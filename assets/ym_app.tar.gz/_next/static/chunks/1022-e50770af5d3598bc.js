(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1022],
  {
    7588: (e, t, a) => {
      "use strict";
      a.d(t, { M: () => i });
      var l = a(74125), s = a(11723), r = a(49124);
      async function i(e2, t2) {
        let { locale: a2, fullUrl: i2, url: o, tld: n, host: u } = t2, d = await (0, l.WGy)(a2), g = e2.title.fullTitle, c = d({ id: "metadata.genre-title" }, { genreTitle: g }), m = "artists" in e2 ? e2.artists : void 0, p = (0, s.f)({ genreTitle: g, artists: m, messageFormatter: d }), f = r.env.ASSET_PREFIX || "", h = "".concat(u).concat(f, "/meta/og-image.png");
        return {
          title: c,
          description: p,
          openGraph: (0, l.i$E)({
            ogTitle: (0, l.NsT)(g),
            ogDescription: p,
            fullUrl: null != i2 ? i2 : "",
            locale: a2,
            siteName: d({ id: "metadata.yandex-music" }),
            ogImage: h
          }),
          twitter: (0, l.HRN)({
            cardType: l.WfF.APP,
            title: c,
            url: null != o ? o : "",
            appName: d({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, l.X5i)({
            additional: { tld: n, url: null != o ? o : "", fullUrl: null != i2 ? i2 : "", host: u },
            appName: d({ id: "metadata.yandex-music" })
          }),
          alternates: (0, l.SEs)("/genre/:metatagId", t2.tld, { params: { metatagId: e2.id } })
        };
      }
    },
    11723: (e, t, a) => {
      "use strict";
      function l(e2) {
        let { genreTitle: t2, artists: a2, messageFormatter: l2 } = e2, s = null;
        return Array.isArray(a2) && (s = a2.slice(0, 3).map((e3) => "artist" in e3 ? e3.artist.name : e3.name).join(", ")), s ? l2({ id: "metadata.genre-description" }, { genreTitle: t2, artistsList: s }) : l2({ id: "metadata.genre-description-short" }, { genreTitle: t2 });
      }
      a.d(t, { f: () => l });
    },
    18753: (e) => {
      e.exports = {
        root: "GenrePlaylistsPage_root__WZwkl",
        scrollContainer: "GenrePlaylistsPage_scrollContainer__N3BZw",
        important: "GenrePlaylistsPage_important__986BX",
        footer: "GenrePlaylistsPage_footer__aMDul",
        item: "GenrePlaylistsPage_item__tUsqJ",
        content: "GenrePlaylistsPage_content__2rKJY"
      };
    },
    33868: (e, t, a) => {
      "use strict";
      a.d(t, { g: () => i });
      var l = a(74125), s = a(11723), r = a(49124);
      async function i(e2, t2) {
        let { locale: a2, fullUrl: i2, url: o, tld: n, host: u } = t2, d = await (0, l.WGy)(a2), g = e2.title.fullTitle, c = d({ id: "metadata.genre-title" }, { genreTitle: g }), m = (0, s.f)({ genreTitle: g, messageFormatter: d }), p = r.env.ASSET_PREFIX || "", f = "".concat(u).concat(p, "/meta/og-image.png");
        return {
          title: c,
          description: m,
          openGraph: (0, l.i$E)({
            ogTitle: (0, l.NsT)(g),
            ogDescription: m,
            fullUrl: null != i2 ? i2 : "",
            locale: a2,
            siteName: d({ id: "metadata.yandex-music" }),
            ogImage: f
          }),
          twitter: (0, l.HRN)({
            cardType: l.WfF.APP,
            title: c,
            url: null != o ? o : "",
            appName: d({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, l.X5i)({
            additional: { tld: n, url: null != o ? o : "", fullUrl: null != i2 ? i2 : "", host: u },
            appName: d({ id: "metadata.yandex-music" })
          }),
          alternates: (0, l.SEs)("/genre/:metatagId/albums", t2.tld, { params: { metatagId: e2.id } })
        };
      }
    },
    38139: (e, t, a) => {
      "use strict";
      a.d(t, { GenrePage: () => y });
      var l = a(54486), s = a(50420), r = a(28303), i = a(97396), o = a(61910), n = a(43426), u = a(56231), d = a(97800), g = a(82644), c = a(94376), m = a(55616), p = a(33276), f = a(83909), h = a(74125), N = a(80585), S = a(7588), L = a(63695), T = a(13611), P = a(50153), _ = a.n(P);
      let y = (0, r.PA)((e2) => {
        let { metatagId: t2, preloadedMeta: a2 } = e2, { genre: r2 } = (0, h.Pjs)(), { formatMessage: P2 } = (0, n.A)(), { contentScrollRef: y2, setContentScrollRef: C } = (0, h.gKY)(), b = (0, h.W6M)();
        return (r2.isNotFound && (0, i.notFound)(), (0, o.useEffect)(
          () => () => {
            r2.reset();
          },
          [r2]
        ), (0, h.Jzs)(r2.isResolved), ((e3) => {
          (0, o.useEffect)(() => {
            if (!e3) return;
            let t3 = ((e4) => ({
              id: "",
              title: { title: "", fullTitle: e4.fullTitle || "" },
              liked: false,
              tracks: [],
              artists: e4.artists.map(L.NE),
              composers: [],
              albums: e4.albums.map(c.fO),
              playlists: e4.playlists.map(T.Ji)
            }))(e3);
            (0, S.M)(t3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, h.jxB)(e4);
            });
          }, [e3]);
        })(r2), t2 && r2.isNeededToLoad && (0, o.use)(r2.getData({ id: t2, preloadedMeta: a2 })), r2.isRejected && !r2.isNotFound) ? (0, l.jsx)(g.w, {}) : (0, l.jsx)(h.nVz, {
          pageId: h._Q$.GENRE,
          children: (0, l.jsxs)(p.hO, {
            scrollElement: y2,
            outerTitle: r2.fullTitle,
            children: [
              (0, l.jsx)(N.Y9, {
                variant: N.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: b.canBack,
                children: (0, l.jsx)(d.Heading, {
                  variant: "h2",
                  weight: "bold",
                  size: "xl",
                  lineClamp: 1,
                  children: r2.fullTitle
                })
              }),
              (0, l.jsx)(u.N, {
                className: _().root,
                containerClassName: _().content,
                ref: C,
                children: (0, l.jsxs)("div", {
                  className: _().carouselBlocks,
                  children: [
                    r2.hasPlaylists && (0, l.jsx)(h.FoH, {
                      blockId: h.hf$.PLAYLISTS_CAROUSEL,
                      blockType: h.hf$.PLAYLISTS_CAROUSEL,
                      blockPosX: 1,
                      blockPosY: 1,
                      blockIdForFrom: h.hf$.PLAYLISTS_CAROUSEL,
                      objectsCount: r2.albums.length,
                      children: (0, l.jsx)(f.EC, {
                        isShimmerVisible: r2.isLoading,
                        isShimmerActive: true,
                        headerClassName: (0, s.$)(_().carouselBlockHeader, _().carouselBlock),
                        containerClassName: _().carouselBlock,
                        playlists: r2.playlists,
                        title: P2({ id: "entity-names.popular-playlists" }),
                        viewAllActionLink: "/genre/".concat(r2.id, "/playlists")
                      })
                    }),
                    r2.hasAlbums && (0, l.jsx)(h.FoH, {
                      blockId: h.hf$.ALBUMS_CAROUSEL,
                      blockType: h.hf$.ALBUMS_CAROUSEL,
                      blockPosX: 1,
                      blockPosY: 2,
                      blockIdForFrom: h.hf$.ALBUMS_CAROUSEL,
                      objectsCount: r2.albums.length,
                      children: (0, l.jsx)(c.pZ, {
                        isShimmerVisible: r2.isLoading,
                        isShimmerActive: true,
                        headerClassName: (0, s.$)(_().carouselBlockHeader, _().carouselBlock),
                        containerClassName: _().carouselBlock,
                        albums: r2.albums,
                        title: P2({ id: "entity-names.new-albums" }),
                        viewAllActionLink: "/genre/".concat(r2.id, "/albums")
                      })
                    }),
                    r2.hasArtists && (0, l.jsx)(h.FoH, {
                      blockId: h.hf$.ARTISTS_CAROUSEL,
                      blockType: h.hf$.ARTISTS_CAROUSEL,
                      blockPosX: 1,
                      blockPosY: 3,
                      blockIdForFrom: h.hf$.ARTISTS_CAROUSEL,
                      objectsCount: r2.albums.length,
                      children: (0, l.jsx)(N.OY, {
                        isShimmerVisible: r2.isLoading,
                        isShimmerActive: true,
                        headerClassName: (0, s.$)(_().carouselBlockHeader, _().carouselBlock),
                        containerClassName: _().carouselBlock,
                        title: P2({ id: "entity-names.popular-artists" }),
                        viewAllActionLink: "/genre/".concat(r2.id, "/artists"),
                        children: r2.artists.map(
                          (e3) => (0, l.jsx)(m.ao, { artist: e3, contentLinesCount: 3 }, e3.id)
                        )
                      })
                    })
                  ]
                })
              })
            ]
          })
        });
      });
    },
    45126: (e, t, a) => {
      "use strict";
      a.d(t, { i: () => i });
      var l = a(74125), s = a(11723), r = a(49124);
      async function i(e2, t2) {
        let { locale: a2, fullUrl: i2, url: o, tld: n, host: u } = t2, d = await (0, l.WGy)(a2), g = e2.title.fullTitle, c = d({ id: "metadata.genre-title" }, { genreTitle: g }), m = "artists" in e2 ? e2.artists : void 0, p = (0, s.f)({ genreTitle: g, artists: m, messageFormatter: d }), f = r.env.ASSET_PREFIX || "", h = "".concat(u).concat(f, "/meta/og-image.png");
        return {
          title: c,
          description: p,
          openGraph: (0, l.i$E)({
            ogTitle: (0, l.NsT)(g),
            ogDescription: p,
            fullUrl: null != i2 ? i2 : "",
            locale: a2,
            siteName: d({ id: "metadata.yandex-music" }),
            ogImage: h
          }),
          twitter: (0, l.HRN)({
            cardType: l.WfF.APP,
            title: c,
            url: null != o ? o : "",
            appName: d({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, l.X5i)({
            additional: { tld: n, url: null != o ? o : "", fullUrl: null != i2 ? i2 : "", host: u },
            appName: d({ id: "metadata.yandex-music" })
          }),
          alternates: (0, l.SEs)("/genre/:metatagId/artists", t2.tld, { params: { metatagId: e2.id } })
        };
      }
    },
    49811: (e, t, a) => {
      "use strict";
      a.d(t, { c: () => l });
      let l = 30;
    },
    49943: (e, t, a) => {
      "use strict";
      a.d(t, { GenreAlbumsPage: () => T });
      var l = a(54486), s = a(50420), r = a(28303), i = a(97396), o = a(61910), n = a(43426), u = a(31500), d = a(97800), g = a(82644), c = a(94376), m = a(33276), p = a(74125), f = a(80585), h = a(49811), N = a(33868), S = a(94189), L = a.n(S);
      let T = (0, r.PA)((e2) => {
        let { metatagId: t2, preloadedMeta: a2 } = e2, {
          genre: { albumsSubpage: r2 },
          settings: { isMobile: S2 }
        } = (0, p.Pjs)(), { formatMessage: T2 } = (0, n.A)(), { contentScrollRef: P, setContentScrollRef: _ } = (0, p.gKY)(), y = (0, p.W6M)(), C = (0, o.useCallback)(
          (e3) => {
            t2 && r2.getData({ metatagId: t2, page: e3, pageSize: h.c });
          },
          [r2, t2]
        );
        (0, p.XcE)(r2.pagesLoader, C), (0, o.useEffect)(
          () => () => {
            r2.reset();
          },
          [r2]
        ), r2.isNotFound && (0, i.notFound)(), (0, p.Jzs)(r2.isResolved), ((e3) => {
          (0, o.useEffect)(() => {
            if (!e3) return;
            let t3 = ((e4) => {
              var t4, a3, l2;
              return {
                id: "",
                title: { title: "", fullTitle: e4.fullTitle || "" },
                albums: e4.items.map(c.fO),
                pager: {
                  page: (null == (t4 = e4.pagesLoader.pager) ? void 0 : t4.page) || 0,
                  perPage: (null == (a3 = e4.pagesLoader.pager) ? void 0 : a3.perPage) || 0,
                  total: (null == (l2 = e4.pagesLoader.pager) ? void 0 : l2.total) || 0
                }
              };
            })(e3);
            (0, N.g)(t3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, p.jxB)(e4);
            });
          }, [e3]);
        })(r2);
        let b = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(f.A, { children: (0, l.jsx)(f.wi, { className: L().footer }) }) }),
          []
        );
        if (t2 && r2.isNeededToLoad && (0, o.use)(r2.getData({ preloadedMeta: a2, metatagId: t2, page: 0, pageSize: h.c })), r2.isSomethingWrong)
          return (0, l.jsx)(g.w, {});
        let E = r2.isShimmerVisible ? 20 : r2.items.length;
        return (0, l.jsx)(p.nVz, {
          pageId: p._Q$.GENRE_ALBUMS,
          children: (0, l.jsx)(m.hO, {
            scrollElement: P,
            outerTitle: r2.fullTitle,
            children: (0, l.jsxs)("div", {
              className: L().root,
              ...(0, u.Am)(u.Xk.genre.GENRE_ALBUMS_PAGE),
              children: [
                (0, l.jsx)(f.Y9, {
                  variant: f.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: y.canBack,
                  children: (0, l.jsx)(d.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: r2.fullTitle
                  })
                }),
                (0, l.jsx)(f.$$, {
                  className: (0, s.$)(L().scrollContainer, L().important),
                  customComponents: b,
                  itemContentCallback: (e3) => {
                    let t3 = r2.items[e3], a3 = T2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: T2({ id: "entity-names.album" }) }
                    );
                    return t3 ? (0, l.jsx)(c.aX, { album: t3, contentLinesCount: 4 }, t3.id) : (0, l.jsx)(f.Vt, { "aria-label": a3, linesCount: 4 });
                  },
                  totalCount: E,
                  onGetDataByPage: C,
                  pageSize: h.c,
                  totalRequests: r2.requestsCount,
                  listClassName: L().content,
                  itemClassName: L().item,
                  handleRef: _,
                  context: { listAriaLabel: T2({ id: "mixes.albums-list" }, { genreName: r2.fullTitle || "" }) },
                  isMobileLayout: S2,
                  useWindowScroll: S2
                })
              ]
            })
          })
        });
      });
    },
    50153: (e) => {
      e.exports = {
        root: "GenrePage_root___kL_v",
        content: "GenrePage_content__NRwAJ",
        shimmerTitle: "GenrePage_shimmerTitle__hrgjK",
        carouselBlocks: "GenrePage_carouselBlocks__kR63B",
        carouselBlock: "GenrePage_carouselBlock__QCkpK",
        carouselBlockHeader: "GenrePage_carouselBlockHeader__u12sn"
      };
    },
    51843: (e, t, a) => {
      "use strict";
      a.d(t, { GenreNotFoundPage: () => i });
      var l = a(54486), s = a(28303), r = a(42421);
      let i = (0, s.PA)(() => (0, l.jsx)(r.M, {}));
    },
    73896: (e, t, a) => {
      "use strict";
      a.d(t, { GenreArtistsPage: () => y });
      var l = a(54486), s = a(28303), r = a(97396), i = a(61910), o = a(43426), n = a(31500), u = a(8817), d = a(56231), g = a(97800), c = a(82644), m = a(55616), p = a(33276), f = a(77516), h = a(74125), N = a(80585), S = a(49811), L = a(45126), T = a(63695), P = a(82975), _ = a.n(P);
      let y = (0, s.PA)((e2) => {
        let { metatagId: t2, preloadedMeta: a2 } = e2, {
          genre: { artistsSubpage: s2 }
        } = (0, h.Pjs)(), { formatMessage: P2 } = (0, o.A)(), { contentScrollRef: y2, setContentScrollRef: C } = (0, h.gKY)(), b = (0, h.W6M)(), E = (0, u.c)(() => 315), A = (0, u.c)(() => {
          var e3;
          return !s2.isShimmerVisible && (null == (e3 = s2.pagesLoader.pager) ? void 0 : e3.total) ? s2.pagesLoader.pager.total : 30;
        }), R = (0, i.useCallback)(
          (e3) => {
            t2 && s2.getData({ metatagId: t2, page: e3, pageSize: S.c });
          },
          [s2, t2]
        ), v = (0, h.ws4)({ pageSize: S.c, callback: R });
        (0, h.XcE)(s2.pagesLoader, R);
        let x = (0, u.c)((e3) => {
          let t3 = s2.items[e3], a3 = P2({ id: "loading-messages.entity-is-loading" }, { entityName: P2({ id: "entity-names.artist" }) });
          return t3 ? (0, l.jsx)(m.ao, { artist: t3, contentLinesCount: 3 }, t3.id) : (0, l.jsx)(N.Vt, { "aria-label": a3, round: true, centered: true });
        });
        return ((0, i.useEffect)(
          () => () => {
            s2.reset();
          },
          [s2]
        ), s2.isNotFound && (0, r.notFound)(), (0, h.Jzs)(s2.isResolved), ((e3) => {
          (0, i.useEffect)(() => {
            if (!e3) return;
            let t3 = ((e4) => {
              var t4, a3, l2;
              return {
                id: "",
                title: { title: "", fullTitle: e4.fullTitle || "" },
                artists: e4.items.map((e5) => ({ artist: (0, T.NE)(e5), popularTracks: [] })),
                pager: {
                  page: (null == (t4 = e4.pagesLoader.pager) ? void 0 : t4.page) || 0,
                  perPage: (null == (a3 = e4.pagesLoader.pager) ? void 0 : a3.perPage) || 0,
                  total: (null == (l2 = e4.pagesLoader.pager) ? void 0 : l2.total) || 0
                }
              };
            })(e3);
            (0, L.i)(t3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, h.jxB)(e4);
            });
          }, [e3]);
        })(s2), t2 && s2.isNeededToLoad && (0, i.use)(s2.getData({ preloadedMeta: a2, metatagId: t2, page: 0, pageSize: S.c })), s2.isSomethingWrong) ? (0, l.jsx)(c.w, {}) : (0, l.jsx)(h.nVz, {
          pageId: h._Q$.GENRE_ARTISTS,
          children: (0, l.jsx)(p.hO, {
            scrollElement: y2,
            outerTitle: s2.fullTitle,
            children: (0, l.jsxs)("div", {
              className: _().root,
              ...(0, n.Am)(n.Xk.genre.GENRE_ARTISTS_PAGE),
              children: [
                (0, l.jsx)(N.Y9, {
                  variant: N.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: b.canBack,
                  children: (0, l.jsx)(g.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: s2.fullTitle
                  })
                }),
                (0, l.jsxs)(d.N, {
                  ref: C,
                  className: _().root,
                  containerClassName: _().container,
                  children: [
                    (0, l.jsx)(f.Q$, {
                      maxColumnCount: 7,
                      count: A(),
                      rowGap: 16,
                      columnGap: 16,
                      getEstimateRowSize: E,
                      minColumnWidth: 170,
                      maxColumnWidth: 270,
                      onChangeRange: v,
                      renderItemByIndex: x
                    }),
                    (0, l.jsx)(N.A, { children: (0, l.jsx)(N.wi, { className: _().footer }) })
                  ]
                })
              ]
            })
          })
        });
      });
    },
    82975: (e) => {
      e.exports = {
        root: "GenreArtistsPage_root__PgtIz",
        container: "GenreArtistsPage_container__NruTu",
        footer: "GenreArtistsPage_footer__fYaCO"
      };
    },
    91022: (e, t, a) => {
      "use strict";
      a.d(t, {
        Z3: () => f.GenreAlbumsPage,
        P0: () => h.GenreArtistsPage,
        L6: () => N.GenrePage,
        G8: () => p,
        ys: () => S.GenrePlaylistsPage
      });
      var l = a(93064), s = a(14287), r = a(94376), i = a(83909), o = a(63695), n = a(74125), u = a(26433);
      let d = l.gK.model("GenreAlbumsPage", {
        pagesLoader: (0, u.Ij)(r.JC),
        errorStatusCode: l.gK.maybeNull(l.gK.number),
        fullTitle: l.gK.maybeNull(l.gK.string)
      }).views((e2) => {
        let t2 = {
          get isNotFound() {
            var a2, l2;
            let t3 = e2.pagesLoader.isSomePageResolved && (null != (l2 = null == (a2 = e2.pagesLoader.items) ? void 0 : a2.length) ? l2 : 0) === 0, r2 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST;
            return e2.pagesLoader.isInitialRequestRejected && r2 || t3;
          },
          get isSomethingWrong() {
            return e2.pagesLoader.isInitialRequestRejected && !t2.isNotFound;
          },
          get isShimmerVisible() {
            return !e2.pagesLoader.isSomePageResolved;
          },
          get isNeededToLoad() {
            return e2.pagesLoader.isNeedToMakeInitialRequest;
          },
          get isResolved() {
            return e2.pagesLoader.isSomePageResolved;
          },
          get requestsCount() {
            return e2.pagesLoader.requestsCount;
          },
          get items() {
            var r2;
            return null != (r2 = e2.pagesLoader.items) ? r2 : [];
          }
        };
        return t2;
      }).actions((e2) => ({
        getData: (0, l.L3)(function* (t2) {
          let { metatagId: a2, page: i2 = 0, pageSize: o2 = 20, preloadedMeta: u2 } = t2, { metatagsResource: d2, modelActionsLogger: g2 } = (0, l._$)(e2);
          if (e2.pagesLoader.isPageNeedToLoad(i2))
            try {
              e2.pagesLoader.setPageState(i2, n.GuX.PENDING);
              let t3 = u2;
              t3 || (t3 = yield d2.getMetatagAlbums({ id: a2, offset: i2, limit: o2 })), e2.fullTitle = t3.title.fullTitle;
              let l2 = t3.albums.map(r.pp);
              e2.pagesLoader.setItems(l2, { page: i2, pager: { page: i2, perPage: o2, total: t3.pager.total } });
            } catch (t3) {
              g2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.pagesLoader.setItems(null, { responseStatus: n.FlZ.ERROR, page: i2 });
            }
        }),
        reset() {
          e2.errorStatusCode = null, e2.fullTitle = null, e2.pagesLoader.reset();
        }
      })), g = l.gK.compose(
        l.gK.model("GenreArtistsPage", {
          errorStatusCode: l.gK.maybeNull(l.gK.number),
          fullTitle: l.gK.maybeNull(l.gK.string),
          pagesLoader: (0, u.Ij)(o.PK)
        }),
        u.XT
      ).views((e2) => {
        let t2 = {
          get isNotFound() {
            var a2;
            let t3 = e2.isResolved && (null == (a2 = e2.pagesLoader.pager) ? void 0 : a2.total) === 0, l2 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST;
            return e2.isRejected && l2 || t3;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          },
          get isShimmerVisible() {
            return !e2.pagesLoader.isSomePageResolved;
          },
          get isNeededToLoad() {
            return e2.pagesLoader.isNeedToMakeInitialRequest;
          },
          get isRejected() {
            return e2.pagesLoader.isInitialRequestRejected;
          },
          get isEmpty() {
            return e2.pagesLoader.isEmpty;
          },
          get isResolved() {
            return e2.pagesLoader.isSomePageResolved;
          },
          get requestsCount() {
            return e2.pagesLoader.requestsCount;
          },
          get items() {
            return e2.pagesLoader.items || [];
          }
        };
        return t2;
      }).actions((e2) => ({
        getData: (0, l.L3)(function* (t2) {
          let { metatagId: a2, page: r2 = 0, pageSize: i2 = 20, preloadedMeta: u2 } = t2, { metatagsResource: d2, modelActionsLogger: g2 } = (0, l._$)(e2);
          if (e2.pagesLoader.isPageNeedToLoad(r2))
            try {
              e2.pagesLoader.setPageState(r2, n.GuX.PENDING);
              let t3 = u2;
              t3 || (t3 = yield d2.getMetatagArtists({ id: a2, offset: r2, limit: i2, period: "week" })), e2.fullTitle = t3.title.fullTitle;
              let l2 = t3.artists.map((e3) => (0, o.dM)(e3.artist));
              e2.pagesLoader.setItems(l2, { page: r2, pager: t3.pager });
            } catch (t3) {
              g2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.pagesLoader.setItems(null, { responseStatus: n.FlZ.ERROR, page: r2 });
            }
        }),
        reset() {
          e2.errorStatusCode = null, e2.pagesLoader.reset();
        }
      }));
      var c = a(13611);
      let m = l.gK.model("GenrePlaylistsPage", {
        pagesLoader: (0, u.Ij)(c.$o),
        errorStatusCode: l.gK.maybeNull(l.gK.number),
        fullTitle: l.gK.maybeNull(l.gK.string)
      }).views((e2) => {
        let t2 = {
          get isNotFound() {
            var a2, l2;
            let t3 = e2.pagesLoader.isSomePageResolved && (null != (l2 = null == (a2 = e2.pagesLoader.items) ? void 0 : a2.length) ? l2 : 0) === 0, r2 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST;
            return e2.pagesLoader.isInitialRequestRejected && r2 || t3;
          },
          get isSomethingWrong() {
            return e2.pagesLoader.isInitialRequestRejected && !t2.isNotFound;
          },
          get isShimmerVisible() {
            return !e2.pagesLoader.isSomePageResolved;
          },
          get isNeededToLoad() {
            return e2.pagesLoader.isNeedToMakeInitialRequest;
          },
          get isResolved() {
            return e2.pagesLoader.isSomePageResolved;
          },
          get requestsCount() {
            return e2.pagesLoader.requestsCount;
          },
          get items() {
            var r2;
            return null != (r2 = e2.pagesLoader.items) ? r2 : [];
          }
        };
        return t2;
      }).actions((e2) => ({
        getData: (0, l.L3)(function* (t2) {
          let { metatagId: a2, page: s2 = 0, pageSize: r2 = 20, preloadedMeta: i2 } = t2, { metatagsResource: o2, modelActionsLogger: u2 } = (0, l._$)(e2);
          if (e2.pagesLoader.isPageNeedToLoad(s2))
            try {
              e2.pagesLoader.setPageState(s2, n.GuX.PENDING);
              let t3 = i2;
              t3 || (t3 = yield o2.getMetatagPlaylists({ id: a2, offset: s2, limit: r2, withLikesCount: true })), e2.fullTitle = t3.title.fullTitle;
              let l2 = t3.playlists.map(c.jX);
              e2.pagesLoader.setItems(l2, { page: s2, pager: { page: s2, perPage: r2, total: t3.pager.total } });
            } catch (t3) {
              u2.error(t3), e2.pagesLoader.setItems(null, { responseStatus: n.FlZ.ERROR, page: s2 });
            }
        }),
        reset() {
          e2.pagesLoader.reset(), e2.errorStatusCode = null, e2.fullTitle = null;
        }
      })), p = l.gK.compose(
        l.gK.model("GenrePage", {
          id: l.gK.maybeNull(l.gK.string),
          errorStatusCode: l.gK.maybeNull(l.gK.number),
          fullTitle: l.gK.maybeNull(l.gK.string),
          artists: l.gK.array(o.PK),
          albums: l.gK.array(r.JC),
          playlists: l.gK.array(i.IP),
          albumsSubpage: d,
          artistsSubpage: g,
          playlistsSubpage: m
        }),
        u.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === n.GuX.PENDING;
          },
          get hasAlbums() {
            return t2.isLoading || e2.albums.length > 0;
          },
          get hasArtists() {
            return t2.isLoading || e2.artists.length > 0;
          },
          get hasPlaylists() {
            return t2.isLoading || e2.playlists.length > 0;
          },
          get isNotFound() {
            let a2 = e2.isResolved && !t2.hasAlbums && !t2.hasArtists && !t2.hasPlaylists, l2 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST;
            return e2.isRejected && l2 || a2;
          }
        };
        return t2;
      }).actions((e2) => ({
        getData: (0, l.L3)(function* (t2) {
          let { id: a2, preloadedMeta: u2 } = t2, { metatagsResource: d2, modelActionsLogger: g2 } = (0, l._$)(e2);
          if (e2.loadingState !== n.GuX.PENDING)
            try {
              e2.loadingState = n.GuX.PENDING;
              let t3 = u2;
              t3 || (t3 = yield d2.getMetatagById({ id: a2 })), e2.id = t3.id, e2.fullTitle = t3.title.fullTitle, e2.artists = (0, l.wg)(t3.artists.map(o.dM)), e2.albums = (0, l.wg)(t3.albums.map(r.pp)), e2.playlists = (0, l.wg)(t3.playlists.map(i.ZC)), e2.loadingState !== n.GuX.IDLE && (e2.loadingState = n.GuX.RESOLVE);
            } catch (t3) {
              g2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== n.GuX.IDLE && (e2.loadingState = n.GuX.REJECT);
            }
        }),
        reset() {
          e2.loadingState = n.GuX.IDLE, e2.fullTitle = null, e2.artists = (0, l.wg)([]), e2.albums = (0, l.wg)([]), e2.playlists = (0, l.wg)([]);
        }
      }));
      var f = a(49943), h = a(73896);
      a(51843);
      var N = a(38139), S = a(93405);
      a(33868), a(45126), a(7588), a(96777);
      var L = a(61910), T = a(49811);
      let P = async (e2, t2) => {
        try {
          let {
            container: a2,
            backendHostTld: l2,
            locale: s2,
            host: r2,
            fullUrl: i2,
            isRSC: o2,
            requestUrl: u2
          } = await (0, n.IhE)();
          if (!e2 || o2) return { genreMeta: void 0, tld: "", locale: null, host: "", fullUrl: null, url: null };
          let d2 = a2.get(n.UtQ);
          return { genreMeta: await t2(d2, e2), tld: l2, locale: s2, host: r2, fullUrl: i2, url: u2 };
        } catch (e3) {
          return (0, n.tfF)(e3, () => ({
            genreMeta: void 0,
            tld: "",
            locale: null,
            host: "",
            fullUrl: null,
            url: null
          }));
        }
      };
      (0, L.cache)(async (e2) => P(e2, async (e3, t2) => e3.getMetatagAlbums({ id: t2, offset: 0, limit: T.c }))), (0, L.cache)(
        async (e2) => P(e2, async (e3, t2) => e3.getMetatagArtists({ id: t2, offset: 0, limit: T.c, period: "week" }))
      ), (0, L.cache)(async (e2) => P(e2, async (e3, t2) => e3.getMetatagById({ id: t2 }))), (0, L.cache)(
        async (e2) => P(e2, async (e3, t2) => e3.getMetatagPlaylists({ id: t2, offset: 0, limit: T.c, withLikesCount: true }))
      );
    },
    93405: (e, t, a) => {
      "use strict";
      a.d(t, { GenrePlaylistsPage: () => P });
      var l = a(54486), s = a(50420), r = a(28303), i = a(97396), o = a(61910), n = a(43426), u = a(31500), d = a(97800), g = a(82644), c = a(33276), m = a(83909), p = a(74125), f = a(80585), h = a(49811), N = a(96777), S = a(13611), L = a(18753), T = a.n(L);
      let P = (0, r.PA)((e2) => {
        let { metatagId: t2, preloadedMeta: a2 } = e2, {
          genre: { playlistsSubpage: r2 },
          settings: { isMobile: L2 }
        } = (0, p.Pjs)(), { formatMessage: P2 } = (0, n.A)(), { contentScrollRef: _, setContentScrollRef: y } = (0, p.gKY)(), C = (0, p.W6M)(), b = (0, o.useCallback)(
          (e3) => {
            t2 && r2.getData({ metatagId: t2, page: e3, pageSize: h.c });
          },
          [r2, t2]
        );
        (0, p.XcE)(r2.pagesLoader, b), (0, o.useEffect)(
          () => () => {
            r2.reset();
          },
          [r2]
        ), r2.isNotFound && (0, i.notFound)(), (0, p.Jzs)(r2.isResolved), ((e3) => {
          (0, o.useEffect)(() => {
            if (!e3) return;
            let t3 = ((e4) => {
              var t4, a3, l2;
              return {
                id: "",
                title: { title: "", fullTitle: e4.fullTitle || "" },
                playlists: e4.items.map(S.Ji),
                pager: {
                  page: (null == (t4 = e4.pagesLoader.pager) ? void 0 : t4.page) || 0,
                  perPage: (null == (a3 = e4.pagesLoader.pager) ? void 0 : a3.perPage) || 0,
                  total: (null == (l2 = e4.pagesLoader.pager) ? void 0 : l2.total) || 0
                }
              };
            })(e3);
            (0, N.H)(t3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, p.jxB)(e4);
            });
          }, [e3]);
        })(r2);
        let E = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(f.A, { children: (0, l.jsx)(f.wi, { className: T().footer }) }) }),
          []
        );
        if (t2 && r2.isNeededToLoad && (0, o.use)(r2.getData({ preloadedMeta: a2, metatagId: t2, page: 0, pageSize: h.c })), r2.isSomethingWrong)
          return (0, l.jsx)(g.w, {});
        let A = r2.isShimmerVisible ? 20 : r2.items.length;
        return (0, l.jsx)(p.nVz, {
          pageId: p._Q$.GENRE_PLAYLISTS,
          children: (0, l.jsx)(c.hO, {
            scrollElement: _,
            outerTitle: r2.fullTitle,
            children: (0, l.jsxs)("div", {
              className: T().root,
              ...(0, u.Am)(u.Xk.genre.GENRE_PLAYLISTS_PAGE),
              children: [
                (0, l.jsx)(f.Y9, {
                  variant: f.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: C.canBack,
                  children: (0, l.jsx)(d.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: r2.fullTitle
                  })
                }),
                (0, l.jsx)(f.$$, {
                  className: (0, s.$)(T().scrollContainer, T().important),
                  customComponents: E,
                  itemContentCallback: (e3) => {
                    let t3 = r2.items[e3], a3 = P2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: P2({ id: "entity-names.playlist" }) }
                    );
                    return t3 ? (0, l.jsx)(m.B6, { playlist: t3, contentLinesCount: 3 }, t3.key) : (0, l.jsx)(f.Vt, { "aria-label": a3 });
                  },
                  totalCount: A,
                  onGetDataByPage: b,
                  pageSize: h.c,
                  totalRequests: r2.requestsCount,
                  listClassName: T().content,
                  itemClassName: T().item,
                  handleRef: y,
                  context: { listAriaLabel: P2({ id: "mixes.playlists-list" }, { genreName: r2.fullTitle || "" }) },
                  isMobileLayout: L2,
                  useWindowScroll: L2
                })
              ]
            })
          })
        });
      });
    },
    94189: (e) => {
      e.exports = {
        root: "GenreAlbumsPage_root__r_Sts",
        scrollContainer: "GenreAlbumsPage_scrollContainer__K_v_b",
        important: "GenreAlbumsPage_important__r3P2T",
        footer: "GenreAlbumsPage_footer__vmCiR",
        item: "GenreAlbumsPage_item__zRzB0",
        content: "GenreAlbumsPage_content__PRJUm"
      };
    },
    96777: (e, t, a) => {
      "use strict";
      a.d(t, { H: () => i });
      var l = a(74125), s = a(11723), r = a(49124);
      async function i(e2, t2) {
        let { locale: a2, fullUrl: i2, url: o, tld: n, host: u } = t2, d = await (0, l.WGy)(a2), g = e2.title.fullTitle, c = d({ id: "metadata.genre-title" }, { genreTitle: g }), m = (0, s.f)({ genreTitle: g, messageFormatter: d }), p = r.env.ASSET_PREFIX || "", f = "".concat(u).concat(p, "/meta/og-image.png");
        return {
          title: c,
          description: m,
          openGraph: (0, l.i$E)({
            ogTitle: (0, l.NsT)(g),
            ogDescription: m,
            fullUrl: null != i2 ? i2 : "",
            locale: a2,
            siteName: d({ id: "metadata.yandex-music" }),
            ogImage: f
          }),
          twitter: (0, l.HRN)({
            cardType: l.WfF.APP,
            title: c,
            url: null != o ? o : "",
            appName: d({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, l.X5i)({
            additional: { tld: n, url: null != o ? o : "", fullUrl: null != i2 ? i2 : "", host: u },
            appName: d({ id: "metadata.yandex-music" })
          }),
          alternates: (0, l.SEs)("/genre/:metatagId/playlists", t2.tld, { params: { metatagId: e2.id } })
        };
      }
    }
  }
]);
