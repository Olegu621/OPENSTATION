(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1308],
  {
    1019: (e, t, a) => {
      "use strict";
      a.d(t, { KidsEditorialAlbumsPage: () => E });
      var r = a(54486), i = a(50420), s = a(28303), n = a(97396), l = a(61910), o = a(43426), d = a(31500), u = a(8817), c = a(27510), h = a(97800), g = a(82644), y = a(94376), m = a(33276), p = a(74125), v = a(80585), P = a(22603), S = a.n(P);
      let E = (0, s.PA)((e2) => {
        var t2, a2, s2, P2;
        let { id: E2 } = e2, {
          kids: { kidsEditorialAlbumSubpage: f },
          settings: { isMobile: b }
        } = (0, p.Pjs)(), I = (0, p.W6M)(), { contentScrollRef: _, setContentScrollRef: k } = (0, p.gKY)(), { formatMessage: C } = (0, o.A)(), T = (0, u.c)((e3) => {
          f.getAlbums({ page: e3, pageSize: 20 });
        });
        f.isNotFound && (0, n.notFound)(), (0, l.useEffect)(
          () => () => {
            f.reset();
          },
          [f]
        );
        let D = (0, c.L)(() => ({
          Footer: () => (0, r.jsx)(v.A, { children: (0, r.jsx)(v.wi, { className: S().footer }) })
        }));
        if ((0, p.Jzs)(f.isResolved), (0, p.XcE)(f.pagesLoader, T), f.isNeededToLoad && (0, l.use)(f.getData({ id: E2, page: 0, pageSize: 20 })), f.isSomethingWrong)
          return (0, r.jsx)(g.w, {});
        let A = f.isLoading ? 20 : null != (s2 = null == (a2 = f.pagesLoader) || null == (t2 = a2.pager) ? void 0 : t2.total) ? s2 : 0;
        return (0, r.jsx)(p.nVz, {
          pageId: p._Q$.KIDS_EDITORIAL_ALBUMS,
          children: (0, r.jsx)(m.hO, {
            scrollElement: _,
            outerTitle: f.title,
            children: (0, r.jsxs)("div", {
              className: S().root,
              ...(0, d.Am)(d.Xk.kids.KIDS_EDITORIAL_ALBUMS),
              children: [
                (0, r.jsx)(v.Y9, {
                  variant: v.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: I.canBack,
                  children: (0, r.jsx)(h.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: f.title
                  })
                }),
                (0, r.jsx)(v.$$, {
                  context: { listAriaLabel: C({ id: "mixes.albums-list" }, { genreName: f.title || "" }) },
                  className: (0, i.$)(S().scrollContainer, S().important),
                  customComponents: D,
                  itemContentCallback: (e3) => {
                    let t3 = f.albums[e3], a3 = C(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: C({ id: "entity-names.album" }) }
                    );
                    return t3 ? (0, r.jsx)(y.aX, { withLikesCount: true, album: t3, contentLinesCount: 3 }, t3.id) : (0, r.jsx)(v.Vt, { isActive: true, "aria-label": a3 });
                  },
                  totalCount: A,
                  onGetDataByPage: T,
                  pageSize: 20,
                  totalRequests: null != (P2 = f.pagesLoader.requestsCount) ? P2 : 0,
                  listClassName: S().content,
                  itemClassName: S().item,
                  handleRef: k,
                  isMobileLayout: b,
                  useWindowScroll: b
                })
              ]
            })
          })
        });
      });
    },
    1320: (e) => {
      e.exports = {
        root: "UgcUploadCenterNotification_root__K_U0z",
        title: "UgcUploadCenterNotification_title__s3yTL",
        link: "UgcUploadCenterNotification_link__NPz6r"
      };
    },
    3062: (e) => {
      e.exports = {
        root: "GenresPage_root__LhP_S",
        shimmerTitle: "GenresPage_shimmerTitle__4j8uH",
        content: "GenresPage_content__yhKrQ",
        list: "GenresPage_list__l2Cuc"
      };
    },
    3070: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { AnalyticsProvider: () => n });
      var r = a(54486), i = a(62395), s = a(74125);
      let n = (e2) => {
        let { children: t2 } = e2, a2 = (0, s.UlF)(), n2 = (0, s.NFA)(), l = "on" === n2.get(s.ooW).get(s.cYZ.AllowAnalyticsLogs), o = n2.get(s.vgk);
        return (0, r.jsx)(i.vZ, { metrika: o, allowAnalyticsLogs: l, evgenUserParam: "evgen", logger: a2, children: t2 });
      };
    },
    4968: (e, t, a) => {
      "use strict";
      a.d(t, { ShortcutsProvider: () => d });
      var r = a(54486), i = a(28303), s = a(61910), n = a(74125), l = a(65429);
      let o = null, d = (0, i.PA)((e2) => {
        let { children: t2 } = e2, { sonataState: a2 } = (0, n.Pjs)(), i2 = (0, s.useMemo)(() => (o || (o = new n.G8o(new n.z$B())), o), []);
        return (0, l.E)({ controller: i2, sonataState: a2, groupId: n.Mo.MAIN }), (0, s.useEffect)(
          () => (null == i2 || i2.listen(), () => {
            null == i2 || i2.stopListening();
          }),
          [i2]
        ), (0, r.jsx)(n.Pic.Provider, { value: i2, children: t2 });
      });
    },
    6923: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { ContainerProvider: () => u });
      var r = a(54486), i = a(61910), s = a(74125), n = a(80585);
      let l = null, o = async (e2) => {
        let {
          userAgent: t2,
          hostTld: a2,
          forwardedForY: r2,
          changeLanguageToken: i2,
          tracestate: n2,
          traceparent: l2,
          icookie: o2,
          serverDetectedLocale: d2,
          env: u2,
          browserName: c,
          browserVersion: h,
          executionContextStore: g
        } = e2, y = await (0, s.MyF)({
          userAgent: t2,
          tld: a2,
          forwardedForY: r2,
          changeLanguageToken: i2,
          tracestate: n2,
          traceparent: l2,
          icookie: o2,
          serverDetectedLocale: d2,
          env: u2,
          browserName: c,
          browserVersion: h,
          executionContextStore: g
        });
        return await y.get(s.Xc9).loadDictionary(), y;
      }, d = (e2) => {
        let { children: t2, containerLoader: a2 } = e2;
        return l || (l = (0, i.use)(a2)), (0, r.jsx)(s.Bz0.Provider, { value: l, children: t2 });
      }, u = (e2) => {
        let {
          children: t2,
          hostTld: a2,
          env: s2,
          forwardedForY: l2,
          tracestate: u2,
          traceparent: c,
          icookie: h,
          changeLanguageToken: g,
          serverDetectedLocale: y,
          userAgent: m,
          browserName: p,
          browserVersion: v,
          executionContextStore: P
        } = e2, S = o({
          userAgent: m,
          hostTld: a2,
          forwardedForY: l2,
          changeLanguageToken: g,
          tracestate: u2,
          traceparent: c,
          icookie: h,
          serverDetectedLocale: y,
          env: s2,
          browserName: p,
          browserVersion: v,
          executionContextStore: P
        });
        return (0, r.jsx)(i.Suspense, {
          fallback: (0, r.jsx)(n.JR, {}),
          children: (0, r.jsx)(d, { containerLoader: S, children: t2 })
        });
      };
    },
    9089: (e, t, a) => {
      "use strict";
      a.d(t, { oN: () => d.TagPage, vV: () => o });
      var r = a(93064), i = a(14287), s = a(13611), n = a(74125), l = a(26433);
      let o = r.gK.model("TagPage", {
        title: r.gK.maybe(r.gK.string),
        errorStatusCode: r.gK.maybeNull(r.gK.number),
        tagLoadingState: r.gK.enumeration(Object.values(n.GuX)),
        playlistsData: r.gK.array(r.gK.model({ uid: r.gK.number, kind: r.gK.number })),
        pagesLoader: (0, l.Ij)(s.$o)
      }).views((e2) => {
        let t2 = {
          get isNeededToLoad() {
            return e2.tagLoadingState === n.GuX.IDLE;
          },
          get isResolved() {
            return e2.tagLoadingState === n.GuX.RESOLVE;
          },
          get isNotFound() {
            let t3 = e2.pagesLoader.isEmpty;
            return e2.tagLoadingState === n.GuX.REJECT && (e2.errorStatusCode === i.X1.NOT_FOUND || e2.errorStatusCode === i.X1.BAD_REQUEST) || t3;
          },
          get isSomethingWrong() {
            return e2.tagLoadingState === n.GuX.REJECT && !t2.isNotFound;
          },
          get playlists() {
            var a2;
            return null != (a2 = e2.pagesLoader.items) ? a2 : [];
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          getPlaylists: (0, r.L3)(function* (t3) {
            let { page: a2 = 0, pageSize: l2 = 20 } = t3, { playlistsResource: o2, modelActionsLogger: d2 } = (0, r._$)(e2);
            if (e2.tagLoadingState === n.GuX.RESOLVE && e2.pagesLoader.isPageNeedToLoad(a2))
              try {
                e2.pagesLoader.setPageState(a2, n.GuX.PENDING);
                let t4 = a2 * l2, r2 = e2.playlistsData.slice(t4, t4 + l2), i2 = yield o2.getPlaylists({
                  playlistIds: r2.map((e3) => "".concat(e3.uid, ":").concat(e3.kind)),
                  resumeStream: false
                }), d3 = { page: a2, perPage: l2, total: e2.playlistsData.length }, u = i2.playlists.map(s.jX);
                e2.pagesLoader.setItems(u, { page: a2, pager: d3 });
              } catch (t4) {
                d2.error(t4), e2.pagesLoader.setItems(null, { responseStatus: n.FlZ.ERROR, page: a2 }), t4 instanceof i.GX && (t4.statusCode === i.X1.NOT_FOUND || t4.statusCode === i.X1.BAD_REQUEST) && (e2.errorStatusCode = i.X1.NOT_FOUND);
              }
          }),
          reset() {
            e2.pagesLoader.reset(), e2.tagLoadingState = n.GuX.IDLE, e2.title = void 0, e2.playlistsData = (0, r.wg)([]), e2.errorStatusCode = null;
          },
          getTag: (0, r.L3)(function* (a2) {
            let { id: s2, page: l2 = 0, pageSize: o2 = 20 } = a2, { tagResource: d2, modelActionsLogger: u } = (0, r._$)(e2);
            if (e2.tagLoadingState !== n.GuX.PENDING)
              try {
                var c;
                e2.tagLoadingState = n.GuX.PENDING;
                let a3 = yield d2.getPlaylistIds({ id: s2 });
                e2.title = null == (c = a3.tag) ? void 0 : c.name, e2.playlistsData = (0, r.wg)(a3.ids.map((e3) => ({ uid: e3.uid, kind: e3.kind }))), e2.tagLoadingState !== n.GuX.IDLE && (e2.tagLoadingState = n.GuX.RESOLVE), yield t2.getPlaylists({ page: l2, pageSize: o2 });
              } catch (t3) {
                u.error(t3), t3 instanceof i.GX && (t3.statusCode === i.X1.NOT_FOUND || t3.statusCode === i.X1.BAD_REQUEST) && (e2.errorStatusCode = i.X1.NOT_FOUND), e2.tagLoadingState !== n.GuX.IDLE && (e2.tagLoadingState = n.GuX.REJECT);
              }
          })
        };
        return t2;
      });
      a(94716);
      var d = a(56440);
    },
    9567: (e, t, a) => {
      "use strict";
      a.d(t, { MyMusicDownloadedTracksPage: () => R });
      var r = a(54486), i = a(50420), s = a(28303), n = a(61910), l = a(43426), o = a(31500), d = a(63585), u = a(8817), c = a(89511), h = a(82644), g = a(33276), y = a(21365), m = a(74125), p = a(80585), v = a(76310), P = a.n(v), S = a(47713), E = a(5956), f = a(97800), b = a(14114), I = a.n(b);
      let _ = (0, s.PA)(() => {
        var e2;
        let {
          myMusic: { downloadedTracks: t2 }
        } = (0, m.Pjs)(), a2 = (0, r.jsx)(f.Caption, { variant: "span", size: "s", weight: "medium", "aria-hidden": true, children: "•" }), i2 = [];
        (null == (e2 = t2.tracks) ? void 0 : e2.length) && i2.push(
          (0, r.jsx)(f.Caption, {
            variant: "span",
            size: "s",
            weight: "medium",
            lineClamp: 1,
            children: (0, r.jsx)(S.A, { id: "entity-names.tracks-count", values: { value: t2.tracks.length } })
          })
        );
        let s2 = Math.floor(t2.tracksDurationInMinutes / 60), l2 = Math.floor(t2.tracksDurationInMinutes % 60);
        return (s2 || l2) && (i2.push(a2), i2.push(
          (0, r.jsx)(f.Caption, {
            variant: "span",
            size: "s",
            weight: "medium",
            children: (0, r.jsx)(S.A, { id: "time.hours-minutes", values: { hours: s2, minutes: l2 } })
          })
        )), (0, r.jsx)("div", { className: I().root, children: i2.map((e3, t3) => (0, n.cloneElement)(e3, { key: t3 })) });
      });
      var k = a(12962), C = a.n(k);
      let T = (0, s.PA)(() => {
        let { isScrolling: e2 } = (0, n.useContext)(p.B9), t2 = (0, m.W6M)(), {
          myMusic: { downloadedTracks: a2 },
          settings: { isMobile: i2 },
          slam: s2
        } = (0, m.Pjs)(), { from: l2 } = (0, m.fyy)({ pageId: m._Q$.OWN_TRACKS, blockId: m.UfI.TRACK_LIST }), o2 = (0, m.PT7)(), c2 = (0, m.brA)(), { isPlaying: h2, togglePlay: g2 } = (0, m.Dx4)({
          playContextParams: {
            contextData: { type: d.K.Various, meta: { id: m._Q$.DOWNLOADS_TRACKS }, from: l2 },
            entitiesData: a2.entitiesData,
            loadContextMeta: false
          }
        }), y2 = (0, u.c)(() => {
          o2() || (g2(), c2(!h2));
        });
        return (0, r.jsx)("header", {
          className: C().root,
          "aria-hidden": e2,
          children: (0, r.jsxs)("div", {
            className: C().container,
            children: [
              !s2.isOfflineModeEnabled && t2.canBack && (0, r.jsx)(p.Lh, {
                withForwardControl: false,
                withBackwardControl: t2.canBack,
                shouldFocusOnMount: !e2,
                buttonSize: "xxs"
              }),
              (0, r.jsxs)("div", {
                className: C().titleContainer,
                children: [
                  (0, r.jsx)(f.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xs",
                    lineClamp: 1,
                    className: C().title,
                    children: (0, r.jsx)(S.A, { id: "offline.downloaded-tracks" })
                  }),
                  (0, r.jsx)(_, {})
                ]
              }),
              !a2.isEmpty && (0, r.jsx)(p.DM, {
                withRipple: true,
                buttonVariant: "default",
                radius: "xxxl",
                size: "s",
                color: "primary",
                iconSize: "xxs",
                isPlaying: h2,
                onClick: y2,
                className: C().playButton,
                ariaHidden: e2,
                tabIndex: e2 ? -1 : 0,
                children: !i2 && (0, r.jsx)(S.A, { id: "player-actions.listen" })
              })
            ]
          })
        });
      });
      var D = a(61336), A = a.n(D);
      let x = (0, s.PA)(
        () => (0, r.jsxs)(r.Fragment, {
          children: [
            (0, r.jsx)(T, {}),
            (0, r.jsxs)("div", {
              className: A().root,
              children: [
                (0, r.jsx)(E.Icon, { className: A().icon, size: "l", variant: "download" }),
                (0, r.jsx)(f.Heading, {
                  className: A().title,
                  variant: "div",
                  size: "xs",
                  children: (0, r.jsx)(S.A, { id: "offline.downloaded-empty" })
                }),
                (0, r.jsx)(f.Caption, {
                  className: A().text,
                  variant: "span",
                  type: "controls",
                  size: "l",
                  weight: "normal",
                  children: (0, r.jsx)(S.A, { id: "offline.download-for-offline" })
                })
              ]
            })
          ]
        })
      ), L = (0, s.PA)(() => {
        let { isScrolling: e2 } = (0, n.useContext)(p.B9), t2 = (0, m.W6M)(), {
          myMusic: { downloadedTracks: a2 },
          settings: { isMobile: s2 },
          slam: l2
        } = (0, m.Pjs)(), { from: o2 } = (0, m.fyy)({ pageId: m._Q$.OWN_TRACKS, blockId: m.UfI.TRACK_LIST }), c2 = (0, m.brA)(), h2 = (0, m.PT7)(), { isPlaying: g2, togglePlay: y2 } = (0, m.Dx4)({
          playContextParams: {
            contextData: { type: d.K.Various, meta: { id: m._Q$.DOWNLOADS_TRACKS }, from: o2 },
            entitiesData: a2.entitiesData,
            loadContextMeta: false
          }
        }), v2 = (0, u.c)(() => {
          h2() || (y2(), c2(!g2));
        });
        return (0, r.jsx)(p.Y9, {
          variant: p.Vw.COMPOSITE,
          "aria-hidden": !e2,
          stickyChild: (0, r.jsxs)("div", {
            className: C().container,
            children: [
              !l2.isOfflineModeEnabled && t2.canBack && (0, r.jsx)(p.Lh, {
                withForwardControl: false,
                withBackwardControl: t2.canBack,
                shouldFocusOnMount: false,
                buttonSize: "xxs"
              }),
              (0, r.jsx)(f.Heading, {
                variant: "h1",
                weight: "bold",
                size: "xs",
                lineClamp: 1,
                className: C().stickyTitle,
                children: (0, r.jsx)(S.A, { id: "offline.downloaded-tracks" })
              }),
              !a2.isEmpty && (0, r.jsx)(p.DM, {
                withRipple: true,
                buttonVariant: "default",
                radius: "xxxl",
                size: "s",
                color: "primary",
                iconSize: "xxs",
                isPlaying: g2,
                onClick: v2,
                className: (0, i.$)(C().playButton, { [C().stickyPlayButton]: !s2 }),
                ariaHidden: !e2,
                tabIndex: e2 ? 0 : -1,
                children: !s2 && (0, r.jsx)(S.A, { id: "player-actions.listen" })
              })
            ]
          }),
          stickyClassName: (0, i.$)(C().stickyHeader, C().important),
          staticClassName: (0, i.$)(C().staticHeader, C().important)
        });
      }), R = (0, s.PA)(() => {
        var e2;
        let t2 = (0, m.jRO)(), { contentScrollRef: a2, setContentScrollRef: s2 } = (0, m.gKY)(), { formatMessage: v2 } = (0, l.A)(), {
          myMusic: { downloadedTracks: S2 }
        } = (0, m.Pjs)(), { from: E2 } = (0, m.fyy)({ pageId: m._Q$.OWN_TRACKS, blockId: m.UfI.TRACK_LIST }), f2 = (0, m.wZZ)(), b2 = (0, u.c)(() => {
          t2.tracksController && S2.getData(t2.tracksController);
        });
        (0, c.L)(b2), (0, n.useEffect)(() => {
          S2.isNeededToLoad && b2();
        }, [S2.isNeededToLoad, b2]), (0, n.useEffect)(
          () => () => {
            S2.reset();
          },
          [S2]
        ), (0, m.Jzs)(S2.isResolved);
        let I2 = (0, n.useMemo)(
          () => ({
            Header: () => (0, r.jsx)(T, {}),
            Footer: () => (0, r.jsx)(p.A, { children: (0, r.jsx)(p.wi, { className: P().footer }) })
          }),
          []
        );
        if (S2.loadingState === m.GuX.REJECT) return (0, r.jsx)(h.w, {});
        if (S2.isEmpty) return (0, r.jsx)(x, {});
        let _2 = (null == (e2 = S2.items) ? void 0 : e2.length) || 10;
        return (0, r.jsx)(m.nVz, {
          pageId: m._Q$.DOWNLOADS_TRACKS,
          children: (0, r.jsx)(g.hO, {
            scrollElement: a2,
            children: (0, r.jsxs)("div", {
              className: P().pageContainer,
              children: [
                (0, r.jsx)(L, {}),
                (0, r.jsx)(p.$$, {
                  context: { listAriaLabel: v2({ id: "offline.downloaded-track-list" }) },
                  className: (0, i.$)(P().root, P().important),
                  listClassName: P().content,
                  customComponents: I2,
                  totalCount: _2,
                  itemContentCallback: (e3) => {
                    var t3;
                    let a3 = null == (t3 = S2.items) ? void 0 : t3[e3];
                    return a3 ? (0, r.jsx)(
                      y.Kt,
                      {
                        track: a3,
                        playContextParams: f2(a3.id, {
                          contextData: { type: d.K.Various, meta: { id: m._Q$.DOWNLOADS_TRACKS }, from: E2 },
                          entitiesData: S2.entitiesData,
                          queueParams: { index: e3, entityId: a3.id },
                          loadContextMeta: false
                        })
                      },
                      a3.id
                    ) : (0, r.jsx)(p.DS, { isActive: true, className: P().trackShimmer, variant: m.Xjt.PLAYLIST });
                  },
                  debounceDurationInMs: 300,
                  initialItemCount: _2,
                  handleRef: s2,
                  shouldTriggerRangeChangedOn: [_2],
                  testId: o.Xk.myMusic.MY_MUSIC_DOWNLOADED_TRACKS_PAGE
                })
              ]
            })
          })
        });
      });
    },
    11189: (e, t, a) => {
      "use strict";
      a.d(t, { bp: () => E, A6: () => G, Bd: () => c });
      var r = a(93064);
      let i = r.gK.model("ConcertDescription", {
        text: r.gK.string,
        genre: r.gK.maybe(r.gK.string),
        source: r.gK.maybe(r.gK.string)
      });
      var s = a(14287), n = a(4542), l = a(63695), o = a(77217), d = a(74125), u = a(26433);
      let c = r.gK.compose(
        r.gK.model("ConcertPage", {
          meta: r.gK.maybeNull(o.aR),
          covers: r.gK.maybeNull(r.gK.array(u.$B)),
          description: r.gK.maybeNull(i),
          leadArtistId: r.gK.maybeNull(r.gK.union(r.gK.string, r.gK.number)),
          artists: r.gK.maybeNull(r.gK.array(l.PK)),
          errorStatusCode: r.gK.maybeNull(r.gK.number),
          landing: n.Ju
        }),
        u.XT,
        u.pl
      ).views((e2) => ({
        get isShimmerVisible() {
          return e2.isNeededToLoad || e2.isLoading || e2.isRejected;
        },
        get isShimmerActive() {
          return e2.isLoading;
        },
        get isNotFound() {
          return e2.isRejected && (e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST);
        },
        get coversUri() {
          var t2, a2;
          return null != (a2 = null == (t2 = e2.covers) ? void 0 : t2.map((e3) => e3.uri).filter((e3) => !!e3)) ? a2 : [];
        }
      })).actions((e2) => ({
        getInfo: (0, r.L3)(function* (t2) {
          let { concertId: a2 } = t2, { concertsResource: i2, modelActionsLogger: n2 } = (0, r._$)(e2);
          if (!e2.isLoading)
            try {
              e2.loadingState = d.GuX.PENDING;
              let {
                concert: t3,
                minPrice: s2,
                covers: n3,
                description: u2,
                leadArtistId: c2,
                artists: h2
              } = yield i2.getInfo({ concertId: a2 });
              e2.meta = (0, o.ho)(t3, s2), e2.covers = (0, r.wg)(null == n3 ? void 0 : n3.map((e3) => (0, d.pX4)(e3))), e2.description = u2 ? (0, r.wg)(u2) : null, e2.leadArtistId = c2 ? (0, r.wg)(c2) : null, e2.artists = (0, r.wg)(null == h2 ? void 0 : h2.map((e3) => (0, l.dM)(e3))), e2.loadingState = d.GuX.RESOLVE;
            } catch (t3) {
              n2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState = d.GuX.REJECT;
            }
        }),
        reset() {
          e2.loadingState = d.GuX.IDLE, e2.landing.reset(), e2.leadArtistId = null, e2.destroyItems([e2.covers, e2.description, e2.artists]);
        }
      }));
      var h = a(54486), g = a(28303), y = a(61910), m = a(43426), p = a(42421), v = a(79087), P = a.n(v);
      let S = (0, g.PA)(() => {
        let { experiments: e2, concert: t2 } = (0, d.Pjs)(), { formatMessage: a2 } = (0, m.A)(), r2 = e2.checkExperiment(d.zal.WebNextConcertPage, "on");
        if ((0, d.ACS)(), (0, y.useEffect)(
          () => () => {
            t2.reset();
          },
          [t2]
        ), !r2)
          return (0, h.jsx)(p.M, {});
        let i2 = a2({ id: "page-error.concert-page-does-not-exist" }), s2 = a2({ id: "page-error.concert-page-does-not-exist-description" });
        return (0, h.jsx)(p.M, {
          title: i2,
          description: s2,
          iconVariant: "attention",
          iconSize: "xxl",
          iconClassName: P().icon
        });
      }), E = (0, g.PA)(() => (0, h.jsx)(d.nVz, { pageId: d._Q$.PAGE_NOT_FOUND_SCREEN, children: (0, h.jsx)(S, {}) }));
      var f = a(97396), b = a(9348), I = a(43350), _ = a(31500), k = a(6024), C = a(8817), T = a(35537), D = a(27510), A = a(56231), x = a(32353), L = a(82644), R = a(33276), N = a(80585), w = a(62395), M = a(42670), O = a.n(M);
      let F = (0, g.PA)((e2) => {
        var t2, a2, r2;
        let { concertId: i2, isWebNextNavigationOn: s2 } = e2, {
          experiments: l2,
          concert: o2,
          modals: { imageSliderModal: u2 }
        } = (0, d.Pjs)(), c2 = (() => {
          let e3 = (0, w.st)(), t3 = (0, d.UlF)(), { pageId: a3 } = (0, d.$au)(), { hash: r3 } = (0, w.gf)();
          return (0, C.c)((i3, s3) => {
            if (!e3 || !a3) return;
            let n2 = {
              hash: r3,
              pageId: a3,
              pageStyle: I.QL.Fullscreen,
              pagePlacement: I.c4.Fullscreen,
              viewUuid: s3,
              mainObjectType: I.ky.Concert
            }, l3 = (0, I.Fx)({ params: n2, logger: t3, context: "useSendEventOnConcertOpenedOrClosed" });
            l3 && (i3 ? (0, I.Fn)(e3.evgenInstance, l3) : (0, I.PO)(e3.evgenInstance, l3));
          });
        })(), g2 = (0, y.useRef)(String((0, b.A)())), { setContentScrollRef: m2, contentScrollRef: p2 } = (0, d.gKY)(), { forceUpdateRefCallback: v2, offsetY: P2 } = (0, T.G)(p2), S2 = (0, d.ytd)(null == (a2 = o2.covers) || null == (t2 = a2[0]) ? void 0 : t2.color), { topColorStyle: E2, headerStyle: M2 } = (0, R.QZ)(S2, P2, s2), F2 = (0, C.c)(() => {
          o2.coversUri.length > 0 && u2.openImages({ images: o2.coversUri, sizeImage: 800, withAspectRatio: false });
        }), G2 = l2.checkExperiment(d.zal.WebNextConcertPage, "on");
        (0, d.ACS)(), (0, y.useEffect)(
          () => () => {
            o2.reset();
          },
          [o2, i2]
        ), (0, y.useEffect)(() => {
          let e3 = g2.current;
          return c2(true, e3), () => {
            c2(false, e3);
          };
        }, [c2]), (0, d.Jzs)(o2.isResolved);
        let K = [];
        if (o2.isNeededToLoad && K.push(o2.getInfo({ concertId: i2 })), o2.landing.isNeededToLoad && K.push(
          o2.landing.getConcertSkeleton({ concertId: i2, skeletonId: k.p.CONCERT_PAGE }, { preloadBlocksCount: 2 })
        ), K.length && (0, y.use)(Promise.allSettled(K)), (!G2 || o2.isNotFound) && (0, f.notFound)(), o2.isRejected)
          return (0, h.jsx)(L.w, {});
        let j = (0, D.L)(() => {
          var e3, t3, a3;
          return o2.isLoading || !o2.meta || o2.isRejected ? (0, h.jsx)(x.c6, { className: O().header, isActive: true }) : (0, h.jsx)(d.Bki, {
            objectType: I.ky.Concert,
            objectId: null == (e3 = o2.meta) ? void 0 : e3.id,
            objectPosX: 1,
            objectPosY: 1,
            objectsCount: 1,
            mainObjectType: I.ky.Concert,
            mainObjectId: null == (t3 = o2.meta) ? void 0 : t3.id,
            children: (0, h.jsx)(x.Dc, {
              description: o2.description,
              onCoverClick: F2,
              leadArtistId: o2.leadArtistId,
              ref: v2,
              className: O().header,
              concert: o2.meta,
              cover: null == (a3 = o2.covers) ? void 0 : a3[0]
            })
          });
        });
        return (0, h.jsx)(d.jPc, {
          children: (0, h.jsxs)(R.hO, {
            scrollElement: p2,
            children: [
              (0, h.jsx)(N.Y9, { style: M2, variant: N.Vw.INNER, showControls: false }),
              (0, h.jsx)("div", { className: O().averageColorBackground, style: E2 }),
              (0, h.jsxs)(A.N, {
                ref: m2,
                className: O().root,
                containerClassName: O().container,
                ...(0, _.Am)(_.Xk.concert.CONCERT_PAGE),
                children: [
                  (0, h.jsxs)("div", {
                    children: [
                      (0, h.jsx)(d.hjC, {
                        tabId: "",
                        tabPos: 0,
                        isTabSelectedByDefault: false,
                        children: (0, h.jsx)(d.FoH, {
                          blockId: I.LA.ConcertHeader,
                          blockType: I.LA.ConcertHeader,
                          blockPosX: 1,
                          blockPosY: 1,
                          objectsCount: 1,
                          mainObjectType: I.ky.Concert,
                          mainObjectId: null == (r2 = o2.meta) ? void 0 : r2.id,
                          children: j
                        })
                      }),
                      (0, h.jsx)(n.EA, {
                        containerClassName: O().skeleton,
                        landing: o2.landing,
                        errorComponent: (0, h.jsx)(L.w, { className: O().error, withBackwardControl: false })
                      })
                    ]
                  }),
                  (0, h.jsx)(N.A, { children: (0, h.jsx)(N.wi, { className: O().footer }) })
                ]
              })
            ]
          })
        });
      }), G = (0, g.PA)(
        (e2) => (0, h.jsx)(d.nVz, { pageId: d._Q$.CONCERT, pageEntityId: e2.concertId, children: (0, h.jsx)(F, { ...e2 }) })
      );
    },
    12393: (e) => {
      e.exports = { root: "PostArtists_root__Zxmjq", content: "PostArtists_content__JzGOH" };
    },
    12962: (e) => {
      e.exports = {
        root: "MyMusicDownloadedTracksPageHeader_root__2vfuc",
        container: "MyMusicDownloadedTracksPageHeader_container__hQ_wt",
        title: "MyMusicDownloadedTracksPageHeader_title__Ncn5X",
        stickyTitle: "MyMusicDownloadedTracksPageHeader_stickyTitle__Efl0U",
        playButton: "MyMusicDownloadedTracksPageHeader_playButton__seWgC",
        stickyPlayButton: "MyMusicDownloadedTracksPageHeader_stickyPlayButton__JVicd",
        titleContainer: "MyMusicDownloadedTracksPageHeader_titleContainer__rLAkS",
        staticHeader: "MyMusicDownloadedTracksPageHeader_staticHeader__LSVC8",
        important: "MyMusicDownloadedTracksPageHeader_important__JIubq",
        stickyHeader: "MyMusicDownloadedTracksPageHeader_stickyHeader__MuQh4"
      };
    },
    13127: (e, t, a) => {
      "use strict";
      a.d(t, {
        jM: () => g.KidsCategoryPage,
        u3: () => y.KidsEditorialAlbumsPage,
        bU: () => m.KidsEditorialPlaylistsPage,
        GY: () => h
      });
      var r = a(74125), i = a(93064), s = a(14287), n = a(46423), l = a(26433);
      let o = i.gK.compose(
        i.gK.model("KidsEditorialAlbumPage", {
          errorStatusCode: i.gK.maybeNull(i.gK.number),
          title: i.gK.maybeNull(i.gK.string),
          albumsData: i.gK.array(i.gK.model({ id: i.gK.number })),
          pagesLoader: (0, l.Ij)(n.GI)
        }),
        l.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === r.GuX.PENDING;
          },
          get isNotFound() {
            let t3 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST, a2 = e2.pagesLoader.isEmpty;
            return e2.isRejected && t3 || a2;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          },
          get albums() {
            var a2;
            return null != (a2 = e2.pagesLoader.items) ? a2 : [];
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          getAlbums: (0, i.L3)(function* (t3) {
            let { page: a2 = 0, pageSize: l2 = 20 } = t3, { albumResource: o2, modelActionsLogger: d2 } = (0, i._$)(e2);
            if (e2.loadingState === r.GuX.RESOLVE && e2.pagesLoader.isPageNeedToLoad(a2)) {
              e2.pagesLoader.setPageState(a2, r.GuX.PENDING);
              try {
                let t4 = a2 * l2, r2 = e2.albumsData.slice(t4, t4 + l2).map((e3) => e3.id), i2 = yield o2.getAlbums({ albumIds: r2 }), s2 = { page: a2, perPage: l2, total: e2.albumsData.length }, d3 = i2.map(n.e7);
                e2.pagesLoader.setItems(d3, { page: a2, pager: s2 });
              } catch (t4) {
                d2.error(t4), e2.pagesLoader.setItems(null, { responseStatus: r.FlZ.ERROR, page: a2 }), t4 instanceof s.GX && (t4.statusCode === s.X1.NOT_FOUND || t4.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.REJECT);
              }
            }
          }),
          getData: (0, i.L3)(function* (a2) {
            let { id: n2, page: l2 = 0, pageSize: o2 = 20 } = a2, { childrenLandingResource: d2, modelActionsLogger: u2 } = (0, i._$)(e2);
            if (e2.loadingState !== r.GuX.PENDING)
              try {
                var c2;
                e2.loadingState = r.GuX.PENDING;
                let a3 = yield d2.getEditorialAlbum({ id: n2 });
                e2.title = a3.title, e2.albumsData = (0, i.wg)((null != (c2 = a3.entities) ? c2 : []).map((e3) => ({ id: e3 }))), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.RESOLVE), yield t2.getAlbums({ page: l2, pageSize: o2 });
              } catch (t3) {
                u2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.REJECT);
              }
          }),
          reset() {
            e2.loadingState = r.GuX.IDLE, e2.title = null, e2.pagesLoader.reset(), e2.albumsData = (0, i.wg)([]), e2.errorStatusCode = null;
          }
        };
        return t2;
      });
      var d = a(13611);
      let u = i.gK.compose(
        i.gK.model("KidsEditorialPlaylistPage", {
          errorStatusCode: i.gK.maybeNull(i.gK.number),
          title: i.gK.maybeNull(i.gK.string),
          playlistsData: i.gK.array(i.gK.model({ uid: i.gK.number, kind: i.gK.number })),
          pagesLoader: (0, l.Ij)(d.$o)
        }),
        l.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === r.GuX.PENDING;
          },
          get isNotFound() {
            let t3 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST, a2 = e2.pagesLoader.isEmpty;
            return e2.isRejected && t3 || a2;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          },
          get playlists() {
            var a2;
            return null != (a2 = e2.pagesLoader.items) ? a2 : [];
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          getPlaylists: (0, i.L3)(function* (t3) {
            let { page: a2 = 0, pageSize: n2 = 20 } = t3, { playlistsResource: l2, modelActionsLogger: o2 } = (0, i._$)(e2);
            if (e2.loadingState === r.GuX.RESOLVE && e2.pagesLoader.isPageNeedToLoad(a2)) {
              e2.pagesLoader.setPageState(a2, r.GuX.PENDING);
              try {
                let t4 = a2 * n2, r2 = e2.playlistsData.slice(t4, t4 + n2), i2 = yield l2.getPlaylists({
                  playlistIds: r2.map((e3) => "".concat(e3.uid, ":").concat(e3.kind)),
                  resumeStream: false
                }), s2 = { page: a2, perPage: n2, total: e2.playlistsData.length }, o3 = i2.playlists.map(d.jX);
                e2.pagesLoader.setItems(o3, { page: a2, pager: s2 });
              } catch (t4) {
                o2.error(t4), e2.pagesLoader.setItems(null, { responseStatus: r.FlZ.ERROR, page: a2 }), t4 instanceof s.GX && (t4.statusCode === s.X1.NOT_FOUND || t4.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.REJECT);
              }
            }
          }),
          getData: (0, i.L3)(function* (a2) {
            let { id: n2, page: l2 = 0, pageSize: o2 = 20 } = a2, { childrenLandingResource: d2, modelActionsLogger: u2 } = (0, i._$)(e2);
            if (e2.loadingState !== r.GuX.PENDING)
              try {
                var c2;
                e2.loadingState = r.GuX.PENDING;
                let a3 = yield d2.getEditorialPlaylist({ id: n2 });
                e2.title = a3.title, e2.playlistsData = (0, i.wg)(
                  (null != (c2 = a3.entities) ? c2 : []).map((e3) => ({ uid: e3.uid, kind: e3.kind }))
                ), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.RESOLVE), yield t2.getPlaylists({ page: l2, pageSize: o2 });
              } catch (t3) {
                u2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.REJECT);
              }
          }),
          reset() {
            e2.loadingState = r.GuX.IDLE, e2.title = null, e2.pagesLoader.reset(), e2.playlistsData = (0, i.wg)([]), e2.errorStatusCode = null;
          }
        };
        return t2;
      });
      var c = a(4542);
      let h = i.gK.model("KidsPage", { landing: c.Ju, kidsEditorialPlaylistSubpage: u, kidsEditorialAlbumSubpage: o });
      var g = a(25945), y = a(1019), m = a(49841);
      a(67923), a(75669);
    },
    14114: (e) => {
      e.exports = { root: "MyMusicDownloadedTracksInfo_root__yIYHx" };
    },
    14741: (e, t, a) => {
      "use strict";
      a.d(t, { f: () => I, _: () => l });
      var r = a(93064), i = a(77217), s = a(74125), n = a(26433);
      let l = r.gK.compose(
        r.gK.model("ConcertsDetailsPage", {
          concerts: r.gK.maybeNull(r.gK.array(i.aR)),
          title: r.gK.maybeNull(r.gK.string)
        }),
        n.XT,
        n.pl
      ).views((e2) => ({
        get isShimmerVisible() {
          return e2.isNeededToLoad || e2.isLoading || e2.isRejected;
        },
        get isShimmerActive() {
          return e2.isLoading;
        }
      })).actions((e2) => ({
        getData: (0, r.L3)(function* (t2) {
          let { type: a2, id: n2 } = t2, { concertsResource: l2, modelActionsLogger: o2 } = (0, r._$)(e2);
          if (!e2.isLoading)
            try {
              e2.loadingState = s.GuX.PENDING;
              let { items: t3 } = yield l2.getConcertsDetails({ type: a2, id: n2 });
              e2.concerts = (0, r.wg)(t3.map((e3) => (0, i.HN)(e3))), e2.loadingState = s.GuX.RESOLVE;
            } catch (t3) {
              o2.error(t3), e2.loadingState = s.GuX.REJECT;
            }
        }),
        reset() {
          e2.loadingState = s.GuX.IDLE, e2.title = null, e2.destroyItems([e2.concerts]);
        }
      }));
      var o = a(54486), d = a(28303), u = a(97396), c = a(61910), h = a(43426), g = a(8817), y = a(67648), m = a(56231), p = a(97800), v = a(82644), P = a(33276), S = a(77516), E = a(80585), f = a(25566), b = a.n(f);
      let I = (0, d.PA)((e2) => {
        let { type: t2, id: a2 } = e2, r2 = (0, c.useId)(), { concertsDetails: n2, experiments: l2 } = (0, s.Pjs)(), { formatMessage: d2 } = (0, h.A)(), { contentScrollRef: f2, setContentScrollRef: I2 } = (0, s.gKY)(), _ = (0, s.W6M)(), [k, C] = (0, y.d)(), T = (0, s.fBs)(), D = (0, c.useRef)(false), A = (0, g.c)(() => {
          var e3;
          return !n2.isShimmerVisible && (null == (e3 = n2.concerts) ? void 0 : e3.length) ? n2.concerts.length : 50;
        }), {
          virtualizer: x,
          rowResizeObserver: L,
          columnCount: R,
          indices: N
        } = (0, S.LW)({
          count: A(),
          rowGap: 32,
          columnGap: 16,
          getEstimateRowSize: () => 371,
          minColumnCount: 2,
          minColumnWidth: 170,
          maxColumnWidth: 227,
          containerRef: k
        }), w = { "--feed-concerts-height": "".concat(x.getTotalSize(), "px"), "--feed-concerts-column-count": R }, M = (0, c.useCallback)(
          (e3) => {
            var t3;
            let a3 = null == (t3 = n2.concerts) ? void 0 : t3[e3];
            return !a3 || n2.isShimmerVisible ? (0, o.jsx)(i.LY, { isActive: n2.isShimmerActive }) : (0, o.jsx)(i.Qb, { concert: a3 });
          },
          [n2.concerts, n2.isShimmerActive, n2.isShimmerVisible]
        );
        if ((0, c.useEffect)(
          () => () => {
            n2.reset();
          },
          [n2]
        ), (0, c.useEffect)(() => {
          n2.isResolved && !D.current && (T(), D.current = true);
        }, [n2.isResolved, T]), n2.isNeededToLoad && (0, c.use)(n2.getData({ type: t2, id: a2 })), (!l2.checkExperiment(s.zal.WebNextConcertsDetailsPage, "on") || l2.checkExperiment(s.zal.disableAllConcerts, "on")) && (0, u.notFound)(), n2.isRejected)
          return (0, o.jsx)(v.w, {});
        let O = d2({ id: "concerts.details-title" });
        return (0, o.jsx)(P.hO, {
          scrollElement: f2,
          outerTitle: O,
          children: (0, o.jsxs)("div", {
            className: b().root,
            children: [
              (0, o.jsx)(E.Y9, {
                variant: E.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: _.canBack,
                children: (0, o.jsx)(p.Heading, {
                  variant: "h2",
                  weight: "bold",
                  size: "xl",
                  lineClamp: 1,
                  children: O
                })
              }),
              (0, o.jsxs)(m.N, {
                ref: I2,
                className: b().scrollContainer,
                children: [
                  (0, o.jsx)("div", {
                    className: b().content,
                    children: (0, o.jsx)("div", {
                      "aria-labelledby": r2,
                      ref: C,
                      style: w,
                      className: b().container,
                      children: x.getVirtualItems().map(
                        (e3) => (0, o.jsx)(
                          S.Ux,
                          {
                            className: b().row,
                            columnClassName: b().column,
                            virtualItem: e3,
                            resizeObserver: L,
                            indices: N,
                            renderItemByIndex: M,
                            scrollMargin: x.options.scrollMargin
                          },
                          e3.key
                        )
                      )
                    })
                  }),
                  (0, o.jsx)(E.A, { children: (0, o.jsx)(E.wi, { className: b().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    15163: (e, t, a) => {
      "use strict";
      a.d(t, { P: () => r });
      let r = (e2) => {
        if ("number" == typeof e2 && !Number.isNaN(e2)) return e2;
        if ("string" == typeof e2) {
          let t2 = Number.parseInt(e2, 10);
          if (!Number.isNaN(t2)) return t2;
        }
      };
    },
    15782: (e, t, a) => {
      "use strict";
      a.d(t, { AdvertProvider: () => u });
      var r = a(54486), i = a(28303), s = a(61910), n = a(89461), l = a(32061), o = a(74125);
      let d = null, u = (0, i.PA)((e2) => {
        var t2, a2;
        let { children: i2 } = e2, { advert: u2, experiments: c, user: h, location: g, sonataState: y } = (0, o.Pjs)(), m = (0, o.UlF)();
        return (!d && h.isAuthorized && c.checkExperiment(o.zal.WebNextAudioVideoAdvert, "on") && ((d = new o.vaf({ logger: m, videoSlotId: l.so.SLOT, videoElementId: l.so.VIDEO })).setVideoContentUrl(
          (null == (a2 = y.entityMeta) ? void 0 : a2.url) || null
        ), d.setVideoContentDuration(y.duration)), (0, s.useEffect)(() => {
          null == d || d.init(g.tld);
        }, [g.tld]), (0, s.useEffect)(() => {
          var e3;
          null == d || d.setVideoContentUrl((null == (e3 = y.entityMeta) ? void 0 : e3.url) || null), null == d || d.setVideoContentDuration(y.duration);
        }, [null == (t2 = y.entityMeta) ? void 0 : t2.url, y.duration]), (0, s.useEffect)(() => {
          if (!c.checkExperiment(o.zal.WebNextAudioVideoAdvert, "on") || !h.isAuthorized) return;
          let e3 = null == d ? void 0 : d.state.isAdvertPlaying.onChange((e4) => {
            if (u2.setAdvertShown(e4), e4) {
              var t3, a3;
              u2.setType((null == d || null == (t3 = d.state.advertData) ? void 0 : t3.type) || null), u2.setData((null == d || null == (a3 = d.state.advertData) ? void 0 : a3.data) || null);
            } else u2.reset();
          });
          return () => {
            null == e3 || e3();
          };
        }, [u2, c, h.isAuthorized]), (0, s.useEffect)(() => {
          let e3;
          if (u2.isAdvertPlaybackCreated) {
            var t3;
            e3 = null == d || null == (t3 = d.audioAdvertPlayback) ? void 0 : t3.state.playerState.event.onChange((e4) => {
              if (u2.isAdvertShown) {
                if (e4 === n.Iu.END && (u2.setAdvertShown(false), null == d || d.state.setDefaultState()), e4 === n.Iu.PLAYING)
                  return void u2.setAdvertPlaying(true);
                if (e4 === n.Iu.END || e4 === n.Iu.PAUSED) return void u2.setAdvertPlaying(false);
              }
            });
          }
          return () => {
            null == e3 || e3();
          };
        }, [u2, u2.isAdvertPlaybackCreated]), (0, s.useEffect)(
          () => () => {
            u2.reset();
          },
          [u2]
        ), c.checkExperiment(o.zal.WebNextAudioVideoAdvert, "on") && h.isAuthorized) ? (0, r.jsx)(o.p8J.Provider, { value: d, children: i2 }) : i2;
      });
    },
    16173: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { WebInitializer: () => l });
      var r = a(54486), i = a(28303), s = a(74125);
      let n = (0, i.PA)((e2) => {
        let { children: t2, userIp: a2 } = e2, { location: r2 } = (0, s.Pjs)();
        return t2;
      }), l = (e2) => {
        let { userIp: t2 } = e2;
        return (0, r.jsx)(n, { userIp: t2 });
      };
    },
    22603: (e) => {
      e.exports = {
        root: "KidsEditorialAlbumsPage_root__7rHF8",
        scrollContainer: "KidsEditorialAlbumsPage_scrollContainer__nQVlt",
        important: "KidsEditorialAlbumsPage_important__hmmxn",
        footer: "KidsEditorialAlbumsPage_footer__6rwU1",
        item: "KidsEditorialAlbumsPage_item__Wc243",
        content: "KidsEditorialAlbumsPage_content__u3zcW"
      };
    },
    23404: (e) => {
      e.exports = {
        root: "PostPage_root__Orhf7",
        scrollableContainer: "PostPage_scrollableContainer__iV9Bo",
        scrollContainer: "PostPage_scrollContainer__zrIrH",
        important: "PostPage_important__qUlED",
        container: "PostPage_container__orSfz",
        shimmerTitle: "PostPage_shimmerTitle__EeFCD"
      };
    },
    23615: (e, t, a) => {
      "use strict";
      var r;
      a.d(t, { Q: () => r }), (function(e2) {
        e2.ALBUMS = "albums", e2.ARTISTS = "artists", e2.PLAYLISTS = "playlists";
      })(r || (r = {}));
    },
    24993: (e) => {
      e.exports = {
        root: "KidsEditorialPlaylistsPage_root__HeHqc",
        scrollContainer: "KidsEditorialPlaylistsPage_scrollContainer__Hy6HY",
        important: "KidsEditorialPlaylistsPage_important__283cd",
        footer: "KidsEditorialPlaylistsPage_footer___UaP5",
        item: "KidsEditorialPlaylistsPage_item__0wBk2",
        content: "KidsEditorialPlaylistsPage_content__6wWkP"
      };
    },
    25522: (e) => {
      e.exports = {
        root: "TagPage_root__EWN9A",
        scrollContainer: "TagPage_scrollContainer__lvG_1",
        important: "TagPage_important__Jq37E",
        content: "TagPage_content__rUC_l",
        footer: "TagPage_footer__W0mZr",
        item: "TagPage_item__X_lW7"
      };
    },
    25566: (e) => {
      e.exports = {
        root: "ConcertsDetailsPage_root__Uyap_",
        scrollContainer: "ConcertsDetailsPage_scrollContainer__BKTRD",
        content: "ConcertsDetailsPage_content__WsuVk",
        header: "ConcertsDetailsPage_header__K7UVE",
        container: "ConcertsDetailsPage_container__swjuX",
        column: "ConcertsDetailsPage_column__EB1kA",
        row: "ConcertsDetailsPage_row__oP8Xu",
        footer: "ConcertsDetailsPage_footer__ooBj8"
      };
    },
    25945: (e, t, a) => {
      "use strict";
      a.d(t, { KidsCategoryPage: () => b });
      var r = a(54486), i = a(50420), s = a(28303), n = a(97396), l = a(61910), o = a(31500), d = a(56231), u = a(97800), c = a(4542), h = a(82644), g = a(33276), y = a(74125), m = a(80585), p = a(44193), v = a.n(p), P = a(27510), S = a(91582), E = a.n(S);
      let f = (0, s.PA)(() => {
        let { experiments: e2 } = (0, y.Pjs)(), t2 = e2.checkExperiment(y.zal.WebNextWaveAgentExperiment, "on"), a2 = (0, P.L)(
          () => t2 ? (0, r.jsx)(m.OY, { isShimmerVisible: true, isShimmerActive: true, isShimmerCentered: true }) : (0, r.jsx)(c.Rj, { isActive: true, length: 4 })
        );
        return (0, r.jsxs)("div", {
          className: E().root,
          children: [
            (0, r.jsx)("div", { children: a2 }),
            (0, r.jsx)(m.OY, { isShimmerVisible: true, isShimmerActive: true }),
            (0, r.jsx)(m.OY, { isShimmerVisible: true, isShimmerActive: true })
          ]
        });
      }), b = (0, s.PA)((e2) => {
        let { categoryId: t2 } = e2, { kids: a2 } = (0, y.Pjs)(), { contentScrollRef: s2, setContentScrollRef: p2 } = (0, y.gKY)(), P2 = (0, y.W6M)();
        (0, l.useEffect)(() => () => a2.landing.reset(), [a2.landing]), (0, y.Jzs)(a2.landing.isResolved), a2.landing.isLoadedAndEmpty && (0, n.notFound)();
        let S2 = (0, c._9)(a2.landing), E2 = (0, l.useMemo)(
          () => a2.landing.isLoading || a2.landing.isNeededToLoad ? (0, r.jsx)(f, {}) : (0, r.jsx)(c.EA, {
            landing: a2.landing,
            errorComponent: (0, r.jsx)(h.w, { className: v().error, withBackwardControl: false })
          }),
          [a2.landing.loadingState, a2.landing]
        );
        return a2.landing.isNeededToLoad && (0, l.use)(a2.landing.getChildrenSkeleton({ categoryId: t2 })), (0, r.jsx)(y.nVz, {
          pageId: y._Q$.KIDS_CATEGORY,
          children: (0, r.jsxs)(g.hO, {
            scrollElement: s2,
            outerTitle: a2.landing.title,
            children: [
              (0, r.jsx)(m.Y9, {
                variant: m.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: P2.canBack,
                children: (0, r.jsx)("div", {
                  className: v().header,
                  children: (0, r.jsx)(u.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    children: a2.landing.title
                  })
                })
              }),
              (0, r.jsxs)(d.N, {
                className: v().root,
                containerClassName: v().content,
                ref: p2,
                ...(0, o.Am)(o.Xk.kids.KIDS_CATEGORY_PAGE),
                children: [
                  (0, r.jsx)("div", {
                    className: (0, i.$)(v().landing, { [v().landing_onlyWizard]: S2 }),
                    children: E2
                  }),
                  (0, r.jsx)(m.A, { children: (0, r.jsx)(m.wi, { className: v().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    26794: (e, t, a) => {
      "use strict";
      a.d(t, { GenresPage: () => p });
      var r = a(54486), i = a(28303), s = a(97396), n = a(61910), l = a(56231), o = a(97800), d = a(82644), u = a(33276), c = a(30004), h = a(74125), g = a(80585), y = a(3062), m = a.n(y);
      let p = (0, i.PA)((e2) => {
        let { navigationId: t2 } = e2, { genres: a2 } = (0, h.Pjs)(), { contentScrollRef: i2, setContentScrollRef: y2 } = (0, h.gKY)(), p2 = (0, h.W6M)();
        return ((0, n.useEffect)(
          () => () => {
            a2.reset();
          },
          [a2, t2]
        ), a2.isNotFound && (0, s.notFound)(), (0, h.Jzs)(a2.isResolved), t2 && a2.isNeededToLoad && (0, n.use)(a2.getData(t2)), a2.isRejected) ? (0, r.jsx)(d.w, {}) : (0, r.jsxs)(u.hO, {
          scrollElement: i2,
          outerTitle: a2.title,
          children: [
            (0, r.jsx)(g.Y9, {
              variant: g.Vw.TEXT,
              withForwardControl: false,
              withBackwardControl: p2.canBack,
              children: (0, r.jsx)(o.Heading, {
                variant: "h2",
                weight: "bold",
                size: "xl",
                lineClamp: 1,
                children: a2.title
              })
            }),
            (0, r.jsx)(l.N, {
              className: m().root,
              containerClassName: m().content,
              ref: y2,
              children: (0, r.jsx)("div", {
                className: m().list,
                children: a2.items.map(
                  (e3) => (0, r.jsx)(c.G4, { tag: e3.tag, title: e3.title, subGenres: e3.subGenres }, e3.tag)
                )
              })
            })
          ]
        });
      });
    },
    27005: (e) => {
      e.exports = {
        root: "KidsPage_root__yycsJ",
        content: "KidsPage_content__08pPR",
        header: "KidsPage_header__2Gk2l",
        landing: "KidsPage_landing__3QZZj",
        landing_onlyWizard: "KidsPage_landing_onlyWizard__xKyDo",
        footer: "KidsPage_footer__p7SVD",
        error: "KidsPage_error__qa7Qo"
      };
    },
    29910: (e, t, a) => {
      "use strict";
      a.d(t, { ServiceWorkerInitialiazer: () => s });
      var r = a(61910), i = a(74125);
      let s = () => {
        let e2 = (0, i.NFA)().get(i.Zft);
        (0, r.useEffect)(() => {
          "serviceWorker" in navigator && navigator.serviceWorker.addEventListener("message", (t2) => {
            var a2, r2, i2, s2, n;
            if ((null == (a2 = t2.data) ? void 0 : a2.type) === "PUT_RSC_WORKER_ERROR_MESSAGE_TYPE") {
              let a3 = new URL(null == (i2 = t2.data) || null == (r2 = i2.payload) ? void 0 : r2.url);
              e2.error(
                "[RSC worker] Error getting url ".concat(a3.origin, " ").concat(a3.pathname).concat(a3.search, ", reason: ").concat(null == (n = t2.data) || null == (s2 = n.payload) ? void 0 : s2.error)
              );
            }
          });
        }, [e2]);
      };
    },
    30004: (e, t, a) => {
      "use strict";
      a.d(t, { G4: () => l.Genre, Gc: () => n, kc: () => i });
      var r = a(93064);
      let i = (e2) => ({
        tag: e2.tag,
        title: e2.title,
        subGenres: (0, r.wg)((e2.leaves || []).map((e3) => ({ tag: e3.tag, title: e3.title })))
      }), s = r.gK.model("GenreListItemSubGenreModel", { tag: r.gK.string, title: r.gK.string }), n = r.gK.model("GenreListItemModel", { tag: r.gK.string, title: r.gK.string, subGenres: r.gK.array(s) });
      var l = a(82667);
    },
    30827: (e) => {
      e.exports = { root: "PostAlbums_root__u2a1q", content: "PostAlbums_content__uMSez" };
    },
    31669: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { UrlInitializer: () => n });
      var r = a(28303), i = a(97396), s = a(74125);
      let n = (0, r.PA)((e2) => {
        let { host: t2 } = e2, { location: a2 } = (0, s.Pjs)(), r2 = (0, i.usePathname)(), n2 = (0, i.useSearchParams)().toString(), l = window.location.host, o = t2 || l, d = "https://".concat(o), u = "https://".concat(o).concat(r2).concat(n2 ? "?" : "").concat(n2);
        d = o, u = "".concat(o).concat(r2).concat(n2 ? "?" : "").concat(n2), a2.setPathname(r2), a2.setSearchParams(n2), a2.setHost(o), a2.setTld((0, s.fMM)(o) || s.lYh), a2.setOrigin(d), a2.setHref(u);
      });
    },
    33134: (e, t, a) => {
      "use strict";
      a.d(t, { W: () => l });
      var r = a(61910), i = a(8817), s = a(89461), n = a(74125);
      let l = (e2) => {
        let { isEnabled: t2, intervalMs: a2, modal: l2, playbackId: o, sonataState: d, isPaywallOpen: u } = e2, c = (0, r.useRef)(/* @__PURE__ */ new Date()), h = (0, n.eGp)(), g = (0, i.c)(() => {
          c.current = /* @__PURE__ */ new Date();
        }), y = (0, i.c)(() => {
          c.current.getTime() < Date.now() - (null != a2 ? a2 : 18e5) && !u && (l2.open(), g());
        });
        (0, r.useEffect)(() => {
          if (!t2) return;
          let e3 = null == h ? void 0 : h.getState(o).playerState.status.onChange((e4) => {
            e4 === s.MT.ENDED && y();
          });
          return () => {
            null == e3 || e3();
          };
        }, [t2, h, y, o]), (0, r.useEffect)(() => {
          t2 && l2.isOpened && (null == h || h.pause(o));
        }, [t2, l2.isOpened, h, d.status, o]), (0, r.useEffect)(() => {
          if (!t2) return;
          let e3 = new AbortController();
          return window.addEventListener("mousemove", g, { signal: e3.signal }), window.addEventListener("keydown", g, { signal: e3.signal }), window.addEventListener("touchstart", g, { signal: e3.signal }), () => {
            e3.abort();
          };
        }, [t2, g]);
      };
    },
    33208: (e, t, a) => {
      "use strict";
      a.d(t, { mK: () => c, mW: () => h });
      var r = a(61910), i = a(74125), s = a(73477), n = a(63930), l = a(93064), o = a(63585), d = a(21365), u = a(54460);
      let c = l.gK.model("ContinueListen", {
        track: l.gK.maybe(d.vj),
        trackIndex: l.gK.maybe(l.gK.number),
        contextType: l.gK.maybeNull(l.gK.enumeration(Object.values(o.K))),
        contextId: l.gK.maybeNull(l.gK.union(l.gK.string, l.gK.number)),
        albumDuration: l.gK.maybe(l.gK.number),
        albumStreamProgress: l.gK.optional(u.B9, { endPositionSec: 0 }),
        trackTempStreamProgress: l.gK.optional(u.B9, { endPositionSec: 0 })
      }).actions((e2) => ({
        saveTrack: (t2) => {
          let { contextType: a2, contextId: r2, track: i2, isDefaultTrack: s2 } = t2;
          s2 && e2.track || (e2.contextType = a2, e2.contextId = r2, e2.track = (0, l.wg)((0, n.HO)(i2)));
        },
        saveTrackIndex: (t2) => {
          e2.trackIndex = t2;
        },
        saveAlbumDuration: (t2) => {
          e2.albumDuration = t2;
        }
      })), h = (0, a(28303).PA)(() => {
        ((e2) => {
          var t2;
          let { sonataState: a2, continueListen: n2 } = (0, i.Pjs)();
          (0, r.useEffect)(() => {
            var t3, r2, i2, l2, o2, d2, u2, c2;
            if (!e2 || !(null == (t3 = a2.entityMeta) ? void 0 : t3.isPodcast) && !(null == (r2 = a2.entityMeta) ? void 0 : r2.isAudiobook))
              return;
            let h2 = e2.state.queueState.index.value;
            e2.state.queueState.order.value.length > 0 && "number" == typeof h2 && n2.saveTrackIndex(h2);
            let g = null == (i2 = e2.state.currentContext.value) ? void 0 : i2.data.meta;
            if (g && a2.contextType && a2.contextId && (n2.saveTrack({ contextType: a2.contextType, contextId: a2.contextId, track: a2.entityMeta }), a2.entityMeta.isAudiobook)) {
              if ("volumes" in g && g.volumes) {
                let e3, t4 = ((e4, t5) => {
                  let a3 = true;
                  return (0, s.A)(e4).reduce((e5, r3) => {
                    if (!r3.durationMs) return e5;
                    if (r3.id === t5) {
                      var i3;
                      return a3 = false, e5 + ((null == (i3 = r3.streamProgress) ? void 0 : i3.endPositionSec) || 0);
                    }
                    return a3 ? e5 + r3.durationMs / 1e3 : e5;
                  }, 0);
                })(g.volumes, a2.entityMeta.id);
                "durationSec" in g && (e3 = g.durationSec), n2.saveAlbumDuration(e3), null == (d2 = n2.trackTempStreamProgress) || d2.updateEndPositionSec(
                  (null == (o2 = n2.track) || null == (l2 = o2.streamProgress) ? void 0 : l2.endPositionSec) || 0
                ), null == (u2 = n2.albumStreamProgress) || u2.updateEndPositionSec(t4);
              }
              "listeningFinished" in g && (null == (c2 = n2.albumStreamProgress) || c2.updateEverFinished(g.listeningFinished || false));
            }
          }, [null == (t2 = a2.entityMeta) ? void 0 : t2.id, a2.entityMeta, a2.contextType, a2.contextId, e2, n2]);
        })((0, i.eGp)());
      });
    },
    33461: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { PrefetchDataProvider: () => o });
      var r = a(28303), i = a(61910), s = a(74125), n = a(79882);
      let l = async (e2) => {
        let { experimentsData: t2, userAccountData: a2, userId: r2, store: i2, withPins: s2 = true } = e2, { user: n2, experiments: l2, pinsCollection: o2, disclaimersDictionary: d } = i2;
        if (await n2.getAbout(a2), n2.puid && r2.setPassportUid(n2.puid), await Promise.allSettled([l2.getData(t2), d.getDisclaimers()]), n2.isAuthorized) {
          let e3 = [n2.getSettings(), i2.library.getData()];
          s2 && e3.push(o2.getData()), await Promise.allSettled(e3);
        }
      }, o = (0, r.PA)((e2) => {
        let { children: t2, ...a2 } = e2, r2 = (0, s.Pjs)(), o2 = (0, s.NFA)().get(s.WA$);
        return (0, n.setClientSideLayout)(r2.settings), r2.user.puid && o2.setPassportUid(r2.user.puid), r2.user.account.loadingState === s.GuX.IDLE && (0, i.use)(l({ store: r2, userId: o2, ...a2 })), t2;
      });
    },
    35462: (e) => {
      e.exports = {
        root: "TopConcertsCarousel_root__opMbb",
        controls: "TopConcertsCarousel_controls__c92PW",
        header: "TopConcertsCarousel_header__3h3Zn",
        carousel: "TopConcertsCarousel_carousel__uMke6",
        item: "TopConcertsCarousel_item__fz8lR",
        important: "TopConcertsCarousel_important__ZcT6Z"
      };
    },
    36138: (e, t, a) => {
      "use strict";
      a.d(t, { UlitochkaInitializer: () => o });
      var r = a(54486), i = a(28303), s = a(85097), n = a(8817), l = a(74125);
      let o = (0, i.PA)((e2) => {
        let { nonce: t2 } = e2, { experiments: a2 } = (0, l.Pjs)(), i2 = (0, n.c)(() => {
          window.Ya.ulitochka.init({
            theme: "light",
            platform: "desktop",
            customButtonStyle: { right: 5, top: 60, left: "auto", border: 0, background: "none" },
            withReactFallbackLoading: true,
            disableAnalytics: true
          });
        });
        if (a2.checkExperiment(l.zal.WebNextUlitochka, "on"))
          return (0, r.jsx)(s.default, {
            src: "https://yastatic.net/s3/ulitochka/latest/ulitochka.min.js",
            nonce: null != t2 ? t2 : void 0,
            onLoad: i2,
            async: true
          });
      });
    },
    36298: (e, t, a) => {
      "use strict";
      a.d(t, { PromoLandingShortcutsProvider: () => d });
      var r = a(54486), i = a(28303), s = a(61910), n = a(74125), l = a(65429);
      let o = null, d = (0, i.PA)((e2) => {
        let { children: t2 } = e2, {
          promolanding: { state: a2 }
        } = (0, n.Pjs)(), i2 = (0, s.useMemo)(() => (o || (o = new n.G8o(new n.z$B())), o), []);
        return (0, l.E)({ controller: i2, sonataState: a2, playbackId: n.V_r.PROMO_LANDING, groupId: n.Mo.PROMO_LANDING }), (0, s.useEffect)(
          () => (null == i2 || i2.listen(), () => {
            null == i2 || i2.stopListening();
          }),
          [i2]
        ), (0, r.jsx)(n.Pic.Provider, { value: i2, children: t2 });
      });
    },
    39507: (e, t, a) => {
      "use strict";
      a.d(t, { uA: () => o.PlaylistPersonalPage, Hj: () => l });
      var r = a(93064), i = a(14287), s = a(74125), n = a(26433);
      let l = r.gK.compose(
        r.gK.model("PlaylistPersonalPage", {
          errorStatusCode: r.gK.maybeNull(r.gK.number),
          playlistUuid: r.gK.maybe(r.gK.string),
          isReady: r.gK.optional(r.gK.boolean, false),
          dummyCoverUrl: r.gK.maybe(r.gK.string),
          dummyDescription: r.gK.maybe(r.gK.string),
          title: r.gK.maybe(r.gK.string)
        }),
        n.XT
      ).views((e2) => ({
        getUrl(t2) {
          if (!e2.playlistUuid) return "";
          let { href: a2 } = (0, s.uvd)("/playlists/:playlistUuid", {
            params: { playlistUuid: e2.playlistUuid },
            query: t2
          });
          return a2;
        },
        get url() {
          if (!e2.playlistUuid) return "";
          let { href: t2 } = (0, s.uvd)("/playlists/:playlistUuid", { params: { playlistUuid: e2.playlistUuid } });
          return t2;
        },
        get isNotFound() {
          let t2 = e2.errorStatusCode === i.X1.NOT_FOUND || e2.errorStatusCode === i.X1.BAD_REQUEST;
          return e2.loadingState === s.GuX.REJECT && t2;
        }
      })).actions((e2) => ({
        getPlaylistPersonalDetails: (0, r.L3)(function* (t2) {
          if (!(0, r._n)(e2)) return;
          let { playlistsResource: a2, modelActionsLogger: n2 } = (0, r._$)(e2);
          if (e2.loadingState !== s.GuX.PENDING)
            try {
              var l2, o2;
              e2.loadingState = s.GuX.PENDING;
              let r2 = yield a2.getPlaylistPersonal({ playlistId: t2 });
              if ((null == (l2 = r2.error) ? void 0 : l2.name) === "no-such-playlist") {
                e2.errorStatusCode = i.X1.NOT_FOUND, e2.loadingState = s.GuX.REJECT;
                return;
              }
              e2.isReady = r2.ready, e2.playlistUuid = r2.data.playlistUuid, e2.dummyCoverUrl = null == (o2 = r2.data.dummyCover) ? void 0 : o2.uri, e2.dummyDescription = r2.data.dummyDescription, e2.title = r2.data.title, e2.loadingState !== s.GuX.IDLE && (e2.loadingState = s.GuX.RESOLVE);
            } catch (t3) {
              n2.error(t3), t3 instanceof i.GX && (t3.statusCode === i.X1.NOT_FOUND || t3.statusCode === i.X1.BAD_REQUEST) && (e2.errorStatusCode = i.X1.NOT_FOUND), e2.loadingState !== s.GuX.IDLE && (e2.loadingState = s.GuX.REJECT);
            }
        }),
        reset() {
          e2.loadingState = s.GuX.IDLE, e2.errorStatusCode = null, e2.isReady = false, e2.playlistUuid = void 0, e2.dummyCoverUrl = void 0, e2.dummyDescription = void 0, e2.title = void 0;
        }
      }));
      a(95657), a(54486), a(42421);
      var o = a(65381);
    },
    41076: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { TranslationsProvider: () => n });
      var r = a(54486), i = a(50722), s = a(74125);
      let n = (e2) => {
        let { children: t2 } = e2, { dictionary: a2, language: n2, defaultLanguage: l } = (0, s.h6b)(), o = (0, s.Crf)();
        return (0, r.jsx)(i.A, { onError: o, defaultLocale: l, locale: n2, messages: a2, children: t2 });
      };
    },
    42670: (e) => {
      e.exports = {
        root: "ConcertPage_root__pqTvU",
        averageColorBackground: "ConcertPage_averageColorBackground__wj67a",
        header: "ConcertPage_header__FxHk1",
        container: "ConcertPage_container__ca9h4",
        footer: "ConcertPage_footer____Dnb",
        skeleton: "ConcertPage_skeleton__8aWkf",
        error: "ConcertPage_error__gcEp_"
      };
    },
    42838: (e) => {
      e.exports = {
        root: "ChartTracksPage_root__QMbqY",
        scrollContainer: "ChartTracksPage_scrollContainer__Pxe8S",
        important: "ChartTracksPage_important__Lddyf",
        content: "ChartTracksPage_content__yyIAN",
        footer: "ChartTracksPage_footer__6sNBk",
        shimmerItem: "ChartTracksPage_shimmerItem__YwM0h"
      };
    },
    43751: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { SavedOfferInitializer: () => n });
      var r = a(28303), i = a(61910), s = a(74125);
      let n = (0, r.PA)(() => {
        let {
          paymentWidgetModal: {
            modal: e2,
            setTarget: t2,
            setTariffOfferName: a2,
            setServiceSessionId: r2,
            setIsSilent: n2,
            setOffersBatchId: l,
            setOffersPositionIds: o
          },
          user: d
        } = (0, s.Pjs)(), { hasFreeUserAccess: u } = (0, s.XCI)(), c = (0, s.NFA)(), h = (0, i.useMemo)(() => c.get(s.vHc), [c]);
        (0, i.useLayoutEffect)(() => {
          if (!d.isAuthorized || !u || null === h) return;
          let i2 = h.get(s.cYZ.Offer);
          if (null === i2) return;
          let {
            target: c2,
            serviceSessionId: g,
            tariffOfferName: y,
            isSilent: m,
            offersBatchId: p,
            offersPositionIds: v
          } = i2;
          h.remove(s.cYZ.Offer), t2(c2), n2(m), r2(g), l(p), o(v), y && a2(y), e2.open();
        }, [u, h, e2, a2, t2, r2, n2, l, o, d.isAuthorized]);
      });
    },
    44193: (e) => {
      e.exports = {
        root: "KidsCategoryPage_root__bk7_R",
        content: "KidsCategoryPage_content__LN0NB",
        header: "KidsCategoryPage_header__Agys3",
        landing: "KidsCategoryPage_landing__aSDYw",
        landing_onlyWizard: "KidsCategoryPage_landing_onlyWizard__3EC9N",
        footer: "KidsCategoryPage_footer__BQhqi",
        error: "KidsCategoryPage_error__tSXF7"
      };
    },
    46562: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { HistoryProvider: () => d });
      var r = a(54486), i = a(97396), s = a(61910), n = a(8817), l = a(74125);
      let o = null, d = (e2) => {
        let { children: t2 } = e2, a2 = (0, l.NFA)(), d2 = (0, i.useRouter)(), u = (0, i.usePathname)(), c = (0, i.useSearchParams)(), [h, g] = (0, s.useState)(false), [y, m] = (0, s.useState)(false), [p, v] = (0, s.useState)(null), P = (0, s.useRef)(0), S = (0, s.useRef)(null), E = (0, s.useMemo)(() => {
          if (o) return o;
          let e3 = a2.get(l.vHc);
          return o = new l.fiH(e3);
        }, [a2]), f = (0, n.c)(() => {
          E && (g(E.canBack), m(E.canForward), v(E.state));
        }), b = (0, n.c)((e3) => {
          E && (E.replaceState(e3), d2.replace(e3.href));
        }), I = (0, n.c)((e3) => {
          E && (E.pushState(e3), f());
        }), _ = (0, n.c)(() => {
          E && (E.back(), f(), d2.back());
        }), k = (0, n.c)(() => {
          E && (E.forward(), f(), d2.forward());
        });
        (0, s.useEffect)(() => {
          var e3;
          let t3 = [u, c.toString()].join("?");
          (!(null == E ? void 0 : E.state) || (null == E || null == (e3 = E.state) ? void 0 : e3.isLocationNotEqual(t3))) && I({ href: t3 });
        }, [E, u, c, I]);
        {
          let e3 = (0, l.Cvn)(u, c);
          e3 !== S.current && (S.current = e3, P.current = P.current + 1);
        }
        return (0, r.jsx)(l.Q0U.Provider, {
          value: {
            pushState: I,
            replaceState: b,
            canForward: y,
            canBack: h,
            back: _,
            forward: k,
            state: p,
            length: P.current
          },
          children: t2
        });
      };
    },
    48249: (e, t, a) => {
      "use strict";
      a.d(t, { km: () => m, h4: () => q, cw: () => u, k_: () => W });
      var r = a(74125), i = a(93064), s = a(4542), n = a(77217), l = a(26433);
      let o = (e2, t2, a2) => -1 === a2 ? e2.slice(t2) : e2.slice(t2, t2 + a2), d = i.gK.compose(
        i.gK.model("ConcertsPageConfig", {
          topOffset: i.gK.optional(i.gK.number, 0),
          topLimit: i.gK.optional(i.gK.number, 3),
          feedOffset: i.gK.optional(i.gK.number, 3),
          feedLimit: i.gK.optional(i.gK.number, -1)
        }),
        l.XT
      ).actions((e2) => ({
        getData: (0, i.L3)(function* () {
          let { concertsResource: t2, modelActionsLogger: a2 } = (0, i._$)(e2);
          if (!e2.isLoading)
            try {
              e2.loadingState = r.GuX.PENDING;
              let {
                config: { feed: a3, top: i2 }
              } = yield t2.getTabConfig({});
              e2.feedLimit = a3.limit, e2.feedOffset = a3.offset, e2.topLimit = i2.limit, e2.topOffset = i2.offset, e2.loadingState = r.GuX.RESOLVE;
            } catch (t3) {
              a2.error(t3), e2.loadingState = r.GuX.REJECT;
            }
        }),
        reset() {
          e2.loadingState = r.GuX.IDLE, e2.feedLimit = -1, e2.feedOffset = 3, e2.topLimit = 3, e2.topOffset = 0;
        }
      })), u = i.gK.compose(
        i.gK.model("ConcertsPage", {
          config: d,
          landing: s.Ju,
          topConcerts: i.gK.maybeNull(i.gK.array(n.aR)),
          feedConcerts: i.gK.maybeNull(i.gK.array(n.aR))
        }),
        l.XT,
        l.pl
      ).views((e2) => ({
        get isShimmerVisible() {
          return e2.isNeededToLoad || e2.isLoading || e2.isRejected;
        },
        get isShimmerActive() {
          return e2.isLoading;
        }
      })).actions((e2) => ({
        getData: (0, i.L3)(function* () {
          let { concertsResource: t2, modelActionsLogger: a2 } = (0, i._$)(e2);
          if (!e2.config.isLoading && !e2.isLoading)
            try {
              e2.loadingState = r.GuX.PENDING, yield e2.config.getData();
              let { items: a3 } = yield t2.getFeed({}), { feedConcerts: s2, topConcerts: l2 } = ((e3, t3) => {
                let { topLimit: a4, topOffset: r2, feedLimit: i2, feedOffset: s3 } = e3;
                return { topConcerts: o(t3, r2, a4), feedConcerts: o(t3, s3, i2) };
              })(
                e2.config,
                a3.map((e3) => (0, n.HN)(e3))
              );
              e2.feedConcerts = (0, i.wg)(s2), e2.topConcerts = (0, i.wg)(l2), e2.loadingState = r.GuX.RESOLVE;
            } catch (t3) {
              a2.error(t3), e2.loadingState = r.GuX.REJECT;
            }
        }),
        reset() {
          e2.config.reset(), e2.landing.reset(), e2.loadingState = r.GuX.IDLE, e2.destroyItems([e2.topConcerts, e2.feedConcerts]);
        }
      }));
      var c = a(54486), h = a(28303), g = a(61910), y = a(42421);
      let m = (0, h.PA)(() => {
        let { concerts: e2 } = (0, r.Pjs)();
        return (0, g.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), (0, c.jsx)(y.M, {});
      });
      var p = a(97396), v = a(43426), P = a(47713), S = a(9348), E = a(43350), f = a(31500), b = a(6024), I = a(56231), _ = a(97800), k = a(8817), C = a(67648), T = a(77516), D = a(80585), A = a(63118), x = a.n(A);
      let L = (0, h.PA)(() => {
        let e2 = (0, g.useId)(), { concerts: t2 } = (0, r.Pjs)(), { formatMessage: a2 } = (0, v.A)(), [i2, s2] = (0, C.d)(), l2 = (0, r.fBs)(), o2 = (0, g.useRef)(false), d2 = (0, k.c)(() => {
          var e3;
          return !t2.isShimmerVisible && (null == (e3 = t2.feedConcerts) ? void 0 : e3.length) ? t2.feedConcerts.length : 50;
        }), {
          virtualizer: u2,
          rowResizeObserver: h2,
          columnCount: y2,
          indices: m2
        } = (0, T.LW)({
          count: d2(),
          rowGap: 32,
          columnGap: 16,
          getEstimateRowSize: () => 371,
          minColumnCount: 2,
          minColumnWidth: 170,
          maxColumnWidth: 227,
          containerRef: i2
        }), p2 = { "--feed-concerts-height": "".concat(u2.getTotalSize(), "px"), "--feed-concerts-column-count": y2 }, P2 = (0, g.useCallback)(
          (e3) => {
            var a3, i3, s3;
            let l3 = null == (a3 = t2.feedConcerts) ? void 0 : a3[e3];
            return !l3 || t2.isShimmerVisible ? (0, c.jsx)(n.LY, { isActive: t2.isShimmerActive }) : (0, c.jsx)(r.Bki, {
              objectType: E.ky.Concert,
              objectId: l3.id,
              objectPosX: e3 % y2 + 1,
              objectPosY: Math.floor(e3 / y2) + 1,
              objectsCount: null != (s3 = null == (i3 = t2.feedConcerts) ? void 0 : i3.length) ? s3 : 0,
              children: (0, c.jsx)(n.Qb, { concert: l3 })
            });
          },
          [y2, t2.feedConcerts, t2.isShimmerActive, t2.isShimmerVisible]
        );
        return (0, g.useEffect)(() => {
          t2.isResolved && !o2.current && (l2(), o2.current = true);
        }, [t2.isResolved, l2]), (0, c.jsxs)("div", {
          className: x().root,
          ...(0, f.Am)(f.e8.concerts.CONCERTS_FEED),
          children: [
            (0, c.jsx)(D.Tw, {
              className: x().header,
              labeledForId: e2,
              title: a2({ id: "concerts.all-concerts" }),
              headingVariant: "h2"
            }),
            (0, c.jsx)("div", {
              "aria-labelledby": e2,
              ref: s2,
              style: p2,
              className: x().container,
              children: u2.getVirtualItems().map(
                (e3) => (0, c.jsx)(
                  T.Ux,
                  {
                    className: x().row,
                    columnClassName: x().column,
                    virtualItem: e3,
                    resizeObserver: h2,
                    indices: m2,
                    renderItemByIndex: P2,
                    scrollMargin: u2.options.scrollMargin
                  },
                  e3.key
                )
              )
            })
          ]
        });
      });
      var R = a(50420), N = a(81203), w = a(35462), M = a.n(w);
      let O = (e2) => {
        let { children: t2 } = e2, a2 = (0, g.useId)(), r2 = (0, g.useRef)(null), { formatMessage: i2 } = (0, v.A)();
        return (0, c.jsxs)("div", {
          className: M().root,
          ...(0, f.Am)(f.e8.concerts.CONCERTS_TOP),
          children: [
            (0, c.jsx)(D.Tw, {
              className: M().header,
              labeledForId: a2,
              title: i2({ id: "concerts.top-for-you" }),
              controls: (0, c.jsx)(D.X9, { className: M().controls, carouselRef: r2 }),
              headingVariant: "h2"
            }),
            (0, c.jsx)(N.Carousel, {
              className: M().carousel,
              ref: r2,
              itemClassName: (0, R.$)(M().item, M().important),
              "aria-labelledby": a2,
              children: t2
            })
          ]
        });
      }, F = (e2) => Array.from({ length: 10 }, (t2, a2) => (0, c.jsx)(n.LY, { isActive: e2, withPriceButton: true }, a2)), G = (0, h.PA)(() => {
        let { concerts: e2 } = (0, r.Pjs)(), t2 = (0, r.fBs)(), a2 = (0, g.useRef)(false), i2 = (0, g.useMemo)(() => {
          var t3;
          return (null == (t3 = e2.topConcerts) ? void 0 : t3.length) && !e2.isShimmerVisible ? e2.topConcerts.map((t4, a3) => {
            var i3, s2;
            return (0, c.jsx)(
              r.Bki,
              {
                objectType: E.ky.Concert,
                objectId: t4.id,
                objectPosX: a3 + 1,
                objectPosY: 1,
                objectsCount: null != (s2 = null == (i3 = e2.topConcerts) ? void 0 : i3.length) ? s2 : 0,
                children: (0, c.jsx)(n.Qb, { withMask: false, withPriceButton: true, concert: t4 })
              },
              t4.getKey(a3)
            );
          }) : F(e2.isShimmerActive);
        }, [e2.isShimmerActive, e2.isShimmerVisible, e2.topConcerts]);
        return (0, g.useEffect)(() => {
          e2.isResolved && !a2.current && (t2(), a2.current = true);
        }, [e2.isResolved, t2]), e2.isNeededToLoad && (0, g.use)(e2.getData()), (0, c.jsx)(O, { children: i2 });
      }), K = () => (0, c.jsx)(g.Suspense, { fallback: (0, c.jsx)(O, { children: F(true) }), children: (0, c.jsx)(G, {}) });
      var j = a(82644), X = a(33276), B = a(62395), V = a(77343), U = a.n(V);
      let q = (0, h.PA)(() => {
        var e2, t2, a2, i2, n2, l2, o2, d2, u2;
        let { formatMessage: h2 } = (0, v.A)(), { setContentScrollRef: y2, contentScrollRef: m2 } = (0, r.gKY)(), { concerts: C2, experiments: T2, user: A2 } = (0, r.Pjs)(), x2 = (() => {
          let e3 = (0, B.st)(), t3 = (0, r.UlF)(), { hash: a3 } = (0, B.gf)();
          return (0, k.c)((r2, i3) => {
            if (!e3) return;
            let s2 = {
              hash: a3,
              pageId: E.QT.ConcertsLandingScreen,
              pageStyle: E.QL.Fullscreen,
              pagePlacement: E.c4.Fullscreen,
              viewUuid: i3
            }, n3 = (0, E.Fx)({ params: s2, logger: t3, context: "useSendEventOnConcertsOpenedOrClosed" });
            n3 && (r2 ? (0, E.Fn)(e3.evgenInstance, n3) : (0, E.PO)(e3.evgenInstance, n3));
          });
        })(), R2 = (0, g.useRef)(String((0, S.A)())), N2 = null != (l2 = null == (e2 = C2.landing.meta) ? void 0 : e2.selectedTabIndex) ? l2 : 0, w2 = null != (o2 = null == (a2 = C2.landing.tabs.data) || null == (t2 = a2[N2]) ? void 0 : t2.blocks.length) ? o2 : 0;
        return ((!T2.checkExperiment(r.zal.WebNextConcertsTab, "on") || T2.checkExperiment(r.zal.disableAllConcerts, "on")) && (0, p.notFound)(), A2.hasPlus || (0, p.redirect)(r.Zyd.main.href), (0, g.useEffect)(
          () => () => {
            C2.reset();
          },
          [C2]
        ), (0, g.useEffect)(() => {
          let e3 = R2.current;
          return x2(true, e3), () => {
            x2(false, e3);
          };
        }, [x2]), (0, r.Jzs)(C2.landing.isResolved), (() => {
          let e3 = (0, g.useRef)(1), { concerts: t3 } = (0, r.Pjs)(), { notify: a3 } = (0, r.lkh)(), { formatMessage: i3 } = (0, v.A)();
          (0, g.useEffect)(() => {
            e3 && (t3.isRejected && a3((0, c.jsx)(D.hT, { error: i3({ id: "concerts.feed-error" }) }), { containerId: r.uQT.ERROR }), e3.current--);
          }, [t3.isRejected, i3, a3]);
        })(), C2.landing.isNeededToLoad && (0, g.use)(
          C2.landing.getSkeleton({ id: b.p.CONCERTS, showWizard: A2.settings.showWizard }, { preloadBlocksCount: 2 })
        ), C2.landing.isRejected) ? (0, c.jsx)(j.w, {}) : (0, c.jsx)(r.nVz, {
          pageId: r._Q$.CONCERTS,
          children: (0, c.jsxs)(X.hO, {
            scrollElement: m2,
            outerTitle: h2({ id: "entity-names.concerts" }),
            children: [
              (0, c.jsx)(D.Y9, {
                variant: D.Vw.TEXT,
                showControls: false,
                children: (0, c.jsx)(_.Heading, {
                  variant: "h1",
                  weight: "bold",
                  size: "xl",
                  children: (0, c.jsx)(P.A, { id: "entity-names.concerts" })
                })
              }),
              (0, c.jsxs)(I.N, {
                ref: y2,
                className: U().root,
                containerClassName: U().container,
                ...(0, f.Am)(f.Xk.concerts.CONCERTS_PAGE),
                children: [
                  (0, c.jsx)(r.jPc, {
                    children: (0, c.jsx)(r.hjC, {
                      tabId: "",
                      tabPos: 0,
                      isTabSelectedByDefault: false,
                      children: (0, c.jsx)(r.FoH, {
                        blockId: E.LA.ConcertTabHeader,
                        blockType: E.LA.ConcertTabHeader,
                        blockPosX: 1,
                        blockPosY: 1,
                        objectsCount: null != (d2 = null == (i2 = C2.topConcerts) ? void 0 : i2.length) ? d2 : 0,
                        children: (0, c.jsx)(K, {})
                      })
                    })
                  }),
                  (0, c.jsx)(r.MZP, {
                    offsetBlockPosY: 1,
                    children: (0, c.jsx)(s.EA, {
                      landing: C2.landing,
                      errorComponent: (0, c.jsx)(j.w, { withBackwardControl: false })
                    })
                  }),
                  (0, c.jsx)(r.jPc, {
                    children: (0, c.jsx)(r.hjC, {
                      tabId: "",
                      tabPos: 0,
                      isTabSelectedByDefault: false,
                      children: (0, c.jsx)(r.FoH, {
                        blockId: E.LA.ConcertTabFeed,
                        blockType: E.LA.ConcertTabFeed,
                        blockPosX: 1,
                        blockPosY: w2 + 2,
                        objectsCount: null != (u2 = null == (n2 = C2.feedConcerts) ? void 0 : n2.length) ? u2 : 0,
                        children: (0, c.jsx)(L, {})
                      })
                    })
                  }),
                  (0, c.jsx)(D.A, { children: (0, c.jsx)(D.wi, { className: U().footer }) })
                ]
              })
            ]
          })
        });
      }), W = () => (0, c.jsx)(D.JR, {
        style: { position: "absolute", background: "var(--ym-background-color-primary-enabled-content)" }
      });
    },
    48625: (e, t, a) => {
      "use strict";
      a.d(t, { EX: () => g.PostPage, VQ: () => h });
      var r = a(93064), i = a(14287), s = a(23615), n = a(94376), l = a(83909), o = a(63695), d = a(13611), u = a(74125), c = a(26433);
      let h = r.gK.compose(
        r.gK.model("PostPage", {
          errorStatusCode: r.gK.maybe(r.gK.number),
          title: r.gK.maybeNull(r.gK.string),
          promotionType: r.gK.maybeNull(r.gK.enumeration(Object.values(s.Q))),
          artists: r.gK.maybe(r.gK.array(o.PK)),
          albums: r.gK.maybe(r.gK.array(n.JC)),
          playlists: r.gK.maybe(r.gK.array(l.IP))
        }),
        c.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === u.GuX.PENDING;
          },
          get isNotFound() {
            let t3 = e2.errorStatusCode === i.X1.NOT_FOUND || e2.errorStatusCode === i.X1.BAD_REQUEST;
            return e2.isRejected && t3;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          }
        };
        return t2;
      }).actions((e2) => ({
        getData: (0, r.L3)(function* (t2) {
          let { promoId: a2 } = t2, { feedResource: s2, modelActionsLogger: l2 } = (0, r._$)(e2);
          if (e2.loadingState !== u.GuX.PENDING)
            try {
              e2.loadingState = u.GuX.PENDING;
              let t3 = yield s2.getPromotionsById({ promoId: a2 });
              e2.title = t3.title, e2.promotionType = t3.promotionType, t3.artists && t3.artists.length > 0 && (e2.artists = (0, r.wg)(t3.artists.map(o.dM))), t3.albums && t3.albums.length > 0 && (e2.albums = (0, r.wg)(t3.albums.map(n.pp))), t3.playlists && t3.playlists.length > 0 && (e2.playlists = (0, r.wg)(
                t3.playlists.map((e3) => {
                  let { playlist: t4 } = e3;
                  return (0, d.jX)(t4);
                })
              )), e2.loadingState !== u.GuX.IDLE && (e2.loadingState = u.GuX.RESOLVE);
            } catch (t3) {
              l2.error(t3), t3 instanceof i.GX && (t3.statusCode === i.X1.NOT_FOUND || t3.statusCode === i.X1.BAD_REQUEST) && (e2.errorStatusCode = i.X1.NOT_FOUND), e2.loadingState !== u.GuX.IDLE && (e2.loadingState = u.GuX.REJECT);
            }
        }),
        reset() {
          e2.loadingState = u.GuX.IDLE, e2.title = null, e2.artists = (0, r.wg)([]), e2.albums = (0, r.wg)([]);
        }
      }));
      a(77026);
      var g = a(93685);
    },
    49841: (e, t, a) => {
      "use strict";
      a.d(t, { KidsEditorialPlaylistsPage: () => E });
      var r = a(54486), i = a(50420), s = a(28303), n = a(97396), l = a(61910), o = a(43426), d = a(31500), u = a(8817), c = a(27510), h = a(97800), g = a(82644), y = a(33276), m = a(83909), p = a(74125), v = a(80585), P = a(24993), S = a.n(P);
      let E = (0, s.PA)((e2) => {
        var t2, a2, s2;
        let { id: P2 } = e2, {
          kids: { kidsEditorialPlaylistSubpage: E2 },
          settings: { isMobile: f }
        } = (0, p.Pjs)(), b = (0, p.W6M)(), { contentScrollRef: I, setContentScrollRef: _ } = (0, p.gKY)(), { formatMessage: k } = (0, o.A)(), C = (0, u.c)((e3) => {
          E2.getPlaylists({ page: e3, pageSize: 20 });
        });
        E2.isNotFound && (0, n.notFound)(), (0, l.useEffect)(
          () => () => {
            E2.reset();
          },
          [E2]
        );
        let T = (0, c.L)(() => ({
          Footer: () => (0, r.jsx)(v.A, { children: (0, r.jsx)(v.wi, { className: S().footer }) })
        }));
        if ((0, p.Jzs)(E2.isResolved), (0, p.XcE)(E2.pagesLoader, C), E2.isNeededToLoad && (0, l.use)(E2.getData({ id: P2, page: 0, pageSize: 20 })), E2.isSomethingWrong)
          return (0, r.jsx)(g.w, {});
        let D = E2.isLoading ? 20 : null != (a2 = null == (t2 = E2.pagesLoader.pager) ? void 0 : t2.total) ? a2 : 0;
        return (0, r.jsx)(p.nVz, {
          pageId: p._Q$.KIDS_EDITORIAL_PLAYLISTS,
          children: (0, r.jsx)(y.hO, {
            scrollElement: I,
            outerTitle: E2.title,
            children: (0, r.jsxs)("div", {
              className: S().root,
              ...(0, d.Am)(d.Xk.kids.KIDS_EDITORIAL_PLAYLISTS),
              children: [
                (0, r.jsx)(v.Y9, {
                  variant: v.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: b.canBack,
                  children: (0, r.jsx)(h.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: E2.title
                  })
                }),
                (0, r.jsx)(v.$$, {
                  context: { listAriaLabel: k({ id: "mixes.playlists-list" }, { genreName: E2.title || "" }) },
                  className: (0, i.$)(S().scrollContainer, S().important),
                  customComponents: T,
                  itemContentCallback: (e3) => {
                    let t3 = E2.playlists[e3], a3 = k(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: k({ id: "entity-names.playlist" }) }
                    );
                    return t3 ? (0, r.jsx)(m.B6, { playlist: t3, contentLinesCount: 3 }, t3.key) : (0, r.jsx)(v.Vt, { isActive: true, "aria-label": a3 });
                  },
                  totalCount: D,
                  onGetDataByPage: C,
                  pageSize: 20,
                  totalRequests: null != (s2 = E2.pagesLoader.requestsCount) ? s2 : 0,
                  listClassName: S().content,
                  itemClassName: S().item,
                  handleRef: _,
                  isMobileLayout: f,
                  useWindowScroll: f
                })
              ]
            })
          })
        });
      });
    },
    50389: (e, t, a) => {
      "use strict";
      a.d(t, { i: () => n });
      var r = a(92761), i = a(60463), s = a(30630);
      function n(e2) {
        let { productQuality: t2, entities: a2, entity: n2 } = e2, l = false;
        if (a2 && (l = a2.some((e3) => (0, i.l)(e3))), n2 && (l = (0, i.l)(n2)), l) return r.e.SMART_PREVIEW;
        switch (t2) {
          case s.e.HIGH_QUALITY:
            return r.e.LOSSLESS;
          case s.e.BALANCED:
            return r.e.NQ;
          case s.e.EFFICIENT:
            return r.e.LQ;
          case s.e.PREVIEW:
            return r.e.PREVIEW;
          default:
            return r.e.NQ;
        }
      }
    },
    50757: (e) => {
      e.exports = { root: "PostPlaylists_root__3tea0", content: "PostPlaylists_content__2fXI5" };
    },
    51760: (e, t, a) => {
      "use strict";
      a.d(t, { ChartTracksPage: () => S });
      var r = a(54486), i = a(50420), s = a(28303), n = a(61910), l = a(43426), o = a(31500), d = a(63585), u = a(22674), c = a(97800), h = a(82644), g = a(33276), y = a(21365), m = a(74125), p = a(80585), v = a(42838), P = a.n(v);
      let S = (0, s.PA)(() => {
        let { formatMessage: e2 } = (0, l.A)(), {
          chart: { tracksSubPage: t2 },
          settings: { isMobile: a2 }
        } = (0, m.Pjs)(), s2 = (0, m.W6M)(), { contentScrollRef: v2, setContentScrollRef: S2 } = (0, m.gKY)(), E = (0, m.wZZ)(), { from: f } = (0, m.fyy)({ pageId: m._Q$.CHART });
        (0, m.Jzs)(t2.isResolved);
        let b = (0, n.useCallback)(
          (e3) => {
            let a3 = t2.items[e3];
            return a3 && !t2.isLoading && t2.playlistMeta ? (0, r.jsx)(y.QB, {
              track: a3,
              playContextParams: E(e3, {
                contextData: {
                  type: d.K.Playlist,
                  meta: { id: "".concat(t2.playlistMeta.uid, ":").concat(t2.playlistMeta.kind) },
                  from: f
                },
                queueParams: { index: e3, entityId: a3.id },
                loadContextMeta: true
              })
            }) : (0, r.jsx)(p.DS, { isActive: true, className: P().shimmerItem, variant: m.Xjt.PLAYLIST });
          },
          [f, E, t2.isLoading, t2.items, t2.playlistMeta]
        ), I = (0, n.useMemo)(
          () => ({ Footer: () => (0, r.jsx)(p.A, { children: (0, r.jsx)(p.wi, { className: P().footer }) }) }),
          []
        ), _ = (0, n.useMemo)(
          () => t2.title ? (0, r.jsx)(c.Heading, {
            id: "collection-artists-header",
            variant: "h1",
            weight: "bold",
            size: "xl",
            lineClamp: 1,
            children: t2.title
          }) : (0, r.jsx)(u.Shimmer, { className: P().shimmerTitle, radius: "l" }),
          [t2.title]
        );
        return (t2.isNeededToLoad && (0, n.use)(t2.getTracks()), t2.isRejected) ? (0, r.jsx)(h.w, {}) : (0, r.jsx)(m.nVz, {
          pageId: m._Q$.CHART,
          children: (0, r.jsx)(g.hO, {
            scrollElement: v2,
            ...t2.title && { outerTitle: t2.title },
            children: (0, r.jsxs)("div", {
              className: P().root,
              ...(0, o.Am)(o.Xk.chart.CHART_PAGE),
              children: [
                (0, r.jsx)(p.Y9, {
                  variant: p.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: s2.canBack,
                  children: _
                }),
                (0, r.jsx)(p.$$, {
                  className: (0, i.$)(P().scrollContainer, P().important),
                  listClassName: P().content,
                  customComponents: I,
                  totalCount: t2.items.length,
                  itemContentCallback: b,
                  debounceDurationInMs: 300,
                  handleRef: S2,
                  context: { listAriaLabel: e2({ id: "entity-names.chart-tracks-list" }) },
                  isMobileLayout: a2,
                  useWindowScroll: a2
                })
              ]
            })
          })
        });
      });
    },
    51892: (e) => {
      e.exports = {
        root: "PostShimmer_root__MlLkY",
        top: "PostShimmer_top__ySpmZ",
        bottom: "PostShimmer_bottom__ajW_P"
      };
    },
    53714: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { StoreProvider: () => tA });
      var r, i, s = a(54486), n = a(28303), l = a(93064), o = a(97396), d = a(61910);
      a(15209);
      var u = a(74125), c = a(30630), h = a(3269), g = a(35620), y = a(89461), m = a(41663);
      a(49756);
      var p = a(4542), v = a(94376), P = a(40502), S = a(26433);
      let E = l.gK.compose(l.gK.model("UpcomingAlbums", { items: l.gK.maybeNull(l.gK.array(v.VH)) }), S.pl, S.XT).actions((e10) => ({
        reset() {
          e10.loadingState = u.GuX.IDLE, e10.destroyItems([e10.items]);
        }
      })), f = l.gK.compose(
        l.gK.model("CollectionAlbumsPage", {
          sort: l.gK.maybeNull(P.wY),
          pagesLoader: (0, S.Ij)(v.JC),
          upcomingAlbums: E
        }),
        S.pl
      ).views((e10) => {
        let t2 = {
          get isAlbumsLoading() {
            return !e10.pagesLoader.isSomePageResolved;
          },
          get isLoading() {
            return t2.isAlbumsLoading || e10.upcomingAlbums.isNeededToLoad || e10.upcomingAlbums.isLoading;
          },
          get isUpcomingAlbumsLoading() {
            return e10.upcomingAlbums.isNeededToLoad || e10.upcomingAlbums.isLoading;
          },
          get isUpcomingAlbumsEmpty() {
            return !t2.isUpcomingAlbumsLoading && (!e10.upcomingAlbums.items || 0 === e10.upcomingAlbums.items.length);
          },
          get isAlbumsEmpty() {
            return e10.pagesLoader.isEmpty;
          },
          get isNeededToLoad() {
            return e10.pagesLoader.isNeedToMakeInitialRequest;
          },
          get isResolved() {
            return e10.pagesLoader.isSomePageResolved;
          },
          get items() {
            var a2;
            return null != (a2 = e10.pagesLoader.items) ? a2 : [];
          }
        };
        return t2;
      }).actions((e10) => ({
        getData: (0, l.L3)(function* (t2) {
          let { userId: a2, page: r2 = 0, pageSize: i2 = 20, sortBy: s2, sortOrder: n2, metaType: o2 } = t2, { usersResource: d2, modelActionsLogger: c2 } = (0, l._$)(e10);
          if (e10.pagesLoader.isPageNeedToLoad(r2)) {
            e10.sort = null, (0, P.WG)(s2) && (0, P.hl)(n2) && (e10.sort = (0, l.wg)({ sortBy: s2, sortOrder: n2 }));
            try {
              var h2, g2;
              e10.pagesLoader.setPageState(r2, u.GuX.PENDING);
              let t3 = yield d2.getLikedAlbums({
                userId: a2,
                page: r2,
                pageSize: i2,
                sortBy: s2,
                sortOrder: n2,
                metaType: o2
              }), l2 = null != (g2 = null == (h2 = t3.albums) ? void 0 : h2.map((e11) => {
                let { album: t4 } = e11;
                return (0, v.pp)(t4);
              })) ? g2 : [];
              e10.pagesLoader.setItems(l2, { page: r2, pager: { page: r2, perPage: i2, total: t3.pager.total } });
            } catch (t3) {
              c2.error(t3), e10.pagesLoader.setItems(null, { responseStatus: u.FlZ.ERROR, page: r2 });
            }
          }
        }),
        getPresaves: (0, l.L3)(function* (t2) {
          let { userId: a2 } = t2, { usersResource: r2, modelActionsLogger: i2 } = (0, l._$)(e10);
          if (!e10.upcomingAlbums.isLoading)
            try {
              var s2;
              e10.upcomingAlbums.loadingState = u.GuX.PENDING;
              let t3 = yield r2.getPresaves({ userId: a2, includeReleased: false, includeUpcoming: true });
              e10.upcomingAlbums.items = (0, l.wg)(null == (s2 = t3.upcomingAlbums) ? void 0 : s2.map(v.lO)), e10.upcomingAlbumsLoadingState !== u.GuX.IDLE && (e10.upcomingAlbums.loadingState = u.GuX.RESOLVE);
            } catch (t3) {
              i2.error(t3), e10.upcomingAlbums.isNeededToLoad || (e10.upcomingAlbums.loadingState = u.GuX.REJECT);
            }
        }),
        reset() {
          e10.pagesLoader.reset(), e10.upcomingAlbums.reset(), e10.destroyItems([e10.sort]);
        }
      }));
      var b = a(55616), I = a(63695);
      let _ = l.gK.compose(l.gK.model("TopArtists", { items: l.gK.array(b.GV) }), S.pl, S.XT).actions((e10) => ({
        reset() {
          e10.loadingState = u.GuX.IDLE, e10.destroyItems([e10.items]);
        }
      })), k = l.gK.compose(
        l.gK.model("CollectionArtistsPage", {
          sort: l.gK.maybeNull(P.wY),
          pagesLoader: (0, S.Ij)(I.PK),
          topArtists: _
        }),
        S.pl
      ).views((e10) => ({
        get isLoadingTopArtists() {
          return e10.topArtists.isNeededToLoad || e10.topArtists.isLoading;
        },
        get isShimmerVisible() {
          return !e10.pagesLoader.isSomePageResolved;
        },
        get isNeededToLoad() {
          return e10.pagesLoader.isNeedToMakeInitialRequest;
        },
        get isRejected() {
          return e10.pagesLoader.isInitialRequestRejected;
        },
        get isResolved() {
          return e10.pagesLoader.isSomePageResolved;
        },
        get requestsCount() {
          return e10.pagesLoader.requestsCount;
        },
        get items() {
          var t2;
          return null != (t2 = e10.pagesLoader.items) ? t2 : [];
        }
      })).actions((e10) => ({
        getDataTopArtists: (0, l.L3)(function* () {
          let { personalResource: t2, modelActionsLogger: a2 } = (0, l._$)(e10);
          try {
            var r2, i2;
            e10.topArtists.loadingState = u.GuX.PENDING;
            let a3 = yield t2.getTopArtists();
            e10.topArtists.items = (0, l.wg)(
              null != (i2 = null == (r2 = a3.artists) ? void 0 : r2.map((e11) => (0, b.MX)(e11))) ? i2 : []
            ), e10.topArtists.loadingState = u.GuX.RESOLVE;
          } catch (t3) {
            a2.error(t3), e10.topArtists.loadingState = u.GuX.REJECT;
          }
        }),
        getData: (0, l.L3)(function* (t2) {
          let { userId: a2, page: r2 = 0, pageSize: i2 = 20, sortBy: s2, sortOrder: n2 } = t2, { usersResource: o2, modelActionsLogger: d2 } = (0, l._$)(e10);
          if (e10.pagesLoader.isPageNeedToLoad(r2)) {
            e10.sort = null, (0, P.WG)(s2) && (0, P.hl)(n2) && (e10.sort = (0, l.wg)({ sortBy: s2, sortOrder: n2 }));
            try {
              var c2, h2;
              e10.pagesLoader.setPageState(r2, u.GuX.PENDING);
              let t3 = yield o2.getLikedArtists({ userId: a2, page: r2, pageSize: i2, sortBy: s2, sortOrder: n2 }), l2 = null != (h2 = null == (c2 = t3.artists) ? void 0 : c2.map(I.dM)) ? h2 : [];
              e10.pagesLoader.setItems(l2, { page: r2, pager: { page: r2, perPage: i2, total: t3.pager.total } });
            } catch (t3) {
              d2.error(t3), e10.pagesLoader.setItems(null, { responseStatus: u.FlZ.ERROR, page: r2 });
            }
          }
        }),
        reset() {
          e10.topArtists.reset(), e10.pagesLoader.reset(), e10.sort = null;
        }
      }));
      var C = a(65779);
      let T = l.gK.compose(l.gK.model("CollectionClipsPageWillLike", { clips: l.gK.maybeNull(l.gK.array(C.kv)) }), S.XT, S.pl).views((e10) => ({
        get isShimmerVisible() {
          return e10.isLoading || e10.isRejected;
        },
        get isEmpty() {
          var t2;
          return e10.isResolved && (!e10.clips || (null == (t2 = e10.clips) ? void 0 : t2.length) === 0);
        }
      })).actions((e10) => ({
        getData: (0, l.L3)(function* () {
          let { clipsResource: t2, modelActionsLogger: a2 } = (0, l._$)(e10);
          try {
            e10.loadingState = u.GuX.PENDING;
            let a3 = yield t2.getClipsWillLike({ page: 0, pageSize: 50 });
            a3.clips && (e10.clips = (0, l.wg)(a3.clips.map(C.i$))), e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.RESOLVE);
          } catch (t3) {
            a2.error(t3), e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.REJECT);
          }
        }),
        reset() {
          e10.loadingState = u.GuX.IDLE, e10.destroyItems([e10.clips]);
        }
      })), D = l.gK.compose(
        l.gK.model("CollectionClipsPage", {
          items: l.gK.array(l.gK.maybeNull(C.kv)),
          pager: l.gK.maybeNull(S.jd),
          alreadyRequestedPages: l.gK.map(l.gK.number),
          pendingPages: l.gK.map(l.gK.number),
          clipsWillLike: T
        }),
        S.XT,
        S.pl
      ).views((e10) => ({
        get isEmpty() {
          return e10.isResolved && (!e10.pager || 0 === e10.pager.total);
        },
        get isLoaded() {
          return e10.isResolved || e10.isRejected;
        }
      })).actions((e10) => ({
        setInitialShimmer() {
          e10.items = (0, l.wg)(Array.from({ length: 20 }, () => null));
        },
        getData: (0, l.L3)(function* (t2) {
          var a2;
          let { userId: r2, page: i2 = 0, pageSize: s2 = 20 } = t2, { usersResource: n2, modelActionsLogger: o2 } = (0, l._$)(e10);
          if (!(e10.pager && e10.items.length >= (null == (a2 = e10.pager) ? void 0 : a2.total) || e10.loadingState === u.GuX.PENDING && e10.pendingPages.has(i2.toString())) && !e10.alreadyRequestedPages.has(i2.toString())) {
            "number" == typeof i2 && e10.alreadyRequestedPages.set(i2.toString(), i2);
            try {
              e10.loadingState = u.GuX.PENDING, e10.pendingPages.set(i2.toString(), i2);
              let t3 = yield n2.getLikedClips({ userId: r2, page: i2, pageSize: s2 }), a3 = { page: i2, perPage: s2, total: t3.pager.total };
              if (t3.clips) {
                let r3 = t3.clips.map(C.i$);
                (0, u.Iyy)({ items: e10.items, mappedRawItems: r3, page: i2, pageSize: s2 }), e10.items = (0, l.wg)(e10.items.slice(0, a3.total));
              }
              e10.pager = a3, e10.loadingState = u.GuX.RESOLVE;
            } catch (t3) {
              o2.error(t3), e10.loadingState = u.GuX.REJECT;
            } finally {
              e10.pendingPages.delete(i2.toString());
            }
          }
        }),
        reset() {
          e10.loadingState = u.GuX.IDLE, e10.pager = null, e10.alreadyRequestedPages.clear(), e10.pendingPages.clear(), e10.destroyItems([e10.items]), e10.clipsWillLike.reset();
        }
      })), A = l.gK.compose(
        l.gK.model("CollectionNonMusicPage", {
          items: l.gK.array(l.gK.maybeNull(v.JC)),
          pager: l.gK.maybeNull(S.jd),
          alreadyRequestedPages: l.gK.map(l.gK.number),
          pendingPages: l.gK.map(l.gK.number),
          requestsCount: l.gK.maybeNull(l.gK.number)
        }),
        S.XT
      ).views((e10) => ({
        get isLoading() {
          return e10.isNeededToLoad || e10.loadingState === u.GuX.PENDING && 0 === e10.items.length;
        },
        get isEmptyItems() {
          var t2;
          return !!(!(null == (t2 = e10.items) ? void 0 : t2.length) && e10.requestsCount);
        }
      })).actions((e10) => ({
        getData: (0, l.L3)(function* (t2) {
          let { userId: a2, page: r2 = 0, pageSize: i2 = 20, metaType: s2 } = t2, { usersResource: n2, modelActionsLogger: o2 } = (0, l._$)(e10);
          if (!(e10.loadingState === u.GuX.PENDING && e10.pendingPages.has("".concat(r2))) && !e10.alreadyRequestedPages.has("".concat(r2))) {
            "number" == typeof r2 && e10.alreadyRequestedPages.set("".concat(r2), r2);
            try {
              var d2, c2, h2;
              e10.loadingState = u.GuX.PENDING, e10.pendingPages.set("".concat(r2), r2);
              let t3 = yield n2.getLikedAlbums({ userId: a2, page: r2, pageSize: i2, metaType: s2 }), o3 = { page: r2, perPage: i2, total: t3.pager.total };
              0 === e10.items.length && (e10.items = (0, l.wg)(Array.from({ length: o3.total }, () => null)));
              let g2 = null != (c2 = null == (d2 = t3.albums) ? void 0 : d2.map((e11) => {
                let { album: t4 } = e11;
                return (0, v.pp)(t4);
              })) ? c2 : [];
              (0, u.Iyy)({ items: e10.items, mappedRawItems: g2, page: r2, pageSize: i2 }), e10.pager = o3, e10.requestsCount = (null != (h2 = e10.requestsCount) ? h2 : 0) + 1, e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.RESOLVE);
            } catch (t3) {
              o2.error(t3), e10.loadingState = u.GuX.REJECT;
            } finally {
              e10.pendingPages.delete("".concat(r2));
            }
          }
        }),
        reset() {
          e10.loadingState = u.GuX.IDLE, e10.items = (0, l.wg)([]), e10.pendingPages.clear(), e10.pager = null, e10.alreadyRequestedPages.clear(), e10.requestsCount = 0;
        }
      }));
      var x = a(83909), L = a(13611);
      let R = l.gK.model("CollectionPlaylistsCreatedPage", {
        sort: l.gK.maybeNull(P.wY),
        pagesLoader: (0, S.Ij)(L.Zq),
        kinds: l.gK.array(l.gK.number)
      }).views((e10) => ({
        get isShimmerVisible() {
          return !e10.pagesLoader.isSomePageResolved;
        },
        get isNeededToLoad() {
          return e10.pagesLoader.isNeedToMakeInitialRequest;
        },
        get isRejected() {
          return e10.pagesLoader.isInitialRequestRejected;
        },
        get isResolved() {
          return e10.pagesLoader.isSomePageResolved;
        },
        get requestsCount() {
          return e10.pagesLoader.requestsCount;
        },
        get isEmpty() {
          return e10.pagesLoader.isEmpty;
        },
        get items() {
          var t2;
          return null != (t2 = e10.pagesLoader.items) ? t2 : [];
        }
      })).actions((e10) => {
        let t2 = {
          getKinds: (0, l.L3)(function* (t3) {
            let a2 = [], { usersResource: r2 } = (0, l._$)(e10);
            a2 = yield r2.getPlaylistsKinds({ userId: t3, addPlaylistWithLikes: true }), e10.kinds = (0, l.wg)(a2);
          }),
          getData: (0, l.L3)(function* (a2) {
            let { userId: r2, page: i2 = 0, pageSize: s2 = 20, withLikesCount: n2 } = a2, { usersResource: o2, modelActionsLogger: d2 } = (0, l._$)(e10);
            if (e10.pagesLoader.isPageNeedToLoad(i2))
              try {
                e10.pagesLoader.setPageState(i2, u.GuX.PENDING), 0 === e10.kinds.length && (yield t2.getKinds(r2));
                let a3 = i2 * s2, l2 = e10.kinds.slice(a3, a3 + s2), d3 = (yield o2.getPlaylistsByKinds({ userId: r2, kinds: l2, withLikesCount: n2, withTracks: true })).map(
                  x.pd
                );
                e10.pagesLoader.setItems(d3, { page: i2, pager: { page: i2, perPage: s2, total: e10.kinds.length } });
              } catch (t3) {
                d2.error(t3), e10.pagesLoader.setItems(null, { responseStatus: u.FlZ.ERROR, page: i2 });
              }
          }),
          reset() {
            e10.sort = null, e10.pagesLoader.reset(), e10.kinds = (0, l.wg)([]);
          }
        };
        return t2;
      }), N = l.gK.model("CollectionPlaylistsLikedPage", { sort: l.gK.maybeNull(P.wY), pagesLoader: (0, S.Ij)(L.$o) }).views((e10) => ({
        get isShimmerVisible() {
          return !e10.pagesLoader.isSomePageResolved;
        },
        get isNeededToLoad() {
          return e10.pagesLoader.isNeedToMakeInitialRequest;
        },
        get isRejected() {
          return e10.pagesLoader.isInitialRequestRejected;
        },
        get isResolved() {
          return e10.pagesLoader.isSomePageResolved;
        },
        get requestsCount() {
          return e10.pagesLoader.requestsCount;
        },
        get isEmpty() {
          return e10.pagesLoader.isEmpty;
        },
        get items() {
          var t2;
          return null != (t2 = e10.pagesLoader.items) ? t2 : [];
        }
      })).actions((e10) => ({
        getData: (0, l.L3)(function* (t2) {
          let {
            userId: a2,
            page: r2 = 0,
            pageSize: i2 = 20,
            sortBy: s2,
            sortOrder: n2,
            playlistMetaType: o2,
            withTracks: d2
          } = t2;
          if (!e10.pagesLoader.isPageNeedToLoad(r2)) return;
          let { usersResource: c2, modelActionsLogger: h2 } = (0, l._$)(e10);
          e10.sort = null, (0, P.WG)(s2) && (0, P.hl)(n2) && (e10.sort = (0, l.wg)({ sortBy: s2, sortOrder: n2 }));
          try {
            e10.pagesLoader.setPageState(r2, u.GuX.PENDING);
            let { likedPlaylists: t3, pager: l2 } = yield c2.getLikedPlaylists({
              userId: a2,
              page: r2,
              pageSize: i2,
              sortBy: s2,
              sortOrder: n2,
              playlistMetaType: o2,
              withTracks: d2
            }), h3 = t3.map((e11) => {
              let { playlist: t4 } = e11;
              return (0, L.jX)(t4);
            });
            e10.pagesLoader.setItems(h3, { page: r2, pager: l2 });
          } catch (t3) {
            h2.error(t3), e10.pagesLoader.setItems(null, { responseStatus: u.FlZ.ERROR, page: r2 });
          }
        }),
        reset() {
          e10.sort = null, e10.pagesLoader.reset();
        }
      })), w = l.gK.model("CollectionPlaylists", {
        playlistsLiked: N,
        playlistsCreated: R,
        activeTabIndex: l.gK.number,
        tabs: l.gK.array(l.gK.number),
        tabIndexElement: l.gK.maybe(l.gK.string)
      }).views((e10) => ({
        get isLikedTabActive() {
          return e10.activeTabIndex === m.a.LIKED;
        },
        get isCreatedTabActive() {
          return e10.activeTabIndex === m.a.CREATED;
        },
        get activePlaylistsModel() {
          switch (e10.activeTabIndex) {
            case m.a.CREATED:
              return e10.playlistsCreated;
            case m.a.LIKED:
              return e10.playlistsLiked;
            default:
              return e10.playlistsCreated;
          }
        },
        get isEmptyLikedTab() {
          return 0 === e10.playlistsLiked.items.length;
        }
      })).actions((e10) => ({
        setActiveTabIndex(t2) {
          e10.activeTabIndex = t2;
        },
        setTabIndexElement(t2) {
          e10.tabIndexElement = t2;
        },
        reset() {
          e10.playlistsLiked.reset(), e10.playlistsCreated.reset(), e10.activeTabIndex = m.a.CREATED;
        }
      }));
      var M = a(21365);
      let O = (e10) => (0, l.wg)({ type: e10.type, track: (0, M.vU)(e10.track), album: e10.album && (0, v.pp)(e10.album) }), F = (e10) => (0, l.wg)({
        type: e10.type,
        album: e10.album && (0, v.pp)(e10.album),
        playlist: e10.playlist && (0, x.ZC)(e10.playlist),
        track: (0, M.vU)(e10.track)
      }), G = l.gK.model("ShelfLikedItem", { type: l.gK.string, track: M.vj, album: l.gK.maybe(v.JC) });
      l.gK.model("ShelfNewEpisodesItem", { type: l.gK.string, playlist: l.gK.maybe(x.BL), track: M.vj });
      let K = l.gK.model("ShelfRecentlyPlayedItem", {
        type: l.gK.string,
        album: l.gK.maybe(v.JC),
        playlist: l.gK.maybe(x.IP),
        track: M.vj
      }), j = l.gK.compose(
        l.gK.model("CollectionShelfLiked", {
          title: l.gK.maybeNull(l.gK.string),
          typeForFrom: l.gK.maybeNull(l.gK.string),
          entities: l.gK.maybeNull(l.gK.array(G)),
          pager: l.gK.maybeNull(S.jd)
        }),
        S.XT
      ).views((e10) => ({
        get isLoading() {
          return e10.isNeededToLoad || e10.loadingState === u.GuX.PENDING;
        },
        get isEmpty() {
          var t2;
          return e10.isResolved && (null == (t2 = e10.entities) ? void 0 : t2.length) === 0;
        }
      })).actions((e10) => ({
        getData: (0, l.L3)(function* () {
          let { nonMusicResource: t2, modelActionsLogger: a2 } = (0, l._$)(e10);
          if (e10.loadingState !== u.GuX.PENDING)
            try {
              var r2, i2;
              e10.loadingState = u.GuX.PENDING;
              let a3 = yield t2.getShelfLiked();
              e10.title = a3.title, e10.typeForFrom = null != (r2 = a3.typeForFrom) ? r2 : null, e10.pager = null != (i2 = a3.pager) ? i2 : null, e10.entities = (0, l.wg)(a3.entities ? a3.entities.map(O) : []), e10.loadingState = u.GuX.RESOLVE;
            } catch (t3) {
              a2.error(t3), e10.loadingState = u.GuX.REJECT;
            }
        }),
        reset() {
          e10.entities = null, e10.title = null, e10.typeForFrom = null, e10.pager = null, e10.loadingState = u.GuX.IDLE;
        }
      })), X = l.gK.compose(
        l.gK.model("CollectionShelfNewEpisodes", {
          title: l.gK.maybeNull(l.gK.string),
          typeForFrom: l.gK.maybeNull(l.gK.string),
          playlist: l.gK.maybeNull(x.BL),
          tracks: l.gK.maybeNull(l.gK.array(M.vj))
        }),
        S.XT
      ).views((e10) => ({
        get withPlaylist() {
          return !!(e10.playlist && e10.playlist.kind && e10.playlist.isAvailable && e10.playlist.uuid);
        },
        get isLoading() {
          return e10.isNeededToLoad || e10.loadingState === u.GuX.PENDING;
        },
        get isEmpty() {
          return e10.isResolved && (!e10.tracks || 0 === e10.tracks.length);
        }
      })).actions((e10) => ({
        getData: (0, l.L3)(function* () {
          let { nonMusicResource: t2, modelActionsLogger: a2 } = (0, l._$)(e10);
          if (e10.loadingState !== u.GuX.PENDING)
            try {
              var r2;
              e10.loadingState = u.GuX.PENDING;
              let a3 = yield t2.getNewEpisodes();
              e10.title = a3.title;
              let i2 = a3.blocks[0];
              (null == i2 ? void 0 : i2.typeForFrom) && (e10.typeForFrom = i2.typeForFrom), (null == i2 || null == (r2 = i2.entities[0]) ? void 0 : r2.playlist) && (e10.playlist = (0, x.ZC)(i2.entities[0].playlist)), (null == i2 ? void 0 : i2.entities) && (e10.tracks = (0, l.wg)(i2.entities.filter((e11) => e11.track).map((e11) => (0, M.vU)(e11.track)))), e10.loadingState = u.GuX.RESOLVE;
            } catch (t3) {
              a2.error(t3), e10.loadingState = u.GuX.REJECT;
            }
        }),
        reset() {
          e10.title = null, e10.playlist = null, e10.typeForFrom = null, e10.tracks = null, e10.loadingState = u.GuX.IDLE;
        }
      })), B = l.gK.compose(
        l.gK.model("CollectionShelfRecentlyPlayed", {
          title: l.gK.maybeNull(l.gK.string),
          typeForFrom: l.gK.maybeNull(l.gK.string),
          entities: l.gK.maybeNull(l.gK.array(K)),
          pager: l.gK.maybeNull(S.jd)
        }),
        S.XT
      ).views((e10) => ({
        get isLoading() {
          return e10.isNeededToLoad || e10.loadingState === u.GuX.PENDING;
        },
        get isEmpty() {
          return !!(e10.isResolved && e10.entities && 0 === e10.entities.length);
        }
      })).actions((e10) => ({
        getData: (0, l.L3)(function* () {
          let { nonMusicResource: t2, modelActionsLogger: a2 } = (0, l._$)(e10);
          if (e10.loadingState !== u.GuX.PENDING)
            try {
              var r2, i2;
              e10.loadingState = u.GuX.PENDING;
              let a3 = yield t2.getShelfRecentlyPlayed();
              e10.title = a3.title, e10.typeForFrom = null != (r2 = a3.typeForFrom) ? r2 : null, e10.pager = null != (i2 = a3.pager) ? i2 : null, e10.entities = (0, l.wg)(a3.entities.map(F)), e10.loadingState = u.GuX.RESOLVE;
            } catch (t3) {
              a2.error(t3), e10.loadingState = u.GuX.REJECT;
            }
        }),
        reset() {
          e10.entities = null, e10.title = null, e10.typeForFrom = null, e10.pager = null, e10.loadingState = u.GuX.IDLE;
        }
      })), V = l.gK.model("CollectionShelfPage", { recentlyPlayed: B, newEpisodes: X, liked: j }).views((e10) => ({
        get isLoading() {
          return e10.recentlyPlayed.isLoading && e10.liked.isLoading;
        },
        get isRejected() {
          return e10.recentlyPlayed.isRejected && e10.liked.isRejected;
        },
        get isResolved() {
          return e10.recentlyPlayed.isResolved && e10.liked.isResolved;
        },
        get isIdle() {
          return e10.recentlyPlayed.loadingState === u.GuX.IDLE && e10.liked.loadingState === u.GuX.IDLE;
        },
        get hasRecentlyPlayed() {
          var t2;
          return e10.recentlyPlayed.isLoading || ((null == (t2 = e10.recentlyPlayed.entities) ? void 0 : t2.length) || 0) > 0;
        },
        get hasLiked() {
          var a2;
          return e10.liked.isLoading || ((null == (a2 = e10.liked.entities) ? void 0 : a2.length) || 0) > 0;
        }
      })).actions((e10) => ({
        reset() {
          e10.recentlyPlayed.reset(), e10.liked.reset();
        }
      })), U = l.gK.compose(l.gK.model("CollectionDislikesPageArtists", { items: l.gK.maybeNull(l.gK.array(I.PK)) }), S.XT).views((e10) => {
        let t2 = {
          get isLoading() {
            return e10.isNeededToLoad || e10.loadingState === u.GuX.PENDING;
          },
          get isEmpty() {
            var a2;
            return !t2.isLoading && (null == (a2 = e10.items) ? void 0 : a2.length) === 0;
          }
        };
        return t2;
      }).actions((e10) => ({
        getData: (0, l.L3)(function* () {
          let { usersResource: t2, modelActionsLogger: a2 } = (0, l._$)(e10);
          if (!(0, l._n)(e10)) return null;
          let { user: r2 } = (0, l.Zn)(e10);
          if (e10.loadingState === u.GuX.PENDING) return null;
          if (e10.loadingState = u.GuX.PENDING, r2.account.data.uid)
            try {
              let a3 = yield t2.getDislikedArtists({ userId: r2.account.data.uid });
              return e10.items = (0, l.wg)((a3 || []).map(I.dM)), e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.RESOLVE), a3;
            } catch (t3) {
              a2.error(t3), e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.REJECT);
            }
          return e10.loadingState = u.GuX.REJECT, null;
        }),
        reset() {
          e10.loadingState = u.GuX.IDLE, e10.items = null;
        }
      }));
      var q = a(14032), W = a(97719);
      let Y = l.gK.model("CollectionDislikesPageTracksItem", {
        id: l.gK.string,
        loadingState: l.gK.enumeration(Object.values(u.GuX)),
        data: l.gK.maybeNull(M.vj)
      }), z = l.gK.compose(l.gK.model("CollectionDislikesPageTracks", { items: l.gK.maybeNull(l.gK.array(Y)) }), S.XT).views((e10) => {
        let t2 = {
          get isLoading() {
            return e10.isNeededToLoad || e10.loadingState === u.GuX.PENDING;
          },
          get isEmpty() {
            var a2;
            return !t2.isLoading && (null == (a2 = e10.items) ? void 0 : a2.length) === 0;
          },
          get sonataEntitiesData() {
            var r2, i2;
            return null != (i2 = null == (r2 = e10.items) ? void 0 : r2.map((e11) => (0, W.li)(e11.id))) ? i2 : [];
          }
        };
        return t2;
      }).actions((e10) => ({
        getData: (0, l.L3)(function* () {
          let { usersResource: t2, modelActionsLogger: a2 } = (0, l._$)(e10), { user: r2 } = (0, l.Zn)(e10);
          if (r2.account.data.uid && e10.loadingState !== u.GuX.PENDING) {
            e10.loadingState = u.GuX.PENDING;
            try {
              let {
                library: { tracks: a3 }
              } = yield t2.getDislikedTracks({ userId: r2.account.data.uid }), i2 = a3.map((e11) => {
                let { id: t3, albumId: a4 } = e11;
                return { id: String((0, q.V)(t3, a4)), loadingState: u.GuX.IDLE };
              });
              e10.items = (0, l.wg)(i2), e10.loadingState = u.GuX.RESOLVE;
            } catch (t3) {
              a2.error(t3), e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.REJECT);
            }
          }
        }),
        getTracksByRange: (0, l.L3)(function* (t2, a2) {
          var r2;
          let { tracksResource: i2, modelActionsLogger: s2 } = (0, l._$)(e10);
          if (!(null == (r2 = e10.items) ? void 0 : r2.length)) return null;
          t2 = Math.max(0, t2), a2 = Math.min(a2, e10.items.length);
          let n2 = ((e11, t3, a3) => {
            let r3 = [];
            for (let n3 = t3; n3 <= a3; n3++) {
              var i3, s3;
              ((null == (i3 = e11[n3]) ? void 0 : i3.loadingState) === u.GuX.IDLE || (null == (s3 = e11[n3]) ? void 0 : s3.loadingState) === u.GuX.REJECT) && r3.push(n3);
            }
            return r3;
          })(e10.items, t2, a2);
          try {
            let t3, a3 = (t3 = e10.items, n2.map((e11) => {
              let a4 = t3[e11];
              return String(null == a4 ? void 0 : a4.id);
            }));
            if (!a3.length) return null;
            n2.forEach((t4) => {
              var a4;
              let r4 = null == (a4 = e10.items) ? void 0 : a4[t4];
              r4 && (r4.loadingState = u.GuX.PENDING);
            });
            let r3 = yield i2.getTracksMeta({ trackIds: a3, withProgress: true });
            n2.forEach((t4, a4) => {
              var i3;
              let s3 = null == r3 ? void 0 : r3[a4];
              (null == (i3 = e10.items) ? void 0 : i3[t4]) && s3 && (e10.items[t4] = { id: String(s3.id), data: (0, M.vU)(s3), loadingState: u.GuX.RESOLVE });
            });
          } catch (t3) {
            s2.error(t3), n2.forEach((t4) => {
              var a3;
              let r3 = null == (a3 = e10.items) ? void 0 : a3[t4];
              r3 && (r3.loadingState = u.GuX.REJECT);
            });
          }
          return null;
        }),
        reset() {
          e10.loadingState = u.GuX.IDLE, e10.items = null;
        }
      })), H = l.gK.model("CollectionDislikesPage", { artists: U, tracks: z }).views((e10) => ({
        get isNeededToLoad() {
          return e10.tracks.isNeededToLoad && e10.artists.isNeededToLoad;
        },
        get isLoading() {
          return e10.tracks.isLoading && e10.artists.isLoading;
        },
        get isResolved() {
          return e10.tracks.isResolved && e10.artists.isResolved;
        }
      })).actions((e10) => ({
        reset() {
          e10.artists.reset(), e10.tracks.reset();
        }
      }));
      var Q = a(4696);
      let $ = l.gK.model("CollectionKidsAlbumsPage", { pagesLoader: (0, S.Ij)(v.JC) }).views((e10) => {
        let t2 = {
          get isShimmerVisible() {
            return !e10.pagesLoader.isSomePageResolved;
          },
          get isNeededToLoad() {
            return e10.pagesLoader.isNeedToMakeInitialRequest;
          },
          get isRejected() {
            return e10.pagesLoader.isInitialRequestRejected;
          },
          get isEmpty() {
            return e10.pagesLoader.isEmpty;
          },
          get isResolved() {
            return e10.pagesLoader.isSomePageResolved;
          },
          get requestsCount() {
            return e10.pagesLoader.requestsCount;
          },
          get items() {
            var a2;
            return null != (a2 = e10.pagesLoader.items) ? a2 : [];
          },
          get shouldShowContent() {
            return t2.isShimmerVisible || t2.items.length > 0;
          },
          get loadedItems() {
            var r2, i2;
            return null != (i2 = null == (r2 = e10.pagesLoader.items) ? void 0 : r2.filter((e11) => null !== e11)) ? i2 : [];
          }
        };
        return t2;
      }).actions((e10) => ({
        getData: (0, l.L3)(function* (t2) {
          let { pageSize: a2 = Q.c, page: r2 = 0 } = t2, { landingBlocksResource: i2, modelActionsLogger: s2 } = (0, l._$)(e10);
          if (e10.pagesLoader.isPageNeedToLoad(r2))
            try {
              e10.pagesLoader.setPageState(r2, u.GuX.PENDING);
              let t3 = yield i2.getCollectionKidsAlbumsLiked({ page: r2, pageSize: a2 }), s3 = t3.items.map((e11) => (0, p.vj)(e11.data).data);
              e10.pagesLoader.setItems(s3, { page: r2, pager: t3.pager });
            } catch (t3) {
              s2.error(t3), e10.pagesLoader.setItems(null, { responseStatus: u.FlZ.ERROR, page: r2 });
            }
        }),
        reset() {
          e10.pagesLoader.reset();
        }
      })), Z = l.gK.model("CollectionKidsPlaylistsPage", { pagesLoader: (0, S.Ij)(x.IP) }).views((e10) => {
        let t2 = {
          get isShimmerVisible() {
            return !e10.pagesLoader.isSomePageResolved;
          },
          get isNeededToLoad() {
            return e10.pagesLoader.isNeedToMakeInitialRequest;
          },
          get isRejected() {
            return e10.pagesLoader.isInitialRequestRejected;
          },
          get isEmpty() {
            return e10.pagesLoader.isEmpty;
          },
          get isResolved() {
            return e10.pagesLoader.isSomePageResolved;
          },
          get requestsCount() {
            return e10.pagesLoader.requestsCount;
          },
          get items() {
            var a2;
            return null != (a2 = e10.pagesLoader.items) ? a2 : [];
          },
          get shouldShowContent() {
            return t2.isShimmerVisible || t2.items.length > 0;
          },
          get loadedItems() {
            var r2, i2;
            return null != (i2 = null == (r2 = e10.pagesLoader.items) ? void 0 : r2.filter((e11) => null !== e11)) ? i2 : [];
          }
        };
        return t2;
      }).actions((e10) => ({
        getData: (0, l.L3)(function* (t2) {
          let { pageSize: a2 = Q.c, page: r2 = 0 } = t2, { landingBlocksResource: i2, modelActionsLogger: s2 } = (0, l._$)(e10);
          if (e10.pagesLoader.isPageNeedToLoad(r2))
            try {
              e10.pagesLoader.setPageState(r2, u.GuX.PENDING);
              let t3 = yield i2.getCollectionKidsPlaylistsLiked({ page: r2, pageSize: a2 }), s3 = t3.items.map((e11) => (0, p.dF)(e11.data).data);
              e10.pagesLoader.setItems(s3, { page: r2, pager: t3.pager });
            } catch (t3) {
              s2.error(t3), e10.pagesLoader.setItems(null, { responseStatus: u.FlZ.ERROR, page: r2 });
            }
        }),
        reset() {
          e10.pagesLoader.reset();
        }
      })), J = l.gK.model("CollectionKidsTracksPage", { pagesLoader: (0, S.Ij)(M.vj) }).views((e10) => {
        let t2 = {
          get isShimmerVisible() {
            return !e10.pagesLoader.isSomePageResolved;
          },
          get isNeededToLoad() {
            return e10.pagesLoader.isNeedToMakeInitialRequest;
          },
          get isRejected() {
            return e10.pagesLoader.isInitialRequestRejected;
          },
          get isEmpty() {
            return e10.pagesLoader.isEmpty;
          },
          get isResolved() {
            return e10.pagesLoader.isSomePageResolved;
          },
          get requestsCount() {
            return e10.pagesLoader.requestsCount;
          },
          get items() {
            var a2;
            return null != (a2 = e10.pagesLoader.items) ? a2 : [];
          },
          get shouldShowContent() {
            return t2.isShimmerVisible || t2.items.length > 0;
          },
          get loadedItems() {
            var r2, i2;
            return null != (i2 = null == (r2 = e10.pagesLoader.items) ? void 0 : r2.filter((e11) => null !== e11)) ? i2 : [];
          },
          get sonataEntitiesData() {
            return t2.loadedItems.map(M.$b);
          }
        };
        return t2;
      }).actions((e10) => ({
        getData: (0, l.L3)(function* (t2) {
          let { pageSize: a2 = Q.c, page: r2 = 0 } = t2, { landingBlocksResource: i2, modelActionsLogger: s2 } = (0, l._$)(e10);
          if (e10.pagesLoader.isPageNeedToLoad(r2))
            try {
              e10.pagesLoader.setPageState(r2, u.GuX.PENDING);
              let t3 = yield i2.getCollectionKidsTracksLiked({ page: r2, pageSize: a2 }), s3 = t3.items.map(p.vI).map((e11) => e11.data);
              e10.pagesLoader.setItems(s3, { page: r2, pager: t3.pager });
            } catch (t3) {
              s2.error(t3), e10.pagesLoader.setItems(null, { responseStatus: u.FlZ.ERROR, page: r2 });
            }
        }),
        reset() {
          e10.pagesLoader.reset();
        }
      })), ee = l.gK.model("CollectionKidsPage", { albums: $, playlists: Z, tracks: J }).views((e10) => ({
        get isNeededToLoad() {
          return e10.albums.isNeededToLoad && e10.playlists.isNeededToLoad && e10.tracks.isNeededToLoad;
        },
        get isRejected() {
          return e10.albums.isRejected && e10.playlists.isRejected && e10.tracks.isRejected;
        },
        get isResolved() {
          return e10.albums.isResolved && e10.playlists.isResolved && e10.tracks.isResolved;
        },
        get shouldShowContent() {
          return e10.albums.shouldShowContent || e10.playlists.shouldShowContent || e10.tracks.shouldShowContent;
        }
      })).actions((e10) => ({
        reset() {
          e10.albums.reset(), e10.playlists.reset(), e10.tracks.reset();
        }
      })), et = l.gK.compose(
        l.gK.model("CollectionShelfLikedPage", {
          pagesLoader: (0, S.Ij)(G),
          typeForFrom: l.gK.maybeNull(l.gK.string)
        }),
        S.pl
      ).views((e10) => ({
        get isShimmerVisible() {
          return !e10.pagesLoader.isSomePageResolved;
        },
        get isNeededToLoad() {
          return e10.pagesLoader.isNeedToMakeInitialRequest;
        },
        get isRejected() {
          return e10.pagesLoader.isInitialRequestRejected;
        },
        get isEmpty() {
          return e10.pagesLoader.isEmpty;
        },
        get isResolved() {
          return e10.pagesLoader.isSomePageResolved;
        },
        get requestsCount() {
          return e10.pagesLoader.requestsCount;
        },
        get items() {
          return e10.pagesLoader.items || [];
        }
      })).actions((e10) => ({
        getData: (0, l.L3)(function* (t2) {
          let { pageSize: a2 = Q.c, page: r2 = 0 } = t2, { nonMusicResource: i2, modelActionsLogger: s2 } = (0, l._$)(e10);
          if (e10.pagesLoader.isPageNeedToLoad(r2))
            try {
              var n2, o2;
              e10.pagesLoader.setPageState(r2, u.GuX.PENDING);
              let t3 = yield i2.getShelfLiked({ page: r2, pageSize: a2 }), s3 = (null == (n2 = t3.entities) ? void 0 : n2.map(O)) || [];
              e10.pagesLoader.setItems(s3, { page: r2, pager: t3.pager }), e10.typeForFrom = null != (o2 = t3.typeForFrom) ? o2 : null;
            } catch (t3) {
              s2.error(t3), e10.pagesLoader.setItems(null, { responseStatus: u.FlZ.ERROR, page: r2 });
            }
        }),
        reset() {
          e10.pagesLoader.reset();
        }
      })), ea = l.gK.model("CollectionShelfRecentlyPlayedPage", {
        pagesLoader: (0, S.Ij)(K),
        typeForFrom: l.gK.maybeNull(l.gK.string)
      }).views((e10) => ({
        get isShimmerVisible() {
          return !e10.pagesLoader.isSomePageResolved;
        },
        get isNeededToLoad() {
          return e10.pagesLoader.isNeedToMakeInitialRequest;
        },
        get isRejected() {
          return e10.pagesLoader.isInitialRequestRejected;
        },
        get isEmpty() {
          return e10.pagesLoader.isEmpty;
        },
        get isResolved() {
          return e10.pagesLoader.isSomePageResolved;
        },
        get requestsCount() {
          return e10.pagesLoader.requestsCount;
        },
        get items() {
          return e10.pagesLoader.items || [];
        }
      })).actions((e10) => ({
        getData: (0, l.L3)(function* (t2) {
          let { pageSize: a2 = Q.c, page: r2 = 0 } = t2, { nonMusicResource: i2, modelActionsLogger: s2 } = (0, l._$)(e10);
          if (e10.pagesLoader.isPageNeedToLoad(r2))
            try {
              var n2, o2;
              e10.pagesLoader.setPageState(r2, u.GuX.PENDING);
              let t3 = yield i2.getShelfRecentlyPlayed({ page: r2, pageSize: a2 }), s3 = (null == (n2 = t3.entities) ? void 0 : n2.map(F)) || [];
              e10.pagesLoader.setItems(s3, { page: r2, pager: t3.pager }), e10.typeForFrom = null != (o2 = t3.typeForFrom) ? o2 : null;
            } catch (t3) {
              s2.error(t3), e10.pagesLoader.setItems(null, { responseStatus: u.FlZ.ERROR, page: r2 });
            }
        }),
        reset() {
          e10.pagesLoader.reset(), e10.typeForFrom = null;
        }
      })), er = l.gK.model("CollectionPage", {
        landing: p.Ju,
        albums: f,
        playlists: w,
        artists: k,
        shelf: V,
        shelfRecentlyPlayed: ea,
        shelfLiked: et,
        nonMusicLiked: A,
        dislikes: H,
        kids: ee,
        clips: D
      });
      a(38155), a(2313), a(66875), a(53793), a(90392), a(50492), a(94162), a(65696), a(72230), a(77770), a(97296), a(20139), a(19796), a(46026), a(24159), a(85872), a(25605), a(23430), a(57202);
      var ei = a(66498), es = a(34942);
      let en = {
        experiments: { loadingState: u.GuX.IDLE, experiments: {}, overwrittenExperiments: {} },
        disclaimersDictionary: { loadingState: u.GuX.IDLE, recentDisclaimersRequestTS: 0 },
        user: { account: { loadingState: u.GuX.IDLE, data: {} }, settings: { loadingState: u.GuX.IDLE } },
        wizard: { loadingState: u.GuX.IDLE, modal: {}, savedLikedArtists: [], likedArtists: [], unlikedArtists: [] },
        collection: {
          albums: { pagesLoader: {}, upcomingAlbums: { loadingState: u.GuX.IDLE } },
          playlists: {
            playlistsLiked: { pagesLoader: {} },
            playlistsCreated: { pagesLoader: {} },
            activeTabIndex: m.a.CREATED,
            tabs: [m.a.CREATED, m.a.LIKED]
          },
          artists: { pagesLoader: {}, topArtists: { loadingState: u.GuX.IDLE, items: [] } },
          landing: { loadingState: u.GuX.IDLE, tabs: { loadingState: u.GuX.IDLE } },
          shelf: {
            recentlyPlayed: { loadingState: u.GuX.IDLE },
            newEpisodes: { loadingState: u.GuX.IDLE },
            liked: { loadingState: u.GuX.IDLE }
          },
          nonMusicLiked: { loadingState: u.GuX.IDLE, items: [] },
          dislikes: { artists: { loadingState: u.GuX.IDLE }, tracks: { loadingState: u.GuX.IDLE } },
          kids: { albums: { pagesLoader: {} }, playlists: { pagesLoader: {} }, tracks: { pagesLoader: {} } },
          shelfRecentlyPlayed: { pagesLoader: {} },
          shelfLiked: { pagesLoader: {} },
          clips: { loadingState: u.GuX.IDLE, clipsWillLike: { loadingState: u.GuX.IDLE } }
        },
        main: {
          specialHeaderLoadingState: u.GuX.IDLE,
          landing: { loadingState: u.GuX.IDLE, tabs: { loadingState: u.GuX.IDLE } }
        },
        nonMusic: {
          landing: { loadingState: u.GuX.IDLE, tabs: { loadingState: u.GuX.IDLE } },
          albums: { loadingState: u.GuX.IDLE },
          categorySubpage: { loadingState: u.GuX.IDLE },
          categoryPlaylistsSubpage: { loadingState: u.GuX.IDLE, pagesLoader: {} }
        },
        kids: {
          landing: { loadingState: u.GuX.IDLE, tabs: { loadingState: u.GuX.IDLE } },
          kidsEditorialPlaylistSubpage: { loadingState: u.GuX.IDLE, pagesLoader: {} },
          kidsEditorialAlbumSubpage: { loadingState: u.GuX.IDLE, pagesLoader: {} }
        },
        settings: {
          layout: null,
          isLandscape: false,
          isMobileLandscapeHeight: false,
          browserInfo: {
            name: void 0,
            version: void 0,
            OSFamily: void 0,
            isMobile: false,
            isTablet: false,
            isTouch: false,
            isBrowser: false,
            inAppBrowser: false,
            hasHuaweiAppGallery: false
          },
          selectedThumbId: u.TZj.DEFAULT
        },
        currentClipInfo: {
          clipLoadingState: u.GuX.IDLE,
          creditsLoadingState: u.GuX.IDLE,
          id: null,
          clip: null,
          credits: null,
          modal: {}
        },
        currentTrackInfo: {
          trackLoadingState: u.GuX.IDLE,
          creditsLoadingState: u.GuX.IDLE,
          descriptionLoadingState: u.GuX.IDLE,
          id: null,
          albumId: null,
          isUGC: null,
          fullTrack: null,
          credits: null,
          modal: {}
        },
        trackLyrics: {
          loadingState: u.GuX.IDLE,
          lyrics: null,
          lyricId: null,
          externalLyricId: null,
          track: null,
          modal: {}
        },
        album: {
          loadingState: u.GuX.IDLE,
          items: [],
          meta: null,
          otherAlbumVersions: [],
          allTracksUnfinished: false,
          donations: { loadingState: u.GuX.IDLE, items: [] },
          latestGenreAlbums: { loadingState: u.GuX.IDLE, items: [] },
          otherArtistAlbums: { loadingState: u.GuX.IDLE, items: [] },
          relatedContent: { loadingState: u.GuX.IDLE, items: [] },
          similarEntities: {
            id: "similar-entities",
            type: g.t.COLLECTION_SIMILAR_ENTITIES,
            loadingState: p.SQ.IDLE,
            isNotFound: false,
            hasSentAnalyticsOnLoaded: false,
            meta: {}
          }
        },
        promolanding: {
          loadingState: u.GuX.IDLE,
          items: [],
          meta: null,
          allTracksUnfinished: false,
          promoCampaign: { loadingState: u.GuX.IDLE, isActive: false },
          state: {
            contextId: null,
            contextType: null,
            entityMeta: null,
            status: y.MT.IDLE,
            canMoveBackward: false,
            canMoveForward: false,
            canSpeed: false,
            canChangeRepeatMode: true,
            repeatMode: h.pM.NONE,
            quality: c.e.BALANCED,
            canShuffle: true,
            shuffle: false
          },
          similarEntities: {
            id: "similar-entities",
            type: g.t.COLLECTION_SIMILAR_ENTITIES,
            loadingState: p.SQ.IDLE,
            isNotFound: false,
            hasSentAnalyticsOnLoaded: false,
            meta: {}
          }
        },
        albumCPA: {},
        artist: {
          loadingState: u.GuX.IDLE,
          meta: null,
          landing: { loadingState: u.GuX.IDLE, tabs: { loadingState: u.GuX.IDLE } },
          popularTracks: [],
          similarArtists: [],
          albums: [],
          discography: [],
          compilations: [],
          playlists: [],
          clips: [],
          fullTracksListSubpage: { loadingState: u.GuX.IDLE },
          albumsSubpage: { pagesLoader: {} },
          concertsSubpage: { loadingState: u.GuX.IDLE },
          similarArtistsSubPage: { loadingState: u.GuX.IDLE },
          familiarInfo: { loadingState: u.GuX.IDLE },
          familiarSubpage: { loadingState: u.GuX.IDLE },
          clipsSubpage: { pagesLoader: {} },
          commonSubPage: {},
          offlineArtist: {
            loadingState: u.GuX.IDLE,
            trackIds: { loadingState: u.GuX.IDLE },
            downloadedTracks: { loadingState: u.GuX.IDLE }
          },
          infoLoadingState: { loadingState: u.GuX.IDLE }
        },
        library: { loadingState: u.GuX.IDLE, tracks: {}, artists: {}, playlists: {}, albums: {}, clips: {} },
        sonataState: {
          contextId: null,
          contextType: null,
          entityMeta: null,
          status: y.MT.IDLE,
          canMoveBackward: false,
          canMoveForward: false,
          canSpeed: false,
          canChangeRepeatMode: true,
          repeatMode: h.pM.NONE,
          quality: c.e.BALANCED,
          canShuffle: true,
          shuffle: false,
          areCoresRegistered: false,
          isVHCoreRegistered: false,
          isCrossFadeEnabled: true
        },
        playlist: {
          loadingState: u.GuX.IDLE,
          meta: null,
          items: [],
          initialItems: [],
          similarPlaylists: [],
          filters: { loadingState: u.GuX.IDLE, shouldSendEventOnTabOpened: true, shouldSendEventOnTabLoaded: true },
          editorFeature: {
            shouldShowDuplicate: false,
            shouldShowGenre: false,
            shouldShowMajor: false,
            colorMajorMap: {},
            duplicate: {}
          },
          search: { loadingState: u.GuX.IDLE, text: "" },
          similarEntities: {
            id: "similar-entities",
            type: g.t.COLLECTION_SIMILAR_ENTITIES,
            loadingState: p.SQ.IDLE,
            isNotFound: false,
            hasSentAnalyticsOnLoaded: false,
            meta: {}
          }
        },
        slides: {
          userSlidesLoadingState: u.GuX.IDLE,
          artistSlidesLoadingState: u.GuX.IDLE,
          podcastSlidesLoadingState: u.GuX.IDLE,
          specialSlidesLoadingState: u.GuX.IDLE,
          kidsSlidesLoadingState: u.GuX.IDLE,
          userItems: [],
          artistItems: [],
          podcastItems: [],
          specialItems: [],
          kidsItems: [],
          isMuted: false
        },
        vibe: { loadingState: u.GuX.IDLE, vibeResetLoadingState: u.GuX.IDLE, isApplying: false },
        search: {
          searchCorrectedText: null,
          loadingState: u.GuX.IDLE,
          results: [],
          historyPage: { loadingState: u.GuX.IDLE, items: [] },
          mixes: { loadingState: u.GuX.IDLE, items: [] },
          landing: { loadingState: u.GuX.IDLE, tabs: { loadingState: u.GuX.IDLE } },
          history: { loadingState: u.GuX.IDLE }
        },
        vibeSettings: { loadingState: u.GuX.IDLE },
        pinsCollection: { loadingState: u.GuX.IDLE, index: {} },
        genre: {
          loadingState: u.GuX.IDLE,
          albumsSubpage: { pagesLoader: {} },
          artistsSubpage: { loadingState: u.GuX.IDLE, pagesLoader: {} },
          playlistsSubpage: { pagesLoader: {} }
        },
        genres: { title: null, loadingState: u.GuX.IDLE, items: [] },
        mixes: { loadingState: u.GuX.IDLE, items: [] },
        tag: { tagLoadingState: u.GuX.IDLE, playlistsData: [], pagesLoader: {} },
        chart: {
          tracksSubPage: { loadingState: u.GuX.IDLE, items: [] },
          podcastsSubPage: { loadingState: u.GuX.IDLE, items: [] }
        },
        post: { loadingState: u.GuX.IDLE },
        landingBlockEntities: { loadingState: u.GuX.IDLE },
        contextMenuPlaylists: { pagesLoader: {} },
        musicHistory: { loadingState: u.GuX.IDLE, tabs: null },
        createPlaylist: {},
        location: {},
        disclaimerModalState: { loadingState: u.GuX.IDLE },
        myMusic: { downloadedTracks: { loadingState: u.GuX.IDLE } },
        trailer: {
          loadingState: u.GuX.IDLE,
          withAnimation: true,
          shouldAutoStartPlaying: true,
          shouldSendEventOnTracksShowed: true,
          modal: {},
          sonataStatusBeforeTrailerStart: y.MT.IDLE,
          isManuallyPaused: true,
          state: { contextId: null, contextType: null, entityMeta: null, status: y.MT.IDLE }
        },
        communication: { loadingState: u.GuX.IDLE },
        modals: {
          disclaimerModal: {},
          shortcutsModal: {},
          aboutAppModal: {},
          overviewModal: {},
          ugcTrackEditModal: { modal: {} },
          popoverOverPlayer: {},
          crackdownModal: {},
          overwrittenExperimentsModal: {},
          buySubscriptionModal: { isOpened: true },
          promoLandingBuySubscriptionModal: {},
          clearMemoryModal: {},
          imageSliderModal: { modal: {} },
          artistAboutModal: { loadingState: u.GuX.IDLE, modal: {} },
          bestRecommedationModal: {}
        },
        landing: { loadingState: u.GuX.IDLE, tabs: { loadingState: u.GuX.IDLE } },
        fullscreenPlayer: { modal: {}, syncLyrics: { loadingState: u.GuX.IDLE }, playQueue: {} },
        fullscreenVideoPlayer: {
          modal: {},
          ids: [],
          loadingState: u.GuX.IDLE,
          sonataStatusBeforeClipStart: y.MT.IDLE,
          withAnimation: true,
          state: {
            contextId: null,
            contextType: null,
            entityMeta: null,
            status: y.MT.IDLE,
            canMoveBackward: false,
            canMoveForward: false
          }
        },
        advert: { data: null, isAdvertPlaying: true, isAdvertShown: false, isAdvertPlaybackCreated: false },
        ugcUploadCenter: { checkProcessingTracksAttempts: 0, notifications: {} },
        paymentWidgetModal: {
          modal: {},
          target: "",
          serviceSessionId: "",
          tariffOfferName: "",
          offersBatchId: "",
          offersPositionIds: "",
          isSilent: false,
          status: es.cF.IDLE
        },
        offers: { music: { loadingState: u.GuX.IDLE } },
        quality: { modal: {} },
        releaseNotes: { modal: {} },
        slam: { networkStatus: {} },
        favoriteTracks: { loadingState: u.GuX.IDLE },
        track: { loadingState: u.GuX.IDLE, withAnimation: true, shouldSendEventOnPlusButtonShowed: true },
        familyInvite: {
          info: { loadingState: u.GuX.IDLE },
          acceptanceLoadingState: u.GuX.IDLE,
          modal: {},
          step: ei._n.INFO
        },
        continueListen: {},
        playlistPersonal: { loadingState: u.GuX.IDLE },
        redAlert: { loadingState: u.GuX.IDLE },
        shareIframe: { modal: {} },
        paywall: { modal: {} },
        downloadMobileApp: { modal: {} },
        advertBanners: {
          banners: {
            topAdvertBanner: { type: u.h8o.EMPTY, noAds: false, hasError: false, isShowBanner: true },
            sideAdvertBanner: { type: u.h8o.EMPTY, noAds: false, hasError: false, isShowBanner: true },
            brandedPlaylistBanner: { type: u.h8o.EMPTY, noAds: false, hasError: false, isShowBanner: true },
            brandedPlayerBanner: { type: u.h8o.EMPTY, noAds: false, hasError: false, isShowBanner: true, modal: {} },
            brandedEntityAxeBanner: { type: u.h8o.EMPTY, noAds: false, hasError: false, isShowBanner: true }
          }
        },
        label: {
          loadingState: u.GuX.IDLE,
          albumsSubpage: { pagesLoader: {}, sort: {} },
          artistsSubpage: { pagesLoader: {} }
        },
        desktopPaywall: {},
        concerts: {
          loadingState: u.GuX.IDLE,
          config: { loadingState: u.GuX.IDLE },
          landing: { loadingState: u.GuX.IDLE, tabs: { loadingState: u.GuX.IDLE } }
        },
        concertsDetails: { loadingState: u.GuX.IDLE },
        concert: {
          loadingState: u.GuX.IDLE,
          landing: { loadingState: u.GuX.IDLE, tabs: { loadingState: u.GuX.IDLE } }
        }
      };
      var el = a(36748), eo = a(50211), ed = a(57390), eu = a(11189), ec = a(48249), eh = a(14741), eg = a(14287);
      let ey = l.gK.compose(
        l.gK.model("FavoriteTracksPage", {
          playlistUuid: l.gK.maybeNull(l.gK.string),
          errorStatusCode: l.gK.maybeNull(l.gK.number)
        }),
        S.XT
      ).views((e10) => ({
        get playlistUrl() {
          if (!e10.playlistUuid) return "";
          let { href: t2 } = (0, u.uvd)("/playlists/:playlistUuid", { params: { playlistUuid: e10.playlistUuid } });
          return t2;
        }
      })).actions((e10) => ({
        getPlaylistUrl: (0, l.L3)(function* () {
          let { landingResource: t2, modelActionsLogger: a2 } = (0, l._$)(e10);
          if (e10.loadingState !== u.GuX.PENDING)
            try {
              e10.loadingState = u.GuX.PENDING, e10.playlistUuid = (yield t2.getBlock({
                source: { uri: "/landing/block/collection/playlist-with-likes", countWeb: 8 },
                type: g.t.COLLECTION_PLAYLIST_WITH_LIKES
              })).playlist.playlistUuid, e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.RESOLVE);
            } catch (t3) {
              a2.error(t3), t3 instanceof eg.GX && (t3.statusCode === eg.X1.NOT_FOUND || t3.statusCode === eg.X1.BAD_REQUEST) && (e10.errorStatusCode = eg.X1.NOT_FOUND), e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.REJECT);
            }
        }),
        reset() {
          e10.loadingState = u.GuX.IDLE, e10.playlistUuid = null;
        }
      }));
      a(99893);
      var em = a(91022), ep = a(69961), ev = a(13127), eP = a(14726);
      let eS = l.gK.model("SpecialHeaderThemeOptions", {
        backgroundColor: l.gK.maybe(l.gK.string),
        textColor: l.gK.maybe(l.gK.string)
      }), eE = l.gK.model("SpecialHeader", { title: l.gK.string, url: l.gK.string, lightTheme: eS, darkTheme: eS }), ef = l.gK.model("MainPage", {
        landing: p.Ju,
        specialHeaderLoadingState: l.gK.enumeration(Object.values(u.GuX)),
        specialHeader: l.gK.maybe(eE)
      }).actions((e10) => ({
        getSpecialHeader: (0, l.L3)(function* () {
          let { landingResource: t2, modelActionsLogger: a2 } = (0, l._$)(e10);
          if (e10.specialHeaderLoadingState !== u.GuX.PENDING)
            try {
              e10.specialHeaderLoadingState = u.GuX.PENDING;
              let a3 = yield t2.getSpecialHeader();
              e10.specialHeader = (0, l.wg)(
                ((e11) => {
                  var t3, a4, r2, i2, s2, n2;
                  if ((null == (t3 = e11.button) ? void 0 : t3.title) && (null == (a4 = e11.button.action) ? void 0 : a4.weblink))
                    return {
                      title: e11.button.title,
                      url: e11.button.action.weblink,
                      lightTheme: {
                        backgroundColor: null == (r2 = e11.lightTheme) ? void 0 : r2.buttonColor,
                        textColor: null == (i2 = e11.lightTheme) ? void 0 : i2.buttonTitleColor
                      },
                      darkTheme: {
                        backgroundColor: null == (s2 = e11.darkTheme) ? void 0 : s2.buttonColor,
                        textColor: null == (n2 = e11.darkTheme) ? void 0 : n2.buttonTitleColor
                      }
                    };
                })(a3)
              ), e10.specialHeaderLoadingState = u.GuX.RESOLVE;
            } catch (t3) {
              a2.error(t3), e10.specialHeaderLoadingState = u.GuX.REJECT;
            }
        }),
        reset() {
          e10.specialHeaderLoadingState = u.GuX.IDLE, e10.specialHeader = void 0;
        }
      }));
      a(94540);
      var eb = a(26303), eI = a(72645), e_ = a(76866);
      let ek = l.gK.compose(
        l.gK.model("MusicHistoryPage", {
          indexesMap: l.gK.map(l.gK.number),
          items: l.gK.maybeNull(l.gK.array(eI.UN)),
          datesMap: l.gK.map(l.gK.boolean),
          tabs: l.gK.maybeNull(l.gK.array(eI.WW))
        }),
        S.XT
      ).views((e10) => {
        let t2 = {
          get isEmpty() {
            var a2;
            return (e10.isResolved || e10.isRejected) && (null == (a2 = e10.tabs) ? void 0 : a2.length) === 0;
          },
          get isShimmerVisible() {
            return e10.isNeededToLoad || e10.isLoading || e10.isRejected;
          },
          get isShimmerActive() {
            return e10.isLoading;
          },
          getStartAndEndIndexes(t3) {
            var a2, r2;
            let i2 = t3, s2 = t3 + 1;
            return (null == (a2 = e10.items) ? void 0 : a2.slice(t3 - 25 + 1, t3).some((e11) => !e11.isResolved)) && (i2 = t3 - 25 + 1), (null == (r2 = e10.items) ? void 0 : r2.slice(t3, t3 + 25).some((e11) => !e11.isResolved)) && (s2 = t3 + 25), [i2, s2];
          },
          getItemsToLoad(a2) {
            var r2, i2;
            let [s2, n2] = t2.getStartAndEndIndexes(a2);
            return null != (i2 = null == (r2 = e10.items) ? void 0 : r2.slice(s2, n2).filter((e11) => !e11.isResolved)) ? i2 : [];
          },
          isInObservationRange(t3) {
            var a2;
            return 0 !== t3 && t3 % 25 == 0 || e10.items && t3 === (null == (a2 = e10.items) ? void 0 : a2.length) - 1;
          },
          get dates() {
            var r2, i2;
            return null != (i2 = null == (r2 = e10.tabs) ? void 0 : r2.map((e11) => e11.date)) ? i2 : [];
          }
        };
        return t2;
      }).actions((e10) => {
        let t2 = {
          fillItemsAndIndexes() {
            var t3;
            let a2 = 0;
            e10.items = (0, l.wg)([]), null == (t3 = e10.tabs) || t3.forEach((t4, r2) => {
              var i2;
              e10.datesMap.set(t4.date, false), null == (i2 = t4.blocks) || i2.forEach((t5, i3) => {
                var s2;
                let n2 = t5.id;
                e10.indexesMap.set("".concat(r2, "_").concat(i3, "_").concat(n2), a2), null == (s2 = e10.items) || s2.push({
                  id: n2,
                  type: t5.type,
                  tabIndex: r2,
                  blockIndex: i3,
                  trackIndex: null,
                  loadingState: a2 < 25 ? u.GuX.RESOLVE : u.GuX.IDLE
                }), ++a2, t5.tracks.forEach((t6, s3) => {
                  var n3;
                  e10.indexesMap.set("".concat(r2, "_").concat(i3, "_").concat(s3, "_").concat(t6.id), a2), null == (n3 = e10.items) || n3.push({
                    id: t6.id,
                    type: t6.type,
                    tabIndex: r2,
                    blockIndex: i3,
                    trackIndex: s3,
                    loadingState: a2 < 25 ? u.GuX.RESOLVE : u.GuX.IDLE
                  }), ++a2;
                });
              });
            });
          },
          setTrack(t3, a2) {
            var r2, i2, s2, n2;
            let { tabIndex: l2, blockIndex: o2, trackIndex: d2 } = t3, { fullModel: c2 } = a2.data;
            if (null === d2) return;
            let h2 = null == (n2 = e10.tabs) || null == (s2 = n2[l2]) || null == (i2 = s2.blocks) || null == (r2 = i2[o2]) ? void 0 : r2.tracks[d2];
            h2 && (h2.data = (0, M.vU)(c2), h2.loadingState = u.GuX.RESOLVE);
          },
          setAlbum(t3, a2) {
            var r2, i2, s2;
            let { tabIndex: n2, blockIndex: l2 } = t3, { fullModel: o2 } = a2.data, d2 = null == (s2 = e10.tabs) || null == (i2 = s2[n2]) || null == (r2 = i2.blocks) ? void 0 : r2[l2];
            (0, eI.z)(d2) && (d2.meta = (0, v.sK)({ album: o2.album, artists: o2.artists }), d2.loadingState = u.GuX.RESOLVE);
          },
          setArtist(t3, a2) {
            var r2, i2, s2;
            let { tabIndex: n2, blockIndex: l2 } = t3, { fullModel: o2 } = a2.data, d2 = null == (s2 = e10.tabs) || null == (i2 = s2[n2]) || null == (r2 = i2.blocks) ? void 0 : r2[l2];
            (0, eI.bg)(d2) && (d2.meta = (0, I.as)({ artist: o2.artist }), d2.loadingState = u.GuX.RESOLVE);
          },
          setPlaylist(t3, a2) {
            var r2, i2, s2;
            let { tabIndex: n2, blockIndex: l2 } = t3, { fullModel: o2 } = a2.data, d2 = null == (s2 = e10.tabs) || null == (i2 = s2[n2]) || null == (r2 = i2.blocks) ? void 0 : r2[l2];
            (0, eI.kU)(d2) && (d2.meta = { ...(0, x.bk)({ playlist: o2.playlist }), tracksCount: o2.tracksCount }, d2.loadingState = u.GuX.RESOLVE);
          },
          setVibe(t3, a2) {
            var r2, i2, s2;
            let { tabIndex: n2, blockIndex: l2 } = t3, { fullModel: o2 } = a2.data, d2 = null == (s2 = e10.tabs) || null == (i2 = s2[n2]) || null == (r2 = i2.blocks) ? void 0 : r2[l2];
            (0, eI.sr)(d2) && (d2.meta = {
              ...(0, e_.er)(o2.wave),
              imageUrl: o2.simpleWaveForegroundImageUrl,
              backgroundColor: o2.simpleWaveBackgroundColor
            }, d2.loadingState = u.GuX.RESOLVE);
          },
          getMusicHistory: (0, l.L3)(function* () {
            let { musicHistoryResource: a2, modelActionsLogger: r2 } = (0, l._$)(e10);
            if (e10.loadingState !== u.GuX.PENDING)
              try {
                e10.loadingState = u.GuX.PENDING;
                let r3 = yield a2.getMusicHistory({ fullModelsCount: 25 }), i2 = ((e11) => {
                  let t3 = { historyTabs: [] }, a3 = 0;
                  for (let s2 of e11.historyTabs) {
                    var r4, i3;
                    if (a3 > 1e3) break;
                    let e12 = { ...s2, items: [] };
                    for (let t4 of null != (r4 = s2.items) ? r4 : []) {
                      if (a3 > 1e3) break;
                      let r5 = { ...t4, tracks: [] };
                      for (let e13 of t4.tracks) {
                        if (a3 > 1e3) break;
                        r5.tracks.push(e13), ++a3;
                      }
                      null == (i3 = e12.items) || i3.push(r5);
                    }
                    e12.items && e12.items.length > 0 && t3.historyTabs.push(e12);
                  }
                  return t3;
                })(r3);
                e10.tabs = (0, l.wg)(i2.historyTabs.map(eI.Sv)), t2.fillItemsAndIndexes(), e10.loadingState = u.GuX.RESOLVE;
              } catch (t3) {
                r2.error(t3), e10.loadingState = u.GuX.REJECT;
              }
          }),
          getItems: (0, l.L3)(function* (a2) {
            let { musicHistoryResource: r2, modelActionsLogger: i2 } = (0, l._$)(e10);
            try {
              let i3 = e10.getItemsToLoad(a2);
              i3.forEach((e11) => {
                e11.loadingState = u.GuX.RESOLVE;
              });
              let s2 = yield r2.getMusicHistoryItems({
                items: i3.map((e11) => {
                  switch (e11.type) {
                    case eb.D.ARTIST:
                    case eb.D.ALBUM:
                      return { type: e11.type, data: { itemId: { id: e11.id } } };
                    case eb.D.PLAYLIST: {
                      let [t3, a3] = e11.id.split(":");
                      return { type: e11.type, data: { itemId: { uid: Number(t3), kind: Number(a3) } } };
                    }
                    case eb.D.WAVE:
                      return { type: e11.type, data: { itemId: { seeds: e11.id.split(",") } } };
                    case eb.D.TRACK: {
                      let [t3, a3] = e11.id.split(":");
                      return { type: e11.type, data: { itemId: { trackId: String(t3), albumId: a3 } } };
                    }
                    default:
                      return null;
                  }
                }).filter((e11) => e11)
              }), n2 = i3.reduce((e11, t3) => {
                let a3 = "".concat(t3.type, "_").concat(t3.id);
                if (a3 in e11) {
                  var r3;
                  null == (r3 = e11[a3]) || r3.push(t3);
                } else e11[a3] = [t3];
                return e11;
              }, {});
              s2.items.forEach((e11) => {
                var a3;
                null == (a3 = n2[((e12) => {
                  switch (e12.type) {
                    case eb.D.ALBUM:
                      return "".concat(e12.type, "_").concat((0, eI.tM)(e12));
                    case eb.D.TRACK:
                      return "".concat(e12.type, "_").concat((0, eI.QF)(e12));
                    case eb.D.WAVE:
                      return "".concat(e12.type, "_").concat((0, eI.u)(e12));
                    case eb.D.PLAYLIST:
                      return "".concat(e12.type, "_").concat((0, eI.uZ)(e12));
                    case eb.D.ARTIST:
                      return "".concat(e12.type, "_").concat((0, eI.Hp)(e12));
                  }
                })(e11)]) || a3.forEach((a4) => {
                  switch (e11.type) {
                    case eb.D.ALBUM:
                      t2.setAlbum(a4, e11);
                      break;
                    case eb.D.TRACK:
                      t2.setTrack(a4, e11);
                      break;
                    case eb.D.WAVE:
                      t2.setVibe(a4, e11);
                      break;
                    case eb.D.PLAYLIST:
                      t2.setPlaylist(a4, e11);
                      break;
                    case eb.D.ARTIST:
                      t2.setArtist(a4, e11);
                  }
                  a4.loadingState = u.GuX.RESOLVE;
                });
              });
            } catch (e11) {
              i2.error(e11);
            }
          }),
          setDatesMap(t3, a2) {
            e10.datesMap.set(t3, a2);
          },
          reset() {
            e10.items = null, e10.tabs = null, e10.indexesMap.clear(), e10.datesMap.clear(), e10.loadingState = u.GuX.IDLE;
          }
        };
        return t2;
      });
      a(42421), a(92521);
      var eC = a(89511);
      let eT = l.gK.model("MyMusicPage", { downloadedTracks: eC.b });
      a(9567);
      var eD = a(77870), eA = a(62481), ex = a(39507), eL = a(48625), eR = a(34291), eN = a(81531), ew = a(42320), eM = a(76421);
      let eO = [eM.n.ARTIST, eM.n.ALBUM, eM.n.TRACK, eM.n.PLAYLIST, eM.n.WAVE, eM.n.PODCAST, eM.n.PODCAST_EPISODE], eF = [
        eM.n.ALBUM,
        eM.n.ARTIST,
        eM.n.PLAYLIST,
        eM.n.TRACK,
        eM.n.UGC_TRACK,
        eM.n.WAVE,
        eM.n.PODCAST,
        eM.n.PODCAST_EPISODE,
        eM.n.CLIP,
        eM.n.CONCERT
      ], eG = (e10) => {
        let { wave: t2 } = e10;
        return (0, l.wg)({
          title: t2.title,
          description: t2.subTitle,
          seeds: ["".concat(t2.id.type, ":").concat(t2.id.tag)],
          backgroundColor: t2.color,
          imageUrl: t2.image,
          agent: (0, e_.KU)(t2.agent)
        });
      }, eK = (e10) => {
        let { type: t2 } = e10;
        switch (t2) {
          case eM.n.UGC_TRACK:
            return { type: t2, data: (0, M.or)(e10.track) };
          case eM.n.TRACK:
            return { type: t2, data: (0, M.vU)(e10.track) };
          case eM.n.ARTIST:
            return { type: t2, data: (0, I.dM)(e10.artist) };
          case eM.n.PLAYLIST:
            return { type: t2, data: (0, x.Ew)({ ...e10.playlist, artists: [] }) };
          case eM.n.ALBUM:
            return { type: t2, data: (0, v.pp)(e10.album) };
          case eM.n.WAVE:
            return { type: t2, data: eG(e10) };
          case eM.n.PODCAST:
            return { type: t2, data: (0, v.pp)(e10.podcast) };
          case eM.n.PODCAST_EPISODE:
            return { type: t2, data: (0, M.vU)(e10.podcast_episode) };
          default:
            return null;
        }
      };
      var ej = a(51427), eX = a(985), eB = a(77217);
      let eV = l.gK.compose(l.gK.model("SearchHistoryPage", { items: l.gK.array(ew.jU) }), S.pl, S.XT).actions((e10) => ({
        reset() {
          e10.destroyItems([e10.items]);
        }
      })), eU = l.gK.model("SearchHistory", {
        loadingState: l.gK.enumeration(Object.values(u.GuX)),
        shouldUpdateHistory: l.gK.optional(l.gK.boolean, false)
      }).views((e10) => ({
        get hasCleared() {
          return e10.loadingState === u.GuX.RESOLVE;
        }
      })).actions((e10) => ({
        setShouldUpdateHistory(t2) {
          e10.shouldUpdateHistory = t2;
        },
        clear: (0, l.L3)(function* () {
          if (!(0, l._n)(e10)) return;
          let { user: t2 } = (0, l.Zn)(e10), { usersResource: a2, modelActionsLogger: r2 } = (0, l._$)(e10);
          if (e10.loadingState !== u.GuX.PENDING && t2.account.data.uid)
            try {
              e10.loadingState = u.GuX.PENDING, yield a2.clearSearchHistory({ userId: t2.account.data.uid }), e10.loadingState = u.GuX.RESOLVE;
            } catch (t3) {
              r2.error(t3), e10.loadingState = u.GuX.REJECT;
            }
        }),
        reset() {
          e10.loadingState = u.GuX.IDLE;
        }
      })), eq = l.gK.compose(
        l.gK.model("SearchPage", {
          searchCorrectedText: l.gK.maybeNull(l.gK.string),
          searchRequestId: l.gK.optional(l.gK.string, ""),
          results: l.gK.array(ew.jU),
          bestResults: l.gK.array(ew.xo),
          historyPage: eV,
          mixes: eN.YM,
          landing: p.Ju,
          history: eU,
          filters: l.gK.maybeNull(l.gK.array(ew.k1))
        }),
        S.pl,
        S.XT
      ).views((e10) => ({
        get isHistoryShimmerVisible() {
          return e10.historyPage.isLoading || e10.historyPage.isRejected;
        },
        get isHistoryLoading() {
          return e10.historyPage.isLoading;
        },
        get isHistoryReady() {
          return e10.historyPage.isNeededToLoad;
        },
        get isEmptyHistory() {
          return !e10.historyPage.items.length && e10.historyPage.isResolved;
        },
        get isShimmerVisible() {
          return e10.isLoading || e10.isRejected;
        },
        get isEmpty() {
          return !e10.isLoading && 0 === e10.results.length && 0 === e10.bestResults.length;
        }
      })).actions((e10) => ({
        getSearchResults: (0, l.L3)(function* (t2) {
          let { text: a2, filter: r2 } = t2, { searchResource: i2 } = (0, l._$)(e10), {
            settings: { isMobile: s2 },
            experiments: n2
          } = (0, l.Zn)(e10), o2 = n2.checkExperiment(u.zal.WebNextSearchConcerts, "on");
          try {
            e10.loadingState = u.GuX.PENDING;
            let t3 = yield i2.getInstantMixedSearch({
              text: a2,
              type: ((e11, t4) => {
                let { withClips: a3, withConcerts: r3 } = t4, i3 = [...eF];
                return e11 === eR.$.TOP && (i3 = i3.filter((e12) => e12 !== eM.n.UGC_TRACK)), a3 || (i3 = i3.filter((e12) => e12 !== eM.n.CLIP)), r3 || (i3 = i3.filter((e12) => e12 !== eM.n.CONCERT)), i3;
              })(r2, { withClips: !s2, withConcerts: o2 }),
              filter: r2 === eR.$.TOP ? void 0 : r2,
              withLikesCount: true,
              page: 0,
              pageSize: 36,
              withBestResults: r2 === eR.$.TOP
            });
            t3.misspellResult && (e10.searchCorrectedText = t3.misspellResult), t3.results && t3.results.length > 0 && (e10.results = (0, l.wg)(
              t3.results.map((e11) => {
                switch (e11.type) {
                  case eM.n.ALBUM:
                    return { type: eM.n.ALBUM, data: (0, v.pp)(e11.album) };
                  case eM.n.ARTIST:
                    return { type: eM.n.ARTIST, data: (0, I.dM)(e11.artist) };
                  case eM.n.PLAYLIST:
                    return { type: eM.n.PLAYLIST, data: (0, x.Ew)({ ...e11.playlist, artists: [] }) };
                  case eM.n.UGC_TRACK:
                    return { type: eM.n.UGC_TRACK, data: (0, M.or)(e11.track) };
                  case eM.n.TRACK:
                    return { type: eM.n.TRACK, data: (0, M.vU)(e11.track) };
                  case eM.n.WAVE:
                    return { type: eM.n.WAVE, data: eG(e11) };
                  case eM.n.PODCAST:
                    return { type: eM.n.PODCAST, data: (0, v.pp)(e11.podcast) };
                  case eM.n.CLIP:
                    return { type: eM.n.CLIP, data: (0, C.i$)(e11.clip) };
                  case eM.n.PODCAST_EPISODE:
                    return { type: eM.n.PODCAST_EPISODE, data: (0, M.vU)(e11.podcast_episode) };
                  case eM.n.CONCERT:
                    return { type: eM.n.CONCERT, data: (0, eB.ho)(e11.concert.concert, e11.concert.minPrice) };
                }
              }).filter((e11) => e11)
            ), e10.searchRequestId = t3.searchRequestId), t3.bestResults && t3.bestResults.length > 0 && (e10.bestResults = (0, l.wg)(
              t3.bestResults.map((e11) => {
                switch (e11.type) {
                  case ej.r.ALBUM:
                    return {
                      type: ej.r.ALBUM,
                      data: (0, v.sK)({
                        album: e11.best_result_album.album,
                        artists: e11.best_result_album.artists,
                        trailer: e11.best_result_album.trailer
                      })
                    };
                  case ej.r.PLAYLIST:
                    return {
                      type: ej.r.PLAYLIST,
                      data: (0, x.bk)({
                        playlist: e11.best_result_playlist.playlist,
                        likesCount: e11.best_result_playlist.likesCount,
                        tracksCount: e11.best_result_playlist.trackCount,
                        trailer: e11.best_result_playlist.trailer
                      })
                    };
                  case ej.r.RECENT_RELEASE:
                    return {
                      type: ej.r.RECENT_RELEASE,
                      data: (0, v.sK)({
                        album: e11.best_result_recent_release.album,
                        artists: e11.best_result_recent_release.artists,
                        trailer: e11.best_result_recent_release.trailer
                      })
                    };
                  case ej.r.WAVE:
                    return { type: ej.r.WAVE, data: (0, e_.er)(e11.best_result_wave) };
                  case ej.r.ARTIST:
                    return {
                      type: ej.r.ARTIST,
                      data: (0, I.as)({
                        artist: e11.best_result_artist.artist,
                        trailer: e11.best_result_artist.trailer,
                        likesCount: e11.best_result_artist.likesCount
                      })
                    };
                  case ej.r.UPCOMING:
                    return { type: ej.r.UPCOMING, data: (0, v.lO)(e11.best_result_upcoming) };
                  case ej.r.CONCERT:
                    return { type: ej.r.CONCERT, data: (0, eB.oP)(e11.best_result_concert) };
                  case ej.r.PODCAST:
                    return {
                      type: ej.r.PODCAST,
                      data: (0, v.sK)({
                        album: e11.best_result_podcast.album,
                        likesCount: e11.best_result_podcast.likesCount
                      })
                    };
                  case ej.r.PODCAST_EPISODE:
                    return { type: ej.r.PODCAST_EPISODE, data: (0, M.vU)(e11.best_result_podcast_episode) };
                  case ej.r.OVERVIEW:
                    return { type: ej.r.OVERVIEW, data: (0, eX.tm)(e11.best_result_overview) };
                  case ej.r.NON_MUSIC:
                    return {
                      type: ej.r.NON_MUSIC,
                      data: (0, v.sK)({
                        album: e11.best_result_non_music.album,
                        artists: e11.best_result_non_music.artists,
                        releaseYear: e11.best_result_non_music.releaseYear
                      })
                    };
                  case ej.r.TRACK:
                    return { type: ej.r.TRACK, data: (0, M.vU)(e11.best_result_track) };
                  case ej.r.CLIP:
                    return { type: ej.r.CLIP, data: (0, C.i$)(e11.best_result_clip) };
                  case ej.r.BOOK_CHAPTER:
                    return { type: ej.r.BOOK_CHAPTER, data: (0, M.vU)(e11.best_result_book_chapter) };
                }
              }).filter((e11) => e11)
            )), t3.filters && t3.filters.length > 0 && (e10.filters = (0, l.wg)(t3.filters)), e10.loadingState = u.GuX.RESOLVE;
          } catch (t3) {
            e10.loadingState = u.GuX.REJECT;
          }
        }),
        getHistory: (0, l.L3)(function* (t2) {
          let { userId: a2 } = t2;
          if (e10.historyPage.loadingState === u.GuX.PENDING) return;
          let { usersResource: r2, modelActionsLogger: i2 } = (0, l._$)(e10);
          try {
            e10.historyPage.loadingState = u.GuX.PENDING;
            let t3 = yield r2.getSearchHistory({ userId: a2, supportedTypes: eO });
            e10.historyPage.items = (0, l.wg)(t3.map(eK).filter((e11) => e11)), e10.historyPage.loadingState = u.GuX.RESOLVE;
          } catch (t3) {
            i2.error(t3), e10.historyPage.loadingState = u.GuX.REJECT;
          }
        }),
        clearHistory: (0, l.L3)(function* (t2) {
          let { userId: a2 } = t2, { usersResource: r2, modelActionsLogger: i2 } = (0, l._$)(e10);
          if (e10.loadingState !== u.GuX.PENDING)
            try {
              e10.loadingState = u.GuX.PENDING, yield r2.clearSearchHistory({ userId: a2 }), e10.loadingState = u.GuX.RESOLVE;
            } catch (t3) {
              i2.error(t3), e10.loadingState = u.GuX.REJECT;
            }
        }),
        resetHistoryItems() {
          e10.historyPage.reset();
        },
        resetHistoryStateRequest() {
          e10.historyPage.loadingState = u.GuX.IDLE, e10.historyPage.reset();
        },
        resetResults() {
          e10.destroyItems([e10.results, e10.bestResults]);
        },
        resetSearchCorrectedText() {
          e10.searchCorrectedText = null;
        },
        reset() {
          e10.searchCorrectedText = null, e10.loadingState = u.GuX.IDLE, e10.filters = null, e10.destroyItems([e10.results, e10.bestResults]);
        },
        sendFeedback: (0, l.L3)(function* (t2) {
          let { searchResource: a2, modelActionsLogger: r2 } = (0, l._$)(e10);
          try {
            yield a2.sendFeedback(t2);
          } catch (e11) {
            r2.error(e11);
          }
        })
      }));
      a(35183), a(43874), a(90777), a(10838);
      var eW = a(9089), eY = a(79952), ez = a(51376), eH = a(19020);
      let eQ = l.gK.model("AdvertBanners", {
        banners: l.gK.model({
          topAdvertBanner: S.Hp,
          sideAdvertBanner: S.vE,
          brandedPlaylistBanner: ez.Ab,
          brandedPlayerBanner: eH.v,
          brandedEntityAxeBanner: ez.vK
        })
      }).views((e10) => {
        let t2 = {
          get values() {
            return [
              e10.banners.topAdvertBanner,
              e10.banners.sideAdvertBanner,
              e10.banners.brandedPlaylistBanner,
              e10.banners.brandedEntityAxeBanner
            ];
          },
          get hasBranding() {
            return t2.values.some((e11) => e11.type === u.h8o.BRANDING);
          },
          isVisible(a2) {
            let { experiments: r2 } = (0, l.Zn)(e10);
            if (r2.checkExperiment(u.zal.WebNextDisableAds, "on")) return false;
            if (a2 === u.h8o.EMPTY) return true;
            let i2 = t2.values.filter((e11) => e11.type !== u.h8o.EMPTY);
            return a2 === u.h8o.DIRECT ? i2.every((e11) => e11.type === u.h8o.DIRECT) : a2 !== u.h8o.CREATIVE || i2.every((e11) => e11.type !== u.h8o.BRANDING);
          }
        };
        return t2;
      });
      var e$ = a(67250);
      !(function(e10) {
        e10.BAR_BELOW = "barBellow", e10.FULLSCREEN = "fullscreen";
      })(r || (r = {}));
      var eZ = a(88294), eJ = a(91803);
      let e0 = l.gK.model("CommunicationList", { barBelow: eZ.t5, modal: eJ.k8 }), e1 = l.gK.model("Communication", {
        loadingState: l.gK.enumeration(Object.values(u.GuX)),
        list: l.gK.maybe(e0),
        errorStatusCode: l.gK.maybeNull(l.gK.number)
      }).views((e10) => ({
        get withTriggersV2() {
          let { experiments: t2 } = (0, l.Zn)(e10);
          return t2.checkExperiment(u.zal.WebNextTriggersV2, "on");
        }
      })).actions((e10) => {
        let t2 = {
          getData: (0, l.L3)(function* () {
            let { dynamicPagesResource: a2, modelActionsLogger: i2 } = (0, l._$)(e10);
            if (e10.loadingState !== u.GuX.PENDING && e10.loadingState !== u.GuX.RESOLVE)
              try {
                var s2;
                let i3;
                if ((e10.loadingState = u.GuX.PENDING, (s2 = i3 = e10.withTriggersV2 ? yield a2.getTriggersV2({ anchorIds: Object.values(e$.v) }) : yield a2.getTriggers({ anchorIds: Object.values(e$.v) })) && s2.triggers && Array.isArray(s2.triggers) && s2.triggers.every(
                  (e11) => !!(e11 && "object" == typeof e11 && "anchorId" in e11 && "triggers" in e11 && Array.isArray(e11.triggers) && e11.triggers.every(
                    (e12) => !!(e12 && "object" == typeof e12 && "screenId" in e12 && "feedbackToken" in e12 && "data" in e12 && "meta" in e12)
                  ))
                )) ? e10.list = ((e11) => {
                  let t3 = [], a3 = [];
                  return e11.triggers.forEach((e12) => {
                    var i4;
                    switch (null == (i4 = e12.triggers[0]) ? void 0 : i4.meta.notificationId) {
                      case r.BAR_BELOW:
                        return void e12.triggers.forEach((e13) => {
                          t3.push((0, eZ.S3)(e13));
                        });
                      case r.FULLSCREEN:
                        return void e12.triggers.forEach((e13) => {
                          a3.push((0, eJ.fZ)(e13));
                        });
                    }
                  }), (0, l.wg)({ barBelow: { list: t3 }, modal: { list: a3 } });
                })(i3) : i3 && i3.triggers && Array.isArray(i3.triggers) && i3.triggers.every(
                  (e11) => !!(e11 && "object" == typeof e11 && "anchorId" in e11 && "screenId" in e11 && "div" in e11 && "meta" in e11 && !("triggers" in e11))
                ) && (e10.list = ((e11) => {
                  let t3 = [], a3 = [];
                  return e11.triggers.forEach((e12) => {
                    switch (e12.meta.notificationId) {
                      case r.BAR_BELOW:
                        t3.push((0, eZ.S3)(e12));
                        return;
                      case r.FULLSCREEN:
                        a3.push((0, eJ.fZ)(e12));
                        return;
                    }
                  }), (0, l.wg)({ barBelow: { list: t3 }, modal: { list: a3 } });
                })(i3)), e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.RESOLVE), !e10.list)
                  return;
                let { barBelow: n2, modal: o2 } = e10.list;
                n2.setAnchorId(e$.v.ON_START_BAR_BELOW), n2.barBelowItem && (n2.show(), t2.shown(n2.barBelowItem.anchorId, n2.barBelowItem.screenId, n2.barBelowItem.feedbackToken)), o2.setAnchorId(e$.v.ON_START_FULLSCREEN), o2.modalItem && (o2.open(), t2.shown(o2.modalItem.anchorId, o2.modalItem.screenId, o2.modalItem.feedbackToken));
              } catch (t3) {
                i2.error(t3), t3 instanceof eg.GX && (t3.statusCode === eg.X1.NOT_FOUND || t3.statusCode === eg.X1.BAD_REQUEST) && (e10.errorStatusCode = eg.X1.NOT_FOUND), e10.loadingState !== u.GuX.IDLE && (e10.loadingState = u.GuX.REJECT);
              }
          }),
          shown: (0, l.L3)(function* (t3, a2, r2) {
            let { dynamicPagesResource: i2, modelActionsLogger: s2 } = (0, l._$)(e10);
            try {
              e10.withTriggersV2 && r2 ? yield i2.shownV2({ anchorIds: [t3], feedbackToken: r2 }) : yield i2.shown({ anchorIds: [t3], screenId: a2 });
            } catch (e11) {
              s2.error(e11);
            }
          }),
          action: (0, l.L3)(function* (t3, a2, r2, i2) {
            let { dynamicPagesResource: s2, modelActionsLogger: n2 } = (0, l._$)(e10);
            try {
              e10.withTriggersV2 && i2 ? yield s2.actionV2({ anchorIds: [t3], actionId: r2, feedbackToken: i2 }) : yield s2.action({ anchorIds: [t3], screenId: a2, actionId: r2 });
            } catch (e11) {
              n2.error(e11);
            }
          })
        };
        return t2;
      });
      var e3 = a(33208), e2 = a(54278), e4 = a(21514);
      let e6 = l.gK.model("ModalsModel", {
        disclaimerModal: S.qt,
        shortcutsModal: S.qt,
        aboutAppModal: S.qt,
        overviewModal: S.qt,
        ugcTrackEditModal: M.n_,
        popoverOverPlayer: S.qt,
        crackdownModal: S.qt,
        overwrittenExperimentsModal: S.qt,
        buySubscriptionModal: S.qt,
        clearMemoryModal: S.qt,
        imageSliderModal: e4.J,
        promoLandingBuySubscriptionModal: S.qt,
        artistAboutModal: b.Xj,
        bestRecommedationModal: S.qt
      });
      var e5 = a(49324), e8 = a(13193), e9 = a(32061), e7 = a(95373), te = a(54722), tt = a(13403), ta = a(98845), tr = a(68317), ti = a(7186), ts = a(12460);
      let tn = l.gK.model("Network", { isOffline: l.gK.optional(l.gK.boolean, false) }), tl = l.gK.model("Entity", {
        progress: l.gK.maybe(l.gK.number),
        loadingState: l.gK.enumeration(Object.values(ts.DT))
      }), to = l.gK.model("Slam", { networkStatus: tn, offlineMode: l.gK.optional(l.gK.boolean, false), tracks: l.gK.map(tl) }).views((e10) => {
        let t2 = {
          isTrackDownloaded: (t3) => {
            var a2;
            return (null == (a2 = e10.tracks.get(t3)) ? void 0 : a2.loadingState) === ts.DT.DOWNLOADED;
          },
          isTrackDownloading: (t3) => {
            var a2;
            return (null == (a2 = e10.tracks.get(t3)) ? void 0 : a2.loadingState) === ts.DT.DOWNLOADING;
          },
          getTrackDownloadingProgress: (t3) => {
            var a2, r2;
            return null != (r2 = null == (a2 = e10.tracks.get(t3)) ? void 0 : a2.progress) ? r2 : 0;
          },
          isPlaylistDownloaded: (e11) => e11.every((e12) => {
            let [a2] = (0, q.d)(e12);
            return !!a2 && t2.isTrackDownloaded(a2);
          }),
          isPlaylistDownloading: (e11) => e11.some((e12) => {
            let [a2] = (0, q.d)(e12);
            return !!a2 && t2.isTrackDownloading(a2);
          }),
          getPlaylistDownloadingProgress: (e11) => Math.floor(
            e11.reduce((e12, a2) => {
              let [r2] = (0, q.d)(a2);
              return r2 && t2.isTrackDownloaded(r2) ? e12 + 1 : e12;
            }, 0) / e11.length * 100
          ),
          get isOfflineModeEnabled() {
            if (!(0, l._n)(e10)) return false;
            return e10.offlineMode;
          }
        };
        return t2;
      }).actions((e10) => ({
        setNetworkStatus: (t2) => {
          e10.networkStatus = t2;
        },
        setTrack: (t2, a2) => {
          e10.tracks.set(t2, a2);
        },
        setTracks: (t2) => {
          e10.tracks = (0, l.wg)(t2);
        },
        setOfflineMode: (t2) => {
          let { localStorage: a2 } = (0, l._$)(e10);
          e10.offlineMode = t2, a2.set(u.cYZ.OfflineMode, t2);
        }
      }));
      var td = a(94968), tu = a(86947), tc = a(63930);
      !(function(e10) {
        e10.PROCESSING = "processing", e10.PLAYABLE = "playable";
      })(i || (i = {}));
      var th = a(54460), tg = a(77009);
      let ty = l.gK.model("UgcUploadCenterNotificationsPairModel", {
        playlist: L.$o,
        type: l.gK.enumeration(Object.values(tg.u))
      }), tm = l.gK.model("UgcUploadCenterNotificationsModel", { pairs: l.gK.array(ty) }).views((e10) => ({
        isNotificationExists: (t2, a2) => e10.pairs.some((e11) => e11.playlist.kind === t2 && e11.type === a2)
      })).actions((e10) => {
        let t2 = {
          addNotification(t3, a2) {
            e10.pairs.push({ playlist: (0, tc.HO)(t3), type: a2 });
          },
          addNonexistentNotification(a2, r2) {
            e10.isNotificationExists(a2.kind, r2) || t2.addNotification(a2, r2);
          },
          showAllNotifications() {
            let t3 = (0, tc.HO)(e10.pairs);
            return e10.pairs = (0, l.wg)([]), t3;
          }
        };
        return t2;
      }), tp = l.gK.model("UgcUploadCenterTrackPlaylistPair", { playlist: L.$o, file: th.vz }), tv = l.gK.model("UgcUploadCenterModel", {
        tracks: l.gK.array(tp),
        notifications: tm,
        checkProcessingTracksAttempts: l.gK.number
      }).views((e10) => ({
        getUploadingTracksByPlaylistKind: (t2) => t2 ? e10.tracks.filter((e11) => e11.playlist.kind === t2).map((e11) => e11.file) : [],
        getTracksByLoadingState: (t2) => e10.tracks.filter((e11) => e11.file.loadingState === t2).map((e11) => e11.file),
        get idleTracks() {
          return this.getTracksByLoadingState(th.pK.IDLE);
        },
        get preparingTracks() {
          return this.getTracksByLoadingState(th.pK.PREPARE);
        },
        get uploadingTracks() {
          return this.getTracksByLoadingState(th.pK.UPLOADING);
        },
        get processingTracks() {
          return this.getTracksByLoadingState(th.pK.PROCESSING);
        },
        get hasTracksInUploadingState() {
          return this.preparingTracks.length + this.uploadingTracks.length > 0;
        },
        get shouldCheckProcessingTracks() {
          return e10.checkProcessingTracksAttempts < 25 && this.processingTracks.length > 0;
        },
        getPlaylistByKind(t2) {
          var a2;
          return null == (a2 = e10.tracks.find((e11) => e11.playlist.kind === t2)) ? void 0 : a2.playlist;
        }
      })).actions((e10) => {
        let t2 = {
          appendFiles(t3, a2) {
            if (t3.forEach((t4) => {
              if (t4.size > 419430400)
                return void e10.notifications.addNonexistentNotification(a2, tg.u.FILE_TOO_LARGE);
              let r3 = th.vz.create({ loadingState: th.pK.IDLE, playlistKind: a2.kind });
              r3.setFile(t4);
              let i2 = tp.create({ file: r3, playlist: (0, tc.HO)(a2) });
              e10.tracks.unshift(i2);
            }), !(0, l._n)(e10))
              return;
            let { playlist: r2 } = (0, l.Zn)(e10);
            r2.search.setText(""), r2.search.reset(), this.runUploadTracksQueue();
          },
          async runUploadTracksQueue() {
            let a2 = e10.idleTracks;
            if (a2.length && !e10.hasTracksInUploadingState) {
              let r2 = a2[a2.length - 1];
              r2 && (await r2.runUpload(), r2.loadingState === th.pK.REJECT && r2.errorReason === th.oQ.TOO_MANY_FILES && (e10.tracks = (0, l.wg)([]), t2.addNotificationForPlaylistKind(r2.playlistKind, tg.u.TOO_MANY_FILES)), t2.checkNotifications()), t2.setCheckProcessingTracksAttempts(0), t2.runUploadTracksQueue();
            }
          },
          checkProcessingTracks: (0, l.L3)(function* () {
            let { tracksResource: a2, modelActionsLogger: r2 } = (0, l._$)(e10), s2 = [];
            if (e10.checkProcessingTracksAttempts >= 25) return null;
            t2.setCheckProcessingTracksAttempts(e10.checkProcessingTracksAttempts + 1);
            try {
              let t3 = e10.processingTracks.map((e11) => e11.trackId).filter((e11) => !!e11);
              if (!t3.length) return null;
              let r3 = yield a2.getTracksMeta({ trackIds: t3, withProgress: true });
              null == r3 || r3.forEach((t4) => {
                let a3 = e10.tracks.find((e11) => e11.file.trackId === t4.id && t4.state === i.PLAYABLE);
                a3 && (a3.file.loadingState = th.pK.RESOLVE, a3.file.trackId && s2.push(a3.file.trackId));
              });
            } catch (e11) {
              r2.error(e11);
            }
            return t2.checkNotifications(s2), t2.moveTracksFromUploadCenterToPlaylist(), null;
          }),
          moveTracksFromUploadCenterToPlaylist() {
            var t3;
            if (!(0, l._n)(e10)) return;
            let { playlist: a2 } = (0, l.Zn)(e10);
            (null == (t3 = a2.meta) ? void 0 : t3.kind) && e10.tracks.find((e11) => {
              var t4;
              return e11.file.loadingState === th.pK.RESOLVE && e11.playlist.kind === (null == (t4 = a2.meta) ? void 0 : t4.kind);
            }) && a2.refreshTracks(), e10.tracks = (0, l.wg)(e10.tracks.filter((e11) => e11.file.loadingState !== th.pK.RESOLVE));
          },
          setCheckProcessingTracksAttempts(t3) {
            e10.checkProcessingTracksAttempts = t3;
          },
          clearCancelledUploads() {
            e10.tracks = (0, l.wg)(e10.tracks.filter((e11) => e11.file.loadingState !== th.pK.CANCELLED));
          },
          checkNotifications(a2) {
            let r2 = /* @__PURE__ */ new Set();
            e10.tracks.forEach((e11) => r2.add(e11.playlist.kind)), r2.forEach((r3) => {
              let i2 = e10.getUploadingTracksByPlaylistKind(r3);
              if (!(!i2.length || i2.some((e11) => e11.loadingState !== th.pK.RESOLVE && e11.loadingState !== th.pK.REJECT)))
                if (i2.some((e11) => e11.loadingState === th.pK.REJECT)) {
                  let s2 = true;
                  if (a2 && a2.length) {
                    let t3 = i2.map((e11) => e11.trackId).filter((e11) => e11), r4 = (0, td.A)(t3, a2, tu.A);
                    r4.length && (s2 = r4.map((t4) => e10.tracks.find((e11) => e11.file.trackId === t4)).some((e11) => (null == e11 ? void 0 : e11.file.loadingState) === th.pK.REJECT));
                  }
                  s2 && t2.addNotificationForPlaylistKind(r3, tg.u.UNKNOWN_ERROR);
                } else t2.addNotificationForPlaylistKind(r3, tg.u.SUCCESS);
            });
          },
          addNotificationForPlaylistKind(t3, a2) {
            let r2 = e10.getPlaylistByKind(t3);
            r2 && e10.notifications.addNonexistentNotification(r2, a2);
          }
        };
        return t2;
      });
      a(85827);
      var tP = a(16020);
      let tS = l.gK.model("DesktopPaywallModel").volatile(() => ({ crackdownTimeoutId: null })).views((e10) => {
        let t2 = {
          get isPaywallOpen() {
            let { paywall: t3 } = (0, l.Zn)(e10);
            return t3.modal.isOpened;
          },
          get intervalMsOnEnter() {
            var a2;
            let { experiments: t3 } = (0, l.Zn)(e10), r2 = null == (a2 = t3.getExperiment(u.zal.WebNextDesktopPaywallInterval)) ? void 0 : a2.value.interval;
            if (Number.isNaN(r2)) return 2592e5;
            return r2;
          },
          get intervalMsCrackdown() {
            var r2;
            let { experiments: t3 } = (0, l.Zn)(e10), a2 = null == (r2 = t3.getExperiment(u.zal.WebNextPaywallCrackdownInterval)) ? void 0 : r2.value.interval;
            if (Number.isNaN(a2)) return 9e5;
            return a2;
          },
          get shouldShowOnEnter() {
            var i2, s2;
            let { settings: a2 } = (0, l.Zn)(e10);
            if (null == (i2 = a2.browserInfo) ? void 0 : i2.isMobile) return false;
            let { localStorage: r2 } = (0, l._$)(e10), n2 = null == (s2 = r2.get(u.cYZ.DesktopPaywall)) ? void 0 : s2.lastOnLoadShowDate;
            if (void 0 === n2) return true;
            return new Date(n2).getTime() < Date.now() - t2.intervalMsOnEnter;
          },
          get isReadyToShowCrackdown() {
            if (this.isPaywallOpen) return false;
            let {
              paymentWidgetModal: t3,
              modals: { crackdownModal: a2 }
            } = (0, l.Zn)(e10);
            if (t3.modal.isOpened || a2.isOpened) return false;
            return true;
          }
        };
        return t2;
      }).actions((e10) => ({
        showPaywall() {
          let { paywall: t2, settings: a2 } = (0, l.Zn)(e10), { localStorage: r2 } = (0, l._$)(e10);
          a2.isMobile;
        },
        clearCrackdownTimeout() {
          null !== e10.crackdownTimeoutId && (clearTimeout(e10.crackdownTimeoutId), e10.crackdownTimeoutId = null);
        },
        startCrackdownTimeout() {
          let { paywall: t2, settings: a2, experiments: r2 } = (0, l.Zn)(e10);
          a2.isMobile;
        }
      })), tE = l.gK.model({ text: l.gK.string, buttonText: l.gK.string, href: l.gK.string }), tf = l.gK.compose(l.gK.model("RedAlert", { data: l.gK.maybeNull(tE) }), S.XT).views((e10) => ({
        get isVisible() {
          let { settings: t2 } = (0, l.Zn)(e10);
          return t2.layout !== u.u40.Mobile && !!e10.data;
        },
        get text() {
          if (null === e10.data) throw Error("Missing data");
          return e10.data.text;
        },
        get buttonText() {
          if (null === e10.data) throw Error("Missing data");
          return e10.data.buttonText;
        },
        get href() {
          if (null === e10.data) throw Error("Missing data");
          return e10.data.href;
        }
      })).actions((e10) => ({
        getData: (0, l.L3)(function* () {
          if (e10.loadingState === u.GuX.PENDING) return;
          let { user: t2 } = (0, l.Zn)(e10), { redAlertResource: a2, modelActionsLogger: r2 } = (0, l._$)(e10);
          if (!t2.isAuthorized) {
            e10.loadingState = u.GuX.IDLE;
            return;
          }
          e10.loadingState = u.GuX.PENDING;
          try {
            let t3 = yield a2.getRedAlerts({ service: "music", client: "music-web", platform: "web" });
            e10.data = ((e11) => {
              let t4 = e11.alerts.find((e12) => {
                let { id: t5 } = e12;
                return "music-grace" === t5;
              });
              return void 0 === t4 ? null : (0, l.wg)({
                text: t4.texts["bar-text"],
                buttonText: t4.texts["bar-button-text"],
                href: t4.clickUrl
              });
            })(t3), e10.loadingState = u.GuX.RESOLVE;
          } catch (t3) {
            r2.error(t3), e10.loadingState = u.GuX.REJECT;
          }
        })
      }));
      var tb = a(92830), tI = a(49320);
      let t_ = l.gK.model("Root", {
        experiments: S.YL,
        user: tI.Fv,
        wizard: ta.H,
        collection: er,
        disclaimersDictionary: S.CA,
        main: ef,
        settings: S.dA,
        currentClipInfo: C.$d,
        currentTrackInfo: M.UU,
        album: el.MH,
        promolanding: el.Wh,
        artist: eo.E,
        library: S.br,
        sonataState: W.bG,
        playlist: eA.Pn,
        albumCPA: el.dx,
        slides: tb.M1,
        vibe: te.D7,
        search: eq,
        vibeSettings: tP.LL,
        pinsCollection: e5._1,
        genre: em.G8,
        genres: ep.Zt,
        mixes: eN.YM,
        myMusic: eT,
        tag: eW.vV,
        chart: ed.vB,
        post: eL.VQ,
        landingBlockEntities: p.hn,
        contextMenuPlaylists: R,
        musicHistory: ek,
        createPlaylist: L.Co,
        location: S.FN,
        nonMusic: eD.rN,
        disclaimerModalState: S.xE,
        communication: e1,
        trailer: e7.v,
        modals: e6,
        landing: p.Ju,
        fullscreenPlayer: e9.uZ,
        fullscreenVideoPlayer: tt.bg,
        releaseNotes: tr._o,
        trackLyrics: M.DP,
        ugcUploadCenter: tv,
        paymentWidgetModal: es.bo,
        offers: S.Fr,
        quality: e9.OK,
        kids: ev.GY,
        slam: to,
        favoriteTracks: ey,
        advert: e9.kn,
        track: eY.qQ,
        continueListen: e3.mK,
        playlistPersonal: ex.Hj,
        familyInvite: ei.J4,
        redAlert: tf,
        shareIframe: ti.D,
        paywall: e8.Sz,
        downloadMobileApp: e2.A,
        advertBanners: eQ,
        label: eP.X,
        desktopPaywall: tS,
        concerts: ec.cw,
        concertsDetails: eh._,
        concert: eu.Bd
      }), tk = (e10, t2) => t_.create(e10, t2);
      var tC = a(98388);
      let tT = [
        "settings",
        "sonataState",
        "offers",
        "modals",
        "shareIframe",
        "paywall",
        "downloadMobileApp",
        "disclaimerModalState",
        "fullscreenPlayer",
        "fullscreenVideoPlayer",
        "advertBanners",
        "redAlert",
        "communication",
        "desktopPaywall"
      ];
      (0, n.eO)(false);
      let tD = (e10) => {
        let { nonce: t2, snapshotsRef: a2 } = e10;
        (0, d.useContext)(o.ServerInsertedHTMLContext);
      }, tA = (e10) => {
        let { children: t2, nonce: a2 } = e10, r2 = (0, d.useRef)([]), i2 = (0, u.Yx9)(), [n2] = (0, d.useState)(() => {
          var e11;
          return (null == (e11 = window.__STATE_SNAPSHOT__) ? void 0 : e11.length) ? tk(window.__STATE_SNAPSHOT__[window.__STATE_SNAPSHOT__.length - 1], i2) : tk(en, i2);
        });
        return (0, d.useLayoutEffect)(() => {
          function e11() {
            var e12;
            let t3 = null == (e12 = window.__STATE_SNAPSHOT__) ? void 0 : e12[window.__STATE_SNAPSHOT__.length - 1];
            t3 && (0, l.Nh)(
              n2,
              tT.reduce((e13, t4) => (e13[t4] = n2[t4], e13), (0, tC.A)(t3))
            ), delete window.__STATE_SNAPSHOT__;
          }
          return e11(), window.addEventListener("yMusicStateSnapshotUpdated", e11), () => window.removeEventListener("yMusicStateSnapshotUpdated", e11);
        }, [n2]), (0, s.jsxs)(s.Fragment, {
          children: [
            (0, s.jsx)(tD, { nonce: a2, snapshotsRef: r2 }),
            (0, s.jsx)(u.PdQ.Provider, { value: n2, children: t2 })
          ]
        });
      };
    },
    56440: (e, t, a) => {
      "use strict";
      a.d(t, { TagPage: () => v });
      var r = a(54486), i = a(50420), s = a(28303), n = a(97396), l = a(61910), o = a(43426), d = a(97800), u = a(82644), c = a(33276), h = a(83909), g = a(74125), y = a(80585), m = a(25522), p = a.n(m);
      let v = (0, s.PA)((e2) => {
        var t2, a2, s2;
        let { tagId: m2 } = e2, {
          tag: v2,
          settings: { isMobile: P }
        } = (0, g.Pjs)(), { formatMessage: S } = (0, o.A)(), { contentScrollRef: E, setContentScrollRef: f } = (0, g.gKY)(), b = (0, g.W6M)();
        m2 || (0, n.notFound)();
        let I = (0, l.useCallback)(
          (e3) => {
            v2.getPlaylists({ page: e3, pageSize: 20 });
          },
          [v2]
        );
        v2.isNotFound && (0, n.notFound)(), (0, l.useEffect)(
          () => () => {
            v2.reset();
          },
          [v2]
        );
        let _ = (0, l.useMemo)(
          () => ({ Footer: () => (0, r.jsx)(y.A, { children: (0, r.jsx)(y.wi, { className: p().footer }) }) }),
          []
        );
        return ((0, g.Jzs)(v2.isResolved), (0, g.XcE)(v2.pagesLoader, I), v2.isNeededToLoad && (0, l.use)(v2.getTag({ id: m2, page: 0, pageSize: 20 })), v2.isSomethingWrong) ? (0, r.jsx)(u.w, {}) : (0, r.jsx)(g.nVz, {
          pageId: g._Q$.TAG,
          children: (0, r.jsx)(c.hO, {
            scrollElement: E,
            outerTitle: v2.title,
            children: (0, r.jsxs)("div", {
              className: p().root,
              children: [
                (0, r.jsx)(y.Y9, {
                  variant: y.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: b.canBack,
                  children: (0, r.jsx)(d.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: v2.title
                  })
                }),
                (0, r.jsx)(y.$$, {
                  className: (0, i.$)(p().scrollContainer, p().important),
                  customComponents: _,
                  itemContentCallback: (e3) => {
                    let t3 = v2.playlists[e3], a3 = S(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: S({ id: "entity-names.playlist" }) }
                    );
                    return t3 ? (0, r.jsx)(h.B6, { playlist: t3, contentLinesCount: 3 }, t3.key) : (0, r.jsx)(y.Vt, { "aria-label": a3 });
                  },
                  totalCount: null != (a2 = null == v2 || null == (t2 = v2.pagesLoader.pager) ? void 0 : t2.total) ? a2 : 0,
                  onGetDataByPage: I,
                  pageSize: 20,
                  totalRequests: null != (s2 = null == v2 ? void 0 : v2.pagesLoader.requestsCount) ? s2 : 0,
                  listClassName: p().content,
                  itemClassName: p().item,
                  handleRef: f,
                  context: { listAriaLabel: S({ id: "mixes.albums-list" }, { genreName: v2.title || "" }) },
                  isMobileLayout: P,
                  useWindowScroll: P
                })
              ]
            })
          })
        });
      });
    },
    57390: (e, t, a) => {
      "use strict";
      a.d(t, { vB: () => h, t6: () => g.ChartPodcastsPage });
      var r = a(74125), i = a(93064), s = a(14287), n = a(94376), l = a(26433);
      let o = i.gK.compose(
        i.gK.model("ChartPodcastsPage", {
          title: i.gK.maybeNull(i.gK.string),
          items: i.gK.array(n.JC),
          errorStatusCode: i.gK.maybeNull(i.gK.number)
        }),
        l.pl,
        l.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === r.GuX.PENDING;
          },
          get isNotFound() {
            var a2;
            let t3 = e2.isResolved && !(null == (a2 = e2.items) ? void 0 : a2.length), i2 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST;
            return e2.loadingState === r.GuX.REJECT && i2 || t3;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          }
        };
        return t2;
      }).actions((e2) => ({
        getData: (0, i.L3)(function* (t2) {
          let { chartResource: a2, modelActionsLogger: l2 } = (0, i._$)(e2);
          if (e2.loadingState !== r.GuX.PENDING)
            try {
              let s2;
              e2.loadingState = r.GuX.PENDING, e2.title = (s2 = t2 ? yield a2.getChartPodcastsCategory({ categoryId: t2 }) : yield a2.getChartPodcasts()).title, s2.chartPositions && (e2.items = (0, i.wg)(s2.chartPositions.map((e3) => (0, n.bl)(e3.album, e3.chartPosition)))), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.RESOLVE);
            } catch (t3) {
              l2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.REJECT);
            }
        }),
        reset() {
          e2.loadingState = r.GuX.IDLE, e2.title = null, e2.errorStatusCode = null, e2.destroyItems([e2.items]);
        }
      }));
      var d = a(21365);
      let u = i.gK.model("ChartPagePlaylistModel", { uuid: i.gK.string, uid: i.gK.number, kind: i.gK.number }), c = i.gK.compose(
        i.gK.model("ChartTracksPage", {
          title: i.gK.maybeNull(i.gK.string),
          playlistMeta: i.gK.maybeNull(u),
          items: i.gK.array(d.vj)
        }),
        l.XT
      ).views((e2) => ({
        get isLoading() {
          return e2.isNeededToLoad || e2.loadingState === r.GuX.PENDING;
        }
      })).actions((e2) => ({
        getTracks: (0, i.L3)(function* () {
          let { landing3Resource: t2, modelActionsLogger: a2 } = (0, i._$)(e2);
          if (e2.loadingState !== r.GuX.PENDING)
            try {
              e2.loadingState = r.GuX.PENDING;
              let a3 = yield t2.getChart();
              e2.title = a3.chart.title, e2.playlistMeta = (0, i.wg)({ uuid: a3.chart.playlistUuid, uid: a3.chart.uid, kind: a3.chart.kind }), e2.items = (0, i.wg)(a3.chart.tracks.map((e3) => (0, d.bV)(e3.track, e3.chart))), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.RESOLVE);
            } catch (t3) {
              a2.error(t3), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.REJECT);
            }
        })
      })), h = i.gK.model("ChartPageModel", { tracksSubPage: c, podcastsSubPage: o });
      a(78208);
      var g = a(71108);
      a(51760);
    },
    58055: (e, t, a) => {
      "use strict";
      a.d(t, { DeeplinkInitializer: () => d });
      var r = a(28303), i = a(97396), s = a(61910), n = a(62443), l = a(74125);
      let o = [l.K3F.DEEPLINK, l.K3F.SEEDS, l.K3F.STATION_ID, l.K3F.OPEN_PLAYER, l.K3F.SCREEN], d = (0, r.PA)(
        () => ((() => {
          let { fullscreenPlayer: e2, sonataState: t2, user: a2, location: r2 } = (0, l.Pjs)(), d2 = (0, i.useSearchParams)(), u = (0, l.XJ9)(), c = d2.get(l.K3F.SEEDS), h = d2.get(l.K3F.STATION_ID), { isFreemium: g } = (0, l.XCI)(), { state: y, toggleTrue: m } = (0, n.e)(false), p = (0, s.useMemo)(() => {
            let e3 = c ? c.split(",") : [];
            return h && e3.unshift(h), e3;
          }, [c, h]), { togglePlay: v } = (0, l.B0S)({ seeds: p, pageIdForFrom: l._Q$.RADIO, blockIdForFrom: p.join("_") });
          (0, s.useEffect)(() => {
            if (y) {
              let e3 = new URL(window.location.href);
              o.forEach((t3) => e3.searchParams.delete(t3)), u(e3.toString()), r2.setHref(window.location.href);
            }
          }, [r2, u, y, r2.href]), (0, s.useEffect)(() => {
            if (d2.get(l.K3F.DEEPLINK) === l.vEM.PLAY_VIBE) {
              if (!a2.isAuthorized || g) return void m();
              t2.setShouldApplyYnisonState(false), v(), "true" === d2.get(l.K3F.OPEN_PLAYER) && e2.modal.open(), m();
            }
            return () => {
              t2.setShouldApplyYnisonState(true);
            };
          }, [e2.modal, g, d2, m, t2, v, a2.isAuthorized]);
        })(), null)
      );
    },
    58699: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { BuySubscriptionParamsInitializer: () => n });
      var r = a(61910), i = a(74125);
      let s = { TARGET: "target", COMMUNICATION_ID: "communication_id", CAMPAIGN_ID: "campaign_id" }, n = () => {
        let e2 = (0, i.NFA)(), t2 = (0, i.XJ9)();
        return (0, r.useLayoutEffect)(() => {
          let a2 = e2.get(i.vHc), r2 = (0, i.qne)(s.TARGET), n2 = (0, i.qne)(s.COMMUNICATION_ID), l = (0, i.qne)(s.CAMPAIGN_ID);
          if (!(r2 || n2 || l)) return;
          a2.set(i.cYZ.BuySubscriptionParams, { target: r2, communicationId: n2, campaignId: l });
          let o = (0, i.jrm)();
          if (null === o) return;
          o.delete(s.TARGET), o.delete(s.COMMUNICATION_ID), o.delete(s.CAMPAIGN_ID);
          let d = new URL(window.location.href);
          d.search = o.toString(), t2(d.toString());
        }, [e2, t2]), null;
      };
    },
    60463: (e, t, a) => {
      "use strict";
      a.d(t, { l: () => i });
      var r = a(5693);
      function i(e2) {
        return (null == e2 ? void 0 : e2.data.type) === r.R.SmartPreview;
      }
    },
    61336: (e) => {
      e.exports = {
        root: "MyMusicDownloadedTracksPageEmpty_root__LAXpY",
        icon: "MyMusicDownloadedTracksPageEmpty_icon__PDhk2",
        title: "MyMusicDownloadedTracksPageEmpty_title__g2w5R",
        text: "MyMusicDownloadedTracksPageEmpty_text__8RJFg"
      };
    },
    61777: (e, t, a) => {
      "use strict";
      a.d(t, { FamilyInviteInitializer: () => l });
      var r = a(28303), i = a(61910), s = a(66498), n = a(74125);
      let l = (0, r.PA)(() => {
        let e2 = (0, s.hj)(), {
          user: t2,
          familyInvite: { start: a2 }
        } = (0, n.Pjs)();
        (0, i.useEffect)(() => {
          e2.shouldShowFamilyInvite && e2.inviteId && (t2.isAuthorized && e2.clear(), a2(e2.inviteId));
        }, [t2.isAuthorized, e2, a2]);
      });
    },
    62803: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { SonataProvider: () => r7 });
      var r, i, s, n, l, o, d, u, c, h, g, y, m, p, v, P, S, E, f, b, I, _, k, C, T, D, A = a(54486), x = a(74338), L = a(28303), R = a(61910), N = a(15209), w = a(96559), M = a(89461), O = a(8075), F = a(5693), G = a(79899), K = a(26688);
      !(function(e10) {
        e10.PLAYING = "playing", e10.NOT_PLAYING = "not-playing";
      })(r || (r = {}));
      let j = (e10) => !!("object" == typeof e10 && e10 && "streamProgress" in e10 && "object" == typeof e10.streamProgress && e10.streamProgress && "endPositionSec" in e10.streamProgress && "number" == typeof e10.streamProgress.endPositionSec);
      class X {
        set playId(e10) {
          this.entityPlayId = e10;
        }
        get playId() {
          return this.entityPlayId;
        }
        set addTracksToPlayerTime(e10) {
          this.entityAddTracksToPlayerTime = e10;
        }
        get addTracksToPlayerTime() {
          return this.entityAddTracksToPlayerTime;
        }
        get totalPlayedSeconds() {
          return (function(e10) {
            let t10, a10, i2 = 0, s2 = [];
            if (0 !== e10.length) {
              for (let i3 of (function(e11) {
                let t11 = [];
                for (; 0 !== e11.length; ) {
                  let a12 = e11.shift();
                  if (a12 && a12.stage === r.PLAYING) {
                    let e12 = t11[t11.length - 1];
                    e12 && e12.stage !== r.NOT_PLAYING || t11.push(a12);
                  } else if (a12 && a12.stage === r.NOT_PLAYING) {
                    let e12 = t11[t11.length - 1];
                    e12 && e12.stage === r.PLAYING && t11.push(a12);
                  }
                }
                let a11 = t11[t11.length - 1];
                return a11 && a11.stage === r.PLAYING && t11.push({ stage: r.NOT_PLAYING, perfNow: performance.now(), ts: Date.now() }), t11;
              })(e10))
                i3.stage === r.PLAYING ? t10 = i3.perfNow : a10 = i3.perfNow, t10 && a10 && (s2.push(a10 - t10), t10 = void 0, a10 = void 0);
              for (let e11 of s2) i2 += e11;
              return Math.round((i2 / 1e3 + Number.EPSILON) * 1e3) / 1e3;
            }
            return i2;
          })([...this.entityTimeStagesOfPlayback]);
        }
        get timeStagesOfPlayback() {
          return this.entityTimeStagesOfPlayback;
        }
        saveTimeStageOfPlayback(e10) {
          let t10 = { stage: e10.stage, perfNow: performance.now(), ts: Date.now() };
          e10.reason && (t10.reason = e10.reason), this.entityTimeStagesOfPlayback.push(t10);
        }
        clearTimeStagesOfPlayback() {
          this.entityTimeStagesOfPlayback = [];
        }
        get data() {
          return this.entityData;
        }
        get isAvailable() {
          return !!("available" in this.entityData.meta && this.entityData.meta.available);
        }
        get isDisliked() {
          return void 0 !== this.likeStore && this.likeStore.isTrackDisliked(this.entityData.meta.id);
        }
        get isExplicit() {
          return "contentWarning" in this.entityData.meta && this.entityData.meta.contentWarning === G.K.EXPLICIT;
        }
        get everFinished() {
          return j(this.entityData.meta) ? this.entityData.meta.streamProgress.everFinished : null;
        }
        set everFinished(e10) {
          j(this.entityData.meta) && null !== e10 && (this.entityData.meta.streamProgress.everFinished = e10);
        }
        hasPlayId() {
          return "" !== this.playId;
        }
        constructor(e10) {
          (0, w._)(this, "entityData", void 0), (0, w._)(this, "likeStore", void 0), (0, w._)(this, "entityPlayId", ""), (0, w._)(this, "entityAddTracksToPlayerTime", ""), (0, w._)(this, "entityTimeStagesOfPlayback", []), (0, w._)(this, "mediaElementErrorReloadCounter", 0), (0, w._)(this, "mediaSourceData", null), (0, w._)(this, "expectedQuality", null), (0, w._)(this, "startPosition", null), (0, w._)(this, "contentType", K.e.AUDIO), (0, w._)(this, "hidden", false), this.entityData = e10.data, this.likeStore = e10.likeStore;
        }
      }
      class B extends X {
      }
      class V extends X {
        constructor(...e10) {
          super(...e10), (0, w._)(this, "contentType", K.e.DOWNLOADED_AUDIO);
        }
      }
      class U extends X {
      }
      class q extends X {
        get isAvailable() {
          return false;
        }
        get isDisliked() {
          return false;
        }
      }
      var W = a(56258);
      class Y extends W.t {
        constructor(e10, { code: t10 = "E_ENTITY_FACTORY", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "EntityFactoryException"), Object.setPrototypeOf(this, Y.prototype);
        }
      }
      class z extends X {
        get isAvailable() {
          return true;
        }
        get isDisliked() {
          return false;
        }
        constructor(...e10) {
          super(...e10), (0, w._)(this, "contentType", K.e.HLS);
        }
      }
      class H extends X {
        get isAvailable() {
          return true;
        }
        get isDisliked() {
          return false;
        }
      }
      class Q extends X {
        get isAvailable() {
          return true;
        }
        get isDisliked() {
          return false;
        }
        constructor(...e10) {
          super(...e10), (0, w._)(this, "contentType", K.e.CLIP);
        }
      }
      class $ extends X {
        get isAvailable() {
          return true;
        }
        get isDisliked() {
          return false;
        }
        constructor(...e10) {
          super(...e10), (0, w._)(this, "contentType", K.e.HLS);
        }
      }
      class Z {
        create(e10) {
          let t10 = null, { data: a10 } = e10;
          void 0 === a10.fromCurrentContext && (a10.fromCurrentContext = true);
          try {
            switch (a10.type) {
              case F.R.Music:
                t10 = new B({ data: a10, likeStore: this.likeStore });
                break;
              case F.R.DownloadedMusic:
                t10 = new V({ data: a10, likeStore: this.likeStore });
                break;
              case F.R.VibeTrack:
                t10 = new U({ data: a10, likeStore: this.likeStore });
                break;
              case F.R.Generative:
                t10 = new z({ data: a10, likeStore: this.likeStore });
                break;
              case F.R.SmartPreview:
                t10 = new H({ data: a10, likeStore: this.likeStore });
                break;
              case F.R.Clip:
                t10 = new Q({ data: a10, likeStore: this.likeStore });
                break;
              case F.R.Radio:
                t10 = new $({ data: a10, likeStore: this.likeStore });
                break;
              case F.R.Unknown:
                a10.meta.type, O.S.MUSIC, t10 = new B({ data: { ...a10, type: F.R.Music }, likeStore: this.likeStore });
                break;
              case M.z4.Unloaded:
                t10 = new q({ data: a10, likeStore: this.likeStore });
            }
          } catch (e11) {
            throw new Y("Error while creating entity", { cause: e11, data: { type: a10.type, meta: a10.meta } });
          }
          if (null !== t10) return t10;
          throw new Y("Cannot create entities with nonexistent type", {
            code: "E_NONEXISTENT_ENTITY_TYPE",
            data: { type: a10.type, meta: a10.meta }
          });
        }
        constructor(e10) {
          (0, w._)(this, "likeStore", void 0), this.likeStore = e10.likeStore;
        }
      }
      var J = a(63585);
      function ee(e10, t10) {
        let a10 = [];
        for (let r10 of e10) for (let e11 of r10) a10.push({ type: M.z4.Unloaded, meta: e11, additional: t10 });
        return a10;
      }
      var et = a(87965);
      class ea extends W.t {
        constructor(e10, { code: t10 = "E_CONTEXT", name: a10, ...r10 } = {}) {
          super(e10, { code: t10, ...r10 }), (0, w._)(this, "name", void 0), this.name = null != a10 ? a10 : "ContextException", Object.setPrototypeOf(this, ea.prototype);
        }
      }
      class er extends M.EX {
        get isCurrentContext() {
          return this.isCurrent;
        }
        set isCurrentContext(e10) {
          this.isCurrent = e10;
        }
        get availableActions() {
          return this.actions;
        }
        logError(e10) {
          let t10, { name: a10, message: r10 = "Error in YaMusicContext", data: i2, cause: s2, originalError: n2 } = e10;
          t10 = n2 instanceof W.t ? n2 : new ea(r10, { name: a10, cause: (0, N.createObjectFromError)(s2), data: i2 }), this.logger.error(t10, { ...t10.data, code: t10.code, cause: t10.cause, stack: t10.stack, message: t10.message });
        }
        constructor({ logger: e10 }) {
          super(), (0, w._)(this, "isCurrent", false), (0, w._)(this, "actions", {
            moveBackward: new et.cJ(false),
            moveForward: new et.cJ(true),
            repeat: new et.cJ(null),
            shuffle: new et.cJ(null),
            speed: new et.cJ(null)
          }), (0, w._)(this, "from", ""), (0, w._)(this, "utmLink", void 0), (0, w._)(this, "logger", void 0), this.logger = e10;
        }
      }
      function ei(e10, t10) {
        return e10.map((e11) => ({ type: F.R.SmartPreview, meta: e11, additional: t10 }));
      }
      class es extends er {
        loadTrailer() {
          return this.albumsResource.getTrailer({ albumId: Number(this.contextData.meta.id) }).then((e10) => (this.contextData.meta.trailerTracks = e10.trailer.tracks, e10)).catch((e10) => {
            throw new ea("Error in AlbumContext", {
              code: "E_ALBUM_LOAD_TRAILER",
              cause: (0, N.createObjectFromError)(e10),
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        apply(e10) {
        }
        loadContextMeta() {
          return this.albumsResource.getAlbumWithRichTracks({ albumId: Number(this.contextData.meta.id), resumeStream: true }).then((e10) => (this.contextData.meta = e10, e10)).catch((e10) => {
            throw new ea("Error in AlbumContext", {
              code: "E_ALBUM_LOAD_CONTEXT_META",
              cause: (0, N.createObjectFromError)(e10),
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        getContextEntitiesData() {
          let e10 = { from: this.from, utmLink: this.utmLink };
          return this.contextData.trailer ? this.loadTrailer().then((t10) => ei(t10.trailer.tracks, e10)) : this.contextData.meta.volumes ? Promise.resolve(ee(this.contextData.meta.volumes, e10)) : this.loadContextMeta().then((t10) => Promise.resolve(ee(t10.volumes, e10)));
        }
        get type() {
          return this.contextData.type;
        }
        get data() {
          return this.contextData;
        }
        get resumeFromIndex() {
          var e10;
          if ((null == (e10 = this.contextData.meta.resumeFrom) ? void 0 : e10.trackId) && Array.isArray(this.contextData.meta.volumes)) {
            let e11 = [].concat(...this.contextData.meta.volumes).findIndex((e12) => {
              var t10;
              return String(e12.id) === String(null == (t10 = this.contextData.meta.resumeFrom) ? void 0 : t10.trackId);
            });
            if (e11 >= 0) return e11;
          }
          return null;
        }
        constructor(e10) {
          super(e10), (0, w._)(this, "contextData", void 0), (0, w._)(this, "albumsResource", void 0), (0, w._)(this, "variables", void 0);
          let { data: t10, albumsResource: a10, variables: r10 } = e10;
          this.albumsResource = a10, this.contextData = t10, this.from = t10.from, this.utmLink = t10.utmLink, this.variables = r10;
        }
      }
      var en = a(70392);
      class el extends er {
        loadTrailer() {
          let { uid: e10, kind: t10 } = (0, en.I)(this.contextData.meta.id);
          return this.usersResource.getPlaylistTrailer({ userId: e10, playlistKind: t10 }).then((e11) => (this.contextData.meta.trailerTracks = e11.trailer.tracks, e11)).catch((e11) => {
            throw new ea("Error in PlaylistContext", {
              code: "E_PLAYLIST_LOAD_TRAILER",
              cause: (0, N.createObjectFromError)(e11),
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        apply(e10) {
        }
        loadContextMeta() {
          let e10 = this.contextData.meta.uuid, { uid: t10, kind: a10 } = (0, en.I)(this.contextData.meta.id), r10 = 3 === a10;
          return (r10 && void 0 !== e10 ? this.playlistResource.getPlaylist({ playlistUuid: e10, resumeStream: false, richTracks: false }) : this.usersResource.getPlaylistWithTracksIds({
            userId: t10,
            playlistKind: a10,
            resumeStream: false,
            trackMetaType: r10 ? "music" : void 0
          })).then((e11) => {
            let t11, a11, r11 = { ...e11, id: (t11 = e11.uid, a11 = e11.kind, "".concat(t11, ":").concat(a11)) };
            return this.contextData.meta = r11, r11;
          }).catch((e11) => {
            throw new ea("Error in PlaylistContext", {
              code: "E_PLAYLIST_LOAD_CONTEXT_META",
              cause: (0, N.createObjectFromError)(e11),
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        getContextEntitiesData() {
          let e10 = { from: this.from, utmLink: this.utmLink };
          if (this.contextData.trailer) return this.loadTrailer().then((t10) => ei(t10.trailer.tracks, e10));
          if (this.contextData.meta.tracks) {
            let t10 = [];
            for (let a10 of this.contextData.meta.tracks) t10.push({ type: M.z4.Unloaded, meta: a10, additional: e10 });
            return Promise.resolve(t10);
          }
          return this.loadContextMeta().then((t10) => {
            let a10 = [];
            for (let r10 of t10.tracks) a10.push({ type: M.z4.Unloaded, meta: r10, additional: e10 });
            return a10;
          });
        }
        get type() {
          return this.contextData.type;
        }
        get data() {
          return this.contextData;
        }
        constructor(e10) {
          super(e10), (0, w._)(this, "contextData", void 0), (0, w._)(this, "usersResource", void 0), (0, w._)(this, "playlistResource", void 0), (0, w._)(this, "variables", void 0);
          let { data: t10, playlistResource: a10, usersResource: r10, variables: i2 } = e10;
          this.usersResource = r10, this.playlistResource = a10, this.contextData = t10, this.from = t10.from, this.utmLink = t10.utmLink, this.variables = i2;
        }
      }
      class eo extends er {
        loadTrailer() {
          return this.artistsResource.getTrailer({ artistId: String(this.contextData.meta.id) }).then((e10) => (this.contextData.meta.trailerTracks = e10.trailer.tracks, e10)).catch((e10) => {
            throw new ea("Error in ArtistContext", {
              code: "E_ARTIST_LOAD_TRAILER",
              cause: (0, N.createObjectFromError)(e10),
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        apply(e10) {
        }
        loadContextMeta() {
          return this.artistsResource.getBriefInfo({
            artistId: String(this.contextData.meta.id),
            discographyBlockEnabled: false,
            fetchPlaylistLikesCounts: false
          }).then((e10) => {
            this.contextData.meta.artist = e10.artist;
          }).catch((e10) => {
            throw new ea("Error in ArtistContext", {
              code: "E_ARTIST_LOAD_CONTEXT_META",
              cause: (0, N.createObjectFromError)(e10),
              data: { contextId: this.contextData.meta.id }
            });
          }), this.artistsResource.getArtistTrackIds({ artistId: String(this.contextData.meta.id) }).then((e10) => (this.contextData.meta.trackIds = e10, this.contextData.meta)).catch((e10) => {
            throw new ea("Error in ArtistContext", {
              code: "E_ARTIST_LOAD_CONTEXT_META",
              cause: (0, N.createObjectFromError)(e10),
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        getContextEntitiesData() {
          let e10 = { from: this.from, utmLink: this.utmLink };
          if (this.contextData.trailer) return this.loadTrailer().then((t10) => ei(t10.trailer.tracks, e10));
          if (this.contextData.meta.trackIds) {
            let t10 = [];
            for (let a10 of this.contextData.meta.trackIds)
              t10.push({ type: M.z4.Unloaded, meta: { id: a10 }, additional: e10 });
            return Promise.resolve(t10);
          }
          return this.loadContextMeta().then((t10) => {
            let a10 = [];
            if (t10.trackIds) for (let r10 of t10.trackIds) a10.push({ type: M.z4.Unloaded, meta: { id: r10 }, additional: e10 });
            return a10;
          });
        }
        get type() {
          return this.contextData.type;
        }
        get data() {
          return this.contextData;
        }
        constructor(e10) {
          super(e10), (0, w._)(this, "contextData", void 0), (0, w._)(this, "artistsResource", void 0), (0, w._)(this, "variables", void 0);
          let { data: t10, artistsResource: a10, variables: r10 } = e10;
          this.artistsResource = a10, this.contextData = t10, this.from = t10.from, this.utmLink = t10.utmLink, this.variables = r10;
        }
      }
      var ed = a(84321);
      function eu(e10, t10) {
        let a10 = [], { batchId: r10, sequence: i2 } = e10;
        for (let e11 of i2)
          a10.push({
            type: F.R.VibeTrack,
            additional: t10,
            batchId: r10,
            meta: { ...e11.track, liked: e11.liked, trackParameters: e11.trackParameters },
            fromCurrentContext: true,
            wasPlayed: false
          });
        return a10;
      }
      var ec = a(54906);
      let eh = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i, eg = (e10) => eh.test(String(e10)), ey = (e10) => {
        let { meta: t10 } = e10.data, a10 = "trackSource" in t10 ? t10.trackSource : void 0;
        return void 0 !== a10 ? a10 === ec.J.UGC || a10 === ec.J.OWN_REPLACED_TO_UGC : eg(t10.id);
      };
      function em(e10) {
        var t10;
        let a10;
        if (!(a10 = e10.data.type === M.z4.Unloaded ? e10.data.meta.id : "realId" in e10.data.meta ? e10.data.meta.realId : e10.data.meta.id))
          throw new ea("Error in VibeContext", { code: "E_WRONG_VIBE_CONTEXT" });
        let r10 = "albums" in e10.data.meta ? e10.data.meta.albums : [];
        return r10 && (null == (t10 = r10[0]) ? void 0 : t10.id) ? "".concat(a10, ":").concat(r10[0].id) : String(a10);
      }
      function ep(e10) {
        return (null == e10 ? void 0 : e10.data.type) === F.R.VibeTrack;
      }
      function ev(e10, t10) {
        let a10 = null, r10 = null;
        for (let i3 = e10.length - 1; i3 >= 0; i3--) {
          let s2 = e10[i3];
          if (!s2 || !ep(s2.entity)) continue;
          let { entity: n2, sourceContext: l2 } = s2;
          if (!l2) {
            if (n2.data.wasPlayed || t10 === i3) break;
            a10 = s2, r10 = i3;
          }
        }
        let i2 = null !== r10 ? r10 + 1 : e10.length;
        return { vibeHistory: e10.slice(0, i2), firstNotPlayedVibeEntity: a10, firstNotPlayedVibeEntityIndex: r10 };
      }
      function eP(e10, t10) {
        let { vibeHistory: a10 } = ev(e10, t10);
        return a10.filter((e11) => !ey(e11.entity)).map((e11) => em(e11.entity));
      }
      var eS = a(52509);
      function eE() {
        return (/* @__PURE__ */ new Date()).toISOString();
      }
      function ef(e10) {
        let t10, { entity: a10, type: r10, from: i2 } = e10, s2 = "user-queue-".concat(a10.data.meta.id, "-").concat(Date.now());
        switch (ep(a10) && a10.data.batchId && (s2 = a10.data.batchId), r10) {
          case ed.O.RADIO_STARTED:
            return { event: { type: r10, timestamp: eE(), from: i2 }, from: i2 };
          case ed.O.TRACK_STARTED:
          case ed.O.LIKE:
          case ed.O.UNLIKE:
          case ed.O.UNDISLIKE:
            return { batchId: s2, event: { type: r10, timestamp: eE(), trackId: em(a10) }, from: i2 };
          case ed.O.TRACK_FINISHED:
            if (ep(a10) && a10.data.meta.durationMs) {
              let e11 = a10.data.meta.durationMs / 1e3;
              t10 = e11 % 1 == 0 ? e11 : Number(e11.toFixed(3));
            }
            return {
              batchId: s2,
              event: {
                type: r10,
                timestamp: eE(),
                trackId: em(a10),
                totalPlayedSeconds: a10.totalPlayedSeconds,
                trackLengthSeconds: t10
              },
              from: i2
            };
          case ed.O.SKIP:
          case ed.O.DISLIKE:
            return {
              batchId: s2,
              event: { type: r10, timestamp: eE(), trackId: em(a10), totalPlayedSeconds: a10.totalPlayedSeconds },
              from: i2
            };
        }
        return null;
      }
      function eb(e10, t10) {
        return e10.some(
          (e11) => (function(e12, t11) {
            if (e12 === t11) return true;
            let a10 = [ed.O.SKIP, ed.O.TRACK_FINISHED];
            return a10.includes(e12) && a10.includes(t11);
          })(t10.event.type, e11.event.type) && "trackId" in t10.event && "trackId" in e11.event && t10.event.trackId === e11.event.trackId
        );
      }
      class eI {
        storeFeedbacksForWasPlayedTracks(e10, t10) {
          for (let a10 of e10)
            if (ep(a10.entity) && a10.entity.data.wasPlayed) {
              let e11 = ef({ entity: a10.entity, type: ed.O.TRACK_STARTED, from: t10 }), r10 = ef({ entity: a10.entity, type: ed.O.TRACK_FINISHED, from: t10 });
              e11 && r10 && this.storeFeedbacksInHistory([e11, r10]);
            }
        }
        storeFeedbacksInHistory(e10) {
          if (e10) for (let t10 of e10) this.feedbacksHistory.push(t10);
        }
        clearStoredFeedbacks() {
          this.feedbacksHistory = [], this.feedbacksForSending = [];
        }
        storeFeedbacksForSending(e10) {
          var t10;
          if (e10 && (null == (t10 = this.variables) ? void 0 : t10.sendFeedbackToSessionTracks)) {
            let t11 = Array.isArray(e10) ? e10 : [e10];
            this.feedbacksForSending.push(...t11);
          }
        }
        getFeedbacksForSending() {
          var e10;
          if (!(null == (e10 = this.variables) ? void 0 : e10.sendFeedbackToSessionTracks)) return null;
          let t10 = this.feedbacksForSending;
          return this.feedbacksForSending = [], t10;
        }
        sendFeedbackRequest(e10) {
          let { feedback: t10, session: a10 } = e10, { radioSessionId: r10 } = a10;
          return this.rotorResource.sessionFeedback({ radioSessionId: r10, feedback: t10 }).then(() => Promise.resolve());
        }
        sendFeedback(e10) {
          var t10;
          let {
            entity: a10,
            type: r10,
            from: i2,
            session: s2,
            sendWithSessionTracks: n2 = false,
            saveFeedbackToHistory: l2 = false
          } = e10, o2 = ef({ entity: a10, type: r10, from: i2 });
          return o2 ? "trackId" in o2.event && ey(a10) || eb(this.feedbacksHistory, o2) || eb(this.feedbacksForSending, o2) ? Promise.resolve() : n2 && (null == (t10 = this.variables) ? void 0 : t10.sendFeedbackToSessionTracks) ? (this.storeFeedbacksForSending(o2), Promise.resolve()) : this.sendFeedbackRequest({ feedback: o2, session: s2 }).then(
            () => (l2 && this.storeFeedbacksInHistory([o2]), Promise.resolve())
          ) : Promise.reject(new W.t("Cannot create feedback", { data: { type: r10 } }));
        }
        constructor({ rotorResource: e10, variables: t10 }) {
          (0, w._)(this, "rotorResource", void 0), (0, w._)(this, "feedbacksForSending", []), (0, w._)(this, "feedbacksHistory", []), (0, w._)(this, "variables", void 0), this.rotorResource = e10, this.variables = t10;
        }
      }
      function e_(e10) {
        let {
          targetEntityWasPlayed: t10,
          hasSourceContext: a10,
          targetEntityIndex: r10,
          livePlayableIndex: i2,
          targetEntityIsLastEntity: s2,
          useWaveQueue: n2
        } = e10;
        return false === n2 ? !s2 && t10 : !s2 && (t10 || a10 || r10 <= i2);
      }
      function ek(e10) {
        return e10.filter((e11) => {
          if ("string" == typeof e11) {
            let [t10] = e11.split(":");
            return !eg(null != t10 ? t10 : "");
          }
          return !e11.ugc;
        });
      }
      class eC extends er {
        apply(e10) {
          let { hooks: t10, playback: a10 } = e10;
          t10.beforeContextSet.tap("VibeContext", () => {
            if (!this.isCurrentContext) return;
            let e11 = a10.state.queueState.currentEntity.value;
            e11 && (this.sendFeedback({ entity: e11.entity, type: ed.O.SKIP }), this.feedbacksController.clearStoredFeedbacks());
          }), t10.afterSetupQueue.tap("VibeContext", () => {
            if (!this.isCurrentContext) return;
            let { value: e11 } = a10.state.queueState.entityList;
            if (this.feedbacksController.storeFeedbacksForWasPlayedTracks(e11.slice(0, -1), this.from), this.contextData.cloneSessionId && this.contextData.meta.session) {
              let e12 = eu(this.contextData.meta.session, { from: this.from, utmLink: this.utmLink });
              a10.injectLast({ entitiesData: e12 });
            }
          }), t10.afterEntityRemove.tapPromise("VibeContext", () => {
            if (!this.isCurrentContext) return Promise.resolve();
            let { nextIndex: e11, entityList: t11, index: r10 } = a10.state.queueState;
            if (null !== e11.value) return Promise.resolve();
            let i2 = eP(t11.value, r10.value);
            return this.getNextSessionTracks(i2).then((e12) => {
              a10.injectLast({ entitiesData: e12 });
            }).catch((e12) => this.logVibeError({ originalError: e12 }));
          }), t10.afterMediaStartPlaying.tapPromise(
            "VibeContext",
            () => this.isCurrentContext ? new Promise((e11) => {
              let t11 = a10.state.queueState.currentEntity.value;
              if (!t11) return void e11();
              let { entity: r10 } = t11;
              this.isVibeStarted ? this.sendFeedback({ type: ed.O.TRACK_STARTED, entity: r10, saveFeedbackToHistory: true }) : (this.sendFeedback({ type: ed.O.RADIO_STARTED, entity: r10 }).then(() => {
                this.sendFeedback({ type: ed.O.TRACK_STARTED, entity: r10, saveFeedbackToHistory: true });
              }), this.isVibeStarted = true), e11();
            }) : Promise.resolve()
          ), t10.beforeFindPlayableEntityIndex.tapPromise(
            "VibeContext",
            (e11) => this.isCurrentContext ? new Promise((t11, r10) => {
              switch (e11.method) {
                case M.So.AUTO_MOVE_FORWARD:
                  this.onAutoMoveForward(a10).then(t11).catch(r10);
                  break;
                case M.So.MOVE_FORWARD:
                  this.onMoveForward(a10).then(t11).catch(r10);
                  break;
                case M.So.MOVE_BACKWARD:
                  this.onMoveBackward(a10).then(t11).catch(r10);
                  break;
                case M.So.SET_INDEX:
                  this.onSetIndex(a10, e11.indexToChangeOn).then(t11).catch(r10);
                  break;
                default:
                  t11();
              }
            }) : Promise.resolve()
          ), t10.beforeInject.tap("VibeContext", (e11) => {
            var t11;
            if (!this.isCurrentContext || !e11.sourceContext) return e11;
            let a11 = (function(e12) {
              let { position: t12, livePlayableIndex: a12, entityList: r10, useWaveQueue: i2 } = e12;
              if ("number" != typeof a12 || !i2) return t12;
              let s2 = (function(e13, t13) {
                if (void 0 === e13) return 0;
                let a13 = 0;
                for (let i3 = t13 + 1; i3 < e13.length; i3++) {
                  var r11;
                  (null == (r11 = e13[i3]) ? void 0 : r11.sourceContext) && (a13 += 1);
                }
                return a13;
              })(r10, a12), n2 = a12 + 1 + s2;
              return t12 > n2 ? n2 : t12;
            })({
              position: e11.position,
              livePlayableIndex: e11.livePlayableIndex,
              entityList: e11.entityList,
              useWaveQueue: null == (t11 = this.variables) ? void 0 : t11.useWaveQueue
            });
            return { ...e11, calibratedPosition: a11 };
          });
        }
        get interactive() {
          var e10;
          return (null == (e10 = this.variables) ? void 0 : e10.sendInteractiveToSession) && void 0 !== this.contextData.interactive ? { interactive: this.contextData.interactive } : {};
        }
        loadContextMeta() {
          this.timeOfLastInteractionWithVibe = performance.now();
          let {
            meta: { id: e10 },
            seeds: t10,
            cloneSessionId: a10,
            queue: r10,
            trackToStartFrom: i2,
            includeTracksInResponse: s2,
            allowExplicit: n2
          } = this.contextData, l2 = r10 ? ek(r10) : void 0;
          return (a10 ? this.rotorResource.sessionClone({
            seeds: t10,
            includeWaveModel: true,
            radioSessionId: a10,
            trackToStartFrom: i2,
            queue: l2,
            allowExplicit: n2,
            includeTracksInResponse: s2,
            ...this.interactive
          }).catch((e11) => {
            throw this.createException("Error in clone vibe session", e11);
          }) : this.rotorResource.sessionNew({
            seeds: t10,
            includeWaveModel: true,
            trackToStartFrom: i2,
            queue: l2,
            allowExplicit: n2,
            includeTracksInResponse: s2,
            ...this.interactive
          }).catch((e11) => {
            throw this.createException("Error in create new vibe session", e11);
          })).then(
            (t11) => (this.contextData.meta.session = t11, this.contextData.trackToStartFrom = void 0, { id: e10, session: t11 })
          );
        }
        setSettings(e10) {
          let { seeds: t10, queueState: a10, allowExplicit: r10, interactive: i2 } = e10;
          this.contextData.interactive = i2;
          let s2 = ek(eP(a10.entityList.value, a10.index.value)), n2 = a10.currentEntity.value, l2 = null != r10 ? r10 : a10.filterParams.value.allowExplicit, o2 = Promise.resolve();
          n2 && ep(n2.entity) && (o2 = this.sendFeedback({ entity: n2.entity, type: ed.O.SKIP }));
          let { trackToStartFrom: d2, includeTracksInResponse: u2 } = this.contextData;
          return o2.then(
            () => this.rotorResource.sessionNew({
              includeTracksInResponse: u2,
              trackToStartFrom: d2,
              seeds: t10,
              queue: s2,
              allowExplicit: l2,
              includeWaveModel: true,
              ...this.interactive
            }).then((e11) => {
              this.contextData.meta.session = e11, this.contextData.meta.id = (0, eS.f)(e11.wave.seeds), this.contextData.meta.allowExplicit = l2, this.feedbacksController.clearStoredFeedbacks();
            }).catch((e11) => {
              this.logVibeError({ message: "Error while setting new vibe settings", cause: e11 });
            })
          );
        }
        getContextEntitiesData() {
          let {
            meta: { session: e10 }
          } = this.contextData, t10 = { from: this.from, utmLink: this.utmLink };
          return e10 ? Promise.resolve(eu(e10, t10)) : this.loadContextMeta().then((e11) => {
            let { session: a10 } = e11;
            return eu(a10, t10);
          });
        }
        get type() {
          return this.contextData.type;
        }
        get data() {
          return this.contextData;
        }
        logVibeError(e10) {
          var t10, a10;
          let { message: r10, cause: i2, originalError: s2 } = e10;
          this.logError({
            name: "VibeContextException",
            message: r10,
            cause: i2,
            data: {
              contextId: this.contextData.meta.id,
              sessionId: null != (a10 = null == (t10 = this.contextData.meta.session) ? void 0 : t10.radioSessionId) ? a10 : ""
            },
            originalError: s2
          });
        }
        createException(e10, t10) {
          var a10, r10;
          return new ea(e10, {
            name: "VibeContextException",
            cause: (0, N.createObjectFromError)(t10),
            data: {
              contextId: this.contextData.meta.id,
              sessionId: null != (r10 = null == (a10 = this.contextData.meta.session) ? void 0 : a10.radioSessionId) ? r10 : ""
            }
          });
        }
        onAutoMoveForward(e10) {
          var t10;
          if (this.sessionTracksPromise) return Promise.resolve();
          let a10 = this.onQueueNavigationCommon(e10);
          return this.sendFeedback({
            type: ed.O.TRACK_FINISHED,
            entity: null == (t10 = e10.state.queueState.currentEntity.value) ? void 0 : t10.entity,
            sendWithSessionTracks: true,
            saveFeedbackToHistory: true
          }).then(() => {
            let { index: t11, entityList: r10 } = e10.state.queueState, i2 = t11.value === r10.value.length - 2, s2 = t11.value === r10.value.length - 1;
            if (!i2 && !s2) return Promise.resolve();
            let n2 = this.getNextSessionTracks(a10).then((t12) => {
              e10.injectLast({ entitiesData: t12 }), this.availableActions.moveForward.value = true;
            });
            return s2 ? n2 : (i2 && n2.catch((e11) => this.logVibeError({ originalError: e11 })), Promise.resolve());
          });
        }
        onMoveForward(e10) {
          var t10;
          if (this.sessionTracksPromise) return Promise.resolve();
          let a10 = this.onQueueNavigationCommon(e10);
          return this.sendFeedback({
            type: ed.O.SKIP,
            entity: null == (t10 = e10.state.queueState.currentEntity.value) ? void 0 : t10.entity,
            sendWithSessionTracks: true,
            saveFeedbackToHistory: true
          }).then(() => {
            var t11;
            let { index: r10, entityList: i2, livePlayableIndex: s2 } = e10.state.queueState, n2 = r10.value === i2.value.length - 1, l2 = r10.value + 1, o2 = e10.getEntityByIndex({ index: l2 }), d2 = l2 === i2.value.length - 1;
            if (e_({
              targetEntityWasPlayed: !!(o2 && ep(o2.entity) && o2.entity.data.wasPlayed),
              hasSourceContext: !!(null == o2 ? void 0 : o2.sourceContext),
              targetEntityIndex: l2,
              livePlayableIndex: s2.value,
              targetEntityIsLastEntity: d2,
              useWaveQueue: !!(null == (t11 = this.variables) ? void 0 : t11.useWaveQueue)
            }))
              return Promise.resolve();
            this.removeVibeTracksBeforeMoveForward(e10);
            let u2 = this.getNextSessionTracks(a10).then((t12) => e10.injectLast({ entitiesData: t12 }));
            return n2 ? u2 : (u2.catch((e11) => this.logVibeError({ originalError: e11 })), Promise.resolve());
          });
        }
        onMoveBackward(e10) {
          this.removeNotPlayedVibeTracksByTtl(e10), this.timeOfLastInteractionWithVibe = performance.now();
          let t10 = e10.state.queueState.currentEntity.value;
          if (!t10) return Promise.resolve();
          let { entity: a10 } = t10;
          return this.sendFeedback({ entity: a10, type: ed.O.SKIP, saveFeedbackToHistory: true }), Promise.resolve();
        }
        onSetIndex(e10, t10) {
          var a10;
          if (this.sessionTracksPromise) return Promise.resolve();
          let r10 = this.onQueueNavigationCommon(e10);
          return this.sendFeedback({
            type: ed.O.SKIP,
            entity: null == (a10 = e10.state.queueState.currentEntity.value) ? void 0 : a10.entity,
            sendWithSessionTracks: true,
            saveFeedbackToHistory: true
          }).then(() => {
            var a11;
            let { index: i2, entityList: s2, livePlayableIndex: n2 } = e10.state.queueState, l2 = i2.value === s2.value.length - 1, o2 = e10.getEntityByIndex({ index: t10 });
            if (e_({
              targetEntityWasPlayed: !!(o2 && ep(o2.entity) && o2.entity.data.wasPlayed),
              hasSourceContext: !!(null == o2 ? void 0 : o2.sourceContext),
              targetEntityIndex: t10,
              livePlayableIndex: n2.value,
              targetEntityIsLastEntity: t10 === s2.value.length - 1,
              useWaveQueue: !!(null == (a11 = this.variables) ? void 0 : a11.useWaveQueue)
            }))
              return Promise.resolve();
            this.removeVibeTracksBeforeMoveForward(e10);
            let d2 = this.getNextSessionTracks(r10).then((t11) => e10.injectLast({ entitiesData: t11 })).catch((e11) => this.logVibeError({ originalError: e11 }));
            return l2 ? d2 : Promise.resolve();
          });
        }
        getNextSessionTracks(e10) {
          if (!this.contextData.meta.session)
            return Promise.reject(this.createException("Cannot get next vibe tracks. No session"));
          let {
            meta: { session: t10 },
            aliceExperiments: a10,
            djData: r10,
            useIchwill: i2
          } = this.contextData, s2 = { from: this.from, utmLink: this.utmLink }, n2 = this.feedbacksController.getFeedbacksForSending();
          return this.sessionTracksPromise = this.rotorResource.sessionTracks({
            radioSessionId: t10.radioSessionId,
            queue: e10,
            aliceExperiments: a10,
            djData: r10,
            useIchwill: i2,
            feedbacks: n2 || void 0
          }).then(
            (e11) => (this.feedbacksController.storeFeedbacksInHistory(n2), this.contextData.meta.sessionTracks = e11, eu(e11, s2))
          ).catch(
            (e11) => (this.feedbacksController.storeFeedbacksForSending(n2), Promise.reject(this.createException("Error in next vibe tracks request", e11)))
          ).finally(() => {
            this.sessionTracksPromise = null, this.availableActions.moveForward.value = true;
          }), this.availableActions.moveForward.value = false, this.sessionTracksPromise;
        }
        sendFeedback(e10) {
          let { entity: t10, type: a10, sendWithSessionTracks: r10 = false, saveFeedbackToHistory: i2 = false } = e10;
          if (!t10) return this.logVibeError({ message: "Cannot send feedback. No entity" }), Promise.resolve();
          let { session: s2 } = this.contextData.meta;
          return s2 ? this.feedbacksController.sendFeedback({
            entity: t10,
            type: a10,
            session: s2,
            from: this.contextData.from,
            sendWithSessionTracks: r10,
            saveFeedbackToHistory: i2
          }).catch(
            (e11) => (this.logVibeError({ message: "Error while sending feedback", cause: e11 }), Promise.resolve())
          ) : (this.logVibeError({ message: "Cannot send feedback. No session" }), Promise.resolve());
        }
        calculateLivePlayableIndex(e10) {
          return e10.state.queueState.livePlayableIndex.value;
        }
        removeNotPlayedVibeTracksByTtl(e10) {
          let { index: t10, entityList: a10 } = e10.state.queueState;
          if (performance.now() - this.timeOfLastInteractionWithVibe >= 18e5) {
            let r10 = [];
            for (let e11 = t10.value + 1; e11 < a10.value.length; e11++) {
              let t11 = a10.value[e11];
              t11 && ep(t11.entity) && !t11.entity.data.wasPlayed && r10.push(e11);
            }
            e10.remove(r10, true);
          }
        }
        removeVibeTracksBeforeMoveForward(e10) {
          var t10, a10;
          let { index: r10, entityList: i2, livePlayableIndex: s2 } = e10.state.queueState;
          if (!(null != (a10 = null == (t10 = this.variables) ? void 0 : t10.useWaveQueue) && a10)) {
            let t11 = this.getPositionsFromStartToEnd(r10.value + 2, i2.value.length);
            e10.remove(t11, true);
            return;
          }
          let n2 = this.findNextPlayablePosition(i2.value, r10.value);
          if (null === n2) return;
          let l2 = this.getPositionsToRemoveForWaveQueue(i2.value, n2 + 1, s2.value);
          e10.remove(l2, true);
        }
        findNextPlayablePosition(e10, t10) {
          for (let r10 = t10 + 1; r10 < e10.length; r10++) {
            var a10;
            if ((null == (a10 = e10[r10]) ? void 0 : a10.entity.hidden) !== true) return r10;
          }
          return null;
        }
        getPositionsToRemoveForWaveQueue(e10, t10, a10) {
          let r10 = [];
          for (let i2 = t10; i2 < e10.length; i2++) {
            let t11 = e10[i2], s2 = i2 <= a10, n2 = !!(null == t11 ? void 0 : t11.sourceContext);
            s2 || n2 || r10.push(i2);
          }
          return r10;
        }
        getPositionsFromStartToEnd(e10, t10) {
          let a10 = [];
          for (let r10 = e10; r10 < t10; r10++) a10.push(r10);
          return a10;
        }
        onQueueNavigationCommon(e10) {
          let t10 = eP(e10.state.queueState.entityList.value, e10.state.queueState.index.value);
          return this.removeNotPlayedVibeTracksByTtl(e10), this.timeOfLastInteractionWithVibe = performance.now(), t10;
        }
        constructor(e10) {
          super(e10), (0, w._)(this, "contextData", void 0), (0, w._)(this, "rotorResource", void 0), (0, w._)(this, "isVibeStarted", false), (0, w._)(this, "timeOfLastInteractionWithVibe", performance.now()), (0, w._)(this, "variables", void 0), (0, w._)(this, "sessionTracksPromise", null), (0, w._)(this, "feedbacksController", void 0);
          let { data: t10, rotorResource: a10, variables: r10 } = e10;
          this.rotorResource = a10, this.contextData = t10, this.from = t10.from, this.utmLink = t10.utmLink, this.availableActions.repeat.value = false, this.availableActions.shuffle.value = false, this.variables = r10, this.feedbacksController = new eI({ rotorResource: a10, variables: r10 });
        }
      }
      class eT extends er {
        getContextId() {
          var e10, t10;
          let a10 = null == (t10 = this.contextData.meta.albums) || null == (e10 = t10[0]) ? void 0 : e10.id;
          return a10 ? "".concat(this.contextData.meta.id, ":").concat(a10) : String(this.contextData.meta.id);
        }
        loadTrailer() {
          return this.tracksResource.getTrailer({ trackId: this.getContextId() }).then((e10) => (this.contextData.meta = e10.track, e10)).catch((e10) => {
            throw new ea("Error in PlaylistContext", {
              code: "E_PLAYLIST_LOAD_TRAILER",
              cause: e10,
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        apply(e10) {
        }
        loadContextMeta() {
          let e10 = this.getContextId();
          return this.tracksResource.getTracksMeta({ trackIds: [e10], withProgress: true }).then((t10) => {
            let a10 = t10[0];
            if (a10) return this.contextData.meta = a10, a10;
            throw new ea("Error in VariousContext. Track not found", {
              code: "E_VARIOUS_LOAD_CONTEXT_META",
              data: { contextId: e10 }
            });
          }).catch((t10) => {
            throw new ea("Error in VariousContext", {
              code: "E_VARIOUS_LOAD_CONTEXT_META",
              cause: t10,
              data: { contextId: e10 }
            });
          });
        }
        getContextEntitiesData() {
          let e10 = { from: this.from, utmLink: this.utmLink };
          return this.contextData.trailer ? this.loadTrailer().then((t10) => [{ meta: t10.track, type: F.R.SmartPreview, additional: e10 }]) : this.contextData.meta ? Promise.resolve([{ meta: this.contextData.meta, type: F.R.Unknown, additional: e10 }]) : this.loadContextMeta().then((t10) => [{ meta: t10, type: F.R.Unknown, additional: e10 }]);
        }
        get type() {
          return this.contextData.type;
        }
        get data() {
          return this.contextData;
        }
        constructor(e10) {
          super(e10), (0, w._)(this, "contextData", void 0), (0, w._)(this, "tracksResource", void 0), (0, w._)(this, "variables", void 0);
          let { data: t10, tracksResource: a10, variables: r10 } = e10;
          this.tracksResource = a10, this.contextData = t10, this.from = t10.from, this.utmLink = t10.utmLink, this.variables = r10;
        }
      }
      class eD extends W.t {
        constructor(e10, { code: t10 = "E_CONTEXT_FACTORY", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "ContextFactoryException"), Object.setPrototypeOf(this, eD.prototype);
        }
      }
      var eA = a(59553);
      let ex = (e10) => [{ type: F.R.Generative, meta: e10 }], eL = "E_GENERATIVE_RESTART_LIMIT", eR = "E_GENERATIVE_RESTART_FAILED";
      class eN extends er {
        apply(e10) {
          let { hooks: t10, playback: a10 } = e10;
          a10.state.playerState.status.onChange((e11) => {
            this.isCurrentContext && e11 && (e11 === M.MT.PLAYING ? (this.isPaused && this.sendFeedback(eA.Q.StreamPlay, a10), this.isPaused = false) : e11 === M.MT.PAUSED && (this.sendFeedback(eA.Q.StreamPause, a10), this.isPaused = true));
          }), t10.afterError.tap("GenerativeContext", (e11) => {
            let t11 = e11 && e11 instanceof ea && e11.code === eL, r10 = e11 && e11 instanceof ea && e11.code === eR;
            !t11 && !r10 && this.isCurrentContext && (this.restartsCount >= 5 || this.restart(a10));
          });
        }
        loadContextMeta() {
          return this.rotorResource.getGenerativeInfo({ stationId: String(this.contextData.meta.id) }).then((e10) => {
            let t10 = { id: String(this.contextData.meta.id), stream: e10.stream, ...e10.data };
            return this.contextData.meta = t10, t10;
          }).catch((e10) => {
            throw new ea("Error GenerativeContext", {
              code: "E_GENERATIVE_LOAD_CONTEXT_META",
              cause: (0, N.createObjectFromError)(e10),
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        getContextEntitiesData() {
          var e10;
          return (null == (e10 = this.contextData.meta.stream) ? void 0 : e10.id) ? Promise.resolve(ex(this.contextData.meta)) : this.loadContextMeta().then((e11) => Promise.resolve(ex(e11)));
        }
        get type() {
          return this.contextData.type;
        }
        get data() {
          return this.contextData;
        }
        sendFeedback(e10, t10) {
          var a10;
          return this.rotorResource.stationFeedback({
            type: e10,
            stationId: String(this.contextData.meta.id),
            streamId: String(null == (a10 = this.contextData.meta.stream) ? void 0 : a10.id),
            timestamp: eE()
          }).then((a11) => {
            if (a11.reload_stream) {
              let a12 = e10 === eA.Q.TimestampDislike;
              this.restart(t10, a12);
            }
          });
        }
        restart(e10) {
          let t10 = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          if (this.restartsCount >= 5) {
            let t11 = new ea("Error GenerativeContext", { code: eL, data: { contextId: this.contextData.meta.id } });
            return e10.hooks.afterError.promise(t11), Promise.reject(t11);
          }
          return this.restartsCount++, this.loadContextMeta().then(() => {
            let a10 = t10 || !this.isPaused;
            return t10 && this.isPaused && (this.isPaused = false), e10.restartContext({ playAfterRestart: a10, entitiesData: ex(this.contextData.meta) });
          }).catch((t11) => {
            let a10 = new ea("Error GenerativeContext restart", {
              code: eR,
              cause: (0, N.createObjectFromError)(t11),
              data: { contextId: this.contextData.meta.id, restartsCount: this.restartsCount }
            });
            throw e10.hooks.afterError.promise(a10), a10;
          });
        }
        constructor(e10) {
          super(e10), (0, w._)(this, "contextData", void 0), (0, w._)(this, "rotorResource", void 0), (0, w._)(this, "isPaused", false), (0, w._)(this, "variables", void 0), (0, w._)(this, "restartsCount", 0);
          let { data: t10, variables: a10, rotorResource: r10 } = e10;
          this.rotorResource = r10, this.contextData = t10, this.from = t10.from, this.utmLink = t10.utmLink, this.availableActions.repeat.value = false, this.availableActions.shuffle.value = false, this.availableActions.moveBackward.value = false, this.availableActions.moveForward.value = false, this.variables = a10;
        }
      }
      let ew = (e10) => [{ type: F.R.Radio, meta: e10 }];
      class eM extends er {
        apply(e10) {
        }
        loadContextMeta() {
          return Promise.all([
            this.radioStationsResource.getStreamBySlug({
              stationSlug: String(this.contextData.meta.stationSlug),
              streamSlug: String(this.contextData.meta.streamSlug)
            }),
            this.radioStationsResource.getStreamUrlBySlug({
              stationSlug: String(this.contextData.meta.stationSlug),
              streamSlug: String(this.contextData.meta.streamSlug)
            })
          ]).then((e10) => {
            let [t10, { url: a10, episodeId: r10 }] = e10, i2 = {
              id: this.contextData.meta.id,
              stationSlug: String(this.contextData.meta.stationSlug),
              streamSlug: String(this.contextData.meta.streamSlug),
              stream: t10,
              streamUrl: a10,
              streamEpisodeId: r10
            };
            return this.contextData.meta = i2, i2;
          }).catch((e10) => {
            throw new ea("Error RadioContext", {
              code: "E_RADIO_LOAD_CONTEXT_META",
              cause: (0, N.createObjectFromError)(e10),
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        getContextEntitiesData() {
          var e10, t10;
          return (null == (t10 = this.contextData.meta) || null == (e10 = t10.stream) ? void 0 : e10.slug) ? Promise.resolve(ew(this.contextData.meta)) : this.loadContextMeta().then((e11) => Promise.resolve(ew(e11)));
        }
        get type() {
          return this.contextData.type;
        }
        get data() {
          return this.contextData;
        }
        constructor(e10) {
          super(e10), (0, w._)(this, "contextData", void 0), (0, w._)(this, "radioStationsResource", void 0), (0, w._)(this, "variables", void 0);
          let { data: t10, variables: a10, radioStationsResource: r10 } = e10;
          this.radioStationsResource = r10, this.contextData = t10, this.from = t10.from, this.utmLink = t10.utmLink, this.availableActions.repeat.value = false, this.availableActions.shuffle.value = false, this.availableActions.moveBackward.value = false, this.availableActions.moveForward.value = false, this.variables = a10;
        }
      }
      let eO = (e10) => [{ type: F.R.Radio, meta: e10 }];
      class eF extends er {
        apply(e10) {
        }
        loadContextMeta() {
          return this.radioStreamResource.getByRadioId({ radioId: String(this.contextData.meta.id) }).then((e10) => {
            let t10 = { id: String(this.contextData.meta.id), ...e10 };
            return this.contextData.meta = t10, t10;
          }).catch((e10) => {
            throw new ea("Error RadioContext", {
              code: "E_RADIO_LOAD_CONTEXT_META",
              cause: (0, N.createObjectFromError)(e10),
              data: { contextId: this.contextData.meta.id }
            });
          });
        }
        getContextEntitiesData() {
          var e10;
          return (null == (e10 = this.contextData.meta) ? void 0 : e10.uuid) ? Promise.resolve(eO(this.contextData.meta)) : this.loadContextMeta().then((e11) => Promise.resolve(eO(e11)));
        }
        get type() {
          return this.contextData.type;
        }
        get data() {
          return this.contextData;
        }
        constructor(e10) {
          super(e10), (0, w._)(this, "contextData", void 0), (0, w._)(this, "radioStreamResource", void 0), (0, w._)(this, "isPaused", false), (0, w._)(this, "restartsCount", 0), (0, w._)(this, "variables", void 0);
          let { data: t10, variables: a10, radioStreamResource: r10 } = e10;
          this.radioStreamResource = r10, this.contextData = t10, this.from = t10.from, this.utmLink = t10.utmLink, this.availableActions.repeat.value = false, this.availableActions.shuffle.value = false, this.availableActions.moveBackward.value = false, this.availableActions.moveForward.value = false, this.variables = a10;
        }
      }
      class eG {
        create(e10) {
          let t10 = null, { data: a10 } = e10;
          try {
            var r10, i2, s2, n2, l2, o2, d2, u2;
            switch (a10.type) {
              case J.K.Album:
                if (!this.albumsResource)
                  throw new eD("Albums resource is not provided", {
                    code: "E_ALBUMS_RESOURCE_NOT_PROVIDED",
                    data: { type: a10.type, meta: a10.meta }
                  });
                t10 = new es({
                  data: a10,
                  albumsResource: this.albumsResource,
                  logger: this.logger,
                  variables: null == (r10 = this.variables) ? void 0 : r10[J.K.Album]
                });
                break;
              case J.K.Playlist:
                if (!this.usersResource || !this.playlistResource)
                  throw new eD("Users and playlist resources are not provided", {
                    code: "E_USERS_AND_PLAYLIST_RESOURCES_NOT_PROVIDED",
                    data: { type: a10.type, meta: a10.meta }
                  });
                t10 = new el({
                  data: a10,
                  usersResource: this.usersResource,
                  playlistResource: this.playlistResource,
                  logger: this.logger,
                  variables: null == (i2 = this.variables) ? void 0 : i2[J.K.Playlist]
                });
                break;
              case J.K.Artist:
                if (!this.artistsResource)
                  throw new eD("Artists resource is not provided", {
                    code: "E_ARTISTS_RESOURCE_NOT_PROVIDED",
                    data: { type: a10.type, meta: a10.meta }
                  });
                t10 = new eo({
                  data: a10,
                  artistsResource: this.artistsResource,
                  logger: this.logger,
                  variables: null == (s2 = this.variables) ? void 0 : s2[J.K.Artist]
                });
                break;
              case J.K.Vibe:
                if (!this.rotorResource)
                  throw new eD("Rotor resource is not provided", {
                    code: "E_ROTOR_RESOURCE_NOT_PROVIDED",
                    data: { type: a10.type, meta: a10.meta }
                  });
                t10 = new eC({
                  data: a10,
                  rotorResource: this.rotorResource,
                  logger: this.logger,
                  variables: null == (n2 = this.variables) ? void 0 : n2[J.K.Vibe]
                });
                break;
              case J.K.Various:
                if (!this.tracksResource)
                  throw new eD("Tracks resource is not provided", {
                    code: "E_TRACKS_RESOURCE_NOT_PROVIDED",
                    data: { type: a10.type, meta: a10.meta }
                  });
                t10 = new eT({
                  data: a10,
                  tracksResource: this.tracksResource,
                  logger: this.logger,
                  variables: null == (l2 = this.variables) ? void 0 : l2[J.K.Various]
                });
                break;
              case J.K.Generative:
                if (!this.rotorResource)
                  throw new eD("Rotor resource is not provided", {
                    code: "E_ROTOR_RESOURCE_NOT_PROVIDED",
                    data: { type: a10.type, meta: a10.meta }
                  });
                t10 = new eN({
                  data: a10,
                  rotorResource: this.rotorResource,
                  logger: this.logger,
                  variables: null == (o2 = this.variables) ? void 0 : o2[J.K.Generative]
                });
                break;
              case J.K.Radio:
                if (!this.radioStationsResource)
                  throw new eD("Radio stations resource is not provided", {
                    code: "E_RADIO_STATIONS_RESOURCE_NOT_PROVIDED",
                    data: { type: a10.type, meta: a10.meta }
                  });
                t10 = new eM({
                  data: a10,
                  radioStationsResource: this.radioStationsResource,
                  logger: this.logger,
                  variables: null == (d2 = this.variables) ? void 0 : d2[J.K.Radio]
                });
                break;
              case J.K.LegacyRadio:
                if (!this.radioStreamResource)
                  throw new eD("Radio stream resource is not provided", {
                    code: "E_RADIO_STREAM_RESOURCE_NOT_PROVIDED",
                    data: { type: a10.type, meta: a10.meta }
                  });
                t10 = new eF({
                  data: a10,
                  radioStreamResource: this.radioStreamResource,
                  logger: this.logger,
                  variables: null == (u2 = this.variables) ? void 0 : u2[J.K.LegacyRadio]
                });
            }
          } catch (e11) {
            throw new eD("Error while creating context", {
              cause: (0, N.createObjectFromError)(e11),
              data: { type: a10.type, meta: a10.meta }
            });
          }
          if (null !== t10) return t10;
          throw new eD("Cannot create context with nonexistent type", {
            code: "E_NONEXISTENT_CONTEXT_TYPE",
            data: { type: a10.type, meta: a10.meta }
          });
        }
        constructor(e10) {
          (0, w._)(this, "logger", void 0), (0, w._)(this, "variables", void 0), (0, w._)(this, "albumsResource", void 0), (0, w._)(this, "usersResource", void 0), (0, w._)(this, "artistsResource", void 0), (0, w._)(this, "rotorResource", void 0), (0, w._)(this, "tracksResource", void 0), (0, w._)(this, "playlistResource", void 0), (0, w._)(this, "radioStationsResource", void 0), (0, w._)(this, "radioStreamResource", void 0);
          let {
            variables: t10,
            logger: a10,
            rotorResource: r10,
            usersResource: i2,
            playlistResource: s2,
            tracksResource: n2,
            albumsResource: l2,
            artistsResource: o2,
            radioStreamResource: d2,
            radioStationsResource: u2
          } = e10;
          this.albumsResource = null != l2 ? l2 : null, this.artistsResource = null != o2 ? o2 : null, this.rotorResource = null != r10 ? r10 : null, this.usersResource = null != i2 ? i2 : null, this.tracksResource = null != n2 ? n2 : null, this.playlistResource = null != s2 ? s2 : null, this.radioStationsResource = null != u2 ? u2 : null, this.radioStreamResource = null != d2 ? d2 : null, this.variables = t10, this.logger = a10;
        }
      }
      var eK = a(70140), ej = a(47719);
      function eX(e10) {
        return !!(0, eK.i)(e10) && !!e10.data.meta.session && e10.data.meta.session.wave.type === ej.y.MIX;
      }
      var eB = a(66570);
      class eV {
        set positionSec(e10) {
          this.internalPositionSec = e10;
        }
        get positionSec() {
          return void 0 !== this.internalPositionSec ? this.internalPositionSec : eX(this.context) && "mixFade" in this.entity.data.meta && void 0 !== this.entity.data.meta.mixFade ? this.entity.data.meta.mixFade.inStart : void 0;
        }
        get canBePlayedOnlyWithCrossing() {
          return eX(this.context);
        }
        canBePlayed(e10) {
          let t10 = "playDisliked" in this.context.data && void 0 !== this.context.data.playDisliked && this.context.data.playDisliked, { entityChangeMethod: a10, index: r10 } = e10, i2 = t10 || a10 === M.So.SET_INDEX || a10 === M.So.PLAY_CONTEXT && void 0 !== r10, s2 = a10 === M.So.SET_INDEX, n2 = !i2 && this.entity.isDisliked, l2 = !s2 && this.entity.hidden, o2 = (0, eK.i)(this.context) || !this.entity.isExplicit || false !== e10.filterParams.allowExplicit;
          return !!(this.entity.isAvailable && o2) && (n2 ? !!(0, eK.i)(this.context) : !l2);
        }
        getCrossParams() {
          return eX(this.context) && "mixFade" in this.entity.data.meta && void 0 !== this.entity.data.meta.mixFade ? this.entity.data.meta.mixFade : "fade" in this.entity.data.meta && void 0 !== this.entity.data.meta.fade ? this.entity.data.meta.fade : null;
        }
        canBeCrossedWith(e10) {
          return !(!("type" in this.entity.data.meta) || !("type" in e10.entity.data.meta) || !("fade" in this.entity.data.meta) || !("fade" in e10.entity.data.meta) || (0, eB.F)(this.context)) && this.entity.data.meta.type === O.S.MUSIC && e10.entity.data.meta.type === O.S.MUSIC && void 0 !== this.entity.data.meta.fade && void 0 !== e10.entity.data.meta.fade;
        }
        getFadeMode() {
          return eX(this.context) && "mixFade" in this.entity.data.meta && void 0 !== this.entity.data.meta.mixFade ? M.OQ.MIX : !("type" in this.entity.data.meta) || !("fade" in this.entity.data.meta) || (0, eB.F)(this.context) || this.entity.data.meta.type !== O.S.MUSIC || void 0 === this.entity.data.meta.fade ? M.OQ.NONE : M.OQ.CROSSFADE;
        }
        constructor(e10, t10, a10) {
          (0, w._)(this, "context", void 0), (0, w._)(this, "entity", void 0), (0, w._)(this, "lastChangeMethod", null), (0, w._)(this, "lastSeekPosition", void 0), (0, w._)(this, "internalPositionSec", void 0), (0, w._)(this, "sourceContext", void 0), this.context = e10, this.entity = t10, this.sourceContext = a10;
        }
      }
      class eU {
        createContext(e10) {
          return this.contextFactory.create(e10);
        }
        createEntity(e10) {
          return this.entityFactory.create(e10);
        }
        createContextEntityPair(e10, t10, a10) {
          return new eV(e10, t10, a10);
        }
        constructor(e10) {
          (0, w._)(this, "entityFactory", void 0), (0, w._)(this, "contextFactory", void 0), this.entityFactory = new Z(e10.entityFactoryParams), this.contextFactory = new eG(e10.contextFactoryParams);
        }
      }
      var eq = a(60463), eW = a(95167);
      class eY {
        getAverageFrequencies(e10) {
          if (null === this.currentGraph) return [];
          let { analyserNode: t10, spectrum: a10, bufferLength: r10, context: i2 } = this.currentGraph;
          if (!t10) throw new W.t("No analyser node has been created");
          t10.getByteFrequencyData(a10);
          let s2 = i2.sampleRate / r10, n2 = 0, l2 = e10.map((e11) => {
            let { low: t11, high: a11 } = e11, r11 = Math.floor(t11 / s2), i3 = Math.floor(a11 / s2);
            return n2 = Math.max(n2, i3), { startIndex: r11, endIndex: i3 };
          }), o2 = Array(n2 + 2).fill(0);
          for (let e11 = 0; e11 < n2 + 1; e11++) {
            var d2, u2;
            let t11 = (null != (d2 = a10[e11]) ? d2 : 0) / 256;
            o2[e11 + 1] = (null != (u2 = o2[e11]) ? u2 : 0) + t11;
          }
          return l2.map((e11) => {
            let { startIndex: t11, endIndex: a11 } = e11, r11 = o2[t11], i3 = o2[a11 + 1];
            return void 0 === r11 || void 0 === i3 ? 0 : (i3 - r11) / (a11 - t11 + 1);
          });
        }
        constructor({ currentAudioElement: e10, graphs: t10 }) {
          (0, w._)(this, "currentGraph", null), (0, w._)(this, "graphs", void 0), this.graphs = t10, e10.onChange((e11) => {
            let t11 = this.graphs.find((t12) => t12.audioElement === e11);
            t11 && (this.currentGraph = t11);
          });
        }
      }
      !(function(e10) {
        e10.IDLE = "IDLE", e10.ENABLED = "ENABLED", e10.DISABLED = "DISABLED";
      })(i || (i = {}));
      class ez {
        enable() {
          this.state !== i.ENABLED && (this.graphs.forEach((e10) => {
            e10.connectEqualizer();
          }), this.state = i.ENABLED);
        }
        disable() {
          this.state !== i.DISABLED && (this.graphs.forEach((e10) => {
            e10.disconnectEqualizer();
          }), this.state = i.DISABLED);
        }
        applyPreset(e10) {
          this.graphs.forEach((t10) => {
            t10.setPreamp(e10.preamp), t10.setBands(e10.frequencies);
          });
        }
        constructor({ preset: e10, graphs: t10 }) {
          (0, w._)(this, "graphs", void 0), (0, w._)(this, "state", i.DISABLED), this.graphs = t10, e10 && this.applyPreset(e10);
        }
      }
      var eH = /* @__PURE__ */ (function(e10, t10, a10) {
        var r10;
        return function(t11) {
          var a11, i2, s2;
          return new Worker(
            r10 = r10 || (i2 = (a11 = atob(e10)).indexOf("\n", 10) + 1, s2 = new Blob([a11.substring(i2) + ""], { type: "application/javascript" }), URL.createObjectURL(s2)),
            t11
          );
        };
      })(
        "Lyogcm9sbHVwLXBsdWdpbi13ZWItd29ya2VyLWxvYWRlciAqLwooZnVuY3Rpb24gKCkgewogICAgJ3VzZSBzdHJpY3QnOwoKICAgIGxldCB0aW1lciA9IG51bGw7CiAgICBmdW5jdGlvbiBvbk1lc3NhZ2UoZSkgewogICAgICAgIHN3aXRjaCAoZS5kYXRhLmNvbW1hbmQpIHsKICAgICAgICAgICAgY2FzZSAnc3RhcnQnOgogICAgICAgICAgICAgICAgc3RhcnQoZS5kYXRhLmludGVydmFsKTsKICAgICAgICAgICAgICAgIGJyZWFrOwogICAgICAgICAgICBjYXNlICdzdG9wJzoKICAgICAgICAgICAgICAgIHN0b3AoKTsKICAgICAgICAgICAgICAgIGJyZWFrOwogICAgICAgIH0KICAgIH0KICAgIGZ1bmN0aW9uIHN0YXJ0KGludGVydmFsKSB7CiAgICAgICAgc3RvcCgpOwogICAgICAgIHRpbWVyID0gc2VsZi5zZXRJbnRlcnZhbCgoKSA9PiB7CiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSB7CiAgICAgICAgICAgICAgICBtZXNzYWdlOiAndGljaycKICAgICAgICAgICAgfTsKICAgICAgICAgICAgc2VsZi5wb3N0TWVzc2FnZShkYXRhKTsKICAgICAgICB9LCBpbnRlcnZhbCk7CiAgICB9CiAgICBmdW5jdGlvbiBzdG9wKCkgewogICAgICAgIGlmICh0aW1lciAhPT0gbnVsbCkgewogICAgICAgICAgICBzZWxmLmNsZWFySW50ZXJ2YWwodGltZXIpOwogICAgICAgIH0KICAgICAgICB0aW1lciA9IG51bGw7CiAgICB9CiAgICBzZWxmLmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCBvbk1lc3NhZ2UpOwoKfSkoKTsK"
      );
      class eQ {
        init() {
          try {
            return this.worker = new eH(), this.worker.addEventListener("message", this.onMessage.bind(this)), Promise.resolve();
          } catch (e10) {
            return this.destroy(), Promise.reject(e10);
          }
        }
        get isIntervalRunning() {
          return this.isTrackingInWorker;
        }
        setInterval(e10, t10) {
          this.worker && (this.callback = e10, this.isTrackingInWorker = true, this.worker.postMessage({ command: "start", interval: t10 }));
        }
        clearInterval() {
          this.worker && (this.isTrackingInWorker = false, this.worker.postMessage({ command: "stop" }));
        }
        onError(e10) {
          this.worker && (this.errorListeners.push(e10), this.worker.addEventListener("error", e10), this.worker.addEventListener("messageerror", e10));
        }
        destroy() {
          var e10;
          this.clearInterval(), this.errorListeners.forEach((e11) => {
            var t10, a10;
            null == (t10 = this.worker) || t10.removeEventListener("error", e11), null == (a10 = this.worker) || a10.removeEventListener("messageerror", e11);
          }), null == (e10 = this.worker) || e10.terminate(), this.worker = null;
        }
        onMessage(e10) {
          "tick" === e10.data.message && this.callback && this.callback();
        }
        constructor() {
          (0, w._)(this, "worker", null), (0, w._)(this, "callback", null), (0, w._)(this, "isTrackingInWorker", false), (0, w._)(this, "errorListeners", []);
        }
      }
      class e$ {
        get isIntervalRunning() {
          return !!this.intervalId;
        }
        init() {
          return Promise.resolve();
        }
        onError() {
        }
        setInterval(e10, t10) {
          this.intervalId = setInterval(e10, t10);
        }
        clearInterval() {
          null !== this.intervalId && clearInterval(this.intervalId), this.intervalId = null;
        }
        destroy() {
          this.clearInterval();
        }
        constructor() {
          (0, w._)(this, "intervalId", null);
        }
      }
      class eZ {
        get isIntervalRunning() {
          return !!this.ticker.isIntervalRunning;
        }
        init() {
          return this.ticker.init().catch((e10) => {
            throw this.ticker = new e$(), Error("Error in creating WorkerTicker. Fallback to IntervalTicker", { cause: e10 });
          });
        }
        onError(e10) {
          return this.ticker.onError(e10);
        }
        setInterval(e10, t10) {
          return this.ticker.setInterval(e10, t10);
        }
        clearInterval() {
          return this.ticker.clearInterval();
        }
        destroy() {
          this.ticker.destroy();
        }
        constructor() {
          (0, w._)(this, "ticker", new eQ());
        }
      }
      !(function(e10) {
        e10.IDLE = "IDLE", e10.ENABLED = "ENABLED", e10.DISABLED = "DISABLED";
      })(s || (s = {}));
      let eJ = 1e3 / 60, e0 = 1 / 60;
      class e1 {
        updateGain() {
          if (this.state !== s.ENABLED) return;
          let e10 = this.graph.audioElement.currentTime, t10 = e10 >= this.inStart && e10 <= this.inStop, a10 = e10 >= this.outStart && e10 <= this.outStop;
          if (t10) {
            let t11 = this.getFadeInVolume(e10);
            this.volumeAtTime = t11;
          }
          if (a10) {
            let e11 = this.getFadeOutVolume();
            this.volumeAtTime = e11;
          }
          e10 > this.inStop && e10 < this.outStart && (this.volumeAtTime = this.maxVolume), e10 > this.outStop && (this.volumeAtTime = 0);
        }
        enable() {
          this.volume = 0, this.state = s.ENABLED, this.ticker.isIntervalRunning || this.ticker.setInterval(this.updateGain.bind(this), eJ);
        }
        enableFadeIn() {
          this.audioElementVolumeBeforeFadeIn = this.graph.audioElement.volume, this.volume = 0, this.state = s.ENABLED, this.ticker.isIntervalRunning || this.ticker.setInterval(this.fadeIn.bind(this), eJ);
        }
        fadeIn() {
          if (this.state !== s.ENABLED) return;
          let e10 = this.graph.audioElement.currentTime, t10 = e10 >= this.inStart && e10 <= this.inStop, a10 = this.getFadeInVolume(e10);
          t10 && (this.volumeAtTime = a10), e10 > this.inStop && e10 < this.outStart && (this.volumeAtTime = this.maxVolume, this.disable());
        }
        enableFadeOut() {
          this.state = s.ENABLED, this.ticker.isIntervalRunning || this.ticker.setInterval(this.fadeOut.bind(this), eJ);
        }
        fadeOut() {
          if (this.state !== s.ENABLED) return;
          let e10 = this.graph.audioElement.currentTime, t10 = e10 >= this.outStart && e10 <= this.outStop, a10 = this.getFadeOutVolume();
          t10 && (this.volumeAtTime = a10), e10 > this.outStop && (this.volumeAtTime = 0);
        }
        getFadeInVolume(e10) {
          let t10 = this.inStop - this.inStart, a10 = this.maxVolume;
          return 0 === e10 ? 0 : Math.min(this.volume + 1 / (t10 / e0), a10);
        }
        getFadeOutVolume() {
          let e10 = this.outStop - this.outStart;
          return Math.max(this.volume - 1 / (e10 / e0), 0);
        }
        disable() {
          this.state = s.DISABLED, this.ticker.clearInterval(), this.volume = this.maxVolume;
        }
        setFadeParams(e10) {
          let { inStart: t10, inStop: a10, outStart: r10, outStop: i2 } = e10;
          this.inStart = t10, this.inStop = a10, this.outStart = r10, this.outStop = i2;
        }
        set volumeAtTime(e10) {
          this.config.useVolumeForAudioEffect ? this.graph.audioElement.volume = e10 : this.graph.gainNode.gain.setValueAtTime(e10, this.graph.context.currentTime);
        }
        set volume(e10) {
          this.config.useVolumeForAudioEffect ? this.graph.audioElement.volume = e10 : this.graph.gainNode.gain.value = e10;
        }
        get volume() {
          return this.config.useVolumeForAudioEffect ? this.graph.audioElement.volume : this.graph.gainNode.gain.value;
        }
        get maxVolume() {
          if (this.config.useVolumeForAudioEffect) {
            var e10;
            return null != (e10 = this.audioElementVolumeBeforeFadeIn) ? e10 : 1;
          }
          return 1;
        }
        handleTickerError(e10) {
          this.disable();
          let t10 = new W.t("FadeEffect. Error in ticker runtime.", { cause: (0, N.createObjectFromError)(e10) });
          this.hooks.afterError.promise(t10);
        }
        constructor({ graph: e10, hooks: t10, config: a10 }) {
          var r10, i2;
          (0, w._)(this, "state", s.IDLE), (0, w._)(this, "inStart", 0), (0, w._)(this, "inStop", 0), (0, w._)(this, "outStart", 0), (0, w._)(this, "outStop", 0), (0, w._)(this, "ticker", void 0), (0, w._)(this, "graph", void 0), (0, w._)(this, "hooks", void 0), (0, w._)(this, "config", void 0), (0, w._)(this, "audioElementVolumeBeforeFadeIn", null), this.graph = e10, this.hooks = t10, this.config = {
            useVolumeForAudioEffect: null != (r10 = a10.useVolumeForAudioEffect) && r10,
            useWorker: null == (i2 = a10.useWorker) || i2
          }, this.config.useWorker ? this.ticker = new eZ() : this.ticker = new e$(), this.ticker.init().then(() => {
            this.ticker.onError(this.handleTickerError.bind(this));
          }).catch((e11) => {
            let t11 = new W.t("FadeEffect. Error in ticker init().", { cause: (0, N.createObjectFromError)(e11) });
            this.hooks.afterError.promise(t11);
          });
        }
      }
      class e3 {
        enable() {
          this.currentFadeEffect && this.currentFadeEffect.enable();
        }
        disable() {
          this.currentFadeEffect && this.currentFadeEffect.disable();
        }
        apply(e10) {
          if (this.currentFadeEffect) {
            if (!e10) return void this.currentFadeEffect.disable();
            this.currentFadeEffect.setFadeParams(e10), this.currentFadeEffect.enable();
          }
        }
        constructor({ currentAudioElement: e10, graphs: t10, playback: a10 }) {
          (0, w._)(this, "fadeEffects", []), (0, w._)(this, "currentFadeEffect", null), t10.forEach((e11) => {
            this.fadeEffects.push(
              new e1({ graph: e11, hooks: a10.hooks, config: { useVolumeForAudioEffect: false, useWorker: false } })
            );
          }), e10.onChange((e11) => {
            let t11 = this.fadeEffects.find((t12) => t12.graph.audioElement === e11);
            t11 && (this.currentFadeEffect = t11);
          });
        }
      }
      class e2 {
        enableCrossfade() {
          let { currentEntity: e10, nextEntity: t10 } = this.playback.state.queueState, a10 = this.playback.state.mediaPlayersStore.value[K.e.AUDIO];
          if (!e10.value || !t10.value || !a10 || !(0, M.uo)(a10)) return;
          let r10 = e10.value.getCrossParams(), i2 = t10.value.getCrossParams();
          if (!r10 || !i2) return;
          let s2 = this.fadeEffects.find(
            (e11) => !!a10.crossOutMediaPlayer && e11.graph.audioElement === a10.crossOutMediaPlayer.currentAudioElement.value
          ), n2 = this.fadeEffects.find(
            (e11) => !!a10.crossInMediaPlayer && e11.graph.audioElement === a10.crossInMediaPlayer.currentAudioElement.value
          );
          s2 && n2 && (s2.setFadeParams(r10), n2.setFadeParams(i2), s2.enableFadeOut(), n2.enableFadeIn());
        }
        enableFastFade() {
          let { currentEntity: e10 } = this.playback.state.queueState, t10 = this.playback.state.mediaPlayersStore.value[K.e.AUDIO];
          if (!e10.value || !t10 || !(0, M.uo)(t10)) return;
          let a10 = e10.value.getCrossParams(), r10 = this.fadeEffects.find((e11) => e11.graph.audioElement === t10.currentAudioElement.value);
          if (!a10 || !r10) return;
          let i2 = a10.inStop - a10.inStart, s2 = { ...a10, inStop: a10.inStart + i2 / 4 };
          r10.setFadeParams(s2), r10.enableFadeIn();
        }
        disableFade() {
          this.fadeEffects.forEach((e10) => {
            e10.disable();
          });
        }
        canEnableFastFade(e10) {
          let { currentEntity: t10 } = this.playback.state.queueState;
          return !!(t10.value && !e10 && eX(t10.value.context));
        }
        constructor({ graphs: e10, playback: t10, config: a10 = {} }) {
          (0, w._)(this, "playback", void 0), (0, w._)(this, "fadeEffects", []), this.playback = t10, e10.forEach((e11) => {
            this.fadeEffects.push(
              new e1({
                graph: e11,
                hooks: t10.hooks,
                config: { useVolumeForAudioEffect: a10.useVolumeForAudioEffect, useWorker: a10.useWorker }
              })
            );
          });
          let r10 = t10.state.mediaPlayersStore.value[K.e.AUDIO];
          r10 && (0, M.uo)(r10) && (r10.isReadyForAudioEffect.onChange(
            (e11) => {
              e11 ? this.enableCrossfade() : this.disableFade();
            },
            { skipFirstChange: true }
          ), r10.isReadyForAudioEffectInStart.onChange(
            (e11) => {
              e11 && this.canEnableFastFade(r10.isReadyForAudioEffect.value) && this.enableFastFade(), e11 || this.disableFade();
            },
            { skipFirstChange: true }
          ));
        }
      }
      class e4 {
        apply(e10) {
          this.durationMs = e10;
        }
        constructor({ playback: e10 }) {
          (0, w._)(this, "playback", null), (0, w._)(this, "durationMs", void 0), this.playback = e10, this.playback.state.playerState.progress.onChange((e11) => {
            var t10, a10;
            let r10 = (null != (t10 = this.durationMs) ? t10 : 0) / 1e3, i2 = e11 && Math.abs(e11.duration - r10) > 1;
            e11 && e11.position > r10 && i2 && (null == (a10 = this.playback) || a10.moveForward());
          });
        }
      }
      !(function(e10) {
        e10.HIGHSHELF = "highshelf", e10.PEAKING = "peaking", e10.LOWSHELF = "lowshelf";
      })(n || (n = {})), (function(e10) {
        e10.SUSPENDED = "suspended", e10.RUNNING = "running", e10.CLOSED = "closed";
      })(l || (l = {}));
      class e6 {
        connectNodes() {
          let { useAnalyser: e10, useGain: t10 } = this.config;
          t10 && e10 && (this.sourceNode.connect(this.gainNode), this.gainNode.connect(this.analyserNode), this.analyserNode.connect(this.context.destination)), t10 && !e10 && (this.sourceNode.connect(this.gainNode), this.gainNode.connect(this.context.destination)), !t10 && e10 && (this.sourceNode.connect(this.analyserNode), this.analyserNode.connect(this.context.destination)), t10 || e10 || this.sourceNode.connect(this.context.destination);
        }
        connectEqualizer() {
          let { useAnalyser: e10, useGain: t10 } = this.config, a10 = this.bands[this.bands.length - 1];
          a10 && (this.sourceNode.disconnect(), this.sourceNode.connect(this.preamp), t10 && a10.connect(this.gainNode), !t10 && e10 && a10.connect(this.analyserNode), t10 || e10 || a10.connect(this.context.destination));
        }
        disconnectEqualizer() {
          let { useAnalyser: e10, useGain: t10 } = this.config, a10 = this.bands[this.bands.length - 1];
          a10 && (this.sourceNode.disconnect(), a10.disconnect(), t10 && this.sourceNode.connect(this.gainNode), !t10 && e10 && this.sourceNode.connect(this.analyserNode), t10 || e10 || this.sourceNode.connect(this.context.destination));
        }
        setBands(e10) {
          0 === this.bands.length ? this.bands = this.connectBandsBetween(this.createBandsByFrequencies(e10)) : this.updateBands(e10);
        }
        setPreamp(e10) {
          this.preamp.gain.linearRampToValueAtTime(e10, this.context.currentTime + 0.3);
        }
        createBandsByFrequencies(e10) {
          return e10.map((t10, a10) => {
            let { key: r10, value: i2 } = t10;
            return this.createBand(this.getBiquadFilterType(a10, e10.length), r10, i2);
          });
        }
        createBand(e10, t10, a10) {
          let r10 = this.context.createBiquadFilter();
          return r10.type = e10, r10.frequency.value = t10, r10.Q.value = 1, a10 && r10.gain.setValueAtTime(a10, this.context.currentTime + 0.3), r10;
        }
        getBiquadFilterType(e10, t10) {
          return 0 === e10 ? n.LOWSHELF : e10 === t10 - 1 ? n.HIGHSHELF : n.PEAKING;
        }
        connectBandsBetween(e10) {
          let t10 = this.preamp;
          return e10.forEach((e11) => {
            t10.connect(e11), t10 = e11;
          }), e10;
        }
        updateBands(e10) {
          this.bands.forEach((t10, a10) => {
            let r10 = e10[a10];
            r10 && t10.gain.setValueAtTime(r10.value, this.context.currentTime + 0.3);
          });
        }
        createAnalyzerNode(e10) {
          let t10 = e10.createAnalyser();
          return t10.fftSize = 32, t10.smoothingTimeConstant = 0, t10;
        }
        checkAndResumeAudioContext(e10) {
          let t10 = () => {
            e10.resume().then(() => {
              document.body.removeEventListener("touchend", t10, true), document.body.removeEventListener("click", t10, true), document.body.removeEventListener("keydown", t10, true);
            });
          };
          e10.state === l.SUSPENDED && (document.body.addEventListener("touchend", t10, true), document.body.addEventListener("click", t10, true), document.body.addEventListener("keydown", t10, true));
        }
        constructor(e10, t10) {
          (0, w._)(this, "audioElement", void 0), (0, w._)(this, "context", void 0), (0, w._)(this, "sourceNode", void 0), (0, w._)(this, "preamp", void 0), (0, w._)(this, "bands", []), (0, w._)(this, "analyserNode", void 0), (0, w._)(this, "bufferLength", 0), (0, w._)(this, "spectrum", new Uint8Array()), (0, w._)(this, "gainNode", void 0), (0, w._)(this, "config", void 0), this.audioElement = e10, this.context = new AudioContext(), this.checkAndResumeAudioContext(this.context), this.sourceNode = this.context.createMediaElementSource(this.audioElement), this.analyserNode = this.createAnalyzerNode(this.context), this.bufferLength = this.analyserNode.frequencyBinCount, this.spectrum = new Uint8Array(this.bufferLength), this.gainNode = this.context.createGain(), this.preamp = this.context.createGain(), this.config = t10, this.connectNodes();
        }
      }
      class e5 {
        get isAudioContextRequired() {
          return !!this.options.useEqualizer || !!this.options.useAnalyser || !!this.options.useFade || !!this.options.useCrossFade;
        }
        createGraphs(e10) {
          let t10 = !!this.options.useFade || !!this.options.useCrossFade;
          if ((0, M.s4)(e10))
            return [new e6(e10.currentAudioElement.value, { useAnalyser: this.options.useAnalyser, useGain: t10 })];
          if ((0, M.uo)(e10))
            return e10.audioElementsStore.map((e11) => new e6(e11, { useAnalyser: this.options.useAnalyser, useGain: t10 }));
          throw new W.t("Can not create audio graph for this type of media player");
        }
        initializeContext(e10, t10) {
          if (this.isAudioContextRequired) {
            if (this.graphs = this.createGraphs(e10), this.options.useAnalyser && (this.analyser = new eY({ currentAudioElement: e10.currentAudioElement, graphs: this.graphs })), this.options.useEqualizer) {
              let e11 = "object" == typeof this.options.useEqualizer ? this.options.useEqualizer : void 0;
              this.equalizer.value = new ez({ graphs: this.graphs, preset: null == e11 ? void 0 : e11.preset });
            }
            this.options.useFade && (this.fade = new e3({ currentAudioElement: e10.currentAudioElement, graphs: this.graphs, playback: t10 })), this.options.useCrossFade && (this.crossfade = new e2({ playback: t10, graphs: this.graphs, config: this.options.crossFadeConfig }));
          }
          this.options.useSmartPreview && (this.smartPreview = new e4({ playback: t10 }));
        }
        apply(e10) {
          let { hooks: t10, playback: a10 } = e10;
          a10.state.mediaPlayersStore.onChange((e11) => {
            if (void 0 === e11) return;
            let t11 = e11[K.e.AUDIO];
            void 0 !== t11 && ((0, M.s4)(t11) || (0, M.uo)(t11)) && this.initializeContext(t11, a10);
          }), a10.state.playerState.event.onChange(() => {
            if (this.fade)
              switch (a10.state.playerState.event.value) {
                case M.Iu.PLAYING:
                  this.fade.enable();
                  break;
                case M.Iu.PAUSED:
                case M.Iu.STOP:
                  this.fade.disable();
              }
          }), t10.beforeMediaStartPlaying.tapPromise("WebAudioPlugin", () => {
            var e11, t11, r10;
            let i2, s2, { currentEntity: n2 } = a10.state.queueState, l2 = null == (e11 = n2.value) ? void 0 : e11.entity;
            return (0, eq.l)(l2) && (i2 = null == (t11 = l2.data.meta.smartPreviewParams) ? void 0 : t11.fade, s2 = null == (r10 = l2.data.meta.smartPreviewParams) ? void 0 : r10.durationMs), (0, eW.b)(l2) && (i2 = l2.data.meta.fade, s2 = l2.data.meta.durationMs), this.fade && this.fade.apply(i2), this.smartPreview && this.smartPreview.apply(s2), Promise.resolve();
          });
        }
        constructor(e10) {
          (0, w._)(this, "options", void 0), (0, w._)(this, "graphs", []), (0, w._)(this, "analyser", void 0), (0, w._)(this, "equalizer", new et.cJ(null)), (0, w._)(this, "fade", void 0), (0, w._)(this, "smartPreview", void 0), (0, w._)(this, "crossfade", void 0), this.options = e10;
        }
      }
      function e8(e10) {
        return (null == e10 ? void 0 : e10.data.type) === F.R.Clip;
      }
      !(function(e10) {
        e10.AD = "ad", e10.SHOT = "shot";
      })(o || (o = {})), (function(e10) {
        e10.NONE = "none", e10.AD = "ad", e10.JINGLE = "jingle";
      })(d || (d = {})), (function(e10) {
        e10.NONE = "none", e10.AD = "ad", e10.JINGLE = "jingle";
      })(u || (u = {})), (function(e10) {
        e10.VIDEO = "video", e10.AUDIO = "audio";
      })(c || (c = {}));
      class e9 {
        apply(e10) {
          let { playback: t10, hooks: a10 } = e10;
          a10.beforeEntityChange.tapPromise(
            "AdvertPlugin",
            () => new Promise((e11) => {
              if (!this.variables.enabled) return void e11();
              let {
                state: {
                  currentContext: a11,
                  queueState: {
                    index: { value: r10 },
                    order: { value: i2 },
                    entityList: { value: s2 },
                    currentEntity: { value: n2 }
                  }
                }
              } = t10;
              if (void 0 !== a11.value) {
                let l2 = i2[r10 + 1], h2 = void 0 !== l2 ? s2[l2] : void 0, g2 = h2 ? String(h2.entity.data.meta.id) : void 0, y2 = i2[r10 - 1], m2 = void 0 !== y2 ? s2[y2] : void 0, p2 = m2 ? String(m2.entity.data.meta.id) : void 0, v2 = ((null == n2 ? void 0 : n2.entity.totalPlayedSeconds) || 0) / (((null == n2 ? void 0 : n2.entity.data.meta) && "durationMs" in n2.entity.data.meta && n2.entity.data.meta.durationMs || 1) / 1e3);
                this.currentTrackId = String(null == n2 ? void 0 : n2.entity.data.meta.id), this.from = a11.value.from, this.afterTrackResource.getAfterTrack({
                  contextItem: String(a11.value.data.meta.id),
                  from: a11.value.from,
                  types: o.AD,
                  nextTrackId: g2,
                  prevTrackId: p2
                }).then((a12) => {
                  var r11, i3, s3;
                  let n3 = v2 >= 0.5 && (null == (r11 = a12.ad) ? void 0 : r11.afterPlay) === d.AD || v2 < 0.5 && (null == (i3 = a12.ad) ? void 0 : i3.afterSkip) === u.AD;
                  if ("ad" in a12 && this.advertModule && n3) {
                    let r12 = e8(null == (s3 = t10.state.queueState.currentEntity.value) ? void 0 : s3.entity) ? c.VIDEO : void 0;
                    t10.pause(), this.advertModule.playAdvert({ afterTrackResponse: a12, advertType: r12 }).finally(e11);
                  } else e11();
                });
              } else e11();
            })
          );
        }
        advertFeedbackCallback() {
          this.adsResource.saveAds({ from: this.from, trackId: this.currentTrackId, type: "ad" });
        }
        constructor(e10) {
          var t10;
          (0, w._)(this, "advertModule", void 0), (0, w._)(this, "variables", void 0), (0, w._)(this, "afterTrackResource", void 0), (0, w._)(this, "adsResource", void 0), (0, w._)(this, "currentTrackId", ""), (0, w._)(this, "from", "");
          let { afterTrackResource: a10, advertModule: r10, adsResource: i2, variables: s2 } = e10;
          this.afterTrackResource = a10, this.adsResource = i2, this.variables = s2, this.advertModule = r10, null == (t10 = this.advertModule) || t10.setAdvertFeedbackCallback(this.advertFeedbackCallback.bind(this));
        }
      }
      var e7 = a(73532), te = a(89130);
      function tt(e10) {
        let t10 = e7.FM.r.PAUSE;
        switch (e10.status.value) {
          case M.MT.BUFFERING:
            t10 = e7.FM.r.BUFFERING;
            break;
          case M.MT.ENDED:
          case M.MT.STOPPED:
            t10 = e7.FM.r.END;
            break;
          case M.MT.PLAYING:
            t10 = e7.FM.r.PLAY;
            break;
          case M.MT.PAUSED:
          case M.MT.IDLE:
          case M.MT.LOADING_MEDIA_SOURCE:
            t10 = e7.FM.r.PAUSE;
        }
        return t10;
      }
      class ta {
        createTelemetry(e10) {
          this.vsid = (0, N.createVsid)(e10.playbackInitializationTime, this.playerTypeForVsid), this.telemetry = new e7.YT({
            getState: () => {
              var t10;
              let {
                progress: {
                  value: { duration: a10, position: r10, remainingBufferedTime: i2 }
                },
                volume: s2
              } = e10.state.playerState;
              return (null == (t10 = e10.state.currentContext.value) ? void 0 : t10.data.type) === J.K.Radio && e10.state.currentContext.value.data.meta.streamEpisodeId ? this.setStaticParams({ videoContentId: e10.state.currentContext.value.data.meta.streamEpisodeId }) : this.setStaticParams({ videoContentId: void 0 }), {
                duration: (0, te.fP)(a10),
                currentTime: (0, te.fP)(r10),
                utcStartTime: void 0,
                videoType: "VOD",
                isFullscreen: false,
                volume: s2.value,
                muted: 0 === s2.value,
                remainingBufferedTime: { total: (0, te.fP)(null != i2 ? i2 : 0) },
                playingState: tt(e10.state.playerState),
                videoSize: void 0,
                liveLatency: void 0,
                videoTracks: [],
                audioTrack: void 0,
                isVisible: false
              };
            },
            sendLog: (e11, t10) => {
              this.telemetryResource.log({ payload: e11, urlParams: t10 });
            },
            playerInfo: { service: this.service, version: "1.0.0", vsid: this.vsid, isVideoADB: false }
          }), this.telemetry.setStaticParams({ labels: { from: this.from } }), this.resourceTimingsMonitor = new e7.yv({
            sendLog: (e11, t10) => {
              this.telemetryResource.perfLog({ payload: e11, urlParams: t10 });
            }
          }), this.resourceTimingsMonitor.attach(window);
        }
        logEvent(e10, t10) {
          var a10;
          null == (a10 = this.telemetry) || a10.logEvent(e10, t10);
        }
        logError(e10, t10) {
          var a10;
          null == (a10 = this.telemetry) || a10.logError(e10, t10);
        }
        setPlayingState(e10) {
          var t10;
          let a10 = tt(e10);
          null == (t10 = this.telemetry) || t10.setPlayingState(a10);
        }
        setStaticParams(e10, t10) {
          var a10;
          null == (a10 = this.telemetry) || a10.setStaticParams(e10, t10);
        }
        onBeforeSetSource() {
          var e10;
          return null == (e10 = this.telemetry) ? void 0 : e10.onBeforeSetSource();
        }
        onSetSource(e10) {
          var t10;
          null == (t10 = this.telemetry) || t10.onSetSource(e10, { streams: [], params: {} });
        }
        onSeek(e10, t10) {
          var a10;
          null == (a10 = this.telemetry) || a10.onSeek({ oldPosition: e10, newPosition: t10 });
        }
        logYaspEvent(e10, t10) {
          var a10;
          null == (a10 = this.telemetry) || a10.logEvent({ name: e10, data: t10 });
        }
        logYaspError(e10) {
          var t10;
          null == (t10 = this.telemetry) || t10.logError({ error: e10.detail });
        }
        constructor({ telemetryResource: e10, service: t10, from: a10, playerTypeForVsid: r10 }) {
          (0, w._)(this, "telemetry", void 0), (0, w._)(this, "resourceTimingsMonitor", void 0), (0, w._)(this, "telemetryResource", void 0), (0, w._)(this, "from", void 0), (0, w._)(this, "service", void 0), (0, w._)(this, "playerTypeForVsid", void 0), (0, w._)(this, "vsid", void 0), this.telemetryResource = e10, this.service = t10, this.from = a10, this.playerTypeForVsid = r10;
        }
      }
      var tr = a(77220), ti = a(53676);
      class ts extends tr.X {
        async sendPlays(e10, t10) {
          return (await this.httpClient.post(
            "plays",
            this.createHttpOptions({
              timeoutKey: "sendPlays",
              params: e10,
              searchParams: (0, ti.P)({ clientNow: e10.clientNow }),
              json: { plays: e10.plays },
              signal: null == t10 ? void 0 : t10.signal
            })
          )).json();
        }
        constructor(e10, t10) {
          super(e10, t10), (0, w._)(this, "httpClient", void 0), (0, w._)(this, "config", void 0), this.httpClient = e10, this.config = t10;
        }
      }
      var tn = a(14287), tl = a(11036);
      !(function(e10) {
        e10.START = "start", e10.END = "end", e10.PLAYING = "playing", e10.PAUSE = "pause";
      })(h || (h = {}));
      var to = a(38285), td = a(82237), tu = a(82116), tc = a(48437), th = a(73477);
      let tg = (e10) => !!(e10 && "object" == typeof e10 && "playId" in e10 && "totalPlayedSeconds" in e10), ty = (e10) => {
        let t10 = [e10.find((e11) => 0 === e11.totalPlayedSeconds), (0, tu.A)(e10, "totalPlayedSeconds")];
        return (0, tc.A)(t10.filter(tg), "totalPlayedSeconds");
      };
      class tm {
        use(e10) {
          return this.middlewares.push(e10), this;
        }
        run(e10) {
          let t10 = (a10) => a10 >= this.middlewares.length ? Promise.resolve() : (0, this.middlewares[a10])(e10, () => t10(a10 + 1));
          return t10(0);
        }
        constructor() {
          (0, w._)(this, "middlewares", []);
        }
      }
      class tp {
        getResult() {
          return this.playData;
        }
        constructor(e10) {
          (0, w._)(this, "contextEntityPair", void 0), (0, w._)(this, "playType", void 0), (0, w._)(this, "totalPlayedSeconds", void 0), (0, w._)(this, "endPositionSeconds", void 0), (0, w._)(this, "dynamicData", void 0), (0, w._)(this, "hooks", void 0), (0, w._)(this, "playback", void 0), (0, w._)(this, "operation", void 0), (0, w._)(this, "clock", void 0), (0, w._)(this, "isCrossfadeEnabled", void 0), (0, w._)(this, "playData", {}), this.contextEntityPair = e10.contextEntityPair, this.playType = e10.playType, this.totalPlayedSeconds = e10.totalPlayedSeconds, this.endPositionSeconds = e10.endPositionSeconds, this.dynamicData = e10.dynamicData, this.hooks = e10.hooks, this.playback = e10.playback, this.operation = e10.operation, this.clock = e10.clock, this.isCrossfadeEnabled = e10.isCrossfadeEnabled;
        }
      }
      class tv extends W.t {
        constructor(e10, { code: t10 = "E_PLAYS", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "PlaysException"), Object.setPrototypeOf(this, tv.prototype);
        }
      }
      let tP = (e10, t10) => {
        var a10, r10, i2;
        let { entity: s2, context: n2 } = e10.contextEntityPair;
        if (!s2.playId) {
          let t11 = {};
          t11.contextId = n2.data.meta.id, t11.entityId = s2.data.meta.id;
          let a11 = new tv("Trying to ".concat(e10.operation, " without playId"), { data: t11 });
          throw null == (r10 = e10.hooks) || r10.afterError.promise(a11), a11;
        }
        let l2 = (null == (a10 = s2.data.additional) ? void 0 : a10.from) || n2.from;
        if (!l2) {
          let t11 = new tv("from field is required for ".concat(e10.operation, ", but was not found in plays data"));
          throw null == (i2 = e10.hooks) || i2.afterError.promise(t11), t11;
        }
        return e10.playData.playId = s2.playId, e10.playData.from = l2, t10();
      };
      function tS(e10) {
        return (null == e10 ? void 0 : e10.data.type) === J.K.Radio;
      }
      function tE(e10) {
        if ((0, eq.l)(e10)) {
          var t10;
          if ("smartPreviewParams" in e10.data.meta && (null == (t10 = e10.data.meta.smartPreviewParams) ? void 0 : t10.durationMs))
            return e10.data.meta.smartPreviewParams.durationMs / 1e3;
        } else if ("durationMs" in e10.data.meta && e10.data.meta.durationMs) return e10.data.meta.durationMs / 1e3;
        return 0;
      }
      let tf = (e10, t10) => {
        let { entity: a10, context: r10 } = e10.contextEntityPair, i2 = tE(a10), s2 = e10.totalPlayedSeconds, n2 = e10.endPositionSeconds;
        return 0.5 > Math.abs(i2 - e10.totalPlayedSeconds) && (s2 = i2), 0.5 > Math.abs(i2 - e10.endPositionSeconds) && (n2 = i2), tS(r10) && (n2 = s2), e10.playData.totalPlayedSeconds = s2, e10.playData.endPositionSeconds = n2, e10.playData.trackLengthSeconds = i2, t10();
      }, tb = (e10) => {
        if (e10.mediaSourceData && "urls" in e10.mediaSourceData.data) {
          let t10 = e10.mediaSourceData.data.urls[0];
          if (t10 && t10.startsWith("blob:")) return true;
        }
        return false;
      };
      function tI(e10) {
        return (null != e10 ? e10 : /* @__PURE__ */ new Date()).toISOString();
      }
      let t_ = (e10, t10) => {
        var a10;
        let { entity: r10, context: i2 } = e10.contextEntityPair;
        e10.playData.timestamp = tI(e10.clock()), e10.playData.albumId = (function(e11) {
          let t11;
          if ("albums" in e11.data.meta) {
            let {
              data: {
                meta: { albums: a11 }
              }
            } = e11;
            if (a11) {
              let e12 = a11[0];
              e12 && (t11 = String(e12.id));
            }
          }
          return t11;
        })(r10), e10.playData.context = i2.data.type, e10.playData.contextItem = String(i2.data.meta.id), e10.playData.addTracksToPlayerTime = r10.addTracksToPlayerTime, e10.playData.fromCache = tb(r10), e10.playData.isRestored = !!r10.data.isRestored;
        let s2 = (null == (a10 = r10.data.additional) ? void 0 : a10.utmLink) || i2.utmLink || {};
        return e10.playData = { ...e10.playData, ...s2 }, t10();
      }, tk = (e10, t10) => (e10.playData.audioAuto = "none", e10.playData.audioOutputName = "Динамик", e10.playData.audioOutputType = "Speaker", t10()), tC = (e10, t10) => {
        let a10, { entity: r10, context: i2 } = e10.contextEntityPair, s2 = String(r10.data.meta.id);
        if ((0, tl.S)(i2)) {
          var n2;
          a10 = {
            generativeStreamId: (null == (n2 = i2.data.meta.stream) ? void 0 : n2.id) ? String(i2.data.meta.stream.id) : void 0
          };
        } else a10 = { trackId: s2 };
        return e10.playData = { ...e10.playData, ...a10 }, t10();
      }, tT = (e10, t10) => {
        let { context: a10 } = e10.contextEntityPair;
        if ((0, eK.i)(a10) && a10.data.meta.session) {
          var r10, i2;
          let { dynamicData: t11 } = e10;
          e10.playData.radioSessionId = null != (r10 = t11.radioSessionId) ? r10 : a10.data.meta.session.radioSessionId, e10.playData.batchId = null != (i2 = t11.radioBatchId) ? i2 : a10.data.meta.session.batchId, e10.playData.isFromAutoflow = t11.isFromAutoflow, e10.playData.isFromPumpkin = t11.isFromPumpkin, e10.playData.context = "radio", e10.playData.contextItem = a10.data.meta.session.wave.stationId;
        }
        return t10();
      };
      var tD = a(64336);
      let tA = (e10, t10) => {
        let { context: a10 } = e10.contextEntityPair;
        return (0, tD.K)(a10) && (e10.playData.playlistId = "".concat(a10.data.meta.uid, ":").concat(a10.data.meta.kind), e10.playData.contextItem = "".concat(a10.data.meta.uid, ":").concat(a10.data.meta.kind)), t10();
      };
      var tx = a(63006), tL = a(77710);
      let tR = (e10, t10) => {
        let { context: a10 } = e10.contextEntityPair;
        if ((0, tx.p)(a10)) {
          var r10;
          let t11 = [tL.b.Search, tL.b.Other], i2 = null != (r10 = a10.data.overrideContextType) ? r10 : tL.b.Other;
          e10.playData.context = i2, t11.includes(i2) && (e10.playData.contextItem = null);
        }
        return t10();
      }, tN = (e10, t10) => {
        let { entity: a10 } = e10.contextEntityPair;
        return (0, eq.l)(a10) && (e10.playData.smartPreview = true), t10();
      }, tw = (e10, t10) => {
        var a10, r10;
        let { dynamicData: i2, playType: s2 } = e10;
        return e10.playData.seek = null != (a10 = i2.seek) && a10, e10.playData.pause = null != (r10 = i2.pause) && r10, e10.playData.startTimestamp = i2.startTimestamp, s2 !== h.START && (e10.playData.maxPlayerStage = i2.maxPlayerStage), t10();
      };
      !(function(e10) {
        e10.FINISH = "finish", e10.SKIP = "skip", e10.DISLIKE = "dislike", e10.BACK_SKIP = "back_skip", e10.OTHER_TRACK = "other_track", e10.IN_PROGRESS = "in_progress";
      })(g || (g = {})), (function(e10) {
        e10.AFTER_MEDIA_END_PLAYING = "AFTER_MEDIA_END_PLAYING", e10.BEFORE_CONTEXT_SET = "BEFORE_CONTEXT_SET", e10.BEFORE_ENTITY_CHANGE = "BEFORE_ENTITY_CHANGE", e10.AFTER_CONTEXT_END = "AFTER_CONTEXT_END";
      })(y || (y = {}));
      let tM = (e10, t10) => {
        let a10, { dynamicData: r10, playType: i2 } = e10;
        if (void 0 !== r10.changeReason) return e10.playData.changeReason = r10.changeReason, t10();
        if (!r10.hookSource) return i2 === h.PLAYING && (e10.playData.changeReason = g.IN_PROGRESS), t10();
        switch (r10.hookSource) {
          case y.AFTER_MEDIA_END_PLAYING:
            a10 = g.FINISH;
            break;
          case y.BEFORE_CONTEXT_SET:
            a10 = g.OTHER_TRACK;
            break;
          case y.BEFORE_ENTITY_CHANGE:
          case y.AFTER_CONTEXT_END:
            a10 = (function(e11, t11) {
              if (!e11) return g.OTHER_TRACK;
              switch (e11) {
                case M.So.AUTO_MOVE_FORWARD:
                  return g.FINISH;
                case M.So.MOVE_FORWARD:
                  return t11 ? g.DISLIKE : g.SKIP;
                case M.So.MOVE_BACKWARD:
                  return g.BACK_SKIP;
                default:
                  return g.OTHER_TRACK;
              }
            })(r10.entityChangeMethod, r10.wasDislikedOnChange);
        }
        return e10.playData.changeReason = a10, t10();
      };
      function tO(e10) {
        let t10 = e10.state.mediaPlayersStore.value[K.e.AUDIO];
        return !!t10 && !!(0, M.uo)(t10) && t10.isReadyForAudioEffect.value;
      }
      let tF = (e10, t10) => {
        if ((0, tl.S)(e10.contextEntityPair.context)) return t10();
        let a10 = tO(e10.playback), r10 = e10.contextEntityPair.getCrossParams(), i2 = e10.contextEntityPair.getFadeMode();
        if (e10.playData.fadeMode = a10 && r10 ? i2 : M.OQ.NONE, !(function(e11) {
          let t11 = e11.contextEntityPair.getCrossParams(), a11 = eX(e11.contextEntityPair.context), r11 = !!e11.isCrossfadeEnabled && e11.isCrossfadeEnabled.value, i3 = a11 || r11 && e11.contextEntityPair.getFadeMode() !== M.OQ.NONE;
          if (!t11 || !i3) {
            e11.playData.expectedTrackLengthSeconds = tE(e11.contextEntityPair.entity);
            return;
          }
          e11.playData.expectedTrackLengthSeconds = t11.outStart - t11.inStart;
        })(e10), e10.dynamicData.startedWithCrossfade && r10)
          e10.playData.startPositionSeconds = r10.inStart;
        else {
          var s2;
          e10.playData.startPositionSeconds = null != (s2 = e10.contextEntityPair.positionSec) ? s2 : 0;
        }
        return t10();
      };
      class tG {
        buildPlayDataPipeline() {
          let e10 = new tm().use(tP).use(tf).use(t_).use(tk).use(tC).use(tT).use(tA).use(tR).use(tN).use(tw).use(tM);
          return this.toggles.enableSendFadeFieldsInPlays && e10.use(tF), e10;
        }
        createPlay(e10) {
          let t10 = new tp({
            ...e10,
            hooks: this.hooks,
            playback: this.playback,
            clock: this.clock,
            isCrossfadeEnabled: this.isCrossfadeEnabled
          });
          return this.playDataPipeline.run(t10).then(() => t10.getResult()).catch((e11) => (console.error("Critical error in play data pipeline:", e11), null));
        }
        createStartPlay(e10) {
          e10.entity.addTracksToPlayerTime = "".concat(Math.random().toString().slice(2), "-").concat(Math.ceil(Number(this.clock()) / 1e3));
          let t10 = this.dynamicDataManager.getDynamicDataByPlayId(e10.entity.playId);
          return this.createPlay({
            contextEntityPair: e10,
            playType: h.START,
            totalPlayedSeconds: 0,
            endPositionSeconds: 0,
            dynamicData: t10,
            operation: "send start entity play"
          });
        }
        createProgressPlay(e10, t10, a10, r10) {
          let i2 = this.dynamicDataManager.getDynamicDataByPlayId(e10.entity.playId);
          return this.createPlay({
            contextEntityPair: e10,
            playType: h.PLAYING,
            totalPlayedSeconds: t10,
            endPositionSeconds: a10,
            dynamicData: i2,
            operation: r10
          });
        }
        createEndPlay(e10, t10, a10) {
          let r10 = this.dynamicDataManager.getDynamicDataByPlayId(e10.entity.playId);
          return this.createPlay({
            contextEntityPair: e10,
            playType: h.END,
            totalPlayedSeconds: t10,
            endPositionSeconds: a10,
            dynamicData: r10,
            operation: "send end entity play"
          });
        }
        sendStartEntityPlay(e10) {
          if (!e10) return Promise.resolve();
          try {
            return this.createStartPlay(e10).then((t10) => {
              if (t10 && !this.toggles.disableSendPlaysOnTrackStart)
                return this.sendPlay(t10).catch((t11) => {
                  this.handleSendingError(t11, "Error while sending plays", e10);
                });
            });
          } catch (t10) {
            this.handleSendingError(t10, "Error while sending plays", e10);
          }
          return Promise.resolve();
        }
        sendPartialPlayReport(e10) {
          if (!e10) return Promise.resolve();
          try {
            let t10 = e10.entity.playId, a10 = e10.entity.totalPlayedSeconds, r10 = this.hasSentPartialPlayReportId(t10), i2 = this.toggles.enablePartialPlayReporting && !r10 && a10 >= 30.1, s2 = this.toggles.enablePeriodicSendPlays && this.nextPeriodicSendTotalPlayedSeconds < a10;
            if (!(0, tl.S)(e10.context) && (i2 || s2))
              return this.createProgressPlay(
                e10,
                a10,
                this.playback.state.playerState.progress.value.position,
                "send partial play report"
              ).then(
                (t11) => t11 ? this.sendPlay(t11).then(() => {
                  i2 && this.addSentPartialPlayReportId(t11.playId), s2 && (this.nextPeriodicSendTotalPlayedSeconds += this.periodicSendIntervalSeconds);
                }).catch((t12) => {
                  this.handleSendingError(t12, "Error while sending plays", e10);
                }) : Promise.resolve()
              );
          } catch (t10) {
            this.handleSendingError(t10, "Error while sending plays partial play report", e10);
          }
          return Promise.resolve();
        }
        sendPausePlayReport(e10) {
          if (!e10) return Promise.resolve();
          try {
            let t10 = e10.entity.playId, a10 = e10.entity.totalPlayedSeconds, r10 = this.dynamicDataManager.getDynamicDataByPlayId(t10);
            return this.createPlay({
              contextEntityPair: e10,
              playType: h.PAUSE,
              totalPlayedSeconds: a10,
              endPositionSeconds: this.playback.state.playerState.progress.value.position,
              dynamicData: { ...r10, changeReason: void 0 },
              operation: "send pause play report"
            }).then(
              (t11) => t11 ? this.sendPlay(t11).catch((t12) => {
                this.handleSendingError(t12, "Error while sending plays", e10);
              }) : Promise.resolve()
            );
          } catch (t10) {
            this.handleSendingError(t10, "Error while sending plays pause play report", e10);
          }
          return Promise.resolve();
        }
        sendEndEntityPlay(e10) {
          if (!e10 || this.toggles.enableRemoveDuplicatePlays && this.hasSentPlayId(e10.entity.playId))
            return Promise.resolve();
          this.toggles.enableRemoveDuplicatePlays && this.addSentPlayId(e10.entity.playId);
          try {
            return this.createEndPlay(
              e10,
              e10.entity.totalPlayedSeconds,
              this.playback.state.playerState.progress.value.position
            ).then((t10) => {
              if (t10)
                return this.clearDynamicData(t10.playId), this.toggles.enablePartialPlayReporting && this.clearSentPartialPlayReportId(t10.playId), this.sendPlay(t10).catch((t11) => {
                  this.handleSendingError(t11, "Error while sending plays", e10);
                }).finally(() => {
                  this.resetIsRestoredFlag(e10.entity);
                });
            });
          } catch (t10) {
            this.handleSendingError(t10, "Error while sending plays", e10);
          }
          return Promise.resolve();
        }
        sendStoredPlaysData() {
          this.isSendingPlays.value = true;
          let e10 = this.toggles.limitOfSendingPlaysData || 25;
          return this.isStorageEnabled() ? this.store.getStoredPlaysData(e10).then((e11) => {
            let t10 = this.filterPlaysForSending(e11);
            if (!t10.length) {
              this.isSendingPlays.value = false;
              return;
            }
            this.playsResourceSend(t10).then(() => {
              this.deletePlaysData(t10).then(() => {
                this.sendStoredPlaysData();
              });
            }).catch((e12) => {
              var a10;
              this.isSendingPlays.value = false, e12 instanceof tn.GX && e12.statusCode === tn.X1.BAD_REQUEST && this.deletePlaysData(t10), null == (a10 = this.hooks) || a10.afterError.promise(new tv("Error while sending plays", { cause: e12 }));
            });
          }).catch((e11) => {
            var t10;
            null == (t10 = this.hooks) || t10.afterError.promise(e11);
          }) : Promise.resolve();
        }
        sendPlay(e10) {
          this.isSendingPlays.value = true;
          let t10 = [e10];
          return this.playsResourceSend(t10).then(() => {
            this.isStorageEnabled() && this.deletePlaysData(t10, (e11) => e11.totalPlayedSeconds > 0);
          }).catch((a10) => {
            throw a10 instanceof tn.GX && a10.statusCode === tn.X1.BAD_REQUEST ? this.deletePlaysData(t10) : this.storeAndReplace(e10), a10;
          }).finally(() => {
            if (!this.isStorageEnabled()) {
              this.isSendingPlays.value = false;
              return;
            }
            this.sendStoredPlaysData();
          });
        }
        clearSentPlayIds() {
          this.sentPlayIds.clear();
        }
        clearPeriodicSendInterval() {
          this.nextPeriodicSendTotalPlayedSeconds = this.periodicSendIntervalSeconds;
        }
        hasSentPlayId(e10) {
          return this.sentPlayIds.has(e10);
        }
        addSentPlayId(e10) {
          this.sentPlayIds.add(e10);
        }
        addSentPartialPlayReportId(e10) {
          this.sentPartialPlayReportIds.add(e10);
        }
        hasSentPartialPlayReportId(e10) {
          return this.sentPartialPlayReportIds.has(e10);
        }
        clearSentPartialPlayReportId(e10) {
          this.sentPartialPlayReportIds.delete(e10);
        }
        isSendingPlaysValue() {
          return this.isSendingPlays.value;
        }
        onSendingPlaysStateChange(e10) {
          return this.isSendingPlays.onChange(e10);
        }
        resetIsRestoredFlag(e10) {
          e10.data.isRestored && (e10.data.isRestored = false);
        }
        handleSendingError(e10, t10, a10) {
          var r10;
          let i2 = "", s2 = "";
          a10 && (i2 = a10.context.data.meta.id, s2 = a10.entity.data.meta.id), null == (r10 = this.hooks) || r10.afterError.promise(new tv(t10, { cause: e10, data: { contextId: i2, entityId: s2 } }));
        }
        clearDynamicData(e10) {
          this.dynamicDataManager.clearDynamicData(e10);
        }
        setPlaysDataForSending(e10) {
          e10.forEach((e11) => {
            let { playId: t10 } = e11;
            this.sendingInProgressForPlayId.add(t10);
          });
        }
        clearSendedPlaysData(e10) {
          e10.forEach((e11) => {
            let { playId: t10 } = e11;
            this.sendingInProgressForPlayId.has(t10) && this.sendingInProgressForPlayId.delete(t10);
          });
        }
        filterPlaysForSending(e10) {
          var t10 = e10.filter((e11) => {
            let { playId: t11 } = e11;
            return !this.sendingInProgressForPlayId.has(t11);
          });
          let a10 = (0, td.A)((0, to.A)(t10, "playId"), ty);
          return (0, th.A)(a10);
        }
        playsResourceSend(e10) {
          return this.setPlaysDataForSending(e10), this.gateway.sendPlays(e10).finally(() => {
            this.clearSendedPlaysData(e10);
          });
        }
        deletePlaysData(e10, t10, a10) {
          return this.isStorageEnabled() ? this.store.deleteAllByPlayId(e10, t10).then(() => {
            if (a10) return a10();
          }).catch((e11) => {
            var t11;
            null == (t11 = this.hooks) || t11.afterError.promise(e11);
          }) : Promise.resolve();
        }
        storeAndReplace(e10) {
          if (!this.isStorageEnabled()) return Promise.resolve();
          let t10 = () => {
            var t11;
            return null == (t11 = this.store) ? void 0 : t11.storePlaysData(e10);
          };
          return this.deletePlaysData([e10], (e11) => e11.totalPlayedSeconds > 0, t10);
        }
        isStorageEnabled() {
          return !!this.toggles.enableLocalStoredPlaysData && this.store.isAvailable();
        }
        storePlay(e10) {
          return this.storeAndReplace(e10);
        }
        sendCurrentEntityEndPlay() {
          let e10 = this.playback.state.queueState.currentEntity.value;
          if (e10 && this.playback.state.currentContext.value) {
            if ((0, eK.i)(this.playback.state.currentContext.value)) return this.sendEndEntityPlay(e10);
            this.sendEndEntityPlay(e10);
          }
          return Promise.resolve();
        }
        constructor(e10) {
          (0, w._)(this, "store", void 0), (0, w._)(this, "gateway", void 0), (0, w._)(this, "dynamicDataManager", void 0), (0, w._)(this, "clock", void 0), (0, w._)(this, "toggles", void 0), (0, w._)(this, "hooks", void 0), (0, w._)(this, "playback", void 0), (0, w._)(this, "isCrossfadeEnabled", void 0), (0, w._)(this, "sentPlayIds", /* @__PURE__ */ new Set()), (0, w._)(this, "sentPartialPlayReportIds", /* @__PURE__ */ new Set()), (0, w._)(this, "sendingInProgressForPlayId", /* @__PURE__ */ new Set()), (0, w._)(this, "nextPeriodicSendTotalPlayedSeconds", 0), (0, w._)(this, "isSendingPlays", void 0), (0, w._)(this, "periodicSendIntervalSeconds", void 0), (0, w._)(this, "playDataPipeline", void 0), this.store = e10.store, this.gateway = e10.gateway, this.dynamicDataManager = e10.dynamicDataManager, this.clock = e10.clock, this.toggles = e10.toggles, this.hooks = e10.hooks, this.playback = e10.playback, this.isCrossfadeEnabled = e10.isCrossfadeEnabled, this.periodicSendIntervalSeconds = e10.periodicSendIntervalSeconds, this.isSendingPlays = new et.cJ(false), this.playDataPipeline = this.buildPlayDataPipeline();
        }
      }
      !(function(e10) {
        e10.PREPARE = "prepare", e10.PLAY = "play";
      })(m || (m = {}));
      class tK {
        getDynamicDataByPlayId(e10) {
          var t10, a10, r10;
          let i2 = this.dynamicDataByPlayId.get(e10);
          return {
            seek: null != (t10 = null == i2 ? void 0 : i2.seek) && t10,
            pause: null != (a10 = null == i2 ? void 0 : i2.pause) && a10,
            maxPlayerStage: null != (r10 = null == i2 ? void 0 : i2.maxPlayerStage) ? r10 : m.PREPARE,
            startTimestamp: null == i2 ? void 0 : i2.startTimestamp,
            radioSessionId: null == i2 ? void 0 : i2.radioSessionId,
            radioBatchId: null == i2 ? void 0 : i2.radioBatchId,
            isFromAutoflow: null == i2 ? void 0 : i2.isFromAutoflow,
            isFromPumpkin: null == i2 ? void 0 : i2.isFromPumpkin,
            changeReason: null == i2 ? void 0 : i2.changeReason,
            hookSource: null == i2 ? void 0 : i2.hookSource,
            entityChangeMethod: null == i2 ? void 0 : i2.entityChangeMethod,
            wasDislikedOnChange: null == i2 ? void 0 : i2.wasDislikedOnChange,
            wasAlreadyDisliked: null == i2 ? void 0 : i2.wasAlreadyDisliked,
            startedWithCrossfade: null == i2 ? void 0 : i2.startedWithCrossfade
          };
        }
        updateDynamicData(e10, t10) {
          var a10;
          let r10 = null != (a10 = this.dynamicDataByPlayId.get(e10)) ? a10 : {};
          this.dynamicDataByPlayId.set(e10, { ...r10, ...t10 });
        }
        clearDynamicData(e10) {
          this.dynamicDataByPlayId.delete(e10);
        }
        hasDynamicData(e10) {
          return this.dynamicDataByPlayId.has(e10);
        }
        markAsAlreadyDisliked(e10) {
          this.updateDynamicData(e10, { wasAlreadyDisliked: true });
        }
        isAlreadyDisliked(e10) {
          var t10;
          return null != (t10 = this.getDynamicDataByPlayId(e10).wasAlreadyDisliked) && t10;
        }
        constructor() {
          (0, w._)(this, "dynamicDataByPlayId", /* @__PURE__ */ new Map());
        }
      }
      var tj = a(1365);
      function tX(e10, t10) {
        if (!(0, eK.i)(null == e10 ? void 0 : e10.context) || !e10) return;
        let {
          meta: { session: a10, sessionTracks: r10 },
          parentContext: i2
        } = e10.context.data, s2 = null == a10 ? void 0 : a10.radioSessionId, n2 = r10 ? r10.batchId : null == a10 ? void 0 : a10.batchId, l2 = r10 ? r10.pumpkin : null == a10 ? void 0 : a10.pumpkin;
        t10.updateDynamicData(e10.entity.playId, {
          radioSessionId: s2,
          radioBatchId: n2,
          isFromPumpkin: l2,
          isFromAutoflow: !!i2
        });
      }
      class tB {
        attachSubscriptions() {
          this.attachPlayerStateEventSubscription(), this.attachProgressSubscriptions();
        }
        attachPlayerStateEventSubscription() {
          this.playback.state.playerState.event.onChange(() => {
            let { currentEntity: e10 } = this.playback.state.queueState;
            if (!e10.value) return;
            let t10 = e10.value.entity.playId;
            switch (this.playback.state.playerState.event.value) {
              case M.Iu.PLAYING:
                this.handlePlayingEvent(e10.value, t10);
                break;
              case M.Iu.PAUSED:
                this.handlePausedEvent(e10.value, t10);
                break;
              case M.Iu.SET_PROGRESS:
                this.handleSetProgressEvent(e10.value, t10);
            }
          });
        }
        handlePlayingEvent(e10, t10) {
          tX(e10, this.dynamicDataManager), this.dynamicDataManager.updateDynamicData(t10, { maxPlayerStage: m.PLAY });
        }
        handlePausedEvent(e10, t10) {
          let a10 = this.playback.state.playerState.progress.value;
          Math.abs(a10.position - a10.duration) > 0.2 && this.dynamicDataManager.updateDynamicData(t10, { pause: true }), tS(e10.context) && this.service.sendPausePlayReport(e10);
        }
        handleSetProgressEvent(e10, t10) {
          (0, tl.S)(e10.context) || tS(e10.context) || this.dynamicDataManager.updateDynamicData(t10, { seek: true });
        }
        attachProgressSubscriptions() {
          this.toggles.enableLocalStoredPlaysData && this.attachStorePlayOnProgress(), (this.toggles.enablePartialPlayReporting || this.toggles.enablePeriodicSendPlays) && this.attachPartialPlayReporting();
        }
        attachStorePlayOnProgress() {
          let e10 = (0, tj.A)(
            () => {
              let e11 = this.playback.state.queueState.currentEntity.value;
              !e11 || (0, tl.S)(e11.context) || this.service.createProgressPlay(
                e11,
                e11.entity.totalPlayedSeconds,
                this.playback.state.playerState.progress.value.position,
                "store play on progress"
              ).then((e12) => {
                e12 && e12.playId && e12.totalPlayedSeconds > 0 && this.service.storePlay(e12);
              });
            },
            this.storePlaysProgressIntervalMs,
            { trailing: false }
          );
          this.playback.state.playerState.progress.onChange(e10);
        }
        attachPartialPlayReporting() {
          let e10 = (0, tj.A)(
            () => {
              let e11 = this.playback.state.queueState.currentEntity.value;
              e11 && this.service.sendPartialPlayReport(e11);
            },
            2e3,
            { trailing: false }
          );
          this.playback.state.playerState.progress.onChange(e10);
        }
        constructor(e10) {
          (0, w._)(this, "playback", void 0), (0, w._)(this, "service", void 0), (0, w._)(this, "dynamicDataManager", void 0), (0, w._)(this, "toggles", void 0), (0, w._)(this, "storePlaysProgressIntervalMs", void 0), this.playback = e10.playback, this.service = e10.service, this.dynamicDataManager = e10.dynamicDataManager, this.toggles = e10.toggles, this.storePlaysProgressIntervalMs = e10.storePlaysProgressIntervalMs;
        }
      }
      class tV extends W.t {
        constructor(e10, { code: t10 = "E_MEDIA_PROVIDER", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "MediaProviderException"), Object.setPrototypeOf(this, tV.prototype);
        }
      }
      class tU extends tV {
        constructor(e10, { code: t10 = "E_GET_FILE_INFO_MEDIA_PROVIDER", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "GetFileInfoMediaProviderException"), Object.setPrototypeOf(this, tU.prototype);
        }
      }
      class tq {
        sendPlays(e10) {
          return this.playsResource.sendPlays({ clientNow: tI(), plays: e10 });
        }
        constructor(e10) {
          (0, w._)(this, "playsResource", void 0), this.playsResource = e10;
        }
      }
      class tW {
        storePlaysData(e10) {
          return this.playsStore.storePlaysData(e10);
        }
        getStoredPlaysData(e10) {
          return this.playsStore.getStoredPlaysData(e10 || this.limit);
        }
        deleteAllByPlayId(e10, t10) {
          return this.playsStore.deleteAllByPlayId(e10, t10);
        }
        isAvailable() {
          return this.playsStore.isAvailable();
        }
        openDatabase() {
          return this.playsStore.openDatabase();
        }
        deleteDatabase() {
          return this.playsStore.deleteDatabase();
        }
        setErrorLogger(e10) {
          var t10, a10;
          null == (t10 = (a10 = this.playsStore).setErrorLogger) || t10.call(a10, e10);
        }
        constructor(e10, t10) {
          (0, w._)(this, "playsStore", void 0), (0, w._)(this, "limit", void 0), this.playsStore = e10, this.limit = t10;
        }
      }
      class tY {
        storePlaysData(e10) {
          return Promise.resolve();
        }
        getStoredPlaysData(e10) {
          return Promise.resolve([]);
        }
        deleteAllByPlayId(e10, t10) {
          return Promise.resolve();
        }
        isAvailable() {
          return false;
        }
        openDatabase() {
          return Promise.resolve();
        }
        deleteDatabase() {
          return Promise.resolve();
        }
        setErrorLogger(e10) {
        }
      }
      var tz = a(86473), tH = a(99796);
      let tQ = "playsHeartBeats";
      class t$ extends W.t {
        constructor(e10, { code: t10 = "E_PLAYS_IDB_STORE", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "PlaysStoreException"), Object.setPrototypeOf(this, t$.prototype);
        }
      }
      class tZ {
        deleteDatabase() {
          return window.indexedDB.databases().then(
            (e10) => e10.find((e11) => this.idbName === e11.name) ? new tH.h(this.idbName).deleteDB({ onBlocked: tz.A }) : Promise.resolve()
          ).catch((e10) => {
            this.logError("Error while deleting database", e10);
          });
        }
        isAvailable() {
          return this.idbIsAvailable;
        }
        openDatabase() {
          return this.openIdb({
            onBlocked: () => this.onBlockedHandler(),
            onTerminated: () => this.onTerminatedHandler()
          }).then((e10) => {
            this.idb = Promise.resolve(e10);
          });
        }
        setErrorLogger(e10) {
          this.errorLogger = e10;
        }
        storePlaysData(e10) {
          return this.executeTransaction((t10) => t10.put(tQ, e10).then(() => t10.count(tQ))).then(
            (e11) => "number" == typeof e11 && e11 > this.storedPlaysLimit ? this.deleteOverLimitPlays(this.storedPlaysLimit) : Promise.resolve()
          ).catch((e11) => {
            throw this.generateError("Saving Play Error", e11);
          });
        }
        getStoredPlaysData(e10) {
          return this.executeTransaction((t10) => t10.getAll(tQ, null, e10), { defaultValue: [] }).catch((e11) => {
            throw this.generateError("Error getting Plays", e11);
          });
        }
        deleteAllByPlayId(e10, t10) {
          return Promise.all(
            e10.map((e11) => {
              let { playId: a10 } = e11;
              return this.iterateByCursor(
                "playId",
                a10,
                "readwrite",
                (e12) => !t10 || t10(e12.value) ? e12.delete() : Promise.resolve()
              );
            })
          ).then(tz.A).catch((e11) => {
            throw this.generateError("Error deleting Plays", e11);
          });
        }
        deleteOverLimitPlays(e10) {
          return this.iterateByCursor(
            null,
            null,
            "readwrite",
            (t10, a10) => a10 <= e10 ? Promise.resolve() : t10.delete()
          ).catch((e11) => {
            throw this.generateError("Error deleting overlimit Plays", e11);
          });
        }
        iterateByCursor() {
          let e10 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t10 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, a10 = arguments.length > 2 ? arguments[2] : void 0, r10 = arguments.length > 3 ? arguments[3] : void 0, i2 = 0, s2 = (e11) => e11 ? r10(e11, ++i2).then(() => e11.continue()).then(s2) : Promise.resolve();
          return this.getCursor(e10, t10, a10).then(s2);
        }
        onBlockedHandler() {
          this.closeConnection(this.idb).then(() => {
            this.idb = this.openIdb({
              onBlocked: () => {
                this.closeConnection(this.idb);
              },
              onTerminated: () => this.onTerminatedHandler()
            });
          });
        }
        onTerminatedHandler() {
          this.idbIsAvailable = false, this.idb = this.openIdb({
            onBlocked: () => this.onBlockedHandler(),
            onTerminated: () => {
              this.idbIsAvailable = false;
            }
          });
        }
        openIdb(e10) {
          return new tH.h(this.idbName).openDB(1, {
            onBlocked: (t10, a10, r10) => {
              var i2;
              this.logError("Connection has been blocked"), null == e10 || null == (i2 = e10.onBlocked) || i2.call(e10, t10, a10, r10);
            },
            onTerminated: () => {
              var t10;
              this.logError("Storage has been terminated"), null == e10 || null == (t10 = e10.onTerminated) || t10.call(e10);
            },
            onUpgrade: (e11) => {
              let t10 = e11.createObjectStore(tQ, { keyPath: "id", autoIncrement: true });
              t10.createIndex("playId", "playId", { unique: false }), t10.createIndex("trackId", "trackId", { unique: false });
            }
          }).then((e11) => (this.idbIsAvailable = true, e11)).catch((e11) => {
            this.idbIsAvailable = false, this.logError("Open storage error", e11);
          });
        }
        closeConnection(e10) {
          return (this.idbIsAvailable = false, this.idb = void 0, e10) ? e10.then((e11) => {
            e11 && e11.close();
          }).catch((e11) => {
            this.logError("Error while try to close connection", e11);
          }) : Promise.resolve();
        }
        getCursor() {
          let e10 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t10 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, a10 = arguments.length > 2 ? arguments[2] : void 0;
          return this.executeTransaction(
            (r10) => {
              let i2 = r10.transaction([tQ], a10).objectStore(tQ);
              return e10 ? i2.index(e10).openCursor(t10, "prev") : i2.openCursor(t10, "prev");
            },
            { defaultValue: null }
          );
        }
        executeTransaction(e10) {
          let t10 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return this.idbIsAvailable && this.idb ? this.idb.then((a10) => a10 ? e10(a10) : Promise.resolve(null == t10 ? void 0 : t10.defaultValue)) : Promise.resolve(null == t10 ? void 0 : t10.defaultValue);
        }
        logError(e10, t10) {
          var a10;
          let r10 = this.generateError(e10, t10);
          null == (a10 = this.errorLogger) || a10.call(this, r10);
        }
        generateError(e10, t10) {
          var a10;
          let r10 = "[IndexedDB][".concat(this.idbName, ".").concat(tQ, "]: ").concat(e10), i2 = String(t10);
          return ("".concat(t10).includes("QuotaExceededError") || /connection.*lost/i.test("".concat(t10))) && this.closeConnection(), new t$(r10, { data: { originalError: i2, storageEstimate: null != (a10 = this.storageEstimate) ? a10 : {} } });
        }
        constructor(e10) {
          (0, w._)(this, "storedPlaysLimit", void 0), (0, w._)(this, "idb", void 0), (0, w._)(this, "errorLogger", void 0), (0, w._)(this, "idbIsAvailable", false), (0, w._)(this, "idbName", void 0), (0, w._)(this, "storageEstimate", void 0), this.storedPlaysLimit = e10, (() => {
            var e11, t10;
            return (null == (t10 = window.navigator) || null == (e11 = t10.storage) ? void 0 : e11.estimate) ? window.navigator.storage.estimate().catch(() => ({})) : Promise.resolve({});
          })().then((e11) => {
            this.storageEstimate = e11;
          }), this.idbName = "".concat("music_plays", "_").concat("1.0.0");
        }
      }
      class tJ {
        apply(e10) {
          var t10, a10;
          let { hooks: r10, playback: i2 } = e10, s2 = this.toggles.enableLocalStoredPlaysData ? new tW(new tZ(this.toggles.limitOfStoredPlaysData), this.toggles.limitOfStoredPlaysData) : new tY(), n2 = new tq(new ts(this.params.httpClient, this.params.playsResourceConfig));
          this.dynamicDataManager = new tK(), this.service = new tG({
            store: s2,
            gateway: n2,
            dynamicDataManager: this.dynamicDataManager,
            clock: () => /* @__PURE__ */ new Date(),
            toggles: this.toggles,
            hooks: r10,
            playback: i2,
            isCrossfadeEnabled: this.params.isCrossfadeEnabled,
            periodicSendIntervalSeconds: null != (t10 = this.params.periodicSendIntervalSeconds) ? t10 : 30
          }), this.playerStateSubscriptions = new tB({
            playback: i2,
            hooks: r10,
            service: this.service,
            dynamicDataManager: this.dynamicDataManager,
            toggles: this.toggles,
            storePlaysProgressIntervalMs: null != (a10 = this.params.storePlaysProgressIntervalMs) ? a10 : 1e4
          }), this.playerStateSubscriptions.attachSubscriptions();
          let {
            playback: l2,
            hooks: o2,
            service: d2,
            dynamicDataManager: u2,
            toggles: c2,
            clock: h2
          } = {
            playback: i2,
            hooks: r10,
            service: this.service,
            dynamicDataManager: this.dynamicDataManager,
            toggles: this.toggles,
            clock: () => /* @__PURE__ */ new Date()
          };
          o2.beforeEntityPlayingProcessStart.tapPromise("PlaysPlugin", () => {
            c2.enableRemoveDuplicatePlays && d2.clearSentPlayIds();
            let { queueState: e11 } = l2.state, t11 = e11.currentEntity.value;
            if (tX(t11, u2), t11) {
              let e12 = tO(l2), a11 = t11.entity.playId;
              u2.updateDynamicData(a11, { startedWithCrossfade: e12 });
            }
            return d2.sendStartEntityPlay(t11), d2.clearPeriodicSendInterval(), Promise.resolve();
          }), o2.beforeMediaStartPlaying.tapPromise("PlaysPlugin", () => {
            let { currentEntity: e11 } = l2.state.queueState;
            if (e11.value) {
              let t11 = e11.value.entity.playId;
              e11.value.entity.isDisliked && u2.markAsAlreadyDisliked(t11), u2.getDynamicDataByPlayId(t11).startTimestamp || u2.updateDynamicData(t11, { startTimestamp: tI(h2()) });
            }
            return Promise.resolve();
          }), o2.afterMediaEndPlaying.tapPromise("PlaysPlugin", () => {
            let {
              repeat: { value: e11 }
            } = l2.state.queueState, t11 = l2.state.queueState.currentEntity.value, a11 = null == t11 ? void 0 : t11.entity.playId, r11 = (null == t11 ? void 0 : t11.entity.isDisliked) && a11 && !u2.isAlreadyDisliked(a11);
            return e11 === M.pM.ONE && t11 && a11 && !r11 && (u2.updateDynamicData(a11, { hookSource: y.AFTER_MEDIA_END_PLAYING }), d2.sendEndEntityPlay(t11)), Promise.resolve();
          }), o2.afterError.tapPromise("PlaysPlugin", (e11) => {
            if (e11 instanceof tU || e11 instanceof M.LI) {
              let e12 = l2.state.queueState.currentEntity.value;
              d2.sendEndEntityPlay(e12);
            }
            return Promise.resolve();
          }), o2.beforeContextSet.tapPromise("PlaysPlugin", () => {
            let e11 = l2.state.queueState.currentEntity.value;
            return e11 && u2.updateDynamicData(e11.entity.playId, { hookSource: y.BEFORE_CONTEXT_SET }), d2.sendCurrentEntityEndPlay();
          }), o2.afterContextEnd.tapPromise("PlaysPlugin", (e11) => {
            let t11 = l2.state.queueState.currentEntity.value, a11 = null == t11 ? void 0 : t11.entity.playId;
            return t11 && a11 && (u2.updateDynamicData(a11, {
              hookSource: y.AFTER_CONTEXT_END,
              entityChangeMethod: e11,
              wasDislikedOnChange: t11.entity.isDisliked && !u2.isAlreadyDisliked(a11)
            }), d2.sendEndEntityPlay(t11)), Promise.resolve();
          }), o2.afterSetupQueue.tap("PlaysPlugin", () => {
            let { queueState: e11 } = l2.state;
            tX(e11.currentEntity.value, u2);
          }), o2.beforeEntityChange.tapPromise("PlaysPlugin", (e11) => {
            var t11;
            let { currentEntity: a11 } = l2.state.queueState, { method: r11 } = e11, i3 = null == (t11 = a11.value) ? void 0 : t11.entity.playId;
            return a11.value && i3 ? (u2.updateDynamicData(i3, {
              hookSource: y.BEFORE_ENTITY_CHANGE,
              entityChangeMethod: r11,
              wasDislikedOnChange: a11.value.entity.isDisliked && !u2.isAlreadyDisliked(i3)
            }), d2.sendCurrentEntityEndPlay()) : Promise.resolve();
          }), o2.beforeDestroy.tap(
            "PlaysPlugin",
            () => new Promise((e11) => {
              if (!d2.isSendingPlaysValue()) return void e11();
              let t11 = d2.onSendingPlaysStateChange((a11) => {
                a11 || (t11(), e11());
              });
            })
          ), this.toggles.enableLocalStoredPlaysData && s2.setErrorLogger((e11) => {
            r10.afterError.promise(e11);
          }), this.toggles.shouldDeletePlaysObjectStore && s2.deleteDatabase(), this.toggles.enableLocalStoredPlaysData && !this.toggles.shouldDeletePlaysObjectStore && s2.openDatabase().then(() => {
            var e11;
            null == (e11 = this.service) || e11.sendStoredPlaysData();
          });
        }
        constructor(e10) {
          var t10, a10, r10, i2, s2, n2, l2, o2, d2, u2, c2, h2, g2, y2, m2, p2, v2, P2;
          (0, w._)(this, "service", void 0), (0, w._)(this, "dynamicDataManager", void 0), (0, w._)(this, "playerStateSubscriptions", void 0), (0, w._)(this, "toggles", void 0), (0, w._)(this, "params", void 0), this.params = e10, this.toggles = {
            disableSendPlaysOnTrackStart: null != (u2 = null == (t10 = e10.variables) ? void 0 : t10.disableSendPlaysOnTrackStart) && u2,
            enableLocalStoredPlaysData: null != (c2 = null == (a10 = e10.variables) ? void 0 : a10.enableLocalStoredPlaysData) && c2,
            limitOfStoredPlaysData: null != (h2 = null == (r10 = e10.variables) ? void 0 : r10.limitOfStoredPlaysData) ? h2 : 100,
            limitOfSendingPlaysData: null != (g2 = null == (i2 = e10.variables) ? void 0 : i2.limitOfSendingPlaysData) ? g2 : 25,
            shouldDeletePlaysObjectStore: null != (y2 = null == (s2 = e10.variables) ? void 0 : s2.shouldDeletePlaysObjectStore) && y2,
            enableRemoveDuplicatePlays: null != (m2 = null == (n2 = e10.variables) ? void 0 : n2.enableRemoveDuplicatePlays) && m2,
            enablePartialPlayReporting: null != (p2 = null == (l2 = e10.variables) ? void 0 : l2.enablePartialPlayReporting) && p2,
            enablePeriodicSendPlays: null != (v2 = null == (o2 = e10.variables) ? void 0 : o2.enablePeriodicSendPlays) && v2,
            enableSendFadeFieldsInPlays: null != (P2 = null == (d2 = e10.variables) ? void 0 : d2.enableSendFadeFieldsInPlays) && P2
          };
        }
      }
      function t0(e10) {
        return (null == e10 ? void 0 : e10.data.type) === J.K.LegacyRadio;
      }
      function t1() {
        return (/* @__PURE__ */ new Date()).toISOString();
      }
      function t3(e10) {
        var t10, a10, r10, i2, s2, n2, l2;
        let o2, {
          contextEntityPair: d2,
          totalPlayedSeconds: u2,
          endPositionSeconds: c2,
          type: h2,
          maxPlayerStage: g2,
          seek: y2,
          pause: m2,
          startTimestamp: p2,
          radioSessionId: v2,
          radioBatchId: P2,
          isFromAutoflow: S2,
          isFromPumpkin: E2,
          changeReason: f2
        } = e10, { entity: b2, context: I2 } = d2, _2 = String(b2.data.meta.id), k2 = (function(e11) {
          let t11;
          if ("albums" in e11.data.meta) {
            let {
              data: {
                meta: { albums: a11 }
              }
            } = e11;
            if (a11) {
              let e12 = a11[0];
              e12 && (t11 = String(e12.id));
            }
          }
          return t11;
        })(b2), C2 = (null == (t10 = b2.data.additional) ? void 0 : t10.from) || I2.from, T2 = (null == (a10 = b2.data.additional) ? void 0 : a10.utmLink) || I2.utmLink || {}, D2 = 0;
        (0, eq.l)(b2) ? "smartPreviewParams" in b2.data.meta && (null == (r10 = b2.data.meta.smartPreviewParams) ? void 0 : r10.durationMs) && (D2 = (null == (i2 = b2.data.meta.smartPreviewParams) ? void 0 : i2.durationMs) / 1e3) : "durationMs" in b2.data.meta && b2.data.meta.durationMs && (D2 = b2.data.meta.durationMs / 1e3);
        let A2 = u2, x2 = c2;
        0.5 > Math.abs(D2 - u2) && (A2 = D2), 0.5 > Math.abs(D2 - c2) && (x2 = D2), o2 = (0, tl.S)(I2) ? { generativeStreamId: String(null == (s2 = I2.data.meta.stream) ? void 0 : s2.id) } : { trackId: _2 }, (tS(I2) || t0(I2)) && (x2 = A2);
        let L2 = !!b2.data.isRestored, R2 = {
          playId: b2.playId,
          timestamp: t1(),
          totalPlayedSeconds: A2,
          endPositionSeconds: x2,
          trackLengthSeconds: D2,
          albumId: k2,
          from: C2,
          context: null != (n2 = I2.data.playsContextType) ? n2 : I2.data.type,
          contextItem: String(I2.data.meta.id),
          addTracksToPlayerTime: b2.addTracksToPlayerTime,
          audioAuto: "none",
          audioOutputName: "Динамик",
          audioOutputType: "Speaker",
          maxPlayerStage: g2,
          seek: y2,
          pause: m2,
          startTimestamp: p2,
          fromCache: tb(b2),
          isRestored: L2,
          changeReason: f2,
          ...T2,
          ...o2
        };
        if ((0, eK.i)(I2) && I2.data.meta.session && (R2.radioSessionId = null != v2 ? v2 : I2.data.meta.session.radioSessionId, R2.batchId = null != P2 ? P2 : I2.data.meta.session.batchId, R2.isFromAutoflow = S2, R2.isFromPumpkin = E2, R2.context = "radio", R2.contextItem = I2.data.meta.session.wave.stationId), (0, tD.K)(I2) && (R2.playlistId = "".concat(I2.data.meta.uid, ":").concat(I2.data.meta.kind), R2.contextItem = "".concat(I2.data.meta.uid, ":").concat(I2.data.meta.kind)), (0, tx.p)(I2)) {
          let e11 = [tL.b.Search, tL.b.Other], t11 = null != (l2 = I2.data.overrideContextType) ? l2 : tL.b.Other;
          R2.context = t11, e11.includes(t11) && (R2.contextItem = null);
        }
        return (0, eq.l)(b2) && (R2.smartPreview = true), { type: h2, data: R2 };
      }
      !(function(e10) {
        e10.START = "start", e10.END = "end", e10.PLAYING = "playing", e10.PAUSE = "pause";
      })(p || (p = {}));
      let t2 = (e10) => !!(e10 && "object" == typeof e10 && "playId" in e10 && "totalPlayedSeconds" in e10), t4 = (e10) => {
        let t10 = [e10.find((e11) => 0 === e11.totalPlayedSeconds), (0, tu.A)(e10, "totalPlayedSeconds")];
        return (0, tc.A)(t10.filter(t2), "totalPlayedSeconds");
      };
      class t6 extends W.t {
        constructor(e10, { code: t10 = "E_PLAYS", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "PlaysException"), Object.setPrototypeOf(this, t6.prototype);
        }
      }
      let t5 = "playsHeartBeats";
      class t8 extends W.t {
        constructor(e10, { code: t10 = "E_PLAYS_IDB_STORE", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "PlaysStoreException"), Object.setPrototypeOf(this, t8.prototype);
        }
      }
      class t9 {
        deleteDatabase() {
          return window.indexedDB.databases().then(
            (e10) => e10.find((e11) => this.idbName === e11.name) ? new tH.h(this.idbName).deleteDB({ onBlocked: tz.A }) : Promise.resolve()
          ).catch((e10) => {
            this.logError("Error while deleting database", e10);
          });
        }
        isAvailable() {
          return this.idbIsAvailable;
        }
        openDatabase() {
          return this.openIdb({
            onBlocked: () => this.onBlockedHandler(),
            onTerminated: () => this.onTerminatedHandler()
          }).then((e10) => {
            this.idb = Promise.resolve(e10);
          });
        }
        setErrorLogger(e10) {
          this.errorLogger = e10;
        }
        storePlaysData(e10) {
          return this.executeTransaction((t10) => t10.put(t5, e10).then(() => t10.count(t5))).then(
            (e11) => "number" == typeof e11 && e11 > this.storedPlaysLimit ? this.deleteOverLimitPlays(this.storedPlaysLimit) : Promise.resolve()
          ).catch((e11) => {
            throw this.generateError("Saving Play Error", e11);
          });
        }
        getStoredPlaysData(e10) {
          return this.executeTransaction((t10) => t10.getAll(t5, null, e10), { defaultValue: [] }).catch((e11) => {
            throw this.generateError("Error getting Plays", e11);
          });
        }
        deleteAllByPlayId(e10, t10) {
          return Promise.all(
            e10.map((e11) => {
              let { playId: a10 } = e11;
              return this.iterateByCursor(
                "playId",
                a10,
                "readwrite",
                (e12) => !t10 || t10(e12.value) ? e12.delete() : Promise.resolve()
              );
            })
          ).then(tz.A).catch((e11) => {
            throw this.generateError("Error deleting Plays", e11);
          });
        }
        deleteOverLimitPlays(e10) {
          return this.iterateByCursor(
            null,
            null,
            "readwrite",
            (t10, a10) => a10 <= e10 ? Promise.resolve() : t10.delete()
          ).catch((e11) => {
            throw this.generateError("Error deleting overlimit Plays", e11);
          });
        }
        iterateByCursor() {
          let e10 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t10 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, a10 = arguments.length > 2 ? arguments[2] : void 0, r10 = arguments.length > 3 ? arguments[3] : void 0, i2 = 0, s2 = (e11) => e11 ? r10(e11, ++i2).then(() => e11.continue()).then(s2) : Promise.resolve();
          return this.getCursor(e10, t10, a10).then(s2);
        }
        onBlockedHandler() {
          this.closeConnection(this.idb).then(() => {
            this.idb = this.openIdb({
              onBlocked: () => {
                this.closeConnection(this.idb);
              },
              onTerminated: () => this.onTerminatedHandler()
            });
          });
        }
        onTerminatedHandler() {
          this.idbIsAvailable = false, this.idb = this.openIdb({
            onBlocked: () => this.onBlockedHandler(),
            onTerminated: () => {
              this.idbIsAvailable = false;
            }
          });
        }
        openIdb(e10) {
          return new tH.h(this.idbName).openDB(1, {
            onBlocked: (t10, a10, r10) => {
              var i2;
              this.logError("Connection has been blocked"), null == e10 || null == (i2 = e10.onBlocked) || i2.call(e10, t10, a10, r10);
            },
            onTerminated: () => {
              var t10;
              this.logError("Storage has been terminated"), null == e10 || null == (t10 = e10.onTerminated) || t10.call(e10);
            },
            onUpgrade: (e11) => {
              let t10 = e11.createObjectStore(t5, { keyPath: "id", autoIncrement: true });
              t10.createIndex("playId", "playId", { unique: false }), t10.createIndex("trackId", "trackId", { unique: false });
            }
          }).then((e11) => (this.idbIsAvailable = true, e11)).catch((e11) => {
            this.idbIsAvailable = false, this.logError("Open storage error", e11);
          });
        }
        closeConnection(e10) {
          return (this.idbIsAvailable = false, this.idb = void 0, e10) ? e10.then((e11) => {
            e11 && e11.close();
          }).catch((e11) => {
            this.logError("Error while try to close connection", e11);
          }) : Promise.resolve();
        }
        getCursor() {
          let e10 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t10 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, a10 = arguments.length > 2 ? arguments[2] : void 0;
          return this.executeTransaction(
            (r10) => {
              let i2 = r10.transaction([t5], a10).objectStore(t5);
              return e10 ? i2.index(e10).openCursor(t10, "prev") : i2.openCursor(t10, "prev");
            },
            { defaultValue: null }
          );
        }
        executeTransaction(e10) {
          let t10 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return this.idbIsAvailable && this.idb ? this.idb.then((a10) => a10 ? e10(a10) : Promise.resolve(null == t10 ? void 0 : t10.defaultValue)) : Promise.resolve(null == t10 ? void 0 : t10.defaultValue);
        }
        logError(e10, t10) {
          var a10;
          let r10 = this.generateError(e10, t10);
          null == (a10 = this.errorLogger) || a10.call(this, r10);
        }
        generateError(e10, t10) {
          var a10;
          let r10 = "[IndexedDB][".concat(this.idbName, ".").concat(t5, "]: ").concat(e10), i2 = String(t10);
          return ("".concat(t10).includes("QuotaExceededError") || /connection.*lost/i.test("".concat(t10))) && this.closeConnection(), new t8(r10, { data: { originalError: i2, storageEstimate: null != (a10 = this.storageEstimate) ? a10 : {} } });
        }
        constructor(e10) {
          (0, w._)(this, "storedPlaysLimit", void 0), (0, w._)(this, "idb", void 0), (0, w._)(this, "errorLogger", void 0), (0, w._)(this, "idbIsAvailable", false), (0, w._)(this, "idbName", void 0), (0, w._)(this, "storageEstimate", void 0), this.storedPlaysLimit = e10, (() => {
            var e11, t10;
            return (null == (t10 = window.navigator) || null == (e11 = t10.storage) ? void 0 : e11.estimate) ? window.navigator.storage.estimate().catch(() => ({})) : Promise.resolve({});
          })().then((e11) => {
            this.storageEstimate = e11;
          }), this.idbName = "".concat("music_plays", "_").concat("1.0.0");
        }
      }
      class t7 {
        apply(e10) {
          var t10, a10;
          let { hooks: r10, playback: i2 } = e10;
          this.hooks = r10, this.variables.enableLocalStoredPlaysData && this.playsStore.setErrorLogger((e11) => {
            r10.afterError.promise(e11);
          }), this.variables.shouldDeletePlaysObjectStore && (null == (t10 = this.playsStore) || t10.deleteDatabase()), this.variables.enableLocalStoredPlaysData && !this.variables.shouldDeletePlaysObjectStore && (null == (a10 = this.playsStore) || a10.openDatabase().then(() => {
            this.sendStoredPlaysData();
          })), i2.state.playerState.event.onChange(() => {
            let { currentEntity: e11 } = i2.state.queueState;
            if (e11.value)
              switch (i2.state.playerState.event.value) {
                case M.Iu.PLAYING:
                  return this.setVibeContextDynamicData(i2), this.changeDynamicPlaysDataByPlayId({
                    playId: e11.value.entity.playId,
                    dynamicData: { maxPlayerStage: m.PLAY }
                  });
                case M.Iu.PAUSED:
                  if (Math.abs(
                    i2.state.playerState.progress.value.position - i2.state.playerState.progress.value.duration
                  ) > 0.2 && this.changeDynamicPlaysDataByPlayId({
                    playId: e11.value.entity.playId,
                    dynamicData: { pause: true }
                  }), tS(e11.value.context) || t0(e11.value.context))
                    return void this.sendPausePlayReport(i2, r10);
                  return;
                case M.Iu.SET_PROGRESS:
                  if ((0, tl.S)(e11.value.context) || tS(e11.value.context) || t0(e11.value.context)) return;
                  return this.changeDynamicPlaysDataByPlayId({
                    playId: e11.value.entity.playId,
                    dynamicData: { seek: true }
                  });
              }
          });
          let s2 = (0, tj.A)(
            () => {
              let e11 = i2.state.queueState.currentEntity.value;
              if (!e11 || (0, tl.S)(e11.context)) return;
              let t11 = this.getDynamicPlaysDataByPlayId(e11.entity.playId), { data: a11 } = t3({
                type: p.PLAYING,
                contextEntityPair: e11,
                totalPlayedSeconds: e11.entity.totalPlayedSeconds,
                endPositionSeconds: i2.state.playerState.progress.value.position,
                ...t11,
                changeReason: g.IN_PROGRESS
              });
              a11.playId && a11.totalPlayedSeconds > 0 && this.storeAndReplace(a11);
            },
            this.storePlaysProgressIntervalMs,
            { trailing: false }
          ), n2 = (0, tj.A)(
            () => {
              this.sendPartialPlayReport(i2, r10);
            },
            2e3,
            { trailing: false }
          );
          this.variables.enableLocalStoredPlaysData && i2.state.playerState.progress.onChange(s2), (this.variables.enablePartialPlayReporting || this.variables.enablePeriodicSendPlays) && i2.state.playerState.progress.onChange(n2), r10.beforeEntityPlayingProcessStart.tapPromise(
            "PlaysPlugin",
            () => (this.variables.enableRemoveDuplicatePlays && this.sentPlayIds.clear(), this.nextPeriodicSendTotalPlayedSeconds = this.periodicSendIntervalSeconds, this.setVibeContextDynamicData(i2), this.sendStartEntityPlay(i2, r10), Promise.resolve())
          ), r10.beforeMediaStartPlaying.tapPromise("PlaysPlugin", () => {
            let { currentEntity: e11 } = i2.state.queueState;
            if (e11.value) {
              var t11;
              let a11 = e11.value.entity.playId, r11 = null == (t11 = this.dynamicPlaysDataByEntitiesPlayId.get(a11)) ? void 0 : t11.startTimestamp;
              e11.value.entity.isDisliked && this.alreadyDislikedPlayIds.add(a11), r11 || this.changeDynamicPlaysDataByPlayId({ playId: a11, dynamicData: { startTimestamp: t1() } });
            }
            return Promise.resolve();
          }), r10.afterMediaEndPlaying.tapPromise("PlaysPlugin", () => {
            let {
              repeat: { value: e11 }
            } = i2.state.queueState, t11 = i2.state.queueState.currentEntity.value, a11 = null == t11 ? void 0 : t11.entity.playId, s3 = (null == t11 ? void 0 : t11.entity.isDisliked) && a11 && !this.alreadyDislikedPlayIds.has(a11);
            return e11 === M.pM.ONE && t11 && !s3 && (this.setChangeReasonToDynamicPlaysData(i2, g.FINISH), this.sendEndEntityPlay(i2, r10)), Promise.resolve();
          }), r10.afterError.tapPromise(
            "PlaysPlugin",
            (e11) => ((e11 instanceof tU || e11 instanceof M.LI) && this.sendEndEntityPlay(i2, r10), Promise.resolve())
          ), r10.beforeContextSet.tapPromise(
            "PlaysPlugin",
            () => (this.setChangeReasonToDynamicPlaysData(i2, g.OTHER_TRACK), this.sendCurrentEntityEndPlay(i2, r10))
          ), r10.afterContextEnd.tapPromise("PlaysPlugin", (e11) => {
            let t11 = i2.state.queueState.currentEntity.value, a11 = null == t11 ? void 0 : t11.entity.playId;
            if (t11) {
              let s3 = g.FINISH;
              t11.entity.isDisliked && a11 && !this.alreadyDislikedPlayIds.has(a11) ? s3 = g.DISLIKE : e11 === M.So.MOVE_FORWARD && (s3 = g.SKIP), this.setChangeReasonToDynamicPlaysData(i2, s3), this.sendEndEntityPlay(i2, r10);
            }
            return Promise.resolve();
          }), r10.afterSetupQueue.tap("PlaysPlugin", () => this.setVibeContextDynamicData(i2)), r10.beforeEntityChange.tapPromise("PlaysPlugin", (e11) => {
            var t11, a11;
            let { currentEntity: s3 } = i2.state.queueState, { method: n3 } = e11, l2 = null == (t11 = s3.value) ? void 0 : t11.entity.playId;
            switch (n3) {
              case M.So.AUTO_MOVE_FORWARD:
                this.setChangeReasonToDynamicPlaysData(i2, g.FINISH);
                break;
              case M.So.MOVE_FORWARD: {
                let e12 = g.SKIP;
                (null == (a11 = s3.value) ? void 0 : a11.entity.isDisliked) && l2 && !this.alreadyDislikedPlayIds.has(l2) && (e12 = g.DISLIKE), this.setChangeReasonToDynamicPlaysData(i2, e12);
                break;
              }
              case M.So.MOVE_BACKWARD:
                this.setChangeReasonToDynamicPlaysData(i2, g.BACK_SKIP);
                break;
              case M.So.SET_INDEX:
              case M.So.PLAY_CONTEXT:
              case M.So.RESTART_CONTEXT:
                this.setChangeReasonToDynamicPlaysData(i2, g.OTHER_TRACK);
            }
            return this.sendCurrentEntityEndPlay(i2, r10, l2);
          }), r10.beforeDestroy.tap(
            "PlaysPlugin",
            () => new Promise((e11) => {
              if (!this.isSendingPlays.value) return void e11();
              let t11 = this.isSendingPlays.onChange((a11) => {
                a11 || (t11(), e11());
              });
            })
          );
        }
        setVibeContextDynamicData(e10) {
          var t10;
          let { queueState: a10 } = e10.state;
          if ((0, eK.i)(null == (t10 = a10.currentEntity.value) ? void 0 : t10.context) && a10.currentEntity.value) {
            let {
              meta: { session: e11, sessionTracks: t11 },
              parentContext: r10
            } = a10.currentEntity.value.context.data, i2 = null == e11 ? void 0 : e11.radioSessionId, s2 = t11 ? t11.batchId : null == e11 ? void 0 : e11.batchId, n2 = t11 ? t11.pumpkin : null == e11 ? void 0 : e11.pumpkin;
            this.changeDynamicPlaysDataByPlayId({
              playId: a10.currentEntity.value.entity.playId,
              dynamicData: { radioSessionId: i2, radioBatchId: s2, isFromPumpkin: n2, isFromAutoflow: !!r10 }
            });
          }
        }
        setChangeReasonToDynamicPlaysData(e10, t10) {
          let { currentEntity: a10 } = e10.state.queueState;
          a10.value && this.changeDynamicPlaysDataByPlayId({ playId: a10.value.entity.playId, dynamicData: { changeReason: t10 } });
        }
        isStorageEnabled() {
          return !!this.variables.enableLocalStoredPlaysData && this.playsStore.isAvailable();
        }
        setPlaysDataForSending(e10) {
          e10.forEach((e11) => {
            let { playId: t10 } = e11;
            this.sendingInProgressForPlayId.set(t10);
          });
        }
        clearSendedPlaysData(e10) {
          e10.forEach((e11) => {
            let { playId: t10 } = e11;
            this.sendingInProgressForPlayId.has(t10) && this.sendingInProgressForPlayId.delete(t10);
          });
        }
        filterPlaysForSending(e10) {
          var t10 = e10.filter((e11) => {
            let { playId: t11 } = e11;
            return !this.sendingInProgressForPlayId.has(t11);
          });
          let a10 = (0, td.A)((0, to.A)(t10, "playId"), t4);
          return (0, th.A)(a10);
        }
        playsResourceSend(e10) {
          return this.setPlaysDataForSending(e10), this.playsResource.sendPlays({ clientNow: t1(), plays: e10 }).finally(() => {
            this.clearSendedPlaysData(e10);
          });
        }
        validatePlaysRequiredData(e10, t10) {
          var a10, r10, i2;
          if (!e10.entity.playId) {
            let a11 = {};
            return a11.contextId = e10.context.data.meta.id, a11.entityId = e10.entity.data.meta.id, null == (r10 = this.hooks) || r10.afterError.promise(new t6("Trying to ".concat(t10, " without playId"), { data: a11 })), false;
          }
          return !!((null == (a10 = e10.entity.data.additional) ? void 0 : a10.from) || e10.context.from) || (null == (i2 = this.hooks) || i2.afterError.promise(
            new t6("from field is required for ".concat(t10, ", but was not found in plays data"))
          ), false);
        }
        deletePlaysData(e10, t10, a10) {
          return this.isStorageEnabled() ? this.playsStore.deleteAllByPlayId(e10, t10).then(() => {
            if (a10) return a10();
          }).catch((e11) => {
            var t11;
            null == (t11 = this.hooks) || t11.afterError.promise(e11);
          }) : Promise.resolve();
        }
        storeAndReplace(e10) {
          if (!this.isStorageEnabled()) return Promise.resolve();
          let t10 = () => {
            var t11;
            return null == (t11 = this.playsStore) ? void 0 : t11.storePlaysData(e10);
          };
          return this.deletePlaysData([e10], (e11) => e11.totalPlayedSeconds > 0, t10);
        }
        sendStoredPlaysData() {
          this.isSendingPlays.value = true;
          let e10 = this.variables.limitOfStoredPlaysData || 25;
          return this.isStorageEnabled() ? this.playsStore.getStoredPlaysData(e10).then((e11) => {
            let t10 = this.filterPlaysForSending(e11);
            if (!t10.length) {
              this.isSendingPlays.value = false;
              return;
            }
            this.playsResourceSend(t10).then(() => {
              this.deletePlaysData(t10).then(() => {
                this.sendStoredPlaysData();
              });
            }).catch((e12) => {
              var a10;
              this.isSendingPlays.value = false, e12 instanceof tn.GX && e12.statusCode === tn.X1.BAD_REQUEST && this.deletePlaysData(t10), null == (a10 = this.hooks) || a10.afterError.promise(new t6("Error while sending plays", { cause: e12 }));
            });
          }).catch((e11) => {
            var t10;
            null == (t10 = this.hooks) || t10.afterError.promise(e11);
          }) : Promise.resolve();
        }
        sendPlayData(e10) {
          this.isSendingPlays.value = true;
          let t10 = [e10];
          return this.playsResourceSend(t10).then(() => {
            this.isStorageEnabled() && this.deletePlaysData(t10, (e11) => e11.totalPlayedSeconds > 0);
          }).catch((a10) => {
            throw a10 instanceof tn.GX && a10.statusCode === tn.X1.BAD_REQUEST ? this.deletePlaysData(t10) : this.storeAndReplace(e10), a10;
          }).finally(() => {
            if (!this.isStorageEnabled()) {
              this.isSendingPlays.value = false;
              return;
            }
            this.sendStoredPlaysData();
          });
        }
        sendCurrentEntityEndPlay(e10, t10, a10) {
          if (e10.state.queueState.currentEntity.value && e10.state.currentContext.value) {
            if ((0, eK.i)(e10.state.currentContext.value)) return this.sendEndEntityPlay(e10, t10);
            this.sendEndEntityPlay(e10, t10).finally(() => {
              a10 && this.alreadyDislikedPlayIds.delete(a10);
            });
          }
          return Promise.resolve();
        }
        sendStartEntityPlay(e10, t10) {
          let a10 = e10.state.queueState.currentEntity.value;
          if (!a10 || !this.validatePlaysRequiredData(a10, "send start entity play")) return Promise.resolve();
          try {
            a10.entity.addTracksToPlayerTime = "".concat(Math.random().toString().slice(2), "-").concat(Math.ceil(Number(/* @__PURE__ */ new Date()) / 1e3));
            let {
              seek: e11,
              pause: r10,
              radioSessionId: i2,
              radioBatchId: s2,
              isFromAutoflow: n2,
              isFromPumpkin: l2
            } = this.getDynamicPlaysDataByPlayId(a10.entity.playId), o2 = t3({
              type: p.START,
              contextEntityPair: a10,
              totalPlayedSeconds: 0,
              endPositionSeconds: 0,
              seek: e11,
              pause: r10,
              radioSessionId: i2,
              radioBatchId: s2,
              isFromAutoflow: n2,
              isFromPumpkin: l2
            });
            if (!this.variables.disableSendPlaysOnTrackStart)
              return this.sendPlayData(o2.data).catch((e12) => {
                let r11 = "", i3 = "";
                a10 && (r11 = a10.context.data.meta.id, i3 = a10.entity.data.meta.id), t10.afterError.promise(
                  new t6("Error while sending plays", { cause: e12, data: { contextId: r11, entityId: i3 } })
                );
              });
          } catch (i2) {
            let e11 = "", r10 = "";
            a10 && (e11 = a10.context.data.meta.id, r10 = a10.entity.data.meta.id), t10.afterError.promise(
              new t6("Error while sending plays", { cause: i2, data: { contextId: e11, entityId: r10 } })
            );
          }
          return Promise.resolve();
        }
        sendPartialPlayReport(e10, t10) {
          let a10 = e10.state.queueState.currentEntity.value;
          if (!a10 || !this.validatePlaysRequiredData(a10, "send partial play report")) return Promise.resolve();
          try {
            let r10 = this.sentPartialPlayReportIds.has(a10.entity.playId), i2 = a10.entity.totalPlayedSeconds, s2 = this.variables.enablePartialPlayReporting && !r10 && i2 >= 30.1, n2 = this.variables.enablePeriodicSendPlays && this.nextPeriodicSendTotalPlayedSeconds < i2;
            if (!(0, tl.S)(a10.context) && (s2 || n2)) {
              let { entity: r11 } = a10, l2 = this.getDynamicPlaysDataByPlayId(r11.playId), o2 = t3({
                type: p.PLAYING,
                contextEntityPair: a10,
                totalPlayedSeconds: i2,
                endPositionSeconds: e10.state.playerState.progress.value.position,
                ...l2,
                changeReason: g.IN_PROGRESS
              });
              return this.sendPlayData(o2.data).then(() => {
                s2 && this.sentPartialPlayReportIds.add(o2.data.playId), n2 && (this.nextPeriodicSendTotalPlayedSeconds += this.periodicSendIntervalSeconds);
              }).catch((e11) => {
                let r12 = "", i3 = "";
                a10 && (r12 = a10.context.data.meta.id, i3 = a10.entity.data.meta.id), t10.afterError.promise(
                  new t6("Error while sending plays", { cause: e11, data: { contextId: r12, entityId: i3 } })
                );
              });
            }
          } catch (i2) {
            let e11 = "", r10 = "";
            a10 && (e11 = a10.context.data.meta.id, r10 = a10.entity.data.meta.id), t10.afterError.promise(
              new t6("Error while sending plays partial play report", {
                cause: i2,
                data: { contextId: e11, entityId: r10 }
              })
            );
          }
          return Promise.resolve();
        }
        sendPausePlayReport(e10, t10) {
          let a10 = e10.state.queueState.currentEntity.value;
          if (!a10 || !this.validatePlaysRequiredData(a10, "send pause play report")) return Promise.resolve();
          try {
            let r10 = a10.entity.totalPlayedSeconds, { entity: i2 } = a10, s2 = this.getDynamicPlaysDataByPlayId(i2.playId), n2 = t3({
              type: p.PAUSE,
              contextEntityPair: a10,
              totalPlayedSeconds: r10,
              endPositionSeconds: e10.state.playerState.progress.value.position,
              ...s2,
              changeReason: void 0
            });
            return this.sendPlayData(n2.data).catch((e11) => {
              let r11 = "", i3 = "";
              a10 && (r11 = a10.context.data.meta.id, i3 = a10.entity.data.meta.id), t10.afterError.promise(
                new t6("Error while sending plays", { cause: e11, data: { contextId: r11, entityId: i3 } })
              );
            });
          } catch (i2) {
            let e11 = "", r10 = "";
            a10 && (e11 = a10.context.data.meta.id, r10 = a10.entity.data.meta.id), t10.afterError.promise(
              new t6("Error while sending plays pause play report", {
                cause: i2,
                data: { contextId: e11, entityId: r10 }
              })
            );
          }
          return Promise.resolve();
        }
        sendEndEntityPlay(e10, t10) {
          let a10 = e10.state.queueState.currentEntity.value;
          if (!a10 || !this.validatePlaysRequiredData(a10, "send end entity play")) return Promise.resolve();
          try {
            let r10 = this.variables.enableRemoveDuplicatePlays, i2 = !!r10 && this.sentPlayIds.has(a10.entity.playId);
            if (!this.sentPlayIds.has(a10.entity.playId) && !i2) {
              let { entity: i3 } = a10, s2 = a10.entity.totalPlayedSeconds, { changeReason: n2, ...l2 } = this.getDynamicPlaysDataByPlayId(i3.playId);
              r10 && this.sentPlayIds.add(i3.playId);
              let o2 = t3({
                type: p.END,
                contextEntityPair: a10,
                totalPlayedSeconds: s2,
                endPositionSeconds: e10.state.playerState.progress.value.position,
                changeReason: n2,
                ...l2
              });
              return this.dynamicPlaysDataByEntitiesPlayId.delete(o2.data.playId), this.variables.enablePartialPlayReporting && this.sentPartialPlayReportIds.delete(o2.data.playId), this.sendPlayData(o2.data).catch((e11) => {
                let r11 = "", i4 = "";
                a10 && (r11 = a10.context.data.meta.id, i4 = a10.entity.data.meta.id), t10.afterError.promise(
                  new t6("Error while sending plays", { cause: e11, data: { contextId: r11, entityId: i4 } })
                );
              }).finally(() => {
                i3.data.isRestored && (i3.data.isRestored = false);
              });
            }
          } catch (i2) {
            let e11 = "", r10 = "";
            a10 && (e11 = a10.context.data.meta.id, r10 = a10.entity.data.meta.id), t10.afterError.promise(
              new t6("Error while sending plays", { cause: i2, data: { contextId: e11, entityId: r10 } })
            );
          }
          return Promise.resolve();
        }
        changeDynamicPlaysDataByPlayId(e10) {
          let { playId: t10, dynamicData: a10 } = e10, r10 = this.dynamicPlaysDataByEntitiesPlayId.get(t10);
          this.dynamicPlaysDataByEntitiesPlayId.set(t10, { ...null != r10 ? r10 : {}, ...null != a10 ? a10 : {} });
        }
        getDynamicPlaysDataByPlayId(e10) {
          var t10, a10, r10;
          let i2 = this.dynamicPlaysDataByEntitiesPlayId.get(e10);
          return {
            seek: null != (t10 = null == i2 ? void 0 : i2.seek) && t10,
            pause: null != (a10 = null == i2 ? void 0 : i2.pause) && a10,
            maxPlayerStage: null != (r10 = null == i2 ? void 0 : i2.maxPlayerStage) ? r10 : m.PREPARE,
            startTimestamp: null == i2 ? void 0 : i2.startTimestamp,
            radioSessionId: null == i2 ? void 0 : i2.radioSessionId,
            radioBatchId: null == i2 ? void 0 : i2.radioBatchId,
            isFromAutoflow: null == i2 ? void 0 : i2.isFromAutoflow,
            isFromPumpkin: null == i2 ? void 0 : i2.isFromPumpkin,
            changeReason: null == i2 ? void 0 : i2.changeReason
          };
        }
        constructor(e10) {
          (0, w._)(this, "dynamicPlaysDataByEntitiesPlayId", /* @__PURE__ */ new Map()), (0, w._)(this, "sendingInProgressForPlayId", /* @__PURE__ */ new Map()), (0, w._)(this, "sentPlayIds", /* @__PURE__ */ new Set()), (0, w._)(this, "sentPartialPlayReportIds", /* @__PURE__ */ new Set()), (0, w._)(this, "alreadyDislikedPlayIds", /* @__PURE__ */ new Set()), (0, w._)(this, "playsResource", void 0), (0, w._)(this, "playsStore", void 0), (0, w._)(this, "variables", void 0), (0, w._)(this, "storePlaysProgressIntervalMs", void 0), (0, w._)(this, "periodicSendIntervalSeconds", void 0), (0, w._)(this, "nextPeriodicSendTotalPlayedSeconds", void 0), (0, w._)(this, "isSendingPlays", void 0), (0, w._)(this, "hooks", void 0);
          let { httpClient: t10, playsResourceConfig: a10, variables: r10 } = e10;
          this.playsResource = new ts(t10, a10), this.variables = r10 || {}, this.storePlaysProgressIntervalMs = e10.storePlaysProgressIntervalMs || 1e4, this.periodicSendIntervalSeconds = e10.periodicSendIntervalSeconds || 30, this.nextPeriodicSendTotalPlayedSeconds = this.periodicSendIntervalSeconds;
          let i2 = this.variables.limitOfStoredPlaysData || 100;
          this.playsStore = new t9(i2), this.isSendingPlays = new et.cJ(false);
        }
      }
      class ae {
        send(e10) {
          return this.transport.send(e10, { topLevelParameter: "player-metrics" });
        }
        constructor(e10) {
          (0, w._)(this, "transport", void 0), this.transport = e10;
        }
      }
      class at {
        send(e10) {
          return this.transport.send(e10, { project: "Player" });
        }
        constructor(e10) {
          (0, w._)(this, "transport", void 0), this.transport = e10;
        }
      }
      let aa = [];
      function ar(e10, t10) {
        let a10, r10, i2 = e10.state.queueState.order.value, s2 = e10.state.queueState.index.value, n2 = e10.state.currentContext.value, l2 = e10.state.queueState.entityList.value, o2 = e10.state.queueState.repeat.value === M.pM.CONTEXT;
        aa.forEach((e11) => e11());
        for (let t11 = s2 - 1; t11 >= 0; t11--) {
          let r11 = i2[t11];
          if ("number" != typeof r11) break;
          let s3 = l2[r11], n3 = null == s3 ? void 0 : s3.canBePlayed({
            index: t11,
            entityChangeMethod: M.So.MOVE_BACKWARD,
            filterParams: e10.state.queueState.filterParams.value
          });
          if (void 0 !== s3 && !s3.entity.hidden && n3) {
            a10 = s3.entity;
            break;
          }
        }
        let d2 = !!a10 || o2;
        for (let t11 = s2 + 1; t11 < i2.length; t11++) {
          let a11 = i2[t11];
          if ("number" != typeof a11) break;
          let s3 = l2[a11], n3 = null == s3 ? void 0 : s3.canBePlayed({
            index: t11,
            entityChangeMethod: M.So.MOVE_FORWARD,
            filterParams: e10.state.queueState.filterParams.value
          });
          if (void 0 !== s3 && !s3.entity.hidden && n3) {
            r10 = s3.entity;
            break;
          }
        }
        let u2 = !!r10 || o2 && !!a10 || !o2 && t10;
        if (n2 && (n2.availableActions.moveBackward.value = d2, n2.availableActions.moveForward.value = u2 && !(0, tl.S)(n2), a10 || r10 || !o2 || (n2.availableActions.moveBackward.value = false, n2.availableActions.moveForward.value = false)), (0, tl.S)(n2))
          return;
        if (!a10) {
          let t11 = e10.state.playerState.progress.onChange((t12) => {
            n2 && t12 && ((o2 = e10.state.queueState.repeat.value === M.pM.CONTEXT) && !a10 && !r10 || !o2) && (n2.availableActions.moveBackward.value = t12.position > M.DS);
          });
          aa.push(t11);
        }
        let c2 = e10.state.queueState.repeat.onChange((e11) => {
          if (n2) {
            if (e11 === M.pM.CONTEXT) {
              n2.availableActions.moveBackward.value = !!a10 || 0 === s2 && !!r10, n2.availableActions.moveForward.value = !!r10 || !!a10;
              return;
            }
            n2.availableActions.moveBackward.value = !!a10, n2.availableActions.moveForward.value = !!r10 || t10;
          }
        });
        aa.push(c2);
      }
      let ai = [O.S.AUDIOBOOK, O.S.FAIRY_TALE, O.S.PODCAST, O.S.COMMENT];
      var as = a(15099);
      let an = (e10) => {
        let { meta: t10 } = e10.data, a10 = "albums" in t10 && t10.albums && t10.albums.length > 0 && t10.albums[0] && t10.albums[0].type === as._.PODCAST;
        return !!("type" in t10 && t10.type && ai.includes(t10.type) || a10);
      };
      class al {
        apply(e10) {
          let { hooks: t10, playback: a10 } = e10, r10 = () => {
            !(function(e12) {
              let { playback: t12, isVibeRepeatEnabled: a11 } = e12, { value: r12 } = t12.state.currentContext, { value: i2 } = t12.state.queueState.currentEntity;
              if (!r12 || !i2) return;
              let { meta: s2 } = i2.entity.data, n2 = (0, eK.i)(r12), l2 = (0, tl.S)(r12), o2 = "type" in s2 && s2.type && ai.includes(s2.type), d2 = !n2 && !l2 && !o2, u2 = (!n2 || a11) && !l2 && !o2;
              r12.availableActions.shuffle.value = d2, r12.availableActions.repeat.value = u2, !d2 && t12.state.queueState.shuffle.value && t12.toggleShuffle();
              let c2 = t12.state.queueState.repeat.value, h2 = !u2 && c2 !== M.pM.NONE, g2 = u2 && n2 && c2 === M.pM.CONTEXT;
              (h2 || g2) && t12.setRepeatMode(M.pM.NONE);
            })({ playback: a10, isVibeRepeatEnabled: this.variables.isVibeRepeatEnabled });
            let { value: e11 } = a10.state.currentContext, { value: t11 } = a10.state.queueState.currentEntity, r11 = void 0 !== t11;
            if (void 0 !== e11 && r11) {
              let a11 = an(t11.entity);
              e11.availableActions.speed.value = !!a11;
            }
          };
          t10.afterContextSet.tap("AvailableActionsPlugin", r10), t10.beforeMediaStartPlaying.tap("AvailableActionsPlugin", r10), a10.state.queueState.entityList.onChange(() => {
            r10(), ar(a10, this.variables.isAutoflowEnabled);
          }), a10.state.queueState.filterParams.onChange(() => {
            r10(), ar(a10, this.variables.isAutoflowEnabled);
          }), a10.state.queueState.index.onChange(() => {
            ar(a10, this.variables.isAutoflowEnabled);
          }), a10.state.queueState.repeat.onChange((e11) => {
            let { value: t11 } = a10.state.currentContext;
            (0, eK.i)(t11) && this.variables.isVibeRepeatEnabled && e11 === M.pM.CONTEXT && a10.setRepeatMode(M.pM.ONE);
          });
        }
        constructor({ variables: e10 }) {
          (0, w._)(this, "variables", void 0), this.variables = e10;
        }
      }
      class ao {
        apply(e10) {
          let { hooks: t10, playback: a10 } = e10;
          t10.afterContextSet.tap("ApplyContextPlugin", () => {
            let e11 = a10.state.currentContext.value;
            e11 && e11 instanceof M.EX && e11.apply({ hooks: t10, playback: a10 });
          });
        }
      }
      class ad {
        apply(e10) {
          let { playback: t10, hooks: a10 } = e10;
          t10.state.playerState.event.onChange(() => {
            let { currentEntity: e11 } = t10.state.queueState;
            if (e11.value)
              switch (t10.state.playerState.event.value) {
                case M.Iu.PAUSED:
                  e11.value.entity.saveTimeStageOfPlayback({
                    stage: r.NOT_PLAYING,
                    reason: "event-".concat(M.Iu.PAUSED)
                  });
                  break;
                case M.Iu.WAITING:
                  e11.value.entity.saveTimeStageOfPlayback({
                    stage: r.NOT_PLAYING,
                    reason: "event-".concat(M.Iu.WAITING)
                  });
                  break;
                case M.Iu.PLAYING:
                  e11.value.entity.saveTimeStageOfPlayback({ stage: r.PLAYING, reason: "event-".concat(M.Iu.PLAYING) });
                  break;
                case M.Iu.MEDIA_ELEMENT_ERROR:
                  e11.value.entity.saveTimeStageOfPlayback({
                    stage: r.NOT_PLAYING,
                    reason: "event-".concat(M.Iu.MEDIA_ELEMENT_ERROR)
                  });
              }
          }), a10.beforeEntityPlayingProcessStart.tapPromise("TotalPlayedTimePlugin", () => {
            let { currentEntity: e11 } = t10.state.queueState;
            return e11.value && e11.value.entity.clearTimeStagesOfPlayback(), Promise.resolve();
          }), a10.afterMediaStartPlaying.tapPromise("TotalPlayedTimePlugin", () => {
            let { currentEntity: e11 } = t10.state.queueState;
            return e11.value && e11.value.entity.saveTimeStageOfPlayback({ stage: r.PLAYING, reason: "hook-afterMediaStartPlaying" }), Promise.resolve();
          }), a10.afterMediaEndPlaying.tapPromise("TotalPlayedTimePlugin", () => {
            let { currentEntity: e11 } = t10.state.queueState;
            return e11.value && e11.value.entity.saveTimeStageOfPlayback({ stage: r.NOT_PLAYING, reason: "hook-afterMediaEndPlaying" }), Promise.resolve();
          }), a10.beforeEntityChange.tapPromise("TotalPlayedTimePlugin", () => {
            let { currentEntity: e11 } = t10.state.queueState;
            return e11.value && e11.value.entity.saveTimeStageOfPlayback({ stage: r.NOT_PLAYING, reason: "hook-beforeEntityChange" }), Promise.resolve();
          }), a10.beforeContextSet.tapPromise("TotalPlayedTimePlugin", () => {
            let { currentEntity: e11 } = t10.state.queueState;
            return e11.value && e11.value.entity.saveTimeStageOfPlayback({ stage: r.NOT_PLAYING, reason: "hook-beforeContextSet" }), Promise.resolve();
          });
        }
      }
      function au(e10) {
        return (null == e10 ? void 0 : e10.data.type) === F.R.Generative;
      }
      !(function(e10) {
        e10.PLAY = "play", e10.PAUSE = "pause", e10.NEXT = "nexttrack", e10.PREV = "previoustrack", e10.SEEK = "seekto", e10.STOP = "stop";
      })(v || (v = {}));
      let ac = [40, 50, 80, 100, 200, 300, 400], ah = [v.PLAY, v.PAUSE, v.STOP, v.SEEK];
      class ag {
        isSupported() {
          return "mediaSession" in window.navigator && "MediaMetadata" in window;
        }
        handleMediaActionEvents(e10, t10) {
          let { action: a10 } = e10;
          switch (a10) {
            case v.PLAY:
              t10.resume();
              break;
            case v.PAUSE:
            case v.STOP:
              t10.pause();
              break;
            case v.NEXT:
              t10.moveForward();
              break;
            case v.PREV:
              t10.moveBackward();
              break;
            case v.SEEK: {
              var r10;
              if (au(null == (r10 = t10.state.queueState.currentEntity.value) ? void 0 : r10.entity)) return;
              let { seekTime: a11 } = e10;
              a11 && t10.setProgress(a11);
            }
          }
        }
        prepareMetadata(e10) {
          let t10, a10, r10 = { title: e10.title };
          if ("artists" in e10 && (r10.artist = (e10.artists || []).map((e11) => e11.name).join(", ")), "albums" in e10) {
            var i2, s2;
            r10.album = null == (s2 = e10.albums) || null == (i2 = s2[0]) ? void 0 : i2.title;
          }
          return "coverUri" in e10 && (t10 = e10.coverUri), "imageUrl" in e10 && (t10 = e10.imageUrl), t10 && (a10 = ac.map((e11) => {
            let a11 = "".concat(e11, "x").concat(e11);
            "Safari" === this.browserName && (a11 = "".concat(2 * e11, "x").concat(2 * e11));
            let r11 = "";
            return "string" == typeof t10 && (r11 = t10.startsWith("blob:") ? t10 : "https://".concat(t10.replace("%%", a11))), { sizes: a11, src: r11, type: "image/jpg" };
          })), r10.artwork = a10, r10;
        }
        updateMetadata(e10) {
          if (!e10) return;
          let t10 = this.prepareMetadata(e10);
          window.navigator.mediaSession.metadata = new MediaMetadata(t10);
        }
        handlePlayerEvents(e10) {
          let t10, a10;
          e10.state.playerState.event.onChange(() => {
            if (e10.state.playerState.event.value === M.Iu.UPDATING_PROGRESS) {
              var t11, a11;
              this.updateMetadata(null == (t11 = e10.state.queueState.currentEntity.value) ? void 0 : t11.entity.data.meta), au(null == (a11 = e10.state.queueState.currentEntity.value) ? void 0 : a11.entity) ? navigator.mediaSession.setPositionState({ duration: 0, position: 0 }) : navigator.mediaSession.setPositionState(), ah.forEach((t12) => {
                try {
                  window.navigator.mediaSession.setActionHandler(t12, (t13) => this.handleMediaActionEvents(t13, e10));
                } catch (e11) {
                  console.log('The media session action "'.concat(t12, '" is not supported yet.'));
                }
              });
            }
          }), e10.state.currentContext.onChange(() => {
            var r10, i2;
            null == t10 || t10(), null == a10 || a10(), t10 = null == (r10 = e10.state.currentContext.value) ? void 0 : r10.availableActions.moveBackward.onChange(() => {
              var t11, a11;
              let r11 = null != (a11 = null == (t11 = e10.state.currentContext.value) ? void 0 : t11.availableActions.moveBackward.value) && a11;
              window.navigator.mediaSession.setActionHandler(
                v.PREV,
                r11 ? (t12) => this.handleMediaActionEvents(t12, e10) : null
              );
            }), a10 = null == (i2 = e10.state.currentContext.value) ? void 0 : i2.availableActions.moveForward.onChange(() => {
              var t11, a11;
              let r11 = null != (a11 = null == (t11 = e10.state.currentContext.value) ? void 0 : t11.availableActions.moveForward.value) && a11;
              window.navigator.mediaSession.setActionHandler(
                v.NEXT,
                r11 ? (t12) => this.handleMediaActionEvents(t12, e10) : null
              );
            });
          });
        }
        apply(e10) {
          let { playback: t10 } = e10;
          this.isSupported() && this.handlePlayerEvents(t10);
        }
        constructor({ browserName: e10, browserVersion: t10 }) {
          (0, w._)(this, "browserName", void 0), (0, w._)(this, "browserVersion", void 0), this.browserName = e10, this.browserVersion = t10;
        }
      }
      class ay {
        apply(e10) {
          let { hooks: t10, playback: a10 } = e10;
          t10.afterError.tapPromise("LoggerPlugin", (e11) => {
            let t11, r10 = a10.state.queueState.currentEntity.value ? a10.state.queueState.currentEntity.value.entity.mediaSourceData : null;
            (t11 = e11 instanceof W.t ? e11 : new W.t("Error in Sonata player", { code: "E_SONATA", cause: e11 })).name = "[Sonata] ".concat(t11.name);
            let i2 = t11.cause ? (0, N.createObjectFromError)(t11.cause) : void 0;
            return this.logger.error(t11, {
              ...t11.data,
              ...r10 || {},
              code: t11.code,
              cause: i2,
              stack: t11.stack,
              message: t11.message
            }), Promise.resolve();
          });
        }
        constructor(e10) {
          (0, w._)(this, "logger", void 0);
          let { logger: t10 } = e10;
          this.logger = t10;
        }
      }
      (P || (P = {})).QUALITY_CHANGE = "QUALITY_CHANGE";
      class am {
        apply(e10) {
          let { playback: t10, hooks: a10 } = e10;
          this.quality.onChange(() => {
            t10.state.playerState.status.value !== M.MT.IDLE && t10.reloadEntity(P.QUALITY_CHANGE).catch((e11) => {
              a10.afterError.promise(e11);
            });
          });
        }
        constructor(e10) {
          (0, w._)(this, "quality", void 0), this.quality = e10;
        }
      }
      var ap = a(34720);
      let av = (e10) => "object" == typeof e10 && e10 && "rememberPosition" in e10 && "boolean" == typeof e10.rememberPosition;
      class aP {
        apply(e10) {
          let { hooks: t10, playback: a10 } = e10;
          t10.beforeEntityChange.tapPromise("ContinuePlayingPlugin", () => {
            let { position: e11, duration: t11 } = this.getTimingsFromPlayback(a10);
            return new Promise((r10) => {
              e11 !== t11 && this.checkBeforeProgressSync(a10), r10();
            });
          }), a10.state.playerState.status.onChange((e11) => {
            (e11 === M.MT.PAUSED || e11 === M.MT.STOPPED) && (this.clearTimeout(), this.checkBeforeProgressSync(a10)), e11 === M.MT.PLAYING && this.shouldSendProgressSync(a10) && this.setTimeout(a10);
          }), a10.state.playerState.event.onChange(() => {
            if (a10.state.playerState.event.value === M.Iu.SET_PROGRESS) {
              let e11 = a10.state.queueState.currentEntity.value, t11 = a10.state.playerState.progress.value.position;
              if (!e11) return;
              let { entity: r10 } = e11;
              av(r10.data.meta) && r10.data.meta.rememberPosition && (e11.lastSeekPosition = t11);
            }
          }), a10.state.queueState.currentEntity.onChange(() => {
            let e11 = a10.state.queueState.currentEntity.value;
            if (!e11) return;
            let { entity: t11 } = e11;
            if (av(t11.data.meta) && t11.data.meta.rememberPosition && j(t11.data.meta)) {
              let { endPositionSec: a11 } = t11.data.meta.streamProgress;
              t11.everFinished ? e11.positionSec = a11 : e11.positionSec = void 0 !== e11.lastSeekPosition ? e11.lastSeekPosition : a11;
            }
          });
        }
        checkBeforeProgressSync(e10) {
          var t10;
          if (this.clearTimeout(), !this.shouldSendProgressSync(e10)) return;
          let { position: a10, duration: r10 } = this.getTimingsFromPlayback(e10), i2 = null == (t10 = e10.state.queueState.currentEntity.value) ? void 0 : t10.entity.data.meta.id;
          Number.isFinite(r10) && Number.isFinite(a10) && r10 && a10 && i2 && (this.sendProgressSync({ duration: r10, position: a10, trackId: i2 }), e10.state.playerState.status.value === M.MT.PLAYING && this.setTimeout(e10));
        }
        sendProgressSync(e10) {
          let t10 = (/* @__PURE__ */ new Date()).toISOString(), { duration: a10, position: r10, trackId: i2 } = e10;
          this.streamsResource.progressSync({
            lastSyncTimestamp: t10,
            trackStreams: [{ trackId: i2, positionSec: r10, trackLengthSec: a10, finished: r10 === a10, timestamp: t10 }]
          });
        }
        shouldSendProgressSync(e10) {
          var t10;
          if (!this.variables.isEnabled) return false;
          let a10 = null == (t10 = e10.state.queueState.currentEntity.value) ? void 0 : t10.entity.data.meta;
          return !!(a10 && "rememberPosition" in a10 && a10.rememberPosition);
        }
        setTimeout(e10) {
          this.clearTimeout(), this.timeoutId = window.setTimeout(() => {
            this.checkBeforeProgressSync(e10);
          }, 3e4);
        }
        clearTimeout() {
          window.clearTimeout(this.timeoutId);
        }
        getTimingsFromPlayback(e10) {
          return {
            duration: Math.floor(e10.state.playerState.progress.value.duration),
            position: Math.floor(e10.state.playerState.progress.value.position)
          };
        }
        constructor(e10) {
          (0, w._)(this, "streamsResource", void 0), (0, w._)(this, "variables", void 0), (0, w._)(this, "timeoutId", 0);
          let { httpClient: t10, streamsResourceConfig: a10, variables: r10 } = e10;
          this.streamsResource = new ap.c(t10, a10), this.variables = r10;
        }
      }
      var aS = a(81849), aE = a(34518);
      let af = { [aE.N.AACMP4]: "mp4a.40.2", [aE.N.HEAACMP4]: "mp4a.40.5", [aE.N.FLACMP4]: "flac" };
      class ab {
        get src() {
          var e10, t10;
          if ("error" in this.data)
            throw new W.t("Error in DownloadInfoSource data", { data: { error: this.data.error } });
          if (!this.data.urls[0]) throw new W.t("No urls in DownloadInfoSource");
          let a10 = this.getQueryParamsString();
          return a10 ? "".concat(this.data.urls[0]).concat(a10, "#t=").concat(null != (e10 = this.positionSec) ? e10 : 0) : "".concat(this.data.urls[0], "#t=").concat(null != (t10 = this.positionSec) ? t10 : 0);
        }
        get mirrorUrls() {
          if ("error" in this.data)
            throw new W.t("Error in DownloadInfoSource data", { data: { error: this.data.error } });
          let e10 = this.getQueryParamsString(), t10 = this.data.urls.slice(1);
          return e10 ? t10.map((t11) => "".concat(t11).concat(e10)) : t10;
        }
        get key() {
          if ("error" in this.data)
            throw new W.t("Error in DownloadInfoSource data", { data: { error: this.data.error } });
          if (this.data.transport === aS.o.ENCRAW) return this.data.key;
        }
        get canBePreloaded() {
          if ("error" in this.data)
            throw new W.t("Error in DownloadInfoSource data", { data: { error: this.data.error } });
          return [aE.N.FLACMP4, aE.N.AACMP4, aE.N.HEAACMP4].includes(this.data.codec);
        }
        getQueryParamsString() {
          if ("error" in this.data)
            throw new W.t("Error in DownloadInfoSource data", { data: { error: this.data.error } });
          let e10 = af[this.data.codec], t10 = e10 ? "mp4" : void 0, a10 = void 0 === this.sourceIndex ? void 0 : String(this.sourceIndex), r10 = new URLSearchParams();
          t10 && r10.append("container", t10), e10 && r10.append("codec", e10), this.vsid && r10.append("vsid", this.vsid), a10 && r10.append("source_index", a10);
          let i2 = r10.toString();
          return i2 ? "?".concat(i2) : void 0;
        }
        constructor(e10) {
          (0, w._)(this, "type", "downloadInfoSource"), (0, w._)(this, "data", void 0), (0, w._)(this, "vsid", void 0), (0, w._)(this, "sourceIndex", void 0), (0, w._)(this, "loadingTime", void 0), (0, w._)(this, "getFileInfoResponseTime", void 0), (0, w._)(this, "url", void 0), (0, w._)(this, "positionSec", void 0), this.data = e10.data, this.vsid = e10.vsid, this.loadingTime = e10.loadingTime, this.getFileInfoResponseTime = e10.getFileInfoResponseTime, this.url = e10.url, this.sourceIndex = e10.sourceIndex;
        }
      }
      !(function(e10) {
        e10.WANT_PLAY_TRACK = "WANT_PLAY_TRACK", e10.TRACK_IS_BUFFERING = "TRACK_IS_BUFFERING", e10.TRACK_IS_PLAYING = "TRACK_IS_PLAYING", e10.TRACK_IS_PLAYING_MISSED = "TRACK_IS_PLAYING_MISSED", e10.TRACK_ERROR_PREPARE = "TRACK_ERROR_PREPARE", e10.TRACK_ERROR_INITIAL_BUFFERING = "TRACK_ERROR_INITIAL_BUFFERING", e10.TRACK_ERROR_PLAYING = "TRACK_ERROR_PLAYING", e10.REQUEST_TIME = "REQUEST_TIME", e10.TRACK_ERROR_PRE_FETCH = "TRACK_ERROR_PRE_FETCH";
      })(S || (S = {})), (E || (E = {})).GET_FILE_INFO = "get_file_info", (function(e10) {
        e10.SKIPPED = "SKIPPED", e10.NEXT = "NEXT", e10.FROM_QUEUE = "FROM_QUEUE", e10.OTHER = "OTHER";
      })(f || (f = {}));
      var aI = a(92761), a_ = a(30630);
      function ak(e10) {
        switch (e10) {
          case aI.e.LOSSLESS:
          case a_.e.HIGH_QUALITY:
            return b.LOSSLESS;
          case aI.e.NQ:
          case a_.e.BALANCED:
            return b.NQ;
          case aI.e.LQ:
          case a_.e.EFFICIENT:
            return b.LQ;
          case aI.e.PREVIEW:
          case a_.e.PREVIEW:
            return b.PREVIEW;
          case aI.e.SMART_PREVIEW:
            return b.SMART_PREVIEW;
          default:
            return;
        }
      }
      !(function(e10) {
        e10.LOSSLESS = "Lossless", e10.NQ = "NQ", e10.LQ = "LQ", e10.PREVIEW = "Preview", e10.SMART_PREVIEW = "SmartPreview";
      })(b || (b = {})), !(function(e10) {
        e10.BAD_RESPONSE_4XX = "BAD_RESPONSE_4XX", e10.BAD_RESPONSE_5XX = "BAD_RESPONSE_5XX", e10.OTHER = "OTHER";
      })(I || (I = {})), !(function(e10) {
        e10.E_GET_MEDIA_SRC = "E_GET_MEDIA_SRC", e10.E_CREATE_SIGN = "E_CREATE_SIGN", e10.E_UNSUITABLE_ENTITY_TYPE = "E_UNSUITABLE_ENTITY_TYPE";
      })(_ || (_ = {})), (function(e10) {
        e10.NETWORK = "NETWORK", e10.OTHER = "OTHER";
      })(k || (k = {})), !(function(e10) {
        e10.TRACK = "track", e10.SET = "set", e10.TRAILER = "trailer", e10.NON_MUSIC = "non-music";
      })(C || (C = {}));
      let aC = (e10) => {
        let { entity: t10 } = e10;
        return e10.getFadeMode() === M.OQ.MIX ? C.SET : (0, eq.l)(t10) ? C.TRAILER : an(t10) || au(t10) ? C.NON_MUSIC : C.TRACK;
      };
      class aT {
        setHooks(e10) {
          this.hooks = e10;
        }
        getEntityQualityInfo(e10) {
          let t10, a10, r10;
          return !e10.mediaSourceData || "error" in e10.mediaSourceData.data || "downloadInfoSource" !== e10.mediaSourceData.type || (t10 = e10.mediaSourceData.data.codec, a10 = e10.mediaSourceData.data.bitrate), e10.expectedQuality && (r10 = ak(e10.expectedQuality)), { codec: t10, bitrate: a10, expectedQuality: r10 };
        }
        logEvent(e10) {
          let { event: t10, eventName: a10 } = e10;
          this.enableDebugMode && (t10 ? (console.group("".concat(null != a10 ? a10 : "Untitled Log Metrics Event Info")), console.table(t10.data), console.group("Raw event"), console.dir(t10), console.groupEnd(), console.groupEnd()) : console.error("Event in logEvent method not provided"));
        }
        requestTime(e10) {
          var t10, a10;
          if (!(e10.mediaSourceData instanceof ab)) return null;
          let r10 = String(e10.data.meta.id), i2 = null == (t10 = e10.mediaSourceData) ? void 0 : t10.getFileInfoResponseTime, s2 = null == (a10 = e10.mediaSourceData) ? void 0 : a10.url, n2 = null;
          return "number" == typeof i2 && s2 && (n2 = { name: S.REQUEST_TIME, data: { trackId: r10, urlType: E.GET_FILE_INFO, url: s2, time: i2 } }), this.logEvent({ event: n2, eventName: null == n2 ? void 0 : n2.name }), n2 && this.send(n2), n2;
        }
        wantPlayTrack(e10) {
          let { entity: t10 } = e10, a10 = String(t10.data.meta.id), r10 = Math.trunc(performance.now()), i2 = aC(e10), s2 = {
            name: S.WANT_PLAY_TRACK,
            data: {
              trackId: a10,
              uuid: t10.playId,
              expectedQuality: ak(this.mediaConfigController.quality.value),
              contentType: i2
            }
          };
          return this.wantPlayTracksEvents.size > 0 && this.sendTrackIsPlayingMissed(), this.wantPlayTracksEvents.set(t10.playId, { time: r10, event: s2, trackId: a10, contentType: i2 }), this.logEvent({ event: s2, eventName: null == s2 ? void 0 : s2.name }), this.send(s2), s2;
        }
        trackError(e10, t10) {
          let { entity: a10 } = t10, { codec: r10, bitrate: i2, expectedQuality: s2 } = this.getEntityQualityInfo(a10), n2 = aC(t10), l2 = null;
          return e10 instanceof tV ? l2 = {
            name: S.TRACK_ERROR_PREPARE,
            data: {
              trackId: String(a10.data.meta.id),
              uuid: a10.playId,
              type: e10.code === _.E_GET_MEDIA_SRC ? k.NETWORK : k.OTHER,
              subType: (function(e11) {
                let t11 = I.OTHER;
                if (e11.cause instanceof tn.GX)
                  switch (String(e11.cause.statusCode)[0]) {
                    case "4":
                      t11 = I.BAD_RESPONSE_4XX;
                      break;
                    case "5":
                      t11 = I.BAD_RESPONSE_5XX;
                  }
                return t11;
              })(e10),
              name: e10.name,
              code: e10.code,
              bitrate: i2,
              codec: r10,
              expectedQuality: s2,
              contentType: n2
            }
          } : e10 instanceof M.LI && e10.code === M.QC.PLAY ? l2 = {
            name: S.TRACK_ERROR_INITIAL_BUFFERING,
            data: {
              trackId: String(a10.data.meta.id),
              uuid: a10.playId,
              name: e10.name,
              code: e10.code,
              bitrate: i2,
              codec: r10,
              expectedQuality: s2,
              contentType: n2,
              ...e10.cause instanceof DOMException ? { causeCode: e10.cause.code, causeMessage: e10.cause.message, causeName: e10.cause.name } : { causeCode: -1, causeMessage: "Unknown error message", causeName: "Unknown error name" }
            }
          } : e10 instanceof M.LI && e10.code === M.QC.MEDIA_ELEMENT_ERROR ? l2 = {
            name: S.TRACK_ERROR_PLAYING,
            data: {
              trackId: String(a10.data.meta.id),
              uuid: a10.playId,
              name: e10.name,
              code: e10.code,
              bitrate: i2,
              codec: r10,
              expectedQuality: s2,
              contentType: n2,
              ...e10.cause instanceof MediaError ? { causeCode: e10.cause.code, causeMessage: e10.cause.message } : { causeCode: -1, causeMessage: "Unknown cause" }
            }
          } : e10 instanceof M.LI && e10.code === M.QC.PRE_FETCH && (l2 = {
            name: S.TRACK_ERROR_PRE_FETCH,
            data: {
              trackId: String(a10.data.meta.id),
              uuid: a10.playId,
              name: e10.name,
              code: e10.code,
              bitrate: i2,
              codec: r10,
              expectedQuality: s2,
              contentType: n2
            }
          }), e10 instanceof M.LI && this.wantPlayTracksEvents.has(a10.playId) && (!l2 || !("causeCode" in l2.data) || "causeCode" in l2.data && (null == l2 ? void 0 : l2.data.causeCode) !== 20) && this.wantPlayTracksEvents.delete(a10.playId), l2 && this.send(l2), this.logEvent({ event: l2, eventName: null == l2 ? void 0 : l2.name }), l2;
        }
        trackIsBuffering(e10) {
          let { entity: t10 } = e10, a10 = String(t10.data.meta.id), { codec: r10, bitrate: i2 } = this.getEntityQualityInfo(t10);
          if (0 === t10.totalPlayedSeconds) return null;
          let s2 = aC(e10), n2 = {
            name: S.TRACK_IS_BUFFERING,
            data: { trackId: a10, uuid: t10.playId, codec: r10, bitrate: i2, contentType: s2 }
          };
          return this.send(n2), this.logEvent({ event: n2, eventName: n2.name }), n2;
        }
        trackIsPlaying(e10) {
          var t10;
          let { entity: a10 } = e10, r10 = String(a10.data.meta.id), i2 = this.wantPlayTracksEvents.get(a10.playId), s2 = null == i2 ? void 0 : i2.time, n2 = (function(e11) {
            switch (e11) {
              case M.So.SET_INDEX:
              case M.So.MOVE_BACKWARD:
                return f.FROM_QUEUE;
              case M.So.AUTO_MOVE_FORWARD:
                return f.NEXT;
              case M.So.MOVE_FORWARD:
                return f.SKIPPED;
              default:
                return f.OTHER;
            }
          })(
            null == (t10 = this.addtionalInfoByPlayId.get(this.lastAdditionalInfoKey)) ? void 0 : t10.entityChangeMethod
          ), { codec: l2, bitrate: o2, expectedQuality: d2 } = this.getEntityQualityInfo(a10), u2 = aC(e10), c2 = null;
          return "number" == typeof s2 && (c2 = {
            name: S.TRACK_IS_PLAYING,
            data: {
              trackId: r10,
              time: Math.trunc(performance.now() - s2),
              uuid: a10.playId,
              codec: l2,
              bitrate: o2,
              expectedQuality: d2,
              extraTrackType: n2,
              contentType: u2
            }
          }, this.addtionalInfoByPlayId.delete(this.lastAdditionalInfoKey), this.wantPlayTracksEvents.delete(a10.playId), this.lastAdditionalInfoKey = null), c2 && this.send(c2), this.logEvent({ event: c2, eventName: null == c2 ? void 0 : c2.name }), c2;
        }
        sendTrackIsPlayingMissed() {
          let [e10, { trackId: t10, contentType: a10 }] = Array.from(this.wantPlayTracksEvents.entries())[0], r10 = { name: S.TRACK_IS_PLAYING_MISSED, data: { trackId: t10, uuid: e10, contentType: a10 } };
          return this.wantPlayTracksEvents.delete(e10), this.send(r10), this.logEvent({ event: r10, eventName: r10.name }), r10;
        }
        trackHasBeenChanged(e10, t10) {
          let { method: a10 } = t10;
          this.addtionalInfoByPlayId.size && this.addtionalInfoByPlayId.clear(), this.lastAdditionalInfoKey = e10.playId, this.addtionalInfoByPlayId.set(e10.playId, { entityChangeMethod: a10 });
        }
        send(e10) {
          this.transports.forEach((t10) => {
            Promise.resolve().then(() => {
              let a10 = t10.send(e10);
              return a10 instanceof Promise ? a10 : Promise.resolve();
            }).catch((e11) => {
              var t11;
              null == (t11 = this.hooks) || t11.afterError.promise(
                new W.t("Failed to send metrics", {
                  code: "E_METRICS_SEND",
                  cause: (0, N.createObjectFromError)(e11)
                })
              );
            });
          });
        }
        constructor(e10) {
          var t10;
          (0, w._)(this, "mediaConfigController", void 0), (0, w._)(this, "wantPlayTracksEvents", /* @__PURE__ */ new Map()), (0, w._)(this, "addtionalInfoByPlayId", /* @__PURE__ */ new Map()), (0, w._)(this, "lastAdditionalInfoKey", null), (0, w._)(this, "enableDebugMode", void 0), (0, w._)(this, "transports", void 0), (0, w._)(this, "hooks", void 0), this.enableDebugMode = null == (t10 = e10.variables) ? void 0 : t10.enableDebugMode, this.mediaConfigController = e10.mediaConfigController, this.transports = e10.transports;
        }
      }
      class aD {
        apply(e10) {
          let { hooks: t10, playback: a10 } = e10;
          this.metricsEventsStore.setHooks(t10), a10.state.playerState.event.onChange(() => {
            let e11 = a10.state.playerState.event.value;
            if (e11 === M.Iu.WAITING && this.recentMediaPlayerEventType !== M.Iu.SETTING_PROGRESS) {
              let e12 = a10.state.queueState.currentEntity.value;
              e12 && this.metricsEventsStore.trackIsBuffering(e12);
            }
            this.recentMediaPlayerEventType = e11;
          }), t10.beforeEntityChange.tapPromise("MetricsPlugin", (e11) => {
            let t11 = a10.state.queueState.currentEntity.value;
            return t11 && this.metricsEventsStore.trackHasBeenChanged(t11.entity, e11), Promise.resolve();
          }), t10.beforeEntityPlayingProcessStart.tapPromise("MetricsPlugin", () => {
            let e11 = a10.state.queueState.currentEntity.value;
            return e11 && this.metricsEventsStore.wantPlayTrack(e11), Promise.resolve();
          }), t10.afterError.tapPromise("MetricsPlugin", (e11) => {
            let t11 = a10.state.queueState.currentEntity.value;
            return t11 && this.metricsEventsStore.trackError(e11, t11), Promise.resolve();
          }), t10.afterMediaStartPlaying.tapPromise("MetricsPlugin", () => {
            let e11 = a10.state.queueState.currentEntity.value;
            return e11 && this.metricsEventsStore.trackIsPlaying(e11), Promise.resolve();
          }), t10.beforeMediaStartPlaying.tapPromise("MetricsPlugin", () => {
            let e11 = a10.state.queueState.currentEntity.value;
            return e11 && this.metricsEventsStore.requestTime(e11.entity), Promise.resolve();
          });
        }
        constructor(e10) {
          (0, w._)(this, "metricsEventsStore", void 0), (0, w._)(this, "recentMediaPlayerEventType", null), this.metricsEventsStore = new aT(e10);
        }
      }
      var aA = a(12186);
      function ax(e10, t10, a10) {
        return !(e10 instanceof q) && !!e10.isAvailable && (null === e10.mediaSourceData || !("downloadInfoSource" !== e10.mediaSourceData.type || "error" in e10.mediaSourceData.data || tb(e10)) && (!!(performance.now() - e10.mediaSourceData.loadingTime > t10) || (function(e11) {
          switch (e11) {
            case aI.e.LOSSLESS:
            case aI.e.HQ:
              return a_.e.HIGH_QUALITY;
            case aI.e.NQ:
              return a_.e.BALANCED;
            case aI.e.LQ:
          }
          return a_.e.EFFICIENT;
        })(e10.mediaSourceData.data.quality) !== a10.quality.value));
      }
      class aL {
        apply(e10) {
          let { hooks: t10, playback: a10 } = e10, r10 = (0, aA.A)(
            () => {
              this.releaseAllPreloadedSrc(a10), this.preload(a10, t10);
            },
            1e3,
            { trailing: true }
          );
          this.variables.isMediaSourcePreloadEnabled && (a10.state.queueState.nextEntity.onChange(r10), this.mediaConfigController.quality.onChange(() => {
            this.releaseAllPreloadedSrc(a10), this.preload(a10, t10);
          }));
        }
        preloadStrmUrls(e10) {
          let {
            queueState: { order: t10, entityList: a10, nextIndex: r10 }
          } = e10.state;
          if (null !== r10.value) {
            let e11 = (function(e12) {
              let { preloadCount: t11, contextEntityPairs: a11, index: r11, order: i3 } = e12, s2 = 0, n2 = r11, l2 = [];
              for (; s2 < t11 && !(n2 >= i3.length); ) {
                let e13 = i3[n2];
                void 0 !== e13 && l2.push(e13), n2 += 1, s2 += 1;
              }
              return l2.map((e13) => a11[e13]);
            })({
              contextEntityPairs: a10.value,
              index: r10.value,
              order: t10.value,
              preloadCount: this.config.entitiesToPreloadStrmUrlsCount
            }), i2 = (function(e12) {
              let { contextEntityPairs: t11, mediaSourceTtlMs: a11, mediaConfigController: r11 } = e12;
              return t11.filter((e13) => ax(e13.entity, a11, r11));
            })({
              contextEntityPairs: e11,
              mediaSourceTtlMs: this.config.strmUrlsTtlMs,
              mediaConfigController: this.mediaConfigController
            }).map((e12) => e12.entity);
            return 0 === i2.length ? Promise.resolve([]) : this.mediaProvider.getMediaSourceBatch({ entities: i2 }).then(() => e11);
          }
          return Promise.resolve([]);
        }
        preloadSources(e10, t10, a10) {
          return 0 === a10.length ? Promise.resolve() : Promise.allSettled(
            a10.slice(0, this.config.entitiesToPreloadSourceCount).map(
              (a11) => e10.preloadSrc({ entity: a11.entity, bufferGoal: this.config.bufferGoal, positionSec: a11.positionSec }).then(() => {
                this.preloadedSrcArray.push(structuredClone(a11.entity.mediaSourceData));
              }).catch((e11) => t10.afterError.promise(e11))
            )
          ).then(() => Promise.resolve());
        }
        preload(e10, t10) {
          this.preloadStrmUrls(e10).then((a10) => {
            this.preloadSources(e10, t10, a10).catch((e11) => t10.afterError.promise(e11));
          }).catch((e11) => {
            t10.afterError.promise(
              new M.LI("Preload strm urls error", { code: M.QC.PRE_FETCH, cause: (0, N.createObjectFromError)(e11) })
            );
          });
        }
        releaseRedundantPreloadedSrc(e10, t10) {
          if (!(this.preloadedSrcArray.length + t10 <= this.config.preloadedSourcesMaxCount))
            for (; this.preloadedSrcArray.length + t10 !== this.config.preloadedSourcesMaxCount; ) {
              let t11 = this.preloadedSrcArray.shift();
              t11 && e10.releaseSrc(t11);
            }
        }
        releaseAllPreloadedSrc(e10) {
          for (; this.preloadedSrcArray.length; ) {
            let t10 = this.preloadedSrcArray.shift();
            t10 && e10.releaseSrc(t10);
          }
        }
        constructor({ mediaProvider: e10, config: t10, mediaConfigController: a10, variables: r10 }) {
          var i2;
          (0, w._)(this, "variables", void 0), (0, w._)(this, "mediaProvider", void 0), (0, w._)(this, "config", void 0), (0, w._)(this, "mediaConfigController", void 0), (0, w._)(this, "preloadedSrcArray", []), this.variables = {
            isMediaSourcePreloadEnabled: null != (i2 = null == r10 ? void 0 : r10.isMediaSourcePreloadEnabled) && i2
          }, this.mediaProvider = e10, this.mediaConfigController = a10, this.config = t10;
        }
      }
      class aR {
        apply() {
          this.trailerPlayback.hooks.afterContextEnd.tapPromise(
            "TrailerPlugin",
            () => (this.trailerPlayback.restartContext({ playAfterRestart: false }), Promise.resolve())
          ), this.trailerPlayback.hooks.afterMediaPause.tapPromise(
            "TrailerPlugin",
            () => (this.onTrailerPaused(), Promise.resolve())
          ), this.trailerPlayback.hooks.afterMediaStartPlaying.tapPromise(
            "TrailerPlugin",
            () => (this.onTrailerPlaying(), Promise.resolve())
          ), this.trailerPlayback.hooks.afterMediaResume.tapPromise(
            "TrailerPlugin",
            () => (this.onTrailerPlaying(), Promise.resolve())
          );
        }
        constructor({ onTrailerPaused: e10, onTrailerPlaying: t10, playbackController: a10, trailerPlaybackParams: r10 }) {
          if ((0, w._)(this, "onTrailerPaused", void 0), (0, w._)(this, "onTrailerPlaying", void 0), (0, w._)(this, "trailerPlayback", void 0), this.onTrailerPaused = e10, this.onTrailerPlaying = t10, a10.createPlayback(r10.id, {
            factory: r10.factory,
            entityProvider: r10.entityProvider,
            playbackConfig: r10.playbackConfig,
            mediaPlayerParams: r10.mediaPlayerParams,
            syncVolumeWithMainPlayback: true
          }), this.trailerPlayback = a10.getPlayback(r10.id), r10.plugins)
            for (let e11 of r10.plugins) e11.apply({ playback: this.trailerPlayback, hooks: this.trailerPlayback.hooks });
        }
      }
      var aN = a(9348);
      (T || (T = {})).START = "start";
      class aw {
        apply(e10) {
          let { playback: t10 } = e10;
          this.channel && (this.channel.onmessage = (e11) => {
            let { type: a10, id: r10 } = e11.data;
            t10.state.playerState.status.value === M.MT.PLAYING && a10 === T.START && r10 !== this.activeStreamId && t10.pause();
          }, t10.state.playerState.status.onChange((e11) => {
            if (e11 === M.MT.PLAYING) {
              var t11;
              null == (t11 = this.channel) || t11.postMessage({ type: T.START, id: this.activeStreamId });
            }
          }));
        }
        constructor() {
          (0, w._)(this, "channel", void 0), (0, w._)(this, "activeStreamId", void 0), this.activeStreamId = (0, aN.A)(), this.channel = new BroadcastChannel("ya_music_playback");
        }
      }
      class aM {
        push(e10) {
          this.callbacks.push(e10);
        }
        exec() {
          let e10 = [];
          for (let t10 of this.callbacks)
            if (0 === e10.length) e10.push(t10());
            else {
              let a10 = e10[e10.length - 1].then(t10);
              e10.push(a10);
            }
          return Promise.allSettled(e10).then(() => Promise.resolve());
        }
        constructor() {
          (0, w._)(this, "callbacks", []);
        }
      }
      let aO = {
        ynisonToPlayback: (e10) => {
          switch (e10) {
            case x.ot.ONE:
              return M.pM.ONE;
            case x.ot.ALL:
              return M.pM.CONTEXT;
            default:
              return M.pM.NONE;
          }
        }
      };
      class aF extends W.t {
        constructor(e10, { code: t10 = "E_YNISON", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "YnisonException"), Object.setPrototypeOf(this, aF.prototype);
        }
      }
      let aG = (e10, t10) => new aF("[YnisonException] ".concat(e10), { cause: (0, N.createObjectFromError)(t10) }), aK = (e10, t10) => {
        var a10;
        let r10 = null == (a10 = e10.player_state) ? void 0 : a10.player_queue, i2 = (null == r10 ? void 0 : r10.current_playable_index) || 0, s2 = ((null == r10 ? void 0 : r10.playable_list) || [])[i2], n2 = null == r10 ? void 0 : r10.entity_type;
        return !s2 || t10.includes(n2) ? { index: 0 } : { entityId: s2.playable_id, index: i2 };
      }, aj = (e10) => {
        let { playableList: t10, getEntityData: a10, restoredParams: { currentPlayableIndex: r10 } = {} } = e10, i2 = t10.filter((e11) => {
          let { playable_type: t11, playable_id: a11 } = e11;
          return t11 === x.yi.TRACK && a11;
        }).map((e11, t11) => a10(e11, "number" == typeof r10 && r10 >= t11)), s2 = "number" == typeof r10 && i2[r10];
        return s2 && (s2.isRestored = true), i2;
      };
      function aX(e10, t10) {
        return { type: M.z4.Unloaded, meta: { id: e10.playable_id, albumId: e10.album_id_optional }, wasPlayed: t10 };
      }
      function aB(e10) {
        var t10, a10;
        return {
          type: F.R.VibeTrack,
          meta: { id: e10.playable_id, albumId: e10.album_id_optional },
          loadEntityMeta: true,
          wasPlayed: true,
          batchId: null != (a10 = null == (t10 = e10.track_info) ? void 0 : t10.batch_id_optional) ? a10 : void 0
        };
      }
      let aV = (e10) => !isNaN(Number(e10)) && Number(e10) > 0, aU = (e10) => {
        var t10, a10;
        let r10 = null == (t10 = e10.player_state) ? void 0 : t10.player_queue, i2 = (null == r10 ? void 0 : r10.playable_list) || [];
        return r10.from_optional || (null == (a10 = i2[0]) ? void 0 : a10.from) || "embedded-radio";
      }, aq = (e10) => {
        var t10, a10, r10, i2;
        let s2 = null == (t10 = e10.player_state) ? void 0 : t10.player_queue, n2 = (null == s2 ? void 0 : s2.playable_list) || [], l2 = null == (i2 = n2[null == (r10 = e10.player_state) || null == (a10 = r10.player_queue) ? void 0 : a10.current_playable_index]) ? void 0 : i2.playable_id;
        return l2 && n2.length ? { type: J.K.Various, from: aU(e10), meta: { id: l2 } } : null;
      }, aW = (e10) => {
        var t10, a10, r10, i2, s2;
        let n2 = null != (s2 = null == (a10 = e10.player_state) || null == (t10 = a10.player_queue) ? void 0 : t10.current_playable_index) ? s2 : 0;
        return ((null == (i2 = e10.player_state) || null == (r10 = i2.player_queue) ? void 0 : r10.playable_list) || []).slice(0, n2 + 1);
      }, aY = "user:onyourwave", az = (e10, t10) => {
        var a10;
        let r10 = null == (a10 = e10.player_state) ? void 0 : a10.player_queue, i2 = null == r10 ? void 0 : r10.entity_type;
        if (!i2) return null;
        if (t10.includes(i2))
          return { type: J.K.Vibe, from: aU(e10), seeds: [aY], includeTracksInResponse: true, meta: { id: aY } };
        switch (i2) {
          case x.$P.ALBUM:
            return ((e11) => {
              var t11;
              let a11 = null == (t11 = e11.player_state) ? void 0 : t11.player_queue, r11 = null == a11 ? void 0 : a11.entity_id;
              return aV(r11) ? { type: J.K.Album, from: aU(e11), meta: { id: r11 } } : aq(e11);
            })(e10);
          case x.$P.ARTIST:
            return ((e11) => {
              var t11;
              let a11 = null == (t11 = e11.player_state) ? void 0 : t11.player_queue, r11 = null == a11 ? void 0 : a11.entity_id;
              return aV(r11) ? { type: J.K.Artist, from: aU(e11), meta: { id: r11 } } : aq(e11);
            })(e10);
          case x.$P.PLAYLIST:
            return ((e11) => {
              var t11;
              let a11 = null == (t11 = e11.player_state) ? void 0 : t11.player_queue, r11 = null == a11 ? void 0 : a11.entity_id, i3 = aU(e11), [s2, n2] = String(r11).split(":");
              if (aV(s2) && aV(n2)) {
                let e12 = { uid: Number(s2) };
                return { type: J.K.Playlist, from: i3, meta: { id: r11, kind: Number(n2), owner: e12 } };
              }
              return aq(e11);
            })(e10);
          case x.$P.RADIO:
            return ((e11) => {
              var t11, a11, r11, i3, s2;
              let n2 = null == (t11 = e11.player_state) ? void 0 : t11.player_queue, l2 = aW(e11), o2 = null == n2 ? void 0 : n2.entity_id, d2 = null == (s2 = n2.queue) || null == (i3 = s2.wave_queue) || null == (r11 = i3.entity_options) || null == (a11 = r11.wave_entity_optional) ? void 0 : a11.session_id, u2 = l2.map(
                (e12) => e12.album_id_optional ? "".concat(e12.playable_id, ":").concat(e12.album_id_optional) : e12.playable_id
              );
              return "string" == typeof o2 || d2 ? {
                type: J.K.Vibe,
                from: aU(e11),
                seeds: String(o2).split(","),
                includeTracksInResponse: true,
                cloneSessionId: d2,
                meta: { id: o2 },
                queue: u2,
                interactive: false
              } : aq(e11);
            })(e10);
          case x.$P.GENERATIVE:
            return ((e11) => {
              var t11, a11;
              let r11 = null == (t11 = e11.player_state) ? void 0 : t11.player_queue, [i3, s2] = (null == r11 || null == (a11 = r11.entity_id) ? void 0 : a11.split(" ")) || [];
              return i3 ? { type: J.K.Generative, from: aU(e11), meta: { id: i3, stream: s2 ? { id: i3, url: s2 } : void 0 } } : null;
            })(e10);
          case x.$P.VARIOUS:
            return aq(e10);
          default:
            return null;
        }
      };
      function aH(e10) {
        let t10 = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1];
        switch (e10.state.playerState.status.value) {
          case M.MT.PLAYING:
            return false;
          case M.MT.PAUSED:
          case M.MT.STOPPED:
          case M.MT.IDLE:
            return true;
          default:
            return t10;
        }
      }
      let aQ = (e10, t10) => ({ ...e10, filterParams: t10.queueState.filterParams.value }), a$ = (e10, t10) => {
        if (!e10) return null;
        let a10 = { ...e10 };
        return a10.type === J.K.Vibe && (a10.allowExplicit = t10.queueState.filterParams.value.allowExplicit), a10;
      };
      function aZ(e10) {
        let {
          playableList: t10,
          trackSourcesMap: a10,
          from: r10,
          livePlayableIndex: i2,
          currentPlayableIndex: s2,
          getEntityData: n2
        } = e10, l2 = t10.filter((e11) => {
          let { playable_type: t11, playable_id: a11 } = e11;
          return t11 === x.yi.TRACK && a11;
        }).map((e11, t11) => n2({ playable: e11, trackSourcesMap: a10, from: r10, wasPlayed: t11 <= i2 })), o2 = l2[s2];
        return o2 && (o2.isRestored = true), l2;
      }
      var aJ = a(29064);
      function a0(e10, t10) {
        var a10, r10;
        if (!e10 || e10.wave_source) return;
        let i2 = e10.phonoteka_source;
        if (!i2) return;
        let s2 = null != (a10 = i2.entity_context) ? a10 : aJ.h.BASED_ON_ENTITY_BY_DEFAULT;
        return i2.playlist_id ? {
          type: J.K.Playlist,
          sourceContextType: s2,
          from: t10,
          meta: { id: i2.playlist_id.id },
          filter: null != (r10 = i2.playlist_id.filter_optional) ? r10 : void 0
        } : i2.album_id ? { type: J.K.Album, sourceContextType: s2, from: t10, meta: { id: Number(i2.album_id.id) } } : i2.artist_id ? { type: J.K.Artist, sourceContextType: s2, from: t10, meta: { id: Number(i2.artist_id.id) } } : { type: J.K.Various, sourceContextType: s2, from: t10, meta: { id: "" } };
      }
      function a1(e10) {
        var t10, a10, r10;
        let { playable: i2, trackSourcesMap: s2, from: n2, wasPlayed: l2 } = e10, o2 = null == (t10 = i2.track_info) ? void 0 : t10.track_source_key, d2 = a0(void 0 !== o2 ? s2.get(o2) : void 0, n2);
        return {
          type: F.R.VibeTrack,
          meta: { id: i2.playable_id, albumId: i2.album_id_optional },
          loadEntityMeta: true,
          wasPlayed: l2,
          batchId: null != (r10 = null == (a10 = i2.track_info) ? void 0 : a10.batch_id_optional) ? r10 : void 0,
          sourceContextData: d2
        };
      }
      function a3(e10) {
        var t10;
        let { playable: a10, trackSourcesMap: r10, from: i2, wasPlayed: s2 } = e10, n2 = null == (t10 = a10.track_info) ? void 0 : t10.track_source_key, l2 = a0(void 0 !== n2 ? r10.get(n2) : void 0, i2);
        return {
          type: M.z4.Unloaded,
          meta: { id: a10.playable_id, albumId: a10.album_id_optional },
          wasPlayed: s2,
          sourceContextData: l2
        };
      }
      class a2 {
        onYnisonStateUpdated(e10) {
          this.variables.shouldApplyState && this.applyYnisonDiff(e10);
        }
        applyYnisonDiff(e10) {
          var t10, a10, r10, i2, s2, n2, l2;
          let o2 = new aM();
          if (((n2 = e10.diff).player_state && n2.player_state.player_queue && (n2.player_state.player_queue.playable_list || n2.player_state.player_queue.entity_id) ? 0 : 1) ? (l2 = e10.diff).player_state && l2.player_state.player_queue && ("number" == typeof l2.player_state.player_queue.current_playable_index && !l2.player_state.player_queue.playable_list && !l2.player_state.player_queue.entity_id || 0) && o2.push(() => this.changeEntityInCurrentContext(e10.state)) : o2.push(() => this.changeContext(e10.state)), null == (a10 = e10.diff.player_state) || null == (t10 = a10.player_queue) ? void 0 : t10.shuffle_optional) {
            let t11 = e10.diff.player_state.player_queue.shuffle_optional;
            o2.push(() => this.changeShuffle(t11));
          }
          if (null == (i2 = e10.diff.player_state) || null == (r10 = i2.player_queue) ? void 0 : r10.options) {
            let t11 = e10.diff.player_state.player_queue.options;
            if (e10.state.player_state.player_queue.entity_type === x.$P.RADIO) {
              let e11 = t11.repeat_mode === x.ot.ALL, a11 = t11.repeat_mode === x.ot.ONE && true !== this.variables.useWaveQueue;
              (e11 || a11) && (t11 = { ...t11, repeat_mode: x.ot.NONE });
            }
            o2.push(() => this.changeOptions(t11));
          }
          if (null == (s2 = e10.diff.player_state) ? void 0 : s2.status) {
            let t11 = e10.diff.player_state.status;
            o2.push(() => this.changeStatus(t11));
          }
          return o2.exec();
        }
        changeOptions(e10) {
          let t10 = aO.ynisonToPlayback(e10.repeat_mode);
          return this.playback.setRepeatMode(t10), Promise.resolve();
        }
        changeShuffle(e10) {
          let t10 = !!(Array.isArray(e10.playable_indices) && e10.playable_indices.length);
          return this.playback.setShuffle(t10), Promise.resolve();
        }
        changeStatus(e10) {
          let t10 = new aM(), a10 = Number(e10.playback_speed), r10 = Number(e10.progress_ms) / 1e3;
          return Number.isNaN(a10) || t10.push(() => this.playback.setSpeed(a10).then(() => Promise.resolve())), Number.isNaN(r10) || t10.push(() => {
            let e11 = this.playback.state.playerState.status.value === M.MT.PLAYING, t11 = Math.abs(this.playback.state.playerState.progress.value.position - r10);
            if (e11 && t11 > x.O5) return this.playback.setProgress(r10).then(() => Promise.resolve());
            let {
              currentEntity: { value: a11 }
            } = this.playback.state.queueState;
            return a11 && (a11.positionSec = r10), Promise.resolve();
          }), void 0 !== e10.paused && e10.paused !== aH(this.playback, e10.paused) && t10.push(() => this.playback.togglePause()), t10.exec();
        }
        changeContext(e10) {
          var t10, a10, r10;
          let i2 = this.variables.useWaveQueue && (null == (r10 = e10.player_state) || null == (a10 = r10.player_queue) || null == (t10 = a10.queue) ? void 0 : t10.wave_queue) !== void 0, s2 = i2 ? this.getContextParamsWithWaveQueue(e10) : this.getContextParams(e10);
          return s2 ? this.playback.setContext(s2).then(() => {
            let t11 = this.playback.state.queueState.currentEntity.value;
            if (t11 && !t11.entity.hasPlayId() && (t11.entity.playId = (0, aN.A)()), i2) {
              var a11, r11, s3, n2, l2;
              let t12 = null != (l2 = null == (n2 = e10.player_state) || null == (s3 = n2.player_queue) || null == (r11 = s3.queue) || null == (a11 = r11.wave_queue) ? void 0 : a11.live_playable_index) ? l2 : 0;
              this.playback.state.queueState.livePlayableIndex.value = t12;
            }
            return this.playback.stop();
          }).then(() => {
            void 0 !== e10.player_state.status.paused && e10.player_state.status.paused !== aH(this.playback, e10.player_state.status.paused) && this.playback.togglePause();
          }).catch((e11) => {
            this.playback.hooks.afterError.promise(aG("PlaybackSetContextError", e11));
          }) : Promise.resolve();
        }
        changeEntityInCurrentContext(e10) {
          let t10 = e10.player_state.player_queue.current_playable_index;
          return this.playback.setEntityByIndex(t10);
        }
        getContextParamsWithWaveQueue(e10) {
          try {
            var t10, a10, r10, i2, s2, n2, l2;
            let o2 = a$(az(e10, this.fallbackTypesQueueToVibe), this.playback.state);
            if (!o2) return null;
            let d2 = this.factory.createContext({ data: o2 }), u2 = null == (t10 = e10.player_state) ? void 0 : t10.player_queue, c2 = null == u2 || null == (a10 = u2.queue) ? void 0 : a10.wave_queue, h2 = null == c2 || null == (r10 = c2.entity_options) ? void 0 : r10.track_sources, g2 = null != (i2 = null == c2 ? void 0 : c2.live_playable_index) ? i2 : 0, y2 = null != (s2 = null == u2 ? void 0 : u2.from_optional) ? s2 : "", m2 = null != (n2 = null == u2 ? void 0 : u2.current_playable_index) ? n2 : 0, p2 = aQ(aK(e10, this.fallbackTypesQueueToVibe), this.playback.state), v2 = null != (l2 = null == u2 ? void 0 : u2.playable_list) ? l2 : [];
            if ((0, tl.S)(d2)) return { context: d2, loadContextMeta: true };
            if (200 === v2.length) return { context: d2, loadContextMeta: true, queueParams: p2 };
            let P2 = (function(e11) {
              let t11 = /* @__PURE__ */ new Map();
              if (!e11) return t11;
              for (let a11 of e11) t11.set(a11.key, a11);
              return t11;
            })(h2);
            if ((0, eK.i)(d2)) {
              let e11 = !(function(e12, t12, a11) {
                let r11 = e12.length - 1;
                return t12 !== r11 && a11 <= r11;
              })(v2, m2, g2) ? v2 : v2.slice(0, -1), t11 = aZ({
                playableList: e11,
                trackSourcesMap: P2,
                from: y2,
                livePlayableIndex: g2,
                currentPlayableIndex: m2,
                getEntityData: a1
              });
              return { context: d2, entitiesData: t11.length ? t11 : void 0, loadContextMeta: true, queueParams: p2 };
            }
            let S2 = aZ({
              playableList: v2,
              trackSourcesMap: P2,
              from: y2,
              livePlayableIndex: g2,
              currentPlayableIndex: m2,
              getEntityData: a3
            });
            if ((0, tx.p)(d2)) return { context: d2, entitiesData: S2, loadContextMeta: false, queueParams: p2 };
            return { context: d2, entitiesData: S2, loadContextMeta: true, queueParams: p2 };
          } catch (e11) {
            return this.playback.hooks.afterError.promise(aG("GetContextParamsWithWaveQueueError", e11)), null;
          }
        }
        getContextParams(e10) {
          try {
            var t10, a10;
            let r10 = a$(az(e10, this.fallbackTypesQueueToVibe), this.playback.state);
            if (!r10) return null;
            let i2 = this.factory.createContext({ data: r10 }), s2 = null == (a10 = e10.player_state) || null == (t10 = a10.player_queue) ? void 0 : t10.playable_list, n2 = aQ(aK(e10, this.fallbackTypesQueueToVibe), this.playback.state);
            if ((0, eK.i)(i2)) {
              let t11 = aj({
                playableList: aW(e10),
                getEntityData: aB,
                restoredParams: { currentPlayableIndex: e10.player_state.player_queue.current_playable_index }
              });
              return { context: i2, entitiesData: t11.length ? t11 : void 0, loadContextMeta: true, queueParams: n2 };
            }
            let l2 = aj({
              playableList: s2,
              getEntityData: aX,
              restoredParams: { currentPlayableIndex: e10.player_state.player_queue.current_playable_index }
            });
            if ((0, tx.p)(i2)) return { context: i2, entitiesData: l2, loadContextMeta: false, queueParams: n2 };
            if ((0, tl.S)(i2)) return { context: i2, loadContextMeta: true };
            if (200 === s2.length) return { context: i2, loadContextMeta: true, queueParams: n2 };
            return { context: i2, entitiesData: l2, loadContextMeta: true, queueParams: n2 };
          } catch (e11) {
            return this.playback.hooks.afterError.promise(aG("GetContextParamsError", e11)), null;
          }
        }
        destroy() {
          this.unlisteners.forEach((e10) => e10());
        }
        constructor({ factory: e10, playback: t10, ynisonStateController: a10, variables: r10, fallbackTypesQueueToVibe: i2 }) {
          (0, w._)(this, "factory", void 0), (0, w._)(this, "playback", void 0), (0, w._)(this, "variables", void 0), (0, w._)(this, "unlisteners", void 0), (0, w._)(this, "fallbackTypesQueueToVibe", void 0), this.factory = e10, this.playback = t10, this.variables = r10, this.unlisteners = [], this.fallbackTypesQueueToVibe = null != i2 ? i2 : [];
          let s2 = a10.on(x.p$.UPDATED, this.onYnisonStateUpdated.bind(this), "YnisonPlugin");
          this.unlisteners.push(s2);
          let n2 = a10.fullState;
          this.onYnisonStateUpdated({ prevState: n2.prevState, state: n2.state, diff: n2.state });
        }
      }
      let a4 = (e10) => e10.hidden, a6 = (e10) => {
        var t10, a10, r10, i2, s2, n2, l2;
        switch (null == (t10 = e10.state.queueState.currentEntity.value) ? void 0 : t10.entity.data.type) {
          case F.R.Music:
          case F.R.VibeTrack:
            return (null == (a10 = e10.state.currentContext.value) ? void 0 : a10.data.meta.id) ? String(null == (r10 = e10.state.currentContext.value) ? void 0 : r10.data.meta.id) : "";
          case F.R.Generative:
            return (null == (i2 = e10.state.currentContext.value) ? void 0 : i2.data.meta.id) ? String(null == (s2 = e10.state.currentContext.value) ? void 0 : s2.data.meta.id) : "";
          default:
            return (null == (n2 = e10.state.currentContext.value) ? void 0 : n2.data.meta.id) ? String(null == (l2 = e10.state.currentContext.value) ? void 0 : l2.data.meta.id) : "";
        }
      }, a5 = (e10) => {
        switch (e10) {
          case J.K.Album:
            return x.$P.ALBUM;
          case J.K.Playlist:
            return x.$P.PLAYLIST;
          case J.K.Artist:
            return x.$P.ARTIST;
          case J.K.Vibe:
            return x.$P.RADIO;
          case J.K.Various:
            return x.$P.VARIOUS;
          case J.K.Generative:
            return x.$P.GENERATIVE;
          default:
            return x.$P.VARIOUS;
        }
      }, a8 = (e10) => {
        var t10, a10, r10;
        return ((e11) => "object" == typeof e11 && e11 && "durationMs" in e11 && "number" == typeof e11.durationMs)(
          null == (t10 = e10.state.queueState.currentEntity.value) ? void 0 : t10.entity.data.meta
        ) && null != (r10 = null == (a10 = e10.state.queueState.currentEntity.value) ? void 0 : a10.entity.data.meta.durationMs) ? r10 : 0;
      }, a9 = (e10, t10, a10) => "".concat(e10, ":").concat(t10, ":").concat(a10);
      var a7 = a(41730);
      function re(e10) {
        var t10, a10, r10, i2, s2, n2, l2;
        if (!e10) return;
        let o2 = { entityContext: null != (t10 = e10.data.sourceContextType) ? t10 : aJ.h.BASED_ON_ENTITY_BY_DEFAULT };
        if ((0, tD.K)(e10)) {
          let { uid: t11, kind: n3, id: l3 } = null != (a10 = e10.data.meta) ? a10 : {}, d2 = void 0 !== l3 ? String(l3) : void 0, [u2, c2] = null != (r10 = null == d2 ? void 0 : d2.split(":")) ? r10 : [];
          return u2 && c2 ? (o2.playlistId = d2, o2.filterOptional = null != (i2 = e10.data.filter) ? i2 : null) : void 0 !== t11 && void 0 !== n3 && (o2.playlistId = "".concat(t11, ":").concat(n3), o2.filterOptional = null != (s2 = e10.data.filter) ? s2 : null), o2;
        }
        if ((0, eB.F)(e10)) {
          let { id: t11 } = null != (n2 = e10.data.meta) ? n2 : {};
          return void 0 !== t11 && (o2.albumId = String(t11)), o2;
        }
        if ((0, a7.T)(e10)) {
          let { id: t11 } = null != (l2 = e10.data.meta) ? l2 : {};
          void 0 !== t11 && (o2.artistId = String(t11));
        }
        return o2;
      }
      function rt(e10, t10, a10) {
        return t10 && 0 !== t10.length ? a10 ? (function(e11, t11) {
          let a11 = re(e11);
          if (!a11) {
            var r10;
            return null != (r10 = t11.waveSourceKey) ? r10 : 0;
          }
          let { entityContext: i2, playlistId: s2, albumId: n2, artistId: l2 } = a11;
          if (s2) {
            let e12 = a9(i2, "playlist", s2), a12 = t11.exactMatchMap.get(e12);
            if (void 0 !== a12) return a12;
          }
          if (n2) {
            let e12 = a9(i2, "album", n2), a12 = t11.exactMatchMap.get(e12);
            if (void 0 !== a12) return a12;
          }
          if (l2) {
            let e12 = a9(i2, "artist", l2), a12 = t11.exactMatchMap.get(e12);
            if (void 0 !== a12) return a12;
          }
          let o2 = t11.contextOnlyMap.get(i2);
          return null != o2 ? o2 : 0;
        })(e10, a10) : (function(e11, t11) {
          var a11, r10;
          let i2 = re(e11);
          if (!i2) {
            let e12 = t11.find((e13) => void 0 !== e13.wave_source);
            return null != (a11 = null == e12 ? void 0 : e12.key) ? a11 : 0;
          }
          let { entityContext: s2, playlistId: n2, albumId: l2, artistId: o2 } = i2, d2 = t11.find((e12) => {
            var t12, a12, r11;
            return !!e12.phonoteka_source && e12.phonoteka_source.entity_context === s2 && (!!n2 && (null == (t12 = e12.phonoteka_source.playlist_id) ? void 0 : t12.id) === n2 || !!l2 && (null == (a12 = e12.phonoteka_source.album_id) ? void 0 : a12.id) === l2 || !!o2 && (null == (r11 = e12.phonoteka_source.artist_id) ? void 0 : r11.id) === o2);
          });
          if (d2) return d2.key;
          let u2 = t11.find(
            (e12) => !!e12.phonoteka_source && e12.phonoteka_source.entity_context === s2 && (!n2 || !e12.phonoteka_source.playlist_id) && (!l2 || !e12.phonoteka_source.album_id) && (!o2 || !e12.phonoteka_source.artist_id)
          );
          return null != (r10 = null == u2 ? void 0 : u2.key) ? r10 : 0;
        })(e10, t10) : 0;
      }
      function ra(e10) {
        let { playableList: t10, rangeStart: a10, livePlayableIndex: r10, isVibeQueue: i2 } = e10;
        return i2 ? Math.max(0, Math.min(r10 - a10, t10.length)) : t10.length;
      }
      let rr = [aJ.h.BASED_ON_ENTITY_BY_DEFAULT, aJ.h.ARTIST_MY_COLLECTION, aJ.h.ARTIST_FAMILIAR_FROM_WAVE];
      function ri(e10) {
        return { wave_source: e10 ? { source_type: e10 } : {} };
      }
      function rs(e10) {
        return { phonoteka_source: e10 };
      }
      class rn {
        subscribeOnPlayerEvents() {
          let e10 = this.playback.state.playerState.status.onChange((e11) => {
            switch (e11) {
              case M.MT.PLAYING:
              case M.MT.PAUSED:
                this.updateYnisonState();
            }
          }), t10 = this.playback.state.playerState.event.onChange((e11) => {
            switch (e11) {
              case M.Iu.SET_PROGRESS:
                this.ynisonStateController.currentState.player_state.status.progress_ms / 1e3 !== this.playback.state.playerState.progress.value.position && this.updateYnisonState();
                break;
              case M.Iu.SET_SPEED:
                this.ynisonStateController.currentState.player_state.status.playback_speed !== this.playback.state.playerState.speed.value && this.updateYnisonState();
            }
          }), a10 = this.playback.state.playerState.speed.onChange(() => {
            this.updateYnisonState();
          }), r10 = this.playback.state.queueState.repeat.onChange(() => {
            this.updateYnisonState();
          }), i2 = this.playback.state.queueState.shuffle.onChange(() => {
            this.updateYnisonState();
          }), s2 = this.playback.state.queueState.entityList.onChange(() => {
            this.updateYnisonState({ useYnisonStatus: true, useWaveQueue: this.variables.useWaveQueue });
          }), n2 = this.playback.state.queueState.order.onChange(() => {
            this.updateYnisonState({ useYnisonStatus: true, useWaveQueue: this.variables.useWaveQueue });
          });
          this.unsubscribeFromPlayerEvents = () => {
            e10(), t10(), r10(), i2(), a10(), s2(), n2();
          };
        }
        updateYnisonState(e10) {
          setTimeout(() => {
            let t10 = (function(e11) {
              var t11, a10, r10, i2, s2, n2, l2, o2;
              let { playback: d2, ynisonStateController: u2, deviceId: c2, variables: h2 } = e11, {
                devices: g2,
                active_device_id_optional: y2,
                player_state: { player_queue_inject_optional: m2, status: p2 }
              } = u2.currentState, v2 = h2.useWaveQueue && !(0, tl.S)(d2.state.currentContext.value), { filteredEntityList: P2, firstNotPlayedVibeEntity: S2 } = (function(e12, t12) {
                let a11 = e12.state.queueState.index.value, r11 = e12.state.queueState.entityList.value, i3 = null, s3 = null;
                return t12.enableSendLimitedEntityListToYnison && (r11 = r11.filter((e13) => !a4(e13.entity))), (0, eK.i)(e12.state.currentContext.value) && t12.enableSendLimitedEntityListToYnison && ({ vibeHistory: r11, firstNotPlayedVibeEntity: i3, firstNotPlayedVibeEntityIndex: s3 } = ev(r11, a11)), { filteredEntityList: r11, firstNotPlayedVibeEntity: i3, firstNotPlayedVibeEntityIndex: s3 };
              })(d2, h2), E2 = (function(e12, t12) {
                let a11 = e12.state.currentContext.value, r11 = /* @__PURE__ */ new Set(), i3 = [];
                for (let { sourceContext: e13 } of t12) {
                  let t13 = null != e13 ? e13 : a11, { uniqueKey: s3, payload: n3 } = (function(e14, t14) {
                    if (!e14) return { uniqueKey: "wave_source", payload: ri() };
                    let { entityContext: a12, playlistId: r12, albumId: i4, artistId: s4 } = e14;
                    if (r12 || i4 || s4) {
                      let t15 = (function(e15) {
                        var t16;
                        let { entityContext: a13, playlistId: r13, albumId: i5, artistId: s5, filterOptional: n4 } = e15;
                        return r13 ? (t16 = null != n4 ? n4 : null, {
                          uniqueKey: "playlist_".concat(a13, "_").concat(r13, "_").concat(null != t16 ? t16 : ""),
                          payload: rs({ entity_context: a13, playlist_id: { id: r13, filter_optional: t16 } })
                        }) : i5 ? {
                          uniqueKey: "album_".concat(a13, "_").concat(i5),
                          payload: rs({ entity_context: a13, album_id: { id: i5 } })
                        } : s5 ? {
                          uniqueKey: "artist_".concat(a13, "_").concat(s5),
                          payload: rs({ entity_context: a13, artist_id: { id: s5 } })
                        } : null;
                      })(e14);
                      if (t15) return t15;
                    }
                    return rr.includes(a12) && t14 ? { uniqueKey: "wave_source", payload: ri("ONLINE_BY_DEFAULT") } : { uniqueKey: "context_".concat(a12), payload: rs({ entity_context: a12 }) };
                  })(re(t13), (0, eK.i)(t13));
                  r11.has(s3) || (r11.add(s3), i3.push({ key: i3.length, ...n3 }));
                }
                return i3;
              })(d2, P2), f2 = (function(e12) {
                let { entityList: t12, from: a11, trackSources: r11, useWaveQueue: i3 } = e12, s3 = (function(e13) {
                  if (!e13 || 0 === e13.length) return null;
                  let t13 = { waveSourceKey: null, exactMatchMap: /* @__PURE__ */ new Map(), contextOnlyMap: /* @__PURE__ */ new Map() };
                  for (let a12 of e13) {
                    if (void 0 !== a12.wave_source && null === t13.waveSourceKey) {
                      t13.waveSourceKey = a12.key;
                      continue;
                    }
                    if (a12.phonoteka_source) {
                      let { entity_context: e14, playlist_id: r12, album_id: i4, artist_id: s4 } = a12.phonoteka_source;
                      if (r12) {
                        let i5 = a9(e14, "playlist", r12.id);
                        t13.exactMatchMap.has(i5) || t13.exactMatchMap.set(i5, a12.key);
                      } else if (i4) {
                        let r13 = a9(e14, "album", i4.id);
                        t13.exactMatchMap.has(r13) || t13.exactMatchMap.set(r13, a12.key);
                      } else if (s4) {
                        let r13 = a9(e14, "artist", s4.id);
                        t13.exactMatchMap.has(r13) || t13.exactMatchMap.set(r13, a12.key);
                      } else t13.contextOnlyMap.has(e14) || t13.contextOnlyMap.set(e14, a12.key);
                    }
                  }
                  return t13;
                })(r11);
                return t12.map(
                  (e13) => ((e14) => {
                    var t13, a12, r12, i4, s4, n3, l3, o3, d3, u3, c3, h3;
                    let {
                      entityPair: g3,
                      from: y3 = "",
                      trackSources: m3,
                      trackSourceIndex: p3,
                      useWaveQueue: v3 = false
                    } = e14, { entity: P3, sourceContext: S3 } = g3;
                    switch (P3.data.type) {
                      case F.R.Music:
                        return {
                          album_id_optional: "number" == typeof (null == (a12 = P3.data.meta.albums) || null == (t13 = a12[0]) ? void 0 : t13.id) ? String(null == (r12 = P3.data.meta.albums) ? void 0 : r12[0].id) : null,
                          from: y3,
                          playable_id: String(P3.data.meta.id),
                          playable_type: x.yi.TRACK,
                          title: null != (i4 = P3.data.meta.title) ? i4 : "",
                          cover_url_optional: null != (s4 = P3.data.meta.coverUri) ? s4 : null,
                          ...v3 && { track_info: { batch_id_optional: null, track_source_key: rt(S3, m3, p3) } },
                          navigation_id_optional: null,
                          playback_action_id_optional: null
                        };
                      case F.R.Generative:
                        return {
                          album_id_optional: null,
                          from: y3,
                          playable_id: "",
                          playable_type: x.yi.INFINITE,
                          title: null != (n3 = P3.data.meta.title) ? n3 : "",
                          cover_url_optional: null,
                          navigation_id_optional: null,
                          playback_action_id_optional: null
                        };
                      case F.R.VibeTrack:
                        return {
                          album_id_optional: "number" == typeof (null == (o3 = P3.data.meta.albums) || null == (l3 = o3[0]) ? void 0 : l3.id) ? String(null == (d3 = P3.data.meta.albums) ? void 0 : d3[0].id) : null,
                          from: y3,
                          playable_id: String(P3.data.meta.id),
                          playable_type: x.yi.TRACK,
                          title: null != (u3 = P3.data.meta.title) ? u3 : "",
                          cover_url_optional: null != (c3 = P3.data.meta.coverUri) ? c3 : null,
                          track_info: {
                            batch_id_optional: null != (h3 = P3.data.batchId) ? h3 : null,
                            track_source_key: rt(S3, m3, p3)
                          },
                          navigation_id_optional: null,
                          playback_action_id_optional: null
                        };
                      default:
                        return {
                          album_id_optional: null,
                          from: y3,
                          playable_id: String(P3.data.meta.id),
                          playable_type: x.yi.TRACK,
                          title: "",
                          cover_url_optional: null,
                          navigation_id_optional: null,
                          playback_action_id_optional: null
                        };
                    }
                  })({ entityPair: e13, from: a11, trackSources: r11, trackSourceIndex: s3, useWaveQueue: i3 })
                );
              })({
                entityList: P2,
                from: null == (t11 = d2.state.currentContext.value) ? void 0 : t11.from,
                trackSources: E2,
                useWaveQueue: v2
              }), {
                playableIndices: b2,
                currentPlayableIndex: I2,
                playableList: _2,
                livePlayableIndex: k2
              } = (function(e12) {
                let { playableList: t12, currentPlayableIndex: a11, playback: r11, newIndexOrderMap: i3, variables: s3 } = e12, n3 = r11.state.queueState.order.value, l3 = (0, eK.i)(r11.state.currentContext.value), { livePlayableIndex: o3 } = r11.state.queueState;
                if (s3.enableSendLimitedEntityListToYnison && (n3 = n3.filter((e13) => i3.has(e13)).map((e13) => i3.get(e13))), t12.length <= 200)
                  return {
                    playableList: t12,
                    currentPlayableIndex: a11,
                    playableIndices: n3,
                    livePlayableIndex: ra({
                      playableList: t12,
                      rangeStart: 0,
                      livePlayableIndex: o3.value,
                      isVibeQueue: l3
                    })
                  };
                if (r11.state.queueState.shuffle.value) {
                  let e13 = n3.indexOf(a11), r12 = n3.slice(e13, 200), i4 = [...r12].sort((e14, t13) => e14 - t13).map((e14) => t12[e14]), s4 = /* @__PURE__ */ new Map(), l4 = r12.map((e14) => {
                    var a12;
                    let r13 = t12[e14].playable_id, n4 = null != (a12 = s4.get(r13)) ? a12 : -1, l5 = i4.findIndex((e15, t13) => t13 > n4 && e15.playable_id === r13);
                    return s4.set(r13, l5), l5;
                  }), o4 = i4.findIndex((e14) => e14.playable_id === t12[a11].playable_id);
                  return {
                    playableList: i4,
                    currentPlayableIndex: o4,
                    playableIndices: l4,
                    livePlayableIndex: i4.length
                  };
                }
                let d3 = t12[a11].playable_id, u3 = Math.max(0, a11 - 100);
                u3 + 200 > t12.length && (u3 = t12.length - 200);
                let c3 = t12.slice(u3, u3 + 200), h3 = c3.findIndex((e13) => e13.playable_id === d3);
                return {
                  playableList: c3,
                  currentPlayableIndex: h3,
                  livePlayableIndex: ra({
                    playableList: c3,
                    rangeStart: u3,
                    livePlayableIndex: o3.value,
                    isVibeQueue: l3
                  }),
                  playableIndices: n3
                };
              })({
                playableList: f2,
                currentPlayableIndex: (function(e12, t12) {
                  let {
                    order: { value: a11 },
                    index: { value: r11 },
                    entityList: { value: i3 }
                  } = e12.state.queueState, s3 = a11[r11];
                  if ("number" != typeof s3) return -1;
                  let n3 = i3[s3];
                  return t12.findIndex((e13) => {
                    let { entity: t13 } = e13;
                    return t13.data.meta.id === (null == n3 ? void 0 : n3.entity.data.meta.id);
                  });
                })(d2, P2),
                newIndexOrderMap: (function(e12, t12) {
                  let a11 = /* @__PURE__ */ new Map(), r11 = 0;
                  for (let i3 = 0; i3 < e12.length; i3++) {
                    let s3 = e12[i3];
                    s3 && !t12(s3.entity) && (a11.set(i3, r11), r11++);
                  }
                  return a11;
                })(d2.state.queueState.entityList.value, a4),
                playback: d2,
                variables: h2
              }), C2 = (function(e12) {
                let { playback: t12, playableList: a11, firstNotPlayedVibeEntity: r11 } = e12;
                if (!(0, eK.i)(t12.state.currentContext.value) || !r11) return [];
                let i3 = a11.findLast((e13) => String(r11.entity.data.meta.id) === e13.playable_id);
                return i3 ? [i3] : [];
              })({ playback: d2, playableList: _2, firstNotPlayedVibeEntity: S2 }), T2 = aH(d2, p2.paused), D2 = {
                duration_ms: a8(d2),
                progress_ms: ((e12) => {
                  var t12;
                  let a11 = 1e3 * Math.floor(e12.state.playerState.progress.value.position), r11 = a8(e12);
                  return (null == (t12 = e12.state.queueState.currentEntity.value) ? void 0 : t12.context.data.type) === J.K.Generative ? 0 : a11 < r11 ? a11 : 0;
                })(d2),
                paused: T2,
                playback_speed: d2.state.playerState.speed.value,
                version: (0, x.fD)(c2)
              }, A2 = ((e12) => {
                var t12, a11;
                let r11 = null == (t12 = e12.state.queueState.currentEntity.value) ? void 0 : t12.context;
                return (0, eK.i)(r11) && (null == (a11 = r11.data.meta.session) ? void 0 : a11.radioSessionId) ? { session_id: r11.data.meta.session.radioSessionId } : null;
              })(d2);
              return {
                active_device_id_optional: y2,
                devices: g2,
                player_state: {
                  player_queue_inject_optional: m2,
                  status: h2.useYnisonStatus ? p2 : D2,
                  player_queue: {
                    entity_id: a6(d2),
                    entity_type: a5(null == (a10 = d2.state.currentContext.value) ? void 0 : a10.data.type),
                    current_playable_index: I2,
                    playable_list: _2,
                    shuffle_optional: d2.state.queueState.shuffle.value ? { playable_indices: b2 } : null,
                    options: {
                      repeat_mode: ((e12) => {
                        switch (e12) {
                          case M.pM.NONE:
                            return x.ot.NONE;
                          case M.pM.ONE:
                            return x.ot.ONE;
                          case M.pM.CONTEXT:
                            return x.ot.ALL;
                          default:
                            return x.ot.NONE;
                        }
                      })(d2.state.queueState.repeat.value)
                    },
                    entity_context: x.oh.BASED_ON_ENTITY_BY_DEFAULT,
                    from_optional: null != (i2 = null == (r10 = d2.state.currentContext.value) ? void 0 : r10.from) ? i2 : null,
                    initial_entity_optional: (0, tl.S)(
                      null == (s2 = d2.state.queueState.currentEntity.value) ? void 0 : s2.context
                    ) ? {
                      entity_id: a6(d2),
                      entity_type: a5(null == (n2 = d2.state.currentContext.value) ? void 0 : n2.data.type)
                    } : null,
                    adding_options_optional: (0, eK.i)(null == (l2 = d2.state.queueState.currentEntity.value) ? void 0 : l2.context) && (null == (o2 = d2.state.queueState.currentEntity.value) ? void 0 : o2.context.data.meta.session) ? {
                      radio_options: {
                        session_id: d2.state.queueState.currentEntity.value.context.data.meta.session.radioSessionId
                      }
                    } : null,
                    queue: v2 ? {
                      wave_queue: {
                        recommended_playable_list: C2,
                        live_playable_index: k2,
                        entity_options: { track_sources: E2, wave_entity_optional: A2 },
                        navigation_id_optional: null,
                        playback_action_id_optional: null
                      }
                    } : null,
                    version: (0, x.fD)(c2)
                  }
                }
              };
            })({
              playback: this.playback,
              ynisonStateController: this.ynisonStateController,
              deviceId: this.deviceConfig.info.device_id,
              variables: { ...this.variables, ...e10 }
            });
            this.ynisonStateController.updateState({ newState: t10, skipVersionCompare: true, trigger: "YnisonPlugin" });
          }, 0);
        }
        destroy() {
          var e10;
          null == (e10 = this.unsubscribeFromPlayerEvents) || e10.call(this);
        }
        constructor({ playback: e10, ynisonStateController: t10, deviceConfig: a10, variables: r10 }) {
          (0, w._)(this, "unsubscribeFromPlayerEvents", void 0), (0, w._)(this, "playback", void 0), (0, w._)(this, "ynisonStateController", void 0), (0, w._)(this, "deviceConfig", void 0), (0, w._)(this, "variables", void 0), this.playback = e10, this.ynisonStateController = t10, this.deviceConfig = a10, this.variables = r10, this.subscribeOnPlayerEvents(), this.updateYnisonState();
        }
      }
      class rl {
        apply(e10) {
          let { playback: t10, hooks: a10 } = e10, r10 = new a2({
            playback: t10,
            factory: this.factory,
            ynisonStateController: this.ynisonStateController,
            variables: this.variables,
            fallbackTypesQueueToVibe: this.fallbackTypesQueueToVibe
          }), i2 = new rn({
            playback: t10,
            ynisonStateController: this.ynisonStateController,
            deviceConfig: this.deviceConfig,
            variables: this.variables
          });
          a10.beforeEntityChange.tapPromise("YnisonPlugin", () => {
            let {
              currentEntity: { value: e11 }
            } = t10.state.queueState;
            return e11 && (e11.positionSec = void 0), Promise.resolve();
          }), a10.beforeDestroy.tapPromise("YnisonPlugin", () => (r10.destroy(), i2.destroy(), Promise.resolve()));
        }
        constructor({
          factory: e10,
          deviceConfig: t10,
          ynisonStateController: a10,
          variables: r10,
          fallbackTypesQueueToVibe: i2
        }) {
          (0, w._)(this, "factory", void 0), (0, w._)(this, "deviceConfig", void 0), (0, w._)(this, "ynisonStateController", void 0), (0, w._)(this, "variables", void 0), (0, w._)(this, "fallbackTypesQueueToVibe", void 0), this.factory = e10, this.deviceConfig = t10, this.ynisonStateController = a10, this.variables = r10, this.fallbackTypesQueueToVibe = null != i2 ? i2 : [];
        }
      }
      class ro {
        subscribeOnPlayerEvents() {
          let e10 = this.playback.state.playerState.volume.onChange(() => {
            this.updateYnisonState();
          });
          this.unsubscribeFromPlayerEvents = () => {
            e10();
          };
        }
        updateYnisonState() {
          this.ynisonStateController.updateState({
            trigger: "YnisonValuePlugin",
            newState: { ...this.ynisonStateController.currentState, devices: this.createDevices() }
          });
        }
        createDevices() {
          return this.ynisonStateController.currentState.devices.map((e10) => {
            var t10;
            return (null == (t10 = e10.info) ? void 0 : t10.device_id) === this.deviceConfig.info.device_id && (e10.volume_info = {
              volume: (0, x.F4)(
                this.playback.state.playerState.exponentVolume.value,
                this.deviceConfig.volumeGranularity
              ),
              version: (0, x.fD)(this.deviceConfig.info.device_id)
            }), e10;
          });
        }
        destroy() {
          var e10;
          null == (e10 = this.unsubscribeFromPlayerEvents) || e10.call(this);
        }
        constructor({ playback: e10, ynisonStateController: t10, deviceConfig: a10 }) {
          (0, w._)(this, "unsubscribeFromPlayerEvents", void 0), (0, w._)(this, "playback", void 0), (0, w._)(this, "ynisonStateController", void 0), (0, w._)(this, "deviceConfig", void 0), this.playback = e10, this.ynisonStateController = t10, this.deviceConfig = a10, this.subscribeOnPlayerEvents(), this.updateYnisonState();
        }
      }
      class rd {
        onYnisonStateUpdated(e10) {
          this.variables.shouldApplyState && this.applyYnisonDiff(e10);
        }
        applyYnisonDiff(e10) {
          if (e10.diff.deviceVolume) {
            let t10 = e10.diff.deviceVolume.volume;
            if (void 0 !== t10) return this.changeVolume(t10);
          }
          return Promise.resolve();
        }
        changeVolume(e10) {
          return this.playback.setExponentVolume(e10), Promise.resolve();
        }
        destroy() {
          this.unlisteners.forEach((e10) => e10());
        }
        constructor({ playback: e10, ynisonStateController: t10, variables: a10 }) {
          (0, w._)(this, "playback", void 0), (0, w._)(this, "variables", void 0), (0, w._)(this, "unlisteners", void 0), this.playback = e10, this.variables = a10, this.unlisteners = [];
          let r10 = t10.on(x.p$.UPDATED, this.onYnisonStateUpdated.bind(this), "YnisonVolumePlugin");
          this.unlisteners.push(r10), this.onYnisonStateUpdated(t10.fullState);
        }
      }
      class ru {
        apply(e10) {
          let { playback: t10, hooks: a10 } = e10, r10 = new rd({ playback: t10, ynisonStateController: this.ynisonStateController, variables: this.variables }), i2 = new ro({
            playback: t10,
            ynisonStateController: this.ynisonStateController,
            deviceConfig: this.deviceConfig
          });
          a10.beforeDestroy.tapPromise("YnisonVolumePlugin", () => (r10.destroy(), i2.destroy(), Promise.resolve()));
        }
        constructor({ deviceConfig: e10, ynisonStateController: t10, variables: a10 }) {
          (0, w._)(this, "deviceConfig", void 0), (0, w._)(this, "ynisonStateController", void 0), (0, w._)(this, "variables", void 0), this.deviceConfig = e10, this.ynisonStateController = t10, this.variables = a10;
        }
      }
      let rc = [J.K.Album, J.K.Artist, J.K.Playlist, J.K.Various];
      class rh {
        apply(e10) {
          let { playback: t10, hooks: a10 } = e10;
          a10.afterContextEnd.tapPromise("AutoflowPlugin", () => {
            var e11, a11, r10;
            if (!this.variables.enabled) return Promise.resolve();
            let i2 = null == (e11 = t10.state.currentContext.value) ? void 0 : e11.data.type;
            return (null == (a11 = t10.state.currentContext.value) ? void 0 : a11.data) && "enableVariousAutoFlow" in t10.state.currentContext.value.data && (null == (r10 = t10.state.currentContext.value) ? void 0 : r10.data.enableVariousAutoFlow) && (i2 = J.K.Various), i2 && rc.includes(i2) && this.playAutoflow(t10), Promise.resolve();
          });
        }
        playAutoflow(e10) {
          var t10, a10, r10;
          let i2 = null == (t10 = e10.state.currentContext.value) ? void 0 : t10.data.type;
          (null == (a10 = e10.state.currentContext.value) ? void 0 : a10.data) && "enableVariousAutoFlow" in e10.state.currentContext.value.data && (null == (r10 = e10.state.currentContext.value) ? void 0 : r10.data.enableVariousAutoFlow) && (i2 = J.K.Various);
          let s2 = ((e11, t11) => {
            var a11, r11, i3, s3;
            let n3 = null == (a11 = t11.state.currentContext.value) ? void 0 : a11.data;
            if (n3) {
              if (e11 === J.K.Album) return ["album:".concat(n3.meta.id)];
              if (e11 === J.K.Artist) return ["artist:".concat(n3.meta.id)];
              if (e11 === J.K.Playlist && "owner" in n3.meta && (null == (r11 = n3.meta.owner) ? void 0 : r11.uid) && "kind" in n3.meta && n3.meta.kind)
                return ["playlist:".concat(null == (i3 = n3.meta.owner) ? void 0 : i3.uid, "_").concat(n3.meta.kind)];
              if (e11 === J.K.Various) {
                if ("overrideAutoflowSeeds" in n3 && n3.overrideAutoflowSeeds) return n3.overrideAutoflowSeeds;
                let e12 = null == (s3 = t11.state.queueState.currentEntity.value) ? void 0 : s3.entity.data.meta.id;
                return ["track:".concat(e12)];
              }
            }
          })(i2, e10), n2 = e10.state.currentContext.value, l2 = Object.create(null != n2 ? n2 : null);
          if (!(i2 && s2)) return;
          let o2 = this.factory.createContext({
            data: {
              type: J.K.Vibe,
              meta: { id: (0, eS.f)(s2) },
              seeds: s2,
              from: ((e11, t11, a11) => {
                var r11;
                let i3 = null == (r11 = t11.state.currentContext.value) ? void 0 : r11.data;
                if (!i3) return "";
                let s3 = e11, n3 = t11.state.queueState.entityList.value.length || 0;
                return s3 === J.K.Various && 1 === n3 && (s3 = "track"), e11 === J.K.Various && "overrideContextType" in i3 && i3.overrideContextType && (s3 = i3.overrideContextType), "".concat(a11, "-radio-").concat(s3, "-autoflow");
              })(i2, e10, this.platform),
              includeTracksInResponse: true,
              parentContext: l2,
              interactive: false
            }
          });
          e10.playContext({ context: o2, loadContextMeta: true });
        }
        constructor({ platform: e10, factory: t10, variables: a10 }) {
          (0, w._)(this, "platform", void 0), (0, w._)(this, "factory", void 0), (0, w._)(this, "variables", void 0), this.platform = e10, this.factory = t10, this.variables = a10;
        }
      }
      class rg {
        apply(e10) {
          let { playback: t10, hooks: a10 } = e10;
          this.telemetry.createTelemetry(t10), this.telemetry.setStaticParams(
            {
              labels: { from: this.telemetry.from },
              puid: this.puid ? String(this.puid) : void 0,
              yaspVersion: this.yaspVersion
            },
            true
          ), t10.state.playerState.status.onChange(() => {
            this.telemetry.setPlayingState(t10.state.playerState);
          }), t10.state.playerState.event.onChange((e11) => {
            e11 && e11 !== M.Iu.UPDATING_PROGRESS && this.telemetry.logEvent({ name: e11 });
          }), a10.afterError.tapPromise(
            "TelemetryPlugin",
            (e11) => (e11 instanceof M.LI && this.telemetry.logError({ error: { ...e11, isFatal: false } }), Promise.resolve())
          ), a10.beforeMediaStartPlaying.tapPromise("TelemetryPlugin", () => {
            let { value: e11 } = t10.state.queueState.currentEntity;
            return this.beforeMediaHandler(null == e11 ? void 0 : e11.entity), Promise.resolve();
          }), a10.beforeMediaSourceContentReload.tapPromise("TelemetryPlugin", () => {
            let { value: e11 } = t10.state.queueState.currentEntity;
            return this.beforeMediaHandler(null == e11 ? void 0 : e11.entity), Promise.resolve();
          }), a10.beforeMediaSourceContentPreload.tapPromise(
            "TelemetryPlugin",
            (e11) => (this.beforeMediaHandler(e11), Promise.resolve())
          );
        }
        beforeMediaHandler(e10) {
          if (!e10 || tb(e10)) return;
          let { mediaSourceData: t10 } = e10;
          t10 && "vsid" in t10 && void 0 === t10.vsid && (t10.vsid = this.telemetry.vsid), t10 && "sourceIndex" in t10 && void 0 === t10.sourceIndex && (t10.sourceIndex = this.telemetry.onBeforeSetSource());
          let a10 = (function(e11) {
            let { mediaSourceData: t11 } = e11;
            if (!t11) return;
            let { data: a11 } = t11;
            return { streamUrl: t11.src, ...a11 };
          })(e10);
          a10 && (this.telemetry.setStaticParams(
            {
              labels: { from: this.telemetry.from },
              puid: this.puid ? String(this.puid) : void 0,
              yaspVersion: this.yaspVersion,
              testIds: this.telemetryTestIds,
              ...a10
            },
            true
          ), this.telemetry.onSetSource(a10));
        }
        constructor({ telemetry: e10, puid: t10, yaspVersion: a10, telemetryTestIds: r10 }) {
          (0, w._)(this, "telemetry", void 0), (0, w._)(this, "puid", void 0), (0, w._)(this, "yaspVersion", void 0), (0, w._)(this, "telemetryTestIds", void 0), this.telemetry = e10, this.puid = t10, this.yaspVersion = a10, this.telemetryTestIds = r10;
        }
      }
      class ry {
        setQuality(e10) {
          this.quality.value = e10;
        }
        constructor(e10) {
          (0, w._)(this, "quality", new et.cJ(a_.e.BALANCED)), (0, w._)(this, "isCrossfadeEnabled", new et.cJ(true)), this.setQuality(e10);
        }
      }
      function rm(e10) {
        return (null == e10 ? void 0 : e10.data.type) === F.R.Radio;
      }
      class rp {
        get src() {
          let e10 = this.getQueryParamsString();
          return e10 ? "".concat(this.data.url).concat(e10) : this.data.url;
        }
        getQueryParamsString() {
          let e10 = new URLSearchParams();
          this.vsid && e10.append("vsid", this.vsid), void 0 !== this.sourceIndex && e10.append("source_index", String(this.sourceIndex));
          let t10 = e10.toString();
          return t10 ? "?".concat(t10) : void 0;
        }
        constructor(e10) {
          (0, w._)(this, "type", "generativeSource"), (0, w._)(this, "data", void 0), (0, w._)(this, "vsid", void 0), (0, w._)(this, "sourceIndex", void 0), (0, w._)(this, "getFileInfoResponseTime", void 0), (0, w._)(this, "url", void 0), this.data = e10.data, this.vsid = e10.vsid, this.sourceIndex = e10.sourceIndex;
        }
      }
      class rv extends tV {
        constructor(e10, { code: t10 = "E_GENERATIVE_MEDIA_PROVIDER", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "GenerativeMediaProviderException"), Object.setPrototypeOf(this, rv.prototype);
        }
      }
      class rP {
        getMediaSource(e10) {
          if (au(e10.entity)) {
            var t10;
            if (null == (t10 = e10.entity.data.meta.stream) ? void 0 : t10.url) {
              let t11 = new rp({ data: e10.entity.data.meta.stream });
              return e10.entity.mediaSourceData = t11, Promise.resolve(t11);
            }
            return Promise.reject(new rv("Failed to create generative src link", { code: _.E_GET_MEDIA_SRC }));
          }
          return Promise.reject(
            new rv("Provided entity is not generative entity", { code: _.E_UNSUITABLE_ENTITY_TYPE })
          );
        }
      }
      var rS = a(93451), rE = a(50389), rf = a(87787);
      class rb {
        getPreloadedFileInfo(e10) {
          let { entity: t10, disableCache: a10 = false } = e10;
          if (!(a10 || ax(t10, this.mediaSourceTtlMs, this.mediaConfigController)) && t10.mediaSourceData && "downloadInfoSource" === t10.mediaSourceData.type)
            return t10.mediaSourceData.data;
        }
        getFileInfoFromResource(e10) {
          let { trackId: t10, quality: a10, codecs: r10, transports: i2 } = e10, s2 = (0, rS.T)(), n2 = r10.join(""), l2 = i2.join(""), o2 = "".concat(s2).concat(t10).concat(a10).concat(n2).concat(l2);
          return new Promise((e11, l3) => {
            this.tools.createSign({ data: o2, secretKey: this.secretKey }).then((o3) => {
              this.resource.getFileInfo({
                tsInSeconds: s2,
                trackId: t10,
                quality: a10,
                codecs: r10,
                transports: i2,
                sign: o3,
                fromPromoLanding: this.variables.fromPromoLanding
              }).then((t11) => {
                e11({ downloadInfo: t11.downloadInfo, responseTime: t11.responseTime, url: t11.url });
              }).catch((e12) => {
                l3(
                  new tU("Error in get-file-info request", {
                    code: _.E_GET_MEDIA_SRC,
                    cause: (0, N.createObjectFromError)(e12),
                    data: { trackId: t10, quality: a10, codecs: n2 }
                  })
                );
              });
            }).catch((e12) => {
              l3(
                new tU("Error in creating sign for get-file-info request", {
                  code: _.E_CREATE_SIGN,
                  cause: (0, N.createObjectFromError)(e12),
                  data: { trackId: t10, quality: a10, codecs: n2 }
                })
              );
            });
          });
        }
        getFileInfo(e10) {
          let { entity: t10, disableCache: a10 = false, codecs: r10, quality: i2, transports: s2 } = e10;
          if (this.variables.isMediaSourcePreloadEnabled)
            try {
              let e11 = this.getPreloadedFileInfo({ entity: t10, disableCache: a10 });
              if (e11) return Promise.resolve({ downloadInfo: e11 });
            } catch (e11) {
              return Promise.reject(e11);
            }
          return this.getFileInfoFromResource({ trackId: t10.data.meta.id, quality: i2, codecs: r10, transports: s2 });
        }
        getMediaSource(e10) {
          let { entity: t10, disableCache: a10 = false } = e10, r10 = (0, rE.i)({ productQuality: this.mediaConfigController.quality.value, entity: t10 }), i2 = (0, eq.l)(t10) ? aS.o.RAW : this.transport;
          return t10.expectedQuality = r10, this.getFileInfo({ entity: t10, disableCache: a10, quality: r10, transports: [i2], codecs: this.codecs }).then(
            (e11) => {
              let { downloadInfo: i3, responseTime: s2, url: n2 } = e11;
              if (!("error" in i3) && !rf.DM.includes(i3.codec) && i3.transport === aS.o.ENCRAW)
                return t10.mediaSourceData = null, this.getFileInfo({
                  entity: t10,
                  disableCache: a10,
                  quality: r10,
                  transports: [aS.o.RAW],
                  codecs: this.codecs
                }).then((e12) => {
                  let { downloadInfo: a11, responseTime: i4, url: s3 } = e12, n3 = this.createMediaSource({
                    downloadInfo: a11,
                    trackId: t10.data.meta.id,
                    quality: r10,
                    codecs: this.codecs,
                    getFileInfoResponseTime: i4,
                    getFileInfoUrl: s3
                  });
                  return t10.mediaSourceData = n3, t10.expectedQuality = r10, n3;
                }).catch((e12) => {
                  let a11 = this.createMediaSource({
                    downloadInfo: i3,
                    trackId: t10.data.meta.id,
                    quality: r10,
                    codecs: this.codecs,
                    getFileInfoResponseTime: s2
                  });
                  throw t10.mediaSourceData = a11, new tU("Error in get-file-info retry enclaw request", {
                    code: _.E_GET_MEDIA_SRC,
                    cause: (0, N.createObjectFromError)(e12),
                    data: { trackId: t10.data.meta.id, quality: r10, codecs: this.codecs.join("") }
                  });
                });
              let l2 = this.createMediaSource({
                downloadInfo: i3,
                trackId: t10.data.meta.id,
                quality: r10,
                codecs: this.codecs,
                getFileInfoResponseTime: s2,
                getFileInfoUrl: n2
              });
              return t10.mediaSourceData = l2, l2;
            }
          );
        }
        getMediaSourceBatch(e10) {
          let { entities: t10 } = e10, a10 = (0, rS.T)(), r10 = (0, rE.i)({ productQuality: this.mediaConfigController.quality.value, entities: t10 }), i2 = this.codecs.join(""), s2 = t10.reduce((e11, t11) => "".concat(e11).concat(t11.data.meta.id, ","), "").slice(0, -1), n2 = t10.some((e11) => (0, eq.l)(e11)) ? aS.o.RAW : this.transport, l2 = "".concat(a10).concat(s2).concat(r10).concat(i2).concat(n2);
          return new Promise((e11, o2) => {
            this.tools.createSign({ data: l2, secretKey: this.secretKey }).then((l3) => {
              this.resource.getFileInfoBatch({
                tsInSeconds: a10,
                trackIds: s2,
                quality: r10,
                codecs: this.codecs,
                transports: [n2],
                sign: l3,
                fromPromoLanding: this.variables.fromPromoLanding
              }).then((a11) => {
                try {
                  for (let e12 of a11.downloadInfos) {
                    let a12 = t10.find((t11) => t11.data.meta.id === e12.trackId);
                    a12 && (a12.mediaSourceData = this.createMediaSource({
                      downloadInfo: e12,
                      trackId: e12.trackId,
                      quality: r10,
                      codecs: this.codecs
                    }), a12.expectedQuality = r10);
                  }
                  e11(a11.downloadInfos);
                } catch (e12) {
                  o2(e12);
                }
              }).catch((e12) => {
                o2(
                  new tU("Error in get-file-info/batch request", {
                    code: _.E_GET_MEDIA_SRC,
                    cause: (0, N.createObjectFromError)(e12),
                    data: { trackId: s2, quality: r10, codecs: i2 }
                  })
                );
              });
            }).catch((e12) => {
              o2(
                new tU("Error in creating sign for get-file-info request", {
                  code: _.E_CREATE_SIGN,
                  cause: (0, N.createObjectFromError)(e12),
                  data: { trackId: s2, quality: r10, codecs: i2 }
                })
              );
            });
          });
        }
        createMediaSource(e10) {
          let { downloadInfo: t10, trackId: a10, codecs: r10, quality: i2, getFileInfoResponseTime: s2, getFileInfoUrl: n2 } = e10, l2 = r10.join("");
          if ("error" in t10)
            throw new tU("Error message in get-file-info response", {
              code: _.E_GET_MEDIA_SRC,
              data: { trackId: a10, quality: i2, codecs: l2, mediaSource: t10 }
            });
          if (!t10.urls[0])
            throw new tU("No urls in get-file-info response", {
              code: _.E_GET_MEDIA_SRC,
              data: { trackId: a10, quality: i2, codecs: l2, mediaSource: t10 }
            });
          return new ab({ data: t10, loadingTime: performance.now(), getFileInfoResponseTime: s2, url: n2 });
        }
        constructor(e10) {
          var t10;
          (0, w._)(this, "secretKey", void 0), (0, w._)(this, "resource", void 0), (0, w._)(this, "mediaConfigController", void 0), (0, w._)(this, "transport", void 0), (0, w._)(this, "codecs", void 0), (0, w._)(this, "variables", void 0), (0, w._)(this, "mediaSourceTtlMs", void 0), (0, w._)(this, "tools", void 0);
          let {
            resource: a10,
            secretKey: r10,
            mediaConfigController: i2,
            transport: s2,
            variables: n2,
            mediaSourceTtlMs: l2,
            codecs: o2,
            tools: d2
          } = e10;
          this.resource = a10, this.secretKey = r10, this.mediaConfigController = i2, this.transport = s2, this.codecs = o2, this.variables = {
            isMediaSourcePreloadEnabled: null != (t10 = null == n2 ? void 0 : n2.isMediaSourcePreloadEnabled) && t10,
            fromPromoLanding: null == n2 ? void 0 : n2.fromPromoLanding
          }, this.mediaSourceTtlMs = null != l2 ? l2 : 0, this.tools = d2 || rf.$n;
        }
      }
      class rI {
        get src() {
          return this.data.src;
        }
        constructor(e10) {
          (0, w._)(this, "type", "clipSource"), (0, w._)(this, "data", void 0), (0, w._)(this, "vsid", void 0), (0, w._)(this, "getFileInfoResponseTime", void 0), (0, w._)(this, "url", void 0), this.data = e10.data;
        }
      }
      class r_ {
        getMediaSource(e10) {
          let { entity: t10 } = e10;
          if (e8(t10)) {
            let e11 = new rI({
              data: {
                src: "".concat(this.vhUrl).concat(t10.data.meta.playerId, "?service=").concat(this.service, "&from=").concat(this.from)
              }
            });
            return t10.mediaSourceData = e11, Promise.resolve(e11);
          }
          return Promise.reject(new W.t("Provided entity is not clip entity", { code: _.E_UNSUITABLE_ENTITY_TYPE }));
        }
        constructor({ service: e10, from: t10, vhUrl: a10 }) {
          (0, w._)(this, "service", void 0), (0, w._)(this, "from", void 0), (0, w._)(this, "vhUrl", void 0), this.service = e10, this.from = t10, this.vhUrl = a10;
        }
      }
      class rk {
        get src() {
          let e10 = this.getQueryParamsString();
          return e10 ? "".concat(this.data.streamUrl).concat(e10) : this.data.streamUrl;
        }
        getQueryParamsString() {
          let e10 = new URLSearchParams();
          this.vsid && e10.append("vsid", this.vsid), void 0 !== this.sourceIndex && e10.append("source_index", String(this.sourceIndex));
          let t10 = e10.toString();
          return t10 ? "?".concat(t10) : void 0;
        }
        constructor(e10) {
          (0, w._)(this, "type", "radioSource"), (0, w._)(this, "data", void 0), (0, w._)(this, "vsid", void 0), (0, w._)(this, "sourceIndex", void 0), (0, w._)(this, "getFileInfoResponseTime", void 0), (0, w._)(this, "url", void 0), this.data = e10.data, this.vsid = e10.vsid, this.sourceIndex = e10.sourceIndex;
        }
      }
      class rC extends tV {
        constructor(e10, { code: t10 = "E_RADIO_MEDIA_PROVIDER", ...a10 } = {}) {
          super(e10, { code: t10, ...a10 }), (0, w._)(this, "name", "RadioMediaProviderException"), Object.setPrototypeOf(this, rC.prototype);
        }
      }
      class rT {
        getMediaSource(e10) {
          if (rm(e10.entity)) {
            if (e10.entity.data.meta.streamUrl) {
              let t10 = new rk({ data: { streamUrl: e10.entity.data.meta.streamUrl } });
              return e10.entity.mediaSourceData = t10, Promise.resolve(t10);
            }
            return Promise.reject(
              new rC(
                'Failed to create fm radio src link because the "streamUrl" property is missing in the entity meta',
                { code: _.E_GET_MEDIA_SRC }
              )
            );
          }
          return Promise.reject(new rC("Provided entity is not fm radio entity", { code: _.E_UNSUITABLE_ENTITY_TYPE }));
        }
      }
      class rD {
        async getMediaSource(e10) {
          return au(e10.entity) ? this.generativeProvider.getMediaSource(e10) : e8(e10.entity) ? this.vhMediaProvider.getMediaSource(e10) : rm(e10.entity) ? this.radioProvider.getMediaSource(e10) : this.getFileInfoProvider.getMediaSource(e10);
        }
        getMediaSourceBatch(e10) {
          let { entities: t10 } = e10;
          return t10.some((e11) => au(e11)) ? Promise.reject(
            new tV("Can not use getMediaSourceBatch for generative entities", { code: _.E_UNSUITABLE_ENTITY_TYPE })
          ) : this.getFileInfoProvider.getMediaSourceBatch({ entities: t10 });
        }
        constructor(e10) {
          (0, w._)(this, "generativeProvider", new rP()), (0, w._)(this, "radioProvider", new rT()), (0, w._)(this, "getFileInfoProvider", void 0), (0, w._)(this, "vhMediaProvider", void 0), this.getFileInfoProvider = new rb(e10.getFileInfoProviderParams), this.vhMediaProvider = new r_(e10.vhMediaProviderParams);
        }
      }
      class rA {
        async loadEntities(e10) {
          let { trackIds: t10 } = (function(e11) {
            let t11 = [];
            return e11.forEach((e12) => {
              let { context: a11, entity: r10 } = e12, i2 = r10.data.meta.id, s2 = "string" == typeof i2 && i2.includes(":");
              if (!r10.data.fromCurrentContext || s2) return void t11.push(r10.data.meta.id);
              (0, eB.F)(a11) && (i2 = "".concat(r10.data.meta.id, ":").concat(a11.data.meta.id)), "albumId" in r10.data.meta && r10.data.meta.albumId && (i2 = "".concat(r10.data.meta.id, ":").concat(r10.data.meta.albumId)), t11.push(i2);
            }, {}), { trackIds: t11 };
          })(e10), a10 = e10.some((e11) => {
            let { context: t11 } = e11;
            return (0, eK.i)(t11);
          });
          return this.resource.getTracksMeta({ trackIds: t10, withProgress: true, withMixData: a10 }).then((t11) => {
            let a11 = [];
            for (let r10 of t11) {
              let t12 = e10.find((e11) => String(e11.entity.data.meta.id).includes(String(r10.id)));
              if (t12) {
                let e11 = t12.entity.data.type === M.z4.Unloaded ? F.R.Unknown : t12.entity.data.type;
                e11 !== F.R.Clip && a11.push({ ...t12.entity.data, type: e11, meta: r10, loadEntityMeta: false });
              }
            }
            return a11;
          }).catch((e11) => {
            throw new W.t("Failed to get track meta", {
              code: "E_TRACK_META_PROVIDER",
              cause: (0, N.createObjectFromError)(e11)
            });
          });
        }
        constructor(e10) {
          (0, w._)(this, "resource", void 0);
          let { tracksResource: t10 } = e10;
          this.resource = t10;
        }
      }
      class rx {
        loadEntities(e10) {
          let t10 = e10.map((e11) => e11.entity.data.meta.id);
          return this.resource.getClip({ clipIds: t10 }).then((t11) => {
            let a10 = [];
            for (let r10 of t11) {
              let t12 = e10.find((e11) => String(e11.entity.data.meta.id) === String(r10.clipId));
              t12 && a10.push({ ...t12.entity.data, type: F.R.Clip, meta: { id: r10.clipId, ...r10 }, loadEntityMeta: false });
            }
            return a10;
          }).catch((e11) => {
            throw new W.t("Failed to get clip meta", {
              code: "E_CLIP_META_PROVIDER",
              cause: (0, N.createObjectFromError)(e11)
            });
          });
        }
        constructor(e10) {
          (0, w._)(this, "resource", void 0), this.resource = e10.clipsResource;
        }
      }
      class rL {
        loadEntities(e10) {
          return e10.some((e11) => e8(e11.entity)) ? this.clipMetaProvider.loadEntities(e10) : this.trackMetaProvider.loadEntities(e10);
        }
        constructor(e10) {
          (0, w._)(this, "trackMetaProvider", void 0), (0, w._)(this, "clipMetaProvider", void 0), this.trackMetaProvider = new rA({ tracksResource: e10.tracksResource }), this.clipMetaProvider = new rx({ clipsResource: e10.clipsResource });
        }
      }
      var rR = a(8817);
      (D || (D = {})).MAIN = "MAIN";
      class rN {
        get availablePlaybacks() {
          return Array.from(this.playbacks.values());
        }
        afterPlayHandler(e10) {
          return this.activePlayback.value = e10, Promise.resolve();
        }
        beforePlayHandler(e10) {
          return this.activePlayback.value && this.activePlayback.value !== e10 ? this.activePlayback.value.pause() : Promise.resolve();
        }
        beforeDestroyHandler(e10) {
          return e10.stop();
        }
        getPlayback(e10) {
          if (e10) {
            let t11 = this.playbacks.get(e10);
            if (t11) return t11;
          }
          let t10 = this.playbacks.get(D.MAIN);
          if (void 0 !== t10) return t10;
          throw new W.t("MAIN playback was not created", { code: "NO_MAIN_PLAYBACK" });
        }
        checkPlaybackBlockingStatus() {
          var e10, t10;
          let a10 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : D.MAIN, r10 = null == (e10 = this.activePlayback.value) ? void 0 : e10.getId(), i2 = r10 === a10;
          return ((null == (t10 = this.activePlayback.value) ? void 0 : t10.isBlocking) || i2) && !i2 ? { status: M.N.BLOCKED, blockingPlaybackId: r10 } : { status: M.N.UNBLOCKED };
        }
        callIfUnblocked(e10, t10) {
          let { status: a10, blockingPlaybackId: r10 } = this.checkPlaybackBlockingStatus(t10);
          return a10 === M.N.UNBLOCKED ? e10() : (this.getPlayback(t10).hooks.afterPlaybackCheckBlockingStatus.promise({ status: a10, blockingPlaybackId: r10 }), Promise.resolve());
        }
        createPlayback(e10, t10) {
          if (!this.playbacks.has(e10)) {
            let a10 = new M.VE({
              id: e10,
              isBlocking: t10.isBlocking || false,
              factory: t10.factory,
              entityProvider: t10.entityProvider,
              mediaPlayerParams: t10.mediaPlayerParams,
              playbackConfig: t10.playbackConfig
            });
            this.playbacks.set(e10, a10), a10.hooks.afterMediaStartPlaying.tapPromise("MusicPlaybackController", () => this.afterPlayHandler(a10)), a10.hooks.beforeMediaStartPlaying.tapPromise("MusicPlaybackController", () => this.beforePlayHandler(a10)), a10.hooks.afterMediaResume.tapPromise("MusicPlaybackController", () => this.afterPlayHandler(a10)), a10.hooks.beforeMediaResume.tapPromise("MusicPlaybackController", () => this.beforePlayHandler(a10)), a10.hooks.beforeDestroy.tapPromise("MusicPlaybackController", () => this.beforeDestroyHandler(a10)), this.syncWithMainPlayback(a10, t10.syncVolumeWithMainPlayback);
          }
        }
        syncWithMainPlayback(e10) {
          let t10 = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
          if (e10.getId() === D.MAIN)
            return void this.playbacksWaitingForSync.forEach((t11) => {
              this.syncVolume(e10, t11);
            });
          let a10 = this.playbacks.get(D.MAIN);
          if (t10 && a10) return void this.syncVolume(a10, e10);
          t10 && !a10 && this.playbacksWaitingForSync.push(e10);
        }
        syncVolume(e10, t10) {
          (this.useExponentVolume ? e10.state.playerState.exponentVolume : e10.state.playerState.volume).onChange((e11) => {
            void 0 !== e11 && this.useExponentVolume ? t10.setExponentVolume(e11) : void 0 === e11 || this.useExponentVolume || t10.setVolume(e11);
          });
        }
        constructor(e10) {
          (0, w._)(this, "activePlayback", new et.cJ(null)), (0, w._)(this, "playbacks", /* @__PURE__ */ new Map()), (0, w._)(this, "playbacksWaitingForSync", []), (0, w._)(this, "useExponentVolume", void 0), this.useExponentVolume = !!e10.useExponentVolume;
        }
      }
      class rw {
        get state() {
          return this.playbackController.getPlayback().state;
        }
        getState(e10) {
          return this.playbackController.getPlayback(e10).state;
        }
        playContext(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          try {
            let { contextData: r10 } = e10, i2 = this.factory.createContext({ data: r10 });
            return this.playbackController.callIfUnblocked(
              () => a10.playContext({
                context: i2,
                entitiesData: e10.entitiesData,
                loadContextMeta: e10.loadContextMeta,
                queueParams: e10.queueParams
              }).catch((e11) => {
                a10.hooks.afterError.promise(e11);
              }),
              t10
            );
          } catch (e11) {
            return a10.hooks.afterError.promise(e11), Promise.resolve();
          }
        }
        setContext(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          try {
            let { contextData: r10 } = e10, i2 = this.factory.createContext({ data: r10 });
            return this.playbackController.callIfUnblocked(
              () => a10.setContext({
                context: i2,
                entitiesData: e10.entitiesData,
                loadContextMeta: e10.loadContextMeta,
                queueParams: e10.queueParams
              }).catch((e11) => {
                a10.hooks.afterError.promise(e11);
              }),
              t10
            );
          } catch (e11) {
            return a10.hooks.afterError.promise(e11), Promise.resolve();
          }
        }
        restartContext(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.restartContext({
              playAfterRestart: e10.playAfterRestart,
              entitiesData: e10.entitiesData,
              queueParams: e10.queueParams
            }).catch((e11) => {
              a10.hooks.afterError.promise(e11);
            }),
            t10
          );
        }
        play(e10) {
          let t10 = this.playbackController.getPlayback(e10);
          return this.playbackController.callIfUnblocked(
            () => t10.play().catch((e11) => {
              t10.hooks.afterError.promise(e11);
            }),
            e10
          );
        }
        stop(e10) {
          let t10 = this.playbackController.getPlayback(e10);
          return this.playbackController.callIfUnblocked(
            () => t10.stop().catch((e11) => {
              t10.hooks.afterError.promise(e11);
            }),
            e10
          );
        }
        pause(e10) {
          let t10 = this.playbackController.getPlayback(e10);
          return this.playbackController.callIfUnblocked(
            () => t10.pause().catch((e11) => {
              t10.hooks.afterError.promise(e11);
            }),
            e10
          );
        }
        resume(e10) {
          let t10 = this.playbackController.getPlayback(e10);
          return this.playbackController.callIfUnblocked(
            () => t10.resume().catch((e11) => {
              t10.hooks.afterError.promise(e11);
            }),
            e10
          );
        }
        setProgress(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.setProgress(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 0)),
            t10
          );
        }
        setExponentVolume(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.setExponentVolume(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 0)),
            t10
          );
        }
        setVolume(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.setVolume(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 0)),
            t10
          );
        }
        setSpeed(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.setSpeed(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 1)),
            t10
          );
        }
        slideForward(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.slideForward(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 0)),
            t10
          );
        }
        slideBackward(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.slideBackward(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 0)),
            t10
          );
        }
        increaseExponentVolume(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.increaseExponentVolume(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 0)),
            t10
          );
        }
        increaseVolume(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.increaseVolume(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 0)),
            t10
          );
        }
        decreaseVolume(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.decreaseVolume(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 0)),
            t10
          );
        }
        decreaseExponentVolume(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.decreaseExponentVolume(e10).catch((e11) => (a10.hooks.afterError.promise(e11), 0)),
            t10
          );
        }
        moveForward(e10) {
          let t10 = this.playbackController.getPlayback(e10);
          return this.playbackController.callIfUnblocked(
            () => t10.moveForward().catch((e11) => {
              t10.hooks.afterError.promise(e11);
            }),
            e10
          );
        }
        moveBackward(e10) {
          let t10 = this.playbackController.getPlayback(e10);
          return this.playbackController.callIfUnblocked(
            () => t10.moveBackward().catch((e11) => {
              t10.hooks.afterError.promise(e11);
            }),
            e10
          );
        }
        setEntityByIndex(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          return this.playbackController.callIfUnblocked(
            () => a10.setEntityByIndex(e10).catch((e11) => {
              a10.hooks.afterError.promise(e11);
            }),
            t10
          );
        }
        togglePause(e10) {
          let t10 = this.playbackController.getPlayback(e10);
          return this.playbackController.callIfUnblocked(
            () => t10.togglePause().catch((e11) => {
              t10.hooks.afterError.promise(e11);
            }),
            e10
          );
        }
        toggleShuffle(e10) {
          let t10 = this.playbackController.getPlayback(e10);
          try {
            this.playbackController.callIfUnblocked(() => t10.toggleShuffle(), e10);
          } catch (e11) {
            t10.hooks.afterError.promise(e11);
          }
        }
        setShuffle(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          try {
            this.playbackController.callIfUnblocked(() => a10.setShuffle(e10), t10);
          } catch (e11) {
            a10.hooks.afterError.promise(e11);
          }
        }
        updateFilterParams(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          try {
            this.playbackController.callIfUnblocked(() => a10.updateFilterParams(e10), t10);
          } catch (e11) {
            a10.hooks.afterError.promise(e11);
          }
        }
        bindPlayer(e10) {
          this.playbackController.getPlayback(e10).bindPlayer();
        }
        unbindPlayer(e10) {
          this.playbackController.getPlayback(e10).unbindPlayer();
        }
        setRepeatMode(e10, t10) {
          let a10 = this.playbackController.getPlayback(t10);
          try {
            this.playbackController.callIfUnblocked(() => a10.setRepeatMode(e10), t10);
          } catch (e11) {
            a10.hooks.afterError.promise(e11);
          }
        }
        removeAndLoadEntities(e10) {
          let { positions: t10, playbackId: a10, silent: r10 } = e10, i2 = this.playbackController.getPlayback(a10);
          return this.playbackController.callIfUnblocked(
            () => i2.removeAndLoadEntities(t10, r10).catch((e11) => {
              i2.hooks.afterError.promise(e11);
            }),
            a10
          );
        }
        remove(e10) {
          let { positions: t10, playbackId: a10, silent: r10 } = e10, i2 = this.playbackController.getPlayback(a10);
          this.playbackController.callIfUnblocked(() => i2.remove(t10, r10), a10);
        }
        hide(e10) {
          let { positions: t10, playbackId: a10, silent: r10 } = e10, i2 = this.playbackController.getPlayback(a10);
          this.playbackController.callIfUnblocked(() => i2.hide(t10, r10), a10);
        }
        inject(e10) {
          let { entitiesData: t10, position: a10, playbackId: r10, silent: i2, sourceContextData: s2 } = e10, n2 = this.playbackController.getPlayback(r10), l2 = s2 ? this.factory.createContext({ data: s2 }) : void 0;
          this.playbackController.callIfUnblocked(
            () => n2.inject({ entitiesData: t10, position: a10, silent: i2, sourceContext: l2 }),
            r10
          );
        }
        injectNext(e10) {
          let { entitiesData: t10, playbackId: a10, silent: r10, sourceContextData: i2 } = e10, s2 = this.playbackController.getPlayback(a10), n2 = i2 ? this.factory.createContext({ data: i2 }) : void 0;
          this.playbackController.callIfUnblocked(
            () => s2.injectNext({ entitiesData: t10, silent: r10, sourceContext: n2 }),
            a10
          );
        }
        injectLast(e10) {
          let { entitiesData: t10, playbackId: a10, silent: r10, sourceContextData: i2 } = e10, s2 = this.playbackController.getPlayback(a10), n2 = i2 ? this.factory.createContext({ data: i2 }) : void 0;
          this.playbackController.callIfUnblocked(
            () => s2.injectLast({ entitiesData: t10, silent: r10, sourceContext: n2 }),
            a10
          );
        }
        registerMediaPlayer(e10) {
          let { mediaPlayerParams: t10, playbackId: a10 } = e10;
          this.playbackController.getPlayback(a10).registerMediaPlayer(t10);
        }
        setVideoCoreContainer(e10) {
          let { container: t10, playbackId: a10 } = e10;
          this.playbackController.getPlayback(a10).setVideoCoreContainer(t10);
        }
        destroyVideoCore(e10) {
          this.playbackController.getPlayback(e10).destroyVideoCore();
        }
        destroy() {
          return Promise.allSettled(
            this.playbackController.availablePlaybacks.map((e10) => e10.hooks.beforeDestroy.promise())
          );
        }
        constructor(e10) {
          if ((0, w._)(this, "factory", void 0), (0, w._)(this, "playbackController", void 0), this.factory = e10.factory, this.playbackController = e10.playbackController, this.playbackController.createPlayback(D.MAIN, {
            factory: e10.factory,
            mediaPlayerParams: e10.mediaPlayerParams,
            entityProvider: e10.entityProvider,
            playbackConfig: e10.playbackConfig
          }), e10.plugins) {
            let t10 = this.playbackController.getPlayback(D.MAIN);
            for (let a10 of e10.plugins) a10.apply({ playback: t10, hooks: t10.hooks });
          }
        }
      }
      var rM = a(98313), rO = a(62481), rF = a(33208), rG = a(68317);
      a(24269);
      var rK = a(65630), rj = a(74125), rX = a(80585);
      let rB = (e10) => {
        let { audioLoader: t10, children: a10 } = e10;
        return (0, R.use)(t10), a10;
      };
      var rV = a(63930), rU = a(40320);
      let rq = (0, L.PA)(() => {
        let e10 = (0, rU.Sq)(), t10 = (0, rj.iIU)(), { sonataState: a10 } = (0, rj.Pjs)();
        (0, R.useEffect)(() => {
          e10.loadPresets();
        }, [e10]), (0, R.useEffect)(() => {
          e10.isAvailable && (null == t10 ? void 0 : t10.equalizer.value) && (e10.isEnabled ? (e10.currentPreset && t10.equalizer.value.applyPreset((0, rV.HO)(e10.currentPreset)), t10.equalizer.value.enable()) : t10.equalizer.value.disable());
        }, [e10.currentPreset, e10.isEnabled, null == t10 ? void 0 : t10.equalizer, a10.areCoresRegistered, e10.isAvailable]);
      });
      var rW = a(43426);
      let rY = (0, L.PA)((e10) => {
        let { isYnisonDisabled: t10 } = e10, { experiments: a10, slam: r10 } = (0, rj.Pjs)(), i2 = (0, rj.NFA)(), s2 = t10 || r10.isOfflineModeEnabled, n2 = a10.checkExperiment(rj.zal.WebNextYnisonActivityInterception, "on");
        (0, R.useEffect)(() => {
          let e11 = i2.get(rj.ooW), t11 = i2.get(rj.byd).stateController.on(
            x.p$.UPDATED,
            (t12) => {
              t12.diff.deviceVolume && e11.set(rj.cYZ.YmPlayerVolume, t12.diff.deviceVolume.volume, { expires: 365 });
            },
            "App"
          );
          return () => {
            t11();
          };
        }, [i2]), (0, R.useEffect)(() => {
          i2.get(rj.byd).updateVariables({ isShadow: !n2 });
        }, [i2, n2]), ((e11) => {
          let t11 = (0, rj.NFA)(), { formatMessage: a11 } = (0, rW.A)();
          (0, R.useEffect)(() => {
            let e12 = t11.get(rj.byd), r11 = a11(
              { id: "ynison.desktop-device-title" },
              { platformName: (0, rj.t1V)((0, rj.uoh)()), hostname: (0, rj.akQ)() }
            );
            e12.updateDeviceInfo({ title: r11 });
          }, [t11, a11]), (0, R.useEffect)(() => {
            let a12 = t11.get(rj.byd);
            if (e11.isConnectionDisabled) return void a12.connector.disconnect();
            let r11 = () => {
              document.hidden || a12.connector.connect({
                oauth: t11.get(rj.QGx).token,
                multiAuthUserId: t11.get(rj.WA$).getPassportUid()
              });
            }, i3 = a12.stateController.on(
              x.p$.UPDATED,
              (e12) => {
                a12.isActive || e12.prevState.active_device_id_optional !== a12.deviceConfig.info.device_id || r11();
              },
              "App"
            );
            return document.addEventListener("visibilitychange", r11), r11(), i3(), () => {
              i3(), document.removeEventListener("visibilitychange", r11);
            };
          }, [t11, e11.isConnectionDisabled, e11.isYnisonActivityInterceptionEnabled]), ((e12) => {
            let t12 = (0, rj.NFA)(), a12 = (0, R.useRef)(0), { experiments: r11 } = (0, rj.Pjs)(), i3 = r11.checkExperiment(rj.zal.WebNextYnisonInactiveTimerDesktop, "on"), s3 = r11.getExperiment(rj.zal.WebNextYnisonInactiveTimerDesktop);
            (0, R.useEffect)(() => {
              if (!e12.isEnabled) return;
              let { inactiveTimeoutMs: r12, inactiveCheckIntervalMs: n3 } = (function(e13) {
                let t13 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, a13 = { inactiveTimeoutMs: 6e5, inactiveCheckIntervalMs: 3e4 };
                try {
                  var r13, i4, s4, n4;
                  if (e13 && (null == (i4 = t13.value) || null == (r13 = i4.metadata) ? void 0 : r13.inactiveTimeoutSec) && (null == (n4 = t13.value) || null == (s4 = n4.metadata) ? void 0 : s4.inactiveCheckIntervalSec)) {
                    let e14 = Number(t13.value.metadata.inactiveTimeoutSec), a14 = Number(t13.value.metadata.inactiveCheckIntervalSec);
                    if (!Number.isNaN(e14) && !Number.isNaN(a14))
                      return { inactiveTimeoutMs: 1e3 * e14, inactiveCheckIntervalMs: 1e3 * a14 };
                  }
                  return a13;
                } catch (e14) {
                  return a13;
                }
              })(i3, s3), l2 = setInterval(() => {
                let e13 = t12.get(rj.byd), i4 = e13.isActive, s4 = Date.now() - a12.current > r12, n4 = e13.stateController.currentState.player_state.status.paused;
                i4 && s4 && n4 && e13.becomePassive();
              }, n3);
              return () => {
                clearInterval(l2);
              };
            }, [t12, e12.isEnabled, i3, s3]), (0, R.useEffect)(() => {
              if (!e12.isEnabled) return;
              let r12 = t12.get(rj.byd), i4 = r12.stateController.on(
                x.p$.UPDATED,
                (e13) => {
                  var t13, i5;
                  ((null == (t13 = e13.diff) ? void 0 : t13.player_state) || (null == (i5 = e13.diff) ? void 0 : i5.active_device_id_optional) && r12.isActive) && (a12.current = Date.now());
                },
                "App"
              );
              return () => {
                i4();
              };
            }, [t12, e12.isEnabled]);
          })({ isEnabled: !e11.isConnectionDisabled || !e11.isYnisonActivityInterceptionEnabled });
        })({ isConnectionDisabled: s2, isYnisonActivityInterceptionEnabled: n2 }), (0, R.useEffect)(() => {
          if (s2 || !n2) return;
          let e11 = i2.get(rj.byd), t11 = e11.stateController.on(
            x.p$.UPDATED,
            () => {
              var t12, a11;
              let r11 = (null == (a11 = e11.stateController.fullState.diff.player_state) || null == (t12 = a11.status) ? void 0 : t12.paused) === false;
              !e11.isActive && r11 && e11.interceptActivity();
            },
            "App"
          );
          return () => {
            t11();
          };
        }, [i2, s2, n2]);
      }), rz = (e10) => {
        let { children: t10 } = e10, a10 = (0, rj.iIU)(), r10 = (0, rj.Yx9)(), [i2] = (0, R.useState)(() => rU.ML.create({ isEnabled: false, modal: {} }, r10));
        return (0, R.useEffect)(() => {
          let e11 = null == a10 ? void 0 : a10.equalizer.onChange((e12) => {
            i2.setIsAvailable(!!e12);
          });
          return () => {
            null == e11 || e11();
          };
        }, [i2, null == a10 ? void 0 : a10.equalizer]), (0, A.jsx)(rU.iV.Provider, { value: i2, children: t10 });
      }, rH = false;
      var rQ = a(3269);
      let r$ = null, rZ = null, rJ = null, r0 = null, r1 = null, r3 = null, r2 = null, r4 = null, r6 = null, r5 = null, r8 = [
        rj.cYZ.YmPlayerQuality,
        rj.cYZ.YmPlayerShuffle,
        rj.cYZ.YmPlayerPrevVolume,
        rj.cYZ.YmPlayerVolume,
        rj.cYZ.YmPlayerRepeatMode,
        rj.cYZ.CrossFadeMode
      ], r9 = (e10) => {
        var t10;
        let { children: r10, hostTld: i2, quality: s2, withPromoLandingPlayback: n2 } = e10, l2 = (0, rj.NFA)(), {
          sonataState: o2,
          experiments: d2,
          library: u2,
          trailer: c2,
          user: h2,
          advert: g2,
          settings: y2,
          promolanding: { state: m2 },
          album: p2,
          albumCPA: { isPlusCPAPlayerBarEnabled: v2 }
        } = (0, rj.Pjs)(), { isPassToProduct: P2, isFreemium: S2 } = (0, rj.XCI)(), E2 = (0, rj.UlF)(), f2 = l2.get(rj.ooW), b2 = l2.get(rj.QGx), I2 = l2.get(rj.twC), _2 = l2.get(rj.P0Z), { language: k2 } = (0, rj.h6b)(), C2 = (0, rj.rs2)(), T2 = (0, rj.Gdz)(), D2 = d2.checkExperiment(rj.zal.WebNextCrossMediaPlayer, "on"), L2 = !h2.isAuthorized || P2 || S2, w2 = h2.isAuthorized && !S2, M2 = _2.get(rj.qVS), O2 = _2.get(rj.W4E), F2 = !!M2 && !!f2.get(rj.cYZ.EnableMetricsPluginDebugMode), G2 = (0, R.useMemo)(() => (r$ || (r$ = new ry(s2)), r$), [s2]), j2 = y2.browserInfo, X2 = "Safari" !== j2.name && "iOS" !== j2.OSFamily, B2 = (null == j2 ? void 0 : j2.isTouch) && v2(p2.id, null == (t10 = p2.meta) ? void 0 : t10.isNonMusic), V2 = (0, R.useMemo)(
          () => rJ || (rJ = new e5({
            useAnalyser: X2,
            useEqualizer: X2,
            useFade: false,
            useCrossFade: D2,
            crossFadeConfig: { useVolumeForAudioEffect: !X2, useWorker: !!window.Worker }
          })),
          [X2, D2, X2]
        ), U2 = (0, R.useMemo)(() => {
          if (null !== r0) return r0;
          let e11 = l2.get(rj.gdC);
          return r0 = new e9({
            advertModule: C2,
            afterTrackResource: l2.get(rj.EN6),
            adsResource: e11,
            variables: {
              get enabled() {
                return !h2.hasPlus;
              }
            }
          });
        }, [C2, l2, h2.hasPlus]), q2 = (0, R.useMemo)(() => {
          if (r3) return r3;
          let e11 = l2.get(rj.qTR), { transport: t11, codecs: a10 } = (0, rj.EKQ)(j2);
          return r3 = new rD({
            getFileInfoProviderParams: {
              resource: e11,
              secretKey: I2.player.secretKey,
              mediaConfigController: G2,
              transport: t11,
              codecs: a10,
              variables: {
                get fromPromoLanding() {
                  return true;
                }
              },
              mediaSourceTtlMs: I2.player.configVariablesPromoLandingPlayback.strmUrlsTtlMs
            },
            vhMediaProviderParams: I2.player.vhMediaProvider
          });
        }, [
          j2,
          I2.player.configVariablesPromoLandingPlayback.strmUrlsTtlMs,
          I2.player.secretKey,
          I2.player.vhMediaProvider,
          l2,
          G2
        ]), W2 = (0, R.useMemo)(() => {
          if (r1) return r1;
          let e11 = l2.get(rj.qTR), { transport: t11, codecs: a10 } = (0, rj.EKQ)(j2);
          return r1 = new rD({
            getFileInfoProviderParams: {
              resource: e11,
              secretKey: I2.player.secretKey,
              mediaConfigController: G2,
              transport: t11,
              codecs: a10,
              variables: {
                get isMediaSourcePreloadEnabled() {
                  return d2.checkExperiment(rj.zal.WebNextTracksPreload, "on");
                }
              },
              mediaSourceTtlMs: I2.player.configVariablesMainPlayback.strmUrlsTtlMs
            },
            vhMediaProviderParams: I2.player.vhMediaProvider
          });
        }, [
          j2,
          I2.player.configVariablesMainPlayback.strmUrlsTtlMs,
          I2.player.secretKey,
          I2.player.vhMediaProvider,
          l2,
          d2,
          G2
        ]), Y2 = (0, R.useMemo)(() => r2 || (r2 = new rN({ useExponentVolume: true })), []);
        (0, R.useEffect)(() => {
          C2 && Y2 && (C2.createAudioAdvertPlayback({ playbackController: Y2 }), g2.setIsAdvertPlaybackCreated(true));
        }, [g2, C2, Y2]);
        let z2 = (0, R.useMemo)(
          () => r4 ? r4 : r4 = new rL({ tracksResource: l2.get(rj.Ooh), clipsResource: l2.get(rj.jQD) }),
          [l2]
        ), H2 = (0, R.useMemo)(() => {
          if (r6) return r6;
          let e11 = l2.get(rj.Ooh), t11 = l2.get(rj._19), a10 = l2.get(rj.ok0), r11 = l2.get(rj.qNr), i3 = l2.get(rj.tzI), s3 = l2.get(rj.O9U);
          return r6 = new eU({
            contextFactoryParams: {
              logger: E2,
              variables: {
                vibe: {
                  get sendFeedbackToSessionTracks() {
                    return d2.checkExperiment(rj.zal.WebNextWaveNewFeedbacks, "on");
                  },
                  get sendInteractiveToSession() {
                    return d2.checkExperiment(rj.zal.WebNextInteractiveSessionNew, "on");
                  },
                  get useWaveQueue() {
                    return d2.checkExperiment(rj.zal.WebNextUseWaveQueue, "on");
                  }
                }
              },
              tracksResource: e11,
              usersResource: t11,
              rotorResource: a10,
              playlistResource: r11,
              albumsResource: i3,
              artistsResource: s3
            },
            entityFactoryParams: { likeStore: u2 }
          });
        }, [l2, d2, u2, E2]), Q2 = (0, R.useMemo)(
          () => r5 || (r5 = new ta({ telemetryResource: l2.get(rj.LCy), ...I2.player.telemetry })),
          [l2, I2.player.telemetry]
        ), $2 = (() => {
          let e11 = (0, rj.NFA)(), { experiments: t11 } = (0, rj.Pjs)(), a10 = e11.get(rj.twC), r11 = a10.player.yaspExpName, i3 = a10.player.yaspCandidateVersion;
          return r11 && i3 && t11.checkExperiment(r11, "on") ? i3 : a10.player.yaspVersionStable;
        })(), Z2 = (() => {
          let e11 = (0, rj.NFA)(), { experiments: t11 } = (0, rj.Pjs)(), {
            player: { yaspSourceLimit: a10 }
          } = e11.get(rj.twC);
          try {
            var r11;
            let e12 = t11.checkExperiment(rj.zal.WebNextYaspSourceLimit, "on"), i3 = t11.getExperiment(rj.zal.WebNextYaspSourceLimit);
            if (e12 && (null == i3 || null == (r11 = i3.value.metadata) ? void 0 : r11.yaspSourceLimit)) {
              let e13 = Number(i3.value.metadata.yaspSourceLimit);
              if (!Number.isNaN(e13)) return e13;
            }
            return a10;
          } catch (e12) {
            return a10;
          }
        })(), J2 = (0, R.useMemo)(() => {
          if (!W2 || !Y2 || !z2 || !H2) return null;
          if (rZ) return rZ;
          let e11 = l2.get(rj.A4B)({ credentials: "include" }), {
            player: { prefixUrl: t11, configVariablesMainPlayback: a10, configVariablesTrailerPlayback: r11 }
          } = I2, s3 = d2.checkExperiment(rj.zal.WebNextEnablePlaysPluginV2, "on") ? tJ : t7, n3 = l2.get(rj.UBc), u3 = l2.get(rj.TqU), g3 = [new ae(n3)];
          u3 && g3.push(new at(u3));
          let y3 = [
            new al({
              variables: {
                get isAutoflowEnabled() {
                  return w2;
                },
                get isVibeRepeatEnabled() {
                  return d2.checkExperiment(rj.zal.WebNextEnableVibeRepeatControl, "on") && d2.checkExperiment(rj.zal.WebNextUseWaveQueue, "on");
                }
              }
            }),
            new ao(),
            new ad(),
            new s3({
              httpClient: e11,
              playsResourceConfig: {
                params: {
                  common: {
                    client: (0, rK._)(),
                    device: (0, rj.V7X)(),
                    language: k2,
                    oauth: b2.token,
                    get multiAuthUserId() {
                      return l2.get(rj.WA$).getPassportUid();
                    }
                  }
                },
                prefixUrl: (0, N.getTldHost)(t11, i2, rj.BEZ)
              },
              variables: {
                get disableSendPlaysOnTrackStart() {
                  return d2.checkExperiment(rj.zal.WebNextDisableSendPlaysOnTrackStart, "on");
                },
                get enableLocalStoredPlaysData() {
                  return d2.checkExperiment(rj.zal.WebNextPlayAudioHeartBeat, "on");
                },
                get shouldDeletePlaysObjectStore() {
                  return d2.checkExperiment(rj.zal.WebNextDeleteIndexedDbPlaysStore, "on");
                },
                get enableRemoveDuplicatePlays() {
                  return d2.checkExperiment(rj.zal.WebNextRemoveDuplicatePlays, "on");
                },
                get enableSendFadeFieldsInPlays() {
                  return d2.checkExperiment(rj.zal.WebNextEnableSendFadeFieldsInPlays, "on");
                }
              },
              isCrossfadeEnabled: G2.isCrossfadeEnabled
            }),
            new ag({ browserName: j2.name, browserVersion: j2.version }),
            new ay({ logger: E2 }),
            new am(G2.quality),
            new aP({
              httpClient: e11,
              streamsResourceConfig: {
                params: {
                  common: {
                    client: (0, rK._)(),
                    device: (0, rj.V7X)(),
                    language: k2,
                    oauth: b2.token,
                    get multiAuthUserId() {
                      return l2.get(rj.WA$).getPassportUid();
                    }
                  }
                },
                prefixUrl: (0, N.getTldHost)(t11, i2, rj.BEZ)
              },
              variables: {
                get isEnabled() {
                  return h2.isAuthorized;
                }
              }
            }),
            new aD({
              mediaConfigController: G2,
              transports: g3,
              variables: {
                get enableDebugMode() {
                  return F2;
                }
              }
            }),
            new aL({
              mediaProvider: W2,
              mediaConfigController: G2,
              config: {
                entitiesToPreloadStrmUrlsCount: a10.entitiesToPreloadStrmUrlsCount,
                entitiesToPreloadSourceCount: a10.entitiesToPreloadSourceCount,
                preloadedSourcesMaxCount: a10.preloadedSourcesMaxCount,
                strmUrlsTtlMs: a10.strmUrlsTtlMs,
                bufferGoal: a10.bufferGoal
              },
              variables: {
                get isMediaSourcePreloadEnabled() {
                  return d2.checkExperiment(rj.zal.WebNextTracksPreload, "on");
                }
              }
            }),
            new aR({
              onTrailerPaused: () => {
                c2.setIsManuallyPaused(true);
              },
              onTrailerPlaying: () => {
                c2.setIsManuallyPaused(false);
              },
              playbackController: Y2,
              trailerPlaybackParams: {
                id: rj.V_r.TRAILER,
                plugins: [
                  new e5({ useFade: X2, useSmartPreview: true }),
                  new al({
                    variables: {
                      get isAutoflowEnabled() {
                        return false;
                      },
                      get isVibeRepeatEnabled() {
                        return false;
                      }
                    }
                  }),
                  new ay({ logger: E2 }),
                  new ad(),
                  new aD({
                    mediaConfigController: G2,
                    transports: g3,
                    variables: {
                      get enableDebugMode() {
                        return F2;
                      }
                    }
                  }),
                  new s3({
                    httpClient: e11,
                    playsResourceConfig: {
                      params: {
                        common: {
                          client: (0, rK._)(),
                          device: (0, rj.V7X)(),
                          language: k2,
                          oauth: b2.token,
                          get multiAuthUserId() {
                            return l2.get(rj.WA$).getPassportUid();
                          }
                        }
                      },
                      prefixUrl: (0, N.getTldHost)(t11, i2, rj.BEZ)
                    },
                    variables: {
                      get disableSendPlaysOnTrackStart() {
                        return d2.checkExperiment(rj.zal.WebNextDisableSendPlaysOnTrackStart, "on");
                      },
                      get enableLocalStoredPlaysData() {
                        return d2.checkExperiment(rj.zal.WebNextPlayAudioHeartBeat, "on");
                      },
                      get shouldDeletePlaysObjectStore() {
                        return d2.checkExperiment(rj.zal.WebNextDeleteIndexedDbPlaysStore, "on");
                      }
                    },
                    storePlaysProgressIntervalMs: 5e3
                  }),
                  new aw()
                ],
                factory: H2,
                entityProvider: z2,
                playbackConfig: {
                  mediaElementErrorReloadCount: r11.mediaElementErrorReloadCount,
                  windowSize: r11.windowSize,
                  setupQueueWindowSize: r11.setupQueueWindowSize
                }
              }
            }),
            U2,
            new aw()
          ];
          if (V2 && y3.push(V2), !L2) {
            let e12 = l2.get(rj.byd), t12 = new rl({
              factory: H2,
              deviceConfig: e12.deviceConfig,
              ynisonStateController: e12.stateController,
              fallbackTypesQueueToVibe: [x.$P.UNSPECIFIED, x.$P.FM_RADIO, x.$P.VIDEO_WAVE, x.$P.LOCAL_TRACKS],
              variables: {
                get shouldApplyState() {
                  return o2.shouldApplyYnisonState;
                },
                get enableSendLimitedEntityListToYnison() {
                  return d2.checkExperiment(rj.zal.WebNextEnableSendLimitedEntityListToYnison, "on");
                },
                get useWaveQueue() {
                  return d2.checkExperiment(rj.zal.WebNextUseWaveQueue, "on");
                }
              }
            }), a11 = new ru({
              deviceConfig: e12.deviceConfig,
              ynisonStateController: e12.stateController,
              variables: {
                get shouldApplyState() {
                  return o2.shouldApplyYnisonState;
                }
              }
            });
            y3.push(a11), y3.push(t12);
          }
          return y3.push(
            new rh({
              factory: H2,
              platform: "desktop",
              variables: {
                get enabled() {
                  return w2;
                }
              }
            })
          ), Q2 && y3.push(
            new rg({
              telemetry: Q2,
              get puid() {
                return h2.puid;
              },
              yaspVersion: $2,
              get telemetryTestIds() {
                return T2();
              }
            })
          ), rZ = new rw({
            factory: H2,
            playbackController: Y2,
            plugins: y3,
            entityProvider: z2,
            playbackConfig: {
              mediaElementErrorReloadCount: a10.mediaElementErrorReloadCount,
              windowSize: a10.windowSize,
              setupQueueWindowSize: a10.setupQueueWindowSize
            }
          });
        }, [
          W2,
          Y2,
          z2,
          H2,
          l2,
          I2,
          k2,
          b2.token,
          i2,
          j2.name,
          j2.version,
          E2,
          G2,
          X2,
          U2,
          V2,
          L2,
          Q2,
          w2,
          d2,
          h2.isAuthorized,
          h2.puid,
          F2,
          c2,
          o2.shouldApplyYnisonState,
          $2,
          T2
        ]);
        (0, rG.H)(J2);
        let ee2 = (0, rR.c)((e11) => {
          null == J2 || J2.setExponentVolume(e11), null == J2 || J2.setExponentVolume(e11, rj.V_r.TRAILER), o2.setVolume(e11), n2 && (null == J2 || J2.setExponentVolume(e11, rj.V_r.PROMO_LANDING), m2.setVolume(e11));
        }), et2 = (0, rR.c)(() => {
          let e11 = f2.get(rj.cYZ.YmPlayerVolume);
          "number" == typeof e11 ? ee2(e11) : ee2(1);
        });
        ((e11) => {
          let {
            mediaProvider: t11,
            playbackController: a10,
            factory: r11,
            entityProvider: i3,
            mediaConfigController: s3,
            isEnabled: n3,
            isMetricsDebugEnabled: l3,
            hostTld: o3,
            browserInfo: d3
          } = e11, u3 = (0, rj.NFA)(), c3 = (0, rj.UlF)(), { experiments: h3 } = (0, rj.Pjs)(), { language: g3 } = (0, rj.h6b)();
          if (!n3 || !a10 || !r11 || !t11 || !i3 || !s3 || rH) return;
          let y3 = u3.get(rj.QGx), m3 = u3.get(rj.twC), p3 = u3.get(rj.A4B)({ credentials: "include" }), {
            player: { configVariablesPromoLandingPlayback: v3, prefixUrl: P3 }
          } = m3, S3 = u3.get(rj.UBc), E3 = u3.get(rj.TqU), f3 = [new ae(S3)];
          E3 && f3.push(new at(E3)), null == a10 || a10.createPlayback(rj.V_r.PROMO_LANDING, {
            factory: r11,
            entityProvider: i3,
            playbackConfig: {
              mediaElementErrorReloadCount: v3.mediaElementErrorReloadCount,
              windowSize: v3.windowSize,
              setupQueueWindowSize: v3.setupQueueWindowSize
            }
          });
          let b3 = a10.getPlayback(rj.V_r.PROMO_LANDING);
          for (let e12 of [
            new al({
              variables: {
                get isAutoflowEnabled() {
                  return false;
                },
                get isVibeRepeatEnabled() {
                  return false;
                }
              }
            }),
            new ao(),
            new ad(),
            new t7({
              httpClient: p3,
              playsResourceConfig: {
                params: {
                  common: {
                    client: (0, rK._)(),
                    device: (0, rj.V7X)(),
                    language: g3,
                    oauth: y3.token,
                    get multiAuthUserId() {
                      return u3.get(rj.WA$).getPassportUid();
                    }
                  }
                },
                prefixUrl: (0, N.getTldHost)(P3, o3, rj.BEZ)
              },
              variables: {
                get disableSendPlaysOnTrackStart() {
                  return h3.checkExperiment(rj.zal.WebNextDisableSendPlaysOnTrackStart, "on");
                },
                get enableLocalStoredPlaysData() {
                  return h3.checkExperiment(rj.zal.WebNextPlayAudioHeartBeat, "on");
                },
                get shouldDeletePlaysObjectStore() {
                  return h3.checkExperiment(rj.zal.WebNextDeleteIndexedDbPlaysStore, "on");
                },
                get enablePartialPlayReporting() {
                  return true;
                }
              }
            }),
            new ag({ browserName: d3.name, browserVersion: d3.version }),
            new ay({ logger: c3 }),
            new aD({
              mediaConfigController: s3,
              transports: f3,
              variables: {
                get enableDebugMode() {
                  return l3;
                }
              }
            }),
            new aw()
          ])
            e12.apply({ playback: b3, hooks: b3.hooks });
          rH = true;
        })({
          isEnabled: !!n2,
          playbackController: Y2,
          entityProvider: z2,
          factory: H2,
          mediaConfigController: G2,
          isNonSafariBrowser: X2,
          isMetricsDebugEnabled: F2,
          browserInfo: j2,
          hostTld: i2,
          mediaProvider: q2
        }), (0, R.useEffect)(() => {
          J2 && O2 && (window.sonataState = J2.state);
        }, [O2, J2]), (0, R.useEffect)(() => {
          J2 && W2 && q2 && Q2 && !o2.areCoresRegistered && (Promise.all([a.e(9096), a.e(2556)]).then(a.bind(a, 2556)).then((e11) => {
            let { YaspCoreAdapter: t11, YaspLoader: a10, HlsCoreAdapter: r11, HtmlAudioCoreAdapter: i3 } = e11, s3 = new a10({
              logger: E2,
              yaspTelemetry: Q2,
              get telemetryTestIds() {
                return T2();
              }
            }), l3 = X2 ? new r11({ hlsErrorRetryLimit: I2.player.hlsErrorRetryLimit }) : new i3();
            J2.registerMediaPlayer({
              mediaPlayerParams: {
                core: l3,
                mediaProvider: W2,
                mediaPlayerType: "audioMediaPlayer",
                contentType: K.e.HLS
              }
            }), C2 && J2.registerMediaPlayer({
              mediaPlayerParams: {
                core: new i3(),
                mediaProvider: new rj.Uvn(),
                mediaPlayerType: "audioMediaPlayer",
                contentType: K.e.AUDIO
              },
              playbackId: rj.V_r.ADVERT
            }), J2.registerMediaPlayer({
              mediaPlayerParams: {
                core: new i3(),
                mediaProvider: W2,
                mediaPlayerType: "audioMediaPlayer",
                contentType: K.e.DOWNLOADED_AUDIO
              }
            }), s3.loadYasp({ version: $2, sourceLimit: Z2, retryDelayMs: I2.player.yaspLoadRetryDelayMs }).then(() => {
              let e12, a11 = s3.getYaspAudioElement();
              e12 = window.Worker ? new eZ() : new e$(), D2 ? J2.registerMediaPlayer({
                mediaPlayerParams: {
                  mediaPlayerType: "crossMediaPlayer",
                  mediaProvider: W2,
                  ticker: e12,
                  contentType: K.e.AUDIO,
                  core: new t11({ yaspAudioElement: a11, yaspTelemetry: Q2 }),
                  additionalCore: new t11({ yaspAudioElement: a11, yaspTelemetry: Q2 }),
                  config: { useVolumeForAudioEffect: !X2 },
                  isEnabled: G2.isCrossfadeEnabled
                }
              }) : J2.registerMediaPlayer({
                mediaPlayerParams: {
                  mediaPlayerType: "audioMediaPlayer",
                  core: new t11({ yaspAudioElement: a11, yaspTelemetry: Q2 }),
                  mediaProvider: W2,
                  contentType: K.e.AUDIO
                }
              }), J2.registerMediaPlayer({
                mediaPlayerParams: {
                  core: new t11({ yaspAudioElement: a11 }),
                  mediaProvider: W2,
                  mediaPlayerType: "audioMediaPlayer",
                  contentType: K.e.AUDIO
                },
                playbackId: rj.V_r.TRAILER
              }), n2 && q2 && J2.registerMediaPlayer({
                mediaPlayerParams: {
                  core: new t11({ yaspAudioElement: a11 }),
                  mediaProvider: q2,
                  mediaPlayerType: "audioMediaPlayer",
                  contentType: K.e.AUDIO
                },
                playbackId: rj.V_r.PROMO_LANDING
              }), et2();
            }).catch((e12) => {
              E2.error("[SonataProvider] Error trying to register media players", { error: e12 });
            });
          }), o2.setCoresAsRegistered(true));
        }, [
          C2,
          I2.player.hlsErrorRetryLimit,
          $2,
          Z2,
          X2,
          E2,
          W2,
          q2,
          et2,
          J2,
          o2,
          n2,
          l2,
          o2.areCoresRegistered,
          Q2,
          D2,
          T2,
          I2.player.yaspSourceLimit,
          I2.player.yaspLoadRetryDelayMs,
          G2.isCrossfadeEnabled
        ]), (0, R.useEffect)(() => {
          a.e(1886).then(a.bind(a, 41886)).then((e11) => {
            let { loadVHPlayerSdk: t11, VHPlayerCoreAdapter: a10 } = e11;
            if (!J2 || !W2 || !Y2 || !z2 || !H2) return;
            let r11 = new a10({ hideAds: true }), { configVariablesMainPlayback: i3 } = I2.player, s3 = async () => t11(I2.player.vhPlayerSdkVersion).then(() => {
              Y2.createPlayback(rj.V_r.CLIP, {
                mediaPlayerParams: {
                  core: r11,
                  mediaProvider: W2,
                  mediaPlayerType: "videoMediaPlayer",
                  contentType: K.e.CLIP
                },
                entityProvider: z2,
                factory: H2,
                playbackConfig: {
                  mediaElementErrorReloadCount: i3.mediaElementErrorReloadCount,
                  windowSize: i3.windowSize,
                  setupQueueWindowSize: i3.setupQueueWindowSize
                },
                syncVolumeWithMainPlayback: true
              });
              let e12 = Y2.getPlayback(rj.V_r.CLIP);
              for (let t12 of [
                new al({
                  variables: {
                    get isAutoflowEnabled() {
                      return false;
                    },
                    get isVibeRepeatEnabled() {
                      return false;
                    }
                  }
                }),
                new ad(),
                U2
              ])
                t12.apply({ playback: e12, hooks: e12.hooks });
              o2.setIsVHCoreRegistered(true);
            }).catch(() => {
              setTimeout(s3, 1e3);
            });
            s3();
          });
        }, [U2, I2.player, l2, z2, H2, W2, Y2, J2, o2, h2.hasPlus]), (0, rG.OM)({ sonata: J2 }), (0, rO.rb)({ sonata: J2 }), ((e11) => {
          let { sonata: t11, playbackId: a10, withStorage: r11, sonataState: i3 } = e11, s3 = (0, rj.NFA)().get(rj.ooW);
          (0, R.useEffect)(() => {
            var e12;
            let n3, l3, o3, d3, u3, c3 = null == t11 ? void 0 : t11.getState(a10).queueState.currentEntity.onChange((e13) => {
              let t12 = null == e13 ? void 0 : e13.context.data.type, a11 = null == e13 ? void 0 : e13.context.data.meta.id, r12 = null == e13 ? void 0 : e13.entity;
              r12 && i3.setEntityMeta(r12), t12 && i3.setContextType(t12), a11 && i3.setContextId(a11);
            }), h3 = null == t11 ? void 0 : t11.getState(a10).playerState.status.onChange((e13) => {
              e13 && i3.setStatus(e13);
            }), g3 = null == t11 ? void 0 : t11.getState(a10).currentContext.onChange(() => {
              var e13, c4, h4, g4, y4, m4;
              if (null == n3 || n3(), null == l3 || l3(), null == o3 || o3(), null == d3 || d3(), null == u3 || u3(), r11) {
                let e14 = null != (m4 = s3.get(rj.cYZ.YmPlayerRepeatMode)) ? m4 : rQ.pM.NONE;
                null == t11 || t11.setRepeatMode(e14, a10);
                let r12 = !!s3.get(rj.cYZ.YmPlayerShuffle);
                null == t11 || t11.setShuffle(r12, a10);
              }
              n3 = null == t11 || null == (e13 = t11.getState(a10).currentContext.value) ? void 0 : e13.availableActions.moveBackward.onChange((e14) => {
                i3.setCanMoveBackward(!!e14);
              }), l3 = null == t11 || null == (c4 = t11.getState(a10).currentContext.value) ? void 0 : c4.availableActions.moveForward.onChange((e14) => {
                i3.setCanMoveForward(!!e14);
              }), o3 = null == t11 || null == (h4 = t11.getState(a10).currentContext.value) ? void 0 : h4.availableActions.repeat.onChange((e14) => {
                "boolean" == typeof e14 && i3.setCanChangeRepeatMode(e14);
              }), d3 = null == t11 || null == (g4 = t11.getState(a10).currentContext.value) ? void 0 : g4.availableActions.shuffle.onChange((e14) => {
                "boolean" == typeof e14 && i3.setCanShuffle(e14);
              }), u3 = null == t11 || null == (y4 = t11.getState(a10).currentContext.value) ? void 0 : y4.availableActions.speed.onChange((e14) => {
                "boolean" == typeof e14 && (i3.setCanSpeed(e14), e14 || null == t11 || t11.setSpeed(1, a10));
              });
            }), y3 = null == t11 || null == (e12 = t11.getState(a10).playerState) ? void 0 : e12.progress.onChange((e13) => {
              e13 && (i3.setPosition(e13.position), i3.setDuration(e13.duration));
            }), m3 = null == t11 ? void 0 : t11.getState(a10).playerState.volume.onChange(() => {
              let e13 = null == t11 ? void 0 : t11.getState(a10).playerState.exponentVolume.value;
              "number" == typeof e13 && i3.setVolume(e13);
            }), p3 = null == t11 ? void 0 : t11.getState(a10).queueState.repeat.onChange((e13) => {
              e13 && (i3.setRepeatMode(e13), r11 && s3.set(rj.cYZ.YmPlayerRepeatMode, e13, { expires: 365 }));
            }), v3 = null == t11 ? void 0 : t11.getState(a10).queueState.shuffle.onChange((e13) => {
              "boolean" == typeof e13 && (i3.setShuffle(e13), r11 && s3.set(rj.cYZ.YmPlayerShuffle, e13, { expires: 365 }));
            });
            return () => {
              null == c3 || c3(), null == h3 || h3(), null == g3 || g3(), null == m3 || m3(), null == p3 || p3(), null == o3 || o3(), null == d3 || d3(), null == v3 || v3(), null == y3 || y3(), null == n3 || n3(), null == l3 || l3(), null == u3 || u3();
            };
          }, [a10, t11, i3, s3, r11]);
        })({ sonata: J2, playbackId: n2 ? rj.V_r.PROMO_LANDING : void 0, withStorage: !n2, sonataState: n2 ? m2 : o2 });
        let ea2 = (0, R.useCallback)(() => {
          if (!h2.isAuthorized || P2 || !h2.hasPlus && B2) return a_.e.PREVIEW;
          if (S2) return a_.e.EFFICIENT;
          let e11 = f2.get(rj.cYZ.YmPlayerQuality);
          if (e11) {
            if (Object.values(rj.lv9).includes(e11)) {
              let t11 = (0, rj.SBI)(e11);
              return f2.set(rj.cYZ.YmPlayerQuality, t11, { expires: 365 }), t11;
            }
            return e11;
          }
          return f2.set(rj.cYZ.YmPlayerQuality, a_.e.BALANCED, { expires: 365 }), a_.e.BALANCED;
        }, [f2, P2, S2, h2.isAuthorized, h2.hasPlus, B2]);
        return (0, R.useEffect)(
          () => (n2 && (null == J2 || J2.stop(), Object.values(rj.V_r).forEach((e11) => {
            e11 !== rj.V_r.PROMO_LANDING && (null == J2 || J2.stop(e11));
          })), () => {
            n2 && (null == J2 || J2.stop(rj.V_r.PROMO_LANDING));
          }),
          [J2, n2]
        ), (0, R.useEffect)(() => {
          n2 || (G2.setQuality(ea2()), o2.setQuality(ea2()));
        }, [G2, ea2, o2, n2]), (0, R.useEffect)(() => {
          let e11 = f2.get(rj.cYZ.CrossFadeMode), t11 = !!D2 && (null == e11 || e11);
          f2.set(rj.cYZ.CrossFadeMode, t11, { expires: 365 }), G2.isCrossfadeEnabled.value = t11;
        }, [G2, o2, f2, D2]), (0, R.useEffect)(() => {
          (0, rM.Bx)(f2, r8);
        }, [f2]), (0, A.jsx)(rj.cdg.Provider, {
          value: G2,
          children: (0, A.jsxs)(rj.GsR.Provider, {
            value: J2,
            children: [
              (0, A.jsx)(rF.mW, {}),
              (0, A.jsx)(rY, { isYnisonDisabled: L2 }),
              (0, A.jsx)(rj.WM$.Provider, {
                value: V2,
                children: (0, A.jsxs)(rz, { children: [(0, A.jsx)(rq, {}), r10] })
              })
            ]
          })
        });
      }, r7 = (0, L.PA)((e10) => {
        let { children: t10, hostTld: a10, quality: r10, ...i2 } = e10, s2 = (0, rj.Dg5)();
        return (0, A.jsx)(R.Suspense, {
          fallback: (0, A.jsx)(rX.JR, {}),
          children: (0, A.jsx)(rB, {
            audioLoader: s2,
            children: (0, A.jsx)(r9, { hostTld: a10, quality: r10, ...i2, children: t10 })
          })
        });
      });
    },
    63118: (e) => {
      e.exports = {
        root: "FeedConcerts_root__W7OGN",
        header: "FeedConcerts_header__Ht1xd",
        container: "FeedConcerts_container__CONvW",
        column: "FeedConcerts_column__FpMgx",
        row: "FeedConcerts_row__HEdtn"
      };
    },
    65381: (e, t, a) => {
      "use strict";
      a.d(t, { PlaylistPersonalPage: () => d });
      var r = a(54486), i = a(28303), s = a(97396), n = a(61910), l = a(74125), o = a(95657);
      let d = (0, i.PA)((e2) => {
        let { params: t2, searchParams: a2 } = e2, { playlistPersonal: i2 } = (0, l.Pjs)(), d2 = i2.getUrl(a2);
        if ((0, n.useEffect)(() => {
          i2.isNeededToLoad && i2.getPlaylistPersonalDetails(t2.playlistId);
        }, [i2.isNeededToLoad, t2.playlistId, i2]), (0, n.useEffect)(
          () => () => {
            i2.reset();
          },
          [i2]
        ), (0, l.Jzs)(i2.isResolved), (i2.isNotFound || i2.isRejected) && (0, s.notFound)(), i2.isResolved && !i2.isReady)
          return i2.dummyDescription || (0, s.notFound)(), (0, r.jsx)(o.PlaylistPersonalDummyPage, {});
        i2.isResolved && i2.isReady && (0, s.redirect)(d2);
      });
    },
    65429: (e, t, a) => {
      "use strict";
      a.d(t, { E: () => n });
      var r = a(61910), i = a(97719), s = a(74125);
      let n = (e2) => {
        let { controller: t2, sonataState: a2, playbackId: n2, groupId: l } = e2, o = (0, s.eGp)(), d = (0, s.NFA)(), u = (0, i.d0)(), c = d.get(s.ooW);
        (0, r.useEffect)(
          () => (null == t2 || t2.addShortcutsListener(l, s.lbr.DECREASE_VOLUME, async () => {
            let e3 = await (null == o ? void 0 : o.decreaseExponentVolume(0.05, n2));
            c.set(s.cYZ.YmPlayerVolume, e3, { expires: 365 });
          }), null == t2 || t2.addShortcutsListener(l, s.lbr.INCREASE_VOLUME, async () => {
            let e3 = await (null == o ? void 0 : o.increaseExponentVolume(0.05, n2));
            c.set(s.cYZ.YmPlayerVolume, e3, { expires: 365 });
          }), null == t2 || t2.addShortcutsListener(l, s.lbr.TOGGLE_MUTE, async () => {
            let e3 = null == o ? void 0 : o.getState(n2).playerState.exponentVolume.value;
            void 0 !== e3 && await u(a2, e3, n2);
          }), () => {
            null == t2 || t2.removeShortcutsListener(l, s.lbr.DECREASE_VOLUME), null == t2 || t2.removeShortcutsListener(l, s.lbr.INCREASE_VOLUME), null == t2 || t2.removeShortcutsListener(l, s.lbr.TOGGLE_MUTE);
          }),
          [t2, n2, o, c, u, a2, l]
        ), (0, r.useEffect)(() => {
          if (!a2.isGenerativeContext)
            return null == t2 || t2.addShortcutsListener(l, s.lbr.MOVE_BACKWARD, async () => {
              var e3;
              (null == o || null == (e3 = o.getState(n2).currentContext.value) ? void 0 : e3.availableActions.moveBackward.value) && await o.moveBackward(n2);
            }), null == t2 || t2.addShortcutsListener(l, s.lbr.MOVE_FORWARD, async () => {
              var e3;
              (null == o || null == (e3 = o.getState(n2).currentContext.value) ? void 0 : e3.availableActions.moveForward.value) && await (null == o ? void 0 : o.moveForward(n2));
            }), null == t2 || t2.addShortcutsListener(l, s.lbr.SLIDE_BACKWARD, async () => {
              (null == o ? void 0 : o.getState(n2).playerState.progress.value.duration) && await (null == o ? void 0 : o.slideBackward(2, n2));
            }), null == t2 || t2.addShortcutsListener(l, s.lbr.SLIDE_FORWARD, async () => {
              (null == o ? void 0 : o.getState(n2).playerState.progress.value.duration) && await (null == o ? void 0 : o.slideForward(2, n2));
            }), () => {
              null == t2 || t2.removeShortcutsListener(l, s.lbr.MOVE_FORWARD), null == t2 || t2.removeShortcutsListener(l, s.lbr.MOVE_BACKWARD), null == t2 || t2.removeShortcutsListener(l, s.lbr.SLIDE_BACKWARD), null == t2 || t2.removeShortcutsListener(l, s.lbr.SLIDE_FORWARD);
            };
        }, [t2, o, c, a2.isGenerativeContext, n2, l]);
      };
    },
    65445: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { ThemeProvider: () => o });
      var r = a(54486), i = a(61910), s = a(8817), n = a(74125), l = a(80585);
      let o = (e2) => {
        let { children: t2, predefinedTheme: a2 } = e2, o2 = (0, n.NFA)().get(n.ooW), { getThemeFromStorage: d, setThemeToStorage: u } = (0, n.QDo)(o2), [c, h] = (0, i.useState)(() => null != a2 ? a2 : d()), g = (0, s.c)((e3) => {
          d() || a2 || (u(n.W3W), h(e3));
        });
        (0, i.useLayoutEffect)(() => {
          a2 || (0, n.Z8R)(c);
        }, [c, a2]), (0, n.kgS)({ onSystemThemeChange: g }), (0, i.useLayoutEffect)(() => {
          g((0, n.VDQ)());
        }, [g]);
        let y = (0, i.useMemo)(() => ({ theme: c, setTheme: h }), [c]);
        return (0, r.jsx)(n.Dx0.Provider, {
          value: y,
          children: (0, r.jsx)(i.Suspense, { fallback: (0, r.jsx)(l.JR, {}), children: t2 })
        });
      };
    },
    67923: (e, t, a) => {
      "use strict";
      a.d(t, { KidsNotFoundPage: () => o });
      var r = a(54486), i = a(28303), s = a(61910), n = a(42421), l = a(74125);
      let o = (0, i.PA)(() => {
        let { kids: e2 } = (0, l.Pjs)();
        return (0, s.useEffect)(
          () => () => {
            e2.landing.reset();
          },
          [e2.landing]
        ), (0, r.jsx)(n.M, {});
      });
    },
    69961: (e, t, a) => {
      "use strict";
      a.d(t, { uN: () => d.GenresPage, Zt: () => o });
      var r = a(93064), i = a(14287), s = a(30004), n = a(74125), l = a(26433);
      let o = r.gK.compose(
        r.gK.model("GenresPageModel", {
          title: r.gK.maybeNull(r.gK.string),
          items: r.gK.array(s.Gc),
          errorStatusCode: r.gK.maybeNull(r.gK.number)
        }),
        l.XT
      ).views((e2) => ({
        get isLoading() {
          return e2.isNeededToLoad || e2.loadingState === n.GuX.PENDING;
        },
        get isNotFound() {
          let t2 = e2.isResolved && 0 === e2.items.length;
          return e2.errorStatusCode === i.X1.NOT_FOUND || t2;
        }
      })).actions((e2) => ({
        getData: (0, r.L3)(function* (t2) {
          let { landing3Resource: a2, modelActionsLogger: l2 } = (0, r._$)(e2);
          if (e2.loadingState !== n.GuX.PENDING)
            try {
              e2.loadingState = n.GuX.PENDING;
              let l3 = (yield a2.getMetatags({})).trees.find((e3) => e3.navigationId === t2);
              if (!l3) {
                e2.errorStatusCode = i.X1.NOT_FOUND;
                return;
              }
              e2.title = l3.title, e2.items = (0, r.wg)(l3.leaves.map(s.kc)), e2.loadingState !== n.GuX.IDLE && (e2.loadingState = n.GuX.RESOLVE);
            } catch (t3) {
              l2.error(t3), t3 instanceof i.GX && (t3.statusCode === i.X1.NOT_FOUND || t3.statusCode === i.X1.BAD_REQUEST) && (e2.errorStatusCode = i.X1.NOT_FOUND), e2.loadingState !== n.GuX.IDLE && (e2.loadingState = n.GuX.REJECT);
            }
        }),
        reset() {
          e2.loadingState = n.GuX.IDLE, e2.title = null, e2.items = (0, r.wg)([]), e2.errorStatusCode = null;
        }
      }));
      a(95364);
      var d = a(26794);
    },
    71108: (e, t, a) => {
      "use strict";
      a.d(t, { ChartPodcastsPage: () => S });
      var r = a(54486), i = a(50420), s = a(28303), n = a(97396), l = a(61910), o = a(43426), d = a(31500), u = a(22674), c = a(97800), h = a(82644), g = a(94376), y = a(33276), m = a(74125), p = a(80585), v = a(85218), P = a.n(v);
      let S = (0, s.PA)((e2) => {
        let { categoryId: t2 } = e2, {
          chart: { podcastsSubPage: a2 },
          settings: { isMobile: s2 }
        } = (0, m.Pjs)(), { contentScrollRef: v2, setContentScrollRef: S2 } = (0, m.gKY)(), { formatMessage: E } = (0, o.A)(), f = (0, m.W6M)(), b = (0, l.useMemo)(
          () => ({ Footer: () => (0, r.jsx)(p.A, { children: (0, r.jsx)(p.wi, { className: P().footer }) }) }),
          []
        ), I = (0, l.useMemo)(
          () => a2.title ? (0, r.jsx)(c.Heading, {
            id: "collection-artists-header",
            variant: "h1",
            weight: "bold",
            size: "xl",
            lineClamp: 1,
            children: a2.title
          }) : (0, r.jsx)(u.Shimmer, { className: P().shimmerTitle, radius: "l" }),
          [a2.title]
        );
        if ((0, m.Jzs)(a2.isResolved), a2.isNotFound && (0, n.notFound)(), (0, l.useEffect)(
          () => () => {
            a2.reset();
          },
          [a2]
        ), a2.isNeededToLoad && (0, l.use)(a2.getData(t2)), a2.isSomethingWrong)
          return (0, r.jsx)(h.w, {});
        let _ = a2.isLoading ? 20 : a2.items.length;
        return (0, r.jsx)(m.nVz, {
          pageId: t2 ? m._Q$.CHART_PODCASTS_CATEGORY : m._Q$.CHART_PODCASTS,
          children: (0, r.jsx)(y.hO, {
            scrollElement: v2,
            outerTitle: a2.title,
            children: (0, r.jsxs)("div", {
              className: P().root,
              ...(0, d.Am)(d.Xk.chart.CHART_PODCASTS),
              children: [
                (0, r.jsx)(p.Y9, {
                  variant: p.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: f.canBack,
                  children: I
                }),
                (0, r.jsx)(p.$$, {
                  className: (0, i.$)(P().scrollContainer, P().important),
                  listClassName: P().content,
                  customComponents: b,
                  itemContentCallback: (e3) => {
                    let t3 = a2.items[e3], i2 = E(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: E({ id: "entity-names.album" }) }
                    );
                    return !t3 || a2.isLoading ? (0, r.jsx)(p.Vt, { "aria-label": i2 }) : (0, r.jsx)(g.aX, {
                      album: t3,
                      contentLinesCount: 3,
                      withLikesCount: true,
                      withChart: true,
                      withAddition: false
                    });
                  },
                  handleRef: S2,
                  initialItemCount: _,
                  totalCount: _,
                  isMobileLayout: s2,
                  useWindowScroll: s2,
                  context: { listAriaLabel: E({ id: "entity-names.chart-podcasts-list" }) }
                })
              ]
            })
          })
        });
      });
    },
    71267: (e, t, a) => {
      "use strict";
      a.d(t, { SlamProvider: () => m });
      var r = a(54486), i = a(28303), s = a(61910), n = a(47713), l = a(50389), o = a(87787), d = a(81849), u = a(12460), c = a(8817), h = a(84262), g = a(74125);
      let y = true, m = (0, i.PA)((e2) => {
        var t2, a2, i2;
        let { children: m2 } = e2, { slam: p, user: v, experiments: P } = (0, g.Pjs)(), S = (0, g.jRO)(), E = (0, g.NFA)(), f = E.get(g.U2_), b = E.get(g.vgk), I = (0, g.gQL)(), { notify: _ } = (0, g.lkh)(), k = (0, c.c)((e3) => {
          p.setNetworkStatus(e3);
        }), C = (0, c.c)((e3) => {
          let { id: t3, state: a3 } = e3;
          p.setTrack(t3, a3), a3.loadingState === u.DT.DOWNLOAD_FAILED && _((0, r.jsx)(h.i, { message: (0, r.jsx)(n.A, { id: "offline.track-download-error" }) }), {
            containerId: g.uQT.ERROR
          });
        }), T = (0, c.c)((e3) => {
          p.setTracks(e3);
        });
        return v.account.data.uid && v.hasPlus && S.init({
          userConfig: { uid: v.account.data.uid },
          resources: {
            tracksResource: E.get(g.Ooh),
            getFileInfoResource: E.get(g.qTR),
            availabilityResource: E.get(g.$5W)
          },
          downloaderVariables: {
            maxConcurrentDownloads: 5,
            getQuality: () => (0, l.i)({ productQuality: null == I ? void 0 : I.quality.value })
          },
          featureFlags: { entities: true },
          tracksControllerVariables: { requestTrackChunkSize: 100 },
          trackDownloadTaskParams: {
            secretKey: E.get(g.twC).player.secretKey,
            transport: d.o.ENCRAW,
            variables: { chunkSize: 1048576, coverSize: 1e3, codecs: o.iy }
          }
        }), (0, s.useEffect)(() => {
          if (y) {
            var e3;
            null == (e3 = S.tracksController) || e3.getTracksCount().then((e4) => {
              let t3 = (0, g.f2y)(e4);
              t3 && b.count({ [g.xQR.TRACKS_COUNT]: t3 }, g.l6e);
            }), y = false;
          }
        }, [b, S.tracksController]), (0, s.useEffect)(() => {
          if (void 0 !== v.puid && !P.checkExperiment(g.zal.WebNextOfflineDegradation, "default")) {
            var e3, t3;
            let a3 = null == (e3 = P.getExperiment(g.zal.WebNextOfflineDegradation)) ? void 0 : e3.group, r2 = "".concat(g.cYZ.OfflineDegradation, "_").concat(v.puid), i3 = f.get(r2);
            a3 && a3 !== i3 && (null == (t3 = S.tracksController) || t3.clearAll(), f.set(r2, a3));
          }
        }, [P, f, S, v.puid]), (0, s.useEffect)(() => {
          var e3, t3, a3;
          return null == (e3 = S.store) || e3.tracks.events.on(u.je.ENTITY_CHANGED, C), null == (t3 = S.store) || t3.tracks.events.on(u.je.STATE_CHANGED, T), null == (a3 = S.tracksController) || a3.initState(), () => {
            var e4, t4;
            null == (e4 = S.store) || e4.tracks.events.off(u.je.ENTITY_CHANGED, C), null == (t4 = S.store) || t4.tracks.events.off(u.je.STATE_CHANGED, T);
          };
        }, [C, T, null == (t2 = S.store) ? void 0 : t2.tracks.events, S.tracksController]), (0, s.useEffect)(() => {
          var e3;
          return null == (e3 = S.network) || e3.subscribe(k), () => {
            var e4;
            null == (e4 = S.network) || e4.unsubscribe(k);
          };
        }, [
          k,
          S.network,
          null == (a2 = S.network) ? void 0 : a2.subscribe,
          null == (i2 = S.network) ? void 0 : i2.unsubscribe
        ]), (0, s.useEffect)(() => {
          let e3 = (0, g.gHp)(f);
          p.setOfflineMode(e3);
        }, [f, p]), (0, r.jsx)(g.h5g.Provider, {
          value: S.artistsController,
          children: (0, r.jsx)(g.mDy.Provider, { value: S.playlistsController, children: m2 })
        });
      });
    },
    75669: (e, t, a) => {
      "use strict";
      a.d(t, { KidsPage: () => E });
      var r = a(54486), i = a(50420), s = a(28303), n = a(61910), l = a(43426), o = a(47713), d = a(31500), u = a(6024), c = a(56231), h = a(97800), g = a(4542), y = a(82644), m = a(33276), p = a(74125), v = a(80585), P = a(27005), S = a.n(P);
      let E = (0, s.PA)(() => {
        let { kids: e2, user: t2 } = (0, p.Pjs)(), { formatMessage: a2 } = (0, l.A)(), { contentScrollRef: s2, setContentScrollRef: P2 } = (0, p.gKY)();
        (0, n.useEffect)(() => () => e2.landing.reset(), [e2.landing]), (0, p.Jzs)(e2.landing.isResolved);
        let E2 = (0, g._9)(e2.landing);
        return e2.landing.isNeededToLoad && (0, n.use)(
          e2.landing.getSkeleton({ id: u.p.KIDS, showWizard: t2.settings.showWizard }, { preloadBlocksCount: 2 })
        ), (0, r.jsx)(p.nVz, {
          pageId: p._Q$.KIDS,
          children: (0, r.jsxs)(m.hO, {
            scrollElement: s2,
            outerTitle: a2({ id: "kids.for-kids" }),
            children: [
              (0, r.jsx)(v.Y9, {
                variant: v.Vw.TEXT,
                showControls: false,
                children: (0, r.jsx)("div", {
                  className: S().header,
                  children: (0, r.jsx)(h.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    children: (0, r.jsx)(o.A, { id: "kids.for-kids" })
                  })
                })
              }),
              (0, r.jsxs)(c.N, {
                className: S().root,
                containerClassName: S().content,
                ref: P2,
                ...(0, d.Am)(d.Xk.kids.KIDS_PAGE),
                children: [
                  (0, r.jsx)("div", {
                    className: (0, i.$)(S().landing, { [S().landing_onlyWizard]: E2 }),
                    children: (0, r.jsx)(g.EA, {
                      landing: e2.landing,
                      errorComponent: (0, r.jsx)(y.w, { className: S().error, withBackwardControl: false })
                    })
                  }),
                  (0, r.jsx)(v.A, { children: (0, r.jsx)(v.wi, { className: S().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    76310: (e) => {
      e.exports = {
        root: "MyMusicDownloadedTracksPage_root__hZZwz",
        important: "MyMusicDownloadedTracksPage_important__QP_t0",
        pageContainer: "MyMusicDownloadedTracksPage_pageContainer__qu3hF",
        footer: "MyMusicDownloadedTracksPage_footer__KI5OP",
        content: "MyMusicDownloadedTracksPage_content__Iz1WY",
        trackShimmer: "MyMusicDownloadedTracksPage_trackShimmer__MZgW3"
      };
    },
    77009: (e, t, a) => {
      "use strict";
      a.d(t, { u: () => r });
      var r = (function(e2) {
        return e2.FILE_TOO_LARGE = "FILE_TOO_LARGE", e2.TOO_MANY_FILES = "TOO_MANY_FILES", e2.UNKNOWN_ERROR = "UNKNOWN_ERROR", e2.SUCCESS = "SUCCESS", e2;
      })({});
    },
    77026: (e, t, a) => {
      "use strict";
      a.d(t, { PostNotFoundPage: () => n });
      var r = a(54486), i = a(28303), s = a(42421);
      let n = (0, i.PA)(() => (0, r.jsx)(s.M, {}));
    },
    77343: (e) => {
      e.exports = {
        root: "ConcertsPage_root__olabl",
        container: "ConcertsPage_container__qS7xA",
        footer: "ConcertsPage_footer__GYRwF"
      };
    },
    78208: (e, t, a) => {
      "use strict";
      a.d(t, { ChartPodcastsNotFoundPage: () => o });
      var r = a(54486), i = a(28303), s = a(61910), n = a(42421), l = a(74125);
      let o = (0, i.PA)(() => {
        let {
          chart: { podcastsSubPage: e2 }
        } = (0, l.Pjs)();
        return (0, s.useEffect)(() => {
          e2.reset();
        }, []), (0, r.jsx)(n.M, {});
      });
    },
    79087: (e) => {
      e.exports = { icon: "ConcertNotFoundPage_icon__9yJIB" };
    },
    79882: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { LayoutProvider: () => v, setClientSideLayout: () => p });
      var r = a(54486), i = a(1365), s = a(28303), n = a(61910), l = a(43426), o = a(67648);
      let d = {
        Chrome: 105,
        ChromeMobile: 105,
        Edge: 105,
        Firefox: 104,
        MobileFirefox: 104,
        Opera: 90,
        OperaMobile: 80,
        Safari: 16,
        MobileSafari: 16,
        UCBrowser: 15,
        MSIE: 12,
        YandexBrowser: 23
      };
      var u = a(50420), c = a(80585), h = a(90058), g = a.n(h);
      let y = (e2) => {
        let { message: t2, closeToast: a2 } = e2;
        return (0, r.jsx)(c.$W, { className: (0, u.$)(g().root, g().important), message: t2, closeToast: a2 });
      };
      var m = a(74125);
      let p = (e2) => {
        {
          document.body.classList.remove("desktop"), e2.setLayout((0, m.Svc)(window.innerWidth)), e2.setIsLandscape(window.matchMedia("(orientation: landscape)").matches);
          let t2 = window.screen.availHeight || window.innerHeight;
          e2.setIsMobileLandscapeHeight(t2 < 450);
        }
      }, v = (0, s.PA)((e2) => {
        let { children: t2 } = e2, { formatMessage: a2 } = (0, l.A)(), { notify: s2 } = (0, m.lkh)(), { settings: u2 } = (0, m.Pjs)(), [c2, h2] = (0, o.d)(), [g2, v2] = (0, o.d)(), [P, S] = (0, o.d)(), [E, f] = (0, o.d)(), [b, I] = (0, o.d)(), [_, k] = (0, o.d)(), [C, T] = (0, o.d)(), [D, A] = (0, o.d)(), [x, L] = (0, o.d)();
        u2.layout;
        let R = (0, n.useMemo)(
          () => (0, i.A)(() => {
            p(u2);
          }, 100),
          [u2]
        );
        (0, n.useEffect)(() => {
          (function(e3) {
            if (!(null == e3 ? void 0 : e3.isBrowser) || !e3.name || !e3.version) return false;
            let t3 = d[e3.name];
            if (!t3) return false;
            let a3 = parseFloat(e3.version);
            return !Number.isNaN(a3) && a3 < t3;
          })(u2.browserInfo) && s2((0, r.jsx)(y, { message: a2({ id: "warning-messages.update-your-browser" }) }), {
            containerId: m.uQT.IMPORTANT,
            single: true
          });
        }, [a2, s2, u2.browserInfo]), (0, n.useLayoutEffect)(() => {
          p(u2);
        }, [u2]), (0, n.useEffect)(
          () => (window.addEventListener("resize", R), () => {
            window.removeEventListener("resize", R);
          }),
          [R]
        );
        let N = (0, n.useMemo)(
          () => ({
            defaultLayoutRef: c2,
            contentRef: g2,
            contentRootRef: P,
            contentScrollRef: E,
            sideBannerRef: _,
            playlistStickyFiltersRef: C,
            playlistStaticFiltersRef: D,
            compositePlayerBarRef: b,
            paywallRef: x,
            setContentRef: v2,
            setDefaultLayoutRef: h2,
            setContentRootRef: S,
            setContentScrollRef: f,
            setSideBannerRef: k,
            setPlaylistStickyFiltersRef: T,
            setPlaylistStaticFiltersRef: A,
            setCompositePlayerBarRef: I,
            setPaywallRef: L
          }),
          [c2, g2, P, E, _, C, D, b, x, h2, v2, S, f, k, T, A, I, L]
        );
        return (0, r.jsx)(m.MQO.Provider, { value: N, children: t2 });
      });
    },
    80616: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { DesktopInitializer: () => l });
      var r = a(54486), i = a(61910), s = a(68317), n = a(74125);
      let l = () => {
        let { language: e2 } = (0, n.h6b)();
        {
          let { theme: t2 } = (0, n.DPo)(), a2 = (0, n.NFA)().get(n.vgk);
          (0, s.sq)(), (0, s.P4)(), (0, s.bk)(), (0, s.LD)(), (0, s.t4)(), (0, s.Fn)(), (0, s.eP)(), (0, s.sb)(), (0, i.useEffect)(() => {
            (0, s.M4)(e2), (0, s.CA)();
          }, [e2]), (0, i.useEffect)(() => {
            let e3 = (0, n.HFS)();
            e3 && a2.count(e3, "appVersion");
          }, [a2]), (0, i.useEffect)(() => {
            t2 && ((0, s._E)(t2), a2.count(t2, "appTheme"));
          }, [t2]);
        }
        return (0, r.jsx)(s.qw, {});
      };
    },
    80986: (e, t, a) => {
      "use strict";
      a.d(t, { DesktopPaywallInitializer: () => l });
      var r = a(28303), i = a(61910), s = a(66498), n = a(74125);
      let l = (0, r.PA)(() => {
        let { desktopPaywall: e2, user: t2 } = (0, n.Pjs)(), { isFreemium: a2 } = (0, n.XCI)(), { shouldShowFamilyInvite: r2 } = (0, s.hj)();
        (0, i.useEffect)(() => {
          if ((!t2.isAuthorized || a2) && !r2)
            return e2.shouldShowOnEnter && e2.showPaywall(), e2.startCrackdownTimeout(), () => {
              e2.clearCrackdownTimeout();
            };
        }, [e2, a2, r2, t2.isAuthorized]);
      });
    },
    81713: (e, t, a) => {
      "use strict";
      a.d(t, { BuySubscriptionInitializer: () => n });
      var r = a(28303), i = a(61910), s = a(74125);
      let n = (0, r.PA)(() => {
        let { user: e2 } = (0, s.Pjs)(), { hasFreeUserAccess: t2 } = (0, s.XCI)(), a2 = (0, s.jwr)(), r2 = (0, s.pFh)("music", t2), {
          payment: { environment: n2 }
        } = (0, s.NFA)().get(s.twC), l = (0, i.useRef)(/* @__PURE__ */ new Date()), o = (0, i.useCallback)(async () => {
          let t3 = "production" === n2 ? e2.account.data.uid : void 0;
          try {
            await r2.getData({ uid: t3, page: a2.page, places: a2.places, widgetServiceName: a2.widgetServiceName });
          } catch (e3) {
          }
          l.current = /* @__PURE__ */ new Date();
        }, [r2, n2, e2, a2]), d = (0, i.useCallback)(async () => {
          let e3 = l.current.getTime() < Date.now() - 6e5;
          "visible" === document.visibilityState && e3 && a2.shouldFetchOffers && await o();
        }, [o, a2.shouldFetchOffers]);
        (0, i.useEffect)(() => {
          if (!t2) return;
          let e3 = new AbortController();
          return window.addEventListener("focus", d, { signal: e3.signal }), () => {
            e3.abort();
          };
        }, [t2, d]);
      });
    },
    82667: (e, t, a) => {
      "use strict";
      a.d(t, { Genre: () => d });
      var r = a(54486), i = a(28303), s = a(97800), n = a(80585), l = a(89281), o = a.n(l);
      let d = (0, i.PA)((e2) => {
        let { tag: t2, title: a2, subGenres: i2 } = e2;
        return (0, r.jsxs)("div", {
          className: o().root,
          children: [
            (0, r.jsx)(n.N_, {
              className: o().link,
              href: "/genre/".concat(t2),
              children: (0, r.jsx)(s.Heading, {
                variant: "h2",
                size: "m",
                lineClamp: 1,
                className: o().linkTitle,
                children: a2
              })
            }),
            i2.length > 0 && (0, r.jsx)("div", {
              className: o().list,
              children: i2.map(
                (e3) => (0, r.jsx)(
                  "div",
                  {
                    className: o().item,
                    children: (0, r.jsx)(n.N_, {
                      className: o().link,
                      href: "/genre/".concat(e3.tag),
                      children: (0, r.jsx)(s.Caption, {
                        variant: "span",
                        size: "l",
                        lineClamp: 1,
                        className: o().linkTitle,
                        children: e3.title
                      })
                    })
                  },
                  e3.tag
                )
              )
            })
          ]
        });
      });
    },
    85218: (e) => {
      e.exports = {
        root: "ChartPodcastsPage_root__J5lnx",
        scrollContainer: "ChartPodcastsPage_scrollContainer__WQTf7",
        important: "ChartPodcastsPage_important__fW45m",
        footer: "ChartPodcastsPage_footer__7ytrT",
        item: "ChartPodcastsPage_item__vGRt8",
        content: "ChartPodcastsPage_content__NcV4M"
      };
    },
    85827: (e, t, a) => {
      "use strict";
      a.d(t, { UgcUploadInitializer: () => v });
      var r = a(28303), i = a(61910), s = a(74125), n = a(54486), l = a(43426), o = a(80585), d = a(47713), u = a(31500), c = a(97800), h = a(1320), g = a.n(h), y = (function(e2) {
        return e2.ERROR = "error", e2.SUCCESS = "success", e2;
      })({});
      let m = (e2) => {
        let { playlistName: t2, url: a2, variant: r2 } = e2, s2 = (0, i.useMemo)(
          () => (0, n.jsx)(o.N_, {
            href: a2,
            className: g().link,
            children: (0, n.jsx)(c.Caption, {
              className: g().title,
              variant: "span",
              type: "controls",
              size: "m",
              lineClamp: 1,
              children: t2
            })
          }),
          [t2, a2]
        ), l2 = (0, i.useMemo)(
          () => "error" === r2 ? (0, n.jsx)(c.Caption, {
            variant: "div",
            type: "controls",
            size: "m",
            ...(0, u.Am)(u.S7.BASE_NOTIFICATION_UGC_TRACK_ERROR_TEXT),
            children: (0, n.jsx)(d.A, { id: "ugc.notification-unknown-error", values: { playlistName: s2 } })
          }) : (0, n.jsxs)(c.Caption, {
            variant: "div",
            type: "controls",
            size: "m",
            children: [(0, n.jsx)(d.A, { id: "ugc.notification-success", values: { playlistName: s2 } }), ";"]
          }),
          [s2, r2]
        );
        return (0, n.jsx)(o.$W, { className: g().root, message: l2 });
      };
      var p = a(77009);
      let v = (0, r.PA)(() => {
        let { ugcUploadCenter: e2 } = (0, s.Pjs)(), t2 = (0, i.useRef)(void 0);
        (() => {
          var e3;
          let {
            ugcUploadCenter: { notifications: t3 },
            playlist: a3
          } = (0, s.Pjs)(), { notify: r3 } = (0, s.lkh)(), { formatMessage: d3 } = (0, l.A)();
          (0, i.useEffect)(() => {
            t3.showAllNotifications().forEach((e4) => {
              switch (e4.type) {
                case p.u.FILE_TOO_LARGE:
                  r3((0, n.jsx)(o.hT, { error: d3({ id: "ugc.notification-too-large-file-error" }) }), {
                    containerId: s.uQT.ERROR
                  });
                  break;
                case p.u.TOO_MANY_FILES:
                  r3((0, n.jsx)(o.hT, { error: d3({ id: "ugc.notification-too-many-files-error" }) }), {
                    containerId: s.uQT.ERROR
                  });
                  break;
                case p.u.UNKNOWN_ERROR:
                  r3((0, n.jsx)(m, { url: e4.playlist.url, playlistName: e4.playlist.title, variant: y.ERROR }), {
                    containerId: s.uQT.ERROR
                  });
                  break;
                case p.u.SUCCESS:
                  var t4;
                  (null == (t4 = a3.meta) ? void 0 : t4.kind) !== e4.playlist.kind && r3((0, n.jsx)(m, { url: e4.playlist.url, playlistName: e4.playlist.title, variant: y.SUCCESS }), {
                    containerId: s.uQT.INFO
                  });
              }
            });
          }, [d3, t3, t3.pairs.length, r3, null == (e3 = a3.meta) ? void 0 : e3.kind]);
        })();
        let a2 = (0, i.useCallback)(() => {
          e2.checkProcessingTracks();
        }, [e2]), r2 = (0, i.useCallback)(() => {
          t2.current || (t2.current = setInterval(a2, 2e3));
        }, [a2]), d2 = (0, i.useCallback)(() => {
          clearInterval(t2.current), t2.current = void 0;
        }, []);
        (0, i.useEffect)(() => {
          e2.shouldCheckProcessingTracks ? r2() : d2();
        }, [d2, r2, e2.shouldCheckProcessingTracks]), (0, i.useEffect)(() => () => d2(), [d2]);
      });
    },
    88187: (e) => {
      e.exports = {
        root: "PlaylistPersonalDummyPage_root__tGxHG",
        cover: "PlaylistPersonalDummyPage_cover__XcCD1",
        title: "PlaylistPersonalDummyPage_title__ZSf9O",
        important: "PlaylistPersonalDummyPage_important__uEHGe",
        text: "PlaylistPersonalDummyPage_text__ci30d"
      };
    },
    89281: (e) => {
      e.exports = {
        root: "Genre_root__80dlk",
        link: "Genre_link__Wewaq",
        linkTitle: "Genre_linkTitle__ORAsw",
        list: "Genre_list__C2Pxf"
      };
    },
    89381: (e, t, a) => {
      "use strict";
      a.d(t, { CommunicationsInitializer: () => n });
      var r = a(28303), i = a(61910), s = a(74125);
      let n = (0, r.PA)(() => {
        let { user: e2, redAlert: t2, communication: a2 } = (0, s.Pjs)();
        (0, i.useEffect)(() => {
          e2.isAuthorized && Promise.allSettled([a2.getData(), t2.getData()]);
        }, [t2, a2, e2.isAuthorized]);
      });
    },
    90058: (e) => {
      e.exports = {
        root: "BrowserUpdateNotification_root__IN495",
        important: "BrowserUpdateNotification_important__6k4Gb"
      };
    },
    90809: (e) => {
      e.exports = {
        toastClassName: "NotificationsInitializer_toastClassName__ZVvrd",
        notificationContainer: "NotificationsInitializer_notificationContainer__oe1ot"
      };
    },
    91582: (e) => {
      e.exports = { root: "KidsCategoryPageShimmer_root__0V_bC" };
    },
    93685: (e, t, a) => {
      "use strict";
      a.d(t, { PostPage: () => N });
      var r = a(54486), i = a(50420), s = a(28303), n = a(97396), l = a(61910), o = a(23615), d = a(56231), u = a(22674), c = a(97800), h = a(82644), g = a(33276), y = a(74125), m = a(80585), p = a(51892), v = a.n(p);
      let P = () => (0, r.jsxs)("div", {
        className: v().root,
        children: [
          (0, r.jsx)(u.Shimmer, { radius: "l", className: v().top }),
          (0, r.jsx)(u.Shimmer, { radius: "l", className: v().bottom })
        ]
      });
      var S = a(23404), E = a.n(S), f = a(94376), b = a(30827), I = a.n(b);
      let _ = (0, s.PA)((e2) => {
        let { albums: t2 = [] } = e2;
        return (0, r.jsx)("div", {
          className: I().root,
          children: (0, r.jsx)("div", {
            className: I().content,
            "aria-labelledby": "post-page-header",
            tabIndex: 0,
            children: t2.map((e3) => (0, r.jsx)(f.aX, { className: I().item, album: e3, contentLinesCount: 3 }, e3.id))
          })
        });
      });
      var k = a(55616), C = a(12393), T = a.n(C);
      let D = (0, s.PA)((e2) => {
        let { artists: t2 = [] } = e2;
        return (0, r.jsx)("div", {
          className: T().root,
          children: (0, r.jsx)("div", {
            className: T().content,
            "aria-labelledby": "post-page-header",
            tabIndex: 0,
            children: t2.map((e3) => (0, r.jsx)(k.ao, { className: T().item, artist: e3, contentLinesCount: 3 }, e3.id))
          })
        });
      });
      var A = a(83909), x = a(50757), L = a.n(x);
      let R = (0, s.PA)((e2) => {
        let { playlists: t2 = [] } = e2;
        return (0, r.jsx)("div", {
          className: L().root,
          children: (0, r.jsx)("div", {
            className: L().content,
            "aria-labelledby": "post-page-header",
            tabIndex: 0,
            children: t2.map(
              (e3) => (0, r.jsx)(A.B6, { className: L().item, playlist: e3, contentLinesCount: 3 }, e3.id)
            )
          })
        });
      }), N = (0, s.PA)((e2) => {
        let { promoId: t2 } = e2, { post: a2 } = (0, y.Pjs)(), s2 = (0, y.W6M)(), { contentScrollRef: p2, setContentScrollRef: v2 } = (0, y.gKY)();
        (0, l.useEffect)(
          () => () => {
            a2.reset();
          },
          [a2]
        ), a2.isNotFound && (0, n.notFound)(), (0, y.Jzs)(a2.isResolved);
        let S2 = (0, l.useMemo)(() => {
          if (a2.isLoading) return (0, r.jsx)(P, {});
          switch (a2.promotionType) {
            case o.Q.ARTISTS:
              return (0, r.jsx)(D, { artists: a2.artists });
            case o.Q.ALBUMS:
              return (0, r.jsx)(_, { albums: a2.albums });
            case o.Q.PLAYLISTS:
              return (0, r.jsx)(R, { playlists: a2.playlists });
            default:
              (0, n.notFound)();
          }
        }, [a2.albums, a2.artists, a2.isLoading, a2.playlists, a2.promotionType]);
        return (t2 && a2.isNeededToLoad && (0, l.use)(a2.getData({ promoId: t2 })), a2.isSomethingWrong) ? (0, r.jsx)(h.w, {}) : (0, r.jsx)(y.nVz, {
          pageId: y._Q$.POST,
          children: (0, r.jsx)(g.hO, {
            scrollElement: p2,
            outerTitle: a2.title || void 0,
            children: (0, r.jsxs)("div", {
              className: E().root,
              children: [
                (0, r.jsx)(m.Y9, {
                  variant: m.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: s2.canBack,
                  children: a2.title ? (0, r.jsx)(c.Heading, {
                    id: "post-header",
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: a2.title
                  }) : (0, r.jsx)(u.Shimmer, { className: E().shimmerTitle, radius: "l" })
                }),
                (0, r.jsx)(d.N, {
                  containerClassName: (0, i.$)(E().scrollContainer, E().important),
                  className: E().scrollableContainer,
                  ref: v2,
                  children: (0, r.jsx)("div", { className: E().container, children: S2 })
                })
              ]
            })
          })
        });
      });
    },
    94716: (e, t, a) => {
      "use strict";
      a.d(t, { TagNotFoundPage: () => n });
      var r = a(54486), i = a(28303), s = a(42421);
      let n = (0, i.PA)(() => (0, r.jsx)(s.M, {}));
    },
    95364: (e, t, a) => {
      "use strict";
      a.d(t, { GenresNotFoundPage: () => s });
      var r = a(54486), i = a(42421);
      let s = () => (0, r.jsx)(i.M, {});
    },
    95657: (e, t, a) => {
      "use strict";
      a.d(t, { PlaylistPersonalDummyPage: () => c });
      var r = a(54486), i = a(50420), s = a(28303), n = a(97800), l = a(74125), o = a(80585), d = a(88187), u = a.n(d);
      let c = (0, s.PA)(() => {
        let {
          playlistPersonal: { dummyCoverUrl: e2, dummyDescription: t2, title: a2 }
        } = (0, l.Pjs)();
        return (0, r.jsxs)("div", {
          className: u().root,
          children: [
            (0, r.jsx)(o.Y9, {}),
            (0, r.jsx)(o.BW, {
              src: e2,
              size: 200,
              fit: "cover",
              withAvatarReplace: true,
              "aria-hidden": true,
              className: u().cover
            }),
            a2 && (0, r.jsx)(n.Heading, {
              className: (0, i.$)(u().title, u().important),
              variant: "h1",
              size: "xs",
              children: a2
            }),
            t2 && (0, r.jsx)(n.Caption, {
              className: (0, i.$)(u().text, u().important),
              variant: "span",
              type: "text",
              size: "l",
              weight: "normal",
              children: t2
            })
          ]
        });
      });
    },
    96269: (e, t, a) => {
      "use strict";
      a.d(t, { PromoLandingCrackdownInitializer: () => l });
      var r = a(28303), i = a(74125), s = a(15163), n = a(33134);
      let l = (0, r.PA)(() => {
        var e2;
        let {
          modals: { crackdownModal: t2, promoLandingBuySubscriptionModal: a2 },
          settings: { isMobile: r2 },
          experiments: l2,
          promolanding: { state: o }
        } = (0, i.Pjs)(), { isFreemium: d } = (0, i.XCI)(), u = d && l2.checkExperiment(i.zal.WebNextPromoLanding, "on"), c = null == (e2 = l2.getExperiment(i.zal.WebNextPromoLandingCrackdownInterval)) ? void 0 : e2.value.interval;
        (0, n.W)({
          isEnabled: u,
          intervalMs: (0, s.P)(c),
          modal: r2 ? a2 : t2,
          playbackId: i.V_r.PROMO_LANDING,
          sonataState: o
        });
      });
    },
    97249: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { SettingsInitializer: () => n });
      var r = a(28303), i = a(61910), s = a(74125);
      let n = (0, r.PA)((e2) => {
        let { browserInfo: t2 } = e2, a2 = (0, s.NFA)(), { settings: r2 } = (0, s.Pjs)(), n2 = (0, s.uoh)(), l = a2.get(s.vgk);
        r2.setBrowserInfo(t2), n2 && r2.setPlatform(n2), (0, i.useLayoutEffect)(() => {
          r2.initializeLiteVersionMode(), r2.initializeCustomPlayerThumb();
        }, []), (0, i.useEffect)(() => {
          r2.liteVersionMode && l.count(r2.liteVersionMode, "liteVersionMode");
        }, [l, r2.liteVersionMode]);
      });
    },
    97691: (e, t, a) => {
      "use strict";
      a.d(t, { CrackdownInitializer: () => l });
      var r = a(28303), i = a(74125), s = a(15163), n = a(33134);
      let l = (0, r.PA)(() => {
        var e2;
        let {
          user: t2,
          modals: { crackdownModal: a2 },
          settings: { isMobile: r2 },
          experiments: l2,
          sonataState: o,
          desktopPaywall: d
        } = (0, i.Pjs)(), { isFreemium: u } = (0, i.XCI)(), c = t2.isAuthorized && u && !r2, h = null == (e2 = l2.getExperiment(i.zal.WebNextCrackdownInterval)) ? void 0 : e2.value.interval;
        (0, n.W)({ isEnabled: c, intervalMs: (0, s.P)(h), modal: a2, sonataState: o, isPaywallOpen: d.isPaywallOpen });
      });
    },
    99893: (e, t, a) => {
      "use strict";
      a.d(t, { FavoriteTracksPage: () => d });
      var r = a(54486), i = a(28303), s = a(61910), n = a(74125), l = a(42421);
      let o = (0, i.PA)(() => (0, r.jsx)(l.M, {})), d = (0, i.PA)(() => {
        let { favoriteTracks: e2 } = (0, n.Pjs)(), t2 = (0, n.ZpR)(e2.playlistUrl);
        if ((0, s.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), (0, s.useEffect)(() => {
          e2.playlistUrl && t2();
        }, [e2.playlistUrl, t2]), e2.isNeededToLoad && (0, s.use)(e2.getPlaylistUrl()), e2.isRejected)
          return (0, r.jsx)(o, {});
      });
    }
  }
]);
