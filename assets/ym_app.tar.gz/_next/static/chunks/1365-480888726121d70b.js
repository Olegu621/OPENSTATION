(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1365],
  {
    855: (t, e, i) => {
      "use strict";
      i.d(e, { W: () => r });
      var a = i(43426);
      let r = (t2) => {
        let { track: e2, withLightning: i2 } = t2, { formatMessage: r2 } = (0, a.A)();
        return e2.isAvailable ? [e2.artistsNames, e2.title, e2.version, i2 && r2({ id: "entity-names.popular-among-users" })].filter(Boolean).join(" ") : "".concat(r2({ id: "extra-explicit.play-unavailable" }), " ").concat(e2.artistsNames, " ").concat(e2.title);
      };
    },
    4165: (t) => {
      t.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "PlayButtonWithPosition_root__H5FYg",
        playButton: "PlayButtonWithPosition_playButton__7cfDQ",
        playButtonIcon: "PlayButtonWithPosition_playButtonIcon___cLAL",
        playingAnimation: "PlayButtonWithPosition_playingAnimation__Hy5rC",
        position: "PlayButtonWithPosition_position__wk3OT",
        root_current: "PlayButtonWithPosition_root_current__FCDLJ",
        root_playing: "PlayButtonWithPosition_root_playing__RpnYU",
        root_disabled: "PlayButtonWithPosition_root_disabled__PMV24",
        root_disliked: "PlayButtonWithPosition_root_disliked__NIZzA",
        spinner: "PlayButtonWithPosition_spinner__jNaNf"
      };
    },
    4242: (t, e, i) => {
      "use strict";
      i.d(e, { TrackNonMusic: () => y });
      var a = i(54486), r = i(28303), l = i(50420), s = i(61910), n = i(31500), o = i(74125), c = i(80585), d = i(78571), u = i(76130), m = i(76858), k = i(16479), _ = i(23728), p = i(22407), v = i.n(p), C = i(58672);
      let x = (0, r.PA)((t2) => {
        let {
          track: e2,
          playContextParams: i2,
          className: r2,
          withDNDBlock: p2,
          isDragging: x2,
          draggingClassName: T2,
          withTimeLeftText: g2,
          ignoreDislikedStyles: y2,
          viewType: A = C.D.PLAYLIST,
          position: h,
          beforeTitle: b,
          handleRemove: N,
          removeButtonAriaLabel: j
        } = t2, I = (0, o.Dx4)({ playContextParams: i2, entityId: e2.entityId }), {
          settings: { isMobile: P }
        } = (0, o.Pjs)(), L = (0, s.useCallback)(
          (t3) => A === C.D.ALBUM ? (0, a.jsx)(k.G, { track: e2, position: h, className: v().playButtonCell, ...t3 }) : (0, a.jsx)(c.q1, {
            isAvailable: e2.isAvailable,
            isDisliked: e2.isDisliked,
            coverUri: e2.coverUri,
            title: e2.title,
            className: v().playButtonCell,
            ignoreDislikedStyles: y2,
            radius: "xs",
            ...t3
          }),
          [y2, h, A, e2]
        );
        return (0, a.jsx)(_.Track, {
          className: (0, l.$)(r2, { [v().trackWithDots]: p2, [v().important]: p2 }),
          track: e2,
          meta: (0, a.jsx)(m.AudiobookMeta, {
            beforeTitle: b,
            withAuthor: A === C.D.PLAYLIST,
            explicitSize: "xxxs",
            track: e2,
            playContextParams: i2,
            withListeningProgress: true,
            withTimeLeftText: g2,
            ignoreDislikedStyles: y2,
            withSavingQueryParams: true,
            withArtistLink: !P
          }),
          playButtonCellRender: L,
          controls: (0, a.jsx)(u.ControlsBar, {
            track: e2,
            className: v().controlsBarCell,
            ignoreDislikedStyles: y2,
            utmLink: i2.contextData.utmLink,
            handleRemove: N,
            removeButtonAriaLabel: j
          }),
          beforeBlock: p2 ? (0, a.jsx)(d.O, { className: (0, l.$)(v().dots, T2), isDragging: x2 }) : void 0,
          ...I,
          ...(0, n.Am)(n.Kq.track.TRACK_AUDIOBOOK)
        });
      });
      var T = i(54586);
      let g = (0, r.PA)((t2) => {
        let {
          track: e2,
          playContextParams: i2,
          withPodcastName: r2 = false,
          className: m2,
          withDNDBlock: k2,
          isDragging: p2,
          draggingClassName: C2,
          handleRemove: x2,
          withTimeLeftText: g2,
          ignoreDislikedStyles: y2,
          beforeTitle: A,
          removeButtonAriaLabel: h
        } = t2, b = (0, o.Dx4)({ playContextParams: i2, entityId: e2.entityId }), {
          settings: { isMobile: N }
        } = (0, o.Pjs)(), j = (0, s.useCallback)(
          (t3) => (0, a.jsx)(c.q1, {
            isAvailable: e2.isAvailable,
            isDisliked: e2.isDisliked,
            coverUri: e2.coverUri,
            title: e2.title,
            className: v().playButtonCell,
            ignoreDislikedStyles: y2,
            radius: "xs",
            ...t3
          }),
          [y2, e2.coverUri, e2.isAvailable, e2.isDisliked, e2.title]
        );
        return (0, a.jsx)(_.Track, {
          className: (0, l.$)(m2, { [v().trackWithDots]: k2, [v().important]: k2 }),
          track: e2,
          meta: (0, a.jsx)(T.PodcastMeta, {
            beforeTitle: A,
            track: e2,
            playContextParams: i2,
            withPodcastName: r2,
            withListeningProgress: true,
            withTimeLeftText: g2,
            ignoreDislikedStyles: y2,
            explicitSize: "xxxs",
            withAlbumTitleLink: !N
          }),
          playButtonCellRender: j,
          controls: (0, a.jsx)(u.ControlsBar, {
            handleRemove: x2,
            track: e2,
            className: v().controlsBarCell,
            ignoreDislikedStyles: y2,
            utmLink: i2.contextData.utmLink,
            removeButtonAriaLabel: h
          }),
          beforeBlock: k2 ? (0, a.jsx)(d.O, { className: (0, l.$)(v().dots, C2), isDragging: p2 }) : void 0,
          ...b,
          ...(0, n.Am)(n.Kq.track.TRACK_PODCAST)
        });
      }), y = (0, r.PA)((t2) => {
        let e2 = t2.track;
        return e2.isTrackAudiobook || e2.isTrackFairyTale ? (0, a.jsx)(x, { ...t2 }) : (0, a.jsx)(g, { ...t2 });
      });
    },
    8871: (t, e, i) => {
      "use strict";
      i.d(e, { useRemoveTrackFromPlaylistByIndex: () => c });
      var a = i(54486), r = i(61910), l = i(43426), s = i(13611), n = i(74125), o = i(80585);
      let c = () => {
        let { playlist: t2, trackIndex: e2 } = (0, r.useContext)(s.xG) || {}, { notify: i2 } = (0, n.lkh)(), { playlist: c2 } = (0, n.Pjs)(), { formatMessage: d } = (0, l.A)(), u = (0, r.useCallback)(async () => {
          let r2 = false;
          if (t2 && "number" == typeof e2 && await t2.changePlaylist(
            (0, s.Mp)({ operation: s.yC.DELETE, startPosition: e2, endPosition: e2 + 1 })
          ) === s.Y9.OK && (r2 = true), r2) {
            if (t2 && "number" == typeof e2) {
              var l2;
              t2.uuid === (null == (l2 = c2.meta) ? void 0 : l2.uuid) && (c2.removeTracksFromItems(e2, 1), c2.search.setFocus());
            }
          } else
            i2((0, a.jsx)(o.hT, { error: d({ id: "playlist-errors.failed-to-remove-track" }) }), {
              containerId: n.uQT.ERROR
            });
        }, [t2, e2, c2, i2, d]);
        return { canRemoveTrackFromPlaylist: !!(null == t2 ? void 0 : t2.canUserChange), removeTrackFromPlaylist: u };
      };
    },
    9821: (t, e, i) => {
      "use strict";
      i.d(e, { TrackCard: () => P });
      var a = i(54486), r = i(50420), l = i(28303), s = i(61910), n = i(43426), o = i(63585), c = i(8817), d = i(27510), u = i(71712), m = i(6971), k = i(97800), _ = i(46423), p = i(63695), v = i(54460), C = i(74125), x = i(80585), T = i(47937), g = i(89324), y = i.n(g), A = i(47713), h = i(43350), b = i(31500), N = i(5956), j = i(62065);
      let I = (0, l.PA)((t2) => {
        let { track: e2, handleLikeButtonClick: i2, handlePlayButtonClick: l2, isPlaying: n2 } = t2, { trailer: o2, user: m2 } = (0, C.Pjs)(), [k2, _2] = (0, s.useState)(false), [p2, v2] = (0, s.useState)(false), T2 = (0, C.PT7)(), g2 = (0, C.Ftl)(), I2 = (0, c.c)(() => {
          _2(!k2), v2(!k2);
        }), P2 = (0, c.c)((t3) => {
          t3.preventDefault(), t3.stopPropagation();
        }), L = (0, c.c)((t3) => {
          if (t3.stopPropagation(), T2()) return void t3.preventDefault();
          o2.openTrackTrailer(e2.id), g2(h.ky.Track, e2.id);
        }), f = (0, d.L)(() => {
          var t3;
          if (null == e2 || null == (t3 = e2.trailer) ? void 0 : t3.isAvailable)
            return (0, a.jsx)(
              x.nE,
              {
                children: (0, a.jsx)(x.kJ, {
                  className: (0, r.$)(y().trailerButton, y().control),
                  radius: "round",
                  size: "s",
                  iconSize: "xxs",
                  onClick: L
                })
              },
              e2.getKey("TrackCardTrailerTooltip")
            );
        });
        return (0, a.jsx)(u.hg, {
          isVisible: k2 || p2,
          className: y().controls,
          labelText: (0, a.jsx)(A.A, { id: "entity-names.track" }),
          playControl: (0, a.jsx)(
            x.DM,
            {
              className: (0, r.$)(y().playButton, y().control),
              buttonVariant: "default",
              withHover: false,
              iconSize: "xl",
              variant: "filled",
              isPlaying: n2,
              onClick: l2
            },
            e2.getKey("PlayButton")
          ),
          likeControl: (0, a.jsx)(
            x.cy,
            {
              className: (0, r.$)(y().likeButton, y().control),
              isLiked: e2.isLiked,
              onClick: i2,
              variant: "default",
              size: "s",
              iconSize: "xxs",
              disabled: !m2.isAuthorized
            },
            e2.getKey("LikeButton")
          ),
          menuControl: (0, a.jsx)(
            j.TrackContextMenu,
            {
              placement: "bottom",
              track: e2,
              onOpenChange: I2,
              open: k2,
              onClick: P2,
              className: (0, r.$)(y().menuButton, y().control),
              icon: (0, a.jsx)(N.Icon, { size: "xxs", variant: "more" }),
              size: "s",
              ...(0, b.Am)(b.Kq.track.TRACK_CONTEXT_MENU_BUTTON)
            },
            e2.getKey("TrackContextMenu")
          ),
          trailerControl: f
        });
      }), P = (0, l.PA)((t2) => {
        var e2, i2;
        let { className: l2, children: g2, track: A2, contentLinesCount: h2, overrideContextType: b2 } = t2, { from: N2 } = (0, C.fyy)(), { track: j2 } = (0, C.Pjs)(), { formatMessage: P2 } = (0, n.A)(), [L, f] = (0, s.useState)(false), [D, S] = (0, s.useState)(false), { sendLikeSearchFeedback: R, sendPlaySearchFeedback: M, sendNavigateSearchFeedback: E } = (0, C.zEv)(), O = (0, v.KX)(A2), K = (0, C.ZpR)(null != (i2 = null == (e2 = A2.mainAlbum) ? void 0 : e2.url) ? i2 : ""), w = (0, C.ZpR)(A2.url), B = (0, C.brA)(), U = (0, C.PT7)(), z = (0, d.L)(() => {
          var t3;
          let e3 = P2({ id: "entity-names.track-name" }, { trackName: A2.title }), i3 = A2.isLiked ? P2({ id: "entity-names.has-your-like" }) : "";
          return "".concat(e3, " ").concat(null != (t3 = A2.version) ? t3 : "", " ").concat(i3);
        }), { isPlaying: G, togglePlay: $ } = (0, C.Dx4)({
          playContextParams: {
            contextData: { type: o.K.Various, meta: { id: A2.entityId }, from: N2, overrideContextType: b2 },
            queueParams: { index: 0 },
            loadContextMeta: true
          },
          entityId: A2.entityId
        }), q = (0, c.c)(() => {
          j2.open({ trackId: A2.id, albumId: A2.albumId });
        }), F = (0, c.c)(() => {
          L || G || (f(true), null == M || M()), $();
        }), X = (0, _.cp)({ album: A2.mainAlbum, callback: K }), Y = (0, T.useTrackDisclaimer)({ track: A2, callback: w }), V = (0, T.useTrackDisclaimer)({ track: A2, callback: q }), Q = (0, T.useTrackDisclaimer)({ track: A2, callback: F }), W = (0, c.c)(() => {
          U() || (Q(), B(!G));
        }), H = (0, c.c)(() => {
          A2.hasTrackLink && V();
        }), J = (0, c.c)(() => {
          D || A2.isLiked || (S(true), null == R || R()), O();
        }), Z = (0, c.c)((t3) => {
          var e3;
          if (A2.hasTrackLink) {
            null == E || E(), Y(t3);
            return;
          }
          A2.hasAlbumLink && (null == (e3 = A2.mainAlbum) ? void 0 : e3.url) && X(t3);
        }), tt = (0, d.L)(() => {
          var t3, e3, i3;
          return A2.hasTrackLink ? (0, a.jsx)(x.N_, {
            "aria-label": "".concat(A2.title, " ").concat(null != (e3 = A2.version) ? e3 : ""),
            className: y().titleLink,
            href: A2.url,
            onClick: Z,
            children: A2.title
          }) : A2.hasAlbumLink && (null == (t3 = A2.mainAlbum) ? void 0 : t3.url) ? (0, a.jsx)(x.N_, {
            "aria-label": "".concat(A2.title, " ").concat(null != (i3 = A2.version) ? i3 : ""),
            className: y().titleLink,
            href: A2.mainAlbum.url,
            onClick: Z,
            children: A2.title
          }) : (0, a.jsx)(k.Caption, { className: y().title, variant: "span", children: A2.title });
        }), te = (0, d.L)(() => {
          var t3, e3;
          return A2.hasAlbumLink && (null == (t3 = A2.mainAlbum) ? void 0 : t3.url) ? (0, a.jsx)(x.N_, {
            href: A2.mainAlbum.url,
            onClick: Z,
            children: "".concat(A2.title, " ").concat(null != (e3 = A2.version) ? e3 : "")
          }) : null;
        }), ti = (0, d.L)(() => {
          if (A2.isAvailable)
            return (0, a.jsx)(I, { track: A2, isPlaying: G, handleLikeButtonClick: J, handlePlayButtonClick: W });
        });
        return (0, a.jsx)(u.MN, {
          className: (0, r.$)(y().root, l2),
          "aria-label": z,
          explicitMarkComponent: A2.explicitDisclaimer && (0, a.jsx)(x.Nq, { getDescriptionTexts: A2.getDescriptionTexts, variant: A2.explicitDisclaimer }),
          title: (0, a.jsxs)(k.Caption, {
            className: (0, r.$)(y().titleContainer, { [y().titleContainer_withVersion]: A2.version }),
            variant: "div",
            type: "entity",
            size: "s",
            weight: "medium",
            lineClamp: 2,
            children: [
              tt,
              A2.version && (0, a.jsx)(k.Caption, { className: y().version, variant: "span", children: " ".concat(A2.version) })
            ]
          }),
          srTitle: te,
          contentLinesCount: h2,
          view: (0, a.jsx)(m.Paper, {
            className: y().cover,
            radius: "l",
            withShadow: true,
            children: (0, a.jsxs)("div", {
              className: (0, r.$)(y().coverBlock, { [y().coverBlock_withTrackLink]: A2.hasTrackLink }),
              onClick: H,
              children: [
                (0, a.jsx)(x.BW, {
                  className: y().image,
                  src: A2.coverUri,
                  size: 200,
                  fit: "cover",
                  alt: z,
                  withAvatarReplace: true,
                  isAvailable: A2.isAvailable,
                  "aria-hidden": true
                }),
                ti
              ]
            })
          }),
          description: (0, a.jsx)(
            p.iQ,
            {
              className: y().artists,
              artists: A2.artists,
              lineClamp: 1,
              linkClassName: y().artistLink,
              captionSize: "s",
              withLink: A2.isNonUserGenerated
            },
            A2.getKey("description")
          ),
          children: g2
        });
      });
    },
    11036: (t, e, i) => {
      "use strict";
      i.d(e, { S: () => r });
      var a = i(63585);
      function r(t2) {
        return (null == t2 ? void 0 : t2.data.type) === a.K.Generative;
      }
    },
    12938: (t, e, i) => {
      "use strict";
      i.d(e, { TrackMeta: () => y });
      var a = i(54486), r = i(50420), l = i(28303), s = i(97396), n = i(61910), o = i(43426), c = i(47713), d = i(31500), u = i(93666), m = i(97800), k = i(63695), _ = i(74125), p = i(80585), v = i(17251), C = i(43326), x = i(69151), T = i(87306), g = i.n(T);
      let y = (0, l.PA)((t2) => {
        let {
          className: e2,
          titleContainerClassName: i2,
          track: l2,
          albumArtists: T2,
          withExplicitMark: y2 = true,
          withSecondaryColor: A,
          captionSize: h = "m",
          explicitSize: b = "xxxs",
          withAllArtistsTitle: N,
          textClassName: j,
          artistsClassName: I,
          ignoreDislikedStyles: P,
          withCustomTooltip: L = true,
          hasLineClamp: f = true,
          withSavingQueryParams: D,
          beforeTitle: S,
          withArtistLink: R = true,
          withTrackLink: M = true,
          afterTitle: E,
          withContextMenuArtists: O
        } = t2, { formatMessage: K } = (0, o.A)(), { sendNavigateSearchFeedback: w } = (0, _.zEv)(), {
          settings: { isMobile: B }
        } = (0, _.Pjs)(), U = (0, C.$)({ withCustomTooltip: L }), z = (0, s.useSearchParams)(), G = l2.getUrl(D ? Object.fromEntries(z) : void 0), $ = (0, n.useMemo)(() => {
          var t3;
          let e3 = K({ id: "entity-names.track-name" }, { trackName: l2.title });
          return "".concat(e3, " ").concat(null != (t3 = l2.version) ? t3 : "");
        }, [K, l2.title, l2.version]), q = (0, x.useOnTrackLinkClick)({
          track: l2,
          onNavigate: w,
          withSavingQueryParams: D,
          entityType: _.nPY.TRACK
        }), F = (0, n.useCallback)(
          (t3) => {
            let e3 = "".concat(l2.title, " ").concat(!l2.isRemoved && l2.version ? l2.version : "");
            return (0, a.jsx)(u.m_, {
              enabled: U && !B,
              offsetOptions: 4,
              placement: "top",
              text: e3,
              hoverSettings: _.VP$,
              children: (0, a.jsx)(m.Caption, {
                className: (0, r.$)(g().text, g().title),
                type: "entity",
                size: h,
                weight: "medium",
                variant: "span",
                ...t3,
                children: l2.title
              })
            });
          },
          [B, U, h, l2.isRemoved, l2.title, l2.version]
        ), X = (0, n.useMemo)(() => {
          let t3 = "".concat(l2.title, " ").concat(!l2.isRemoved && l2.version ? l2.version : "");
          return l2.isRemoved ? (0, a.jsx)(u.m_, {
            enabled: U && !B,
            offsetOptions: 4,
            placement: "top",
            text: K({ id: "track-title.error-not-found" }),
            hoverSettings: _.VP$,
            children: (0, a.jsx)(m.Caption, {
              className: (0, r.$)(g().text, g().title),
              type: "entity",
              size: h,
              weight: "medium",
              variant: "span",
              title: U ? void 0 : K({ id: "track-title.error-not-found" }),
              children: (0, a.jsx)(c.A, { id: "track-title.error-not-found" })
            })
          }) : l2.hasTrackLink && M ? (0, a.jsx)(p.N_, {
            onClick: q,
            className: g().albumLink,
            href: G,
            "aria-label": $,
            title: U ? void 0 : t3,
            ...(0, d.Am)(d.Kq.track.TRACK_TITLE),
            children: F()
          }) : F((0, d.Am)(d.Kq.track.TRACK_TITLE));
        }, [B, l2.title, l2.isRemoved, l2.version, l2.hasTrackLink, F, U, K, h, $, q, G, M]), Y = (0, v.s)(l2.artists, T2), V = (0, n.useMemo)(() => +!!f, [f]);
        return (0, a.jsx)("div", {
          className: (0, r.$)(
            g().root,
            {
              [g().root_disabled]: !l2.isAvailable,
              [g().root_disliked]: l2.isDisliked && !P,
              [g().root_withSecondaryColor]: A
            },
            e2
          ),
          children: (0, a.jsxs)("div", {
            className: g().metaContainer,
            children: [
              (0, a.jsxs)("div", {
                className: (0, r.$)(g().titleContainer, { [g().titleContainer_withVersion]: l2.version }, i2),
                children: [
                  (0, a.jsxs)(m.Caption, {
                    className: (0, r.$)(g().text, j),
                    type: "entity",
                    size: h,
                    weight: "medium",
                    variant: "div",
                    lineClamp: 1,
                    children: [
                      S,
                      X,
                      !l2.isRemoved && l2.version && (0, a.jsxs)(m.Caption, {
                        className: (0, r.$)(g().text, g().version),
                        type: "entity",
                        size: h,
                        weight: "medium",
                        variant: "span",
                        title: U ? void 0 : l2.version,
                        ...(0, d.Am)(d.Kq.track.TRACK_VERSION),
                        children: [" ", l2.version]
                      })
                    ]
                  }),
                  l2.explicitDisclaimer && y2 && (0, a.jsx)(p.Nq, {
                    containerClassName: g().explicitMarkContainer,
                    getDescriptionTexts: l2.getDescriptionTexts,
                    size: b,
                    variant: l2.explicitDisclaimer,
                    className: g().explicitMark,
                    trackId: l2.id
                  }),
                  E
                ]
              }),
              Y.length > 0 && (0, a.jsx)(k.iQ, {
                className: (0, r.$)(g().text, { [g().artists]: f }, I, j),
                withAllArtistsTitle: N,
                linkClassName: (0, r.$)(g().text, g().link),
                captionClassName: (0, r.$)(g().text, g().artistCaption),
                artists: Y,
                withLink: l2.isNonUserGenerated && R,
                lineClamp: V,
                captionSize: h,
                withContextMenu: O
              })
            ]
          })
        });
      });
    },
    13868: (t, e, i) => {
      "use strict";
      i.d(e, { TrackSchema: () => o });
      var a = i(54486), r = i(28303), l = i(15209), s = i(74125), n = i(80585);
      let o = (0, r.PA)((t2) => {
        var e2, i2;
        let { track: r2 } = t2;
        return (0, a.jsx)(n.Sj, {
          value: {
            "@type": "MusicRecording",
            name: r2.title,
            url: r2.url,
            thumbnailUrl: r2.coverUri ? (0, l.createAvatarUrl)(r2.coverUri, "orig") : void 0,
            duration: (0, s.FXG)(null != (e2 = r2.durationMs) ? e2 : 0),
            genre: null != (i2 = r2.genre) ? i2 : void 0,
            datePublished: r2.pubDate,
            description: r2.shortDescription,
            byArtist: r2.mainArtist ? { "@type": "MusicGroup", name: r2.mainArtist.name, url: r2.mainArtist.url } : void 0,
            inAlbum: r2.mainAlbum ? {
              "@type": "MusicAlbum",
              name: r2.mainAlbum.title,
              url: r2.mainAlbum.url,
              thumbnailUrl: r2.mainAlbum.coverUri ? (0, l.createAvatarUrl)(r2.mainAlbum.coverUri, "orig") : void 0
            } : void 0,
            potentialAction: {
              "@type": "ListenAction",
              expectsAcceptanceOf: {
                "@type": "Offer",
                category: "free",
                target: { "@type": "EntryPoint", actionPlatform: r2.url }
              }
            }
          }
        });
      });
    },
    14032: (t, e, i) => {
      "use strict";
      i.d(e, { V: () => r, d: () => a });
      let a = (t2) => String(t2).split(":"), r = (t2, e2) => e2 ? [t2, e2].join(":") : t2;
    },
    16479: (t, e, i) => {
      "use strict";
      i.d(e, { G: () => k });
      var a = i(54486), r = i(50420), l = i(28303), s = i(31500), n = i(3728), o = i(97800), c = i(74125), d = i(80585), u = i(4165), m = i.n(u);
      let k = (0, l.PA)((t2) => {
        let {
          className: e2,
          track: i2,
          position: l2,
          onPlayButtonClick: u2,
          isPlaying: k2,
          isCurrent: _,
          withDislikeStyles: p = true,
          isLoading: v
        } = t2, {
          settings: { isMobile: C }
        } = (0, c.Pjs)();
        return (0, a.jsxs)("div", {
          className: (0, r.$)(e2, m().root, {
            [m().root_disabled]: !i2.isAvailable && !i2.hasModalAccess,
            [m().root_playing]: k2,
            [m().root_disliked]: i2.isDisliked && p,
            [m().root_current]: _
          }),
          children: [
            (i2.isAvailable || i2.hasModalAccess) && (0, a.jsxs)(a.Fragment, {
              children: [
                !v && (0, a.jsx)(d.PD, { stopAnimation: !k2, className: m().playingAnimation }),
                v && C && (0, a.jsx)(n.y, { size: "xs", className: m().spinner }),
                !C && (0, a.jsx)(d.DM, {
                  variant: "filled",
                  className: m().playButton,
                  iconClassName: m().playButtonIcon,
                  isPlaying: k2,
                  onClick: u2,
                  iconSize: "xs"
                })
              ]
            }),
            l2 && (0, a.jsx)(o.Caption, {
              variant: "div",
              className: m().position,
              weight: "normal",
              type: "entity",
              size: "m",
              ...(0, s.Am)(s.Kq.track.TRACK_POSITION),
              children: l2
            })
          ]
        });
      });
    },
    17251: (t, e, i) => {
      "use strict";
      i.d(e, { s: () => r });
      var a = i(86947);
      let r = function() {
        var t2, e2;
        let i2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], r2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
        if (null == (e2 = i2[0]) || null == (t2 = e2.decomposed) ? void 0 : t2.length) return i2;
        let l = r2.map((t3) => t3.id).sort(), s = i2.map((t3) => t3.id).sort();
        return (0, a.A)(l, s) ? [] : i2.filter((t3) => !t3.various);
      };
    },
    21365: (t, e, i) => {
      "use strict";
      i.d(e, {
        ZS: () => w.AudiobookMeta,
        QD: () => K.ControlsBar,
        UU: () => f,
        xe: () => G.Lyrics,
        wo: () => B.PodcastMeta,
        Pt: () => V.PromoLandingTrackAlbum,
        c8: () => $.SearchTrackCard,
        CC: () => q.Track,
        FR: () => Q.TrackAlbum,
        wO: () => F.TrackCard,
        QB: () => H.TrackChart,
        _Y: () => z.TrackContextMenu,
        DP: () => M,
        j7: () => U.TrackMeta,
        vj: () => L,
        Kd: () => J.TrackNonMusic,
        Kt: () => tt.TrackPlaylist,
        II: () => ti.TrackPlaylistAddition,
        v4: () => X.TrackSchema,
        yY: () => ta.TrackUgcUpload,
        g2: () => W.TrailerTrackAlbum,
        nP: () => te.TrailerTrackPlaylist,
        U6: () => Y.UgcTrackEditModal,
        n_: () => E,
        kK: () => O,
        Df: () => Z.D,
        bV: () => c,
        h3: () => m,
        su: () => k.s,
        ye: () => v,
        zc: () => x,
        $b: () => g,
        vU: () => o,
        or: () => y,
        Rg: () => A.useAddTrackToPlaylist,
        $N: () => h.$,
        O6: () => b.useOnTrackLinkClick,
        sR: () => N.useRemoveTrackFromPlaylistByIndex,
        wf: () => j.useTrackDisclaimer
      });
      var a = i(93064), r = i(42140), l = i(46423), s = i(63695), n = i(54460);
      let o = (t2, e2) => {
        var i2, r2;
        let o2 = null == (i2 = t2.artists) ? void 0 : i2.map(s.dM), c2 = null == (r2 = t2.albums) ? void 0 : r2.map(l.e7);
        return (0, a.wg)({ ...(0, n.gK)(t2, e2), artists: o2, albums: c2 });
      }, c = (t2, e2) => (0, a.wg)({ ...o(t2), chart: e2 && (0, r.ws)(e2) });
      var d = i(60482), u = i(74125);
      let m = (t2, e2) => {
        let i2 = Math.floor(Date.now() / 1e3), a2 = "".concat(t2).concat(i2);
        return {
          sign: (0, d.createHmac)("sha256", (0, u.Efj)()).update(a2).digest("base64"),
          timeStamp: i2,
          trackId: t2,
          format: e2
        };
      };
      var k = i(17251), _ = i(97396), p = i(61910);
      (0, p.cache)(async (t2, e2) => {
        let i2;
        (0, u.LLJ)(t2) && (0, u.LLJ)(e2) || (0, _.notFound)();
        try {
          var a2, r2;
          let {
            container: l2,
            backendHostTld: s2,
            locale: n2,
            host: o2,
            isRSC: c2,
            fullUrl: d2,
            requestUrl: m2
          } = await (0, u.IhE)();
          if (c2)
            return {
              track: void 0,
              album: void 0,
              similarTracks: void 0,
              fullUrl: d2,
              requestUrl: m2,
              backendHostTld: s2,
              locale: n2,
              host: o2,
              isRSC: c2
            };
          let k2 = l2.get(u.Ooh), _2 = await k2.getFullInfoTrack({ trackId: t2, albumId: Number(e2) });
          i2 = {
            track: _2.track,
            album: null == (r2 = _2.track) || null == (a2 = r2.albums) ? void 0 : a2[0],
            similarTracks: _2.similarTracks,
            backendHostTld: s2,
            locale: n2,
            host: o2,
            fullUrl: d2,
            requestUrl: m2,
            isRSC: c2
          };
        } catch (t3) {
          return (0, u.tfF)(t3, () => ({ track: void 0, album: void 0, similarTracks: void 0, ...(0, u.Bj3)() }));
        }
        return i2.track && "not-found" !== i2.track.error || (0, _.notFound)(), i2;
      });
      let v = (t2, e2) => {
        if (!e2 || !t2) return;
        let { h: i2, s: a2 } = (0, u.g8k)(e2);
        return "hsl(".concat(i2, ", ").concat(a2, "%, ").concat(t2 === u.Sxu.Light ? 60 : 20, "%)");
      };
      (0, p.cache)(async (t2) => {
        let e2;
        try {
          var i2, a2;
          let {
            container: r2,
            backendHostTld: l2,
            locale: s2,
            host: n2,
            fullUrl: o2,
            requestUrl: c2,
            isRSC: d2
          } = await (0, u.IhE)();
          if (d2)
            return {
              track: void 0,
              album: void 0,
              fullUrl: o2,
              isRSC: d2,
              requestUrl: c2,
              backendHostTld: l2,
              locale: s2,
              host: n2
            };
          let m2 = r2.get(u.Ooh), k2 = await m2.getTracksMeta({ trackIds: [t2], removeDuplicates: true });
          e2 = {
            track: null == k2 ? void 0 : k2[0],
            album: null == k2 || null == (a2 = k2[0]) || null == (i2 = a2.albums) ? void 0 : i2[0],
            backendHostTld: l2,
            locale: s2,
            host: n2,
            fullUrl: o2,
            requestUrl: c2
          };
        } catch (t3) {
          return (0, u.tfF)(t3, () => ({ track: void 0, album: void 0, ...(0, u.Bj3)() }));
        }
        return e2.track && "not-found" !== e2.track.error || (0, _.notFound)(), e2;
      });
      var C = i(8075);
      let x = (t2) => t2 ? { id: t2.id, artists: t2.artists.map(s.NE), durationMs: t2.durationMs, title: t2.title, type: t2.type } : { id: 0, artists: [], durationMs: 0, title: "", type: C.S.TRACK };
      var T = i(89461);
      let g = (t2) => ({ type: T.z4.Unloaded, meta: { id: t2.entityId } }), y = (t2) => {
        var e2, i2;
        return (0, a.wg)({
          ...o(t2),
          artists: null != (i2 = null == t2 || null == (e2 = t2.artists) ? void 0 : e2.map(s.dM)) ? i2 : []
        });
      };
      var A = i(48284), h = i(43326), b = i(69151);
      i(43658);
      var N = i(8871), j = i(47937);
      let I = a.gK.model("Credit", { title: a.gK.string, value: a.gK.string });
      var P = i(26433);
      let L = n.OQ.props({ artists: a.gK.array(s.PK), albums: a.gK.array(l.GI), chart: a.gK.maybe(r.Iz) }).views((t2) => ({
        get artistsNames() {
          var e2;
          return null == (e2 = t2.artists) ? void 0 : e2.map((t3) => t3.name).join(", ");
        },
        get mainArtist() {
          var i2, a2, r2, l2;
          if (null == (a2 = t2.artists) || null == (i2 = a2[0]) ? void 0 : i2.various) return null;
          return null != (l2 = null == (r2 = t2.artists) ? void 0 : r2[0]) ? l2 : null;
        },
        get mainAlbum() {
          var s2, n2;
          return null != (n2 = null == (s2 = t2.albums) ? void 0 : s2[0]) ? n2 : null;
        },
        get index() {
          var o2, c2, d2;
          return null != (d2 = null == (c2 = t2.albums[0]) || null == (o2 = c2.trackPosition) ? void 0 : o2.index) ? d2 : null;
        },
        get isAvailableOnlyForPlus() {
          var u2;
          return !!(null == (u2 = this.mainAlbum) ? void 0 : u2.isAvailableOnlyForPlus);
        }
      })).actions((t2) => ({
        changeTrackInfo: (0, a.L3)(function* (e2, i2) {
          let { ugcResource: r2, modelActionsLogger: l2 } = (0, a._$)(t2);
          if (t2.artists.map((t3) => t3.name).join(", ") === i2 && e2 === t2.title) return u.FlZ.OK;
          try {
            var n2;
            yield r2.changeTrack({ trackId: t2.id, title: e2, artist: i2 }), t2.title = e2;
            let l3 = (null == (n2 = t2.artists[0]) ? void 0 : n2.id) || "0";
            if (t2.artists = (0, a.wg)([]), i2) {
              let e3 = s.PK.create({ id: l3, name: i2, isAvailable: true });
              t2.artists = (0, a.wg)([e3]);
            }
            return u.FlZ.OK;
          } catch (t3) {
            return l2.error(t3), u.FlZ.ERROR;
          }
        })
      })).named("Track"), f = a.gK.model("CurrentTrackInfo", {
        id: a.gK.maybeNull(a.gK.union(a.gK.string, a.gK.number)),
        albumId: a.gK.maybeNull(a.gK.number),
        isUGC: a.gK.maybeNull(a.gK.boolean),
        trackLoadingState: a.gK.enumeration(Object.values(u.GuX)),
        fullTrack: a.gK.maybeNull(L),
        creditsLoadingState: a.gK.enumeration(Object.values(u.GuX)),
        credits: a.gK.maybeNull(a.gK.array(I)),
        modal: P.qt,
        fullDescription: a.gK.maybeNull(a.gK.string),
        descriptionLoadingState: a.gK.enumeration(Object.values(u.GuX))
      }).views((t2) => ({
        get isTrackIdle() {
          return t2.trackLoadingState === u.GuX.IDLE;
        },
        get isCreditsIdle() {
          return t2.creditsLoadingState === u.GuX.IDLE;
        },
        get isTrackLoading() {
          return t2.trackLoadingState === u.GuX.PENDING || t2.trackLoadingState === u.GuX.IDLE;
        },
        get isTrackRejected() {
          return t2.trackLoadingState === u.GuX.REJECT;
        },
        get isCreditsLoading() {
          return t2.creditsLoadingState === u.GuX.PENDING || t2.creditsLoadingState === u.GuX.IDLE;
        },
        get isCreditsRejected() {
          return t2.creditsLoadingState === u.GuX.REJECT;
        },
        get isRejected() {
          return t2.creditsLoadingState === u.GuX.REJECT && t2.trackLoadingState === u.GuX.REJECT;
        }
      })).actions((t2) => ({
        setTrack(e2) {
          let { id: i2, albumId: a2, isUGC: r2 } = e2;
          t2.id = i2, t2.albumId = a2, t2.isUGC = r2;
        },
        getFullTrack: (0, a.L3)(function* () {
          let { tracksResource: e2, modelActionsLogger: i2 } = (0, a._$)(t2);
          if (!t2.id || t2.trackLoadingState === u.GuX.PENDING) return null;
          try {
            t2.trackLoadingState = u.GuX.PENDING;
            let i3 = yield e2.getFullInfoTrack({ trackId: t2.id, albumId: t2.albumId });
            if (!i3) return null;
            t2.fullTrack = (0, a.wg)(o(i3.track)), t2.trackLoadingState = u.GuX.RESOLVE;
          } catch (e3) {
            i2.error(e3), t2.trackLoadingState = u.GuX.REJECT;
          }
          return null;
        }),
        getFullDescription: (0, a.L3)(function* () {
          let { tracksResource: e2, modelActionsLogger: i2 } = (0, a._$)(t2);
          if (!t2.id || t2.descriptionLoadingState === u.GuX.PENDING) return null;
          try {
            t2.descriptionLoadingState = u.GuX.PENDING;
            let i3 = yield e2.getFullDescriptionTrack({ trackId: t2.id });
            if (!i3) return null;
            t2.fullDescription = i3.description, t2.descriptionLoadingState = u.GuX.RESOLVE;
          } catch (e3) {
            i2.error(e3), t2.descriptionLoadingState = u.GuX.REJECT;
          }
          return null;
        }),
        getTrackMeta: (0, a.L3)(function* () {
          let { tracksResource: e2, modelActionsLogger: i2 } = (0, a._$)(t2);
          if (!t2.id || t2.trackLoadingState === u.GuX.PENDING) return null;
          try {
            t2.trackLoadingState = u.GuX.PENDING;
            let i3 = yield e2.getTracksMeta({ trackIds: [t2.id], removeDuplicates: true });
            if (!i3 || !i3.length) return null;
            i3[0] && (t2.fullTrack = (0, a.wg)(o(i3[0])), t2.trackLoadingState = u.GuX.RESOLVE);
          } catch (e3) {
            i2.error(e3), t2.trackLoadingState = u.GuX.REJECT;
          }
          return null;
        }),
        getCreditsInfo: (0, a.L3)(function* () {
          let { tracksResource: e2, modelActionsLogger: i2 } = (0, a._$)(t2);
          if (!t2.id || t2.creditsLoadingState === u.GuX.PENDING) return null;
          try {
            t2.creditsLoadingState = u.GuX.PENDING;
            let i3 = yield e2.getCredits({ trackId: t2.id });
            t2.credits = (0, a.wg)(null == i3 ? void 0 : i3.credits), t2.creditsLoadingState = u.GuX.RESOLVE;
          } catch (e3) {
            i2.error(e3), t2.creditsLoadingState = u.GuX.REJECT;
          }
          return null;
        }),
        reset() {
          t2.id = null, t2.albumId = null, t2.isUGC = null, t2.trackLoadingState = u.GuX.IDLE, t2.descriptionLoadingState = u.GuX.IDLE, t2.creditsLoadingState = u.GuX.IDLE, t2.fullTrack = null, t2.credits = null;
        }
      }));
      var D = i(63930), S = i(9348), R = i(68907);
      let M = a.gK.compose(
        a.gK.model("TrackLyrics", {
          lyrics: a.gK.maybeNull(a.gK.string),
          major: a.gK.maybeNull(n.t$),
          lyricId: a.gK.maybeNull(a.gK.number),
          writers: a.gK.array(a.gK.string),
          externalLyricId: a.gK.maybeNull(a.gK.string),
          modal: P.qt,
          track: a.gK.maybeNull(L),
          trackId: a.gK.maybeNull(a.gK.union(a.gK.string, a.gK.number)),
          currentTrackId: a.gK.maybeNull(a.gK.union(a.gK.string, a.gK.number)),
          hasError: a.gK.optional(a.gK.boolean, false)
        }),
        P.XT
      ).views((t2) => ({
        get writersNames() {
          return t2.writers.join(", ");
        },
        get hasWriters() {
          return 0 !== t2.writers.length;
        },
        get isShimmerVisible() {
          return t2.isLoading || t2.isRejected;
        },
        get shouldShowErrorNotification() {
          return t2.isRejected && t2.hasError;
        }
      })).actions((t2) => {
        let e2 = {
          setTrack(e3) {
            t2.track = (0, a.wg)({ ...(0, D.HO)(e3) });
          },
          resetShouldShowError() {
            t2.hasError = false;
          },
          getLyrics: (0, a.L3)(function* (i2) {
            let { tracksResource: r2, modelActionsLogger: l2 } = (0, a._$)(t2);
            if (t2.loadingState !== u.GuX.PENDING && t2.currentTrackId !== i2)
              try {
                t2.loadingState = u.GuX.PENDING, t2.currentTrackId = i2;
                let {
                  downloadUrl: l3,
                  major: s2,
                  externalLyricId: o2,
                  lyricId: c2,
                  writers: d2
                } = yield r2.getLyrics(m(i2, R.o.TEXT));
                t2.major = (0, n.LT)(s2), t2.externalLyricId = o2, t2.lyricId = c2, t2.writers = (0, a.wg)(d2 || []), yield e2.downloadLyrics(l3), t2.loadingState = u.GuX.RESOLVE;
              } catch (e3) {
                t2.loadingState = u.GuX.REJECT, t2.currentTrackId = null, t2.hasError = true, t2.modal.isOpened && t2.modal.close(), l2.error(e3);
              }
          }),
          downloadLyrics: (0, a.L3)(function* (e3) {
            let { prefixlessResource: i2 } = (0, a._$)(t2);
            t2.lyrics = yield i2.getLyricsText(e3);
          }),
          sendViews: (0, a.L3)(function* (e3) {
            let { trackId: i2, albumId: r2 } = e3, { lyricViewsResource: l2, modelActionsLogger: s2 } = (0, a._$)(t2);
            if (t2.loadingState === u.GuX.RESOLVE)
              try {
                if (!t2.major || !t2.lyricId || !t2.externalLyricId || !t2.currentTrackId) return;
                yield l2.sendViews({
                  lyricViews: [
                    {
                      id: (0, S.A)(),
                      trackId: i2,
                      majorId: t2.major.id,
                      lyricId: t2.lyricId,
                      externalLyricId: t2.externalLyricId,
                      lyricFormat: R.o.TEXT,
                      albumId: void 0 !== r2 ? String(r2) : void 0
                    }
                  ]
                });
              } catch (t3) {
                s2.error(t3);
              }
          })
        };
        return e2;
      }), E = a.gK.model("UgcTrackEditModal", { modal: P.qt }).volatile(() => ({ track: null })).views((t2) => ({
        get trackTitle() {
          if (!t2.track) return "";
          return t2.track.title;
        },
        get trackArtist() {
          if (!t2.track) return "";
          return t2.track.artists.map((t3) => t3.name).join(", ");
        }
      })).actions((t2) => {
        let e2 = {
          open(e3) {
            t2.track = e3, t2.modal.open();
          },
          close() {
            t2.modal.close(), e2.reset();
          },
          reset() {
            t2.track = null;
          }
        };
        return e2;
      }), O = a.gK.compose(L, n.jU).named("UgcTrack");
      var K = i(76130), w = i(76858), B = i(54586), U = i(12938), z = i(62065), G = i(39194), $ = i(97778), q = i(23728), F = i(9821), X = i(13868), Y = i(43616), V = i(92810), Q = i(79971), W = i(61920), H = i(93549), J = i(4242), Z = i(58672), tt = i(79045), te = i(72850), ti = i(26853), ta = i(85905);
    },
    22407: (t) => {
      t.exports = {
        playButtonCell: "TrackNonMusic_playButtonCell__HaJrc",
        controlsBarCell: "TrackNonMusic_controlsBarCell__zWt44",
        dots: "TrackNonMusic_dots__Wom40",
        trackWithDots: "TrackNonMusic_trackWithDots__v2VbZ",
        important: "TrackNonMusic_important__u29Uj"
      };
    },
    23728: (t, e, i) => {
      "use strict";
      i.d(e, { Track: () => p });
      var a = i(54486), r = i(50420), l = i(28303), s = i(61910), n = i(8817), o = i(73633), c = i(74125), d = i(80585), u = i(855), m = i(47937), k = i(95953), _ = i.n(k);
      let p = (0, l.PA)((t2) => {
        var e2;
        let {
          className: i2,
          track: l2,
          meta: k2,
          beforeBlock: p2,
          controls: v,
          playButtonCellRender: C,
          withLightning: x,
          isPlaying: T,
          isCurrent: g,
          togglePlay: y,
          restartPlay: A,
          onPlayClick: h,
          playButtonIconSize: b,
          ...N
        } = t2, { shouldShowBuySubscriptionModal: j, showBuySubscriptionModal: I } = (0, c.qBP)(), {
          track: P,
          fullscreenPlayer: L,
          settings: { isMobile: f },
          album: D,
          albumCPA: { isPlusCPAPlayerBarEnabled: S }
        } = (0, c.Pjs)(), { ref: R, intersectionPropertyId: M } = (0, c.nMI)(), E = (0, c.brA)(), O = (0, c.PT7)(), K = (0, u.W)({ withLightning: x, track: l2 }), w = (0, c.uyA)(l2.entityId), B = S(D.id, null == (e2 = D.meta) ? void 0 : e2.isNonMusic), U = l2.isAvailable && j && !B, z = (0, m.useTrackDisclaimer)({ track: l2, callback: y }), G = (0, n.c)(() => {
          P.open({ trackId: l2.id, albumId: l2.albumId });
        }), $ = (0, m.useTrackDisclaimer)({ track: l2, callback: G }), { sendPlaySearchFeedback: q } = (0, c.zEv)(), [F, X] = (0, s.useState)(false), Y = (0, n.c)(() => {
          if (!O()) {
            if (U) return void I();
            F || T || (X(true), null == q || q()), z(), E(!T), null == h || h(!T);
          }
        }), V = (0, n.c)(() => {
          if (T) return void A();
          Y();
        }), Q = (0, n.c)((t3) => {
          if (!l2.isAvailable && !l2.hasModalAccess) {
            j && l2.isAvailableOnlyForPlus && I();
            return;
          }
          return U ? void I() : ((0, o.P)(t3, _().ripple), f) ? void Y() : 2 === t3.detail ? void V() : void (1 === t3.detail && l2.hasTrackLink && !L.modal.isOpened && $());
        }), W = null == C ? void 0 : C({ onPlayButtonClick: Y, isPlaying: T, isCurrent: g, isLoading: w, playButtonIconSize: b });
        return (0, a.jsxs)(d.Cj, {
          ref: R,
          "aria-label": K,
          "data-intersection-property-id": M,
          onClick: Q,
          className: (0, r.$)(_().root, { [_().root_disabled]: !l2.isAvailable, [_().root_current]: g && f }, i2),
          ...N,
          children: [p2, W, k2, v]
        });
      });
    },
    26853: (t, e, i) => {
      "use strict";
      i.d(e, { TrackPlaylistAddition: () => v });
      var a = i(54486), r = i(28303), l = i(61910), s = i(43426), n = i(31500), o = i(77881), c = i(5956), d = i(74125), u = i(80585), m = i(12938), k = i(23728), _ = i(58887), p = i.n(_);
      let v = (0, r.PA)((t2) => {
        let { className: e2, track: i2, playContextParams: r2, onClick: _2 } = t2, { formatMessage: v2 } = (0, s.A)(), {
          settings: { isMobile: C }
        } = (0, d.Pjs)(), x = (0, d.Dx4)({ playContextParams: r2, entityId: i2.entityId }), T = (0, l.useCallback)(
          (t3) => (0, a.jsx)(u.q1, {
            isAvailable: i2.isAvailable,
            isDisliked: i2.isDisliked,
            coverUri: i2.coverUri,
            title: i2.title,
            className: p().playButtonCell,
            radius: "xs",
            ...t3
          }),
          [i2]
        ), g = (0, l.useCallback)(
          (t3) => {
            t3.stopPropagation(), null == _2 || _2(i2);
          },
          [i2, _2]
        ), y = (0, l.useMemo)(
          () => (0, a.jsx)("div", {
            className: p().controls,
            children: (0, a.jsx)(o.$, {
              className: p().button,
              variant: "text",
              size: "xs",
              radius: "xxxl",
              "aria-label": v2({ id: "interface-actions.add-track-to-playlist" }),
              onClick: g,
              icon: (0, a.jsx)(c.Icon, { size: "xxs", variant: "add" })
            })
          }),
          [v2, g]
        );
        return (0, a.jsx)(k.Track, {
          className: e2,
          track: i2,
          meta: (0, a.jsx)(m.TrackMeta, { withArtistLink: !C, track: i2 }),
          playButtonCellRender: T,
          controls: y,
          ...x,
          ...(0, n.Am)(n.Kq.track.TRACK_PLAYLIST_ADDITION)
        });
      });
    },
    29220: (t) => {
      t.exports = {
        menu: "ContextSubMenuAddToPlaylist_menu__76MDp",
        listMenu: "ContextSubMenuAddToPlaylist_listMenu__e3qCt"
      };
    },
    29799: (t) => {
      t.exports = {
        root: "CommonTrack_root__i6shE",
        card: "TrackUgcUpload_card__bidIG",
        important: "TrackUgcUpload_important__RQkp0",
        playButton: "TrackUgcUpload_playButton__3l2I7",
        meta: "TrackUgcUpload_meta__aHQv9",
        title: "TrackUgcUpload_title__Xq3UP",
        status: "TrackUgcUpload_status__aFGvl",
        controls: "TrackUgcUpload_controls__Ie2Ox"
      };
    },
    31367: (t) => {
      t.exports = { ugcLabel: "TrackContextMenuHeader_ugcLabel__k7hmv" };
    },
    31992: (t) => {
      t.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        dateWithName: "PodcastMeta_dateWithName__cKy0o",
        podcastMetaContainer: "PodcastMeta_podcastMetaContainer__pFASj",
        podcastTitleContainer: "PodcastMeta_podcastTitleContainer__p9Zja",
        podcastName: "PodcastMeta_podcastName__iQeNK",
        progress: "PodcastMeta_progress__5DqlO",
        progress_disabled: "PodcastMeta_progress_disabled__KX04q",
        progress_withPreviousInfo: "PodcastMeta_progress_withPreviousInfo__eOrCi",
        soonDate: "PodcastMeta_soonDate__zGuG9",
        dateDisabled: "PodcastMeta_dateDisabled__DxjtJ",
        dateDisliked: "PodcastMeta_dateDisliked__95MlL"
      };
    },
    33738: (t) => {
      t.exports = { shimmer: "ContextMenuPlaylistItemShimmer_shimmer__bQ2Yb" };
    },
    35415: (t) => {
      t.exports = { root: "DragAndDropIcon_root__OstQU", root_active: "DragAndDropIcon_root_active__xOTKt" };
    },
    36386: (t, e, i) => {
      "use strict";
      i.d(e, { d: () => r });
      var a = i(74125);
      let r = (t2, e2, i2) => {
        let {
          settings: { isMobile: r2 }
        } = (0, a.Pjs)();
        return !!(r2 && t2 && ((null == e2 ? void 0 : e2.endPositionSec) && e2.endPositionSec > 0 || (null == e2 ? void 0 : e2.hasEverFinished) || i2 && i2 > 0));
      };
    },
    39194: (t, e, i) => {
      "use strict";
      i.d(e, { Lyrics: () => d });
      var a = i(54486), r = i(43426), l = i(31500), s = i(97800), n = i(80585), o = i(81510), c = i.n(o);
      let d = (t2) => {
        let { lyrics: e2, authors: i2, source: o2, isShimmerVisible: d2, isShimmerActive: u } = t2, { formatMessage: m } = (0, r.A)();
        return d2 ? (0, a.jsx)(n.q$, { count: 25, isActive: u }) : (0, a.jsxs)(a.Fragment, {
          children: [
            e2,
            (0, a.jsxs)("div", {
              className: c().writers,
              children: [
                i2.length > 0 && (0, a.jsx)(s.Caption, {
                  variant: "div",
                  size: "l",
                  weight: "medium",
                  ...(0, l.Am)(l.e8.content.TRACK_LYRICS_AUTHORS),
                  children: m({ id: "entity-names.authors" }, { authors: i2 })
                }),
                o2 && (0, a.jsx)(s.Caption, {
                  variant: "div",
                  size: "l",
                  weight: "medium",
                  ...(0, l.Am)(l.e8.content.TRACK_LYRICS_SOURCE),
                  children: m({ id: "entity-names.source" }, { source: o2 })
                })
              ]
            })
          ]
        });
      };
    },
    39206: (t, e, i) => {
      "use strict";
      i.d(e, { useVideoModal: () => s });
      var a = i(8817), r = i(74125), l = i(83333);
      let s = () => {
        let { fullscreenVideoPlayer: t2 } = (0, r.Pjs)(), e2 = (0, r.pqZ)();
        return (0, a.c)(function(i2) {
          let a2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
          t2.setIds(i2), t2.setClipIndex(a2), e2((0, l.J)(i2, a2)), t2.modal.open();
        });
      };
    },
    39757: (t) => {
      t.exports = {
        playButtonCell: "PromoLandingTrackAlbum_playButtonCell__5ZuIk",
        controlsBarCell: "PromoLandingTrackAlbum_controlsBarCell__Hapyd"
      };
    },
    42061: (t, e, i) => {
      "use strict";
      i.d(e, { useWithClips: () => r });
      var a = i(74125);
      let r = () => {
        let {
          settings: { isMobile: t2 }
        } = (0, a.Pjs)();
        return !t2;
      };
    },
    43326: (t, e, i) => {
      "use strict";
      i.d(e, { $: () => r });
      var a = i(74125);
      function r(t2) {
        let { withCustomTooltip: e2 } = t2, {
          settings: { isMobile: i2, browserInfo: r2 }
        } = (0, a.Pjs)();
        return !((null == r2 ? void 0 : r2.name) === "Safari" || i2) && e2;
      }
    },
    43616: (t, e, i) => {
      "use strict";
      i.d(e, { UgcTrackEditModal: () => u });
      var a = i(54486), r = i(28303), l = i(61910), s = i(43426), n = i(8817), o = i(74125), c = i(80585), d = (function(t2) {
        return t2.TITLE = "title", t2.ARTIST = "artist", t2;
      })({});
      let u = (0, r.PA)(() => {
        let {
          modals: { ugcTrackEditModal: t2 },
          fullscreenPlayer: e2
        } = (0, o.Pjs)(), { notify: i2 } = (0, o.lkh)(), { formatMessage: r2 } = (0, s.A)(), u2 = (0, l.useMemo)(
          () => [
            {
              key: d.TITLE,
              title: r2({ id: "track-modal.track-name" }),
              value: t2.trackTitle,
              minLength: 1,
              maxLength: 200
            },
            {
              key: d.ARTIST,
              title: r2({ id: "entity-names.singer" }),
              value: t2.trackArtist,
              minLength: 0,
              maxLength: 200
            }
          ],
          [r2, t2.trackArtist, t2.trackTitle]
        ), m = (0, n.c)(async (l2) => {
          let { title: s2, artist: n2 } = ((t3) => {
            var e3, i3;
            let a2 = null == (e3 = t3.find((t4) => t4.key === d.TITLE)) ? void 0 : e3.value, r3 = null == (i3 = t3.find((t4) => t4.key === d.ARTIST)) ? void 0 : i3.value;
            return { title: a2 = a2 ? a2.trim() : "", artist: r3 = r3 ? r3.trim() : "" };
          })(l2);
          t2.track && await t2.track.changeTrackInfo(s2, n2) === o.FlZ.ERROR && i2((0, a.jsx)(c.hT, { error: r2({ id: "ugc.editing-failed" }) }), {
            containerId: e2.modal.isOpened ? o.uQT.FULLSCREEN_ERROR : o.uQT.ERROR
          }), t2.close();
        });
        return t2.modal.isOpened ? (0, a.jsx)(c.$, {
          open: t2.modal.isOpened,
          title: r2({ id: "entity-names.track" }),
          content: u2,
          onClose: t2.close,
          onChange: m
        }) : null;
      });
    },
    43658: (t, e, i) => {
      "use strict";
      i.d(e, { h: () => o });
      var a = i(54486), r = i(8817), l = i(13611), s = i(54460), n = i(74125);
      let o = () => {
        let { notify: t2 } = (0, n.lkh)(), { playlist: e2, fullscreenPlayer: i2 } = (0, n.Pjs)(), o2 = (0, r.c)((r2) => {
          var o3, c2;
          let { withSuccessNotification: d, withPageRefresh: u, playlist: m, track: k } = r2;
          if (d && k && m) {
            let e3 = (0, s.eK)(k);
            t2(
              (0, a.jsx)(l.mM, {
                entityTitle: k.title,
                entityVariant: e3,
                entityCoverUri: null != (c2 = k.coverUri) ? c2 : "",
                playlist: m
              }),
              { containerId: i2.modal.isOpened ? n.uQT.FULLSCREEN_INFO : n.uQT.INFO }
            );
          }
          u && (null == m ? void 0 : m.uuid) === (null == (o3 = e2.meta) ? void 0 : o3.uuid) && e2.refresh();
        }), c = (0, r.c)((e3) => {
          let { withFailNotification: r2 } = e3;
          r2 && t2((0, a.jsx)(l.HB, {}), { containerId: i2.modal.isOpened ? n.uQT.FULLSCREEN_ERROR : n.uQT.ERROR });
        });
        return (0, r.c)(async (t3) => {
          let {
            playlist: e3,
            track: i3,
            trackIndex: a2,
            withSuccessNotification: r2 = true,
            withFailNotification: s2 = true,
            withPageRefresh: n2 = true
          } = t3, d = await e3.changePlaylist((0, l.Mp)({ operation: l.yC.DELETE, startPosition: a2, endPosition: a2 + 1 }));
          return d === l.Y9.OK ? o2({ withSuccessNotification: r2, withPageRefresh: n2, playlist: e3, track: i3 }) : c({ withFailNotification: s2 }), d;
        });
      };
    },
    44005: (t) => {
      t.exports = { syncLyrics: "TrackContextMenu_syncLyrics___CDVn" };
    },
    47937: (t, e, i) => {
      "use strict";
      i.d(e, { useTrackDisclaimer: () => r });
      var a = i(74125);
      let r = (t2) => {
        let { track: e2, callback: i2, disclaimerRejectHandler: r2 } = t2;
        return (0, a.lVe)({ entity: e2, entityType: a.nPY.TRACK, callback: i2, onReject: r2, preventDefaultWhenSafe: false });
      };
    },
    48284: (t, e, i) => {
      "use strict";
      i.d(e, { useAddTrackToPlaylist: () => o });
      var a = i(54486), r = i(8817), l = i(13611), s = i(54460), n = i(74125);
      let o = () => {
        let { notify: t2 } = (0, n.lkh)(), { playlist: e2, fullscreenPlayer: i2 } = (0, n.Pjs)(), o2 = (0, r.c)((r2) => {
          var o3, c2;
          let { withSuccessNotification: d, withPageRefresh: u, playlist: m, track: k } = r2;
          if (d) {
            let e3 = (0, s.eK)(k);
            t2(
              (0, a.jsx)(l.mZ, {
                entityTitle: k.title,
                entityVariant: e3,
                entityCoverUri: null != (c2 = k.coverUri) ? c2 : "",
                playlist: m
              }),
              { containerId: i2.modal.isOpened ? n.uQT.FULLSCREEN_INFO : n.uQT.INFO }
            );
          }
          u && m.uuid === (null == (o3 = e2.meta) ? void 0 : o3.uuid) && e2.refresh();
        }), c = (0, r.c)((e3) => {
          let { withFailNotification: r2 } = e3;
          r2 && t2((0, a.jsx)(l.pw, {}), { containerId: i2.modal.isOpened ? n.uQT.FULLSCREEN_ERROR : n.uQT.ERROR });
        });
        return (0, r.c)(async (t3) => {
          var e3;
          let {
            playlist: i3,
            track: a2,
            withSuccessNotification: r2 = true,
            withFailNotification: s2 = true,
            withPageRefresh: n2 = true
          } = t3, d = await i3.changePlaylist(
            (0, l.Mp)({
              operation: l.yC.INSERT,
              position: 0,
              tracks: [{ id: a2.id, albumId: null == (e3 = a2.mainAlbum) ? void 0 : e3.id }]
            })
          );
          return d === l.Y9.OK ? o2({ withSuccessNotification: r2, withPageRefresh: n2, playlist: i3, track: a2 }) : c({ withFailNotification: s2 }), d;
        });
      };
    },
    53700: (t, e, i) => {
      "use strict";
      i.d(e, { h: () => r });
      var a = i(74125);
      let r = (t2) => {
        let e2 = Math.round((t2 || 0) / a.k7R);
        return (0, a.E4p)(e2);
      };
    },
    54586: (t, e, i) => {
      "use strict";
      i.d(e, { PodcastMeta: () => j });
      var a = i(54486), r = i(50420), l = i(28303), s = i(97396), n = i(61910), o = i(43426), c = i(47713), d = i(97151), u = i(31500), m = i(8817), k = i(27510), _ = i(93666), p = i(97800), v = i(54460), C = i(74125), x = i(80585), T = i(43326), g = i(69151), y = i(36386), A = i(87306), h = i.n(A), b = i(31992), N = i.n(b);
      let j = (0, l.PA)((t2) => {
        var e2, i2, l2, A2, b2, j2;
        let {
          track: I,
          className: P,
          withPodcastName: L = false,
          withDate: f = true,
          withSecondaryColor: D = false,
          withListeningProgress: S = false,
          captionSize: R = "m",
          explicitSize: M = "xs",
          withExplicitMark: E = true,
          titleContainerClassName: O,
          textClassName: K,
          playContextParams: w,
          withTimeLeftText: B = true,
          ignoreDislikedStyles: U,
          withCustomTooltip: z = true,
          withSavingQueryParams: G,
          beforeTitle: $,
          afterTitle: q,
          titleLineClamp: F = 1,
          podcastMetaClassName: X,
          progressClassName: Y,
          withAlbumTitleLink: V = true
        } = t2, {
          fullscreenPlayer: Q,
          sonataState: W,
          settings: { isMobile: H }
        } = (0, C.Pjs)(), { formatMessage: J } = (0, o.A)(), Z = (0, T.$)({ withCustomTooltip: z }), tt = (0, s.useSearchParams)(), te = I.getUrl(G ? Object.fromEntries(tt) : void 0), ti = I.pubDate ? new Date(I.pubDate) : /* @__PURE__ */ new Date(), ta = (0, C.LkW)(ti), tr = false, tl = (0, C.ZpR)(null != (b2 = null == (e2 = I.mainAlbum) ? void 0 : e2.url) ? b2 : ""), ts = (0, n.useMemo)(() => {
          var t3;
          let e3 = J({ id: "entity-names.podcast-name" }, { podcastName: I.title });
          return "".concat(e3, " ").concat(null != (t3 = I.version) ? t3 : "");
        }, [J, I.title, I.version]), tn = !!(S && w && I.shouldRememberPosition && I.streamProgress && I.durationMs), to = I.id === (null == (i2 = W.entityMeta) ? void 0 : i2.id) && (null == (A2 = W.entityMeta) || null == (l2 = A2.streamProgress) ? void 0 : l2.endPositionSec), tc = (0, y.d)(tn, I.streamProgress, to), td = I.mainAlbum && L && !tc, tu = I.pubDate && f && !tc, tm = (0, C.lVe)({ entity: null != (j2 = I.mainAlbum) ? j2 : null, entityType: C.nPY.PODCAST, callback: tl }), tk = (0, m.c)((t3) => {
          Q.modal.isOpened && Q.modal.close(), tm(t3);
        }), t_ = (0, g.useOnTrackLinkClick)({ track: I, withSavingQueryParams: G, entityType: C.nPY.PODCAST }), tp = (0, n.useCallback)(() => {
          switch (ta) {
            case C.rdQ.TODAY:
              return (0, a.jsx)(c.A, { id: "interface-actions.date-today" });
            case C.rdQ.YESTERDAY:
              return (0, a.jsx)(c.A, { id: "interface-actions.date-yesterday" });
            case C.rdQ.DATE_WITH_YEAR:
              return (0, a.jsx)(d.XU, { value: I.pubDate, month: "long", day: "numeric", year: "numeric" });
            default:
              return (0, a.jsx)(d.XU, { value: I.pubDate, month: "long", day: "numeric" });
          }
        }, [I.pubDate, ta]);
        I.pubDate && f && (tr = [C.rdQ.TODAY, C.rdQ.YESTERDAY].includes(ta));
        let tv = (0, n.useCallback)(
          (t3) => (0, a.jsx)(_.m_, {
            enabled: Z && !H,
            offsetOptions: 4,
            placement: "top",
            text: I.title,
            hoverSettings: C.VP$,
            children: (0, a.jsx)(p.Caption, {
              className: h().title,
              type: "entity",
              size: R,
              variant: "span",
              title: Z ? void 0 : I.title,
              ...t3,
              children: I.title
            })
          }),
          [H, Z, R, I.title]
        ), tC = (0, n.useMemo)(
          () => I.isRemoved ? (0, a.jsx)(_.m_, {
            enabled: Z && !H,
            offsetOptions: 4,
            placement: "top",
            text: J({ id: "track-title.podcast-not-found" }),
            hoverSettings: C.VP$,
            children: (0, a.jsx)("span", {
              children: (0, a.jsx)(c.A, { id: "track-title.podcast-not-found" })
            })
          }) : I.hasTrackLink ? (0, a.jsx)(x.N_, {
            onClick: t_,
            className: h().albumLink,
            href: te,
            "aria-label": ts,
            title: Z ? void 0 : I.title,
            ...(0, u.Am)(u.Kq.track.TRACK_TITLE),
            children: tv()
          }) : tv((0, u.Am)(u.Kq.track.TRACK_TITLE)),
          [H, I.isRemoved, I.hasTrackLink, I.title, tv, Z, J, t_, te, ts]
        ), tx = (0, k.L)(() => {
          var t3;
          if (!td) return;
          let e3 = (0, a.jsx)(_.m_, {
            enabled: Z && !H,
            offsetOptions: 4,
            placement: "top",
            text: I.mainAlbum.title,
            hoverSettings: C.VP$,
            children: (0, a.jsx)(p.Caption, {
              variant: "span",
              type: "entity",
              size: R,
              className: h().albumTitle,
              children: I.mainAlbum.title
            })
          });
          return V ? (0, a.jsx)(x.N_, {
            "aria-label": J({ id: "entity-names.podcast-name" }, { podcastName: I.mainAlbum.title }),
            className: h().link,
            href: null == (t3 = I.mainAlbum) ? void 0 : t3.url,
            title: Z ? void 0 : I.mainAlbum.title,
            onClick: tk,
            ...(0, u.Am)(u.Kq.track.TRACK_PARENT_PODCAST_TITLE),
            children: e3
          }) : (0, a.jsx)("span", { ...(0, u.Am)(u.Kq.track.TRACK_PARENT_PODCAST_TITLE), children: e3 });
        });
        return (0, a.jsx)("div", {
          className: (0, r.$)(
            h().root,
            {
              [h().root_disabled]: !I.isAvailable,
              [h().root_disliked]: I.isDisliked && !U,
              [h().root_withSecondaryColor]: D
            },
            P
          ),
          children: (0, a.jsxs)("div", {
            className: (0, r.$)(h().metaContainer, N().podcastMetaContainer, X),
            children: [
              tn && w && I.streamProgress && (0, a.jsx)(v.Bg, {
                className: (0, r.$)(N().progress, Y, {
                  [N().progress_withPreviousInfo]: td || tu,
                  [N().progress_disabled]: !I.isAvailable || I.isDisliked
                }),
                id: I.id,
                albumId: I.albumId,
                streamProgress: I.streamProgress,
                durationMs: I.durationMs || 0,
                playContextParams: w,
                withTimeLeftText: B
              }),
              (0, a.jsxs)("div", {
                className: (0, r.$)(h().titleContainer, O, N().podcastTitleContainer),
                children: [
                  (0, a.jsxs)(p.Caption, {
                    className: (0, r.$)(h().text, K),
                    type: "entity",
                    size: R,
                    variant: "div",
                    lineClamp: F,
                    children: [
                      $,
                      tC,
                      !I.isRemoved && I.version && (0, a.jsxs)(p.Caption, {
                        className: (0, r.$)(h().text, h().version),
                        type: "entity",
                        size: R,
                        weight: "medium",
                        variant: "span",
                        title: Z ? void 0 : I.version,
                        children: [" ", I.version]
                      })
                    ]
                  }),
                  I.explicitDisclaimer && E && (0, a.jsx)(x.Nq, {
                    containerClassName: h().explicitMarkContainer,
                    getDescriptionTexts: I.getDescriptionTexts,
                    variant: I.explicitDisclaimer,
                    className: h().explicitMark,
                    size: M,
                    trackId: I.id
                  }),
                  q
                ]
              }),
              (td || tu) && (0, a.jsxs)(p.Caption, {
                type: "entity",
                size: R,
                variant: "div",
                lineClamp: 1,
                className: (0, r.$)(h().text, N().podcastName, K),
                children: [
                  tx,
                  tu && (0, a.jsx)(p.Caption, {
                    variant: "span",
                    type: "entity",
                    size: R,
                    className: (0, r.$)({
                      [N().dateWithName]: td,
                      [N().soonDate]: tr,
                      [N().dateDisabled]: !I.isAvailable,
                      [N().dateDisliked]: I.isDisliked && !U
                    }),
                    children: tp()
                  })
                ]
              })
            ]
          })
        });
      });
    },
    54830: (t, e, i) => {
      "use strict";
      i.d(e, {
        z8: () => v,
        l6: () => c,
        z4: () => d,
        JL: () => u.J,
        KX: () => m.useOnLikeClick,
        Hx: () => a.useSendEventOnClipClosed,
        _7: () => r.useSendEventOnClipNavigated,
        QV: () => l.useSendEventOnClipOpened,
        Mn: () => s.useSendEventOnClipShowedOrHidden,
        Cc: () => k.useVideoModal,
        df: () => _.useWithClips
      });
      var a = i(64782), r = i(59839), l = i(60339), s = i(58435), n = i(93064), o = i(74125);
      let c = (t2) => {
        let { available: e2, disclaimers: i2 } = (0, o.fyr)(t2);
        return (0, n.wg)({
          clipId: t2.clipId,
          title: t2.title,
          thumbnail: t2.thumbnail,
          duration: t2.duration,
          previewUrl: t2.previewUrl,
          isAvailable: e2,
          version: t2.version,
          disclaimers: i2
        });
      }, d = (t2, e2) => {
        let i2 = Number(e2);
        return !Number.isNaN(i2) && i2 > 0 && i2 < t2.length ? i2 : 0;
      };
      var u = i(83333), m = i(60272), k = i(39206), _ = i(42061), p = i(26433);
      let v = n.gK.compose(
        n.gK.model("BaseClip", {
          clipId: n.gK.number,
          title: n.gK.maybe(n.gK.string),
          thumbnail: n.gK.maybe(n.gK.string),
          previewUrl: n.gK.maybe(n.gK.string),
          duration: n.gK.maybe(n.gK.number),
          isAvailable: n.gK.boolean,
          version: n.gK.maybe(n.gK.string)
        }),
        p.Ec
      ).views((t2) => ({
        get url() {
          let { href: e2 } = (0, o.uvd)(o.Zyd.video.href, { query: { ids: String(t2.clipId) } });
          return e2;
        },
        get isLiked() {
          if (!(0, n._n)(t2)) return false;
          let { library: e2 } = (0, n.Zn)(t2);
          return e2.isClipLiked(t2.clipId);
        },
        get isLegalRejected() {
          return t2.getIsLegalRejected(t2.isAvailable);
        },
        get isUnsafeLegal() {
          return t2.getIsUnsafeLegal(t2.isAvailable);
        },
        getDisclaimerEntityRef: (e2) => ({ entityType: null != e2 ? e2 : o.nPY.CLIP, entityId: t2.clipId })
      })).actions((t2) => ({
        getKey: (e2) => "".concat(e2, "_").concat(t2.clipId),
        toggleLike() {
          if (!(0, n._n)(t2)) return;
          let { library: e2, user: i2 } = (0, n.Zn)(t2);
          if (i2.isAuthorized) return e2.toggleClipLike({ entityId: t2.clipId, userId: i2.account.data.uid });
        }
      }));
    },
    57104: (t) => {
      t.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "CommonControlsBar_root__N8b0F",
        root_withSecondaryColor: "CommonControlsBar_root_withSecondaryColor__4Y1P_",
        item: "CommonControlsBar_item__qGErG",
        contextMenu: "CommonControlsBar_contextMenu__EAq_c",
        contextMenu_visible: "CommonControlsBar_contextMenu_visible__M0ry0",
        contextMenuWrapper: "CommonControlsBar_contextMenuWrapper__XjkaL",
        lightning: "CommonControlsBar_lightning__o7wrY",
        ugcIcon: "CommonControlsBar_ugcIcon__OV0Cl",
        lightning_withOffset: "CommonControlsBar_lightning_withOffset__LGvUS",
        duration: "CommonControlsBar_duration__un38A",
        duration_hidden: "CommonControlsBar_duration_hidden__noQ4S",
        alwaysVisibleDuration: "CommonControlsBar_alwaysVisibleDuration__3V6gl",
        controls: "CommonControlsBar_controls__QrogT",
        trailerIcon: "CommonControlsBar_trailerIcon__ZHSBo",
        removeButton: "CommonControlsBar_removeButton__35xHY",
        controls_disabled: "CommonControlsBar_controls_disabled__0RmLo",
        explicitMark: "CommonControlsBar_explicitMark__3I_Op",
        controls_dislikedControls: "CommonControlsBar_controls_dislikedControls__mMjKC",
        likeIcon: "CommonControlsBar_likeIcon__YqgZY",
        controls_dislikedColors: "CommonControlsBar_controls_dislikedColors__h5lev",
        downloadIcon: "CommonControlsBar_downloadIcon__2mM6m",
        popover: "CommonControlsBar_popover__6bmNd"
      };
    },
    58435: (t, e, i) => {
      "use strict";
      i.d(e, { useSendEventOnClipShowedOrHidden: () => n });
      var a = i(43350), r = i(62395), l = i(8817), s = i(74125);
      let n = (t2) => {
        let e2 = (0, r.st)(), { hash: i2 } = (0, r.gf)(), { pageId: n2 } = (0, s.$au)(), { tabId: o, tabPos: c, isTabSelectedByDefault: d } = (0, s.Rro)(), { blockType: u, blockId: m, blockPosX: k, blockPosY: _, mainObjectType: p, mainObjectId: v } = (0, s.N8n)(), { objectsCount: C, objectType: x, objectId: T, objectPosX: g, objectPosY: y } = (0, s.Jfv)(), A = (0, s.UlF)(), { skeleton: h } = (0, s.bCF)();
        return (0, l.c)((r2) => {
          if (!e2 || !n2 || !s.xKB.includes(n2)) return;
          let l2 = {
            hash: i2,
            pageId: n2,
            entityType: u,
            entityId: m,
            entityPosX: k,
            entityPosY: _,
            objectsCount: C,
            viewUuid: t2,
            objectType: x,
            objectId: T,
            objectPosX: g,
            objectPosY: y
          };
          s.qG9.includes(n2) && (l2.tabId = o, l2.tabPos = c, l2.isTabSelectedByDefault = d), h && (l2.skeletonId = h), p && (l2.mainObjectType = p), v && (l2.mainObjectId = v);
          let b = (0, a.Fx)({ params: l2, logger: A, context: "useSendEventOnClipShowedOrHidden" });
          if (b) {
            if (r2) return void (0, a.Pf)(e2.evgenInstance, b);
            (0, a.nv)(e2.evgenInstance, b);
          }
        });
      };
    },
    58672: (t, e, i) => {
      "use strict";
      i.d(e, { D: () => a });
      var a = (function(t2) {
        return t2.ALBUM = "album", t2.PLAYLIST = "playlist", t2;
      })({});
    },
    58887: (t) => {
      t.exports = {
        playButtonCell: "TrackPlaylistAddition_playButtonCell__Ocnhq",
        controls: "TrackPlaylistAddition_controls__S346Y",
        button: "TrackPlaylistAddition_button__fsY9k"
      };
    },
    59839: (t, e, i) => {
      "use strict";
      i.d(e, { useSendEventOnClipNavigated: () => n });
      var a = i(43350), r = i(62395), l = i(8817), s = i(74125);
      let n = (t2) => {
        let e2 = (0, r.st)(), { hash: i2 } = (0, r.gf)(), { pageId: n2 } = (0, s.$au)(), { tabId: o, tabPos: c, isTabSelectedByDefault: d } = (0, s.Rro)(), { skeleton: u } = (0, s.bCF)(), { blockType: m, blockId: k, blockPosX: _, blockPosY: p, mainObjectType: v, mainObjectId: C } = (0, s.N8n)(), { objectsCount: x, objectType: T, objectId: g, objectPosX: y, objectPosY: A } = (0, s.Jfv)(), h = (0, s.UlF)();
        return (0, l.c)(() => {
          if (!e2 || !n2 || !s.xKB.includes(n2)) return;
          let r2 = {
            hash: i2,
            pageId: n2,
            entityType: m,
            entityId: k,
            entityPosX: _,
            entityPosY: p,
            objectId: g,
            objectType: T,
            objectPosX: y,
            objectPosY: A,
            objectsCount: x,
            from: s.Wft[n2],
            to: a.QT.VideoScreen
          };
          s.qG9.includes(n2) && (r2.tabId = o, r2.tabPos = c, r2.isTabSelectedByDefault = d), u && (r2.skeletonId = u), v && (r2.mainObjectType = v), C && (r2.mainObjectId = C);
          let l2 = (0, a.Fx)({ params: r2, logger: h, context: "useSendEventOnClipNavigated" });
          l2 && t2 && (0, a.QS)(e2.evgenInstance, l2);
        });
      };
    },
    60272: (t, e, i) => {
      "use strict";
      i.d(e, { useOnLikeClick: () => u });
      var a = i(54486), r = i(63930), l = i(61910), s = i(43426), n = i(77534), o = i(74125), c = i(80585);
      let d = (t2) => {
        let { clip: e2, closeToast: i2 } = t2;
        return (0, a.jsx)(c.OM, {
          entityVariant: c.cp.CLIP,
          entityTitle: e2.title,
          collectionUrl: o.Zyd.collectionClips.href,
          isLiked: e2.isLiked,
          closeToast: i2,
          coverUri: e2.thumbnail
        });
      }, u = (t2) => {
        let { user: e2, fullscreenVideoPlayer: i2, collection: u2 } = (0, o.Pjs)(), { notify: m } = (0, o.lkh)(), [k, _] = (0, l.useState)(false), { formatMessage: p } = (0, s.A)();
        return (0, l.useCallback)(async () => {
          if (!t2) return;
          let l2 = i2.modal.isOpened ? o.uQT.FULLSCREEN_INFO : o.uQT.INFO, s2 = i2.modal.isOpened ? o.uQT.FULLSCREEN_ERROR : o.uQT.ERROR;
          if (!e2.isAuthorized)
            return void m((0, a.jsx)(c.hT, { error: p({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: s2
            });
          if (k) return;
          let v = { ...(0, r.HO)(t2), isLiked: !t2.isLiked };
          _(true);
          let C = await t2.toggleLike();
          _(false), u2.clips.reset(), C === n.f.OK ? m((0, a.jsx)(d, { clip: v }), { containerId: l2 }) : m((0, a.jsx)(c.hT, { error: p({ id: "error-messages.error-during-action" }) }), { containerId: s2 });
        }, [t2, e2.isAuthorized, k, p, m, i2.modal.isOpened, u2.clips]);
      };
    },
    60339: (t, e, i) => {
      "use strict";
      i.d(e, { useSendEventOnClipOpened: () => n });
      var a = i(43350), r = i(62395), l = i(8817), s = i(74125);
      let n = () => {
        let t2 = (0, r.st)(), { hash: e2 } = (0, r.gf)(), i2 = (0, s.UlF)();
        return (0, l.c)((r2) => {
          if (!t2) return;
          let l2 = { hash: e2, pageId: a.QT.VideoScreen, mainObjectType: a.ky.Video, mainObjectId: r2 }, s2 = (0, a.Fx)({ params: l2, logger: i2, context: "useSendEventOnClipOpened" });
          s2 && (0, a.w5)(t2.evgenInstance, s2);
        });
      };
    },
    61920: (t, e, i) => {
      "use strict";
      i.d(e, { TrailerTrackAlbum: () => _ });
      var a = i(54486), r = i(28303), l = i(61910), s = i(31500), n = i(74125), o = i(76130), c = i(12938), d = i(16479), u = i(23728), m = i(94169), k = i.n(m);
      let _ = (0, r.PA)((t2) => {
        let {
          track: e2,
          albumArtists: i2,
          position: r2,
          playContextParams: m2,
          withLightning: _2,
          onPlayClick: p,
          onLikeClick: v,
          onDislikeClick: C
        } = t2, {
          trailer: x,
          settings: { isMobile: T },
          album: g
        } = (0, n.Pjs)(), y = (0, n.Dx4)({
          playContextParams: m2,
          entityId: e2.entityId,
          sonataState: x.state,
          playbackId: n.V_r.TRAILER
        }), A = (0, l.useCallback)(
          (t3) => (0, a.jsx)(d.G, { track: e2, position: r2, className: k().playButtonCell, ...t3 }),
          [e2, r2]
        );
        return (0, a.jsx)(u.Track, {
          track: e2,
          withLightning: _2,
          meta: (0, a.jsx)(c.TrackMeta, {
            withArtistLink: !T,
            albumArtists: i2,
            track: e2,
            withSavingQueryParams: g.id === e2.albumId
          }),
          playButtonCellRender: A,
          onPlayClick: p,
          controls: (0, a.jsx)(o.ControlsBar, {
            withLightning: _2,
            track: e2,
            className: k().controlsBarCell,
            onLikeClick: v,
            onDislikeClick: C
          }),
          ...y,
          ...(0, s.Am)(s.Kq.track.TRACK_ALBUM)
        });
      });
    },
    62040: (t) => {
      t.exports = { root: "ContextMenuPlaylistItem_root__WU_1g", icon: "ContextMenuPlaylistItem_icon__U79vo" };
    },
    62065: (t, e, i) => {
      "use strict";
      i.d(e, { TrackContextMenu: () => to });
      var a = i(54486), r = i(50420), l = i(63930), s = i(28303), n = i(61910), o = i(43426), c = i(47713), d = i(43350), u = i(31500), m = i(70140), k = i(11036), _ = i(8817), p = i(5956), v = i(61958), C = i(46423), x = i(54830), T = i(83504), g = i(54460), y = i(74125), A = i(80585), h = i(8871), b = i(86062);
      let N = (0, s.PA)((t2) => {
        let { track: e2 } = t2, {
          modals: { ugcTrackEditModal: i2 }
        } = (0, y.Pjs)(), r2 = (0, n.useCallback)(() => {
          i2.open(e2);
        }, [e2, i2]);
        return (0, a.jsx)(v.Dr, {
          onClick: r2,
          icon: (0, a.jsx)(p.Icon, { variant: "edit", size: "xxs" }),
          ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_UGC_EDIT_BUTTON),
          children: (0, a.jsx)(c.A, { id: "interface-actions.edit" })
        });
      });
      var j = i(63695), I = i(44005), P = i.n(I);
      let L = (0, s.PA)((t2) => {
        let { className: e2, artist: i2, ...r2 } = t2, { fullscreenPlayer: l2 } = (0, y.Pjs)(), s2 = (0, y.ZpR)(i2.url), n2 = (0, _.c)((t3) => {
          s2(t3), l2.modal.close();
        });
        return (0, a.jsx)(v.Dr, {
          className: e2,
          onClick: n2,
          icon: (0, a.jsx)(p.Icon, { className: P().navigateToAlbumIcon, variant: "artist", size: "xxs" }),
          ...r2,
          children: (0, a.jsx)(c.A, { id: "interface-actions.navigate-to-artist" })
        });
      }), f = (0, s.PA)((t2) => {
        let { className: e2, artists: i2 } = t2, {
          settings: { isMobile: r2 }
        } = (0, y.Pjs)(), { formatMessage: l2 } = (0, o.A)();
        return 1 === i2.length && i2[0] ? (0, a.jsx)(L, {
          className: e2,
          artist: i2[0],
          ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_NAVIGATE_TO_ARTIST)
        }) : (0, a.jsx)(v.W1, {
          isMobile: r2,
          icon: (0, a.jsx)(p.Icon, { variant: "artist", size: "xxs" }),
          label: l2({ id: "interface-actions.navigate-to-artists" }),
          ariaLabel: l2({ id: "interface-actions.navigate-to-artists" }),
          className: e2,
          ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_NAVIGATE_TO_ARTIST),
          children: i2.map((t3) => (0, a.jsx)(j.V8, { artist: t3 }, t3.id))
        });
      });
      var D = i(97396), S = i(31905), R = i(13611), M = i(48284), E = i(85360), O = i(27510), K = i(97800), w = i(43658), B = i(62040), U = i.n(B);
      let z = (t2) => {
        let { playlist: e2, track: i2, autoFocus: r2 } = t2, { formatMessage: l2 } = (0, o.A)(), s2 = (0, M.useAddTrackToPlaylist)(), c2 = (0, w.h)(), { isTrackInPlaylist: d2, trackIndexInPlaylist: m2 } = ((t3, e3) => {
          var i3, a2;
          let r3 = -1;
          return (null == (i3 = t3.tracks) ? void 0 : i3.length) && (r3 = null == (a2 = t3.tracks) ? void 0 : a2.findIndex(
            (t4) => t4.albumId ? String(t4.id) === e3.id && t4.albumId === e3.albumId : String(t4.id) === e3.id
          )), { isTrackInPlaylist: r3 > -1, trackIndexInPlaylist: r3 };
        })(e2, i2), k2 = (0, n.useCallback)(() => {
          d2 ? c2({ playlist: e2, track: i2, trackIndex: m2 }) : s2({ playlist: e2, track: i2 });
        }, [s2, c2, e2, i2, m2, d2]);
        return (0, a.jsxs)(v.Dr, {
          autoFocus: r2,
          className: U().root,
          onClick: k2,
          ...(0, u.Am)(u.Kq.track.TRACK_SUBMENU_ITEM),
          children: [
            (0, a.jsx)(K.Caption, { variant: "div", lineClamp: 1, children: e2.title }),
            d2 && (0, a.jsx)(p.Icon, {
              className: U().icon,
              size: "xxs",
              variant: "check",
              "aria-label": l2({ id: "entity-names.track-in-playlist" }),
              ...(0, u.Am)(u.Kq.track.TRACK_SUBMENU_IN_PLAYLIST_ICON)
            })
          ]
        });
      };
      var G = i(22674), $ = i(33738), q = i.n($);
      let F = (t2) => {
        let { forwardRef: e2, className: i2, ...r2 } = t2;
        return (0, a.jsx)(v.Dr, {
          className: i2,
          ref: e2,
          ...r2,
          children: (0, a.jsx)(G.Shimmer, { isActive: true, className: q().shimmer })
        });
      }, X = (0, n.forwardRef)((t2, e2) => {
        let { ...i2 } = t2;
        return (0, a.jsx)(F, { ...i2, forwardRef: e2 });
      });
      var Y = i(88948), V = i.n(Y);
      let Q = "EndlessFeed", W = (0, s.PA)((t2) => {
        var e2, i2, l2;
        let { track: s2 } = t2, { user: d2, contextMenuPlaylists: m2 } = (0, y.Pjs)(), { formatMessage: k2 } = (0, o.A)(), C2 = (0, g.KX)(s2), x2 = (0, n.useRef)(null), { isIntersecting: T2 } = null != (i2 = (0, E.BL)([x2], { preflightCheck: false }, m2.isShimmerVisible)[Q]) ? i2 : {}, A2 = Math.ceil(m2.items.length / 20), h2 = null != (l2 = null == (e2 = m2.pagesLoader.pager) ? void 0 : e2.page) ? l2 : 0, b2 = (0, _.c)((t3) => {
          d2.account.data.uid && m2.getData({ userId: d2.account.data.uid, page: t3, pageSize: 20 });
        });
        (0, n.useEffect)(() => {
          T2 && b2(h2 + 1);
        }, [T2, b2]);
        let N2 = (0, n.useMemo)(() => {
          if (!s2.isTrackNonMusic && m2.isResolved)
            return (0, a.jsxs)(v.Dr, {
              className: V().favouritesPlaylistItem,
              onClick: C2,
              ...(0, u.Am)(u.Kq.track.TRACK_SUBMENU_LIKE_PLAYLIST_BUTTON),
              children: [
                (0, a.jsx)(c.A, { id: "entity-names.liked-playlist" }),
                s2.isLiked && (0, a.jsx)(p.Icon, {
                  className: V().icon,
                  size: "xxs",
                  variant: "check",
                  "aria-label": k2({ id: "entity-names.track-in-playlist" }),
                  ...(0, u.Am)(u.Kq.track.TRACK_SUBMENU_IN_PLAYLIST_ICON)
                })
              ]
            });
        }, [m2.isResolved, C2, s2, k2]), j2 = (0, O.L)(() => {
          let t3 = m2.items.filter((t4) => null !== t4);
          if (0 !== t3.length)
            return t3.map((t4, e3) => {
              if (!t4 || t4.kind === R.ji.LIKE) return;
              let i3 = h2 + 1 === A2 && e3 === m2.items.length - m2.items.length % 20;
              return (0, a.jsx)(z, { autoFocus: i3, track: s2, playlist: t4 }, t4.uuid);
            });
        });
        return (0, a.jsx)("div", {
          className: V().root,
          ...(0, u.Am)(u.Kq.track.TRACK_SUBMENU),
          children: (0, a.jsxs)("div", {
            className: V().listPlaylist,
            children: [
              N2,
              j2,
              !m2.isResolved && Array.from({ length: 10 }, (t3, e3) => (0, a.jsx)(X, {}, e3)),
              (0, a.jsx)(X, {
                className: (0, r.$)({ [V().shimmerEndItem]: h2 + 1 === A2 }),
                ref: x2,
                "data-intersection-property-id": Q
              })
            ]
          })
        });
      });
      var H = i(29220), J = i.n(H);
      let Z = (0, s.PA)((t2) => {
        let { track: e2 } = t2, { user: i2, contextMenuPlaylists: r2 } = (0, y.Pjs)(), l2 = ((t3) => {
          let { createPlaylist: e3, fullscreenPlayer: i3 } = (0, y.Pjs)(), { notify: r3 } = (0, y.lkh)(), l3 = (0, D.useRouter)(), { formatMessage: s3 } = (0, o.A)(), n2 = (0, M.useAddTrackToPlaylist)(), c2 = (0, _.c)(async (t4) => {
            var i4;
            if (await e3.create({ title: s3({ id: "entity-names.new-playlist" }), visibility: S.L.PUBLIC }), !(null == e3 || null == (i4 = e3.meta) ? void 0 : i4.uuid))
              return null;
            if (await n2({
              playlist: e3.meta,
              track: t4,
              withPageRefresh: false,
              withFailNotification: false,
              withSuccessNotification: false
            }) === R.Y9.OK) {
              let { href: t5 } = (0, y.uvd)("/playlists/:playlistUuid", { params: { playlistUuid: e3.meta.uuid } });
              return e3.reset(), t5;
            }
            return null;
          });
          return (0, _.c)(async () => {
            let e4 = await c2(t3);
            e4 ? (i3.modal.isOpened && i3.modal.close(), l3.push(e4)) : r3((0, a.jsx)(R.pw, {}), { containerId: i3.modal.isOpened ? y.uQT.FULLSCREEN_ERROR : y.uQT.ERROR });
          });
        })(e2), { formatMessage: s2 } = (0, o.A)(), d2 = (0, n.useCallback)(async () => {
          i2.account.data.uid && await r2.getData({ userId: i2.account.data.uid, page: 0, pageSize: 20 });
        }, [r2, i2.account.data.uid]);
        return (0, n.useEffect)(
          () => () => {
            r2.reset();
          },
          [r2]
        ), (0, a.jsxs)(v.W1, {
          offsetOptions: 3,
          onShow: d2,
          icon: (0, a.jsx)(p.Icon, { variant: "addToPlaylist", size: "xxs" }),
          label: s2({ id: "playlist-actions.add-track-to-playlist" }),
          ariaLabel: s2({ id: "playlist-actions.add-track-to-playlist" }),
          disabled: !i2.isAuthorized,
          menuClassName: J().menu,
          listClassName: J().listMenu,
          ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_ADD_TO_PLAYLIST_BUTTON),
          children: [
            (0, a.jsx)(v.Dr, {
              onClick: l2,
              icon: (0, a.jsx)(p.Icon, { variant: "add", size: "xxs" }),
              ...(0, u.Am)(u.Kq.track.TRACK_SUBMENU_ADD_PLAYLIST_BUTTON),
              children: (0, a.jsx)(c.A, { id: "playlist-actions.create-playlist" })
            }),
            (0, a.jsx)(W, { track: e2 })
          ]
        });
      });
      var tt = i(95167), te = i(14032), ti = i(83635), ta = i.n(ti);
      let tr = (0, s.PA)((t2) => {
        let { track: e2 } = t2, i2 = (0, y.jRO)(), {
          slam: { isOfflineModeEnabled: r2 }
        } = (0, y.Pjs)(), l2 = (0, y.NFA)().get(y.vgk), s2 = (0, y.eGp)(), o2 = (0, n.useCallback)(() => {
          var t3, a2, n2;
          if (e2.isDownloaded) {
            null == (a2 = i2.tracksController) || a2.deleteTrack(e2.entityId);
            let t4 = null == s2 ? void 0 : s2.state.queueState.entityList.value.findIndex((t5) => {
              let { entity: i3 } = t5;
              if ((0, tt.b)(i3)) {
                var a3, r3;
                return e2.entityId === (0, te.V)(
                  i3.data.meta.id,
                  null == (r3 = i3.data.meta.albums) || null == (a3 = r3[0]) ? void 0 : a3.id
                );
              }
              return false;
            });
            void 0 !== t4 && r2 && (null == s2 || s2.hide({ positions: [t4] })), l2.count(y.xQR.TRACK_DELETE, y.l6e);
            return;
          }
          if (e2.isDownloading) {
            null == (n2 = i2.tracksController) || n2.stopDownload(e2.entityId);
            return;
          }
          null == (t3 = i2.tracksController) || t3.download(e2.entityId), l2.count(y.xQR.TRACK_DOWNLOAD, y.l6e);
        }, [e2.isDownloaded, e2.isDownloading, e2.entityId, i2.tracksController, l2, s2, r2]), d2 = (0, n.useMemo)(
          () => e2.isDownloaded ? (0, a.jsx)(c.A, { id: "offline.delete-from-device" }) : e2.isDownloading ? (0, a.jsx)(c.A, { id: "offline.stop-downloading" }) : (0, a.jsx)(c.A, { id: "offline.download" }),
          [e2.isDownloaded, e2.isDownloading]
        ), m2 = (0, n.useMemo)(
          () => e2.isDownloaded ? (0, a.jsx)(p.Icon, { variant: "upload", size: "xxs" }) : e2.isDownloading ? (0, a.jsx)(A.AD, {
            value: e2.downloadingProgress,
            size: 20,
            withCancelIcon: true,
            className: ta().downloadingProgress,
            progressBarClassName: ta().progress,
            cancelIconClassName: ta().cancelIcon
          }) : (0, a.jsx)(p.Icon, { variant: "download", size: "xxs" }),
          [e2.downloadingProgress, e2.isDownloaded, e2.isDownloading]
        );
        return (0, a.jsx)(v.Dr, {
          onClick: o2,
          icon: m2,
          className: ta().root,
          ...(0, u.Am)(u.S7.CONTEXT_MENU_DOWNLOAD_BUTTON),
          children: d2
        });
      });
      var tl = i(31367), ts = i.n(tl);
      let tn = (0, s.PA)((t2) => {
        let { track: e2 } = t2, {
          settings: { isMobile: i2 }
        } = (0, y.Pjs)();
        return e2.isUGC && i2 ? (0, a.jsxs)("div", {
          className: ts().ugcLabel,
          children: [
            (0, a.jsx)(p.Icon, { variant: "eye_crossed", size: "xxs" }),
            (0, a.jsx)(K.Caption, {
              variant: "span",
              size: "s",
              children: (0, a.jsx)(c.A, { id: "ugc.track-description" })
            })
          ]
        }) : null;
      }), to = (0, s.PA)((t2) => {
        var e2, i2, s2, j2, I2, L2, D2, S2, R2, M2, E2, O2, K2, w2, B2, U2, z2, G2, $2, q2;
        let {
          track: F2,
          onOpenChange: X2,
          open: Y2,
          placement: V2,
          isFullscreenMobile: Q2 = false,
          icon: W2,
          size: H2,
          utmLink: J2,
          handleRemove: tt2,
          dismissSettings: te2,
          withTrailer: ti2 = true,
          ...ta2
        } = t2, { shouldShowBuySubscriptionModal: tl2, showBuySubscriptionModal: ts2 } = (0, y.qBP)(), to2 = (0, y.eGp)(), {
          settings: tc,
          currentTrackInfo: td,
          experiments: tu,
          fullscreenPlayer: tm,
          trailer: tk,
          sonataState: { entityMeta: t_, isVibeContext: tp },
          trackLyrics: tv,
          album: tC,
          track: tx,
          user: tT,
          slam: tg,
          albumCPA: { isPlusCPAPlayerBarEnabled: ty }
        } = (0, y.Pjs)(), { formatMessage: tA } = (0, o.A)(), { sendLikeSearchFeedback: th } = (0, y.zEv)(), [tb, tN] = (0, n.useState)(false), { modal: tj } = tv, { modal: tI } = td, tP = (0, g.Dv)(F2), tL = (0, g.iQ)(F2, g.NM.NEXT, tP), tf = (0, g.iQ)(F2, g.NM.LAST, tP), tD = (0, g.KX)(F2), tS = (0, g.mW)(F2), tR = (0, C.KX)(F2.mainAlbum), tM = (0, g.TH)(F2), tE = (0, y.Ftl)(), tO = "".concat(y.UfI.TRACK, "-").concat(F2.id), tK = Q2 || tc.isMobile, tw = "/album/:albumId/track/:trackId";
        F2.albumId || (tw = "/track/:trackId");
        let { shareLink: tB, pathname: tU } = (0, y.bNS)(tw, {
          params: { albumId: null != ($2 = F2.albumId) ? $2 : "", trackId: F2.id }
        }), tz = F2.isUGC ? y.DwC.UGC_TRACK : y.DwC.TRACK, tG = (0, T.A_)({ entityVariant: tz, urlParams: { id: F2.id } }), t$ = (0, b.useTrackAboutModalTitle)(F2), tq = (0, x.Cc)(), tF = !!(null == (e2 = F2.mainAlbum) ? void 0 : e2.isNonMusic), tX = (null == t_ ? void 0 : t_.id) === F2.id && (null == t_ ? void 0 : t_.albumId) === (null == (i2 = F2.mainAlbum) ? void 0 : i2.id), tY = (null == tC || null == (s2 = tC.meta) ? void 0 : s2.listeningFinished) || tX && (null == t_ || null == (j2 = t_.streamProgress) ? void 0 : j2.hasEverFinished) || (null == (I2 = F2.streamProgress) ? void 0 : I2.hasEverFinished), tV = tT.hasPlus && F2.isAvailableForDownload, tQ = tu.checkExperiment(y.zal.WebEditorsFeatures, "on"), tW = tu.checkExperiment(y.zal.WebNextUseWaveQueue, "on"), tH = !!((0, m.i)(null == to2 ? void 0 : to2.state.currentContext.value) && !tW || (0, k.S)(null == to2 ? void 0 : to2.state.currentContext.value)), { canRemoveTrackFromPlaylist: tJ, removeTrackFromPlaylist: tZ } = (0, h.useRemoveTrackFromPlaylistByIndex)(), t0 = (0, y.PT7)(), t1 = ty(null == (L2 = F2.mainAlbum) ? void 0 : L2.id, null == (D2 = F2.mainAlbum) ? void 0 : D2.isNonMusic), { isPlaying: t3, togglePlay: t5 } = (0, y.B0S)({
          seeds: null != (q2 = null == F2 ? void 0 : F2.seeds) ? q2 : [],
          pageIdForFrom: y._Q$.RADIO,
          blockIdForFrom: tO,
          parentContextId: (null == (S2 = F2.mainAlbum) ? void 0 : S2.id) ? "".concat(F2.mainAlbum.id, ":").concat(F2.id) : F2.entityId
        }), t4 = (0, _.c)(async () => {
          tb || F2.isLiked || (tN(true), null == th || th()), await tD();
        }), t8 = (0, _.c)(() => {
          if (tl2 && tT.isAuthorized) return void ts2();
          !t0() && (t3 || t5());
        }), t6 = (0, _.c)(() => {
          if (tl2 && !t1) return void ts2();
          t0() || (tk.setUtmLink(J2), tk.openTrackTrailer(F2.entityId), tE(d.ky.Track, F2.id));
        }), t7 = (0, _.c)(() => {
          var t10;
          td.setTrack({
            id: F2.id,
            albumId: (null == (t10 = F2.mainAlbum) ? void 0 : t10.id) || null,
            isUGC: F2.isUGC || null
          }), tx.isOpened && tx.close(), tI.open();
        }), t22 = (0, _.c)(() => {
          F2.clipIds && tq((0, l.HO)(F2.clipIds));
        }), t9 = (0, _.c)(() => {
          if (tl2 && tT.isAuthorized) return void ts2();
          tv.setTrack(F2), tx.isOpened && tx.close(), tj.open();
        }), et = (0, _.c)(() => {
          if (tl2 && tT.isAuthorized) return void ts2();
          tm.isSyncLyricsMode ? tm.hideSyncLyrics() : tm.showSyncLyrics();
        }), ee = (0, _.c)(() => {
          null == tt2 || tt2(), null == X2 || X2(false);
        }), ei = (0, _.c)(() => F2.isSyncLyricsAvailable && tm.modal.isOpened && tK), ea = (0, _.c)(() => F2.isLyricsAvailable && !tm.modal.isOpened), er = (0, _.c)(() => {
          var t10;
          return (null == (t10 = F2.trailer) ? void 0 : t10.isAvailable) && !tm.modal.isOpened && ti2;
        }), {
          withSyncLyricsItem: el,
          withLyricsItem: es,
          withTrailerItem: en
        } = (0, n.useMemo)(
          () => ({ withSyncLyricsItem: ei(), withLyricsItem: ea(), withTrailerItem: er() }),
          [
            ei,
            ea,
            er,
            F2.isSyncLyricsAvailable,
            F2.isLyricsAvailable,
            null == (R2 = F2.trailer) ? void 0 : R2.isAvailable
          ]
        );
        (0, y.NBO)(Y2);
        let eo = !tF, ec = F2.isNonUserGenerated && !tF, ed = !tF, eu = !tK, em = tF && tR, ek = F2.isNonUserGenerated && (F2.albums.length || F2.mainAlbum), e_ = F2.isNonUserGenerated && !!(null == (M2 = F2.artists) ? void 0 : M2.length) && ((null == (E2 = F2.mainAlbum) ? void 0 : E2.isAudiobook) || (null == (O2 = F2.mainAlbum) ? void 0 : O2.isAlbum) || F2.isTrackAudiobook || F2.isTrackMusic), ep = !tH && t_, ev = tm.isPlayQueueMode && tt2 && !tp, eC = (0, x.df)() && F2.isNonUserGenerated && (null == (K2 = F2.clipIds) ? void 0 : K2.length), ex = {
          variant: y.Yxq.TRACK,
          id: F2.id,
          title: F2.title,
          path: tU,
          trackArtistName: null == (w2 = F2.mainArtist) ? void 0 : w2.name,
          trackArtistId: null == (B2 = F2.mainArtist) ? void 0 : B2.id,
          trackAlbumId: F2.albumId
        };
        return tg.isOfflineModeEnabled ? (0, a.jsxs)(v.W1, {
          isMobile: tK,
          placement: V2,
          offsetOptions: 10,
          open: Y2,
          onOpenChange: X2,
          icon: W2,
          size: H2,
          dismissSettings: te2,
          containerProps: (0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU),
          ariaLabel: tA({ id: "interface-actions.context-menu" }),
          variant: "text",
          ...ta2,
          children: [
            tV && (0, a.jsx)(tr, { track: F2 }),
            F2.isNonUserGenerated && (0, a.jsx)(A.Ht, { shareLink: tB, entityMeta: ex })
          ]
        }) : (0, a.jsxs)(v.W1, {
          dismissSettings: te2,
          isMobile: tK,
          placement: V2,
          offsetOptions: 10,
          open: Y2,
          onOpenChange: X2,
          icon: W2,
          size: H2,
          containerProps: (0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU),
          ariaLabel: tA({ id: "interface-actions.context-menu" }),
          variant: "text",
          ...ta2,
          children: [
            (0, a.jsx)(tn, { track: F2 }),
            tK && (0, a.jsx)(A.Cu, { getDescriptionTexts: F2.getDescriptionTexts, entityId: F2.id }),
            tQ && (0, a.jsx)(T.dx, { entityVariant: tz, adminUrl: tG }),
            tF && (0, a.jsx)(A.W$, { onClick: tM, isFinished: tY }),
            eo && (0, a.jsx)(A.TW, { onClick: t4, isLiked: F2.isLiked, disabled: !tT.isAuthorized }),
            en && (0, a.jsx)(A.No, { onClick: t6 }),
            ec && (0, a.jsx)(A.C6, {
              onClick: t8,
              variant: y.IGO.TRACK,
              disabled: !F2.isAvailable || t1 && tK,
              onOpenMenuChange: X2
            }),
            eC && (0, a.jsx)(v.Dr, {
              onClick: t22,
              icon: (0, a.jsx)(p.Icon, { variant: "clip", size: "xxs" }),
              ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_NAVIGATE_TO_CLIP_BUTTON),
              children: (0, a.jsx)(c.A, { id: "non-music.navigate-to-clip" })
            }),
            tV && (0, a.jsx)(tr, { track: F2 }),
            ep && (0, a.jsx)(v.Dr, {
              onClick: tL,
              icon: (0, a.jsx)(p.Icon, { variant: "playNext", size: "xxs" }),
              disabled: !tT.isAuthorized,
              ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_PLAY_NEXT_BUTTON),
              children: (0, a.jsx)(c.A, { id: "play-queue.play-next" })
            }),
            ep && (0, a.jsx)(v.Dr, {
              onClick: tf,
              icon: (0, a.jsx)(p.Icon, { variant: "playLast", size: "xxs" }),
              disabled: !tT.isAuthorized,
              ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_PLAY_LAST_BUTTON),
              children: (0, a.jsx)(c.A, { id: "play-queue.play-last" })
            }),
            el && !tm.isSyncLyricsMode && (0, a.jsx)(v.Dr, {
              className: (0, r.$)({ [P().syncLyrics]: Q2 }),
              onClick: et,
              icon: (0, a.jsx)(p.Icon, { variant: "syncLyrics", size: "xxs" }),
              disabled: !tT.isAuthorized,
              ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_SHOW_SYNC_LYRICS_BUTTON),
              children: (0, a.jsx)(c.A, { id: "interface-actions.open-sync-lyrics" })
            }),
            el && tm.isSyncLyricsMode && (0, a.jsx)(v.Dr, {
              className: (0, r.$)({ [P().syncLyrics]: Q2 }),
              onClick: et,
              icon: (0, a.jsx)(p.Icon, { variant: "syncLyrics", size: "xxs" }),
              ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_HIDE_SYNC_LYRICS_BUTTON),
              children: (0, a.jsx)(c.A, { id: "interface-actions.hide-sync-lyrics" })
            }),
            ev && (0, a.jsx)(v.Dr, {
              onClick: ee,
              icon: (0, a.jsx)(p.Icon, { variant: "bucket", size: "xxs" }),
              children: (0, a.jsx)(c.A, { id: "play-queue.delete-from-queue" })
            }),
            ed && (0, a.jsx)(A.DZ, { onClick: tS, isDisliked: F2.isDisliked }),
            eu && (0, a.jsx)(Z, { track: F2 }),
            es && (0, a.jsx)(v.Dr, {
              disabled: !tT.isAuthorized,
              onClick: t9,
              icon: (0, a.jsx)(p.Icon, { variant: "lyrics", size: "xxs" }),
              ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_LYRICS_BUTTON),
              children: (0, a.jsx)(c.A, { id: "interface-actions.open-lyrics" })
            }),
            F2.isNonUserGenerated && (0, a.jsx)(A.Ht, { shareLink: tB, entityMeta: ex }),
            ek && (null == (U2 = F2.mainAlbum) ? void 0 : U2.url) && (0, a.jsx)(A.f, { albumUrl: F2.mainAlbum.url, albumType: F2.mainAlbum.type, trackType: F2.type }),
            e_ && F2.artists[0] && (0, a.jsx)(f, { artists: F2.artists }),
            em && (0, a.jsx)(A.Uc, {
              onClick: tR,
              isLiked: null == (z2 = F2.mainAlbum) ? void 0 : z2.isLiked,
              albumType: null == (G2 = F2.mainAlbum) ? void 0 : G2.type
            }),
            F2.isUGC && (0, a.jsx)(N, { track: F2 }),
            tK && tJ && (0, a.jsx)(v.Dr, {
              onClick: tZ,
              icon: (0, a.jsx)(p.Icon, { variant: "bucket", size: "xxs" }),
              ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_REMOVE_TRACK_FROM_PLAYLIST_BUTTON),
              children: (0, a.jsx)(c.A, { id: "playlist-actions.remove-from-playlist" })
            }),
            !tK && (0, a.jsx)(v.Dr, {
              onClick: t7,
              icon: (0, a.jsx)(p.Icon, { variant: "info", size: "xxs" }),
              ...(0, u.Am)(u.Kq.track.TRACK_CONTEXT_MENU_ABOUT_TRACK_BUTTON),
              children: t$
            })
          ]
        });
      });
    },
    64782: (t, e, i) => {
      "use strict";
      i.d(e, { useSendEventOnClipClosed: () => n });
      var a = i(43350), r = i(62395), l = i(8817), s = i(74125);
      let n = () => {
        let t2 = (0, r.st)(), { hash: e2 } = (0, r.gf)(), i2 = (0, s.UlF)();
        return (0, l.c)((r2) => {
          if (!t2) return;
          let l2 = { hash: e2, pageId: a.QT.VideoScreen, mainObjectType: a.ky.Video, mainObjectId: r2 }, s2 = (0, a.Fx)({ params: l2, logger: i2, context: "useSendEventOnClipClosed" });
          s2 && (0, a.XB)(t2.evgenInstance, s2);
        });
      };
    },
    68907: (t, e, i) => {
      "use strict";
      var a;
      i.d(e, { o: () => a }), (function(t2) {
        t2.TEXT = "TEXT", t2.LRC = "LRC", t2.RICH_JSON = "RICH_JSON";
      })(a || (a = {}));
    },
    69151: (t, e, i) => {
      "use strict";
      i.d(e, { useOnTrackLinkClick: () => l });
      var a = i(8817), r = i(74125);
      let l = (t2) => {
        let { track: e2, withSavingQueryParams: i2, entityType: l2, onNavigate: s } = t2, { fullscreenPlayer: n, album: o, track: c } = (0, r.Pjs)(), d = o.id === e2.albumId, u = (0, r.pqZ)(), m = (0, a.c)((t3) => {
          if (n.modal.isOpened && n.modal.close(), null == s || s(), d) {
            null == t3 || t3.preventDefault();
            let a2 = (0, r.jrm)();
            i2 && a2 ? u(e2.getUrl(Object.fromEntries(a2))) : u(e2.url), c.open({ trackId: e2.id, albumId: e2.albumId });
          } else null == t3 || t3.stopPropagation();
        }), k = (0, a.c)((t3) => {
          null == s || s(), null == t3 || t3.stopPropagation();
        }), _ = { entity: e2, entityType: l2 }, p = (0, r.lVe)({ ..._, callback: m }), v = (0, r.lVe)({ ..._, callback: k });
        return (0, r.Cz$)({ onClick: p, onCmdCtrlClick: v });
      };
    },
    72850: (t, e, i) => {
      "use strict";
      i.d(e, { TrailerTrackPlaylist: () => _ });
      var a = i(54486), r = i(28303), l = i(61910), s = i(31500), n = i(74125), o = i(80585), c = i(76130), d = i(12938), u = i(23728), m = i(91759), k = i.n(m);
      let _ = (0, r.PA)((t2) => {
        let { track: e2, playContextParams: i2, onPlayClick: r2, onLikeClick: m2, onDislikeClick: _2 } = t2, {
          trailer: p,
          settings: { isMobile: v }
        } = (0, n.Pjs)(), C = (0, n.Dx4)({
          playContextParams: i2,
          entityId: e2.entityId,
          sonataState: p.state,
          playbackId: n.V_r.TRAILER
        }), x = (0, l.useCallback)(
          (t3) => (0, a.jsx)(o.q1, {
            isAvailable: e2.isAvailable,
            isDisliked: e2.isDisliked,
            coverUri: e2.coverUri,
            title: e2.title,
            className: k().playButtonCell,
            radius: "xs",
            ...t3
          }),
          [e2]
        );
        return (0, a.jsx)(u.Track, {
          track: e2,
          meta: (0, a.jsx)(d.TrackMeta, { withArtistLink: !v, track: e2 }),
          playButtonCellRender: x,
          onPlayClick: r2,
          controls: (0, a.jsx)(c.ControlsBar, {
            track: e2,
            className: k().controlsBarCell,
            onLikeClick: m2,
            onDislikeClick: _2
          }),
          ...C,
          ...(0, s.Am)(s.Kq.track.TRACK_PLAYLIST)
        });
      });
    },
    76130: (t, e, i) => {
      "use strict";
      i.d(e, { ControlsBar: () => N });
      var a = i(54486), r = i(50420), l = i(28303), s = i(61910), n = i(43426), o = i(47713), c = i(43350), d = i(31500), u = i(8817), m = i(5956), k = i(93666), _ = i(97800), p = i(54460), v = i(74125), C = i(80585), x = i(53700), T = i(62065), g = i(57104), y = i.n(g), A = i(93719), h = i.n(A);
      let b = (0, l.PA)((t2) => {
        let { track: e2 } = t2, { formatMessage: i2 } = (0, n.A)();
        return e2.isDownloaded ? (0, a.jsx)(m.Icon, {
          size: "xxs",
          variant: "downloaded",
          "aria-label": i2({ id: "offline.track-downloaded" })
        }) : e2.isDownloading ? (0, a.jsx)(C.AD, {
          value: e2.downloadingProgress,
          size: 16,
          className: h().downloadingProgress,
          progressBarClassName: h().progress
        }) : null;
      }), N = (0, l.PA)((t2) => {
        var e2, i2;
        let {
          className: l2,
          track: g2,
          withLightning: A2,
          ignoreDislikedStyles: h2,
          onLikeClick: N2,
          utmLink: j,
          withSecondaryColor: I,
          handleRemove: P,
          withTrailer: L = true,
          likeIconSize: f = "xxs",
          removeButtonAriaLabel: D
        } = t2, { user: S, trailer: R } = (0, v.Pjs)(), { formatMessage: M } = (0, n.A)(), { sendLikeSearchFeedback: E } = (0, v.zEv)(), [O, K] = (0, s.useState)(false), [w, B] = (0, s.useState)(false), U = (0, v.PT7)(), z = (0, p.KX)(g2), G = (0, v.PMf)(Math.round((null != (i2 = g2.durationMs) ? i2 : 0) / 1e3)), $ = (0, v.Ftl)(), q = S.hasPlus, F = (0, u.c)(async () => {
          O || g2.isLiked || (K(true), null == E || E()), await z(), null == N2 || N2(g2.isLiked);
        }), X = (0, u.c)((t3) => {
          t3.stopPropagation();
        }), Y = (0, u.c)((t3) => {
          if (t3.stopPropagation(), U()) return void t3.preventDefault();
          R.openTrackTrailer(g2.id), $(c.ky.Track, g2.id);
        }), V = (0, s.useMemo)(() => {
          if (!g2.isRemoved && g2.isAvailable)
            return (0, a.jsx)("div", {
              onClick: X,
              children: (0, a.jsx)(T.TrackContextMenu, {
                track: g2,
                open: w,
                onOpenChange: B,
                placement: "bottom",
                icon: (0, a.jsx)(m.Icon, { size: "xs", variant: "more" }),
                size: "xs",
                utmLink: j,
                className: (0, r.$)(y().contextMenu, { [y().contextMenu_visible]: w }),
                handleRemove: P,
                withTrailer: L,
                ...(0, d.Am)(d.Kq.track.TRACK_CONTEXT_MENU_BUTTON)
              })
            });
        }, [X, P, w, L, g2, j]);
        return (0, a.jsxs)("div", {
          className: (0, r.$)(y().root, y().controls, l2, {
            [y().controls_dislikedControls]: g2.isDisliked,
            [y().controls_dislikedColors]: g2.isDisliked && !h2,
            [y().controls_disabled]: !g2.isAvailable,
            [y().root_withSecondaryColor]: I
          }),
          children: [
            A2 && (0, a.jsx)(m.Icon, {
              "aria-label": M({ id: "entity-names.popular-among-users" }),
              size: "xxs",
              className: y().lightning,
              variant: "lightning"
            }),
            g2.isUGC && (0, a.jsxs)(k.m_, {
              placement: "bottom",
              offsetOptions: 8,
              children: [
                (0, a.jsx)(m.Icon, {
                  "aria-label": M({ id: "ugc.track-description" }),
                  size: "xxs",
                  className: y().ugcIcon,
                  variant: "eye_crossed",
                  ...(0, d.Am)(d.Kq.track.UGC_TRACK_ICON)
                }),
                (0, a.jsx)(k.ZI, { children: (0, a.jsx)(o.A, { id: "ugc.track-description" }) })
              ]
            }),
            q && (0, a.jsx)("div", {
              className: (0, r.$)(y().item, y().downloadIcon),
              children: (0, a.jsx)(b, { track: g2 })
            }),
            P && (0, a.jsx)(p.d0, {
              size: "xs",
              iconSize: "xxs",
              className: (0, r.$)(y().item, y().removeButton),
              onClick: P,
              ariaLabel: D
            }),
            !g2.isRemoved && g2.isAvailable && (0, a.jsx)(C.aQ, {
              fallback: (0, a.jsx)(C.cy, {
                size: "xs",
                iconSize: f,
                className: (0, r.$)(y().item, y().likeIcon),
                isLiked: g2.isLiked,
                onClick: F,
                disabled: !S.isAuthorized
              })
            }),
            (null == (e2 = g2.trailer) ? void 0 : e2.isAvailable) && g2.isAvailable && (0, a.jsx)(C.aQ, {
              fallback: (0, a.jsx)(C.kJ, {
                className: (0, r.$)(y().item, y().trailerIcon),
                iconSize: "xs",
                variant: "text",
                onClick: Y,
                withRipple: false
              })
            }),
            (0, a.jsxs)("div", {
              className: (0, r.$)(y().item, y().contextMenuWrapper),
              children: [
                "number" == typeof g2.durationMs && (0, a.jsx)(_.Caption, {
                  variant: "span",
                  className: (0, r.$)(y().duration, { [y().duration_hidden]: w }),
                  type: "entity",
                  size: "m",
                  weight: "medium",
                  "aria-label": G,
                  role: "text",
                  ...(0, d.Am)(d.Kq.track.TRACK_DURATION),
                  children: (0, a.jsx)("span", { "aria-hidden": "true", children: (0, x.h)(g2.durationMs) })
                }),
                V
              ]
            })
          ]
        });
      });
    },
    76858: (t, e, i) => {
      "use strict";
      i.d(e, { AudiobookMeta: () => b });
      var a = i(54486), r = i(50420), l = i(28303), s = i(61910), n = i(43426), o = i(47713), c = i(31500), d = i(93666), u = i(97800), m = i(63695), k = i(54460), _ = i(74125), p = i(80585), v = i(17251), C = i(43326), x = i(69151), T = i(36386), g = i(87306), y = i.n(g), A = i(83112), h = i.n(A);
      let b = (0, l.PA)((t2) => {
        var e2, i2, l2, g2;
        let {
          track: A2,
          className: b2,
          withAuthor: N = false,
          withSecondaryColor: j = false,
          withListeningProgress: I = false,
          captionSize: P = "m",
          explicitSize: L = "xs",
          withExplicitMark: f = true,
          titleContainerClassName: D,
          textClassName: S,
          playContextParams: R,
          withTimeLeftText: M = true,
          ignoreDislikedStyles: E,
          albumArtists: O,
          withCustomTooltip: K = true,
          hasLineClamp: w = true,
          withSavingQueryParams: B,
          beforeTitle: U,
          afterTitle: z,
          withContextMenuArtists: G,
          withArtistLink: $ = true
        } = t2, {
          sonataState: q,
          settings: { isMobile: F }
        } = (0, _.Pjs)(), { formatMessage: X } = (0, n.A)(), Y = (0, C.$)({ withCustomTooltip: K }), V = (0, x.useOnTrackLinkClick)({ track: A2, withSavingQueryParams: B, entityType: _.nPY.AUDIOBOOK }), Q = !!(I && R && A2.shouldRememberPosition && A2.streamProgress && A2.durationMs), W = A2.id === (null == (e2 = q.entityMeta) ? void 0 : e2.id) && (null == (l2 = q.entityMeta) || null == (i2 = l2.streamProgress) ? void 0 : i2.endPositionSec), H = (0, T.d)(Q, A2.streamProgress, W), J = (0, s.useMemo)(() => (0, v.s)(A2.artists, O), [A2.artists, O, A2.id]), Z = J.length > 0 && N && !H, tt = (0, s.useCallback)(
          (t3) => (0, a.jsx)(d.m_, {
            enabled: Y && !F,
            offsetOptions: 4,
            placement: "top",
            text: A2.title,
            hoverSettings: _.VP$,
            children: (0, a.jsx)(u.Caption, {
              className: y().title,
              type: "entity",
              size: P,
              variant: "span",
              title: Y ? void 0 : A2.title,
              ...t3,
              children: A2.title
            })
          }),
          [F, Y, P, A2.title]
        ), te = (0, s.useMemo)(() => {
          if (A2.isRemoved) return (0, a.jsx)(o.A, { id: "track-title.audiobook-not-found" });
          if (A2.hasTrackLink) {
            var t3;
            return (0, a.jsx)(p.N_, {
              "aria-label": X(
                { id: "entity-names.audiobook-name" },
                { bookName: null == (t3 = A2.mainAlbum) ? void 0 : t3.title }
              ),
              className: y().albumLink,
              href: A2.url,
              title: Y ? void 0 : A2.title,
              onClick: V,
              ...(0, c.Am)(c.Kq.track.TRACK_TITLE),
              children: tt()
            });
          }
          return tt((0, c.Am)(c.Kq.track.TRACK_TITLE));
        }, [A2.isRemoved, A2.hasTrackLink, null == (g2 = A2.mainAlbum) ? void 0 : g2.title, A2.title, A2.url, tt, X, Y, V]), ti = (0, s.useMemo)(() => +!!w, [w]);
        return (0, a.jsx)("div", {
          className: (0, r.$)(
            y().root,
            {
              [y().root_disabled]: !A2.isAvailable,
              [y().root_disliked]: A2.isDisliked && !E,
              [y().root_withSecondaryColor]: j
            },
            b2
          ),
          children: (0, a.jsxs)("div", {
            className: (0, r.$)(y().metaContainer, h().metaContainer, { [h().metaContainer_oneLine]: !N }),
            children: [
              (0, a.jsxs)("div", {
                className: (0, r.$)(y().titleContainer, D, h().titleContainer),
                children: [
                  (0, a.jsxs)(u.Caption, {
                    className: (0, r.$)(y().text, S),
                    type: "entity",
                    size: P,
                    variant: "div",
                    lineClamp: 1,
                    children: [
                      U,
                      te,
                      !A2.isRemoved && A2.version && (0, a.jsxs)(u.Caption, {
                        className: (0, r.$)(y().text, y().version),
                        type: "entity",
                        size: P,
                        weight: "medium",
                        variant: "span",
                        title: Y ? void 0 : A2.version,
                        children: [" ", A2.version]
                      })
                    ]
                  }),
                  A2.explicitDisclaimer && f && (0, a.jsx)(p.Nq, {
                    containerClassName: y().explicitMarkContainer,
                    getDescriptionTexts: A2.getDescriptionTexts,
                    variant: A2.explicitDisclaimer,
                    className: y().explicitMark,
                    size: L,
                    trackId: A2.id
                  }),
                  z
                ]
              }),
              Z && (0, a.jsx)(u.Caption, {
                type: "entity",
                size: P,
                variant: "div",
                lineClamp: 1,
                className: (0, r.$)(y().text, h().artists, S),
                children: (0, a.jsx)(m.iQ, {
                  className: (0, r.$)(y().text, { [y().artists]: w }, S),
                  linkClassName: (0, r.$)(y().text, y().link),
                  captionClassName: (0, r.$)(y().text, y().artistCaption),
                  artists: J,
                  withLink: A2.isNonUserGenerated && $,
                  lineClamp: ti,
                  captionSize: P,
                  withContextMenu: G
                })
              }),
              Q && A2.streamProgress && R && (0, a.jsx)(k.Bg, {
                className: (0, r.$)(h().progress, {
                  [h().progress_withPreviousInfo]: Z,
                  [h().progress_disabled]: !A2.isAvailable || A2.isDisliked
                }),
                id: A2.id,
                albumId: A2.albumId,
                streamProgress: A2.streamProgress,
                durationMs: A2.durationMs || 0,
                playContextParams: R,
                withTimeLeftText: M
              })
            ]
          })
        });
      });
    },
    77710: (t, e, i) => {
      "use strict";
      var a;
      i.d(e, { b: () => a }), (function(t2) {
        t2.Album = "album", t2.Artist = "artist", t2.Playlist = "playlist", t2.Radio = "fm_radio", t2.Other = "other", t2.Search = "search";
      })(a || (a = {}));
    },
    78571: (t, e, i) => {
      "use strict";
      i.d(e, { O: () => o });
      var a = i(54486), r = i(50420), l = i(5956), s = i(35415), n = i.n(s);
      let o = (t2) => {
        let { isDragging: e2, className: i2 } = t2;
        return (0, a.jsx)(l.Icon, {
          variant: "dragDots",
          size: "xxs",
          className: (0, r.$)(n().root, { [n().root_active]: e2 }, i2),
          "aria-hidden": true
        });
      };
    },
    79045: (t, e, i) => {
      "use strict";
      i.d(e, { TrackPlaylist: () => C });
      var a = i(54486), r = i(50420), l = i(28303), s = i(61910), n = i(31500), o = i(8817), c = i(74125), d = i(80585), u = i(78571), m = i(76130), k = i(12938), _ = i(23728), p = i(91759), v = i.n(p);
      let C = (0, l.PA)((t2) => {
        var e2;
        let {
          track: i2,
          playContextParams: l2,
          className: p2,
          withDNDBlock: C2,
          isDragging: x,
          draggingClassName: T,
          ignoreDislikedStyles: g,
          withSecondaryColor: y,
          activeFilter: A,
          activeFilterIndex: h,
          handleRemove: b,
          withDislike: N,
          withTrailer: j = true,
          beforeTitle: I,
          removeButtonAriaLabel: P
        } = t2, L = (0, c.Dx4)({ playContextParams: l2, entityId: i2.entityId }), {
          settings: { isMobile: f }
        } = (0, c.Pjs)(), D = (0, c.Nap)({ objectId: i2.id, tabId: A, tabPos: h }), S = (0, o.c)((t3) => {
          t3 && D();
        }), R = (0, s.useCallback)(
          (t3) => (0, a.jsx)(d.q1, {
            isAvailable: i2.isAvailable,
            isDisliked: i2.isDisliked,
            coverUri: i2.coverUri,
            title: i2.title,
            className: v().playButtonCell,
            ignoreDislikedStyles: g,
            radius: "xs",
            ...t3
          }),
          [g, i2.coverUri, i2.isAvailable, i2.isDisliked, i2.title]
        );
        return (0, a.jsx)(_.Track, {
          className: (0, r.$)(p2, { [v().trackWithDots]: C2, [v().important]: C2 }),
          track: i2,
          beforeBlock: C2 ? (0, a.jsx)(u.O, { className: (0, r.$)(v().dots, T), isDragging: x }) : void 0,
          meta: (0, a.jsx)(k.TrackMeta, {
            withArtistLink: !f,
            beforeTitle: I,
            track: i2,
            ignoreDislikedStyles: g,
            withSecondaryColor: y
          }),
          playButtonCellRender: R,
          controls: (0, a.jsx)(m.ControlsBar, {
            track: i2,
            className: v().controlsBarCell,
            ignoreDislikedStyles: g,
            utmLink: null == (e2 = l2.contextData) ? void 0 : e2.utmLink,
            withSecondaryColor: y,
            handleRemove: b,
            withDislike: N,
            withTrailer: j,
            removeButtonAriaLabel: P
          }),
          onPlayClick: S,
          ...L,
          ...(0, n.Am)(n.Kq.track.TRACK_PLAYLIST)
        });
      });
    },
    79971: (t, e, i) => {
      "use strict";
      i.d(e, { TrackAlbum: () => _ });
      var a = i(54486), r = i(28303), l = i(61910), s = i(31500), n = i(74125), o = i(76130), c = i(12938), d = i(16479), u = i(23728), m = i(94169), k = i.n(m);
      let _ = (0, r.PA)((t2) => {
        let { track: e2, albumArtists: i2, position: r2, playContextParams: m2, withLightning: _2 } = t2, p = (0, n.Dx4)({ playContextParams: m2, entityId: e2.entityId }), {
          settings: { isMobile: v }
        } = (0, n.Pjs)(), C = (0, l.useCallback)(
          (t3) => (0, a.jsx)(d.G, { track: e2, position: r2, className: k().playButtonCell, ...t3 }),
          [e2, r2]
        );
        return (0, a.jsx)(u.Track, {
          track: e2,
          withLightning: _2,
          meta: (0, a.jsx)(c.TrackMeta, { withArtistLink: !v, albumArtists: i2, track: e2, withSavingQueryParams: true }),
          playButtonCellRender: C,
          controls: (0, a.jsx)(o.ControlsBar, {
            withLightning: _2,
            track: e2,
            className: k().controlsBarCell,
            utmLink: m2.contextData.utmLink
          }),
          ...p,
          ...(0, s.Am)(s.Kq.track.TRACK_ALBUM)
        });
      });
    },
    81510: (t) => {
      t.exports = { writers: "Lyrics_writers__xvrNp" };
    },
    83112: (t) => {
      t.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        explicitMark: "AudiobookMeta_explicitMark__1rN7x",
        metaContainer: "AudiobookMeta_metaContainer__F7d9X",
        metaContainer_oneLine: "AudiobookMeta_metaContainer_oneLine__D9CQh",
        titleContainer: "AudiobookMeta_titleContainer__GIY6Q",
        artists: "AudiobookMeta_artists__ScMoq",
        progress: "AudiobookMeta_progress__i3_kS",
        progress_disabled: "AudiobookMeta_progress_disabled__D_7E9",
        progress_withPreviousInfo: "AudiobookMeta_progress_withPreviousInfo__97Hxr"
      };
    },
    83333: (t, e, i) => {
      "use strict";
      i.d(e, { J: () => r });
      var a = i(74125);
      let r = function(t2) {
        let e2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, { href: i2 } = (0, a.uvd)(a.Zyd.video.href, {
          query: { [a.K3F.IDS]: t2.join(","), [a.K3F.ACTIVE_INDEX]: String(e2) }
        });
        return i2;
      };
    },
    83635: (t) => {
      t.exports = {
        cancelIcon: "TrackContextMenuDownloadItem_cancelIcon__0YF_e",
        root: "TrackContextMenuDownloadItem_root__BALdW",
        downloadingProgress: "TrackContextMenuDownloadItem_downloadingProgress__Xmtgm",
        progress: "TrackContextMenuDownloadItem_progress__FMBws"
      };
    },
    85905: (t, e, i) => {
      "use strict";
      i.d(e, { TrackUgcUpload: () => v });
      var a = i(54486), r = i(50420), l = i(28303), s = i(61910), n = i(43426), o = i(47713), c = i(31500), d = i(77881), u = i(97800), m = i(54460), k = i(80585), _ = i(29799), p = i.n(_);
      let v = (0, l.PA)((t2) => {
        var e2;
        let { className: i2, track: l2 } = t2, { formatMessage: _2 } = (0, n.A)(), v2 = null == (e2 = l2.file) ? void 0 : e2.name, C = (0, s.useCallback)(() => {
          l2.abortUpload();
        }, [l2]), x = (0, s.useCallback)(() => {
          l2.retryUpload();
        }, [l2]), T = (0, s.useMemo)(
          () => (0, a.jsx)(d.$, {
            variant: "text",
            withRipple: false,
            "aria-label": _2({ id: "ugc.cancel-upload" }),
            color: "primary",
            onClick: C,
            ...(0, c.Am)(c.Kq.track.UGC_TRACK_CANCEL_UPLOAD_BUTTON),
            children: (0, a.jsx)(u.Caption, {
              variant: "span",
              size: "m",
              type: "text",
              className: p().button,
              children: (0, a.jsx)(o.A, { id: "ugc.cancel-upload" })
            })
          }),
          [C, _2]
        ), g = (0, s.useMemo)(
          () => (0, a.jsx)(d.$, {
            variant: "text",
            withRipple: false,
            "aria-label": _2({ id: "ugc.repeat-upload" }),
            color: "primary",
            onClick: x,
            ...(0, c.Am)(c.Kq.track.UGC_TRACK_RETRY_UPLOAD_BUTTON),
            children: (0, a.jsx)(u.Caption, {
              variant: "span",
              size: "m",
              type: "text",
              className: p().button,
              children: (0, a.jsx)(o.A, { id: "ugc.repeat-upload" })
            })
          }),
          [_2, x]
        ), y = (0, s.useMemo)(() => {
          switch (l2.loadingState) {
            case m.pK.IDLE:
            case m.pK.PREPARE:
            case m.pK.UPLOADING:
              return T;
            case m.pK.REJECT:
              return g;
            default:
              return null;
          }
        }, [T, g, l2.loadingState]), A = (0, s.useMemo)(() => {
          switch (l2.loadingState) {
            case m.pK.IDLE:
            case m.pK.PREPARE:
            case m.pK.UPLOADING:
              return (0, a.jsx)(u.Caption, {
                variant: "div",
                size: "m",
                className: p().status,
                ...(0, c.Am)(c.Kq.track.UGS_TRACK_UPLOADING_PENDING_STATUS_TEXT),
                children: (0, a.jsx)(o.A, { id: "ugc.track-uploading-pending-status" })
              });
            case m.pK.PROCESSING:
            case m.pK.RESOLVE:
              return (0, a.jsx)(u.Caption, {
                variant: "div",
                size: "m",
                className: p().status,
                children: (0, a.jsx)(o.A, { id: "ugc.track-uploading-processing-status" })
              });
            case m.pK.REJECT:
              return (0, a.jsx)(u.Caption, {
                variant: "div",
                size: "m",
                className: p().status,
                ...(0, c.Am)(c.Kq.track.UGC_TRACK_UPLOADING_ERROR_STATUS_TEXT),
                children: (0, a.jsx)(o.A, { id: "ugc.track-uploading-error-status" })
              });
            default:
              return null;
          }
        }, [l2.loadingState]);
        return (0, a.jsxs)(k.Cj, {
          "aria-label": v2,
          className: (0, r.$)(p().root, p().card, p().important, i2),
          ...(0, c.Am)(c.Kq.track.UGC_TRACK),
          children: [
            (0, a.jsx)(k.q1, { title: v2, radius: "xs", className: p().playButton }),
            (0, a.jsxs)("div", {
              className: p().meta,
              children: [
                (0, a.jsx)(u.Caption, {
                  variant: "div",
                  size: "m",
                  className: p().title,
                  ...(0, c.Am)(c.Kq.track.UGC_TRACK_TITLE),
                  children: v2
                }),
                A
              ]
            }),
            (0, a.jsx)("div", { className: p().controls, children: y })
          ]
        });
      });
    },
    86062: (t, e, i) => {
      "use strict";
      i.d(e, { useTrackAboutModalTitle: () => l });
      var a = i(43426), r = i(8075);
      let l = (t2) => {
        var e2;
        let { formatMessage: i2 } = (0, a.A)();
        return i2(
          (null == t2 ? void 0 : t2.type) === r.S.AUDIOBOOK ? { id: "track-modal.audiobook-title" } : (null == t2 ? void 0 : t2.isTrackPodcast) || (null == t2 || null == (e2 = t2.mainAlbum) ? void 0 : e2.isPodcast) ? { id: "track-modal.podcast-title" } : { id: "track-modal.title" }
        );
      };
    },
    87306: (t) => {
      t.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        artistCaption: "Meta_artistCaption__JESZi",
        link: "Meta_link__IFDBA",
        albumTitle: "Meta_albumTitle__mHeOs",
        root: "Meta_root__R8n1h",
        root_withSecondaryColor: "Meta_root_withSecondaryColor___uENY",
        root_disabled: "Meta_root_disabled__Dpx_M",
        albumLink: "Meta_albumLink__gASh6",
        artists: "Meta_artists__VnR52",
        explicitMark: "Meta_explicitMark__ocnCV",
        title: "Meta_title__GGBnH",
        titleContainer: "Meta_titleContainer__gDuXr",
        version: "Meta_version__c2sHU",
        root_disliked: "Meta_root_disliked__DrZ7_",
        text: "Meta_text__Y5uYH",
        explicitMarkContainer: "Meta_explicitMarkContainer__BxMQg",
        metaContainer: "Meta_metaContainer__7i2dp",
        titleContainer_withVersion: "Meta_titleContainer_withVersion__n7MdY"
      };
    },
    88948: (t) => {
      t.exports = {
        root: "ContextMenuPlaylistsList_root__Greny",
        listPlaylist: "ContextMenuPlaylistsList_listPlaylist__0oWLm",
        shimmerEndItem: "ContextMenuPlaylistsList_shimmerEndItem__1K0_w",
        favouritesPlaylistItem: "ContextMenuPlaylistsList_favouritesPlaylistItem__qYrTR",
        icon: "ContextMenuPlaylistsList_icon__Fhxnh"
      };
    },
    89324: (t) => {
      t.exports = {
        root: "TrackCard_root__kIpe1",
        controls: "TrackCard_controls__E7Y3L",
        cover: "TrackCard_cover__tkVPB",
        coverBlock: "TrackCard_coverBlock__WdvvQ",
        coverBlock_withTrackLink: "TrackCard_coverBlock_withTrackLink__fDe6k",
        image: "TrackCard_image__KsOFF",
        artists: "TrackCard_artists__wH48n",
        artistLink: "TrackCard_artistLink__aqLl7",
        titleContainer: "TrackCard_titleContainer__YCcZk",
        titleContainer_withVersion: "TrackCard_titleContainer_withVersion__fTRGu",
        title: "TrackCard_title__BVLuv",
        titleLink: "TrackCard_titleLink__NtPhm",
        version: "TrackCard_version__7iPuj",
        playButton: "TrackCard_playButton__ukJDd",
        likeButton: "TrackCard_likeButton__Hejrk",
        menuButton: "TrackCard_menuButton__XtYLf",
        trailerButton: "TrackCard_trailerButton__nGqhD",
        control: "TrackCard_control___huPc"
      };
    },
    91759: (t) => {
      t.exports = {
        playButtonCell: "TrackPlaylist_playButtonCell__Q6YT_",
        controlsBarCell: "TrackPlaylist_controlsBarCell__6clda",
        dots: "TrackPlaylist_dots__nLYej",
        trackWithDots: "TrackPlaylist_trackWithDots__EU6LD",
        important: "TrackPlaylist_important__n8Tjb"
      };
    },
    92810: (t, e, i) => {
      "use strict";
      i.d(e, { PromoLandingTrackAlbum: () => L });
      var a = i(54486), r = i(28303), l = i(61910), s = i(74125), n = i(50420), o = i(43426), c = i(31500), d = i(5956), u = i(97800), m = i(54460), k = i(80585), _ = i(53700), p = i(57104), v = i.n(p);
      let C = (0, r.PA)((t2) => {
        let { className: e2, track: i2, withLightning: r2 } = t2, {
          settings: { isMobile: l2 }
        } = (0, s.Pjs)(), { formatMessage: p2 } = (0, o.A)(), C2 = (0, m.c5)(i2);
        return (0, a.jsxs)("div", {
          className: (0, n.$)(v().root, v().controls, e2, { [v().controls_disabled]: !i2.isAvailable }),
          children: [
            r2 && (0, a.jsx)(d.Icon, {
              "aria-label": p2({ id: "entity-names.popular-among-users" }),
              size: "xxs",
              className: (0, n.$)(v().lightning, { [v().lightning_withOffset]: l2 }),
              variant: "lightning"
            }),
            !i2.isRemoved && i2.isAvailable && (0, a.jsx)(k.cy, {
              size: "xs",
              iconSize: "xxs",
              className: (0, n.$)(v().item, v().likeIcon),
              isLiked: i2.isLiked,
              onClick: C2
            }),
            !l2 && "number" == typeof i2.durationMs && (0, a.jsx)("div", {
              className: (0, n.$)(v().item, v().contextMenuWrapper),
              children: (0, a.jsx)(u.Caption, {
                variant: "span",
                className: (0, n.$)(v().duration, v().alwaysVisibleDuration),
                type: "entity",
                size: "m",
                weight: "medium",
                ...(0, c.Am)(c.Kq.track.TRACK_DURATION),
                children: (0, _.h)(i2.durationMs)
              })
            })
          ]
        });
      });
      var x = i(12938), T = i(16479), g = i(8817), y = i(73633), A = i(855), h = i(47937), b = i(95953), N = i.n(b);
      let j = (0, r.PA)((t2) => {
        let {
          className: e2,
          track: i2,
          meta: r2,
          beforeBlock: l2,
          controls: o2,
          playButtonCellRender: d2,
          withLightning: u2,
          isPlaying: m2,
          isCurrent: _2,
          togglePlay: p2,
          restartPlay: v2,
          onPlayClick: C2,
          ...x2
        } = t2, { ref: T2, intersectionPropertyId: b2 } = (0, s.nMI)(), j2 = (0, s.brA)(), I2 = (0, A.W)({ withLightning: u2, track: i2 }), {
          settings: { isMobile: P2 }
        } = (0, s.Pjs)(), L2 = (0, h.useTrackDisclaimer)({ track: i2, callback: p2 }), f = (0, g.c)(() => {
          L2(), j2(!m2), null == C2 || C2(!m2);
        }), D = (0, g.c)(() => {
          if (m2) return void v2();
          f();
        }), S = (0, g.c)((t3) => {
          if (i2.isAvailable || i2.hasModalAccess) {
            if ((0, y.P)(t3, N().ripple), P2) return void f();
            2 === t3.detail && D();
          }
        }), R = null == d2 ? void 0 : d2({ onPlayButtonClick: f, isPlaying: m2, isCurrent: _2 });
        return (0, a.jsxs)(k.Cj, {
          ref: T2,
          "aria-label": I2,
          "data-intersection-property-id": b2,
          onClick: S,
          ...(0, c.Am)(c.Kq.track.TRACK_PROMOLANDING),
          className: (0, n.$)(N().root, { [N().root_disabled]: !i2.isAvailable }, e2),
          ...x2,
          children: [l2, R, r2, o2]
        });
      });
      var I = i(39757), P = i.n(I);
      let L = (0, r.PA)((t2) => {
        let { track: e2, albumArtists: i2, position: r2, playContextParams: n2, withLightning: o2 } = t2, { promolanding: c2 } = (0, s.Pjs)(), d2 = (0, s.Dx4)({
          playContextParams: n2,
          entityId: e2.entityId,
          playbackId: s.V_r.PROMO_LANDING,
          sonataState: c2.state
        }), u2 = (0, l.useCallback)(
          (t3) => (0, a.jsx)(T.G, { track: e2, position: r2, className: P().playButtonCell, withDislikeStyles: false, ...t3 }),
          [e2, r2]
        );
        return (0, a.jsx)(j, {
          track: e2,
          withLightning: o2,
          meta: (0, a.jsx)(x.TrackMeta, {
            ignoreDislikedStyles: true,
            withArtistLink: false,
            withAlbumLink: false,
            withTrackLink: false,
            albumArtists: i2,
            track: e2,
            withSavingQueryParams: true
          }),
          playButtonCellRender: u2,
          controls: (0, a.jsx)(C, { withLightning: o2, track: e2, className: P().controlsBarCell }),
          ...d2
        });
      });
    },
    93549: (t, e, i) => {
      "use strict";
      i.d(e, { TrackChart: () => p });
      var a = i(54486), r = i(28303), l = i(61910), s = i(31500), n = i(42140), o = i(74125), c = i(80585), d = i(76130), u = i(12938), m = i(23728), k = i(99751), _ = i.n(k);
      let p = (0, r.PA)((t2) => {
        var e2, i2;
        let { track: r2, playContextParams: k2 } = t2, p2 = (0, o.Dx4)({ playContextParams: k2, entityId: r2.entityId }), {
          settings: { isMobile: v }
        } = (0, o.Pjs)(), C = (0, l.useCallback)(
          (t3) => (0, a.jsx)(c.q1, {
            isAvailable: r2.isAvailable,
            isDisliked: r2.isDisliked,
            coverUri: r2.coverUri,
            title: r2.title,
            className: _().playButtonCell,
            radius: "xs",
            ...t3
          }),
          [r2]
        );
        return (0, a.jsx)(m.Track, {
          track: r2,
          meta: (0, a.jsx)(u.TrackMeta, { withArtistLink: !v, track: r2 }),
          beforeBlock: (0, a.jsx)(n.t1, {
            withIcon: true,
            className: _().chartCell,
            progress: null == (e2 = r2.chart) ? void 0 : e2.progress,
            position: null == (i2 = r2.chart) ? void 0 : i2.position,
            isDisliked: r2.isDisliked,
            isDisabled: !r2.isAvailable
          }),
          playButtonCellRender: C,
          controls: (0, a.jsx)(d.ControlsBar, { track: r2, className: _().controlsBarCell }),
          ...p2,
          ...(0, s.Am)(s.Kq.track.TRACK_CHART)
        });
      });
    },
    93719: (t) => {
      t.exports = {
        downloadingProgress: "TrackDownloadControl_downloadingProgress__wNg2W",
        progress: "TrackDownloadControl_progress__K_OhO"
      };
    },
    94169: (t) => {
      t.exports = {
        playButtonCell: "TrackAlbum_playButtonCell__pLJte",
        controlsBarCell: "TrackAlbum_controlsBarCell__XUUCc"
      };
    },
    95953: (t) => {
      t.exports = {
        root: "CommonTrack_root__i6shE",
        root_disabled: "CommonTrack_root_disabled__vDyCm",
        root_current: "CommonTrack_root_current__MNrpS",
        ripple: "CommonTrack_ripple__wnpUs"
      };
    },
    97778: (t, e, i) => {
      "use strict";
      i.d(e, { SearchTrackCard: () => T });
      var a = i(54486), r = i(50420), l = i(28303), s = i(61910), n = i(31500), o = i(63585), c = i(77710), d = i(8075), u = i(8817), m = i(73633), k = i(74125), _ = i(80585), p = i(47937), v = i(76130), C = i(54586), x = i(12938);
      let T = (0, l.PA)((t2) => {
        var e2;
        let { className: i2, track: l2, pageId: T2 } = t2, { shouldShowBuySubscriptionModal: g, showBuySubscriptionModal: y } = (0, k.qBP)(), { ref: A, intersectionPropertyId: h } = (0, k.nMI)(), {
          track: b,
          settings: { isMobile: N }
        } = (0, k.Pjs)(), { from: j } = (0, k.fyy)({ pageId: T2 }), I = (0, k.brA)(), {
          isPlaying: P,
          isCurrent: L,
          togglePlay: f,
          restartPlay: D
        } = (0, k.Dx4)({
          playContextParams: {
            contextData: { type: o.K.Various, meta: { id: l2.entityId }, from: j, overrideContextType: c.b.Search },
            queueParams: { index: 0, entityId: l2.id },
            loadContextMeta: true
          },
          entityId: l2.entityId
        }), S = (0, k.PT7)(), R = (0, p.useTrackDisclaimer)({ track: l2, callback: f }), M = (0, s.useCallback)(() => {
          b.open({ trackId: l2.id, albumId: l2.albumId });
        }, [b, l2.id, l2.albumId]), E = (0, p.useTrackDisclaimer)({ track: l2, callback: M }), { sendPlaySearchFeedback: O } = (0, k.zEv)(), [K, w] = (0, s.useState)(false), B = (0, u.c)(() => {
          if (!S()) {
            if (g) return void y();
            K || P || (w(true), null == O || O()), R(), I(!P);
          }
        }), U = (0, u.c)(() => {
          if (P) return void D();
          B();
        }), z = (0, u.c)((t3) => {
          if (!l2.isAvailable && !l2.hasModalAccess) {
            g && l2.isAvailableOnlyForPlus && y();
            return;
          }
          return g ? void y() : ((0, m.P)(t3, _.$f.ripple), 2 === t3.detail) ? void U() : void (1 === t3.detail && l2.hasTrackLink && E());
        }), G = (0, s.useCallback)(
          (t3) => (0, a.jsx)(_.q1, {
            isAvailable: l2.isAvailable,
            isDisliked: l2.isDisliked,
            coverUri: l2.coverUri,
            title: l2.title,
            className: _.$f.playButtonCell,
            radius: "xs",
            ...t3
          }),
          [l2]
        ), $ = null == G ? void 0 : G({ onPlayButtonClick: B, isPlaying: P, isCurrent: L });
        return (0, a.jsxs)(_.Cj, {
          ref: A,
          "data-intersection-property-id": h,
          className: (0, r.$)(_.$f.root, i2),
          "aria-label": "".concat(l2.artistsNames, " ").concat(l2.title, " ").concat(null != (e2 = l2.version) ? e2 : ""),
          onClick: z,
          ...(0, n.Am)(n.Kq.track.SEARCH_TRACK_CARD),
          children: [
            $,
            l2.type === d.S.PODCAST ? (0, a.jsx)(C.PodcastMeta, {
              track: l2,
              playContextParams: {
                contextData: { type: o.K.Various, meta: { id: l2.entityId }, from: j },
                queueParams: { index: 0 },
                loadContextMeta: true
              },
              withPodcastName: true,
              withListeningProgress: true,
              withAlbumTitleLink: !N
            }) : (0, a.jsx)(x.TrackMeta, { withArtistLink: !N, track: l2 }),
            (0, a.jsx)(v.ControlsBar, { className: _.$f.controlsBarCell, track: l2 })
          ]
        });
      });
    },
    99751: (t) => {
      t.exports = {
        playButtonCell: "TrackChart_playButtonCell__cvY7u",
        controlsBarCell: "TrackChart_controlsBarCell__Xd5pn",
        chartCell: "TrackChart_chartCell__33_al"
      };
    }
  }
]);
