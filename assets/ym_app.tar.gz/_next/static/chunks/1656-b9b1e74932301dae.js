"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1656],
  {
    71656: (e, t, r) => {
      r.d(t, { c$: () => d, ms: () => f });
      var n, s = r(88834), a = r(94377), o = r(61910), i = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        1920: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            contentContainer: "JjlbHZ4FaP9EAcR_1DxF",
            contentContainer_block: "iOlzvyUREgDkthkrx7Sf",
            flexIcon: "WsKeF73pWotx9W1tWdYY",
            root: "cpeagBA1_PblpJn8Xgtv",
            root_withoutBorder: "qU2apWBO1yyEK0lZ3lPO",
            root_radius_xs: "MmZbSs387gu2qrJ1lDWd",
            root_radius_s: "mlcrraysn7mW6xrBXSBF",
            root_radius_m: "dgV08FKVLZKFsucuiryn",
            root_radius_l: "S97_5dtzhpxo_amtfYRg",
            root_radius_xl: "nNBJnDHRlyLTniWosJhk",
            root_radius_xxxl: "zIMibMuH7wcqUoW7KH1B",
            root_radius_round: "uwk3hfWzB2VT7kE13SQk",
            root_size: "IlG7b1K0AD7E7AMx6F5p",
            root_size_default: "C_QGmfTz6UFX93vfPt6Z",
            root_size_xxxs: "eQt33MLDiQ6DRSuLaYEp",
            root_size_xxs: "oR11LfCBVqMbUJiAgknd",
            root_size_xs: "j1jXIVckFgZECecFzZMe",
            root_size_s: "WtFdWDF44egSVM_YiMUX",
            root_size_m: "Y2uqxoU7xa_AZ8FUCVOW",
            root_size_l: "SGYcNjvjmMsXeEVGUV2Z",
            root_icon_left: "kc5CjvU5hT9KEj0iTt3C",
            root_icon_right: "et24Jf7pT_X9Fvc7TznR",
            root_primary: "fXlFz1qMkliFUWOkHo8T",
            root_primary_default: "_eTRQi5ADZCUvUKMZqJU",
            ripple: "spMT3NcRD9Yb0ntNaNct",
            root_primary_outline: "fCUSh2B0Ye9kEvceE8zc",
            root_primary_text: "qlPp6CSQQEMVZPqtqLiQ",
            root_primary_withHover: "KZF6_4K1p_Y_GMIAxaAn",
            root_primary_withHover_default: "rWukOKAJh5Ga7JuIp62L",
            root_primary_withHover_outline: "fdwWCJKgUqml5wNqrRcN",
            root_primary_withHover_text: "IgYbZLnYjW0nMahgpkus",
            root_secondary: "_T4p_w41oaq6L4sztSdw",
            root_secondary_default: "iJVAJMgccD4vj4E4o068",
            root_secondary_outline: "pnM3iSP9keZOELI2oohr",
            root_secondary_text: "UDMYhpDjiAFT3xUx268O",
            root_secondary_withHover: "qUbrkhZIOVrvM0roV1QF",
            root_secondary_withHover_default: "nHWc2sto1C6Gm0Dpw_l0",
            root_secondary_withHover_outline: "i5WuBm5mfG0mflk_1jH_",
            root_secondary_withHover_text: "HbaqudSqu7Q3mv3zMPGr",
            root_plus: "ixLRsIJ2FvXO2k04n_QY",
            root_plus_default: "yRHwHzEGfDgRXGzYJqw2",
            root_plus_outline: "e777irPFmyQFFrURLF_U",
            root_plus_text: "vRqDhvmt3gt8TFp45_Zw",
            root_plus_withHover: "TZif6q3I2RwBEYXwK_iA",
            root_plus_withHover_default: "k3DhvmzpnM_Fb9oFdE4q",
            root_plus_withHover_outline: "RiDWYwGIxqbrUPR699DM",
            root_plus_withHover_text: "hC_mMCzWjkTn2j9xZzGc",
            root_accent: "jqD2jMT6n7F0WKyqwMsn",
            root_accent_default: "bDp0r9MtoYECZ8ObMoCh",
            root_accent_outline: "rXNyGp8NBAw2MUjACZNj",
            root_accent_text: "hmV4ERaXWAJc4uPLZL30",
            root_accent_withHover: "uKuxXu1N4TP5cWaEK5Ke",
            root_accent_withHover_default: "t_hequUaUgAMhFuxizLb",
            root_accent_withHover_outline: "Oy9sPFTxNTo1_E29U4aF",
            root_accent_withHover_text: "LcKRSd3DLoh7k60Oqox8",
            root_withActiveSpinner: "nAGvO87rLs15SJgft6Hh",
            block: "BbCxxIjBGupN28bq2lSP",
            icon: "J9wTKytjOWG73QMoN5WP",
            icon_position_left: "elJfazUBui03YWZgHCbW",
            icon_position_right: "RBoEbyJKP5rEtLsXM1ji",
            icon_withButtonSize: "cE17_kCWJgx8kzQEkeVr",
            spinnerContainer: "STbBDGqYjUEcLuNvhu9w"
          };
        },
        7139: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "B4n8OdxhLWJhLyFqsefx",
            swipeIcon: "vuZQkmZ17j2PrMjlV_Xe",
            button: "p4iG7Cp_CDu1zdXubsSc",
            container: "XrtoMzIRQNFtCya4Uj_Y",
            container_mobile: "d_Dy0pjtAUkecSvJ4OkW",
            textContainer: "arHH121CVMJ1HftqBKkg"
          };
        },
        9184: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "moy62QJwl9MPl3EIySFq",
            button: "yX_R7bYjE0ELIFl0wvrT",
            icon: "Hit8edYVZ8_ejMJMo5G9",
            buttonText: "BnPanQExuLk6q6xa2NbF"
          };
        },
        2964: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_size_xxxs: "Rkdd2vKC_3xa1eUdRdHP",
            root_size_xxs: "l3tE1hAMmBj2aoPPwU08",
            root_size_xs: "UwnL5AJBMMAp6NwMDdZk",
            root_size_s: "DzJFnuf7XgdkFh28JAsM",
            root_size_m: "o_v2ds2BaqtzAsRuCVjw",
            root_size_l: "YjRa1ZjM_lXFlrfS7jcu",
            root_size_xl: "Seq0GowcqQmiA9LdLP_g",
            root_size_xxl: "mfy69_BvBIamD0e22rCQ",
            root_size_xxxl: "JY1OniQewgW9iHgfllZS"
          };
        },
        7820: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { overlay: "ZSjQrniulol6xKOq2Bou" };
        },
        4123: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "TYgwct6DZLAMvvFaBZ7z" };
        },
        5909: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "dJZf0Flxzx7PR15g7zqM" };
        },
        3641: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_controls_xxs: "tRaaBpDMg9Qu8v6gKjtn",
            root_entity_xxs: "M9zvtlcpLUVn6DKdcHhj",
            root_text_xxs: "ln0PYYwDmFnfYxCDJsFU",
            root_controls_xs: "n5AeWEsJC3_AYXcbK4Lt",
            root_entity_xs: "__hrMKGmNbw54T54IUyh",
            root_text_xs: "SehSa7OyRpC2nzYTVb2Q",
            root_controls_s: "_oBLf5gprWsKjCw4Ce58",
            root_entity_s: "mxSPe5xpZnie9gpIqacd",
            root_text_s: "Ai2iRN9elHpk_u5splD6",
            root_controls_m: "tk7ahHRDYXJMMB879KUA",
            root_entity_m: "Z_WIr2W8JU4MPQek3hgR",
            root_text_m: "g3qWNP6xl__7qxNmtrvd",
            root_controls_l: "grvxapJE3vGArOKDWf6n",
            root_entity_l: "Esj5A1UeSi4xV4tZ839D",
            root_text_l: "V3WU123oO65AxsprotU9",
            root_weight_normal: "ZYV27jeWd30QDXu4GhaH",
            root_weight_medium: "_3_Mxw7Si7j2g4kWjlpR",
            root_weight_bold: "Vi7Rd0SZWqD17F0872TB"
          };
        },
        5153: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_size_xs: "qJJ288377iHlWN_RXeEE",
            root_size_s: "_sd8Q9d_Ttn0Ufe4ISWS",
            root_size_m: "Ctk8dbecq31Qh7isOJPQ",
            root_size_l: "M_Djh6ppIkCO3A2k_BTA",
            root_size_xl: "dtxlzGQMPAbM2MEndXWX",
            root_size_xxl: "IUb9XLplTAoZqne9rNUL",
            root_size_xxxl: "ZYZamUwql_rfFR4RpI2B",
            root_size_xxxxl: "ZBZyxow5njdq8z5dnRPY",
            root_size_xxxxxl: "WdvQQNwdDNCdRSwRkAtT",
            root_weight_bold: "nSU6fV9y80WrZEfafvww",
            root_weight_black: "KBeGPPK4DinQzAP41Y_N"
          };
        },
        5818: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "_MWOVuZRvUQdXKTMcOPx",
            root_clamp: "LezmJlldtbHWqU7l1950",
            root_clamp_oneline: "oyQL2RSmoNbNQf3Vc6YI",
            root_clamp_multiline: "jMyoZB5J9iZbzJmWOrF0"
          };
        },
        6544: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { RemoveScroll: () => Y });
          var n2, s2, a2 = function() {
            return (a2 = Object.assign || function(e3) {
              for (var t3, r3 = 1, n3 = arguments.length; r3 < n3; r3++)
                for (var s3 in t3 = arguments[r3]) Object.prototype.hasOwnProperty.call(t3, s3) && (e3[s3] = t3[s3]);
              return e3;
            }).apply(this, arguments);
          };
          function o2(e3, t3) {
            var r3 = {};
            for (var n3 in e3) Object.prototype.hasOwnProperty.call(e3, n3) && 0 > t3.indexOf(n3) && (r3[n3] = e3[n3]);
            if (null != e3 && "function" == typeof Object.getOwnPropertySymbols)
              for (var s3 = 0, n3 = Object.getOwnPropertySymbols(e3); s3 < n3.length; s3++)
                0 > t3.indexOf(n3[s3]) && Object.prototype.propertyIsEnumerable.call(e3, n3[s3]) && (r3[n3[s3]] = e3[n3[s3]]);
            return r3;
          }
          Object.create;
          Object.create;
          var i2 = ("function" == typeof SuppressedError && SuppressedError, r2(810)), l2 = "right-scroll-bar-position", c2 = "width-before-scroll-bar";
          function u2(e3, t3) {
            return "function" == typeof e3 ? e3(t3) : e3 && (e3.current = t3), e3;
          }
          var f2 = i2.useLayoutEffect, d2 = /* @__PURE__ */ new WeakMap();
          function x(e3) {
            return e3;
          }
          var p = (function(e3) {
            void 0 === e3 && (e3 = {});
            var t3, r3, n3, s3 = (void 0 === t3 && (t3 = x), r3 = [], n3 = false, {
              read: function() {
                if (n3)
                  throw Error(
                    "Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`."
                  );
                return r3.length ? r3[r3.length - 1] : null;
              },
              useMedium: function(e4) {
                var s4 = t3(e4, n3);
                return r3.push(s4), function() {
                  r3 = r3.filter(function(e5) {
                    return e5 !== s4;
                  });
                };
              },
              assignSyncMedium: function(e4) {
                for (n3 = true; r3.length; ) {
                  var t4 = r3;
                  r3 = [], t4.forEach(e4);
                }
                r3 = {
                  push: function(t5) {
                    return e4(t5);
                  },
                  filter: function() {
                    return r3;
                  }
                };
              },
              assignMedium: function(e4) {
                n3 = true;
                var t4 = [];
                if (r3.length) {
                  var s4 = r3;
                  r3 = [], s4.forEach(e4), t4 = r3;
                }
                var a3 = function() {
                  var r4 = t4;
                  t4 = [], r4.forEach(e4);
                }, o3 = function() {
                  return Promise.resolve().then(a3);
                };
                o3(), r3 = {
                  push: function(e5) {
                    t4.push(e5), o3();
                  },
                  filter: function(e5) {
                    return t4 = t4.filter(e5), r3;
                  }
                };
              }
            });
            return s3.options = a2({ async: true, ssr: false }, e3), s3;
          })(), _ = function() {
          }, v = i2.forwardRef(function(e3, t3) {
            var r3, n3, s3, l3, c3 = i2.useRef(null), x2 = i2.useState({ onScrollCapture: _, onWheelCapture: _, onTouchMoveCapture: _ }), v2 = x2[0], g2 = x2[1], m2 = e3.forwardProps, k2 = e3.children, y2 = e3.className, b2 = e3.removeScrollBar, E2 = e3.enabled, w2 = e3.shards, h2 = e3.sideCar, O2 = e3.noIsolation, R2 = e3.inert, j2 = e3.allowPinchZoom, H2 = e3.as, P2 = e3.gapMode, C2 = o2(e3, [
              "forwardProps",
              "children",
              "className",
              "removeScrollBar",
              "enabled",
              "shards",
              "sideCar",
              "noIsolation",
              "inert",
              "allowPinchZoom",
              "as",
              "gapMode"
            ]), M2 = (r3 = [c3, t3], n3 = function(e4) {
              return r3.forEach(function(t4) {
                return u2(t4, e4);
              });
            }, (s3 = (0, i2.useState)(function() {
              return {
                value: null,
                callback: n3,
                facade: {
                  get current() {
                    return s3.value;
                  },
                  set current(value) {
                    var e4 = s3.value;
                    e4 !== value && (s3.value = value, s3.callback(value, e4));
                  }
                }
              };
            })[0]).callback = n3, l3 = s3.facade, f2(
              function() {
                var e4 = d2.get(l3);
                if (e4) {
                  var t4 = new Set(e4), n4 = new Set(r3), s4 = l3.current;
                  t4.forEach(function(e5) {
                    n4.has(e5) || u2(e5, null);
                  }), n4.forEach(function(e5) {
                    t4.has(e5) || u2(e5, s4);
                  });
                }
                d2.set(l3, r3);
              },
              [r3]
            ), l3), S2 = a2(a2({}, C2), v2);
            return i2.createElement(
              i2.Fragment,
              null,
              E2 && i2.createElement(h2, {
                sideCar: p,
                removeScrollBar: b2,
                shards: w2,
                noIsolation: O2,
                inert: R2,
                setCallbacks: g2,
                allowPinchZoom: !!j2,
                lockRef: c3,
                gapMode: P2
              }),
              m2 ? i2.cloneElement(i2.Children.only(k2), a2(a2({}, S2), { ref: M2 })) : i2.createElement(void 0 === H2 ? "div" : H2, a2({}, S2, { className: y2, ref: M2 }), k2)
            );
          });
          v.defaultProps = { enabled: true, removeScrollBar: true, inert: false }, v.classNames = { fullWidth: c2, zeroRight: l2 };
          var g = function(e3) {
            var t3 = e3.sideCar, r3 = o2(e3, ["sideCar"]);
            if (!t3) throw Error("Sidecar: please provide `sideCar` property to import the right car");
            var n3 = t3.read();
            if (!n3) throw Error("Sidecar medium not found");
            return i2.createElement(n3, a2({}, r3));
          };
          g.isSideCarExport = true;
          var m = function() {
            var e3 = 0, t3 = null;
            return {
              add: function(n3) {
                if (0 == e3 && (t3 = (function() {
                  if (!document) return null;
                  var e4 = document.createElement("style");
                  e4.type = "text/css";
                  var t4 = s2 || r2.nc;
                  return t4 && e4.setAttribute("nonce", t4), e4;
                })())) {
                  var a3, o3;
                  (a3 = t3).styleSheet ? a3.styleSheet.cssText = n3 : a3.appendChild(document.createTextNode(n3)), o3 = t3, (document.head || document.getElementsByTagName("head")[0]).appendChild(o3);
                }
                e3++;
              },
              remove: function() {
                --e3 || !t3 || (t3.parentNode && t3.parentNode.removeChild(t3), t3 = null);
              }
            };
          }, k = function() {
            var e3 = m();
            return function(t3, r3) {
              i2.useEffect(
                function() {
                  return e3.add(t3), function() {
                    e3.remove();
                  };
                },
                [t3 && r3]
              );
            };
          }, y = function() {
            var e3 = k();
            return function(t3) {
              return e3(t3.styles, t3.dynamic), null;
            };
          }, b = function(e3) {
            return parseInt(e3 || "", 10) || 0;
          }, E = function(e3) {
            var t3 = window.getComputedStyle(document.body), r3 = t3["padding" === e3 ? "paddingLeft" : "marginLeft"], n3 = t3["padding" === e3 ? "paddingTop" : "marginTop"], s3 = t3["padding" === e3 ? "paddingRight" : "marginRight"];
            return [b(r3), b(n3), b(s3)];
          }, w = function(e3) {
            void 0 === e3 && (e3 = "margin");
            var t3 = E(e3), r3 = document.documentElement.clientWidth, n3 = window.innerWidth;
            return { left: t3[0], top: t3[1], right: t3[2], gap: Math.max(0, n3 - r3 + t3[2] - t3[0]) };
          }, h = y(), O = "data-scroll-locked", R = function(e3, t3, r3, n3) {
            var s3 = e3.left, a3 = e3.top, o3 = e3.right, i3 = e3.gap;
            return void 0 === r3 && (r3 = "margin"), "\n  .".concat("with-scroll-bars-hidden", " {\n   overflow: hidden ").concat(n3, ";\n   padding-right: ").concat(i3, "px ").concat(n3, ";\n  }\n  body[").concat(O, "] {\n    overflow: hidden ").concat(n3, ";\n    overscroll-behavior: contain;\n    ").concat(
              [
                t3 && "position: relative ".concat(n3, ";"),
                "margin" === r3 && "\n    padding-left: ".concat(s3, "px;\n    padding-top: ").concat(a3, "px;\n    padding-right: ").concat(o3, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(i3, "px ").concat(n3, ";\n    "),
                "padding" === r3 && "padding-right: ".concat(i3, "px ").concat(n3, ";")
              ].filter(Boolean).join(""),
              "\n  }\n  \n  ."
            ).concat(l2, " {\n    right: ").concat(i3, "px ").concat(n3, ";\n  }\n  \n  .").concat(c2, " {\n    margin-right: ").concat(i3, "px ").concat(n3, ";\n  }\n  \n  .").concat(l2, " .").concat(l2, " {\n    right: 0 ").concat(n3, ";\n  }\n  \n  .").concat(c2, " .").concat(c2, " {\n    margin-right: 0 ").concat(n3, ";\n  }\n  \n  body[").concat(O, "] {\n    ").concat("--removed-body-scroll-bar-size", ": ").concat(i3, "px;\n  }\n");
          }, j = function() {
            var e3 = parseInt(document.body.getAttribute(O) || "0", 10);
            return isFinite(e3) ? e3 : 0;
          }, H = function() {
            i2.useEffect(function() {
              return document.body.setAttribute(O, (j() + 1).toString()), function() {
                var e3 = j() - 1;
                e3 <= 0 ? document.body.removeAttribute(O) : document.body.setAttribute(O, e3.toString());
              };
            }, []);
          }, P = function(e3) {
            var t3 = e3.noRelative, r3 = e3.noImportant, n3 = e3.gapMode, s3 = void 0 === n3 ? "margin" : n3;
            H();
            var a3 = i2.useMemo(
              function() {
                return w(s3);
              },
              [s3]
            );
            return i2.createElement(h, { styles: R(a3, !t3, s3, r3 ? "" : "!important") });
          }, C = false;
          try {
            var M = Object.defineProperty({}, "passive", {
              get: function() {
                return C = true, true;
              }
            });
            window.addEventListener("test", M, M), window.removeEventListener("test", M, M);
          } catch (e3) {
            C = false;
          }
          var S = !!C && { passive: false }, L = function(e3, t3) {
            if (!(e3 instanceof Element)) return false;
            var r3 = window.getComputedStyle(e3);
            return "hidden" !== r3[t3] && (r3.overflowY !== r3.overflowX || "TEXTAREA" === e3.tagName || "visible" !== r3[t3]);
          }, T = function(e3, t3) {
            var r3 = t3.ownerDocument, n3 = t3;
            do {
              if ("undefined" != typeof ShadowRoot && n3 instanceof ShadowRoot && (n3 = n3.host), D(e3, n3)) {
                var s3 = F(e3, n3);
                if (s3[1] > s3[2]) return true;
              }
              n3 = n3.parentNode;
            } while (n3 && n3 !== r3.body);
            return false;
          }, D = function(e3, t3) {
            return "v" === e3 ? L(t3, "overflowY") : L(t3, "overflowX");
          }, F = function(e3, t3) {
            return "v" === e3 ? [t3.scrollTop, t3.scrollHeight, t3.clientHeight] : [t3.scrollLeft, t3.scrollWidth, t3.clientWidth];
          }, N = function(e3, t3, r3, n3, s3) {
            var a3, o3 = (a3 = window.getComputedStyle(t3).direction, "h" === e3 && "rtl" === a3 ? -1 : 1), i3 = o3 * n3, l3 = r3.target, c3 = t3.contains(l3), u3 = false, f3 = i3 > 0, d3 = 0, x2 = 0;
            do {
              var p2 = F(e3, l3), _2 = p2[0], v2 = p2[1] - p2[2] - o3 * _2;
              (_2 || v2) && D(e3, l3) && (d3 += v2, x2 += _2), l3 = l3 instanceof ShadowRoot ? l3.host : l3.parentNode;
            } while (!c3 && l3 !== document.body || c3 && (t3.contains(l3) || t3 === l3));
            return f3 && (s3 && 1 > Math.abs(d3) || !s3 && i3 > d3) ? u3 = true : !f3 && (s3 && 1 > Math.abs(x2) || !s3 && -i3 > x2) && (u3 = true), u3;
          }, A = function(e3) {
            return "changedTouches" in e3 ? [e3.changedTouches[0].clientX, e3.changedTouches[0].clientY] : [0, 0];
          }, B = function(e3) {
            return [e3.deltaX, e3.deltaY];
          }, I = function(e3) {
            return e3 && "current" in e3 ? e3.current : e3;
          }, z = 0, U = [];
          let W = (n2 = function(e3) {
            var t3 = i2.useRef([]), r3 = i2.useRef([0, 0]), n3 = i2.useRef(), s3 = i2.useState(z++)[0], a3 = i2.useState(y)[0], o3 = i2.useRef(e3);
            i2.useEffect(
              function() {
                o3.current = e3;
              },
              [e3]
            ), i2.useEffect(
              function() {
                if (e3.inert) {
                  document.body.classList.add("block-interactivity-".concat(s3));
                  var t4 = (function(e4, t5, r4) {
                    if (r4 || 2 == arguments.length)
                      for (var n4, s4 = 0, a4 = t5.length; s4 < a4; s4++)
                        !n4 && s4 in t5 || (n4 || (n4 = Array.prototype.slice.call(t5, 0, s4)), n4[s4] = t5[s4]);
                    return e4.concat(n4 || Array.prototype.slice.call(t5));
                  })([e3.lockRef.current], (e3.shards || []).map(I), true).filter(Boolean);
                  return t4.forEach(function(e4) {
                    return e4.classList.add("allow-interactivity-".concat(s3));
                  }), function() {
                    document.body.classList.remove("block-interactivity-".concat(s3)), t4.forEach(function(e4) {
                      return e4.classList.remove("allow-interactivity-".concat(s3));
                    });
                  };
                }
              },
              [e3.inert, e3.lockRef.current, e3.shards]
            );
            var l3 = i2.useCallback(function(e4, t4) {
              if ("touches" in e4 && 2 === e4.touches.length || "wheel" === e4.type && e4.ctrlKey)
                return !o3.current.allowPinchZoom;
              var s4, a4 = A(e4), i3 = r3.current, l4 = "deltaX" in e4 ? e4.deltaX : i3[0] - a4[0], c4 = "deltaY" in e4 ? e4.deltaY : i3[1] - a4[1], u4 = e4.target, f4 = Math.abs(l4) > Math.abs(c4) ? "h" : "v";
              if ("touches" in e4 && "h" === f4 && "range" === u4.type) return false;
              var d4 = T(f4, u4);
              if (!d4) return true;
              if (d4 ? s4 = f4 : (s4 = "v" === f4 ? "h" : "v", d4 = T(f4, u4)), !d4) return false;
              if (!n3.current && "changedTouches" in e4 && (l4 || c4) && (n3.current = s4), !s4) return true;
              var x3 = n3.current || s4;
              return N(x3, t4, e4, "h" === x3 ? l4 : c4, true);
            }, []), c3 = i2.useCallback(function(e4) {
              if (U.length && U[U.length - 1] === a3) {
                var r4 = "deltaY" in e4 ? B(e4) : A(e4), n4 = t3.current.filter(function(t4) {
                  var n5;
                  return t4.name === e4.type && (t4.target === e4.target || e4.target === t4.shadowParent) && (n5 = t4.delta, n5[0] === r4[0] && n5[1] === r4[1]);
                })[0];
                if (n4 && n4.should) {
                  e4.cancelable && e4.preventDefault();
                  return;
                }
                if (!n4) {
                  var s4 = (o3.current.shards || []).map(I).filter(Boolean).filter(function(t4) {
                    return t4.contains(e4.target);
                  });
                  (s4.length > 0 ? l3(e4, s4[0]) : !o3.current.noIsolation) && e4.cancelable && e4.preventDefault();
                }
              }
            }, []), u3 = i2.useCallback(function(e4, r4, n4, s4) {
              var a4 = {
                name: e4,
                delta: r4,
                target: n4,
                should: s4,
                shadowParent: (function(e5) {
                  for (var t4 = null; null !== e5; )
                    e5 instanceof ShadowRoot && (t4 = e5.host, e5 = e5.host), e5 = e5.parentNode;
                  return t4;
                })(n4)
              };
              t3.current.push(a4), setTimeout(function() {
                t3.current = t3.current.filter(function(e5) {
                  return e5 !== a4;
                });
              }, 1);
            }, []), f3 = i2.useCallback(function(e4) {
              r3.current = A(e4), n3.current = void 0;
            }, []), d3 = i2.useCallback(function(t4) {
              u3(t4.type, B(t4), t4.target, l3(t4, e3.lockRef.current));
            }, []), x2 = i2.useCallback(function(t4) {
              u3(t4.type, A(t4), t4.target, l3(t4, e3.lockRef.current));
            }, []);
            i2.useEffect(function() {
              return U.push(a3), e3.setCallbacks({ onScrollCapture: d3, onWheelCapture: d3, onTouchMoveCapture: x2 }), document.addEventListener("wheel", c3, S), document.addEventListener("touchmove", c3, S), document.addEventListener("touchstart", f3, S), function() {
                U = U.filter(function(e4) {
                  return e4 !== a3;
                }), document.removeEventListener("wheel", c3, S), document.removeEventListener("touchmove", c3, S), document.removeEventListener("touchstart", f3, S);
              };
            }, []);
            var p2 = e3.removeScrollBar, _2 = e3.inert;
            return i2.createElement(
              i2.Fragment,
              null,
              _2 ? i2.createElement(a3, {
                styles: "\n  .block-interactivity-".concat(s3, " {pointer-events: none;}\n  .allow-interactivity-").concat(s3, " {pointer-events: all;}\n")
              }) : null,
              p2 ? i2.createElement(P, { gapMode: e3.gapMode }) : null
            );
          }, p.useMedium(n2), g);
          var V = i2.forwardRef(function(e3, t3) {
            return i2.createElement(v, a2({}, e3, { ref: t3, sideCar: W }));
          });
          V.classNames = v.classNames;
          let Y = V;
        },
        4490: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { DOWN: () => i2, LEFT: () => s2, RIGHT: () => a2, UP: () => o2, useSwipeable: () => x });
          var n2 = r2(810);
          let s2 = "Left", a2 = "Right", o2 = "Up", i2 = "Down", l2 = {
            delta: 10,
            preventScrollOnSwipe: false,
            rotationAngle: 0,
            trackMouse: false,
            trackTouch: true,
            swipeDuration: 1 / 0,
            touchEventOptions: { passive: true }
          }, c2 = { first: true, initial: [0, 0], start: 0, swiping: false, xy: [0, 0] }, u2 = "mousemove", f2 = "mouseup";
          function d2(e3, t3) {
            if (0 === t3) return e3;
            let r3 = Math.PI / 180 * t3;
            return [e3[0] * Math.cos(r3) + e3[1] * Math.sin(r3), e3[1] * Math.cos(r3) - e3[0] * Math.sin(r3)];
          }
          function x(e3) {
            var t3, r3, x2;
            let p, { trackMouse: _ } = e3, v = n2.useRef(Object.assign({}, c2)), g = n2.useRef(Object.assign({}, l2)), m = n2.useRef(Object.assign({}, g.current));
            for (p in m.current = Object.assign({}, g.current), g.current = Object.assign(Object.assign({}, l2), e3), l2)
              void 0 === g.current[p] && (g.current[p] = l2[p]);
            let [k, y] = n2.useMemo(
              () => (function(e4, t4) {
                let r4 = (t5) => {
                  let r5 = "touches" in t5;
                  r5 && t5.touches.length > 1 || e4((e5, s3) => {
                    s3.trackMouse && !r5 && (document.addEventListener(u2, n3), document.addEventListener(f2, p2));
                    let { clientX: a3, clientY: o3 } = r5 ? t5.touches[0] : t5, i3 = d2([a3, o3], s3.rotationAngle);
                    return s3.onTouchStartOrOnMouseDown && s3.onTouchStartOrOnMouseDown({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), {
                      initial: i3.slice(),
                      xy: i3,
                      start: t5.timeStamp || 0
                    });
                  });
                }, n3 = (t5) => {
                  e4((e5, r5) => {
                    var n4, c3, u3, f3;
                    let x4 = "touches" in t5;
                    if (x4 && t5.touches.length > 1) return e5;
                    if (t5.timeStamp - e5.start > r5.swipeDuration)
                      return e5.swiping ? Object.assign(Object.assign({}, e5), { swiping: false }) : e5;
                    let { clientX: p3, clientY: _3 } = x4 ? t5.touches[0] : t5, [v3, g2] = d2([p3, _3], r5.rotationAngle), m2 = v3 - e5.xy[0], k2 = g2 - e5.xy[1], y2 = Math.abs(m2), b = Math.abs(k2), E = (t5.timeStamp || 0) - e5.start, w = Math.sqrt(y2 * y2 + b * b) / (E || 1), h = [m2 / (E || 1), k2 / (E || 1)], O = (n4 = y2, c3 = b, u3 = m2, f3 = k2, n4 > c3 ? u3 > 0 ? a2 : s2 : f3 > 0 ? i2 : o2), R = "number" == typeof r5.delta ? r5.delta : r5.delta[O.toLowerCase()] || l2.delta;
                    if (y2 < R && b < R && !e5.swiping) return e5;
                    let j = {
                      absX: y2,
                      absY: b,
                      deltaX: m2,
                      deltaY: k2,
                      dir: O,
                      event: t5,
                      first: e5.first,
                      initial: e5.initial,
                      velocity: w,
                      vxvy: h
                    };
                    j.first && r5.onSwipeStart && r5.onSwipeStart(j), r5.onSwiping && r5.onSwiping(j);
                    let H = false;
                    return (r5.onSwiping || r5.onSwiped || r5["onSwiped".concat(O)]) && (H = true), H && r5.preventScrollOnSwipe && r5.trackTouch && t5.cancelable && t5.preventDefault(), Object.assign(Object.assign({}, e5), { first: false, eventData: j, swiping: true });
                  });
                }, x3 = (t5) => {
                  e4((e5, r5) => {
                    let n4;
                    if (e5.swiping && e5.eventData) {
                      if (t5.timeStamp - e5.start < r5.swipeDuration) {
                        n4 = Object.assign(Object.assign({}, e5.eventData), { event: t5 }), r5.onSwiped && r5.onSwiped(n4);
                        let s3 = r5["onSwiped".concat(n4.dir)];
                        s3 && s3(n4);
                      }
                    } else r5.onTap && r5.onTap({ event: t5 });
                    return r5.onTouchEndOrOnMouseUp && r5.onTouchEndOrOnMouseUp({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), { eventData: n4 });
                  });
                }, p2 = (e5) => {
                  document.removeEventListener(u2, n3), document.removeEventListener(f2, p2), x3(e5);
                }, _2 = (e5, t5) => {
                  let s3 = () => {
                  };
                  if (e5 && e5.addEventListener) {
                    let a3 = Object.assign(Object.assign({}, l2.touchEventOptions), t5.touchEventOptions), o3 = [
                      ["touchstart", r4, a3],
                      [
                        "touchmove",
                        n3,
                        Object.assign(Object.assign({}, a3), t5.preventScrollOnSwipe ? { passive: false } : {})
                      ],
                      ["touchend", x3, a3]
                    ];
                    o3.forEach((t6) => {
                      let [r5, n4, s4] = t6;
                      return e5.addEventListener(r5, n4, s4);
                    }), s3 = () => o3.forEach((t6) => {
                      let [r5, n4] = t6;
                      return e5.removeEventListener(r5, n4);
                    });
                  }
                  return s3;
                }, v2 = {
                  ref: (t5) => {
                    null !== t5 && e4((e5, r5) => {
                      if (e5.el === t5) return e5;
                      let n4 = {};
                      return e5.el && e5.el !== t5 && e5.cleanUpTouch && (e5.cleanUpTouch(), n4.cleanUpTouch = void 0), r5.trackTouch && t5 && (n4.cleanUpTouch = _2(t5, r5)), Object.assign(Object.assign(Object.assign({}, e5), { el: t5 }), n4);
                    });
                  }
                };
                return t4.trackMouse && (v2.onMouseDown = r4), [v2, _2];
              })((e4) => v.current = e4(v.current, g.current), { trackMouse: _ }),
              [_]
            );
            return t3 = v.current, r3 = g.current, x2 = m.current, v.current = r3.trackTouch && t3.el ? t3.cleanUpTouch ? r3.preventScrollOnSwipe !== x2.preventScrollOnSwipe || r3.touchEventOptions.passive !== x2.touchEventOptions.passive ? (t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) })) : t3 : Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) }) : (t3.cleanUpTouch && t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: void 0 })), k;
          }
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        8442: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "addToPlaylist_xxs", xlinkHref: "/icons/sprite.svg#addToPlaylist_xxs" })
            ]);
          });
        },
        6644: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "add_l", xlinkHref: "/icons/sprite.svg#add_l" })
            ]);
          });
        },
        7319: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "add_xxs", xlinkHref: "/icons/sprite.svg#add_xxs" })
            ]);
          });
        },
        9351: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_s", xlinkHref: "/icons/sprite.svg#adult_s" })
            ]);
          });
        },
        7171: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xs", xlinkHref: "/icons/sprite.svg#adult_xs" })
            ]);
          });
        },
        2586: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xxs", xlinkHref: "/icons/sprite.svg#adult_xxs" })
            ]);
          });
        },
        4656: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xxxs", xlinkHref: "/icons/sprite.svg#adult_xxxs" })
            ]);
          });
        },
        996: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_l", xlinkHref: "/icons/sprite.svg#album_l" })
            ]);
          });
        },
        2092: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_s", xlinkHref: "/icons/sprite.svg#album_s" })
            ]);
          });
        },
        6304: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xl", xlinkHref: "/icons/sprite.svg#album_xl" })
            ]);
          });
        },
        9030: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xs", xlinkHref: "/icons/sprite.svg#album_xs" })
            ]);
          });
        },
        5822: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xxs", xlinkHref: "/icons/sprite.svg#album_xxs" })
            ]);
          });
        },
        9422: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowDown_xs", xlinkHref: "/icons/sprite.svg#arrowDown_xs" })
            ]);
          });
        },
        5272: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowDown_xxs", xlinkHref: "/icons/sprite.svg#arrowDown_xxs" })
            ]);
          });
        },
        1491: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowLeft_xs", xlinkHref: "/icons/sprite.svg#arrowLeft_xs" })
            ]);
          });
        },
        4860: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowLeft_xxs", xlinkHref: "/icons/sprite.svg#arrowLeft_xxs" })
            ]);
          });
        },
        2337: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xs", xlinkHref: "/icons/sprite.svg#arrowRight_xs" })
            ]);
          });
        },
        8711: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxs" })
            ]);
          });
        },
        8170: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xxxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxxs" })
            ]);
          });
        },
        8109: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "artist_xxs", xlinkHref: "/icons/sprite.svg#artist_xxs" })
            ]);
          });
        },
        7341: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "attention_xxl", xlinkHref: "/icons/sprite.svg#attention_xxl" })
            ]);
          });
        },
        2435: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "attention_xxxl", xlinkHref: "/icons/sprite.svg#attention_xxxl" })
            ]);
          });
        },
        3918: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "bandlink", xlinkHref: "/icons/sprite.svg#bandlink" })
            ]);
          });
        },
        2571: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "booksLogo", xlinkHref: "/icons/sprite.svg#booksLogo" })
            ]);
          });
        },
        4904: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "bucket_xxs", xlinkHref: "/icons/sprite.svg#bucket_xxs" })
            ]);
          });
        },
        9202: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "cast_xs", xlinkHref: "/icons/sprite.svg#cast_xs" })
            ]);
          });
        },
        130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chain_xs", xlinkHref: "/icons/sprite.svg#chain_xs" })
            ]);
          });
        },
        5971: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chain_xxs", xlinkHref: "/icons/sprite.svg#chain_xxs" })
            ]);
          });
        },
        3331: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartDown_xxs", xlinkHref: "/icons/sprite.svg#chartDown_xxs" })
            ]);
          });
        },
        9783: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartNew_xxs", xlinkHref: "/icons/sprite.svg#chartNew_xxs" })
            ]);
          });
        },
        8184: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartSame_xxs", xlinkHref: "/icons/sprite.svg#chartSame_xxs" })
            ]);
          });
        },
        4926: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartUp_xxs", xlinkHref: "/icons/sprite.svg#chartUp_xxs" })
            ]);
          });
        },
        9505: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxl", xlinkHref: "/icons/sprite.svg#check_xxl" })
            ]);
          });
        },
        3176: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxs", xlinkHref: "/icons/sprite.svg#check_xxs" })
            ]);
          });
        },
        5565: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxxs", xlinkHref: "/icons/sprite.svg#check_xxxs" })
            ]);
          });
        },
        9040: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "clip_xl", xlinkHref: "/icons/sprite.svg#clip_xl" })
            ]);
          });
        },
        4789: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "clip_xxs", xlinkHref: "/icons/sprite.svg#clip_xxs" })
            ]);
          });
        },
        7923: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xs", xlinkHref: "/icons/sprite.svg#close_xs" })
            ]);
          });
        },
        8151: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xxs", xlinkHref: "/icons/sprite.svg#close_xxs" })
            ]);
          });
        },
        8127: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xxxs", xlinkHref: "/icons/sprite.svg#close_xxxs" })
            ]);
          });
        },
        8690: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "code_xxs", xlinkHref: "/icons/sprite.svg#code_xxs" })
            ]);
          });
        },
        3076: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "collections_m", xlinkHref: "/icons/sprite.svg#collections_m" })
            ]);
          });
        },
        2495: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "collections_selected_m",
                xlinkHref: "/icons/sprite.svg#collections_selected_m"
              })
            ]);
          });
        },
        1524: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "crown_xxs", xlinkHref: "/icons/sprite.svg#crown_xxs" })
            ]);
          });
        },
        1162: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_s", xlinkHref: "/icons/sprite.svg#dislike_s" })
            ]);
          });
        },
        3654: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_xs", xlinkHref: "/icons/sprite.svg#dislike_xs" })
            ]);
          });
        },
        2361: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_xxs", xlinkHref: "/icons/sprite.svg#dislike_xxs" })
            ]);
          });
        },
        6837: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_s", xlinkHref: "/icons/sprite.svg#disliked_s" })
            ]);
          });
        },
        6507: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_xs", xlinkHref: "/icons/sprite.svg#disliked_xs" })
            ]);
          });
        },
        3972: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_xxs", xlinkHref: "/icons/sprite.svg#disliked_xxs" })
            ]);
          });
        },
        8993: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "donation_xxxs", xlinkHref: "/icons/sprite.svg#donation_xxxs" })
            ]);
          });
        },
        7031: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "download_l", xlinkHref: "/icons/sprite.svg#download_l" })
            ]);
          });
        },
        9330: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "download_xxs", xlinkHref: "/icons/sprite.svg#download_xxs" })
            ]);
          });
        },
        7346: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "downloaded_xxs", xlinkHref: "/icons/sprite.svg#downloaded_xxs" })
            ]);
          });
        },
        2604: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dragDots_xxs", xlinkHref: "/icons/sprite.svg#dragDots_xxs" })
            ]);
          });
        },
        6894: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "edit_xxs", xlinkHref: "/icons/sprite.svg#edit_xxs" })
            ]);
          });
        },
        2024: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_s", xlinkHref: "/icons/sprite.svg#exclamation_s" })
            ]);
          });
        },
        3193: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xs", xlinkHref: "/icons/sprite.svg#exclamation_xs" })
            ]);
          });
        },
        6391: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xxs", xlinkHref: "/icons/sprite.svg#exclamation_xxs" })
            ]);
          });
        },
        2933: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xxxs", xlinkHref: "/icons/sprite.svg#exclamation_xxxs" })
            ]);
          });
        },
        776: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_s", xlinkHref: "/icons/sprite.svg#explicit_s" })
            ]);
          });
        },
        30: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xs", xlinkHref: "/icons/sprite.svg#explicit_xs" })
            ]);
          });
        },
        9369: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xxs", xlinkHref: "/icons/sprite.svg#explicit_xxs" })
            ]);
          });
        },
        1334: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xxxs", xlinkHref: "/icons/sprite.svg#explicit_xxxs" })
            ]);
          });
        },
        226: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "eye_crossed_xxs", xlinkHref: "/icons/sprite.svg#eye_crossed_xxs" })
            ]);
          });
        },
        7802: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "filter_xs", xlinkHref: "/icons/sprite.svg#filter_xs" })
            ]);
          });
        },
        8130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "filter_xxs", xlinkHref: "/icons/sprite.svg#filter_xxs" })
            ]);
          });
        },
        3738: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "fullscreen_xs", xlinkHref: "/icons/sprite.svg#fullscreen_xs" })
            ]);
          });
        },
        2161: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "googlePlay", xlinkHref: "/icons/sprite.svg#googlePlay" })
            ]);
          });
        },
        9509: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "history_m", xlinkHref: "/icons/sprite.svg#history_m" })
            ]);
          });
        },
        8987: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "home_m", xlinkHref: "/icons/sprite.svg#home_m" })
            ]);
          });
        },
        190: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "home_selected_m", xlinkHref: "/icons/sprite.svg#home_selected_m" })
            ]);
          });
        },
        5304: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "huaweiAppGallery", xlinkHref: "/icons/sprite.svg#huaweiAppGallery" })
            ]);
          });
        },
        5270: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "info_xxs", xlinkHref: "/icons/sprite.svg#info_xxs" })
            ]);
          });
        },
        843: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kids_m", xlinkHref: "/icons/sprite.svg#kids_m" })
            ]);
          });
        },
        5122: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kids_selected_m", xlinkHref: "/icons/sprite.svg#kids_selected_m" })
            ]);
          });
        },
        2646: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kinopoiskEn", xlinkHref: "/icons/sprite.svg#kinopoiskEn" })
            ]);
          });
        },
        7500: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kinopoiskRu", xlinkHref: "/icons/sprite.svg#kinopoiskRu" })
            ]);
          });
        },
        3560: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lightning_xxs", xlinkHref: "/icons/sprite.svg#lightning_xxs" })
            ]);
          });
        },
        9838: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likeVariant_xxs", xlinkHref: "/icons/sprite.svg#likeVariant_xxs" })
            ]);
          });
        },
        4793: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_l", xlinkHref: "/icons/sprite.svg#like_l" })
            ]);
          });
        },
        7405: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_m", xlinkHref: "/icons/sprite.svg#like_m" })
            ]);
          });
        },
        2340: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_xs", xlinkHref: "/icons/sprite.svg#like_xs" })
            ]);
          });
        },
        7513: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_xxs", xlinkHref: "/icons/sprite.svg#like_xxs" })
            ]);
          });
        },
        5720: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likedVariant_s", xlinkHref: "/icons/sprite.svg#likedVariant_s" })
            ]);
          });
        },
        7399: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likedVariant_xxs", xlinkHref: "/icons/sprite.svg#likedVariant_xxs" })
            ]);
          });
        },
        820: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_m", xlinkHref: "/icons/sprite.svg#liked_m" })
            ]);
          });
        },
        2125: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_xs", xlinkHref: "/icons/sprite.svg#liked_xs" })
            ]);
          });
        },
        9104: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_xxs", xlinkHref: "/icons/sprite.svg#liked_xxs" })
            ]);
          });
        },
        5849: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "link_xxs", xlinkHref: "/icons/sprite.svg#link_xxs" })
            ]);
          });
        },
        1426: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "listen_xxxs", xlinkHref: "/icons/sprite.svg#listen_xxxs" })
            ]);
          });
        },
        4014: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liteVersion_xs", xlinkHref: "/icons/sprite.svg#liteVersion_xs" })
            ]);
          });
        },
        5443: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_m", xlinkHref: "/icons/sprite.svg#lock_m" })
            ]);
          });
        },
        896: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_xs", xlinkHref: "/icons/sprite.svg#lock_xs" })
            ]);
          });
        },
        3613: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_xxs", xlinkHref: "/icons/sprite.svg#lock_xxs" })
            ]);
          });
        },
        9372: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lyrics_xxs", xlinkHref: "/icons/sprite.svg#lyrics_xxs" })
            ]);
          });
        },
        6104: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "macos", xlinkHref: "/icons/sprite.svg#macos" })
            ]);
          });
        },
        3709: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "macos_xxs", xlinkHref: "/icons/sprite.svg#macos_xxs" })
            ]);
          });
        },
        3685: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "menuArrow_xxs", xlinkHref: "/icons/sprite.svg#menuArrow_xxs" })
            ]);
          });
        },
        8782: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_m", xlinkHref: "/icons/sprite.svg#more_m" })
            ]);
          });
        },
        1829: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_xs", xlinkHref: "/icons/sprite.svg#more_xs" })
            ]);
          });
        },
        3302: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_xxs", xlinkHref: "/icons/sprite.svg#more_xxs" })
            ]);
          });
        },
        2502: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogo", xlinkHref: "/icons/sprite.svg#musicLogo" })
            ]);
          });
        },
        1754: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoCenterEn", xlinkHref: "/icons/sprite.svg#musicLogoCenterEn" })
            ]);
          });
        },
        6615: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoCenterRu", xlinkHref: "/icons/sprite.svg#musicLogoCenterRu" })
            ]);
          });
        },
        7942: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoLeftEn", xlinkHref: "/icons/sprite.svg#musicLogoLeftEn" })
            ]);
          });
        },
        1498: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoLeftRu", xlinkHref: "/icons/sprite.svg#musicLogoLeftRu" })
            ]);
          });
        },
        1893: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationCollection_xs",
                xlinkHref: "/icons/sprite.svg#navigationCollection_xs"
              })
            ]);
          });
        },
        1563: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationConcerts_xs",
                xlinkHref: "/icons/sprite.svg#navigationConcerts_xs"
              })
            ]);
          });
        },
        1578: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationForYouAndTrends_xs",
                xlinkHref: "/icons/sprite.svg#navigationForYouAndTrends_xs"
              })
            ]);
          });
        },
        9348: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "navigationKids_xs", xlinkHref: "/icons/sprite.svg#navigationKids_xs" })
            ]);
          });
        },
        965: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationMyVibe_xs",
                xlinkHref: "/icons/sprite.svg#navigationMyVibe_xs"
              })
            ]);
          });
        },
        3877: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationNonMusic_xs",
                xlinkHref: "/icons/sprite.svg#navigationNonMusic_xs"
              })
            ]);
          });
        },
        9968: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "navigationPlus_xs", xlinkHref: "/icons/sprite.svg#navigationPlus_xs" })
            ]);
          });
        },
        3778: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationSearch_xs",
                xlinkHref: "/icons/sprite.svg#navigationSearch_xs"
              })
            ]);
          });
        },
        1084: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xs", xlinkHref: "/icons/sprite.svg#next_xs" })
            ]);
          });
        },
        4483: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xxl", xlinkHref: "/icons/sprite.svg#next_xxl" })
            ]);
          });
        },
        811: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xxs", xlinkHref: "/icons/sprite.svg#next_xxs" })
            ]);
          });
        },
        7252: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "non_music_m", xlinkHref: "/icons/sprite.svg#non_music_m" })
            ]);
          });
        },
        3013: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "non_music_selected_m",
                xlinkHref: "/icons/sprite.svg#non_music_selected_m"
              })
            ]);
          });
        },
        2774: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_s", xlinkHref: "/icons/sprite.svg#note_s" })
            ]);
          });
        },
        4298: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_xl", xlinkHref: "/icons/sprite.svg#note_xl" })
            ]);
          });
        },
        4254: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_xs", xlinkHref: "/icons/sprite.svg#note_xs" })
            ]);
          });
        },
        8499: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "offline_xxl", xlinkHref: "/icons/sprite.svg#offline_xxl" })
            ]);
          });
        },
        4997: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pauseVibe_s", xlinkHref: "/icons/sprite.svg#pauseVibe_s" })
            ]);
          });
        },
        7076: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_l", xlinkHref: "/icons/sprite.svg#pause_filled_l" })
            ]);
          });
        },
        3792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_m", xlinkHref: "/icons/sprite.svg#pause_filled_m" })
            ]);
          });
        },
        5132: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xl", xlinkHref: "/icons/sprite.svg#pause_filled_xl" })
            ]);
          });
        },
        8131: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xs", xlinkHref: "/icons/sprite.svg#pause_filled_xs" })
            ]);
          });
        },
        705: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xxl", xlinkHref: "/icons/sprite.svg#pause_filled_xxl" })
            ]);
          });
        },
        5346: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_m", xlinkHref: "/icons/sprite.svg#pause_m" })
            ]);
          });
        },
        792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_xs", xlinkHref: "/icons/sprite.svg#pause_xs" })
            ]);
          });
        },
        6122: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_xxs", xlinkHref: "/icons/sprite.svg#pause_xxs" })
            ]);
          });
        },
        5386: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pencil_xxs", xlinkHref: "/icons/sprite.svg#pencil_xxs" })
            ]);
          });
        },
        3146: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_s", xlinkHref: "/icons/sprite.svg#picture_s" })
            ]);
          });
        },
        8868: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_xl", xlinkHref: "/icons/sprite.svg#picture_xl" })
            ]);
          });
        },
        1125: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_xs", xlinkHref: "/icons/sprite.svg#picture_xs" })
            ]);
          });
        },
        976: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_filled_xs", xlinkHref: "/icons/sprite.svg#pin_filled_xs" })
            ]);
          });
        },
        9434: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_filled_xxs", xlinkHref: "/icons/sprite.svg#pin_filled_xxs" })
            ]);
          });
        },
        9288: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_xs", xlinkHref: "/icons/sprite.svg#pin_xs" })
            ]);
          });
        },
        3201: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_xxs", xlinkHref: "/icons/sprite.svg#pin_xxs" })
            ]);
          });
        },
        8112: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playLast_xxs", xlinkHref: "/icons/sprite.svg#playLast_xxs" })
            ]);
          });
        },
        8044: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playNext_xxs", xlinkHref: "/icons/sprite.svg#playNext_xxs" })
            ]);
          });
        },
        8303: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playQueue_m", xlinkHref: "/icons/sprite.svg#playQueue_m" })
            ]);
          });
        },
        9863: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playQueue_xs", xlinkHref: "/icons/sprite.svg#playQueue_xs" })
            ]);
          });
        },
        2084: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playVibe_s", xlinkHref: "/icons/sprite.svg#playVibe_s" })
            ]);
          });
        },
        8582: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_l", xlinkHref: "/icons/sprite.svg#play_filled_l" })
            ]);
          });
        },
        4777: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_m", xlinkHref: "/icons/sprite.svg#play_filled_m" })
            ]);
          });
        },
        8779: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xl", xlinkHref: "/icons/sprite.svg#play_filled_xl" })
            ]);
          });
        },
        1945: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xs", xlinkHref: "/icons/sprite.svg#play_filled_xs" })
            ]);
          });
        },
        7402: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xxl", xlinkHref: "/icons/sprite.svg#play_filled_xxl" })
            ]);
          });
        },
        1351: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_m", xlinkHref: "/icons/sprite.svg#play_m" })
            ]);
          });
        },
        1874: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xs", xlinkHref: "/icons/sprite.svg#play_xs" })
            ]);
          });
        },
        2026: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xxs", xlinkHref: "/icons/sprite.svg#play_xxs" })
            ]);
          });
        },
        5378: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xxxs", xlinkHref: "/icons/sprite.svg#play_xxxs" })
            ]);
          });
        },
        3751: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_s", xlinkHref: "/icons/sprite.svg#playlist_s" })
            ]);
          });
        },
        8503: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_xl", xlinkHref: "/icons/sprite.svg#playlist_xl" })
            ]);
          });
        },
        1580: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_xs", xlinkHref: "/icons/sprite.svg#playlist_xs" })
            ]);
          });
        },
        8861: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plus", xlinkHref: "/icons/sprite.svg#plus" })
            ]);
          });
        },
        6809: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusBadge", xlinkHref: "/icons/sprite.svg#plusBadge" })
            ]);
          });
        },
        5266: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusColor", xlinkHref: "/icons/sprite.svg#plusColor" })
            ]);
          });
        },
        1179: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusOutlined", xlinkHref: "/icons/sprite.svg#plusOutlined" })
            ]);
          });
        },
        735: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusOutlined_m", xlinkHref: "/icons/sprite.svg#plusOutlined_m" })
            ]);
          });
        },
        2754: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "podcasts_xxs", xlinkHref: "/icons/sprite.svg#podcasts_xxs" })
            ]);
          });
        },
        4091: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xs", xlinkHref: "/icons/sprite.svg#previous_xs" })
            ]);
          });
        },
        1427: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xxl", xlinkHref: "/icons/sprite.svg#previous_xxl" })
            ]);
          });
        },
        5251: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xxs", xlinkHref: "/icons/sprite.svg#previous_xxs" })
            ]);
          });
        },
        895: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_one_xs", xlinkHref: "/icons/sprite.svg#repeat_one_xs" })
            ]);
          });
        },
        5632: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_one_xxs", xlinkHref: "/icons/sprite.svg#repeat_one_xxs" })
            ]);
          });
        },
        8090: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_xs", xlinkHref: "/icons/sprite.svg#repeat_xs" })
            ]);
          });
        },
        9370: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_xxs", xlinkHref: "/icons/sprite.svg#repeat_xxs" })
            ]);
          });
        },
        1001: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "reset_xxs", xlinkHref: "/icons/sprite.svg#reset_xxs" })
            ]);
          });
        },
        6579: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "reset_xxxs", xlinkHref: "/icons/sprite.svg#reset_xxxs" })
            ]);
          });
        },
        5910: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "rewindBackwards_xs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xs"
              })
            ]);
          });
        },
        893: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "rewindBackwards_xxs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xxs"
              })
            ]);
          });
        },
        4892: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "rewindForward_xs", xlinkHref: "/icons/sprite.svg#rewindForward_xs" })
            ]);
          });
        },
        6331: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "rewindForward_xxs", xlinkHref: "/icons/sprite.svg#rewindForward_xxs" })
            ]);
          });
        },
        2176: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_m", xlinkHref: "/icons/sprite.svg#ruble_m" })
            ]);
          });
        },
        9876: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_xxs", xlinkHref: "/icons/sprite.svg#ruble_xxs" })
            ]);
          });
        },
        3935: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_xxxs", xlinkHref: "/icons/sprite.svg#ruble_xxxs" })
            ]);
          });
        },
        7643: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_l", xlinkHref: "/icons/sprite.svg#search_l" })
            ]);
          });
        },
        8235: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_m", xlinkHref: "/icons/sprite.svg#search_m" })
            ]);
          });
        },
        8915: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_selected_m", xlinkHref: "/icons/sprite.svg#search_selected_m" })
            ]);
          });
        },
        3366: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_xs", xlinkHref: "/icons/sprite.svg#search_xs" })
            ]);
          });
        },
        7934: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_xxl", xlinkHref: "/icons/sprite.svg#search_xxl" })
            ]);
          });
        },
        5034: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "settings_xs", xlinkHref: "/icons/sprite.svg#settings_xs" })
            ]);
          });
        },
        1758: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "settings_xxs", xlinkHref: "/icons/sprite.svg#settings_xxs" })
            ]);
          });
        },
        7196: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "share_xxs", xlinkHref: "/icons/sprite.svg#share_xxs" })
            ]);
          });
        },
        5792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "shuffle_xs", xlinkHref: "/icons/sprite.svg#shuffle_xs" })
            ]);
          });
        },
        7951: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "shuffle_xxs", xlinkHref: "/icons/sprite.svg#shuffle_xxs" })
            ]);
          });
        },
        9545: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "site_xs", xlinkHref: "/icons/sprite.svg#site_xs" })
            ]);
          });
        },
        2037: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_25x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_m"
              })
            ]);
          });
        },
        3362: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_25x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_xs"
              })
            ]);
          });
        },
        9846: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_25x_l", xlinkHref: "/icons/sprite.svg#speed_1_25x_l" })
            ]);
          });
        },
        5197: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_5x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_m"
              })
            ]);
          });
        },
        1079: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_5x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_xs"
              })
            ]);
          });
        },
        6275: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_5x_l", xlinkHref: "/icons/sprite.svg#speed_1_5x_l" })
            ]);
          });
        },
        7026: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_75x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_m"
              })
            ]);
          });
        },
        8994: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_75x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_xs"
              })
            ]);
          });
        },
        3702: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_75x_l", xlinkHref: "/icons/sprite.svg#speed_1_75x_l" })
            ]);
          });
        },
        8664: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_m"
              })
            ]);
          });
        },
        51: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_xs"
              })
            ]);
          });
        },
        8550: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1x_l", xlinkHref: "/icons/sprite.svg#speed_1x_l" })
            ]);
          });
        },
        8619: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_2x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_m"
              })
            ]);
          });
        },
        5218: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_2x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_xs"
              })
            ]);
          });
        },
        857: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_2x_l", xlinkHref: "/icons/sprite.svg#speed_2x_l" })
            ]);
          });
        },
        6130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_m", xlinkHref: "/icons/sprite.svg#syncLyrics_m" })
            ]);
          });
        },
        3049: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_xs", xlinkHref: "/icons/sprite.svg#syncLyrics_xs" })
            ]);
          });
        },
        126: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_xxs", xlinkHref: "/icons/sprite.svg#syncLyrics_xxs" })
            ]);
          });
        },
        6210: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ticket_m", xlinkHref: "/icons/sprite.svg#ticket_m" })
            ]);
          });
        },
        5596: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ticket_selected_m", xlinkHref: "/icons/sprite.svg#ticket_selected_m" })
            ]);
          });
        },
        380: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "trailer_xs", xlinkHref: "/icons/sprite.svg#trailer_xs" })
            ]);
          });
        },
        3112: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "trailer_xxs", xlinkHref: "/icons/sprite.svg#trailer_xxs" })
            ]);
          });
        },
        1045: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unavailable_xl", xlinkHref: "/icons/sprite.svg#unavailable_xl" })
            ]);
          });
        },
        2834: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unavailable_xs", xlinkHref: "/icons/sprite.svg#unavailable_xs" })
            ]);
          });
        },
        8819: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unpin_xxs", xlinkHref: "/icons/sprite.svg#unpin_xxs" })
            ]);
          });
        },
        8772: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "upload_xxs", xlinkHref: "/icons/sprite.svg#upload_xxs" })
            ]);
          });
        },
        3522: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "users_xxxs", xlinkHref: "/icons/sprite.svg#users_xxxs" })
            ]);
          });
        },
        5695: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "vibe_xxs", xlinkHref: "/icons/sprite.svg#vibe_xxs" })
            ]);
          });
        },
        6174: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "volumeOff_xs", xlinkHref: "/icons/sprite.svg#volumeOff_xs" })
            ]);
          });
        },
        540: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "volume_xs", xlinkHref: "/icons/sprite.svg#volume_xs" })
            ]);
          });
        },
        6206: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "windows", xlinkHref: "/icons/sprite.svg#windows" })
            ]);
          });
        },
        7185: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "windows_xs", xlinkHref: "/icons/sprite.svg#windows_xs" })
            ]);
          });
        },
        9481: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexBooksEn", xlinkHref: "/icons/sprite.svg#yandexBooksEn" })
            ]);
          });
        },
        7364: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexBooksRu", xlinkHref: "/icons/sprite.svg#yandexBooksRu" })
            ]);
          });
        },
        8577: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPayEn", xlinkHref: "/icons/sprite.svg#yandexPayEn" })
            ]);
          });
        },
        5760: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPayRu", xlinkHref: "/icons/sprite.svg#yandexPayRu" })
            ]);
          });
        },
        5667: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPlusEn", xlinkHref: "/icons/sprite.svg#yandexPlusEn" })
            ]);
          });
        },
        2639: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPlusRu", xlinkHref: "/icons/sprite.svg#yandexPlusRu" })
            ]);
          });
        },
        9110: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.usePopoverSwipeable = t2.useReturnValue = t2.useCallbackRef = t2.useDebouncedToggle = t2.useResize = t2.useIsomorphicEffect = t2.useForceUpdateRef = t2.useElementOffsetY = t2.getElementNameByDataAttribute = t2.createIntersectionObserver = t2.useIntersectionObserver = t2.useKeyboardNavigation = t2.useScroll = t2.useForwardRef = void 0;
          var n2 = r2(245);
          Object.defineProperty(t2, "useForwardRef", {
            enumerable: true,
            get: function() {
              return n2.useForwardRef;
            }
          });
          var s2 = r2(2067);
          Object.defineProperty(t2, "useScroll", {
            enumerable: true,
            get: function() {
              return s2.useScroll;
            }
          });
          var a2 = r2(5188);
          Object.defineProperty(t2, "useKeyboardNavigation", {
            enumerable: true,
            get: function() {
              return a2.useKeyboardNavigation;
            }
          });
          var o2 = r2(5663);
          Object.defineProperty(t2, "useIntersectionObserver", {
            enumerable: true,
            get: function() {
              return o2.useIntersectionObserver;
            }
          }), Object.defineProperty(t2, "createIntersectionObserver", {
            enumerable: true,
            get: function() {
              return o2.createIntersectionObserver;
            }
          }), Object.defineProperty(t2, "getElementNameByDataAttribute", {
            enumerable: true,
            get: function() {
              return o2.getElementNameByDataAttribute;
            }
          });
          var i2 = r2(2101);
          Object.defineProperty(t2, "useElementOffsetY", {
            enumerable: true,
            get: function() {
              return i2.useElementOffsetY;
            }
          });
          var l2 = r2(2767);
          Object.defineProperty(t2, "useForceUpdateRef", {
            enumerable: true,
            get: function() {
              return l2.useForceUpdateRef;
            }
          });
          var c2 = r2(9019);
          Object.defineProperty(t2, "useIsomorphicEffect", {
            enumerable: true,
            get: function() {
              return c2.useIsomorphicEffect;
            }
          });
          var u2 = r2(2947);
          Object.defineProperty(t2, "useResize", {
            enumerable: true,
            get: function() {
              return u2.useResize;
            }
          });
          var f2 = r2(6699);
          Object.defineProperty(t2, "useDebouncedToggle", {
            enumerable: true,
            get: function() {
              return f2.useDebouncedToggle;
            }
          });
          var d2 = r2(8691);
          Object.defineProperty(t2, "useCallbackRef", {
            enumerable: true,
            get: function() {
              return d2.useCallbackRef;
            }
          });
          var x = r2(998);
          Object.defineProperty(t2, "useReturnValue", {
            enumerable: true,
            get: function() {
              return x.useReturnValue;
            }
          });
          var p = r2(4395);
          Object.defineProperty(t2, "usePopoverSwipeable", {
            enumerable: true,
            get: function() {
              return p.usePopoverSwipeable;
            }
          });
          var _ = r2(5969);
          Object.defineProperty(t2, "useDynamicText", {
            enumerable: true,
            get: function() {
              return _.useDynamicText;
            }
          });
        },
        8691: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useCallbackRef = void 0;
          let n2 = r2(810);
          t2.useCallbackRef = function(e3) {
            let t3 = (0, n2.useRef)({
              stableFn: function() {
                for (var e4 = arguments.length, r3 = Array(e4), n3 = 0; n3 < e4; n3++) r3[n3] = arguments[n3];
                return t3.current.callback(...r3);
              },
              callback: e3
            });
            return (0, n2.useInsertionEffect)(() => {
              t3.current.callback = e3;
            }), t3.current.stableFn;
          };
        },
        1381: (e2, t2, r2) => {
          var n2;
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useComponentSwipeable = t2.SwipeablePlacement = void 0;
          let s2 = r2(4490), a2 = r2(8691);
          !(function(e3) {
            e3.TOP = "top", e3.BOTTOM = "bottom", e3.RIGHT = "right", e3.LEFT = "left";
          })(n2 || (t2.SwipeablePlacement = n2 = {}));
          let o2 = (e3) => {
            let { ref: t3, deltaY: r3, deltaX: s3, placement: a3 } = e3;
            requestAnimationFrame(() => {
              t3.current && (t3.current.style.willChange = "transform", t3.current.style.transform = a3 === n2.TOP || a3 === n2.BOTTOM ? "translateY(".concat(r3 || 0, "px)") : "translateX(".concat(s3 || 0, "px)"));
            });
          }, i2 = (e3) => {
            requestAnimationFrame(() => {
              e3.current && (e3.current.style.transition = "none", e3.current.style.willChange = "", e3.current.style.transform = "");
            });
          };
          t2.useComponentSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: l2, disableSwipe: c2, placement: u2, threshold: f2 } = e3, d2 = (0, a2.useCallbackRef)(() => {
              l2 && (i2(t3), l2());
            }), x = (0, a2.useCallbackRef)((e4) => {
              c2 || ((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3 } = e5;
                switch (a3) {
                  case n2.TOP:
                    r4 <= 0 && o2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.RIGHT:
                    s3 >= 0 && o2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.LEFT:
                    s3 <= 0 && o2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  default:
                    r4 >= 0 && o2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2 });
            }), p = (0, a2.useCallbackRef)((e4) => {
              !c2 && (((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3, threshold: o3 = 25 } = e5;
                if (!t4.current) return false;
                let i3 = o3 / 100 * (a3 === n2.TOP || a3 === n2.BOTTOM ? t4.current.offsetHeight : t4.current.offsetWidth);
                switch (a3) {
                  case n2.TOP:
                    return r4 < 0 && Math.abs(r4) >= i3;
                  case n2.RIGHT:
                    return s3 > 0 && s3 >= i3;
                  case n2.LEFT:
                    return s3 < 0 && Math.abs(s3) >= i3;
                  default:
                    return r4 > 0 && r4 >= i3;
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2, threshold: f2 }) ? l2 && (i2(t3), l2()) : i2(t3));
            });
            return {
              handlers: (0, s2.useSwipeable)({ onSwiped: p, onSwiping: x, trackMouse: true, trackTouch: true, ...r3 }),
              onCloseCallback: d2
            };
          };
        },
        6699: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let n2 = r2(352), s2 = r2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: r3, throttleTimeout: a2 } = e3, o2 = (0, s2.useRef)(null), [i2, l2] = (0, s2.useState)(!!r3), c2 = (0, s2.useMemo)(
              () => (0, n2.throttle)(() => {
                l2(!r3), o2.current && window.clearTimeout(o2.current), o2.current = window.setTimeout(() => {
                  l2(!!r3);
                }, t3);
              }, a2),
              [t3, r3, a2]
            ), u2 = (0, s2.useCallback)(() => {
              l2(!!r3), o2.current && window.clearTimeout(o2.current);
            }, [r3]);
            return (0, s2.useEffect)(
              () => () => {
                o2.current && window.clearTimeout(o2.current);
              },
              []
            ), { state: i2, handleDebouncedToggle: c2, reset: u2 };
          };
        },
        5969: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.findOptimalFontSize = void 0;
          let n2 = r2(810), s2 = (e3) => {
            e3.style.wordBreak = "keep-all", e3.style.overflowWrap = "normal", e3.style.maxHeight = "none", e3.style.height = "auto", e3.style.overflow = "visible", Array.from(e3.children).forEach((e4) => {
              e4 instanceof HTMLElement && s2(e4);
            });
          };
          t2.findOptimalFontSize = (e3) => {
            let {
              container: t3,
              containerWidth: r3,
              containerHeight: n3,
              minFontSize: a2,
              maxFontSize: o2,
              lineHeight: i2,
              maxLines: l2
            } = e3, c2 = ((e4, t4, r4) => {
              let n4 = e4.cloneNode(true);
              return n4.style.cssText = "\n        position: absolute !important;\n        visibility: hidden !important;\n        pointer-events: none !important;\n        width: ".concat(
                t4,
                "px !important;\n    "
              ), s2(n4), n4.style.setProperty("--dynamic-line-height", String(r4)), document.body.appendChild(n4), n4;
            })(t3, r3, i2);
            try {
              let e4 = a2, t4 = o2, s3 = a2;
              for (; e4 <= t4; ) {
                let a3 = Math.floor((e4 + t4) / 2);
                c2.style.setProperty("--dynamic-font-size", "".concat(a3, "px"));
                let o3 = Math.min(l2 * a3 * i2, n3), u2 = c2.scrollHeight <= o3, f2 = c2.scrollWidth <= r3 + 1;
                u2 && f2 ? (s3 = a3, e4 = a3 + 1) : t4 = a3 - 1;
              }
              return s3 - 1;
            } finally {
              c2.remove();
            }
          }, t2.useDynamicText = (e3, r3) => {
            (0, n2.useLayoutEffect)(() => {
              if (null === e3) return;
              e3.style.setProperty("--dynamic-line-height", String(r3.lineHeight));
              let n3 = () => {
                let { width: n4, height: s4 } = e3.getBoundingClientRect(), a3 = e3.childNodes.length > 0;
                if (0 === n4 || 0 === s4 || !a3) return;
                let o2 = (0, t2.findOptimalFontSize)({ container: e3, containerWidth: n4, containerHeight: s4, ...r3 });
                e3.style.setProperty("--dynamic-font-size", "".concat(o2, "px"));
              }, s3 = new ResizeObserver(n3), a2 = new MutationObserver(n3);
              return s3.observe(e3), a2.observe(e3, { childList: true, characterData: true, subtree: true }), document.fonts.ready.then(n3), n3(), () => {
                s3.disconnect(), a2.disconnect();
              };
            }, [e3, r3]);
          };
        },
        2101: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useElementOffsetY = void 0;
          let n2 = r2(810), s2 = r2(2067), a2 = r2(2767);
          t2.useElementOffsetY = (e3) => {
            let [t3, r3] = (0, a2.useForceUpdateRef)(), [o2, i2] = (0, n2.useState)(), l2 = (0, n2.useCallback)(() => {
              let e4 = null == t3 ? void 0 : t3.getBoundingClientRect();
              e4 && i2(e4.y);
            }, [t3]);
            return (0, n2.useLayoutEffect)(l2), (0, s2.useScroll)({ onScroll: l2, elementRef: e3 }), { forceUpdateRefCallback: r3, offsetY: o2 };
          };
        },
        2767: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForceUpdateRef = void 0;
          let n2 = r2(810);
          t2.useForceUpdateRef = () => {
            let [e3, t3] = (0, n2.useState)(null);
            return [
              e3,
              (0, n2.useCallback)((e4) => {
                t3((t4) => t4 !== e4 ? e4 : t4);
              }, [])
            ];
          };
        },
        245: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForwardRef = void 0;
          let n2 = r2(810);
          t2.useForwardRef = function(e3, t3) {
            let r3 = (0, n2.useRef)(t3);
            return (0, n2.useEffect)(() => {
              e3 && ("function" == typeof e3 ? e3(r3.current) : e3.current = r3.current);
            }, [e3]), r3;
          };
        },
        5663: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIntersectionObserver = t2.createIntersectionObserver = t2.getElementNameByDataAttribute = t2.isInViewportNow = t2.defaultOptions = void 0;
          let n2 = r2(810), { innerWidth: s2 = 0, innerHeight: a2 = 0 } = window;
          function o2(e3) {
            let { top: t3, right: r3, bottom: n3, left: o3 } = e3.getBoundingClientRect();
            return (t3 >= 0 && t3 <= a2 || n3 >= 0 && n3 <= a2) && (o3 >= 0 && o3 <= s2 || r3 >= 0 && r3 <= s2);
          }
          function i2(e3) {
            var t3, r3;
            let n3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "data-intersection-property-id";
            return null != (r3 = null == e3 || null == (t3 = e3.getAttribute) ? void 0 : t3.call(e3, n3)) ? r3 : e3.attributes[0];
          }
          function l2(e3, t3) {
            let r3 = new IntersectionObserver((t4) => {
              t4.forEach((t5) => {
                e3(t5, r3);
              });
            }, t3);
            return r3;
          }
          t2.defaultOptions = { threshold: 0, preflightCheck: true }, t2.isInViewportNow = o2, t2.getElementNameByDataAttribute = i2, t2.createIntersectionObserver = l2, t2.useIntersectionObserver = function(e3, r3, s3) {
            let [{ freezeOnceVisible: a3, preflightCheck: c2, ...u2 }, f2 = false] = "boolean" == typeof r3 || void 0 === r3 ? [t2.defaultOptions, r3] : [{ ...t2.defaultOptions, ...r3 }, s3], [d2, x] = (0, n2.useState)({}), p = (0, n2.useRef)(/* @__PURE__ */ new Set()), _ = (0, n2.useMemo)(
              () => f2 ? null : l2((e4) => {
                let t3 = i2(e4.target);
                if (t3 && _) {
                  if (p.current.has(t3)) return;
                  x((r4) => ({ ...r4, [t3]: { isIntersecting: e4.isIntersecting } })), a3 && e4.isIntersecting && (p.current.add(t3), _.unobserve(e4.target));
                }
              }, u2),
              [f2]
            );
            return (0, n2.useLayoutEffect)(
              () => (_ && !f2 && e3.forEach((e4) => {
                if (e4.current) {
                  let t3 = false;
                  if (c2 && (t3 = o2(e4.current))) {
                    let t4 = i2(e4.current);
                    x((e5) => ({ ...e5, [t4]: { isIntersecting: true } }));
                  }
                  t3 || _.observe(e4.current);
                }
              }), () => {
                _ && _.disconnect();
              }),
              [f2, _, e3.length]
            ), d2;
          };
        },
        9019: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIsomorphicEffect = void 0;
          let n2 = r2(810);
          t2.useIsomorphicEffect = "undefined" != typeof document ? n2.useLayoutEffect : n2.useEffect;
        },
        5188: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useKeyboardNavigation = void 0;
          let n2 = r2(810);
          function s2(e3, t3) {
            return e3.current ? Array.from(t3 ? e3.current.querySelectorAll(t3) : e3.current.children) : [];
          }
          t2.useKeyboardNavigation = function(e3) {
            let t3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, { navigationItemsSelector: r3, activeAttributeName: a2 = "aria-selected" } = t3, o2 = (0, n2.useCallback)(
              (t4) => {
                let n3 = s2(e3, r3);
                if (!n3.length) return;
                let a3 = t4.target, o3 = n3.indexOf(a3);
                if (-1 === o3) return;
                let [i2] = n3, l2 = n3.at(-1), c2 = null;
                switch (t4.key) {
                  case "ArrowLeft":
                  case "ArrowUp":
                    c2 = n3[o3 - 1] || l2;
                    break;
                  case "ArrowRight":
                  case "ArrowDown":
                    c2 = n3[o3 + 1] || i2;
                    break;
                  case "Home":
                    c2 = i2;
                    break;
                  case "End":
                    c2 = l2;
                }
                null !== c2 && (c2.focus(), t4.preventDefault());
              },
              [r3, e3]
            );
            (0, n2.useEffect)(() => {
              let t4 = e3.current;
              return null == t4 || t4.addEventListener("keydown", o2), () => null == t4 ? void 0 : t4.removeEventListener("keydown", o2);
            }, [e3, o2]), (0, n2.useEffect)(() => {
              s2(e3, r3).forEach((e4) => {
                e4.hasAttribute(a2) && ("true" === e4.getAttribute(a2) ? e4.tabIndex = 0 : e4.tabIndex = -1);
              });
            });
          };
        },
        4395: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.usePopoverSwipeable = void 0;
          let n2 = r2(810), s2 = r2(1381);
          t2.usePopoverSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: a2, disableSwipe: o2, placement: i2, threshold: l2 } = e3, c2 = (0, n2.useMemo)(() => {
              switch (i2) {
                case "top":
                case "top-end":
                case "top-start":
                  return s2.SwipeablePlacement.TOP;
                case "right":
                case "right-end":
                case "right-start":
                  return s2.SwipeablePlacement.RIGHT;
                case "left":
                case "left-end":
                case "left-start":
                  return s2.SwipeablePlacement.LEFT;
                default:
                  return s2.SwipeablePlacement.BOTTOM;
              }
            }, [i2]);
            return (0, s2.useComponentSwipeable)({
              ref: t3,
              swipeableProps: r3,
              onClose: a2,
              disableSwipe: o2,
              placement: c2,
              threshold: l2
            });
          };
        },
        2947: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useResize = void 0;
          let n2 = r2(810), s2 = r2(361);
          t2.useResize = (e3, t3) => {
            (0, n2.useEffect)(() => {
              let r3 = (0, s2.getElementFromRefOrElement)(t3);
              if (null === r3) return;
              let n3 = null != r3 ? r3 : document.documentElement, a2 = new ResizeObserver(e3);
              return a2.observe(n3), () => a2.disconnect();
            }, [t3, e3]);
          };
        },
        998: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useReturnValue = void 0, t2.useReturnValue = (e3) => e3();
        },
        2067: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useScroll = void 0;
          let n2 = r2(810), s2 = r2(361), a2 = r2(6699);
          t2.useScroll = (e3) => {
            let { onScroll: t3, listenIsScrolling: r3, elementRef: o2 } = e3, { state: i2, handleDebouncedToggle: l2 } = (0, a2.useDebouncedToggle)({
              delay: 1e3,
              throttleTimeout: 100
            }), c2 = (0, n2.useCallback)(() => {
              r3 && l2(), null == t3 || t3();
            }, [r3, l2, t3]);
            return (0, n2.useEffect)(() => {
              let e4 = (0, s2.getElementFromRefOrElement)(o2);
              if (null === e4) return;
              let t4 = null != e4 ? e4 : window, r4 = { capture: true, passive: true };
              return t4.addEventListener("scroll", c2, r4), () => t4.removeEventListener("scroll", c2, r4);
            }, [o2, c2]), i2;
          };
        },
        4601: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useToggle = void 0;
          let n2 = r2(810);
          t2.useToggle = (e3) => {
            let [t3, r3] = (0, n2.useState)(e3);
            (0, n2.useEffect)(() => {
              r3(e3);
            }, [e3]);
            let s2 = (0, n2.useCallback)(() => {
              r3((e4) => !e4);
            }, []), a2 = (0, n2.useCallback)(() => {
              r3(true);
            }, []), o2 = (0, n2.useCallback)(() => {
              r3(false);
            }, []);
            return { state: t3, toggle: s2, setState: r3, toggleTrue: a2, toggleFalse: o2 };
          };
        },
        8796: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.createRipple = void 0, t2.createRipple = function(e3, t3, r2) {
            let n2 = null != r2 ? r2 : e3.currentTarget, s2 = document.createElement("span"), a2 = Math.max(n2.clientWidth, n2.clientHeight), o2 = a2 / 2, i2 = n2.getBoundingClientRect(), l2 = 0 === e3.clientX ? Math.round(i2.width / 2) : e3.clientX - i2.left, c2 = 0 === e3.clientY ? Math.round(i2.height / 2) : e3.clientY - i2.top;
            s2.style.width = "".concat(a2, "px"), s2.style.height = "".concat(a2, "px"), s2.style.left = 0 === e3.clientX ? "0px" : "".concat(l2 - o2, "px"), s2.style.top = "".concat(c2 - o2, "px"), s2.classList.add(t3);
            let u2 = n2.getElementsByClassName(t3)[0];
            u2 && u2.remove(), n2.insertBefore(s2, n2.firstChild);
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        8216: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = t2.createRipple = void 0;
          var n2 = r2(8796);
          Object.defineProperty(t2, "createRipple", {
            enumerable: true,
            get: function() {
              return n2.createRipple;
            }
          });
          var s2 = r2(361);
          Object.defineProperty(t2, "getElementFromRefOrElement", {
            enumerable: true,
            get: function() {
              return s2.getElementFromRefOrElement;
            }
          });
        },
        8119: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          let s2 = r2(4377), a2 = r2(810), o2 = r2(5881), i2 = r2(8216), l2 = n2(r2(1920)), c2 = (e3) => {
            let {
              forwardRef: t3,
              isBlock: r3,
              iconPosition: n3 = "left",
              children: c3,
              className: u2,
              color: f2 = "secondary",
              flexIcon: d2,
              icon: x,
              spinner: p,
              role: _,
              onClick: v,
              radius: g = "m",
              size: m,
              type: k = "button",
              variant: y = "default",
              withRipple: b = true,
              withHover: E = true,
              withBorder: w = false,
              disabled: h,
              iconClassName: O,
              contentContainerClassName: R,
              ...j
            } = e3, H = (0, a2.useId)(), P = !a2.Children.toArray(c3).filter(Boolean).length, C = "left" === n3, M = null, S = (0, a2.isValidElement)(p);
            if (x) {
              var L, T;
              M = (0, a2.cloneElement)(x, {
                className: (0, o2.clsx)(
                  l2.default.icon,
                  {
                    [l2.default["icon_position_".concat(n3)]]: n3 && !P,
                    [l2.default.icon_withButtonSize]: !(null == (L = x.props) ? void 0 : L.size)
                  },
                  null == (T = x.props) ? void 0 : T.className,
                  O
                ),
                key: H
              });
            }
            let D = (0, a2.useMemo)(
              () => S ? (0, s2.jsx)("div", { className: l2.default.spinnerContainer, children: p }) : null,
              [S, p]
            ), F = (0, a2.useCallback)(
              (e4) => {
                S || (b && (0, i2.createRipple)(e4, l2.default.ripple), null == v || v(e4));
              },
              [S, v, b]
            );
            return (0, s2.jsx)("button", {
              ref: t3,
              className: (0, o2.clsx)(
                l2.default.root,
                l2.default["root_".concat(f2, "_").concat(y)],
                l2.default["root_radius_".concat(g)],
                l2.default.root_size,
                {
                  [l2.default["root_".concat(f2, "_withHover_").concat(y)]]: E && !h && !S,
                  [l2.default["root_size_".concat(m)]]: m,
                  [l2.default.root_withoutBorder]: !w,
                  [l2.default.root_withActiveSpinner]: S,
                  [l2.default.block]: r3,
                  [l2.default.flexIcon]: d2,
                  [l2.default.iconOnly]: P,
                  [l2.default.root_icon_left]: x && !P && C,
                  [l2.default.root_icon_right]: x && !P && !C
                },
                u2
              ),
              type: k,
              role: _,
              onClick: F,
              ...j,
              disabled: h,
              "aria-live": S ? "polite" : "off",
              "aria-busy": S,
              children: x || S ? (0, s2.jsxs)("span", {
                className: (0, o2.clsx)(
                  l2.default.contentContainer,
                  { [l2.default.contentContainer_block]: r3 },
                  R
                ),
                children: [x && C && M, !P && c3, x && !C && M, D]
              }) : c3
            });
          };
          t2.Button = (0, a2.forwardRef)((e3, t3) => (0, s2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        5928: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          var n2 = r2(8119);
          Object.defineProperty(t2, "Button", {
            enumerable: true,
            get: function() {
              return n2.Button;
            }
          });
        },
        8324: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Dropdown = t2.DropdownComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), o2 = r2(810), i2 = r2(5062), l2 = r2(1688), c2 = n2(r2(7139));
          t2.DropdownComponent = (e3) => {
            let {
              reference: t3,
              onSelect: r3,
              onIconActiveState: n3,
              offsetOptions: u2 = 8,
              defaultValue: f2,
              placement: d2,
              header: x,
              isDisabled: p = false,
              footer: _,
              isMobile: v = false,
              children: g,
              forwardRef: m,
              className: k,
              containerClassName: y,
              strategy: b,
              ...E
            } = e3, w = (0, o2.useId)(), [h, O] = (0, o2.useState)(false), [R, j] = (0, o2.useState)(f2);
            (0, o2.useEffect)(() => {
              j(f2);
            }, [f2]);
            let H = (0, o2.useCallback)(() => {
              p || (O(!h), null == n3 || n3(!h));
            }, [p, h, n3]), P = (0, o2.useCallback)(
              (e4) => {
                j(e4.id), r3(e4), O(false), null == n3 || n3(false);
              },
              [r3, n3]
            ), C = t3.props && "object" == typeof t3.props ? t3.props : {}, M = "className" in C && "string" == typeof C.className ? C.className : "";
            return (0, s2.jsxs)(i2.Popover, {
              open: h,
              onOpenChange: H,
              placement: d2,
              offsetOptions: u2,
              isMobile: v,
              customRoleProps: { role: "menu" },
              "aria-labelledby": w,
              strategy: b,
              children: [
                (0, o2.cloneElement)(t3, {
                  id: w,
                  onClick: H,
                  disabled: p,
                  variant: "text",
                  withHover: false,
                  color: "primary",
                  className: (0, a2.clsx)(c2.default.button, M)
                }),
                (0, s2.jsx)(l2.PopoverContent, {
                  children: (0, s2.jsxs)("div", {
                    className: (0, a2.clsx)(c2.default.root, k),
                    ...E,
                    children: [
                      v && (0, s2.jsx)("div", { className: c2.default.swipeIcon }),
                      (0, s2.jsxs)("ul", {
                        ref: m,
                        className: (0, a2.clsx)(c2.default.container, { [c2.default.container_mobile]: v }, y),
                        children: [
                          x && (0, s2.jsx)("div", { className: c2.default.textContainer, children: x }),
                          o2.Children.map(g, (e4) => {
                            let t4 = e4.props;
                            return (0, o2.cloneElement)(e4, { key: t4.id, onClick: () => P(t4), isSelected: R === t4.id });
                          }),
                          _ && (0, s2.jsx)("div", { className: c2.default.textContainer, children: _ })
                        ]
                      })
                    ]
                  })
                })
              ]
            });
          }, t2.Dropdown = (0, o2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.DropdownComponent, { forwardRef: r3, ...e3 }));
        },
        1057: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Option = t2.OptionComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), o2 = r2(810), i2 = r2(1964), l2 = r2(5928), c2 = r2(7066), u2 = r2(2582), f2 = n2(r2(9184));
          t2.OptionComponent = (e3) => {
            let { id: t3, label: r3, isSelected: n3 = false, className: o3, forwardRef: d2, ...x } = e3, p = (0, i2.useListItem)(), _ = (0, i2.useMergeRefs)([p.ref, d2]);
            return (0, s2.jsx)("li", {
              className: f2.default.root,
              children: (0, s2.jsxs)(l2.Button, {
                className: (0, a2.clsx)(f2.default.button, o3),
                ref: _,
                id: t3,
                variant: "text",
                color: "primary",
                withHover: false,
                role: "menuitem",
                "aria-selected": n3,
                ...x,
                children: [
                  (0, s2.jsx)(u2.Caption, { variant: "span", className: f2.default.buttonText, children: r3 }),
                  n3 && (0, s2.jsx)(c2.Icon, { size: "xxs", variant: "check" })
                ]
              })
            });
          }, t2.Option = (0, o2.forwardRef)((e3, r3) => {
            let { children: n3, ...a3 } = e3;
            return (0, s2.jsx)(t2.OptionComponent, { forwardRef: r3, ...a3, children: n3 });
          });
        },
        5189: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = t2.IconComponent = void 0;
          let s2 = r2(4377), a2 = r2(810), o2 = r2(5881), i2 = r2(5151), l2 = n2(r2(2964));
          t2.IconComponent = (e3) => {
            let { "aria-label": t3, className: r3, focusable: n3 = false, variant: a3, size: c2, forwardRef: u2, ...f2 } = e3, d2 = c2 ? "".concat(a3, "_").concat(c2) : a3, x = i2.iconsCollection[d2];
            return x ? (0, s2.jsx)(x, {
              className: (0, o2.clsx)(l2.default.root, r3, l2.default["root_size_".concat(c2)]),
              focusable: n3,
              "aria-label": t3,
              ...f2,
              "aria-hidden": !t3,
              ref: u2
            }) : null;
          }, t2.Icon = (0, a2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.IconComponent, { forwardRef: r3, ...e3 }));
        },
        5151: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e10) {
            return e10 && e10.__esModule ? e10 : { default: e10 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.iconsCollection = t2.iconsCollectionBySize = void 0;
          let s2 = n2(r2(4656)), a2 = n2(r2(8170)), o2 = n2(r2(5565)), i2 = n2(r2(8127)), l2 = n2(r2(8993)), c2 = n2(r2(2933)), u2 = n2(r2(1334)), f2 = n2(r2(1426)), d2 = n2(r2(5378)), x = n2(r2(6579)), p = n2(r2(3935)), _ = n2(r2(3522)), v = n2(r2(7319)), g = n2(r2(8442)), m = n2(r2(2586)), k = n2(r2(5822)), y = n2(r2(5272)), b = n2(r2(4860)), E = n2(r2(8711)), w = n2(r2(8109)), h = n2(r2(4904)), O = n2(r2(5971)), R = n2(r2(3331)), j = n2(r2(9783)), H = n2(r2(8184)), P = n2(r2(4926)), C = n2(r2(3176)), M = n2(r2(4789)), S = n2(r2(8151)), L = n2(r2(8690)), T = n2(r2(1524)), D = n2(r2(2361)), F = n2(r2(3972)), N = n2(r2(9330)), A = n2(r2(7346)), B = n2(r2(2604)), I = n2(r2(6894)), z = n2(r2(6391)), U = n2(r2(9369)), W = n2(r2(226)), V = n2(r2(8130)), Y = n2(r2(5270)), Z = n2(r2(3560)), q = n2(r2(7513)), X = n2(r2(9838)), Q = n2(r2(9104)), K = n2(r2(7399)), J = n2(r2(5849)), G = n2(r2(3613)), $ = n2(r2(9372)), ee = n2(r2(3709)), et = n2(r2(3685)), er = n2(r2(3302)), en = n2(r2(811)), es = n2(r2(6122)), ea = n2(r2(5386)), eo = n2(r2(3201)), ei = n2(r2(9434)), el = n2(r2(2026)), ec = n2(r2(8112)), eu = n2(r2(8044)), ef = n2(r2(2754)), ed = n2(r2(5251)), ex = n2(r2(9370)), ep = n2(r2(5632)), e_ = n2(r2(1001)), ev = n2(r2(893)), eg = n2(r2(6331)), em = n2(r2(9876)), ek = n2(r2(1758)), ey = n2(r2(7196)), eb = n2(r2(7951)), eE = n2(r2(126)), ew = n2(r2(3112)), eh = n2(r2(8819)), eO = n2(r2(8772)), eR = n2(r2(5695)), ej = n2(r2(7171)), eH = n2(r2(9030)), eP = n2(r2(9422)), eC = n2(r2(1491)), eM = n2(r2(2337)), eS = n2(r2(9202)), eL = n2(r2(130)), eT = n2(r2(7923)), eD = n2(r2(3654)), eF = n2(r2(6507)), eN = n2(r2(3193)), eA = n2(r2(30)), eB = n2(r2(7802)), eI = n2(r2(3738)), ez = n2(r2(2340)), eU = n2(r2(2125)), eW = n2(r2(4014)), eV = n2(r2(896)), eY = n2(r2(1829)), eZ = n2(r2(1893)), eq = n2(r2(1563)), eX = n2(r2(1578)), eQ = n2(r2(9348)), eK = n2(r2(965)), eJ = n2(r2(3877)), eG = n2(r2(9968)), e$ = n2(r2(3778)), e0 = n2(r2(1084)), e1 = n2(r2(4254)), e8 = n2(r2(792)), e22 = n2(r2(8131)), e5 = n2(r2(1125)), e7 = n2(r2(9288)), e9 = n2(r2(976)), e3 = n2(r2(1874)), e4 = n2(r2(9863)), e6 = n2(r2(1945)), te = n2(r2(1580)), tt = n2(r2(4091)), tr = n2(r2(8090)), tn = n2(r2(895)), ts = n2(r2(5910)), ta = n2(r2(4892)), to = n2(r2(3366)), ti = n2(r2(5034)), tl = n2(r2(5792)), tc = n2(r2(9545)), tu = n2(r2(3362)), tf = n2(r2(1079)), td = n2(r2(8994)), tx = n2(r2(51)), tp = n2(r2(5218)), t_ = n2(r2(3049)), tv = n2(r2(380)), tg = n2(r2(2834)), tm = n2(r2(540)), tk = n2(r2(6174)), ty = n2(r2(7185)), tb = n2(r2(9351)), tE = n2(r2(2092)), tw = n2(r2(1162)), th = n2(r2(6837)), tO = n2(r2(2024)), tR = n2(r2(776)), tj = n2(r2(5720)), tH = n2(r2(2774)), tP = n2(r2(4997)), tC = n2(r2(3146)), tM = n2(r2(2084)), tS = n2(r2(3751)), tL = n2(r2(3076)), tT = n2(r2(2495)), tD = n2(r2(9509)), tF = n2(r2(8987)), tN = n2(r2(190)), tA = n2(r2(843)), tB = n2(r2(5122)), tI = n2(r2(7405)), tz = n2(r2(820)), tU = n2(r2(5443)), tW = n2(r2(8782)), tV = n2(r2(7252)), tY = n2(r2(3013)), tZ = n2(r2(5346)), tq = n2(r2(3792)), tX = n2(r2(1351)), tQ = n2(r2(8303)), tK = n2(r2(4777)), tJ = n2(r2(735)), tG = n2(r2(2176)), t$ = n2(r2(8235)), t0 = n2(r2(8915)), t1 = n2(r2(2037)), t8 = n2(r2(5197)), t22 = n2(r2(7026)), t5 = n2(r2(8664)), t7 = n2(r2(8619)), t9 = n2(r2(6130)), t3 = n2(r2(6210)), t4 = n2(r2(5596)), t6 = n2(r2(6644)), re = n2(r2(996)), rt = n2(r2(7031)), rr = n2(r2(4793)), rn = n2(r2(7076)), rs = n2(r2(8582)), ra = n2(r2(7643)), ro = n2(r2(9846)), ri = n2(r2(6275)), rl = n2(r2(3702)), rc = n2(r2(8550)), ru = n2(r2(857)), rf = n2(r2(6304)), rd = n2(r2(9040)), rx = n2(r2(4298)), rp = n2(r2(5132)), r_ = n2(r2(8868)), rv = n2(r2(8779)), rg = n2(r2(8503)), rm = n2(r2(1045)), rk = n2(r2(7341)), ry = n2(r2(9505)), rb = n2(r2(4483)), rE = n2(r2(8499)), rw = n2(r2(705)), rh = n2(r2(7402)), rO = n2(r2(1427)), rR = n2(r2(7934)), rj = n2(r2(2435)), rH = n2(r2(3918)), rP = n2(r2(2571)), rC = n2(r2(2161)), rM = n2(r2(5304)), rS = n2(r2(2646)), rL = n2(r2(7500)), rT = n2(r2(6104)), rD = n2(r2(2502)), rF = n2(r2(1754)), rN = n2(r2(6615)), rA = n2(r2(7942)), rB = n2(r2(1498)), rI = n2(r2(8861)), rz = n2(r2(6809)), rU = n2(r2(5266)), rW = n2(r2(1179)), rV = n2(r2(6206)), rY = n2(r2(9481)), rZ = n2(r2(7364)), rq = n2(r2(8577)), rX = n2(r2(5760)), rQ = n2(r2(5667)), rK = n2(r2(2639));
          t2.iconsCollectionBySize = {
            xxxs: [
              "adult",
              "arrowRight",
              "check",
              "close",
              "donation",
              "exclamation",
              "explicit",
              "listen",
              "play",
              "reset",
              "ruble",
              "users"
            ],
            xxs: [
              "add",
              "addToPlaylist",
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "artist",
              "bucket",
              "chain",
              "chartDown",
              "chartNew",
              "chartSame",
              "chartUp",
              "check",
              "clip",
              "close",
              "code",
              "crown",
              "dislike",
              "disliked",
              "download",
              "downloaded",
              "dragDots",
              "edit",
              "exclamation",
              "explicit",
              "eye_crossed",
              "filter",
              "info",
              "lightning",
              "like",
              "likeVariant",
              "liked",
              "likedVariant",
              "link",
              "lock",
              "lyrics",
              "macos",
              "menuArrow",
              "more",
              "next",
              "pause",
              "pencil",
              "pin",
              "pin_filled",
              "play",
              "playLast",
              "playNext",
              "podcasts",
              "previous",
              "repeat",
              "repeat_one",
              "reset",
              "rewindBackwards",
              "rewindForward",
              "ruble",
              "settings",
              "share",
              "shuffle",
              "syncLyrics",
              "trailer",
              "unpin",
              "upload",
              "vibe"
            ],
            xs: [
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "cast",
              "chain",
              "close",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "filter",
              "fullscreen",
              "like",
              "liked",
              "liteVersion",
              "lock",
              "more",
              "navigationCollection",
              "navigationConcerts",
              "navigationForYouAndTrends",
              "navigationKids",
              "navigationMyVibe",
              "navigationNonMusic",
              "navigationPlus",
              "navigationSearch",
              "next",
              "note",
              "pause",
              "pause_filled",
              "picture",
              "pin",
              "pin_filled",
              "play",
              "playQueue",
              "play_filled",
              "playlist",
              "previous",
              "repeat",
              "repeat_one",
              "rewindBackwards",
              "rewindForward",
              "search",
              "settings",
              "shuffle",
              "site",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "trailer",
              "unavailable",
              "volume",
              "volumeOff",
              "windows"
            ],
            s: [
              "adult",
              "album",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "likedVariant",
              "note",
              "pauseVibe",
              "picture",
              "playVibe",
              "playlist"
            ],
            m: [
              "collections",
              "collections_selected",
              "history",
              "home",
              "home_selected",
              "kids",
              "kids_selected",
              "like",
              "liked",
              "lock",
              "more",
              "non_music",
              "non_music_selected",
              "pause",
              "pause_filled",
              "play",
              "playQueue",
              "play_filled",
              "plusOutlined",
              "ruble",
              "search",
              "search_selected",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "ticket",
              "ticket_selected"
            ],
            l: [
              "add",
              "album",
              "download",
              "like",
              "pause_filled",
              "play_filled",
              "search",
              "speed_1_25x",
              "speed_1_5x",
              "speed_1_75x",
              "speed_1x",
              "speed_2x"
            ],
            xl: ["album", "clip", "note", "pause_filled", "picture", "play_filled", "playlist", "unavailable"],
            xxl: ["attention", "check", "next", "offline", "pause_filled", "play_filled", "previous", "search"],
            xxxl: ["attention"],
            "": [
              "bandlink",
              "booksLogo",
              "googlePlay",
              "huaweiAppGallery",
              "kinopoiskEn",
              "kinopoiskRu",
              "macos",
              "musicLogo",
              "musicLogoCenterEn",
              "musicLogoCenterRu",
              "musicLogoLeftEn",
              "musicLogoLeftRu",
              "plus",
              "plusBadge",
              "plusColor",
              "plusOutlined",
              "windows",
              "yandexBooksEn",
              "yandexBooksRu",
              "yandexPayEn",
              "yandexPayRu",
              "yandexPlusEn",
              "yandexPlusRu"
            ]
          }, t2.iconsCollection = {
            adult_xxxs: s2.default,
            arrowRight_xxxs: a2.default,
            check_xxxs: o2.default,
            close_xxxs: i2.default,
            donation_xxxs: l2.default,
            exclamation_xxxs: c2.default,
            explicit_xxxs: u2.default,
            listen_xxxs: f2.default,
            play_xxxs: d2.default,
            reset_xxxs: x.default,
            ruble_xxxs: p.default,
            users_xxxs: _.default,
            add_xxs: v.default,
            addToPlaylist_xxs: g.default,
            adult_xxs: m.default,
            album_xxs: k.default,
            arrowDown_xxs: y.default,
            arrowLeft_xxs: b.default,
            arrowRight_xxs: E.default,
            artist_xxs: w.default,
            bucket_xxs: h.default,
            chain_xxs: O.default,
            chartDown_xxs: R.default,
            chartNew_xxs: j.default,
            chartSame_xxs: H.default,
            chartUp_xxs: P.default,
            check_xxs: C.default,
            clip_xxs: M.default,
            close_xxs: S.default,
            code_xxs: L.default,
            crown_xxs: T.default,
            dislike_xxs: D.default,
            disliked_xxs: F.default,
            download_xxs: N.default,
            downloaded_xxs: A.default,
            dragDots_xxs: B.default,
            edit_xxs: I.default,
            exclamation_xxs: z.default,
            explicit_xxs: U.default,
            eye_crossed_xxs: W.default,
            filter_xxs: V.default,
            info_xxs: Y.default,
            lightning_xxs: Z.default,
            like_xxs: q.default,
            likeVariant_xxs: X.default,
            liked_xxs: Q.default,
            likedVariant_xxs: K.default,
            link_xxs: J.default,
            lock_xxs: G.default,
            lyrics_xxs: $.default,
            macos_xxs: ee.default,
            menuArrow_xxs: et.default,
            more_xxs: er.default,
            next_xxs: en.default,
            pause_xxs: es.default,
            pencil_xxs: ea.default,
            pin_xxs: eo.default,
            pin_filled_xxs: ei.default,
            play_xxs: el.default,
            playLast_xxs: ec.default,
            playNext_xxs: eu.default,
            podcasts_xxs: ef.default,
            previous_xxs: ed.default,
            repeat_xxs: ex.default,
            repeat_one_xxs: ep.default,
            reset_xxs: e_.default,
            rewindBackwards_xxs: ev.default,
            rewindForward_xxs: eg.default,
            ruble_xxs: em.default,
            settings_xxs: ek.default,
            share_xxs: ey.default,
            shuffle_xxs: eb.default,
            syncLyrics_xxs: eE.default,
            trailer_xxs: ew.default,
            unpin_xxs: eh.default,
            upload_xxs: eO.default,
            vibe_xxs: eR.default,
            adult_xs: ej.default,
            album_xs: eH.default,
            arrowDown_xs: eP.default,
            arrowLeft_xs: eC.default,
            arrowRight_xs: eM.default,
            cast_xs: eS.default,
            chain_xs: eL.default,
            close_xs: eT.default,
            dislike_xs: eD.default,
            disliked_xs: eF.default,
            exclamation_xs: eN.default,
            explicit_xs: eA.default,
            filter_xs: eB.default,
            fullscreen_xs: eI.default,
            like_xs: ez.default,
            liked_xs: eU.default,
            liteVersion_xs: eW.default,
            lock_xs: eV.default,
            more_xs: eY.default,
            navigationCollection_xs: eZ.default,
            navigationConcerts_xs: eq.default,
            navigationForYouAndTrends_xs: eX.default,
            navigationKids_xs: eQ.default,
            navigationMyVibe_xs: eK.default,
            navigationNonMusic_xs: eJ.default,
            navigationPlus_xs: eG.default,
            navigationSearch_xs: e$.default,
            next_xs: e0.default,
            note_xs: e1.default,
            pause_xs: e8.default,
            pause_filled_xs: e22.default,
            picture_xs: e5.default,
            pin_xs: e7.default,
            pin_filled_xs: e9.default,
            play_xs: e3.default,
            playQueue_xs: e4.default,
            play_filled_xs: e6.default,
            playlist_xs: te.default,
            previous_xs: tt.default,
            repeat_xs: tr.default,
            repeat_one_xs: tn.default,
            rewindBackwards_xs: ts.default,
            rewindForward_xs: ta.default,
            search_xs: to.default,
            settings_xs: ti.default,
            shuffle_xs: tl.default,
            site_xs: tc.default,
            speed_1_25x_centered_xs: tu.default,
            speed_1_5x_centered_xs: tf.default,
            speed_1_75x_centered_xs: td.default,
            speed_1x_centered_xs: tx.default,
            speed_2x_centered_xs: tp.default,
            syncLyrics_xs: t_.default,
            trailer_xs: tv.default,
            unavailable_xs: tg.default,
            volume_xs: tm.default,
            volumeOff_xs: tk.default,
            windows_xs: ty.default,
            adult_s: tb.default,
            album_s: tE.default,
            dislike_s: tw.default,
            disliked_s: th.default,
            exclamation_s: tO.default,
            explicit_s: tR.default,
            likedVariant_s: tj.default,
            note_s: tH.default,
            pauseVibe_s: tP.default,
            picture_s: tC.default,
            playVibe_s: tM.default,
            playlist_s: tS.default,
            collections_m: tL.default,
            collections_selected_m: tT.default,
            history_m: tD.default,
            home_m: tF.default,
            home_selected_m: tN.default,
            kids_m: tA.default,
            kids_selected_m: tB.default,
            like_m: tI.default,
            liked_m: tz.default,
            lock_m: tU.default,
            more_m: tW.default,
            non_music_m: tV.default,
            non_music_selected_m: tY.default,
            pause_m: tZ.default,
            pause_filled_m: tq.default,
            play_m: tX.default,
            playQueue_m: tQ.default,
            play_filled_m: tK.default,
            plusOutlined_m: tJ.default,
            ruble_m: tG.default,
            search_m: t$.default,
            search_selected_m: t0.default,
            speed_1_25x_centered_m: t1.default,
            speed_1_5x_centered_m: t8.default,
            speed_1_75x_centered_m: t22.default,
            speed_1x_centered_m: t5.default,
            speed_2x_centered_m: t7.default,
            syncLyrics_m: t9.default,
            ticket_m: t3.default,
            ticket_selected_m: t4.default,
            add_l: t6.default,
            album_l: re.default,
            download_l: rt.default,
            like_l: rr.default,
            pause_filled_l: rn.default,
            play_filled_l: rs.default,
            search_l: ra.default,
            speed_1_25x_l: ro.default,
            speed_1_5x_l: ri.default,
            speed_1_75x_l: rl.default,
            speed_1x_l: rc.default,
            speed_2x_l: ru.default,
            album_xl: rf.default,
            clip_xl: rd.default,
            note_xl: rx.default,
            pause_filled_xl: rp.default,
            picture_xl: r_.default,
            play_filled_xl: rv.default,
            playlist_xl: rg.default,
            unavailable_xl: rm.default,
            attention_xxl: rk.default,
            check_xxl: ry.default,
            next_xxl: rb.default,
            offline_xxl: rE.default,
            pause_filled_xxl: rw.default,
            play_filled_xxl: rh.default,
            previous_xxl: rO.default,
            search_xxl: rR.default,
            attention_xxxl: rj.default,
            bandlink: rH.default,
            booksLogo: rP.default,
            googlePlay: rC.default,
            huaweiAppGallery: rM.default,
            kinopoiskEn: rS.default,
            kinopoiskRu: rL.default,
            macos: rT.default,
            musicLogo: rD.default,
            musicLogoCenterEn: rF.default,
            musicLogoCenterRu: rN.default,
            musicLogoLeftEn: rA.default,
            musicLogoLeftRu: rB.default,
            plus: rI.default,
            plusBadge: rz.default,
            plusColor: rU.default,
            plusOutlined: rW.default,
            windows: rV.default,
            yandexBooksEn: rY.default,
            yandexBooksRu: rZ.default,
            yandexPayEn: rq.default,
            yandexPayRu: rX.default,
            yandexPlusEn: rQ.default,
            yandexPlusRu: rK.default
          };
        },
        7066: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = void 0;
          var n2 = r2(5189);
          Object.defineProperty(t2, "Icon", {
            enumerable: true,
            get: function() {
              return n2.Icon;
            }
          });
        },
        9430: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Popover = void 0;
          let s2 = r2(4377), a2 = r2(810), o2 = r2(1964), i2 = r2(5881), l2 = r2(6544), c2 = r2(5853), u2 = r2(7601), f2 = r2(4395), d2 = n2(r2(7820));
          t2.Popover = (e3) => {
            var t3;
            let {
              children: r3,
              offsetOptions: n3,
              strategy: x,
              placement: p,
              isMobile: _,
              visuallyHiddenDismiss: v,
              positionElement: g,
              transform: m,
              initialOpen: k = false,
              open: y,
              onOpenChange: b,
              disableFloatingStyles: E = false,
              overlayClassName: w,
              style: h,
              returnFocus: O,
              isNested: R = false,
              onShow: j,
              customRoleProps: H,
              portalNode: P,
              isEnabled: C = true,
              arrowProps: M,
              lockScroll: S = true,
              popoverContentRef: L,
              transitionDuration: T = 150
            } = e3, [D, F] = r3, [N, A] = (0, a2.useState)(k), [B, I] = (0, a2.useState)(null), z = (0, a2.useRef)([]), U = (0, a2.useRef)([]), W = (0, o2.useFloatingNodeId)(), V = (0, o2.useFloatingParentNodeId)(), Y = (0, o2.useListItem)(), Z = (0, o2.useFloatingTree)(), q = (0, a2.useRef)(null), X = b || A, Q = void 0 !== y, K = (0, a2.useCallback)(() => {
              X(false);
            }, [X]), {
              refs: J,
              floatingStyles: G,
              context: $
            } = (0, o2.useFloating)({
              nodeId: W,
              open: Q ? y : N,
              onOpenChange: X,
              placement: p,
              middleware: [
                (0, o2.offset)(n3),
                (0, o2.flip)({ crossAxis: null == p ? void 0 : p.includes("end") }),
                (0, o2.shift)({ padding: 5 }),
                ...(null == M ? void 0 : M.isEnabled) ? [(0, o2.arrow)({ element: q })] : []
              ],
              whileElementsMounted: o2.autoUpdate,
              strategy: x,
              transform: m
            }), ee = (0, a2.useId)(), et = (0, a2.useId)(), er = (0, o2.useListNavigation)($, { listRef: z, activeIndex: B, nested: R, onNavigate: I }), en = (0, o2.useTypeahead)($, { listRef: U, onMatch: N ? I : void 0, activeIndex: B });
            (0, a2.useEffect)(() => {
              if (!Z) return;
              let e4 = () => {
                A(false);
              }, t4 = (e5) => {
                e5.nodeId !== W && e5.parentId === V && A(false);
              };
              return Z.events.on("click", e4), Z.events.on("menuopen", t4), () => {
                Z.events.off("click", e4), Z.events.off("menuopen", t4);
              };
            }, [Z, W, V, A]), (0, a2.useEffect)(() => {
              N && (null == j || j());
            }, [j, N]), (0, a2.useEffect)(() => {
              N && Z && Z.events.emit("menuopen", { parentId: V, nodeId: W });
            }, [Z, N, W, V]), (0, a2.useLayoutEffect)(() => {
              g && J.setPositionReference(g);
            }, [J, g]);
            let { handlers: es } = (0, f2.usePopoverSwipeable)({
              ref: J.floating,
              onClose: K,
              placement: p,
              disableSwipe: !_,
              swipeableProps: { preventScrollOnSwipe: true }
            }), ea = L ? [J.setFloating, L] : [J.setFloating, null == es ? void 0 : es.ref], eo = (0, o2.useMergeRefs)(ea), ei = (0, o2.useRole)($, H), el = (0, o2.useDismiss)($, { referencePress: true }), ec = (0, o2.useClick)($, { enabled: C, toggle: !R, ignoreMouse: R }), eu = (0, o2.useHover)($, {
              enabled: R && C,
              handleClose: (0, o2.safePolygon)({ blockPointerEvents: true })
            }), ef = (0, a2.useCallback)((e4) => {
              e4.stopPropagation();
            }, []), {
              getReferenceProps: ed,
              getFloatingProps: ex,
              getItemProps: ep
            } = (0, o2.useInteractions)([ei, el, ec, eu, er, en]), [e_, ev] = (() => {
              switch (p) {
                case "bottom":
                default:
                  return ["translate(0, 10%)", "translate(0, 0)"];
                case "right":
                  if ("undefined" != typeof document && "rtl" === document.dir)
                    return ["translateX(-5%)", "translateX(0)"];
                  return ["translateX(5%)", "translateX(0)"];
              }
            })(), { isMounted: eg, styles: em } = (0, o2.useTransitionStyles)($, {
              initial: { opacity: 0, transform: e_ },
              open: { opacity: 1, transform: ev },
              duration: T
            }), ek = (0, o2.useMergeRefs)([J.setReference, Y.ref]), ey = D && (0, a2.cloneElement)(D, {
              ref: ek,
              ...ed({ onClick: null == (t3 = D.props) ? void 0 : t3.onClick }),
              key: ee
            }), eb = (0, a2.useMemo)(
              () => _ ? { ...E ? {} : G, ...h, bottom: 0, left: 0, right: 0, top: "auto", transform: "none" } : { ...E ? {} : G, ...h },
              [_, E, G, h]
            ), eE = (0, a2.useMemo)(() => {
              if (null == M ? void 0 : M.isEnabled) return (0, s2.jsx)(u2.PopoverArrow, { ref: q, context: $, ...M });
            }, [M, $]), ew = {
              ref: eo,
              style: { ...em, ...eb },
              ...ex(),
              onMouseDown: L || null == es ? void 0 : es.onMouseDown,
              arrow: eE,
              children: (0, a2.cloneElement)(F.props.children, { onClose: K, key: et })
            }, eh = (0, a2.cloneElement)(F, ew), eO = (0, a2.useMemo)(
              () => ({ activeIndex: B, setActiveIndex: I, getItemProps: ep, isOpen: N }),
              [B, ep, N]
            ), eR = R ? -1 : 0;
            return (0, s2.jsxs)(c2.PopoverContext.Provider, {
              value: eO,
              children: [
                ey,
                (0, s2.jsx)(o2.FloatingList, {
                  elementsRef: z,
                  children: eg && (0, s2.jsxs)(o2.FloatingPortal, {
                    root: P,
                    children: [
                      (0, s2.jsx)(o2.FloatingOverlay, { className: (0, i2.clsx)(d2.default.overlay, w), onClick: ef }),
                      (0, s2.jsx)(o2.FloatingFocusManager, {
                        context: $,
                        returnFocus: O,
                        initialFocus: eR,
                        visuallyHiddenDismiss: v,
                        children: (0, s2.jsx)(l2.RemoveScroll, { enabled: S && N, children: eh })
                      })
                    ]
                  })
                })
              ]
            });
          };
        },
        7601: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverArrow = t2.PopoverArrowComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), o2 = r2(810), i2 = r2(9110), l2 = r2(4601), c2 = n2(r2(4123)), u2 = { top: "", left: "rotate(-90deg)", bottom: "rotate(180deg)", right: "rotate(90deg)" };
          t2.PopoverArrowComponent = (e3) => {
            let {
              forwardRef: t3,
              className: r3,
              context: n3,
              width: o3 = 14,
              height: f2 = 7,
              tipRadius: d2 = 0,
              customClipPath: x,
              staticOffset: p,
              style: { transform: _, ...v } = {},
              isEnabled: g,
              ...m
            } = e3, {
              placement: k,
              elements: { floating: y },
              middlewareData: { arrow: b }
            } = n3, { state: E, toggleTrue: w } = (0, l2.useToggle)(false);
            if ((0, i2.useIsomorphicEffect)(() => {
              y && "rtl" === getComputedStyle(y).direction && w();
            }, [y, w]), !y || !g)
              return null;
            let h = o3 / 2 * (-(d2 / 8) + 1), O = f2 / 2 * d2 / 4, [R, j] = k.split("-"), H = p && "end" === j ? "right" : "left";
            p && E && (H = "end" === j ? "left" : "right");
            let P = (null == b ? void 0 : b.x) ? p || b.x : "", C = (null == b ? void 0 : b.y) ? p || b.y : "", M = u2[R], S = x || '"M0,0' + " H".concat(o3) + " L".concat(o3 - h, ",").concat(f2 - O) + " Q".concat(o3 / 2, ",").concat(f2, " ").concat(h, ",").concat(f2 - O) + ' Z"', L = {
              [H]: P,
              [p && "end" === j ? "bottom" : "top"]: C,
              [R]: "100%",
              transform: "".concat(M).concat(null != _ ? _ : ""),
              "--arrow-width": "".concat(o3, "px"),
              "--arrow-clip-path": S,
              ...v
            };
            return (0, s2.jsx)("div", { ...m, className: (0, a2.clsx)(c2.default.root, r3), ref: t3, style: L });
          }, t2.PopoverArrow = (0, o2.forwardRef)(
            (e3, r3) => (0, s2.jsx)(t2.PopoverArrowComponent, { forwardRef: r3, ...e3 })
          );
        },
        1688: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverContent = t2.PopoverContentComponent = void 0;
          let s2 = r2(4377), a2 = r2(810), o2 = r2(5881), i2 = n2(r2(5909));
          t2.PopoverContentComponent = (e3) => {
            let { className: t3, children: r3, forwardRef: n3, arrow: l2, ...c2 } = e3;
            return (0, s2.jsxs)("div", {
              className: (0, o2.clsx)(i2.default.root, t3),
              ref: n3,
              ...c2,
              children: [r3, (0, a2.isValidElement)(l2) && l2]
            });
          }, t2.PopoverContent = (0, a2.forwardRef)(
            (e3, r3) => (0, s2.jsx)(t2.PopoverContentComponent, { forwardRef: r3, ...e3 })
          );
        },
        5853: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverContext = void 0, t2.PopoverContext = (0, r2(810).createContext)({
            getItemProps: () => ({}),
            activeIndex: null,
            setActiveIndex: () => {
            },
            isOpen: false
          });
        },
        5062: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverContent = t2.Popover = void 0;
          var n2 = r2(9430);
          Object.defineProperty(t2, "Popover", {
            enumerable: true,
            get: function() {
              return n2.Popover;
            }
          });
          var s2 = r2(1688);
          Object.defineProperty(t2, "PopoverContent", {
            enumerable: true,
            get: function() {
              return s2.PopoverContent;
            }
          });
        },
        7743: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Caption = t2.CaptionComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), o2 = r2(810), i2 = r2(4721), l2 = n2(r2(3641));
          t2.CaptionComponent = (e3) => {
            let {
              forwardRef: t3,
              variant: r3,
              type: n3 = "text",
              size: o3 = "s",
              className: c2,
              children: u2,
              weight: f2 = "medium",
              ...d2
            } = e3;
            return (0, s2.jsx)(i2.Typography, {
              variant: r3,
              ref: t3,
              className: (0, a2.clsx)(
                l2.default.root,
                l2.default["root_".concat(n3, "_").concat(o3)],
                l2.default["root_weight_".concat(f2)],
                c2
              ),
              ...d2,
              children: u2
            });
          }, t2.Caption = (0, o2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.CaptionComponent, { forwardRef: r3, ...e3 }));
        },
        404: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.HeadingComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), o2 = r2(810), i2 = r2(4721), l2 = n2(r2(5153));
          t2.HeadingComponent = (e3) => {
            let { forwardRef: t3, variant: r3, weight: n3 = "bold", size: o3 = "s", className: c2, children: u2, ...f2 } = e3;
            return (0, s2.jsx)(i2.Typography, {
              variant: r3,
              ref: t3,
              className: (0, a2.clsx)(
                l2.default.root,
                l2.default["root_size_".concat(o3)],
                l2.default["root_weight_".concat(n3)],
                c2
              ),
              ...f2,
              children: u2
            });
          }, t2.Heading = (0, o2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.HeadingComponent, { forwardRef: r3, ...e3 }));
        },
        4721: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Typography = t2.TypographyComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), o2 = r2(810), i2 = n2(r2(5818));
          function l2(e3) {
            let { forwardRef: t3, style: r3, className: n3, children: o3, variant: l3, lineClamp: c2, ...u2 } = e3, f2 = c2 && "string" == typeof o3 ? o3 : void 0;
            return (0, s2.jsx)(l3, {
              style: { ...r3, WebkitLineClamp: c2 },
              ref: t3,
              title: f2,
              className: (0, a2.clsx)(
                i2.default.root,
                {
                  [i2.default.root_clamp]: c2 && c2 > 0,
                  [i2.default.root_clamp_oneline]: c2 && 1 === c2,
                  [i2.default.root_clamp_multiline]: c2 && c2 > 1
                },
                n3
              ),
              ...u2,
              children: o3
            });
          }
          t2.TypographyComponent = l2, t2.Typography = (0, o2.forwardRef)((e3, t3) => (0, s2.jsx)(l2, { forwardRef: t3, ...e3 }));
        },
        2582: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.Caption = void 0;
          var n2 = r2(7743);
          Object.defineProperty(t2, "Caption", {
            enumerable: true,
            get: function() {
              return n2.Caption;
            }
          });
          var s2 = r2(404);
          Object.defineProperty(t2, "Heading", {
            enumerable: true,
            get: function() {
              return s2.Heading;
            }
          });
        },
        1964: (e2) => {
          e2.exports = s;
        },
        352: (e2) => {
          e2.exports = a;
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(o, 2));
        }
      }, l = {};
      function c(e2) {
        var t2 = l[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = l[e2] = { exports: {} };
        return i[e2].call(r2.exports, r2, r2.exports, c), r2.exports;
      }
      c.d = (e2, t2) => {
        for (var r2 in t2) c.o(t2, r2) && !c.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, c.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), c.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      }, c.nc = void 0;
      var u = {};
      (() => {
        Object.defineProperty(u, "X$", { value: true }), u.Wx = u.Lt = void 0;
        var e2 = c(8324);
        Object.defineProperty(u, "Lt", {
          enumerable: true,
          get: function() {
            return e2.Dropdown;
          }
        });
        var t2 = c(1057);
        Object.defineProperty(u, "Wx", {
          enumerable: true,
          get: function() {
            return t2.Option;
          }
        });
      })();
      var f = u.Lt, d = u.Wx;
      u.X$;
    }
  }
]);
