(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1752],
  {
    5751: (e) => {
      e.exports = {
        content: "MusicSectionMobile_content__lAARM",
        card: "MusicSectionMobile_card__f5Xnr",
        logo_ru: "MusicSectionMobile_logo_ru__itG4j",
        logo_en: "MusicSectionMobile_logo_en__Tv2yd"
      };
    },
    9646: (e) => {
      e.exports = {
        root: "MainCardDesktop_root__qa00U",
        root_horizontal: "MainCardDesktop_root_horizontal__Fy_E0",
        textContainer: "MainCardDesktop_textContainer__mzWGu",
        imageContainer: "MainCardDesktop_imageContainer__81MQy",
        image: "MainCardDesktop_image__nUJz3",
        root_vertical: "MainCardDesktop_root_vertical__KGeJ2",
        imageContainer_align_center: "MainCardDesktop_imageContainer_align_center__kEU_O",
        imageContainer_align_right: "MainCardDesktop_imageContainer_align_right__T12Qo",
        text: "MainCardDesktop_text__omw7l"
      };
    },
    10628: (e) => {
      e.exports = {
        root: "BuySubscriptionBlock_root__vcGLK",
        text_main: "BuySubscriptionBlock_text_main__fU5RA",
        text_addition: "BuySubscriptionBlock_text_addition__bbHYT",
        text_secondary: "BuySubscriptionBlock_text_secondary__ZT9ke",
        buttonContainer: "BuySubscriptionBlock_buttonContainer__Tu2hm",
        root_withSecondButton: "BuySubscriptionBlock_root_withSecondButton___v2dL",
        button: "BuySubscriptionBlock_button__EqUAg",
        stickyContainer: "BuySubscriptionBlock_stickyContainer__yA50y",
        stickyContainer_enter: "BuySubscriptionBlock_stickyContainer_enter__50hEo",
        stickyContainer_enter_active: "BuySubscriptionBlock_stickyContainer_enter_active__4vFVC",
        "animation-show": "BuySubscriptionBlock_animation-show__xlvuU",
        stickyContainer_exit: "BuySubscriptionBlock_stickyContainer_exit__9Axef",
        stickyContainer_exit_active: "BuySubscriptionBlock_stickyContainer_exit_active__HjXVn",
        "animation-hide": "BuySubscriptionBlock_animation-hide__gnUki"
      };
    },
    13193: (e, t, s) => {
      "use strict";
      s.d(t, { pU: () => tL, cw: () => tI, Sz: () => b });
      var r, a, n, i, l, o, c, x, d, u, f, _, m, p, g = s(93064), v = s(26433);
      let b = g.gK.model({ modal: v.qt }).actions((e10) => ({
        openModal() {
          e10.modal.open();
        },
        closeModal() {
          let { desktopPaywall: t2 } = (0, g.Zn)(e10);
          t2.startCrackdownTimeout(), e10.modal.close();
        },
        onOpenChange(t2) {
          if (!t2) {
            let { desktopPaywall: t3 } = (0, g.Zn)(e10);
            t3.startCrackdownTimeout();
          }
          e10.modal.onOpenChange(t2);
        }
      }));
      var k = s(54486), y = s(50420), E = s(28303), h = s(61910), j = s(31500), w = s(27510), O = s(85284), R = s(74125), S = (function(e10) {
        return e10.RU = "ru", e10.BY = "by", e10.OTHER = "other", e10;
      })({});
      let C = { [R.ij5.RU]: S.RU, [R.ij5.BY]: S.BY };
      var A = s(17017), N = s.n(A), L = s(55994), H = s.n(L), P = s(47713), T = s(80585);
      let I = (e10) => {
        let { className: t2, faqProps: s2, variant: r2 } = e10, { location: a2 } = (0, R.Pjs)(), n2 = {
          cancelUntilEndQuestion: (0, k.jsx)(P.A, {
            id: "paywall.faq-question-cancel-until-end-other-countries",
            values: { nbsp: " " }
          }),
          cancelUntilEndStep1Link: (0, k.jsx)(P.A, {
            id: "paywall.faq-answer-cancel-until-end-step-1-link-other-countries"
          }),
          cancelUntilEndStep2: (0, k.jsx)(P.A, {
            id: "paywall.faq-answer-cancel-until-end-step-2-other-countries",
            values: { nbsp: " " }
          }),
          afraidForgetCancel: (0, k.jsx)(P.A, {
            id: "paywall.faq-question-afraid-forget-cancel-other-countries",
            values: { nbsp: " " }
          }),
          whereElseSubscribe: (0, k.jsx)(P.A, {
            id: "paywall.faq-question-where-else-subscribe-other-countries",
            values: { nbsp: " " }
          })
        };
        r2 === S.RU && (n2.cancelUntilEndQuestion = (0, k.jsx)(P.A, {
          id: "paywall.faq-question-cancel-until-end",
          values: { nbsp: " " }
        }), n2.cancelUntilEndStep1Link = (0, k.jsx)(P.A, { id: "paywall.faq-answer-cancel-until-end-step-1-link" }), n2.cancelUntilEndStep2 = (0, k.jsx)(P.A, {
          id: "paywall.faq-answer-cancel-until-end-step-2",
          values: { nbsp: " " }
        }), n2.afraidForgetCancel = (0, k.jsx)(P.A, {
          id: "paywall.faq-question-afraid-forget-cancel",
          values: { nbsp: " " }
        }), n2.whereElseSubscribe = (0, k.jsx)(P.A, {
          id: "paywall.faq-question-where-else-subscribe",
          values: { nbsp: " " }
        }));
        let i2 = {
          nbsp: " ",
          steps: (0, k.jsxs)("ul", {
            className: T.VN.list,
            children: [
              (0, k.jsx)("li", {
                className: T.VN.listITem,
                children: (0, k.jsx)(P.A, {
                  id: "paywall.faq-answer-cancel-until-end-step-1",
                  values: {
                    link: (0, k.jsx)(T.N_, {
                      className: T.VN.link,
                      href: "http://plus.yandex.".concat(a2.tld, "/my"),
                      target: "_blank",
                      children: n2.cancelUntilEndStep1Link
                    })
                  }
                })
              }),
              (0, k.jsx)("li", { className: T.VN.listITem, children: n2.cancelUntilEndStep2 })
            ]
          })
        };
        return (0, k.jsxs)(T.Bh, {
          className: t2,
          ...s2,
          ...(0, j.Am)(j.e8.paywall.PAYWALL_FAQ_SECTION),
          children: [
            (0, k.jsx)(T.ot, {
              question: (0, k.jsx)(T.nI, {
                children: (0, k.jsx)(P.A, { id: "paywall.faq-question-without-card-binding" })
              }),
              answer: (0, k.jsx)(T.L9, {
                children: (0, k.jsx)(P.A, {
                  id: "paywall.faq-answer-without-card-binding",
                  values: { nbsp: " " }
                })
              }),
              questionDataTestId: (0, j.Am)(j.e8.paywall.PAYWALL_FAQ_ITEM_DEMO_PERIOD_QUESTION),
              answerDataTestId: (0, j.Am)(j.e8.paywall.PAYWALL_FAQ_ITEM_DEMO_PERIOD_ANSWER)
            }),
            (0, k.jsx)(T.ot, {
              question: (0, k.jsx)(T.nI, { children: n2.afraidForgetCancel }),
              answer: (0, k.jsx)(T.L9, {
                children: (0, k.jsx)(P.A, {
                  id: "paywall.faq-answer-afraid-forget-cancel",
                  values: { nbsp: " " }
                })
              }),
              questionDataTestId: (0, j.Am)(j.e8.paywall.PAYWALL_FAQ_ITEM_FORGET_CANCEL_SUB_QUESTION),
              answerDataTestId: (0, j.Am)(j.e8.paywall.PAYWALL_FAQ_ITEM_FORGET_CANCEL_SUB_ANSWER)
            }),
            (0, k.jsx)(T.ot, {
              question: (0, k.jsx)(T.nI, { children: n2.cancelUntilEndQuestion }),
              answer: (0, k.jsx)(T.L9, {
                children: r2 === S.RU ? (0, k.jsx)(P.A, { id: "paywall.faq-answer-cancel-until-end", values: i2 }) : (0, k.jsx)(P.A, { id: "paywall.faq-answer-cancel-until-end-other-countries", values: i2 })
              }),
              questionDataTestId: (0, j.Am)(j.e8.paywall.PAYWALL_FAQ_ITEM_CAN_CANCEL_SUB_QUESTION),
              answerDataTestId: (0, j.Am)(j.e8.paywall.PAYWALL_FAQ_ITEM_CAN_CANCEL_SUB_ANSWER)
            }),
            false
          ]
        });
      }, M = (0, E.PA)((e10) => {
        let { variant: t2 } = e10, { location: s2 } = (0, R.Pjs)(), r2 = t2 === S.RU ? (0, k.jsx)(P.A, { id: "paywall-footer.subscription-terms-link" }) : (0, k.jsx)(P.A, { id: "paywall-footer.subscription-terms-link-other-countries" });
        return (0, k.jsx)(T.c, {
          ageRestriction: "0+",
          links: [
            {
              href: "https://yandex.".concat(s2.tld, "/legal/yandex_plus_conditions/"),
              text: r2,
              testId: j.e8.paywall.PAYWALL_FOOTER_ITEM_CONDITIONS_SUB
            },
            {
              href: "https://yandex.".concat(s2.tld, "/legal/yandex_plus_privilege_list"),
              text: (0, k.jsx)(P.A, { id: "paywall-footer.privileges-terms-link" }),
              testId: j.e8.paywall.PAYWALL_FOOTER_ITEM_CONDITIONS_PRIVILEGE
            },
            {
              href: "https://yandex.".concat(s2.tld, "/legal/plus_loyalty/"),
              text: (0, k.jsx)(P.A, { id: "paywall-footer.cashback-terms-link" }),
              testId: j.e8.paywall.PAYWALL_FOOTER_ITEM_CONDITIONS_CASHBACK
            },
            {
              href: "https://yandex.".concat(s2.tld, "/legal/plus_generalrules/"),
              text: (0, k.jsx)(P.A, { id: "paywall-footer.promotion-terms-link" }),
              testId: j.e8.paywall.PAYWALL_FOOTER_ITEM_CONDITIONS_PROMO
            },
            {
              href: "https://yandex.".concat(s2.tld, "/support/plus"),
              text: (0, k.jsx)(P.A, { id: "paywall-footer.support-link" }),
              testId: j.e8.paywall.PAYWALL_FOOTER_ITEM_SUPPORT
            }
          ]
        });
      });
      var D = s(5956), B = s(39610), U = s(97800), F = s(15209), W = s(58360), z = s(9646), Y = s.n(z);
      let K = (e10) => {
        let {
          variant: t2 = "horizontal",
          className: s2,
          text: r2,
          imageAlign: a2 = "center",
          imageSrc: n2,
          image2xSrc: i2,
          ...l2
        } = e10;
        return (0, k.jsxs)("div", {
          className: (0, y.$)(Y().root, Y()["root_".concat(t2)], s2),
          ...(0, F.getDataAttrFromProps)(l2),
          children: [
            (0, k.jsx)("div", {
              className: Y().textContainer,
              children: (0, k.jsx)(U.Heading, { variant: "h3", size: "xl", className: Y().text, children: r2 })
            }),
            (0, k.jsx)("div", {
              className: (0, y.$)(Y().imageContainer, Y()["imageContainer_align_".concat(a2)]),
              children: (0, k.jsx)(W.Image, {
                className: Y().image,
                src: n2,
                srcSet: i2 ? "".concat(i2, " 2x") : void 0,
                fit: "horizontal" === t2 ? "cover" : "none",
                "aria-hidden": true
              })
            })
          ]
        });
      };
      var V = s(88297), q = s.n(V);
      let Z = (e10) => {
        let { id: t2, className: s2, contentClassName: r2, heading: a2, content: n2, ...i2 } = e10;
        return (0, k.jsxs)("section", {
          className: (0, y.$)(q().root, s2),
          id: t2,
          ...(0, F.getDataAttrFromProps)(i2),
          children: [
            (0, k.jsx)("div", { className: q().headingContainer, children: a2 }),
            (0, k.jsx)("div", { className: (0, y.$)(q().contentContainer, r2), children: n2 })
          ]
        });
      };
      var Q = s(15485), G = s.n(Q);
      let X = {
        [S.RU]: "https://avatars.mds.yandex.net/get-music-misc/69699/img.66743ac814d05542b9b518b4/orig",
        [S.BY]: "https://avatars.mds.yandex.net/get-music-misc/69699/img.66b2317aaf6bde7f5d486c61/orig"
      }, J = {
        [S.RU]: "https://avatars.mds.yandex.net/get-music-misc/30221/img.66743aea14d05542b9b518b6/orig",
        [S.BY]: "https://avatars.mds.yandex.net/get-music-misc/49997/img.66b2317caf6bde7f5d486c62/orig"
      }, $ = (e10) => {
        let { className: t2, variant: s2 = S.RU } = e10, r2 = (0, R.jjz)();
        return (0, k.jsx)(Z, {
          className: t2,
          contentClassName: G()["content_".concat(s2)],
          heading: (0, k.jsxs)(k.Fragment, {
            children: [
              (0, k.jsx)(D.Icon, {
                variant: "kinopoisk".concat(r2),
                className: G()["logo_".concat(r2.toLocaleLowerCase())]
              }),
              (0, k.jsx)(B.q, {
                children: (0, k.jsx)(U.Heading, {
                  variant: "h2",
                  children: (0, k.jsx)(P.A, { id: "paywall.kinopoisk-part-title" })
                })
              })
            ]
          }),
          content: (0, k.jsxs)(k.Fragment, {
            children: [
              (0, k.jsx)(K, {
                className: G().card1,
                variant: "vertical",
                text: (0, k.jsx)(P.A, {
                  id: "paywall.kinopoisk-part-benefit-movies",
                  values: { br: "\n", nbsp: " " }
                }),
                imageSrc: X[s2],
                image2xSrc: J[s2],
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_CHOOSE_FILM)
              }),
              (0, k.jsx)(K, {
                className: G().card2,
                text: (0, k.jsx)(P.A, {
                  id: "paywall.kinopoisk-part-benefit-exclusive",
                  values: { br: "\n", nbsp: " " }
                }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/70850/img.66743b78de307e536b5852ba/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/49997/img.66743b96de307e536b5852bc/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_WATCH_EXCLUSIVES)
              }),
              s2 === S.RU && (0, k.jsx)(K, {
                className: G().card3,
                text: (0, k.jsx)(P.A, {
                  id: "paywall.kinopoisk-part-benefit-sport",
                  values: { br: "\n", nbsp: " " }
                }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/2413828/img.66743e3514d05542b9b518ff/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/34161/img.66743e5514d05542b9b51902/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_WATCH_SPORT)
              }),
              (0, k.jsx)(K, {
                className: G().card4,
                variant: "vertical",
                text: (0, k.jsx)(P.A, {
                  id: "paywall.kinopoisk-part-benefit-channels",
                  values: { br: "\n", nbsp: " " }
                }),
                imageAlign: "right",
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/2419084/img.66743c3c14d05542b9b518f8/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/70683/img.66743c5514d05542b9b518fa/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_MANY_CHANNELS)
              })
            ]
          }),
          ...(0, j.Am)(j.e8.paywall.PAYWALL_KINOPOISK_SECTION)
        });
      };
      var ee = s(65749), et = s(98922), es = s.n(et);
      let er = "content-anchor", ea = (e10) => {
        let { className: t2, shouldShowLabel: s2 = true, anchorId: r2 = er, children: a2 } = e10;
        return (0, k.jsxs)(ee.N, {
          className: (0, y.$)(es().root, t2),
          href: "#".concat(r2),
          role: "button",
          children: [
            (0, k.jsx)("div", { className: es().content, children: a2 }),
            s2 && (0, k.jsx)(U.Caption, {
              variant: "span",
              children: (0, k.jsx)(P.A, { id: "paywall.more-info", values: { nbsp: " " } })
            }),
            (0, k.jsx)(D.Icon, { variant: "arrowDown", size: "xs" })
          ]
        });
      };
      var en = s(19950), ei = s.n(en);
      let el = (e10) => {
        let { className: t2, variant: s2 = S.RU } = e10, r2 = (0, R.jjz)(), a2 = (0, h.useMemo)(
          () => s2 === S.RU ? (0, k.jsx)(P.A, { id: "paywall.music-part-benefit-books", values: { br: "\n", nbsp: " " } }) : (0, k.jsx)(P.A, {
            id: "paywall.music-part-benefit-books-alternative",
            values: { br: "\n", nbsp: " " }
          }),
          [s2]
        );
        return (0, k.jsx)(Z, {
          id: er,
          className: t2,
          contentClassName: ei().content,
          heading: (0, k.jsxs)(k.Fragment, {
            children: [
              (0, k.jsx)(D.Icon, {
                variant: "musicLogoCenter".concat(r2),
                className: ei()["logo_".concat(r2.toLocaleLowerCase())]
              }),
              (0, k.jsx)(B.q, {
                children: (0, k.jsx)(U.Heading, {
                  variant: "h2",
                  children: (0, k.jsx)(P.A, { id: "paywall.music-part-title", values: { nbsp: " " } })
                })
              })
            ]
          }),
          content: (0, k.jsxs)(k.Fragment, {
            children: [
              (0, k.jsx)(K, {
                className: ei().card,
                variant: "vertical",
                text: (0, k.jsx)(P.A, {
                  id: "paywall.music-part-benefit-recommendations",
                  values: { br: "\n", nbsp: " " }
                }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/2413828/img.6672d19b5a94b319a48169ce/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/34161/img.6672b094f164645e9c012622/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_FIND_INTERESTING)
              }),
              (0, k.jsx)(K, {
                className: ei().card,
                text: (0, k.jsx)(P.A, {
                  id: "paywall.music-part-benefit-many-devices",
                  values: { br: "\n", nbsp: " " }
                }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/30221/img.6672d53cef7546320ecbe015/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/69699/img.6672d45cff447523654b51a4/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_SMART_RECOMENDATIONS)
              }),
              (0, k.jsx)(K, {
                className: ei().card,
                text: (0, k.jsx)(P.A, {
                  id: "paywall.music-part-benefit-without-internet",
                  values: { br: "\n", nbsp: " " }
                }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/69699/img.6703f9237733220b25bd3744/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/2406661/img.6703f91a37dd1d4ade86c11a/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_LISTEN_WITHOUT_INTERNET)
              }),
              (0, k.jsx)(K, {
                className: ei().card,
                text: (0, k.jsx)(P.A, {
                  id: "paywall.music-part-benefit-playlists",
                  values: { br: "\n", nbsp: " " }
                }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/2413828/img.66740bd5ff447523654b56e3/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/2413828/img.66740bb7ff447523654b56b7/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_MAKE_COLLECTIONS)
              }),
              (0, k.jsx)(K, {
                className: ei().card,
                variant: "vertical",
                text: a2,
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/34161/img.6674522214d05542b9b51983/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/70850/img.6674527a14d05542b9b51985/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_LISTEN_AUDIOBOKS)
              })
            ]
          }),
          ...(0, j.Am)(j.e8.paywall.PAYWALL_MUSIC_SECTION)
        });
      };
      var eo = s(36382), ec = s.n(eo);
      let ex = (e10) => {
        let { className: t2, variant: s2 = S.RU } = e10, r2 = (0, R.jjz)();
        return (0, k.jsx)(Z, {
          className: t2,
          contentClassName: ec()["content_".concat(s2)],
          heading: (0, k.jsxs)(k.Fragment, {
            children: [
              (0, k.jsx)(D.Icon, {
                variant: "yandexPlus".concat(r2),
                className: ec()["logo_".concat(r2.toLocaleLowerCase())]
              }),
              (0, k.jsx)(B.q, {
                children: (0, k.jsx)(U.Heading, {
                  variant: "h2",
                  children: (0, k.jsx)(P.A, { id: "paywall.plus-part-title", values: { nbsp: " " } })
                })
              })
            ]
          }),
          content: (0, k.jsxs)(k.Fragment, {
            children: [
              (0, k.jsx)(K, {
                className: ec().card,
                text: (0, k.jsx)(P.A, { id: "paywall.plus-part-benefit-family", values: { br: "\n", nbsp: " " } }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/28052/img.66756428fda47e2147b8b478/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.66756449fda47e2147b8b47a/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_ADD_CLOSES)
              }),
              (0, k.jsx)(K, {
                className: ec().card,
                variant: "vertical",
                text: (0, k.jsx)(P.A, { id: "paywall.plus-part-benefit-devices", values: { br: "\n" } }),
                imageAlign: "right",
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/30221/img.66f29c21b8a7ae33ed006e72/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/29541/img.66f292cc89f5b04b855a8040/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_ADD_CLOSES)
              }),
              s2 === S.RU && (0, k.jsxs)(k.Fragment, {
                children: [
                  (0, k.jsx)(K, {
                    className: ec().card,
                    variant: "vertical",
                    text: (0, k.jsx)(P.A, {
                      id: "paywall.plus-part-spend-points",
                      values: { br: "\n", nbsp: " " }
                    }),
                    imageAlign: "right",
                    imageSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.68eebcc48f03fb5a1cf861dd/orig",
                    image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.68eebcd66fc33b70f1711a33/orig",
                    ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_SPEND_POINTS)
                  }),
                  (0, k.jsx)(K, {
                    className: ec().card,
                    text: (0, k.jsx)(P.A, {
                      id: "paywall.plus-part-benefit-options",
                      values: { br: "\n", nbsp: " " }
                    }),
                    imageSrc: "https://avatars.mds.yandex.net/get-music-misc/49997/img.68eebd405566813399938420/orig",
                    image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/69699/img.68eebd498f03fb5a1cf861df/orig",
                    ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_BENEFIT_OPTIONS)
                  })
                ]
              })
            ]
          }),
          ...(0, j.Am)(j.e8.paywall.PAYWALL_PLUS_SECTION)
        });
      };
      var ed = s(92803), eu = s(63664), ef = s(85360), e_ = s(77881), em = s(10628), ep = s.n(em);
      let eg = {
        exit: ep().stickyContainer_exit,
        exitActive: ep().stickyContainer_exit_active,
        enter: ep().stickyContainer_enter,
        enterActive: ep().stickyContainer_enter_active
      }, ev = "buy-subscription-block-button-container", eb = "buy-subscription-block-first-button", ek = "buy-subscription-block-second-button", ey = (0, E.PA)((e10) => {
        var t2;
        let { className: s2, shouldShowFixed: r2, place: a2 } = e10, n2 = (0, h.useRef)(null), i2 = (0, h.useRef)(null), l2 = (0, h.useRef)(null), { user: o2, experiments: c2 } = (0, R.Pjs)(), x2 = c2.checkExperiment(R.zal.WebNextPaywallSecondButton, "on"), d2 = (0, R.DpZ)({
          storeName: "music",
          place: a2 || R.RBW.BLOCK_1,
          offerElement: { element: i2.current, intersectionPropertyId: eb }
        }), u2 = (0, R.DpZ)({
          storeName: "music",
          place: R.RBW.BLOCK_2,
          offerElement: { element: l2.current, intersectionPropertyId: ek },
          isEnabled: x2
        }), f2 = (0, h.useRef)(null), [_2, m2] = (0, h.useState)(), [p2, g2] = (0, h.useState)(false), { isIntersecting: v2 } = null != (t2 = (0, ef.BL)([n2], { preflightCheck: false }, !r2)[ev]) ? t2 : {}, b2 = (0, h.useCallback)(() => {
          if (!o2.isAuthorized) return void d2.saveOfferAndAuthorize();
          d2.openPaymentWidgetModal();
        }, [o2.isAuthorized, d2]), E2 = (0, h.useCallback)(() => {
          if (!o2.isAuthorized) return void u2.saveOfferAndAuthorize();
          u2.openPaymentWidgetModal();
        }, [o2.isAuthorized, u2]);
        (0, h.useEffect)(() => {
          if (!v2) {
            var e11;
            m2(null == (e11 = n2.current) ? void 0 : e11.closest("[data-buy-subscription-block-portal]"));
          }
        }, [v2]), (0, h.useEffect)(() => {
          r2 && setTimeout(() => {
            g2(true);
          }, 300);
        }, [r2, g2]);
        let w2 = r2 && _2, O2 = !!(w2 && !v2 && p2);
        return (0, k.jsxs)("div", {
          className: (0, y.$)(ep().root, s2, { [ep().root_withSecondButton]: x2 }),
          children: [
            (0, k.jsxs)("div", {
              ref: n2,
              className: ep().buttonContainer,
              "data-intersection-property-id": ev,
              children: [
                (0, k.jsxs)(e_.$, {
                  isBlock: true,
                  radius: "xxxl",
                  size: "l",
                  color: "plus",
                  className: ep().button,
                  ref: i2,
                  onClick: b2,
                  "aria-label": d2.mainTextA11y,
                  "data-intersection-property-id": eb,
                  ...(0, j.Am)(j.e8.paywall.PAYWALL_OFFER_BUTTON),
                  children: [
                    (0, k.jsx)(U.Caption, {
                      className: ep().text_main,
                      variant: "div",
                      size: "l",
                      children: d2.mainText
                    }),
                    d2.additionText && (0, k.jsx)(U.Caption, {
                      className: ep().text_addition,
                      variant: "div",
                      size: "m",
                      children: d2.additionText
                    })
                  ]
                }),
                x2 && !u2.oneClickAvailable && (0, k.jsxs)(e_.$, {
                  isBlock: true,
                  radius: "xxxl",
                  size: "l",
                  color: "secondary",
                  className: ep().button,
                  ref: l2,
                  onClick: E2,
                  "aria-label": u2.mainTextA11y,
                  "data-intersection-property-id": ek,
                  ...(0, j.Am)(j.e8.paywall.PAYWALL_SECOND_OFFER_BUTTON),
                  children: [
                    (0, k.jsx)(U.Caption, {
                      className: ep().text_main,
                      variant: "div",
                      size: "l",
                      children: u2.mainText
                    }),
                    u2.additionText && (0, k.jsx)(U.Caption, {
                      className: ep().text_addition,
                      variant: "div",
                      size: "m",
                      children: u2.additionText
                    })
                  ]
                })
              ]
            }),
            d2.oneClickAvailable && (0, k.jsx)(U.Caption, {
              className: ep().text_secondary,
              variant: "div",
              size: "s",
              weight: "normal",
              "aria-label": d2.oneClickDisclaimerTextA11y,
              children: d2.oneClickDisclaimerText
            }),
            w2 && (0, ed.createPortal)(
              (0, k.jsx)(eu.A, {
                in: O2,
                nodeRef: f2,
                timeout: 300,
                classNames: eg,
                unmountOnExit: true,
                children: (0, k.jsx)("div", {
                  className: ep().stickyContainer,
                  "aria-hidden": true,
                  ref: f2,
                  children: (0, k.jsx)(ey, { place: R.RBW.BOTTOM_BUTTON })
                })
              }),
              _2
            )
          ]
        });
      });
      ey.displayName = "BuySubscriptionBlock";
      var eE = s(36729), eh = s.n(eE);
      let ej = (e10) => {
        let { className: t2 } = e10;
        return (0, k.jsx)("section", {
          className: (0, y.$)(eh().root, t2),
          children: (0, k.jsx)("div", {
            className: eh().wrapper,
            children: (0, k.jsxs)("div", {
              className: eh().content,
              children: [
                (0, k.jsx)(U.Heading, {
                  variant: "h1",
                  size: "xxl",
                  className: eh().title,
                  children: (0, k.jsx)(P.A, { id: "paywall.music-on-many-devices", values: { nbsp: " " } })
                }),
                (0, k.jsx)(U.Caption, {
                  variant: "div",
                  size: "l",
                  weight: "normal",
                  className: eh().label,
                  children: (0, k.jsx)(P.A, { id: "paywall.recommendations-on-devices", values: { nbsp: " " } })
                }),
                (0, k.jsx)(ey, { className: eh().buySubscriptionBlock, shouldShowFixed: true })
              ]
            })
          })
        });
      };
      var ew = s(45606), eO = s.n(ew);
      let eR = () => (0, k.jsxs)(k.Fragment, {
        children: [
          (0, k.jsx)(ej, { className: eO().topSection }),
          (0, k.jsx)(el, { className: N().section, variant: S.BY }),
          (0, k.jsx)($, { className: N().section, variant: S.BY }),
          (0, k.jsx)(ex, { className: N().section, variant: S.BY }),
          (0, k.jsx)(I, { className: N().section_faq }),
          (0, k.jsx)(M, {})
        ]
      });
      var eS = s(50286), eC = s.n(eS);
      let eA = (e10) => {
        let { className: t2, text: s2, imageSrc: r2, image2xSrc: a2 } = e10;
        return (0, k.jsxs)("div", {
          className: (0, y.$)(eC().root, t2),
          children: [
            (0, k.jsx)(W.Image, {
              className: eC().image,
              src: r2,
              srcSet: a2 ? "".concat(a2, " 2x") : void 0,
              fit: "cover",
              "aria-hidden": true
            }),
            (0, k.jsx)(U.Caption, { className: eC().text, variant: "span", size: "l", weight: "medium", children: s2 })
          ]
        });
      };
      var eN = s(21511), eL = s.n(eN);
      let eH = (e10) => {
        let { id: t2, className: s2, contentClassName: r2, heading: a2, content: n2 } = e10;
        return (0, k.jsxs)("section", {
          className: (0, y.$)(eL().root, s2),
          id: t2,
          children: [
            (0, k.jsx)("div", { className: eL().headingContainer, children: a2 }),
            (0, k.jsx)("div", { className: (0, y.$)(eL().contentContainer, r2), children: n2 })
          ]
        });
      };
      var eP = s(24603), eT = s.n(eP);
      let eI = {
        [S.RU]: "https://avatars.mds.yandex.net/get-music-misc/30221/img.66743f6a14d05542b9b51906/orig",
        [S.BY]: "https://avatars.mds.yandex.net/get-music-misc/28052/img.66b240550e8bdd7a18b0d48f/orig"
      }, eM = {
        [S.RU]: "https://avatars.mds.yandex.net/get-music-misc/70683/img.667440e414d05542b9b5192c/orig",
        [S.BY]: "https://avatars.mds.yandex.net/get-music-misc/28052/img.66b240560e8bdd7a18b0d490/orig"
      }, eD = {
        [S.RU]: "https://avatars.mds.yandex.net/get-music-misc/2419084/img.66744288699ba338f5126199/orig",
        [S.BY]: "https://avatars.mds.yandex.net/get-music-misc/69699/img.66b240db0e8bdd7a18b0d493/orig"
      }, eB = {
        [S.RU]: "https://avatars.mds.yandex.net/get-music-misc/2419084/img.667442a8699ba338f512619b/orig",
        [S.BY]: "https://avatars.mds.yandex.net/get-music-misc/70850/img.66b240da0e8bdd7a18b0d492/orig"
      }, eU = (e10) => {
        let { className: t2, variant: s2 = S.RU } = e10, r2 = (0, R.jjz)();
        return (0, k.jsx)("div", {
          ...(0, j.Am)(j.e8.paywall.MOBILE_PAYWALL_KINOPOISK_SECTION),
          children: (0, k.jsx)(eH, {
            className: t2,
            contentClassName: eT()["content_".concat(s2)],
            heading: (0, k.jsxs)(k.Fragment, {
              children: [
                (0, k.jsx)(D.Icon, {
                  variant: "kinopoisk".concat(r2),
                  className: eT()["logo_".concat(r2.toLocaleLowerCase())]
                }),
                (0, k.jsx)(B.q, {
                  children: (0, k.jsx)(U.Heading, {
                    variant: "h2",
                    children: (0, k.jsx)(P.A, { id: "paywall.kinopoisk-part-title" })
                  })
                })
              ]
            }),
            content: (0, k.jsxs)(k.Fragment, {
              children: [
                (0, k.jsx)(eA, {
                  className: eT().card1,
                  text: (0, k.jsx)(P.A, {
                    id: "paywall.kinopoisk-part-benefit-movies",
                    values: { br: "\n", nbsp: " " }
                  }),
                  imageSrc: eI[s2],
                  image2xSrc: eM[s2]
                }),
                (0, k.jsx)(eA, {
                  className: eT().card2,
                  text: (0, k.jsx)(P.A, {
                    id: "paywall.kinopoisk-part-benefit-exclusive",
                    values: { br: "\n", nbsp: " " }
                  }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.667441724ca5c169150d1473/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.667441934ca5c169150d1475/orig"
                }),
                s2 === S.RU && (0, k.jsx)(eA, {
                  className: eT().card3,
                  text: (0, k.jsx)(P.A, {
                    id: "paywall.kinopoisk-part-benefit-sport",
                    values: { br: "\n", nbsp: " " }
                  }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/2413828/img.667441e54ca5c169150d1477/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/40584/img.667441ff4ca5c169150d1479/orig"
                }),
                (0, k.jsx)(eA, {
                  className: (0, y.$)(eT().card4, eT()["card4_".concat(s2)]),
                  text: (0, k.jsx)(P.A, {
                    id: "paywall.kinopoisk-part-benefit-channels",
                    values: { br: "\n", nbsp: " " }
                  }),
                  imageSrc: eD[s2],
                  image2xSrc: eB[s2]
                })
              ]
            })
          })
        });
      };
      var eF = s(5751), eW = s.n(eF);
      let ez = (e10) => {
        let { className: t2, variant: s2 = S.RU } = e10, r2 = (0, R.jjz)(), a2 = (0, h.useMemo)(
          () => s2 === S.RU ? (0, k.jsx)(P.A, { id: "paywall.music-part-benefit-books", values: { br: "\n", nbsp: " " } }) : (0, k.jsx)(P.A, {
            id: "paywall.music-part-benefit-books-alternative",
            values: { br: "\n", nbsp: " " }
          }),
          [s2]
        );
        return (0, k.jsx)("div", {
          ...(0, j.Am)(j.e8.paywall.MOBILE_PAYWALL_MUSIC_SECTION),
          children: (0, k.jsx)(eH, {
            id: er,
            className: t2,
            contentClassName: eW().content,
            heading: (0, k.jsxs)(k.Fragment, {
              children: [
                (0, k.jsx)(D.Icon, {
                  variant: "musicLogoCenter".concat(r2),
                  className: eW()["logo_".concat(r2.toLocaleLowerCase())]
                }),
                (0, k.jsx)(B.q, {
                  children: (0, k.jsx)(U.Heading, {
                    variant: "h2",
                    children: (0, k.jsx)(P.A, { id: "paywall.music-part-title", values: { nbsp: " " } })
                  })
                })
              ]
            }),
            content: (0, k.jsxs)(k.Fragment, {
              children: [
                (0, k.jsx)(eA, {
                  className: eW().card,
                  text: (0, k.jsx)(P.A, {
                    id: "paywall.music-part-benefit-recommendations",
                    values: { br: "\n", nbsp: " " }
                  }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/40584/img.667415134ca5c169150d135d/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/70850/img.667415424ca5c169150d135f/orig"
                }),
                (0, k.jsx)(eA, {
                  className: eW().card,
                  text: (0, k.jsx)(P.A, {
                    id: "paywall.music-part-benefit-many-devices",
                    values: { br: "\n", nbsp: " " }
                  }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/70850/img.6674157e4ca5c169150d1361/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28052/img.667415a74ca5c169150d1364/orig"
                }),
                (0, k.jsx)(eA, {
                  className: eW().card,
                  text: (0, k.jsx)(P.A, {
                    id: "paywall.music-part-benefit-playlists",
                    values: { br: "\n", nbsp: " " }
                  }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/2406661/img.667415d64ca5c169150d1366/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28052/img.667415f44ca5c169150d1368/orig"
                }),
                (0, k.jsx)(eA, {
                  className: eW().card,
                  text: (0, k.jsx)(P.A, {
                    id: "paywall.music-part-benefit-without-internet-mobile",
                    values: { br: "\n", nbsp: " " }
                  }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/40584/img.667417c14ca5c169150d1382/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/40584/img.667417e14ca5c169150d1384/orig"
                }),
                (0, k.jsx)(eA, {
                  className: eW().card,
                  text: a2,
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/2406661/img.667418304ca5c169150d1386/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28052/img.6674184e4ca5c169150d1388/orig"
                })
              ]
            })
          })
        });
      };
      var eY = s(56206), eK = s.n(eY);
      let eV = (e10) => {
        let { className: t2, variant: s2 = S.RU } = e10, r2 = (0, R.jjz)();
        return (0, k.jsx)("div", {
          ...(0, j.Am)(j.e8.paywall.MOBILE_PAYWALL_PLUS_SECTION),
          children: (0, k.jsx)(eH, {
            className: t2,
            contentClassName: eK()["content_".concat(s2)],
            heading: (0, k.jsxs)(k.Fragment, {
              children: [
                (0, k.jsx)(D.Icon, {
                  variant: "yandexPlus".concat(r2),
                  className: eK()["logo_".concat(r2.toLocaleLowerCase())]
                }),
                (0, k.jsx)(B.q, {
                  children: (0, k.jsx)(U.Heading, {
                    variant: "h2",
                    children: (0, k.jsx)(P.A, { id: "paywall.plus-part-title", values: { nbsp: " " } })
                  })
                })
              ]
            }),
            content: (0, k.jsxs)(k.Fragment, {
              children: [
                (0, k.jsx)(eA, {
                  className: eK().card,
                  text: (0, k.jsx)(P.A, { id: "paywall.plus-part-benefit-family", values: { br: "\n", nbsp: " " } }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/29541/img.667566fbcc842022e134a7ac/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/40584/img.66756714cc842022e134a7ae/orig"
                }),
                (0, k.jsx)(eA, {
                  className: eK().card,
                  text: (0, k.jsx)(P.A, { id: "paywall.plus-part-benefit-devices", values: { br: "\n" } }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/34161/img.67cade4deeed590a0d455116/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28052/img.67cade4beeed590a0d455115/orig"
                })
              ]
            })
          })
        });
      };
      var eq = s(84535), eZ = s.n(eq);
      let eQ = (e10) => {
        let { className: t2, moreInfoLinkProps: s2 } = e10;
        return (0, k.jsxs)("section", {
          className: (0, y.$)(eZ().root, t2),
          children: [
            (0, k.jsx)("div", { className: eZ().image }),
            (0, k.jsxs)("div", {
              className: eZ().content,
              children: [
                (0, k.jsx)(U.Heading, {
                  className: eZ().title,
                  variant: "h1",
                  size: "xl",
                  weight: "bold",
                  children: (0, k.jsx)(P.A, { id: "paywall.music-on-many-devices", values: { nbsp: " " } })
                }),
                (0, k.jsx)(U.Caption, {
                  variant: "div",
                  size: "l",
                  children: (0, k.jsx)(P.A, { id: "paywall.recommendations-on-devices", values: { nbsp: " " } })
                }),
                (0, k.jsx)(ey, { className: eZ().buySubscriptionBlock, shouldShowFixed: true }),
                (0, k.jsx)(ea, { ...s2, className: (0, y.$)(eZ().moreInfoLink, null == s2 ? void 0 : s2.className) })
              ]
            })
          ]
        });
      };
      var eG = s(17950), eX = s.n(eG);
      let eJ = () => (0, k.jsxs)(k.Fragment, {
        children: [
          (0, k.jsx)(eQ, { className: eX().topSection }),
          (0, k.jsx)(ez, { className: N().section, variant: S.BY }),
          (0, k.jsx)(eU, { className: N().section, variant: S.BY }),
          (0, k.jsx)(eV, { className: N().section, variant: S.BY }),
          (0, k.jsx)(I, { className: N().section_faq }),
          (0, k.jsx)(M, {})
        ]
      }), e$ = (0, E.PA)(() => {
        let {
          settings: { isMobile: e10 }
        } = (0, R.Pjs)();
        return (0, k.jsx)("div", { className: H().root, children: e10 ? (0, k.jsx)(eJ, {}) : (0, k.jsx)(eR, {}) });
      });
      var e0 = s(16503), e1 = s.n(e0);
      let e8 = () => (0, k.jsxs)("div", {
        className: e1().root,
        children: [
          (0, k.jsx)(ej, { className: e1().topSection }),
          (0, k.jsx)(I, { className: N().section_faq }),
          (0, k.jsx)(M, {})
        ]
      });
      var e6 = s(55330), e4 = s.n(e6);
      let e3 = () => (0, k.jsxs)(k.Fragment, {
        children: [
          (0, k.jsx)(eQ, { className: e4().topSection, moreInfoLinkProps: { shouldShowLabel: false } }),
          (0, k.jsx)(I, { faqProps: { id: er } }),
          (0, k.jsx)(M, {})
        ]
      }), e2 = (0, E.PA)(() => {
        let {
          settings: { isMobile: e10 }
        } = (0, R.Pjs)();
        return e10 ? (0, k.jsx)(e3, {}) : (0, k.jsx)(e8, {});
      });
      var e5 = s(26018), e9 = s.n(e5), e7 = s(97396);
      let te = () => {
        let { experiments: e10 } = (0, R.Pjs)(), t2 = (0, e7.useSearchParams)().get(R.K3F.UTM_MEDIUM), s2 = e10.checkExperiment(R.zal.WebNextPaidPerformancePaywallTopSection, "music_benefits") && "paid_performance" === t2;
        return e10.checkExperiment(R.zal.WebNextPaywallTopSection, "music_benefits") || s2;
      };
      var tt = s(72100), ts = s.n(tt);
      let tr = (e10) => {
        let { className: t2, variant: s2 = S.RU } = e10, r2 = (0, R.jjz)();
        return (0, k.jsx)(Z, {
          className: t2,
          contentClassName: ts()["content_".concat(s2)],
          heading: (0, k.jsxs)(k.Fragment, {
            children: [
              (0, k.jsx)(D.Icon, {
                variant: "yandexBooks".concat(r2),
                className: ts()["logo_".concat(r2.toLocaleLowerCase())]
              }),
              (0, k.jsx)(B.q, {
                children: (0, k.jsx)(U.Heading, {
                  variant: "h2",
                  children: (0, k.jsx)(P.A, { id: "paywall.books-part-title", values: { nbsp: " " } })
                })
              })
            ]
          }),
          content: (0, k.jsxs)(k.Fragment, {
            children: [
              (0, k.jsx)(K, {
                className: ts().card,
                text: (0, k.jsx)(P.A, { id: "paywall.books-part-benefit-app-desktop", values: { nbsp: " " } }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.68c02cb364560d354cb53936/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28052/img.68c02ce6cccb5e758b864480/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_READ_IN_APP)
              }),
              (0, k.jsx)(K, {
                className: ts().card,
                variant: "vertical",
                text: (0, k.jsx)(P.A, { id: "paywall.books-part-benefit-follow-desktop", values: { nbsp: " " } }),
                imageAlign: "right",
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/40584/img.66f6a89798264a4b59f3a749/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/30221/img.66f6a890ed792c3f4a135a74/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_FIND_NEWS)
              }),
              (0, k.jsx)(K, {
                className: ts().card,
                variant: "vertical",
                text: (0, k.jsx)(P.A, { id: "paywall.books-part-benefit-download-desktop", values: { nbsp: " " } }),
                imageAlign: "right",
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/30221/img.66f6a8c8caf72c4bc9eaea8c/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/2406661/img.66f6a8bf4e6e980968aa844d/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_DOWNLOAD_BOOKS)
              }),
              (0, k.jsx)(K, {
                className: ts().card,
                text: (0, k.jsx)(P.A, { id: "paywall.books-part-benefit-speed-desktop", values: { br: "\n" } }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/70850/img.68c02cbc9daf1b03347faca5/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.68c02cdccccb5e758b86447e/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_CHOOSE_PASE)
              })
            ]
          }),
          ...(0, j.Am)(j.e8.paywall.PAYWALL_BOOKS_SECTION)
        });
      };
      var ta = s(41752), tn = s.n(ta);
      let ti = (e10) => {
        let { className: t2, variant: s2 = S.RU } = e10;
        return (0, k.jsx)(Z, {
          className: t2,
          contentClassName: tn()["content_".concat(s2)],
          heading: (0, k.jsx)(U.Heading, {
            variant: "h2",
            className: tn().title,
            children: (0, k.jsx)(P.A, { id: "paywall.other-services-part-title", values: { nbsp: " " } })
          }),
          content: (0, k.jsxs)(k.Fragment, {
            children: [
              (0, k.jsx)(K, {
                className: tn().card,
                variant: "vertical",
                imageAlign: "right",
                text: (0, k.jsx)(P.A, { id: "paywall.other-services-part-benefit-maps", values: { nbsp: " " } }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/70850/img.68eec5170c5fe5082085b079/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.68eec52e94053d016bcd7bf3/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_MAPS)
              }),
              (0, k.jsx)(K, {
                className: tn().card,
                text: (0, k.jsx)(P.A, {
                  id: "paywall.other-services-part-benefit-your-plus",
                  values: { nbsp: " " }
                }),
                imageAlign: "right",
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.68eec5408fcfeb05fbb439ec/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.68eec547b510f9053778b2d0/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_YOUR_PLUS)
              }),
              (0, k.jsx)(K, {
                className: tn().card,
                text: (0, k.jsx)(P.A, { id: "paywall.pay-part-benefit-split-desktop", values: { nbsp: " " } }),
                imageAlign: "right",
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.68eec5516fc33b70f1711a3a/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/70850/img.68eec558b510f9053778b2d2/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_DIVIDE_PAYMENT)
              }),
              (0, k.jsx)(K, {
                className: tn().card,
                variant: "vertical",
                imageAlign: "right",
                text: (0, k.jsx)(P.A, { id: "paywall.other-services-part-save", values: { nbsp: " " } }),
                imageSrc: "https://avatars.mds.yandex.net/get-music-misc/70683/img.68eec565d57d6359e4120722/orig",
                image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/70683/img.68eec56e6fc33b70f1711a3c/orig",
                ...(0, j.Am)(j.e8.paywall.PAYWALL_SECTION_CARD_TAKE_SAVES)
              })
            ]
          }),
          ...(0, j.Am)(j.e8.paywall.PAYWALL_OTHER_SERVICES_SECTION)
        });
      };
      function tl() {
        return (tl = Object.assign ? Object.assign.bind() : function(e10) {
          for (var t2 = 1; t2 < arguments.length; t2++) {
            var s2 = arguments[t2];
            for (var r2 in s2) ({}).hasOwnProperty.call(s2, r2) && (e10[r2] = s2[r2]);
          }
          return e10;
        }).apply(null, arguments);
      }
      let to = function(e10) {
        return h.createElement(
          "svg",
          tl({ width: 64, height: 64, viewBox: "0 0 64 64", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, e10),
          h.createElement(
            "mask",
            {
              id: "mask0_1016_316950",
              style: { maskType: "alpha" },
              maskUnits: "userSpaceOnUse",
              x: -1,
              y: 0,
              width: 65,
              height: 64
            },
            r || (r = h.createElement("circle", { cx: 31.6934, cy: 32, r: 32, fill: "#D9D9D9" }))
          ),
          a || (a = h.createElement(
            "g",
            { mask: "url(#mask0_1016_316950)" },
            h.createElement("path", {
              d: "M17.9864 0V29.0933L0 16V0H17.9864Z",
              fill: "url(#paint0_linear_1016_316950)"
            }),
            h.createElement("path", {
              d: "M58.2771 0L36.0641 16.04L17.9844 29.0933V0H58.2771Z",
              fill: "url(#paint1_linear_1016_316950)"
            }),
            h.createElement("path", {
              d: "M63.9993 0V31.88L36.0664 39.36V16.04L58.2794 0H63.9993Z",
              fill: "url(#paint2_linear_1016_316950)"
            }),
            h.createElement("path", {
              d: "M63.9993 31.8789V60.5189L36.0664 53.0389V39.3589L63.9993 31.8789Z",
              fill: "url(#paint3_linear_1016_316950)"
            }),
            h.createElement("path", {
              d: "M63.9993 60.5191V63.9991H36.0664V53.0391L63.9993 60.5191Z",
              fill: "url(#paint4_linear_1016_316950)"
            }),
            h.createElement("path", { d: "M36.0661 16.04V64H0V16L17.9864 29.0933L36.0661 16.04Z", fill: "#FFDAEA" }),
            h.createElement("path", {
              d: "M27.0129 47.8395C24.8663 51.4394 21.5197 53.0261 18.013 53.0261C10.9998 53.0261 5.75991 48.0928 5.75991 40.6796C5.75991 40.6796 5.77324 39.6396 5.79991 39.3063L36.0661 39.3463V16.04L17.9864 29.0931L0 16V63.9992H36.0661V53.0394C32.5728 53.0261 29.3995 51.4394 27.0129 47.8528V47.8395ZM18.013 49.0128C21.5463 49.0128 23.7063 47.1862 23.9996 43.0662H11.1598C11.7198 46.7728 14.5864 49.0128 18.0264 49.0128H18.013ZM30.0262 43.0662H43.026C42.466 46.7728 39.4394 49.0128 35.9994 49.0128C32.5595 49.0128 30.3062 47.1862 30.0128 43.0662H30.0262Z",
              fill: "#4D0000"
            })
          )),
          n || (n = h.createElement(
            "defs",
            null,
            h.createElement(
              "linearGradient",
              {
                id: "paint0_linear_1016_316950",
                x1: 8.99319,
                y1: 29.0933,
                x2: 8.99319,
                y2: -2.64766,
                gradientUnits: "userSpaceOnUse"
              },
              h.createElement("stop", { stopColor: "#FFDAEA" }),
              h.createElement("stop", { offset: 0.6, stopColor: "#FFB56F" }),
              h.createElement("stop", { offset: 0.9, stopColor: "#FF5D5D" })
            ),
            h.createElement(
              "linearGradient",
              {
                id: "paint1_linear_1016_316950",
                x1: 38.1307,
                y1: 29.0933,
                x2: 38.1307,
                y2: 0,
                gradientUnits: "userSpaceOnUse"
              },
              h.createElement("stop", { stopColor: "#FFDAEA" }),
              h.createElement("stop", { offset: 0.4, stopColor: "#FFB56F" }),
              h.createElement("stop", { offset: 0.9, stopColor: "#FF5D5D" })
            ),
            h.createElement(
              "linearGradient",
              {
                id: "paint2_linear_1016_316950",
                x1: 36.0664,
                y1: 19.68,
                x2: 63.9993,
                y2: 19.68,
                gradientUnits: "userSpaceOnUse"
              },
              h.createElement("stop", { stopColor: "#FFDAEA" }),
              h.createElement("stop", { offset: 0.4, stopColor: "#FFB56F" }),
              h.createElement("stop", { offset: 0.9, stopColor: "#FF5D5D" })
            ),
            h.createElement(
              "linearGradient",
              {
                id: "paint3_linear_1016_316950",
                x1: 36.0664,
                y1: 46.1989,
                x2: 67.0254,
                y2: 46.1989,
                gradientUnits: "userSpaceOnUse"
              },
              h.createElement("stop", { stopColor: "#FFDAEA" }),
              h.createElement("stop", { offset: 0.6, stopColor: "#FFB56F" }),
              h.createElement("stop", { offset: 0.9, stopColor: "#FF5D5D" })
            ),
            h.createElement(
              "linearGradient",
              {
                id: "paint4_linear_1016_316950",
                x1: 36.0664,
                y1: 58.5191,
                x2: 63.9993,
                y2: 58.5191,
                gradientUnits: "userSpaceOnUse"
              },
              h.createElement("stop", { stopColor: "#FFDAEA" }),
              h.createElement("stop", { offset: 0.4, stopColor: "#FFB56F" }),
              h.createElement("stop", { offset: 0.9, stopColor: "#FF5D5D" })
            )
          ))
        );
      };
      function tc() {
        return (tc = Object.assign ? Object.assign.bind() : function(e10) {
          for (var t2 = 1; t2 < arguments.length; t2++) {
            var s2 = arguments[t2];
            for (var r2 in s2) ({}).hasOwnProperty.call(s2, r2) && (e10[r2] = s2[r2]);
          }
          return e10;
        }).apply(null, arguments);
      }
      let tx = function(e10) {
        return h.createElement(
          "svg",
          tc({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 64 65", fill: "none" }, e10),
          h.createElement(
            "g",
            { clipPath: "url(#clip0_4165_10094)" },
            i || (i = h.createElement("rect", { y: 0.5, width: 64, height: 64, rx: 32, fill: "white" })),
            l || (l = h.createElement("path", {
              d: "M18.4483 14.2142C21.818 11.7173 25.8007 10.2079 29.9516 9.83281V16.7015C27.2684 17.0494 24.7059 18.0767 22.5139 19.7009C19.7692 21.7347 17.7508 24.5968 16.7563 27.8649C15.7619 31.133 15.8441 34.6342 16.9909 37.8521C18.1376 41.0699 20.2881 43.8341 23.1252 45.7368C25.9624 47.6395 29.3359 48.58 32.7482 48.4197C36.1605 48.2594 39.4309 47.0066 42.0771 44.8462C44.7233 42.6859 46.6052 39.7322 47.4451 36.421C48.031 34.1114 48.0883 31.7131 47.6293 29.4009L53.3973 24.7639L53.3935 24.7265C54.9505 29.0095 55.1883 33.669 54.0643 38.1001C52.8644 42.8304 50.1761 47.0498 46.3958 50.1361C42.6155 53.2223 37.9434 55.012 33.0687 55.241C28.194 55.4701 23.3747 54.1264 19.3216 51.4083C15.2686 48.6901 12.1964 44.7414 10.5583 40.1444C8.92008 35.5475 8.80263 30.5458 10.2232 25.877C11.6438 21.2082 14.5273 17.1196 18.4483 14.2142Z",
              fill: "#FCCA00"
            })),
            o || (o = h.createElement("path", {
              d: "M49.048 17.4203L49.0722 17.4808L45.2177 23.6027C43.8161 21.5255 41.9377 19.7966 39.7395 18.5728V32.5043C39.7395 36.7786 36.2744 40.2436 32.0001 40.2436C27.7258 40.2436 24.2607 36.7786 24.2607 32.5043C24.2607 28.2299 27.7258 24.7649 32.0001 24.7649C33.602 24.7649 35.0903 25.2516 36.325 26.0852V10.1518C41.3497 11.1183 45.7865 13.7369 49.048 17.4203Z",
              fill: "#FC3F1D"
            })),
            h.createElement(
              "mask",
              {
                id: "mask0_4165_10094",
                style: { maskType: "alpha" },
                maskUnits: "userSpaceOnUse",
                x: 0,
                y: 0,
                width: 64,
                height: 65
              },
              c || (c = h.createElement("ellipse", { cx: 32, cy: 32.5, rx: 32, ry: 32, fill: "white" }))
            ),
            x || (x = h.createElement("g", { mask: "url(#mask0_4165_10094)" })),
            d || (d = h.createElement(
              "g",
              { clipPath: "url(#clip1_4165_10094)" },
              h.createElement("rect", {
                width: 63.9999,
                height: 63.9999,
                transform: "translate(0 0.5)",
                fill: "black"
              }),
              h.createElement("path", {
                d: "M63.9999 10.0984L30.9887 27.7682L48.1919 10.0984L38.6559 10.0984L26.9439 26.3551V10.0984H19.2L19.2 54.8984H26.9439L26.9439 38.668L38.6559 54.8984H48.1919L31.4355 37.7842L63.9999 54.8984V46.5784L34.2988 34.6629L63.9999 36.6584V28.3384L34.487 30.2571L63.9999 18.4184V10.0984Z",
                fill: "url(#paint0_radial_4165_10094)"
              })
            ))
          ),
          u || (u = h.createElement(
            "defs",
            null,
            h.createElement(
              "radialGradient",
              {
                id: "paint0_radial_4165_10094",
                cx: 0,
                cy: 0,
                r: 1,
                gradientUnits: "userSpaceOnUse",
                gradientTransform: "translate(19.2 10.0984) rotate(45) scale(63.3567 63.3567)"
              },
              h.createElement("stop", { offset: 0.5, stopColor: "#FF5500" }),
              h.createElement("stop", { offset: 1, stopColor: "#BBFF00" })
            ),
            h.createElement(
              "clipPath",
              { id: "clip0_4165_10094" },
              h.createElement("rect", { y: 0.5, width: 64, height: 64, rx: 32, fill: "white" })
            ),
            h.createElement(
              "clipPath",
              { id: "clip1_4165_10094" },
              h.createElement("rect", {
                width: 63.9999,
                height: 63.9999,
                fill: "white",
                transform: "translate(0 0.5)"
              })
            )
          ))
        );
      };
      function td() {
        return (td = Object.assign ? Object.assign.bind() : function(e10) {
          for (var t2 = 1; t2 < arguments.length; t2++) {
            var s2 = arguments[t2];
            for (var r2 in s2) ({}).hasOwnProperty.call(s2, r2) && (e10[r2] = s2[r2]);
          }
          return e10;
        }).apply(null, arguments);
      }
      let tu = function(e10) {
        return h.createElement(
          "svg",
          td({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 64 65", fill: "none" }, e10),
          f || (f = h.createElement("path", {
            d: "M32 64.5C49.6731 64.5 64 50.1731 64 32.5C64 14.8269 49.6731 0.5 32 0.5C14.3269 0.5 0 14.8269 0 32.5C0 50.1731 14.3269 64.5 32 64.5Z",
            fill: "black"
          })),
          _ || (_ = h.createElement("path", {
            d: "M47.4516 28.882C47.4516 28.882 55.4213 40.0392 55.3875 40.1373C55.238 40.5644 55.0773 40.9858 54.9052 41.4016C54.8659 41.4963 44.9333 32.923 44.9333 32.923C44.9333 32.923 47.6607 51.2055 47.6067 51.2506C47.211 51.5751 46.8074 51.8884 46.3925 52.1882C46.3352 52.2298 40.4251 34.2786 40.4251 34.2786C40.4251 34.2786 32.1609 56.938 32.0912 56.9391C31.963 56.9413 31.8337 56.9425 31.7055 56.9425C31.2738 56.9425 30.8455 56.9312 30.4183 56.9098C30.3542 56.9064 35.3548 32.7697 35.3548 32.7697C35.3548 32.7697 11.8448 47.1679 11.8111 47.1239C11.4738 46.6867 11.1512 46.2382 10.8431 45.7773C10.8105 45.7289 31.3829 28.4233 31.3829 28.4233C31.384 28.4245 7.07582 26.9178 7.08594 26.8671C7.18937 26.3465 7.30854 25.8304 7.44345 25.3221C7.45581 25.2737 30.8084 23.4346 30.8084 23.4346C30.8084 23.4346 13.7594 14.1976 13.7999 14.1559C14.1495 13.7986 14.5104 13.4516 14.8814 13.1146C14.9264 13.0741 33.7022 19.3463 33.7022 19.3463C33.7022 19.3463 27.9247 6.91001 28.0293 6.89423C28.4509 6.83225 28.8747 6.78042 29.3031 6.73985C29.393 6.73196 39.121 18.1969 39.121 18.1969C39.121 18.1969 42.2306 8.93727 42.3228 8.98122C42.7635 9.18857 43.1975 9.40718 43.6236 9.63819C43.7034 9.68101 43.9709 19.7136 43.9709 19.7136C43.9709 19.7136 51.4842 16.2958 51.5022 16.3184C51.7641 16.6553 52.0182 16.999 52.2633 17.3506C52.279 17.3731 46.7737 23.829 46.7737 23.829C46.7737 23.829 56.4016 27.2728 56.4173 27.3629C56.4893 27.7697 56.5523 28.1788 56.604 28.5912C56.6141 28.6757 47.4516 28.882 47.4516 28.882Z",
            fill: "#FED42B"
          }))
        );
      };
      function tf() {
        return (tf = Object.assign ? Object.assign.bind() : function(e10) {
          for (var t2 = 1; t2 < arguments.length; t2++) {
            var s2 = arguments[t2];
            for (var r2 in s2) ({}).hasOwnProperty.call(s2, r2) && (e10[r2] = s2[r2]);
          }
          return e10;
        }).apply(null, arguments);
      }
      let t_ = function(e10) {
        return h.createElement(
          "svg",
          tf({ xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 64 65", fill: "none" }, e10),
          m || (m = h.createElement(
            "g",
            { clipPath: "url(#clip0_4032_54517)" },
            h.createElement("rect", { y: 0.5, width: 64, height: 64, rx: 32, fill: "white" }),
            h.createElement("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M64 32.5C64 50.1731 49.6731 64.5 32 64.5C14.3269 64.5 0 50.1731 0 32.5C0 14.8269 14.3269 0.5 32 0.5C35.4533 0.5 38.7788 1.04699 41.8946 2.05907L34.6013 24.5H13.303L10.7003 32.5H32.0013L25.7613 51.7H34.5613L40.8013 32.5H64ZM62.9919 24.5H43.4013L49.508 5.71001C56.0847 10.0168 60.9791 16.68 62.9919 24.5Z",
              fill: "url(#paint0_linear_4032_54517)"
            })
          )),
          p || (p = h.createElement(
            "defs",
            null,
            h.createElement(
              "linearGradient",
              {
                id: "paint0_linear_4032_54517",
                x1: -253254e-12,
                y1: 28.2333,
                x2: 64,
                y2: 28.2333,
                gradientUnits: "userSpaceOnUse"
              },
              h.createElement("stop", { stopColor: "#FF5C4D" }),
              h.createElement("stop", { offset: 0.4, stopColor: "#EB469F" }),
              h.createElement("stop", { offset: 1, stopColor: "#8341EF" })
            ),
            h.createElement(
              "clipPath",
              { id: "clip0_4032_54517" },
              h.createElement("rect", { y: 0.5, width: 64, height: 64, rx: 32, fill: "white" })
            )
          ))
        );
      };
      var tm = s(23698), tp = s.n(tm);
      let tg = () => (0, k.jsxs)("ul", {
        className: tp().services,
        children: [
          (0, k.jsxs)("li", {
            className: tp().service,
            children: [
              (0, k.jsx)(tu, { className: tp().serviceLogo, "aria-hidden": true }),
              (0, k.jsx)(U.Heading, {
                variant: "h2",
                size: "m",
                className: tp().serviceLabel,
                children: (0, k.jsx)(P.A, { id: "paywall.plus-benefit-music", values: { br: "\n", nbsp: " " } })
              })
            ]
          }),
          (0, k.jsxs)("li", {
            className: tp().service,
            children: [
              (0, k.jsx)(tx, { className: tp().serviceLogo, "aria-hidden": true }),
              (0, k.jsx)(U.Heading, {
                variant: "h2",
                size: "m",
                className: tp().serviceLabel,
                children: (0, k.jsx)(P.A, {
                  id: "paywall.plus-benefit-kinopoisk",
                  values: { br: "\n", nbsp: " " }
                })
              })
            ]
          }),
          (0, k.jsxs)("li", {
            className: tp().service,
            children: [
              (0, k.jsx)(to, { className: tp().serviceLogo, "aria-hidden": true }),
              (0, k.jsx)(U.Heading, {
                variant: "h2",
                size: "m",
                className: tp().serviceLabel,
                children: (0, k.jsx)(P.A, { id: "paywall.plus-benefit-books", values: { br: "\n" } })
              })
            ]
          }),
          (0, k.jsxs)("li", {
            className: tp().service,
            children: [
              (0, k.jsx)(t_, { className: tp().serviceLogo, "aria-hidden": true }),
              (0, k.jsx)(U.Heading, {
                variant: "h2",
                size: "m",
                className: tp().serviceLabel,
                children: (0, k.jsx)(P.A, {
                  id: "paywall.plus-benefit-cashback",
                  values: { br: "\n", nbsp: " " }
                })
              })
            ]
          })
        ]
      }), tv = (e10) => {
        let { className: t2 } = e10, {
          settings: { browserInfo: s2 }
        } = (0, R.Pjs)(), r2 = (0, R.jjz)(), a2 = (0, e7.usePathname)() === R.Zyd.pay.href && !s2.isTouch;
        return (0, k.jsxs)("section", {
          className: (0, y.$)(tp().root, t2),
          ...(0, j.Am)(j.e8.paywall.PAYWALL_TOP_SECTION),
          children: [
            (0, k.jsxs)("div", {
              className: tp().main,
              children: [
                (0, k.jsx)(D.Icon, {
                  variant: "yandexPlus".concat(r2),
                  className: (0, y.$)(tp().logo, tp()["logo_".concat(r2.toLowerCase())])
                }),
                (0, k.jsx)(U.Heading, {
                  variant: "h1",
                  size: "xxxl",
                  weight: "bold",
                  className: tp().title,
                  children: (0, k.jsx)(P.A, { id: "paywall.open-plus-benefits", values: { br: "\n", nbsp: " " } })
                }),
                (0, k.jsx)(tg, {}),
                (0, k.jsx)(ey, { className: tp().buySubscriptionBlock, shouldShowFixed: true }),
                a2 && (0, k.jsx)(ee.N, {
                  className: tp().goHomeLink,
                  href: "/",
                  children: (0, k.jsx)(U.Caption, {
                    variant: "span",
                    size: "m",
                    weight: "medium",
                    children: (0, k.jsx)(P.A, { id: "navigation.go-home" })
                  })
                })
              ]
            }),
            (0, k.jsx)(ea, {
              ...(0, j.Am)(j.e8.paywall.PAYWALL_MORE_INFO_LINK),
              children: (0, k.jsx)(W.Image, {
                src: "https://avatars.mds.yandex.net/get-music-misc/49997/img.68eeb31b8fcfeb05fbb439da/orig",
                srcSet: "https://avatars.mds.yandex.net/get-music-misc/49997/img.68eeb33c5566813399938412/orig",
                fit: "contain",
                className: tp().moreInfoChildren,
                "aria-hidden": true,
                ...(0, j.Am)(j.e8.paywall.PAYWALL_MORE_INFO_LINK)
              })
            })
          ]
        });
      };
      var tb = s(43426), tk = s(30718), ty = s.n(tk);
      let tE = (e10) => {
        let { children: t2 } = e10, {
          settings: { isMobile: s2, browserInfo: r2 }
        } = (0, R.Pjs)();
        return s2 || r2.isTablet ? (0, k.jsx)(U.Caption, { variant: "span", size: "m", className: ty().benefitLabelMobile, children: t2 }) : (0, k.jsx)(U.Heading, { variant: "h2", size: "m", className: ty().benefitLabelDesktop, children: t2 });
      }, th = () => {
        let {
          settings: { isMobile: e10, browserInfo: t2 }
        } = (0, R.Pjs)(), { formatMessage: s2 } = (0, tb.A)(), r2 = s2(
          e10 || t2.isTablet ? { id: "paywall.music-benefit-all-in-one-mobile" } : { id: "paywall.music-benefit-all-in-one-desktop" },
          { br: "\n", nbsp: " " }
        );
        return (0, k.jsxs)("ul", {
          className: ty().benefits,
          children: [
            (0, k.jsxs)("li", {
              className: ty().benefit,
              children: [
                (0, k.jsx)(W.Image, {
                  className: ty().benefitLogo,
                  src: "https://avatars.mds.yandex.net/get-music-misc/2413828/img.693ad41840fb42546cc35e13/orig",
                  srcSet: "https://avatars.mds.yandex.net/get-music-misc/28592/img.693ad43c40fb42546cc35e15/orig"
                }),
                (0, k.jsx)(tE, {
                  children: (0, k.jsx)(P.A, { id: "paywall.music-benefit-audio", values: { nbsp: " " } })
                })
              ]
            }),
            (0, k.jsxs)("li", {
              className: (0, y.$)(ty().benefit, ty().benefit_recommendation),
              children: [
                (0, k.jsx)(W.Image, {
                  className: ty().benefitLogo,
                  src: "https://avatars.mds.yandex.net/get-music-misc/40584/img.693ad52e40fb42546cc35e1a/orig",
                  srcSet: "https://avatars.mds.yandex.net/get-music-misc/40584/img.693ad53793461475f95b4f50/orig"
                }),
                (0, k.jsx)(tE, {
                  children: (0, k.jsx)(P.A, { id: "paywall.music-benefit-recommendation", values: { nbsp: " " } })
                })
              ]
            }),
            (0, k.jsxs)("li", {
              className: ty().benefit,
              children: [
                (0, k.jsx)(W.Image, {
                  className: ty().benefitLogo,
                  src: "https://avatars.mds.yandex.net/get-music-misc/2413828/img.693ad56040fb42546cc35e1c/orig",
                  srcSet: "https://avatars.mds.yandex.net/get-music-misc/2413828/img.693ad56640fb42546cc35e1e/orig"
                }),
                (0, k.jsx)(tE, {
                  children: (0, k.jsx)(P.A, {
                    id: "paywall.music-benefit-without-network",
                    values: { nbsp: " " }
                  })
                })
              ]
            }),
            (0, k.jsxs)("li", {
              className: ty().benefit,
              children: [
                (0, k.jsx)(W.Image, {
                  className: ty().benefitLogo,
                  src: "https://avatars.mds.yandex.net/get-music-misc/28592/img.693ad56e621a600def9091d8/orig",
                  srcSet: "https://avatars.mds.yandex.net/get-music-misc/28592/img.693ad57632413276cc433bf8/orig"
                }),
                (0, k.jsx)(tE, { children: r2 })
              ]
            })
          ]
        });
      }, tj = (e10) => {
        let { className: t2 } = e10, {
          settings: { browserInfo: s2 }
        } = (0, R.Pjs)(), r2 = (0, R.jjz)(), a2 = (0, e7.usePathname)() === R.Zyd.pay.href && !s2.isTouch;
        return (0, k.jsxs)("section", {
          className: (0, y.$)(ty().root, t2),
          ...(0, j.Am)(j.e8.paywall.PAYWALL_TOP_SECTION),
          children: [
            (0, k.jsxs)("div", {
              className: ty().main,
              children: [
                (0, k.jsx)(D.Icon, {
                  variant: "musicLogoCenter".concat(r2),
                  className: (0, y.$)(ty().logo, ty()["logo_".concat(r2.toLowerCase())])
                }),
                (0, k.jsx)(U.Heading, {
                  variant: "h1",
                  size: "xxxl",
                  weight: "bold",
                  className: ty().title,
                  children: (0, k.jsx)(P.A, {
                    id: "paywall.music-benefits-title",
                    values: { br: "\n", nbsp: " " }
                  })
                }),
                (0, k.jsx)(th, {}),
                (0, k.jsx)(ey, { className: ty().buySubscriptionBlock, shouldShowFixed: true }),
                a2 && (0, k.jsx)(ee.N, {
                  className: ty().goHomeLink,
                  href: "/",
                  children: (0, k.jsx)(U.Caption, {
                    variant: "span",
                    size: "m",
                    weight: "medium",
                    children: (0, k.jsx)(P.A, { id: "navigation.go-home" })
                  })
                })
              ]
            }),
            (0, k.jsx)(ea, {
              ...(0, j.Am)(j.e8.paywall.PAYWALL_MORE_INFO_LINK),
              children: (0, k.jsx)(W.Image, {
                src: "https://avatars.mds.yandex.net/get-music-misc/49997/img.68eeb31b8fcfeb05fbb439da/orig",
                srcSet: "https://avatars.mds.yandex.net/get-music-misc/49997/img.68eeb33c5566813399938412/orig",
                fit: "contain",
                className: ty().moreInfoChildren,
                "aria-hidden": true,
                ...(0, j.Am)(j.e8.paywall.PAYWALL_MORE_INFO_LINK)
              })
            })
          ]
        });
      }, tw = () => {
        let e10 = te();
        return (0, k.jsxs)(k.Fragment, {
          children: [
            e10 ? (0, k.jsx)(tj, {}) : (0, k.jsx)(tv, {}),
            (0, k.jsx)(el, { className: N().section }),
            (0, k.jsx)($, { className: N().section }),
            (0, k.jsx)(tr, { className: N().section }),
            (0, k.jsx)(ex, { className: N().section }),
            (0, k.jsx)(ti, { className: N().section }),
            (0, k.jsx)(I, { className: N().section_faq, variant: S.RU }),
            (0, k.jsx)(M, { variant: S.RU })
          ]
        });
      };
      var tO = s(66183), tR = s.n(tO);
      let tS = (e10) => {
        let { className: t2, variant: s2 = S.RU } = e10, r2 = (0, R.jjz)();
        return (0, k.jsx)("div", {
          ...(0, j.Am)(j.e8.paywall.MOBILE_PAYWALL_BOOKS_SECTION),
          children: (0, k.jsx)(eH, {
            className: t2,
            contentClassName: tR()["content_".concat(s2)],
            heading: (0, k.jsxs)(k.Fragment, {
              children: [
                (0, k.jsx)(D.Icon, {
                  variant: "yandexBooks".concat(r2),
                  className: tR()["logo_".concat(r2.toLocaleLowerCase())]
                }),
                (0, k.jsx)(B.q, {
                  children: (0, k.jsx)(U.Heading, {
                    variant: "h2",
                    children: (0, k.jsx)(P.A, { id: "paywall.books-part-title", values: { nbsp: " " } })
                  })
                })
              ]
            }),
            content: (0, k.jsxs)(k.Fragment, {
              children: [
                (0, k.jsx)(eA, {
                  className: tR().card,
                  text: (0, k.jsx)(P.A, { id: "paywall.books-part-benefit-switch-mobile", values: { nbsp: " " } }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/69699/img.68c0128ad8f3372f64a885b4/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28052/img.68c012b2fbed8f7a98fb1441/orig"
                }),
                (0, k.jsx)(eA, {
                  className: tR().card,
                  text: (0, k.jsx)(P.A, { id: "paywall.books-part-benefit-read-mobile", values: { nbsp: " " } }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/40584/img.66f6ac99ed792c3f4a135afd/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/28592/img.66f6ac924e6e980968aa8463/orig"
                }),
                (0, k.jsx)(eA, {
                  className: tR().card,
                  text: (0, k.jsx)(P.A, {
                    id: "paywall.books-part-benefit-download-mobile",
                    values: { nbsp: " " }
                  }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/40584/img.66f6aca698264a4b59f3a7be/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/70850/img.66f6ac9fcaf72c4bc9eaeaab/orig"
                }),
                (0, k.jsx)(eA, {
                  className: tR().card,
                  text: (0, k.jsx)(P.A, { id: "paywall.books-part-benefit-speed-mobile", values: { nbsp: " " } }),
                  imageSrc: "https://avatars.mds.yandex.net/get-music-misc/30221/img.68c01296fbed8f7a98fb143c/orig",
                  image2xSrc: "https://avatars.mds.yandex.net/get-music-misc/70850/img.68c012bbd8f3372f64a885b9/orig"
                })
              ]
            })
          })
        });
      }, tC = () => {
        let e10 = te();
        return (0, k.jsxs)(k.Fragment, {
          children: [
            e10 ? (0, k.jsx)(tj, {}) : (0, k.jsx)(tv, {}),
            (0, k.jsx)(ez, { className: N().section }),
            (0, k.jsx)(eU, { className: N().section }),
            (0, k.jsx)(tS, { className: N().section }),
            (0, k.jsx)(eV, { className: N().section }),
            (0, k.jsx)(I, { className: N().section_faq, variant: S.RU }),
            (0, k.jsx)(M, { variant: S.RU })
          ]
        });
      }, tA = (0, E.PA)(() => {
        let {
          settings: { isMobile: e10 }
        } = (0, R.Pjs)();
        return (0, k.jsx)("div", { className: e9().root, children: e10 ? (0, k.jsx)(tC, {}) : (0, k.jsx)(tw, {}) });
      }), tN = { [S.RU]: (0, k.jsx)(tA, {}), [S.BY]: (0, k.jsx)(e$, {}), [S.OTHER]: (0, k.jsx)(e2, {}) }, tL = (0, E.PA)((e10) => {
        let { useOverlayScroll: t2 = true } = e10, { user: s2, experiments: r2 } = (0, R.Pjs)(), a2 = (0, R.jwr)(), n2 = (0, w.L)(
          () => (0, k.jsx)("div", {
            "data-buy-subscription-block-portal": true,
            className: N().root,
            ...(0, j.Am)(j.e8.paywall.PAYWALL),
            children: tN[((e11) => e11 && C[e11] || S.OTHER)(s2.account.data.geoRegionIso)]
          })
        ), i2 = (0, h.useMemo)(() => {
          if (a2.isContextDefined) return n2;
          let e11 = r2.checkExperiment(R.zal.WebNextPaywallSecondButton, "on") ? [R.RBW.BLOCK_1, R.RBW.BLOCK_2, R.RBW.BOTTOM_BUTTON] : [R.RBW.BLOCK_1, R.RBW.BOTTOM_BUTTON];
          return (0, k.jsx)(R.rtM, { page: R.l7W.MUSIC_PAYWALL_SCREEN, places: e11, children: n2 });
        }, [a2.isContextDefined, n2, r2]);
        return t2 ? (0, k.jsx)(O.C, {
          className: (0, y.$)(N().overlayScroll, { [N().overlayScroll_desktop]: true }),
          children: i2
        }) : i2;
      });
      var tH = s(32692), tP = s(23189), tT = s.n(tP);
      let tI = (0, E.PA)(() => {
        let { paywall: e10 } = (0, R.Pjs)(), { formatMessage: t2 } = (0, tb.A)(), s2 = (0, R.eGp)();
        return (0, h.useEffect)(() => {
          e10.modal.isOpened && (null == s2 || s2.pause());
        }, [e10.modal.isOpened, s2, true]), (0, k.jsxs)(tH.a, {
          open: e10.modal.isOpened,
          size: "fullscreen",
          placement: "center",
          showHeader: false,
          onClose: e10.closeModal,
          onOpenChange: e10.onOpenChange,
          closeOnOutsidePress: false,
          className: tT().root,
          contentClassName: tT().content,
          overlayColor: "full",
          ...(0, j.Am)(j.e8.paywallModal.PAYWALL_MODAL),
          children: [
            (0, k.jsx)("header", {
              className: tT().header,
              children: (0, k.jsx)(e_.$, {
                radius: "round",
                color: "secondary",
                size: "xxs",
                icon: (0, k.jsx)(D.Icon, { variant: "close", size: "xxs" }),
                className: tT().closeButton,
                onClick: e10.closeModal,
                "aria-label": t2({ id: "interface-actions.close" }),
                ...(0, j.Am)(j.e8.paywallModal.PAYWALL_MODAL_CLOSE_BUTTON)
              })
            }),
            (0, k.jsx)(tL, {})
          ]
        });
      });
    },
    15485: (e) => {
      e.exports = {
        content_ru: "KinopoiskSectionDesktop_content_ru__gILD5",
        content_by: "KinopoiskSectionDesktop_content_by__31QvZ",
        card1: "KinopoiskSectionDesktop_card1__nlqOH",
        card2: "KinopoiskSectionDesktop_card2__ZMW4Z",
        card3: "KinopoiskSectionDesktop_card3__n9_1i",
        card4: "KinopoiskSectionDesktop_card4__TpOZ7",
        logo_ru: "KinopoiskSectionDesktop_logo_ru__f6OLB",
        logo_en: "KinopoiskSectionDesktop_logo_en__2oXnD"
      };
    },
    16503: (e) => {
      e.exports = { root: "PaywallOtherDesktop_root__c19Ht", topSection: "PaywallOtherDesktop_topSection__d1CVV" };
    },
    17017: (e) => {
      e.exports = {
        root: "Paywall_root__XE_NC",
        section: "Paywall_section__Y30nd",
        section_faq: "Paywall_section_faq__43qaB",
        overlayScroll_desktop: "Paywall_overlayScroll_desktop__P46WF"
      };
    },
    17950: (e) => {
      e.exports = { topSection: "PaywallBYMobile_topSection__sQ_sw" };
    },
    19950: (e) => {
      e.exports = {
        content: "MusicSectionDesktop_content__uCWAp",
        card: "MusicSectionDesktop_card__YurZs",
        logo_ru: "MusicSectionDesktop_logo_ru__Tiwfx",
        logo_en: "MusicSectionDesktop_logo_en__dbYCi"
      };
    },
    21511: (e) => {
      e.exports = {
        root: "MainSectionMobile_root__l2R5l",
        headingContainer: "MainSectionMobile_headingContainer__6mJvx",
        contentContainer: "MainSectionMobile_contentContainer__vmaD5"
      };
    },
    23189: (e) => {
      e.exports = {
        root: "PaywallModal_root__HIYOy",
        header: "PaywallModal_header__3oCYF",
        closeButton: "PaywallModal_closeButton__rkLNM",
        content: "PaywallModal_content__mVxnz"
      };
    },
    23698: (e) => {
      e.exports = {
        root: "TopSectionRU_root__DP9u2",
        main: "TopSectionRU_main__PbltM",
        logo: "TopSectionRU_logo__LgT8M",
        moreInfoChildren: "TopSectionRU_moreInfoChildren__d82Ha",
        title: "TopSectionRU_title__csPE2",
        services: "TopSectionRU_services__cmjFp",
        service: "TopSectionRU_service__Q0dCS",
        serviceLogo: "TopSectionRU_serviceLogo___Xpo_",
        serviceLabel: "TopSectionRU_serviceLabel__Q3O8n",
        buySubscriptionBlock: "TopSectionRU_buySubscriptionBlock__VBGT5",
        goHomeLink: "TopSectionRU_goHomeLink__zWv2w"
      };
    },
    24603: (e) => {
      e.exports = {
        content_ru: "KinopoiskSectionMobile_content_ru__CCtkX",
        content_by: "KinopoiskSectionMobile_content_by__XjQaB",
        card1: "KinopoiskSectionMobile_card1__JCIyK",
        card2: "KinopoiskSectionMobile_card2__jTtnr",
        card3: "KinopoiskSectionMobile_card3__wTJCh",
        card4: "KinopoiskSectionMobile_card4__wi_RO",
        card4_by: "KinopoiskSectionMobile_card4_by__8ehWE",
        logo_ru: "KinopoiskSectionMobile_logo_ru__8alc5",
        logo_en: "KinopoiskSectionMobile_logo_en__A673z"
      };
    },
    26018: (e) => {
      e.exports = { root: "PaywallRU_root__X8j2f" };
    },
    30718: (e) => {
      e.exports = {
        root: "TopSectionRUWithBenefits_root__wF1_n",
        main: "TopSectionRUWithBenefits_main__0igzf",
        logo: "TopSectionRUWithBenefits_logo__PbF2i",
        moreInfoChildren: "TopSectionRUWithBenefits_moreInfoChildren__9OEAu",
        title: "TopSectionRUWithBenefits_title__pXmdX",
        benefits: "TopSectionRUWithBenefits_benefits__GweJJ",
        benefit: "TopSectionRUWithBenefits_benefit__12ENa",
        benefit_recommendation: "TopSectionRUWithBenefits_benefit_recommendation__PMApk",
        benefitLogo: "TopSectionRUWithBenefits_benefitLogo__ntii8",
        benefitLabelDesktop: "TopSectionRUWithBenefits_benefitLabelDesktop__eITJ5",
        benefitLabelMobile: "TopSectionRUWithBenefits_benefitLabelMobile__ndVcr",
        buySubscriptionBlock: "TopSectionRUWithBenefits_buySubscriptionBlock___AM6p",
        goHomeLink: "TopSectionRUWithBenefits_goHomeLink__EJjJD"
      };
    },
    32448: (e) => {
      e.exports = {
        root: "UserIcon_root__X0jg9",
        root_withPlus: "UserIcon_root_withPlus__pRhgW",
        avatar: "UserIcon_avatar__6_6av"
      };
    },
    36382: (e) => {
      e.exports = {
        content_ru: "PlusSectionDesktop_content_ru__85q1P",
        content_by: "PlusSectionDesktop_content_by__UBg10",
        card: "PlusSectionDesktop_card__h8LmR",
        logo_ru: "PlusSectionDesktop_logo_ru__G2AkZ",
        logo_en: "PlusSectionDesktop_logo_en__gn4qE"
      };
    },
    36729: (e) => {
      e.exports = {
        root: "TopSectionDesktop_root__lDNkV",
        wrapper: "TopSectionDesktop_wrapper__sEPZr",
        content: "TopSectionDesktop_content__356Uk",
        title: "TopSectionDesktop_title__JFo6R",
        label: "TopSectionDesktop_label__JmilG",
        buySubscriptionBlock: "TopSectionDesktop_buySubscriptionBlock__dhv3Z"
      };
    },
    41752: (e) => {
      e.exports = {
        title: "OtherServicesSectionDesktop_title__TmiIR",
        content_ru: "OtherServicesSectionDesktop_content_ru__tShm1",
        content_by: "OtherServicesSectionDesktop_content_by__GAt4T",
        card: "OtherServicesSectionDesktop_card__HqmGz",
        logo_ru: "OtherServicesSectionDesktop_logo_ru__tox8Q",
        logo_en: "OtherServicesSectionDesktop_logo_en__xuJro"
      };
    },
    45606: (e) => {
      e.exports = { topSection: "PaywallBYDesktop_topSection__AS3Pv" };
    },
    49320: (e, t, s) => {
      "use strict";
      s.d(t, { ny: () => v, Fv: () => d, YS: () => W });
      var r = s(93064), a = s(26433);
      let n = r.gK.model({
        uid: r.gK.maybe(r.gK.number),
        hasPlus: r.gK.maybe(r.gK.boolean),
        login: r.gK.maybe(r.gK.string),
        avatarId: r.gK.maybe(r.gK.string),
        isChild: r.gK.maybe(r.gK.boolean),
        publicId: r.gK.maybe(r.gK.string),
        publicName: r.gK.maybe(r.gK.string),
        userSessionRegionIso: r.gK.maybe(r.gK.string),
        geoRegionIso: r.gK.maybe(r.gK.string),
        serviceAvailable: r.gK.maybe(r.gK.boolean)
      }), i = r.gK.compose(r.gK.model("Account", { data: n }), a.XT);
      var l = s(74125), o = s(31905);
      let c = (e2) => {
        var t2, s2;
        return (0, r.wg)({
          loadingState: l.GuX.RESOLVE,
          showWizard: !e2.wizardIsPassed,
          userCollectionHue: e2.userCollectionHue,
          isChildModeEnabled: !!e2.childModEnabled,
          userMusicVisibility: null != (s2 = null == (t2 = e2.userMusicVisibility) ? void 0 : t2.toLowerCase()) ? s2 : o.L.PUBLIC
        });
      }, x = r.gK.compose(
        r.gK.model("Settings", {
          showWizard: r.gK.optional(r.gK.boolean, true),
          userCollectionHue: r.gK.maybe(r.gK.number),
          isChildModeEnabled: r.gK.optional(r.gK.boolean, false),
          userMusicVisibility: r.gK.optional(r.gK.string, o.L.PUBLIC)
        }),
        a.XT
      ), d = r.gK.model("User", { account: i, settings: x, userCollectionHue: r.gK.maybe(r.gK.number) }).views((e2) => ({
        get isAuthorized() {
          return !!e2.account.data.uid;
        },
        get hasPlus() {
          return !!e2.account.data.hasPlus;
        },
        get isChild() {
          return !!e2.account.data.isChild;
        },
        get puid() {
          return e2.account.data.uid;
        },
        get collectionHue() {
          return e2.userCollectionHue || e2.settings.userCollectionHue;
        },
        get isServiceAvailable() {
          var t2;
          return null == (t2 = e2.account.data.serviceAvailable) || t2;
        },
        get advertRole() {
          if (!this.isAuthorized) return l.Zxe.UNAUTHORIZED;
          if (this.hasPlus) return l.Zxe.PLUS;
          return l.Zxe.NON_PLUS;
        }
      })).actions((e2) => ({
        getAbout: (0, r.L3)(function* (t2) {
          let { accountResource: s2, modelActionsLogger: a2, containerStorage: n2 } = (0, r._$)(e2);
          if (!e2.account.isLoading)
            try {
              let a3;
              e2.account.loadingState = l.GuX.PENDING;
              let i2 = t2;
              i2 || (i2 = yield s2.about()), n2.set(l.cYZ.YmUid, i2.uid), e2.account.data = (a3 = i2, (0, r.wg)({
                uid: a3.uid,
                login: a3.login,
                avatarId: a3.avatarId,
                hasPlus: a3.hasPlus,
                publicId: a3.publicId,
                publicName: a3.publicName,
                isChild: a3.isChild,
                userSessionRegionIso: a3.userSessionRegionIso,
                geoRegionIso: a3.geoRegionIso,
                serviceAvailable: a3.serviceAvailable
              })), e2.account.loadingState = l.GuX.RESOLVE;
            } catch (t3) {
              a2.error(t3), e2.account.loadingState = l.GuX.REJECT;
            }
        }),
        getSettings: (0, r.L3)(function* () {
          let { accountResource: t2, modelActionsLogger: s2 } = (0, r._$)(e2);
          if (e2.settings.loadingState !== l.GuX.PENDING)
            try {
              e2.settings.loadingState = l.GuX.PENDING;
              let s3 = yield t2.settings();
              e2.settings = c(s3);
            } catch (t3) {
              s2.error(t3), e2.settings.showWizard = false, e2.settings.loadingState = l.GuX.REJECT;
            }
        }),
        setSettings: (0, r.L3)(function* (t2) {
          let { isChildModeEnabled: s2, userMusicVisibility: a2 } = t2, { accountResource: n2, modelActionsLogger: i2 } = (0, r._$)(e2);
          try {
            let t3 = {};
            "boolean" == typeof s2 && (t3.childModEnabled = s2, e2.settings.isChildModeEnabled = s2), a2 && (t3.userMusicVisibility = a2, e2.settings.userMusicVisibility = a2);
            let r2 = yield n2.settings(t3);
            if (e2.settings = c(r2), r2.childModEnabled !== s2) return l.FlZ.ERROR;
            return l.FlZ.OK;
          } catch (e3) {
            return i2.error(e3), l.FlZ.ERROR;
          }
        }),
        setUnauthorized: () => {
          e2.account.loadingState = l.GuX.RESOLVE;
        },
        setUserCollectionHue: (t2) => {
          e2.userCollectionHue = t2;
        }
      }));
      var u = s(54486), f = s(50420), _ = s(58360);
      let m = { src: "/_next/static/media/avatar.e9a40453.png" };
      var p = s(32448), g = s.n(p);
      let v = (e2) => {
        let { className: t2, hasPlus: s2, avatarSrc: r2 = m.src, ...a2 } = e2;
        return (0, u.jsx)("div", {
          className: (0, f.$)(g().root, { [g().root_withPlus]: s2 }, t2),
          ...a2,
          children: (0, u.jsx)(_.Image, { src: r2, fit: "cover", className: g().avatar })
        });
      };
      var b = s(62088), k = s(28303), y = s(61910), E = s.t(y, 2), h = s(47713), j = s(15209), w = s(31500), O = s(8817), R = {
        5881: (e2, t2, s2) => {
          function r2() {
            for (var e3, t3, s3 = 0, r3 = ""; s3 < arguments.length; )
              (e3 = arguments[s3++]) && (t3 = (function e4(t4) {
                var s4, r4, a3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) a3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (s4 = 0; s4 < t4.length; s4++) t4[s4] && (r4 = e4(t4[s4])) && (a3 && (a3 += " "), a3 += r4);
                  else for (s4 in t4) t4[s4] && (a3 && (a3 += " "), a3 += s4);
                return a3;
              })(e3)) && (r3 && (r3 += " "), r3 += t3);
            return r3;
          }
          s2.r(t2), s2.d(t2, { clsx: () => r2, default: () => a2 });
          let a2 = r2;
        },
        2964: (e2, t2, s2) => {
          s2.r(t2), s2.d(t2, { default: () => r2 });
          let r2 = {
            root_size_xxxs: "Rkdd2vKC_3xa1eUdRdHP",
            root_size_xxs: "l3tE1hAMmBj2aoPPwU08",
            root_size_xs: "UwnL5AJBMMAp6NwMDdZk",
            root_size_s: "DzJFnuf7XgdkFh28JAsM",
            root_size_m: "o_v2ds2BaqtzAsRuCVjw",
            root_size_l: "YjRa1ZjM_lXFlrfS7jcu",
            root_size_xl: "Seq0GowcqQmiA9LdLP_g",
            root_size_xxl: "mfy69_BvBIamD0e22rCQ",
            root_size_xxxl: "JY1OniQewgW9iHgfllZS"
          };
        },
        1684: (e2, t2, s2) => {
          s2.r(t2), s2.d(t2, { default: () => r2 });
          let r2 = { root: "mdbxU6IWInQTsVjwnapn", text: "Cl_DNqTqaeGRXa9FZpOO", icon: "WMUZ6rmDKcZuPFMkQwf6" };
        },
        3641: (e2, t2, s2) => {
          s2.r(t2), s2.d(t2, { default: () => r2 });
          let r2 = {
            root_controls_xxs: "tRaaBpDMg9Qu8v6gKjtn",
            root_entity_xxs: "M9zvtlcpLUVn6DKdcHhj",
            root_text_xxs: "ln0PYYwDmFnfYxCDJsFU",
            root_controls_xs: "n5AeWEsJC3_AYXcbK4Lt",
            root_entity_xs: "__hrMKGmNbw54T54IUyh",
            root_text_xs: "SehSa7OyRpC2nzYTVb2Q",
            root_controls_s: "_oBLf5gprWsKjCw4Ce58",
            root_entity_s: "mxSPe5xpZnie9gpIqacd",
            root_text_s: "Ai2iRN9elHpk_u5splD6",
            root_controls_m: "tk7ahHRDYXJMMB879KUA",
            root_entity_m: "Z_WIr2W8JU4MPQek3hgR",
            root_text_m: "g3qWNP6xl__7qxNmtrvd",
            root_controls_l: "grvxapJE3vGArOKDWf6n",
            root_entity_l: "Esj5A1UeSi4xV4tZ839D",
            root_text_l: "V3WU123oO65AxsprotU9",
            root_weight_normal: "ZYV27jeWd30QDXu4GhaH",
            root_weight_medium: "_3_Mxw7Si7j2g4kWjlpR",
            root_weight_bold: "Vi7Rd0SZWqD17F0872TB"
          };
        },
        5153: (e2, t2, s2) => {
          s2.r(t2), s2.d(t2, { default: () => r2 });
          let r2 = {
            root_size_xs: "qJJ288377iHlWN_RXeEE",
            root_size_s: "_sd8Q9d_Ttn0Ufe4ISWS",
            root_size_m: "Ctk8dbecq31Qh7isOJPQ",
            root_size_l: "M_Djh6ppIkCO3A2k_BTA",
            root_size_xl: "dtxlzGQMPAbM2MEndXWX",
            root_size_xxl: "IUb9XLplTAoZqne9rNUL",
            root_size_xxxl: "ZYZamUwql_rfFR4RpI2B",
            root_size_xxxxl: "ZBZyxow5njdq8z5dnRPY",
            root_size_xxxxxl: "WdvQQNwdDNCdRSwRkAtT",
            root_weight_bold: "nSU6fV9y80WrZEfafvww",
            root_weight_black: "KBeGPPK4DinQzAP41Y_N"
          };
        },
        5818: (e2, t2, s2) => {
          s2.r(t2), s2.d(t2, { default: () => r2 });
          let r2 = {
            root: "_MWOVuZRvUQdXKTMcOPx",
            root_clamp: "LezmJlldtbHWqU7l1950",
            root_clamp_oneline: "oyQL2RSmoNbNQf3Vc6YI",
            root_clamp_multiline: "jMyoZB5J9iZbzJmWOrF0"
          };
        },
        9097: (e2, t2) => {
          var s2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function r2(e3, t3, r3) {
            var a2 = null;
            if (void 0 !== r3 && (a2 = "" + r3), void 0 !== t3.key && (a2 = "" + t3.key), "key" in t3)
              for (var n2 in r3 = {}, t3) "key" !== n2 && (r3[n2] = t3[n2]);
            else r3 = t3;
            return { $$typeof: s2, type: e3, key: a2, ref: void 0 !== (t3 = r3.ref) ? t3 : null, props: r3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = r2, t2.jsxs = r2;
        },
        4377: (e2, t2, s2) => {
          e2.exports = s2(9097);
        },
        8442: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "addToPlaylist_xxs", xlinkHref: "/icons/sprite.svg#addToPlaylist_xxs" })
            ]);
          });
        },
        6644: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "add_l", xlinkHref: "/icons/sprite.svg#add_l" })
            ]);
          });
        },
        7319: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "add_xxs", xlinkHref: "/icons/sprite.svg#add_xxs" })
            ]);
          });
        },
        9351: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "adult_s", xlinkHref: "/icons/sprite.svg#adult_s" })
            ]);
          });
        },
        7171: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "adult_xs", xlinkHref: "/icons/sprite.svg#adult_xs" })
            ]);
          });
        },
        2586: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "adult_xxs", xlinkHref: "/icons/sprite.svg#adult_xxs" })
            ]);
          });
        },
        4656: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "adult_xxxs", xlinkHref: "/icons/sprite.svg#adult_xxxs" })
            ]);
          });
        },
        996: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "album_l", xlinkHref: "/icons/sprite.svg#album_l" })
            ]);
          });
        },
        2092: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "album_s", xlinkHref: "/icons/sprite.svg#album_s" })
            ]);
          });
        },
        6304: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "album_xl", xlinkHref: "/icons/sprite.svg#album_xl" })
            ]);
          });
        },
        9030: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "album_xs", xlinkHref: "/icons/sprite.svg#album_xs" })
            ]);
          });
        },
        5822: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "album_xxs", xlinkHref: "/icons/sprite.svg#album_xxs" })
            ]);
          });
        },
        9422: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "arrowDown_xs", xlinkHref: "/icons/sprite.svg#arrowDown_xs" })
            ]);
          });
        },
        5272: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "arrowDown_xxs", xlinkHref: "/icons/sprite.svg#arrowDown_xxs" })
            ]);
          });
        },
        1491: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "arrowLeft_xs", xlinkHref: "/icons/sprite.svg#arrowLeft_xs" })
            ]);
          });
        },
        4860: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "arrowLeft_xxs", xlinkHref: "/icons/sprite.svg#arrowLeft_xxs" })
            ]);
          });
        },
        2337: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "arrowRight_xs", xlinkHref: "/icons/sprite.svg#arrowRight_xs" })
            ]);
          });
        },
        8711: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "arrowRight_xxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxs" })
            ]);
          });
        },
        8170: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "arrowRight_xxxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxxs" })
            ]);
          });
        },
        8109: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "artist_xxs", xlinkHref: "/icons/sprite.svg#artist_xxs" })
            ]);
          });
        },
        7341: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "attention_xxl", xlinkHref: "/icons/sprite.svg#attention_xxl" })
            ]);
          });
        },
        2435: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "attention_xxxl", xlinkHref: "/icons/sprite.svg#attention_xxxl" })
            ]);
          });
        },
        3918: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "bandlink", xlinkHref: "/icons/sprite.svg#bandlink" })
            ]);
          });
        },
        2571: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "booksLogo", xlinkHref: "/icons/sprite.svg#booksLogo" })
            ]);
          });
        },
        4904: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "bucket_xxs", xlinkHref: "/icons/sprite.svg#bucket_xxs" })
            ]);
          });
        },
        9202: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "cast_xs", xlinkHref: "/icons/sprite.svg#cast_xs" })
            ]);
          });
        },
        130: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "chain_xs", xlinkHref: "/icons/sprite.svg#chain_xs" })
            ]);
          });
        },
        5971: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "chain_xxs", xlinkHref: "/icons/sprite.svg#chain_xxs" })
            ]);
          });
        },
        3331: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "chartDown_xxs", xlinkHref: "/icons/sprite.svg#chartDown_xxs" })
            ]);
          });
        },
        9783: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "chartNew_xxs", xlinkHref: "/icons/sprite.svg#chartNew_xxs" })
            ]);
          });
        },
        8184: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "chartSame_xxs", xlinkHref: "/icons/sprite.svg#chartSame_xxs" })
            ]);
          });
        },
        4926: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "chartUp_xxs", xlinkHref: "/icons/sprite.svg#chartUp_xxs" })
            ]);
          });
        },
        9505: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "check_xxl", xlinkHref: "/icons/sprite.svg#check_xxl" })
            ]);
          });
        },
        3176: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "check_xxs", xlinkHref: "/icons/sprite.svg#check_xxs" })
            ]);
          });
        },
        5565: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "check_xxxs", xlinkHref: "/icons/sprite.svg#check_xxxs" })
            ]);
          });
        },
        9040: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "clip_xl", xlinkHref: "/icons/sprite.svg#clip_xl" })
            ]);
          });
        },
        4789: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "clip_xxs", xlinkHref: "/icons/sprite.svg#clip_xxs" })
            ]);
          });
        },
        7923: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "close_xs", xlinkHref: "/icons/sprite.svg#close_xs" })
            ]);
          });
        },
        8151: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "close_xxs", xlinkHref: "/icons/sprite.svg#close_xxs" })
            ]);
          });
        },
        8127: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "close_xxxs", xlinkHref: "/icons/sprite.svg#close_xxxs" })
            ]);
          });
        },
        8690: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "code_xxs", xlinkHref: "/icons/sprite.svg#code_xxs" })
            ]);
          });
        },
        3076: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "collections_m", xlinkHref: "/icons/sprite.svg#collections_m" })
            ]);
          });
        },
        2495: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "collections_selected_m",
                xlinkHref: "/icons/sprite.svg#collections_selected_m"
              })
            ]);
          });
        },
        1524: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "crown_xxs", xlinkHref: "/icons/sprite.svg#crown_xxs" })
            ]);
          });
        },
        1162: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "dislike_s", xlinkHref: "/icons/sprite.svg#dislike_s" })
            ]);
          });
        },
        3654: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "dislike_xs", xlinkHref: "/icons/sprite.svg#dislike_xs" })
            ]);
          });
        },
        2361: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "dislike_xxs", xlinkHref: "/icons/sprite.svg#dislike_xxs" })
            ]);
          });
        },
        6837: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "disliked_s", xlinkHref: "/icons/sprite.svg#disliked_s" })
            ]);
          });
        },
        6507: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "disliked_xs", xlinkHref: "/icons/sprite.svg#disliked_xs" })
            ]);
          });
        },
        3972: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "disliked_xxs", xlinkHref: "/icons/sprite.svg#disliked_xxs" })
            ]);
          });
        },
        8993: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "donation_xxxs", xlinkHref: "/icons/sprite.svg#donation_xxxs" })
            ]);
          });
        },
        7031: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "download_l", xlinkHref: "/icons/sprite.svg#download_l" })
            ]);
          });
        },
        9330: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "download_xxs", xlinkHref: "/icons/sprite.svg#download_xxs" })
            ]);
          });
        },
        7346: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "downloaded_xxs", xlinkHref: "/icons/sprite.svg#downloaded_xxs" })
            ]);
          });
        },
        2604: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "dragDots_xxs", xlinkHref: "/icons/sprite.svg#dragDots_xxs" })
            ]);
          });
        },
        6894: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "edit_xxs", xlinkHref: "/icons/sprite.svg#edit_xxs" })
            ]);
          });
        },
        2024: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "exclamation_s", xlinkHref: "/icons/sprite.svg#exclamation_s" })
            ]);
          });
        },
        3193: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "exclamation_xs", xlinkHref: "/icons/sprite.svg#exclamation_xs" })
            ]);
          });
        },
        6391: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "exclamation_xxs", xlinkHref: "/icons/sprite.svg#exclamation_xxs" })
            ]);
          });
        },
        2933: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "exclamation_xxxs", xlinkHref: "/icons/sprite.svg#exclamation_xxxs" })
            ]);
          });
        },
        776: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "explicit_s", xlinkHref: "/icons/sprite.svg#explicit_s" })
            ]);
          });
        },
        30: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "explicit_xs", xlinkHref: "/icons/sprite.svg#explicit_xs" })
            ]);
          });
        },
        9369: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "explicit_xxs", xlinkHref: "/icons/sprite.svg#explicit_xxs" })
            ]);
          });
        },
        1334: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "explicit_xxxs", xlinkHref: "/icons/sprite.svg#explicit_xxxs" })
            ]);
          });
        },
        226: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "eye_crossed_xxs", xlinkHref: "/icons/sprite.svg#eye_crossed_xxs" })
            ]);
          });
        },
        7802: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "filter_xs", xlinkHref: "/icons/sprite.svg#filter_xs" })
            ]);
          });
        },
        8130: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "filter_xxs", xlinkHref: "/icons/sprite.svg#filter_xxs" })
            ]);
          });
        },
        3738: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "fullscreen_xs", xlinkHref: "/icons/sprite.svg#fullscreen_xs" })
            ]);
          });
        },
        2161: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "googlePlay", xlinkHref: "/icons/sprite.svg#googlePlay" })
            ]);
          });
        },
        9509: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "history_m", xlinkHref: "/icons/sprite.svg#history_m" })
            ]);
          });
        },
        8987: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "home_m", xlinkHref: "/icons/sprite.svg#home_m" })
            ]);
          });
        },
        190: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "home_selected_m", xlinkHref: "/icons/sprite.svg#home_selected_m" })
            ]);
          });
        },
        5304: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "huaweiAppGallery", xlinkHref: "/icons/sprite.svg#huaweiAppGallery" })
            ]);
          });
        },
        5270: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "info_xxs", xlinkHref: "/icons/sprite.svg#info_xxs" })
            ]);
          });
        },
        843: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "kids_m", xlinkHref: "/icons/sprite.svg#kids_m" })
            ]);
          });
        },
        5122: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "kids_selected_m", xlinkHref: "/icons/sprite.svg#kids_selected_m" })
            ]);
          });
        },
        2646: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "kinopoiskEn", xlinkHref: "/icons/sprite.svg#kinopoiskEn" })
            ]);
          });
        },
        7500: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "kinopoiskRu", xlinkHref: "/icons/sprite.svg#kinopoiskRu" })
            ]);
          });
        },
        3560: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "lightning_xxs", xlinkHref: "/icons/sprite.svg#lightning_xxs" })
            ]);
          });
        },
        9838: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "likeVariant_xxs", xlinkHref: "/icons/sprite.svg#likeVariant_xxs" })
            ]);
          });
        },
        4793: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "like_l", xlinkHref: "/icons/sprite.svg#like_l" })
            ]);
          });
        },
        7405: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "like_m", xlinkHref: "/icons/sprite.svg#like_m" })
            ]);
          });
        },
        2340: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "like_xs", xlinkHref: "/icons/sprite.svg#like_xs" })
            ]);
          });
        },
        7513: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "like_xxs", xlinkHref: "/icons/sprite.svg#like_xxs" })
            ]);
          });
        },
        5720: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "likedVariant_s", xlinkHref: "/icons/sprite.svg#likedVariant_s" })
            ]);
          });
        },
        7399: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "likedVariant_xxs", xlinkHref: "/icons/sprite.svg#likedVariant_xxs" })
            ]);
          });
        },
        820: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "liked_m", xlinkHref: "/icons/sprite.svg#liked_m" })
            ]);
          });
        },
        2125: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "liked_xs", xlinkHref: "/icons/sprite.svg#liked_xs" })
            ]);
          });
        },
        9104: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "liked_xxs", xlinkHref: "/icons/sprite.svg#liked_xxs" })
            ]);
          });
        },
        5849: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "link_xxs", xlinkHref: "/icons/sprite.svg#link_xxs" })
            ]);
          });
        },
        1426: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "listen_xxxs", xlinkHref: "/icons/sprite.svg#listen_xxxs" })
            ]);
          });
        },
        4014: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "liteVersion_xs", xlinkHref: "/icons/sprite.svg#liteVersion_xs" })
            ]);
          });
        },
        5443: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "lock_m", xlinkHref: "/icons/sprite.svg#lock_m" })
            ]);
          });
        },
        896: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "lock_xs", xlinkHref: "/icons/sprite.svg#lock_xs" })
            ]);
          });
        },
        3613: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "lock_xxs", xlinkHref: "/icons/sprite.svg#lock_xxs" })
            ]);
          });
        },
        9372: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "lyrics_xxs", xlinkHref: "/icons/sprite.svg#lyrics_xxs" })
            ]);
          });
        },
        6104: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "macos", xlinkHref: "/icons/sprite.svg#macos" })
            ]);
          });
        },
        3709: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "macos_xxs", xlinkHref: "/icons/sprite.svg#macos_xxs" })
            ]);
          });
        },
        3685: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "menuArrow_xxs", xlinkHref: "/icons/sprite.svg#menuArrow_xxs" })
            ]);
          });
        },
        8782: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "more_m", xlinkHref: "/icons/sprite.svg#more_m" })
            ]);
          });
        },
        1829: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "more_xs", xlinkHref: "/icons/sprite.svg#more_xs" })
            ]);
          });
        },
        3302: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "more_xxs", xlinkHref: "/icons/sprite.svg#more_xxs" })
            ]);
          });
        },
        2502: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "musicLogo", xlinkHref: "/icons/sprite.svg#musicLogo" })
            ]);
          });
        },
        1754: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "musicLogoCenterEn", xlinkHref: "/icons/sprite.svg#musicLogoCenterEn" })
            ]);
          });
        },
        6615: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "musicLogoCenterRu", xlinkHref: "/icons/sprite.svg#musicLogoCenterRu" })
            ]);
          });
        },
        7942: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "musicLogoLeftEn", xlinkHref: "/icons/sprite.svg#musicLogoLeftEn" })
            ]);
          });
        },
        1498: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "musicLogoLeftRu", xlinkHref: "/icons/sprite.svg#musicLogoLeftRu" })
            ]);
          });
        },
        1893: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "navigationCollection_xs",
                xlinkHref: "/icons/sprite.svg#navigationCollection_xs"
              })
            ]);
          });
        },
        1563: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "navigationConcerts_xs",
                xlinkHref: "/icons/sprite.svg#navigationConcerts_xs"
              })
            ]);
          });
        },
        1578: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "navigationForYouAndTrends_xs",
                xlinkHref: "/icons/sprite.svg#navigationForYouAndTrends_xs"
              })
            ]);
          });
        },
        9348: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "navigationKids_xs", xlinkHref: "/icons/sprite.svg#navigationKids_xs" })
            ]);
          });
        },
        965: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "navigationMyVibe_xs",
                xlinkHref: "/icons/sprite.svg#navigationMyVibe_xs"
              })
            ]);
          });
        },
        3877: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "navigationNonMusic_xs",
                xlinkHref: "/icons/sprite.svg#navigationNonMusic_xs"
              })
            ]);
          });
        },
        9968: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "navigationPlus_xs", xlinkHref: "/icons/sprite.svg#navigationPlus_xs" })
            ]);
          });
        },
        3778: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "navigationSearch_xs",
                xlinkHref: "/icons/sprite.svg#navigationSearch_xs"
              })
            ]);
          });
        },
        1084: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "next_xs", xlinkHref: "/icons/sprite.svg#next_xs" })
            ]);
          });
        },
        4483: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "next_xxl", xlinkHref: "/icons/sprite.svg#next_xxl" })
            ]);
          });
        },
        811: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "next_xxs", xlinkHref: "/icons/sprite.svg#next_xxs" })
            ]);
          });
        },
        7252: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "non_music_m", xlinkHref: "/icons/sprite.svg#non_music_m" })
            ]);
          });
        },
        3013: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "non_music_selected_m",
                xlinkHref: "/icons/sprite.svg#non_music_selected_m"
              })
            ]);
          });
        },
        2774: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "note_s", xlinkHref: "/icons/sprite.svg#note_s" })
            ]);
          });
        },
        4298: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "note_xl", xlinkHref: "/icons/sprite.svg#note_xl" })
            ]);
          });
        },
        4254: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "note_xs", xlinkHref: "/icons/sprite.svg#note_xs" })
            ]);
          });
        },
        8499: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "offline_xxl", xlinkHref: "/icons/sprite.svg#offline_xxl" })
            ]);
          });
        },
        4997: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pauseVibe_s", xlinkHref: "/icons/sprite.svg#pauseVibe_s" })
            ]);
          });
        },
        7076: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pause_filled_l", xlinkHref: "/icons/sprite.svg#pause_filled_l" })
            ]);
          });
        },
        3792: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pause_filled_m", xlinkHref: "/icons/sprite.svg#pause_filled_m" })
            ]);
          });
        },
        5132: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pause_filled_xl", xlinkHref: "/icons/sprite.svg#pause_filled_xl" })
            ]);
          });
        },
        8131: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pause_filled_xs", xlinkHref: "/icons/sprite.svg#pause_filled_xs" })
            ]);
          });
        },
        705: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pause_filled_xxl", xlinkHref: "/icons/sprite.svg#pause_filled_xxl" })
            ]);
          });
        },
        5346: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pause_m", xlinkHref: "/icons/sprite.svg#pause_m" })
            ]);
          });
        },
        792: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pause_xs", xlinkHref: "/icons/sprite.svg#pause_xs" })
            ]);
          });
        },
        6122: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pause_xxs", xlinkHref: "/icons/sprite.svg#pause_xxs" })
            ]);
          });
        },
        5386: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pencil_xxs", xlinkHref: "/icons/sprite.svg#pencil_xxs" })
            ]);
          });
        },
        3146: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "picture_s", xlinkHref: "/icons/sprite.svg#picture_s" })
            ]);
          });
        },
        8868: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "picture_xl", xlinkHref: "/icons/sprite.svg#picture_xl" })
            ]);
          });
        },
        1125: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "picture_xs", xlinkHref: "/icons/sprite.svg#picture_xs" })
            ]);
          });
        },
        976: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pin_filled_xs", xlinkHref: "/icons/sprite.svg#pin_filled_xs" })
            ]);
          });
        },
        9434: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pin_filled_xxs", xlinkHref: "/icons/sprite.svg#pin_filled_xxs" })
            ]);
          });
        },
        9288: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pin_xs", xlinkHref: "/icons/sprite.svg#pin_xs" })
            ]);
          });
        },
        3201: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "pin_xxs", xlinkHref: "/icons/sprite.svg#pin_xxs" })
            ]);
          });
        },
        8112: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "playLast_xxs", xlinkHref: "/icons/sprite.svg#playLast_xxs" })
            ]);
          });
        },
        8044: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "playNext_xxs", xlinkHref: "/icons/sprite.svg#playNext_xxs" })
            ]);
          });
        },
        8303: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "playQueue_m", xlinkHref: "/icons/sprite.svg#playQueue_m" })
            ]);
          });
        },
        9863: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "playQueue_xs", xlinkHref: "/icons/sprite.svg#playQueue_xs" })
            ]);
          });
        },
        2084: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "playVibe_s", xlinkHref: "/icons/sprite.svg#playVibe_s" })
            ]);
          });
        },
        8582: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "play_filled_l", xlinkHref: "/icons/sprite.svg#play_filled_l" })
            ]);
          });
        },
        4777: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "play_filled_m", xlinkHref: "/icons/sprite.svg#play_filled_m" })
            ]);
          });
        },
        8779: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "play_filled_xl", xlinkHref: "/icons/sprite.svg#play_filled_xl" })
            ]);
          });
        },
        1945: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "play_filled_xs", xlinkHref: "/icons/sprite.svg#play_filled_xs" })
            ]);
          });
        },
        7402: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "play_filled_xxl", xlinkHref: "/icons/sprite.svg#play_filled_xxl" })
            ]);
          });
        },
        1351: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "play_m", xlinkHref: "/icons/sprite.svg#play_m" })
            ]);
          });
        },
        1874: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "play_xs", xlinkHref: "/icons/sprite.svg#play_xs" })
            ]);
          });
        },
        2026: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "play_xxs", xlinkHref: "/icons/sprite.svg#play_xxs" })
            ]);
          });
        },
        5378: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "play_xxxs", xlinkHref: "/icons/sprite.svg#play_xxxs" })
            ]);
          });
        },
        3751: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "playlist_s", xlinkHref: "/icons/sprite.svg#playlist_s" })
            ]);
          });
        },
        8503: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "playlist_xl", xlinkHref: "/icons/sprite.svg#playlist_xl" })
            ]);
          });
        },
        1580: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "playlist_xs", xlinkHref: "/icons/sprite.svg#playlist_xs" })
            ]);
          });
        },
        8861: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "plus", xlinkHref: "/icons/sprite.svg#plus" })
            ]);
          });
        },
        6809: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "plusBadge", xlinkHref: "/icons/sprite.svg#plusBadge" })
            ]);
          });
        },
        5266: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "plusColor", xlinkHref: "/icons/sprite.svg#plusColor" })
            ]);
          });
        },
        1179: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "plusOutlined", xlinkHref: "/icons/sprite.svg#plusOutlined" })
            ]);
          });
        },
        735: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "plusOutlined_m", xlinkHref: "/icons/sprite.svg#plusOutlined_m" })
            ]);
          });
        },
        2754: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "podcasts_xxs", xlinkHref: "/icons/sprite.svg#podcasts_xxs" })
            ]);
          });
        },
        4091: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "previous_xs", xlinkHref: "/icons/sprite.svg#previous_xs" })
            ]);
          });
        },
        1427: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "previous_xxl", xlinkHref: "/icons/sprite.svg#previous_xxl" })
            ]);
          });
        },
        5251: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "previous_xxs", xlinkHref: "/icons/sprite.svg#previous_xxs" })
            ]);
          });
        },
        895: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "repeat_one_xs", xlinkHref: "/icons/sprite.svg#repeat_one_xs" })
            ]);
          });
        },
        5632: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "repeat_one_xxs", xlinkHref: "/icons/sprite.svg#repeat_one_xxs" })
            ]);
          });
        },
        8090: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "repeat_xs", xlinkHref: "/icons/sprite.svg#repeat_xs" })
            ]);
          });
        },
        9370: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "repeat_xxs", xlinkHref: "/icons/sprite.svg#repeat_xxs" })
            ]);
          });
        },
        1001: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "reset_xxs", xlinkHref: "/icons/sprite.svg#reset_xxs" })
            ]);
          });
        },
        6579: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "reset_xxxs", xlinkHref: "/icons/sprite.svg#reset_xxxs" })
            ]);
          });
        },
        5910: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "rewindBackwards_xs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xs"
              })
            ]);
          });
        },
        893: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "rewindBackwards_xxs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xxs"
              })
            ]);
          });
        },
        4892: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "rewindForward_xs", xlinkHref: "/icons/sprite.svg#rewindForward_xs" })
            ]);
          });
        },
        6331: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "rewindForward_xxs", xlinkHref: "/icons/sprite.svg#rewindForward_xxs" })
            ]);
          });
        },
        2176: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "ruble_m", xlinkHref: "/icons/sprite.svg#ruble_m" })
            ]);
          });
        },
        9876: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "ruble_xxs", xlinkHref: "/icons/sprite.svg#ruble_xxs" })
            ]);
          });
        },
        3935: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "ruble_xxxs", xlinkHref: "/icons/sprite.svg#ruble_xxxs" })
            ]);
          });
        },
        7643: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "search_l", xlinkHref: "/icons/sprite.svg#search_l" })
            ]);
          });
        },
        8235: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "search_m", xlinkHref: "/icons/sprite.svg#search_m" })
            ]);
          });
        },
        8915: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "search_selected_m", xlinkHref: "/icons/sprite.svg#search_selected_m" })
            ]);
          });
        },
        3366: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "search_xs", xlinkHref: "/icons/sprite.svg#search_xs" })
            ]);
          });
        },
        7934: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "search_xxl", xlinkHref: "/icons/sprite.svg#search_xxl" })
            ]);
          });
        },
        5034: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "settings_xs", xlinkHref: "/icons/sprite.svg#settings_xs" })
            ]);
          });
        },
        1758: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "settings_xxs", xlinkHref: "/icons/sprite.svg#settings_xxs" })
            ]);
          });
        },
        7196: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "share_xxs", xlinkHref: "/icons/sprite.svg#share_xxs" })
            ]);
          });
        },
        5792: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "shuffle_xs", xlinkHref: "/icons/sprite.svg#shuffle_xs" })
            ]);
          });
        },
        7951: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "shuffle_xxs", xlinkHref: "/icons/sprite.svg#shuffle_xxs" })
            ]);
          });
        },
        9545: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "site_xs", xlinkHref: "/icons/sprite.svg#site_xs" })
            ]);
          });
        },
        2037: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_1_25x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_m"
              })
            ]);
          });
        },
        3362: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_1_25x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_xs"
              })
            ]);
          });
        },
        9846: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "speed_1_25x_l", xlinkHref: "/icons/sprite.svg#speed_1_25x_l" })
            ]);
          });
        },
        5197: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_1_5x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_m"
              })
            ]);
          });
        },
        1079: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_1_5x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_xs"
              })
            ]);
          });
        },
        6275: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "speed_1_5x_l", xlinkHref: "/icons/sprite.svg#speed_1_5x_l" })
            ]);
          });
        },
        7026: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_1_75x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_m"
              })
            ]);
          });
        },
        8994: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_1_75x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_xs"
              })
            ]);
          });
        },
        3702: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "speed_1_75x_l", xlinkHref: "/icons/sprite.svg#speed_1_75x_l" })
            ]);
          });
        },
        8664: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_1x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_m"
              })
            ]);
          });
        },
        51: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_1x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_xs"
              })
            ]);
          });
        },
        8550: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "speed_1x_l", xlinkHref: "/icons/sprite.svg#speed_1x_l" })
            ]);
          });
        },
        8619: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_2x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_m"
              })
            ]);
          });
        },
        5218: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", {
                key: "speed_2x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_xs"
              })
            ]);
          });
        },
        857: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "speed_2x_l", xlinkHref: "/icons/sprite.svg#speed_2x_l" })
            ]);
          });
        },
        6130: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "syncLyrics_m", xlinkHref: "/icons/sprite.svg#syncLyrics_m" })
            ]);
          });
        },
        3049: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "syncLyrics_xs", xlinkHref: "/icons/sprite.svg#syncLyrics_xs" })
            ]);
          });
        },
        126: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "syncLyrics_xxs", xlinkHref: "/icons/sprite.svg#syncLyrics_xxs" })
            ]);
          });
        },
        6210: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "ticket_m", xlinkHref: "/icons/sprite.svg#ticket_m" })
            ]);
          });
        },
        5596: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "ticket_selected_m", xlinkHref: "/icons/sprite.svg#ticket_selected_m" })
            ]);
          });
        },
        380: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "trailer_xs", xlinkHref: "/icons/sprite.svg#trailer_xs" })
            ]);
          });
        },
        3112: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "trailer_xxs", xlinkHref: "/icons/sprite.svg#trailer_xxs" })
            ]);
          });
        },
        1045: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "unavailable_xl", xlinkHref: "/icons/sprite.svg#unavailable_xl" })
            ]);
          });
        },
        2834: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "unavailable_xs", xlinkHref: "/icons/sprite.svg#unavailable_xs" })
            ]);
          });
        },
        8819: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "unpin_xxs", xlinkHref: "/icons/sprite.svg#unpin_xxs" })
            ]);
          });
        },
        8772: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "upload_xxs", xlinkHref: "/icons/sprite.svg#upload_xxs" })
            ]);
          });
        },
        3522: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "users_xxxs", xlinkHref: "/icons/sprite.svg#users_xxxs" })
            ]);
          });
        },
        5695: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "vibe_xxs", xlinkHref: "/icons/sprite.svg#vibe_xxs" })
            ]);
          });
        },
        6174: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "volumeOff_xs", xlinkHref: "/icons/sprite.svg#volumeOff_xs" })
            ]);
          });
        },
        540: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "volume_xs", xlinkHref: "/icons/sprite.svg#volume_xs" })
            ]);
          });
        },
        6206: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "windows", xlinkHref: "/icons/sprite.svg#windows" })
            ]);
          });
        },
        7185: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "windows_xs", xlinkHref: "/icons/sprite.svg#windows_xs" })
            ]);
          });
        },
        9481: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "yandexBooksEn", xlinkHref: "/icons/sprite.svg#yandexBooksEn" })
            ]);
          });
        },
        7364: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "yandexBooksRu", xlinkHref: "/icons/sprite.svg#yandexBooksRu" })
            ]);
          });
        },
        8577: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "yandexPayEn", xlinkHref: "/icons/sprite.svg#yandexPayEn" })
            ]);
          });
        },
        5760: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "yandexPayRu", xlinkHref: "/icons/sprite.svg#yandexPayRu" })
            ]);
          });
        },
        5667: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "yandexPlusEn", xlinkHref: "/icons/sprite.svg#yandexPlusEn" })
            ]);
          });
        },
        2639: (e2, t2, s2) => {
          var r2 = s2(810);
          e2.exports = r2.forwardRef(function(e3, t3) {
            return r2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              r2.createElement("use", { key: "yandexPlusRu", xlinkHref: "/icons/sprite.svg#yandexPlusRu" })
            ]);
          });
        },
        5189: function(e2, t2, s2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = t2.IconComponent = void 0;
          let a2 = s2(4377), n2 = s2(810), i2 = s2(5881), l2 = s2(5151), o2 = r2(s2(2964));
          t2.IconComponent = (e3) => {
            let { "aria-label": t3, className: s3, focusable: r3 = false, variant: n3, size: c2, forwardRef: x2, ...d2 } = e3, u2 = c2 ? "".concat(n3, "_").concat(c2) : n3, f2 = l2.iconsCollection[u2];
            return f2 ? (0, a2.jsx)(f2, {
              className: (0, i2.clsx)(o2.default.root, s3, o2.default["root_size_".concat(c2)]),
              focusable: r3,
              "aria-label": t3,
              ...d2,
              "aria-hidden": !t3,
              ref: x2
            }) : null;
          }, t2.Icon = (0, n2.forwardRef)((e3, s3) => (0, a2.jsx)(t2.IconComponent, { forwardRef: s3, ...e3 }));
        },
        5151: function(e2, t2, s2) {
          var r2 = this && this.__importDefault || function(e10) {
            return e10 && e10.__esModule ? e10 : { default: e10 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.iconsCollection = t2.iconsCollectionBySize = void 0;
          let a2 = r2(s2(4656)), n2 = r2(s2(8170)), i2 = r2(s2(5565)), l2 = r2(s2(8127)), o2 = r2(s2(8993)), c2 = r2(s2(2933)), x2 = r2(s2(1334)), d2 = r2(s2(1426)), u2 = r2(s2(5378)), f2 = r2(s2(6579)), _2 = r2(s2(3935)), m2 = r2(s2(3522)), p2 = r2(s2(7319)), g2 = r2(s2(8442)), v2 = r2(s2(2586)), b2 = r2(s2(5822)), k2 = r2(s2(5272)), y2 = r2(s2(4860)), E2 = r2(s2(8711)), h2 = r2(s2(8109)), j2 = r2(s2(4904)), w2 = r2(s2(5971)), O2 = r2(s2(3331)), R2 = r2(s2(9783)), S2 = r2(s2(8184)), C2 = r2(s2(4926)), A2 = r2(s2(3176)), N2 = r2(s2(4789)), L2 = r2(s2(8151)), H2 = r2(s2(8690)), P2 = r2(s2(1524)), T2 = r2(s2(2361)), I2 = r2(s2(3972)), M2 = r2(s2(9330)), D2 = r2(s2(7346)), B2 = r2(s2(2604)), U2 = r2(s2(6894)), F2 = r2(s2(6391)), W2 = r2(s2(9369)), z = r2(s2(226)), Y = r2(s2(8130)), K = r2(s2(5270)), V = r2(s2(3560)), q = r2(s2(7513)), Z = r2(s2(9838)), Q = r2(s2(9104)), G = r2(s2(7399)), X = r2(s2(5849)), J = r2(s2(3613)), $ = r2(s2(9372)), ee = r2(s2(3709)), et = r2(s2(3685)), es = r2(s2(3302)), er = r2(s2(811)), ea = r2(s2(6122)), en = r2(s2(5386)), ei = r2(s2(3201)), el = r2(s2(9434)), eo = r2(s2(2026)), ec = r2(s2(8112)), ex = r2(s2(8044)), ed = r2(s2(2754)), eu = r2(s2(5251)), ef = r2(s2(9370)), e_ = r2(s2(5632)), em = r2(s2(1001)), ep = r2(s2(893)), eg = r2(s2(6331)), ev = r2(s2(9876)), eb = r2(s2(1758)), ek = r2(s2(7196)), ey = r2(s2(7951)), eE = r2(s2(126)), eh = r2(s2(3112)), ej = r2(s2(8819)), ew = r2(s2(8772)), eO = r2(s2(5695)), eR = r2(s2(7171)), eS = r2(s2(9030)), eC = r2(s2(9422)), eA = r2(s2(1491)), eN = r2(s2(2337)), eL = r2(s2(9202)), eH = r2(s2(130)), eP = r2(s2(7923)), eT = r2(s2(3654)), eI = r2(s2(6507)), eM = r2(s2(3193)), eD = r2(s2(30)), eB = r2(s2(7802)), eU = r2(s2(3738)), eF = r2(s2(2340)), eW = r2(s2(2125)), ez = r2(s2(4014)), eY = r2(s2(896)), eK = r2(s2(1829)), eV = r2(s2(1893)), eq = r2(s2(1563)), eZ = r2(s2(1578)), eQ = r2(s2(9348)), eG = r2(s2(965)), eX = r2(s2(3877)), eJ = r2(s2(9968)), e$ = r2(s2(3778)), e0 = r2(s2(1084)), e1 = r2(s2(4254)), e8 = r2(s2(792)), e6 = r2(s2(8131)), e4 = r2(s2(1125)), e3 = r2(s2(9288)), e22 = r2(s2(976)), e5 = r2(s2(1874)), e9 = r2(s2(9863)), e7 = r2(s2(1945)), te = r2(s2(1580)), tt = r2(s2(4091)), ts = r2(s2(8090)), tr = r2(s2(895)), ta = r2(s2(5910)), tn = r2(s2(4892)), ti = r2(s2(3366)), tl = r2(s2(5034)), to = r2(s2(5792)), tc = r2(s2(9545)), tx = r2(s2(3362)), td = r2(s2(1079)), tu = r2(s2(8994)), tf = r2(s2(51)), t_ = r2(s2(5218)), tm = r2(s2(3049)), tp = r2(s2(380)), tg = r2(s2(2834)), tv = r2(s2(540)), tb = r2(s2(6174)), tk = r2(s2(7185)), ty = r2(s2(9351)), tE = r2(s2(2092)), th = r2(s2(1162)), tj = r2(s2(6837)), tw = r2(s2(2024)), tO = r2(s2(776)), tR = r2(s2(5720)), tS = r2(s2(2774)), tC = r2(s2(4997)), tA = r2(s2(3146)), tN = r2(s2(2084)), tL = r2(s2(3751)), tH = r2(s2(3076)), tP = r2(s2(2495)), tT = r2(s2(9509)), tI = r2(s2(8987)), tM = r2(s2(190)), tD = r2(s2(843)), tB = r2(s2(5122)), tU = r2(s2(7405)), tF = r2(s2(820)), tW = r2(s2(5443)), tz = r2(s2(8782)), tY = r2(s2(7252)), tK = r2(s2(3013)), tV = r2(s2(5346)), tq = r2(s2(3792)), tZ = r2(s2(1351)), tQ = r2(s2(8303)), tG = r2(s2(4777)), tX = r2(s2(735)), tJ = r2(s2(2176)), t$ = r2(s2(8235)), t0 = r2(s2(8915)), t1 = r2(s2(2037)), t8 = r2(s2(5197)), t6 = r2(s2(7026)), t4 = r2(s2(8664)), t3 = r2(s2(8619)), t22 = r2(s2(6130)), t5 = r2(s2(6210)), t9 = r2(s2(5596)), t7 = r2(s2(6644)), se = r2(s2(996)), st = r2(s2(7031)), ss = r2(s2(4793)), sr = r2(s2(7076)), sa = r2(s2(8582)), sn = r2(s2(7643)), si = r2(s2(9846)), sl = r2(s2(6275)), so = r2(s2(3702)), sc = r2(s2(8550)), sx = r2(s2(857)), sd = r2(s2(6304)), su = r2(s2(9040)), sf = r2(s2(4298)), s_ = r2(s2(5132)), sm = r2(s2(8868)), sp = r2(s2(8779)), sg = r2(s2(8503)), sv = r2(s2(1045)), sb = r2(s2(7341)), sk = r2(s2(9505)), sy = r2(s2(4483)), sE = r2(s2(8499)), sh = r2(s2(705)), sj = r2(s2(7402)), sw = r2(s2(1427)), sO = r2(s2(7934)), sR = r2(s2(2435)), sS = r2(s2(3918)), sC = r2(s2(2571)), sA = r2(s2(2161)), sN = r2(s2(5304)), sL = r2(s2(2646)), sH = r2(s2(7500)), sP = r2(s2(6104)), sT = r2(s2(2502)), sI = r2(s2(1754)), sM = r2(s2(6615)), sD = r2(s2(7942)), sB = r2(s2(1498)), sU = r2(s2(8861)), sF = r2(s2(6809)), sW = r2(s2(5266)), sz = r2(s2(1179)), sY = r2(s2(6206)), sK = r2(s2(9481)), sV = r2(s2(7364)), sq = r2(s2(8577)), sZ = r2(s2(5760)), sQ = r2(s2(5667)), sG = r2(s2(2639));
          t2.iconsCollectionBySize = {
            xxxs: [
              "adult",
              "arrowRight",
              "check",
              "close",
              "donation",
              "exclamation",
              "explicit",
              "listen",
              "play",
              "reset",
              "ruble",
              "users"
            ],
            xxs: [
              "add",
              "addToPlaylist",
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "artist",
              "bucket",
              "chain",
              "chartDown",
              "chartNew",
              "chartSame",
              "chartUp",
              "check",
              "clip",
              "close",
              "code",
              "crown",
              "dislike",
              "disliked",
              "download",
              "downloaded",
              "dragDots",
              "edit",
              "exclamation",
              "explicit",
              "eye_crossed",
              "filter",
              "info",
              "lightning",
              "like",
              "likeVariant",
              "liked",
              "likedVariant",
              "link",
              "lock",
              "lyrics",
              "macos",
              "menuArrow",
              "more",
              "next",
              "pause",
              "pencil",
              "pin",
              "pin_filled",
              "play",
              "playLast",
              "playNext",
              "podcasts",
              "previous",
              "repeat",
              "repeat_one",
              "reset",
              "rewindBackwards",
              "rewindForward",
              "ruble",
              "settings",
              "share",
              "shuffle",
              "syncLyrics",
              "trailer",
              "unpin",
              "upload",
              "vibe"
            ],
            xs: [
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "cast",
              "chain",
              "close",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "filter",
              "fullscreen",
              "like",
              "liked",
              "liteVersion",
              "lock",
              "more",
              "navigationCollection",
              "navigationConcerts",
              "navigationForYouAndTrends",
              "navigationKids",
              "navigationMyVibe",
              "navigationNonMusic",
              "navigationPlus",
              "navigationSearch",
              "next",
              "note",
              "pause",
              "pause_filled",
              "picture",
              "pin",
              "pin_filled",
              "play",
              "playQueue",
              "play_filled",
              "playlist",
              "previous",
              "repeat",
              "repeat_one",
              "rewindBackwards",
              "rewindForward",
              "search",
              "settings",
              "shuffle",
              "site",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "trailer",
              "unavailable",
              "volume",
              "volumeOff",
              "windows"
            ],
            s: [
              "adult",
              "album",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "likedVariant",
              "note",
              "pauseVibe",
              "picture",
              "playVibe",
              "playlist"
            ],
            m: [
              "collections",
              "collections_selected",
              "history",
              "home",
              "home_selected",
              "kids",
              "kids_selected",
              "like",
              "liked",
              "lock",
              "more",
              "non_music",
              "non_music_selected",
              "pause",
              "pause_filled",
              "play",
              "playQueue",
              "play_filled",
              "plusOutlined",
              "ruble",
              "search",
              "search_selected",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "ticket",
              "ticket_selected"
            ],
            l: [
              "add",
              "album",
              "download",
              "like",
              "pause_filled",
              "play_filled",
              "search",
              "speed_1_25x",
              "speed_1_5x",
              "speed_1_75x",
              "speed_1x",
              "speed_2x"
            ],
            xl: ["album", "clip", "note", "pause_filled", "picture", "play_filled", "playlist", "unavailable"],
            xxl: ["attention", "check", "next", "offline", "pause_filled", "play_filled", "previous", "search"],
            xxxl: ["attention"],
            "": [
              "bandlink",
              "booksLogo",
              "googlePlay",
              "huaweiAppGallery",
              "kinopoiskEn",
              "kinopoiskRu",
              "macos",
              "musicLogo",
              "musicLogoCenterEn",
              "musicLogoCenterRu",
              "musicLogoLeftEn",
              "musicLogoLeftRu",
              "plus",
              "plusBadge",
              "plusColor",
              "plusOutlined",
              "windows",
              "yandexBooksEn",
              "yandexBooksRu",
              "yandexPayEn",
              "yandexPayRu",
              "yandexPlusEn",
              "yandexPlusRu"
            ]
          }, t2.iconsCollection = {
            adult_xxxs: a2.default,
            arrowRight_xxxs: n2.default,
            check_xxxs: i2.default,
            close_xxxs: l2.default,
            donation_xxxs: o2.default,
            exclamation_xxxs: c2.default,
            explicit_xxxs: x2.default,
            listen_xxxs: d2.default,
            play_xxxs: u2.default,
            reset_xxxs: f2.default,
            ruble_xxxs: _2.default,
            users_xxxs: m2.default,
            add_xxs: p2.default,
            addToPlaylist_xxs: g2.default,
            adult_xxs: v2.default,
            album_xxs: b2.default,
            arrowDown_xxs: k2.default,
            arrowLeft_xxs: y2.default,
            arrowRight_xxs: E2.default,
            artist_xxs: h2.default,
            bucket_xxs: j2.default,
            chain_xxs: w2.default,
            chartDown_xxs: O2.default,
            chartNew_xxs: R2.default,
            chartSame_xxs: S2.default,
            chartUp_xxs: C2.default,
            check_xxs: A2.default,
            clip_xxs: N2.default,
            close_xxs: L2.default,
            code_xxs: H2.default,
            crown_xxs: P2.default,
            dislike_xxs: T2.default,
            disliked_xxs: I2.default,
            download_xxs: M2.default,
            downloaded_xxs: D2.default,
            dragDots_xxs: B2.default,
            edit_xxs: U2.default,
            exclamation_xxs: F2.default,
            explicit_xxs: W2.default,
            eye_crossed_xxs: z.default,
            filter_xxs: Y.default,
            info_xxs: K.default,
            lightning_xxs: V.default,
            like_xxs: q.default,
            likeVariant_xxs: Z.default,
            liked_xxs: Q.default,
            likedVariant_xxs: G.default,
            link_xxs: X.default,
            lock_xxs: J.default,
            lyrics_xxs: $.default,
            macos_xxs: ee.default,
            menuArrow_xxs: et.default,
            more_xxs: es.default,
            next_xxs: er.default,
            pause_xxs: ea.default,
            pencil_xxs: en.default,
            pin_xxs: ei.default,
            pin_filled_xxs: el.default,
            play_xxs: eo.default,
            playLast_xxs: ec.default,
            playNext_xxs: ex.default,
            podcasts_xxs: ed.default,
            previous_xxs: eu.default,
            repeat_xxs: ef.default,
            repeat_one_xxs: e_.default,
            reset_xxs: em.default,
            rewindBackwards_xxs: ep.default,
            rewindForward_xxs: eg.default,
            ruble_xxs: ev.default,
            settings_xxs: eb.default,
            share_xxs: ek.default,
            shuffle_xxs: ey.default,
            syncLyrics_xxs: eE.default,
            trailer_xxs: eh.default,
            unpin_xxs: ej.default,
            upload_xxs: ew.default,
            vibe_xxs: eO.default,
            adult_xs: eR.default,
            album_xs: eS.default,
            arrowDown_xs: eC.default,
            arrowLeft_xs: eA.default,
            arrowRight_xs: eN.default,
            cast_xs: eL.default,
            chain_xs: eH.default,
            close_xs: eP.default,
            dislike_xs: eT.default,
            disliked_xs: eI.default,
            exclamation_xs: eM.default,
            explicit_xs: eD.default,
            filter_xs: eB.default,
            fullscreen_xs: eU.default,
            like_xs: eF.default,
            liked_xs: eW.default,
            liteVersion_xs: ez.default,
            lock_xs: eY.default,
            more_xs: eK.default,
            navigationCollection_xs: eV.default,
            navigationConcerts_xs: eq.default,
            navigationForYouAndTrends_xs: eZ.default,
            navigationKids_xs: eQ.default,
            navigationMyVibe_xs: eG.default,
            navigationNonMusic_xs: eX.default,
            navigationPlus_xs: eJ.default,
            navigationSearch_xs: e$.default,
            next_xs: e0.default,
            note_xs: e1.default,
            pause_xs: e8.default,
            pause_filled_xs: e6.default,
            picture_xs: e4.default,
            pin_xs: e3.default,
            pin_filled_xs: e22.default,
            play_xs: e5.default,
            playQueue_xs: e9.default,
            play_filled_xs: e7.default,
            playlist_xs: te.default,
            previous_xs: tt.default,
            repeat_xs: ts.default,
            repeat_one_xs: tr.default,
            rewindBackwards_xs: ta.default,
            rewindForward_xs: tn.default,
            search_xs: ti.default,
            settings_xs: tl.default,
            shuffle_xs: to.default,
            site_xs: tc.default,
            speed_1_25x_centered_xs: tx.default,
            speed_1_5x_centered_xs: td.default,
            speed_1_75x_centered_xs: tu.default,
            speed_1x_centered_xs: tf.default,
            speed_2x_centered_xs: t_.default,
            syncLyrics_xs: tm.default,
            trailer_xs: tp.default,
            unavailable_xs: tg.default,
            volume_xs: tv.default,
            volumeOff_xs: tb.default,
            windows_xs: tk.default,
            adult_s: ty.default,
            album_s: tE.default,
            dislike_s: th.default,
            disliked_s: tj.default,
            exclamation_s: tw.default,
            explicit_s: tO.default,
            likedVariant_s: tR.default,
            note_s: tS.default,
            pauseVibe_s: tC.default,
            picture_s: tA.default,
            playVibe_s: tN.default,
            playlist_s: tL.default,
            collections_m: tH.default,
            collections_selected_m: tP.default,
            history_m: tT.default,
            home_m: tI.default,
            home_selected_m: tM.default,
            kids_m: tD.default,
            kids_selected_m: tB.default,
            like_m: tU.default,
            liked_m: tF.default,
            lock_m: tW.default,
            more_m: tz.default,
            non_music_m: tY.default,
            non_music_selected_m: tK.default,
            pause_m: tV.default,
            pause_filled_m: tq.default,
            play_m: tZ.default,
            playQueue_m: tQ.default,
            play_filled_m: tG.default,
            plusOutlined_m: tX.default,
            ruble_m: tJ.default,
            search_m: t$.default,
            search_selected_m: t0.default,
            speed_1_25x_centered_m: t1.default,
            speed_1_5x_centered_m: t8.default,
            speed_1_75x_centered_m: t6.default,
            speed_1x_centered_m: t4.default,
            speed_2x_centered_m: t3.default,
            syncLyrics_m: t22.default,
            ticket_m: t5.default,
            ticket_selected_m: t9.default,
            add_l: t7.default,
            album_l: se.default,
            download_l: st.default,
            like_l: ss.default,
            pause_filled_l: sr.default,
            play_filled_l: sa.default,
            search_l: sn.default,
            speed_1_25x_l: si.default,
            speed_1_5x_l: sl.default,
            speed_1_75x_l: so.default,
            speed_1x_l: sc.default,
            speed_2x_l: sx.default,
            album_xl: sd.default,
            clip_xl: su.default,
            note_xl: sf.default,
            pause_filled_xl: s_.default,
            picture_xl: sm.default,
            play_filled_xl: sp.default,
            playlist_xl: sg.default,
            unavailable_xl: sv.default,
            attention_xxl: sb.default,
            check_xxl: sk.default,
            next_xxl: sy.default,
            offline_xxl: sE.default,
            pause_filled_xxl: sh.default,
            play_filled_xxl: sj.default,
            previous_xxl: sw.default,
            search_xxl: sO.default,
            attention_xxxl: sR.default,
            bandlink: sS.default,
            booksLogo: sC.default,
            googlePlay: sA.default,
            huaweiAppGallery: sN.default,
            kinopoiskEn: sL.default,
            kinopoiskRu: sH.default,
            macos: sP.default,
            musicLogo: sT.default,
            musicLogoCenterEn: sI.default,
            musicLogoCenterRu: sM.default,
            musicLogoLeftEn: sD.default,
            musicLogoLeftRu: sB.default,
            plus: sU.default,
            plusBadge: sF.default,
            plusColor: sW.default,
            plusOutlined: sz.default,
            windows: sY.default,
            yandexBooksEn: sK.default,
            yandexBooksRu: sV.default,
            yandexPayEn: sq.default,
            yandexPayRu: sZ.default,
            yandexPlusEn: sQ.default,
            yandexPlusRu: sG.default
          };
        },
        7066: (e2, t2, s2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = void 0;
          var r2 = s2(5189);
          Object.defineProperty(t2, "Icon", {
            enumerable: true,
            get: function() {
              return r2.Icon;
            }
          });
        },
        1093: function(e2, t2, s2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PlusBadge = void 0;
          let a2 = s2(4377), n2 = s2(5881), i2 = s2(2582), l2 = s2(7066), o2 = r2(s2(1684));
          t2.PlusBadge = (e3) => {
            let { className: t3, children: s3 } = e3;
            return (0, a2.jsxs)("div", {
              className: (0, n2.clsx)(o2.default.root, t3),
              children: [
                (0, a2.jsx)(l2.Icon, { variant: "plus", className: o2.default.icon }),
                (0, a2.jsx)(i2.Caption, {
                  variant: "div",
                  type: "controls",
                  weight: "medium",
                  size: "m",
                  className: o2.default.text,
                  children: s3
                })
              ]
            });
          };
        },
        7743: function(e2, t2, s2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Caption = t2.CaptionComponent = void 0;
          let a2 = s2(4377), n2 = s2(5881), i2 = s2(810), l2 = s2(4721), o2 = r2(s2(3641));
          t2.CaptionComponent = (e3) => {
            let {
              forwardRef: t3,
              variant: s3,
              type: r3 = "text",
              size: i3 = "s",
              className: c2,
              children: x2,
              weight: d2 = "medium",
              ...u2
            } = e3;
            return (0, a2.jsx)(l2.Typography, {
              variant: s3,
              ref: t3,
              className: (0, n2.clsx)(
                o2.default.root,
                o2.default["root_".concat(r3, "_").concat(i3)],
                o2.default["root_weight_".concat(d2)],
                c2
              ),
              ...u2,
              children: x2
            });
          }, t2.Caption = (0, i2.forwardRef)((e3, s3) => (0, a2.jsx)(t2.CaptionComponent, { forwardRef: s3, ...e3 }));
        },
        404: function(e2, t2, s2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.HeadingComponent = void 0;
          let a2 = s2(4377), n2 = s2(5881), i2 = s2(810), l2 = s2(4721), o2 = r2(s2(5153));
          t2.HeadingComponent = (e3) => {
            let { forwardRef: t3, variant: s3, weight: r3 = "bold", size: i3 = "s", className: c2, children: x2, ...d2 } = e3;
            return (0, a2.jsx)(l2.Typography, {
              variant: s3,
              ref: t3,
              className: (0, n2.clsx)(
                o2.default.root,
                o2.default["root_size_".concat(i3)],
                o2.default["root_weight_".concat(r3)],
                c2
              ),
              ...d2,
              children: x2
            });
          }, t2.Heading = (0, i2.forwardRef)((e3, s3) => (0, a2.jsx)(t2.HeadingComponent, { forwardRef: s3, ...e3 }));
        },
        4721: function(e2, t2, s2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Typography = t2.TypographyComponent = void 0;
          let a2 = s2(4377), n2 = s2(5881), i2 = s2(810), l2 = r2(s2(5818));
          function o2(e3) {
            let { forwardRef: t3, style: s3, className: r3, children: i3, variant: o3, lineClamp: c2, ...x2 } = e3, d2 = c2 && "string" == typeof i3 ? i3 : void 0;
            return (0, a2.jsx)(o3, {
              style: { ...s3, WebkitLineClamp: c2 },
              ref: t3,
              title: d2,
              className: (0, n2.clsx)(
                l2.default.root,
                {
                  [l2.default.root_clamp]: c2 && c2 > 0,
                  [l2.default.root_clamp_oneline]: c2 && 1 === c2,
                  [l2.default.root_clamp_multiline]: c2 && c2 > 1
                },
                r3
              ),
              ...x2,
              children: i3
            });
          }
          t2.TypographyComponent = o2, t2.Typography = (0, i2.forwardRef)((e3, t3) => (0, a2.jsx)(o2, { forwardRef: t3, ...e3 }));
        },
        2582: (e2, t2, s2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.Caption = void 0;
          var r2 = s2(7743);
          Object.defineProperty(t2, "Caption", {
            enumerable: true,
            get: function() {
              return r2.Caption;
            }
          });
          var a2 = s2(404);
          Object.defineProperty(t2, "Heading", {
            enumerable: true,
            get: function() {
              return a2.Heading;
            }
          });
        },
        810: (e2) => {
          e2.exports = E;
        }
      }, S = {};
      function C(e2) {
        var t2 = S[e2];
        if (void 0 !== t2) return t2.exports;
        var s2 = S[e2] = { exports: {} };
        return R[e2].call(s2.exports, s2, s2.exports, C), s2.exports;
      }
      C.d = (e2, t2) => {
        for (var s2 in t2) C.o(t2, s2) && !C.o(e2, s2) && Object.defineProperty(e2, s2, { enumerable: true, get: t2[s2] });
      }, C.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), C.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var A = {};
      (() => {
        Object.defineProperty(A, "X", { value: true }), A.R = void 0;
        var e2 = C(1093);
        Object.defineProperty(A, "R", {
          enumerable: true,
          get: function() {
            return e2.PlusBadge;
          }
        });
      })();
      var N = A.R;
      A.X;
      var L = s(97800), H = s(80585), P = (function(e2) {
        return e2.SETTINGS = "settings", e2.LOGOUT = "logout", e2.ACCOUNT_ACTION = "account-action", e2;
      })({}), T = s(5956), I = s(61958), M = s(69850), D = s.n(M);
      let B = (0, k.PA)(() => {
        let { user: e2 } = (0, l.Pjs)(), t2 = (0, l.ZpR)(l.Zyd.settings.href);
        return (0, u.jsx)(I.W1, {
          placement: "top",
          offsetOptions: 10,
          variant: "text",
          withRipple: false,
          className: D().button,
          label: (0, u.jsx)(v, { className: D().button, hasPlus: e2.hasPlus }),
          children: (0, u.jsx)(I.Dr, {
            icon: (0, u.jsx)(T.Icon, { variant: "settings", size: "xxs" }),
            onClick: t2,
            children: (0, u.jsx)(h.A, { id: "page.settings" })
          })
        });
      });
      var U = s(50638), F = s.n(U);
      let W = (0, k.PA)((e2) => {
        var t2;
        let {
          className: s2,
          variant: r2 = "desktop",
          withMeta: a2,
          metaClassName: n2,
          usernameClassName: i2,
          userIdClassName: o2
        } = e2, { user: c2, location: x2, experiments: d2, settings: _2, slam: m2 } = (0, l.Pjs)(), { theme: p2, setTheme: g2 } = (0, l.DPo)(), v2 = (0, l.NFA)(), k2 = v2.get(l.vgk), E2 = v2.get(l.ooW), R2 = v2.get(l.twC), { getThemeFromStorage: S2, setThemeToStorage: C2 } = (0, l.QDo)(E2), [A2, T2] = (0, y.useState)(() => {
          var e3;
          return null != (e3 = S2()) ? e3 : l.W3W;
        }), {
          oldWebHost: I2,
          passportCredentials: { origin: M2 }
        } = R2, D2 = (0, l._lF)(I2), U2 = (0, y.useRef)(null), [W2, z] = (0, y.useState)(0), Y = (0, l.ZpR)(l.Zyd.settings.href), { language: K, setLanguage: V, availableLanguages: q } = (0, l.h6b)(), Z = d2.checkExperiment(l.zal.WebForceNext, "oldnew_button"), Q = d2.checkExperiment(l.zal.WebForceNext, "force_oldnew_button"), G = d2.checkExperiment(l.zal.WebPreferredDesign, "new") || d2.checkExperiment(l.zal.WebPreferredDesign, "oldnew") || Z || Q, X = (0, j.stringifyJSONSafely)({ entrypoint: "web_desktop" }), J = (0, y.useMemo)(() => {
          switch (_2.platform) {
            case l.ODD.WINDOWS:
              return "windows_music";
            case l.ODD.MACOS:
              return "mac_music";
            case l.ODD.LINUX:
              return "linux_music";
            default:
              return "";
          }
        }, [_2.platform]), $ = (0, O.c)((e3) => {
          T2(e3), e3 === l.W3W ? g2((0, l.VDQ)()) : g2(e3), C2(e3);
        }), ee = (0, y.useCallback)(
          (e3) => {
            V(e3);
          },
          [V]
        ), et = (0, y.useCallback)(() => {
        }, [v2, true, Q, Z, k2, D2, null == (t2 = _2.browserInfo) ? void 0 : t2.version]), es = (0, y.useCallback)(
          (e3, t3, s3) => {
            e3 === P.SETTINGS && (null == s3 || s3.onClose(), Y()), (e3 === P.LOGOUT || e3 === P.ACCOUNT_ACTION) && E2.remove(l.cYZ.YmUid);
          },
          [Y, E2]
        ), er = (0, y.useCallback)(() => {
          var e3;
          z(
            document.documentElement.clientHeight - ((null == (e3 = U2.current) ? void 0 : e3.getBoundingClientRect().top) || 0)
          );
        }, [z]), ea = (0, y.useMemo)(() => ({ "--user-top-distance": "".concat(W2, "px") }), [W2]), en = (0, y.useMemo)(() => {
          if (m2.networkStatus.isOffline || m2.isOfflineModeEnabled) return (0, u.jsx)(B, {});
          let e3 = void 0 !== c2.puid ? String(c2.puid) : "";
          return (0, u.jsx)(b.User, {
            className: (0, f.$)(F().userId, o2),
            platform: "desktop" === r2 ? "desktop" : "touch",
            userData: { plus: c2.hasPlus, avatarId: c2.account.data.avatarId },
            onLocaleChange: ee,
            project: "music",
            queryParams: {
              uid: e3,
              "music.locales": q.join(),
              l10n: K,
              "music.showSettings": c2.isAuthorized ? "1" : "0",
              "music.chatContext": X,
              "music.chatUtmSource": J,
              "music.showBackToOldDesign": "0",
              target: "_blank",
              origin: M2
            },
            env: "prod",
            avatarSize: "desktop" === r2 ? 34 : 26,
            dialogClassName: (0, f.$)(F().dialog, F()["dialog_".concat(r2)]),
            retpath: x2.href,
            onMenuItemClick: es,
            rpcHandlers: { setOldDesign: et },
            tld: x2.tld,
            preload: true,
            onOpen: er,
            theme: A2,
            colorScheme: null != p2 ? p2 : void 0,
            onThemeChange: $
          });
        }, [
          q,
          X,
          J,
          er,
          ee,
          et,
          $,
          true,
          K,
          x2.href,
          x2.tld,
          es,
          M2,
          m2.isOfflineModeEnabled,
          m2.networkStatus.isOffline,
          p2,
          c2.account.data.avatarId,
          c2.hasPlus,
          c2.isAuthorized,
          c2.puid,
          o2,
          r2,
          G,
          A2
        ]);
        return (0, u.jsxs)("div", {
          className: (0, f.$)(F().root, s2),
          ref: U2,
          style: ea,
          ...(0, w.Am)(w.OA.user.USER_PROFILE),
          children: [
            en,
            a2 && (0, u.jsxs)("div", {
              className: (0, f.$)(F().meta, n2),
              children: [
                (0, u.jsx)(L.Caption, {
                  variant: "div",
                  type: "controls",
                  size: "m",
                  weight: "medium",
                  className: (0, f.$)(F().userName, i2),
                  lineClamp: 1,
                  children: c2.account.data.publicName || c2.account.data.login
                }),
                c2.hasPlus && (0, u.jsx)(H.N_, {
                  href: "https://plus.yandex.".concat(x2.tld, "/"),
                  target: "_blank",
                  className: F().plusLink,
                  children: (0, u.jsx)(N, { children: (0, u.jsx)(h.A, { id: "sidebar.plus-badge" }) })
                })
              ]
            })
          ]
        });
      });
    },
    50286: (e) => {
      e.exports = {
        root: "MainCardMobile_root__AXTwk",
        image: "MainCardMobile_image__DZHrE",
        text: "MainCardMobile_text__rli4d"
      };
    },
    50638: (e) => {
      e.exports = {
        root: "UserProfile_root__vFuOj",
        userId: "UserProfile_userId__Jb6Ix",
        dialog: "UserProfile_dialog__kQ8sz",
        dialog_desktop: "UserProfile_dialog_desktop__0p006",
        meta: "UserProfile_meta___okny",
        plusLink: "UserProfile_plusLink__NhVsU",
        userName: "UserProfile_userName__PTRuJ"
      };
    },
    55330: (e) => {
      e.exports = { topSection: "PaywallOtherMobile_topSection__Pscnw" };
    },
    55994: (e) => {
      e.exports = { root: "PaywallBY_root__XMtUB" };
    },
    56206: (e) => {
      e.exports = {
        content_ru: "PlusSectionMobile_content_ru__OvJV0",
        content_by: "PlusSectionMobile_content_by__d5iGm",
        card: "PlusSectionMobile_card__QbwGe",
        logo_ru: "PlusSectionMobile_logo_ru___FFew",
        logo_en: "PlusSectionMobile_logo_en__u_HSO"
      };
    },
    66183: (e) => {
      e.exports = {
        content_ru: "BooksSectionMobile_content_ru__xiiQh",
        content_by: "BooksSectionMobile_content_by__t_UNK",
        card: "BooksSectionMobile_card__t6bb7",
        logo_ru: "BooksSectionMobile_logo_ru__cnYJJ",
        logo_en: "BooksSectionMobile_logo_en__wcgiD"
      };
    },
    69850: (e) => {
      e.exports = { button: "OfflineUserProfile_button__OJntz" };
    },
    72100: (e) => {
      e.exports = {
        content_ru: "BooksSectionDesktop_content_ru__Yauyu",
        content_by: "BooksSectionDesktop_content_by___eqCQ",
        card: "BooksSectionDesktop_card__blMRo",
        logo_ru: "BooksSectionDesktop_logo_ru__SRY4d",
        logo_en: "BooksSectionDesktop_logo_en__Szpr_"
      };
    },
    84535: (e) => {
      e.exports = {
        root: "TopSectionMobile_root__bl_XJ",
        image: "TopSectionMobile_image__t_hCH",
        content: "TopSectionMobile_content__sqstr",
        title: "TopSectionMobile_title__O_Zx0",
        buySubscriptionBlock: "TopSectionMobile_buySubscriptionBlock__NSVnY",
        moreInfoLink: "TopSectionMobile_moreInfoLink__zjcOO"
      };
    },
    88297: (e) => {
      e.exports = {
        root: "MainSectionDesktop_root__MjgTL",
        headingContainer: "MainSectionDesktop_headingContainer__IaoRT",
        contentContainer: "MainSectionDesktop_contentContainer__L4OlR"
      };
    },
    98922: (e) => {
      e.exports = { root: "MoreInfoLink_root___TgXc", content: "MoreInfoLink_content__Rjqj_" };
    }
  }
]);
