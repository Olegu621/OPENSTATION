(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1872],
  {
    468: (e) => {
      e.exports = { root: "PlaylistShimmersPage_root__RsNRj", header: "PlaylistShimmersPage_header__vm4q3" };
    },
    5203: (e, t, a) => {
      "use strict";
      a.d(t, { PlaylistShimmersPage: () => o });
      var l = a(54486), i = a(32353), s = a(80585), r = a(468), n = a.n(r);
      let o = () => (0, l.jsxs)("div", {
        className: n().root,
        children: [(0, l.jsx)(s.Y9, { className: n().header }), (0, l.jsx)(i.c6, { isActive: true })]
      });
    },
    9464: (e) => {
      e.exports = {
        root: "PlaylistPage_root__ajyaP",
        important: "PlaylistPage_important__1Xpl5",
        wrapper: "PlaylistPage_wrapper__XLjbD",
        averageColorBackground: "PlaylistPage_averageColorBackground__3wEkw",
        content: "PlaylistPage_content__T7zOm",
        brandedPlaylistBannerCreative: "PlaylistPage_brandedPlaylistBannerCreative__fr6ZP"
      };
    },
    13296: (e) => {
      e.exports = {
        root: "PlaylistPageItemEditorialBeforeTitle_root__DcMpV",
        major: "PlaylistPageItemEditorialBeforeTitle_major__lifWe"
      };
    },
    14782: (e, t, a) => {
      "use strict";
      a.d(t, { useSetPlaylistFilters: () => r });
      var l = a(61910), i = a(63585), s = a(74125);
      let r = (e2) => {
        let { sonata: t2 } = e2, { sonataState: a2 } = (0, s.Pjs)();
        (0, l.useEffect)(() => {
          let e3 = null == t2 ? void 0 : t2.state.queueState.currentEntity.onChange((e4) => {
            if (null == e4 ? void 0 : e4.context.data) {
              if ("filter" in e4.context.data) {
                let t3 = null == e4 ? void 0 : e4.context.data.filter;
                a2.setPlaylistFilter(t3);
              }
              (null == e4 ? void 0 : e4.context.data.type) === i.K.Vibe && a2.setPlaylistFilter(void 0);
            }
          });
          return () => {
            null == e3 || e3();
          };
        }, [null == t2 ? void 0 : t2.state.queueState.currentEntity, a2]);
      };
    },
    30520: (e) => {
      e.exports = {
        emptyBlockContainer: "PlaylistPageItem_emptyBlockContainer__K5xRV",
        shimmerItem: "PlaylistPageItem_shimmerItem__s_fFo",
        isDuplicate: "PlaylistPageItem_isDuplicate__Fhcc1"
      };
    },
    30712: (e) => {
      e.exports = {
        header: "PlaylistPageHeader_header__Fgqns",
        header_branded: "PlaylistPageHeader_header_branded__WyJ4k",
        content: "PlaylistPageHeader_content__boBkt",
        emptyPlaylist: "PlaylistPageHeader_emptyPlaylist__oiG4B"
      };
    },
    41390: (e, t, a) => {
      "use strict";
      a.d(t, { PlaylistPage: () => eh });
      var l = a(54486), i = a(50420), s = a(28303), r = a(97396), n = a(61910), o = a(43426), d = a(31500), c = a(35537), u = a(82644), m = a(51376), g = a(33276), p = a(74125), y = a(80585), P = a(80769), v = a(31905), h = a(84458), _ = a(9464), k = a.n(_), f = a(37706), x = a(85598), b = a.n(x);
      let j = (0, s.PA)(
        (0, n.forwardRef)((e2, t2) => {
          var a2;
          let { children: s2, "data-index": r2, ...o2 } = e2, { playlist: d2 } = (0, p.Pjs)(), {
            isDragging: c2,
            listeners: u2,
            setNodeRef: m2,
            transform: g2,
            transition: y2,
            attributes: P2
          } = (0, f.gl)({ id: String(null == (a2 = d2.items[r2]) ? void 0 : a2.key) }), v2 = (0, n.useCallback)(
            (e3) => {
              m2(e3), "function" == typeof t2 && t2(e3);
            },
            [t2, m2]
          ), h2 = { transition: y2, "--translate-y": g2 ? "".concat(Math.round(g2.y), "px") : void 0 };
          return (0, l.jsx)("div", {
            ref: v2,
            "data-index": r2,
            style: h2,
            ...o2,
            className: b().root,
            children: (0, l.jsx)("div", {
              className: (0, i.$)(b().inner, { [b().dragging]: c2 }),
              ...u2,
              ...P2,
              children: s2
            })
          });
        })
      );
      var I = a(95296), T = a(19713), C = a(92803);
      let N = (e2, t2) => {
        var a2;
        let l2 = t2 - 1;
        if (!e2.items.length || l2 < 0 || l2 > e2.items.length) return "";
        let i2 = e2.items[l2];
        return (null == i2 || null == (a2 = i2.data) ? void 0 : a2.title) || "";
      };
      var S = a(13611), A = a(43350), D = a(63585), L = a(30520), E = a.n(L), F = a(21365), B = a(97800), w = a(13296), R = a.n(w);
      let O = (0, s.PA)((e2) => {
        var t2, a2, i2, s2, r2;
        let { item: o2 } = e2, { playlist: d2, experiments: c2 } = (0, p.Pjs)(), { shouldShowMajor: u2, shouldShowGenre: m2, shouldShowDuplicate: g2 } = d2.editorFeature, y2 = c2.checkExperiment(p.zal.WebEditorsFeatures, "on"), P2 = g2 && d2.editorFeature.getNumberGroupTrackDuplicated(o2);
        if (!y2 || !o2 || !m2 && !u2 && !P2) return null;
        let v2 = [], h2 = null == (a2 = o2.data) || null == (t2 = a2.major) ? void 0 : t2.name, _2 = null == (r2 = o2.data) || null == (s2 = r2.albums) || null == (i2 = s2[0]) ? void 0 : i2.genre;
        if (P2 && v2.push("№".concat(P2)), u2 && h2) {
          let e3 = d2.editorFeature.getColorForMajor(h2), t3 = (0, l.jsx)("span", { className: R().major, style: { "--major-color": e3 }, children: h2 });
          v2.push(t3);
        }
        if (m2 && _2 && v2.push(_2), !v2.length) return null;
        let k2 = v2.map((e3, t3, a3) => (0, l.jsxs)(n.Fragment, { children: [e3, t3 < a3.length - 1 && "; "] }, t3));
        return (0, l.jsxs)(B.Caption, {
          className: R().root,
          type: "entity",
          size: "m",
          weight: "medium",
          variant: "span",
          children: ["[", k2, "]  "]
        });
      }), U = (0, s.PA)((e2) => {
        let {
          item: t2,
          track: a2,
          withDNDBlock: i2,
          isDragging: s2,
          draggingClassName: r2,
          from: n2,
          utmLink: d2,
          index: c2,
          className: u2
        } = e2, { playlist: m2, sonataState: g2 } = (0, p.Pjs)(), { formatMessage: y2 } = (0, o.A)(), { removeTrackFromPlaylist: P2, canRemoveTrackFromPlaylist: v2 } = (0, F.sR)();
        return (0, l.jsx)(F.Kd, {
          beforeTitle: (0, l.jsx)(O, { item: t2 }),
          withPodcastName: true,
          withDNDBlock: i2,
          isDragging: s2,
          track: a2,
          handleRemove: v2 ? P2 : void 0,
          draggingClassName: r2,
          playContextParams: {
            contextData: { type: D.K.Playlist, meta: m2.contextMeta, from: n2, utmLink: d2 },
            entitiesData: g2.unloadedEntitiesDataFromModels,
            queueParams: { index: c2 },
            loadContextMeta: true
          },
          removeButtonAriaLabel: y2({ id: "playlist-actions.remove-from-playlist" }),
          className: u2
        });
      }), M = (0, s.PA)((e2) => {
        let {
          item: t2,
          track: a2,
          withDNDBlock: s2,
          isDragging: r2,
          draggingClassName: n2,
          from: d2,
          utmLink: c2,
          index: u2,
          className: m2
        } = e2, { playlist: g2, sonataState: y2 } = (0, p.Pjs)(), { formatMessage: P2 } = (0, o.A)(), { removeTrackFromPlaylist: v2, canRemoveTrackFromPlaylist: h2 } = (0, F.sR)();
        return (0, l.jsx)(F.Kt, {
          beforeTitle: (0, l.jsx)(O, { item: t2 }),
          withDNDBlock: s2,
          isDragging: r2,
          track: a2,
          handleRemove: h2 ? v2 : void 0,
          draggingClassName: n2,
          playContextParams: {
            contextData: {
              type: D.K.Playlist,
              meta: g2.contextMeta,
              from: d2,
              utmLink: c2,
              filter: g2.filters.activeFilter,
              filterName: g2.filters.activeFilterName,
              enableVariousAutoFlow: g2.enableVariousAutoFlow
            },
            entitiesData: y2.unloadedEntitiesDataFromModels,
            queueParams: { index: u2 },
            loadContextMeta: true
          },
          activeFilter: g2.filters.activeFilter,
          activeFilterIndex: g2.filters.analyticsParamsActiveFilterIndex,
          removeButtonAriaLabel: P2({ id: "playlist-actions.remove-from-playlist" }),
          className: (0, i.$)(m2, { [E().isDuplicate]: g2.editorFeature.shouldHighlightDublicatedTrack(t2) })
        });
      }), H = (0, s.PA)((e2) => {
        var t2, a2, s2, r2, n2;
        let o2, { index: d2, className: c2, isDragging: u2, draggingClassName: m2 } = e2, { playlist: g2 } = (0, p.Pjs)(), P2 = (null == (t2 = g2.meta) ? void 0 : t2.uuid) || g2.uuid, { from: v2, utmLink: h2 } = (0, p.fyy)({
          pageId: p._Q$.PLAYLIST,
          blockId: p.UfI.PLAYLIST,
          pageEntityId: P2,
          contextType: D.K.Playlist,
          contextId: P2
        }), _2 = g2.isDragAndDropEnabled, k2 = null == (a2 = g2.items) ? void 0 : a2[d2];
        return o2 = k2 && k2.data && g2.meta ? k2.data.isTrackNonMusic || (null == (s2 = k2.data.mainAlbum) ? void 0 : s2.isNonMusic) ? (0, l.jsx)(U, {
          item: k2,
          withDNDBlock: _2,
          isDragging: u2,
          from: v2,
          index: d2,
          track: k2.data,
          utmLink: h2,
          draggingClassName: m2,
          className: c2
        }) : (0, l.jsx)(M, {
          item: k2,
          from: v2,
          index: d2,
          track: k2.data,
          withDNDBlock: _2,
          isDragging: u2,
          draggingClassName: m2,
          className: (0, i.$)(c2, { [E().isDuplicate]: g2.editorFeature.shouldHighlightDublicatedTrack(k2) })
        }) : (0, l.jsx)(y.DS, { isActive: true, className: E().shimmerItem, variant: p.Xjt.PLAYLIST }), (0, l.jsx)(S.xG.Provider, {
          value: { playlist: g2.meta, trackIndex: d2 },
          children: (0, l.jsx)(p.FoH, {
            blockType: A.LA.Tracks,
            blockId: A.LA.Tracks,
            blockPosX: 1,
            blockPosY: 1,
            objectsCount: g2.items.length,
            mainObjectId: String(null == g2 || null == (r2 = g2.meta) ? void 0 : r2.id),
            mainObjectType: A.ky.Album,
            children: (0, l.jsx)(p.Bki, {
              objectType: A.ky.Track,
              objectId: String(null == k2 || null == (n2 = k2.data) ? void 0 : n2.id),
              objectPosX: 1,
              objectPosY: d2 + 1,
              objectsCount: g2.items.length,
              children: o2
            })
          })
        });
      });
      var Y = a(62882), K = a.n(Y);
      let $ = (0, s.PA)((e2) => {
        let { children: t2, playlist: a2 } = e2, { announcements: i2, screenReaderInstructions: s2 } = ((e3) => {
          let { formatMessage: t3 } = (0, o.A)();
          return {
            screenReaderInstructions: { draggable: t3({ id: "drag-and-drop.playlist-move-instructions" }) },
            announcements: {
              onDragStart(a3) {
                let { active: l2 } = a3;
                return t3(
                  { id: "drag-and-drop.playlist-on-move-start" },
                  { trackName: N(e3, Number(l2.id)), index: l2.id }
                );
              },
              onDragOver(a3) {
                let { active: l2, over: i3 } = a3, s3 = N(e3, Number(l2.id));
                return i3 ? t3({ id: "drag-and-drop.playlist-on-move" }, { trackName: s3, index: i3.id }) : t3({ id: "drag-and-drop.playlist-on-move-fail" }, { trackName: s3 });
              },
              onDragEnd(a3) {
                let { active: l2, over: i3 } = a3, s3 = N(e3, Number(l2.id));
                return i3 ? t3({ id: "drag-and-drop.playlist-on-move-end-with-index" }, { trackName: s3, index: i3.id }) : t3({ id: "drag-and-drop.playlist-on-move-end" }, { trackName: s3 });
              },
              onDragCancel: () => t3({ id: "drag-and-drop.playlist-on-move-cancel" })
            }
          };
        })(a2), r2 = ((e3) => {
          let { notify: t3 } = (0, p.lkh)(), { formatMessage: a3 } = (0, o.A)();
          return (0, n.useCallback)(
            async (i3) => {
              var s3, r3, n2, o2;
              let { from: d3, to: c3 } = i3;
              if (d3 < 0 || c3 < 0 || d3 >= e3.items.length || c3 >= e3.items.length) return;
              let u3 = String(null == (s3 = e3.items[d3]) ? void 0 : s3.id);
              if (!u3) return;
              let m3 = (null == (r3 = e3.items[d3]) ? void 0 : r3.albumId) ? Number(null == (n2 = e3.items[d3]) ? void 0 : n2.albumId) : void 0;
              e3.moveTrack(d3, c3);
              let g3 = await (null == (o2 = e3.meta) ? void 0 : o2.changePlaylist(
                (0, S.Mp)({
                  operation: S.yC.MOVE,
                  startPosition: d3,
                  endPosition: c3,
                  tracks: [{ id: u3, albumId: m3 }]
                })
              ));
              g3 && g3 === S.Y9.OK || (g3 === S.Y9.RELOAD ? e3.refresh() : e3.moveTrack(c3, d3), t3((0, l.jsx)(y.hT, { error: a3({ id: "drag-and-drop.failed-to-move" }) }), {
                containerId: p.uQT.ERROR
              }));
            },
            [a3, t3, e3]
          );
        })(a2), { activeId: d2, handleDragStart: c2, handleDragCancel: u2, sensors: m2 } = (0, p.YcA)(), g2 = (0, n.useCallback)(
          (e3) => {
            let { active: t3, over: l2 } = e3;
            if (!t3.id || !(null == l2 ? void 0 : l2.id)) return;
            let i3 = a2.itemsKeys.indexOf(String(t3.id)), s3 = a2.itemsKeys.indexOf(String(l2.id));
            Number.isInteger(i3) && Number.isInteger(s3) && r2({ from: i3, to: s3 });
          },
          [r2, a2.itemsKeys]
        ), P2 = (0, n.useMemo)(() => a2.itemsKeys.indexOf(String(d2)), [d2, a2.itemsKeys]);
        return a2.isDragAndDropEnabled ? (0, l.jsxs)(I.Mp, {
          sensors: m2,
          collisionDetection: I.fp,
          onDragStart: c2,
          onDragEnd: g2,
          onDragCancel: u2,
          modifiers: [T.FN, T.gj],
          accessibility: { announcements: i2, screenReaderInstructions: s2 },
          children: [
            (0, l.jsx)("div", {
              className: K().root,
              children: (0, l.jsx)(f.gB, { items: a2.itemsKeys, strategy: f._G, children: t2 })
            }),
            (0, C.createPortal)(
              (0, l.jsx)(I.Hd, {
                dropAnimation: { duration: 0 },
                children: d2 ? (0, l.jsx)("div", {
                  className: K().draggableItemWrapper,
                  children: (0, l.jsx)(H, {
                    index: P2,
                    className: K().noHoverItem,
                    isDragging: true,
                    draggingClassName: K().dots
                  })
                }) : null
              }),
              window.document.body
            )
          ]
        }) : t2;
      });
      var W = a(4542), Q = a(83909), V = a(99456), X = a.n(V);
      let G = (0, s.PA)((e2) => {
        var t2, a2, s2;
        let { playlist: r2 } = e2, { formatMessage: n2 } = (0, o.A)();
        return (0, l.jsxs)("div", {
          className: X().root,
          children: [
            (0, l.jsxs)("div", {
              children: [
                r2.hasSimilarEntities && (0, l.jsx)(p.FoH, {
                  blockType: A.LA.SimilarEntities,
                  blockId: A.LA.SimilarEntities,
                  blockPosX: 1,
                  blockPosY: 2,
                  objectsCount: null == (t2 = r2.similarEntities.data) ? void 0 : t2.items.length,
                  mainObjectId: String(null == (a2 = r2.meta) ? void 0 : a2.id),
                  mainObjectType: A.ky.Playlist,
                  children: (0, l.jsx)(W.Qh, {
                    ...r2.similarEntities,
                    meta: { title: n2({ id: "page.similar-entities-block-title" }) },
                    headingVariant: "h2",
                    className: X().carouselContainer,
                    headerClassName: (0, i.$)(X().carouselBlock, X().carouselBlockHeader),
                    containerClassName: X().carouselBlock,
                    shouldSentAnalyticsOnLoaded: true,
                    isLoaded: r2.similarEntities.isLoaded,
                    setHasSentAnalyticsOnLoaded: r2.similarEntities.setHasSentAnalyticsOnLoaded
                  })
                }),
                r2.hasSimilarPlaylists && (0, l.jsx)(p.FoH, {
                  blockId: A.LA.SimilarPlaylists,
                  blockType: A.LA.SimilarPlaylists,
                  blockPosX: 1,
                  blockPosY: 3,
                  blockIdForFrom: p.hf$.PLAYLISTS_SIMILAR_PLAYLIST,
                  objectsCount: r2.similarPlaylists.length,
                  mainObjectId: String(null == (s2 = r2.meta) ? void 0 : s2.id),
                  mainObjectType: A.ky.Playlist,
                  children: (0, l.jsx)(Q.EC, {
                    headingVariant: "h2",
                    isShimmerVisible: r2.isLoading,
                    isShimmerActive: true,
                    className: X().carouselContainer,
                    headerClassName: (0, i.$)(X().carouselBlockHeader, X().carouselBlock),
                    containerClassName: X().carouselBlock,
                    title: n2({ id: "entity-names.similar-playlists" }),
                    playlists: r2.similarPlaylists
                  })
                })
              ]
            }),
            (0, l.jsx)(y.A, { children: (0, l.jsx)(y.wi, { className: X().footer }) })
          ]
        });
      });
      var q = a(32353), z = a(12186), J = a(47713), Z = a(79021);
      let ee = (e2) => {
        let { item: t2, from: a2, tracks: l2 } = e2, i2 = l2.map((e3) => {
          if (e3) return (0, F.$b)(e3);
        }).filter((e3) => e3);
        return {
          contextData: { type: D.K.Various, meta: { id: t2.entityId }, from: a2 },
          queueParams: { entityId: t2.entityId },
          loadContextMeta: true,
          entitiesData: i2
        };
      };
      var et = a(92737), ea = a.n(et);
      let el = (0, s.PA)((e2) => {
        var t2, a2, s2, r2, c2, u2, m2, g2;
        let { autoFocus: P2, className: v2 } = e2, { formatMessage: h2 } = (0, o.A)(), { playlist: _2 } = (0, p.Pjs)(), { search: k2 } = _2, f2 = (0, F.Rg)(), x2 = (0, n.useRef)(0), b2 = (null == (t2 = _2.meta) ? void 0 : t2.isOwnPlaylist) ? p._Q$.OWN_PLAYLISTS : p._Q$.PLAYLIST, { from: j2 } = (0, p.fyy)({ pageId: b2, blockId: p.UfI.FILTERED }), { from: I2 } = (0, p.fyy)({ pageId: b2, blockId: p.UfI.SUGGESTED }), [T2, C2] = (0, n.useState)(false);
        (0, n.useEffect)(
          () => () => {
            window.clearTimeout(x2.current);
          },
          []
        );
        let N2 = (0, n.useMemo)(
          () => (0, z.A)((e3) => {
            let t3 = e3.trim();
            k2.setText(t3), t3 && (null == _2 ? void 0 : _2.meta) && (k2.reset(), k2.getTracks({ uid: _2.meta.uid, kind: _2.meta.kind })), t3 && 0 !== t3.length || (T2 && (C2(false), _2.refreshTracks()), k2.setIdleState());
          }, 100),
          [k2, _2, T2]
        ), A2 = (0, n.useCallback)(
          async (e3) => {
            if (_2.meta) {
              k2.setAdditionTrackAnimation(e3.id);
              let t3 = f2({ track: e3, playlist: _2.meta, withSuccessNotification: false, withPageRefresh: false }), a3 = new Promise((e4) => {
                x2.current = window.setTimeout(e4, 300);
              }), [l2] = await Promise.all([t3, a3]);
              l2 === S.Y9.OK ? (k2.replaceAdditionTrackInProggress(), C2(true)) : k2.resetAdditionTrackAnimation();
            }
          },
          [f2, _2.meta, k2]
        ), L2 = (0, n.useMemo)(() => {
          var e3;
          return k2.isLoading ? (0, l.jsx)(y.DS, { isActive: true, className: ea().shimmerItem, variant: p.Xjt.PLAYLIST }) : null == (e3 = k2.playlistTracks) ? void 0 : e3.map(
            (e4) => e4 ? e4.isTrackNonMusic ? (0, l.jsx)(
              F.Kd,
              {
                withPodcastName: true,
                track: e4,
                playContextParams: ee({ item: e4, from: j2, tracks: k2.playlistTracks }),
                className: (0, i.$)(ea().track, {
                  [ea().appearingTrack]: e4.id === k2.additionTrackInProggress
                })
              },
              e4.id
            ) : (0, l.jsx)(
              F.Kt,
              {
                className: (0, i.$)(ea().track, {
                  [ea().appearingTrack]: e4.id === k2.additionTrackInProggress
                }),
                track: e4,
                playContextParams: ee({ item: e4, from: j2, tracks: k2.playlistTracks })
              },
              e4.id
            ) : null
          );
        }, [k2.isLoading, k2.playlistTracks, k2.additionTrackInProggress, j2]), E2 = (0, n.useMemo)(() => {
          var e3, t3;
          if (null == (e3 = _2.meta) ? void 0 : e3.canUserChange)
            return k2.isLoading ? (0, l.jsx)(y.DS, { isActive: true, className: ea().shimmerItem, variant: p.Xjt.PLAYLIST }) : null == (t3 = k2.suggestedTracks) ? void 0 : t3.map(
              (e4) => e4 ? (0, l.jsx)(
                F.II,
                {
                  track: e4,
                  className: (0, i.$)({ [ea().disappearingTrack]: e4.id === k2.additionTrackInProggress }),
                  playContextParams: ((e5, t4) => ({
                    contextData: { type: D.K.Various, meta: { id: e5.entityId }, from: t4 },
                    queueParams: { index: 0, entityId: e5.entityId },
                    loadContextMeta: true
                  }))(e4, I2),
                  onClick: A2
                },
                e4.id
              ) : null
            );
        }, [
          null == (a2 = _2.meta) ? void 0 : a2.canUserChange,
          k2.isLoading,
          k2.suggestedTracks,
          k2.additionTrackInProggress,
          I2,
          A2
        ]), w2 = (0, n.useMemo)(() => {
          var e3, t3, a3;
          let i2 = !(null == (e3 = k2.suggestedTracks) ? void 0 : e3.length) || !(null == (t3 = _2.meta) ? void 0 : t3.canUserChange);
          return (null == (a3 = k2.playlistTrackIds) ? void 0 : a3.length) || !i2 || k2.isLoading ? null : (0, l.jsx)(Q.pA, { className: ea().emptyBlockContainer, isEmptySearch: true });
        }, [
          null == (s2 = k2.suggestedTracks) ? void 0 : s2.length,
          null == (r2 = k2.playlistTrackIds) ? void 0 : r2.length,
          k2.isLoading,
          null == (c2 = _2.meta) ? void 0 : c2.canUserChange
        ]);
        return (0, l.jsxs)(l.Fragment, {
          children: [
            (0, l.jsx)(Z.D, {
              className: (0, i.$)(ea().root, v2),
              autoFocus: P2,
              initialValue: k2.text,
              correctedValue: null,
              placeholder: h2({ id: "search.track-placeholder" }),
              onChange: N2,
              resetButtonAriaLabel: h2({ id: "interface-actions.reset-search-input" }),
              onResetClick: k2.reset,
              innerInputProps: (0, d.Am)(d.e8.searchPlaylist.SEARCH_PLAYLIST_INPUT),
              resetButtonProps: (0, d.Am)(d.e8.searchPlaylist.SEARCH_PLAYLIST_INPUT_RESET_BUTTON),
              searchIconProps: (0, d.Am)(d.e8.searchPlaylist.SEARCH_PLAYLIST_INPUT_ICON),
              shouldPreventAutoFocusScroll: true
            }),
            k2.text && (0, l.jsxs)("div", {
              className: ea().content,
              children: [
                w2,
                L2,
                Number(null == (u2 = k2.suggestedTracks) ? void 0 : u2.length) > 0 && (null == (m2 = _2.meta) ? void 0 : m2.canUserChange) && (0, l.jsx)(
                  B.Heading,
                  {
                    variant: "h3",
                    className: (0, i.$)(ea().catalog, {
                      [ea().catalog_withTracks]: null == (g2 = k2.playlistTrackIds) ? void 0 : g2.length
                    }),
                    children: (0, l.jsx)(J.A, { id: "search.search-catalog" })
                  },
                  "search.search-catalog-caption"
                ),
                E2
              ]
            })
          ]
        });
      });
      var ei = a(8817), es = a(51321), er = a(6197), en = a(66810), eo = a.n(en);
      let ed = (0, s.PA)((e2) => {
        var t2, a2;
        let { playlist: i2 } = e2, { setPlaylistStickyFiltersRef: s2, setPlaylistStaticFiltersRef: r2 } = (0, p.gKY)(), o2 = (0, es.useTabsState)(i2.filters.activeFilterIndex), d2 = (0, n.useRef)(null), c2 = { objectId: i2.uuid }, u2 = (0, p.s4Q)(i2.analyticsParams), m2 = (0, p.QUC)(c2);
        (0, n.useEffect)(() => {
          var e3;
          i2.filters.shouldSendEventOnTabOpened && (null == (e3 = i2.filters.items) ? void 0 : e3.length) && (u2(), i2.filters.setShouldSendEventOnTabOpened(false));
        }, [null == (t2 = i2.filters.items) ? void 0 : t2.length, i2.filters, u2]), (0, n.useEffect)(() => {
          var e3, t3;
          i2.filters.shouldSendEventOnTabLoaded && (null == (e3 = i2.filters.items) ? void 0 : e3.length) && (null == (t3 = i2.filters.items) || t3.forEach((e4, t4) => {
            m2({ tabId: e4.id, tabPos: t4 });
          }), i2.filters.setShouldSendEventOnTabLoaded(false));
        }, [
          m2,
          i2.filters.items,
          i2.filters.shouldSendEventOnTabLoaded,
          i2.filters.setShouldSendEventOnTabLoaded,
          i2.filters
        ]), (0, n.useEffect)(() => {
          i2.isResolved && i2.filters.getFilters();
        }, [i2, i2.loadingState]);
        let y2 = (0, ei.c)((e3) => {
          var t3;
          if (!o2.onTabChange || e3 === o2.value) return;
          setTimeout(() => {
            var t4, a4, l2;
            null == (l2 = d2.current) || null == (a4 = l2.children[e3]) || null == (t4 = a4.focus) || t4.call(a4);
          }), o2.onTabChange(e3);
          let a3 = null == (t3 = i2.filters.items) ? void 0 : t3[e3];
          a3 && i2.filters.handleFilterClick(a3);
        }), P2 = null == (a2 = i2.filters.items) ? void 0 : a2.map((e3) => ({ id: e3.id, name: e3.name }));
        return (0, l.jsx)(g.jr, {
          child: (0, l.jsx)(er.A, {
            className: eo().stickyFilters,
            tabsState: o2,
            handleFilterClick: y2,
            ref: s2,
            isSticky: true,
            items: P2
          }),
          children: (0, l.jsx)(er.A, {
            className: eo().staticFilters,
            tabsState: o2,
            handleFilterClick: y2,
            ref: r2,
            carouselClassName: eo().staticFiltersCarousel,
            items: P2
          })
        });
      });
      var ec = a(98898), eu = a.n(ec);
      let em = (0, s.PA)(() => {
        var e2;
        let {
          experiments: t2,
          advertBanners: {
            banners: { brandedPlaylistBanner: a2 }
          }
        } = (0, p.Pjs)(), s2 = (0, m.Qj)(), r2 = a2.isVisible && s2.isEnabled;
        return t2.checkExperiment(p.zal.WebNextDisableAds, "on") ? null : (0, l.jsx)("div", {
          className: (0, i.$)({ [eu().brandedPlaylistBannerWrapper]: r2 }),
          style: null == (e2 = s2.data) ? void 0 : e2.style,
          children: (0, l.jsx)(m.Zr, { creativeClassName: eu().creative })
        });
      }), eg = (0, s.PA)((e2) => {
        var t2;
        let { className: a2 } = e2, { ugcUploadCenter: i2, playlist: s2 } = (0, p.Pjs)();
        if (!(null == (t2 = s2.meta) ? void 0 : t2.kind) || !s2.search.isNeededToLoad) return;
        let r2 = i2.getUploadingTracksByPlaylistKind(s2.meta.kind);
        if (0 !== r2.length)
          return (0, l.jsx)("div", { className: a2, children: r2.map((e3, t3) => (0, l.jsx)(F.yY, { track: e3 }, t3)) });
      });
      var ep = a(30712), ey = a.n(ep);
      let eP = (0, s.PA)((e2) => {
        let { playlistHeaderRef: t2 } = e2, { playlist: a2 } = (0, p.Pjs)(), s2 = (0, m.Qj)();
        return ((0, n.useEffect)(() => {
          a2.search.isFocused && a2.search.removeFocus();
        }, [a2.search.isFocused, a2.search]), a2.isLoading || !a2.meta || a2.isRejected) ? (0, l.jsx)(q.c6, { className: ey().header }) : (0, l.jsxs)(l.Fragment, {
          children: [
            (0, l.jsx)(em, {}),
            (0, l.jsx)(q.Jq, {
              className: (0, i.$)(ey().header, { [ey().header_branded]: s2.isEnabled }),
              playlist: a2.meta,
              isDisabled: a2.isDisabled,
              ref: t2
            }),
            (0, l.jsx)(el, { autoFocus: !!(!a2.items.length || a2.search.isFocused) }),
            a2.isFiltersAvailable && (0, l.jsx)(ed, { playlist: a2 }),
            (0, l.jsx)(eg, { className: ey().content }),
            a2.shouldShowEmptyBlock && (0, l.jsx)(Q.pA, { className: ey().emptyPlaylist })
          ]
        });
      }), ev = (0, s.PA)((e2) => {
        var t2, a2, s2, _2, f2;
        let { userId: x2, kind: b2, playlistUuid: I2, preloadedPlaylistByUuid: T2, isWebNextNavigationOn: C2 } = e2, {
          playlist: N2,
          settings: { isMobile: S2 }
        } = (0, p.Pjs)(), { formatMessage: A2 } = (0, o.A)(), { contentScrollRef: D2, setContentScrollRef: L2 } = (0, p.gKY)(), { forceUpdateRefCallback: E2, offsetY: F2 } = (0, c.G)(D2), B2 = (0, p.OQH)(N2.analyticsParams), w2 = (0, p.vXf)(N2.analyticsParams), R2 = (0, p.ytd)(null == N2 || null == (t2 = N2.meta) ? void 0 : t2.averageColor), O2 = (0, n.useMemo)(() => {
          var e3;
          return N2.isRewind2024Playlist && (null == (e3 = N2.meta) ? void 0 : e3.personalColor) ? ((e4) => {
            let { theme: t3 } = (0, p.DPo)(), a3 = t3 === p.Sxu.Light ? 0.7 : 0.36;
            return (0, p.eWZ)(e4, 0.6, a3);
          })(N2.meta.personalColor) : R2;
        }, [N2.isRewind2024Playlist, null == (a2 = N2.meta) ? void 0 : a2.personalColor, R2]), { topColorStyle: U2, headerStyle: M2 } = (0, g.QZ)(O2, F2, C2);
        ((e3) => {
          var t3;
          let { setDeeplink: a3 } = null != (t3 = (0, p.P7Q)()) ? t3 : {};
          (0, n.useEffect)(() => {
            if (e3) {
              let { href: t4 } = (0, p.uvd)("/playlists/:playlistUuid", { params: { playlistUuid: e3 } });
              null == a3 || a3(t4);
            }
            return () => {
              null == a3 || a3(null);
            };
          }, [e3, a3]);
        })(I2), (0, p.Jzs)(N2.isResolved), ((e3) => {
          (0, n.useEffect)(() => {
            if (!(null == e3 ? void 0 : e3.meta) || e3.isLoading) return;
            let t3 = ((e4) => {
              var t4, a3, l2, i2, s3, r2, n2, o2, d2, c2, u2, m2, g2;
              let p2 = e4.items.map((e5) => ({ id: Number(e5.id), albumId: Number(e5.albumId) || void 0 }));
              return {
                owner: null == (t4 = e4.meta) ? void 0 : t4.owner,
                uid: (null == (a3 = e4.meta) ? void 0 : a3.uid) || 0,
                kind: (null == (l2 = e4.meta) ? void 0 : l2.kind) || 0,
                title: (null == (i2 = e4.meta) ? void 0 : i2.title) || "",
                description: null == (s3 = e4.meta) ? void 0 : s3.description,
                revision: (null == (r2 = e4.meta) ? void 0 : r2.revision) || 0,
                snapshot: 0,
                trackCount: p2.length,
                cover: {
                  uri: (null == (n2 = e4.meta) ? void 0 : n2.coverUri) || "",
                  prefix: "",
                  type: P.Q.FROM_ALBUM_COVER,
                  custom: false
                },
                playlistUuid: (null == (o2 = e4.meta) ? void 0 : o2.uuid) || "",
                available: (null == (d2 = e4.meta) ? void 0 : d2.isAvailable) || true,
                visibility: (null == (c2 = e4.meta) ? void 0 : c2.visibility) || v.L.PUBLIC,
                likesCount: null == (u2 = e4.meta) ? void 0 : u2.likesCount,
                modified: (null == (m2 = e4.meta) ? void 0 : m2.modified) || "",
                created: "",
                isBanner: false,
                isPremiere: false,
                durationMs: 0,
                collective: false,
                ogImage: (null == (g2 = e4.meta) ? void 0 : g2.coverUri) || "",
                tags: [],
                tracks: p2
              };
            })(e3);
            (0, h.C)(t3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, p.jxB)(e4);
            });
          }, [null == e3 ? void 0 : e3.meta, null == e3 ? void 0 : e3.isLoading, e3]);
        })(N2), (0, p.ACS)(), (0, n.useEffect)(
          () => (B2(), () => {
            N2.reset(), w2();
          }),
          [N2, I2, x2, b2]
        );
        let Y2 = (0, n.useMemo)(
          () => ({
            Header: () => (0, l.jsx)(eP, { playlistHeaderRef: E2 }),
            Item: N2.isDragAndDropEnabled ? j : void 0,
            Footer: () => (0, l.jsx)(G, { playlist: N2 })
          }),
          [E2, N2, N2.isDragAndDropEnabled]
        ), K2 = (0, n.useCallback)(
          (e3) => {
            N2.getTracksByRange(e3);
          },
          [N2]
        ), W2 = (0, n.useCallback)(
          (e3) => {
            var t3;
            return null == (t3 = N2.items[e3]) ? void 0 : t3.key;
          },
          [N2.items]
        ), Q2 = (0, n.useCallback)((e3) => e3, []), V2 = (0, m.Qj)();
        if (N2.isNeededToLoad && ("string" == typeof I2 ? (0, n.use)(N2.getPlaylistByUuid({ playlistUuid: I2, resumeStream: false, preloadedPlaylist: T2 })) : "string" == typeof x2 && "string" == typeof b2 && (0, n.use)(N2.getPlaylistByUserIdAndKind({ userId: x2, playlistKind: Number(b2), resumeStream: false }))), N2.uuid && N2.isResolved && N2.similarEntities.isNeededToLoad && N2.isSimilarEntitiesEnabled && (0, n.use)(N2.getSimilarEntities({ playlistUuid: N2.uuid })), N2.isNotFound && (0, r.notFound)(), N2.isRejected)
          return (0, l.jsx)(u.w, {});
        let X2 = V2.isEnabled ? y.Vw.BRANDED_PLAYLIST : y.Vw.INNER;
        return (0, l.jsx)(g.hO, {
          scrollElement: D2,
          children: (0, l.jsxs)("div", {
            className: k().wrapper,
            style: null == (s2 = V2.data) ? void 0 : s2.style,
            children: [
              (0, l.jsx)(y.Y9, { variant: X2, style: M2 }),
              !V2.isEnabled && (0, l.jsx)("div", { className: k().averageColorBackground, style: U2 }),
              (0, l.jsx)($, {
                playlist: N2,
                children: (0, l.jsx)(y.$$, {
                  context: {
                    listAriaLabel: A2(
                      { id: "entity-names.playlist-tracks-list" },
                      { playlistName: (null == (_2 = N2.meta) ? void 0 : _2.title) || "" }
                    )
                  },
                  className: (0, i.$)(k().root, k().important),
                  listClassName: k().content,
                  customComponents: Y2,
                  computeItemKey: N2.isDragAndDropEnabled ? W2 : Q2,
                  totalCount: N2.virtualListItemsCount,
                  itemContentCallback: (e3) => (0, l.jsx)(H, { index: e3 }),
                  onGetDataByRange: K2,
                  debounceDurationInMs: 300,
                  initialItemCount: null == (f2 = N2.items) ? void 0 : f2.length,
                  handleRef: L2,
                  shouldTriggerRangeChangedOn: [N2.filters.activeFilter, N2.virtualListItemsCount],
                  testId: d.Xk.playlist.PLAYLIST_PAGE,
                  isMobileLayout: S2,
                  useWindowScroll: S2,
                  withFooter: true,
                  withForceScroll: true
                })
              })
            ]
          })
        });
      }), eh = (0, s.PA)(
        (e2) => (0, l.jsx)(m.AL, {
          children: (0, l.jsx)(p.nVz, {
            pageId: p._Q$.PLAYLIST,
            pageEntityId: e2.playlistUuid,
            children: (0, l.jsx)(p.jPc, { children: (0, l.jsx)(ev, { ...e2 }) })
          })
        })
      );
    },
    62882: (e) => {
      e.exports = {
        root: "PlaylistPageDnDList_root__6Fryw",
        draggableItemWrapper: "PlaylistPageDnDList_draggableItemWrapper__vvEWL",
        dots: "PlaylistPageDnDList_dots__F4qh2",
        noHoverItem: "PlaylistPageDnDList_noHoverItem__dbPTH"
      };
    },
    66810: (e) => {
      e.exports = {
        stickyFilters: "PlaylistPageFilters_stickyFilters__SfT9C",
        staticFilters: "PlaylistPageFilters_staticFilters__sk7JJ",
        staticFiltersCarousel: "PlaylistPageFilters_staticFiltersCarousel__vJQXE"
      };
    },
    84458: (e, t, a) => {
      "use strict";
      a.d(t, { C: () => i });
      var l = a(74125);
      async function i(e2, t2) {
        var a2, i2, s, r, n;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let o = await (0, l.WGy)(t2.locale), d = null != (i2 = e2.ogTitle) ? i2 : (0, l.YFq)(e2.title, 48, false), c = o({ id: "metadata.playlist-title" }, { playlistTitle: e2.title });
        return (null == (a2 = e2.owner) ? void 0 : a2.verified) ? {
          title: c,
          description: c,
          openGraph: (0, l.i$E)({
            ogTitle: d,
            ogDescription: (function(e3) {
              var t3;
              let { playlistMeta: a3, messageFormatter: i3 } = e3, s2 = "";
              return a3.ogDescription ? s2 = a3.ogDescription : a3.description && (s2 = a3.description.replace(/\[(.*?)\]\(.*?\)/gi, "$1")), [
                s2 = (0, l.YFq)(s2, 96, false),
                i3({ id: "metadata.playlist" }),
                (null != (t3 = a3.likesCount) ? t3 : 0) > 0 && i3({ id: "metadata.likes-counter" }, { counter: a3.likesCount })
              ].filter(Boolean).join(" • ");
            })({ playlistMeta: e2, messageFormatter: o }),
            fullUrl: null != (s = t2.fullUrl) ? s : "",
            locale: t2.locale,
            ogImage: e2.ogImage,
            siteName: o({ id: "metadata.yandex-music" }),
            ogType: "music.playlist"
          }),
          twitter: (0, l.HRN)({
            cardType: l.WfF.APP,
            title: d,
            url: t2.url,
            appName: o({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, l.X5i)({
            additional: {
              ...t2,
              url: null != (r = t2.url) ? r : "",
              fullUrl: null != (n = t2.fullUrl) ? n : "",
              host: t2.host
            },
            appName: o({ id: "metadata.yandex-music" })
          }),
          alternates: (0, l.SEs)("/playlists/:playlistUuid", t2.tld, { params: { playlistUuid: e2.playlistUuid } })
        } : { robots: { index: false, follow: false } };
      }
    },
    85598: (e) => {
      e.exports = {
        root: "PlaylistPageDnDItemWrapper_root__eBm1E",
        inner: "PlaylistPageDnDItemWrapper_inner__UXQZf",
        dragging: "PlaylistPageDnDItemWrapper_dragging__Pl94m",
        dragOverlay: "PlaylistPageDnDItemWrapper_dragOverlay__tWQut"
      };
    },
    92737: (e) => {
      e.exports = {
        root: "SearchPlaylistInput_root__o14iM",
        content: "SearchPlaylistInput_content__iDyfU",
        catalog: "SearchPlaylistInput_catalog__5r6Xm",
        catalog_withTracks: "SearchPlaylistInput_catalog_withTracks__B2ZYF",
        track: "SearchPlaylistInput_track__2TGLS",
        shimmerItem: "SearchPlaylistInput_shimmerItem__V0cOt",
        emptyBlockContainer: "SearchPlaylistInput_emptyBlockContainer__NSQKG",
        disappearingTrack: "SearchPlaylistInput_disappearingTrack__D6ja5",
        disappearing: "SearchPlaylistInput_disappearing__w48Cd",
        appearingTrack: "SearchPlaylistInput_appearingTrack__CYHzN",
        appearing: "SearchPlaylistInput_appearing__SafaE"
      };
    },
    94094: (e, t, a) => {
      "use strict";
      a.d(t, { PlaylistNotFoundPage: () => d });
      var l = a(54486), i = a(28303), s = a(61910), r = a(42421), n = a(74125);
      let o = (0, i.PA)(() => {
        let { playlist: e2 } = (0, n.Pjs)();
        return (0, n.ACS)(), (0, s.useEffect)(() => {
          e2.reset();
        }, []), (0, l.jsx)(r.M, {});
      }), d = (0, i.PA)(() => (0, l.jsx)(n.nVz, { pageId: n._Q$.PAGE_NOT_FOUND_SCREEN, children: (0, l.jsx)(o, {}) }));
    },
    98898: (e) => {
      e.exports = {
        brandedPlaylistBannerWrapper: "PlaylistPageHeaderBranding_brandedPlaylistBannerWrapper__S8BTI",
        creative: "PlaylistPageHeaderBranding_creative__5OXtq"
      };
    },
    99456: (e) => {
      e.exports = {
        root: "PlaylistPageFooter_root__h6jh8",
        carouselContainer: "PlaylistPageFooter_carouselContainer__fIwg5",
        carouselBlock: "PlaylistPageFooter_carouselBlock__OFRtz",
        carouselBlockHeader: "PlaylistPageFooter_carouselBlockHeader__HbjLr",
        footer: "PlaylistPageFooter_footer__Mqwre"
      };
    }
  }
]);
