"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1886],
  {
    1269: (e, t, r) => {
      Object.defineProperty(t, "__esModule", { value: true }), t.default = function() {
        var e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "localStorage", t2 = String(e2).replace(/storage$/i, "").toLowerCase();
        if ("local" === t2) return i("localStorage");
        if ("session" === t2) return i("sessionStorage");
        if ("cookie" === t2) return (0, n.hasCookies)();
        if ("memory" === t2) return true;
        throw Error(
          "Storage method `" + e2 + "` is not available.\n    Please use one of the following: localStorage, sessionStorage, cookieStorage, memoryStorage."
        );
      };
      var n = r(39348), o = "__test";
      function i(e2) {
        try {
          var t2 = window[e2];
          return t2.setItem(o, "1"), t2.removeItem(o), true;
        } catch (e3) {
          return false;
        }
      }
    },
    10096: (e, t) => {
      t.parse = function(e2, t2) {
        if ("string" != typeof e2) throw TypeError("argument str must be a string");
        for (var n2 = {}, i2 = e2.split(o), a = (t2 || {}).decode || r, s = 0; s < i2.length; s++) {
          var l = i2[s], u = l.indexOf("=");
          if (!(u < 0)) {
            var h = l.substr(0, u).trim(), c = l.substr(++u, l.length).trim();
            '"' == c[0] && (c = c.slice(1, -1)), void 0 == n2[h] && (n2[h] = (function(e3, t3) {
              try {
                return t3(e3);
              } catch (t4) {
                return e3;
              }
            })(c, a));
          }
        }
        return n2;
      }, t.serialize = function(e2, t2, r2) {
        var o2 = r2 || {}, a = o2.encode || n;
        if ("function" != typeof a) throw TypeError("option encode is invalid");
        if (!i.test(e2)) throw TypeError("argument name is invalid");
        var s = a(t2);
        if (s && !i.test(s)) throw TypeError("argument val is invalid");
        var l = e2 + "=" + s;
        if (null != o2.maxAge) {
          var u = o2.maxAge - 0;
          if (isNaN(u)) throw Error("maxAge should be a Number");
          l += "; Max-Age=" + Math.floor(u);
        }
        if (o2.domain) {
          if (!i.test(o2.domain)) throw TypeError("option domain is invalid");
          l += "; Domain=" + o2.domain;
        }
        if (o2.path) {
          if (!i.test(o2.path)) throw TypeError("option path is invalid");
          l += "; Path=" + o2.path;
        }
        if (o2.expires) {
          if ("function" != typeof o2.expires.toUTCString) throw TypeError("option expires is invalid");
          l += "; Expires=" + o2.expires.toUTCString();
        }
        if (o2.httpOnly && (l += "; HttpOnly"), o2.secure && (l += "; Secure"), o2.sameSite)
          switch ("string" == typeof o2.sameSite ? o2.sameSite.toLowerCase() : o2.sameSite) {
            case true:
            case "strict":
              l += "; SameSite=Strict";
              break;
            case "lax":
              l += "; SameSite=Lax";
              break;
            default:
              throw TypeError("option sameSite is invalid");
          }
        return l;
      };
      var r = decodeURIComponent, n = encodeURIComponent, o = /; */, i = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;
    },
    39348: (e, t, r) => {
      Object.defineProperty(t, "__esModule", { value: true });
      var n = /* @__PURE__ */ (function() {
        function e2(e3, t2) {
          for (var r2 = 0; r2 < t2.length; r2++) {
            var n2 = t2[r2];
            n2.enumerable = n2.enumerable || false, n2.configurable = true, "value" in n2 && (n2.writable = true), Object.defineProperty(e3, n2.key, n2);
          }
        }
        return function(t2, r2, n2) {
          return r2 && e2(t2.prototype, r2), n2 && e2(t2, n2), t2;
        };
      })();
      t.hasCookies = function() {
        var e2 = new a();
        try {
          var t2 = "__test";
          e2.setItem(t2, "1");
          var r2 = e2.getItem(t2);
          return e2.removeItem(t2), "1" === r2;
        } catch (e3) {
          return false;
        }
      };
      var o = (function(e2) {
        return e2 && e2.__esModule ? e2 : { default: e2 };
      })(r(10096)), i = "lS_", a = (function() {
        function e2() {
          var t2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          if (!(this instanceof e2)) throw TypeError("Cannot call a class as a function");
          this.cookieOptions = Object.assign({ path: "/" }, t2), i = void 0 === t2.prefix ? i : t2.prefix;
        }
        return n(e2, [
          {
            key: "getItem",
            value: function(e3) {
              var t2 = o.default.parse(document.cookie);
              return t2 && t2.hasOwnProperty(i + e3) ? t2[i + e3] : null;
            }
          },
          {
            key: "setItem",
            value: function(e3, t2) {
              return document.cookie = o.default.serialize(i + e3, t2, this.cookieOptions), t2;
            }
          },
          {
            key: "removeItem",
            value: function(e3) {
              var t2 = Object.assign({}, this.cookieOptions, { maxAge: -1 });
              return document.cookie = o.default.serialize(i + e3, "", t2), null;
            }
          },
          {
            key: "clear",
            value: function() {
              var e3 = o.default.parse(document.cookie);
              for (var t2 in e3) 0 === t2.indexOf(i) && this.removeItem(t2.substr(i.length));
              return null;
            }
          }
        ]), e2;
      })();
      t.default = a;
    },
    41886: (e, t, r) => {
      var _a;
      r.r(t), r.d(t, { VHPlayerCoreAdapter: () => S, loadVHPlayerSdk: () => y });
      var n, o, i = r(99809);
      let a = "__VPUID_INLINE__", s = "vpuid";
      var l = r(83308);
      let u = {
        getItem(e2) {
          try {
            return l.getItem(e2);
          } catch {
            return null;
          }
        },
        setItem(e2, t2) {
          try {
            l.setItem(e2, t2);
          } catch {
          }
        },
        removeItem(e2) {
          try {
            l.removeItem(e2);
          } catch {
          }
        },
        clear() {
          try {
            l.clear();
          } catch {
          }
        }
      };
      var h = r(70281);
      let c = "qwertyuiopasdfghjklzxcvbnm0123456789", f = -1 === a.indexOf("__VPUID") ? a : (_a = u.getItem(s)) != null ? _a : (function() {
        let e2 = [];
        for (let t2 = 0; t2 < 10; t2++) e2.push(c[Math.floor((0, h.y)() * c.length)]);
        return e2.join("");
      })();
      async function d(e2) {
        let t2 = [
          ["vpuid", f],
          ["version", e2 == null ? void 0 : e2.version],
          ["testid", isFinite(e2.testid) ? String(e2.testid) : void 0],
          ["bundleurl", e2 == null ? void 0 : e2.bundleUrl]
        ].filter(([e3, t3]) => !!t3).map((e3) => e3.join("=")).join("&");
        try {
          var r2, n2;
          let o2 = e2.hostname || "frontend.vh.yandex.ru", a2 = t2 ? `?${t2}` : "";
          await (r2 = `https://${o2}/get_player/${e2.file}${a2}`, n2 = e2.checkLoad, (0, i.I)({
            src: r2,
            async: false,
            retries: 3,
            dropCacheOnRetry: true,
            onBeforeLoad: (e3) => {
              e3.crossOrigin = "use-credentials";
            },
            checkLoad: n2
          }));
        } catch (e3) {
          throw e3;
        }
      }
      function p(e2) {
        try {
          return e2();
        } catch {
          return;
        }
      }
      u.setItem(s, f);
      let m = (0, r(42018).x)();
      async function g(e2) {
        var _a2;
        if ((_a2 = p(() => m.Ya.playerSdk)) == null ? void 0 : _a2.init) return Promise.resolve();
        await d({
          file: "player-sdk.js",
          version: e2 == null ? void 0 : e2.version,
          checkLoad: () => {
            var _a3;
            return !!((_a3 = p(() => m.Ya.playerSdk)) == null ? void 0 : _a3.preloadScripts);
          }
        }), await m.Ya.playerSdk.preloadScripts();
      }
      function y(e2) {
        return g({ version: e2 });
      }
      var v = r(96559), C = r(52599);
      !(function(e2) {
        e2.SourceChange = "SourceChange", e2.StatusChange = "StatusChange", e2.ErrorChange = "ErrorChange", e2.CurrentTimeChange = "CurrentTimeChange", e2.DurationChange = "DurationChange", e2.UtcStartTimeChange = "UtcStartTimeChange", e2.VideoTypeChange = "VideoTypeChange", e2.MutedChange = "MutedChange", e2.VolumeChange = "VolumeChange";
      })(n || (n = {})), (function(e2) {
        e2.idle = "idle", e2.init = "init", e2.buffering = "buffering", e2.play = "play", e2.pause = "pause", e2.end = "end", e2.fatal = "fatal", e2.broken = "broken", e2.destroyed = "destroyed", e2.cancelled = "cancelled", e2.preparing = "preparing", e2.finished = "finished";
      })(o || (o = {}));
      class S {
        statusChangeHandler() {
          let { status: e2 } = this.player.getState();
          switch (e2) {
            case "end":
              this.emitter.emit("end");
              break;
            case "play":
              this.emitter.emit("play");
              break;
            case "pause":
              this.emitter.emit("pause");
          }
        }
        currentTimeChangeHandler() {
          let { duration: e2, currentTime: t2 } = this.player.getState();
          this.emitter.emit("currentTimeChange", { duration: e2, position: t2, loaded: 0 });
        }
        volumeChangeHandler() {
          let { volume: e2 } = this.player.getState();
          this.emitter.emit("volumeChange", e2);
        }
        errorChangeHandler() {
          let { error: e2 } = this.player.getState();
          e2 instanceof Error && this.emitter.emit("errorChange", e2);
        }
        subscribePlayerEvents() {
          this.player && (this.player.on(n.StatusChange, this.statusChangeHandler), this.player.on(n.CurrentTimeChange, this.currentTimeChangeHandler), this.player.on(n.VolumeChange, this.volumeChangeHandler), this.player.on(n.ErrorChange, this.errorChangeHandler));
        }
        unsubscribePlayerEvents() {
          this.player && (this.player.off(n.StatusChange, this.statusChangeHandler), this.player.off(n.CurrentTimeChange, this.currentTimeChangeHandler), this.player.off(n.VolumeChange, this.volumeChangeHandler), this.player.off(n.ErrorChange, this.errorChangeHandler));
        }
        get adConfig() {
          if (this.hideAds) return { adBreaks: [] };
        }
        initPlayer(e2) {
          let { src: t2, autoplay: r2, container: n2 } = e2;
          this.player = window.Ya.playerSdk.init({
            element: n2,
            source: t2,
            hiddenControls: "*",
            autoplay: r2,
            adConfig: this.adConfig
          }), this.subscribePlayerEvents(), null !== this.storedVolume && (this.player.setVolume(this.storedVolume), this.storedVolume = null);
        }
        play(e2) {
          let { source: t2 } = e2;
          return this.internalSetSrc({ source: t2, autoplay: true });
        }
        setSrc(e2) {
          let { source: t2 } = e2;
          this.internalSetSrc({ source: t2, autoplay: false });
        }
        internalSetSrc(e2) {
          let { source: t2, autoplay: r2 } = e2;
          if (this.player)
            return this.player.setSource({ source: t2.src, autoplay: r2, adConfig: this.adConfig }).then(() => {
              if (null !== this.storedVolume) {
                var e3;
                null == (e3 = this.player) || e3.setVolume(this.storedVolume), this.storedVolume = null;
              }
            });
          try {
            return this.container && this.initPlayer({ src: t2.src, autoplay: r2, container: this.container }), Promise.resolve();
          } catch (e3) {
            return Promise.reject(e3);
          }
        }
        pause() {
          var e2;
          return null == (e2 = this.player) || e2.pause(), Promise.resolve();
        }
        resume() {
          return this.player ? this.player.play() : Promise.resolve();
        }
        setProgress(e2) {
          var t2;
          return null == (t2 = this.player) || t2.seek(e2), Promise.resolve(e2);
        }
        setVolume(e2) {
          var t2;
          return this.storedVolume = e2, null == (t2 = this.player) || t2.setVolume(e2), Promise.resolve(e2);
        }
        setSpeed(e2) {
          return Promise.resolve(e2);
        }
        stop() {
          return Promise.resolve();
        }
        destroy() {
          return (this.unsubscribePlayerEvents(), this.player) ? this.player.destroy().finally(() => {
            this.player = null, this.container = null;
          }) : Promise.resolve();
        }
        setContainer(e2) {
          this.container = e2;
        }
        setVideoQuality() {
        }
        onEnd(e2) {
          this.emitter.on("end", e2);
        }
        onPaused(e2) {
          this.emitter.on("pause", e2);
        }
        onUpdatingProgress(e2) {
          this.emitter.on("currentTimeChange", e2);
        }
        onPlaying(e2) {
          this.emitter.on("play", e2);
        }
        onError(e2) {
          this.emitter.on("errorChange", e2);
        }
        onVolumeChange(e2) {
          this.emitter.on("volumeChange", e2);
        }
        onSpeedChange() {
        }
        onResume() {
        }
        onSeeked() {
        }
        onSeeking() {
        }
        onStalled() {
        }
        onCanplay() {
        }
        onWaiting() {
        }
        offEnd(e2) {
          this.emitter.off("end", e2);
        }
        offPaused(e2) {
          this.emitter.off("pause", e2);
        }
        offUpdatingProgress(e2) {
          this.emitter.off("currentTimeChange", e2);
        }
        offPlaying(e2) {
          this.emitter.off("play", e2);
        }
        offError(e2) {
          this.emitter.off("errorChange", e2);
        }
        offVolumeChange(e2) {
          this.emitter.off("volumeChange", e2);
        }
        offSpeedChange() {
        }
        offResume() {
        }
        offSeeked() {
        }
        offSeeking() {
        }
        offStalled() {
        }
        offCanplay() {
        }
        offWaiting() {
        }
        constructor(e2) {
          (0, v._)(this, "player", null), (0, v._)(this, "container", null), (0, v._)(this, "emitter", new C.b()), (0, v._)(this, "hideAds", void 0), (0, v._)(this, "storedVolume", null), this.hideAds = !!e2.hideAds, this.statusChangeHandler = this.statusChangeHandler.bind(this), this.currentTimeChangeHandler = this.currentTimeChangeHandler.bind(this), this.volumeChangeHandler = this.volumeChangeHandler.bind(this), this.errorChangeHandler = this.errorChangeHandler.bind(this);
        }
      }
    },
    42018: (e, t, r) => {
      r.d(t, { x: () => n });
      function n() {
        return "object" == typeof self ? self : "object" == typeof window ? window : globalThis;
      }
    },
    46412: (e) => {
      var t = Object.prototype.hasOwnProperty, r = "~";
      function n() {
      }
      function o(e2, t2, r2) {
        this.fn = e2, this.context = t2, this.once = r2 || false;
      }
      function i(e2, t2, n2, i2, a2) {
        if ("function" != typeof n2) throw TypeError("The listener must be a function");
        var s2 = new o(n2, i2 || e2, a2), l = r ? r + t2 : t2;
        return e2._events[l] ? e2._events[l].fn ? e2._events[l] = [e2._events[l], s2] : e2._events[l].push(s2) : (e2._events[l] = s2, e2._eventsCount++), e2;
      }
      function a(e2, t2) {
        0 == --e2._eventsCount ? e2._events = new n() : delete e2._events[t2];
      }
      function s() {
        this._events = new n(), this._eventsCount = 0;
      }
      Object.create && (n.prototype = /* @__PURE__ */ Object.create(null), new n().__proto__ || (r = false)), s.prototype.eventNames = function() {
        var e2, n2, o2 = [];
        if (0 === this._eventsCount) return o2;
        for (n2 in e2 = this._events) t.call(e2, n2) && o2.push(r ? n2.slice(1) : n2);
        return Object.getOwnPropertySymbols ? o2.concat(Object.getOwnPropertySymbols(e2)) : o2;
      }, s.prototype.listeners = function(e2) {
        var t2 = r ? r + e2 : e2, n2 = this._events[t2];
        if (!n2) return [];
        if (n2.fn) return [n2.fn];
        for (var o2 = 0, i2 = n2.length, a2 = Array(i2); o2 < i2; o2++) a2[o2] = n2[o2].fn;
        return a2;
      }, s.prototype.listenerCount = function(e2) {
        var t2 = r ? r + e2 : e2, n2 = this._events[t2];
        return n2 ? n2.fn ? 1 : n2.length : 0;
      }, s.prototype.emit = function(e2, t2, n2, o2, i2, a2) {
        var s2 = r ? r + e2 : e2;
        if (!this._events[s2]) return false;
        var l, u, h = this._events[s2], c = arguments.length;
        if (h.fn) {
          switch (h.once && this.removeListener(e2, h.fn, void 0, true), c) {
            case 1:
              return h.fn.call(h.context), true;
            case 2:
              return h.fn.call(h.context, t2), true;
            case 3:
              return h.fn.call(h.context, t2, n2), true;
            case 4:
              return h.fn.call(h.context, t2, n2, o2), true;
            case 5:
              return h.fn.call(h.context, t2, n2, o2, i2), true;
            case 6:
              return h.fn.call(h.context, t2, n2, o2, i2, a2), true;
          }
          for (u = 1, l = Array(c - 1); u < c; u++) l[u - 1] = arguments[u];
          h.fn.apply(h.context, l);
        } else {
          var f, d = h.length;
          for (u = 0; u < d; u++)
            switch (h[u].once && this.removeListener(e2, h[u].fn, void 0, true), c) {
              case 1:
                h[u].fn.call(h[u].context);
                break;
              case 2:
                h[u].fn.call(h[u].context, t2);
                break;
              case 3:
                h[u].fn.call(h[u].context, t2, n2);
                break;
              case 4:
                h[u].fn.call(h[u].context, t2, n2, o2);
                break;
              default:
                if (!l) for (f = 1, l = Array(c - 1); f < c; f++) l[f - 1] = arguments[f];
                h[u].fn.apply(h[u].context, l);
            }
        }
        return true;
      }, s.prototype.on = function(e2, t2, r2) {
        return i(this, e2, t2, r2, false);
      }, s.prototype.once = function(e2, t2, r2) {
        return i(this, e2, t2, r2, true);
      }, s.prototype.removeListener = function(e2, t2, n2, o2) {
        var i2 = r ? r + e2 : e2;
        if (!this._events[i2]) return this;
        if (!t2) return a(this, i2), this;
        var s2 = this._events[i2];
        if (s2.fn) s2.fn !== t2 || o2 && !s2.once || n2 && s2.context !== n2 || a(this, i2);
        else {
          for (var l = 0, u = [], h = s2.length; l < h; l++)
            (s2[l].fn !== t2 || o2 && !s2[l].once || n2 && s2[l].context !== n2) && u.push(s2[l]);
          u.length ? this._events[i2] = 1 === u.length ? u[0] : u : a(this, i2);
        }
        return this;
      }, s.prototype.removeAllListeners = function(e2) {
        var t2;
        return e2 ? (t2 = r ? r + e2 : e2, this._events[t2] && a(this, t2)) : (this._events = new n(), this._eventsCount = 0), this;
      }, s.prototype.off = s.prototype.removeListener, s.prototype.addListener = s.prototype.on, s.prefixed = r, s.EventEmitter = s, e.exports = s;
    },
    52599: (e, t, r) => {
      r.d(t, { b: () => n });
      var n = r(46412);
    },
    79339: (e, t) => {
      Object.defineProperty(t, "__esModule", { value: true });
      var r = /* @__PURE__ */ (function() {
        function e2(e3, t2) {
          for (var r2 = 0; r2 < t2.length; r2++) {
            var n = t2[r2];
            n.enumerable = n.enumerable || false, n.configurable = true, "value" in n && (n.writable = true), Object.defineProperty(e3, n.key, n);
          }
        }
        return function(t2, r2, n) {
          return r2 && e2(t2.prototype, r2), n && e2(t2, n), t2;
        };
      })();
      t.default = (function() {
        function e2() {
          if (!(this instanceof e2)) throw TypeError("Cannot call a class as a function");
          this._data = {};
        }
        return r(e2, [
          {
            key: "getItem",
            value: function(e3) {
              return this._data.hasOwnProperty(e3) ? this._data[e3] : null;
            }
          },
          {
            key: "setItem",
            value: function(e3, t2) {
              return this._data[e3] = String(t2);
            }
          },
          {
            key: "removeItem",
            value: function(e3) {
              return delete this._data[e3];
            }
          },
          {
            key: "clear",
            value: function() {
              return this._data = {};
            }
          }
        ]), e2;
      })();
    },
    83308: (e, t, r) => {
      Object.defineProperty(t, "__esModule", { value: true }), t.MemoryStorage = t.CookieStorage = t.isSupported = t.storage = void 0;
      var n = a(r(1269)), o = a(r(39348)), i = a(r(79339));
      function a(e2) {
        return e2 && e2.__esModule ? e2 : { default: e2 };
      }
      var s = null;
      (0, n.default)("localStorage") ? t.storage = s = window.localStorage : (0, n.default)("sessionStorage") ? t.storage = s = window.sessionStorage : (0, n.default)("cookieStorage") ? t.storage = s = new o.default() : t.storage = s = new i.default(), t.default = s, t.storage = s, t.isSupported = n.default, t.CookieStorage = o.default, t.MemoryStorage = i.default;
    },
    99809: (e, t, r) => {
      r.d(t, { I: () => i });
      let n = () => {
      }, o = (e2) => true;
      function i(e2) {
        return new Promise((t2, r2) => {
          !(function(e3) {
            let { dropCacheOnRetry: t3 = false, onBeforeLoad: r3 = n, retries: i2 = 0 } = e3;
            if (e3.checkLoad && e3.checkLoad()) {
              e3.onLoad && e3.onLoad();
              return;
            }
            let a = r3, s = 0;
            t3 && i2 > 0 && (a = (e4) => {
              if (r3(e4), s > 0) {
                var t4;
                let r4, n2 = -1 === e4.src.indexOf("?") ? "?" : "&", o2 = (t4 = s, Number.isFinite(r4 = Math.floor(1e9 * Math.random()) % 1e9) || (r4 = 0), r4 += Date.now() % 1e9, String(t4) + r4.toString(36));
                e4.src += n2 + o2;
              }
              s++;
            }), (function e4(t4) {
              let {
                src: r4,
                win: i3 = window,
                charset: a2 = "utf-8",
                async: s2 = true,
                retries: l = 0,
                onRetry: u = n,
                retryDelay: h = 0,
                checkLoad: c = o,
                onBeforeLoad: f = n,
                onLoad: d = n,
                onError: p = n
              } = t4, m = i3.document.createElement("script"), g = (n2) => {
                var _a;
                l > 0 ? (u(n2), e4({ ...t4, src: r4, retries: l - 1 })) : p(n2), (_a = m.parentNode) == null ? void 0 : _a.removeChild(m);
              };
              m.type = "text/javascript", m.async = s2, m.onload = () => c(m) ? d() : g(Error(`checkLoad for ${r4} failed`)), m.onerror = (e5) => {
                try {
                  i3.setTimeout(() => {
                    g(e5);
                  }, h);
                } catch {
                }
              }, m.src = r4, m.charset = a2, f(m), (function(e5) {
                let t5 = e5.document, r5 = t5.getElementsByTagName("head")[0];
                return r5 || (r5 = t5.createElement("head"), t5.documentElement.appendChild(r5)), r5;
              })(i3).appendChild(m);
            })({ ...e3, onBeforeLoad: a });
          })({ ...e2, onLoad: t2, onError: r2 });
        });
      }
    }
  }
]);
