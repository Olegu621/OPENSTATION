(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1995],
  {
    2438: (e, t, i) => {
      "use strict";
      i.d(t, { HorizontalAlbumCard: () => k });
      var r = i(54486), a = i(50420), s = i(28303), l = i(61910), n = i(43350), o = i(31500), u = i(63585), c = i(8817), d = i(27510), m = i(73633), b = i(97800), v = i(46423), p = i(63695), _ = i(74125), g = i(80585), A = i(5956), C = i(44592), y = i.n(C);
      let h = (0, s.PA)((e2) => {
        var t2;
        let { className: i2, album: s2, likeIconSize: o2 = "xxs" } = e2, { user: u2, trailer: d2 } = (0, _.Pjs)(), m2 = (0, _.PT7)(), { sendLikeSearchFeedback: b2 } = (0, _.zEv)(), p2 = (0, v.KX)(s2), [C2, h2] = (0, l.useState)(false), k2 = (0, c.c)(async () => {
          C2 || s2.isLiked || (h2(true), null == b2 || b2()), await p2();
        }), x = (0, _.Ftl)(), P = (0, c.c)((e3) => {
          if (e3.stopPropagation(), m2()) return void e3.preventDefault();
          d2.openAlbumTrailer(s2.id), x(n.ky.Album, String(s2.id));
        });
        return (0, r.jsxs)("div", {
          className: (0, a.$)(y().root, y().controls, i2, { [y().controls_disabled]: !s2.isAvailable }),
          children: [
            s2.isAvailable && (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(g.aQ, {
                  fallback: (0, r.jsx)(g.cy, {
                    size: "xs",
                    iconSize: o2,
                    className: (0, a.$)(y().item, y().likeIcon),
                    isLiked: s2.isLiked,
                    onClick: k2,
                    disabled: !u2.isAuthorized
                  })
                }),
                (null == (t2 = s2.trailer) ? void 0 : t2.isAvailable) && (0, r.jsx)(g.aQ, {
                  fallback: (0, r.jsx)(g.kJ, {
                    className: (0, a.$)(y().item, y().trailerIcon),
                    iconSize: "xs",
                    variant: "text",
                    onClick: P,
                    withRipple: false
                  })
                })
              ]
            }),
            (0, r.jsx)("div", {
              className: (0, a.$)(y().item, y().item_buttonArrow),
              children: (0, r.jsx)(A.Icon, { className: g.$f.buttonArrow, variant: "arrowRight", size: "xs" })
            })
          ]
        });
      }), k = (0, s.PA)((e2) => {
        let {
          className: t2,
          album: i2,
          pageId: s2,
          coverClassName: A2,
          playButtonIconSize: C2,
          likeIconSize: y2,
          shouldShowReleaseYear: k2,
          description: x
        } = e2, P = (0, v.r_)(i2.type), { ref: f, intersectionPropertyId: N } = (0, _.nMI)(), { from: L } = (0, _.fyy)({ pageId: s2 }), [K, I] = (0, l.useState)(false), T = (0, _.brA)(), O = (0, _.ZpR)(i2.url), j = (0, _.PT7)(), { sendNavigateSearchFeedback: M, sendPlaySearchFeedback: U } = (0, _.zEv)(), B = (0, _.NKK)(), {
          isPlaying: w,
          isCurrent: R,
          togglePlay: E
        } = (0, _.Dx4)({
          playContextParams: { contextData: { type: u.K.Album, meta: { id: i2.id }, from: L }, loadContextMeta: true }
        }), S = (0, v.cp)({ album: i2, callback: O }), z = (0, v.cp)({ album: i2, callback: E }), D = (0, c.c)((e3) => {
          null == M || M(), B({ to: n.QT.AlbumScreen }), S(e3);
        }), F = (0, c.c)(() => {
          j() || (K || w || (I(true), null == U || U()), z(), T(!w));
        }), $ = (0, c.c)((e3) => {
          (0, m.P)(e3, g.$f.ripple), D(e3);
        }), Q = (0, c.c)((e3) => {
          e3.stopPropagation(), D(e3);
        }), q = (0, l.useCallback)(
          (e3) => (0, r.jsx)(g.q1, {
            isAvailable: i2.isAvailable,
            isDisliked: false,
            coverUri: i2.coverUri,
            title: i2.title,
            className: (0, a.$)(g.$f.playButtonCell, A2),
            alt: "".concat(P, " ").concat(i2.title),
            radius: "xs",
            ...e3
          }),
          [i2.coverUri, i2.isAvailable, i2.title, A2, P]
        ), G = null == q ? void 0 : q({ onPlayButtonClick: F, isPlaying: w, isCurrent: R, playButtonIconSize: C2 }), H = (0, l.useMemo)(
          () => i2.url && i2.isAvailable ? (0, r.jsx)(g.N_, {
            className: (0, a.$)(g.$f.text, g.$f.titleLink),
            href: i2.url,
            onClick: Q,
            children: i2.title
          }) : (0, r.jsx)(b.Caption, {
            className: (0, a.$)(g.$f.text, g.$f.titleText),
            size: "m",
            variant: "div",
            type: "text",
            children: i2.title
          }),
          [i2.isAvailable, i2.title, i2.url, Q]
        ), V = (0, l.useCallback)(
          (e3, t3) => {
            var a2;
            return (null == (a2 = i2.artists) ? void 0 : a2.length) ? (0, r.jsx)(p.iQ, {
              linkClassName: e3,
              captionClassName: t3,
              artists: i2.artists,
              lineClamp: 1,
              withLink: i2.isAvailable
            }) : null;
          },
          [i2.artists, i2.isAvailable]
        ), W = (0, d.L)(() => [i2.artistNames, i2.title, i2.version].filter(Boolean).join(" "));
        return (0, r.jsxs)(g.Cj, {
          ref: f,
          "data-intersection-property-id": N,
          className: (0, a.$)(g.$f.root, { [g.$f.root_disabled]: !i2.isAvailable }, t2),
          "aria-label": W,
          onClick: $,
          ...(0, o.Am)(o.Kq.album.HORIZONTAL_ALBUM_CARD),
          children: [
            G,
            (0, r.jsx)(g.ro, {
              isDisabled: !i2.isAvailable,
              version: i2.version,
              title: H,
              artistsComponent: V,
              getDescriptionTexts: i2.getDescriptionTexts,
              explicitMarkVariant: i2.explicitDisclaimer,
              likesCount: i2.isNonMusic ? i2.actualLikesCount : void 0,
              isLiked: i2.isNonMusic ? i2.isLiked : void 0,
              releaseYear: i2.isNonMusic && k2 ? i2.year : void 0,
              description: x
            }),
            (0, r.jsx)(h, { className: g.$f.controlsBar, album: i2, likeIconSize: y2 })
          ]
        });
      });
    },
    2608: (e, t, i) => {
      "use strict";
      i.d(t, { b: () => s });
      var r = i(15099), a = i(80585);
      let s = (e2) => {
        switch (e2.type) {
          case r._.PODCAST:
            return a.cp.PODCAST;
          case r._.AUDIOBOOK:
            return a.cp.AUDIOBOOK;
          case r._.FAIRY_TALE:
            return a.cp.FAIRY_TALE;
          default:
            return a.cp.ALBUM;
        }
      };
    },
    11472: (e, t, i) => {
      "use strict";
      i.d(t, { AlbumContextMenu: () => g });
      var r = i(54486), a = i(28303), s = i(61910), l = i(43426), n = i(43350), o = i(31500), u = i(63585), c = i(8817), d = i(61958), m = i(46423), b = i(83504), v = i(74125), p = i(80585), _ = i(50118);
      let g = (0, a.PA)((e2) => {
        var t2, i2;
        let { album: a2, onOpenChange: g2, open: A, wrapperClassName: C, variant: y, ...h } = e2, { shouldShowBuySubscriptionModal: k, showBuySubscriptionModal: x } = (0, v.qBP)(), {
          settings: { isMobile: P },
          trailer: f,
          user: N,
          experiments: L,
          albumCPA: { isPlusCPAEnabled: K, isPlusCPAPlayerBarEnabled: I }
        } = (0, v.Pjs)(), T = (0, m.KX)(a2), O = (0, m.A7)(a2), j = (0, v.Ftl)(), M = "".concat(v.UfI.ALBUM, "-").concat(a2.id), U = a2.isNonMusic && y === _.z.PAGE, B = L.checkExperiment(v.zal.WebEditorsFeatures, "on"), { formatMessage: w } = (0, l.A)(), R = (0, v.PT7)(), { pageAlbumId: E } = (0, v.THB)(), S = K({ pageAlbumId: E, albumId: a2.id, isNonMusic: a2.isNonMusic }), z = I(a2.id, a2.isNonMusic), D = (0, m.Ek)(), { shareLink: F, pathname: $ } = (0, v.bNS)("/album/:albumId", { params: { albumId: a2.id } }), Q = (0, b.A_)({ entityVariant: v.DwC.ALBUM, urlParams: { id: a2.id } }), { isPlaying: q, togglePlay: G } = (0, v.B0S)({
          seeds: null != (i2 = null == a2 ? void 0 : a2.seeds) ? i2 : [],
          pageIdForFrom: v._Q$.RADIO,
          blockIdForFrom: M,
          parentContextId: a2.id
        }), { utmLink: H } = (0, v.fyy)({
          blockId: v.UfI.ALBUM,
          contextType: u.K.Album,
          contextId: null == a2 ? void 0 : a2.id
        }), V = (0, c.c)(() => {
          if (k && N.isAuthorized) return void x();
          !R() && (q || G());
        }), W = (0, c.c)(() => {
          if (k && !z) return void x();
          R() || (f.setUtmLink(H), f.openAlbumTrailer(a2.id), j(n.ky.Album, String(a2.id)));
        });
        (0, v.NBO)(A);
        let Y = (0, s.useMemo)(() => {
          if (!P) return (0, r.jsx)(p.L1, { onClick: O, isPinned: a2.isPinned, disabled: !a2.isAvailable });
        }, [a2.isAvailable, a2.isPinned, O, P]), Z = (0, s.useMemo)(() => {
          let e3 = !S && !N.isAuthorized;
          return a2.isNonMusic ? (0, r.jsx)(p.Uc, { onClick: T, isLiked: a2.isLiked, albumType: a2.type }) : (0, r.jsx)(p.TW, { onClick: T, isLiked: a2.isLiked, disabled: e3 });
        }, [a2.isLiked, a2.type, T, a2.isNonMusic, N.isAuthorized, S]), J = (0, s.useMemo)(() => {
          var e3;
          if (!a2.isNonMusic && (null == (e3 = a2.trailer) ? void 0 : e3.isAvailable))
            return (0, r.jsx)(p.No, { onClick: W, disabled: !a2.isAvailable });
        }, [a2.isAvailable, null == (t2 = a2.trailer) ? void 0 : t2.isAvailable, a2.isNonMusic, W]), X = (0, s.useMemo)(() => {
          if (!a2.isNonMusic)
            return (0, r.jsx)(p.C6, {
              onClick: V,
              disabled: !a2.isAvailable || z && P,
              variant: v.IGO.ALBUM,
              onOpenMenuChange: g2
            });
        }, [a2.isAvailable, V, a2.isNonMusic, g2, z, P]), ee = {
          variant: v.Yxq.ALBUM,
          id: a2.id,
          title: a2.title,
          path: $,
          albumArtistName: a2.artistName,
          albumArtistId: a2.artistId
        };
        return (0, r.jsxs)(d.W1, {
          isMobile: P,
          offsetOptions: 10,
          open: A,
          onOpenChange: g2,
          ariaLabel: w({ id: "interface-actions.context-menu" }),
          wrapperClassName: C,
          containerProps: (0, o.Am)(o.Kq.album.ALBUM_CONTEXT_MENU),
          ...h,
          children: [
            P && (0, r.jsx)(p.Cu, { getDescriptionTexts: a2.getDescriptionTexts, entityId: a2.id }),
            B && (0, r.jsx)(b.dx, { entityVariant: v.DwC.ARTIST, adminUrl: Q }),
            Y,
            Z,
            J,
            X,
            U && (0, r.jsx)(p.iF, { onClick: D, isFinished: a2.listeningFinished }),
            (0, r.jsx)(p.Ht, { shareLink: F, entityMeta: ee })
          ]
        });
      });
    },
    28795: (e, t, i) => {
      "use strict";
      i.d(t, { Chart: () => v });
      var r = i(54486), a = i(50420), s = i(28303), l = i(61910), n = i(43426), o = i(31500), u = i(60423), c = i(5956), d = i(97800), m = i(49423), b = i.n(m);
      let v = (0, s.PA)((e2) => {
        let {
          progress: t2,
          withIcon: i2,
          withCrownIcon: s2,
          position: m2,
          weight: v2 = "normal",
          isDisliked: p,
          isDisabled: _,
          className: g,
          positionClassName: A
        } = e2, { formatMessage: C } = (0, n.A)(), y = t2 || i2, h = (0, l.useMemo)(() => {
          if (s2) return "crown";
          switch (t2) {
            case u._.UP:
              return "chartUp";
            case u._.DOWN:
              return "chartDown";
            case u._.NEW:
              return "chartNew";
            default:
              return "chartSame";
          }
        }, [t2, s2]), k = (0, l.useMemo)(() => {
          switch (t2) {
            case u._.UP:
              return C({ id: "entity-names.chart-up" });
            case u._.DOWN:
              return C({ id: "entity-names.chart-down" });
            case u._.NEW:
              return C({ id: "entity-names.chart-new" });
            default:
              return C({ id: "entity-names.chart-same" });
          }
        }, [C, t2]), x = s2 ? "crown" : t2;
        return (0, r.jsxs)("div", {
          className: (0, a.$)(b().root, g),
          ...(0, o.Am)(o.OA.chart.CHART_PROGRESS),
          children: [
            (0, r.jsx)(d.Caption, {
              variant: "div",
              weight: v2,
              type: "entity",
              size: "m",
              className: (0, a.$)(b().position, A, { [b().position_disliked]: p, [b().position_disabled]: _ }),
              ...(0, o.Am)(o.OA.chart.CHART_PROGRESS_POSITION),
              children: m2
            }),
            y && (0, r.jsx)(c.Icon, {
              variant: h,
              size: "xxs",
              "aria-label": k,
              className: (0, a.$)(b().progress, b()["progress_".concat(x)], {
                [b().progress_disliked]: p,
                [b().progress_disabled]: _
              }),
              ...(0, o.Am)(o.OA.chart.CHART_PROGRESS_ICON)
            })
          ]
        });
      });
    },
    30662: (e, t, i) => {
      "use strict";
      i.d(t, { useAlbumAnalyticsAppScreenName: () => l });
      var r = i(61910), a = i(43350), s = i(15099);
      let l = (e2) => (0, r.useMemo)(() => {
        switch (e2) {
          case s._.PODCAST:
            return a.QT.PodcastScreen;
          case s._.AUDIOBOOK:
            return a.QT.AudiobookScreen;
          default:
            return a.QT.AlbumScreen;
        }
      }, [e2]);
    },
    31757: (e, t, i) => {
      "use strict";
      i.d(t, { useAlbumDisclaimer: () => a });
      var r = i(74125);
      let a = (e2) => {
        let { album: t2, callback: i2, shouldHistoryBack: a2 } = e2;
        return (0, r.lVe)({
          entity: t2,
          callback: i2,
          modalBehavior: void 0 === a2 ? void 0 : { shouldHistoryBack: a2 },
          preventDefaultWhenSafe: true
        });
      };
    },
    38868: (e, t, i) => {
      "use strict";
      i.d(t, { useOnPinClick: () => m });
      var r = i(54486), a = i(63930), s = i(61910), l = i(43426), n = i(74125), o = i(80585), u = i(28303), c = i(2608);
      let d = (0, u.PA)((e2) => {
        let { album: t2, closeToast: i2 } = e2, a2 = (0, c.b)(t2);
        return (0, r.jsx)(o.k4, {
          closeToast: i2,
          entityVariant: a2,
          coverUri: t2.coverUri,
          entityUrl: t2.url,
          entityTitle: t2.title,
          isPinned: t2.isPinned,
          radius: "s"
        });
      }), m = (e2) => {
        let { user: t2 } = (0, n.Pjs)(), { notify: i2 } = (0, n.lkh)(), { formatMessage: u2 } = (0, l.A)(), [c2, m2] = (0, s.useState)(false);
        return (0, s.useCallback)(async () => {
          if (!t2.isAuthorized)
            return void i2((0, r.jsx)(o.hT, { error: u2({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: n.uQT.ERROR
            });
          if (c2) return;
          let s2 = { ...(0, a.HO)(e2), url: e2.url, isPinned: !e2.isPinned };
          m2(true);
          let l2 = await e2.togglePin();
          m2(false), l2 ? i2((0, r.jsx)(d, { album: s2 }), { containerId: n.uQT.INFO }) : i2((0, r.jsx)(o.hT, { error: u2({ id: "error-messages.error-during-action" }) }), {
            containerId: n.uQT.ERROR
          });
        }, [e2, u2, i2, c2, t2.isAuthorized]);
      };
    },
    42140: (e, t, i) => {
      "use strict";
      i.d(t, { t1: () => n.Chart, Iz: () => l, ws: () => a });
      var r = i(93064);
      let a = (e2) => (0, r.wg)({ position: e2.position, progress: e2.progress });
      var s = i(60423);
      let l = r.gK.model("Chart", {
        position: r.gK.maybe(r.gK.number),
        progress: r.gK.maybe(r.gK.enumeration(Object.values(s._)))
      });
      var n = i(28795);
    },
    44592: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "ControlsBar_root__hZQ_Z",
        item: "ControlsBar_item__Y7iTC",
        item_buttonArrow: "ControlsBar_item_buttonArrow__y_Ku0",
        controls: "ControlsBar_controls__yRO8t",
        trailerIcon: "ControlsBar_trailerIcon__areYT",
        controls_disabled: "ControlsBar_controls_disabled___S7Rg",
        likeIcon: "ControlsBar_likeIcon__eJvkI"
      };
    },
    46423: (e, t, i) => {
      "use strict";
      i.d(t, {
        cr: () => c.AlbumEntityNameConsumer,
        GI: () => x,
        oM: () => f,
        rU: () => n,
        e7: () => s,
        G_: () => l,
        Rl: () => o.useAlbumAnalyticsAppScreenName,
        cp: () => u.useAlbumDisclaimer,
        r_: () => c.useAlbumEntityName,
        Ek: () => d.useMarkAlbumListenedClick,
        $1: () => m.useNavigateToAlbumCPA,
        KX: () => b.useOnLikeClick,
        A7: () => v.useOnPinClick,
        PL: () => p.useOnPresaveClick,
        c5: () => _.useOnPromoLandingLikeClick
      });
      var r = i(93064), a = i(74125);
      let s = (e2) => {
        let t2 = (0, a.mxW)(e2.trailer);
        return (0, r.wg)({
          id: e2.id,
          title: e2.title,
          coverUri: e2.coverUri,
          type: e2.type,
          year: e2.year,
          version: e2.version,
          genre: e2.genre,
          likesCount: e2.likesCount,
          averageColor: (0, a.QBb)(e2.derivedColors),
          isAvailable: !!e2.available,
          trackPosition: e2.trackPosition,
          disclaimers: e2.disclaimers,
          trackCount: e2.trackCount,
          availableForPremiumUsers: e2.availableForPremiumUsers,
          availableForOptions: e2.availableForOptions || [],
          bestAlbumTracks: e2.bests,
          durationSec: e2.durationSec,
          trailer: t2,
          listeningFinished: !!e2.listeningFinished
        });
      }, l = (e2) => {
        let t2 = false;
        e2.presaveDate ? t2 = true : e2.presaved && (t2 = e2.presaved);
        let { disclaimers: i2 } = (0, a.fyr)(e2);
        return (0, r.wg)({
          id: e2.id,
          disclaimers: i2,
          isPresave: t2,
          title: e2.title,
          type: e2.type,
          coverUri: e2.coverUri,
          releaseDate: e2.releaseDate
        });
      };
      var n = (function(e2) {
        return e2.TRACK = "track", e2.TEXT = "text", e2;
      })({}), o = i(30662), u = i(31757), c = i(51672), d = i(63449), m = i(65134), b = i(96819), v = i(38868), p = i(77163), _ = i(96025), g = i(15099), A = i(93729), C = i(60049), y = i(77534), h = i(26433);
      let k = r.gK.model("TrackPosition", { volume: r.gK.number, index: r.gK.number }), x = r.gK.compose(
        r.gK.model({
          id: r.gK.number,
          title: r.gK.string,
          type: r.gK.maybe(r.gK.enumeration(Object.values(g._))),
          coverUri: r.gK.maybe(r.gK.string),
          averageColor: r.gK.maybe(r.gK.string),
          year: r.gK.maybe(r.gK.number),
          version: r.gK.maybe(r.gK.string),
          isAvailable: r.gK.optional(r.gK.boolean, true),
          availableForOptions: r.gK.maybe(r.gK.array(r.gK.enumeration(Object.values(A.E)))),
          availableForPremiumUsers: r.gK.maybe(r.gK.boolean),
          bookmateOptionRequired: r.gK.maybe(r.gK.boolean),
          genre: r.gK.maybe(r.gK.string),
          trackPosition: r.gK.maybe(k),
          disclaimers: r.gK.maybe(r.gK.array(r.gK.string)),
          trackCount: r.gK.maybe(r.gK.number),
          bestAlbumTracks: r.gK.maybe(r.gK.array(r.gK.number)),
          trailer: r.gK.maybe(h.aQ),
          durationSec: r.gK.maybe(r.gK.number),
          listeningFinished: r.gK.maybe(r.gK.boolean),
          releaseDate: r.gK.maybe(r.gK.string)
        }),
        h.tP,
        h.Ec
      ).views((e2) => {
        let t2 = {
          get url() {
            let { href: t3 } = (0, a.uvd)("/album/:albumId", { params: { albumId: e2.id } });
            return t3;
          },
          get isLiked() {
            if (!(0, r._n)(e2)) return false;
            let { library: t3 } = (0, r.Zn)(e2);
            return null == t3 ? void 0 : t3.isAlbumLiked(e2.id);
          },
          get pinId() {
            return "".concat(C._.ALBUM_ITEM).concat(e2.id);
          },
          get seeds() {
            return ["album:".concat(e2.id)];
          },
          get isAlbum() {
            return e2.type === g._.ALBUM || e2.type === g._.SINGLE;
          },
          get isPodcast() {
            return e2.type === g._.PODCAST;
          },
          get isAudiobook() {
            return e2.type === g._.AUDIOBOOK;
          },
          get isFairyTale() {
            return e2.type === g._.FAIRY_TALE;
          },
          get isNonMusic() {
            if (!(0, r._n)(e2)) return false;
            return t2.isPodcast || t2.isAudiobook || t2.isFairyTale;
          },
          get isPinned() {
            if (!(0, r._n)(e2)) return false;
            let { pinsCollection: t3 } = (0, r.Zn)(e2);
            return t3.isPinned(this.pinId);
          },
          get isLegalRejected() {
            if (!(0, r._n)(e2)) return false;
            return e2.getIsLegalRejected(e2.isAvailable);
          },
          get isUnsafeLegal() {
            if (!(0, r._n)(e2)) return false;
            return e2.getIsUnsafeLegal(e2.isAvailable);
          },
          get isAvailableOnlyForPlus() {
            var i2;
            return !e2.isAvailable && (e2.availableForPremiumUsers || !!(null == (i2 = e2.availableForOptions) ? void 0 : i2.includes(A.E.BOOKMATE)));
          },
          get shouldShowBooksBadge() {
            var s2;
            return !!(e2.bookmateOptionRequired || !e2.availableForPremiumUsers && (null == (s2 = e2.availableForOptions) ? void 0 : s2.includes(A.E.BOOKMATE)));
          },
          getDisclaimerEntityRef: (i2) => ({
            entityType: null != i2 ? i2 : t2.isPodcast ? a.nPY.PODCAST : a.nPY.ALBUM,
            entityId: e2.id
          })
        };
        return t2;
      }).actions((e2) => ({
        toggleLike: (0, r.L3)(function* () {
          if (!(0, r._n)(e2)) return;
          let { library: t2, user: i2 } = (0, r.Zn)(e2);
          if (i2.isAuthorized) {
            let a2 = yield t2.toggleAlbumLike({ entityId: e2.id, userId: i2.account.data.uid });
            return (0, r._n)(e2) && a2 === y.f.OK && (e2.isLiked ? e2.likePending() : e2.unlikePending()), a2;
          }
        }),
        togglePin: (0, r.L3)(function* () {
          if (!(0, r._n)(e2)) return;
          let { pinsCollection: t2, user: i2 } = (0, r.Zn)(e2);
          if (i2.isAuthorized) return yield t2.toggleAlbumPin({ id: e2.id }, e2.pinId);
        }),
        getKey: (t2) => "".concat(t2, "_").concat(e2.id),
        updateFinished: (t2) => {
          e2.listeningFinished = t2;
        }
      })).named("BaseAlbum");
      var P = i(71020);
      let f = r.gK.compose(
        r.gK.model("BaseUpcomingAlbum", {
          id: r.gK.number,
          isPresave: r.gK.boolean,
          title: r.gK.maybe(r.gK.string),
          type: r.gK.maybe(r.gK.enumeration(Object.values(g._))),
          coverUri: r.gK.maybe(r.gK.string),
          releaseDate: r.gK.maybe(r.gK.string)
        }),
        h.Ec
      ).actions((e2) => {
        let t2 = {
          presaveAlbum: (0, r.L3)(function* (t3) {
            let { usersResource: i2, modelActionsLogger: a2 } = (0, r._$)(e2);
            try {
              e2.isPresave = true;
              let r2 = yield i2.presaveAlbum(t3);
              return r2 === P.J.ERROR && (e2.isPresave = false), r2;
            } catch (t4) {
              return e2.isPresave = false, a2.error(t4), P.J.ERROR;
            }
          }),
          removePresaveAlbum: (0, r.L3)(function* (t3) {
            let { usersResource: i2, modelActionsLogger: a2 } = (0, r._$)(e2);
            try {
              e2.isPresave = false;
              let r2 = yield i2.removePresaveAlbum(t3);
              return r2 === P.J.ERROR && (e2.isPresave = true), r2;
            } catch (t4) {
              return e2.isPresave = true, a2.error(t4), P.J.ERROR;
            }
          }),
          toggleLike: (0, r.L3)(function* () {
            let i2;
            if (!(0, r._n)(e2)) return;
            let { user: a2 } = (0, r.Zn)(e2);
            if (a2.account.data.uid)
              return i2 = e2.isPresave ? yield t2.removePresaveAlbum({ albumId: e2.id, userId: a2.account.data.uid }) : yield t2.presaveAlbum({ albumId: e2.id, userId: a2.account.data.uid, likeAfterRelease: true }), !(0, r._n)(e2), i2;
          }),
          getKey: (t3) => "".concat(t3, "_").concat(e2.id)
        };
        return t2;
      });
    },
    46540: (e, t, i) => {
      "use strict";
      i.d(t, { UpcomingAlbumCard: () => k });
      var r = i(54486), a = i(50420), s = i(28303), l = i(61910), n = i(43426), o = i(47713), u = i(31500), c = i(27510), d = i(77881), m = i(71712), b = i(5956), v = i(6971), p = i(97800), _ = i(46423), g = i(63695), A = i(74125), C = i(80585), y = i(56096), h = i.n(y);
      let k = (0, s.PA)((e2) => {
        let { className: t2, children: i2, upcomingAlbum: s2, contentLinesCount: y2 } = e2, { user: k2 } = (0, A.Pjs)(), { ref: x, intersectionPropertyId: P } = (0, A.nMI)(), { formatMessage: f, formatDate: N } = (0, n.A)(), L = (0, _.PL)(s2), K = s2.getKey("PlayButton"), I = s2.getKey("LikeButton"), T = (0, l.useMemo)(() => {
          let e3 = f({ id: "entity-names.upcoming-album-name" }, { upcomingAlbumName: s2.title }), t3 = s2.isPresave ? f({ id: "entity-names.has-your-like" }) : "";
          return "".concat(e3, " ").concat(t3);
        }, [f, s2.title, s2.isPresave]), O = (0, c.L)(
          () => (0, r.jsxs)(v.Paper, {
            className: h().cover,
            radius: "s",
            withShadow: true,
            children: [
              (0, r.jsx)(C.BW, {
                className: h().image,
                src: s2.coverUri,
                size: 200,
                fit: "cover",
                alt: T,
                withAvatarReplace: true
              }),
              (0, r.jsx)(m.hg, {
                className: h().controls,
                playControl: (0, r.jsx)(
                  d.$,
                  {
                    className: h().lockButton,
                    disabled: true,
                    radius: "xxxl",
                    variant: "default",
                    size: "s",
                    icon: (0, r.jsx)(b.Icon, { variant: "lock", size: "xxs", className: h().lockIcon }),
                    "aria-label": f({ id: "entity-names.upcoming-album-play-disabled" }),
                    ...(0, u.Am)(u.Kq.album.UPCOMING_ALBUM_LOCK_BUTTON)
                  },
                  K
                ),
                likeControl: (0, r.jsx)(
                  C.cy,
                  {
                    className: (0, a.$)(h().control, h().presaveButton),
                    isLiked: s2.isPresave,
                    onClick: L,
                    variant: "default",
                    size: "s",
                    iconSize: "xxs",
                    disabled: !k2.isAuthorized
                  },
                  I
                )
              })
            ]
          })
        );
        return (0, r.jsxs)(m.MN, {
          ref: x,
          className: (0, a.$)(h().root, t2),
          "aria-label": T,
          explicitMarkComponent: s2.explicitDisclaimer && (0, r.jsx)(C.Nq, { getDescriptionTexts: s2.getDescriptionTexts, variant: s2.explicitDisclaimer }),
          title: (0, r.jsx)(p.Caption, {
            variant: "div",
            type: "entity",
            size: "s",
            weight: "medium",
            lineClamp: 2,
            ...(0, u.Am)(u.Kq.album.UPCOMING_ALBUM_TITLE),
            children: s2.title
          }),
          "data-intersection-property-id": P,
          ...(0, u.Am)(u.Kq.album.UPCOMING_ALBUM_CARD),
          contentLinesCount: y2,
          view: O,
          description: (0, r.jsx)(g.iQ, {
            className: h().artists,
            artists: s2.artists,
            lineClamp: 1,
            linkClassName: h().artistLink,
            captionSize: "s"
          }),
          children: [
            (0, r.jsx)(p.Caption, {
              className: h().releaseDate,
              variant: "div",
              type: "entity",
              size: "s",
              weight: "medium",
              lineClamp: 1,
              ...(0, u.Am)(u.Kq.album.UPCOMING_ALBUM_RELEASE_DATE),
              children: (0, r.jsx)(o.A, {
                id: "entity-names.upcoming-album-date",
                values: { releaseDate: N(s2.releaseDate, (0, A.sDH)()) }
              })
            }),
            i2
          ]
        });
      });
    },
    49423: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "Chart_root__ODed_",
        position: "Chart_position__7UNY9",
        position_disliked: "Chart_position_disliked__HzjC7",
        position_disabled: "Chart_position_disabled__poZzD",
        progress: "Chart_progress__sGj4s",
        progress_up: "Chart_progress_up__y083c",
        progress_same: "Chart_progress_same__Cnbdb",
        progress_down: "Chart_progress_down__lv_ae",
        progress_crown: "Chart_progress_crown__o__Zm",
        progress_new: "Chart_progress_new__7DobI",
        progress_disliked: "Chart_progress_disliked__maVAk",
        progress_disabled: "Chart_progress_disabled__JoFqG"
      };
    },
    50118: (e, t, i) => {
      "use strict";
      i.d(t, { z: () => r });
      var r = (function(e2) {
        return e2.PAGE = "PAGE", e2.CARD = "CARD", e2;
      })({});
    },
    51672: (e, t, i) => {
      "use strict";
      i.d(t, { AlbumEntityNameConsumer: () => l, useAlbumEntityName: () => n });
      var r = i(61910), a = i(43426), s = i(15099), l = (function(e2) {
        return e2.PIN = "pin", e2;
      })({});
      let n = (e2, t2) => {
        let { formatMessage: i2 } = (0, a.A)();
        return (0, r.useMemo)(() => {
          switch (e2) {
            case s._.SINGLE:
              return i2({ id: "entity-names.single" });
            case s._.PODCAST:
              return i2({ id: "entity-names.podcast" });
            case s._.AUDIOBOOK:
              if ("pin" === t2) return i2({ id: "entity-names.book" });
              return i2({ id: "entity-names.audio" });
            case s._.FAIRY_TALE:
              return i2({ id: "entity-names.fairy-tale" });
            default:
              return i2({ id: "entity-names.album" });
          }
        }, [e2, i2, t2]);
      };
    },
    56096: (e) => {
      e.exports = {
        root: "UpcomingAlbumCard_root__lSZ5l",
        controls: "UpcomingAlbumCard_controls__fQ50f",
        cover: "UpcomingAlbumCard_cover__qvU1m",
        image: "UpcomingAlbumCard_image__WKtGR",
        releaseDate: "UpcomingAlbumCard_releaseDate__EvDzB",
        artists: "UpcomingAlbumCard_artists__Jp1OE",
        artistLink: "UpcomingAlbumCard_artistLink__RSqXw",
        control: "UpcomingAlbumCard_control__pSMdI",
        presaveButton: "UpcomingAlbumCard_presaveButton__ixwy_",
        lockButton: "UpcomingAlbumCard_lockButton__9_qyp",
        lockIcon: "UpcomingAlbumCard_lockIcon__wtvkP"
      };
    },
    60423: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { _: () => r }), (function(e2) {
        e2.UP = "up", e2.DOWN = "down", e2.SAME = "same", e2.NEW = "new";
      })(r || (r = {}));
    },
    63449: (e, t, i) => {
      "use strict";
      i.d(t, { useMarkAlbumListenedClick: () => u });
      var r = i(54486), a = i(61910), s = i(43426), l = i(58623), n = i(74125), o = i(80585);
      let u = () => {
        let { user: e2, album: t2, fullscreenPlayer: i2 } = (0, n.Pjs)(), { notify: u2 } = (0, n.lkh)(), { formatMessage: c } = (0, s.A)();
        return (0, a.useCallback)(async () => {
          var a2, s2;
          if (!t2) return;
          let d = i2.modal.isOpened ? n.uQT.FULLSCREEN_ERROR : n.uQT.ERROR;
          return e2.isAuthorized ? await t2.setListeningFinishedStatus() !== l.T.OK ? void u2((0, r.jsx)(o.hT, { error: c({ id: "error-messages.error-during-action" }) }), { containerId: d }) : void (null == (s2 = t2.meta) || s2.updateFinished(!(null == (a2 = t2.meta) ? void 0 : a2.listeningFinished))) : void u2((0, r.jsx)(o.hT, { error: c({ id: "authorization-messages.need-to-authorizate" }) }), {
            containerId: d
          });
        }, [c, u2, t2, e2.isAuthorized, i2.modal.isOpened]);
      };
    },
    65134: (e, t, i) => {
      "use strict";
      i.d(t, { useNavigateToAlbumCPA: () => s });
      var r = i(8817), a = i(74125);
      let s = (e2) => {
        let { albumId: t2, albumUrl: i2, callback: s2 } = e2, { getAlbumUrlWithSavedClid: l, checkIsCurrentAlbumPage: n } = (0, a.IQF)(), o = (0, a.pqZ)();
        return (0, r.c)((e3) => {
          if (!t2 || !i2) {
            null == s2 || s2(e3);
            return;
          }
          if (n(t2)) {
            null == e3 || e3.preventDefault(), o(l(t2, i2));
            return;
          }
          null == s2 || s2(e3);
        });
      };
    },
    69536: (e, t, i) => {
      "use strict";
      i.r(t), i.d(t, { AlbumCard: () => T });
      var r = i(54486), a = i(50420), s = i(28303), l = i(61910), n = i(43426), o = i(43350), u = i(31500), c = i(63585), d = i(15099), m = i(8817), b = i(27510), v = i(77881), p = i(71712), _ = i(5956), g = i(6971), A = i(97800), C = i(46423), y = i(63695), h = i(42140), k = i(74125), x = i(80585), P = i(50118);
      let f = { mainAxis: -26, alignmentAxis: -16 }, N = {
        isEnabled: true,
        width: 20,
        height: 8,
        tipRadius: 2,
        fill: "var(--ym-background-color-primary-enabled-tooltip)"
      };
      var L = i(11472), K = i(82516), I = i.n(K);
      let T = (0, s.PA)((e2) => {
        let {
          className: t2,
          children: i2,
          album: s2,
          contentLinesCount: K2,
          withLikesCount: T2,
          withChart: O,
          withAddition: j = true,
          withArtistName: M = true,
          releaseDateFormatter: U = k.sDH
        } = e2, { ref: B, intersectionPropertyId: w } = (0, k.nMI)(), {
          user: R,
          trailer: E,
          settings: { isMobile: S },
          albumCPA: { isPlusCPAEnabled: z },
          experiments: D
        } = (0, k.Pjs)(), { from: F, utmLink: $ } = (0, k.fyy)({ contextId: s2.id, contextType: c.K.Album, utmForPageIds: s2.artistIds }), { formatMessage: Q, formatDate: q } = (0, n.A)(), { sendLikeSearchFeedback: G, sendNavigateSearchFeedback: H, sendPlaySearchFeedback: V } = (0, k.zEv)(), [W, Y] = (0, l.useState)(false), [Z, J] = (0, l.useState)(false), [X, ee] = (0, l.useState)(false), et = (0, k.NKK)(), ei = (0, k.brA)(), er = (0, C.KX)(s2), ea = (0, C.A7)(s2), es = (0, k.ZpR)(s2.url), [el, en] = (0, l.useState)(false), eo = (0, k.Ftl)(), [eu, ec] = (0, l.useState)(false), ed = (0, k.PT7)(), { pageAlbumId: em } = (0, k.THB)(), eb = z({ pageAlbumId: em, albumId: s2.id, isNonMusic: s2.isNonMusic }), ev = s2.isAvailableOnlyForPlus && !s2.isUnsafeLegal && !s2.isLegalRejected, ep = ev && !S, e_ = s2.isAvailable || ep || s2.isAudiobook, eg = (0, l.useId)(), eA = (0, k.ZpR)(
          "https://music.yandex.ru/promo/lt-pay-promo/?get-plus=1&utm_source=music&utm_medium=non_music_tab&utm_campaign=web_music_birthday"
        ), eC = (0, m.c)((e3) => {
          if (e3.stopPropagation(), ed()) return void e3.preventDefault();
          E.openAlbumTrailer(s2.id), eo(o.ky.Album, String(s2.id));
        }), ey = s2.type === d._.SINGLE ? Q({ id: "entity-names.single" }) : void 0, eh = s2.releaseDate ? q(s2.releaseDate, U()) : void 0, ek = (0, k.daX)([null != eh ? eh : s2.year, ey]), ex = (0, C.r_)(s2.type), eP = (0, l.useMemo)(() => {
          var e3;
          let t3 = s2.isLiked ? Q({ id: "entity-names.has-your-like" }) : "";
          return "".concat(ex, " ").concat(s2.title, " ").concat(null != (e3 = s2.version) ? e3 : "", " ").concat(t3);
        }, [ex, Q, s2.title, s2.isLiked, s2.version]), { isPlaying: ef, togglePlay: eN } = (0, k.Dx4)({
          playContextParams: {
            contextData: { type: c.K.Album, meta: { id: s2.id }, from: F, utmLink: $ },
            loadContextMeta: true
          }
        }), eL = (0, C.cp)({ album: s2, callback: es }), eK = (0, C.cp)({ album: s2, callback: eN }), eI = (0, m.c)((e3) => {
          et({ to: o.QT.AlbumScreen }), null == H || H(), eL(e3);
        }), eT = (0, m.c)(() => {
          ed() || (Z || ef || (J(true), null == V || V()), eK(), ei(!ef));
        }), eO = (0, m.c)(() => {
          W || s2.isLiked || (Y(true), null == G || G()), er();
        }), ej = (0, m.c)((e3) => {
          ee(e3), en(e3);
        }), eM = (0, l.useMemo)(() => {
          var e3;
          return (0, r.jsxs)(A.Caption, {
            className: (0, a.$)(I().title, { [I().title_withVersion]: s2.version, [I().title_withChart]: O }),
            variant: "div",
            type: "entity",
            size: "s",
            weight: "medium",
            lineClamp: 2,
            ...(0, u.Am)(u.Kq.album.ALBUM_TITLE),
            children: [
              (0, r.jsx)(x.N_, {
                "aria-label": "".concat(s2.title, " ").concat(null != (e3 = s2.version) ? e3 : ""),
                className: I().titleLink,
                href: s2.url,
                onClick: eI,
                ...(0, u.Am)(u.Kq.album.ALBUM_TITLE_LINK),
                children: s2.title
              }),
              s2.version && (0, r.jsx)(A.Caption, {
                className: I().version,
                variant: "span",
                ...(0, u.Am)(u.Kq.album.ALBUM_VERSION),
                children: " ".concat(s2.version)
              })
            ]
          });
        }, [s2.title, s2.url, s2.version, eI, O]), eU = (0, l.useMemo)(() => {
          var e3;
          return (0, r.jsx)(x.N_, {
            href: s2.url,
            onClick: eI,
            children: "".concat(s2.title, " ").concat(null != (e3 = s2.version) ? e3 : "")
          });
        }, [s2.title, s2.url, s2.version, eI]), eB = (0, l.useMemo)(() => {
          var e3;
          if (null == s2 || null == (e3 = s2.trailer) ? void 0 : e3.isAvailable)
            return (0, r.jsx)(
              x.nE,
              {
                children: (0, r.jsx)(
                  x.kJ,
                  {
                    className: (0, a.$)(I().trailerButton, I().control),
                    radius: "round",
                    size: "s",
                    iconSize: "xxs",
                    onClick: eC
                  },
                  s2.getKey("TrailerButton")
                )
              },
              s2.getKey("AlbumCardTrailerTooltip")
            );
        }, [s2, eC]), ew = (0, l.useMemo)(
          () => (0, r.jsx)(
            L.AlbumContextMenu,
            {
              album: s2,
              onOpenChange: ej,
              open: X,
              className: (0, a.$)(I().menuButton, I().control),
              icon: (0, r.jsx)(_.Icon, { size: "xxs", variant: "more" }),
              size: "s",
              variant: P.z.CARD,
              ...(0, u.Am)(u.Kq.album.ALBUM_CONTEXT_MENU_BUTTON)
            },
            s2.getKey("AlbumContextMenu")
          ),
          [s2, ej, X]
        ), eR = (0, l.useCallback)(
          () => (0, r.jsx)(
            x.DM,
            {
              className: (0, a.$)(I().playButton, I().control),
              buttonVariant: "default",
              withHover: false,
              iconSize: "xl",
              variant: "filled",
              onClick: eT,
              isPlaying: ef,
              disabled: ep
            },
            s2.getKey("PlayButton")
          ),
          [ep, s2, ef, eT]
        ), eE = (0, b.L)(
          () => (0, r.jsx)(
            v.$,
            {
              role: "link",
              color: "plus",
              size: "xxs",
              radius: "xxxl",
              onClick: eA,
              children: (0, r.jsx)(A.Caption, {
                variant: "div",
                size: "m",
                children: Q({ id: "payment.try-button" })
              })
            },
            eg
          )
        ), eS = (0, l.useMemo)(
          () => ep && R.hasPlus && D.checkExperiment(k.zal.WebNextPlusLandingLink, "on") ? (0, r.jsx)(x.SU, {
            className: I().buyPlusPopover,
            buttonText: Q({ id: "interface-actions.more-details" }),
            isNested: true,
            placement: "top-start",
            isOpened: eu,
            onOpenChange: ec,
            textVariant: "album",
            albumTextVariant: s2.type,
            arrowProps: N,
            offsetOptions: f,
            renderChildren: eR,
            customButtons: [eE]
          }) : ep ? (0, r.jsx)(x.SU, {
            className: I().buyPlusPopover,
            buttonText: Q({ id: "interface-actions.more-details" }),
            isNested: true,
            placement: "top-start",
            isOpened: eu,
            onOpenChange: ec,
            textVariant: "album",
            albumTextVariant: s2.type,
            arrowProps: N,
            offsetOptions: f,
            renderChildren: eR
          }) : eR(),
          [ep, eu, ec, Q, eR, s2.type, eE, D, R.hasPlus]
        ), ez = (0, b.L)(() => {
          if (ep) return;
          let e3 = !eb && !R.isAuthorized;
          return (0, r.jsx)(
            x.cy,
            {
              className: (0, a.$)(I().likeButton, I().control),
              isLiked: s2.isLiked,
              onClick: eO,
              variant: "default",
              size: "s",
              iconSize: "xxs",
              disabled: e3
            },
            s2.getKey("LikeButton")
          );
        }), eD = (0, l.useMemo)(() => {
          if (!ep)
            return (0, r.jsx)(
              x.O0,
              {
                onClick: ea,
                isPinned: s2.isPinned,
                className: (0, a.$)(I().pinButton, I().control),
                withRipple: false,
                isDisabled: ep
              },
              s2.getKey("PinButton")
            );
        }, [s2, ep, ea]), eF = (0, l.useMemo)(() => {
          if (s2.isAvailable || ep)
            return (0, r.jsx)(p.hg, {
              isVisible: X || el || eu,
              className: I().controls,
              playControl: eS,
              likeControl: ez,
              menuControl: ew,
              pinControl: eD,
              trailerControl: eB
            });
        }, [s2, X, el, ew, eB, eu, eS, ez, eD, ep]), e$ = (0, l.useMemo)(
          () => (0, r.jsx)(g.Paper, {
            className: I().cover,
            radius: "s",
            withShadow: true,
            ...(0, u.Am)(u.Kq.album.ALBUM_CARD),
            children: (0, r.jsxs)("div", {
              className: I().coverBlock,
              onClick: eI,
              children: [
                (0, r.jsx)(x.BW, {
                  className: I().image,
                  src: s2.coverUri,
                  size: 200,
                  fit: "cover",
                  alt: eP,
                  withAvatarReplace: true,
                  isAvailable: e_,
                  "aria-hidden": true
                }),
                ev && (0, r.jsx)(_.Icon, { variant: "plusBadge", className: I().plusBadge }),
                eF
              ]
            })
          }),
          [eI, s2.coverUri, e_, eP, eF, ev]
        );
        return (0, r.jsxs)(p.MN, {
          ref: B,
          className: (0, a.$)(I().root, { [I().root_withChart]: O }, t2),
          "aria-label": eP,
          explicitMarkComponent: s2.explicitDisclaimer && (0, r.jsx)(
            x.Nq,
            {
              className: I().explicitMark,
              getDescriptionTexts: s2.getDescriptionTexts,
              variant: s2.explicitDisclaimer
            },
            s2.getKey("AlbumCardExplicitMarkIcon")
          ),
          title: eM,
          srTitle: eU,
          "data-intersection-property-id": w,
          contentLinesCount: K2,
          view: e$,
          description: M && (0, r.jsx)(
            y.iQ,
            {
              className: I().artists,
              artists: s2.artists,
              lineClamp: 1,
              linkClassName: I().artistLink,
              captionSize: "s"
            },
            s2.getKey("description")
          ),
          chart: O && s2.chart && (0, r.jsx)(
            h.t1,
            { withIcon: true, className: I().chart, position: s2.chart.position, progress: s2.chart.progress },
            s2.getKey("chart")
          ),
          ...(0, u.Am)(u.Kq.album.ALBUM_ITEM),
          children: [
            j && ek && (0, r.jsx)(A.Caption, {
              className: I().addition,
              variant: "div",
              type: "entity",
              size: "s",
              weight: "medium",
              lineClamp: 1,
              children: ek
            }),
            T2 && !!s2.actualLikesCount && (0, r.jsx)(x.xW, {
              className: I().likeTextButton,
              ariaLabel: Q({ id: "entity-names.likes-counter" }, { counter: s2.actualLikesCount }),
              likesCount: s2.actualLikesCount,
              isLiked: s2.isLiked,
              handleLikeClick: er
            }),
            i2
          ]
        });
      });
    },
    71020: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { J: () => r }), (function(e2) {
        e2.OK = "ok", e2.ERROR = "error";
      })(r || (r = {}));
    },
    77163: (e, t, i) => {
      "use strict";
      i.d(t, { useOnPresaveClick: () => d });
      var r = i(54486), a = i(63930), s = i(61910), l = i(43426), n = i(71020), o = i(74125), u = i(80585);
      let c = (e2) => {
        let { upcomingAlbum: t2, closeToast: i2 } = e2;
        return (0, r.jsx)(u.Pv, {
          closeToast: i2,
          albumTitle: t2.title,
          coverUri: t2.coverUri,
          entityTitle: t2.title,
          isPresave: t2.isPresave
        });
      }, d = (e2) => {
        let { user: t2 } = (0, o.Pjs)(), { notify: i2 } = (0, o.lkh)(), [d2, m] = (0, s.useState)(false), { formatMessage: b } = (0, l.A)();
        return (0, s.useCallback)(async () => {
          if (!t2.isAuthorized)
            return void i2((0, r.jsx)(u.hT, { error: b({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: o.uQT.ERROR
            });
          if (d2) return;
          let s2 = { ...(0, a.HO)(e2), isPresave: !e2.isPresave };
          m(true);
          let l2 = await e2.toggleLike();
          m(false), l2 === n.J.OK ? i2((0, r.jsx)(c, { upcomingAlbum: s2 }), { containerId: o.uQT.INFO }) : i2((0, r.jsx)(u.hT, { error: b({ id: "error-messages.error-during-action" }) }), {
            containerId: o.uQT.ERROR
          });
        }, [t2.isAuthorized, d2, e2, i2, b]);
      };
    },
    82516: (e) => {
      e.exports = {
        root: "AlbumCard_root__vP6k4",
        root_withChart: "AlbumCard_root_withChart__J2SZv",
        artists: "AlbumCard_artists__phKco",
        likeTextButton: "AlbumCard_likeTextButton__2AQd9",
        controls: "AlbumCard_controls__yuO40",
        cover: "AlbumCard_cover__zXmdl",
        coverBlock: "AlbumCard_coverBlock__94ZzY",
        image: "AlbumCard_image__Mm55s",
        titleLink: "AlbumCard_titleLink__u_WLG",
        title: "AlbumCard_title__8YvhT",
        title_withVersion: "AlbumCard_title_withVersion__NClAp",
        title_withChart: "AlbumCard_title_withChart__PVOiJ",
        chart: "AlbumCard_chart__gASdj",
        version: "AlbumCard_version__h2aJz",
        artistLink: "AlbumCard_artistLink__uPR_2",
        playButton: "AlbumCard_playButton__mYK9R",
        likeButton: "AlbumCard_likeButton__9B9C0",
        menuButton: "AlbumCard_menuButton__pxkA6",
        pinButton: "AlbumCard_pinButton__Mdi_E",
        trailerButton: "AlbumCard_trailerButton__typHh",
        control: "AlbumCard_control__qx7Xh",
        plusBadge: "AlbumCard_plusBadge__i0FkP",
        buyPlusPopover: "AlbumCard_buyPlusPopover__Kb79C"
      };
    },
    93729: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { E: () => r }), (function(e2) {
        e2.KIDS = "kids", e2.BOOKMATE = "bookmate";
      })(r || (r = {}));
    },
    94376: (e, t, i) => {
      "use strict";
      i.d(t, {
        aX: () => h.AlbumCard,
        kz: () => k.AlbumContextMenu,
        zh: () => r.z,
        JC: () => C,
        pZ: () => L,
        M_: () => K.HorizontalAlbumCard,
        M3: () => I.UpcomingAlbumCard,
        VH: () => y,
        fO: () => s,
        pp: () => o,
        bl: () => c,
        sK: () => m,
        EV: () => b,
        h: () => v,
        yb: () => g,
        lO: () => A
      });
      var r = i(50118), a = i(63695);
      let s = (e2) => {
        var t2;
        if (!e2)
          return {
            id: 0,
            title: "",
            availableForOptions: [],
            availableForPremiumUsers: true,
            artists: [],
            volumes: [],
            ogImage: "",
            availablePartially: false,
            trackCount: 0,
            recent: false,
            veryImportant: false,
            labels: [],
            metaType: "",
            availableForMobile: true
          };
        let i2 = (null == (t2 = e2.artists) ? void 0 : t2.map((e3) => (0, a.NE)(e3))) || [];
        return {
          id: e2.id,
          title: e2.title,
          type: e2.type,
          coverUri: e2.coverUri,
          year: e2.year,
          version: e2.version,
          availableForOptions: e2.availableForOptions || [],
          availableForPremiumUsers: e2.availableForPremiumUsers || true,
          artists: i2,
          volumes: [],
          ogImage: e2.coverUri || "",
          availablePartially: false,
          trackCount: e2.trackCount || 0,
          recent: false,
          veryImportant: false,
          labels: [],
          metaType: "",
          availableForMobile: true
        };
      };
      var l = i(93064), n = i(46423);
      let o = (e2) => {
        let t2 = e2.artists.map((e3) => (0, a.dM)(e3));
        return (0, l.wg)({ ...(0, n.e7)(e2), artists: t2 });
      };
      var u = i(42140);
      let c = (e2, t2) => (0, l.wg)({ ...o(e2), chart: t2 && (0, u.ws)(t2) });
      var d = i(74125);
      let m = (e2) => {
        var t2, i2;
        let {
          album: r2,
          artists: s2,
          bookmateOptionRequired: n2,
          chart: o2,
          likesCount: u2,
          trailer: c2,
          releaseYear: m2,
          releaseDate: b2
        } = e2, { available: v2, disclaimers: p2 } = (0, d.fyr)(r2);
        return (0, l.wg)({
          id: r2.id,
          title: r2.title,
          coverUri: null == (t2 = r2.cover) ? void 0 : t2.uri,
          type: r2.albumType,
          disclaimers: p2,
          artists: null == s2 ? void 0 : s2.map((e3) => (0, a.as)({ artist: e3 })),
          averageColor: null == (i2 = r2.cover) ? void 0 : i2.color,
          isAvailable: v2,
          likesCount: u2,
          bookmateOptionRequired: n2,
          chart: o2,
          trailer: (0, d.mxW)(c2),
          listeningFinished: r2.listeningFinished,
          year: m2 ? Number(m2) : void 0,
          releaseDate: b2
        });
      }, b = (e2) => {
        let { album: t2, artists: i2, likesCount: r2, chart: a2 } = e2;
        return (0, l.wg)({ ...m({ album: t2, artists: i2, likesCount: r2 }), chart: a2 && (0, u.ws)(a2) });
      }, v = (e2) => {
        var t2;
        let { album: i2, artists: r2, releaseDate: s2, isPresave: n2 } = e2, { disclaimers: o2 } = (0, d.fyr)(i2);
        return (0, l.wg)({
          id: i2.id,
          title: i2.title,
          type: i2.albumType,
          coverUri: null == (t2 = i2.cover) ? void 0 : t2.uri,
          isPresave: n2,
          releaseDate: s2,
          disclaimers: o2,
          artists: null == r2 ? void 0 : r2.map((e3) => (0, a.as)({ artist: e3 }))
        });
      };
      var p = i(97396), _ = i(61910);
      let g = (e2) => {
        let { searchParams: t2 = {} } = e2;
        return "bandlink" === t2[d.K3F.UTM_SOURCE] || !!t2[d.K3F.CLID] || !!t2[d.K3F.REF_ID];
      };
      (0, _.cache)(async function(e2) {
        var t2;
        let i2;
        arguments.length > 1 && void 0 !== arguments[1] && arguments[1], (0, d.LLJ)(e2) || (0, p.notFound)();
        try {
          let {
            container: t3,
            backendHostTld: r2,
            locale: a2,
            host: s2,
            fullUrl: l2,
            isRSC: n2,
            requestUrl: o2,
            referer: u2
          } = await (0, d.IhE)();
          if (n2) return { album: void 0, backendHostTld: r2, locale: a2, host: s2, fullUrl: l2, requestUrl: o2 };
          let c2 = t3.get(d.tzI).getAlbumWithTracksIds({ albumId: Number(e2), resumeStream: false }), [m2, b2] = await Promise.allSettled([c2]);
          if (!m2 || "fulfilled" !== m2.status) return (0, d.tfF)(m2.reason, () => ({ album: void 0, ...(0, d.Bj3)() }));
          {
            let e3 = (null == b2 ? void 0 : b2.status) === "fulfilled" && b2.value ? b2.value.id : null;
            i2 = { album: m2.value, backendHostTld: r2, locale: a2, host: s2, fullUrl: l2, requestUrl: o2, cpa: e3 };
          }
        } catch (e3) {
          return (0, d.tfF)(e3, () => ({ album: void 0, ...(0, d.Bj3)() }));
        }
        return (null == (t2 = i2.album) ? void 0 : t2.error) === "not-found" && (0, p.notFound)(), i2;
      }), (0, _.cache)(async (e2, t2) => {
        var i2;
        let r2;
        (0, d.LLJ)(e2) || (0, p.notFound)();
        try {
          let {
            container: i3,
            backendHostTld: a2,
            locale: s2,
            host: l2,
            fullUrl: n2,
            isRSC: o2,
            requestUrl: u2,
            referer: c2
          } = await (0, d.IhE)();
          if (o2)
            return { album: void 0, backendHostTld: a2, locale: s2, host: l2, fullUrl: n2, requestUrl: u2, isActive: false };
          let m2 = i3.get(d.tzI), b2 = i3.get(d.dh7), v2 = await b2.getPromoAlbumInfo({ albumId: Number(e2), campaignId: t2 });
          if (!v2.active)
            return { album: void 0, backendHostTld: a2, locale: s2, host: l2, fullUrl: n2, requestUrl: u2, isActive: false };
          let p2 = m2.getAlbumWithTracksIds({ albumId: Number(e2), resumeStream: false }), [_2, g2] = await Promise.allSettled([p2]);
          if (!_2 || "fulfilled" !== _2.status)
            return (0, d.tfF)(_2.reason, () => ({ album: void 0, isActive: false, ...(0, d.Bj3)() }));
          {
            let e3 = (null == g2 ? void 0 : g2.status) === "fulfilled" && g2.value ? g2.value.id : null;
            r2 = {
              album: _2.value,
              backendHostTld: a2,
              locale: s2,
              host: l2,
              fullUrl: n2,
              requestUrl: u2,
              isActive: true,
              artistId: v2.artistId || null,
              cpa: e3
            };
          }
        } catch (e3) {
          return (0, d.tfF)(e3, () => ({ album: void 0, isActive: false, ...(0, d.Bj3)() }));
        }
        return (null == (i2 = r2.album) ? void 0 : i2.error) === "not-found" && (0, p.notFound)(), r2;
      });
      let A = (e2) => {
        var t2;
        let i2 = null == (t2 = e2.artists) ? void 0 : t2.map((e3) => (0, a.as)({ artist: e3 }));
        return (0, l.wg)({ ...(0, n.G_)(e2), artists: i2 });
      }, C = n.GI.props({ artists: l.gK.maybe(l.gK.array(a.PK)), chart: l.gK.maybe(u.Iz) }).views((e2) => ({
        get artistNames() {
          var t2;
          return null == (t2 = e2.artists) ? void 0 : t2.map((e3) => e3.name).join(", ");
        },
        get artistName() {
          var i2, r2, a2, s2;
          if (null == (r2 = e2.artists) || null == (i2 = r2[0]) ? void 0 : i2.various) return;
          return null == (s2 = e2.artists) || null == (a2 = s2[0]) ? void 0 : a2.name;
        },
        get artistIds() {
          var l2;
          return null == (l2 = e2.artists) ? void 0 : l2.map((e3) => e3.id);
        },
        get artistId() {
          var n2, o2;
          return null == (o2 = e2.artists) || null == (n2 = o2[0]) ? void 0 : n2.id;
        }
      })), y = n.oM.props({ artists: l.gK.maybe(l.gK.array(a.PK)) }).views((e2) => ({
        get artistNames() {
          var t2;
          return null == (t2 = e2.artists) ? void 0 : t2.map((e3) => e3.name).join(", ");
        }
      }));
      var h = i(69536), k = i(11472), x = i(54486), P = i(43350), f = i(80585);
      let N = (e2) => {
        let {
          forwardRef: t2,
          isShimmerVisible: i2,
          isShimmerActive: r2,
          title: a2,
          description: s2,
          albums: l2,
          className: n2,
          containerClassName: o2,
          headerClassName: u2,
          viewAllActionLink: c2,
          headingRef: m2,
          headingVariant: b2,
          ...v2
        } = e2;
        return (0, x.jsx)(f.OY, {
          isShimmerVisible: i2,
          isShimmerActive: r2,
          className: n2,
          headerClassName: u2,
          containerClassName: o2,
          ref: t2,
          title: a2,
          description: s2,
          viewAllActionLink: c2,
          headingRef: m2,
          headingVariant: b2,
          ...v2,
          children: null == l2 ? void 0 : l2.map(
            (e3, t3) => (0, x.jsx)(
              d.Bki,
              {
                objectType: P.ky.Album,
                objectId: String(e3.id),
                objectPosX: t3 + 1,
                objectPosY: 1,
                objectsCount: l2.length,
                children: (0, x.jsx)(h.AlbumCard, {
                  album: e3,
                  contentLinesCount: 3,
                  withAddition: !e3.isNonMusic,
                  withLikesCount: e3.isNonMusic
                })
              },
              e3.id
            )
          )
        });
      }, L = (0, _.forwardRef)((e2, t2) => (0, x.jsx)(N, { forwardRef: t2, ...e2 }));
      var K = i(2438), I = i(46540);
    },
    94490: (e, t, i) => {
      "use strict";
      i.d(t, { f: () => v });
      var r = i(54486), a = i(63930), s = i(61910), l = i(43426), n = i(77534), o = i(8817), u = i(74125), c = i(80585), d = i(28303), m = i(2608);
      let b = (0, d.PA)((e2) => {
        let { album: t2, closeToast: i2, withLink: a2 } = e2, s2 = (0, m.b)(t2);
        return (0, r.jsx)(c.OM, {
          closeToast: i2,
          entityVariant: s2,
          coverUri: t2.coverUri,
          entityUrl: t2.url,
          collectionUrl: "/collection",
          entityTitle: t2.title,
          isLiked: t2.isLiked,
          withLink: a2
        });
      }), v = () => {
        let { notify: e2 } = (0, u.lkh)(), [t2, i2] = (0, s.useState)(false), { formatMessage: d2 } = (0, l.A)();
        return (0, o.c)(async (s2) => {
          let { album: l2, withLink: o2 = true, withNotification: m2 = true } = s2;
          if (t2) return;
          let v2 = { ...(0, a.HO)(l2), url: l2.url, isLiked: !l2.isLiked };
          i2(true);
          let p = await l2.toggleLike();
          i2(false), m2 && (p === n.f.OK ? e2((0, r.jsx)(b, { withLink: o2, album: v2 }), { containerId: u.uQT.INFO }) : e2((0, r.jsx)(c.hT, { error: d2({ id: "error-messages.error-during-action" }) }), {
            containerId: u.uQT.ERROR
          }));
        });
      };
    },
    96025: (e, t, i) => {
      "use strict";
      i.d(t, { useOnPromoLandingLikeClick: () => o });
      var r = i(97396), a = i(34132), s = i(8817), l = i(74125), n = i(94490);
      let o = (e2) => {
        let {
          user: t2,
          modals: { promoLandingBuySubscriptionModal: i2, crackdownModal: o2 },
          settings: { isMobile: u },
          paywall: c,
          albumCPA: { isPlusCPAEnabled: d },
          promolanding: m
        } = (0, l.Pjs)(), { isFreemium: b } = (0, l.XCI)(), v = (0, n.f)(), { pageAlbumId: p } = (0, l.THB)(), _ = (0, r.useSearchParams)();
        return (0, s.c)(async () => {
          if (d({ pageAlbumId: p, albumId: null == e2 ? void 0 : e2.id, isNonMusic: null == e2 ? void 0 : e2.isNonMusic }))
            return void c.openModal();
          if ((!b || (null == e2 ? void 0 : e2.isLiked) || (u ? i2.open() : o2.open()), t2.isAuthorized) && e2) {
            if (!e2.isLiked) {
              var r2, s2;
              m.sendLikeFeedback({
                reaction: a.g.LIKE,
                yclid: null != (r2 = _.get(l.K3F.YCLID)) ? r2 : "",
                campaignId: null != (s2 = _.get(l.K3F.UTM_CAMPAIGN)) ? s2 : ""
              });
            }
            return v({ album: e2, withLink: false, withNotification: t2.hasPlus });
          }
        });
      };
    },
    96819: (e, t, i) => {
      "use strict";
      i.d(t, { useOnLikeClick: () => u });
      var r = i(54486), a = i(43426), s = i(8817), l = i(74125), n = i(80585), o = i(94490);
      let u = (e2) => {
        let {
          user: t2,
          paywall: i2,
          albumCPA: { isPlusCPAEnabled: u2 }
        } = (0, l.Pjs)(), { formatMessage: c } = (0, a.A)(), { notify: d } = (0, l.lkh)(), m = (0, o.f)(), { pageAlbumId: b } = (0, l.THB)();
        return (0, s.c)(async () => {
          if (e2)
            return u2({ pageAlbumId: b, albumId: e2.id, isNonMusic: e2.isNonMusic }) ? void i2.openModal() : t2.isAuthorized ? m({ album: e2 }) : void d((0, r.jsx)(n.hT, { error: c({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: l.uQT.ERROR
            });
        });
      };
    }
  }
]);
