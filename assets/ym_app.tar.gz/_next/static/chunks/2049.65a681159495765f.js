"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2049],
  {
    52049: (e, t, r) => {
      var _a;
      let n;
      r.d(t, { domToBlob: () => eo });
      let a = "[modern-screenshot]", o = "undefined" != typeof window, l = o && "Worker" in window, i = o && "atob" in window;
      o && window;
      let s = o ? (_a = window.navigator) == null ? void 0 : _a.userAgent : "", c = s.includes("Chrome"), u = s.includes("AppleWebKit") && !c, d = s.includes("Firefox"), f = (e2) => 1 === e2.nodeType, g = (e2) => f(e2) && void 0 !== e2.style && "object" != typeof e2.className, m = (e2) => 8 === e2.nodeType, h = (e2) => "SLOT" === e2.tagName, w = (e2) => e2.startsWith("data:");
      function p(e2, t2) {
        if (e2.match(/^[a-z]+:\/\//i)) return e2;
        if (o && e2.match(/^\/\//)) return window.location.protocol + e2;
        if (e2.match(/^[a-z]+:/i) || !o) return e2;
        let r2 = y().implementation.createHTMLDocument(), n2 = r2.createElement("base"), a2 = r2.createElement("a");
        return r2.head.appendChild(n2), r2.body.appendChild(a2), t2 && (n2.href = t2), a2.href = e2, a2.href;
      }
      function y(e2) {
        var _a2;
        return (_a2 = e2 && f(e2) ? e2 == null ? void 0 : e2.ownerDocument : e2) != null ? _a2 : window.document;
      }
      let b = "http://www.w3.org/2000/svg";
      async function S(e2, t2 = "image/png", r2 = 1) {
        try {
          return await new Promise((n2, a2) => {
            e2.toBlob(
              (e3) => {
                e3 ? n2(e3) : a2(Error("Blob is null"));
              },
              t2,
              r2
            );
          });
        } catch (n2) {
          if (i)
            return (function(e3) {
              var _a2, _b;
              let [t3, r3] = e3.split(","), n3 = (_b = (_a2 = t3.match(/data:(.+);/)) == null ? void 0 : _a2[1]) != null ? _b : void 0, a2 = window.atob(r3), o2 = a2.length, l2 = new Uint8Array(o2);
              for (let e4 = 0; e4 < o2; e4 += 1) l2[e4] = a2.charCodeAt(e4);
              return new Blob([l2], { type: n3 });
            })(e2.toDataURL(t2, r2));
          throw n2;
        }
      }
      function E(e2, t2) {
        return new Promise((r2, n2) => {
          let a2 = new FileReader();
          a2.onload = () => r2(a2.result), a2.onerror = () => n2(a2.error), a2.onabort = () => n2(Error(`Failed read blob to ${t2}`)), "dataUrl" === t2 ? a2.readAsDataURL(e2) : "arrayBuffer" === t2 && a2.readAsArrayBuffer(e2);
        });
      }
      let v = (e2) => E(e2, "dataUrl");
      function x(e2, t2) {
        let r2 = y(t2).createElement("img");
        return r2.decoding = "sync", r2.loading = "eager", r2.src = e2, r2;
      }
      function N(e2, t2) {
        return new Promise((r2) => {
          let { timeout: n2, ownerDocument: a2, onError: o2, onWarn: l2 } = t2 != null ? t2 : {}, i2 = "string" == typeof e2 ? x(e2, y(a2)) : e2, s2 = null, c2 = null;
          function u2() {
            r2(i2), s2 && clearTimeout(s2), c2 == null ? void 0 : c2();
          }
          if (n2 && (s2 = setTimeout(u2, n2)), "VIDEO" === i2.tagName) {
            let e3 = i2.currentSrc || i2.src;
            if (!e3) return i2.poster ? N(i2.poster, t2).then(r2) : u2();
            if (i2.readyState >= 2) return u2();
            let n3 = (t3) => {
              l2 == null ? void 0 : l2("Failed video load", e3, t3), o2 == null ? void 0 : o2(t3), u2();
            };
            c2 = () => {
              i2.removeEventListener("loadeddata", u2), i2.removeEventListener("error", n3);
            }, i2.addEventListener("loadeddata", u2, { once: true }), i2.addEventListener("error", n3, { once: true });
          } else {
            let e3 = "image" === i2.tagName ? i2.href.baseVal : i2.currentSrc || i2.src;
            if (!e3) return u2();
            let t3 = async () => {
              if ("IMG" === i2.tagName && "decode" in i2)
                try {
                  await i2.decode();
                } catch (t4) {
                  l2 == null ? void 0 : l2("Failed to decode image, trying to render anyway", i2.dataset.originalSrc || e3, t4);
                }
              u2();
            }, r3 = (t4) => {
              l2 == null ? void 0 : l2("Failed image load", i2.dataset.originalSrc || e3, t4), u2();
            };
            if ("IMG" === i2.tagName && i2.complete) return t3();
            c2 = () => {
              i2.removeEventListener("load", t3), i2.removeEventListener("error", r3);
            }, i2.addEventListener("load", t3, { once: true }), i2.addEventListener("error", r3, { once: true });
          }
        });
      }
      async function A(e2, t2) {
        g(e2) && ("IMG" === e2.tagName || "VIDEO" === e2.tagName ? await N(e2, t2) : await Promise.all(
          ["img", "video"].flatMap((r2) => Array.from(e2.querySelectorAll(r2)).map((e3) => N(e3, t2)))
        ));
      }
      let C = /* @__PURE__ */ (function() {
        let e2 = 0;
        return () => (e2 += 1, `u${`0000${(1679616 * Math.random() | 0).toString(36)}`.slice(-4)}${e2}`);
      })();
      function k(e2) {
        return e2 == null ? void 0 : e2.split(",").map((e3) => e3.trim().replace(/"|'/g, "").toLowerCase()).filter(Boolean);
      }
      let T = 0;
      async function D(e2, t2) {
        return e2 && "__CONTEXT__" in e2 ? e2 : $(e2, { ...t2, autoDestruct: true });
      }
      async function $(e2, t2) {
        var _a2, _b, _c, _d, _e;
        let { scale: r2 = 1, workerUrl: n2, workerNumber: i2 = 1 } = t2 || {}, s2 = !!(t2 == null ? void 0 : t2.debug), c2 = (_a2 = t2 == null ? void 0 : t2.features) != null ? _a2 : true, u2 = (_b = e2.ownerDocument) != null ? _b : o ? window.document : void 0, d2 = (_d = (_c = e2.ownerDocument) == null ? void 0 : _c.defaultView) != null ? _d : o ? window : void 0, g2 = /* @__PURE__ */ new Map(), m2 = {
          width: 0,
          height: 0,
          quality: 1,
          type: "image/png",
          scale: r2,
          backgroundColor: null,
          style: null,
          filter: null,
          maximumCanvasSize: 0,
          timeout: 3e4,
          progress: null,
          debug: s2,
          fetch: {
            requestInit: { cache: ((_e = t2 == null ? void 0 : t2.fetch) == null ? void 0 : _e.bypassingCache) ? "no-cache" : "force-cache" },
            placeholderImage: "data:image/png;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
            bypassingCache: false,
            ...t2 == null ? void 0 : t2.fetch
          },
          fetchFn: null,
          font: {},
          drawImageInterval: 100,
          workerUrl: null,
          workerNumber: i2,
          onCloneEachNode: null,
          onCloneNode: null,
          onEmbedNode: null,
          onCreateForeignObjectSvg: null,
          includeStyleProperties: null,
          autoDestruct: false,
          ...t2,
          __CONTEXT__: true,
          log: (function(e3) {
            let t3 = `${a}[#${T}]`;
            return T++, {
              time: (r3) => e3 && console.time(`${t3} ${r3}`),
              timeEnd: (r3) => e3 && console.timeEnd(`${t3} ${r3}`),
              warn: (...t4) => e3 && ((...e4) => console.warn(a, ...e4))(...t4)
            };
          })(s2),
          node: e2,
          ownerDocument: u2,
          ownerWindow: d2,
          dpi: 1 === r2 ? null : 96 * r2,
          svgStyleElement: I(u2),
          svgDefsElement: u2 == null ? void 0 : u2.createElementNS(b, "defs"),
          svgStyles: /* @__PURE__ */ new Map(),
          defaultComputedStyles: /* @__PURE__ */ new Map(),
          workers: [...Array.from({ length: l && n2 && i2 ? i2 : 0 })].map(() => {
            try {
              let e3 = new Worker(n2);
              return e3.onmessage = async (e4) => {
                var _a3, _b2, _c2, _d2;
                let { url: t3, result: r3 } = e4.data;
                r3 ? (_b2 = (_a3 = g2.get(t3)) == null ? void 0 : _a3.resolve) == null ? void 0 : _b2.call(_a3, r3) : (_d2 = (_c2 = g2.get(t3)) == null ? void 0 : _c2.reject) == null ? void 0 : _d2.call(_c2, Error(`Error receiving message from worker: ${t3}`));
              }, e3.onmessageerror = (e4) => {
                var _a3, _b2;
                let { url: t3 } = e4.data;
                (_b2 = (_a3 = g2.get(t3)) == null ? void 0 : _a3.reject) == null ? void 0 : _b2.call(_a3, Error(`Error receiving message from worker: ${t3}`));
              }, e3;
            } catch (e3) {
              return m2.log.warn("Failed to new Worker", e3), null;
            }
          }).filter(Boolean),
          fontFamilies: /* @__PURE__ */ new Map(),
          fontCssTexts: /* @__PURE__ */ new Map(),
          acceptOfImage: `${[
            (function(e3) {
              var _a3;
              let t3 = (_a3 = e3 == null ? void 0 : e3.createElement) == null ? void 0 : _a3.call(e3, "canvas");
              return t3 && (t3.height = t3.width = 1), !!t3 && "toDataURL" in t3 && !!t3.toDataURL("image/webp").includes("image/webp");
            })(u2) && "image/webp",
            "image/svg+xml",
            "image/*",
            "*/*"
          ].filter(Boolean).join(",")};q=0.8`,
          requests: g2,
          drawImageCount: 0,
          tasks: [],
          features: c2,
          isEnable: (e3) => {
            var _a3, _b2;
            return "restoreScrollPosition" === e3 ? "boolean" != typeof c2 && ((_a3 = c2[e3]) != null ? _a3 : false) : "boolean" == typeof c2 ? c2 : (_b2 = c2[e3]) != null ? _b2 : true;
          },
          shadowRoots: []
        };
        m2.log.time("wait until load"), await A(e2, { timeout: m2.timeout, onWarn: m2.log.warn }), m2.log.timeEnd("wait until load");
        let { width: h2, height: w2 } = (function(e3, t3) {
          let { width: r3, height: n3 } = t3;
          if (f(e3) && (!r3 || !n3)) {
            let t4 = e3.getBoundingClientRect();
            r3 = r3 || t4.width || Number(e3.getAttribute("width")) || 0, n3 = n3 || t4.height || Number(e3.getAttribute("height")) || 0;
          }
          return { width: r3, height: n3 };
        })(e2, m2);
        return m2.width = h2, m2.height = w2, m2;
      }
      function I(e2) {
        if (!e2) return;
        let t2 = e2.createElement("style"), r2 = t2.ownerDocument.createTextNode(`
.______background-clip--text {
  background-clip: text;
  -webkit-background-clip: text;
}
`);
        return t2.appendChild(r2), t2;
      }
      async function F(e2, t2) {
        let { log: r2, timeout: n2, drawImageCount: a2, drawImageInterval: o2 } = t2;
        r2.time("image to canvas");
        let l2 = await N(e2, { timeout: n2, onWarn: t2.log.warn }), { canvas: i2, context2d: s2 } = (function(e3, t3) {
          let { width: r3, height: n3, scale: a3, backgroundColor: o3, maximumCanvasSize: l3 } = t3, i3 = e3.createElement("canvas");
          i3.width = Math.floor(r3 * a3), i3.height = Math.floor(n3 * a3), i3.style.width = `${r3}px`, i3.style.height = `${n3}px`, l3 && (i3.width > l3 || i3.height > l3) && (i3.width > l3 && i3.height > l3 ? i3.width > i3.height ? (i3.height *= l3 / i3.width, i3.width = l3) : (i3.width *= l3 / i3.height, i3.height = l3) : i3.width > l3 ? (i3.height *= l3 / i3.width, i3.width = l3) : (i3.width *= l3 / i3.height, i3.height = l3));
          let s3 = i3.getContext("2d");
          return s3 && o3 && (s3.fillStyle = o3, s3.fillRect(0, 0, i3.width, i3.height)), { canvas: i3, context2d: s3 };
        })(e2.ownerDocument, t2), c2 = () => {
          try {
            s2 == null ? void 0 : s2.drawImage(l2, 0, 0, i2.width, i2.height);
          } catch (e3) {
            t2.log.warn("Failed to drawImage", e3);
          }
        };
        if (c2(), t2.isEnable("fixSvgXmlDecode"))
          for (let e3 = 0; e3 < a2; e3++)
            await new Promise((t3) => {
              setTimeout(() => {
                s2 == null ? void 0 : s2.clearRect(0, 0, i2.width, i2.height), c2(), t3();
              }, e3 + o2);
            });
        return t2.drawImageCount = 0, r2.timeEnd("image to canvas"), i2;
      }
      function P(e2, t2) {
        if (e2.ownerDocument)
          try {
            let t3 = e2.toDataURL();
            if ("data:," !== t3) return x(t3, e2.ownerDocument);
          } catch (e3) {
            t2.log.warn("Failed to clone canvas", e3);
          }
        let r2 = e2.cloneNode(false), n2 = e2.getContext("2d"), a2 = r2.getContext("2d");
        try {
          n2 && a2 && a2.putImageData(n2.getImageData(0, 0, e2.width, e2.height), 0, 0);
        } catch (e3) {
          t2.log.warn("Failed to clone canvas", e3);
        }
        return r2;
      }
      async function R(e2, t2) {
        if (e2.ownerDocument && !e2.currentSrc && e2.poster) return x(e2.poster, e2.ownerDocument);
        let r2 = e2.cloneNode(false);
        r2.crossOrigin = "anonymous", e2.currentSrc && e2.currentSrc !== e2.src && (r2.src = e2.currentSrc);
        let n2 = r2.ownerDocument;
        if (n2) {
          let a2 = true;
          if (await N(r2, { onError: () => a2 = false, onWarn: t2.log.warn }), !a2)
            return e2.poster ? x(e2.poster, e2.ownerDocument) : r2;
          r2.currentTime = e2.currentTime, await new Promise((e3) => {
            r2.addEventListener("seeked", e3, { once: true });
          });
          let o2 = n2.createElement("canvas");
          o2.width = e2.offsetWidth, o2.height = e2.offsetHeight;
          try {
            let e3 = o2.getContext("2d");
            e3 && e3.drawImage(r2, 0, 0, o2.width, o2.height);
          } catch (n3) {
            if (t2.log.warn("Failed to clone video", n3), e2.poster) return x(e2.poster, e2.ownerDocument);
            return r2;
          }
          return P(o2, t2);
        }
        return r2;
      }
      let _ = ["width", "height", "-webkit-text-fill-color"], M = ["stroke", "fill"];
      function B(e2, t2, r2) {
        let n2, a2, { defaultComputedStyles: o2 } = r2, l2 = e2.nodeName.toLowerCase(), i2 = "object" == typeof e2.className && "svg" !== l2, s2 = i2 ? M.map((t3) => [t3, e2.getAttribute(t3)]).filter(([, e3]) => null !== e3) : [], c2 = [i2 && "svg", l2, s2.map((e3, t3) => `${e3}=${t3}`).join(","), t2].filter(Boolean).join(":");
        if (o2.has(c2)) return o2.get(c2);
        let u2 = (function(e3) {
          let t3 = e3.sandbox;
          if (!t3) {
            let { ownerDocument: r3 } = e3;
            try {
              r3 && ((t3 = r3.createElement("iframe")).id = `__SANDBOX__${C()}`, t3.width = "0", t3.height = "0", t3.style.visibility = "hidden", t3.style.position = "fixed", r3.body.appendChild(t3), t3.srcdoc = '<!DOCTYPE html><meta charset="UTF-8"><title></title><body>', e3.sandbox = t3);
            } catch (t4) {
              e3.log.warn("Failed to getSandBox", t4);
            }
          }
          return t3;
        })(r2), d2 = u2 == null ? void 0 : u2.contentWindow;
        if (!d2) return /* @__PURE__ */ new Map();
        let f2 = d2 == null ? void 0 : d2.document;
        i2 ? (a2 = (n2 = f2.createElementNS(b, "svg")).ownerDocument.createElementNS(n2.namespaceURI, l2), s2.forEach(([e3, t3]) => {
          a2.setAttributeNS(null, e3, t3);
        }), n2.appendChild(a2)) : n2 = a2 = f2.createElement(l2), a2.textContent = " ", f2.body.appendChild(n2);
        let g2 = d2.getComputedStyle(a2, t2), m2 = /* @__PURE__ */ new Map();
        for (let e3 = g2.length, t3 = 0; t3 < e3; t3++) {
          let e4 = g2.item(t3);
          _.includes(e4) || m2.set(e4, g2.getPropertyValue(e4));
        }
        return f2.body.removeChild(n2), o2.set(c2, m2), m2;
      }
      function L(e2, t2, r2) {
        var _a2;
        let n2 = /* @__PURE__ */ new Map(), a2 = [], o2 = /* @__PURE__ */ new Map();
        if (r2) for (let e3 of r2) l2(e3);
        else for (let t3 = e2.length, r3 = 0; r3 < t3; r3++) l2(e2.item(r3));
        for (let e3 = a2.length, t3 = 0; t3 < e3; t3++) (_a2 = o2.get(a2[t3])) == null ? void 0 : _a2.forEach((e4, t4) => n2.set(t4, e4));
        function l2(r3) {
          let l3 = e2.getPropertyValue(r3), i2 = e2.getPropertyPriority(r3), s2 = r3.lastIndexOf("-"), c2 = s2 > -1 ? r3.substring(0, s2) : void 0;
          if (c2) {
            let e3 = o2.get(c2);
            e3 || (e3 = /* @__PURE__ */ new Map(), o2.set(c2, e3)), e3.set(r3, [l3, i2]);
          }
          (t2.get(r3) !== l3 || i2) && (c2 ? a2.push(c2) : n2.set(r3, [l3, i2]));
        }
        return n2;
      }
      let U = ["::before", "::after"], j = [
        "::-webkit-scrollbar",
        "::-webkit-scrollbar-button",
        "::-webkit-scrollbar-thumb",
        "::-webkit-scrollbar-track",
        "::-webkit-scrollbar-track-piece",
        "::-webkit-scrollbar-corner",
        "::-webkit-resizer"
      ], W = /* @__PURE__ */ new Set(["symbol"]);
      async function O(e2, t2, r2, n2, a2) {
        if (f(r2) && ("STYLE" === r2.tagName || "SCRIPT" === r2.tagName) || n2.filter && !n2.filter(r2)) return;
        W.has(t2.nodeName) || W.has(r2.nodeName) ? n2.currentParentNodeStyle = void 0 : n2.currentParentNodeStyle = n2.currentNodeStyle;
        let o2 = await q(r2, n2, false, a2);
        n2.isEnable("restoreScrollPosition") && (function(e3, t3) {
          if (!g(e3) || !g(t3)) return;
          let { scrollTop: r3, scrollLeft: n3 } = e3;
          if (!r3 && !n3) return;
          let { transform: a3 } = t3.style, o3 = new DOMMatrix(a3), { a: l2, b: i2, c: s2, d: c2 } = o3;
          o3.a = 1, o3.b = 0, o3.c = 0, o3.d = 1, o3.translateSelf(-n3, -r3), o3.a = l2, o3.b = i2, o3.c = s2, o3.d = c2, t3.style.transform = o3.toString();
        })(e2, o2), t2.appendChild(o2);
      }
      async function V(e2, t2, r2, n2) {
        var _a2;
        let a2 = e2.firstChild;
        f(e2) && e2.shadowRoot && (a2 = (_a2 = e2.shadowRoot) == null ? void 0 : _a2.firstChild, r2.shadowRoots.push(e2.shadowRoot));
        for (let o2 = a2; o2; o2 = o2.nextSibling)
          if (!m(o2))
            if (f(o2) && h(o2) && "function" == typeof o2.assignedNodes) {
              let a3 = o2.assignedNodes();
              for (let o3 = 0; o3 < a3.length; o3++) await O(e2, t2, a3[o3], r2, n2);
            } else await O(e2, t2, o2, r2, n2);
      }
      let z = /^[\w-:]+$/;
      async function q(e2, t2, r2 = false, n2) {
        var _a2, _b, _c, _d;
        let { ownerDocument: a2, ownerWindow: o2, fontFamilies: l2, onCloneEachNode: i2 } = t2;
        if (a2 && 3 === e2.nodeType) return n2 && /\S/.test(e2.data) && n2(e2.data), a2.createTextNode(e2.data);
        if (a2 && o2 && f(e2) && (g(e2) || "object" == typeof e2.className)) {
          let u2 = function(r3) {
            var _a3;
            let a4 = m2.getComputedStyle(e2, r3), o4 = a4.getPropertyValue("content");
            if (!o4 || "none" === o4) return;
            g2 == null ? void 0 : g2(o4), o4 = o4.replace(/(')|(")|(counter\(.+\))/g, "");
            let l3 = [C()], i3 = B(e2, r3, t2);
            p2 == null ? void 0 : p2.forEach((e3, t3) => {
              i3.delete(t3);
            });
            let s3 = L(a4, i3, t2.includeStyleProperties);
            s3.delete("content"), s3.delete("-webkit-locale"), ((_a3 = s3.get("background-clip")) == null ? void 0 : _a3[0]) === "text" && n3.classList.add("______background-clip--text");
            let c2 = [`content: '${o4}';`];
            if (s3.forEach(([e3, t3], r4) => {
              c2.push(`${r4}: ${e3}${t3 ? " !important" : ""};`);
            }), 1 === c2.length)
              return;
            try {
              n3.className = [n3.className, ...l3].join(" ");
            } catch (e3) {
              t2.log.warn("Failed to copyPseudoClass", e3);
              return;
            }
            let u3 = c2.join("\n  "), d4 = w2.get(u3);
            d4 || (d4 = [], w2.set(u3, d4)), d4.push(`.${l3[0]}${r3}`);
          };
          let n3 = await (function(e3, t3) {
            var _a3;
            if ("CANVAS" === e3.tagName) return P(e3, t3);
            if ("IFRAME" === e3.tagName) {
              try {
                if ((_a3 = e3 == null ? void 0 : e3.contentDocument) == null ? void 0 : _a3.body) return q(e3.contentDocument.body, t3);
              } catch (e4) {
                t3.log.warn("Failed to clone iframe", e4);
              }
              return e3.cloneNode(false);
            }
            if ("IMG" === e3.tagName) {
              let t4 = e3.cloneNode(false);
              return e3.currentSrc && e3.currentSrc !== e3.src && (t4.src = e3.currentSrc, t4.srcset = ""), "lazy" === t4.loading && (t4.loading = "eager"), t4;
            }
            return "VIDEO" === e3.tagName ? R(e3, t3) : e3.cloneNode(false);
          })(e2, t2);
          if (t2.isEnable("removeAbnormalAttributes")) {
            let e3 = n3.getAttributeNames();
            for (let t3 = e3.length, r3 = 0; r3 < t3; r3++) {
              let t4 = e3[r3];
              z.test(t4) || n3.removeAttribute(t4);
            }
          }
          let a3 = t2.currentNodeStyle = (function(e3, t3, r3, n4) {
            var _a3, _b2, _c2, _d2;
            let { ownerWindow: a4, includeStyleProperties: o4, currentParentNodeStyle: l3 } = n4, i3 = t3.style, s3 = a4.getComputedStyle(e3), u3 = B(e3, null, n4);
            l3 == null ? void 0 : l3.forEach((e4, t4) => {
              u3.delete(t4);
            });
            let d4 = L(s3, u3, o4);
            d4.delete("transition-property"), d4.delete("all"), d4.delete("d"), d4.delete("content"), r3 && (d4.delete("margin-top"), d4.delete("margin-right"), d4.delete("margin-bottom"), d4.delete("margin-left"), d4.delete("margin-block-start"), d4.delete("margin-block-end"), d4.delete("margin-inline-start"), d4.delete("margin-inline-end"), d4.set("box-sizing", ["border-box", ""])), ((_a3 = d4.get("background-clip")) == null ? void 0 : _a3[0]) === "text" && t3.classList.add("______background-clip--text"), c && (d4.has("font-kerning") || d4.set("font-kerning", ["normal", ""]), (((_b2 = d4.get("overflow-x")) == null ? void 0 : _b2[0]) === "hidden" || ((_c2 = d4.get("overflow-y")) == null ? void 0 : _c2[0]) === "hidden") && ((_d2 = d4.get("text-overflow")) == null ? void 0 : _d2[0]) === "ellipsis" && e3.scrollWidth === e3.clientWidth && d4.set("text-overflow", ["clip", ""]));
            for (let e4 = i3.length, t4 = 0; t4 < e4; t4++) i3.removeProperty(i3.item(t4));
            return d4.forEach(([e4, t4], r4) => {
              i3.setProperty(r4, e4, t4);
            }), d4;
          })(e2, n3, r2, t2);
          r2 && (function(e3, t3) {
            let { backgroundColor: r3, width: n4, height: a4, style: o4 } = t3, l3 = e3.style;
            if (r3 && l3.setProperty("background-color", r3, "important"), n4 && l3.setProperty("width", `${n4}px`, "important"), a4 && l3.setProperty("height", `${a4}px`, "important"), o4)
              for (let e4 in o4) l3[e4] = o4[e4];
          })(n3, t2);
          let o3 = false;
          if (t2.isEnable("copyScrollbar")) {
            let t3 = [(_a2 = a3.get("overflow-x")) == null ? void 0 : _a2[0], (_b = a3.get("overflow-y")) == null ? void 0 : _b[0]];
            o3 = t3.includes("scroll") || (t3.includes("auto") || t3.includes("overlay")) && (e2.scrollHeight > e2.clientHeight || e2.scrollWidth > e2.clientWidth);
          }
          let d3 = (_c = a3.get("text-transform")) == null ? void 0 : _c[0], f2 = k((_d = a3.get("font-family")) == null ? void 0 : _d[0]), g2 = f2 ? (e3) => {
            "uppercase" === d3 ? e3 = e3.toUpperCase() : "lowercase" === d3 ? e3 = e3.toLowerCase() : "capitalize" === d3 && (e3 = e3[0].toUpperCase() + e3.substring(1)), f2.forEach((t3) => {
              let r3 = l2.get(t3);
              r3 || l2.set(t3, r3 = /* @__PURE__ */ new Set()), e3.split("").forEach((e4) => r3.add(e4));
            });
          } : void 0;
          var s2 = o3;
          let { ownerWindow: m2, svgStyleElement: h2, svgStyles: w2, currentNodeStyle: p2 } = t2;
          return h2 && m2 && (U.forEach(u2), s2 && j.forEach(u2)), ("TEXTAREA" === e2.tagName || "INPUT" === e2.tagName || "SELECT" === e2.tagName) && n3.setAttribute("value", e2.value), "VIDEO" !== e2.tagName && await V(e2, n3, t2, g2), await (i2 == null ? void 0 : i2(n3)), n3;
        }
        let d2 = e2.cloneNode(false);
        return await V(e2, d2, t2), await (i2 == null ? void 0 : i2(d2)), d2;
      }
      function G(e2, t2) {
        let { url: r2, requestType: n2 = "text", responseType: a2 = "text", imageDom: o2 } = t2, l2 = r2, {
          timeout: i2,
          acceptOfImage: s2,
          requests: c2,
          fetchFn: f2,
          fetch: { requestInit: g2, bypassingCache: m2, placeholderImage: h2 },
          font: w2,
          workers: p2,
          fontFamilies: y2
        } = e2;
        "image" === n2 && (u || d) && e2.drawImageCount++;
        let b2 = c2.get(r2);
        if (!b2) {
          m2 && m2 instanceof RegExp && m2.test(l2) && (l2 += (/\?/.test(l2) ? "&" : "?") + (/* @__PURE__ */ new Date()).getTime());
          let t3 = n2.startsWith("font") && w2 && w2.minify, d2 = /* @__PURE__ */ new Set();
          t3 && n2.split(";")[1].split(",").forEach((e3) => {
            y2.has(e3) && y2.get(e3).forEach((e4) => d2.add(e4));
          });
          let S2 = t3 && d2.size, E2 = {
            url: l2,
            timeout: i2,
            responseType: S2 ? "arrayBuffer" : a2,
            headers: "image" === n2 ? { accept: s2 } : void 0,
            ...g2
          };
          (b2 = { type: n2, resolve: void 0, reject: void 0, response: null }).response = (async () => {
            if (f2 && "image" === n2) {
              let e4 = await f2(r2);
              if (e4) return e4;
            }
            if (!u && r2.startsWith("http") && p2.length)
              return new Promise((e4, t5) => {
                p2[c2.size & p2.length - 1].postMessage({ rawUrl: r2, ...E2 }), b2.resolve = e4, b2.reject = t5;
              });
            let { url: e3, timeout: t4, responseType: a3, ...o3 } = E2, l3 = new AbortController(), i3 = t4 ? setTimeout(() => l3.abort(), t4) : void 0;
            return fetch(e3, { signal: l3.signal, ...o3 }).then((e4) => {
              if (!e4.ok) throw Error("Failed fetch, not 2xx response", { cause: e4 });
              switch (a3) {
                case "arrayBuffer":
                  return e4.arrayBuffer();
                case "dataUrl":
                  return e4.blob().then(v);
                default:
                  return e4.text();
              }
            }).finally(() => clearTimeout(i3));
          })().catch((t4) => {
            if (c2.delete(r2), "image" === n2 && h2)
              return e2.log.warn("Failed to fetch image base64, trying to use placeholder image", l2), "string" == typeof h2 ? h2 : h2(o2);
            throw t4;
          }), c2.set(r2, b2);
        }
        return b2.response;
      }
      async function H(e2, t2, r2, n2) {
        if (!X(e2)) return e2;
        for (let [a2, o2] of (function(e3, t3) {
          let r3 = [];
          return e3.replace(Y, (e4, n3, a3) => (r3.push([a3, p(a3, t3)]), e4)), r3.filter(([e4]) => !w(e4));
        })(e2, t2))
          try {
            let t3 = await G(r2, { url: o2, requestType: n2 ? "image" : "text", responseType: "dataUrl" });
            e2 = e2.replace(
              (function(e3) {
                let t4 = e3.replace(/([.*+?^${}()|\[\]\/\\])/g, "\\$1");
                return RegExp(`(url\\(['"]?)(${t4})(['"]?\\))`, "g");
              })(a2),
              `$1${t3}$3`
            );
          } catch (e3) {
            r2.log.warn("Failed to fetch css data url", a2, e3);
          }
        return e2;
      }
      function X(e2) {
        return /url\((['"]?)([^'"]+?)\1\)/.test(e2);
      }
      let Y = /url\((['"]?)([^'"]+?)\1\)/g, K = [
        "background-image",
        "border-image-source",
        "-webkit-border-image",
        "-webkit-mask-image",
        "list-style-image"
      ];
      async function Q(e2, t2) {
        let { ownerDocument: r2, svgStyleElement: n2, fontFamilies: a2, fontCssTexts: o2, tasks: l2, font: i2 } = t2;
        if (r2 && n2 && a2.size)
          if (i2 && i2.cssText) {
            let e3 = er(i2.cssText, t2);
            n2.appendChild(
              r2.createTextNode(`${e3}
`)
            );
          } else {
            let e3 = Array.from(r2.styleSheets).filter((e4) => {
              try {
                return "cssRules" in e4 && !!e4.cssRules.length;
              } catch (r3) {
                return t2.log.warn(`Error while reading CSS rules from ${e4.href}`, r3), false;
              }
            });
            await Promise.all(
              e3.flatMap(
                (e4) => Array.from(e4.cssRules).map(async (r3, n3) => {
                  if ("CSSImportRule" === r3.constructor.name) {
                    let a3 = n3 + 1, o3 = r3.href, l3 = "";
                    try {
                      l3 = await G(t2, { url: o3, requestType: "text", responseType: "text" });
                    } catch (e5) {
                      t2.log.warn(`Error fetch remote css import from ${o3}`, e5);
                    }
                    for (let r4 of (function(e5) {
                      if (null == e5) return [];
                      let t3 = [], r5 = e5.replace(J, "");
                      for (; ; ) {
                        let e6 = Z.exec(r5);
                        if (!e6) break;
                        t3.push(e6[0]);
                      }
                      r5 = r5.replace(Z, "");
                      let n4 = /@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi, a4 = RegExp(
                        "((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})",
                        "gi"
                      );
                      for (; ; ) {
                        let e6 = n4.exec(r5);
                        if (e6) a4.lastIndex = n4.lastIndex;
                        else if (e6 = a4.exec(r5)) n4.lastIndex = a4.lastIndex;
                        else break;
                        t3.push(e6[0]);
                      }
                      return t3;
                    })(l3.replace(Y, (e5, t3, r5) => e5.replace(r5, p(r5, o3)))))
                      try {
                        e4.insertRule(r4, r4.startsWith("@import") ? a3 += 1 : e4.cssRules.length);
                      } catch (e5) {
                        t2.log.warn("Error inserting rule from remote css import", { rule: r4, error: e5 });
                      }
                  }
                })
              )
            ), e3.flatMap((e4) => Array.from(e4.cssRules)).filter(
              (e4) => {
                var _a2;
                return "CSSFontFaceRule" === e4.constructor.name && X(e4.style.getPropertyValue("src")) && ((_a2 = k(e4.style.getPropertyValue("font-family"))) == null ? void 0 : _a2.some((e5) => a2.has(e5)));
              }
            ).forEach((e4) => {
              let a3 = o2.get(e4.cssText);
              a3 ? n2.appendChild(
                r2.createTextNode(`${a3}
`)
              ) : l2.push(
                H(e4.cssText, e4.parentStyleSheet ? e4.parentStyleSheet.href : null, t2).then((a4) => {
                  a4 = er(a4, t2), o2.set(e4.cssText, a4), n2.appendChild(
                    r2.createTextNode(`${a4}
`)
                  );
                })
              );
            });
          }
      }
      let J = /(\/\*[\s\S]*?\*\/)/g, Z = /((@.*?keyframes [\s\S]*?){([\s\S]*?}\s*?)})/gi, ee = /url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g, et = /src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;
      function er(e2, t2) {
        let { font: r2 } = t2, n2 = r2 ? r2 == null ? void 0 : r2.preferredFormat : void 0;
        return n2 ? e2.replace(et, (e3) => {
          for (; ; ) {
            let [t3, , r3] = ee.exec(e3) || [];
            if (!r3) return "";
            if (r3 === n2) return `src: ${t3};`;
          }
        }) : e2;
      }
      async function en(e2, t2) {
        let r2 = await D(e2, t2);
        if (f(r2.node) && "object" == typeof r2.node.className) return r2.node;
        let {
          ownerDocument: n2,
          log: a2,
          tasks: o2,
          svgStyleElement: l2,
          svgDefsElement: i2,
          svgStyles: s2,
          font: c2,
          progress: m2,
          autoDestruct: h2,
          onCloneNode: p2,
          onEmbedNode: S2,
          onCreateForeignObjectSvg: E2
        } = r2;
        a2.time("clone node");
        let v2 = await q(r2.node, r2, true);
        if (l2 && n2) {
          let e3 = "";
          s2.forEach((t3, r3) => {
            e3 += `${t3.join(",\n")} {
  ${r3}
}
`;
          }), l2.appendChild(n2.createTextNode(e3));
        }
        a2.timeEnd("clone node"), await (p2 == null ? void 0 : p2(v2)), false !== c2 && f(v2) && (a2.time("embed web font"), await Q(v2, r2), a2.timeEnd("embed web font")), a2.time("embed node"), (function e3(t3, r3) {
          var n3;
          let { tasks: a3 } = r3;
          f(t3) && (("IMG" === t3.tagName || "image" === t3.tagName) && a3.push(
            ...(function(e4, t4) {
              if ("IMG" === e4.tagName) {
                let r4 = e4.currentSrc || e4.src;
                if (!w(r4))
                  return [
                    G(t4, { url: r4, imageDom: e4, requestType: "image", responseType: "dataUrl" }).then((t5) => {
                      t5 && (e4.srcset = "", e4.dataset.originalSrc = r4, e4.src = t5 || "");
                    })
                  ];
                (u || d) && t4.drawImageCount++;
              } else if ("object" == typeof e4.className && !w(e4.href.baseVal)) {
                let r4 = e4.href.baseVal;
                return [
                  G(t4, { url: r4, imageDom: e4, requestType: "image", responseType: "dataUrl" }).then((t5) => {
                    t5 && (e4.dataset.originalSrc = r4, e4.href.baseVal = t5 || "");
                  })
                ];
              }
              return [];
            })(t3, r3)
          ), "use" === t3.tagName && a3.push(
            ...(function(e4, t4) {
              var _a2;
              let { ownerDocument: r4, svgDefsElement: n4 } = t4, a4 = (_a2 = e4.getAttribute("href")) != null ? _a2 : e4.getAttribute("xlink:href");
              if (!a4) return [];
              let [o3, l3] = a4.split("#");
              if (l3) {
                let a5 = `#${l3}`, i3 = t4.shadowRoots.reduce(
                  (e5, t5) => e5 != null ? e5 : t5.querySelector(`svg ${a5}`),
                  r4 == null ? void 0 : r4.querySelector(`svg ${a5}`)
                );
                if (o3 && e4.setAttribute("href", a5), n4 == null ? void 0 : n4.querySelector(a5)) return [];
                if (i3) n4 == null ? void 0 : n4.appendChild(i3.cloneNode(true));
                else if (o3)
                  return [
                    G(t4, { url: o3, responseType: "text" }).then((e5) => {
                      n4 == null ? void 0 : n4.insertAdjacentHTML("beforeend", e5);
                    })
                  ];
              }
              return [];
            })(t3, r3)
          )), g(t3) && a3.push(
            ...(n3 = t3.style, K.map((e4) => {
              let t4 = n3.getPropertyValue(e4);
              return t4 && "none" !== t4 ? ((u || d) && r3.drawImageCount++, H(t4, null, r3, true).then((r4) => {
                r4 && t4 !== r4 && n3.setProperty(e4, r4, n3.getPropertyPriority(e4));
              })) : null;
            }).filter(Boolean))
          ), t3.childNodes.forEach((t4) => {
            e3(t4, r3);
          });
        })(v2, r2);
        let x2 = o2.length, N2 = 0, A2 = async () => {
          for (; ; ) {
            let e3 = o2.pop();
            if (!e3) break;
            try {
              await e3;
            } catch (e4) {
              r2.log.warn("Failed to run task", e4);
            }
            m2 == null ? void 0 : m2(++N2, x2);
          }
        };
        m2 == null ? void 0 : m2(N2, x2), await Promise.all([...Array.from({ length: 4 })].map(A2)), a2.timeEnd("embed node"), await (S2 == null ? void 0 : S2(v2));
        let C2 = (function(e3, t3) {
          let { width: r3, height: n3 } = t3, a3 = (function(e4, t4, r4) {
            let n4 = y(r4).createElementNS(b, "svg");
            return n4.setAttributeNS(null, "width", e4.toString()), n4.setAttributeNS(null, "height", t4.toString()), n4.setAttributeNS(null, "viewBox", `0 0 ${e4} ${t4}`), n4;
          })(r3, n3, e3.ownerDocument), o3 = a3.ownerDocument.createElementNS(a3.namespaceURI, "foreignObject");
          return o3.setAttributeNS(null, "x", "0%"), o3.setAttributeNS(null, "y", "0%"), o3.setAttributeNS(null, "width", "100%"), o3.setAttributeNS(null, "height", "100%"), o3.append(e3), a3.appendChild(o3), a3;
        })(v2, r2);
        return i2 && C2.insertBefore(i2, C2.children[0]), l2 && C2.insertBefore(l2, C2.children[0]), h2 && (function(e3) {
          if (e3.ownerDocument = void 0, e3.ownerWindow = void 0, e3.svgStyleElement = void 0, e3.svgDefsElement = void 0, e3.svgStyles.clear(), e3.defaultComputedStyles.clear(), e3.sandbox) {
            try {
              e3.sandbox.remove();
            } catch (t3) {
              e3.log.warn("Failed to destroyContext", t3);
            }
            e3.sandbox = void 0;
          }
          e3.workers = [], e3.fontFamilies.clear(), e3.fontCssTexts.clear(), e3.requests.clear(), e3.tasks = [], e3.shadowRoots = [];
        })(r2), await (E2 == null ? void 0 : E2(C2)), C2;
      }
      async function ea(e2, t2) {
        var _a2;
        var r2;
        let n2, a2 = await D(e2, t2), o2 = await en(a2), l2 = (r2 = a2.isEnable("removeControlCharacter"), n2 = new XMLSerializer().serializeToString(o2), r2 && (n2 = n2.replace(/[\u0000-\u0008\v\f\u000E-\u001F\uD800-\uDFFF\uFFFE\uFFFF]/gu, "")), `data:image/svg+xml;charset=utf-8,${encodeURIComponent(n2)}`);
        a2.autoDestruct || (a2.svgStyleElement = I(a2.ownerDocument), a2.svgDefsElement = (_a2 = a2.ownerDocument) == null ? void 0 : _a2.createElementNS(b, "defs"), a2.svgStyles.clear());
        let i2 = x(l2, o2.ownerDocument);
        return await F(i2, a2);
      }
      async function eo(e2, t2) {
        let r2 = await D(e2, t2), { log: a2, type: o2, quality: l2, dpi: i2 } = r2, s2 = await ea(r2);
        a2.time("canvas to blob");
        let c2 = await S(s2, o2, l2);
        if (["image/png", "image/jpeg"].includes(o2) && i2) {
          let e3 = new Uint8Array(await E(c2.slice(0, 33), "arrayBuffer"));
          if ("image/png" === o2)
            e3 = (function(e4, t3, r3 = false) {
              let a3 = new Uint8Array(13);
              t3 *= 39.3701, a3[0] = 112, a3[1] = 72, a3[2] = 89, a3[3] = 115, a3[4] = t3 >>> 24, a3[5] = t3 >>> 16, a3[6] = t3 >>> 8, a3[7] = 255 & t3, a3[8] = a3[4], a3[9] = a3[5], a3[10] = a3[6], a3[11] = a3[7], a3[12] = 1;
              let o3 = (function(e5) {
                let t4 = -1;
                n || (n = (function() {
                  let e6 = new Int32Array(256);
                  for (let t5 = 0; t5 < 256; t5++) {
                    let r4 = t5;
                    for (let e7 = 0; e7 < 8; e7++) r4 = 1 & r4 ? 3988292384 ^ r4 >>> 1 : r4 >>> 1;
                    e6[t5] = r4;
                  }
                  return e6;
                })());
                for (let r4 = 0; r4 < e5.length; r4++) t4 = n[(t4 ^ e5[r4]) & 255] ^ t4 >>> 8;
                return -1 ^ t4;
              })(a3), l3 = new Uint8Array(4);
              if (l3[0] = o3 >>> 24, l3[1] = o3 >>> 16, l3[2] = o3 >>> 8, l3[3] = 255 & o3, r3) {
                let t4 = (function(e5) {
                  let t5 = e5.length - 1;
                  for (let r4 = t5; r4 >= 4; r4--)
                    if (9 === e5[r4 - 4] && 112 === e5[r4 - 3] && 72 === e5[r4 - 2] && 89 === e5[r4 - 1] && 115 === e5[r4])
                      return r4 - 3;
                  return 0;
                })(e4);
                return e4.set(a3, t4), e4.set(l3, t4 + 13), e4;
              }
              {
                let t4 = new Uint8Array(4);
                t4[0] = 0, t4[1] = 0, t4[2] = 0, t4[3] = 9;
                let r4 = new Uint8Array(54);
                return r4.set(e4, 0), r4.set(t4, 33), r4.set(a3, 37), r4.set(l3, 50), r4;
              }
            })(e3, i2);
          else {
            var u2;
            "image/jpeg" === o2 && ((u2 = e3)[13] = 1, u2[14] = i2 >> 8, u2[15] = 255 & i2, u2[16] = i2 >> 8, u2[17] = 255 & i2, e3 = u2);
          }
          return a2.timeEnd("canvas to blob"), new Blob([e3, c2.slice(33)], { type: o2 });
        }
        return a2.timeEnd("canvas to blob"), c2;
      }
    }
  }
]);
