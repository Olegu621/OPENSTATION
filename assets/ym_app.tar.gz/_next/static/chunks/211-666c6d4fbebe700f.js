"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [211],
  {
    50211: (t, e, a) => {
      a.d(e, {
        rJ: () => _.ArtistAlbumsPage,
        GH: () => F.ArtistClipsPage,
        cC: () => B.ArtistConcertsPage,
        Sd: () => j.ArtistFamiliarPage,
        ZQ: () => J.ArtistPage,
        E: () => w,
        Wy: () => V.ArtistSimilarPage,
        fD: () => $.ArtistTracksPage
      }), a(8242), a(46310), a(30697), a(79190), a(71284), a(44034), a(20121), a(91280), a(50365);
      var r, i = a(93064), s = a(14287), o = a(12460), l = a(4542), n = a(94376), u = a(55616), d = a(65779), g = a(83909), c = a(21365), m = a(63695), p = a(77217), S = a(74125), N = a(26433);
      !(function(t2) {
        t2.DEFAULT = "default", t2.DONATION = "donation", t2.REWIND = "year-rewind";
      })(r || (r = {}));
      let v = /^https:\/\/tips\.yandex\.ru\//, E = (t2) => v.test(null != t2 ? t2 : ""), C = (t2) => {
        let { available: e2, disclaimers: a2 } = (0, S.fyr)(t2);
        return (0, i.wg)({
          clipId: t2.clipId,
          title: t2.title,
          thumbnail: t2.thumbnail,
          previewUrl: t2.previewUrl,
          duration: t2.duration,
          version: t2.version,
          artists: (t2.artists || []).map((t3) => (0, m.as)({ artist: t3 })),
          isAvailable: e2,
          disclaimers: a2
        });
      };
      var L = a(46163), b = a(2880);
      let I = i.gK.compose(
        i.gK.model("ArtistAlbumsPage", {
          pagesLoader: (0, N.Ij)(n.JC),
          variant: i.gK.maybeNull(i.gK.enumeration(Object.values(b.h))),
          errorStatusCode: i.gK.maybeNull(i.gK.number)
        }),
        N.pl
      ).views((t2) => ({
        get isNotFound() {
          var e2, a2;
          let r2 = t2.pagesLoader.isSomePageResolved && (null != (a2 = null == (e2 = t2.pagesLoader.items) ? void 0 : e2.length) ? a2 : 0) === 0, i2 = t2.errorStatusCode === s.X1.NOT_FOUND || t2.errorStatusCode === s.X1.BAD_REQUEST;
          return t2.pagesLoader.isInitialRequestRejected && i2 || r2;
        },
        get isShimmerVisible() {
          return !t2.pagesLoader.isSomePageResolved;
        },
        get isNeededToLoad() {
          return t2.pagesLoader.isNeedToMakeInitialRequest;
        },
        get isRejected() {
          return t2.pagesLoader.isInitialRequestRejected;
        },
        get isResolved() {
          return t2.pagesLoader.isSomePageResolved;
        },
        get requestsCount() {
          return t2.pagesLoader.requestsCount;
        },
        get items() {
          var r2;
          return null != (r2 = t2.pagesLoader.items) ? r2 : [];
        }
      })).actions((t2) => ({
        setVariant: (e2) => {
          t2.variant = e2;
        },
        getData: (0, i.L3)(function* (e2) {
          let { artistId: a2, page: r2 = 0, pageSize: o2 = 20, sort: l2, preloadedAlbums: u2 } = e2, { artistsResource: d2, modelActionsLogger: g2 } = (0, i._$)(t2);
          if (t2.pagesLoader.isPageNeedToLoad(r2))
            try {
              t2.pagesLoader.setPageState(r2, S.GuX.PENDING);
              let e3 = { artistId: a2, page: r2, pageSize: o2, sort: { sortBy: null == l2 ? void 0 : l2.sortBy } }, i2 = u2;
              if (!i2)
                switch (t2.variant) {
                  case b.h.COMPILATIONS:
                    i2 = yield d2.getAlsoAlbums(e3);
                    break;
                  case b.h.DISCOGRAPHY:
                    i2 = yield d2.getDiscographyAlbums(e3);
                    break;
                  default:
                    i2 = yield d2.getDirectAlbums(e3);
                }
              let s2 = i2.albums.map(n.pp);
              t2.pagesLoader.setItems(s2, { page: r2, pager: { page: r2, perPage: o2, total: i2.pager.total } });
            } catch (e3) {
              g2.error(e3), e3 instanceof s.GX && (e3.statusCode === s.X1.NOT_FOUND || e3.statusCode === s.X1.BAD_REQUEST) && (t2.errorStatusCode = s.X1.NOT_FOUND), t2.pagesLoader.setItems(null, { responseStatus: S.FlZ.ERROR, page: r2 });
            }
        }),
        reset() {
          t2.variant = null, t2.errorStatusCode = null, t2.pagesLoader.reset();
        }
      })), T = i.gK.model("ArtistClipsPage", { pagesLoader: (0, N.Ij)(d.kv), errorStatusCode: i.gK.maybeNull(i.gK.number) }).views((t2) => ({
        get isShimmerVisible() {
          return !t2.pagesLoader.isSomePageResolved;
        },
        get isNeededToLoad() {
          return t2.pagesLoader.isNeedToMakeInitialRequest;
        },
        get isRejected() {
          return t2.pagesLoader.isInitialRequestRejected;
        },
        get isEmpty() {
          return t2.pagesLoader.isEmpty;
        },
        get isResolved() {
          return t2.pagesLoader.isSomePageResolved;
        },
        get requestsCount() {
          return t2.pagesLoader.requestsCount;
        },
        get items() {
          var e2;
          return null != (e2 = t2.pagesLoader.items) ? e2 : [];
        },
        get isNotFound() {
          return this.isRejected && t2.errorStatusCode === s.X1.NOT_FOUND;
        }
      })).actions((t2) => ({
        getData: (0, i.L3)(function* (e2) {
          let { artistId: a2, page: r2 = 0, pageSize: o2 = 20, preloadedClips: l2 } = e2, { artistsResource: n2, modelActionsLogger: u2 } = (0, i._$)(t2);
          if (t2.pagesLoader.isPageNeedToLoad(r2))
            try {
              t2.pagesLoader.setPageState(r2, S.GuX.PENDING);
              let e3 = l2;
              e3 || (e3 = yield n2.getClips({ artistId: a2, page: r2, pageSize: o2 }));
              let i2 = e3.items.map((t3) => (0, d.SZ)({ clip: t3.data.clip, artists: t3.data.artists }));
              t2.pagesLoader.setItems(i2, { page: r2, pager: e3.pager });
            } catch (e3) {
              u2.error(e3), t2.pagesLoader.setItems(null, { responseStatus: S.FlZ.ERROR, page: r2 }), e3 instanceof s.GX && (e3.statusCode === s.X1.NOT_FOUND || e3.statusCode === s.X1.BAD_REQUEST) && (t2.errorStatusCode = s.X1.NOT_FOUND);
            }
        }),
        reset() {
          t2.pagesLoader.reset(), t2.errorStatusCode = null;
        }
      })), X = i.gK.compose(
        i.gK.model("ArtistConcertsPage", {
          errorStatusCode: i.gK.maybeNull(i.gK.number),
          concerts: i.gK.maybeNull(i.gK.array(p.aR))
        }),
        N.pl,
        N.XT
      ).views((t2) => ({
        get isLoading() {
          return t2.isNeededToLoad || t2.loadingState === S.GuX.PENDING;
        },
        get isNotFound() {
          var e2;
          let a2 = t2.isResolved && (null == (e2 = t2.concerts) ? void 0 : e2.length) === 0, r2 = t2.errorStatusCode === s.X1.NOT_FOUND || t2.errorStatusCode === s.X1.BAD_REQUEST;
          return t2.isRejected && r2 || a2;
        }
      })).actions((t2) => ({
        getData: (0, i.L3)(function* (e2) {
          let { artistId: a2, preloadedConcerts: r2 } = e2, { artistsResource: o2, modelActionsLogger: l2 } = (0, i._$)(t2);
          if (t2.loadingState !== S.GuX.PENDING)
            try {
              t2.loadingState = S.GuX.PENDING;
              let e3 = null == r2 ? void 0 : r2.concerts;
              e3 || (e3 = (yield o2.getConcerts({ artistId: a2 })).concerts), t2.concerts = (0, i.wg)(e3.map(p.oP)), t2.loadingState = S.GuX.RESOLVE;
            } catch (e3) {
              l2.error(e3), e3 instanceof s.GX && (e3.statusCode === s.X1.NOT_FOUND || e3.statusCode === s.X1.BAD_REQUEST) && (t2.errorStatusCode = s.X1.NOT_FOUND), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.REJECT);
            }
        }),
        reset() {
          t2.loadingState = S.GuX.IDLE, t2.errorStatusCode = null, t2.destroyItems([t2.concerts]);
        }
      })), y = (t2) => (0, i.wg)({ ...(0, n.sK)({ album: t2, artists: t2.artists }), version: t2.version }), D = i.gK.compose(
        i.gK.model("ArtistFamiliarPage", {
          errorStatusCode: i.gK.maybeNull(i.gK.number),
          vibeTracks: i.gK.maybeNull(i.gK.array(c.vj)),
          collectionTracks: i.gK.maybeNull(i.gK.array(c.vj)),
          collectionAlbums: i.gK.maybeNull(i.gK.array(n.JC))
        }),
        N.pl,
        N.XT
      ).views((t2) => {
        let e2 = {
          get isLoading() {
            return t2.isNeededToLoad || t2.loadingState === S.GuX.PENDING;
          },
          get isNotFound() {
            let e3 = t2.errorStatusCode === s.X1.NOT_FOUND || t2.errorStatusCode === s.X1.BAD_REQUEST;
            return t2.isRejected && e3;
          },
          get hasCollectionEntities() {
            var a2, r2;
            return t2.isResolved && Number(null == (a2 = t2.collectionTracks) ? void 0 : a2.length) > 0 || Number(null == (r2 = t2.collectionAlbums) ? void 0 : r2.length) > 0;
          },
          get shouldShowTitleBlocks() {
            var i2, o2;
            if (e2.isLoading) return true;
            return Number(null == (i2 = t2.collectionTracks) ? void 0 : i2.length) > 0 && Number(null == (o2 = t2.collectionAlbums) ? void 0 : o2.length) > 0;
          },
          get hasVibeTracks() {
            var l2;
            return Number(null == (l2 = t2.vibeTracks) ? void 0 : l2.length) > 0;
          },
          get collectionEntitiesData() {
            var n2, u2;
            return null != (u2 = null == (n2 = t2.collectionTracks) ? void 0 : n2.map(c.$b)) ? u2 : [];
          },
          get vibeEntitiesData() {
            var d2, g2;
            return null != (g2 = null == (d2 = t2.vibeTracks) ? void 0 : d2.map(c.$b)) ? g2 : [];
          }
        };
        return e2;
      }).actions((t2) => ({
        getData: (0, i.L3)(function* (e2) {
          let { artistId: a2, preloadedFamiliar: r2 } = e2, { artistsResource: o2, modelActionsLogger: l2 } = (0, i._$)(t2);
          if (t2.loadingState !== S.GuX.PENDING)
            try {
              var n2, u2, d2, g2, m2, p2;
              t2.loadingState = S.GuX.PENDING;
              let e3 = r2;
              e3 || (e3 = yield o2.getFamiliarYou({
                artistId: a2,
                waveTracksLimit: 100,
                collectionTracksLimit: 100,
                collectionAlbumsLimit: 20
              })), t2.vibeTracks = (0, i.wg)(
                null == (u2 = e3.wave) || null == (n2 = u2.tracks) ? void 0 : n2.map((t3) => (0, c.vU)(t3))
              ), t2.collectionTracks = (0, i.wg)(
                null == (g2 = e3.collection) || null == (d2 = g2.tracks) ? void 0 : d2.map((t3) => (0, c.vU)(t3))
              ), t2.collectionAlbums = (0, i.wg)(
                null == (p2 = e3.collection) || null == (m2 = p2.albums) ? void 0 : m2.map(y)
              ), t2.loadingState = S.GuX.RESOLVE;
            } catch (e3) {
              l2.error(e3), e3 instanceof s.GX && (e3.statusCode === s.X1.NOT_FOUND || e3.statusCode === s.X1.BAD_REQUEST) && (t2.errorStatusCode = s.X1.NOT_FOUND), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.REJECT);
            }
        }),
        reset() {
          t2.loadingState = S.GuX.IDLE, t2.errorStatusCode = null, t2.destroyItems([t2.vibeTracks, t2.collectionTracks]);
        }
      }));
      var G = a(13611);
      let f = i.gK.model("ArtistPick", { playlist: G.$o, artists: i.gK.array(m.PK) }), h = i.gK.compose(
        i.gK.model("ArtistSimilarArtistsPage", {
          errorStatusCode: i.gK.maybeNull(i.gK.number),
          similarArtists: i.gK.maybeNull(i.gK.array(m.PK))
        }),
        N.pl,
        N.XT
      ).views((t2) => ({
        get isLoading() {
          return t2.isNeededToLoad || t2.loadingState === S.GuX.PENDING;
        },
        get isNotFound() {
          var e2;
          let a2 = t2.isResolved && (null == (e2 = t2.similarArtists) ? void 0 : e2.length) === 0, r2 = t2.errorStatusCode === s.X1.NOT_FOUND || t2.errorStatusCode === s.X1.BAD_REQUEST;
          return t2.isRejected && r2 || a2;
        }
      })).actions((t2) => ({
        getData: (0, i.L3)(function* (e2) {
          let { artistId: a2, preloadedSimilarArtists: r2 } = e2, { artistsResource: o2, modelActionsLogger: l2 } = (0, i._$)(t2);
          try {
            t2.loadingState = S.GuX.PENDING;
            let e3 = r2;
            e3 || (e3 = yield o2.getSimilarArtists({ artistId: a2 })), t2.similarArtists = (0, i.wg)(e3.similarArtists.map(m.dM)), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.RESOLVE);
          } catch (e3) {
            l2.error(e3), e3 instanceof s.GX && (e3.statusCode === s.X1.NOT_FOUND || e3.statusCode === s.X1.BAD_REQUEST) && (t2.errorStatusCode = s.X1.NOT_FOUND), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.REJECT);
          }
        }),
        reset() {
          t2.loadingState = S.GuX.IDLE, t2.errorStatusCode = null, t2.destroyItems([t2.similarArtists]);
        }
      })), K = i.gK.model("CommonSubPage", { artistName: i.gK.maybeNull(i.gK.string) }), A = i.gK.compose(
        i.gK.model("FamiliarInfo", {
          vibeTrackCount: i.gK.optional(i.gK.number, 0),
          collectionTrackCount: i.gK.optional(i.gK.number, 0),
          collectionAlbumCount: i.gK.optional(i.gK.number, 0)
        }),
        N.XT
      ).views((t2) => {
        let e2 = {
          get hasTracks() {
            return t2.isResolved && (t2.collectionTrackCount > 0 || t2.vibeTrackCount > 0);
          },
          get hasFamiliarInfo() {
            return t2.isResolved && (e2.hasTracks || t2.collectionAlbumCount > 0);
          },
          get tracksCount() {
            return t2.collectionTrackCount + t2.vibeTrackCount;
          },
          get hasCollectionEntities() {
            return t2.isResolved && (t2.collectionTrackCount > 0 || t2.collectionAlbumCount > 0);
          },
          get hasVibeEntities() {
            return t2.isResolved && t2.vibeTrackCount > 0;
          },
          href(t3) {
            if (!t3) return "";
            if (e2.hasCollectionEntities) {
              let { href: e3 } = (0, S.uvd)("/artist/:artistId/familiar", {
                params: { artistId: t3 },
                query: { tab: S.JCK.COLLECTION }
              });
              return e3;
            }
            if (e2.hasVibeEntities) {
              let { href: e3 } = (0, S.uvd)("/artist/:artistId/familiar", {
                params: { artistId: t3 },
                query: { tab: S.JCK.VIBE }
              });
              return e3;
            }
            let { href: a2 } = (0, S.uvd)("/artist/:artistId/familiar", { params: { artistId: t3 } });
            return a2;
          }
        };
        return e2;
      }).actions((t2) => ({
        getData: (0, i.L3)(function* (e2) {
          let { artistId: a2 } = e2, { artistsResource: r2, modelActionsLogger: s2 } = (0, i._$)(t2);
          if (t2.loadingState !== S.GuX.PENDING)
            try {
              t2.loadingState = S.GuX.PENDING;
              let e3 = yield r2.getFamiliarYouInfo({ artistId: a2, withWaveInfo: true, withCollectionInfo: true });
              e3.collection && (t2.collectionTrackCount = e3.collection.trackCount, t2.collectionAlbumCount = e3.collection.albumCount), e3.wave && (t2.vibeTrackCount = e3.wave.trackCount), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.RESOLVE);
            } catch (e3) {
              s2.error(e3), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.REJECT);
            }
        }),
        reset() {
          t2.loadingState = S.GuX.IDLE, t2.vibeTrackCount = 0, t2.collectionTrackCount = 0, t2.collectionAlbumCount = 0;
        }
      }));
      var R = a(97719);
      let k = i.gK.compose(
        i.gK.model("FullTracksList", {
          errorStatusCode: i.gK.maybeNull(i.gK.number),
          ids: i.gK.maybeNull(i.gK.array(i.gK.string)),
          tracks: i.gK.optional(i.gK.map(c.vj), {})
        }),
        N.pl,
        N.XT
      ).views((t2) => ({
        getTrackByIndex(e2) {
          if (!t2.ids || !t2.ids.length) return null;
          let a2 = t2.ids[e2];
          return a2 && t2.tracks.get(a2) || null;
        },
        get isNotFound() {
          var e2;
          let a2 = t2.isResolved && (null == (e2 = t2.ids) ? void 0 : e2.length) === 0, r2 = t2.errorStatusCode === s.X1.NOT_FOUND || t2.errorStatusCode === s.X1.BAD_REQUEST;
          return t2.isRejected && r2 || a2;
        }
      })).actions((t2) => ({
        getTracksIds: (0, i.L3)(function* (e2) {
          let { artistId: a2 } = e2, { artistsResource: r2, modelActionsLogger: o2 } = (0, i._$)(t2);
          try {
            t2.loadingState = S.GuX.PENDING;
            let e3 = yield r2.getArtistTrackIds({ artistId: a2 }), { sonataState: s2 } = (0, i.Zn)(t2);
            s2.setUnloadedEntitiesData(e3.map((t3) => (0, R.li)(t3))), t2.ids = (0, i.wg)(e3), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.RESOLVE);
          } catch (e3) {
            o2.error(e3), e3 instanceof s.GX && (e3.statusCode === s.X1.NOT_FOUND || e3.statusCode === s.X1.BAD_REQUEST) && (t2.errorStatusCode = s.X1.NOT_FOUND), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.REJECT);
          }
        }),
        getTracks: (0, i.L3)(function* (e2) {
          let { trackIds: a2 } = e2, { tracksResource: r2, modelActionsLogger: s2 } = (0, i._$)(t2);
          try {
            let e3 = yield r2.getTracksMeta({ trackIds: a2, withProgress: true });
            t2.tracks.merge(e3.reduce((t3, e4) => (t3[e4.id] = (0, c.vU)(e4), t3), {}));
          } catch (t3) {
            s2.error(t3);
          }
        }),
        reset() {
          let { sonataState: e2 } = (0, i.Zn)(t2);
          e2.resetUnloadedEntitiesData(), t2.loadingState = S.GuX.IDLE, t2.destroyItems([t2.tracks, t2.ids]);
        }
      }));
      var O = a(89511);
      let P = i.gK.compose(i.gK.model("OfflineArtistTrackIds", { ids: i.gK.maybeNull(i.gK.array(i.gK.string)) }), N.XT, N.pl).actions((t2) => ({
        getIds: (0, i.L3)(function* (e2, a2) {
          let { modelActionsLogger: r2 } = (0, i._$)(t2);
          if (t2.loadingState !== S.GuX.PENDING)
            try {
              t2.loadingState = S.GuX.PENDING;
              let r3 = yield a2.getArtistTrackIdsByUser(e2);
              t2.ids = (0, i.wg)(r3), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.RESOLVE);
            } catch (e3) {
              r2.error(e3), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.REJECT);
            }
        }),
        reset() {
          t2.loadingState = S.GuX.IDLE, t2.destroyItems([t2.ids]);
        }
      })), U = i.gK.compose(
        i.gK.model("OfflineArtist", {
          id: i.gK.maybeNull(i.gK.string),
          meta: i.gK.maybeNull(u.G4),
          trackIds: P,
          downloadedTracks: O.b
        }),
        N.XT,
        N.pl
      ).views((t2) => ({
        get isNotFound() {
          return t2.isResolved && !t2.meta;
        }
      })).actions((t2) => ({
        setTracksCount: (e2) => {
          var a2;
          (null == (a2 = t2.meta) ? void 0 : a2.artist.counts) && (t2.meta.artist.counts.tracks = e2);
        },
        getArtist: (0, i.L3)(function* (e2, a2) {
          let { modelActionsLogger: r2 } = (0, i._$)(t2);
          if (t2.loadingState !== S.GuX.PENDING) {
            t2.id = e2;
            try {
              t2.loadingState = S.GuX.PENDING;
              let r3 = yield a2.getArtist(e2);
              r3 && (t2.meta = (0, i.wg)({ artist: (0, m.dM)(r3) })), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.RESOLVE);
            } catch (e3) {
              r2.error(e3), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.REJECT);
            }
          }
        }),
        reset() {
          t2.id = null, t2.loadingState = S.GuX.IDLE, t2.trackIds.reset(), t2.downloadedTracks.reset(), t2.destroyItems([t2.meta]);
        }
      })), w = i.gK.compose(
        i.gK.model("ArtistPage", {
          id: i.gK.maybeNull(i.gK.string),
          meta: i.gK.maybeNull(u.G4),
          landing: l.Ju,
          popularTracks: i.gK.array(c.vj),
          lastRelease: i.gK.maybeNull(n.JC),
          upcomingAlbum: i.gK.maybeNull(n.VH),
          concerts: i.gK.maybeNull(i.gK.array(p.aR)),
          similarArtists: i.gK.array(m.PK),
          playlists: i.gK.array(g.IP),
          errorStatusCode: i.gK.maybeNull(i.gK.number),
          deprecationTargetArtistId: i.gK.maybeNull(i.gK.number),
          albums: i.gK.array(n.JC),
          discography: i.gK.array(n.JC),
          compilations: i.gK.array(n.JC),
          clips: i.gK.array(d.kv),
          artistPick: i.gK.maybeNull(f),
          familiarInfo: A,
          albumsSubpage: I,
          fullTracksListSubpage: k,
          concertsSubpage: X,
          similarArtistsSubPage: h,
          clipsSubpage: T,
          familiarSubpage: D,
          commonSubPage: K,
          offlineArtist: U,
          infoLoadingState: N.XT,
          infoErrorStatusCode: i.gK.maybeNull(i.gK.number)
        }),
        N.pl,
        N.XT
      ).views((t2) => {
        let e2 = {
          get isLoading() {
            return t2.isNeededToLoad || t2.loadingState === S.GuX.PENDING;
          },
          get hasPopularTracks() {
            return e2.isLoading || t2.popularTracks.length > 0;
          },
          get hasAlbums() {
            return e2.isLoading || t2.albums.length > 0;
          },
          get hasDiscography() {
            return e2.isLoading || t2.discography.length > 0;
          },
          get hasCompilations() {
            return e2.isLoading || t2.compilations.length > 0;
          },
          get hasSimilarArtists() {
            return e2.isLoading || t2.similarArtists.length > 0;
          },
          get hasPlaylists() {
            return e2.isLoading || t2.playlists && t2.playlists.length > 0;
          },
          get hasConcerts() {
            return e2.isLoading || t2.concerts && t2.concerts.length > 0;
          },
          get hasClips() {
            return e2.isLoading || t2.clips.length > 0;
          },
          get isNotFound() {
            return t2.isRejected && (t2.errorStatusCode === s.X1.NOT_FOUND || t2.errorStatusCode === s.X1.BAD_REQUEST);
          },
          get isInfoNotFound() {
            return t2.infoLoadingState.isRejected && (t2.infoErrorStatusCode === s.X1.NOT_FOUND || t2.infoErrorStatusCode === s.X1.BAD_REQUEST);
          },
          get isSomethingWentWrong() {
            return t2.isRejected && !e2.isNotFound;
          },
          get isInfoSomethingWentWrong() {
            return t2.infoLoadingState.isRejected && !e2.isInfoNotFound;
          },
          get isCacheNotFound() {
            return t2.isRejected && t2.errorStatusCode === o.FX;
          },
          get hasReleaseBlock() {
            return !!(e2.isLoading || t2.upcomingAlbum || t2.lastRelease);
          },
          get selfLink() {
            if (!t2.id) return "";
            let { href: e3 } = (0, S.uvd)("/artist/:artistId", { params: { artistId: t2.id } });
            return e3;
          },
          get tracksUrl() {
            if (!t2.id) return "";
            let { href: e3 } = (0, S.uvd)("/artist/:artistId/tracks", { params: { artistId: t2.id } });
            return e3;
          },
          get concertsUrl() {
            var a2;
            if ((null == (a2 = t2.meta) ? void 0 : a2.artist.id) && t2.concerts && t2.concerts.length > u.M$) {
              let { href: e3 } = (0, S.uvd)("/artist/:artistId/concerts", {
                params: { artistId: t2.meta.artist.id }
              });
              return e3;
            }
            return "";
          },
          get clipsUrl() {
            if (!t2.id) return "";
            let { href: e3 } = (0, S.uvd)("/artist/:artistId/videos", { params: { artistId: t2.id } });
            return e3;
          },
          get compilationsUrl() {
            if (!t2.id) return "";
            let { href: e3 } = (0, S.uvd)("/artist/:artistId/compilations", { params: { artistId: t2.id } });
            return e3;
          },
          get discographyUrl() {
            if (!t2.id) return "";
            let { href: e3 } = (0, S.uvd)("/artist/:artistId/discography", { params: { artistId: t2.id } });
            return e3;
          },
          get albumsUrl() {
            if (!t2.id) return "";
            let { href: e3 } = (0, S.uvd)("/artist/:artistId/albums", { params: { artistId: t2.id } });
            return e3;
          },
          get similarArtistsUrl() {
            if (!t2.id) return "";
            let { href: e3 } = (0, S.uvd)("/artist/:artistId/similar", { params: { artistId: t2.id } });
            return e3;
          }
        };
        return e2;
      }).actions((t2) => ({
        getData: (0, i.L3)(function* (e2) {
          let { artistId: a2, preloadedArtist: o2 } = e2, { slides: l2, experiments: d2 } = (0, i.Zn)(t2), { artistsResource: N2, modelActionsLogger: v2 } = (0, i._$)(t2);
          if (t2.id = a2, t2.loadingState !== S.GuX.PENDING)
            try {
              var L2, b2, I2;
              t2.loadingState = S.GuX.PENDING;
              let e3 = o2;
              e3 || (e3 = yield N2.getBriefInfo({
                artistId: a2,
                popularTracksCount: u.xx,
                fetchPlaylistLikesCounts: true,
                discographyBlockEnabled: true,
                useClipDataFormat: true
              }));
              let {
                popularTracks: v3,
                error: T2,
                artist: X2,
                stats: y2,
                albums: D2,
                playlists: G2,
                alsoAlbums: f2,
                similarArtists: h2,
                lastReleases: K2,
                concerts: A2,
                upcomingAlbum: R2,
                discography: k2,
                artistPick: O2,
                clips: P2,
                allCovers: U2
              } = e3;
              if ("not-found" === T2 || (null == X2 ? void 0 : X2.error) === "not-found") {
                t2.errorStatusCode = s.X1.NOT_FOUND, t2.loadingState = S.GuX.REJECT;
                return;
              }
              if (null == (L2 = X2.deprecation) ? void 0 : L2.targetArtistId) {
                t2.deprecationTargetArtistId = X2.deprecation.targetArtistId, t2.loadingState = S.GuX.RESOLVE;
                return;
              }
              if (t2.commonSubPage.artistName = X2.name, d2.checkExperiment(S.zal.WebNextArtistSkeletonHeader, "on") || (t2.meta = (0, i.wg)(
                ((t3, e4, a3) => {
                  var s2;
                  let o3 = null == (s2 = t3.extraActions) ? void 0 : s2.find((t4) => t4.type === r.DONATION && E(t4.url));
                  return (0, i.wg)({
                    artist: (0, m.dM)(t3),
                    donationUrl: null == o3 ? void 0 : o3.url,
                    lastMonthListeners: null == e4 ? void 0 : e4.lastMonthListeners,
                    covers: null == a3 ? void 0 : a3.map((t4) => t4.uri)
                  });
                })(X2, y2, U2)
              )), (null == (I2 = t2.meta) || null == (b2 = I2.artist) ? void 0 : b2.resolveAllDisclaimers) && (yield t2.meta.artist.resolveAllDisclaimers()), K2 && K2.length > 0) {
                let e4 = K2[0];
                e4 && D2 && D2.length > 1 && (t2.lastRelease = (0, i.wg)((0, n.pp)(e4)));
              }
              R2 && (t2.upcomingAlbum = (0, i.wg)((0, n.lO)(R2))), A2 && (t2.concerts = (0, i.wg)(A2.map(p.oP))), v3 && v3.length > 0 && (t2.popularTracks = (0, i.wg)(v3.slice(0, u.xx).map((t3) => (0, c.vU)(t3)))), h2 && h2.length > 0 && (t2.similarArtists = (0, i.wg)(h2.slice(0, u.dg).map(m.dM))), Number(null == D2 ? void 0 : D2.length) > 0 && (t2.albums = (0, i.wg)(null == D2 ? void 0 : D2.map(n.pp))), Number(null == k2 ? void 0 : k2.length) > 0 && (t2.discography = (0, i.wg)(null == k2 ? void 0 : k2.map(n.pp).slice(0, u.vx))), Number(null == f2 ? void 0 : f2.length) > 0 && (t2.compilations = (0, i.wg)(null == f2 ? void 0 : f2.map(n.pp).slice(0, u.vx))), G2 && G2.length > 0 && (t2.playlists = (0, i.wg)(G2.map(g.ZC).slice(0, u.vx))), O2 && (t2.artistPick = ((t3) => {
                let e4 = t3.artists.map((t4) => (0, m.as)({ artist: t4 }));
                return (0, i.wg)({ playlist: (0, g.bk)({ playlist: t3.playlist }), artists: e4 });
              })(O2)), P2 && (t2.clips = (0, i.wg)(P2.map(C).slice(0, u.eS))), l2.resetArtist(), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.RESOLVE);
            } catch (e3) {
              v2.error(e3), e3 instanceof s.GX && (t2.errorStatusCode = e3.statusCode), t2.loadingState !== S.GuX.IDLE && (t2.loadingState = S.GuX.REJECT);
            }
        }),
        getInfo: (0, i.L3)(function* (e2) {
          let { artistId: a2 } = e2, { artistsResource: r2, modelActionsLogger: o2 } = (0, i._$)(t2);
          if (t2.id = a2, t2.infoLoadingState.loadingState !== S.GuX.PENDING)
            try {
              var l2, n2, d2, g2, c2, p2;
              t2.infoLoadingState.loadingState = S.GuX.PENDING;
              let e3 = yield r2.getInfo({ artistId: a2 }), { artist: s2, deprecation: o3 } = e3;
              if (null == o3 ? void 0 : o3.targetArtistId) {
                t2.deprecationTargetArtistId = o3.targetArtistId, t2.loadingState = S.GuX.RESOLVE;
                return;
              }
              t2.commonSubPage.artistName = s2.name, t2.meta = (0, i.wg)(
                (0, i.wg)({
                  artist: (0, m.as)({
                    artist: e3.artist,
                    trailer: e3.trailer,
                    isComposer: e3.artistType === L.o.COMPOSER
                  }),
                  donationUrl: E(null == (d2 = e3.donation) ? void 0 : d2.tipUrl) ? null == (g2 = e3.donation) ? void 0 : g2.tipUrl : void 0,
                  lastMonthListeners: null == (c2 = e3.stats) ? void 0 : c2.lastMonthListeners,
                  brandedButton: e3.brandedButton ? (0, u.LH)(e3.brandedButton) : void 0,
                  covers: null == (p2 = e3.covers) ? void 0 : p2.map((t3) => {
                    var e4;
                    return null != (e4 = t3.uri) ? e4 : "";
                  })
                })
              ), (null == (n2 = t2.meta) || null == (l2 = n2.artist) ? void 0 : l2.resolveAllDisclaimers) && (yield t2.meta.artist.resolveAllDisclaimers()), t2.infoLoadingState.loadingState !== S.GuX.IDLE && (t2.infoLoadingState.loadingState = S.GuX.RESOLVE);
            } catch (e3) {
              o2.error(e3), e3 instanceof s.GX && (t2.infoErrorStatusCode = e3.statusCode), t2.infoLoadingState.loadingState !== S.GuX.IDLE && (t2.infoLoadingState.loadingState = S.GuX.REJECT);
            }
        }),
        reset() {
          t2.loadingState = S.GuX.IDLE, t2.infoLoadingState.loadingState = S.GuX.IDLE, t2.landing.reset(), t2.id = null, t2.errorStatusCode = null, t2.deprecationTargetArtistId = null, t2.destroyItems([
            t2.clips,
            t2.popularTracks,
            t2.similarArtists,
            t2.playlists,
            t2.albums,
            t2.discography,
            t2.compilations,
            t2.meta,
            t2.lastRelease,
            t2.upcomingAlbum,
            t2.concerts,
            t2.artistPick
          ]);
        }
      }));
      var _ = a(42509), F = a(89071), B = a(6237), j = a(70768);
      a(45957);
      var J = a(35335), V = a(7425), $ = a(55273);
    }
  }
]);
