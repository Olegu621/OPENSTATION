(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2141],
  {
    5693: (t, e, i) => {
      "use strict";
      var s;
      i.d(e, { R: () => s }), (function(t2) {
        t2.Music = "music", t2.DownloadedMusic = "downloadedMusic", t2.VibeTrack = "vibeTrack", t2.Generative = "generative", t2.Unknown = "unknown", t2.SmartPreview = "smartPreview", t2.Clip = "clip", t2.Radio = "fm_radio";
      })(s || (s = {}));
    },
    12744: (t) => {
      t.exports = {
        root: "Slider_root__T7EOX",
        root_visible: "Slider_root_visible__b3Kqx",
        fade: "Slider_fade__V7FGV",
        container: "Slider_container__tZ0VH"
      };
    },
    16605: (t) => {
      t.exports = {
        root: "SliderControls_root__v_ofj",
        control: "SliderControls_control__E3joM",
        top: "SliderControls_top__HN5gZ"
      };
    },
    27820: (t) => {
      t.exports = {
        root: "SlidesPage_root__URM_B",
        header: "SlidesPage_header__pnBx9",
        slidesResult: "SlidesPage_slidesResult__neqIE",
        counterActiveItem: "SlidesPage_counterActiveItem__Y_K9I",
        counterItem: "SlidesPage_counterItem__3CqZW",
        button: "SlidesPage_button__s9V8y",
        volumeButton: "SlidesPage_volumeButton__HfFCM",
        desktopBackButton: "SlidesPage_desktopBackButton__ae1Uj",
        mobileBackButton: "SlidesPage_mobileBackButton__MwOgB"
      };
    },
    31144: (t) => {
      t.exports = { root: "Slide_root__x5JEM", root_isActive: "Slide_root_isActive__CKUSv" };
    },
    46215: (t) => {
      t.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    46965: (t, e, i) => {
      "use strict";
      i.d(e, { SlidesPage: () => z });
      var s = i(54486), a = i(50420), n = i(28303), o = i(97396), r = i(61910), l = i(43426), d = i(47713), u = i(43350), c = i(31500), h = i(8817), p = i(77881), m = i(5956), g = i(39610), f = i(97800), S = i(89461), v = i(91657), _ = i(36553), b = i(62443), x = i(74125), V = i(16605), E = i.n(V);
      let I = (t2) => {
        let { isFirstSlide: e2, isLastSlide: i2, style: a2 } = t2, n2 = (0, _.Mn)(), { formatMessage: o2 } = (0, l.A)(), d2 = (0, r.useCallback)(() => {
          n2.slidePrev();
        }, [n2]), u2 = (0, r.useCallback)(() => {
          n2.slideNext();
        }, [n2]);
        return (0, s.jsxs)("div", {
          className: E().root,
          style: a2,
          children: [
            (0, s.jsx)(p.$, {
              variant: "outline",
              iconClassName: E().top,
              size: "m",
              radius: "round",
              onClick: d2,
              disabled: e2,
              icon: (0, s.jsx)(m.Icon, { variant: "arrowDown", size: "xxs" }, "prevIcon"),
              withRipple: false,
              "aria-label": o2({ id: "slider.prev-slide" }),
              className: E().control
            }),
            (0, s.jsx)(p.$, {
              variant: "outline",
              size: "m",
              radius: "round",
              onClick: u2,
              disabled: i2,
              icon: (0, s.jsx)(m.Icon, { variant: "arrowDown", size: "xxs" }, "nextIcon"),
              withRipple: false,
              "aria-label": o2({ id: "slider.next-slide" }),
              className: E().control
            })
          ]
        });
      };
      var k = i(63585), y = i(77710), j = i(6971), A = i(92830), w = i(31144), N = i.n(w);
      let F = (t2) => {
        var e2;
        let { slide: i2, isVisible: n2 } = t2, { ref: o2, intersectionPropertyId: l2 } = (0, x.nMI)(), d2 = (0, x.eGp)(), { from: u2 } = (0, x.fyy)({ pageId: x._Q$.TRAILER_OF_THE_YEAR, blockId: x.UfI.DEFAULT }), c2 = (0, x.brA)(), { isActive: h2 } = (0, _.JO)(), p2 = null == d2 ? void 0 : d2.getState(x.V_r.TRAILER).queueState.entityList.value, m2 = (0, r.useMemo)(
          () => i2.entitiesData && p2 && i2.entitiesData.every((t3, e3) => {
            var i3;
            return t3.meta.id === (null == (i3 = p2[e3]) ? void 0 : i3.entity.data.meta.id);
          }),
          [i2.entitiesData, p2]
        ), g2 = n2 && i2.hasTrailer && (!m2 || (null == d2 ? void 0 : d2.getState(x.V_r.TRAILER).playerState.status.value) !== S.MT.PLAYING), f2 = g2 && (null == d2 || null == (e2 = d2.getState(x.V_r.TRAILER).currentContext.value) ? void 0 : e2.data.meta.id) === i2.id;
        return (0, r.useEffect)(() => {
          if (f2)
            return void d2.restartContext(
              { playAfterRestart: true, queueParams: { index: 0 }, entitiesData: i2.entitiesData },
              x.V_r.TRAILER
            ).then(() => {
              c2(true);
            });
          g2 && (null == d2 || d2.playContext(
            {
              contextData: {
                type: k.K.Various,
                overrideContextType: y.b.Other,
                trailer: true,
                meta: { id: i2.id },
                from: u2
              },
              queueParams: { index: 0 },
              entitiesData: i2.entitiesData,
              loadContextMeta: false
            },
            x.V_r.TRAILER
          ).then(() => {
            c2(true);
          }));
        }, [u2, c2, g2, f2, i2.entitiesData, i2.id, d2]), (0, s.jsx)(j.Paper, {
          className: (0, a.$)(N().root, { [N().root_isActive]: h2 }),
          radius: "l",
          tabIndex: 0,
          "data-intersection-property-id": l2,
          ref: o2,
          children: (0, s.jsx)(A.AR, { slide: i2, isActive: h2 })
        });
      };
      var P = i(12744), C = i.n(P);
      let T = (0, n.PA)((t2) => {
        let { items: e2 } = t2, {
          settings: { isMobile: i2 },
          slides: n2
        } = (0, x.Pjs)(), { formatMessage: o2 } = (0, l.A)(), { state: d2, toggleTrue: c2 } = (0, b.e)(false), h2 = (0, _.Mn)(), p2 = (0, x.fBs)(), m2 = (0, r.useRef)(false), [g2, f2] = (0, r.useState)(true), [S2, V2] = (0, r.useState)(false);
        (0, r.useEffect)(
          () => (c2(), () => {
            null == h2 || h2.slideTo(0), n2.setActiveSlide(0);
          }),
          [c2, h2, n2]
        ), (0, r.useEffect)(() => {
          n2.isLoaded && !m2.current && (p2(), m2.current = true);
        }, [n2.isLoaded, p2]);
        let E2 = (0, r.useCallback)(
          (t3) => {
            f2(t3.isBeginning), V2(t3.isEnd), n2.setActiveSlide(t3.activeIndex);
          },
          [n2]
        );
        return (0, s.jsx)("div", {
          className: (0, a.$)(C().root, { [C().root_visible]: d2 }),
          children: (0, s.jsxs)(_.RC, {
            direction: "vertical",
            centeredSlides: !i2,
            slidesPerView: "auto",
            spaceBetween: 16,
            className: C().container,
            keyboard: { enabled: true },
            modules: [v.s3, v.Jq, v.FJ],
            onActiveIndexChange: E2,
            a11y: { enabled: true, containerMessage: o2({ id: "page.results-of-the-year" }) },
            mousewheel: { thresholdDelta: 30, thresholdTime: 500 },
            children: [
              e2.map((t3, i3) => {
                var a2, o3;
                return (0, s.jsx)(
                  _.qr,
                  {
                    children: (0, s.jsx)(x.FoH, {
                      blockPosX: 1,
                      blockPosY: i3 + 1,
                      blockType: null == (a2 = t3.content) ? void 0 : a2.type,
                      blockId: t3.id,
                      mainObjectId: n2.mainObjectId,
                      mainObjectType: u.ky.Slide,
                      children: (0, s.jsx)(x.Bki, {
                        objectType: u.ky.SlideContent,
                        objectId: "",
                        objectPosX: (null != (o3 = t3.carouselIndex) ? o3 : 0) + 1,
                        objectPosY: 1,
                        objectsCount: e2.length,
                        children: (0, s.jsx)(F, { isVisible: n2.activeSlide === i3, slide: t3 })
                      })
                    })
                  },
                  t3.id
                );
              }),
              (0, s.jsx)(I, { isFirstSlide: g2, isLastSlide: S2 })
            ]
          })
        });
      });
      var L = i(27820), R = i.n(L);
      function D(t2, e2) {
        return (t2 === x.GuX.RESOLVE || t2 === x.GuX.REJECT) && 0 === e2.length;
      }
      let z = (0, n.PA)((t2) => {
        var e2;
        let { slidesConsumer: i2, artistId: n2, podcastId: v2, campaignId: _2 } = t2, { formatMessage: b2 } = (0, l.A)(), { slides: V2, experiments: E2, sonataState: I2, settings: k2 } = (0, x.Pjs)(), y2 = (0, x.eGp)(), j2 = E2.checkExperiment(x.zal.WebNextSlidesPage, "on"), w2 = !(null == (e2 = k2.browserInfo) ? void 0 : e2.isMobile) || !k2.browserInfo.isTouch, N2 = null == y2 ? void 0 : y2.getState(x.V_r.TRAILER), F2 = (0, h.c)((t3) => {
          null == y2 || y2.setExponentVolume(t3, x.V_r.TRAILER);
        });
        (0, r.useEffect)(() => {
          F2(1), V2.setIsMuted(false);
        }, [F2, V2, y2]);
        let { canBack: P2, moveBack: C2 } = (0, x.JD0)(x.Zyd.main.href), L2 = (0, x.ZpR)(x.Zyd.main.href);
        (0, r.useEffect)(
          () => () => {
            V2.resetUser(), V2.resetArtist(), V2.resetPodcast(), V2.resetSpecial(), V2.resetKids(), null == y2 || y2.pause(x.V_r.TRAILER);
          },
          [V2, y2]
        ), j2 || (0, o.notFound)();
        let z2 = (0, x.zxo)(V2.mainObjectId);
        (0, r.useEffect)(() => {
          I2.status === S.MT.PLAYING && (null == y2 || y2.togglePause());
        }, [y2, I2.status]), (0, r.useEffect)(
          () => (z2(true), () => {
            z2(false);
          }),
          [z2]
        );
        let O = (0, r.useMemo)(() => {
          switch (i2) {
            case A.z6.USER:
              return V2.userItems;
            case A.z6.ARTIST:
              return V2.artistItems;
            case A.z6.PODCAST:
              return V2.podcastItems;
            case A.z6.SPECIAL:
              return V2.specialItems;
            case A.z6.KIDS:
              return V2.kidsItems;
          }
        }, [V2.artistItems, V2.kidsItems, V2.podcastItems, V2.specialItems, V2.userItems, i2]);
        (0, r.useEffect)(() => {
          if (j2)
            switch (i2) {
              case A.z6.USER:
                D(V2.userSlidesLoadingState, O) && (0, o.notFound)();
                break;
              case A.z6.ARTIST:
                D(V2.artistSlidesLoadingState, O) && (0, o.notFound)();
                break;
              case A.z6.PODCAST:
                D(V2.podcastSlidesLoadingState, O) && (0, o.notFound)();
                break;
              case A.z6.SPECIAL:
                D(V2.specialSlidesLoadingState, O) && (0, o.notFound)();
                break;
              case A.z6.KIDS:
                D(V2.kidsSlidesLoadingState, O) && (0, o.notFound)();
            }
          else (0, o.notFound)();
        }, [
          E2,
          j2,
          O,
          O.length,
          V2.artistSlidesLoadingState,
          V2.podcastSlidesLoadingState,
          V2.userSlidesLoadingState,
          V2.specialSlidesLoadingState,
          i2,
          V2.kidsSlidesLoadingState
        ]), (0, x.NBO)(true);
        let B = (0, r.useMemo)(() => {
          var t3;
          let e3, i3 = null == (t3 = O[V2.activeSlide]) ? void 0 : t3.slideColor;
          if (i3) {
            let { r: t4, g: s2, b: a2 } = (0, x.E2N)(i3);
            e3 = "rgba(".concat(t4, ", ").concat(s2, ", ").concat(a2, ", 0.5)");
          }
          return { "--card-color-enabled_variant": i3, "--card-color-enabled": e3, "--logo-color": i3 };
        }, [O, O.length, V2.activeSlide]), M = (0, r.useCallback)(() => {
          V2.toggleMute(), (null == N2 ? void 0 : N2.playerState.exponentVolume.value) !== 0 ? F2(0) : F2(1);
        }, [F2, V2, null == N2 ? void 0 : N2.playerState.exponentVolume.value]), G = (0, h.c)(() => {
          P2 ? C2() : L2();
        }), $ = V2.isMuted ? "volumeOff" : "volume", q = b2(V2.isMuted ? { id: "player-actions.volume-off" } : { id: "player-actions.volume-on" });
        switch (i2) {
          case A.z6.USER:
            V2.userSlidesLoadingState === x.GuX.IDLE && (0, r.use)(V2.getUserSlides());
            break;
          case A.z6.ARTIST:
            n2 && V2.artistSlidesLoadingState === x.GuX.IDLE && (0, r.use)(V2.getArtistSlides({ artistId: n2 }));
            break;
          case A.z6.PODCAST:
            v2 && V2.podcastSlidesLoadingState === x.GuX.IDLE && (0, r.use)(V2.getPodcastSlides({ podcastId: Number(v2) }));
            break;
          case A.z6.SPECIAL:
            _2 && V2.specialSlidesLoadingState === x.GuX.IDLE && (0, r.use)(V2.getSpecialSlides({ campaignId: _2 }));
            break;
          case A.z6.KIDS:
            V2.kidsSlidesLoadingState === x.GuX.IDLE && (0, r.use)(V2.getKidsSlides());
        }
        return (0, s.jsx)(x.jPc, {
          children: (0, s.jsx)(x.nVz, {
            pageId: x._Q$.SLIDES_SCREEN,
            children: (0, s.jsxs)("div", {
              className: R().root,
              style: B,
              ...(0, c.Am)(c.Xk.slides.SLIDES_PAGE),
              children: [
                (0, s.jsx)(g.q, {
                  children: (0, s.jsx)(f.Heading, {
                    variant: "h1",
                    children: (0, s.jsx)(d.A, { id: "page.results-of-the-year" })
                  })
                }),
                (0, s.jsxs)("header", {
                  className: R().header,
                  children: [
                    (null == O ? void 0 : O.length) > 0 && (0, s.jsxs)("div", {
                      className: R().slidesResult,
                      children: [
                        (0, s.jsx)(f.Caption, {
                          variant: "span",
                          className: R().counterActiveItem,
                          type: "text",
                          size: "l",
                          weight: "medium",
                          children: Number(V2.activeSlide) + 1
                        }),
                        (0, s.jsx)(f.Caption, {
                          variant: "span",
                          type: "text",
                          size: "l",
                          weight: "medium",
                          className: R().counterItem,
                          children: "/"
                        }),
                        (0, s.jsx)(f.Caption, {
                          variant: "span",
                          type: "text",
                          size: "l",
                          weight: "medium",
                          className: R().counterItem,
                          children: null == O ? void 0 : O.length
                        })
                      ]
                    }),
                    w2 && (0, s.jsx)(p.$, {
                      "aria-label": q,
                      variant: "text",
                      radius: "round",
                      size: "xxxs",
                      icon: (0, s.jsx)(m.Icon, { size: "xs", className: R().icon, variant: $ }),
                      onClick: M,
                      className: (0, a.$)(R().button, R().volumeButton),
                      withRipple: false
                    }),
                    (0, s.jsx)(p.$, {
                      "aria-label": b2({ id: "navigation.go-back" }),
                      radius: "round",
                      size: "xs",
                      icon: (0, s.jsx)(m.Icon, { size: "xs", variant: "close" }, "handleBackIcon"),
                      onClick: G,
                      className: (0, a.$)(R().button, R().desktopBackButton),
                      role: "link"
                    }),
                    (0, s.jsx)(p.$, {
                      variant: "text",
                      "aria-label": b2({ id: "navigation.go-back" }),
                      radius: "round",
                      size: "xs",
                      icon: (0, s.jsx)(m.Icon, { size: "xs", variant: "arrowLeft" }, "handleBackIcon"),
                      onClick: G,
                      className: (0, a.$)(R().button, R().mobileBackButton),
                      role: "link"
                    })
                  ]
                }),
                (0, s.jsx)(x.FoH, {
                  mainObjectType: u.ky.Slide,
                  mainObjectId: V2.mainObjectId,
                  blockType: u.ky.Slide,
                  blockId: V2.mainObjectId,
                  blockPosX: 1,
                  blockPosY: 1,
                  objectsCount: O.length,
                  children: (0, s.jsx)(T, { items: O })
                })
              ]
            })
          })
        });
      });
    },
    65034: (t, e, i) => {
      "use strict";
      i.d(e, { NotFound: () => g });
      var s = i(54486), a = i(50420), n = i(28303), o = i(47713), r = i(77881), l = i(5956), d = i(97800), u = i(74125), c = i(80585), h = i(61910), p = i(46215), m = i.n(p);
      let g = (0, n.PA)((t2) => {
        let { className: e2, title: i2, description: n2, iconVariant: p2 = "musicLogo", iconClassName: g2, iconSize: f } = t2, { contentRef: S } = (0, u.gKY)(), v = (0, u.ZpR)(u.Zyd.main.href);
        (0, u.LZB)();
        let { handleNavigateToMain: _ } = (0, u.D5F)(v);
        return (0, u.NBO)(true), !(function() {
          let { location: t3 } = (0, u.Pjs)();
          (0, h.useEffect)(
            () => (t3.setNotFound(true), () => {
              t3.setNotFound(false);
            }),
            [t3]
          );
        })(), (0, s.jsxs)("div", {
          className: (0, a.$)(m().root, { [m().root_desktop]: !S }, e2),
          children: [
            (0, s.jsx)(c.Lh, { withBackwardFallback: "/", className: m().navigation, withForwardControl: false }),
            (0, s.jsxs)("div", {
              className: m().content,
              children: [
                (0, s.jsx)(l.Icon, { className: (0, a.$)(m().icon, g2), variant: p2, size: f }),
                (0, s.jsx)(d.Heading, {
                  className: (0, a.$)(m().title, m().important),
                  variant: "h3",
                  size: "xs",
                  children: i2 || (0, s.jsx)(o.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, s.jsx)(d.Caption, {
                  className: (0, a.$)(m().text, m().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: n2 || (0, s.jsx)(o.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, s.jsx)(r.$, {
                  onClick: _,
                  className: m().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, s.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, s.jsx)(o.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    70837: (t, e, i) => {
      "use strict";
      i.d(e, { T: () => a });
      var s = function() {
        return (s = Object.assign || function(t2) {
          for (var e2, i2 = 1, s2 = arguments.length; i2 < s2; i2++)
            for (var a2 in e2 = arguments[i2]) Object.prototype.hasOwnProperty.call(e2, a2) && (t2[a2] = e2[a2]);
          return t2;
        }).apply(this, arguments);
      }, a = (function() {
        function t2(t3, e2, i2) {
          var a2 = this;
          this.endVal = e2, this.options = i2, this.version = "2.8.1", this.defaults = {
            startVal: 0,
            decimalPlaces: 0,
            duration: 2,
            useEasing: true,
            useGrouping: true,
            useIndianSeparators: false,
            smartEasingThreshold: 999,
            smartEasingAmount: 333,
            separator: ",",
            decimal: ".",
            prefix: "",
            suffix: "",
            enableScrollSpy: false,
            scrollSpyDelay: 200,
            scrollSpyOnce: false
          }, this.finalEndVal = null, this.useEasing = true, this.countDown = false, this.error = "", this.startVal = 0, this.paused = true, this.once = false, this.count = function(t4) {
            a2.startTime || (a2.startTime = t4);
            var e3 = t4 - a2.startTime;
            a2.remaining = a2.duration - e3, a2.useEasing ? a2.countDown ? a2.frameVal = a2.startVal - a2.easingFn(e3, 0, a2.startVal - a2.endVal, a2.duration) : a2.frameVal = a2.easingFn(e3, a2.startVal, a2.endVal - a2.startVal, a2.duration) : a2.frameVal = a2.startVal + (a2.endVal - a2.startVal) * (e3 / a2.duration);
            var i3 = a2.countDown ? a2.frameVal < a2.endVal : a2.frameVal > a2.endVal;
            a2.frameVal = i3 ? a2.endVal : a2.frameVal, a2.frameVal = Number(a2.frameVal.toFixed(a2.options.decimalPlaces)), a2.printValue(a2.frameVal), e3 < a2.duration ? a2.rAF = requestAnimationFrame(a2.count) : null !== a2.finalEndVal ? a2.update(a2.finalEndVal) : a2.options.onCompleteCallback && a2.options.onCompleteCallback();
          }, this.formatNumber = function(t4) {
            var e3, i3, s2, n = (Math.abs(t4).toFixed(a2.options.decimalPlaces) + "").split(".");
            if (e3 = n[0], i3 = n.length > 1 ? a2.options.decimal + n[1] : "", a2.options.useGrouping) {
              s2 = "";
              for (var o = 3, r = 0, l = 0, d = e3.length; l < d; ++l)
                a2.options.useIndianSeparators && 4 === l && (o = 2, r = 1), 0 !== l && r % o == 0 && (s2 = a2.options.separator + s2), r++, s2 = e3[d - l - 1] + s2;
              e3 = s2;
            }
            return a2.options.numerals && a2.options.numerals.length && (e3 = e3.replace(/[0-9]/g, function(t5) {
              return a2.options.numerals[+t5];
            }), i3 = i3.replace(/[0-9]/g, function(t5) {
              return a2.options.numerals[+t5];
            })), (t4 < 0 ? "-" : "") + a2.options.prefix + e3 + i3 + a2.options.suffix;
          }, this.easeOutExpo = function(t4, e3, i3, s2) {
            return i3 * (1 - Math.pow(2, -10 * t4 / s2)) * 1024 / 1023 + e3;
          }, this.options = s(s({}, this.defaults), i2), this.formattingFn = this.options.formattingFn ? this.options.formattingFn : this.formatNumber, this.easingFn = this.options.easingFn ? this.options.easingFn : this.easeOutExpo, this.startVal = this.validateValue(this.options.startVal), this.frameVal = this.startVal, this.endVal = this.validateValue(e2), this.options.decimalPlaces = Math.max(this.options.decimalPlaces), this.resetDuration(), this.options.separator = String(this.options.separator), this.useEasing = this.options.useEasing, "" === this.options.separator && (this.options.useGrouping = false), this.el = "string" == typeof t3 ? document.getElementById(t3) : t3, this.el ? this.printValue(this.startVal) : this.error = "[CountUp] target is null or undefined", "undefined" != typeof window && this.options.enableScrollSpy && (this.error ? console.error(this.error, t3) : (window.onScrollFns = window.onScrollFns || [], window.onScrollFns.push(function() {
            return a2.handleScroll(a2);
          }), window.onscroll = function() {
            window.onScrollFns.forEach(function(t4) {
              return t4();
            });
          }, this.handleScroll(this)));
        }
        return t2.prototype.handleScroll = function(t3) {
          if (t3 && window && !t3.once) {
            var e2 = window.innerHeight + window.scrollY, i2 = t3.el.getBoundingClientRect(), s2 = i2.top + window.pageYOffset, a2 = i2.top + i2.height + window.pageYOffset;
            a2 < e2 && a2 > window.scrollY && t3.paused ? (t3.paused = false, setTimeout(function() {
              return t3.start();
            }, t3.options.scrollSpyDelay), t3.options.scrollSpyOnce && (t3.once = true)) : (window.scrollY > a2 || s2 > e2) && !t3.paused && t3.reset();
          }
        }, t2.prototype.determineDirectionAndSmartEasing = function() {
          var t3 = this.finalEndVal ? this.finalEndVal : this.endVal;
          if (this.countDown = this.startVal > t3, Math.abs(t3 - this.startVal) > this.options.smartEasingThreshold && this.options.useEasing) {
            this.finalEndVal = t3;
            var e2 = this.countDown ? 1 : -1;
            this.endVal = t3 + e2 * this.options.smartEasingAmount, this.duration = this.duration / 2;
          } else this.endVal = t3, this.finalEndVal = null;
          null !== this.finalEndVal ? this.useEasing = false : this.useEasing = this.options.useEasing;
        }, t2.prototype.start = function(t3) {
          this.error || (this.options.onStartCallback && this.options.onStartCallback(), t3 && (this.options.onCompleteCallback = t3), this.duration > 0 ? (this.determineDirectionAndSmartEasing(), this.paused = false, this.rAF = requestAnimationFrame(this.count)) : this.printValue(this.endVal));
        }, t2.prototype.pauseResume = function() {
          this.paused ? (this.startTime = null, this.duration = this.remaining, this.startVal = this.frameVal, this.determineDirectionAndSmartEasing(), this.rAF = requestAnimationFrame(this.count)) : cancelAnimationFrame(this.rAF), this.paused = !this.paused;
        }, t2.prototype.reset = function() {
          cancelAnimationFrame(this.rAF), this.paused = true, this.resetDuration(), this.startVal = this.validateValue(this.options.startVal), this.frameVal = this.startVal, this.printValue(this.startVal);
        }, t2.prototype.update = function(t3) {
          cancelAnimationFrame(this.rAF), this.startTime = null, this.endVal = this.validateValue(t3), this.endVal !== this.frameVal && (this.startVal = this.frameVal, null == this.finalEndVal && this.resetDuration(), this.finalEndVal = null, this.determineDirectionAndSmartEasing(), this.rAF = requestAnimationFrame(this.count));
        }, t2.prototype.printValue = function(t3) {
          var e2;
          if (this.el) {
            var i2 = this.formattingFn(t3);
            (null == (e2 = this.options.plugin) ? void 0 : e2.render) ? this.options.plugin.render(this.el, i2) : "INPUT" === this.el.tagName ? this.el.value = i2 : "text" === this.el.tagName || "tspan" === this.el.tagName ? this.el.textContent = i2 : this.el.innerHTML = i2;
          }
        }, t2.prototype.ensureNumber = function(t3) {
          return "number" == typeof t3 && !isNaN(t3);
        }, t2.prototype.validateValue = function(t3) {
          var e2 = Number(t3);
          return this.ensureNumber(e2) ? e2 : (this.error = "[CountUp] invalid start or end value: ".concat(t3), null);
        }, t2.prototype.resetDuration = function() {
          this.startTime = null, this.duration = 1e3 * Number(this.options.duration), this.remaining = this.duration;
        }, t2;
      })();
    },
    77710: (t, e, i) => {
      "use strict";
      var s;
      i.d(e, { b: () => s }), (function(t2) {
        t2.Album = "album", t2.Artist = "artist", t2.Playlist = "playlist", t2.Radio = "fm_radio", t2.Other = "other", t2.Search = "search";
      })(s || (s = {}));
    },
    91165: (t, e, i) => {
      "use strict";
      function s(t2) {
        let { reason: e2, children: i2 } = t2;
        return i2;
      }
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return s;
        }
      }), i(39201);
    },
    96598: (t) => {
      t.exports = { root: "SlidesNotFoundPage_root__bmv9K", important: "SlidesNotFoundPage_important__VELWc" };
    },
    98944: (t, e, i) => {
      "use strict";
      function s(t2) {
        let { moduleIds: e2 } = t2;
        return null;
      }
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return s;
        }
      }), i(54486), i(92803), i(14367), i(32038);
    },
    99078: (t, e, i) => {
      Promise.resolve().then(i.t.bind(i, 96598, 23)), Promise.resolve().then(i.bind(i, 46965)), Promise.resolve().then(i.bind(i, 65034));
    }
  }
]);
