(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2353],
  {
    1456: (e) => {
      e.exports = {
        root: "PageHeaderPlaylistCover_root__Vdn75",
        coverButton: "PageHeaderPlaylistCover_coverButton__dw0rj",
        root_hoverable: "PageHeaderPlaylistCover_root_hoverable__ZeqpX",
        coverImage: "PageHeaderPlaylistCover_coverImage__OC58K",
        backCoverColor: "PageHeaderPlaylistCover_backCoverColor__7z3dk",
        button: "PageHeaderPlaylistCover_button__vCYgD",
        fileUploadContainer: "PageHeaderPlaylistCover_fileUploadContainer___JnqP",
        fileUploadContainer_hovered: "PageHeaderPlaylistCover_fileUploadContainer_hovered__RtD_X",
        buttonContainer: "PageHeaderPlaylistCover_buttonContainer__OkEaT",
        buttonContainer_withCursorPointer: "PageHeaderPlaylistCover_buttonContainer_withCursorPointer__pnzha",
        formFile: "PageHeaderPlaylistCover_formFile__1xnry"
      };
    },
    3476: (e) => {
      e.exports = {
        root: "PageHeaderBase_root__xMIBu",
        root_withCover: "PageHeaderBase_root_withCover__JIKxy",
        root_withCoverAndLogo: "PageHeaderBase_root_withCoverAndLogo__nsTU2",
        logo: "PageHeaderBase_logo__pD3fg",
        coverCell: "PageHeaderBase_coverCell__nBx4c",
        content: "PageHeaderBase_content___DNyv",
        info: "PageHeaderBase_info__GRcah",
        entityContainer: "PageHeaderBase_entityContainer__BDwxT",
        title_withDisclaimerLabel: "PageHeaderBase_title_withDisclaimerLabel__Apuhc",
        entityName: "PageHeaderBase_entityName__9Sj_Q",
        disclaimerLabel: "PageHeaderBase_disclaimerLabel___2wo6",
        meta: "PageHeaderBase_meta__bMvfR",
        meta_withDisclaimerLabel: "PageHeaderBase_meta_withDisclaimerLabel__nxckS",
        controls: "PageHeaderBase_controls__HzGgE"
      };
    },
    4962: (e) => {
      e.exports = {
        menuControl: "PageHeaderAlbumControls_menuControl__wlqyr",
        likeControl: "PageHeaderAlbumControls_likeControl__eohAO",
        pinOrDonationControl: "PageHeaderAlbumControls_pinOrDonationControl__3aFUW",
        trailerControl: "PageHeaderAlbumControls_trailerControl___HcW0"
      };
    },
    13008: (e) => {
      e.exports = {
        root: "PageHeaderPlaylistMeta_root__9SHZ0",
        description: "PageHeaderPlaylistMeta_description__edoVx",
        descriptionButton: "PageHeaderPlaylistMeta_descriptionButton__Jkbg9",
        descriptionLink: "PageHeaderPlaylistMeta_descriptionLink__OcY5m",
        updatedText: "PageHeaderPlaylistMeta_updatedText__FSo_0",
        descriptionActionLink: "PageHeaderPlaylistMeta_descriptionActionLink__aGgtK",
        addDescription: "PageHeaderPlaylistMeta_addDescription__bFw2Y",
        textField: "PageHeaderPlaylistMeta_textField__J5QMd",
        actionButtons: "PageHeaderPlaylistMeta_actionButtons__EYX8Z",
        saveButton: "PageHeaderPlaylistMeta_saveButton__rZbPS",
        cancelButton: "PageHeaderPlaylistMeta_cancelButton__Qc5lG"
      };
    },
    16560: (e, t, a) => {
      "use strict";
      a.d(t, { m: () => i });
      let i = (e2) => "object" == typeof e2 && null !== e2 && !Array.isArray(e2) && "source" in e2 && "adfox" === e2.source && "type" in e2 && "payload" in e2;
    },
    20175: (e) => {
      e.exports = {
        root: "PageHeaderConcert_root__zghAY",
        coverCell: "PageHeaderConcert_coverCell__0ppUT",
        cover: "PageHeaderConcert_cover__mJ4ml",
        controls: "PageHeaderConcert_controls__7Ggou",
        button: "PageHeaderConcert_button__zLikp",
        meta: "PageHeaderConcert_meta__5G1EX",
        cashbackBadge: "PageHeaderConcert_cashbackBadge__HL7QW",
        info: "PageHeaderConcert_info__wct3b",
        title: "PageHeaderConcert_title__MoRyD",
        coverButton: "PageHeaderConcert_coverButton__r79DU",
        important: "PageHeaderConcert_important__rx2pp",
        bottomContent: "PageHeaderConcert_bottomContent__d5YKQ",
        overview: "PageHeaderConcert_overview__vbGCy",
        overviewButton: "PageHeaderConcert_overviewButton__sXecu",
        overviewMessage: "PageHeaderConcert_overviewMessage__q95AL",
        overviewMessageModal: "PageHeaderConcert_overviewMessageModal__OlUO6",
        overviewModal: "PageHeaderConcert_overviewModal__6Ubd0"
      };
    },
    20609: (e) => {
      e.exports = {
        controlsContainer: "CommonPageHeader_controlsContainer__4_h22",
        controls: "CommonPageHeader_controls__c27E_",
        playControl: "CommonPageHeader_playControl__gYOuR"
      };
    },
    21884: (e) => {
      e.exports = {
        root: "PageHeaderTextField_root__Aq9UL",
        root_textarea: "PageHeaderTextField_root_textarea__OgDzd"
      };
    },
    26547: (e) => {
      e.exports = {
        root: "InfoBlock_root__2D2Mj",
        infoTitle: "InfoBlock_infoTitle___At72",
        link: "InfoBlock_link__iA21Q"
      };
    },
    27627: (e) => {
      e.exports = {
        root: "PageHeaderArtist_root__QhL_a",
        playControl: "PageHeaderArtist_playControl__N_3l_",
        trailerControl: "PageHeaderArtist_trailerControl__BWQXJ",
        likeControl: "PageHeaderArtist_likeControl__oEdXe",
        menuControl: "PageHeaderArtist_menuControl__8qi0J",
        pinControl: "PageHeaderArtist_pinControl__dQToz",
        donateControl: "PageHeaderArtist_donateControl__EX63H",
        controls: "PageHeaderArtist_controls__U_6g7",
        main: "PageHeaderArtist_main__VNnip",
        brandedControl: "PageHeaderArtist_brandedControl__b6qhV",
        meta: "PageHeaderArtist_meta__ZAlx_",
        label: "PageHeaderArtist_label__rXyrB",
        donationButtonTooltip: "PageHeaderArtist_donationButtonTooltip__G7XtX",
        tooltipText: "PageHeaderArtist_tooltipText__aYfaU",
        closeTooltip: "PageHeaderArtist_closeTooltip__z2w_O"
      };
    },
    32108: (e) => {
      e.exports = {
        root: "PageHeaderShimmer_root__kqSwa",
        cover: "PageHeaderShimmer_cover__ay2cr",
        content: "PageHeaderShimmer_content__SdBKK",
        info: "PageHeaderShimmer_info__cZkS2",
        entityName: "PageHeaderShimmer_entityName__tlWnA",
        title: "PageHeaderShimmer_title__xKG4e",
        meta: "PageHeaderShimmer_meta__YWx0m",
        controls: "PageHeaderShimmer_controls__gPErM",
        desktopPlayButton: "PageHeaderShimmer_desktopPlayButton__R7EmH",
        button: "PageHeaderShimmer_button__13qrG"
      };
    },
    32353: (e, t, a) => {
      "use strict";
      a.d(t, {
        c0: () => en,
        qi: () => ef,
        kE: () => B,
        Dc: () => eT,
        hW: () => eD,
        Jq: () => tr,
        c6: () => D,
        RR: () => I,
        e4: () => td,
        Wm: () => r,
        q: () => l
      });
      var i = a(74125);
      let r = (e10) => {
        if (!e10) return null;
        let { h: t2, s: a2, l: r2 } = (0, i.g8k)(e10), l2 = Math.min(70, Math.max(10, r2 + 10));
        return "hsl(".concat(t2, "deg, ").concat(a2, "%, ").concat(l2, "%)");
      }, l = (e10) => ({ controlSize: e10 ? "l" : "s", iconSize: e10 ? "m" : "xxs" });
      var o = a(54486), n = a(50420), s = a(28303), d = a(61910), c = a.t(d, 2), u = a(31500), _ = {
        5881: (e10, t2, a2) => {
          function i2() {
            for (var e11, t3, a3 = 0, i3 = ""; a3 < arguments.length; )
              (e11 = arguments[a3++]) && (t3 = (function e12(t4) {
                var a4, i4, r3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) r3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (a4 = 0; a4 < t4.length; a4++) t4[a4] && (i4 = e12(t4[a4])) && (r3 && (r3 += " "), r3 += i4);
                  else for (a4 in t4) t4[a4] && (r3 && (r3 += " "), r3 += a4);
                return r3;
              })(e11)) && (i3 && (i3 += " "), i3 += t3);
            return i3;
          }
          a2.r(t2), a2.d(t2, { clsx: () => i2, default: () => r2 });
          let r2 = i2;
        },
        9474: (e10, t2, a2) => {
          a2.r(t2), a2.d(t2, { default: () => i2 });
          let i2 = { root: "LizdJ2L0HW7JWOvPrfly" };
        },
        3641: (e10, t2, a2) => {
          a2.r(t2), a2.d(t2, { default: () => i2 });
          let i2 = {
            root_controls_xxs: "tRaaBpDMg9Qu8v6gKjtn",
            root_entity_xxs: "M9zvtlcpLUVn6DKdcHhj",
            root_text_xxs: "ln0PYYwDmFnfYxCDJsFU",
            root_controls_xs: "n5AeWEsJC3_AYXcbK4Lt",
            root_entity_xs: "__hrMKGmNbw54T54IUyh",
            root_text_xs: "SehSa7OyRpC2nzYTVb2Q",
            root_controls_s: "_oBLf5gprWsKjCw4Ce58",
            root_entity_s: "mxSPe5xpZnie9gpIqacd",
            root_text_s: "Ai2iRN9elHpk_u5splD6",
            root_controls_m: "tk7ahHRDYXJMMB879KUA",
            root_entity_m: "Z_WIr2W8JU4MPQek3hgR",
            root_text_m: "g3qWNP6xl__7qxNmtrvd",
            root_controls_l: "grvxapJE3vGArOKDWf6n",
            root_entity_l: "Esj5A1UeSi4xV4tZ839D",
            root_text_l: "V3WU123oO65AxsprotU9",
            root_weight_normal: "ZYV27jeWd30QDXu4GhaH",
            root_weight_medium: "_3_Mxw7Si7j2g4kWjlpR",
            root_weight_bold: "Vi7Rd0SZWqD17F0872TB"
          };
        },
        5153: (e10, t2, a2) => {
          a2.r(t2), a2.d(t2, { default: () => i2 });
          let i2 = {
            root_size_xs: "qJJ288377iHlWN_RXeEE",
            root_size_s: "_sd8Q9d_Ttn0Ufe4ISWS",
            root_size_m: "Ctk8dbecq31Qh7isOJPQ",
            root_size_l: "M_Djh6ppIkCO3A2k_BTA",
            root_size_xl: "dtxlzGQMPAbM2MEndXWX",
            root_size_xxl: "IUb9XLplTAoZqne9rNUL",
            root_size_xxxl: "ZYZamUwql_rfFR4RpI2B",
            root_size_xxxxl: "ZBZyxow5njdq8z5dnRPY",
            root_size_xxxxxl: "WdvQQNwdDNCdRSwRkAtT",
            root_weight_bold: "nSU6fV9y80WrZEfafvww",
            root_weight_black: "KBeGPPK4DinQzAP41Y_N"
          };
        },
        5818: (e10, t2, a2) => {
          a2.r(t2), a2.d(t2, { default: () => i2 });
          let i2 = {
            root: "_MWOVuZRvUQdXKTMcOPx",
            root_clamp: "LezmJlldtbHWqU7l1950",
            root_clamp_oneline: "oyQL2RSmoNbNQf3Vc6YI",
            root_clamp_multiline: "jMyoZB5J9iZbzJmWOrF0"
          };
        },
        9097: (e10, t2) => {
          var a2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function i2(e11, t3, i3) {
            var r2 = null;
            if (void 0 !== i3 && (r2 = "" + i3), void 0 !== t3.key && (r2 = "" + t3.key), "key" in t3)
              for (var l2 in i3 = {}, t3) "key" !== l2 && (i3[l2] = t3[l2]);
            else i3 = t3;
            return { $$typeof: a2, type: e11, key: r2, ref: void 0 !== (t3 = i3.ref) ? t3 : null, props: i3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = i2, t2.jsxs = i2;
        },
        4377: (e10, t2, a2) => {
          e10.exports = a2(9097);
        },
        2: function(e10, t2, a2) {
          var i2 = this && this.__importDefault || function(e11) {
            return e11 && e11.__esModule ? e11 : { default: e11 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Label = void 0;
          let r2 = a2(4377), l2 = a2(5881), o2 = a2(2582), n2 = i2(a2(9474));
          t2.Label = (e11) => {
            let { children: t3, className: a3, size: i3 = "s", ...s2 } = e11;
            return (0, r2.jsx)(o2.Caption, {
              variant: "div",
              type: "text",
              size: i3,
              lineClamp: 1,
              className: (0, l2.clsx)(n2.default.root, a3),
              ...s2,
              children: t3
            });
          };
        },
        7743: function(e10, t2, a2) {
          var i2 = this && this.__importDefault || function(e11) {
            return e11 && e11.__esModule ? e11 : { default: e11 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Caption = t2.CaptionComponent = void 0;
          let r2 = a2(4377), l2 = a2(5881), o2 = a2(810), n2 = a2(4721), s2 = i2(a2(3641));
          t2.CaptionComponent = (e11) => {
            let {
              forwardRef: t3,
              variant: a3,
              type: i3 = "text",
              size: o3 = "s",
              className: d2,
              children: c2,
              weight: u2 = "medium",
              ..._2
            } = e11;
            return (0, r2.jsx)(n2.Typography, {
              variant: a3,
              ref: t3,
              className: (0, l2.clsx)(
                s2.default.root,
                s2.default["root_".concat(i3, "_").concat(o3)],
                s2.default["root_weight_".concat(u2)],
                d2
              ),
              ..._2,
              children: c2
            });
          }, t2.Caption = (0, o2.forwardRef)((e11, a3) => (0, r2.jsx)(t2.CaptionComponent, { forwardRef: a3, ...e11 }));
        },
        404: function(e10, t2, a2) {
          var i2 = this && this.__importDefault || function(e11) {
            return e11 && e11.__esModule ? e11 : { default: e11 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.HeadingComponent = void 0;
          let r2 = a2(4377), l2 = a2(5881), o2 = a2(810), n2 = a2(4721), s2 = i2(a2(5153));
          t2.HeadingComponent = (e11) => {
            let { forwardRef: t3, variant: a3, weight: i3 = "bold", size: o3 = "s", className: d2, children: c2, ...u2 } = e11;
            return (0, r2.jsx)(n2.Typography, {
              variant: a3,
              ref: t3,
              className: (0, l2.clsx)(
                s2.default.root,
                s2.default["root_size_".concat(o3)],
                s2.default["root_weight_".concat(i3)],
                d2
              ),
              ...u2,
              children: c2
            });
          }, t2.Heading = (0, o2.forwardRef)((e11, a3) => (0, r2.jsx)(t2.HeadingComponent, { forwardRef: a3, ...e11 }));
        },
        4721: function(e10, t2, a2) {
          var i2 = this && this.__importDefault || function(e11) {
            return e11 && e11.__esModule ? e11 : { default: e11 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Typography = t2.TypographyComponent = void 0;
          let r2 = a2(4377), l2 = a2(5881), o2 = a2(810), n2 = i2(a2(5818));
          function s2(e11) {
            let { forwardRef: t3, style: a3, className: i3, children: o3, variant: s3, lineClamp: d2, ...c2 } = e11, u2 = d2 && "string" == typeof o3 ? o3 : void 0;
            return (0, r2.jsx)(s3, {
              style: { ...a3, WebkitLineClamp: d2 },
              ref: t3,
              title: u2,
              className: (0, l2.clsx)(
                n2.default.root,
                {
                  [n2.default.root_clamp]: d2 && d2 > 0,
                  [n2.default.root_clamp_oneline]: d2 && 1 === d2,
                  [n2.default.root_clamp_multiline]: d2 && d2 > 1
                },
                i3
              ),
              ...c2,
              children: o3
            });
          }
          t2.TypographyComponent = s2, t2.Typography = (0, o2.forwardRef)((e11, t3) => (0, r2.jsx)(s2, { forwardRef: t3, ...e11 }));
        },
        2582: (e10, t2, a2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.Caption = void 0;
          var i2 = a2(7743);
          Object.defineProperty(t2, "Caption", {
            enumerable: true,
            get: function() {
              return i2.Caption;
            }
          });
          var r2 = a2(404);
          Object.defineProperty(t2, "Heading", {
            enumerable: true,
            get: function() {
              return r2.Heading;
            }
          });
        },
        810: (e10) => {
          e10.exports = c;
        }
      }, p = {};
      function m(e10) {
        var t2 = p[e10];
        if (void 0 !== t2) return t2.exports;
        var a2 = p[e10] = { exports: {} };
        return _[e10].call(a2.exports, a2, a2.exports, m), a2.exports;
      }
      m.d = (e10, t2) => {
        for (var a2 in t2) m.o(t2, a2) && !m.o(e10, a2) && Object.defineProperty(e10, a2, { enumerable: true, get: t2[a2] });
      }, m.o = (e10, t2) => Object.prototype.hasOwnProperty.call(e10, t2), m.r = (e10) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e10, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e10, "__esModule", { value: true });
      };
      var v = {};
      (() => {
        Object.defineProperty(v, "__esModule", { value: true }), v.Label = void 0;
        var e10 = m(2);
        Object.defineProperty(v, "Label", {
          enumerable: true,
          get: function() {
            return e10.Label;
          }
        });
      })();
      var x = v.Label;
      v.__esModule;
      var g = a(97800), y = a(3476), f = a.n(y), h = a(43426), b = a(8817), C = a(27510), P = a(77881), A = a(5956), j = a(33276), N = a(80585), k = a(21884), T = a.n(k);
      let w = (0, s.PA)((e10) => {
        let {
          className: t2,
          text: a2 = "",
          maxTextLength: i2,
          minTextLength: r2,
          variant: l2 = "input",
          shouldFinishOnKeyPress: s2 = false,
          placeholder: c2,
          onChangeFinish: u2
        } = e10, [_2, p2] = (0, d.useState)(a2), m2 = (0, d.useRef)(false), v2 = (0, d.useRef)(null), x2 = (0, d.useCallback)((e11) => {
          p2(e11.target.value);
        }, []), g2 = (0, d.useCallback)(
          (e11) => {
            if (s2 && ["Enter", "Escape"].includes(e11.key)) {
              var t3;
              "Escape" === e11.key && (m2.current = true), null == (t3 = e11.currentTarget) || t3.blur();
            }
          },
          [s2]
        ), y2 = (0, d.useCallback)(() => {
          let e11 = _2.trim();
          m2.current || r2 && e11.length < r2 ? (m2.current = false, null == u2 || u2(a2)) : null == u2 || u2(e11);
        }, [_2, m2, r2, u2, a2]);
        (0, d.useEffect)(() => {
          v2.current && (v2.current.selectionStart = v2.current.value.length, v2.current.selectionEnd = v2.current.value.length);
        }, []), (0, d.useLayoutEffect)(() => {
          let e11 = v2.current;
          if (e11) {
            e11.style.height = "0px";
            let t3 = e11.scrollHeight;
            e11.style.height = "".concat(t3, "px");
          }
        }, [v2, _2]);
        let f2 = (0, d.useMemo)(
          () => "textarea" === l2 ? (e11) => (0, o.jsx)("textarea", { ref: v2, rows: 6, ...e11 }) : (e11) => (0, o.jsx)("input", { ...e11 }),
          [l2]
        );
        return (0, o.jsx)(f2, {
          className: (0, n.$)(T().root, t2, { [T().root_textarea]: "textarea" === l2 }),
          type: "text",
          value: _2,
          maxLength: i2,
          onBlur: y2,
          onChange: x2,
          onKeyDown: g2,
          placeholder: c2,
          autoFocus: true
        });
      });
      var L = a(66824), H = a.n(L);
      let I = (0, s.PA)((e10) => {
        let {
          title: t2 = "",
          "aria-labelledby": a2,
          canChange: r2 = false,
          onChange: l2,
          maxTitleLength: s2,
          version: c2 = "",
          onVersionClick: _2,
          className: p2,
          headingVariant: m2 = "h2",
          withHeadingClamp: v2 = true,
          link: x2,
          onTitleLinkClick: y2
        } = e10, {
          settings: { isMobile: f2 }
        } = (0, i.Pjs)(), { formatMessage: k2 } = (0, h.A)(), [T2, L2] = (0, d.useState)(false), I2 = (0, d.useRef)(null), E2 = t2.length + c2.length > 25, B2 = (0, i.ZpR)(null != x2 ? x2 : ""), M2 = (0, b.c)((e11) => {
          null == y2 || y2(), B2(e11);
        }), R2 = (0, d.useMemo)(
          () => f2 ? { font: H().font_mobile, iconLink: H().arrowWrapper_mobile } : E2 ? { font: H().font_long, iconLink: H().arrowWrapper_long } : { font: H().font_short, iconLink: H().arrowWrapper_short },
          [f2, E2]
        ), S2 = !f2 && r2 && T2, D2 = (0, d.useCallback)(() => {
          var e11;
          L2(true), null == (e11 = I2.current) || e11.focus();
        }, []), O2 = (0, d.useCallback)(
          (e11) => {
            L2(false), null == l2 || l2(e11);
          },
          [l2]
        ), z2 = (0, C.L)(
          () => (0, o.jsx)("span", {
            className: (0, n.$)(H().arrowWrapper, R2.iconLink),
            children: (0, o.jsx)(A.Icon, { className: H().titleWithLinkIcon, size: "xs", variant: "arrowRight" })
          })
        ), U2 = (0, C.L)(
          () => (0, o.jsxs)(g.Heading, {
            variant: m2,
            id: a2,
            lineClamp: f2 && v2 ? 2 : void 0,
            className: (0, n.$)(H().heading, { [H().heading_withVersion]: c2 }),
            ...(0, u.Am)(u.e8.pageHeader.ENTITY_TITLE),
            children: [
              (0, o.jsx)(g.Caption, {
                className: (0, n.$)(H().font, R2.font, H().title),
                variant: "span",
                children: t2
              }),
              c2 && (0, o.jsx)(g.Caption, {
                onClick: _2,
                className: (0, n.$)(H().font, R2.font, H().version, { [H().version_withOtherVersions]: _2 }),
                variant: "span",
                ...(0, u.Am)(u.e8.pageHeader.ENTITY_VERSION),
                children: " ".concat(c2)
              }),
              x2 && !f2 && z2
            ]
          })
        ), F2 = (0, C.L)(
          () => x2 ? (0, o.jsxs)(N.N_, {
            className: H().titleWithLink,
            containerClassName: H().linkContainer,
            textClassName: H().linkText,
            href: x2,
            onClick: M2,
            children: [U2, f2 && z2]
          }) : U2
        );
        return (0, o.jsxs)(o.Fragment, {
          children: [
            !S2 && (0, o.jsxs)("div", {
              className: (0, n.$)(H().root, p2),
              children: [
                (0, o.jsx)(j.jp, { title: t2, className: H().stickyTitle, children: F2 }),
                r2 && (0, o.jsx)("div", {
                  className: (0, n.$)(H().editButton, { [H().editButton_centered]: !E2 && !f2 }),
                  children: (0, o.jsx)(P.$, {
                    onClick: D2,
                    "aria-label": k2({ id: "playlist-actions.change-title" }),
                    icon: (0, o.jsx)(A.Icon, { size: "xxs", variant: "pencil" }),
                    size: "s",
                    radius: "round",
                    ...(0, u.Am)(u.e8.pageHeader.EDIT_TITLE_BUTTON)
                  })
                })
              ]
            }),
            S2 && (0, o.jsx)("div", {
              className: H().textFieldContainer,
              children: (0, o.jsx)(w, {
                text: t2,
                className: (0, n.$)(H().font, R2.font, H().textField, H().title, { [H().textField_long]: E2 && !f2 }),
                onChangeFinish: O2,
                maxTextLength: s2,
                minTextLength: 1,
                placeholder: k2({ id: "playlist-actions.enter-title" }),
                shouldFinishOnKeyPress: true
              })
            })
          ]
        });
      }), E = (0, s.PA)((e10) => {
        let {
          "aria-labelledby": t2,
          entityName: a2,
          title: i2,
          meta: r2,
          controls: l2,
          className: s2,
          forwardRef: c2,
          canChangeTitle: _2 = false,
          maxTitleLength: p2,
          onTitleChange: m2,
          cover: v2,
          version: y2,
          onVersionClick: h2,
          disclaimerLabel: b2,
          entityNameIcon: C2,
          headingVariant: P2,
          titleClassName: A2,
          metaClassName: j2,
          contentClassName: N2,
          withHeadingClamp: k2,
          entityNameClassName: T2,
          logo: w2,
          coverCellClassName: L2,
          infoClassName: H2,
          linkTitle: E2,
          onTitleLinkClick: B2
        } = e10, M2 = (0, d.useMemo)(
          () => b2 ? (0, o.jsx)("div", {
            className: f().entityContainer,
            children: (0, o.jsx)(x, {
              size: "m",
              className: f().disclaimerLabel,
              ...(0, u.Am)(u.e8.pageHeader.DISCLAIMER_LABEL),
              children: b2
            })
          }) : (0, o.jsxs)(g.Caption, {
            variant: "div",
            type: "text",
            size: "m",
            weight: "medium",
            className: (0, n.$)(f().entityName, T2),
            ...(0, u.Am)(u.e8.pageHeader.ENTITY_NAME),
            children: [a2, C2]
          }),
          [b2, a2, T2, C2]
        );
        return (0, o.jsxs)("div", {
          className: (0, n.$)(
            f().root,
            {
              [f().root_withCover]: (0, d.isValidElement)(v2),
              [f().root_withCoverAndLogo]: (0, d.isValidElement)(w2) && (0, d.isValidElement)(v2)
            },
            s2
          ),
          ref: c2,
          ...(0, u.Am)(u.e8.pageHeader.ENTITY_HEADER),
          children: [
            v2 && (0, o.jsx)("div", { className: (0, n.$)(f().coverCell, L2), children: v2 }),
            (0, o.jsxs)("div", {
              className: (0, n.$)(f().content, N2),
              children: [
                (0, o.jsxs)("div", {
                  className: (0, n.$)(f().info, H2),
                  children: [
                    M2,
                    (0, o.jsx)(I, {
                      onTitleLinkClick: B2,
                      link: E2,
                      className: (0, n.$)(f().title, A2, { [f().title_withDisclaimerLabel]: !!b2 }),
                      title: i2,
                      "aria-labelledby": t2,
                      canChange: _2,
                      maxTitleLength: p2,
                      onChange: m2,
                      version: y2,
                      onVersionClick: h2,
                      headingVariant: P2,
                      withHeadingClamp: k2
                    }),
                    !!r2 && (0, o.jsx)("div", {
                      className: (0, n.$)(f().meta, { [f().meta_withDisclaimerLabel]: !!b2 }, j2),
                      children: r2
                    })
                  ]
                }),
                (0, o.jsx)("div", {
                  className: f().controls,
                  ...(0, u.Am)(u.e8.pageHeader.BASE_PAGE_HEADER_CONTROLS),
                  children: l2
                })
              ]
            }),
            (0, d.isValidElement)(w2) && (0, o.jsx)("div", { className: f().logo, children: w2 })
          ]
        });
      }), B = (0, d.forwardRef)((e10, t2) => (0, o.jsx)(E, { forwardRef: t2, ...e10 }));
      var M = a(22674), R = a(32108), S = a.n(R);
      let D = (0, s.PA)((e10) => {
        let { className: t2, coverRadius: a2 = "m", isActive: r2 } = e10, {
          settings: { isMobile: l2 }
        } = (0, i.Pjs)(), s2 = (0, d.useMemo)(
          () => l2 ? (0, o.jsxs)("div", {
            className: S().controls,
            children: [
              (0, o.jsx)(M.Shimmer, { className: S().button, radius: "round", isActive: r2 }),
              (0, o.jsx)(M.Shimmer, { className: S().button, radius: "round", isActive: r2 }),
              (0, o.jsx)(M.Shimmer, { className: S().button, radius: "round", isActive: r2 })
            ]
          }) : (0, o.jsxs)("div", {
            className: S().controls,
            children: [
              (0, o.jsx)(M.Shimmer, { className: S().desktopPlayButton, isActive: r2 }),
              (0, o.jsx)(M.Shimmer, { className: S().button, radius: "round", isActive: r2 }),
              (0, o.jsx)(M.Shimmer, { className: S().button, radius: "round", isActive: r2 }),
              (0, o.jsx)(M.Shimmer, { className: S().button, radius: "round", isActive: r2 })
            ]
          }),
          [r2, l2]
        );
        return (0, o.jsxs)("div", {
          className: (0, n.$)(S().root, t2),
          children: [
            (0, o.jsx)(M.Shimmer, { className: S().cover, radius: a2, isActive: r2 }),
            (0, o.jsxs)("div", {
              className: S().content,
              children: [
                (0, o.jsxs)("div", {
                  className: S().info,
                  children: [
                    (0, o.jsx)(M.Shimmer, { className: S().entityName, radius: "s", isActive: r2 }),
                    (0, o.jsx)(M.Shimmer, { className: S().title, radius: "xl", isActive: r2 }),
                    (0, o.jsx)(M.Shimmer, { className: S().meta, radius: "s", isActive: r2 })
                  ]
                }),
                s2
              ]
            })
          ]
        });
      });
      var O = a(47713), z = a(63585), U = a(46423), F = a(43350), V = a(94376), W = a(4962), Y = a.n(W);
      let Q = (0, s.PA)((e10) => {
        var t2;
        let { album: a2, likeButtonAriaLabel: r2, withLikeButton: n2 = true, donationButton: s2 } = e10, {
          user: c2,
          settings: { isMobile: _2 },
          trailer: p2,
          albumCPA: { isPlusCPAEnabled: m2 }
        } = (0, i.Pjs)(), [v2, x2] = (0, d.useState)(false), y2 = (0, U.KX)(a2), f2 = (0, U.A7)(a2), { formatNumber: P2 } = (0, h.A)(), j2 = (0, i.Ftl)(), { utmLink: k2 } = (0, i.fyy)({ contextId: a2.id, contextType: z.K.Album }), T2 = (0, i.PT7)(), { controlSize: w2, iconSize: L2 } = l(_2), { pageAlbumId: H2 } = (0, i.THB)(), I2 = !m2({ pageAlbumId: H2, albumId: a2.id, isNonMusic: a2.isNonMusic }) && !c2.isAuthorized, E2 = (0, b.c)(() => {
          T2() || (p2.setUtmLink(k2), p2.openAlbumTrailer(a2.id), j2(F.ky.Album, String(a2.id)));
        }), B2 = (0, d.useMemo)(() => {
          var e11;
          return (null == (e11 = a2.trailer) ? void 0 : e11.isAvailable) && !_2 ? (0, o.jsx)(N.cv, {
            children: (0, o.jsx)(N.kJ, {
              size: "s",
              radius: "xxxl",
              iconSize: "xxs",
              className: Y().trailerControl,
              disabled: !a2.isAvailable,
              onClick: E2,
              children: (0, o.jsx)(O.A, { id: "entity-names.trailer" })
            })
          }) : null;
        }, [null == (t2 = a2.trailer) ? void 0 : t2.isAvailable, a2.isAvailable, E2, _2]), M2 = (0, C.L)(() => {
          if (!_2)
            return (0, d.isValidElement)(s2) ? s2 : (0, o.jsx)(N.O0, {
              size: w2,
              iconSize: L2,
              onClick: f2,
              isPinned: a2.isPinned,
              isDisabled: !a2.isAvailable
            });
        }), R2 = (0, C.L)(() => {
          if (a2.actualLikesCount && 0 !== a2.actualLikesCount && !_2)
            return (0, o.jsx)(g.Caption, {
              variant: "span",
              type: "controls",
              size: "s",
              weight: "medium",
              children: a2.actualLikesCount && P2(a2.actualLikesCount)
            });
        }), S2 = (0, C.L)(() => {
          if (n2)
            return (0, o.jsx)(N.cy, {
              className: Y().likeControl,
              isLiked: a2.isLiked,
              onClick: y2,
              variant: "default",
              size: w2,
              iconSize: L2,
              withRipple: !_2,
              disabled: I2,
              "aria-label": r2,
              children: R2
            });
        });
        return (0, o.jsxs)(o.Fragment, {
          children: [
            B2,
            S2,
            (0, d.isValidElement)(M2) && (0, o.jsx)("div", { className: Y().pinOrDonationControl, children: M2 }),
            (0, o.jsx)(V.kz, {
              album: a2,
              open: v2,
              onOpenChange: x2,
              wrapperClassName: Y().menuControl,
              size: w2,
              icon: (0, o.jsx)(A.Icon, { size: L2, variant: "more" }),
              variant: V.zh.PAGE,
              ...(0, u.Am)(u.e8.pageHeader.ALBUM_HEADER_CONTEXT_MENU_BUTTON)
            })
          ]
        });
      });
      var $ = a(6971), K = a(63695);
      let X = function() {
        let e10 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t2 = e10.filter((e11) => !e11.isComposer), a2 = t2.filter((e11) => !e11.various), i2 = e10.filter((e11) => e11.isComposer && !e11.various), r2 = [];
        return a2.length > 0 ? r2 = a2 : t2.length > 0 && (r2 = t2), r2.concat(i2);
      };
      var q = a(58714), G = a.n(q);
      let Z = (0, s.PA)((e10) => {
        var t2, a2, r2;
        let { album: l2, withArtistLink: s2 = true } = e10, {
          settings: { isMobile: c2 }
        } = (0, i.Pjs)(), _2 = (0, d.useMemo)(() => X(l2.artists), [l2.artists]), p2 = (null == _2 ? void 0 : _2.length) === 1 && !(null == (t2 = _2[0]) ? void 0 : t2.decomposed) && !(null == (a2 = _2[0]) ? void 0 : a2.various);
        return (0, o.jsxs)("div", {
          className: G().meta,
          children: [
            p2 && (0, o.jsx)($.Paper, {
              radius: "round",
              className: G().artistCover,
              children: (0, o.jsx)(N.BW, {
                src: null == (r2 = _2[0]) ? void 0 : r2.coverUri,
                size: 30,
                withAvatarReplace: true
              })
            }),
            (0, o.jsx)(K.iQ, {
              artists: _2,
              lineClamp: c2 ? 1 : void 0,
              className: G().artists,
              spoilerClassName: G().artistsSpoiler,
              visibleArtistsCount: c2 ? void 0 : 2,
              linkClassName: G().artistLink,
              captionClassName: G().artistLabel,
              variant: c2 ? "breakAll" : "breakWord",
              withLink: s2
            }),
            l2.year && (0, o.jsx)(g.Caption, {
              variant: "div",
              type: "text",
              size: "m",
              weight: "medium",
              className: (0, n.$)(G().year, { [G().year_dot]: _2.length > 0 }),
              ...(0, u.Am)(u.e8.pageHeader.ALBUM_RELEASE_DATE),
              children: l2.year
            })
          ]
        });
      });
      var J = a(64396), ee = a.n(J);
      let et = (e10) => {
        let {
          coverVariant: t2,
          coverUri: a2,
          isAvailable: i2,
          className: r2,
          withPlusBadge: l2,
          onClick: s2,
          "aria-label": d2,
          customCover: c2,
          buttonClassName: _2
        } = e10;
        return (0, o.jsxs)($.Paper, {
          radius: "round" === t2 ? "round" : "m",
          className: (0, n.$)(ee().root, r2, { [ee().root_hoverable]: !!s2 }),
          children: [
            (0, o.jsx)(P.$, {
              className: (0, n.$)(ee().coverButton, _2),
              onClick: s2,
              "aria-label": d2,
              tabIndex: s2 ? 0 : -1,
              disabled: !s2,
              ...(0, u.Am)(u.S7.ENTITY_COVER_BUTTON),
              children: c2 || (0, o.jsx)(N.BW, {
                fit: "cover",
                src: a2,
                size: 300,
                className: ee().coverImage,
                withAvatarReplace: true,
                isAvailable: i2
              })
            }),
            l2 && (0, o.jsx)(A.Icon, { variant: "plusBadge", className: ee().plusBadge })
          ]
        });
      };
      var ea = a(20609), ei = a.n(ea), er = a(87767), el = a.n(er);
      let eo = (0, s.PA)((e10) => {
        let { album: t2, donationButton: a2, className: r2, "aria-labelledby": l2, forwardRef: n2, onVersionClick: s2 } = e10, { formatMessage: c2 } = (0, h.A)(), { shouldShowBuySubscriptionModal: u2, showBuySubscriptionModal: _2 } = (0, i.qBP)(), p2 = (0, i.brA)(), { from: m2, utmLink: v2 } = (0, i.fyy)({
          pageId: i._Q$.ALBUM,
          blockId: i.UfI.ALBUM,
          contextType: z.K.Album,
          contextId: t2.id
        }), x2 = (0, i.PT7)(), {
          user: g2,
          settings: { isMobile: y2 },
          sonataState: f2,
          track: { isTrackPage: C2 },
          modals: { imageSliderModal: P2 },
          albumCPA: { isPlusCPAPlayerBarEnabled: j2 }
        } = (0, i.Pjs)(), k2 = !g2.hasPlus && t2.isAvailableOnlyForPlus, T2 = !!t2.coverUri, w2 = j2(t2.id, t2.isNonMusic), L2 = (0, U.r_)(t2.type), H2 = (0, d.useMemo)(() => {
          if (t2.shouldShowBooksBadge)
            return (0, o.jsx)(A.Icon, { variant: "booksLogo", className: el().booksLogo });
        }, [t2.shouldShowBooksBadge]), { isPlaying: I2, togglePlay: E2 } = (0, i.Dx4)({
          playContextParams: {
            contextData: { type: z.K.Album, meta: { id: t2.id }, from: m2, utmLink: v2 },
            loadContextMeta: true,
            entitiesData: f2.unloadedEntitiesDataFromModels
          }
        }), M2 = (0, b.c)(() => {
          t2.coverUri && P2.openImages({ images: [t2.coverUri] });
        }), R2 = (0, b.c)(() => {
          if (!x2()) {
            if (u2 && !w2) return void _2();
            E2(), p2(!I2);
          }
        }), S2 = (0, d.useMemo)(
          () => k2 ? (0, o.jsx)(N.w1, { className: el().plusPaywallButton, albumType: t2.type }) : y2 ? (0, o.jsx)(N.DM, {
            className: ei().playControl,
            color: "primary",
            buttonVariant: "default",
            iconSize: "xxl",
            isPlaying: I2,
            onClick: R2,
            variant: "filled",
            disabled: !t2.isAvailable
          }) : (0, o.jsx)(N.DM, {
            className: ei().playControl,
            withRipple: true,
            buttonVariant: "default",
            radius: "xxxl",
            size: "s",
            color: "primary",
            iconSize: "xxs",
            isPlaying: I2,
            onClick: R2,
            disabled: !t2.isAvailable,
            children: (0, o.jsx)(O.A, { id: "player-actions.listen" })
          }),
          [k2, y2, I2, R2, t2.isAvailable, t2.type]
        ), D2 = (0, d.useMemo)(
          () => (0, o.jsx)("div", {
            className: ei().controlsContainer,
            children: (0, o.jsxs)("div", {
              className: ei().controls,
              children: [S2, (0, o.jsx)(Q, { donationButton: a2, album: t2, withLikeButton: !k2 })]
            })
          }),
          [t2, a2, S2, k2]
        );
        return (0, o.jsx)(B, {
          ref: n2,
          headingVariant: C2 ? "div" : "h1",
          className: r2,
          controls: D2,
          meta: (0, o.jsx)(Z, { album: t2 }),
          entityName: L2,
          entityNameIcon: H2,
          title: t2.title,
          cover: (0, o.jsx)(et, {
            coverVariant: "square",
            coverUri: t2.coverUri,
            isAvailable: t2.isAvailable,
            withPlusBadge: t2.isAvailableOnlyForPlus,
            onClick: T2 ? M2 : void 0,
            "aria-label": T2 ? c2({ id: "slider.view-cover" }) : void 0
          }),
          "aria-labelledby": l2,
          version: t2.version,
          onVersionClick: s2
        });
      }), en = (0, d.forwardRef)((e10, t2) => (0, o.jsx)(eo, { forwardRef: t2, ...e10 }));
      var es = a(55616), ed = a(7981), ec = a(1365);
      let eu = (0, s.PA)((e10) => {
        let { url: t2, iconSize: a2, controlSize: r2, className: l2, "aria-label": n2, ref: s2 } = e10, d2 = (0, i.ZpR)(t2), c2 = (0, ed.cg)(), u2 = (0, ed.CC)(), { ref: _2, intersectionPropertyId: p2 } = (0, i.nMI)({ callback: u2, withViewUuid: true }), m2 = (0, b.c)((e11) => {
          c2(F.QT.Link, t2), d2(e11);
        });
        return (0, o.jsx)("div", {
          ref: s2,
          "data-intersection-property-id": i.NZ,
          className: l2,
          children: (0, o.jsx)(ed.vK, {
            "data-intersection-property-id": p2,
            iconSize: a2,
            size: r2,
            onClick: m2,
            ref: _2,
            "aria-label": n2
          })
        });
      });
      var e_ = a(67648), ep = a(93666), em = a(27627), ev = a.n(em);
      let ex = { width: 20, height: 8, tipRadius: 2, fill: "var(--ym-background-color-primary-enabled-tooltip)" }, eg = (e10) => {
        let { children: t2 } = e10, {
          settings: { isMobile: a2 }
        } = (0, i.Pjs)(), { contentRef: r2 } = (0, i.gKY)(), { setIsOnboardingOpened: l2 } = (0, i.wD7)(), [n2, s2] = (0, e_.d)(), c2 = (0, i.zzi)({ id: i.hCo.ARTIST_DONATION_BUTTON, ref: n2 }), [u2, _2] = (0, d.useState)(c2), p2 = (0, b.c)(() => {
          _2(false), l2(false);
        }), m2 = (0, b.c)((e11) => {
          e11 || (p2(), l2(false));
        });
        return (0, o.jsxs)(ep.m_, {
          placement: a2 ? "top" : "right",
          arrowProps: ex,
          offsetOptions: 14,
          isHoverEnabled: false,
          open: u2,
          onOpenChange: m2,
          enableAriaDescribedby: true,
          referenceRef: s2,
          children: [
            t2,
            (0, o.jsxs)(ep.ZI, {
              className: ev().donationButtonTooltip,
              rootNode: r2,
              children: [
                (0, o.jsx)(P.$, {
                  icon: (0, o.jsx)(A.Icon, { variant: "close", size: "xxs" }),
                  onClick: p2,
                  variant: "text",
                  className: ev().closeTooltip,
                  withRipple: false
                }),
                (0, o.jsx)(g.Caption, {
                  variant: "span",
                  className: ev().tooltipText,
                  children: (0, o.jsx)(O.A, {
                    id: "onboarding.artist-donation-button-1",
                    values: { br: (0, o.jsx)("br", {}) }
                  })
                })
              ]
            })
          ]
        });
      }, ey = (0, s.PA)((e10) => {
        var t2, a2, n2, s2, c2, _2;
        let { className: p2, artistMeta: m2, entitiesData: v2, forwardRef: x2, onCoverClick: y2 } = e10, { shouldShowBuySubscriptionModal: f2, showBuySubscriptionModal: C2 } = (0, i.qBP)(), { from: j2, utmLink: k2 } = (0, i.fyy)({
          pageId: i._Q$.ARTIST,
          blockId: i.UfI.ARTIST,
          contextType: z.K.Artist,
          contextId: null == m2 ? void 0 : m2.artist.id
        }), T2 = (0, K.KX)(null == m2 ? void 0 : m2.artist), w2 = (0, K.A7)(null == m2 ? void 0 : m2.artist), L2 = (0, i.Ftl)(), { formatMessage: H2 } = (0, h.A)(), [I2, E2] = (0, d.useState)(false), {
          settings: { isMobile: M2 },
          trailer: R2,
          user: S2,
          slam: { isOfflineModeEnabled: D2 }
        } = (0, i.Pjs)(), U2 = (0, i.brA)(), V2 = (0, i.PT7)(), W2 = (0, ed.Q$)(), Y2 = !!(null == m2 || null == (t2 = m2.artist.trailer) ? void 0 : t2.isAvailable) && !M2, Q2 = !M2, $2 = !!(null == m2 ? void 0 : m2.donationUrl), X2 = (0, i.coI)(null == m2 ? void 0 : m2.artist), q2 = (() => {
          let [e11, t3] = (0, d.useState)(window.innerWidth < 1120), a3 = (0, d.useMemo)(
            () => (0, ec.A)(
              () => {
                t3(window.innerWidth < 1120);
              },
              100,
              { trailing: false }
            ),
            [t3]
          );
          return (0, d.useEffect)(
            () => (window.addEventListener("resize", a3), a3(), () => {
              window.removeEventListener("resize", a3);
            }),
            [a3]
          ), e11;
        })(), { controlSize: G2, iconSize: Z2 } = l(M2), J2 = (0, d.useMemo)(
          () => (null == m2 ? void 0 : m2.artist.isComposer) ? H2({ id: "entity-names.composer" }) : H2({ id: "entity-names.singer" }),
          [H2, null == m2 ? void 0 : m2.artist.isComposer]
        ), ee2 = !!(null == m2 ? void 0 : m2.brandedButton) && !D2, ea2 = (0, i.ZpR)(null != (_2 = null == m2 || null == (a2 = m2.brandedButton) ? void 0 : a2.url) ? _2 : ""), ei2 = !q2 || q2 && !ee2, { isPlaying: er2, togglePlay: el2 } = (0, i.Dx4)({
          playContextParams: {
            contextData: {
              type: D2 ? z.K.Various : z.K.Artist,
              meta: { id: Number(null == m2 ? void 0 : m2.artist.id) },
              from: j2,
              utmLink: k2
            },
            loadContextMeta: !D2,
            entitiesData: v2
          }
        }), eo2 = (0, b.c)(() => {
          if (!V2()) {
            if (f2) return void C2();
            el2(), U2(!er2);
          }
        }), en2 = (0, d.useMemo)(() => {
          var e11, t3;
          return M2 ? (0, o.jsx)(N.DM, {
            className: ev().playControl,
            color: "primary",
            buttonVariant: "default",
            iconSize: "xxl",
            isPlaying: er2,
            variant: "filled",
            onClick: eo2,
            disabled: !(null == m2 || null == (t3 = m2.artist) ? void 0 : t3.isAvailableForPlaying) || !m2.artist.isAvailable
          }) : (0, o.jsx)(N.DM, {
            className: ev().playControl,
            withRipple: true,
            buttonVariant: "default",
            radius: "xxxl",
            size: "s",
            color: "primary",
            iconSize: "xxs",
            isPlaying: er2,
            disabled: !(null == m2 || null == (e11 = m2.artist) ? void 0 : e11.isAvailableForPlaying) || !m2.artist.isAvailable,
            onClick: eo2,
            variant: "default",
            children: ei2 && (0, o.jsx)(O.A, { id: "player-actions.listen" })
          });
        }, [
          ei2,
          null == m2 ? void 0 : m2.artist.isAvailable,
          null == m2 ? void 0 : m2.artist.isAvailableForPlaying,
          eo2,
          M2,
          er2
        ]), e_2 = (0, b.c)(() => {
          !V2() && (null == m2 ? void 0 : m2.artist.id) && (R2.setUtmLink(k2), R2.openArtistTrailer(m2.artist.id), L2(F.ky.Artist, m2.artist.id));
        }), ep2 = (0, d.useMemo)(
          () => Y2 ? (0, o.jsx)(N.aQ, {
            fallback: (0, o.jsx)(N.cv, {
              children: (0, o.jsx)(N.kJ, {
                size: "s",
                radius: "xxxl",
                iconSize: "xxs",
                className: ev().trailerControl,
                onClick: e_2,
                children: ei2 && (0, o.jsx)(O.A, { id: "entity-names.trailer" })
              })
            })
          }) : null,
          [ei2, e_2, Y2]
        ), em2 = (0, d.useMemo)(() => {
          var e11;
          return M2 && ee2 ? null : (null == m2 ? void 0 : m2.donationUrl) && (null == (e11 = m2.artist) ? void 0 : e11.id) ? (0, o.jsx)(i.FoH, {
            blockType: F.LA.Donations,
            blockId: i.UfI.DONATY,
            blockPosX: 1,
            blockPosY: 1,
            children: (0, o.jsx)(i.Bki, {
              objectType: F.ky.Donation,
              objectId: m2.artist.id,
              objectPosX: 0,
              objectPosY: 0,
              objectsCount: 1,
              mainObjectId: m2.artist.id,
              mainObjectType: F.ky.Artist,
              children: (0, o.jsx)(eg, {
                children: (0, o.jsx)(eu, {
                  className: ev().donateControl,
                  iconSize: Z2,
                  controlSize: G2,
                  url: W2(m2.donationUrl)
                })
              })
            })
          }) : (0, o.jsx)(N.O0, {
            onClick: w2,
            isPinned: null == m2 ? void 0 : m2.artist.isPinned,
            className: ev().pinControl,
            isDisabled: !(null == m2 ? void 0 : m2.artist.isAvailable)
          });
        }, [
          M2,
          ee2,
          null == m2 ? void 0 : m2.donationUrl,
          null == m2 ? void 0 : m2.artist.id,
          null == m2 ? void 0 : m2.artist.isPinned,
          null == m2 ? void 0 : m2.artist.isAvailable,
          w2,
          Z2,
          G2,
          W2
        ]), ex2 = (0, d.useMemo)(() => {
          var e11;
          let t3 = {
            gridTemplateAreas: "".concat(
              ((e12) => {
                let { isMobile: t4, brandedButton: a4, trailerButton: i2, pinOrDonateControl: r2 } = e12, l2 = r2 ? "pinOrDonate" : "";
                return t4 ? a4 ? "'menu play like' 'branded branded branded'" : "'menu like ".concat(l2, " play '") : "'play ".concat(a4 ? "branded" : "", " ").concat(i2 ? "trailer" : "", " like ").concat(l2, " menu'");
              })({ isMobile: M2, brandedButton: ee2, pinOrDonateControl: $2 || Q2, trailerButton: Y2 })
            )
          }, a3 = { "--baranded-button-color-background": r(null == m2 ? void 0 : m2.artist.averageColor) };
          return (0, o.jsxs)("div", {
            style: t3,
            className: ev().controls,
            children: [
              en2,
              ee2 && (0, o.jsx)(N.aQ, {
                fallback: (0, o.jsx)(P.$, {
                  className: ev().brandedControl,
                  style: a3,
                  withRipple: false,
                  withHover: false,
                  radius: "xxxl",
                  size: "s",
                  color: "primary",
                  onClick: ea2,
                  variant: "default",
                  role: "link",
                  children: (0, o.jsx)(g.Caption, {
                    variant: "span",
                    lineClamp: 1,
                    children: null == m2 || null == (e11 = m2.brandedButton) ? void 0 : e11.title
                  })
                })
              }),
              ep2,
              (0, o.jsx)(N.aQ, {
                fallback: (0, o.jsx)(N.cy, {
                  className: ev().likeControl,
                  isLiked: null == m2 ? void 0 : m2.artist.isLiked,
                  onClick: T2,
                  withRipple: !M2,
                  iconSize: Z2,
                  size: G2,
                  variant: "default",
                  iconClassName: ev().likeIcon,
                  disabled: !(null == m2 ? void 0 : m2.artist.isAvailable) || !S2.isAuthorized
                })
              }),
              (0, o.jsx)(N.aQ, { fallback: em2 }),
              (0, o.jsx)(es.gg, {
                artist: null == m2 ? void 0 : m2.artist,
                open: I2,
                onOpenChange: E2,
                className: ev().menuControl,
                size: G2,
                icon: (0, o.jsx)(A.Icon, { size: Z2, variant: "more" }),
                ...(0, u.Am)(u.e8.pageHeader.ARTIST_HEADER_CONTEXT_MENU_BUTTON)
              })
            ]
          });
        }, [
          null == m2 ? void 0 : m2.artist,
          null == m2 || null == (n2 = m2.brandedButton) ? void 0 : n2.title,
          G2,
          T2,
          Z2,
          I2,
          M2,
          ea2,
          en2,
          em2,
          ep2,
          S2.isAuthorized,
          ee2,
          Q2,
          $2,
          Y2
        ]), ey2 = (0, d.useMemo)(
          () => (0, o.jsx)("div", {
            className: ev().meta,
            children: (null == m2 ? void 0 : m2.lastMonthListeners) && (0, o.jsxs)("div", {
              className: ev().label,
              ...(0, u.Am)(u.e8.pageHeader.ARTIST_LISTENERS_COUNT),
              children: [
                (0, o.jsx)(A.Icon, { variant: "users", size: "xxxs" }),
                (0, o.jsx)(g.Caption, {
                  type: "text",
                  size: "m",
                  weight: "medium",
                  variant: "span",
                  children: (0, o.jsx)(O.A, {
                    id: "entity-names.listeners-per-month",
                    values: { counter: m2.lastMonthListeners }
                  })
                })
              ]
            })
          }),
          [null == m2 ? void 0 : m2.lastMonthListeners]
        );
        return (0, o.jsx)("div", {
          className: ev().root,
          children: (0, o.jsx)(B, {
            ref: x2,
            className: p2,
            entityName: J2,
            title: (null == m2 || null == (s2 = m2.artist) ? void 0 : s2.name) || "",
            meta: ey2,
            cover: (0, o.jsx)(et, {
              coverVariant: "round",
              coverUri: null == m2 || null == (c2 = m2.artist) ? void 0 : c2.coverUri,
              isAvailable: null == m2 ? void 0 : m2.artist.isAvailable,
              onClick: y2,
              "aria-label": y2 ? H2({ id: "slider.view-artist-covers" }) : void 0
            }),
            controls: ex2,
            disclaimerLabel: X2,
            headingVariant: "h1"
          })
        });
      }), ef = (0, d.forwardRef)((e10, t2) => (0, o.jsx)(ey, { forwardRef: t2, ...e10 }));
      var eh = a(62443), eb = a(985), eC = a(77217), eP = a(34284), eA = a(62395), ej = a(20175), eN = a.n(ej);
      let ek = (0, s.PA)((e10) => {
        var t2;
        let {
          className: a2,
          forwardRef: r2,
          onCoverClick: l2,
          concert: s2,
          leadArtistId: c2,
          cover: _2,
          description: p2
        } = e10, { formatMessage: m2, formatDate: v2 } = (0, h.A)(), { state: x2, toggleTrue: y2, toggleFalse: f2 } = (0, eh.e)(false), A2 = (() => {
          let e11 = (0, i.UlF)(), t3 = (0, eA.st)(), { hash: a3 } = (0, eA.gf)(), { pageId: r3 } = (0, i.$au)(), { tabId: l3, tabPos: o2, isTabSelectedByDefault: n2 } = (0, i.Rro)(), { blockType: s3, blockId: d2, blockPosX: c3, blockPosY: u2 } = (0, i.N8n)(), {
            objectType: _3,
            objectsCount: p3,
            objectId: m3,
            objectPosX: v3,
            objectPosY: x3,
            mainObjectType: g2,
            mainObjectId: y3
          } = (0, i.Jfv)();
          return (0, b.c)((i2, f3) => {
            if (!t3 || !r3) return;
            let h2 = (0, F.Fx)({
              params: {
                hash: a3,
                pageId: r3,
                entityType: s3,
                entityId: d2,
                entityPosX: c3,
                entityPosY: u2,
                objectsCount: p3,
                viewUuid: f3,
                objectType: _3,
                objectId: m3,
                objectPosX: v3,
                objectPosY: x3,
                mainObjectType: g2,
                mainObjectId: y3,
                tabId: l3,
                tabPos: o2,
                isTabSelectedByDefault: n2
              },
              logger: e11,
              context: "useSendEventOnHeaderConcertBlockShowedOrHidden"
            });
            h2 && (i2 ? (0, F.lW)(t3.evgenInstance, h2) : (0, F.LZ)(t3.evgenInstance, h2));
          });
        })(), j2 = (() => {
          let e11 = (0, eA.st)(), t3 = (0, i.UlF)(), { hash: a3 } = (0, eA.gf)(), { pageId: r3 } = (0, i.$au)(), { tabId: l3, tabPos: o2, isTabSelectedByDefault: n2 } = (0, i.Rro)(), { offsetBlockPosY: s3 } = (0, i.uih)(), {
            blockId: d2,
            blockType: c3,
            blockPosX: u2,
            blockPosY: _3,
            mainObjectId: p3,
            mainObjectType: m3
          } = (0, i.N8n)(), { objectId: v3, objectPosX: x3, objectPosY: g2, objectType: y3, objectsCount: f3 } = (0, i.Jfv)(), h2 = (0, C.L)(() => void 0 !== s3 && void 0 !== _3 ? s3 + _3 : _3);
          return (0, b.c)((i2) => {
            let { to: s4, objectId: _4, objectType: b2, deepLink: C2 } = i2;
            if (!e11 || !r3) return;
            let P2 = {
              hash: a3,
              pageId: r3,
              entityType: c3,
              entityId: d2,
              entityPosX: u2,
              entityPosY: h2,
              objectId: null != _4 ? _4 : v3,
              objectType: null != b2 ? b2 : y3,
              objectPosX: x3,
              objectPosY: g2,
              objectsCount: f3,
              from: r3,
              to: s4,
              mainObjectType: m3,
              mainObjectId: p3,
              tabId: l3,
              tabPos: o2,
              isTabSelectedByDefault: n2
            };
            C2 && (P2.deepLink = C2);
            let A3 = (0, F.Fx)({ params: P2, logger: t3, context: "useSendEventOnHeaderConcertBlockNavigated" });
            A3 && (0, F.iF)(e11.evgenInstance, A3);
          });
        })(), { ref: k2, intersectionPropertyId: T2 } = (0, i.nMI)({ callback: A2, withViewUuid: true }), w2 = (() => {
          let e11 = (0, eA.st)(), t3 = (0, i.UlF)(), { hash: a3 } = (0, eA.gf)(), { pageId: r3 } = (0, i.$au)(), { tabId: l3, tabPos: o2, isTabSelectedByDefault: n2 } = (0, i.Rro)(), {
            blockId: s3,
            blockType: d2,
            blockPosX: c3,
            blockPosY: u2,
            objectsCount: _3,
            mainObjectType: p3,
            mainObjectId: m3
          } = (0, i.N8n)();
          return (0, b.c)(() => {
            if (!e11 || !r3) return;
            let i2 = {
              hash: a3,
              pageId: r3,
              tabId: l3,
              tabPos: o2,
              entityType: d2,
              mainObjectType: p3,
              mainObjectId: m3,
              entityId: s3,
              entityPosX: c3,
              entityPosY: u2,
              isTabSelectedByDefault: n2,
              objectsCount: _3,
              pagePlacement: F.c4.Fullscreen,
              pageStyle: F.QL.Fullscreen
            }, v3 = (0, F.Fx)({ params: i2, logger: t3, context: "useSendEventOnHeaderConcertLandingBlockLoaded" });
            v3 && (0, F.uJ)(e11.evgenInstance, v3);
          });
        })(), L2 = (0, d.useRef)(false), H2 = (0, eC.Yi)()(s2);
        (0, d.useEffect)(() => {
          L2.current || (w2(), L2.current = true);
        }, [w2]);
        let I2 = (0, b.c)((e11) => {
          y2(), null == e11 || e11.stopPropagation();
        }), E2 = (0, b.c)((e11) => {
          j2({ to: F.QT.ConcertPurchaseScreen }), I2(e11), e11.preventDefault();
        }), M2 = (0, b.c)(() => {
          j2({ to: F.QT.ShareScreen });
        }), R2 = (0, b.c)(() => {
          j2({ to: F.QT.ArtistScreen });
        }), { shareLink: S2, pathname: D2 } = (0, i.bNS)("/concert/:concertId", { params: { concertId: s2.id } }), O2 = { variant: i.Yxq.CONCERT, id: s2.id, title: null != (t2 = s2.title) ? t2 : "", path: D2 }, z2 = (0, C.L)(
          () => (0, o.jsxs)("div", {
            className: eN().controls,
            children: [
              (0, o.jsx)(P.$, {
                "aria-hidden": true,
                tabIndex: -1,
                radius: "xxxl",
                className: eN().button,
                size: "s",
                variant: "default",
                color: "primary",
                onClick: E2,
                ...(0, u.Am)(u.e8.pageHeader.CONCERT_BUY_TICKET_BUTTON),
                children: H2
              }),
              (0, o.jsx)(N.wD, { onClick: M2, shareLink: S2, entityMeta: O2 })
            ]
          })
        ), U2 = (0, d.useMemo)(() => {
          var e11;
          return [s2.city, s2.place, v2(new Date(null != (e11 = s2.datetime) ? e11 : ""), (0, i.LIS)()), s2.contentRating].filter(Boolean).join(" • ");
        }, [s2.city, s2.place, s2.datetime, s2.contentRating, v2]), V2 = (0, C.L)(() => {
          if (!p2) return;
          let e11 = {
            title: m2({ id: "track-modal.concert-title" }),
            message: p2.text,
            isExpandable: true,
            visibleLinesCount: 3
          }, t3 = (0, C.L)(() => {
            if (!p2.genre) return;
            let e12 = (0, o.jsx)(eP.D, { children: p2.genre });
            return (0, o.jsx)(eP.O, {
              title: m2({ id: "track-modal.genre" }),
              infoDescription: e12,
              ...(0, u.Am)(u.e8.pageHeader.CONCERT_GENRE_INFO_BLOCK)
            });
          }), a3 = (0, C.L)(() => {
            if (!s2.contentRating) return;
            let e12 = (0, o.jsx)(eP.D, { children: s2.contentRating });
            return (0, o.jsx)(eP.O, {
              title: m2({ id: "track-modal.content-rating" }),
              infoDescription: e12,
              ...(0, u.Am)(u.e8.pageHeader.CONCERT_CONTENT_RATING_INFO_BLOCK)
            });
          }), i2 = (0, C.L)(() => {
            if (!p2.source) return;
            let e12 = (0, o.jsx)(eP.D, { children: p2.source });
            return (0, o.jsx)(eP.O, {
              title: m2({ id: "track-modal.source" }),
              infoDescription: e12,
              ...(0, u.Am)(u.e8.pageHeader.CONCERT_SOURCE_INFO_BLOCK)
            });
          }), r3 = (0, o.jsxs)("div", { className: eN().bottomContent, children: [t3, a3, i2] });
          return (0, o.jsx)("div", {
            className: eN().overview,
            ...(0, u.Am)(u.e8.landing.OVERVIEW),
            children: (0, o.jsx)(eb.Fn, {
              modalClassName: (0, n.$)(eN().overviewModal, eN().important),
              textButton: m2({ id: "interface-actions.more-details" }),
              buttonClassName: (0, n.$)(eN().overviewButton, eN().important),
              messageModalClassName: eN().overviewMessageModal,
              messageClassName: eN().overviewMessage,
              creditsModal: r3,
              meta: e11,
              withShowButton: true
            })
          });
        }), W2 = (0, d.useMemo)(
          () => (0, o.jsxs)("div", {
            className: eN().meta,
            children: [
              U2 && (0, o.jsx)(g.Caption, {
                variant: "span",
                type: "text",
                size: "m",
                weight: "medium",
                ...(0, u.Am)(u.e8.pageHeader.CONCERT_META_INFO),
                children: U2
              }),
              s2.cashbackTitle && (0, o.jsx)(eC.mi, { className: eN().cashbackBadge, title: s2.cashbackTitle }),
              V2
            ]
          }),
          [s2.cashbackTitle, U2, V2]
        ), Y2 = (0, C.L)(() => {
          if (!c2) return;
          let { href: e11 } = (0, i.uvd)("/artist/:artistId", { params: { artistId: c2 } });
          return e11;
        });
        return (0, o.jsxs)("div", {
          ref: k2,
          "data-intersection-property-id": T2,
          className: eN().root,
          children: [
            (0, o.jsx)(B, {
              onTitleLinkClick: R2,
              linkTitle: Y2,
              ref: r2,
              className: (0, n.$)(a2, eN().root),
              infoClassName: eN().info,
              titleClassName: eN().title,
              entityName: "",
              title: s2.title || "",
              meta: W2,
              coverCellClassName: eN().coverCell,
              cover: (0, o.jsx)(et, {
                buttonClassName: (0, n.$)(eN().coverButton, eN().important),
                className: eN().cover,
                onClick: l2,
                "aria-label": l2 ? m2({ id: "slider.view-concert-covers" }) : void 0,
                customCover: (0, o.jsx)(eC.Wt, {
                  datetime: s2.datetime,
                  coverColor: null == _2 ? void 0 : _2.color,
                  uri: null == _2 ? void 0 : _2.uri,
                  withMask: true
                })
              }),
              controls: z2,
              headingVariant: "h1"
            }),
            (0, o.jsx)(eC.hW, { dataSessionId: s2.dataSessionId, isOpened: x2, onOpen: y2, onClose: f2 })
          ]
        });
      }), eT = (0, d.forwardRef)((e10, t2) => (0, o.jsx)(ek, { forwardRef: t2, ...e10 }));
      var ew = {
        5881: (e10, t2, a2) => {
          function i2() {
            for (var e11, t3, a3 = 0, i3 = ""; a3 < arguments.length; )
              (e11 = arguments[a3++]) && (t3 = (function e12(t4) {
                var a4, i4, r3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) r3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (a4 = 0; a4 < t4.length; a4++) t4[a4] && (i4 = e12(t4[a4])) && (r3 && (r3 += " "), r3 += i4);
                  else for (a4 in t4) t4[a4] && (r3 && (r3 += " "), r3 += a4);
                return r3;
              })(e11)) && (i3 && (i3 += " "), i3 += t3);
            return i3;
          }
          a2.r(t2), a2.d(t2, { clsx: () => i2, default: () => r2 });
          let r2 = i2;
        },
        4092: (e10, t2, a2) => {
          a2.r(t2), a2.d(t2, { default: () => i2 });
          let i2 = {
            root: "sLuudThzDxW_5ARYjgjx",
            horizontal: "xd6ji7lvp0et4nirt0TL",
            hasLabel: "abbPp8VtL2D_PdW0Q_Wc",
            vertical: "sMz62rSqViFDkXAMfGeO"
          };
        },
        9097: (e10, t2) => {
          var a2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function i2(e11, t3, i3) {
            var r2 = null;
            if (void 0 !== i3 && (r2 = "" + i3), void 0 !== t3.key && (r2 = "" + t3.key), "key" in t3)
              for (var l2 in i3 = {}, t3) "key" !== l2 && (i3[l2] = t3[l2]);
            else i3 = t3;
            return { $$typeof: a2, type: e11, key: r2, ref: void 0 !== (t3 = i3.ref) ? t3 : null, props: i3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = i2, t2.jsxs = i2;
        },
        4377: (e10, t2, a2) => {
          e10.exports = a2(9097);
        },
        5455: function(e10, t2, a2) {
          var i2 = this && this.__importDefault || function(e11) {
            return e11 && e11.__esModule ? e11 : { default: e11 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Divider = void 0;
          let r2 = a2(4377), l2 = a2(5881), o2 = i2(a2(4092));
          t2.Divider = (e11) => {
            let { className: t3, orientation: a3 = "horizontal", children: i3, ...n2 } = e11, s2 = i3 && (0, r2.jsx)("span", { children: i3 });
            return (0, r2.jsx)("div", {
              className: (0, l2.clsx)(o2.default.root, { [o2.default[a3]]: a3, [o2.default.hasLabel]: s2 }, t3),
              ...n2,
              role: "separator",
              "aria-orientation": a3,
              children: s2
            });
          };
        }
      }, eL = {};
      function eH(e10) {
        var t2 = eL[e10];
        if (void 0 !== t2) return t2.exports;
        var a2 = eL[e10] = { exports: {} };
        return ew[e10].call(a2.exports, a2, a2.exports, eH), a2.exports;
      }
      eH.d = (e10, t2) => {
        for (var a2 in t2) eH.o(t2, a2) && !eH.o(e10, a2) && Object.defineProperty(e10, a2, { enumerable: true, get: t2[a2] });
      }, eH.o = (e10, t2) => Object.prototype.hasOwnProperty.call(e10, t2), eH.r = (e10) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e10, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e10, "__esModule", { value: true });
      };
      var eI = {};
      (() => {
        Object.defineProperty(eI, "__esModule", { value: true }), eI.Divider = void 0;
        var e10 = eH(5455);
        Object.defineProperty(eI, "Divider", {
          enumerable: true,
          get: function() {
            return e10.Divider;
          }
        });
      })();
      var eE = eI.Divider;
      eI.__esModule;
      var eB = a(65749), eM = a(71609), eR = a.n(eM);
      let eS = (0, s.PA)((e10) => {
        let { album: t2, actionButton: a2, className: r2, "aria-labelledby": l2, forwardRef: n2, onVersionClick: s2 } = e10, { formatMessage: c2 } = (0, h.A)(), { shouldShowBuySubscriptionModal: _2, showBuySubscriptionModal: p2 } = (0, i.qBP)(), { from: m2, utmLink: v2 } = (0, i.fyy)({
          pageId: i._Q$.ALBUM,
          blockId: i.UfI.ALBUM,
          contextType: z.K.Album,
          contextId: t2.id
        }), {
          user: x2,
          settings: { isMobile: y2 },
          sonataState: f2,
          modals: { imageSliderModal: C2 },
          experiments: P2
        } = (0, i.Pjs)(), j2 = (0, i.brA)(), k2 = (0, i.PT7)(), T2 = (0, i.$hw)(t2.isLiked, t2.type), w2 = (0, U.r_)(t2.type), L2 = t2.isAvailable || t2.isAudiobook, H2 = !!t2.coverUri, I2 = (0, d.useMemo)(() => {
          if (t2.shouldShowBooksBadge)
            return (0, o.jsx)(A.Icon, { variant: "booksLogo", className: eR().booksLogo });
        }, [t2.shouldShowBooksBadge]), E2 = !x2.hasPlus && t2.isAvailableOnlyForPlus, M2 = !t2.isAvailable && !E2 && P2.checkExperiment(i.zal.WebNextPlusLandingLink, "on"), R2 = (0, i.coI)(t2.isPodcast ? t2 : null), { isPlaying: S2, togglePlay: D2 } = (0, i.Dx4)({
          playContextParams: {
            contextData: { type: z.K.Album, meta: { id: t2.id }, from: m2, utmLink: v2 },
            loadContextMeta: true,
            entitiesData: f2.unloadedEntitiesDataFromModels
          }
        }), F2 = (0, b.c)(() => {
          t2.coverUri && C2.openImages({ images: [t2.coverUri] });
        }), V2 = (0, b.c)(() => {
          if (!k2()) {
            if (_2) return void p2();
            D2(), j2(!S2);
          }
        }), W2 = (0, d.useMemo)(
          () => E2 ? (0, o.jsx)(N.w1, { className: eR().plusPaywallButton, albumType: t2.type }) : y2 ? (0, o.jsx)(N.DM, {
            className: ei().playControl,
            color: "primary",
            buttonVariant: "default",
            iconSize: "xxl",
            isPlaying: S2,
            onClick: V2,
            variant: "filled",
            disabled: !t2.isAvailable
          }) : (0, o.jsx)(N.DM, {
            className: ei().playControl,
            withRipple: true,
            buttonVariant: "default",
            radius: "xxxl",
            size: "s",
            color: "primary",
            iconSize: "xxs",
            isPlaying: S2,
            onClick: V2,
            disabled: !t2.isAvailable,
            children: (0, o.jsx)(O.A, { id: "player-actions.listen" })
          }),
          [E2, y2, S2, V2, t2.isAvailable, t2.type]
        ), Y2 = (0, d.useMemo)(
          () => (0, o.jsxs)("div", {
            className: eR().controlsBlock,
            children: [
              (0, o.jsxs)("div", {
                className: ei().controlsContainer,
                children: [
                  (0, o.jsxs)("div", {
                    className: ei().controls,
                    ...(0, u.Am)(u.e8.pageHeader.NON_MUSIC_PAGE_HEADER_CONTROLS),
                    children: [W2, (0, o.jsx)(Q, { album: t2, likeButtonAriaLabel: T2, withLikeButton: !E2 })]
                  }),
                  a2 && (0, o.jsx)("div", { className: ei().controls, children: a2 })
                ]
              }),
              M2 && (0, o.jsxs)("div", {
                className: eR().plusLinkBlock,
                children: [
                  y2 && (0, o.jsx)(eE, { className: eR().divider }),
                  (0, o.jsxs)(g.Caption, {
                    className: eR().plusLinkContainer,
                    variant: "div",
                    type: "controls",
                    size: "m",
                    children: [
                      (0, o.jsxs)(eB.N, {
                        href: "https://music.yandex.ru/promo/lt-pay-promo/?get-plus=1&utm_source=music&utm_medium=non_music_tab&utm_campaign=web_music_birthday",
                        target: "_blank",
                        className: eR().plusLink,
                        children: [
                          (0, o.jsx)(A.Icon, { variant: "info", size: "xxs" }),
                          " ",
                          (0, o.jsx)(O.A, { id: "payment.get-plus" })
                        ]
                      }),
                      " ",
                      (0, o.jsx)(O.A, { id: "payment.listen-to-books-and-podcasts" })
                    ]
                  }),
                  y2 && (0, o.jsx)(eE, { className: eR().divider })
                ]
              })
            ]
          }),
          [W2, t2, T2, E2, a2, M2, y2]
        ), $2 = (0, d.useMemo)(
          () => (0, o.jsx)("div", { className: eR().meta, children: (0, o.jsx)(Z, { album: t2 }) }),
          [t2]
        );
        return (0, o.jsx)(B, {
          ref: n2,
          headingVariant: "h1",
          className: r2,
          controls: Y2,
          meta: $2,
          entityName: w2,
          entityNameIcon: I2,
          title: t2.title,
          cover: (0, o.jsx)(et, {
            coverVariant: "square",
            coverUri: t2.coverUri,
            isAvailable: L2,
            withPlusBadge: t2.isAvailableOnlyForPlus,
            onClick: H2 ? F2 : void 0,
            "aria-label": H2 ? c2({ id: "slider.view-cover" }) : void 0
          }),
          "aria-labelledby": l2,
          version: t2.version,
          onVersionClick: s2,
          disclaimerLabel: R2
        });
      }), eD = (0, d.forwardRef)((e10, t2) => (0, o.jsx)(eS, { forwardRef: t2, ...e10 }));
      var eO = a(9635), ez = a(97396), eU = a(13611), eF = a(61958), eV = a(53266), eW = a.n(eV);
      let eY = (0, s.PA)((e10) => {
        let { trackIds: t2, className: a2, onRemove: r2 } = e10, { slam: l2 } = (0, i.Pjs)(), s2 = (0, i.AN5)(), { formatMessage: c2 } = (0, h.A)(), u2 = (0, i.NFA)(), [_2, p2] = (0, d.useState)(false), m2 = u2.get(i.vgk), v2 = l2.isPlaylistDownloaded(t2), x2 = l2.isPlaylistDownloading(t2), y2 = l2.getPlaylistDownloadingProgress(t2), f2 = (0, b.c)(() => {
          if (x2) {
            null == s2 || s2.stopDownload(t2);
            return;
          }
          if (v2) return void p2(true);
          null == s2 || s2.download(t2), m2.count(i.xQR.MY_FAVORITES_PLAYLIST_DOWNLOAD, i.l6e);
        }), C2 = (0, b.c)(() => {
          null == s2 || s2.delete(t2), m2.count(i.xQR.MY_FAVORITES_PLAYLIST_DELETE, i.l6e), null == r2 || r2();
        }), j2 = (0, d.useMemo)(
          () => v2 ? (0, o.jsx)(A.Icon, { variant: "check", size: "xxs", className: eW().downloadedIcon }) : x2 ? (0, o.jsx)(N.AD, {
            value: null != y2 ? y2 : 0,
            size: 26,
            withCancelIcon: true,
            className: eW().downloadingProgress,
            progressBarClassName: eW().progress,
            cancelIconClassName: eW().cancelIcon
          }) : (0, o.jsx)(A.Icon, { variant: "download", size: "xxs" }),
          [v2, x2, y2]
        ), k2 = (0, d.useMemo)(() => x2 ? c2({ id: "offline.stop-downloading" }) : c2({ id: "offline.download" }), [c2, x2]);
        return v2 ? (0, o.jsx)(eF.W1, {
          variant: "default",
          size: "s",
          radius: "xxxl",
          icon: j2,
          offsetOptions: 10,
          open: _2,
          onOpenChange: p2,
          wrapperClassName: a2,
          ariaLabel: c2({ id: "offline.delete-from-device" }),
          children: (0, o.jsx)(eF.Dr, {
            icon: (0, o.jsx)(A.Icon, { variant: "upload", size: "xxs" }),
            onClick: C2,
            children: (0, o.jsx)(O.A, { id: "offline.delete-from-device" })
          })
        }) : (0, o.jsx)(P.$, {
          className: (0, n.$)(eW().root, { [eW().root_downloading]: x2 }, a2),
          variant: "default",
          size: "s",
          radius: "xxxl",
          icon: j2,
          "aria-label": k2,
          onClick: f2,
          children: x2 && (0, o.jsx)(g.Caption, {
            variant: "div",
            className: eW().progressText,
            children: (0, o.jsx)(O.A, { id: "offline.downloading-progress", values: { value: y2 } })
          })
        });
      });
      var eQ = a(61805), e$ = a.n(eQ), eK = a(51376), eX = a(92504), eq = a.n(eX);
      let eG = (0, s.PA)((e10) => {
        var t2, a2, r2;
        let { playlistUuid: l2 } = e10, n2 = (0, eK.Qj)(), s2 = (0, i.Zzs)({ objectId: l2, link: null == (a2 = n2.data) || null == (t2 = a2.button) ? void 0 : t2.href });
        return n2.isEnabled && (null == (r2 = n2.data) ? void 0 : r2.button) ? (0, o.jsx)(eB.N, {
          className: eq().root,
          href: n2.data.button.href,
          target: "_blank",
          onClick: s2,
          children: (0, o.jsx)(g.Caption, {
            variant: "span",
            type: "text",
            size: "s",
            weight: "medium",
            lineClamp: 1,
            children: n2.data.button.text
          })
        }) : null;
      });
      var eZ = a(15209);
      let eJ = ["image/png", "image/jpeg", "image/jpg"];
      var e0 = a(1456), e1 = a.n(e0);
      let e7 = (0, s.PA)((e10) => {
        let { className: t2, playlist: a2 } = e10, {
          settings: { isMobile: r2 },
          playlist: { isRewind2024Playlist: l2 },
          modals: { imageSliderModal: s2 }
        } = (0, i.Pjs)(), c2 = a2.coverUri, _2 = a2.canUserChange && !r2, { notify: p2 } = (0, i.lkh)(), { formatMessage: m2 } = (0, h.A)(), v2 = (0, d.useRef)(null), [x2, g2] = (0, d.useState)(c2 || ""), [y2, f2] = (0, d.useState)(_2), [C2, A2] = (0, d.useState)(new FormData()), j2 = (0, eZ.createAvatarUrl)(c2 || "", 600, false), k2 = (0, eZ.createAvatarUrl)(c2 || "", 300, false), [T2, w2] = (0, d.useState)(j2), [L2, H2] = (0, d.useState)(false), I2 = !!c2, E2 = (0, d.useMemo)(() => {
          if (l2 && a2.personalColor) return (0, i.mBl)(a2.personalColor);
        }, [l2, a2.personalColor]);
        (0, d.useEffect)(() => {
          y2 !== _2 && f2(_2);
        }, [_2, y2]);
        let B2 = (0, d.useCallback)(
          () => p2((0, o.jsx)(N.hT, { error: m2({ id: "playlist-errors.failed-to-change-poster" }) }), {
            containerId: i.uQT.ERROR
          }),
          [p2, m2]
        ), M2 = (0, b.c)(() => {
          c2 && !L2 && s2.openImages({ images: [c2] });
        }), R2 = (0, b.c)((e11) => {
          var t3;
          null == e11 || e11.stopPropagation(), null == v2 || null == (t3 = v2.current) || t3.click();
        }), S2 = (0, b.c)((e11) => {
          e11.stopPropagation(), "Enter" === e11.key && R2();
        }), D2 = (0, b.c)((e11) => {
          e11.stopPropagation();
        }), O2 = (0, b.c)((e11) => {
          let t3, a3 = e11.target, i2 = (a3.files || [])[0] || null;
          if (a3.value = "", !i2 || (t3 = i2.type, !eJ.includes(t3)) || !((e12) => e12 > 0 && e12 <= 2e7)(i2.size))
            return void B2();
          x2 && w2(x2), f2(false), g2(URL.createObjectURL(i2));
          let r3 = new FormData();
          r3.append("image", i2), A2(r3);
        }), z2 = (0, d.useCallback)(
          async (e11) => {
            let t3 = e11.target, r3 = () => {
              g2(T2), B2(), f2(true);
            };
            if (c2 && (t3.currentSrc === j2 || t3.currentSrc === k2) || !_2 || T2 === t3.currentSrc) return;
            if (!((e12) => {
              if (!e12) return;
              let t4 = 2 * e12.naturalHeight || e12.height, a3 = 2 * e12.naturalWidth || e12.width;
              return t4 < 5e3 && a3 < 5e3;
            })(t3))
              return void r3();
            H2(true);
            let l3 = await a2.changePlaylistCover(C2);
            H2(false), l3 === i.FlZ.ERROR ? r3() : f2(true);
          },
          [B2, T2, a2, C2, c2, _2, j2, k2]
        ), U2 = (0, d.useMemo)(
          () => x2 ? m2({ id: "playlist-actions.change-poster" }) : m2({ id: "playlist-actions.add-poster" }),
          [x2, m2]
        );
        return (0, o.jsxs)($.Paper, {
          radius: "m",
          className: (0, n.$)(e1().root, t2, { [e1().root_hoverable]: I2 }),
          children: [
            (0, o.jsx)("div", {
              className: e1().backCoverColor,
              style: E2,
              children: (0, o.jsx)(P.$, {
                onClick: M2,
                "aria-label": I2 ? m2({ id: "slider.view-cover" }) : void 0,
                tabIndex: I2 ? 0 : -1,
                disabled: !I2,
                className: e1().coverButton,
                children: (0, o.jsx)(N.BW, {
                  fit: "cover",
                  src: x2,
                  size: 300,
                  className: e1().coverImage,
                  withAvatarReplace: true,
                  onLoad: z2
                })
              })
            }),
            y2 && (0, o.jsx)("div", {
              className: (0, n.$)(e1().buttonContainer, { [e1().buttonContainer_withCursorPointer]: x2 }),
              onClick: I2 ? M2 : void 0,
              children: (0, o.jsxs)("div", {
                className: (0, n.$)(e1().fileUploadContainer, { [e1().fileUploadContainer_hovered]: x2 }),
                children: [
                  (0, o.jsx)(P.$, {
                    className: e1().button,
                    radius: "xxxl",
                    size: "xxs",
                    color: "secondary",
                    withRipple: false,
                    onClick: R2,
                    onKeyUp: S2,
                    "aria-label": m2({ id: "playlist-actions.add-poster" }),
                    ...(0, u.Am)(u.e8.pageHeader.PLAYLIST_HEADER_ADD_COVER_BUTTON),
                    children: U2
                  }),
                  (0, o.jsx)("form", {
                    className: e1().formFile,
                    encType: "multipart/form-data",
                    children: (0, o.jsx)("input", {
                      ref: v2,
                      type: "file",
                      name: "file",
                      accept: "image/jpeg, image/png, image/jpg",
                      onChange: O2,
                      onClick: D2
                    })
                  })
                ]
              })
            })
          ]
        });
      });
      var e8 = a(13008), e2 = a.n(e8), e4 = a(66534);
      let e5 = (0, s.PA)((e10) => {
        let { playlist: t2, className: a2 } = e10, { formatMessage: r2 } = (0, h.A)(), l2 = (0, d.useCallback)(
          (e11, t3) => {
            if (!(null == t3 ? void 0 : t3.playlistReceiver))
              switch (e11) {
                case i.rdQ.TODAY:
                  return r2({ id: "interface-actions.playlist-made-today" }, t3);
                case i.rdQ.YESTERDAY:
                  return r2({ id: "interface-actions.playlist-made-yesterday" }, t3);
                case i.rdQ.DATE_WITH_YEAR:
                  return r2({ id: "interface-actions.playlist-made-date-with-year" }, t3);
                default:
                  return r2({ id: "interface-actions.playlist-made-date" }, t3);
              }
            switch (e11) {
              case i.rdQ.TODAY:
                return r2({ id: "interface-actions.playlist-made-for-today" }, t3);
              case i.rdQ.YESTERDAY:
                return r2({ id: "interface-actions.playlist-made-for-yesterday" }, t3);
              case i.rdQ.DATE_WITH_YEAR:
                return r2({ id: "interface-actions.playlist-made-for-date-with-year" }, t3);
              default:
                return r2({ id: "interface-actions.playlist-made-for-date" }, t3);
            }
          },
          [r2]
        ), n2 = (0, d.useCallback)(
          (e11, t3) => {
            if (!(null == t3 ? void 0 : t3.ownerName))
              switch (e11) {
                case i.rdQ.TODAY:
                  return r2({ id: "interface-actions.updated-anonymously-playlist-today" }, t3);
                case i.rdQ.YESTERDAY:
                  return r2({ id: "interface-actions.updated-anonymously-playlist-yesterday" }, t3);
                case i.rdQ.DATE_WITH_YEAR:
                  return r2({ id: "interface-actions.updated-anonymously-playlist-date-with-year" }, t3);
                default:
                  return r2({ id: "interface-actions.updated-anonymously-playlist-date" }, t3);
              }
            switch (e11) {
              case i.rdQ.TODAY:
                return r2({ id: "interface-actions.updated-playlist-today" }, t3);
              case i.rdQ.YESTERDAY:
                return r2({ id: "interface-actions.updated-playlist-yesterday" }, t3);
              case i.rdQ.DATE_WITH_YEAR:
                return r2({ id: "interface-actions.updated-playlist-date-with-year" }, t3);
              default:
                return r2({ id: "interface-actions.updated-playlist-date" }, t3);
            }
          },
          [r2]
        ), s2 = (0, d.useMemo)(() => {
          var e11, a3, r3, o2, s3;
          let d2 = new Date(t2.modified), c2 = (0, i.LkW)(d2);
          return t2.madeFor ? l2(c2, {
            playlistReceiver: (null == t2 || null == (o2 = t2.madeFor) || null == (r3 = o2.caseForms) ? void 0 : r3.genitive) || "",
            updateDate: d2
          }) : t2.isFavouritePlaylist ? (null == (s3 = t2.owner) ? void 0 : s3.name) || "" : n2(c2, {
            updateDate: new Date(t2.modified),
            ownerName: (null == (e11 = t2.owner) ? void 0 : e11.name) || "",
            gender: (null == (a3 = t2.owner) ? void 0 : a3.sex) === e4.U.FEMALE ? "female" : "male"
          });
        }, [t2, l2, n2]);
        return (0, o.jsx)(g.Caption, {
          variant: "span",
          className: a2,
          type: "text",
          size: "m",
          weight: "medium",
          lineClamp: 1,
          ...(0, u.Am)(u.e8.pageHeader.PLAYLIST_HEADER_UPDATED_TEXT),
          children: s2
        });
      }), e6 = (0, s.PA)((e10) => {
        let { playlist: t2 } = e10, { formatMessage: a2 } = (0, h.A)(), {
          settings: { isMobile: r2 }
        } = (0, i.Pjs)(), { notify: l2 } = (0, i.lkh)(), s2 = t2.canUserChange && !r2, c2 = !!t2.description, { state: _2, toggleTrue: p2, toggleFalse: m2 } = (0, eh.e)(false), [v2, x2] = (0, d.useState)(t2.description || ""), y2 = (0, d.useCallback)(async () => {
          m2(), await t2.changeDescription(v2) === i.FlZ.ERROR && l2((0, o.jsx)(N.hT, { error: a2({ id: "playlist-errors.failed-to-change-description" }) }), {
            containerId: i.uQT.ERROR
          });
        }, [a2, v2, l2, t2, m2]), f2 = (0, d.useCallback)((e11) => {
          x2(e11);
        }, []), b2 = (0, d.useMemo)(
          () => (0, i.rVI)(t2.description, N.N_, { className: e2().descriptionLink }),
          [t2.description]
        ), C2 = (0, d.useMemo)(
          () => t2.tagsString ? (0, o.jsx)(g.Caption, {
            variant: "span",
            type: "text",
            size: "m",
            weight: "medium",
            children: (0, o.jsx)(O.A, { id: "entity-names.tags", values: { tags: t2.tagsString } })
          }) : null,
          [t2.tagsString]
        );
        return (0, o.jsxs)("div", {
          className: e2().root,
          children: [
            c2 && !_2 && (0, o.jsxs)(g.Caption, {
              variant: "span",
              className: e2().description,
              type: "text",
              size: "m",
              weight: "medium",
              children: [
                b2,
                s2 && (0, o.jsx)(P.$, {
                  variant: "text",
                  withRipple: false,
                  onClick: p2,
                  className: (0, n.$)(e2().descriptionActionLink, e2().addDescription),
                  "aria-label": a2({ id: "playlist-actions.change-description" }),
                  color: "primary",
                  ...(0, u.Am)(u.e8.pageHeader.PLAYLIST_HEADER_CHANGE_DESCRIPTION_BUTTON),
                  children: (0, o.jsx)(g.Caption, {
                    variant: "span",
                    size: "m",
                    type: "text",
                    className: e2().button,
                    children: (0, o.jsx)(O.A, { id: "playlist-actions.change-description-abbr" })
                  })
                })
              ]
            }),
            !c2 && s2 && !_2 && (0, o.jsx)(P.$, {
              variant: "text",
              withRipple: false,
              onClick: p2,
              className: e2().descriptionActionLink,
              "aria-label": a2({ id: "playlist-actions.add-description" }),
              color: "primary",
              ...(0, u.Am)(u.e8.pageHeader.PLAYLIST_HEADER_ADD_DESCRIPTION_BUTTON),
              children: (0, o.jsxs)(g.Caption, {
                variant: "span",
                size: "m",
                type: "text",
                className: e2().button,
                children: [(0, o.jsx)(O.A, { id: "playlist-actions.add-description" }), "..."]
              })
            }),
            s2 && _2 && (0, o.jsxs)(o.Fragment, {
              children: [
                (0, o.jsx)(w, {
                  text: t2.description,
                  className: e2().textField,
                  placeholder: "".concat(a2({ id: "playlist-actions.add-description" }), "..."),
                  maxTextLength: eU.iz,
                  onChangeFinish: f2,
                  variant: "textarea"
                }),
                (0, o.jsxs)("div", {
                  className: e2().actionButtons,
                  children: [
                    (0, o.jsx)(P.$, {
                      className: e2().saveButton,
                      color: "secondary",
                      radius: "xxxl",
                      size: "s",
                      "aria-label": a2({ id: "interface-actions.save" }),
                      onClick: y2,
                      withHover: true,
                      children: (0, o.jsx)(O.A, { id: "interface-actions.save" })
                    }),
                    (0, o.jsx)(P.$, {
                      variant: "text",
                      withRipple: false,
                      onClick: m2,
                      className: e2().cancelButton,
                      "aria-label": a2({ id: "interface-actions.cancel" }),
                      color: "primary",
                      children: (0, o.jsx)(g.Caption, {
                        variant: "span",
                        size: "m",
                        type: "text",
                        className: e2().button,
                        children: (0, o.jsx)(O.A, { id: "interface-actions.cancel" })
                      })
                    })
                  ]
                })
              ]
            }),
            (0, o.jsx)(e5, { className: e2().updatedText, playlist: t2 }),
            C2
          ]
        });
      });
      var e3 = a(53516), e9 = a.n(e3);
      let te = (0, s.PA)((e10) => {
        let { playlist: t2 } = e10, a2 = (0, d.useRef)(null), { ugcUploadCenter: r2 } = (0, i.Pjs)(), { formatMessage: l2 } = (0, h.A)(), n2 = (0, d.useCallback)(() => {
          var e11;
          null == a2 || null == (e11 = a2.current) || e11.click();
        }, [a2]), s2 = (0, d.useCallback)(
          (e11) => {
            let a3 = e11.target.files;
            a3 && a3.length > 0 && r2.appendFiles([...a3], t2), e11.target.value = "";
          },
          [t2, r2]
        );
        return (0, o.jsxs)(o.Fragment, {
          children: [
            (0, o.jsx)(P.$, {
              size: "s",
              radius: "xxxl",
              "aria-label": l2({ id: "ugc.upload-track" }),
              className: e9().button,
              onClick: n2,
              ...(0, u.Am)(u.e8.pageHeader.PLAYLIST_HEADER_UPLOAD_UGC_BUTTON),
              children: l2({ id: "ugc.upload-track" })
            }),
            (0, o.jsx)("form", {
              className: e9().form,
              encType: "multipart/form-data",
              children: (0, o.jsx)("input", { ref: a2, type: "file", accept: "audio/*", onChange: s2, multiple: true })
            })
          ]
        });
      });
      var tt = a(83504);
      let ta = (0, s.PA)((e10) => {
        var t2, a2, r2, l2;
        let { playlist: n2, onOpenChange: s2, open: c2, wrapperClassName: _2, ...p2 } = e10, { shouldShowBuySubscriptionModal: m2, showBuySubscriptionModal: v2 } = (0, i.qBP)(), {
          settings: { isMobile: x2 },
          trailer: g2,
          playlist: {
            filters: { activeFilter: y2, analyticsParamsActiveFilterIndex: f2 }
          },
          user: C2,
          experiments: P2
        } = (0, i.Pjs)(), j2 = (0, eU.KX)(n2), k2 = P2.checkExperiment(i.zal.WebEditorsFeatures, "on"), T2 = (0, eU.A7)(n2), w2 = (0, i.Ftl)(), L2 = "".concat(i.UfI.PLAYLIST, "-").concat(n2.uid, "_").concat(n2.kind), H2 = n2.canUserChange, { utmLink: I2 } = (0, i.fyy)({
          pageId: i._Q$.PLAYLIST,
          blockId: i.UfI.PLAYLIST,
          contextType: z.K.Playlist,
          contextId: n2.uuid,
          pageEntityId: n2.uuid
        }), E2 = (0, i.PT7)(), B2 = n2.isOwnFavouritePlaylist && P2.checkExperiment(i.zal.WebNextToggleFavouritePlaylistVisibility, "on"), { notify: M2 } = (0, i.lkh)(), { formatMessage: R2 } = (0, h.A)(), S2 = (0, ez.useRouter)(), D2 = (0, d.useMemo)(() => ({ objectId: n2.seeds[0], tabId: y2, tabPos: f2 }), [n2.seeds, y2, f2]), U2 = (0, i.V8i)(D2), { shareLink: V2, pathname: W2 } = (0, i.bNS)("/playlists/:playlistUuid", {
          params: { playlistUuid: n2.uuid }
        }), Y2 = (0, tt.A_)({ entityVariant: i.DwC.PLAYLIST, urlParams: { id: n2.uid, kind: n2.kind } }), { isPlaying: Q2, togglePlay: $2 } = (0, i.B0S)({
          seeds: null != (l2 = n2.seeds) ? l2 : [],
          pageIdForFrom: i._Q$.RADIO,
          blockIdForFrom: L2,
          parentContextId: n2.uuid
        }), K2 = (0, b.c)(() => {
          if (m2 && C2.isAuthorized) return void v2();
          !E2() && (Q2 || ($2(), U2()));
        }), X2 = (0, b.c)(() => {
          if (m2) return void v2();
          E2() || (g2.setUtmLink(I2), g2.openPlaylistTrailer(n2.id), w2(F.ky.Playlist, n2.id));
        }), q2 = (0, b.c)(async () => {
          if (await n2.deletePlaylist() === i.FlZ.ERROR)
            return void M2((0, o.jsx)(N.hT, { error: R2({ id: "playlist-errors.failed-to-remove-playlist" }) }), {
              containerId: i.uQT.ERROR
            });
          S2.push(i.Zyd.collection.href);
        });
        (0, i.NBO)(c2);
        let G2 = (n2.isPublic || n2.isFavouritePlaylist) && n2.isAvailable, Z2 = {
          variant: i.Yxq.PLAYLIST,
          id: n2.kind,
          title: n2.title,
          path: W2,
          playlistOwnerName: null == (t2 = n2.owner) ? void 0 : t2.name,
          playlistOwnerLogin: null == (a2 = n2.owner) ? void 0 : a2.login
        };
        return (0, o.jsxs)(eF.W1, {
          isMobile: x2,
          offsetOptions: 10,
          open: c2,
          onOpenChange: s2,
          ariaLabel: R2({ id: "interface-actions.context-menu" }),
          wrapperClassName: _2,
          ...p2,
          containerProps: (0, u.Am)(u.Kq.playlist.PLAYLIST_CONTEXT_MENU),
          children: [
            k2 && (0, o.jsx)(tt.dx, {
              entityVariant: i.DwC.PLAYLIST,
              adminUrl: n2.isFavouritePlaylist ? void 0 : Y2,
              withPlaylistPageFeatures: true
            }),
            !x2 && (0, o.jsx)(N.L1, { onClick: T2, isPinned: n2.isPinned }),
            !n2.isFavouritePlaylist && (0, o.jsx)(N.TW, { onClick: j2, isLiked: n2.isLiked, disabled: !C2.isAuthorized }),
            (null == (r2 = n2.trailer) ? void 0 : r2.isAvailable) && (0, o.jsx)(N.No, { onClick: X2 }),
            (0, o.jsx)(N.C6, { disabled: !n2.isAvailable, onClick: K2, variant: i.IGO.PLAYLIST }),
            (0, o.jsx)(N.Ht, { disabled: !G2, shareLink: V2, entityMeta: Z2 }),
            H2 && (0, o.jsx)(eF.Dr, {
              icon: (0, o.jsx)(A.Icon, { variant: "bucket", size: "xxs" }),
              onClick: q2,
              children: (0, o.jsx)(O.A, { id: "playlist-actions.remove-playlist" })
            }),
            (H2 || B2) && (0, o.jsx)(eU.uY, { playlist: n2 })
          ]
        });
      }), ti = (0, s.PA)((e10) => {
        var t2, a2;
        let { playlist: r2, isDisabled: n2, className: s2, forwardRef: c2 } = e10, { shouldShowBuySubscriptionModal: _2, showBuySubscriptionModal: p2 } = (0, i.qBP)(), { from: m2, utmLink: v2 } = (0, i.fyy)({
          pageId: i._Q$.PLAYLIST,
          blockId: i.UfI.PLAYLIST,
          contextType: z.K.Playlist,
          contextId: r2.uuid,
          pageEntityId: r2.uuid
        }), {
          settings: { isMobile: x2 },
          sonataState: y2,
          trailer: f2,
          playlist: {
            filters: { activeFilter: P2, activeFilterName: j2, analyticsParamsActiveFilterIndex: k2 },
            enableVariousAutoFlow: T2,
            trackIds: w2,
            isRewind2024Playlist: L2,
            setShouldShowTrailerOnboarding: H2
          },
          user: I2
        } = (0, i.Pjs)(), { formatMessage: E2, formatNumber: M2 } = (0, h.A)(), [R2, S2] = (0, d.useState)(false), D2 = (0, eU.KX)(r2), U2 = (0, eU.A7)(r2), V2 = (0, i.Ftl)(), W2 = !x2, Y2 = (0, d.useRef)(null), Q2 = (0, d.useMemo)(() => ({ objectId: r2.uuid, tabId: P2, tabPos: k2 }), [r2.uuid, P2, k2]), $2 = (0, i.AA)(Q2), K2 = (0, i.YAl)(Q2), X2 = (0, i.Hu_)(Q2), q2 = (0, i.s6k)(Q2), G2 = (0, i.dtS)(Q2), Z2 = (0, i.brA)(), J2 = (0, i.PT7)(), { controlSize: ee2, iconSize: et2 } = l(x2), { notify: ea2 } = (0, i.lkh)(), er2 = r2.canUserChange && !x2, el2 = (0, ez.useSearchParams)(), eo2 = (0, d.useMemo)(() => {
          if (L2 && r2.personalColor) return (0, i.R4Z)(r2.personalColor);
        }, [L2, r2.personalColor]), en2 = (0, b.c)(() => {
          var e11;
          null == (e11 = Y2.current) || e11.focus();
        });
        (0, d.useEffect)(() => {
          R2 && $2();
        }, [R2, $2]);
        let es2 = (0, b.c)(async (e11) => {
          await r2.changeTitle(e11) === i.FlZ.ERROR && ea2((0, o.jsx)(N.hT, { error: E2({ id: "playlist-errors.failed-to-change-title" }) }), {
            containerId: i.uQT.ERROR
          });
        }), { isPlaying: ed2, togglePlay: ec2 } = (0, i.Dx4)({
          playContextParams: {
            contextData: {
              type: z.K.Playlist,
              meta: { id: r2.id, uuid: r2.uuid },
              filter: P2,
              filterName: j2,
              enableVariousAutoFlow: T2,
              from: m2,
              utmLink: v2
            },
            loadContextMeta: true,
            entitiesData: y2.unloadedEntitiesDataFromModels
          }
        }), [eu2, e_2] = (0, d.useState)(ed2), ep2 = (0, b.c)(() => {
          if (!J2()) {
            if (_2) return void p2();
            ec2(), Z2(!ed2), y2.setPlaylistFilter(P2), eu2 ? G2() : q2();
          }
        });
        (0, d.useEffect)(() => {
          ed2 && (y2.playlistFilter === P2 || (0, eO.A)(y2.playlistFilter) && (0, eO.A)(P2)) ? e_2(true) : e_2(false);
        }, [ed2, y2.playlistFilter, P2]);
        let em2 = (0, d.useMemo)(() => {
          if (r2.actualLikesCount && r2.actualLikesCount > 0)
            return (0, o.jsx)(g.Caption, {
              variant: "span",
              type: "controls",
              size: "s",
              weight: "medium",
              children: r2.actualLikesCount && M2(r2.actualLikesCount)
            });
        }, [r2.actualLikesCount, M2]), ev2 = (0, d.useMemo)(
          () => x2 ? (0, o.jsx)(N.DM, {
            ref: Y2,
            className: ei().playControl,
            color: "primary",
            buttonVariant: "default",
            iconSize: "xxl",
            isPlaying: eu2,
            variant: "filled",
            onClick: ep2,
            disabled: n2
          }) : (0, o.jsx)(N.DM, {
            ref: Y2,
            className: ei().playControl,
            withRipple: true,
            buttonVariant: "default",
            radius: "xxxl",
            size: "s",
            color: "primary",
            iconSize: "xxs",
            isPlaying: eu2,
            onClick: ep2,
            disabled: n2,
            children: (0, o.jsx)(O.A, { id: "player-actions.listen" })
          }),
          [n2, x2, ep2, eu2]
        ), ex2 = (0, b.c)(() => {
          J2() || (f2.setUtmLink(v2), f2.openPlaylistTrailer(r2.id), V2(F.ky.Playlist, r2.id));
        });
        (0, d.useEffect)(() => {
          var e11;
          (null == (e11 = r2.trailer) ? void 0 : e11.isAvailable) && "true" === el2.get(i.K3F.OPEN_TRAILER) && ex2();
        }, [L2, r2.personalColor, ex2, el2, H2, null == (t2 = r2.trailer) ? void 0 : t2.isAvailable]);
        let eg2 = (0, d.useMemo)(() => {
          var e11;
          return (null == (e11 = r2.trailer) ? void 0 : e11.isAvailable) && !x2 ? (0, o.jsx)(N.cv, {
            children: (0, o.jsx)(N.kJ, {
              size: "s",
              radius: "xxxl",
              iconSize: "xxs",
              className: e$().trailerControl,
              onClick: ex2,
              disabled: !r2.isAvailable,
              style: eo2,
              children: (0, o.jsx)(O.A, { id: "entity-names.trailer" })
            })
          }) : null;
        }, [ex2, x2, null == (a2 = r2.trailer) ? void 0 : a2.isAvailable, r2.isAvailable, eo2]), ey2 = (0, d.useMemo)(() => {
          if (r2.canUserChange)
            return (0, o.jsx)("div", { className: e$().ugcControls, children: (0, o.jsx)(te, { playlist: r2 }) });
        }, [r2]), ef2 = (0, d.useMemo)(
          () => E2({ id: "entity-names.likes-count-description" }, { count: r2.actualLikesCount }),
          [E2, r2.actualLikesCount]
        ), eh2 = (0, b.c)(() => {
          D2(), r2.isLiked ? K2() : X2();
        }), eb2 = (0, C.L)(() => {
          if (!r2.isFavouritePlaylist)
            return x2 ? (0, o.jsx)(N.cy, {
              className: e$().likeControl,
              isLiked: r2.isLiked,
              onClick: eh2,
              variant: "default",
              size: ee2,
              iconSize: et2,
              iconClassName: e$().likeIcon,
              disabled: !I2.isAuthorized
            }) : (0, o.jsx)(N.cy, {
              className: e$().likeControl,
              isLiked: r2.isLiked,
              onClick: eh2,
              withRipple: true,
              iconSize: et2,
              size: ee2,
              variant: "default",
              "aria-label": ef2,
              iconClassName: e$().likeIcon,
              disabled: !I2.isAuthorized,
              children: em2
            });
        }), eC2 = I2.hasPlus && !x2 && r2.isFavouritePlaylist && r2.isOwnPlaylist, eP2 = (0, d.useMemo)(
          () => (0, o.jsxs)("div", {
            className: e$().controls,
            children: [
              (0, o.jsxs)("div", {
                className: e$().mainControls,
                children: [
                  ev2,
                  (0, o.jsx)(eG, { playlistUuid: r2.uuid }),
                  eg2,
                  eb2,
                  W2 && (0, o.jsx)(N.O0, { onClick: U2, isPinned: r2.isPinned, className: e$().pinControl }),
                  (0, o.jsx)(ta, {
                    playlist: r2,
                    open: R2,
                    onOpenChange: S2,
                    wrapperClassName: e$().menuControl,
                    size: ee2,
                    icon: (0, o.jsx)(A.Icon, { size: et2, variant: "more" }),
                    ...(0, u.Am)(u.e8.pageHeader.PLAYLIST_HEADER_CONTEXT_MENU_BUTTON)
                  }),
                  eC2 && (0, o.jsx)(eY, { trackIds: w2, className: e$().downloadControl, onRemove: en2 })
                ]
              }),
              ey2
            ]
          }),
          [ev2, eg2, eb2, U2, r2, eC2, w2, R2, ee2, et2, ey2, W2, en2]
        );
        return (0, o.jsx)("div", {
          className: e$().root,
          children: (0, o.jsx)(B, {
            headingVariant: "h1",
            ref: c2,
            className: s2,
            controls: eP2,
            meta: (0, o.jsx)(e6, { playlist: r2 }),
            entityName: E2({ id: "entity-names.playlist" }),
            title: r2.title,
            canChangeTitle: er2,
            maxTitleLength: eU.kc,
            onTitleChange: es2,
            cover: (0, o.jsx)(e7, { playlist: r2 })
          })
        });
      }), tr = (0, d.forwardRef)((e10, t2) => (0, o.jsx)(ti, { forwardRef: t2, ...e10 }));
      var tl = a(14342), to = a(91283), tn = a(34923), ts = a.n(tn);
      let td = (0, s.PA)((e10) => {
        let { album: t2, className: a2, "aria-labelledby": r2 } = e10, { language: n2 } = (0, i.h6b)(), { formatMessage: s2 } = (0, h.A)(), { from: d2, utmLink: c2 } = (0, i.fyy)({
          pageId: i._Q$.PROMOLANDING_ALBUM,
          blockId: i.UfI.ALBUM,
          contextType: z.K.Album,
          contextId: t2.id
        }), {
          settings: { isMobile: _2 },
          promolanding: { state: p2 },
          albumCPA: { isPlusCPAEnabled: m2 },
          promolanding: v2
        } = (0, i.Pjs)(), { headerElements: x2 } = (0, to.E8)(), { isPlaying: g2, togglePlay: y2 } = (0, i.Dx4)({
          playContextParams: {
            contextData: { type: z.K.Album, meta: { id: t2.id }, from: d2, utmLink: c2, playDisliked: true },
            loadContextMeta: true,
            entitiesData: p2.unloadedEntitiesDataFromModels
          },
          playbackId: i.V_r.PROMO_LANDING,
          sonataState: p2
        }), f2 = (0, U.c5)(t2), { pageAlbumId: b2 } = (0, i.THB)(), P2 = (0, U.r_)(t2.type), { iconSize: A2, controlSize: j2 } = l(_2), k2 = (0, ed.Q$)(), T2 = (0, C.L)(
          () => _2 ? (0, o.jsx)(N.DM, {
            className: ei().playControl,
            color: "primary",
            buttonVariant: "default",
            iconSize: "xxl",
            isPlaying: g2,
            onClick: y2,
            variant: "filled",
            disabled: !t2.isAvailable
          }) : (0, o.jsx)(N.DM, {
            className: ei().playControl,
            withRipple: true,
            buttonVariant: "default",
            radius: "xxxl",
            size: "s",
            color: "primary",
            iconSize: "xxs",
            isPlaying: g2,
            onClick: y2,
            disabled: !t2.isAvailable,
            children: (0, o.jsx)(O.A, { id: "player-actions.listen" })
          })
        ), w2 = !m2({ pageAlbumId: b2, albumId: t2.id, isNonMusic: t2.isNonMusic }) && !t2.isAvailable, L2 = (0, C.L)(() => {
          var e11, t3;
          if (!v2.hasDonations || !(null == (t3 = v2.donations) || null == (e11 = t3.items) ? void 0 : e11[0])) return null;
          let a3 = v2.donations.items[0], r3 = k2(a3.url);
          return (0, o.jsx)(i.FoH, {
            blockType: F.LA.Donations,
            blockId: i.UfI.DONATY,
            children: (0, o.jsx)(i.Bki, {
              objectType: F.ky.Donation,
              objectId: String(a3.artist.id),
              children: (0, o.jsx)(eu, {
                iconSize: A2,
                controlSize: j2,
                url: r3,
                "aria-label": s2({ id: "donation.button-text" })
              })
            })
          });
        }), H2 = (0, C.L)(() => {
          if (!x2 || 0 === x2.length)
            return (0, o.jsxs)(o.Fragment, {
              children: [
                T2,
                (0, o.jsx)(N.cy, {
                  className: ts().likeControl,
                  isLiked: t2.isLiked,
                  onClick: f2,
                  variant: "default",
                  size: j2,
                  iconSize: A2,
                  withRipple: !_2,
                  disabled: w2
                })
              ]
            });
          let e11 = {
            [to._7.Player]: T2,
            [to._7.Like]: (0, o.jsx)(N.cy, {
              className: ts().likeControl,
              isLiked: t2.isLiked,
              onClick: f2,
              variant: "default",
              size: j2,
              iconSize: A2,
              withRipple: !_2,
              disabled: w2
            }),
            [to._7.Donation]: L2
          };
          return (0, o.jsx)(o.Fragment, {
            children: x2.map((t3, a3) => {
              let i2 = e11[t3];
              return i2 ? (0, o.jsx)("div", { style: { order: a3 }, children: i2 }, "".concat(t3, "-").concat(a3)) : null;
            })
          });
        });
        return (0, o.jsx)(B, {
          headingVariant: "h1",
          className: a2,
          controls: (0, o.jsx)("div", {
            className: ei().controlsContainer,
            children: (0, o.jsx)("div", { className: ei().controls, children: H2 })
          }),
          meta: (0, o.jsx)(Z, { album: t2, withArtistLink: false }),
          entityName: P2,
          title: t2.title,
          cover: (0, o.jsx)(et, { coverVariant: "square", coverUri: t2.coverUri, isAvailable: t2.isAvailable }),
          "aria-labelledby": r2,
          version: t2.version,
          logo: (0, o.jsx)(N.N_, {
            component: (0, o.jsx)("a", {}),
            target: "_blank",
            href: "/",
            "aria-label": s2({ id: "footer.yandex-music" }),
            ...(0, u.Am)(u.e8.pageHeader.PROMOLANDING_PAGE_HEADER_LOGO),
            children: (0, o.jsx)(tl.gu, {
              size: "xs",
              alignIcon: tl.wT.CENTER,
              lang: "ru" !== n2 ? tl.LogoLang.EN : tl.LogoLang.RU
            })
          })
        });
      });
    },
    34284: (e, t, a) => {
      "use strict";
      a.d(t, { O: () => d, D: () => p });
      var i = a(54486), r = a(50420), l = a(15209), o = a(97800), n = a(26547), s = a.n(n);
      let d = (e2) => {
        let { title: t2, className: a2, titleClassName: n2, infoDescription: d2, ...c2 } = e2;
        return (0, i.jsxs)("div", {
          className: (0, r.$)(s().root, a2),
          ...(0, l.getDataAttrFromProps)(c2),
          children: [
            t2 && (0, i.jsx)(o.Heading, { variant: "h4", className: (0, r.$)(s().infoTitle, n2), children: t2 }),
            d2
          ]
        });
      };
      var c = a(28303), u = a(74125), _ = a(80585);
      let p = (0, c.PA)((e2) => {
        let { children: t2, href: a2, className: r2 } = e2, {
          currentTrackInfo: { modal: l2 }
        } = (0, u.Pjs)();
        return a2 ? (0, i.jsx)(_.N_, {
          className: s().link,
          href: a2,
          onClick: l2.close,
          children: (0, i.jsx)(o.Caption, { className: r2, variant: "div", size: "l", children: t2 })
        }) : (0, i.jsx)(o.Caption, { className: r2, variant: "div", size: "l", children: t2 });
      });
    },
    34923: (e) => {
      e.exports = { likeControl: "PromoLandingPageHeaderAlbum_likeControl__iWuEF" };
    },
    51376: (e, t, a) => {
      "use strict";
      a.d(t, { vK: () => d, Zr: () => h, Ab: () => c, AL: () => P, sO: () => T, Qj: () => l });
      var i = a(61910);
      let r = (0, i.createContext)({ data: null, isEnabled: false }), l = () => (0, i.useContext)(r);
      var o = a(93064), n = a(74125), s = a(26433);
      let d = s.JE.extend((e2) => ({
        views: {
          get isVisible() {
            let { experiments: t2 } = (0, o.Zn)(e2);
            return t2.checkExperiment(n.zal.WebNextBrandedPlaylistsAxe, "on"), false;
          }
        }
      })).named("BrandedEntityAxeBanner"), c = s.JE.extend((e2) => ({
        views: {
          get isVisible() {
            let { experiments: t2, settings: a2, user: i2 } = (0, o.Zn)(e2);
            if (!e2.noAds && !e2.hasError && e2.type === n.h8o.BRANDING) return !a2.isMobile;
            if (e2.noAds || e2.hasError || e2.type !== n.h8o.BRANDING || t2.checkExperiment(n.zal.WebNextDisableAds, "on"))
              return false;
            return !i2.hasPlus && !a2.isMobile;
          }
        }
      })).named("BrandedPlaylistBanner");
      var u = a(54486), _ = a(28303), p = a(43426), m = a(8817), v = a(80585);
      let x = { pp: "g", ps: "clni", p2: "jjwl", puid1: "", puid2: "", puid3: "" }, g = { pp: "g", ps: "clni", p2: "jjzh", puid1: "", puid2: "", puid3: "" }, y = { pp: "g", ps: "clni", p2: "jozm", puid1: "", puid2: "", puid3: "" }, f = { p1: "dlnfl", p2: "jpzb", puid1: "", puid2: "", puid3: "" }, h = (0, _.PA)((e2) => {
        let { className: t2, creativeClassName: a2, gradientClassName: r2 } = e2, {
          advertBanners: {
            banners: { brandedPlaylistBanner: l2 }
          }
        } = (0, n.Pjs)(), { formatMessage: o2 } = (0, p.A)(), s2 = (0, m.c)(() => {
          l2.setType(n.h8o.BRANDING);
        });
        return (0, i.useEffect)(
          () => () => {
            l2.reset();
          },
          [l2]
        ), (0, u.jsxs)("div", {
          className: t2,
          "aria-label": o2({ id: "advert.banner" }),
          role: "banner",
          children: [
            (0, u.jsx)(v.NX, {
              className: r2,
              ownerId: n.PVv,
              containerId: "adfox_173998931315812570",
              params: x,
              onLoad: s2,
              onError: l2.toggleHasErrorTrue,
              onNoAds: l2.toggleNoAdsTrue
            }),
            (0, u.jsx)(v.NX, {
              className: a2,
              ownerId: n.PVv,
              containerId: "adfox_174043316511852570",
              params: g,
              onLoad: s2,
              onError: l2.toggleHasErrorTrue,
              onNoAds: l2.toggleNoAdsTrue
            })
          ]
        });
      });
      var b = a(16560), C = (function(e2) {
        return e2.PLAYLIST_GRADIENT = "branded_playlist_gradient", e2.AXE_GRADIENT = "branded_axe_gradient", e2;
      })({});
      let P = (0, _.PA)((e2) => {
        let { children: t2 } = e2, {
          advertBanners: {
            banners: { brandedPlaylistBanner: a2, brandedEntityAxeBanner: l2 }
          }
        } = (0, n.Pjs)(), [o2, s2] = (0, i.useState)(null), d2 = (e3) => {
          ((e4) => (0, b.m)(e4) && (e4.type === C.PLAYLIST_GRADIENT || e4.type === C.AXE_GRADIENT) && "object" == typeof e4.payload && null !== e4.payload && !Array.isArray(e4.payload) && "color" in e4.payload)(e3.data) && s2(e3.data);
        };
        (0, i.useEffect)(
          () => (window.addEventListener("message", d2), () => {
            window.removeEventListener("message", d2);
          }),
          []
        );
        let c2 = (0, i.useMemo)(() => {
          if ((null == o2 ? void 0 : o2.payload.color) === void 0) return {};
          let e3 = {
            "--entity-branding-gradient-color-from": o2.payload.color,
            "--entity-branding-gradient-color-to": "transparent"
          };
          return null === o2.payload.button ? e3 : {
            ...e3,
            "--entity-branding-button-background-color": o2.payload.button.backgroundColor,
            "--entity-branding-button-text-color": o2.payload.button.textColor
          };
        }, [null == o2 ? void 0 : o2.payload.color, null == o2 ? void 0 : o2.payload.button]), _2 = (0, i.useMemo)(() => {
          let e3 = a2.isVisible && a2.type !== n.h8o.EMPTY, t3 = l2.isVisible && l2.type !== n.h8o.EMPTY, i2 = e3 || t3;
          return i2 && null !== o2 ? { data: { type: o2.type, style: c2, button: o2.payload.button }, isEnabled: i2 } : { data: null, isEnabled: false };
        }, [o2, c2, a2.isVisible, a2.type, l2.isVisible, l2.type]);
        return (0, u.jsx)(r.Provider, { value: _2, children: t2 });
      });
      var A = a(50420), j = a(72166), N = a.n(j);
      let k = (0, _.PA)((e2) => {
        var t2, a2;
        let { children: r2, className: o2 } = e2, { formatMessage: s2 } = (0, p.A)(), {
          advertBanners: {
            banners: { brandedEntityAxeBanner: d2 }
          }
        } = (0, n.Pjs)(), c2 = l(), _2 = (0, i.useContext)(n.qTt), x2 = null != (a2 = null == _2 ? void 0 : _2.isCollapsed) && a2, g2 = (0, m.c)(() => {
          d2.setType(n.h8o.BRANDING);
        });
        return ((0, i.useEffect)(
          () => () => {
            d2.reset();
          },
          [d2]
        ), d2.isVisible) ? (0, u.jsxs)("div", {
          "aria-label": s2({ id: "advert.banner" }),
          role: "banner",
          children: [
            (0, u.jsx)(v.NX, {
              ownerId: n.PVv,
              containerId: "adfox_176504636866914259",
              params: f,
              onLoad: g2,
              onError: d2.toggleHasErrorTrue,
              onNoAds: d2.toggleNoAdsTrue,
              className: (0, A.$)(N().creative, { [N().creative_withCollapsedNavbar]: x2 })
            }),
            (0, u.jsx)(v.NX, {
              ownerId: n.PVv,
              containerId: "adfox_176053846725924259",
              params: y,
              onLoad: g2,
              onError: d2.toggleHasErrorTrue,
              onNoAds: d2.toggleNoAdsTrue
            }),
            (0, u.jsx)("div", {
              className: (0, A.$)(N().root, o2, { [N().root_withCollapsedNavbar]: x2 }),
              style: null == (t2 = c2.data) ? void 0 : t2.style,
              children: r2
            })
          ]
        }) : r2;
      }), T = (0, _.PA)((e2) => {
        let { children: t2, className: a2 } = e2;
        return (0, u.jsx)(P, { children: (0, u.jsx)(k, { className: a2, children: t2 }) });
      });
    },
    53266: (e) => {
      e.exports = {
        cancelIcon: "DownloadButton_cancelIcon__MR36M",
        root_downloading: "DownloadButton_root_downloading__H8Eh7",
        root: "DownloadButton_root__AU5eq",
        downloadingProgress: "DownloadButton_downloadingProgress__eenjt",
        progress: "DownloadButton_progress__MM72T",
        progressText: "DownloadButton_progressText__aQ12B",
        downloadedIcon: "DownloadButton_downloadedIcon__tETl2"
      };
    },
    53516: (e) => {
      e.exports = {
        button: "PageHeaderPlaylistUgcUploadButton_button__mWtCr",
        form: "PageHeaderPlaylistUgcUploadButton_form__V64Yu"
      };
    },
    58714: (e) => {
      e.exports = {
        meta: "PageHeaderAlbumMeta_meta__zsMI8",
        artistCover: "PageHeaderAlbumMeta_artistCover__L3jJ0",
        artistLabel: "PageHeaderAlbumMeta_artistLabel__2WZSM",
        year: "PageHeaderAlbumMeta_year__2X3NO",
        artists: "PageHeaderAlbumMeta_artists__Nfdob",
        artistsSpoiler: "PageHeaderAlbumMeta_artistsSpoiler__VOkfE",
        artistLink: "PageHeaderAlbumMeta_artistLink__eTSrZ",
        year_dot: "PageHeaderAlbumMeta_year_dot__TrSFr"
      };
    },
    61805: (e) => {
      e.exports = {
        root: "PageHeaderPlaylist_root__yJBii",
        trailerControl: "PageHeaderPlaylist_trailerControl__grrD9",
        pinControl: "PageHeaderPlaylist_pinControl__hJOde",
        downloadControl: "PageHeaderPlaylist_downloadControl__ijcAx",
        menuControl: "PageHeaderPlaylist_menuControl__RGH0G",
        likeControl: "PageHeaderPlaylist_likeControl__bCypn",
        controls: "PageHeaderPlaylist_controls__uSwwK",
        mainControls: "PageHeaderPlaylist_mainControls__k_S_i",
        ugcControls: "PageHeaderPlaylist_ugcControls__9q8Ne"
      };
    },
    64396: (e) => {
      e.exports = {
        root_hoverable: "PageHeaderCover_root_hoverable__WF_BH",
        coverImage: "PageHeaderCover_coverImage__i0wBv",
        coverImage_hoverable: "PageHeaderCover_coverImage_hoverable__9XZK7",
        coverButton: "PageHeaderCover_coverButton__3zeub",
        coverButton_hoverable: "PageHeaderCover_coverButton_hoverable__hS1Gq",
        plusBadge: "PageHeaderCover_plusBadge__O09t4"
      };
    },
    66824: (e) => {
      e.exports = {
        root: "PageHeaderTitle_root__ESu2q",
        editButton: "PageHeaderTitle_editButton__KF4eh",
        editButton_centered: "PageHeaderTitle_editButton_centered__W9EwU",
        textField: "PageHeaderTitle_textField__LXJ3X",
        textField_long: "PageHeaderTitle_textField_long__ReeJz",
        title: "PageHeaderTitle_title__caKyB",
        version: "PageHeaderTitle_version__g5BeO",
        version_withOtherVersions: "PageHeaderTitle_version_withOtherVersions__Amfwk",
        heading: "PageHeaderTitle_heading__UADXi",
        heading_withVersion: "PageHeaderTitle_heading_withVersion__jw12r",
        textFieldContainer: "PageHeaderTitle_textFieldContainer__FSD_B",
        font_long: "PageHeaderTitle_font_long__q9Leq",
        font_short: "PageHeaderTitle_font_short__76VRG",
        font_mobile: "PageHeaderTitle_font_mobile__M1__v",
        stickyTitle: "PageHeaderTitle_stickyTitle__CL1m4",
        titleWithLinkIcon: "PageHeaderTitle_titleWithLinkIcon__mBP_B",
        titleWithLink: "PageHeaderTitle_titleWithLink__pJZN5",
        linkContainer: "PageHeaderTitle_linkContainer__KUyIF",
        linkText: "PageHeaderTitle_linkText__rSUmw",
        arrowWrapper: "PageHeaderTitle_arrowWrapper__cadS3",
        arrowWrapper_long: "PageHeaderTitle_arrowWrapper_long__xhAjB",
        arrowWrapper_short: "PageHeaderTitle_arrowWrapper_short__45ema",
        arrowWrapper_mobile: "PageHeaderTitle_arrowWrapper_mobile__iYnjq"
      };
    },
    71609: (e) => {
      e.exports = {
        meta: "PageHeaderNonMusic_meta__9DQPy",
        infoNote: "PageHeaderNonMusic_infoNote__7xbV5",
        infoNoteIcon: "PageHeaderNonMusic_infoNoteIcon__VDK7_",
        infoNoteText: "PageHeaderNonMusic_infoNoteText__DCQq8",
        plusPaywallButton: "PageHeaderNonMusic_plusPaywallButton__O7Tx_",
        booksLogo: "PageHeaderNonMusic_booksLogo__4_TgU",
        controlsBlock: "PageHeaderNonMusic_controlsBlock__jta99",
        plusLinkBlock: "PageHeaderNonMusic_plusLinkBlock__8R1OK",
        plusLinkContainer: "PageHeaderNonMusic_plusLinkContainer__guWlu",
        plusLink: "PageHeaderNonMusic_plusLink__6dU1b",
        divider: "PageHeaderNonMusic_divider__F_sbf"
      };
    },
    72166: (e) => {
      e.exports = {
        root: "WithBrandedEntityAxeBanner_root__aXh91",
        root_withCollapsedNavbar: "WithBrandedEntityAxeBanner_root_withCollapsedNavbar__msb7M",
        creative: "WithBrandedEntityAxeBanner_creative__Fp6Vg"
      };
    },
    87767: (e) => {
      e.exports = {
        plusPaywallButton: "PageHeaderAlbum_plusPaywallButton__yJWCh",
        booksLogo: "PageHeaderAlbum_booksLogo__f4gjV"
      };
    },
    91283: (e, t, a) => {
      "use strict";
      a.d(t, { Cq: () => r, _7: () => o, E8: () => s });
      var i = a(74125), r = (function(e2) {
        return e2.Concerts = "concerts", e2.Donation = "donation", e2.PlusOffer = "plusOffer", e2.ExternalStreamings = "externalStreamings", e2.SocialLinks = "socialLinks", e2;
      })({}), l = (function(e2) {
        return e2.PlusOffer = "plusOffer", e2;
      })({}), o = (function(e2) {
        return e2.Like = "like", e2.Donation = "donation", e2.Player = "player", e2;
      })({}), n = a(27510);
      let s = () => {
        let {
          experiments: e2,
          settings: { isMobile: t2 }
        } = (0, i.Pjs)(), a2 = (0, n.L)(() => {
          var t3;
          let a3 = e2.getExperiment(i.zal.WebNextPromoLandingLayout), n2 = null == a3 || null == (t3 = a3.value) ? void 0 : t3.params;
          return ((e3) => {
            if ("object" != typeof e3 || null === e3) return false;
            let t4 = "mobile" in e3 && ((e4) => {
              if ("object" != typeof e4 || null === e4) return false;
              let t5 = "header" in e4 && (0, i.BCw)(e4.header, o), a5 = "content" in e4 && (0, i.BCw)(e4.content, r);
              return t5 && a5;
            })(e3.mobile), a4 = "desktop" in e3 && ((e4) => {
              if ("object" != typeof e4 || null === e4) return false;
              let t5 = "header" in e4 && (0, i.BCw)(e4.header, o), a5 = "content" in e4 && (0, i.BCw)(e4.content, r), n3 = "footer" in e4 && (0, i.BCw)(e4.footer, l);
              return t5 && a5 && n3;
            })(e3.desktop);
            return t4 && a4;
          })(n2) ? n2 : null;
        }), s2 = (0, n.L)(() => {
          if (!a2) return [];
          let e3 = t2 ? a2.mobile : a2.desktop;
          return (null == e3 ? void 0 : e3.header) || [];
        }), d = (0, n.L)(() => {
          if (!a2) return [];
          let e3 = t2 ? a2.mobile : a2.desktop;
          return (null == e3 ? void 0 : e3.content) || [];
        }), c = (0, n.L)(() => {
          var e3;
          return !a2 || t2 ? [] : (null == (e3 = a2.desktop) ? void 0 : e3.footer) || [];
        });
        return { layoutConfig: a2, headerElements: s2, contentElements: d, footerElements: c };
      };
    },
    92504: (e) => {
      e.exports = { root: "PageHeaderPlaylistBrandingLink_root__7dQVL" };
    }
  }
]);
