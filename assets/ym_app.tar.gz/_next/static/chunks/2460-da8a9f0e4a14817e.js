"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2460],
  {
    5892: (t, e, r) => {
      r.d(e, { Q: () => s });
      var a = r(96559), i = r(77220), n = r(53676);
      class s extends i.X {
        async experiments(t2, e2) {
          return (await this.httpClient.get(
            "account/experiments",
            this.createHttpOptions({ timeoutKey: "experiments", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async experimentsDetails(t2, e2) {
          return (await this.httpClient.get(
            "account/experiments/details",
            this.createHttpOptions({
              timeoutKey: "experimentsDetails",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async settings(t2, e2) {
          return (await this.httpClient.post(
            "account/settings",
            this.createHttpOptions({
              timeoutKey: "settings",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, n.P)({
                childModEnabled: null == t2 ? void 0 : t2.childModEnabled,
                userMusicVisibility: null == t2 ? void 0 : t2.userMusicVisibility
              })
            })
          )).json();
        }
        async about(t2, e2) {
          return (await this.httpClient.get(
            "account/about",
            this.createHttpOptions({ timeoutKey: "about", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, a._)(this, "httpClient", void 0), (0, a._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    12460: (t, e, r) => {
      r.d(e, {
        wV: () => t7,
        d7: () => es,
        o7: () => ed,
        wK: () => tt,
        DT: () => o,
        FX: () => eo,
        OU: () => n,
        Mz: () => t4,
        je: () => c,
        _2: () => et,
        sY: () => ec
      });
      var a, i, n, s, o, c, l, u = r(96559);
      let h = /* @__PURE__ */ Symbol("CONTAINER_USER_CONFIG_TOKEN"), d = /* @__PURE__ */ Symbol("CONTAINER_FEATURE_FLAGS_TOKEN"), g = /* @__PURE__ */ Symbol("CONTAINER_STORE_TOKEN"), y = /* @__PURE__ */ Symbol("CONTAINER_RESOURCES_TOKEN"), v = /* @__PURE__ */ Symbol("CONTAINER_REPOSITORY_CONTAINER_TOKEN"), m = /* @__PURE__ */ Symbol("CONTAINER_FILE_STORAGE_TOKEN"), p = /* @__PURE__ */ Symbol("CONTAINER_TRACK_MANAGER_TOKEN"), w = /* @__PURE__ */ Symbol("CONTAINER_USERS_TRACKS_MANAGER_TOKEN"), E = /* @__PURE__ */ Symbol("CONTAINER_ARTIST_MANAGER_TOKEN"), b = /* @__PURE__ */ Symbol("CONTAINER_ALBUM_MANAGER_TOKEN"), f = /* @__PURE__ */ Symbol("CONTAINER_USERS_ALBUMS_MANAGER_TOKEN"), T = /* @__PURE__ */ Symbol("CONTAINER_TRACKS_CONTROLLER_TOKEN"), k = /* @__PURE__ */ Symbol("CONTAINER_PLAYLISTS_CONTROLLER_TOKEN"), C = /* @__PURE__ */ Symbol("CONTAINER_ARTISTS_CONTROLLER_TOKEN"), S = /* @__PURE__ */ Symbol("CONTAINER_ALBUMS_CONTROLLER_TOKEN"), I = /* @__PURE__ */ Symbol("CONTAINER_DOWNLOADER_TOKEN"), A = /* @__PURE__ */ Symbol("CONTAINER_HOOKS_TOKEN"), _ = /* @__PURE__ */ Symbol("CONTAINER_TRACK_DOWNLOAD_TASK_PARAMS_TOKEN");
      !(function(t10) {
        t10.TRACK_META_RECEIVED = "track_meta_received", t10.TRACK_DECRYPT_KEY_RECEIVED = "track_decrypt_key_received", t10.CHUNK_MEDIA_FILE_RECEIVED = "chunk_media_file_received", t10.MEDIA_FILE_RECEIVED = "media_file_received", t10.ARTIST_IMAGE_RECEIVED = "artist_image_received", t10.TRACK_IMAGE_RECEIVED = "track_image_received", t10.TRACK_DOWNLOAD_FINISHED = "track_download_finished", t10.TRACK_DOWNLOAD_STOPPED = "track_download_stopped", t10.TRACK_DOWNLOAD_FAILED = "track_download_failed", t10.ALBUM_META_RECEIVED = "album_meta_received";
      })(a || (a = {}));
      var R = r(56258);
      class O extends R.t {
        constructor(t10, { code: e2 = "E_ARTISTS_CONTROLLER", ...r2 } = {}) {
          super("".concat("[ArtistsController]", " ").concat(t10), { code: e2, ...r2 }), (0, u._)(this, "name", "ArtistsControllerException"), Object.setPrototypeOf(this, O.prototype);
        }
      }
      let D = (t10) => "images/artists/".concat(t10);
      class x {
        async getArtist(t10) {
          try {
            return await this.artistManager.getArtist(t10);
          } catch (e2) {
            return this.hooks.afterError.promise(new O("Failed to get artist", { cause: e2, data: { id: t10 } })), null;
          }
        }
        async getArtistTrackIdsByUser(t10) {
          return await this.artistManager.getArtistTrackIdsByUser(t10);
        }
        onArtistImageReceived(t10, e2) {
          var r2;
          let a2 = D(t10);
          null == (r2 = this.fileStorage) || r2.writeFile(a2, e2).catch((t11) => {
            this.hooks.afterError.promise(new O("Failed to write artist image", { cause: t11, data: { path: a2 } }));
          });
        }
        constructor(t10) {
          (0, u._)(this, "hooks", void 0), (0, u._)(this, "downloader", void 0), (0, u._)(this, "fileStorage", void 0), (0, u._)(this, "artistManager", void 0), this.hooks = t10.container.get(A), this.downloader = t10.container.get(I), this.fileStorage = t10.container.get(m), this.artistManager = t10.container.get(E), this.downloader.events.on(a.ARTIST_IMAGE_RECEIVED, this.onArtistImageReceived.bind(this));
        }
      }
      var N = r(60482), L = r(14287);
      class P extends R.t {
        constructor(t10, { code: e2 = "E_CACHE_CONTROLLER", ...r2 } = {}) {
          super("".concat("[CacheController]", " ").concat(t10), { code: e2, ...r2 }), (0, u._)(this, "name", "CacheControllerException"), Object.setPrototypeOf(this, P.prototype);
        }
      }
      var M = r(99796);
      !(function(t10) {
        t10.RESPONSE_CACHE = "response_cache", t10.TRACKS = "tracks", t10.ALBUMS = "albums", t10.ALBUMS_TRACKS = "albums_tracks", t10.ALBUMS_ARTISTS = "albums_artists", t10.ARTISTS = "artists", t10.ARTISTS_TRACKS = "artists_tracks", t10.USERS = "users", t10.USERS_TRACKS = "users_tracks", t10.USERS_ALBUMS = "users_albums";
      })(i || (i = {}));
      let F = { name: i.ALBUMS, version: 1, restrictions: { attemptsCount: 3, count: 100 } }, K = { name: i.ALBUMS_ARTISTS, version: 1, restrictions: { attemptsCount: 3 } }, j = { name: i.ALBUMS_TRACKS, version: 1, restrictions: { attemptsCount: 3 } }, U = { name: i.ARTISTS, version: 1, restrictions: { attemptsCount: 3, count: 100 } }, B = { name: i.ARTISTS_TRACKS, version: 1, restrictions: { attemptsCount: 3 } }, G = { name: i.RESPONSE_CACHE, version: 1, restrictions: { attemptsCount: 3, count: 100 } };
      !(function(t10) {
        t10[t10.LOW = 1] = "LOW", t10[t10.MEDIUM = 2] = "MEDIUM", t10[t10.HIGH = 3] = "HIGH";
      })(n || (n = {}));
      let W = { name: i.TRACKS, version: 1, restrictions: { attemptsCount: 3, count: 100 } }, H = { name: i.USERS, version: 1, restrictions: { attemptsCount: 3, count: 100 } }, q = { name: i.USERS_ALBUMS, version: 1, restrictions: { attemptsCount: 3 } };
      !(function(t10) {
        t10.TRACK = "track", t10.ENTITY = "entity";
      })(s || (s = {}));
      let V = { name: i.USERS_TRACKS, version: 1, restrictions: { attemptsCount: 3 } };
      class Y {
        async get(t10, e2, r2) {
          var a2;
          return (null == (a2 = this.repositoryContainer.responseCacheRepository) ? void 0 : a2.get(t10, e2, r2)) || null;
        }
        put(t10) {
          var e2;
          let { uid: r2, requestId: a2, priority: i2, response: s2 } = t10;
          null == (e2 = this.repositoryContainer.responseCacheRepository) || e2.put({ uid: r2, requestId: a2, priority: null != i2 ? i2 : n.LOW, response: s2 });
        }
        constructor(t10) {
          (0, u._)(this, "repositoryContainer", void 0), this.repositoryContainer = t10.repositoryContainer;
        }
      }
      let z = [L.X1.REQUEST_TIMEOUT, L.X1.TEAPOT];
      class X {
        get shouldGetCache() {
          return "number" == typeof this.variables.uid && this.variables.isOffline;
        }
        getRequestId(t10) {
          return (0, N.createHash)("sha256").update(JSON.stringify(t10)).digest("hex");
        }
        async get(t10, e2) {
          if ("number" == typeof this.variables.uid)
            try {
              let r2 = await this.cacheManager.get(this.variables.uid, t10, e2);
              if (r2) return r2.response;
            } catch (e3) {
              throw new P("Cache not found", { cause: e3, data: { requestId: t10, uid: this.variables.uid } });
            }
          throw new P("Cache not found", { data: { requestId: t10, uid: String(this.variables.uid) } });
        }
        put(t10) {
          let { requestId: e2, response: r2, uid: a2, priority: i2 } = t10, n2 = null != a2 ? a2 : this.variables.uid;
          "number" == typeof n2 && this.cacheManager.put({ uid: n2, requestId: e2, priority: i2, response: r2 });
        }
        async handleError(t10, e2, r2) {
          if (!(t10 instanceof L.GX) || z.includes(t10.statusCode)) return this.get(e2, r2);
          throw t10;
        }
        constructor(t10) {
          (0, u._)(this, "cacheManager", void 0), (0, u._)(this, "variables", void 0), this.cacheManager = new Y({ repositoryContainer: t10.repositoryContainer }), this.variables = t10.variables;
        }
      }
      var Q = r(56157);
      let J = (t10) => (e2) => e2.id !== t10 || (e2.stop(), false);
      class Z {
        get quality() {
          return this.variables.getQuality();
        }
        injectTask(t10) {
          this.queue.push(t10), this.startNextDownload();
        }
        removeTask(t10) {
          this.removeTaskFromQueue(t10), this.removeTaskFromActiveDownloads(t10);
        }
        startTask(t10) {
          this.activeTasks.push(t10), t10.start().finally(() => {
            this.removeTaskFromActiveDownloads(t10.id), this.startNextDownload();
          });
        }
        startNextDownload() {
          let t10 = this.activeTasks.length, e2 = this.variables.maxConcurrentDownloads - t10;
          e2 > 0 && this.queue.length > 0 && this.queue.splice(0, e2).forEach(this.startTask.bind(this));
        }
        removeTaskFromQueue(t10) {
          this.queue = this.queue.filter(J(t10));
        }
        removeTaskFromActiveDownloads(t10) {
          this.activeTasks = this.activeTasks.filter(J(t10));
        }
        constructor(t10) {
          (0, u._)(this, "variables", void 0), (0, u._)(this, "events", new Q.v()), (0, u._)(this, "queue", []), (0, u._)(this, "activeTasks", []), this.variables = t10.variables;
        }
      }
      class $ {
        download(t10) {
          t10.forEach((t11) => {
            this.trackManager.download(t11, s.ENTITY);
          });
        }
        stopDownload(t10) {
          t10.forEach((t11) => {
            this.trackManager.stopDownload(t11);
          });
        }
        delete(t10) {
          t10.forEach((t11) => {
            this.trackManager.deleteTrack(t11);
          });
        }
        constructor(t10) {
          (0, u._)(this, "trackManager", void 0), this.trackManager = t10.container.get(p);
        }
      }
      class tt {
        apply(t10) {
          let { hooks: e2 } = t10;
          e2.afterError.tapPromise("LoggerPlugin", async (t11) => {
            let e3;
            return (e3 = t11 instanceof R.t ? t11 : new R.t("Error in Slam", { code: "E_SLAM", cause: t11 })).cause instanceof Error && delete e3.cause.stack, this.logger.error("[Slam] ".concat(e3.message), { ...e3.data, code: e3.code, cause: e3.cause }), Promise.resolve();
          });
        }
        constructor(t10) {
          (0, u._)(this, "logger", void 0);
          let { logger: e2 } = t10;
          this.logger = e2;
        }
      }
      var te = r(58900);
      !(function(t10) {
        t10.IDLE = "IDLE", t10.DOWNLOADING = "DOWNLOADING", t10.DOWNLOADED = "DOWNLOADED", t10.DOWNLOAD_FAILED = "DOWNLOAD_FAILED", t10.REMOVING = "REMOVING";
      })(o || (o = {}));
      class tr extends R.t {
        constructor(t10, { code: e2 = "E_ALBUMS_CONTROLLER", ...r2 } = {}) {
          super("".concat("[AlbumsController]", " ").concat(t10), { code: e2, ...r2 }), (0, u._)(this, "name", "AlbumsControllerException"), Object.setPrototypeOf(this, tr.prototype);
        }
      }
      class ta {
        async initState() {
          try {
            let t10 = await this.usersAlbumsManager.getAlbumsByUid();
            (null == t10 ? void 0 : t10.length) && (this.store.albums.state = t10.reduce((t11, e2) => (t11[String(e2)] = { loadingState: o.DOWNLOADED }, t11), {}));
          } catch (t10) {
            this.hooks.afterError.promise(new tr("Failed to init albums state", { cause: t10 }));
          }
        }
        download(t10, e2) {
          this.albumManager.download(t10, e2);
        }
        stopDownload(t10, e2) {
          this.albumManager.stopDownload(t10, e2);
        }
        async delete(t10, e2) {
          try {
            await this.albumManager.delete(t10, e2);
          } catch (r2) {
            this.hooks.afterError.promise(
              new tr("Failed to delete album", { cause: r2, data: { albumId: t10, trackIds: e2 } })
            );
          }
        }
        async getAlbum(t10) {
          try {
            return await this.albumManager.getAlbum(t10);
          } catch (e2) {
            return this.hooks.afterError.promise(new tr("Failed to get album", { cause: e2, data: { albumId: t10 } })), null;
          }
        }
        constructor(t10) {
          (0, u._)(this, "hooks", void 0), (0, u._)(this, "store", void 0), (0, u._)(this, "albumManager", void 0), (0, u._)(this, "usersAlbumsManager", void 0), this.hooks = t10.container.get(A), this.store = t10.container.get(g), this.albumManager = t10.container.get(b), this.usersAlbumsManager = t10.container.get(f);
        }
      }
      var ti = r(14032);
      !(function(t10) {
        t10.STATE_CHANGED = "STATE_CHANGED", t10.ENTITY_CHANGED = "ENTITY_CHANGED";
      })(c || (c = {}));
      let tn = (t10, e2) => 0 === e2 ? 100 : Math.min(Math.trunc(t10 / e2 * 100), 100);
      class ts {
        downloadList(t10, e2) {
          e2.length && (this.updateListState(t10, { loadingState: o.DOWNLOADING }), e2.forEach((t11) => {
            this.trackManager.download(t11, s.ENTITY);
          }), this.subscribeToTracksStateChanges(t10, e2));
        }
        stopDownloadList(t10, e2) {
          e2.length && (e2.forEach((t11) => {
            this.trackManager.stopDownload(t11);
          }), this.unsubscribeFromTracksStateChanges(t10), this.updateListState(t10, { loadingState: o.IDLE }));
        }
        async deleteList(t10, e2) {
          if (!e2.length) return;
          this.unsubscribeFromTracksStateChanges(t10), this.updateListState(t10, { loadingState: o.REMOVING });
          let r2 = e2.map(async (t11) => this.trackManager.deleteTrack(t11));
          await Promise.all(r2), this.updateListState(t10, { loadingState: o.IDLE, progress: void 0 });
        }
        unsubscribeFromTracksStateChanges(t10) {
          let e2 = this.trackStateChangeHandlers.get(t10);
          e2 && (this.store.tracks.events.off(c.ENTITY_CHANGED, e2), this.trackStateChangeHandlers.delete(t10));
        }
        subscribeToTracksStateChanges(t10, e2) {
          this.unsubscribeFromTracksStateChanges(t10);
          let r2 = e2.length, a2 = [];
          e2.forEach((t11) => {
            var e3;
            let [r3] = (0, ti.d)(t11);
            r3 && (null == (e3 = this.store.tracks.state[r3]) ? void 0 : e3.loadingState) === o.DOWNLOADED && a2.push(r3);
          });
          let i2 = new Set(a2);
          this.updateListState(t10, { loadingState: o.DOWNLOADING, progress: tn(i2.size, r2) });
          let n2 = (e3) => {
            let { id: a3, state: n3 } = e3;
            if (!i2.has(a3) && n3.loadingState === o.DOWNLOADED) {
              i2.add(a3);
              let e4 = i2.size, n4 = tn(e4, r2);
              e4 === r2 ? (this.updateListState(t10, { loadingState: o.DOWNLOADED, progress: n4 }), this.unsubscribeFromTracksStateChanges(t10)) : this.updateListState(t10, { loadingState: o.DOWNLOADING, progress: n4 });
            }
          };
          this.trackStateChangeHandlers.set(t10, n2), this.store.tracks.events.on(c.ENTITY_CHANGED, n2);
        }
        constructor(t10) {
          (0, u._)(this, "store", void 0), (0, u._)(this, "trackManager", void 0), (0, u._)(this, "trackStateChangeHandlers", /* @__PURE__ */ new Map()), this.store = t10.container.get(g), this.trackManager = t10.container.get(p);
        }
      }
      let to = (t10) => "images/albums/".concat(t10);
      class tc extends ts {
        download(t10, e2) {
          this.downloadList(t10, e2);
        }
        async delete(t10, e2) {
          if (!e2.length) return;
          let r2 = await this.filterEntityTracks(e2);
          r2.length && await this.deleteList(t10, r2);
        }
        stopDownload(t10, e2) {
          this.stopDownloadList(t10, e2);
        }
        async getAlbum(t10) {
          var e2;
          let r2 = await (null == (e2 = this.repositoryContainer.albumsRepository) ? void 0 : e2.get(t10));
          if (!r2) return null;
          let a2 = await this.getAlbumArtists(t10), i2 = { ...r2, artists: a2 };
          return i2.coverUri && this.fileStorage && (i2.coverUri = await this.fileStorage.createFileURL(to(t10))), i2;
        }
        async getAlbumArtists(t10) {
          var e2;
          let r2 = await (null == (e2 = this.repositoryContainer.albumsArtistsRepository) ? void 0 : e2.getArtistsByAlbumId(t10));
          return (null == r2 ? void 0 : r2.length) ? (await Promise.all(
            r2.map(async (t11) => {
              var e3;
              let { artistId: r3 } = t11;
              return null == (e3 = this.repositoryContainer.artistsRepository) ? void 0 : e3.get(r3);
            })
          )).filter((t11) => !!t11) : [];
        }
        async saveAlbum(t10, e2) {
          var r2, a2;
          let i2 = to(String(t10.id));
          null == (r2 = this.fileStorage) || r2.writeFile(i2, e2).catch((e3) => {
            this.hooks.afterError.promise(
              new tr("Failed to write album image", { cause: e3, data: { albumId: String(t10.id) } })
            );
          }), await (null == (a2 = this.repositoryContainer.albumsTracksRepository) ? void 0 : a2.getCountByAlbum(String(t10.id))) === t10.trackCount && (this.store.albums.setEntityState(String(t10.id), { loadingState: o.DOWNLOADED }), await this.usersAlbumsManager.put(String(t10.id)));
        }
        async filterEntityTracks(t10) {
          return (await Promise.all(
            t10.map(async (t11) => {
              let e2 = await this.usersTracksManager.get(t11);
              return (null == e2 ? void 0 : e2.downloadSource) === s.ENTITY ? t11 : null;
            })
          )).filter((t11) => null !== t11);
        }
        updateListState(t10, e2) {
          this.store.albums.setEntityState(t10, e2);
        }
        constructor(t10) {
          super({ container: t10.container }), (0, u._)(this, "hooks", void 0), (0, u._)(this, "downloader", void 0), (0, u._)(this, "fileStorage", void 0), (0, u._)(this, "repositoryContainer", void 0), (0, u._)(this, "usersAlbumsManager", void 0), (0, u._)(this, "usersTracksManager", void 0), this.hooks = t10.container.get(A), this.downloader = t10.container.get(I), this.fileStorage = t10.container.get(m), this.repositoryContainer = t10.container.get(v), this.usersAlbumsManager = t10.container.get(f), this.usersTracksManager = t10.container.get(w), this.downloader.events.on(a.ALBUM_META_RECEIVED, this.saveAlbum.bind(this));
        }
      }
      class tl {
        async getArtist(t10) {
          var e2, r2, a2;
          let i2 = await (null == (e2 = this.repositoryContainer.artistsRepository) ? void 0 : e2.get(t10));
          if (!i2) return null;
          let n2 = {
            available: true,
            decomposed: [],
            hasPromotions: false,
            ogImage: "",
            genres: [],
            ticketsAvailable: false,
            links: [],
            ratings: { week: 0, month: 0, day: 0 },
            counts: { tracks: 0, directAlbums: 0, alsoAlbums: 0, alsoTracks: 0 },
            ...i2
          }, s2 = D(t10);
          if (await (null == (r2 = this.fileStorage) ? void 0 : r2.isFileExisting(s2))) {
            let t11 = await (null == (a2 = this.fileStorage) ? void 0 : a2.createFileURL(s2));
            n2.cover && t11 && (n2.cover.uri = t11);
          }
          return n2;
        }
        async getArtistTrackIdsByUser(t10) {
          var e2, r2;
          return Promise.all([
            null == (e2 = this.repositoryContainer.usersTracksRepository) ? void 0 : e2.getTracksByUid(this.userConfig.uid),
            null == (r2 = this.repositoryContainer.artistsTracksRepository) ? void 0 : r2.getTracksByArtistId(t10)
          ]).then((t11) => {
            let [e3, r3] = t11;
            if (!e3 || !r3) return [];
            let a2 = r3.reduce((t12, e4) => (t12[e4.trackId] = true, t12), {});
            return e3.filter((t12) => {
              let [e4] = (0, ti.d)(t12);
              return e4 && a2[e4];
            });
          }).catch(() => []);
        }
        constructor(t10) {
          (0, u._)(this, "userConfig", void 0), (0, u._)(this, "repositoryContainer", void 0), (0, u._)(this, "fileStorage", void 0), this.userConfig = t10.container.get(h), this.repositoryContainer = t10.container.get(v), this.fileStorage = t10.container.get(m);
        }
      }
      let tu = { afterError: new (r(1271)).AsyncSeriesHook(["error"]) };
      class th {
        get state() {
          return this.loadingState;
        }
        set state(t10) {
          this.loadingState = t10, this.events.emit(c.STATE_CHANGED, this.state);
        }
        setEntityState(t10, e2) {
          this.loadingState[t10] = e2, this.events.emit(c.ENTITY_CHANGED, { id: t10, state: e2 });
        }
        clear() {
          this.state = {};
        }
        constructor() {
          (0, u._)(this, "loadingState", {}), (0, u._)(this, "events", new Q.v());
        }
      }
      class td {
        constructor() {
          (0, u._)(this, "tracks", void 0), (0, u._)(this, "albums", void 0), this.tracks = new th(), this.albums = new th();
        }
      }
      var tg = r(23666), ty = r(15209), tv = r(93451), tm = r(81849);
      class tp extends R.t {
        constructor(t10, { code: e2 = "E_DOWNLOADER", ...r2 } = {}) {
          super("".concat("[Downloader]", " ").concat(t10), { code: e2, ...r2 }), (0, u._)(this, "name", "DownloaderException"), Object.setPrototypeOf(this, tp.prototype);
        }
      }
      class tw {
        async getFileInfo(t10, e2) {
          let r2 = (0, tv.T)(), a2 = this.variables.codecs.join(""), i2 = "".concat(r2).concat(t10).concat(e2).concat(a2).concat(this.transport), n2 = await (0, tv.m)({ secretKey: this.secretKey, data: i2 });
          return this.getFileInfoResource.getFileInfo({
            tsInSeconds: r2,
            trackId: t10,
            quality: e2,
            codecs: this.variables.codecs,
            transports: [this.transport],
            sign: n2
          });
        }
        async getImage(t10, e2) {
          try {
            let r2 = (0, ty.createAvatarUrl)(t10, this.variables.coverSize, false), a2 = await fetch(r2, { cache: "no-store" }), i2 = await a2.blob();
            e2(i2);
          } catch (e3) {
            this.hooks.afterError.promise(
              new tp("Error when downloading image", { cause: String(e3), data: { src: t10 } })
            );
          }
        }
        async start() {
          try {
            var t10, e2;
            let [r2] = await this.tracksResource.getTracksMeta({ trackIds: [this.id] });
            if (!r2 || !r2.available) return void this.handleDownloadError("Track is not defined or is not available");
            let i2 = String(r2.id);
            this.events.emit(a.TRACK_META_RECEIVED, r2), r2.coverUri && this.getImage(r2.coverUri, (t11) => {
              this.events.emit(a.TRACK_IMAGE_RECEIVED, this.id, t11);
            }), null == (t10 = r2.artists) || t10.forEach((t11) => {
              var e3;
              (null == (e3 = t11.cover) ? void 0 : e3.uri) && this.getImage(t11.cover.uri, (e4) => {
                this.events.emit(a.ARTIST_IMAGE_RECEIVED, t11.id, e4);
              });
            }), null == (e2 = r2.albums) || e2.forEach((t11) => {
              t11.coverUri && this.getImage(t11.coverUri, (e3) => {
                this.events.emit(a.ALBUM_META_RECEIVED, t11, e3);
              });
            });
            let { downloadInfo: n2 } = await this.getFileInfo(i2, this.quality);
            if ("error" in n2 || n2.transport !== tm.o.ENCRAW)
              return void this.handleDownloadError("Erorr in download info or transport is not encraw");
            this.events.emit(a.TRACK_DECRYPT_KEY_RECEIVED, i2, n2.key);
            let s2 = null, o2 = 0, c2 = [], l2 = n2.urls[0];
            if (!l2) return void this.handleDownloadError("Src is not defined");
            let u2 = async () => {
              if (this.isStopped) return;
              let t11 = 0;
              null === s2 || o2 + this.variables.chunkSize < s2 ? t11 = o2 + this.variables.chunkSize - 1 : o2 + this.variables.chunkSize >= s2 && (t11 = s2);
              let {
                contentLength: e3,
                data: r3,
                contentRange: i3
              } = await this.getFileInfoResource.getByteRange({ srcUrl: l2, start: o2, end: t11 });
              o2 += e3, s2 = Number(i3.split("/")[1]), c2.push(r3), this.events.emit(a.CHUNK_MEDIA_FILE_RECEIVED, this.id, Math.floor(o2 / s2 * 100)), null !== s2 && o2 < s2 && await u2();
            };
            await u2(), o2 === s2 ? (this.events.emit(a.MEDIA_FILE_RECEIVED, this.id, new Blob(c2)), this.events.emit(a.TRACK_DOWNLOAD_FINISHED, this.id, this.downloadSource)) : this.events.emit(a.TRACK_DOWNLOAD_STOPPED, this.id);
          } catch (t11) {
            this.handleDownloadError(String(t11));
          }
        }
        stop() {
          this.isStopped = true;
        }
        handleDownloadError(t10) {
          this.hooks.afterError.promise(new tp("Error when downloading track", { cause: t10, data: { id: this.id } })), this.events.emit(a.TRACK_DOWNLOAD_FAILED, this.id);
        }
        constructor(t10, e2, r2, a2) {
          (0, u._)(this, "id", void 0), (0, u._)(this, "isStopped", false), (0, u._)(this, "tracksResource", void 0), (0, u._)(this, "getFileInfoResource", void 0), (0, u._)(this, "secretKey", void 0), (0, u._)(this, "transport", void 0), (0, u._)(this, "variables", void 0), (0, u._)(this, "quality", void 0), (0, u._)(this, "downloadSource", void 0), (0, u._)(this, "hooks", void 0), (0, u._)(this, "events", new Q.v()), this.id = t10, this.tracksResource = e2.tracksResource, this.getFileInfoResource = e2.getFileInfoResource, this.secretKey = e2.secretKey, this.transport = e2.transport, this.variables = e2.variables, this.events = e2.events, this.hooks = e2.hooks, this.quality = r2, this.downloadSource = null != a2 ? a2 : s.TRACK;
        }
      }
      let tE = (t10) => "images/tracks/".concat(t10), tb = (t10) => "tracks/".concat(t10), tf = [o.IDLE, o.DOWNLOAD_FAILED], tT = [o.IDLE, o.DOWNLOADING];
      class tk {
        initDownloaderEvents() {
          this.downloader.events.on(a.TRACK_META_RECEIVED, this.saveTrack.bind(this)), this.downloader.events.on(a.TRACK_DECRYPT_KEY_RECEIVED, this.putDecryptKey.bind(this)), this.downloader.events.on(a.CHUNK_MEDIA_FILE_RECEIVED, this.onChunkMediaFileReceived.bind(this)), this.downloader.events.on(a.TRACK_IMAGE_RECEIVED, this.onTrackImageReceived.bind(this)), this.downloader.events.on(a.TRACK_DOWNLOAD_FINISHED, this.onTrackDownloadFinished.bind(this)), this.downloader.events.on(a.TRACK_DOWNLOAD_STOPPED, this.onTrackDownloadStopped.bind(this)), this.downloader.events.on(a.TRACK_DOWNLOAD_FAILED, this.onTrackDownloadFailed.bind(this)), this.downloader.events.on(a.MEDIA_FILE_RECEIVED, this.onMediaFileReceived.bind(this));
        }
        async putTrackArtists(t10) {
          let e2 = 0;
          if (!t10.artists) return Promise.resolve();
          let r2 = [];
          return t10.artists.forEach((a2) => {
            let { decomposed: i2, ...n2 } = a2;
            r2.push({
              artistMeta: n2,
              artistTrack: { artistId: String(a2.id), trackId: String(t10.id), artistIndex: e2 }
            }), e2++;
            let s2 = "";
            i2 && i2.length > 0 && i2.forEach((a3) => {
              if ("string" == typeof a3) {
                s2 = a3;
                return;
              }
              r2.push({
                artistMeta: a3,
                artistTrack: {
                  artistId: String(a3.id),
                  trackId: String(t10.id),
                  artistIndex: e2,
                  decomposed: true,
                  prefix: s2
                }
              }), e2++, s2 = "";
            });
          }), Promise.all(
            r2.map(async (t11) => {
              var e3, r3;
              let { artistMeta: a2, artistTrack: i2 } = t11;
              return Promise.all([
                null == (e3 = this.repositoryContainer.artistsRepository) ? void 0 : e3.put(a2),
                null == (r3 = this.repositoryContainer.artistsTracksRepository) ? void 0 : r3.put(i2)
              ]);
            })
          );
        }
        async putTrackAlbums(t10) {
          return t10.albums ? Promise.all(
            t10.albums.map(async (e2) => {
              var r2, a2, i2, n2;
              let { artists: s2, trackPosition: o2, ...c2 } = e2, l2 = String(c2.id), u2 = String(t10.id), h2 = [
                null == (r2 = this.repositoryContainer.albumsRepository) ? void 0 : r2.put(c2),
                null == (a2 = this.repositoryContainer.albumsTracksRepository) ? void 0 : a2.put({
                  trackId: u2,
                  albumId: l2,
                  volume: null != (i2 = null == o2 ? void 0 : o2.volume) ? i2 : NaN,
                  position: null != (n2 = null == o2 ? void 0 : o2.index) ? n2 : NaN
                })
              ];
              if (s2 && s2.length > 0) {
                let t11 = s2.map(async (t12, e3) => {
                  var r3;
                  return null == (r3 = this.repositoryContainer.albumsArtistsRepository) ? void 0 : r3.put({ albumId: l2, artistId: String(t12.id), artistIndex: e3 });
                });
                h2.push(...t11.filter((t12) => !!t12));
              }
              return Promise.all(h2);
            })
          ) : Promise.resolve();
        }
        async getTrackArtists(t10) {
          var e2;
          let r2, a2 = await (null == (e2 = this.repositoryContainer.artistsTracksRepository) ? void 0 : e2.getArtistsByTrackId(t10));
          if (!(null == a2 ? void 0 : a2.length)) return [];
          let i2 = await Promise.all(
            a2.map(async (t11) => {
              var e3;
              let { artistId: r3 } = t11;
              return null == (e3 = this.repositoryContainer.artistsRepository) ? void 0 : e3.get(r3);
            })
          ), n2 = [];
          return a2.forEach((t11, e3) => {
            let { decomposed: a3, prefix: s2 } = t11, o2 = i2[e3];
            if (o2) {
              if (!a3 && "object" == typeof o2 && "id" in o2) {
                r2 = o2, n2.push(o2);
                return;
              }
              r2 && (void 0 === r2.decomposed && (r2.decomposed = []), s2 && r2.decomposed.push(s2), r2.decomposed.push(o2));
            }
          }), n2;
        }
        async getTrackAlbums(t10, e2) {
          var r2, a2;
          let i2 = [];
          if (e2) {
            let t11 = await (null == (r2 = this.repositoryContainer.albumsRepository) ? void 0 : r2.get(e2));
            t11 && i2.push({ ...t11, artists: [] });
          } else {
            let e3 = await (null == (a2 = this.repositoryContainer.albumsTracksRepository) ? void 0 : a2.getAlbumsByTrackId(t10));
            if (!(null == e3 ? void 0 : e3.length)) return i2;
            (await Promise.all(
              e3.map(
                async (t11) => this.repositoryContainer.albumsRepository ? this.repositoryContainer.albumsRepository.get(t11) : null
              )
            )).forEach((t11) => {
              t11 && i2.push({ ...t11, artists: [] });
            });
          }
          return i2;
        }
        async deleteTrackArtists(t10) {
          var e2;
          let r2 = await (null == (e2 = this.repositoryContainer.artistsTracksRepository) ? void 0 : e2.getArtistsByTrackId(t10));
          return (null == r2 ? void 0 : r2.length) ? Promise.all(
            r2.map(async (e3) => {
              var r3, a2, i2, n2;
              let { artistId: s2 } = e3;
              return (await (null == (r3 = this.repositoryContainer.artistsTracksRepository) ? void 0 : r3.delete(t10, s2)), 0 === await (null == (a2 = this.repositoryContainer.artistsTracksRepository) ? void 0 : a2.getCountByArtist(s2))) ? Promise.all([
                null == (i2 = this.fileStorage) ? void 0 : i2.deleteFile(D(s2)),
                null == (n2 = this.repositoryContainer.artistsRepository) ? void 0 : n2.delete(s2)
              ]) : Promise.resolve();
            })
          ) : Promise.resolve();
        }
        async deleteTrackAlbums(t10) {
          var e2;
          let r2 = await (null == (e2 = this.repositoryContainer.albumsTracksRepository) ? void 0 : e2.getAlbumsByTrackId(t10));
          return (null == r2 ? void 0 : r2.length) ? Promise.all(
            r2.map(async (e3) => {
              var r3, a2, i2, n2, s2;
              await (null == (r3 = this.repositoryContainer.albumsTracksRepository) ? void 0 : r3.delete(t10, e3));
              let c2 = await (null == (a2 = this.repositoryContainer.albumsTracksRepository) ? void 0 : a2.getCountByAlbum(e3));
              return (this.store.albums.setEntityState(e3, { loadingState: o.IDLE }), this.usersAlbumsManager.delete(e3), 0 === c2) ? Promise.all([
                null == (i2 = this.fileStorage) ? void 0 : i2.deleteFile(to(e3)),
                null == (n2 = this.repositoryContainer.albumsRepository) ? void 0 : n2.delete(e3),
                null == (s2 = this.repositoryContainer.albumsArtistsRepository) ? void 0 : s2.deleteByAlbumId(e3)
              ]) : Promise.resolve();
            })
          ) : Promise.resolve();
        }
        async saveTrack(t10) {
          var e2;
          this.store.tracks.setEntityState(String(t10.id), { loadingState: o.DOWNLOADING });
          let r2 = (0, tg.A)(t10);
          return delete r2.albums, delete r2.artists, Promise.all([
            null == (e2 = this.repositoryContainer.tracksRepository) ? void 0 : e2.put(r2),
            this.putTrackAlbums(t10),
            this.putTrackArtists(t10)
          ]);
        }
        async getTrack(t10) {
          var e2, r2;
          let [a2, i2] = (0, ti.d)(t10);
          if (!a2) return null;
          let n2 = await (null == (e2 = this.repositoryContainer.tracksRepository) ? void 0 : e2.get(a2));
          if (!n2) return null;
          let s2 = n2.meta;
          return s2.coverUri && (s2.coverUri = await (null == (r2 = this.fileStorage) ? void 0 : r2.createFileURL(tE(t10)))), s2.albums = await this.getTrackAlbums(String(s2.id), i2), s2.artists = await this.getTrackArtists(String(s2.id)), s2;
        }
        async getAllIds() {
          var t10;
          return null == (t10 = this.repositoryContainer.tracksRepository) ? void 0 : t10.getAllIds();
        }
        async putDecryptKey(t10, e2) {
          var r2;
          await (null == (r2 = this.repositoryContainer.tracksRepository) ? void 0 : r2.putDecryptKey(t10, e2));
        }
        async putTrackAvailable(t10, e2) {
          var r2;
          await (null == (r2 = this.repositoryContainer.tracksRepository) ? void 0 : r2.putTrackAvailable(t10, e2));
        }
        async deleteTrack(t10) {
          var e2, r2, a2;
          let [i2] = (0, ti.d)(t10);
          if (i2) {
            if (this.changeState(i2, { loadingState: o.REMOVING }), await this.usersTracksManager.delete(i2), 0 !== await this.usersTracksManager.getCountByTrackId(i2))
              return void this.changeState(i2, { loadingState: o.DOWNLOADED });
            await Promise.all([
              null == (e2 = this.fileStorage) ? void 0 : e2.deleteFile(tb(i2)),
              null == (r2 = this.fileStorage) ? void 0 : r2.deleteFile(tE(t10)),
              null == (a2 = this.repositoryContainer.tracksRepository) ? void 0 : a2.delete(i2),
              this.deleteTrackAlbums(i2),
              this.deleteTrackArtists(i2)
            ]), this.changeState(i2, { loadingState: o.IDLE });
          }
        }
        download(t10, e2) {
          var r2;
          let [a2] = (0, ti.d)(t10);
          if (!a2) return;
          let i2 = null == (r2 = this.store.tracks.state[a2]) ? void 0 : r2.loadingState;
          (!this.store.tracks.state[a2] || i2 && tf.includes(i2)) && this.downloader.injectTask(new tw(String(t10), this.trackDownloadTaskParams, this.downloader.quality, e2));
        }
        stopDownload(t10) {
          var e2;
          let [r2] = (0, ti.d)(t10);
          if (!r2) return;
          let a2 = null == (e2 = this.store.tracks.state[r2]) ? void 0 : e2.loadingState;
          (!this.store.tracks.state[r2] || a2 && tT.includes(a2)) && (this.changeState(r2, { loadingState: o.IDLE }), this.downloader.removeTask(String(t10)));
        }
        onTrackDownloadFinished(t10, e2) {
          let [r2, a2] = (0, ti.d)(t10);
          r2 && (this.usersTracksManager.put({ uid: this.userConfig.uid, downloadSource: e2, trackId: r2, albumId: a2 }), this.changeState(r2, { loadingState: o.DOWNLOADED }));
        }
        onTrackDownloadStopped(t10) {
          let [e2] = (0, ti.d)(t10);
          e2 && (this.deleteTrack(t10), this.changeState(e2, { loadingState: o.IDLE }));
        }
        onTrackDownloadFailed(t10) {
          let [e2] = (0, ti.d)(t10);
          e2 && (this.deleteTrack(t10), this.changeState(e2, { loadingState: o.DOWNLOAD_FAILED }));
        }
        onTrackImageReceived(t10, e2) {
          var r2;
          let a2 = tE(t10);
          null == (r2 = this.fileStorage) || r2.writeFile(a2, e2).catch(() => {
            this.hooks.afterError.promise(Error("Error in tracks manager")), this.stopDownload(t10), this.onTrackDownloadFailed(t10);
          });
        }
        onChunkMediaFileReceived(t10, e2) {
          var r2;
          let [a2] = (0, ti.d)(t10);
          a2 && (null == (r2 = this.store.tracks.state[a2]) ? void 0 : r2.loadingState) !== o.IDLE && this.changeState(a2, { loadingState: o.DOWNLOADING, progress: e2 });
        }
        onMediaFileReceived(t10, e2) {
          var r2, a2;
          let [i2] = (0, ti.d)(t10);
          if (!i2 || (null == (r2 = this.store.tracks.state[i2]) ? void 0 : r2.loadingState) === o.IDLE) return;
          let n2 = tb(i2);
          null == (a2 = this.fileStorage) || a2.writeFile(n2, e2).catch(() => {
            this.hooks.afterError.promise(Error("Error in tracks manager")), this.stopDownload(t10), this.onTrackDownloadFailed(t10);
          });
        }
        changeState(t10, e2) {
          this.store.tracks.setEntityState(t10, e2);
        }
        constructor(t10) {
          (0, u._)(this, "userConfig", void 0), (0, u._)(this, "store", void 0), (0, u._)(this, "hooks", void 0), (0, u._)(this, "downloader", void 0), (0, u._)(this, "repositoryContainer", void 0), (0, u._)(this, "fileStorage", void 0), (0, u._)(this, "usersTracksManager", void 0), (0, u._)(this, "usersAlbumsManager", void 0), (0, u._)(this, "trackDownloadTaskParams", void 0), this.userConfig = t10.container.get(h), this.downloader = t10.container.get(I), this.repositoryContainer = t10.container.get(v), this.fileStorage = t10.container.get(m), this.store = t10.container.get(g), this.hooks = t10.container.get(A), this.trackDownloadTaskParams = t10.container.get(_), this.usersTracksManager = t10.container.get(w), this.usersAlbumsManager = t10.container.get(f), this.initDownloaderEvents();
        }
      }
      var tC = r(38549);
      class tS extends R.t {
        constructor(t10, { code: e2 = "E_TRACKS_CONTROLLER", ...r2 } = {}) {
          super("".concat("[TracksController]", " ").concat(t10), { code: e2, ...r2 }), (0, u._)(this, "name", "TracksControllerException"), Object.setPrototypeOf(this, tS.prototype);
        }
      }
      class tI {
        async initState() {
          try {
            let t10 = await this.usersTracksManager.getTracksByUid();
            (null == t10 ? void 0 : t10.length) && (this.store.tracks.state = t10.reduce((t11, e2) => {
              let [r2] = (0, ti.d)(e2);
              return r2 && (t11[r2] = { loadingState: o.DOWNLOADED }), t11;
            }, {}));
          } catch (t10) {
            this.hooks.afterError.promise(new tS("Failed to init tracks state", { cause: t10 }));
          }
        }
        async clearAll() {
          try {
            let t10 = await this.usersTracksManager.getTracksByUid();
            null == t10 || t10.forEach((t11) => {
              this.deleteTrack(t11);
            }), this.store.tracks.clear();
          } catch (t10) {
            this.hooks.afterError.promise(new tS("Failed to clear all tracks", { cause: t10 }));
          }
        }
        async validateTracks() {
          try {
            let t10 = await this.trackManager.getAllIds();
            t10 && t10.forEach(async (t11) => {
              let e2 = String(t11), r2 = await this.usersTracksManager.getCountByTrackId(e2);
              0 === r2 && this.deleteTrack(e2);
            });
          } catch (t10) {
            this.hooks.afterError.promise(new tS("Failed to validate tracks", { cause: t10 }));
          }
        }
        download(t10) {
          this.trackManager.download(t10);
        }
        stopDownload(t10) {
          this.trackManager.stopDownload(t10);
        }
        async getTracks(t10) {
          let e2 = t10;
          return (t10 || (e2 = await this.usersTracksManager.getTracksByUid()), e2) ? (await Promise.all(null == e2 ? void 0 : e2.map(async (t11) => this.getTrack(t11)))).filter((t11) => null !== t11) : [];
        }
        async getTracksCount() {
          let t10 = await this.usersTracksManager.getCountByUid();
          return null != t10 ? t10 : 0;
        }
        async getTrack(t10) {
          try {
            return await this.trackManager.getTrack(t10);
          } catch (e2) {
            return this.hooks.afterError.promise(new tS("Failed to get track", { cause: e2, data: { id: t10 } })), null;
          }
        }
        async deleteTrack(t10) {
          try {
            await this.trackManager.deleteTrack(t10);
          } catch (e2) {
            this.hooks.afterError.promise(new tS("Failed to delete track", { cause: e2, data: { id: t10 } }));
          }
        }
        async refreshTracksAvailability() {
          try {
            let t10 = await this.usersTracksManager.getTracksByUid();
            if (!t10) return;
            let e2 = async (t11) => {
              (await this.availabilityResource.getAvailabilityTracks({ trackIds: t11 })).availabilities.forEach((t12) => {
                let { trackId: e3, available: r3 } = t12, [a2] = (0, ti.d)(e3);
                a2 && this.trackManager.putTrackAvailable(a2, r3);
              });
            }, r2 = (0, tC.A)(t10, this.variables.requestTrackChunkSize);
            Promise.all(r2.map(e2));
          } catch (t10) {
            this.hooks.afterError.promise(new tS("Failed to refresh tracks availability", { cause: t10 }));
          }
        }
        async refreshTracksMeta() {
          try {
            let t10 = await this.usersTracksManager.getTracksByUid();
            if (!t10) return;
            let e2 = async (t11) => {
              (await this.tracksResource.getTracksMeta({ trackIds: t11 })).forEach(this.updateTrackMeta.bind(this));
            }, r2 = (0, tC.A)(t10, this.variables.requestTrackChunkSize);
            Promise.all(r2.map(e2));
          } catch (t10) {
            this.hooks.afterError.promise(new tS("Failed to refresh tracks meta", { cause: t10 }));
          }
        }
        async updateTrackMeta(t10) {
          try {
            var e2, r2;
            let a2 = await this.usersTracksManager.get(String(t10.id));
            if (!a2) return;
            let i2 = null == (r2 = t10.albums) || null == (e2 = r2[0]) ? void 0 : e2.id;
            if (void 0 === a2.albumId && void 0 === i2 || a2.albumId === String(i2)) {
              await this.trackManager.deleteTrackArtists(String(t10.id)), this.trackManager.saveTrack(t10);
              return;
            }
            await this.deleteTrack(String((0, ti.V)(a2.trackId, a2.albumId))), this.download(String((0, ti.V)(t10.id, i2)));
          } catch (e3) {
            this.hooks.afterError.promise(new tS("Failed to update track meta", { cause: e3, data: { id: t10.id } }));
          }
        }
        constructor(t10) {
          (0, u._)(this, "userConfig", void 0), (0, u._)(this, "hooks", void 0), (0, u._)(this, "store", void 0), (0, u._)(this, "tracksResource", void 0), (0, u._)(this, "availabilityResource", void 0), (0, u._)(this, "trackManager", void 0), (0, u._)(this, "usersTracksManager", void 0), (0, u._)(this, "variables", void 0);
          let { availabilityResource: e2, tracksResource: r2 } = t10.container.get(y);
          this.userConfig = t10.container.get(h), this.hooks = t10.container.get(A), this.store = t10.container.get(g), this.availabilityResource = e2, this.tracksResource = r2, this.variables = t10.variables, this.trackManager = t10.container.get(p), this.usersTracksManager = t10.container.get(w), this.validateTracks();
        }
      }
      class tA {
        async getAlbumsByUid() {
          var t10;
          return null == (t10 = this.repositoryContainer.usersAlbumsRepository) ? void 0 : t10.getAlbumsByUid(this.userConfig.uid);
        }
        async getCountByUid() {
          var t10;
          return null == (t10 = this.repositoryContainer.usersAlbumsRepository) ? void 0 : t10.getCountByUid(this.userConfig.uid);
        }
        async getCountByAlbumId(t10) {
          var e2;
          return null == (e2 = this.repositoryContainer.usersAlbumsRepository) ? void 0 : e2.getCountByAlbumId(t10);
        }
        async get(t10) {
          var e2;
          return null == (e2 = this.repositoryContainer.usersAlbumsRepository) ? void 0 : e2.get(this.userConfig.uid, t10);
        }
        async put(t10) {
          var e2;
          await (null == (e2 = this.repositoryContainer.usersAlbumsRepository) ? void 0 : e2.put({ uid: this.userConfig.uid, albumId: t10 }));
        }
        async delete(t10) {
          var e2;
          await (null == (e2 = this.repositoryContainer.usersAlbumsRepository) ? void 0 : e2.delete(this.userConfig.uid, t10));
        }
        constructor(t10) {
          (0, u._)(this, "userConfig", void 0), (0, u._)(this, "repositoryContainer", void 0), this.userConfig = t10.container.get(h), this.repositoryContainer = t10.container.get(v);
        }
      }
      class t_ {
        async getTracksByUid() {
          var t10;
          return null == (t10 = this.repositoryContainer.usersTracksRepository) ? void 0 : t10.getTracksByUid(this.userConfig.uid);
        }
        async getCountByUid() {
          var t10;
          return null == (t10 = this.repositoryContainer.usersTracksRepository) ? void 0 : t10.getCountByUid(this.userConfig.uid);
        }
        async getCountByTrackId(t10) {
          var e2;
          return null == (e2 = this.repositoryContainer.usersTracksRepository) ? void 0 : e2.getCountByTrackId(t10);
        }
        async get(t10) {
          var e2;
          return null == (e2 = this.repositoryContainer.usersTracksRepository) ? void 0 : e2.get(this.userConfig.uid, t10);
        }
        async put(t10) {
          var e2;
          await (null == (e2 = this.repositoryContainer.usersTracksRepository) ? void 0 : e2.put(t10));
        }
        async delete(t10) {
          var e2;
          await (null == (e2 = this.repositoryContainer.usersTracksRepository) ? void 0 : e2.delete(this.userConfig.uid, t10));
        }
        constructor(t10) {
          (0, u._)(this, "userConfig", void 0), (0, u._)(this, "repositoryContainer", void 0), this.userConfig = t10.container.get(h), this.repositoryContainer = t10.container.get(v);
        }
      }
      let tR = () => "undefined" == typeof navigator ? { isOffline: false } : { isOffline: !navigator.onLine };
      class tO {
        updateStatus(t10) {
          this.status = tR(), t10(this.status);
        }
        subscribe(t10) {
          this.updateStatus(t10), window.addEventListener("online", this.updateStatus.bind(this, t10)), window.addEventListener("offline", this.updateStatus.bind(this, t10));
        }
        unsubscribe(t10) {
          window.removeEventListener("online", this.updateStatus.bind(this, t10)), window.removeEventListener("offline", this.updateStatus.bind(this, t10));
        }
        constructor() {
          (0, u._)(this, "status", tR());
        }
      }
      class tD extends R.t {
        constructor(t10, { code: e2 = "E_FILE_STORAGE", ...r2 } = {}) {
          super("".concat("[FileStorage]", " ").concat(t10), { code: e2, ...r2 }), (0, u._)(this, "name", "FileStorageException"), Object.setPrototypeOf(this, tD.prototype);
        }
      }
      class tx {
        async getRootDir() {
          try {
            let t10 = await this.rootDir;
            if (!this.isAvailable || !t10) throw this.generateError("FileStorage is not available");
            return t10;
          } catch (t10) {
            throw this.generateError("FileStorage is not available", t10);
          }
        }
        parsePath(t10) {
          let e2 = t10.split("/"), r2 = e2.pop();
          if (!r2) throw this.generateError("Invalid file path");
          return { name: r2, dir: e2.join("/") };
        }
        async getDirectoryRecursive(t10, e2, r2) {
          let a2 = e2.shift();
          if (!a2) return t10;
          let i2 = await t10.getDirectoryHandle(a2, r2);
          return this.getDirectoryRecursive(i2, e2, r2);
        }
        async getDirectory(t10, e2) {
          let r2 = t10.split("/"), a2 = await this.getRootDir();
          return this.getDirectoryRecursive(a2, r2, e2);
        }
        async getFile(t10, e2) {
          let { name: r2, dir: a2 } = this.parsePath(t10);
          return (await this.getDirectory(a2, e2)).getFileHandle(r2, e2);
        }
        async isFileExisting(t10) {
          try {
            return await this.getFile(t10), true;
          } catch (t11) {
            return false;
          }
        }
        async writeFile(t10, e2) {
          try {
            let r2 = await this.getFile(t10, { create: true }), a2 = await r2.createWritable();
            await a2.write(e2), await a2.close();
          } catch (e3) {
            throw this.generateError("Error when trying to write file", e3, { path: t10 });
          }
        }
        async readFile(t10) {
          try {
            let e2 = await this.getFile(t10);
            return await e2.getFile();
          } catch (e2) {
            throw this.generateError("Error when trying to read file", e2, { path: t10 });
          }
        }
        async deleteFile(t10, e2) {
          try {
            if (!await this.isFileExisting(t10)) return;
            let { name: r2, dir: a2 } = this.parsePath(t10), i2 = await this.getDirectory(a2);
            return await i2.removeEntry(r2, e2);
          } catch (e3) {
            throw this.generateError("Error when trying to delete file", e3, { path: t10 });
          }
        }
        async createFileURL(t10) {
          try {
            let e2 = await this.getFile(t10), r2 = await e2.getFile();
            return URL.createObjectURL(r2);
          } catch (e2) {
            throw this.generateError("Error when trying to create file URL", e2, { path: t10 });
          }
        }
        async getEstimate() {
          var t10, e2;
          return (null == (e2 = window.navigator) || null == (t10 = e2.storage) ? void 0 : t10.estimate) ? window.navigator.storage.estimate().catch(() => ({})) : {};
        }
        generateError(t10, e2, r2) {
          return new tD(t10, {
            cause: e2 instanceof Error ? e2.message : String(e2),
            data: { errorMeta: { estimate: this.estimate }, ...r2 }
          });
        }
        constructor() {
          (0, u._)(this, "rootDir", void 0), (0, u._)(this, "isAvailable", true), (0, u._)(this, "estimate", {}), this.rootDir = window.navigator.storage.getDirectory(), this.getEstimate().then((t10) => {
            this.estimate = t10;
          });
        }
      }
      !(function(t10) {
        t10.WRITE = "WRITE", t10.READ = "READ", t10.DELETE = "DELETE", t10.CREATE_URL = "CREATE_URL", t10.IS_EXISTING = "IS_EXISTING";
      })(l || (l = {}));
      class tN {
        async executeWithLock(t10, e2) {
          let r2 = this.operationsInProgress.get(t10);
          if (r2) return r2;
          let a2 = e2();
          return this.operationsInProgress.set(t10, a2), a2.finally(() => {
            this.operationsInProgress.delete(t10);
          });
        }
        getOperationKey(t10) {
          for (var e2 = arguments.length, r2 = Array(e2 > 1 ? e2 - 1 : 0), a2 = 1; a2 < e2; a2++) r2[a2 - 1] = arguments[a2];
          return [t10, ...r2].join("-");
        }
        async writeFile() {
          for (var t10 = arguments.length, e2 = Array(t10), r2 = 0; r2 < t10; r2++) e2[r2] = arguments[r2];
          return this.executeWithLock(this.getOperationKey(l.WRITE, ...e2), async () => this.storage.writeFile(...e2));
        }
        async readFile() {
          for (var t10 = arguments.length, e2 = Array(t10), r2 = 0; r2 < t10; r2++) e2[r2] = arguments[r2];
          return this.executeWithLock(this.getOperationKey(l.READ, ...e2), async () => this.storage.readFile(...e2));
        }
        async deleteFile() {
          for (var t10 = arguments.length, e2 = Array(t10), r2 = 0; r2 < t10; r2++) e2[r2] = arguments[r2];
          return this.executeWithLock(this.getOperationKey(l.DELETE, ...e2), async () => this.storage.deleteFile(...e2));
        }
        async createFileURL() {
          for (var t10 = arguments.length, e2 = Array(t10), r2 = 0; r2 < t10; r2++) e2[r2] = arguments[r2];
          return this.executeWithLock(
            this.getOperationKey(l.CREATE_URL, ...e2),
            async () => this.storage.createFileURL(...e2)
          );
        }
        async isFileExisting() {
          for (var t10 = arguments.length, e2 = Array(t10), r2 = 0; r2 < t10; r2++) e2[r2] = arguments[r2];
          return this.executeWithLock(
            this.getOperationKey(l.IS_EXISTING, ...e2),
            async () => this.storage.isFileExisting(...e2)
          );
        }
        get activeOperationsCount() {
          return this.operationsInProgress.size;
        }
        get activeOperationsPaths() {
          return Array.from(this.operationsInProgress.keys());
        }
        constructor(t10 = new tx()) {
          (0, u._)(this, "storage", void 0), (0, u._)(this, "operationsInProgress", /* @__PURE__ */ new Map()), this.storage = t10;
        }
      }
      class tL extends R.t {
        constructor(t10, { code: e2 = "E_IDB_REPOSITORY", ...r2 } = {}) {
          super("".concat("[IndexedDB]", " ").concat(t10), { code: e2, ...r2 }), (0, u._)(this, "name", "IdbRepositoryException"), Object.setPrototypeOf(this, tL.prototype);
        }
      }
      class tP {
        async clearAll() {
          return this.executeTransaction(async (t10) => t10.clear(this.config.name));
        }
        async executeTransaction(t10) {
          let e2 = await this.idb;
          if (!this.isIdbAvailable || !e2) throw this.generateError("IdbRepository is not available");
          return t10(e2);
        }
        async count() {
          return this.executeTransaction(async (t10) => t10.count(this.config.name));
        }
        async openIdb() {
          return new M.h("".concat("music_slam", "_").concat(this.config.name)).openDB(this.config.version, {
            onBlocked: (t10, e2, r2) => {
              var a2, i2;
              this.onError(), null == (i2 = this.handlers) || null == (a2 = i2.onBlocked) || a2.call(i2, t10, e2, r2);
            },
            onBlocking: (t10, e2, r2) => {
              var a2, i2;
              this.onError(), null == (i2 = this.handlers) || null == (a2 = i2.onBlocking) || a2.call(i2, t10, e2, r2);
            },
            onTerminated: () => {
              var t10, e2;
              this.onError(), null == (e2 = this.handlers) || null == (t10 = e2.onTerminated) || t10.call(e2);
            },
            onUpgrade: (t10, e2, r2, a2, i2) => {
              var n2, s2;
              null == (s2 = this.handlers) || null == (n2 = s2.onUpgrade) || n2.call(s2, t10, e2, r2, a2, i2);
            }
          });
        }
        onError() {
          this.closeConnection().finally(() => {
            this.attemptsConnection < this.config.restrictions.attemptsCount ? (this.attemptsConnection++, this.idb = this.openIdb()) : this.isIdbAvailable = false;
          });
        }
        async closeConnection() {
          let t10 = await this.idb;
          t10 && t10.close();
        }
        async getEstimate() {
          var t10, e2;
          return (null == (e2 = window.navigator) || null == (t10 = e2.storage) ? void 0 : t10.estimate) ? window.navigator.storage.estimate().catch(() => ({})) : {};
        }
        generateError(t10, e2, r2) {
          return new tL(t10, {
            cause: e2 instanceof Error ? e2.message : String(e2),
            data: {
              errorMeta: {
                repository: { name: String(this.config.name), version: this.config.version },
                estimate: this.estimate
              },
              ...r2
            }
          });
        }
        constructor({ config: t10, handlers: e2 }) {
          (0, u._)(this, "idb", void 0), (0, u._)(this, "config", void 0), (0, u._)(this, "handlers", void 0), (0, u._)(this, "attemptsConnection", 0), (0, u._)(this, "isIdbAvailable", true), (0, u._)(this, "estimate", {}), this.config = t10, this.handlers = e2, this.idb = this.openIdb(), this.getEstimate().then((t11) => {
            this.estimate = t11;
          });
        }
      }
      class tM extends tP {
        async put(t10) {
          return this.executeTransaction(async (e2) => {
            var r2;
            let a2 = await e2.get(F.name, String(t10.id)), i2 = Date.now(), n2 = null != (r2 = null == a2 ? void 0 : a2.createdAt) ? r2 : i2;
            return e2.put(F.name, { meta: t10, updatedAt: i2, createdAt: n2 }, String(t10.id));
          }).catch((e2) => {
            throw this.generateError("Error when trying to put data", e2, { albumId: t10.id });
          });
        }
        async get(t10) {
          return this.executeTransaction(async (e2) => {
            var r2;
            let a2 = await e2.get(F.name, t10);
            return null != (r2 = null == a2 ? void 0 : a2.meta) ? r2 : null;
          }).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { albumId: t10 });
          });
        }
        async delete(t10) {
          return this.executeTransaction(async (e2) => e2.delete(F.name, t10)).catch((e2) => {
            throw this.generateError("Error when trying to delete data", e2, { albumId: t10 });
          });
        }
        constructor() {
          super({
            config: F,
            handlers: {
              onUpgrade: (t10) => {
                t10.createObjectStore(F.name);
              }
            }
          });
        }
      }
      let tF = "albumId", tK = "artistId", tj = (t10, e2) => "".concat(t10, ":").concat(e2);
      class tU extends tP {
        async put(t10) {
          let { albumId: e2, artistId: r2, artistIndex: a2 } = t10;
          return this.executeTransaction(async (t11) => {
            var i2;
            let n2 = await t11.get(K.name, tj(e2, r2)), s2 = Date.now(), o2 = null != (i2 = null == n2 ? void 0 : n2.createdAt) ? i2 : s2;
            return t11.put(K.name, { albumId: e2, artistId: r2, artistIndex: a2, updatedAt: s2, createdAt: o2 }, tj(e2, r2));
          }).catch((t11) => {
            throw this.generateError("Error when trying to put data", t11, { albumId: e2, artistId: r2 });
          });
        }
        async get(t10, e2) {
          return this.executeTransaction(async (r2) => {
            let a2 = await r2.get(K.name, tj(t10, e2));
            return null != a2 ? a2 : null;
          }).catch((r2) => {
            throw this.generateError("Error when trying to get data", r2, { albumId: t10, artistId: e2 });
          });
        }
        async getArtistsByAlbumId(t10) {
          return this.executeTransaction(
            async (e2) => (await e2.getAllFromIndex(K.name, tF, t10)).sort((t11, e3) => t11.artistIndex - e3.artistIndex)
          ).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { albumId: t10 });
          });
        }
        async getAlbumsByArtistId(t10) {
          return this.executeTransaction(
            async (e2) => (await e2.getAllFromIndex(K.name, tK, t10)).sort((t11, e3) => t11.artistIndex - e3.artistIndex)
          ).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { artistId: t10 });
          });
        }
        async delete(t10, e2) {
          return this.executeTransaction(async (r2) => r2.delete(K.name, tj(t10, e2))).catch((r2) => {
            throw this.generateError("Error when trying to delete data", r2, { albumId: t10, artistId: e2 });
          });
        }
        async deleteByAlbumId(t10) {
          return this.executeTransaction(async (e2) => {
            let r2 = (await e2.getAllFromIndex(K.name, tF, t10)).map(
              async (t11) => e2.delete(K.name, tj(t11.albumId, t11.artistId))
            );
            await Promise.all(r2);
          }).catch((e2) => {
            throw this.generateError("Error when trying to delete data by albumId", e2, { albumId: t10 });
          });
        }
        async getCountByAlbum(t10) {
          return this.executeTransaction(async (e2) => e2.countFromIndex(K.name, tF, t10)).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { albumId: t10 });
          });
        }
        async getCountByArtist(t10) {
          return this.executeTransaction(async (e2) => e2.countFromIndex(K.name, tK, t10)).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { artistId: t10 });
          });
        }
        constructor() {
          super({
            config: K,
            handlers: {
              onUpgrade: (t10) => {
                let e2 = t10.createObjectStore(K.name);
                e2.createIndex(tF, "albumId"), e2.createIndex(tK, "artistId");
              }
            }
          });
        }
      }
      let tB = "albumId", tG = "trackId", tW = (t10, e2) => "".concat(t10, ":").concat(e2);
      class tH extends tP {
        async put(t10) {
          let { trackId: e2, albumId: r2, volume: a2, position: i2 } = t10;
          return this.executeTransaction(
            async (t11) => t11.put(j.name, { trackId: e2, albumId: r2, volume: a2, position: i2 }, tW(e2, r2))
          ).catch((t11) => {
            throw this.generateError("Error when trying to put data", t11, { trackId: e2, albumId: r2 });
          });
        }
        async get(t10, e2) {
          return this.executeTransaction(async (r2) => {
            let a2 = await r2.get(j.name, tW(t10, e2));
            return null != a2 ? a2 : null;
          }).catch((r2) => {
            throw this.generateError("Error when trying to get data", r2, { trackId: t10, albumId: e2 });
          });
        }
        async getTracksByAlbumId(t10) {
          return this.executeTransaction(
            async (e2) => (await e2.getAllFromIndex(j.name, tB, t10)).map((t11) => t11.trackId)
          ).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { albumId: t10 });
          });
        }
        async getAlbumsByTrackId(t10) {
          return this.executeTransaction(
            async (e2) => (await e2.getAllFromIndex(j.name, tG, t10)).map((t11) => t11.albumId)
          ).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { trackId: t10 });
          });
        }
        async delete(t10, e2) {
          return this.executeTransaction(async (r2) => r2.delete(j.name, tW(t10, e2))).catch((r2) => {
            throw this.generateError("Error when trying to delete data", r2, { trackId: t10, albumId: e2 });
          });
        }
        async getCountByAlbum(t10) {
          return this.executeTransaction(async (e2) => e2.countFromIndex(j.name, tB, t10)).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { albumId: t10 });
          });
        }
        constructor() {
          super({
            config: j,
            handlers: {
              onUpgrade: (t10) => {
                let e2 = t10.createObjectStore(j.name);
                e2.createIndex(tB, "albumId"), e2.createIndex(tG, "trackId");
              }
            }
          });
        }
      }
      class tq extends tP {
        async put(t10) {
          return this.executeTransaction(async (e2) => {
            var r2;
            let a2 = await e2.get(U.name, String(t10.id)), i2 = Date.now(), n2 = null != (r2 = null == a2 ? void 0 : a2.createdAt) ? r2 : i2;
            return e2.put(U.name, { meta: t10, updatedAt: i2, createdAt: n2 }, String(t10.id));
          }).catch((e2) => {
            throw this.generateError("Error when trying to put data", e2, { artistId: t10.id });
          });
        }
        async get(t10) {
          return this.executeTransaction(async (e2) => {
            var r2;
            let a2 = await e2.get(U.name, t10);
            return null != (r2 = null == a2 ? void 0 : a2.meta) ? r2 : null;
          }).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { artistId: t10 });
          });
        }
        async delete(t10) {
          return this.executeTransaction(async (e2) => e2.delete(U.name, t10)).catch((e2) => {
            throw this.generateError("Error when trying to delete data", e2, { artistId: t10 });
          });
        }
        constructor() {
          super({
            config: U,
            handlers: {
              onUpgrade: (t10) => {
                t10.createObjectStore(U.name);
              }
            }
          });
        }
      }
      let tV = "artistId", tY = "trackId", tz = (t10, e2) => "".concat(t10, ":").concat(e2);
      class tX extends tP {
        async put(t10) {
          let { trackId: e2, artistId: r2 } = t10;
          return this.executeTransaction(async (a2) => a2.put(B.name, t10, tz(e2, r2))).catch((t11) => {
            throw this.generateError("Error when trying to put data", t11, { artistId: r2, trackId: e2 });
          });
        }
        async get(t10, e2) {
          return this.executeTransaction(async (r2) => {
            let a2 = await r2.get(B.name, tz(t10, e2));
            return null != a2 ? a2 : null;
          }).catch((r2) => {
            throw this.generateError("Error when trying to get data", r2, { trackId: t10, artistId: e2 });
          });
        }
        async getArtistsByTrackId(t10) {
          return this.executeTransaction(
            async (e2) => (await e2.getAllFromIndex(B.name, tY, t10)).sort((t11, e3) => t11.artistIndex - e3.artistIndex)
          ).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { trackId: t10 });
          });
        }
        async getTracksByArtistId(t10) {
          return this.executeTransaction(
            async (e2) => (await e2.getAllFromIndex(B.name, tV, t10)).sort((t11, e3) => t11.artistIndex - e3.artistIndex)
          ).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { artistId: t10 });
          });
        }
        async delete(t10, e2) {
          return this.executeTransaction(async (r2) => r2.delete(B.name, tz(t10, e2))).catch((r2) => {
            throw this.generateError("Error when trying to delete data", r2, { artistId: e2, trackId: t10 });
          });
        }
        async getCountByArtist(t10) {
          return this.executeTransaction(async (e2) => e2.countFromIndex(B.name, tV, t10)).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { artistId: t10 });
          });
        }
        constructor() {
          super({
            config: B,
            handlers: {
              onUpgrade: (t10) => {
                let e2 = t10.createObjectStore(B.name);
                e2.createIndex(tY, "trackId"), e2.createIndex(tV, "artistId");
              }
            }
          });
        }
      }
      let tQ = "priority_updatedAt", tJ = (t10, e2) => "".concat(t10, ":").concat(e2);
      class tZ extends tP {
        async put(t10) {
          let { uid: e2, requestId: r2 } = t10;
          return this.executeTransaction(async (a2) => {
            var i2;
            let n2 = await this.get(e2, r2), s2 = Date.now(), o2 = null != (i2 = null == n2 ? void 0 : n2.createdAt) ? i2 : s2, c2 = { ...t10, updatedAt: s2, createdAt: o2 }, l2 = await a2.count(G.name);
            return n2 || l2 < Number(G.restrictions.count) || await this.deleteResponseByLowPriority(), a2.put(G.name, c2, tJ(e2, r2));
          }).catch((t11) => {
            throw this.generateError("Error when trying to put data", t11, { uid: e2, requestId: r2 });
          });
        }
        async get(t10, e2, r2) {
          let a2 = await this.getResponse(t10, e2);
          return a2 && r2 && Date.now() - a2.updatedAt > r2 ? (await this.delete(t10, e2), null) : null != a2 ? a2 : null;
        }
        async getResponse(t10, e2) {
          return this.executeTransaction(async (r2) => {
            let a2 = tJ(t10, e2), i2 = await r2.get(G.name, a2);
            return null != i2 ? i2 : null;
          }).catch((r2) => {
            throw this.generateError("Error when trying to get data", r2, { uid: t10, requestId: e2 });
          });
        }
        async delete(t10, e2) {
          return this.executeTransaction(async (r2) => r2.delete(G.name, tJ(t10, e2))).catch((r2) => {
            throw this.generateError("Error when trying to delete data", r2, { uid: t10, requestId: e2 });
          });
        }
        async deleteResponseByLowPriority() {
          return this.executeTransaction(async (t10) => {
            let e2 = t10.transaction([G.name], "readwrite").objectStore(G.name).index(tQ), r2 = await e2.openCursor();
            return null == r2 ? void 0 : r2.delete();
          }).catch((t10) => {
            throw this.generateError("Error when trying to delete data", t10);
          });
        }
        constructor() {
          super({
            config: G,
            handlers: {
              onUpgrade: (t10) => {
                t10.createObjectStore(G.name).createIndex(tQ, ["priority", "updatedAt"]);
              }
            }
          });
        }
      }
      class t$ extends tP {
        async put(t10) {
          return this.executeTransaction(async (e2) => {
            var r2;
            let a2 = await e2.get(W.name, t10.id), i2 = Date.now(), n2 = null != (r2 = null == a2 ? void 0 : a2.createdAt) ? r2 : i2;
            return e2.put(W.name, { ...a2, meta: t10, updatedAt: i2, createdAt: n2 }, t10.id);
          }).catch((e2) => {
            throw this.generateError("Error when trying to put data", e2, { trackId: t10.id });
          });
        }
        async get(t10) {
          return this.executeTransaction(async (e2) => {
            let r2 = await e2.get(W.name, t10);
            return null != r2 ? r2 : null;
          }).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { trackId: t10 });
          });
        }
        async getAllIds() {
          return this.executeTransaction(async (t10) => t10.getAllKeys(W.name)).catch((t10) => {
            throw this.generateError("Error when trying to get data", t10);
          });
        }
        async putDecryptKey(t10, e2) {
          return this.executeTransaction(async (r2) => {
            var a2;
            let i2 = await r2.get(W.name, t10);
            if (!i2) throw new tL("Track not found");
            let n2 = Date.now(), s2 = null != (a2 = null == i2 ? void 0 : i2.createdAt) ? a2 : n2;
            return r2.put(W.name, { meta: i2.meta, decryptKey: e2, updatedAt: n2, createdAt: s2 }, t10);
          }).catch((e3) => {
            throw this.generateError("Error when trying to put data", e3, { trackId: t10 });
          });
        }
        async putTrackAvailable(t10, e2) {
          return this.executeTransaction(async (r2) => {
            var a2;
            let i2 = await r2.get(W.name, t10);
            if (!i2) throw new tL("Track not found");
            let n2 = Date.now(), s2 = null != (a2 = null == i2 ? void 0 : i2.createdAt) ? a2 : n2, { meta: o2 } = i2;
            return r2.put(W.name, { ...i2, meta: { ...o2, available: e2 }, updatedAt: n2, createdAt: s2 }, t10);
          }).catch((e3) => {
            throw this.generateError("Error when trying to put data", e3, { trackId: t10 });
          });
        }
        async getDecryptKey(t10) {
          return this.executeTransaction(async (e2) => {
            var r2;
            let a2 = await e2.get(W.name, t10);
            return null != (r2 = null == a2 ? void 0 : a2.decryptKey) ? r2 : null;
          }).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { trackId: t10 });
          });
        }
        async delete(t10) {
          return this.executeTransaction(async (e2) => e2.delete(W.name, t10)).catch((e2) => {
            throw this.generateError("Error when trying to delete data", e2, { trackId: t10 });
          });
        }
        constructor() {
          super({
            config: W,
            handlers: {
              onUpgrade: (t10) => {
                t10.createObjectStore(W.name);
              }
            }
          });
        }
      }
      class t0 extends tP {
        async put(t10) {
          return this.executeTransaction(async (e2) => {
            var r2;
            let a2 = await e2.get(H.name, t10.uid), i2 = Date.now(), n2 = null != (r2 = null == a2 ? void 0 : a2.createdAt) ? r2 : i2;
            return e2.put(H.name, { ...t10, updatedAt: i2, createdAt: n2 }, t10.uid);
          }).catch((e2) => {
            throw this.generateError("Error when trying to put data", e2, { uid: t10.uid });
          });
        }
        async get(t10) {
          return this.executeTransaction(async (e2) => {
            let r2 = await e2.get(H.name, t10);
            return null != r2 ? r2 : null;
          }).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { uid: t10 });
          });
        }
        async delete(t10) {
          return this.executeTransaction(async (e2) => e2.delete(H.name, t10)).catch((e2) => {
            throw this.generateError("Error when trying to delete data", e2, { uid: t10 });
          });
        }
        constructor() {
          super({
            config: H,
            handlers: {
              onUpgrade: (t10) => {
                t10.createObjectStore(H.name);
              }
            }
          });
        }
      }
      let t1 = "albumId", t6 = (t10, e2) => "".concat(t10, ":").concat(e2);
      class t5 extends tP {
        async put(t10) {
          let { uid: e2, albumId: r2 } = t10;
          return this.executeTransaction(async (a2) => {
            var i2;
            let n2 = t6(e2, r2), s2 = await a2.get(q.name, n2), o2 = Date.now(), c2 = null != (i2 = null == s2 ? void 0 : s2.createdAt) ? i2 : o2;
            return a2.put(q.name, { ...t10, updatedAt: o2, createdAt: c2 }, n2);
          }).catch((t11) => {
            throw this.generateError("Error when trying to put data", t11, { uid: e2, albumId: r2 });
          });
        }
        async get(t10, e2) {
          return this.executeTransaction(async (r2) => {
            let a2 = await r2.get(q.name, t6(t10, e2));
            return null != a2 ? a2 : null;
          }).catch((r2) => {
            throw this.generateError("Error when trying to get data", r2, { uid: t10, albumId: e2 });
          });
        }
        async getAlbumsByUid(t10) {
          return this.executeTransaction(
            async (e2) => (await e2.getAllFromIndex(q.name, "uid", t10)).sort((t11, e3) => e3.createdAt - t11.createdAt).map((t11) => {
              let { albumId: e3 } = t11;
              return Number(e3);
            })
          ).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { uid: t10 });
          });
        }
        async delete(t10, e2) {
          return this.executeTransaction(async (r2) => r2.delete(q.name, t6(t10, e2))).catch((r2) => {
            throw this.generateError("Error when trying to delete data", r2, { uid: t10, albumId: e2 });
          });
        }
        async getCountByAlbumId(t10) {
          return this.executeTransaction(async (e2) => e2.countFromIndex(q.name, t1, t10)).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { albumId: t10 });
          });
        }
        async getCountByUid(t10) {
          return this.executeTransaction(async (e2) => e2.countFromIndex(q.name, "uid", t10)).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { uid: t10 });
          });
        }
        constructor() {
          super({
            config: q,
            handlers: {
              onUpgrade: (t10) => {
                let e2 = t10.createObjectStore(q.name);
                e2.createIndex("uid", "uid"), e2.createIndex(t1, "albumId");
              }
            }
          });
        }
      }
      let t2 = "trackId", t9 = (t10, e2) => "".concat(t10, ":").concat(e2);
      class t8 extends tP {
        async put(t10) {
          let { uid: e2, trackId: r2 } = t10;
          return this.executeTransaction(async (a2) => {
            var i2;
            let n2 = t9(e2, r2), s2 = await a2.get(V.name, n2), o2 = Date.now(), c2 = null != (i2 = null == s2 ? void 0 : s2.createdAt) ? i2 : o2;
            return a2.put(V.name, { ...t10, updatedAt: o2, createdAt: c2 }, n2);
          }).catch((t11) => {
            throw this.generateError("Error when trying to put data", t11, { uid: e2, trackId: r2 });
          });
        }
        async get(t10, e2) {
          return this.executeTransaction(async (r2) => {
            let a2 = await r2.get(V.name, t9(t10, e2));
            return null != a2 ? a2 : null;
          }).catch((r2) => {
            throw this.generateError("Error when trying to get data", r2, { uid: t10, trackId: e2 });
          });
        }
        async getTracksByUid(t10) {
          return this.executeTransaction(
            async (e2) => (await e2.getAllFromIndex(V.name, "uid", t10)).sort((t11, e3) => e3.createdAt - t11.createdAt).map((t11) => {
              let { trackId: e3, albumId: r2 } = t11;
              return String((0, ti.V)(e3, r2));
            })
          ).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { uid: t10 });
          });
        }
        async delete(t10, e2) {
          return this.executeTransaction(async (r2) => r2.delete(V.name, t9(t10, e2))).catch((r2) => {
            throw this.generateError("Error when trying to delete data", r2, { uid: t10, trackId: e2 });
          });
        }
        async getCountByTrackId(t10) {
          return this.executeTransaction(async (e2) => e2.countFromIndex(V.name, t2, t10)).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { trackId: t10 });
          });
        }
        async getCountByUid(t10) {
          return this.executeTransaction(async (e2) => e2.countFromIndex(V.name, "uid", t10)).catch((e2) => {
            throw this.generateError("Error when trying to get data", e2, { uid: t10 });
          });
        }
        constructor() {
          super({
            config: V,
            handlers: {
              onUpgrade: (t10) => {
                let e2 = t10.createObjectStore(V.name);
                e2.createIndex("uid", "uid"), e2.createIndex(t2, "trackId");
              }
            }
          });
        }
      }
      class t4 {
        get tracksController() {
          return this.container ? this.container.get(T) : null;
        }
        get albumsController() {
          return this.container ? this.container.get(S) : null;
        }
        get playlistsController() {
          return this.container ? this.container.get(k) : null;
        }
        get artistsController() {
          return this.container ? this.container.get(C) : null;
        }
        get store() {
          return this.container ? this.container.get(g) : null;
        }
        createCacheController(t10) {
          this.cacheController || (this.cacheController = new X(t10));
        }
        init(t10) {
          var e2, r2;
          this.container || (this.container = (function(t11) {
            let {
              repositoryContainer: e3,
              userConfig: r3,
              resources: a2,
              downloaderVariables: i2,
              featureFlags: n2,
              tracksControllerVariables: s2,
              trackDownloadTaskParams: o2
            } = t11;
            return new te.Dt().registerMany({
              [h]: (0, te.Gr)(() => r3),
              [d]: (0, te.Gr)(() => n2),
              [g]: (0, te.Gr)(() => new td()),
              [A]: (0, te.Gr)(() => tu),
              [I]: (0, te.Gr)(() => new Z({ variables: i2 })),
              [y]: (0, te.Gr)(() => a2),
              [v]: (0, te.Gr)(() => e3),
              [m]: (0, te.Gr)(() => e3.fileStorage),
              [p]: (0, te.do)((t12) => new tk({ container: t12 })),
              [w]: (0, te.do)((t12) => new t_({ container: t12 })),
              [E]: (0, te.do)((t12) => new tl({ container: t12 })),
              [b]: (0, te.do)((t12) => new tc({ container: t12 })),
              [f]: (0, te.do)((t12) => new tA({ container: t12 })),
              [T]: (0, te.Gr)((t12) => {
                let { entities: e4 } = t12.get(d);
                return e4 ? new tI({ container: t12, variables: s2 }) : null;
              }),
              [k]: (0, te.Gr)((t12) => {
                let { entities: e4 } = t12.get(d);
                return e4 ? new $({ container: t12 }) : null;
              }),
              [C]: (0, te.Gr)((t12) => {
                let { entities: e4 } = t12.get(d);
                return e4 ? new x({ container: t12 }) : null;
              }),
              [S]: (0, te.Gr)((t12) => {
                let { entities: e4 } = t12.get(d);
                return e4 ? new ta({ container: t12 }) : null;
              }),
              [_]: (0, te.Gr)((t12) => {
                let { tracksResource: e4, getFileInfoResource: r4 } = t12.get(y);
                return {
                  tracksResource: e4,
                  getFileInfoResource: r4,
                  secretKey: o2.secretKey,
                  transport: o2.transport,
                  variables: o2.variables,
                  events: t12.get(I).events,
                  hooks: t12.get(A)
                };
              })
            });
          })({ repositoryContainer: this.repositoryContainer, ...t10 })), null == (r2 = this.repositoryContainer) || null == (e2 = r2.usersRepository) || e2.put({ uid: t10.userConfig.uid });
        }
        async clearAll() {
          var t10;
          return Promise.all([null == (t10 = this.tracksController) ? void 0 : t10.clearAll()]);
        }
        constructor({ config: t10, plugins: e2 }) {
          (0, u._)(this, "hooks", tu), (0, u._)(this, "container", null), (0, u._)(this, "network", new tO()), (0, u._)(this, "repositoryContainer", void 0), (0, u._)(this, "cacheController", null), this.repositoryContainer = ((t11) => {
            let { useFileStorage: e3, useResponseCacheStorage: r2, useEntitiesStorage: a2 } = t11, i2 = {};
            return e3 && (i2.fileStorage = new tN()), r2 && (i2.responseCacheRepository = new tZ()), a2 && (i2.albumsRepository = new tM(), i2.albumsTracksRepository = new tH(), i2.albumsArtistsRepository = new tU(), i2.artistsRepository = new tq(), i2.artistsTracksRepository = new tX(), i2.tracksRepository = new t$(), i2.usersRepository = new t0(), i2.usersTracksRepository = new t8(), i2.usersAlbumsRepository = new t5()), i2;
          })(t10), null == e2 || e2.forEach((t11) => t11.apply({ hooks: this.hooks }));
        }
      }
      var t3 = r(5892);
      class t7 extends t3.Q {
        async about(t10, e2) {
          let r2 = this.cacheController.getRequestId({
            resourceName: t3.Q.constructor.name,
            methodName: this.about.name,
            args: [t10]
          });
          if (this.cacheController.shouldGetCache) return this.cacheController.get(r2, 6048e5);
          try {
            let a2 = await super.about(t10, e2);
            return this.cacheController.put({ requestId: r2, response: a2, uid: a2.uid, priority: n.MEDIUM }), a2;
          } catch (t11) {
            return this.cacheController.handleError(t11, r2, 6048e5);
          }
        }
        async settings(t10, e2) {
          let r2 = this.cacheController.getRequestId({
            resourceName: t3.Q.constructor.name,
            methodName: this.settings.name,
            args: [t10]
          });
          if (this.cacheController.shouldGetCache) return this.cacheController.get(r2, 6048e5);
          try {
            let a2 = await super.settings(t10, e2);
            return this.cacheController.put({ requestId: r2, response: a2, priority: n.MEDIUM }), a2;
          } catch (t11) {
            return this.cacheController.handleError(t11, r2, 6048e5);
          }
        }
        async experiments(t10, e2) {
          let r2 = this.cacheController.getRequestId({
            resourceName: t3.Q.constructor.name,
            methodName: this.experiments.name,
            args: [t10]
          });
          if (this.cacheController.shouldGetCache) return this.cacheController.get(r2, 6048e5);
          try {
            let a2 = await super.experiments(t10, e2);
            return this.cacheController.put({ requestId: r2, response: a2, priority: n.MEDIUM }), a2;
          } catch (t11) {
            return this.cacheController.handleError(t11, r2, 6048e5);
          }
        }
        async experimentsDetails(t10, e2) {
          let r2 = this.cacheController.getRequestId({
            resourceName: t3.Q.constructor.name,
            methodName: this.experimentsDetails.name,
            args: [t10]
          });
          if (this.cacheController.shouldGetCache) return this.cacheController.get(r2, 6048e5);
          try {
            let a2 = await super.experimentsDetails(t10, e2);
            return this.cacheController.put({ requestId: r2, response: a2, priority: n.MEDIUM }), a2;
          } catch (t11) {
            return this.cacheController.handleError(t11, r2, 6048e5);
          }
        }
        constructor(t10, e2, r2) {
          super(t10, e2), (0, u._)(this, "httpClient", void 0), (0, u._)(this, "config", void 0), (0, u._)(this, "cacheController", void 0), this.httpClient = t10, this.config = e2, this.cacheController = r2.cacheController;
        }
      }
      let et = (t10) => {
        let { resource: e2, cacheController: r2, config: a2 } = t10;
        return new Proxy(e2, {
          get(t11, e3) {
            let i2 = t11[e3], {
              enabled: n2,
              ttl: s2,
              priority: o2
            } = ((t12, e4) => {
              var r3, a3, i3, n3;
              let s3 = null == (r3 = t12.overrides) ? void 0 : r3[e4];
              return {
                enabled: null != (a3 = null == s3 ? void 0 : s3.enabled) ? a3 : t12.enabled,
                ttl: null != (i3 = null == s3 ? void 0 : s3.ttl) ? i3 : t12.ttl,
                priority: null != (n3 = null == s3 ? void 0 : s3.priority) ? n3 : t12.priority
              };
            })(a2, e3);
            return "function" == typeof i2 && n2 ? async function() {
              for (var n3 = arguments.length, c2 = Array(n3), l2 = 0; l2 < n3; l2++) c2[l2] = arguments[l2];
              let { resourceName: u2 } = a2.common, h2 = r2.getRequestId({ resourceName: u2, prop: e3, args: c2 });
              if (r2.shouldGetCache) return r2.get(h2, s2);
              try {
                let e4 = await i2.apply(t11, c2);
                return r2.put({ requestId: h2, response: e4, priority: o2 }), e4;
              } catch (t12) {
                return r2.handleError(t12, h2, s2);
              }
            } : i2;
          }
        });
      };
      var ee = r(48448);
      class er extends R.t {
        constructor(t10, { code: e2 = "E_RESOURCE_PROXY", ...r2 } = {}) {
          super("".concat("[ResourceProxy]", " ").concat(t10), { code: e2, ...r2 }), (0, u._)(this, "name", "ResourceProxyException"), Object.setPrototypeOf(this, er.prototype);
        }
      }
      var ea = r(92761);
      let ei = [ea.e.PREVIEW, ea.e.SMART_PREVIEW], en = async (t10) => {
        let { key: e2, data: r2, loadedBytes: a2 } = t10, i2 = await crypto.subtle.importKey(
          "raw",
          new Uint8Array(e2.match(/.{1,2}/g).map((t11) => parseInt(t11, 16))),
          { name: "AES-CTR" },
          false,
          ["encrypt", "decrypt"]
        ), n2 = new Uint8Array(16);
        return a2 && (n2 = ((t11) => {
          let e3 = t11, r3 = new Uint8Array(16);
          for (let t12 = 0; t12 < 16; ++t12) r3[r3.length - 1 - t12] = 255 & e3, e3 >>= 8;
          return r3;
        })(a2 / 16)), crypto.subtle.decrypt({ name: "AES-CTR", counter: n2, length: 128 }, i2, r2);
      };
      class es extends ee.v {
        async isTrackDownloaded(t10, e2) {
          if (!this.variables.uid || ei.includes(e2)) return false;
          try {
            return !!await this.usersTracksRepository.get(this.variables.uid, t10);
          } catch (e3) {
            return this.hooks.afterError.promise(
              new er("Can not determine if track was downloaded", { cause: e3, data: { trackId: t10 } })
            ), false;
          }
        }
        async getLocalFileDownloadInfo(t10) {
          let e2 = await this.tracksRepository.getDecryptKey(String(t10));
          if (!e2) throw new er("Decrypt key not found");
          let r2 = await this.fileStorage.readFile(tb(String(t10))), a2 = r2.slice(0, r2.size), i2 = await a2.arrayBuffer(), n2 = await en({ data: i2, key: e2 });
          return { trackId: t10, urls: [URL.createObjectURL(new Blob([n2]))] };
        }
        async getFileInfo(t10, e2) {
          if (!await this.isTrackDownloaded(String(t10.trackId), t10.quality)) return super.getFileInfo(t10, e2);
          try {
            return { downloadInfo: await this.getLocalFileDownloadInfo(String(t10.trackId)) };
          } catch (r2) {
            return this.hooks.afterError.promise(
              new er("Can not get a local file", { cause: r2, data: { trackId: t10.trackId } })
            ), super.getFileInfo(t10, e2);
          }
        }
        async getSign(t10, e2, r2, a2) {
          let i2 = (0, tv.T)(), n2 = t10.join(","), s2 = e2.join(""), o2 = "".concat(i2).concat(n2).concat(r2).concat(s2).concat(a2);
          return (0, tv.m)({ secretKey: this.variables.secretKey, data: o2 });
        }
        async getFileInfoBatch(t10, e2) {
          let r2 = t10.trackIds.split(","), a2 = await Promise.all(r2.map(async (e3) => this.isTrackDownloaded.bind(this)(e3, t10.quality))), i2 = {}, n2 = [], s2 = [];
          r2.forEach((t11, e3) => {
            i2[t11] = e3, a2[e3] ? s2.push(t11) : n2.push(t11);
          });
          let o2 = await Promise.allSettled(s2.map(this.getLocalFileDownloadInfo.bind(this))), c2 = [];
          o2.forEach((t11, e3) => {
            switch (t11.status) {
              case "fulfilled": {
                let e4 = i2[t11.value.trackId];
                void 0 !== e4 && (c2[e4] = t11.value);
                break;
              }
              case "rejected": {
                let t12 = s2[e3];
                t12 && (this.hooks.afterError.promise(new er("Can not get a local file", { data: { trackId: t12 } })), n2.push(t12));
              }
            }
          });
          let l2 = null;
          if (n2.length > 0) {
            let r3 = t10.transports[0] || tm.o.RAW, a3 = await this.getSign(n2, t10.codecs, t10.quality, r3);
            try {
              l2 = (await super.getFileInfoBatch({ ...t10, sign: a3, trackIds: n2.join(",") }, e2)).downloadInfos;
            } catch (t11) {
              this.hooks.afterError.promise(
                new er("Can not get file info batch", { cause: String(t11), data: { trackIds: n2.join(",") } })
              );
            }
          }
          return null == l2 || l2.forEach((t11) => {
            let e3 = i2[t11.trackId];
            void 0 !== e3 && (c2[e3] = t11);
          }), { downloadInfos: c2 };
        }
        constructor(t10, e2, r2) {
          super(t10, e2), (0, u._)(this, "httpClient", void 0), (0, u._)(this, "config", void 0), (0, u._)(this, "fileStorage", void 0), (0, u._)(this, "tracksRepository", void 0), (0, u._)(this, "usersTracksRepository", void 0), (0, u._)(this, "hooks", void 0), (0, u._)(this, "variables", void 0), this.httpClient = t10, this.config = e2;
          let { fileStorage: a2, tracksRepository: i2, usersTracksRepository: n2, hooks: s2, variables: o2 } = r2;
          this.fileStorage = a2, this.tracksRepository = i2, this.usersTracksRepository = n2, this.hooks = s2, this.variables = o2;
        }
      }
      let eo = L.X1.TEAPOT, ec = (t10, e2) => new Proxy(t10, {
        get(t11, r2) {
          let a2 = t11[r2], { isOffline: i2 } = e2;
          return "function" == typeof a2 && i2 ? function() {
            throw new L.GX("Offline mode enabled", { statusCode: eo });
          } : a2;
        }
      });
      var el = r(65099), eu = r(35620), eh = r(6024);
      class ed extends el.G {
        async getCollectionDownloadedTracks() {
          let t10 = { tracks: [] };
          if (!this.variables.tracksController) return t10;
          try {
            return { tracks: await this.variables.tracksController.getTracks() };
          } catch (e2) {
            return this.hooks.afterError.promise(new er("Can not get collection downloaded tracks", { cause: e2 })), t10;
          }
        }
        async getBlock(t10, e2) {
          return t10.type === eu.t.COLLECTION_DOWNLOADED_TRACKS ? this.getCollectionDownloadedTracks() : super.getBlock(t10, e2);
        }
        async getSkeleton(t10, e2) {
          if (!this.variables.cacheController) return super.getSkeleton(t10, e2);
          if (t10.id === eh.p.WEB_COLLECTION) {
            let r2 = this.variables.cacheController.getRequestId({
              resourceName: el.G.constructor.name,
              methodName: this.getSkeleton.name,
              args: [t10]
            });
            if (this.variables.cacheController.shouldGetCache) return this.variables.cacheController.get(r2, 6048e5);
            try {
              let a2 = await super.getSkeleton(t10, e2);
              return this.variables.cacheController.put({ requestId: r2, response: a2, priority: n.MEDIUM }), a2;
            } catch (t11) {
              return this.variables.cacheController.handleError(t11, r2, 6048e5);
            }
          }
          return super.getSkeleton(t10, e2);
        }
        constructor(t10, e2, r2) {
          super(t10, e2), (0, u._)(this, "httpClient", void 0), (0, u._)(this, "config", void 0), (0, u._)(this, "hooks", void 0), (0, u._)(this, "variables", void 0), this.httpClient = t10, this.config = e2, this.hooks = r2.hooks, this.variables = r2.variables;
        }
      }
    },
    48448: (t, e, r) => {
      r.d(e, { v: () => s });
      var a = r(96559), i = r(53676), n = r(77220);
      class s extends n.X {
        async getFileInfo(t2, e2) {
          var r2;
          let a2 = await this.httpClient.get(
            "get-file-info",
            this.createHttpOptions({
              timeoutKey: "getFileInfo",
              params: t2,
              searchParams: (0, i.P)({
                ts: t2.tsInSeconds,
                trackId: t2.trackId,
                quality: t2.quality,
                codecs: t2.codecs.join(","),
                transports: t2.transports.join(","),
                sign: t2.sign,
                fromPromoLanding: t2.fromPromoLanding
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          );
          return { ...await a2.json(), responseTime: null == (r2 = a2.timings) ? void 0 : r2.response, url: a2.url };
        }
        async getFileInfoBatch(t2, e2) {
          return (await this.httpClient.get(
            "get-file-info/batch",
            this.createHttpOptions({
              timeoutKey: "getFileInfoBatch",
              params: t2,
              searchParams: (0, i.P)({
                ts: t2.tsInSeconds,
                trackIds: t2.trackIds,
                quality: t2.quality,
                codecs: t2.codecs.join(","),
                transports: t2.transports.join(","),
                sign: t2.sign,
                fromPromoLanding: t2.fromPromoLanding
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getByteRange(t2, e2) {
          let r2 = await this.httpClient.get(
            t2.srcUrl,
            this.createHttpOptions(
              {
                timeoutKey: "getByteRange",
                params: t2,
                signal: null == e2 ? void 0 : e2.signal,
                headers: { Range: "bytes=".concat(t2.start, "-").concat(t2.end) },
                excludeHeaders: ["x-request-id", "x-retry-count"]
              },
              { withoutPrefixUrl: true }
            )
          ), a2 = await r2.arrayBuffer();
          return {
            data: a2,
            contentLength: Number(r2.headers["content-length"]),
            contentRange: r2.headers["content-range"]
          };
        }
        constructor(t2, e2) {
          super(t2, e2), (0, a._)(this, "httpClient", void 0), (0, a._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    53676: (t, e, r) => {
      r.d(e, { P: () => a });
      let a = (t2) => {
        let e2 = {};
        return Object.getOwnPropertyNames(t2).filter((e3) => void 0 !== t2[e3] && null !== t2[e3]).map((r2) => {
          e2[r2] = String(t2[r2]);
        }), new URLSearchParams(e2);
      };
    },
    58900: (t, e, r) => {
      r.d(e, { Dt: () => c, P9: () => h, Gr: () => u, do: () => l });
      var a = r(96559), i = r(56258);
      class n extends i.t {
        constructor(t2 = "Internal error", { code: e2 = "E_CONTAINER", ...r2 } = {}) {
          super(t2, { code: e2, ...r2 }), (0, a._)(this, "name", "ContainerException"), Object.setPrototypeOf(this, n.prototype);
        }
      }
      class s extends n {
        constructor(t2) {
          super("A binding with the name '".concat(t2.toString(), "' already exists in the container"), {
            code: "E_CONTAINER_ALREADY_EXISTS"
          }), (0, a._)(this, "name", "AlreadyExistsContainerException"), Object.setPrototypeOf(this, s.prototype);
        }
      }
      class o extends n {
        constructor(t2) {
          super("No entry with the name '".concat(t2.toString(), "' was found in the container"), {
            code: "E_CONTAINER_NOT_FOUND"
          }), (0, a._)(this, "name", "NotFoundContainerException"), Object.setPrototypeOf(this, o.prototype);
        }
      }
      class c {
        register(t2, e2) {
          if (this.has(t2)) throw new s(t2);
          return this.bindings = { ...this.bindings, [t2]: e2 }, this;
        }
        registerMany(t2) {
          for (let e2 in t2) if (this.has(e2)) throw new s(e2);
          return this.bindings = { ...this.bindings, ...t2 }, this;
        }
        get(t2) {
          if (this.shared.has(t2)) return this.shared.get(t2);
          let e2 = this.bindings[t2];
          if (void 0 === e2) throw new o(t2);
          let r2 = this.create(e2);
          return e2.isShared && this.shared.set(t2, r2), r2;
        }
        has(t2) {
          return t2 in this.bindings;
        }
        create(t2) {
          return t2.creator(this);
        }
        constructor() {
          (0, a._)(this, "bindings", {}), (0, a._)(this, "shared", /* @__PURE__ */ new Map());
        }
      }
      function l(t2) {
        return { type: "transient", creator: t2, isShared: false };
      }
      function u(t2) {
        return { type: "singleton", creator: t2, isShared: true };
      }
      function h(t2) {
        return { type: "factory", creator: t2, isShared: false };
      }
    },
    65099: (t, e, r) => {
      r.d(e, { G: () => l });
      var a = r(96559), i = r(35620), n = r(77220), s = r(53676), o = r(56258);
      class c extends o.t {
        constructor(t2 = "Landing resource error", e2 = {}) {
          super(t2, e2), (0, a._)(this, "name", "LandingResourceException"), Object.setPrototypeOf(this, c.prototype);
        }
      }
      class l extends n.X {
        async getSkeleton(t2, e2) {
          return (await this.httpClient.get(
            "landing/skeleton/".concat(t2.id),
            this.createHttpOptions({
              timeoutKey: "getSkeleton",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, s.P)({ showWizard: t2.showWizard })
            })
          )).json();
        }
        async getBlock(t2, e2) {
          if (!(null == t2 ? void 0 : t2.source)) throw new c("Landing block source is not defined");
          let r2 = t2.type === i.t.CHART_TRACKS, a2 = ((t3, e3, r3) => {
            let { uri: a3, count: i2, countWeb: n2, ...o2 } = e3, c2 = t3 + a3, l2 = (0, s.P)(o2);
            n2 && l2.append(r3 ? "limit" : "count", String(n2));
            let u = l2.toString();
            return u ? "".concat(c2, "?").concat(u) : c2;
          })(this.config.prefixUrl, t2.source, r2);
          return (await this.httpClient.get(
            a2,
            this.createHttpOptions(
              { timeoutKey: "getBlock", params: t2, signal: null == e2 ? void 0 : e2.signal },
              { withoutPrefixUrl: true }
            )
          )).json();
        }
        async getBlockEntities(t2, e2) {
          return (await this.httpClient.get(
            "landing/block/".concat(t2.blockId, "/entities"),
            this.createHttpOptions({
              timeoutKey: "getBlockEntities",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, s.P)({ page: t2.page, pageSize: t2.pageSize })
            })
          )).json();
        }
        async getSpecialHeader(t2, e2) {
          return (await this.httpClient.get(
            "landing/special-header",
            this.createHttpOptions({
              timeoutKey: "getSpecialHeader",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, a._)(this, "httpClient", void 0), (0, a._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    77220: (t, e, r) => {
      r.d(e, { X: () => n });
      var a = r(96559);
      class i {
        constructor(t2) {
          (0, a._)(this, "httpClient", void 0), this.httpClient = t2;
        }
      }
      class n extends i {
        createHttpOptions(t2) {
          let e2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, { timeoutKey: r2, params: a2, headers: i2, signal: n2, ...s } = t2, { prefixUrl: o, ...c } = s, { timeouts: l = this.config.timeouts, withoutPrefixUrl: u, withoutHeaders: h } = e2, d = null == l ? void 0 : l[r2], g = h ? void 0 : null != i2 ? i2 : this.createRequestHeaders({ params: a2, timeout: d }), y = null != o ? o : this.config.prefixUrl, v = { headers: g, retry: this.getRetryPolicyConfig(), timeout: d, signal: n2, ...c };
          return u ? v : { prefixUrl: y, ...v };
        }
        createRequestHeaders() {
          var t2, e2;
          let r2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, { params: a2, timeout: i2 } = r2, n2 = this.createRequestHeadersFromParams(a2);
          if ((null != (e2 = null == a2 || null == (t2 = a2.common) ? void 0 : t2.sendRequestDeadline) ? e2 : this.config.params.common.sendRequestDeadline) && void 0 !== i2) {
            let t3 = Date.now() + i2;
            n2["x-request-deadline-ms"] = String(t3);
          }
          return n2;
        }
        createRequestHeadersFromParams(t2) {
          var e2, r2, a2, i2, n2, s, o, c, l, u, h, d, g, y, v, m, p, w, E;
          let b = (null == t2 || null == (e2 = t2.common) ? void 0 : e2.oauth) || this.config.params.common.oauth, f = (null == t2 || null == (r2 = t2.common) ? void 0 : r2.client) || this.config.params.common.client, T = (null == t2 || null == (a2 = t2.common) ? void 0 : a2.language) || this.config.params.common.language, k = (null == t2 || null == (i2 = t2.common) ? void 0 : i2.device) || this.config.params.common.device, C = (null == t2 || null == (n2 = t2.common) ? void 0 : n2.multiAuthUserId) || this.config.params.common.multiAuthUserId, S = (null == t2 || null == (o = t2.common) || null == (s = o.blackbox) ? void 0 : s.userTicket) || (null == (c = this.config.params.common.blackbox) ? void 0 : c.userTicket), I = (null == t2 || null == (u = t2.common) || null == (l = u.tvm) ? void 0 : l.serviceTicket) || (null == (h = this.config.params.common.tvm) ? void 0 : h.serviceTicket), A = null == (E = null == t2 || null == (d = t2.common) ? void 0 : d.withoutInvocationInfo) || E, _ = (null == t2 || null == (g = t2.common) ? void 0 : g.icookie) || this.config.params.common.icookie, R = (null == t2 || null == (y = t2.common) ? void 0 : y.requestId) || this.config.params.common.requestId, O = (null == t2 || null == (v = t2.common) ? void 0 : v.clientIp) || this.config.params.common.clientIp, D = (null == t2 || null == (m = t2.common) ? void 0 : m.tracestate) || this.config.params.common.tracestate, x = (null == t2 || null == (p = t2.common) ? void 0 : p.traceparent) || this.config.params.common.traceparent, N = (null == t2 || null == (w = t2.common) ? void 0 : w.referer) || this.config.params.common.referer, L = {
            authorization: void 0 !== b ? "OAuth ".concat(b) : void 0,
            "x-yandex-music-client": f,
            "accept-language": T,
            "x-yandex-music-device": k,
            "x-yandex-music-multi-auth-user-id": void 0 !== C ? String(C) : void 0
          };
          return void 0 !== S && (L["x-ya-user-ticket"] = S), void 0 !== I && (L["x-ya-service-ticket"] = I), A && (L["x-yandex-music-without-invocation-info"] = "1"), void 0 !== _ && (L["x-yandex-icookie"] = _), void 0 !== R && (L["x-request-id"] = R), void 0 !== O && (L["x-forwarded-for-y"] = O), void 0 !== D && (L.tracestate = D), void 0 !== x && (L.traceparent = x), void 0 !== N && (L.referer = N), L;
        }
        getRetryPolicyConfig() {
          return { config: this.config.retryPolicyConfig };
        }
        constructor(t2, e2) {
          super(t2), (0, a._)(this, "httpClient", void 0), (0, a._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    92761: (t, e, r) => {
      var a;
      r.d(e, { e: () => a }), (function(t2) {
        t2.LOSSLESS = "lossless", t2.HQ = "hq", t2.NQ = "nq", t2.LQ = "lq", t2.PREVIEW = "preview", t2.SMART_PREVIEW = "smart_preview";
      })(a || (a = {}));
    },
    99796: (t, e, r) => {
      r.d(e, { h: () => y });
      var a = r(10081);
      class i {
        get delete() {
          var t2;
          return null == (t2 = this.cursor.delete) ? void 0 : t2.bind(this.cursor);
        }
        get update() {
          var t2;
          return null == (t2 = this.cursor.update) ? void 0 : t2.bind(this.cursor);
        }
        [Symbol.asyncIterator]() {
          return this.cursor[Symbol.asyncIterator]();
        }
        constructor(t2) {
          Object.defineProperty(this, "cursor", { enumerable: true, configurable: true, writable: true, value: t2 }), Object.defineProperty(this, "key", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "direction", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "request", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "primaryKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "advance", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "continue", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "continuePrimaryKey", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), this.direction = t2.direction, this.request = t2.request, this.primaryKey = t2.primaryKey, this.key = t2.key, this.advance = t2.advance.bind(t2), this.continue = t2.continue.bind(t2), this.continuePrimaryKey = t2.continuePrimaryKey.bind(t2);
        }
      }
      class n extends i {
        [Symbol.asyncIterator]() {
          return this.cursor[Symbol.asyncIterator]();
        }
        constructor(t2) {
          super(t2), Object.defineProperty(this, "cursor", { enumerable: true, configurable: true, writable: true, value: t2 }), Object.defineProperty(this, "value", { enumerable: true, configurable: true, writable: true, value: void 0 }), this.value = t2.value;
        }
      }
      var s = function(t2, e2, r2, a2) {
        return new (r2 || (r2 = Promise))(function(i2, n2) {
          function s2(t3) {
            try {
              c2(a2.next(t3));
            } catch (t4) {
              n2(t4);
            }
          }
          function o2(t3) {
            try {
              c2(a2.throw(t3));
            } catch (t4) {
              n2(t4);
            }
          }
          function c2(t3) {
            var e3;
            t3.done ? i2(t3.value) : ((e3 = t3.value) instanceof r2 ? e3 : new r2(function(t4) {
              t4(e3);
            })).then(s2, o2);
          }
          c2((a2 = a2.apply(t2, e2 || [])).next());
        });
      };
      class o {
        get(t2) {
          return s(this, void 0, void 0, function* () {
            return this.index.get(t2);
          });
        }
        getAll(t2, e2) {
          return s(this, void 0, void 0, function* () {
            return this.index.getAll(t2, e2);
          });
        }
        getAllKeys(t2, e2) {
          return s(this, void 0, void 0, function* () {
            return this.index.getAllKeys(t2, e2);
          });
        }
        getKey(t2) {
          return s(this, void 0, void 0, function* () {
            return this.index.getKey(t2);
          });
        }
        count(t2) {
          return s(this, void 0, void 0, function* () {
            return this.index.count(t2);
          });
        }
        openCursor(t2, e2) {
          return s(this, void 0, void 0, function* () {
            let r2 = yield this.index.openCursor(t2, e2);
            return r2 && new n(r2);
          });
        }
        openKeyCursor(t2, e2) {
          return s(this, void 0, void 0, function* () {
            let r2 = yield this.index.openKeyCursor(t2, e2);
            return r2 && new i(r2);
          });
        }
        [Symbol.asyncIterator]() {
          return this.index[Symbol.asyncIterator]();
        }
        iterate(t2, e2) {
          return this.index.iterate(t2, e2);
        }
        constructor(t2) {
          Object.defineProperty(this, "index", { enumerable: true, configurable: true, writable: true, value: t2 }), Object.defineProperty(this, "keyPath", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "multiEntry", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "name", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "unique", { enumerable: true, configurable: true, writable: true, value: void 0 }), this.keyPath = t2.keyPath, this.multiEntry = t2.multiEntry, this.name = t2.name, this.unique = t2.unique;
        }
      }
      var c = function(t2, e2, r2, a2) {
        return new (r2 || (r2 = Promise))(function(i2, n2) {
          function s2(t3) {
            try {
              c2(a2.next(t3));
            } catch (t4) {
              n2(t4);
            }
          }
          function o2(t3) {
            try {
              c2(a2.throw(t3));
            } catch (t4) {
              n2(t4);
            }
          }
          function c2(t3) {
            var e3;
            t3.done ? i2(t3.value) : ((e3 = t3.value) instanceof r2 ? e3 : new r2(function(t4) {
              t4(e3);
            })).then(s2, o2);
          }
          c2((a2 = a2.apply(t2, e2 || [])).next());
        });
      };
      class l {
        get indexNames() {
          return this.objectStore.indexNames;
        }
        get put() {
          var t2;
          return null == (t2 = this.objectStore.put) ? void 0 : t2.bind(this.objectStore);
        }
        get add() {
          var t2;
          return null == (t2 = this.objectStore.add) ? void 0 : t2.bind(this.objectStore);
        }
        get clear() {
          var t2;
          return null == (t2 = this.objectStore.clear) ? void 0 : t2.bind(this.objectStore);
        }
        get delete() {
          var t2;
          return null == (t2 = this.objectStore.delete) ? void 0 : t2.bind(this.objectStore);
        }
        createIndex(t2, e2, r2) {
          return this.objectStore.createIndex ? new o(this.objectStore.createIndex(t2, e2, r2)) : null;
        }
        deleteIndex(t2) {
          return this.objectStore.deleteIndex(t2);
        }
        count(t2) {
          return c(this, void 0, void 0, function* () {
            return this.objectStore.count(t2);
          });
        }
        get(t2) {
          return c(this, void 0, void 0, function* () {
            return this.objectStore.get(t2);
          });
        }
        getAll(t2, e2) {
          return c(this, void 0, void 0, function* () {
            return this.objectStore.getAll(t2, e2);
          });
        }
        getAllKeys(t2, e2) {
          return c(this, void 0, void 0, function* () {
            return this.objectStore.getAllKeys(t2, e2);
          });
        }
        getKey(t2) {
          return c(this, void 0, void 0, function* () {
            return this.objectStore.getKey(t2);
          });
        }
        index(t2) {
          return new o(this.objectStore.index(t2));
        }
        openKeyCursor(t2, e2) {
          return c(this, void 0, void 0, function* () {
            let r2 = yield this.objectStore.openKeyCursor(t2, e2);
            return r2 && new i(r2);
          });
        }
        openCursor(t2, e2) {
          return c(this, void 0, void 0, function* () {
            let r2 = yield this.objectStore.openCursor(t2, e2);
            return r2 && new n(r2);
          });
        }
        iterate(t2, e2) {
          return this.objectStore.iterate(t2, e2);
        }
        [Symbol.asyncIterator]() {
          return this.objectStore[Symbol.asyncIterator]();
        }
        constructor(t2) {
          Object.defineProperty(this, "objectStore", { enumerable: true, configurable: true, writable: true, value: t2 }), Object.defineProperty(this, "autoIncrement", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "keyPath", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "name", { enumerable: true, configurable: true, writable: true, value: void 0 }), this.autoIncrement = t2.autoIncrement, this.keyPath = t2.keyPath, this.name = t2.name;
        }
      }
      class u {
        get error() {
          return this.transaction.error;
        }
        get done() {
          return this.transaction.done;
        }
        abort() {
          return this.transaction.abort();
        }
        commit() {
          return this.transaction.commit();
        }
        objectStore(t2) {
          return new l(this.transaction.objectStore(t2));
        }
        addEventListener(t2, e2, r2) {
          return this.transaction.addEventListener(t2, e2, r2);
        }
        removeEventListener(t2, e2, r2) {
          return this.transaction.removeEventListener(t2, e2, r2);
        }
        set onabort(t2) {
          this.transaction.onabort = t2;
        }
        set onerror(t2) {
          this.transaction.onerror = t2;
        }
        set oncomplete(t2) {
          this.transaction.oncomplete = t2;
        }
        dispatchEvent(t2) {
          return this.transaction.dispatchEvent(t2);
        }
        constructor(t2) {
          Object.defineProperty(this, "transaction", { enumerable: true, configurable: true, writable: true, value: t2 }), Object.defineProperty(this, "durability", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "mode", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "objectStoreNames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), this.durability = t2.durability, this.mode = t2.mode, this.objectStoreNames = t2.objectStoreNames;
        }
      }
      var h = function(t2, e2, r2, a2) {
        return new (r2 || (r2 = Promise))(function(i2, n2) {
          function s2(t3) {
            try {
              c2(a2.next(t3));
            } catch (t4) {
              n2(t4);
            }
          }
          function o2(t3) {
            try {
              c2(a2.throw(t3));
            } catch (t4) {
              n2(t4);
            }
          }
          function c2(t3) {
            var e3;
            t3.done ? i2(t3.value) : ((e3 = t3.value) instanceof r2 ? e3 : new r2(function(t4) {
              t4(e3);
            })).then(s2, o2);
          }
          c2((a2 = a2.apply(t2, e2 || [])).next());
        });
      };
      class d {
        get objectStoreNames() {
          return this.database.objectStoreNames;
        }
        transaction(t2, e2, r2) {
          return new u(this.database.transaction(t2, e2, r2));
        }
        createObjectStore(t2, e2) {
          return new l(this.database.createObjectStore(t2, e2));
        }
        deleteObjectStore(t2) {
          return this.database.deleteObjectStore(t2);
        }
        get(t2, e2) {
          return h(this, void 0, void 0, function* () {
            return this.database.get(t2, e2);
          });
        }
        getAll(t2, e2, r2) {
          return h(this, void 0, void 0, function* () {
            return this.database.getAll(t2, e2, r2);
          });
        }
        add(t2, e2, r2) {
          return h(this, void 0, void 0, function* () {
            return this.database.add(t2, e2, r2);
          });
        }
        put(t2, e2, r2) {
          return h(this, void 0, void 0, function* () {
            return this.database.put(t2, e2, r2);
          });
        }
        delete(t2, e2) {
          return h(this, void 0, void 0, function* () {
            return this.database.delete(t2, e2);
          });
        }
        clear(t2) {
          return h(this, void 0, void 0, function* () {
            return this.database.clear(t2);
          });
        }
        count(t2, e2) {
          return h(this, void 0, void 0, function* () {
            return this.database.count(t2, e2);
          });
        }
        getKey(t2, e2) {
          return h(this, void 0, void 0, function* () {
            return this.database.getKey(t2, e2);
          });
        }
        getAllKeys(t2, e2, r2) {
          return h(this, void 0, void 0, function* () {
            return this.database.getAllKeys(t2, e2, r2);
          });
        }
        countFromIndex(t2, e2, r2) {
          return h(this, void 0, void 0, function* () {
            return this.database.countFromIndex(t2, e2, r2);
          });
        }
        getFromIndex(t2, e2, r2) {
          return h(this, void 0, void 0, function* () {
            return this.database.getFromIndex(t2, e2, r2);
          });
        }
        getAllFromIndex(t2, e2, r2, a2) {
          return h(this, void 0, void 0, function* () {
            return this.database.getAllFromIndex(t2, e2, r2, a2);
          });
        }
        getAllKeysFromIndex(t2, e2, r2, a2) {
          return h(this, void 0, void 0, function* () {
            return this.database.getAllKeysFromIndex(t2, e2, r2, a2);
          });
        }
        getKeyFromIndex(t2, e2, r2) {
          return h(this, void 0, void 0, function* () {
            return this.database.getKeyFromIndex(t2, e2, r2);
          });
        }
        addEventListener(t2, e2, r2) {
          this.database.addEventListener(t2, e2, r2);
        }
        removeEventListener(t2, e2, r2) {
          this.database.removeEventListener(t2, e2, r2);
        }
        set onabort(t2) {
          this.database.onabort = t2;
        }
        set onclose(t2) {
          this.database.onclose = t2;
        }
        set onerror(t2) {
          this.database.onerror = t2;
        }
        set onversionchange(t2) {
          this.database.onversionchange = t2;
        }
        close() {
          return this.database.close();
        }
        dispatchEvent(t2) {
          return this.database.dispatchEvent(t2);
        }
        constructor(t2) {
          Object.defineProperty(this, "database", { enumerable: true, configurable: true, writable: true, value: t2 }), Object.defineProperty(this, "version", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "name", { enumerable: true, configurable: true, writable: true, value: void 0 }), this.version = t2.version, this.name = t2.name;
        }
      }
      var g = function(t2, e2, r2, a2) {
        return new (r2 || (r2 = Promise))(function(i2, n2) {
          function s2(t3) {
            try {
              c2(a2.next(t3));
            } catch (t4) {
              n2(t4);
            }
          }
          function o2(t3) {
            try {
              c2(a2.throw(t3));
            } catch (t4) {
              n2(t4);
            }
          }
          function c2(t3) {
            var e3;
            t3.done ? i2(t3.value) : ((e3 = t3.value) instanceof r2 ? e3 : new r2(function(t4) {
              t4(e3);
            })).then(s2, o2);
          }
          c2((a2 = a2.apply(t2, e2 || [])).next());
        });
      };
      class y {
        openDB(t2) {
          let {
            onBlocked: e2,
            onBlocking: r2,
            onTerminated: i2,
            onUpgrade: n2
          } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return g(this, void 0, void 0, function* () {
            let s2 = yield (0, a.P2)(this.name, t2, {
              blocked: e2,
              blocking: r2,
              terminated: i2,
              upgrade: (t3, e3, r3, a2, i3) => {
                let s3 = new d(t3);
                null == n2 || n2(s3, e3, r3, new u(a2), i3);
              }
            });
            return new d(s2);
          });
        }
        deleteDB(t2) {
          let { onBlocked: e2 } = t2;
          return g(this, void 0, void 0, function* () {
            yield (0, a.MR)(this.name, { blocked: e2 });
          });
        }
        constructor(t2) {
          Object.defineProperty(this, "name", { enumerable: true, configurable: true, writable: true, value: t2 });
        }
      }
    }
  }
]);
