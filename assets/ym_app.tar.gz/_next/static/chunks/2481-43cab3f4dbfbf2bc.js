"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2481],
  {
    62481: (t, e, i) => {
      i.d(e, {
        SM: () => K.PlaylistPage,
        Pn: () => D,
        Cm: () => P.PlaylistShimmersPage,
        rb: () => l.useSetPlaylistFilters
      }), i(84458);
      var a = (function(t2) {
        return t2.ALL = "all", t2;
      })({}), l = i(14782), r = i(93064), n = i(15209), s = i(74125), d = (function(t2) {
        return t2.MAJOR = "Major", t2.NAME = "Название", t2.ARTISCS = "Исполнители", t2.LINK = "Ссылка", t2.ALBUM_ID = "albumId", t2.TRACK_ID = "trackId", t2;
      })({}), o = (function(t2) {
        return t2.MAJOR = "major", t2.NAME = "name", t2.ARTISCS = "artists", t2.LINK = "link", t2.ALBUM_ID = "albumId", t2.TRACK_ID = "trackId", t2;
      })({});
      let u = r.gK.model("EditorFeature", {
        shouldShowMajor: r.gK.boolean,
        shouldShowGenre: r.gK.boolean,
        shouldShowDuplicate: r.gK.boolean,
        colorMajorMap: r.gK.map(r.gK.string),
        duplicate: r.gK.map(r.gK.number)
      }).views((t2) => {
        let e2 = {
          getNumberGroupTrackDuplicated(e3) {
            let { experiments: i2 } = (0, r.Zn)(t2);
            if (e3 && i2.checkExperiment(s.zal.WebEditorsFeatures, "on")) return t2.duplicate.get(String(e3.id));
          },
          shouldHighlightDublicatedTrack: (i2) => !!(t2.shouldShowDuplicate && e2.getNumberGroupTrackDuplicated(i2)),
          get sheetDataPlaylist() {
            var i2, a2;
            let { location: e3, playlist: l2 } = (0, r.Zn)(t2), s2 = "https://".concat(e3.host, ".").concat(e3.tld), u2 = {
              sheet: "Playlist",
              columns: [
                { label: d.MAJOR, value: o.MAJOR },
                { label: d.NAME, value: o.NAME },
                { label: d.ARTISCS, value: o.ARTISCS },
                { label: d.LINK, value: o.LINK },
                { label: d.ALBUM_ID, value: o.ALBUM_ID },
                { label: d.TRACK_ID, value: o.TRACK_ID }
              ],
              content: l2.items.filter((t3) => t3.data).map((t3) => {
                var e4, i3, a3, l3, r2, d2, o2, u3, g2, m2, c2, v2, S2;
                let { href: h2 } = (0, n.getLinkAttributesBase)(
                  null != (u3 = null == (e4 = t3.data) ? void 0 : e4.url) ? u3 : "",
                  { options: { host: s2 } }
                ), E2 = (null == (i3 = t3.data) ? void 0 : i3.url) ? h2 : "";
                return {
                  major: null != (g2 = null == (l3 = t3.data) || null == (a3 = l3.major) ? void 0 : a3.name) ? g2 : "",
                  name: null != (m2 = null == (r2 = t3.data) ? void 0 : r2.title) ? m2 : "",
                  artists: null != (c2 = null == (d2 = t3.data) ? void 0 : d2.artists.map((t4) => t4.name).join(", ")) ? c2 : "",
                  link: E2,
                  albumId: null != (v2 = t3.albumId) ? v2 : "",
                  trackId: null != (S2 = null == (o2 = t3.data) ? void 0 : o2.id) ? S2 : ""
                };
              })
            };
            return {
              data: u2,
              settings: {
                fileName: (null == (i2 = l2.meta) ? void 0 : i2.uid) && (null == (a2 = l2.meta) ? void 0 : a2.kind) ? "%".concat(l2.meta.uid, "%_%").concat(l2.meta.kind, "%_to_text") : "to_text"
              }
            };
          }
        };
        return e2;
      }).actions((t2) => ({
        exportToExcel: (0, r.L3)(function* () {
          let { modelActionsLogger: e2 } = (0, r._$)(t2);
          try {
            let e3 = yield Promise.all([i.e(714), i.e(8473), i.e(9484)]).then(i.t.bind(i, 52224, 23)), { data: a2, settings: l2 } = t2.sheetDataPlaylist;
            if (0 === a2.content.length) return s.FlZ.ERROR;
            return yield new Promise((t3) => {
              e3.default([a2], l2, () => t3());
            }), s.FlZ.OK;
          } catch (t3) {
            return e2.error(t3), s.FlZ.ERROR;
          }
        }),
        getAllPlaylistItems: (0, r.L3)(function* (e2) {
          let { batchSize: i2 } = e2, { playlist: a2 } = (0, r.Zn)(t2), l2 = a2.items.length - 1;
          for (let t3 = 0; t3 < l2; t3 += i2) yield a2.getTracksByRange({ startIndex: t3, endIndex: Math.min(t3 + i2, l2) });
        }),
        getColorForMajor(e2) {
          let i2 = t2.colorMajorMap.get(e2);
          if (i2) return i2;
          let a2 = (0, s.KkH)(e2), l2 = "hsl(".concat(a2, ", 50%, 50%)");
          return t2.colorMajorMap.set(e2, l2), l2;
        },
        getDuplicates(e2) {
          let i2 = /* @__PURE__ */ new Map();
          e2.forEach((t3) => {
            let e3 = i2.get(t3.id) || 0;
            i2.set(t3.id, e3 + 1);
          });
          let a2 = 1;
          i2.forEach((e3, i3) => {
            e3 > 1 && (t2.duplicate.set(String(i3), a2), a2++);
          });
        },
        toggleShouldShowMajor() {
          t2.shouldShowMajor = !t2.shouldShowMajor;
        },
        toggleShouldShowGenre() {
          t2.shouldShowGenre = !t2.shouldShowGenre;
        },
        toggleShouldShowDuplicate() {
          t2.shouldShowDuplicate = !t2.shouldShowDuplicate;
        },
        reset() {
          t2.shouldShowDuplicate = false, t2.shouldShowGenre = false, t2.shouldShowMajor = false, t2.colorMajorMap = (0, r.wg)({}), t2.duplicate = (0, r.wg)({});
        }
      }));
      var g = i(21365);
      let m = r.gK.model("PlaylistItem", {
        id: r.gK.union(r.gK.string, r.gK.number),
        albumId: r.gK.maybeNull(r.gK.union(r.gK.string, r.gK.number)),
        key: r.gK.string,
        data: r.gK.maybeNull(g.vj),
        loadingState: r.gK.enumeration(Object.values(s.GuX))
      }), c = r.gK.model("PlaylistFiltersItem", { id: r.gK.string, name: r.gK.string, tracks: r.gK.array(m) });
      var v = i(63930), S = i(14287), h = i(14032), E = i(4542), y = i(83909), I = i(13611), T = i(26433), p = i(97719);
      let k = (t2) => t2.map((t3) => (0, p.li)(t3.id, t3.albumId || void 0)), b = (t2) => {
        var e2, i2;
        let a2 = (null == (e2 = t2.tracks) ? void 0 : e2.length) ? null == (i2 = t2.tracks) ? void 0 : i2.map(
          (t3, e3) => ((t4, e4) => {
            let [i3, a3] = t4.split(":");
            return (0, r.wg)({
              id: i3 || "",
              albumId: a3 || "",
              key: "".concat(i3, "-").concat(e4),
              data: null,
              loadingState: s.GuX.IDLE
            });
          })(t3, e3)
        ) : [];
        return { id: t2.id, name: t2.name, tracks: (0, r.wg)(a2) };
      }, N = r.gK.compose(
        r.gK.model("PlaylistPageFilters", {
          items: r.gK.maybeNull(r.gK.array(c)),
          activeFilter: r.gK.maybe(r.gK.string),
          activeFilterName: r.gK.maybeNull(r.gK.string),
          shouldSendEventOnTabOpened: r.gK.boolean,
          shouldSendEventOnTabLoaded: r.gK.boolean
        }),
        T.XT,
        T.pl
      ).views((t2) => {
        let e2 = {
          get isShimmerVisible() {
            return t2.isRejected || t2.isLoading;
          },
          get activeFilterIndex() {
            var i2;
            let e3 = null == (i2 = t2.items) ? void 0 : i2.findIndex((e4) => e4.id === t2.activeFilter);
            return e3 && e3 > -1 ? e3 : 0;
          },
          get analyticsParamsActiveFilterIndex() {
            return e2.activeFilterIndex + 1;
          }
        };
        return e2;
      }).actions((t2) => {
        let e2 = {
          getFilters: (0, r.L3)(function* () {
            var i2, l2;
            let { filtersResource: n2, modelActionsLogger: d2 } = (0, r._$)(t2), { sonataState: o2, playlist: u2 } = (0, r.Zn)(t2);
            if (t2.isLoading || !(null == (i2 = u2.items) ? void 0 : i2.length)) return;
            let g2 = u2.items.map((t3) => String((0, h.V)(t3.id, t3.albumId))) || [];
            try {
              t2.loadingState = s.GuX.PENDING;
              let i3 = yield n2.getTracksFilters({ trackIds: g2 });
              t2.items = (0, r.wg)(
                ((t3) => {
                  let e3 = t3.filters.map(b);
                  if (e3.length < 3) return [];
                  let i4 = e3.find((t4) => t4.id === a.ALL);
                  if (!i4) return [];
                  let l3 = e3.filter((t4) => t4.tracks.length >= 8);
                  return l3.length < 2 ? [] : [i4].concat(l3.slice(0, 7));
                })(i3)
              ), e2.setActiveFilter(o2.playlistFilter), e2.getFilterName(o2.playlistFilter || a.ALL);
              let d3 = null == (l2 = t2.items) ? void 0 : l2.find((e3) => e3.id === t2.activeFilter);
              d3 && (u2.setItems(d3.tracks), o2.setUnloadedEntitiesData(k(u2.items))), t2.loadingState = s.GuX.RESOLVE;
            } catch (e3) {
              d2.error(e3), t2.loadingState = s.GuX.REJECT;
            }
          }),
          getFilterName: (0, r.L3)(function* (e3) {
            let { filtersResource: i2, modelActionsLogger: a2 } = (0, r._$)(t2);
            try {
              t2.activeFilterName = (yield i2.getFilterName({ filterId: e3 })).name;
            } catch (t3) {
              a2.error(t3);
            }
          }),
          handleFilterClick(i2) {
            if (!(0, r._n)(t2)) return;
            let { sonataState: a2, playlist: l2 } = (0, r.Zn)(t2);
            e2.setActiveFilter(i2.id), e2.getFilterName(i2.id), l2.setItems(t2.activeFilter ? i2.tracks : l2.initialItems), a2.setUnloadedEntitiesData(k(l2.items)), e2.setShouldSendEventOnTabOpened(true);
          },
          setActiveFilter(e3) {
            e3 !== a.ALL ? t2.activeFilter = e3 : t2.activeFilter = void 0;
          },
          setShouldSendEventOnTabOpened(e3) {
            t2.shouldSendEventOnTabOpened = e3;
          },
          setShouldSendEventOnTabLoaded(e3) {
            t2.shouldSendEventOnTabLoaded = e3;
          },
          reset() {
            t2.destroyItems([t2.items]), t2.loadingState = s.GuX.IDLE, t2.activeFilter = void 0, t2.activeFilterName = null, t2.shouldSendEventOnTabOpened = true, t2.shouldSendEventOnTabLoaded = true;
          }
        };
        return e2;
      }), f = r.gK.compose(
        r.gK.model("PlaylistPageSearch", {
          errorStatusCode: r.gK.maybeNull(r.gK.number),
          text: r.gK.string,
          playlistTrackIds: r.gK.maybeNull(r.gK.array(r.gK.string)),
          suggestedTrackIds: r.gK.maybeNull(r.gK.array(r.gK.string)),
          additionTrackInProggress: r.gK.maybeNull(r.gK.string),
          tracks: r.gK.maybeNull(r.gK.array(g.vj)),
          isFocused: r.gK.optional(r.gK.boolean, false)
        }),
        T.XT
      ).views((t2) => ({
        get isLoading() {
          return t2.isNeededToLoad || t2.loadingState === s.GuX.PENDING;
        },
        get hasText() {
          return !!t2.text.length;
        },
        get suggestedTracks() {
          var e2;
          return null == (e2 = t2.suggestedTrackIds) ? void 0 : e2.map((e3) => {
            var i2;
            return (null == (i2 = t2.tracks) ? void 0 : i2.find((t3) => t3.id === e3)) || null;
          });
        },
        get playlistTracks() {
          let e2 = [...t2.playlistTrackIds || []];
          return t2.additionTrackInProggress && e2.unshift(t2.additionTrackInProggress), null == e2 ? void 0 : e2.map((e3) => {
            var i2;
            return (null == (i2 = t2.tracks) ? void 0 : i2.find((t3) => {
              var i3;
              return ((null == (i3 = t3.mainAlbum) ? void 0 : i3.id) && e3.includes(":") ? "".concat(t3.id, ":").concat(t3.mainAlbum.id) : t3.id) === e3;
            })) || null;
          });
        }
      })).actions((t2) => {
        let e2 = {
          getTracksMeta: (0, r.L3)(function* () {
            let { tracksResource: e3, modelActionsLogger: i2 } = (0, r._$)(t2), a2 = [...t2.playlistTrackIds || []].concat(t2.suggestedTrackIds || []);
            try {
              let i3 = yield e3.getTracksMeta({ trackIds: a2, removeDuplicates: true, withProgress: true });
              t2.tracks = (0, r.wg)(null == i3 ? void 0 : i3.map((t3) => (0, g.vU)(t3))), t2.loadingState !== s.GuX.IDLE && (t2.loadingState = s.GuX.RESOLVE);
            } catch (t3) {
              i2.error(t3);
            }
            return null;
          }),
          getTracks: (0, r.L3)(function* (i2) {
            let { uid: a2, kind: l2 } = i2, { searchPlaylistResource: n2, modelActionsLogger: d2 } = (0, r._$)(t2);
            if (t2.loadingState === s.GuX.PENDING || !t2.hasText || !(0, r._n)(t2)) return;
            let { playlist: o2 } = (0, r.Zn)(t2);
            try {
              var u2, g2;
              let i3;
              t2.loadingState = s.GuX.PENDING;
              let { playlistTrackIds: d3 = [], suggestedTrackIds: m2 = [] } = yield n2.getTrackIds({
                uid: a2,
                kind: l2,
                part: t2.text
              }), c2 = (i3 = o2.items, d3.map((t3) => {
                let e3 = i3.find((e4) => String(e4.id) === t3);
                return (null == e3 ? void 0 : e3.albumId) ? "".concat(t3, ":").concat(e3.albumId) : t3;
              }));
              t2.playlistTrackIds = (0, r.wg)(c2), t2.suggestedTrackIds = (0, r.wg)(m2), ((null == (u2 = t2.playlistTrackIds) ? void 0 : u2.length) || 0) + ((null == (g2 = t2.suggestedTrackIds) ? void 0 : g2.length) || 0) > 0 ? e2.getTracksMeta() : t2.loadingState = s.GuX.RESOLVE;
            } catch (e3) {
              d2.error(e3), e3 instanceof S.GX && (e3.statusCode === S.X1.NOT_FOUND || e3.statusCode === S.X1.BAD_REQUEST) && (t2.errorStatusCode = S.X1.NOT_FOUND), t2.loadingState !== s.GuX.IDLE && (t2.loadingState = s.GuX.REJECT);
            }
          }),
          setText(e3) {
            t2.text = e3;
          },
          setIdleState() {
            t2.loadingState = s.GuX.IDLE;
          },
          setAdditionTrackAnimation(e3) {
            t2.additionTrackInProggress = e3;
          },
          setFocus() {
            t2.isFocused = true;
          },
          removeFocus() {
            t2.isFocused = false;
          },
          replaceAdditionTrackInProggress() {
            if (t2.additionTrackInProggress) {
              var e3, i2;
              null == (e3 = t2.playlistTrackIds) || e3.unshift(t2.additionTrackInProggress), t2.suggestedTrackIds = (0, r.wg)(
                null == (i2 = t2.suggestedTrackIds) ? void 0 : i2.filter((e4) => e4 !== t2.additionTrackInProggress)
              ), t2.additionTrackInProggress = null;
            }
          },
          resetAdditionTrackAnimation() {
            t2.additionTrackInProggress = null;
          },
          reset() {
            t2.playlistTrackIds = null, t2.suggestedTrackIds = null, t2.additionTrackInProggress = null, t2.tracks = null, t2.loadingState = s.GuX.IDLE, t2.isFocused = false;
          }
        };
        return e2;
      }), D = r.gK.compose(
        r.gK.model("PlaylistPage", {
          uuid: r.gK.maybeNull(r.gK.string),
          meta: r.gK.maybeNull(y.BL),
          items: r.gK.array(m),
          errorStatusCode: r.gK.maybeNull(r.gK.number),
          similarPlaylists: r.gK.array(y.IP),
          initialItems: r.gK.array(m),
          shouldShowTrailerOnboarding: r.gK.maybeNull(r.gK.boolean),
          editorFeature: u,
          search: f,
          filters: N,
          similarEntities: E.F6
        }),
        T.pl,
        T.XT
      ).views((t2) => {
        let e2 = {
          getUrl(e3) {
            if (!t2.uuid) return "";
            let { href: i2 } = (0, s.uvd)("/playlists/:playlistUuid", {
              params: { playlistUuid: t2.uuid },
              query: e3
            });
            return i2;
          },
          get isLoading() {
            return t2.isNeededToLoad || t2.loadingState === s.GuX.PENDING;
          },
          get isDisabled() {
            var i2;
            return t2.isResolved && (0 === t2.items.length || !(null == (i2 = t2.meta) ? void 0 : i2.isAvailable));
          },
          get isNotFound() {
            return t2.isRejected && t2.errorStatusCode === S.X1.NOT_FOUND;
          },
          get hasSimilarPlaylists() {
            return e2.isLoading || t2.similarPlaylists.length > 0;
          },
          get isEmptyPlaylist() {
            return t2.isResolved && 0 === t2.items.length;
          },
          get isSimilarEntitiesEnabled() {
            let { experiments: e3 } = (0, r.Zn)(t2);
            return e3.checkExperiment(s.zal.WebNextWaveAgentExperiment, "on");
          },
          get hasSimilarEntities() {
            var a2;
            return !!(e2.isSimilarEntitiesEnabled && t2.similarEntities.isLoaded && (null == (a2 = t2.similarEntities.data) ? void 0 : a2.items) && t2.similarEntities.data.items.length > 0);
          },
          get contextMeta() {
            var l2, n2, d2, o2, u2, g2, m2, c2, v2, E2;
            return {
              isAvailable: null == (l2 = t2.meta) ? void 0 : l2.isAvailable,
              id: t2.meta.id,
              uid: null == (n2 = t2.meta) ? void 0 : n2.uid,
              uuid: t2.meta.uuid,
              kind: null == (d2 = t2.meta) ? void 0 : d2.kind,
              title: null == (o2 = t2.meta) ? void 0 : o2.title,
              coverUri: null == (u2 = t2.meta) ? void 0 : u2.coverUri,
              likesCount: null == (g2 = t2.meta) ? void 0 : g2.likesCount,
              averageColor: null == (m2 = t2.meta) ? void 0 : m2.averageColor,
              owner: null == (c2 = t2.meta) ? void 0 : c2.owner,
              description: null == (v2 = t2.meta) ? void 0 : v2.description,
              modified: null == (E2 = t2.meta) ? void 0 : E2.modified
            };
          },
          get isDragAndDropEnabled() {
            var y2;
            if (!(0, r._n)(t2)) return false;
            let { ugcUploadCenter: e3 } = (0, r.Zn)(t2);
            return !!((null == (y2 = t2.meta) ? void 0 : y2.canUserChange) && (t2.items.length > 1 || e3.getUploadingTracksByPlaylistKind(t2.meta.kind).length > 0));
          },
          get itemsKeys() {
            return t2.items.map((t3) => t3.key);
          },
          get isFavouritePlaylist() {
            var T2;
            return (null == (T2 = t2.meta) ? void 0 : T2.kind) === I.ji.LIKE;
          },
          get enableVariousAutoFlow() {
            return !!t2.filters.activeFilter;
          },
          get trackIds() {
            return t2.initialItems.map((t3) => String((0, h.V)(t3.id, t3.albumId)));
          },
          get isRewind2024Playlist() {
            var p2;
            return (null == (p2 = t2.meta) ? void 0 : p2.generatedPlaylistType) === "rewind2024";
          },
          get areAllTracksUploaded() {
            return t2.items.every((t3) => t3.loadingState === s.GuX.RESOLVE);
          },
          get shouldShowEmptyBlock() {
            var k2, b2;
            if (!(0, r._n)(t2)) return false;
            let { ugcUploadCenter: i2 } = (0, r.Zn)(t2), a2 = !!(null == (k2 = t2.meta) ? void 0 : k2.isOwnPlaylist), l2 = !!((null == (b2 = t2.meta) ? void 0 : b2.kind) && i2.getUploadingTracksByPlaylistKind(t2.meta.kind).length), n2 = !!t2.search.hasText;
            return e2.isEmptyPlaylist && a2 && !l2 && !n2;
          },
          get virtualListItemsCount() {
            var N2, f2;
            if (t2.search.hasText) return 0;
            return null != (f2 = null == (N2 = t2.items) ? void 0 : N2.length) ? f2 : 0;
          },
          get isFiltersAvailable() {
            var D2;
            return !!(e2.isFavouritePlaylist && (null == (D2 = t2.meta) ? void 0 : D2.isOwnPlaylist));
          },
          get analyticsParams() {
            return {
              objectId: t2.uuid || void 0,
              tabId: t2.filters.activeFilter,
              tabPos: t2.filters.analyticsParamsActiveFilterIndex
            };
          }
        };
        return e2;
      }).actions((t2) => {
        let e2 = {
          getTracksByRange: (0, r.L3)(function* (e3) {
            var i2, a2;
            let { startIndex: l2, endIndex: n2 } = e3, { tracksResource: d2, modelActionsLogger: o2 } = (0, r._$)(t2);
            if (!(null == (i2 = t2.meta) ? void 0 : i2.uid) || !(null == (a2 = t2.meta) ? void 0 : a2.kind)) return null;
            l2 = Math.max(0, l2), n2 = Math.min(n2, t2.items.length);
            let u2 = ((t3, e4) => {
              let { startIndex: i3, endIndex: a3 } = e4, l3 = [];
              for (let e5 = i3; e5 <= a3; e5++) {
                var r2, n3;
                ((null == (r2 = t3[e5]) ? void 0 : r2.loadingState) === s.GuX.IDLE || (null == (n3 = t3[e5]) ? void 0 : n3.loadingState) === s.GuX.REJECT) && l3.push(e5);
              }
              return l3;
            })(t2.items, { startIndex: l2, endIndex: n2 });
            try {
              let e4, i3 = (e4 = t2.items, u2.map((t3) => {
                let i4 = e4[t3];
                return (null == i4 ? void 0 : i4.albumId) ? "".concat(i4.id, ":").concat(i4.albumId) : String(null == i4 ? void 0 : i4.id);
              }));
              if (!i3.length) return null;
              u2.forEach((e5) => {
                let i4 = t2.items[e5];
                i4 && (i4.loadingState = s.GuX.PENDING);
              });
              let a3 = yield d2.getTracksMeta({ trackIds: i3, withProgress: true });
              u2.forEach((e5, i4) => {
                let l3 = null == a3 ? void 0 : a3[i4];
                if (t2.items[e5] && l3) {
                  var r2, n3;
                  t2.items[e5] = {
                    id: l3.id,
                    albumId: (null == (n3 = l3.albums) || null == (r2 = n3[0]) ? void 0 : r2.id) || null,
                    key: "".concat(l3.id, "-").concat(e5),
                    data: (0, g.vU)(l3),
                    loadingState: s.GuX.RESOLVE
                  };
                }
              });
            } catch (e4) {
              o2.error(e4), u2.forEach((e5) => {
                let i3 = t2.items[e5];
                i3 && (i3.loadingState = s.GuX.REJECT);
              });
            }
            return null;
          }),
          updateData: (0, r.L3)(function* (i2) {
            var a2, l2;
            if ((null == i2 ? void 0 : i2.error) === "not-found")
              return t2.errorStatusCode = S.X1.NOT_FOUND, t2.loadingState = s.GuX.REJECT, null;
            let { sonataState: n2, playlist: d2, experiments: o2, user: u2 } = (0, r.Zn)(t2);
            return t2.similarPlaylists = (0, r.wg)(null == (a2 = i2.similarPlaylists) ? void 0 : a2.map(y.Ew)), t2.meta = (0, y.ZC)(i2), (null == (l2 = t2.meta) ? void 0 : l2.isOwnFavouritePlaylist) && (t2.meta.visibility = u2.settings.userMusicVisibility), t2.items = (0, r.wg)(
              i2.tracks.map((t3, e3) => ({
                id: String(t3.id),
                albumId: t3.albumId || null,
                key: "".concat(t3.id, "-").concat(e3),
                loadingState: s.GuX.IDLE
              }))
            ), t2.initialItems = (0, v.HO)(t2.items), n2.setUnloadedEntitiesData(k(t2.items)), (null == o2 ? void 0 : o2.checkExperiment(s.zal.WebEditorsFeatures, "on")) && d2.editorFeature.getDuplicates(t2.items), yield e2.getTracksByRange({ startIndex: 0, endIndex: 10 });
          }),
          getPlaylistByUserIdAndKind: (0, r.L3)(function* (i2) {
            let { userId: a2, playlistKind: l2, resumeStream: n2 = false, trackMetaType: d2, preloadedPlaylist: o2 } = i2, { usersResource: u2, modelActionsLogger: g2 } = (0, r._$)(t2);
            if (t2.loadingState !== s.GuX.PENDING)
              try {
                t2.loadingState = s.GuX.PENDING;
                let i3 = o2;
                if (i3 || (i3 = yield u2.getPlaylistWithTracksIds({
                  userId: a2,
                  playlistKind: l2,
                  resumeStream: n2,
                  trackMetaType: d2
                })), t2.uuid = null == i3 ? void 0 : i3.playlistUuid, "string" != typeof i3.playlistUuid) {
                  t2.errorStatusCode = S.X1.NOT_FOUND, t2.loadingState = s.GuX.REJECT;
                  return;
                }
                yield e2.updateData(i3), t2.loadingState = s.GuX.RESOLVE;
              } catch (e3) {
                g2.error(e3), e3 instanceof S.GX && (e3.statusCode === S.X1.NOT_FOUND || e3.statusCode === S.X1.BAD_REQUEST) && (t2.errorStatusCode = S.X1.NOT_FOUND), t2.loadingState = s.GuX.REJECT;
              }
          }),
          getPlaylistByUuid: (0, r.L3)(function* (i2) {
            let { playlistUuid: a2, richTracks: l2 = false, resumeStream: n2 = false, preloadedPlaylist: d2 } = i2, { playlistResource: o2, modelActionsLogger: u2 } = (0, r._$)(t2);
            if (t2.uuid = a2, t2.loadingState !== s.GuX.PENDING)
              try {
                t2.loadingState = s.GuX.PENDING;
                let i3 = d2;
                i3 || (i3 = yield o2.getPlaylist({ playlistUuid: a2, resumeStream: n2, richTracks: l2 })), yield e2.updateData(i3), t2.loadingState !== s.GuX.IDLE && (t2.loadingState = s.GuX.RESOLVE);
              } catch (e3) {
                u2.error(e3), e3 instanceof S.GX && (e3.statusCode === S.X1.NOT_FOUND || e3.statusCode === S.X1.BAD_REQUEST) && (t2.errorStatusCode = S.X1.NOT_FOUND), t2.loadingState !== s.GuX.IDLE && (t2.loadingState = s.GuX.REJECT);
              }
          }),
          getSimilarEntities: (0, r.L3)(function* (e3) {
            let { playlistResource: i2, modelActionsLogger: a2 } = (0, r._$)(t2);
            if (!t2.similarEntities.isLoading)
              try {
                t2.similarEntities.loadingState = E.SQ.PENDING;
                let a3 = yield i2.getSimilarEntities(e3);
                t2.similarEntities.data = (0, E.Ds)(a3), t2.similarEntities.loadingState = E.SQ.RESOLVE;
              } catch (e4) {
                a2.error(e4), t2.similarEntities.loadingState = E.SQ.REJECT;
              }
          }),
          updatePlaylistTrackByUuid: (0, r.L3)(function* (i2) {
            let { playlistUuid: a2, richTracks: l2 = false, resumeStream: n2 = false } = i2, { playlistResource: d2, modelActionsLogger: o2 } = (0, r._$)(t2);
            t2.uuid = a2;
            try {
              let i3 = yield d2.getPlaylist({ playlistUuid: a2, resumeStream: n2, richTracks: l2 }), o3 = [];
              if (t2.items = (0, r.wg)(
                i3.tracks.map((e3, i4) => {
                  var a3, l3;
                  let r2 = String(e3.id), n3 = e3.albumId || null;
                  return r2 === (null == (a3 = t2.items[i4]) ? void 0 : a3.id) && n3 === (null == (l3 = t2.items[i4]) ? void 0 : l3.albumId) ? t2.items[i4] : (o3.push(i4), {
                    id: String(e3.id),
                    albumId: e3.albumId || null,
                    key: "".concat(e3.id, "-").concat(i4),
                    loadingState: s.GuX.IDLE
                  });
                })
              ), t2.meta && (t2.meta.modified = i3.modified, t2.meta.revision = i3.revision, o3.length)) {
                let t3 = Math.min(...o3), i4 = Math.max(...o3);
                e2.getTracksByRange({ startIndex: t3, endIndex: i4 });
              }
              if (t2.loadingState !== s.GuX.IDLE && (t2.loadingState = s.GuX.RESOLVE), (0, r._n)(t2)) {
                let { sonataState: e3 } = (0, r.Zn)(t2);
                e3.setUnloadedEntitiesData(k(t2.items));
              }
            } catch (e3) {
              o2.error(e3), e3 instanceof S.GX && (e3.statusCode === S.X1.NOT_FOUND || e3.statusCode === S.X1.BAD_REQUEST) && (t2.errorStatusCode = S.X1.NOT_FOUND), t2.loadingState !== s.GuX.IDLE && (t2.loadingState = s.GuX.REJECT);
            }
          }),
          moveTrack(e3, i2) {
            let a2 = (0, v.HO)(t2.items[e3]);
            if (!(e3 < 0) && !(i2 < 0) && !(e3 >= t2.items.length) && !(i2 >= t2.items.length) && a2 && (t2.items.splice(e3, 1), t2.items.splice(i2, 0, a2), (0, r._n)(t2))) {
              let { sonataState: e4 } = (0, r.Zn)(t2);
              e4.setUnloadedEntitiesData(k(t2.items));
            }
          },
          removeTracksFromItems(e3, i2) {
            if (t2.items.splice(e3, i2), (0, r._n)(t2)) {
              let { sonataState: e4 } = (0, r.Zn)(t2);
              e4.setUnloadedEntitiesData(k(t2.items));
            }
          },
          setItems(e3) {
            t2.items = (0, r.wg)((0, v.HO)(e3));
          },
          setShouldShowTrailerOnboarding(e3) {
            t2.shouldShowTrailerOnboarding = e3;
          },
          reset() {
            let { sonataState: e3 } = (0, r.Zn)(t2);
            e3.resetUnloadedEntitiesData(), t2.uuid = null, t2.loadingState = s.GuX.IDLE, t2.errorStatusCode = null, t2.shouldShowTrailerOnboarding = null, t2.similarEntities.data = void 0, t2.similarEntities.loadingState = E.SQ.IDLE, t2.search.setText(""), t2.search.reset(), t2.filters.reset(), t2.destroyItems([t2.meta, t2.items, t2.initialItems, t2.similarPlaylists]);
          },
          refresh() {
            var i2, a2;
            (null == (i2 = t2.meta) ? void 0 : i2.uuid) && e2.getPlaylistByUuid({ playlistUuid: null == (a2 = t2.meta) ? void 0 : a2.uuid, resumeStream: false });
          },
          refreshTracks() {
            var i2, a2;
            (null == (i2 = t2.meta) ? void 0 : i2.uuid) && e2.updatePlaylistTrackByUuid({
              playlistUuid: null == (a2 = t2.meta) ? void 0 : a2.uuid,
              resumeStream: false
            });
          }
        };
        return e2;
      });
      i(94094);
      var K = i(41390), P = i(5203);
    }
  }
]);
