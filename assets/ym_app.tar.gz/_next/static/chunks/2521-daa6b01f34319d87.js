(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2521],
  {
    1146: (e, t, a) => {
      "use strict";
      a.d(t, { MusicHistoryIntersectionObserverContext: () => i });
      let i = (0, a(61910).createContext)({ observeElement: () => {
      }, unobserveElement: () => {
      } });
    },
    22685: (e) => {
      e.exports = { date: "MusicHistoryTab_date__Fjy3P", content: "MusicHistoryTab_content__Jt15j" };
    },
    26303: (e, t, a) => {
      "use strict";
      var i;
      a.d(t, { D: () => i }), (function(e2) {
        e2.TRACK = "track", e2.WAVE = "wave", e2.ARTIST = "artist", e2.PLAYLIST = "playlist", e2.ALBUM = "album", e2.OTHER = "other", e2.SEARCH = "search";
      })(i || (i = {}));
    },
    37363: (e) => {
      e.exports = {
        header: "MusicHistoryBlock_header__sIFVC",
        vibeHeader: "MusicHistoryBlock_vibeHeader__HWzD5",
        vibeCover: "MusicHistoryBlock_vibeCover__RnM_6",
        vibeTextBlock: "MusicHistoryBlock_vibeTextBlock__nvhPk",
        heading: "MusicHistoryBlock_heading__HEfmk",
        headerTitle: "MusicHistoryBlock_headerTitle__Yhyst",
        content: "MusicHistoryBlock_content__S9lfi",
        artists: "MusicHistoryBlock_artists__AjuWP",
        artistLink: "MusicHistoryBlock_artistLink__yFHPE",
        shimmerTitle: "MusicHistoryBlock_shimmerTitle__Mx1IC"
      };
    },
    61019: (e) => {
      e.exports = {
        root: "MusicHistoryPage_root__FYB2m",
        scroll: "MusicHistoryPage_scroll__ykpDX",
        scrollContainer: "MusicHistoryPage_scrollContainer__eemvg",
        headerContainer: "MusicHistoryPage_headerContainer__QG0L3",
        header: "MusicHistoryPage_header__dzEvD",
        content: "MusicHistoryPage_content__j4evw",
        footer: "MusicHistoryPage_footer__Vu7aC",
        empty: "MusicHistoryPage_empty__fQRHA",
        carousel: "MusicHistoryPage_carousel__jcl8l",
        tabs: "MusicHistoryPage_tabs__v_5Zg",
        tab: "MusicHistoryPage_tab__WDE1e",
        tab_isLoading: "MusicHistoryPage_tab_isLoading__nNqd2",
        tab_selected: "MusicHistoryPage_tab_selected__nmn8P",
        date: "MusicHistoryPage_date__OV6rR",
        error: "MusicHistoryPage_error__9f_8i",
        important: "MusicHistoryPage_important__qNFO8"
      };
    },
    72645: (e, t, a) => {
      "use strict";
      a.d(t, {
        cY: () => b.MusicHistoryIntersectionObserverContext,
        UN: () => R,
        ln: () => E.MusicHistoryTab,
        WW: () => D,
        tM: () => i,
        Hp: () => r,
        uZ: () => s,
        QF: () => l,
        u: () => n,
        z: () => p,
        bg: () => S,
        kU: () => I,
        sr: () => A,
        Sv: () => x,
        lT: () => k.useFormatDate
      });
      let i = (e2) => e2.data.itemId.id, r = (e2) => e2.data.itemId.id, s = (e2) => {
        let { uid: t2, kind: a2 } = e2.data.itemId;
        return "".concat(t2, ":").concat(a2);
      }, l = (e2) => {
        let { albumId: t2, trackId: a2 } = e2.data.itemId;
        return t2 ? "".concat(a2, ":").concat(t2) : a2;
      }, n = (e2) => e2.data.itemId.seeds.sort().join(",");
      var o = a(93064), c = a(26303), d = a(94376), m = a(74125), u = a(21365);
      let v = (e2) => {
        if ("fullModel" in e2.data) {
          let { fullModel: t2 } = e2.data;
          return (0, o.wg)({ type: c.D.TRACK, id: l(e2), loadingState: m.GuX.RESOLVE, data: (0, u.vU)(t2) });
        }
        return (0, o.wg)({ type: c.D.TRACK, id: l(e2), data: null, loadingState: m.GuX.IDLE });
      };
      var y = a(63695), h = a(9348), _ = a(83909), g = a(76866);
      let x = (e2) => {
        var t2, a2;
        let l2 = null == (t2 = e2.items) ? void 0 : t2.map((e3) => {
          switch (e3.context.type) {
            case c.D.ALBUM:
              return ((e4, t3) => {
                let { data: a3 } = e4;
                if ("fullModel" in a3) {
                  let { fullModel: r2 } = a3;
                  return (0, o.wg)({
                    type: c.D.ALBUM,
                    available: r2.available,
                    id: i(e4),
                    meta: (0, d.sK)({ album: r2.album, artists: r2.artists }),
                    loadingState: m.GuX.RESOLVE,
                    tracks: t3.map(v)
                  });
                }
                return (0, o.wg)({
                  type: c.D.ALBUM,
                  available: true,
                  id: i(e4),
                  meta: null,
                  loadingState: m.GuX.IDLE,
                  tracks: t3.map(v)
                });
              })(e3.context, e3.tracks);
            case c.D.PLAYLIST:
              return ((e4, t3) => {
                let { data: a3, type: i2 } = e4;
                if ("fullModel" in a3) {
                  let { fullModel: r2 } = a3;
                  return (0, o.wg)({
                    type: i2,
                    id: s(e4),
                    meta: { ...(0, _.bk)({ playlist: r2.playlist }), tracksCount: r2.tracksCount },
                    loadingState: m.GuX.RESOLVE,
                    tracks: t3.map(v)
                  });
                }
                return (0, o.wg)({
                  type: c.D.PLAYLIST,
                  id: s(e4),
                  meta: null,
                  loadingState: m.GuX.IDLE,
                  tracks: t3.map(v)
                });
              })(e3.context, e3.tracks);
            case c.D.ARTIST:
              return ((e4, t3) => {
                let { data: a3, type: i2 } = e4;
                if ("fullModel" in a3) {
                  let { fullModel: s2 } = a3;
                  return (0, o.wg)({
                    type: i2,
                    available: s2.available,
                    id: r(e4),
                    meta: (0, y.as)({ artist: s2.artist }),
                    loadingState: m.GuX.RESOLVE,
                    tracks: t3.map(v)
                  });
                }
                return (0, o.wg)({
                  type: i2,
                  available: true,
                  id: r(e4),
                  meta: null,
                  loadingState: m.GuX.IDLE,
                  tracks: t3.map(v)
                });
              })(e3.context, e3.tracks);
            case c.D.WAVE:
              return ((e4, t3) => {
                let { data: a3, type: i2 } = e4;
                if ("fullModel" in a3) {
                  let { fullModel: r2 } = a3;
                  return (0, o.wg)({
                    type: i2,
                    id: n(e4),
                    meta: {
                      ...(0, g.er)(r2.wave),
                      imageUrl: r2.simpleWaveForegroundImageUrl,
                      backgroundColor: r2.simpleWaveBackgroundColor
                    },
                    loadingState: m.GuX.RESOLVE,
                    tracks: t3.map(v)
                  });
                }
                return (0, o.wg)({ type: i2, id: n(e4), meta: null, loadingState: m.GuX.IDLE, tracks: t3.map(v) });
              })(e3.context, e3.tracks);
            case c.D.SEARCH:
            case c.D.OTHER:
              return ((e4, t3) => {
                let { type: a3 } = e4;
                return (0, o.wg)({ type: a3, id: (0, h.A)(), tracks: t3.map(v) });
              })(e3.context, e3.tracks);
            default:
              return null;
          }
        }).filter((e3) => e3);
        return { date: e2.date, blocks: null != (a2 = (0, o.wg)(l2)) ? a2 : null };
      };
      var b = a(1146);
      let p = (e2) => (null == e2 ? void 0 : e2.type) === c.D.ALBUM, S = (e2) => (null == e2 ? void 0 : e2.type) === c.D.ARTIST, I = (e2) => (null == e2 ? void 0 : e2.type) === c.D.PLAYLIST, A = (e2) => (null == e2 ? void 0 : e2.type) === c.D.WAVE;
      var k = a(87803), C = a(26433), M = a(89461);
      let H = (e2) => ({ type: M.z4.Unloaded, meta: { id: e2.entityId } }), T = o.gK.compose(
        o.gK.model("MusicHistoryTrack", {
          type: o.gK.literal(c.D.TRACK),
          id: o.gK.string,
          data: o.gK.maybeNull(u.vj)
        }),
        C.XT
      ).views((e2) => ({
        get key() {
          return "".concat(e2.type, "_").concat(e2.id);
        },
        get isShimmerVisible() {
          return e2.isNeededToLoad || e2.isLoading || e2.isRejected;
        },
        get isShimmerActive() {
          return e2.isLoading;
        },
        get entityId() {
          var t2;
          if (!e2.data) return e2.id;
          let { id: a2, albums: i2 } = e2.data, r2 = null == (t2 = i2[0]) ? void 0 : t2.id;
          return r2 ? "".concat(a2, ":").concat(r2) : a2;
        }
      })).named("MusicHistoryPlaylist"), j = o.gK.compose(o.gK.model("MusicHistoryBaseBlock", { id: o.gK.string, tracks: o.gK.array(T) }), C.XT).views((e2) => ({
        get isShimmerVisible() {
          return e2.isNeededToLoad || e2.isLoading || e2.isRejected;
        },
        get isShimmerActive() {
          return e2.isLoading;
        },
        get contextId() {
          return e2.id;
        },
        get entitiesData() {
          return e2.tracks.map(H);
        }
      })), L = j.props({ type: o.gK.literal(c.D.ALBUM), available: o.gK.boolean, meta: o.gK.maybeNull(d.JC) }).views((e2) => ({
        get key() {
          return "".concat(e2.type, "_").concat(e2.id);
        },
        get autoflowSeeds() {
          var t2;
          return ["album:".concat(null == (t2 = e2.meta) ? void 0 : t2.id)];
        }
      })).named("MusicHistoryAlbum"), N = j.props({ type: o.gK.literal(c.D.ARTIST), available: o.gK.boolean, meta: o.gK.maybeNull(y.PK) }).views((e2) => ({
        get key() {
          return "".concat(e2.type, "_").concat(e2.id);
        },
        get autoflowSeeds() {
          var t2;
          return ["artist:".concat(null == (t2 = e2.meta) ? void 0 : t2.id)];
        }
      })).named("MusicHistoryArtist"), P = o.gK.model("MusicHistoryCommon", {
        id: o.gK.string,
        type: o.gK.union(o.gK.literal(c.D.OTHER), o.gK.literal(c.D.SEARCH)),
        tracks: o.gK.array(T)
      }).views((e2) => ({
        get key() {
          return "".concat(e2.type, "_").concat(e2.id);
        },
        get contextId() {
          return e2.tracks.map((e3) => e3.id).join(",");
        },
        get entitiesData() {
          return e2.tracks.map(H);
        }
      })), f = j.props({ type: o.gK.literal(c.D.PLAYLIST), meta: o.gK.maybeNull(_.IP) }).views((e2) => ({
        get key() {
          return "".concat(e2.type, "_").concat(e2.id);
        },
        get autoflowSeeds() {
          var t2, a2;
          return [
            "playlist:".concat(null == (t2 = e2.meta) ? void 0 : t2.uid, "_").concat(null == (a2 = e2.meta) ? void 0 : a2.kind)
          ];
        }
      })).named("MusicHistoryPlaylist"), w = j.props({ id: o.gK.string, type: o.gK.literal(c.D.WAVE), meta: o.gK.maybeNull(g.Gh) }).views((e2) => ({
        get key() {
          return "".concat(e2.type, "_").concat(e2.id);
        },
        get contextId() {
          var t2, a2;
          return null != (a2 = null == (t2 = e2.meta) ? void 0 : t2.stationId) ? a2 : m.M19;
        },
        get autoflowSeeds() {
          var i2;
          return null == (i2 = e2.meta) ? void 0 : i2.seeds;
        }
      })), K = o.gK.union(L, N, f, w, P), R = o.gK.compose(
        o.gK.model({
          id: o.gK.string,
          type: o.gK.enumeration(Object.values(c.D)),
          tabIndex: o.gK.number,
          blockIndex: o.gK.number,
          trackIndex: o.gK.maybeNull(o.gK.number)
        }),
        C.XT
      ), D = o.gK.model("MusicHistoryTab", { date: o.gK.string, blocks: o.gK.maybeNull(o.gK.array(K)) });
      var E = a(93724);
    },
    75237: (e) => {
      e.exports = { trackShimmer: "MusicHistoryTrack_trackShimmer__yxcx9" };
    },
    87803: (e, t, a) => {
      "use strict";
      a.d(t, { useFormatDate: () => s });
      var i = a(61910), r = a(43426);
      let s = () => {
        let { formatDate: e2, formatRelativeTime: t2 } = (0, r.A)();
        return (0, i.useCallback)(
          function(a2) {
            let i2 = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1], r2 = new Date(a2), s2 = /* @__PURE__ */ new Date();
            r2.setHours(0, 0, 0, 0), s2.setHours(0, 0, 0, 0);
            let l = (r2.getTime() - s2.getTime()) / 864e5, n = t2(l, "day", { numeric: "auto" }), o = e2(a2, { day: "numeric", month: "long" });
            switch (l) {
              case 0:
              case -1:
              case -2:
                if (i2) return "".concat(n, ", ").concat(o);
                return n;
              default:
                return o;
            }
          },
          [e2, t2]
        );
      };
    },
    92346: (e) => {
      e.exports = {
        shimmersContainer: "MusicHistoryPageContentShimmer_shimmersContainer__82cj6",
        dateShimmer: "MusicHistoryPageContentShimmer_dateShimmer__d4_te",
        contextNameShimmer: "MusicHistoryPageContentShimmer_contextNameShimmer__Tzbqr",
        contextHeaderShimmer: "MusicHistoryPageContentShimmer_contextHeaderShimmer__Tq0PZ",
        trackListShimmers: "MusicHistoryPageContentShimmer_trackListShimmers__4GSp8"
      };
    },
    92521: (e, t, a) => {
      "use strict";
      a.d(t, { MusicHistoryPage: () => C });
      var i = a(54486), r = a(50420), s = a(28303), l = a(61910), n = a(47713), o = a(31500), c = a(56231), d = a(51321), m = a(97800), u = a(72645), v = a(82644), y = a(74125), h = a(80585), _ = a(85360);
      let g = (e2) => {
        let { children: t2 } = e2, a2 = (0, l.useRef)({}), r2 = (0, l.useMemo)(
          () => (0, _.Gv)((e3) => {
            var t3, i2;
            let r3 = (0, _.L5)(e3.target), s3 = a2.current[r3];
            e3.isIntersecting ? null == s3 || null == (t3 = s3.onShow) || t3.call(s3) : null == s3 || null == (i2 = s3.onHide) || i2.call(s3);
          }),
          []
        );
        (0, l.useEffect)(() => () => null == r2 ? void 0 : r2.disconnect(), [r2]);
        let s2 = (0, l.useCallback)(
          (e3) => {
            !a2.current[e3.elementId] && e3.elementRef.current && (null == r2 || r2.observe(e3.elementRef.current), a2.current[e3.elementId] = e3);
          },
          [r2]
        ), n2 = (0, l.useCallback)(
          (e3) => {
            let t3 = a2.current[e3];
            t3 && t3.elementRef.current && (null == r2 || r2.unobserve(t3.elementRef.current));
          },
          [r2]
        ), o2 = (0, l.useMemo)(() => ({ observeElement: s2, unobserveElement: n2 }), [s2, n2]);
        return (0, i.jsx)(u.cY.Provider, { value: o2, children: t2 });
      }, x = async (e2, t2) => new Promise((a2) => {
        if ("onscrollend" in window) {
          var i2;
          let r2 = () => {
            var e3;
            a2(), null == (e3 = t2.current) || e3.removeEventListener("scrollend", r2);
          };
          null == (i2 = t2.current) || i2.addEventListener("scrollend", r2), e2.scrollIntoView({ behavior: "smooth" });
        } else e2.scrollIntoView({ behavior: "smooth" }), window.setTimeout(a2, 1e3);
      });
      var b = a(61019), p = a.n(b), S = a(22674), I = a(92346), A = a.n(I);
      let k = (e2) => {
        let { isActive: t2 } = e2, a2 = (0, i.jsxs)("div", {
          className: A().trackListShimmers,
          children: [
            (0, i.jsx)(h.DS, { isActive: t2, variant: y.Xjt.PLAYLIST }),
            (0, i.jsx)(h.DS, { isActive: t2, variant: y.Xjt.PLAYLIST }),
            (0, i.jsx)(h.DS, { isActive: t2, variant: y.Xjt.PLAYLIST })
          ]
        });
        return (0, i.jsxs)("div", {
          className: A().shimmersContainer,
          children: [
            (0, i.jsx)(S.Shimmer, { isActive: t2, className: A().dateShimmer }),
            (0, i.jsx)(S.Shimmer, { isActive: t2, className: A().contextNameShimmer }),
            (0, i.jsx)(h.Mo, { withDescription: true, className: A().contextHeaderShimmer }),
            a2,
            (0, i.jsx)(S.Shimmer, { isActive: t2, className: A().contextNameShimmer }),
            (0, i.jsx)(h.Mo, { coverRadius: "round", className: A().contextHeaderShimmer }),
            a2
          ]
        });
      }, C = (0, s.PA)(() => {
        let [e2, t2] = (0, l.useState)(false), { musicHistory: a2 } = (0, y.Pjs)(), { contentScrollRef: s2, setContentScrollRef: _2 } = (0, y.gKY)(), b2 = (0, d.useTabsState)(0), S2 = (0, l.useRef)(false), I2 = (0, l.useRef)(null), A2 = (0, l.useCallback)(
          async (e3) => {
            var i2;
            t2(true);
            let r2 = a2.dates[e3];
            if (!r2) return;
            null == (i2 = b2.onTabChange) || i2.call(b2, e3), S2.current = true;
            let l2 = document.querySelector('[data-date-anchor="'.concat(r2, '"]'));
            l2 && (I2.current = s2, await x(l2, I2)), S2.current = false;
          },
          [a2.dates, b2, s2]
        ), C2 = (0, l.useCallback)(() => {
          if (S2.current) return;
          let e3 = a2.dates.findIndex((e4) => a2.datesMap.get(e4));
          if (e3 >= 0) {
            var t3;
            null == (t3 = b2.onTabChange) || t3.call(b2, e3);
          }
        }, [a2.dates, a2.datesMap, b2]);
        (0, l.useEffect)(() => () => a2.reset(), [a2]), (0, y.Jzs)(a2.isResolved);
        let M = (0, l.useMemo)(() => {
          var t3;
          return a2.isRejected ? (0, i.jsx)(v.w, { className: (0, r.$)(p().error, p().important), withBackwardControl: false }) : a2.isShimmerVisible ? (0, i.jsx)(k, { isActive: a2.isShimmerActive }) : a2.isEmpty ? (0, i.jsx)("div", {
            className: p().empty,
            children: (0, i.jsx)(m.Caption, {
              variant: "div",
              size: "m",
              weight: "normal",
              children: (0, i.jsx)(n.A, { id: "music-history.empty-title" })
            })
          }) : null == (t3 = a2.tabs) ? void 0 : t3.map(
            (t4, a3) => (0, i.jsx)(
              u.ln,
              {
                onTabShowOrHide: C2,
                "data-intersection-property-id": t4.date,
                tab: t4,
                tabIndex: a3,
                shouldHideInactiveTab: e2
              },
              a3
            )
          );
        }, [C2, a2.isEmpty, a2.isRejected, a2.isShimmerActive, a2.isShimmerVisible, a2.tabs, e2]), H = (0, u.lT)(), T = (0, l.useMemo)(
          () => (0, i.jsx)(h.wI, {
            isShimmerVisible: a2.isShimmerVisible,
            className: p().tabs,
            ...b2,
            onTabChange: A2,
            shimmer: (0, i.jsx)(h.zr, {
              className: p().tabs,
              shimmerClassName: (0, r.$)(p().tab, { [p().tab_isLoading]: a2.isShimmerVisible }),
              count: 5
            }),
            children: a2.dates.map(
              (e3, t3) => (0, i.jsx)(
                h.oz,
                {
                  className: (0, r.$)(p().tab, { [p().tab_selected]: t3 === b2.value }),
                  titleClassName: p().date,
                  "aria-label": H(e3, false),
                  title: H(e3, false),
                  value: t3
                },
                t3
              )
            )
          }),
          [H, A2, a2.dates, a2.isShimmerVisible, b2]
        );
        return a2.isNeededToLoad && (0, l.use)(a2.getMusicHistory()), (0, i.jsx)(y.nVz, {
          pageId: y._Q$.HISTORY,
          children: (0, i.jsxs)("div", {
            className: p().root,
            ...(0, o.Am)(o.Xk.musicHistory.MUSIC_HISTORY_PAGE),
            children: [
              (0, i.jsxs)("div", {
                className: p().headerContainer,
                children: [
                  (0, i.jsxs)("div", {
                    className: p().header,
                    children: [
                      (0, i.jsx)(h.Lh, { withForwardControl: false }),
                      (0, i.jsx)(m.Heading, {
                        variant: "h1",
                        weight: "bold",
                        size: "xl",
                        lineClamp: 1,
                        children: (0, i.jsx)(n.A, { id: "music-history.title" })
                      })
                    ]
                  }),
                  (0, i.jsx)(h.FY, { className: p().carousel, carouselElement: T })
                ]
              }),
              (0, i.jsxs)(c.N, {
                ref: _2,
                className: p().scroll,
                containerClassName: p().scrollContainer,
                children: [
                  (0, i.jsx)(g, { children: (0, i.jsx)("div", { className: p().content, children: M }) }),
                  (0, i.jsx)(h.A, { children: (0, i.jsx)(h.wi, { className: p().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    93724: (e, t, a) => {
      "use strict";
      a.d(t, { MusicHistoryTab: () => E });
      var i = a(54486), r = a(28303), s = a(61910), l = a(31500), n = a(26303), o = a(97800), c = a(74125), d = a(1146), m = a(87803), u = a(50420), v = a(47713), y = a(63585), h = a(63695), _ = a(80585);
      let g = (e2) => {
        let { entityId: t2, from: a2 } = e2;
        return {
          contextData: { type: y.K.Various, meta: { id: t2 }, from: a2 },
          queueParams: { index: 0 },
          loadContextMeta: true
        };
      }, x = (e2) => {
        let { id: t2, tabIndex: a2, blockIndex: i2, trackIndex: r2 } = e2, { musicHistory: l2 } = (0, c.Pjs)(), n2 = (0, s.useId)(), o2 = (0, s.useRef)(null), { observeElement: m2, unobserveElement: u2 } = (0, s.useContext)(d.MusicHistoryIntersectionObserverContext);
        return (0, s.useEffect)(() => {
          let e3 = void 0 !== r2 ? "".concat(a2, "_").concat(i2, "_").concat(r2, "_").concat(t2) : "".concat(a2, "_").concat(i2, "_").concat(t2), s2 = l2.indexesMap.get(e3);
          l2.isInObservationRange(s2) && m2({
            elementRef: o2,
            elementId: n2,
            index: s2,
            onShow() {
              l2.getItems(this.index), u2(n2);
            }
          });
        }, [i2, t2, n2, l2, m2, a2, r2, u2]), { intersectionPropertyId: n2, ref: o2 };
      };
      var b = a(21365), p = a(75237), S = a.n(p);
      let I = (0, r.PA)((e2) => {
        let { type: t2, track: a2, artists: r2, tabIndex: s2, blockIndex: l2, trackIndex: n2, playContextParams: o2 } = e2, { ref: d2, intersectionPropertyId: m2 } = x({ id: a2.id, tabIndex: s2, blockIndex: l2, trackIndex: n2 });
        return a2.isShimmerVisible || !a2.data ? (0, i.jsx)("div", {
          "data-intersection-property-id": m2,
          ref: d2,
          children: (0, i.jsx)(_.DS, {
            isActive: a2.isShimmerActive,
            "data-intersection-property-id": m2,
            className: S().trackShimmer,
            variant: t2 === y.K.Album ? c.Xjt.ALBUM : c.Xjt.PLAYLIST
          })
        }) : t2 === y.K.Album ? (0, i.jsx)(b.FR, { track: a2.data, position: a2.data.index, albumArtists: r2, playContextParams: o2 }) : (0, i.jsx)(b.Kt, { track: a2.data, playContextParams: o2 });
      });
      var A = a(37363), k = a.n(A);
      let C = (0, r.PA)((e2) => {
        var t2, a2, r2, n2, d2;
        let { album: m2, tabIndex: b2, blockIndex: p2 } = e2, { ref: S2, intersectionPropertyId: A2 } = x({ id: m2.id, tabIndex: b2, blockIndex: p2 }), { from: C2 } = (0, c.fyy)({ blockId: "album-".concat(m2.id) }), M2 = (0, s.useMemo)(() => {
          var e3, t3;
          return m2.available ? (0, i.jsx)(h.iQ, {
            className: k().artists,
            linkClassName: k().artistLink,
            artists: null == (e3 = m2.meta) ? void 0 : e3.artists,
            lineClamp: 1
          }) : null == (t3 = m2.meta) ? void 0 : t3.artistNames;
        }, [m2.available, null == (t2 = m2.meta) ? void 0 : t2.artistNames, null == (a2 = m2.meta) ? void 0 : a2.artists]), H2 = (0, s.useMemo)(() => {
          var e3, t3, a3;
          return m2.isShimmerVisible ? (0, i.jsx)(_.Mo, { isActive: m2.isShimmerActive, className: k().header, withDescription: true }) : (0, i.jsx)(_.Tw, {
            className: k().header,
            coverUrl: null == (e3 = m2.meta) ? void 0 : e3.coverUri,
            title: null == (t3 = m2.meta) ? void 0 : t3.title,
            titleSize: "xs",
            titleLineClamp: 1,
            description: M2,
            titleClassName: k().headerTitle,
            viewAllActionLink: null == (a3 = m2.meta) ? void 0 : a3.url,
            available: m2.available,
            fallbackIconVariant: "album",
            headingVariant: "h4",
            withCover: true,
            withDescription: !!M2
          });
        }, [
          m2.available,
          m2.isShimmerActive,
          m2.isShimmerVisible,
          null == (r2 = m2.meta) ? void 0 : r2.coverUri,
          null == (n2 = m2.meta) ? void 0 : n2.title,
          null == (d2 = m2.meta) ? void 0 : d2.url,
          M2
        ]), T2 = (0, s.useMemo)(
          () => m2.tracks.map((e3, t3) => {
            var a3;
            let r3 = g({ entityId: e3.entityId, from: C2 });
            return (0, i.jsx)(
              I,
              { type: y.K.Album, track: e3, playContextParams: r3, tabIndex: b2, blockIndex: p2, trackIndex: t3 },
              null == (a3 = e3.data) ? void 0 : a3.getKey(t3)
            );
          }),
          [m2.tracks, C2, b2, p2]
        );
        return (0, i.jsxs)("section", {
          className: k().root,
          ref: S2,
          "data-intersection-property-id": A2,
          ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_ALBUM_BLOCK),
          children: [
            (0, i.jsx)(o.Heading, {
              className: (0, u.$)(k().header, k().heading),
              variant: "h3",
              ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_BLOCK_TYPE_ALBUM),
              children: (0, i.jsx)(v.A, { id: "music-history.album" })
            }),
            H2,
            (0, i.jsx)("div", { className: k().content, children: T2 })
          ]
        });
      }), M = (0, r.PA)((e2) => {
        var t2, a2, r2;
        let { artist: n2, tabIndex: d2, blockIndex: m2 } = e2, { ref: h2, intersectionPropertyId: b2 } = x({ id: n2.id, tabIndex: d2, blockIndex: m2 }), { from: p2 } = (0, c.fyy)({ blockId: "artist-".concat(n2.id) }), S2 = (0, s.useMemo)(() => {
          var e3, t3, a3;
          return n2.isShimmerVisible ? (0, i.jsx)(_.Mo, { isActive: n2.isShimmerActive, className: k().header, coverRadius: "round" }) : (0, i.jsx)(_.Tw, {
            titleSize: "xs",
            titleLineClamp: 1,
            className: k().header,
            coverUrl: null == (e3 = n2.meta) ? void 0 : e3.coverUri,
            title: null == (t3 = n2.meta) ? void 0 : t3.name,
            titleClassName: k().headerTitle,
            viewAllActionLink: null == (a3 = n2.meta) ? void 0 : a3.url,
            available: n2.available,
            withCover: true,
            coverRadius: "round",
            headingVariant: "h4"
          });
        }, [
          n2.available,
          n2.isShimmerActive,
          n2.isShimmerVisible,
          null == (t2 = n2.meta) ? void 0 : t2.coverUri,
          null == (a2 = n2.meta) ? void 0 : a2.name,
          null == (r2 = n2.meta) ? void 0 : r2.url
        ]), A2 = (0, s.useMemo)(
          () => n2.tracks.map((e3, t3) => {
            var a3;
            let r3 = g({ entityId: e3.entityId, from: p2 });
            return (0, i.jsx)(
              I,
              { type: y.K.Artist, track: e3, playContextParams: r3, tabIndex: d2, blockIndex: m2, trackIndex: t3 },
              null == (a3 = e3.data) ? void 0 : a3.getKey(t3)
            );
          }),
          [n2.tracks, p2, d2, m2]
        );
        return (0, i.jsxs)("section", {
          className: k().root,
          ref: h2,
          "data-intersection-property-id": b2,
          ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_ARTIST_BLOCK),
          children: [
            (0, i.jsx)(o.Heading, {
              className: (0, u.$)(k().header, k().heading),
              variant: "h3",
              ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_BLOCK_TYPE_ARTIST),
              children: (0, i.jsx)(v.A, { id: "music-history.artist" })
            }),
            S2,
            (0, i.jsx)("div", { className: k().content, children: A2 })
          ]
        });
      });
      var H = a(29064), T = a(54460);
      let j = (0, r.PA)((e2) => {
        let { common: t2, tabIndex: a2, blockIndex: r2 } = e2, { ref: d2, intersectionPropertyId: m2 } = x({ id: t2.id, tabIndex: a2, blockIndex: r2 }), { from: h2 } = (0, c.fyy)(), _2 = ((e3) => (0, s.useMemo)(
          () => e3 === n.D.SEARCH ? (0, T.tW)({ contextType: y.K.Various, contextId: "", entityContextType: H.h.MUSIC_HISTORY_SEARCH }) : null,
          [e3]
        ))(t2.type), b2 = (0, s.useMemo)(
          () => t2.tracks.map((e3, t3) => {
            var s2;
            let l2 = g({ entityId: e3.entityId, from: h2 });
            return (0, i.jsx)(
              I,
              { playContextParams: l2, type: y.K.Various, track: e3, tabIndex: a2, blockIndex: r2, trackIndex: t3 },
              null == (s2 = e3.data) ? void 0 : s2.getKey(t3)
            );
          }),
          [t2.tracks, h2, a2, r2]
        ), p2 = (0, s.useMemo)(() => {
          switch (t2.type) {
            case n.D.OTHER:
              return (0, i.jsx)(v.A, { id: "music-history.shuffle" });
            case n.D.SEARCH:
              return (0, i.jsx)(v.A, { id: "music-history.search" });
          }
        }, [t2.type]);
        return (0, i.jsx)(c._Fn, {
          sourceContextData: _2,
          children: (0, i.jsxs)("section", {
            className: k().root,
            ref: d2,
            "data-intersection-property-id": m2,
            ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_COMMON_BLOCK),
            children: [
              (0, i.jsx)(o.Heading, {
                className: (0, u.$)(k().header, k().heading),
                variant: "h3",
                ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_BLOCK_TYPE_COMMON),
                children: p2
              }),
              (0, i.jsx)("div", { className: k().content, children: b2 })
            ]
          })
        });
      });
      var L = a(43426);
      let N = (0, r.PA)((e2) => {
        var t2, a2, r2, n2, d2;
        let { playlist: m2, tabIndex: h2, blockIndex: b2 } = e2, { ref: p2, intersectionPropertyId: S2 } = x({ id: m2.id, tabIndex: h2, blockIndex: b2 }), { from: A2 } = (0, c.fyy)({
          blockId: m2.isResolved ? "playlist-".concat(null == (t2 = m2.meta) ? void 0 : t2.id) : ""
        }), { formatMessage: C2 } = (0, L.A)(), M2 = (0, s.useMemo)(() => {
          var e3, t3, a3, r3;
          return m2.isShimmerVisible ? (0, i.jsx)(_.Mo, { isActive: m2.isShimmerActive, className: k().header, withDescription: true }) : (0, i.jsx)(_.Tw, {
            className: k().header,
            titleSize: "xs",
            titleLineClamp: 1,
            coverUrl: null == (e3 = m2.meta) ? void 0 : e3.coverUri,
            title: null == (t3 = m2.meta) ? void 0 : t3.title,
            titleClassName: k().headerTitle,
            description: C2(
              { id: "entity-names.number-of-tracks" },
              { counter: null == (a3 = m2.meta) ? void 0 : a3.tracksCount }
            ),
            fallbackIconVariant: "playlist",
            withCover: true,
            viewAllActionLink: null == (r3 = m2.meta) ? void 0 : r3.url,
            headingVariant: "h4",
            withDescription: true
          });
        }, [
          C2,
          m2.isShimmerActive,
          m2.isShimmerVisible,
          null == (a2 = m2.meta) ? void 0 : a2.coverUri,
          null == (r2 = m2.meta) ? void 0 : r2.title,
          null == (n2 = m2.meta) ? void 0 : n2.tracksCount,
          null == (d2 = m2.meta) ? void 0 : d2.url
        ]), H2 = (0, s.useMemo)(
          () => m2.tracks.map((e3, t3) => {
            var a3;
            let r3 = g({ entityId: e3.entityId, from: A2 });
            return (0, i.jsx)(
              I,
              { playContextParams: r3, type: y.K.Playlist, track: e3, tabIndex: h2, blockIndex: b2, trackIndex: t3 },
              null == (a3 = e3.data) ? void 0 : a3.getKey(t3)
            );
          }),
          [m2.tracks, A2, h2, b2]
        );
        return (0, i.jsxs)("section", {
          className: k().root,
          ref: p2,
          "data-intersection-property-id": S2,
          ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_PLAYLIST_BLOCK),
          children: [
            (0, i.jsx)(o.Heading, {
              className: (0, u.$)(k().header, k().heading),
              variant: "h3",
              ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_BLOCK_TYPE_PLAYLIST),
              children: (0, i.jsx)(v.A, { id: "music-history.playlist" })
            }),
            M2,
            (0, i.jsx)("div", { className: k().content, children: H2 })
          ]
        });
      });
      var P = a(8817), f = a(27510), w = a(76866);
      let K = (0, r.PA)((e2) => {
        var t2, a2, r2, n2, d2, m2;
        let { vibe: h2, blockIndex: b2, tabIndex: p2 } = e2, {
          experiments: S2,
          settings: { isMobile: A2 }
        } = (0, c.Pjs)(), { pageId: C2 } = (0, c.$au)(), { blockIdForFrom: M2 } = (0, c.N8n)(), H2 = (0, c.PT7)(), { isFreemium: T2 } = (0, c.XCI)(), [j2, L2] = (0, s.useState)(false), {
          isPlaying: N2,
          togglePlay: K2,
          isCurrent: R2
        } = (0, c.B0S)({
          seeds: (null == (t2 = h2.meta) ? void 0 : t2.seeds) || [c.M19],
          pageIdForFrom: C2,
          blockIdForFrom: M2
        }), D2 = (0, s.useId)(), E2 = S2.checkExperiment(c.zal.WebNextVibeDescription, "on"), { ref: B, intersectionPropertyId: O } = x({ id: h2.id, blockIndex: b2, tabIndex: p2 }), { from: V } = (0, c.fyy)({ blockId: "wave-".concat(h2.id) }), U = (0, P.c)(() => {
          if (!H2()) {
            if (T2) return void L2(true);
            K2();
          }
        }), Y = (0, P.c)((e3) => {
          if (A2 || 2 === e3.detail) return void U();
        }), X = (0, f.L)(() => {
          var e3, t3, a3, i2, r3, s2, l2, n3;
          return E2 ? {
            title: null == (e3 = h2.meta) ? void 0 : e3.title,
            description: null == (i2 = h2.meta) ? void 0 : i2.getDescription(
              null != (n3 = null == (t3 = h2.meta) ? void 0 : t3.title) ? n3 : null == (a3 = h2.meta) ? void 0 : a3.description
            )
          } : {
            title: null != (l2 = null == (r3 = h2.meta) ? void 0 : r3.title) ? l2 : null == (s2 = h2.meta) ? void 0 : s2.description
          };
        }), z = (0, s.useCallback)(() => {
          var e3, t3, a3, r3, s2;
          return (null == (e3 = h2.meta) ? void 0 : e3.shouldShowAgent) && (null == (t3 = h2.meta) ? void 0 : t3.agent) ? (0, i.jsx)(w.nr, {
            agent: h2.meta.agent,
            isPlaying: N2,
            isCurrent: R2,
            onPlayButtonClick: U,
            className: k().vibeCover,
            playButtonIconSize: "m"
          }) : (0, i.jsx)(_.q1, {
            isCurrent: R2,
            isPlaying: N2,
            isAvailable: true,
            onPlayButtonClick: U,
            title: null == (a3 = h2.meta) ? void 0 : a3.title,
            entityCoverStyle: { backgroundColor: null == (r3 = h2.meta) ? void 0 : r3.backgroundColor },
            ariaDescribedBy: D2,
            coverUri: null == (s2 = h2.meta) ? void 0 : s2.imageUrl,
            radius: "round",
            withLoadingIndicator: false,
            className: k().vibeCover,
            playButtonIconSize: "m"
          });
        }, [
          U,
          R2,
          N2,
          D2,
          null == (a2 = h2.meta) ? void 0 : a2.agent,
          null == (r2 = h2.meta) ? void 0 : r2.backgroundColor,
          null == (n2 = h2.meta) ? void 0 : n2.imageUrl,
          null == (d2 = h2.meta) ? void 0 : d2.shouldShowAgent,
          null == (m2 = h2.meta) ? void 0 : m2.title
        ]), F = (0, f.L)(() => {
          var e3;
          return h2.isShimmerVisible ? (0, i.jsx)(_.Mo, { isActive: h2.isShimmerActive, className: k().header, coverRadius: "round" }) : (0, i.jsxs)(_.Cj, {
            className: (0, u.$)(k().header, k().vibeHeader),
            onClick: Y,
            ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_HEADER),
            children: [
              (0, i.jsx)(_.SU, {
                isOpened: j2,
                onOpenChange: L2,
                isEnabled: T2,
                placement: "bottom",
                textVariant: "vibe",
                vibeTextVariant: null == (e3 = h2.meta) ? void 0 : e3.stationType,
                renderChildren: z
              }),
              (0, i.jsx)(_.Tw, {
                titleSize: "xs",
                titleLineClamp: 1,
                headingVariant: "h4",
                labeledForId: D2,
                className: k().vibeTextBlock,
                ...X
              })
            ]
          });
        }), G = (0, s.useMemo)(
          () => h2.tracks.map((e3, t3) => {
            var a3;
            let r3 = g({ entityId: e3.entityId, from: V });
            return (0, i.jsx)(
              I,
              { playContextParams: r3, type: y.K.Vibe, track: e3, blockIndex: b2, tabIndex: p2, trackIndex: t3 },
              null == (a3 = e3.data) ? void 0 : a3.getKey(t3)
            );
          }),
          [h2.tracks, V, p2, b2]
        );
        return (0, i.jsxs)("section", {
          className: k().root,
          ref: B,
          "data-intersection-property-id": O,
          ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_VIBE_BLOCK),
          children: [
            !E2 && (0, i.jsx)(o.Heading, {
              className: (0, u.$)(k().header, k().heading),
              variant: "h3",
              ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_BLOCK_TYPE_VIBE),
              children: (0, i.jsx)(v.A, { id: "music-history.my-vibe" })
            }),
            F,
            (0, i.jsx)("div", { className: k().content, children: G })
          ]
        });
      });
      var R = a(22685), D = a.n(R);
      let E = (0, r.PA)((e2) => {
        let { tab: t2, tabIndex: a2, onTabShowOrHide: r2, shouldHideInactiveTab: u2, ...v2 } = e2, { musicHistory: y2 } = (0, c.Pjs)(), h2 = (0, s.useMemo)(() => {
          var e3;
          return null == (e3 = t2.blocks) ? void 0 : e3.map((e4, t3) => {
            switch (e4.type) {
              case n.D.ALBUM:
                return (0, i.jsx)(C, { album: e4, blockIndex: t3, tabIndex: a2 }, "".concat(e4.key, "_").concat(t3));
              case n.D.PLAYLIST:
                return (0, i.jsx)(
                  N,
                  { playlist: e4, blockIndex: t3, tabIndex: a2 },
                  "".concat(e4.key, "_").concat(t3)
                );
              case n.D.WAVE:
                return (0, i.jsx)(K, { vibe: e4, blockIndex: t3, tabIndex: a2 }, "".concat(e4.key, "_").concat(t3));
              case n.D.ARTIST:
                return (0, i.jsx)(
                  M,
                  { artist: e4, blockIndex: t3, tabIndex: a2 },
                  "".concat(e4.key, "_").concat(t3)
                );
              case n.D.SEARCH:
              case n.D.OTHER:
                return (0, i.jsx)(
                  j,
                  { common: e4, blockIndex: t3, tabIndex: a2 },
                  "".concat(e4.key, "_").concat(t3)
                );
              default:
                return null;
            }
          }).filter((e4) => e4);
        }, [t2.blocks, a2]), _2 = (0, m.useFormatDate)(), g2 = (0, s.useRef)(null), { observeElement: x2 } = (0, s.useContext)(d.MusicHistoryIntersectionObserverContext), b2 = y2.datesMap.get(t2.date);
        return (0, s.useEffect)(() => {
          x2({
            elementId: t2.date,
            elementRef: g2,
            index: 0,
            onShow: () => {
              y2.setDatesMap(t2.date, true), r2();
            },
            onHide: () => {
              y2.setDatesMap(t2.date, false), r2();
            }
          });
        }, [y2, y2.datesMap, x2, r2, t2.date]), (0, i.jsxs)("div", {
          "aria-hidden": !b2 && u2,
          ref: g2,
          "data-intersection-property-id": t2.date,
          className: D().root,
          ...v2,
          ...{ inert: !!(!b2 && u2) },
          ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB),
          children: [
            (0, i.jsx)(o.Heading, {
              "data-date-anchor": t2.date,
              className: D().date,
              variant: "h2",
              size: "m",
              ...(0, l.Am)(l.e8.musicHistory.MUSIC_HISTORY_TAB_DATE),
              children: _2(t2.date)
            }),
            (0, i.jsx)("div", { className: D().content, children: h2 })
          ]
        });
      });
    }
  }
]);
