"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2556],
  {
    2556: (e, t, r) => {
      r.r(t), r.d(t, {
        HlsCoreAdapter: () => _,
        HtmlAudioCoreAdapter: () => w,
        YaspCoreAdapter: () => g,
        YaspLoader: () => m,
        checkBuffering: () => T,
        getRemainingBufferedTime: () => f
      });
      var s = r(96559), n = r(99809), i = r(35606);
      async function o(e2) {
        let t2 = [
          ["vpuid", i.$],
          ["version", e2 == null ? void 0 : e2.version],
          ["testid", isFinite(e2.testid) ? String(e2.testid) : void 0],
          ["bundleurl", e2 == null ? void 0 : e2.bundleUrl]
        ].filter(([e3, t3]) => !!t3).map((e3) => e3.join("=")).join("&");
        try {
          var r2, s2;
          let i2 = e2.hostname || "frontend.vh.yandex.ru", o2 = t2 ? `?${t2}` : "";
          await (r2 = `https://${i2}/get_player/${e2.file}${o2}`, s2 = e2.checkLoad, (0, n.I)({
            src: r2,
            async: false,
            retries: 3,
            dropCacheOnRetry: true,
            onBeforeLoad: (e3) => {
              e3.crossOrigin = "use-credentials";
            },
            checkLoad: s2
          }));
        } catch (e3) {
          throw e3;
        }
      }
      function a(e2) {
        try {
          return e2();
        } catch {
          return;
        }
      }
      let l = (0, r(42018).x)();
      async function h(e2) {
        var _a;
        if ((_a = a(() => l.Ya)) == null ? void 0 : _a.YaspVideoElement) return Promise.resolve();
        await o({
          file: "yasp.js",
          version: e2 == null ? void 0 : e2.version,
          testid: e2 == null ? void 0 : e2.testid,
          bundleUrl: e2 == null ? void 0 : e2.bundleUrl,
          checkLoad: () => {
            var _a2;
            return !!((_a2 = a(() => l.Ya)) == null ? void 0 : _a2.preloadYaspScripts);
          }
        }), await l.Ya.preloadYaspScripts();
      }
      var d = r(56258);
      class u extends d.t {
        constructor(e2 = "[Sonata] YASP loading aborted", { code: t2 = "E_SONATA", ...r2 } = {}) {
          super(e2, { code: t2, ...r2 }), (0, s._)(this, "name", "YaspLoadingAbortedException"), Object.setPrototypeOf(this, u.prototype);
        }
      }
      class m {
        get isYaspLoaded() {
          return void 0 !== window.Ya && void 0 !== window.Ya.YaspAudioElement;
        }
        loadYasp(e2) {
          let { version: t2, sourceLimit: r2, retryDelayMs: s2, abortSignal: n2 } = e2;
          if (this.isYaspLoaded) return Promise.resolve();
          let i2 = null != s2 ? s2 : 1e3, o2 = null;
          return new Promise((e3, s3) => {
            if (null == n2 ? void 0 : n2.aborted) return void s3(new u());
            let a2 = () => {
              o2 && clearTimeout(o2), s3(new u());
            };
            null == n2 || n2.addEventListener("abort", a2, { once: true });
            let l2 = () => {
              if (null == n2 ? void 0 : n2.aborted) return void s3(new u());
              h({ version: t2 }).then(() => {
                var t3;
                null == n2 || n2.removeEventListener("abort", a2);
                let s4 = window.Ya.YaspAudioElement;
                s4.messenger.on("yasp-event", this.yaspEventHandler), null == (t3 = this.yaspTelemetry) || t3.setStaticParams({ testIds: this.telemetryTestIds }), s4.setWorkerConfig({ sourceLimit: r2 }), e3();
              }).catch((e4) => {
                let r3 = new d.t("[Sonata] Error in loading YASP", { code: "E_SONATA", cause: e4 });
                this.logger.error(r3, { yaspVersion: t2 }), new Promise((e5) => {
                  o2 = setTimeout(e5, i2);
                }).then(() => l2());
              });
            };
            l2();
          });
        }
        yaspEventHandler(e2) {
          var t2;
          null == (t2 = this.yaspTelemetry) || t2.logYaspEvent(e2.name, e2.data);
        }
        getYaspAudioElement() {
          if (!this.isYaspLoaded) throw new d.t("YaspAudioElement has not been loaded");
          return window.Ya.YaspAudioElement;
        }
        attachYasp(e2) {
          let t2 = window.Ya.YaspAudioElement;
          if (!this.isYaspLoaded) throw new d.t("YaspAudioElement has not been loaded");
          t2.isYaspAudioElement(e2) || t2.attach(e2);
        }
        constructor({ logger: e2, yaspTelemetry: t2, telemetryTestIds: r2 }) {
          (0, s._)(this, "logger", void 0), (0, s._)(this, "yaspTelemetry", void 0), (0, s._)(this, "telemetryTestIds", void 0), this.logger = e2, this.yaspTelemetry = t2, this.telemetryTestIds = r2, this.yaspEventHandler = this.yaspEventHandler.bind(this);
        }
      }
      var c = r(52599), p = r(89130);
      function E(e2) {
        let t2 = [];
        for (let r2 = 0; r2 < e2.buffered.length; r2++)
          try {
            t2.push({ start: (0, p.fP)(e2.buffered.start(r2)), end: (0, p.fP)(e2.buffered.end(r2)) });
          } catch (e3) {
          }
        return (function(e3) {
          if (e3.length <= 1) return e3;
          let t3 = e3.slice().sort((e4, t4) => e4.start - t4.start), r2 = t3[0] ? [t3[0]] : [];
          for (let e4 = 1; e4 < t3.length; e4++) {
            let s2 = t3[e4], n2 = r2[r2.length - 1];
            s2 && n2 && (n2.end < s2.start ? r2.push(s2) : n2.end < s2.end && (n2.end = s2.end));
          }
          return r2;
        })(t2);
      }
      function f(e2) {
        let t2 = E(e2), r2 = t2[t2.length - 1];
        if (!r2) return (0, p.fP)(0);
        let s2 = r2.end - e2.currentTime;
        return (0, p.fP)(Number(s2.toFixed(3)));
      }
      class v {
        setupAudioElement() {
          this.audioElement.autoplay = false, this.audioElement.loop = false, this.audioElement.preload = "auto", this.audioElement.crossOrigin = "anonymous", this.audioElement.addEventListener("timeupdate", this.progressHandler), this.audioElement.addEventListener("durationchange", this.progressHandler), this.audioElement.addEventListener("pause", this.pauseHandler), this.audioElement.addEventListener("error", this.audioErrorHandler), this.audioElement.addEventListener("volumechange", this.volumeChangeHandler), this.audioElement.addEventListener("ratechange", this.speedChangeHandler);
        }
        get source() {
          return this.audioElement;
        }
        async play(e2) {
          let { source: t2, positionSec: r2 } = e2;
          this.audioElement.src = t2.src, this.audioElement.load(), await this.audioElement.play(), void 0 !== r2 && (this.audioElement.currentTime = r2);
        }
        setSrc(e2) {
          let { source: t2, positionSec: r2 } = e2;
          this.audioElement.src = t2.src, this.audioElement.load(), void 0 !== r2 && (this.audioElement.currentTime = r2);
        }
        preloadSrc(e2) {
          return Promise.resolve();
        }
        releaseSrc(e2) {
          return Promise.resolve();
        }
        pause() {
          return this.audioElement.pause(), Promise.resolve();
        }
        async resume() {
          await this.audioElement.play(), this.emitter.emit("resume");
        }
        setProgress(e2) {
          let t2 = e2 >= this.audioElement.duration ? this.audioElement.duration - 0.01 : e2;
          return this.audioElement.currentTime = t2, Promise.resolve(this.audioElement.currentTime);
        }
        setVolume(e2) {
          return this.audioElement.volume = e2, Promise.resolve(this.audioElement.volume);
        }
        setSpeed(e2) {
          return this.audioElement.defaultPlaybackRate = e2, this.audioElement.playbackRate = e2, Promise.resolve(this.audioElement.playbackRate);
        }
        stop() {
          return this.audioElement.removeAttribute("src"), this.audioElement.load(), Promise.resolve();
        }
        onEnd(e2) {
          this.audioElement.addEventListener("ended", e2);
        }
        onPaused(e2) {
          this.emitter.on("custom_pause_event", e2);
        }
        pauseHandler() {
          Math.abs(this.audioElement.duration - this.audioElement.currentTime) >= 0.01 && this.emitter.emit("custom_pause_event");
        }
        onResume(e2) {
          this.emitter.on("resume", e2);
        }
        onUpdatingProgress(e2) {
          this.emitter.on("update_progress", e2);
        }
        progressHandler() {
          let e2 = isNaN(this.audioElement.duration) ? 0 : this.audioElement.duration, t2 = this.audioElement.currentTime, r2 = this.audioElement.buffered.length ? this.audioElement.buffered.end(this.audioElement.buffered.length - 1) : 0;
          this.emitter.emit("update_progress", {
            duration: e2,
            position: t2,
            loaded: r2,
            remainingBufferedTime: f(this.audioElement)
          });
        }
        onSeeked(e2) {
          this.audioElement.addEventListener("seeked", e2);
        }
        onSeeking(e2) {
          this.audioElement.addEventListener("seeking", e2);
        }
        onStalled(e2) {
          this.audioElement.addEventListener("stalled", e2);
        }
        onCanplay(e2) {
          this.audioElement.addEventListener("canplay", e2);
        }
        onPlaying(e2) {
          this.audioElement.addEventListener("playing", e2);
        }
        onError(e2) {
          this.emitter.on("error", e2);
        }
        onVolumeChange(e2) {
          this.emitter.on("volumechange", e2);
        }
        volumeChangeHandler() {
          this.emitter.emit("volumechange", this.audioElement.volume);
        }
        onSpeedChange(e2) {
          this.emitter.on("ratechange", e2);
        }
        speedChangeHandler() {
          this.emitter.emit("ratechange", this.audioElement.playbackRate);
        }
        audioErrorHandler(e2) {
          this.emitter.emit("error", e2);
        }
        onWaiting(e2) {
          this.audioElement.addEventListener("waiting", e2);
        }
        offEnd(e2) {
          this.audioElement.removeEventListener("ended", e2);
        }
        offPaused(e2) {
          this.emitter.off("custom_pause_event", e2);
        }
        offResume(e2) {
          this.emitter.off("resume", e2);
        }
        offUpdatingProgress(e2) {
          this.emitter.off("update_progress", e2);
        }
        offSeeked(e2) {
          this.audioElement.removeEventListener("seeked", e2);
        }
        offSeeking(e2) {
          this.audioElement.removeEventListener("seeking", e2);
        }
        offStalled(e2) {
          this.audioElement.removeEventListener("stalled", e2);
        }
        offCanplay(e2) {
          this.audioElement.removeEventListener("canplay", e2);
        }
        offPlaying(e2) {
          this.audioElement.removeEventListener("playing", e2);
        }
        offError(e2) {
          this.audioElement.removeEventListener("error", e2);
        }
        offVolumeChange(e2) {
          this.emitter.off("volumechange", e2);
        }
        offSpeedChange(e2) {
          this.emitter.off("ratechange", e2);
        }
        offWaiting(e2) {
          this.audioElement.removeEventListener("waiting", e2);
        }
        constructor() {
          (0, s._)(this, "emitter", new c.b()), this.progressHandler = this.progressHandler.bind(this), this.volumeChangeHandler = this.volumeChangeHandler.bind(this), this.speedChangeHandler = this.speedChangeHandler.bind(this), this.audioErrorHandler = this.audioErrorHandler.bind(this), this.pauseHandler = this.pauseHandler.bind(this);
        }
      }
      function y(e2) {
        try {
          return new URL(e2);
        } catch (e3) {
          return null;
        }
      }
      class g extends v {
        yaspEventHandler(e2) {
          var t2;
          null == (t2 = this.yaspTelemetry) || t2.logYaspEvent(e2.detail.name, e2.detail.data);
        }
        yaspErrorHandler(e2) {
          var t2;
          null == (t2 = this.yaspTelemetry) || t2.logYaspError(e2);
        }
        play(e2) {
          let { source: t2, positionSec: r2 } = e2;
          window.Ya.YaspAudioElement.configureSource(t2.src, { audioDecodingKey: t2.key, mirrorUrls: t2.mirrorUrls }), t2.positionSec = r2;
          let s2 = this.audioElement.src, n2 = t2.src;
          this.audioElement.src = n2;
          let i2 = Promise.resolve();
          return !(function(e3, t3) {
            let r3 = y(e3), s3 = y(t3);
            return !!r3 && !!s3 && "".concat(r3.origin).concat(r3.pathname) === "".concat(s3.origin).concat(s3.pathname);
          })(s2, n2) && (i2 = this.audioElement.yaspReleaseSrc(s2)), i2.finally(
            () => this.audioElement.play().catch((e3) => {
              if ("string" != typeof e3 || "Source loading interrupted: new source requested before previous load completed" !== e3)
                throw e3;
            })
          );
        }
        preloadSrc(e2) {
          let { source: t2, bufferGoal: r2, positionSec: s2 } = e2;
          return t2.canBePreloaded ? (t2.positionSec = s2, this.audioElement.yaspPreloadSrc(t2.src, {
            yaspSourceConfig: { preloadBufferGoal: r2, audioDecodingKey: t2.key, mirrorUrls: t2.mirrorUrls }
          }).then(() => Promise.resolve())) : Promise.resolve();
        }
        releaseSrc(e2) {
          let { source: t2 } = e2;
          return this.audioElement.yaspReleaseSrc(t2.src).then(() => Promise.resolve());
        }
        setSrc(e2) {
          let { source: t2, positionSec: r2 } = e2;
          window.Ya.YaspAudioElement.configureSource(t2.src, { audioDecodingKey: t2.key, mirrorUrls: t2.mirrorUrls }), t2.positionSec = r2, this.audioElement.src = t2.src;
        }
        setProgress(e2) {
          var t2;
          return null == (t2 = this.yaspTelemetry) || t2.onSeek(this.audioElement.currentTime, e2), super.setProgress(e2);
        }
        stop() {
          return this.audioElement.yaspReleaseSrc(this.audioElement.src).then(), super.stop();
        }
        detachYasp() {
          this.audioElement.removeEventListener("yasp-event", this.yaspEventHandler), this.audioElement.removeEventListener("yasp-error", this.yaspErrorHandler), this.audioElement.detach();
        }
        constructor({ yaspAudioElement: e2, yaspTelemetry: t2 }) {
          super(), (0, s._)(this, "audioElement", void 0), (0, s._)(this, "yaspTelemetry", void 0), this.audioElement = e2.attach(document.createElement("audio")), this.yaspTelemetry = t2, this.yaspEventHandler = this.yaspEventHandler.bind(this), this.yaspErrorHandler = this.yaspErrorHandler.bind(this), this.setupAudioElement(), this.audioElement.addEventListener("yasp-event", this.yaspEventHandler), this.audioElement.addEventListener("yasp-error", this.yaspErrorHandler);
        }
      }
      var L = r(6028);
      class _ extends v {
        play(e2) {
          let { source: t2 } = e2;
          return this.stop().then(
            () => (this.hls || this.initHls(), this.load(t2.src).then(() => this.audioElement.play()))
          );
        }
        stop() {
          return this.removeAllHlsEvents(), this.removeErrorListener(), this.removeProgramDateTimeListener(), this.retryCounter = 0, this.hls && (this.hls.stopLoad(), this.hls.destroy(), this.hls = null), this.audioElement.removeAttribute("src"), this.audioElement.load(), Promise.resolve();
        }
        initHls() {
          this.hls || (this.hls = new L.Ay({ liveDurationInfinity: true, maxBufferSize: 3e6 }), this.setErrorListener(this.errorListener), this.setProgramDateTimeListener(this.onFragChanged));
        }
        load(e2) {
          return this.hls ? (this.hls.attachMedia(this.audioElement), this.hls.loadSource(e2), new Promise((e3) => {
            this.addOnceHlsEvent(L.sV.MANIFEST_PARSED, () => {
              this.hls && this.hls.startLoad();
            }), this.addOnceHlsEvent(L.sV.MEDIA_ATTACHED, () => {
              e3();
            });
          })) : Promise.resolve();
        }
        destroyHls() {
          this.stop();
        }
        addOnceHlsEvent(e2, t2) {
          this.hls && (this.hls.once(e2, t2), this.hlsListeners.push({ event: e2, listener: t2, once: true }));
        }
        removeAllHlsEvents() {
          this.hlsListeners.forEach((e2) => {
            this.hls && this.hls.off(e2.event, e2.listener, void 0, e2.once);
          }), this.hlsListeners = [];
        }
        errorListener(e2, t2) {
          if (this.hls)
            switch (t2.type) {
              case L.wU.NETWORK_ERROR:
                if (this.retryCounter++, this.retryCounter > this.hlsErrorRetryLimit) {
                  this.destroyHls();
                  let e3 = new d.t("HLS error", { data: t2 });
                  this.emitter.emit("error", e3);
                } else this.hls.startLoad();
                break;
              case L.Ay.ErrorTypes.MEDIA_ERROR:
                this.hls.recoverMediaError();
                break;
              default:
                this.destroyHls(), this.emitter.emit("error", new d.t("HLS error", { data: t2 }));
            }
        }
        setErrorListener(e2) {
          this.removeErrorListener(), this.hls && (this.hlsJsErrorListener = e2, this.hls.on(L.sV.ERROR, e2));
        }
        removeErrorListener() {
          this.hls && this.hlsJsErrorListener && this.hls.off(L.sV.ERROR, this.hlsJsErrorListener), this.hlsJsErrorListener = null;
        }
        onFragChanged(e2, t2) {
          var r2;
          (null == (r2 = t2.frag) ? void 0 : r2.programDateTime) && this.onProgramDateTimeUpdate && this.onProgramDateTimeUpdate(t2.frag.programDateTime);
        }
        setProgramDateTimeListener(e2) {
          this.removeProgramDateTimeListener(), this.hls && (this.programDateTimeListener = e2, this.hls.on(L.sV.FRAG_CHANGED, this.programDateTimeListener));
        }
        removeProgramDateTimeListener() {
          this.hls && this.programDateTimeListener && this.hls.off(L.sV.FRAG_CHANGED, this.programDateTimeListener), this.programDateTimeListener = null;
        }
        constructor(e2) {
          super(), (0, s._)(this, "audioElement", document.createElement("audio")), (0, s._)(this, "hls", null), (0, s._)(this, "retryCounter", 0), (0, s._)(this, "hlsErrorRetryLimit", void 0), (0, s._)(this, "hlsJsErrorListener", null), (0, s._)(this, "programDateTimeListener", null), (0, s._)(this, "onProgramDateTimeUpdate", void 0), (0, s._)(this, "hlsListeners", []), this.setupAudioElement(), this.hlsErrorRetryLimit = e2.hlsErrorRetryLimit, this.onProgramDateTimeUpdate = e2.onProgramDateTimeUpdate, this.errorListener = this.errorListener.bind(this), this.onFragChanged = this.onFragChanged.bind(this), this.initHls();
        }
      }
      class w extends v {
        constructor() {
          super(), (0, s._)(this, "audioElement", document.createElement("audio")), this.setupAudioElement();
        }
      }
      let b = (0, p.fP)(0.15);
      function T(e2) {
        let { currentTime: t2, duration: r2 } = e2;
        return e2.readyState < e2.HAVE_FUTURE_DATA || !E(e2).some((e3) => {
          let { start: s2, end: n2 } = e3;
          return !(t2 < s2) && !(t2 > n2) && (r2 <= n2 || t2 + b < n2);
        });
      }
    },
    42018: (e, t, r) => {
      r.d(t, { x: () => s });
      function s() {
        return "object" == typeof self ? self : "object" == typeof window ? window : globalThis;
      }
    },
    46412: (e) => {
      var t = Object.prototype.hasOwnProperty, r = "~";
      function s() {
      }
      function n(e2, t2, r2) {
        this.fn = e2, this.context = t2, this.once = r2 || false;
      }
      function i(e2, t2, s2, i2, o2) {
        if ("function" != typeof s2) throw TypeError("The listener must be a function");
        var a2 = new n(s2, i2 || e2, o2), l = r ? r + t2 : t2;
        return e2._events[l] ? e2._events[l].fn ? e2._events[l] = [e2._events[l], a2] : e2._events[l].push(a2) : (e2._events[l] = a2, e2._eventsCount++), e2;
      }
      function o(e2, t2) {
        0 == --e2._eventsCount ? e2._events = new s() : delete e2._events[t2];
      }
      function a() {
        this._events = new s(), this._eventsCount = 0;
      }
      Object.create && (s.prototype = /* @__PURE__ */ Object.create(null), new s().__proto__ || (r = false)), a.prototype.eventNames = function() {
        var e2, s2, n2 = [];
        if (0 === this._eventsCount) return n2;
        for (s2 in e2 = this._events) t.call(e2, s2) && n2.push(r ? s2.slice(1) : s2);
        return Object.getOwnPropertySymbols ? n2.concat(Object.getOwnPropertySymbols(e2)) : n2;
      }, a.prototype.listeners = function(e2) {
        var t2 = r ? r + e2 : e2, s2 = this._events[t2];
        if (!s2) return [];
        if (s2.fn) return [s2.fn];
        for (var n2 = 0, i2 = s2.length, o2 = Array(i2); n2 < i2; n2++) o2[n2] = s2[n2].fn;
        return o2;
      }, a.prototype.listenerCount = function(e2) {
        var t2 = r ? r + e2 : e2, s2 = this._events[t2];
        return s2 ? s2.fn ? 1 : s2.length : 0;
      }, a.prototype.emit = function(e2, t2, s2, n2, i2, o2) {
        var a2 = r ? r + e2 : e2;
        if (!this._events[a2]) return false;
        var l, h, d = this._events[a2], u = arguments.length;
        if (d.fn) {
          switch (d.once && this.removeListener(e2, d.fn, void 0, true), u) {
            case 1:
              return d.fn.call(d.context), true;
            case 2:
              return d.fn.call(d.context, t2), true;
            case 3:
              return d.fn.call(d.context, t2, s2), true;
            case 4:
              return d.fn.call(d.context, t2, s2, n2), true;
            case 5:
              return d.fn.call(d.context, t2, s2, n2, i2), true;
            case 6:
              return d.fn.call(d.context, t2, s2, n2, i2, o2), true;
          }
          for (h = 1, l = Array(u - 1); h < u; h++) l[h - 1] = arguments[h];
          d.fn.apply(d.context, l);
        } else {
          var m, c = d.length;
          for (h = 0; h < c; h++)
            switch (d[h].once && this.removeListener(e2, d[h].fn, void 0, true), u) {
              case 1:
                d[h].fn.call(d[h].context);
                break;
              case 2:
                d[h].fn.call(d[h].context, t2);
                break;
              case 3:
                d[h].fn.call(d[h].context, t2, s2);
                break;
              case 4:
                d[h].fn.call(d[h].context, t2, s2, n2);
                break;
              default:
                if (!l) for (m = 1, l = Array(u - 1); m < u; m++) l[m - 1] = arguments[m];
                d[h].fn.apply(d[h].context, l);
            }
        }
        return true;
      }, a.prototype.on = function(e2, t2, r2) {
        return i(this, e2, t2, r2, false);
      }, a.prototype.once = function(e2, t2, r2) {
        return i(this, e2, t2, r2, true);
      }, a.prototype.removeListener = function(e2, t2, s2, n2) {
        var i2 = r ? r + e2 : e2;
        if (!this._events[i2]) return this;
        if (!t2) return o(this, i2), this;
        var a2 = this._events[i2];
        if (a2.fn) a2.fn !== t2 || n2 && !a2.once || s2 && a2.context !== s2 || o(this, i2);
        else {
          for (var l = 0, h = [], d = a2.length; l < d; l++)
            (a2[l].fn !== t2 || n2 && !a2[l].once || s2 && a2[l].context !== s2) && h.push(a2[l]);
          h.length ? this._events[i2] = 1 === h.length ? h[0] : h : o(this, i2);
        }
        return this;
      }, a.prototype.removeAllListeners = function(e2) {
        var t2;
        return e2 ? (t2 = r ? r + e2 : e2, this._events[t2] && o(this, t2)) : (this._events = new s(), this._eventsCount = 0), this;
      }, a.prototype.off = a.prototype.removeListener, a.prototype.addListener = a.prototype.on, a.prefixed = r, a.EventEmitter = a, e.exports = a;
    },
    52599: (e, t, r) => {
      r.d(t, { b: () => s });
      var s = r(46412);
    },
    99809: (e, t, r) => {
      r.d(t, { I: () => i });
      let s = () => {
      }, n = (e2) => true;
      function i(e2) {
        return new Promise((t2, r2) => {
          !(function(e3) {
            let { dropCacheOnRetry: t3 = false, onBeforeLoad: r3 = s, retries: i2 = 0 } = e3;
            if (e3.checkLoad && e3.checkLoad()) {
              e3.onLoad && e3.onLoad();
              return;
            }
            let o = r3, a = 0;
            t3 && i2 > 0 && (o = (e4) => {
              if (r3(e4), a > 0) {
                var t4;
                let r4, s2 = -1 === e4.src.indexOf("?") ? "?" : "&", n2 = (t4 = a, Number.isFinite(r4 = Math.floor(1e9 * Math.random()) % 1e9) || (r4 = 0), r4 += Date.now() % 1e9, String(t4) + r4.toString(36));
                e4.src += s2 + n2;
              }
              a++;
            }), (function e4(t4) {
              let {
                src: r4,
                win: i3 = window,
                charset: o2 = "utf-8",
                async: a2 = true,
                retries: l = 0,
                onRetry: h = s,
                retryDelay: d = 0,
                checkLoad: u = n,
                onBeforeLoad: m = s,
                onLoad: c = s,
                onError: p = s
              } = t4, E = i3.document.createElement("script"), f = (s2) => {
                var _a;
                l > 0 ? (h(s2), e4({ ...t4, src: r4, retries: l - 1 })) : p(s2), (_a = E.parentNode) == null ? void 0 : _a.removeChild(E);
              };
              E.type = "text/javascript", E.async = a2, E.onload = () => u(E) ? c() : f(Error(`checkLoad for ${r4} failed`)), E.onerror = (e5) => {
                try {
                  i3.setTimeout(() => {
                    f(e5);
                  }, d);
                } catch {
                }
              }, E.src = r4, E.charset = o2, m(E), (function(e5) {
                let t5 = e5.document, r5 = t5.getElementsByTagName("head")[0];
                return r5 || (r5 = t5.createElement("head"), t5.documentElement.appendChild(r5)), r5;
              })(i3).appendChild(E);
            })({ ...e3, onBeforeLoad: o });
          })({ ...e2, onLoad: t2, onError: r2 });
        });
      }
    }
  }
]);
