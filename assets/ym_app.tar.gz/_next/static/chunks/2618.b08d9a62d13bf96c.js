"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2618],
  {
    2618: (e, t, r) => {
      r.d(t, { createDesktopContainer: () => ey });
      var o = r(89885), n = r(74338), g = r(9348), i = r(15209), a = r(21220), l = r(58900), c = r(79850), u = r(84690), s = r(34965), m = r(18258), p = r(36211), d = r(5892), w = r(40080), G = r(81658), x = r(79817), A = r(88660), f = r(52962), h = r(96992), v = r(48448), k = r(93076), E = r(36788), L = r(35566), U = r(64659), H = r(63988), _ = r(37934), R = r(79329), T = r(12774), B = r(24252), V = r(29372), X = r(10582), Q = r(13696), y = r(78226), C = r(94150), b = r(92103), D = r(3463), P = r(24120), M = r(55948), S = r(80535), N = r(38689), q = r(50218), O = r(34720), Z = r(54280), $ = r(99676), Y = r(86420), K = r(33716), W = r(30508), I = r(95198), z = r(10560), J = r(54924), F = r(74922), j = r(16068), ee = r(41778), et = r(29449), er = r(3327), eo = r(87716), en = r(42132), eg = r(81760), ei = r(2936), ea = r(40168), el = r(12460), ec = r(98313), eu = r(25289), es = r(24269), em = r(65630), ep = r(7029), ed = r(74875), ew = r(62901), eG = r(27493), ex = r(12979), eA = r(558);
      class ef {
        onChangeLanguage() {
          window.location.reload();
        }
      }
      var eh = r(59433), ev = r(90579), ek = r(37343), eE = r(47339), eL = r(37538), eU = r(5808), eH = r(90461), e_ = r(78171), eR = r(45628), eT = r(67454), eB = r(65098), eV = r(88246), eX = r(13871), eQ = r(6556);
      async function ey(e2) {
        let { tld: t2, env: r2 } = e2, ey2 = (0, eQ.J)(await (0, ex.z)(r2)), eC = await (0, eG.B)(r2), eb = {};
        return new l.Dt().registerMany({
          [eT.SX]: (0, l.Gr)(() => r2),
          [eT.tw]: (0, l.Gr)(() => ey2),
          [eT.P0]: (0, l.Gr)(() => new a.q(eC)),
          [eT.Zi]: (0, l.Gr)(() => new eA.Y(eb))
        }).register(
          eT.WA,
          (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.Zi);
            return new eR.V(t3);
          })
        ).registerMany({
          [eT.Zf]: (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.P0).get(ew.qV);
            return new m.r({
              maxLogLevel: s.cm.DEBUG,
              secureFields: ek.x,
              disableLogToConsole: !t3,
              additionalData: {
                get puid() {
                  return e3.get(eT.WA).getPassportUid();
                }
              }
            });
          }),
          [eT.TK]: (0, l.Gr)(
            (e3) => new ((0, ev.b)(m.r))({
              maxLogLevel: s.cm.DEBUG,
              secureFields: ek.x,
              disableLogToConsole: "development" !== e3.get(eT.SX),
              additionalData: {
                get puid() {
                  return e3.get(eT.WA).getPassportUid();
                }
              }
            })
          ),
          [eT.oo]: (0, l.Gr)(() => new ec.si()),
          [eT.DP]: (0, l.Gr)(() => new ec.MJ("client ".concat("desktop"), "cookie")),
          [eT.U2]: (0, l.Gr)(() => new ec.si()),
          [eT.vH]: (0, l.Gr)(() => new ec.fW()),
          [eT.Xc]: (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.oo), r3 = e3.get(eT.Zf);
            return new eh.E({
              isBuildTypeDesktop: true,
              logger: r3,
              changeLanguageHandler: new ef(),
              storage: {
                get: () => t3.get(eH.c.SavedUserLanguage),
                set(e4) {
                  t3.set(eH.c.SavedUserLanguage, e4);
                }
              }
            });
          })
        }).registerMany({
          [eT.y$]: (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.Zf), r3 = e3.get(eT.oo), o2 = new el.Mz({
              config: { useEntitiesStorage: true, useFileStorage: true, useResponseCacheStorage: true },
              plugins: [new el.wK({ logger: t3 })]
            });
            return o2.createCacheController({
              repositoryContainer: o2.repositoryContainer,
              variables: {
                get uid() {
                  return r3.get(eH.c.YmUid);
                },
                get isOffline() {
                  return !!o2.network.status.isOffline;
                }
              }
            }), o2;
          }),
          [eT.Hm]: (0, l.P9)(
            () => function() {
              let e3 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
              return new u.Q(e3);
            }
          ),
          [eT.gu]: (0, l.P9)(
            () => function() {
              let e3 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
              return new c.S(e3);
            }
          )
        }).registerMany({
          [eT.QG]: (0, l.Gr)((e3) => new ep.G(e3.get(eT.oo), e3.get(eT.tw), e3.get(eT.Xc).getLanguage())),
          [eT.OP]: (0, l.P9)(
            (e3) => function() {
              var t3, r3, o2, n2, g2;
              let i2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a2 = arguments.length > 1 ? arguments[1] : void 0, l2 = e3.get(eT.Zf), c2 = e3.get(eT.U2), u2 = new ek.N(l2), {
                resources: { musicExternalApi: s2 }
              } = e3.get(eT.tw);
              i2.timeout = s2.defaultTimeout, i2.hooks = {
                afterResponse: [...(null == i2 || null == (t3 = i2.hooks) ? void 0 : t3.afterResponse) || []],
                beforeError: [
                  u2.beforeErrorHook,
                  ...(null == i2 || null == (r3 = i2.hooks) ? void 0 : r3.beforeError) || []
                ],
                beforeRequest: [eV.x, ...(null == i2 || null == (o2 = i2.hooks) ? void 0 : o2.beforeRequest) || []],
                afterTimeout: [
                  u2.beforeErrorHook,
                  ...(null == i2 || null == (n2 = i2.hooks) ? void 0 : n2.afterTimeout) || []
                ],
                beforeRetry: [
                  eX.i,
                  u2.beforeRetryHook,
                  ...(null == i2 || null == (g2 = i2.hooks) ? void 0 : g2.beforeRetry) || []
                ]
              };
              let m2 = a2(i2);
              return (0, el.sY)(m2, {
                get isOffline() {
                  return (0, eE.g)(c2);
                }
              });
            }
          )
        }).registerMany({
          [eT.A4]: (0, l.P9)(
            (e3) => function() {
              var r3;
              let o2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : e3.get(eT.OP), g2 = e3.get(eT.QG), { resources: a2 } = e3.get(eT.tw), l2 = n2({}, e3.get(eT.Hm)), { prefixUrl: c2, timeouts: u2, retryPolicyConfig: s2 } = a2.musicExternalApi, m2 = e3.get(eT.Xc).getLanguage(), p2 = new d.Q(l2, {
                prefixUrl: (0, i.getTldHost)(c2, t2, e_.B),
                retryPolicyConfig: s2,
                timeouts: u2.accountResource,
                params: { common: { oauth: g2.token, client: (0, em._)(), device: (0, eU.V)(), language: m2 } }
              });
              return o2.hooks = {
                beforeError: [
                  (0, ed.o)(g2, p2),
                  ...(null == o2 || null == (r3 = o2.hooks) ? void 0 : r3.beforeError) || []
                ]
              }, n2(o2, e3.get(eT.Hm));
            }
          )
        }).register(
          eT.CR,
          (0, l.P9)(
            (e3) => function() {
              let t3 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
              return e3.get(eT.A4)(t3, e3.get(eT.gu));
            }
          )
        ).registerMany({
          [eT.$I]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4), c2 = e3.get(eT.y$), u2 = l2(), s2 = e3.get(eT.QG), m2 = {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.accountResource,
              params: { common: { oauth: s2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            };
            return c2.cacheController ? new el.wV(u2, m2, { cacheController: c2.cacheController }) : new d.Q(u2, m2);
          }),
          [eT._1]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new w.d(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.usersResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.V3]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG), u2 = e3.get(eT.y$), s2 = {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.landingResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            };
            return new el.o7(l2, s2, {
              hooks: u2.hooks,
              variables: {
                get tracksController() {
                  return u2.tracksController;
                },
                get cacheController() {
                  var m2;
                  return null != (m2 = u2.cacheController) ? m2 : null;
                }
              }
            });
          }),
          [eT.Lb]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new G.H(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.landing3Resource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.tz]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new x.B(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.albumsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.$8]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new A.w(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.libraryResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.Oo]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new f.L(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.tracksResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.$5]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new h._(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.availabilityResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.qT]: (0, l.Gr)((e3) => {
            let { resources: r3, player: o2 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: g2, retryPolicyConfig: a2 } = r3.musicExternalApi, l2 = e3.get(eT.Xc).getLanguage(), c2 = e3.get(eT.A4)(), u2 = e3.get(eT.QG), s2 = e3.get(eT.y$), m2 = e3.get(eT.oo), p2 = {
              prefixUrl: (0, i.getTldHost)(n2, t2, e_.B),
              retryPolicyConfig: a2,
              timeouts: g2.getFileInfoResource,
              params: { common: { oauth: u2.token, client: (0, em._)(), device: (0, eU.V)(), language: l2 } }
            }, d2 = s2.repositoryContainer.fileStorage, w2 = s2.repositoryContainer.tracksRepository, G2 = s2.repositoryContainer.usersTracksRepository;
            return d2 && w2 && G2 ? new el.d7(c2, p2, {
              fileStorage: d2,
              tracksRepository: w2,
              usersTracksRepository: G2,
              hooks: s2.hooks,
              variables: {
                get uid() {
                  return m2.get(eH.c.YmUid);
                },
                secretKey: o2.secretKey
              }
            }) : new v.v(c2, p2);
          }),
          [eT.X4]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new k.a(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.topResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.O9]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new E.b(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.artistsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.E]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new L.V(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.slidesResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.wH]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4), c2 = e3.get(eT.QG), u2 = l2();
            return new U.c(u2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.redAlertResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.ok]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new H.Z(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.rotorResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.yq]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new _.p(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.searchResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.NN]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new R.v(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.searchResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.qN]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new T.T(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.playlistResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.ro]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new B.e(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.playlistsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.nM]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new V.o(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.pinResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.Ut]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new X.$(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.metatagsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.K1]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new Q.p(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.tagResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.eu]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new y.D(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.feedResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.aE]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG), u2 = e3.get(eT.y$), s2 = new C.l(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.pinsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
            return u2.cacheController ? (0, el._2)({
              resource: s2,
              cacheController: u2.cacheController,
              config: {
                common: { resourceName: C.l.constructor.name },
                enabled: true,
                priority: el.OU.HIGH,
                ttl: 6048e5
              }
            }) : s2;
          }),
          [eT.ki]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new b.I(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.musicHistoryResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.c9]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new D.s(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.dynamicPagesResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.en]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new P.B(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.chartResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.jQ]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new M._(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.clipsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.cZ]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new S.c(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.lyricViewsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.Zl]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new N.D(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.nonMusicResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.CN]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new q.N(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.donationResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.JM]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new O.c(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.streamsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.P1]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new Z.S(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.loaderResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.re]: (0, l.Gr)((e3) => {
            let { resources: t3 } = e3.get(eT.tw), { timeouts: r3, retryPolicyConfig: o2 } = t3.musicExternalApi, n2 = e3.get(eT.Xc).getLanguage(), g2 = e3.get(eT.A4)({ credentials: "omit" });
            return new $.s(g2, {
              prefixUrl: "",
              retryPolicyConfig: o2,
              timeouts: r3.prefixlessResource,
              params: { common: { client: (0, em._)(), device: (0, eU.V)(), language: n2 } }
            });
          }),
          [eT.Lk]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new Y.g(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.filtersResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.he]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)();
            return new K.K(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.offersResource,
              params: { common: { client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.uM]: (0, l.Gr)((e3) => {
            var t3;
            let { acqOffers: r3, rumSettings: n2 } = e3.get(eT.tw), { brand: g2, service: i2, environment: a2, appVersion: l2 } = r3, { platform: c2, page: u2 } = n2, s2 = e3.get(eT.QG), m2 = e3.get(eT.Xc).getLanguage(), p2 = e3.get(eT.A4), d2 = s2.token || null, w2 = p2({ credentials: "omit" }), { request_id: G2, puid: x2 } = null != (t3 = e3.get(eT.Zi).getStore()) ? t3 : {};
            return new o.mZ({
              brand: g2,
              service: i2,
              environment: a2,
              appVersion: l2,
              etld: "yandex.net",
              platform: "Desktop",
              lang: m2,
              oAuthToken: d2,
              authMethod: "oauth",
              requester: (0, eB.n)(w2),
              puid: (null == x2 ? void 0 : x2.toString()) || null,
              rumOptions: { platform: c2, page: u2, requestId: G2 }
            });
          }),
          [eT.$$]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new W.E(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.ugcResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), language: a2 } }
            });
          }),
          [eT.sv]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new I.L(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.collectionResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.gd]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new z.z(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.adsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.EN]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new J._(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.afterTrackResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.Ez]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new F.l(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.personalResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.N1]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG), u2 = e3.get(eT.y$), s2 = new j.H(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.disclaimersResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
            return u2.cacheController ? (0, el._2)({
              resource: s2,
              cacheController: u2.cacheController,
              config: {
                common: { resourceName: j.H.constructor.name },
                enabled: true,
                priority: el.OU.HIGH,
                ttl: 6048e5
              }
            }) : s2;
          }),
          [eT.u2]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new ee.J(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.familyResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.TD]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new et.L(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.childrenLandingResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.wK]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new er.u(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.landingBlocksResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.dh]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new eo.q(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.promoResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.LC]: (0, l.Gr)((e3) => {
            let { resources: t3, player: r3 } = e3.get(eT.tw), { timeouts: o2, retryPolicyConfig: n2 } = t3.musicExternalApi, g2 = e3.get(eT.CR)({ credentials: "include" });
            return new en.g(g2, {
              prefixUrl: r3.telemetry.telemetryUrl,
              retryPolicyConfig: n2,
              timeouts: o2.telemetryResouce,
              params: { common: { client: (0, em._)() } }
            });
          }),
          [eT.W5]: (0, l.Gr)((e3) => {
            let { resources: t3, player: r3 } = e3.get(eT.tw), { retryPolicyConfig: o2 } = t3.musicExternalApi, n2 = e3.get(eT.CR)({ credentials: "include" });
            return new eg.N(n2, {
              prefixUrl: r3.telemetry.rumUrl,
              retryPolicyConfig: o2,
              params: { common: { client: (0, em._)() } }
            });
          }),
          [eT.PL]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new ei.w(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.labelsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.DT]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: o2, timeouts: n2, retryPolicyConfig: g2 } = r3.musicExternalApi, a2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)(), c2 = e3.get(eT.QG);
            return new ea.O(l2, {
              prefixUrl: (0, i.getTldHost)(o2, t2, e_.B),
              retryPolicyConfig: g2,
              timeouts: n2.concertsResource,
              params: { common: { oauth: c2.token, client: (0, em._)(), device: (0, eU.V)(), language: a2 } }
            });
          }),
          [eT.vg]: (0, l.Gr)(() => (0, eu.a)())
        }).registerMany({
          [eT.UB]: (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.vg);
            return new p.B(t3);
          }),
          [eT.Tq]: (0, l.Gr)((e3) => {
            var t3;
            let r3 = e3.get(eT.W5);
            return (null == (t3 = window.Ya) ? void 0 : t3.Rum) ? new p.G((0, es.y)(), r3, window.Ya.Rum) : null;
          })
        }).register(
          eT.by,
          (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.oo), r3 = e3.get(eT.U2), o2 = e3.get(eT.Zf), i2 = r3.get(eH.c.YnisonDeviceId);
            i2 || (i2 = (0, g.A)(), r3.set(eH.c.YnisonDeviceId, i2));
            let a2 = {
              info: {
                app_name: "Desktop",
                app_version: (0, eL.H)() || "",
                title: "Music Desktop App",
                device_id: i2,
                type: n.bq.WEB_DESKTOP
              },
              volumeGranularity: 20,
              get defaultVolume() {
                var l2;
                return null != (l2 = t3.get(eH.c.YmPlayerVolume)) ? l2 : void 0;
              }
            }, c2 = e3.get(eT.WA).getPassportUid(), u2 = e3.get(eT.QG);
            return new n.Jd({
              logger: o2,
              deviceConfig: a2,
              multiAuthUserId: c2,
              oauth: u2.token,
              ynisonConnectionConfig: ey2.ynisonConnectionConfig,
              variables: { isShadow: true }
            });
          })
        );
      }
    }
  }
]);
