(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2830],
  {
    6379: (e) => {
      e.exports = {
        root: "ChartBlock_root__GQF6w",
        root_spacer_m: "ChartBlock_root_spacer_m__yVzU8",
        root_spacer_l: "ChartBlock_root_spacer_l__wBImk",
        root_spacer_xxl: "ChartBlock_root_spacer_xxl__cSNqe"
      };
    },
    7754: (e, t, a) => {
      "use strict";
      var l;
      a.d(t, { m: () => l }), (function(e2) {
        e2.WAVE = "WAVE", e2.ACTION = "ACTION", e2.SHARE = "SHARE", e2.SIMPLE = "SIMPLE";
      })(l || (l = {}));
    },
    8066: (e) => {
      e.exports = {
        root: "ArtistsContent_root__Jpd8M",
        covers: "ArtistsContent_covers__OeO2T",
        cover: "ArtistsContent_cover__rzlO2",
        image: "ArtistsContent_image__okuHk"
      };
    },
    12978: (e) => {
      e.exports = {
        root: "ThenNowComparison_root__sAUJF",
        row: "ThenNowComparison_row__1osE7",
        textPrimary: "ThenNowComparison_textPrimary__mXrAG",
        textSecondary: "ThenNowComparison_textSecondary__O5HTV",
        cover: "ThenNowComparison_cover___UkLn",
        itemLabel: "ThenNowComparison_itemLabel__L_vTN",
        itemMeta: "ThenNowComparison_itemMeta__TqbEJ",
        header: "ThenNowComparison_header__tWhL1"
      };
    },
    18259: (e, t, a) => {
      "use strict";
      a.d(t, { SlideCard: () => te });
      var l, i, r, n, o, s, d, c, u = a(54486), g = a(50420), m = a(28303), _ = a(61910), v = a(43350);
      !(function(e10) {
        e10.TOP = "TOP", e10.CENTER = "CENTER", e10.BOTTOM = "BOTTOM";
      })(l || (l = {}));
      var p = a(83510), C = a(8817), x = a(62443), S = a(14342), b = a(74125), y = a(15209), h = a(58360), K = a(89461), N = a(92757), T = a.n(N);
      let E = (0, m.PA)((e10) => {
        let {
          className: t2,
          children: a2,
          background: {
            animationDelay: l2,
            withPersonalColor: i2,
            videoUrl: r2,
            firstFrameVideoUrl: n2,
            lastFrameVideoUrl: o2,
            bgImageUrl: s2,
            withSound: d2,
            videoLoopEnabled: c2
          },
          isActive: m2,
          isContentVisible: v2,
          setContentVisible: p2,
          setContentInvisible: C2
        } = e10, {
          user: x2,
          slides: { isMuted: S2 }
        } = (0, b.Pjs)(), { isVisible: N2 } = (0, b.dtw)(), E2 = (0, _.useRef)(null), k2 = (0, b.eGp)(), I2 = (null == k2 ? void 0 : k2.getState(b.V_r.TRAILER).playerState.status.value) === K.MT.PLAYING && d2, w2 = (0, _.useCallback)(() => setTimeout(p2, 1e3 * l2), [l2, p2]);
        (0, _.useEffect)(() => {
          !m2 && v2 && C2();
        }, [m2, v2, C2]), (0, _.useEffect)(() => {
          var e11, t3, a3;
          m2 && !N2 ? ((null == (e11 = E2.current) ? void 0 : e11.readyState) !== 4 && w2(), null == (t3 = E2.current) || t3.play().then(() => {
            w2(), I2 && (null == k2 || k2.pause(b.V_r.TRAILER));
          }).catch(w2)) : E2.current && (E2.current.currentTime = 0, null == (a3 = E2.current) || a3.pause());
        }, [w2, m2, N2, p2, I2, k2]);
        let f2 = (0, _.useMemo)(() => {
          if (i2 && x2.collectionHue) return { "--user-background-color": (0, b.eWZ)(x2.collectionHue, 1, 0.5) };
        }, [i2, x2.collectionHue]), A2 = r2 && n2 && !i2, R2 = !r2 && s2;
        return (0, u.jsxs)("div", {
          className: (0, g.$)(T().root, t2),
          style: f2,
          children: [
            R2 && (0, u.jsx)(h.Image, { src: (0, y.createAvatarUrl)(s2, 800, true), className: T().firstFrame }),
            A2 && (0, u.jsx)(h.Image, { src: (0, y.createAvatarUrl)(n2, 800, true), className: T().firstFrame }),
            r2 && (0, u.jsxs)(u.Fragment, {
              children: [
                o2 && (0, u.jsx)(h.Image, {
                  "data-screenshot-visible": true,
                  src: (0, y.createAvatarUrl)(o2, 800, true),
                  className: (0, g.$)(T().lastFrame, T().hidden)
                }),
                (0, u.jsx)("video", {
                  className: (0, g.$)(T().media, { [T().media_withPersonalColor]: i2 }),
                  "data-screenshot-hidden": true,
                  ref: E2,
                  src: r2,
                  poster: (0, y.createAvatarUrl)(s2, 800, true),
                  playsInline: true,
                  muted: !d2 || S2,
                  loop: c2
                })
              ]
            }),
            !!a2 && a2
          ]
        });
      }), k = (0, _.memo)(E);
      var I = a(83645), w = a(43426), f = a(7754), A = a(27510), R = a(77881), j = a(5956), L = a(6971), B = a(97800), O = a(80585), P = a(34340), D = a.n(P);
      let G = (e10) => {
        var t2;
        let { data: a2, className: l2 } = e10, i2 = (0, b.NKK)(), r2 = (0, C.c)(() => {
          var e11;
          i2({ deepLink: null != (e11 = a2.url) ? e11 : "", to: v.QT.Link });
        });
        return (0, u.jsxs)(O.N_, {
          href: null != (t2 = a2.url) ? t2 : void 0,
          onClick: r2,
          className: (0, g.$)(D().root, l2),
          children: [
            (0, u.jsx)(L.Paper, {
              radius: "xs",
              className: D().cover,
              children: a2.imageUrl && (0, u.jsx)(O.BW, {
                src: a2.imageUrl,
                withAvatarReplace: true,
                fit: "contain",
                className: D().image,
                size: 100
              })
            }),
            (0, u.jsx)(B.Caption, {
              variant: "span",
              type: "controls",
              size: "l",
              weight: "medium",
              className: D().text,
              lineClamp: 1,
              children: a2.title
            }),
            (0, u.jsx)(j.Icon, { variant: "arrowRight", size: "xs", className: D().icon })
          ]
        });
      };
      var X = a(99020), H = a.n(X);
      let M = (e10) => {
        var t2;
        let { data: a2, className: l2, handleClick: i2 } = e10, r2 = (0, b.ZpR)(null != (t2 = a2.url) ? t2 : ""), n2 = (0, b.NKK)(), o2 = (0, _.useMemo)(
          () => ({ "--text-color": a2.textColor, "--button-color": a2.buttonColor }),
          [a2.buttonColor, a2.textColor]
        ), s2 = (0, C.c)(() => {
          var e11;
          if (i2) return i2();
          n2({ deepLink: null != (e11 = a2.url) ? e11 : "", to: v.QT.Link }), r2();
        });
        return (0, u.jsx)(R.$, {
          role: "link",
          style: o2,
          className: (0, g.$)(H().root, l2),
          size: "default",
          radius: "xxxl",
          color: "primary",
          withHover: false,
          withRipple: false,
          onClick: s2,
          children: (0, u.jsx)(B.Caption, {
            variant: "span",
            type: "controls",
            size: "l",
            weight: "medium",
            lineClamp: 1,
            children: a2.title
          })
        });
      };
      var z = a(91453), V = a.n(z);
      let U = I.default.default(
        () => Promise.all([a.e(5595), a.e(7466)]).then(a.bind(a, 47466)).then((e10) => e10.ShareButton),
        { ssr: false }
      ), F = (e10) => {
        let { button: t2, buttonClassName: a2, cardRef: l2 } = e10, i2 = (0, g.$)(a2, V().contractButton);
        switch (t2.type) {
          case f.m.ACTION:
            if (t2.data.url) return (0, u.jsx)(G, { data: t2.data, className: i2 });
            return null;
          case f.m.SIMPLE:
            if (t2.data.url) return (0, u.jsx)(M, { data: t2.data, className: i2 });
            return null;
          case f.m.SHARE:
            return (0, u.jsx)(U, { data: t2.data, wrapperClassName: i2, cardRef: l2 });
        }
      }, $ = (0, m.PA)((e10) => {
        var t2, a2;
        let {
          slide: l2,
          className: i2,
          cardRef: r2,
          hasLeft: n2 = true,
          hasRight: o2 = true,
          onSaveChoice: s2,
          onEditChoice: d2,
          onSlidePrev: c2,
          onSlideNext: m2
        } = e10, { button: v2 } = l2, {
          slides: { savedChoice: C2 }
        } = (0, b.Pjs)(), x2 = null != (a2 = null == C2 ? void 0 : C2.isSaved) && a2, { formatMessage: S2 } = (0, w.A)(), y2 = (0, _.useMemo)(
          () => (null == v2 ? void 0 : v2.type) === f.m.SHARE || (null == v2 ? void 0 : v2.type) === f.m.SIMPLE ? { textColor: v2.data.textColor, buttonColor: v2.data.buttonColor } : { textColor: null, buttonColor: null },
          [v2]
        ), h2 = (0, _.useMemo)(() => ({ "--text-color": y2.textColor, "--button-color": y2.buttonColor }), [y2]), K2 = (0, A.L)(() => v2 && (0, u.jsx)(F, { button: v2, buttonClassName: i2, cardRef: r2 })), N2 = (0, A.L)(
          () => l2.savedChoiceKey && (n2 || o2) ? (0, u.jsx)(M, {
            data: { title: S2({ id: "rewind.save-choice" }), url: null, ...y2 },
            handleClick: s2,
            className: i2
          }) : K2
        ), T2 = null == (t2 = l2.content) ? void 0 : t2.type;
        return T2 !== p.x.CAROUSEL && T2 !== p.x.COLLAGE ? K2 : x2 ? (0, u.jsxs)("div", {
          className: V().buttonsContainer,
          children: [
            v2 && (0, u.jsx)(F, { button: v2, buttonClassName: i2, cardRef: r2 }),
            (0, u.jsx)(R.$, {
              color: "primary",
              className: (0, g.$)(V().iconButton, H().root, V().editButton),
              icon: (0, u.jsx)(j.Icon, { variant: "pencil", size: "xxs" }),
              radius: "round",
              role: "link",
              size: "default",
              withHover: true,
              withRipple: true,
              style: h2,
              onClick: d2
            })
          ]
        }) : (0, u.jsxs)("div", {
          className: V().buttonsContainer,
          children: [
            n2 && (0, u.jsx)(R.$, {
              color: "primary",
              className: (0, g.$)(V().iconButton, H().root, V().arrowLeftButton),
              icon: (0, u.jsx)(j.Icon, { variant: "arrowLeft", size: "xxs" }),
              radius: "round",
              role: "link",
              size: "default",
              withHover: true,
              withRipple: true,
              style: h2,
              onClick: c2
            }),
            (0, u.jsx)("div", { className: V().mainButtonContainer, children: N2 }),
            o2 && (0, u.jsx)(R.$, {
              color: "primary",
              className: (0, g.$)(V().iconButton, H().root, V().arrowRightButton),
              icon: (0, u.jsx)(j.Icon, { variant: "arrowRight", size: "xxs" }),
              radius: "round",
              role: "link",
              size: "default",
              withHover: true,
              withRipple: true,
              style: h2,
              onClick: m2
            })
          ]
        });
      });
      var W = a(70837), Y = a(39610);
      let J = { 6: 84, 7: 84, 8: 68, 9: 68, 10: 56, 11: 56, 12: 48, 13: 48 };
      var Z = a(93988), q = a.n(Z);
      let Q = (e10) => {
        let { caption: t2, className: a2, lineClamp: l2 = 2 } = e10;
        return (0, u.jsx)(B.Caption, {
          variant: "span",
          type: "text",
          size: "l",
          weight: "medium",
          className: (0, g.$)(q().root, a2),
          lineClamp: l2,
          children: t2
        });
      };
      var ee = a(79074), et = a.n(ee);
      let ea = (e10) => {
        let {
          data: t2,
          className: a2,
          valueClassName: l2,
          valueContainerClassName: i2,
          withAutoResize: r2,
          descriptionLineClamp: n2,
          withOpacity: o2
        } = e10, s2 = (0, _.useRef)(null), { formatNumber: d2 } = (0, w.A)(), c2 = (0, _.useCallback)((e11) => e11 >= 1e4 ? d2(e11) : String(e11), [d2]);
        (0, _.useEffect)(() => {
          if (s2.current) {
            if (!t2.value) return;
            let e11 = new W.T(s2.current, Number(t2.value), { startVal: 1, formattingFn: c2 });
            e11.error || e11.start();
          }
        }, [t2.value, c2]);
        let m2 = (0, _.useMemo)(() => {
          if (r2 && t2.value)
            return {
              fontSize: ((e11) => {
                let t3 = String(e11).length;
                return t3 > 13 ? "clamp(".concat(18, "px, ").concat(11, "cqi, ").concat(54, "px)") : t3 <= 5 ? "clamp(".concat(18, "px, ").concat(26, "cqi, ").concat(100, "px)") : "clamp(".concat(18, "px, ").concat(26 - t3, "cqi, ").concat(J[t3], "px)");
              })(t2.value)
            };
        }, [t2.value, r2]);
        return (0, u.jsxs)(u.Fragment, {
          children: [
            (0, u.jsxs)(Y.q, { children: [t2.value, " ", t2.valueSuffix, " ", t2.valueDescription] }),
            (0, u.jsxs)("div", {
              className: (0, g.$)(et().root, { [et().root_withOpacity]: o2 }, a2),
              "aria-hidden": true,
              children: [
                (0, u.jsxs)("div", {
                  className: (0, g.$)(et().valueContainer, i2),
                  children: [
                    (0, u.jsx)(B.Heading, {
                      variant: "div",
                      size: "xxxxl",
                      tabIndex: -1,
                      ref: s2,
                      "aria-hidden": true,
                      className: (0, g.$)(et().value, l2),
                      style: m2
                    }),
                    t2.valueSuffix && (0, u.jsx)(B.Heading, {
                      variant: "div",
                      size: "xxxxl",
                      className: et().value,
                      style: m2,
                      children: t2.valueSuffix
                    })
                  ]
                }),
                (0, u.jsx)(B.Heading, {
                  variant: "div",
                  size: "xl",
                  weight: "black",
                  className: et().unit,
                  lineClamp: n2,
                  children: t2.valueDescription
                }),
                t2.footer && (0, u.jsx)(Q, { caption: t2.footer, className: et().footer, lineClamp: 3 })
              ]
            })
          ]
        });
      };
      var el = a(8066), ei = a.n(el);
      let er = (e10) => {
        let { data: t2 } = e10, a2 = (0, _.useMemo)(
          () => ({
            value: t2.value,
            valueDescription: t2.valueDescription,
            valueSuffix: t2.valueSuffix,
            footer: t2.footer
          }),
          [t2.footer, t2.value, t2.valueDescription, t2.valueSuffix]
        ), l2 = (0, _.useMemo)(
          () => ({ "--covers-offset-translate": "".concat((t2.covers.length - 1) * 7.5, "px") }),
          [t2.covers]
        ), i2 = (0, _.useCallback)((e11) => ({ "--cover-offset-translate": "-".concat(15 * e11, "px") }), []);
        return (0, u.jsxs)("div", {
          className: ei().root,
          children: [
            (0, u.jsx)(ea, { data: a2, withAutoResize: true }),
            (0, u.jsx)("div", {
              className: ei().covers,
              style: l2,
              children: t2.covers.map((e11, t3) => {
                var a3;
                return (0, u.jsx)(
                  L.Paper,
                  {
                    radius: "round",
                    className: ei().cover,
                    style: i2(t3),
                    children: (0, u.jsx)(O.BW, {
                      src: null != (a3 = e11.uri) ? a3 : void 0,
                      withAvatarReplace: true,
                      fit: "contain",
                      size: 100,
                      className: ei().image
                    })
                  },
                  e11.uri
                );
              })
            })
          ]
        });
      };
      var en = a(31756), eo = a(91657), es = a(36553), ed = a(68280), ec = a.n(ed);
      let eu = (0, m.PA)((e10) => {
        let {
          isDisabled: t2,
          initialIndex: a2 = 0,
          slidesPerView: l2 = en.bF,
          disabledClassName: i2,
          slideActiveClassName: r2,
          slideClassName: n2,
          onSlideChange: o2,
          onCarouselReady: s2,
          children: d2
        } = e10, c2 = (0, _.useRef)(null);
        (0, _.useEffect)(() => {
          var e11, a3;
          t2 ? null == (e11 = c2.current) || e11.disable() : null == (a3 = c2.current) || a3.enable();
        }, [t2]);
        let m2 = (0, _.useCallback)(
          (e11) => {
            let { activeIndex: a3 } = e11;
            t2 || null == o2 || o2(a3);
          },
          [t2, o2]
        ), v2 = (0, _.useCallback)(
          (e11) => {
            c2.current = e11, null == s2 || s2({ slideNext: () => e11.slideNext(), slidePrev: () => e11.slidePrev() });
          },
          [s2]
        );
        return (0, u.jsx)(es.RC, {
          a11y: { enabled: true },
          centeredSlides: true,
          className: (0, g.$)(ec().root, ec().swiper, { [null != i2 ? i2 : ""]: t2 }),
          initialSlide: a2,
          keyboard: true,
          modules: [eo.Jq, eo.s3, eo.Vx, eo.dK],
          pagination: { dynamicBullets: true, dynamicMainBullets: 3 },
          slidesPerView: l2,
          spaceBetween: en.ur,
          wrapperClass: ec().wrapper,
          onActiveIndexChange: m2,
          onSwiper: v2,
          children: d2.map((e11, t3) => {
            var l3, i3;
            return (0, u.jsx)(
              es.qr,
              {
                className: (0, g.$)(ec().slide, n2, {
                  [null != r2 ? r2 : ""]: t3 === (null != (i3 = null == (l3 = c2.current) ? void 0 : l3.activeIndex) ? i3 : a2)
                }),
                children: e11
              },
              t3
            );
          })
        });
      });
      var eg = a(82864), em = a.n(eg);
      let e_ = (e10) => {
        let { className: t2, heading: a2, lineClamp: l2 = 2 } = e10;
        return (0, u.jsx)(B.Heading, {
          variant: "h3",
          size: "xxl",
          weight: "bold",
          className: (0, g.$)(em().root, t2),
          lineClamp: l2,
          children: a2
        });
      };
      var ev = a(75146), ep = a.n(ev);
      let eC = (0, m.PA)((e10) => {
        let { data: t2, carouselIndex: a2, onSlideChange: l2, onCarouselReady: i2 } = e10, {
          slides: { savedChoice: r2 }
        } = (0, b.Pjs)(), { isSaved: n2 } = null != r2 ? r2 : { index: 0, isSaved: false }, [o2, s2] = (0, _.useState)(() => {
          if (void 0 !== a2) return t2.items[a2];
        }), d2 = (0, _.useCallback)(
          (e11) => {
            let a3 = t2.items[e11];
            a3 && (s2(a3), null == l2 || l2(e11, t2.items.length));
          },
          [t2.items, l2]
        );
        return t2.items.length ? (0, u.jsxs)("div", {
          className: ep().root,
          children: [
            o2 && o2.data.description && (0, u.jsx)(Q, { caption: o2.data.description, className: ep().description, lineClamp: 3 }),
            (0, u.jsx)(eu, {
              isDisabled: n2,
              initialIndex: a2,
              slideClassName: ep().slide,
              slideActiveClassName: ep().slideActive,
              disabledClassName: ep().disabled,
              onCarouselReady: i2,
              onSlideChange: d2,
              children: t2.items.map((e11, t3) => {
                var a3, l3;
                return (0, u.jsx)(
                  L.Paper,
                  {
                    className: ep().cover,
                    children: e11.data.cover.uri && (0, u.jsx)(O.pU, {
                      backgroundSrc: null != (a3 = e11.data.coverBackground) ? a3 : "",
                      className: ep().image,
                      fit: "contain",
                      maskSrc: null != (l3 = e11.data.coverMask) ? l3 : "",
                      size: en.e0,
                      src: e11.data.cover.uri,
                      withAvatarReplace: true,
                      withSrcSet: false
                    })
                  },
                  t3
                );
              })
            }),
            (0, u.jsxs)("div", {
              className: ep().meta,
              children: [
                (null == o2 ? void 0 : o2.data.subtitle) && (0, u.jsx)(Q, { caption: o2.data.subtitle, className: ep().subtitle }),
                (null == o2 ? void 0 : o2.data.title) && (0, u.jsx)(e_, { className: ep().title, heading: o2.data.title, lineClamp: 3 })
              ]
            })
          ]
        }) : null;
      });
      !(function(e10) {
        e10.SQUARE = "SQUARE", e10.CIRCLE = "CIRCLE";
      })(i || (i = {}));
      var ex = a(6379), eS = a.n(ex), eb = a(93064);
      !(function(e10) {
        e10.NUMBER = "NUMBER", e10.TEXT = "TEXT";
      })(r || (r = {}));
      var ey = a(85511), eh = a.n(ey);
      let eK = (0, m.PA)((e10) => {
        var t2;
        let { data: a2, index: l2, variant: n2, isOrderVisible: o2, hasOnlyArtistItems: s2 } = e10, { formatNumber: d2 } = (0, w.A)(), c2 = (0, _.useMemo)(
          () => ({
            "--slide-final-translate-offset": n2 === p.x.CHART && s2 ? "".concat(-8 * l2, "px") : 0,
            animationDelay: "".concat(0.5 * l2, "s")
          }),
          [l2, s2, n2]
        ), m2 = (0, _.useMemo)(() => {
          let e11 = Number(a2.subtitle);
          return a2.subtitle && !isNaN(e11) ? d2(e11) : a2.subtitle;
        }, [a2.subtitle, d2]), v2 = (0, _.useMemo)(
          () => a2.titleType === r.NUMBER && "number" == typeof a2.value ? (0, u.jsx)(ea, {
            data: (0, eb.wg)({ value: a2.value }),
            className: eh().stat,
            valueClassName: eh().statValue,
            valueContainerClassName: eh().statValueContainer
          }) : a2.title ? n2 === p.x.CHART_ARTIST ? (0, u.jsx)(B.Heading, {
            variant: "div",
            size: "s",
            weight: "black",
            lineClamp: 2,
            className: eh().textVariant,
            children: a2.title
          }) : (0, u.jsx)(B.Caption, {
            variant: "span",
            type: "text",
            size: "l",
            weight: "medium",
            lineClamp: 2,
            className: eh().textVariant,
            children: a2.title
          }) : void 0,
          [a2.title, a2.titleType, a2.value, n2]
        ), C2 = (0, _.useMemo)(() => {
          if (m2)
            return n2 === p.x.CHART && s2 || n2 === p.x.CHART_FAVORITES ? (0, u.jsx)(B.Heading, {
              variant: "div",
              size: "s",
              weight: "black",
              lineClamp: 2,
              className: (0, g.$)(eh().textVariant, eh().subTitle),
              children: m2
            }) : (0, u.jsx)(B.Caption, {
              variant: "span",
              type: "text",
              size: "l",
              weight: "medium",
              lineClamp: 2,
              className: (0, g.$)(eh().text, { [eh().textVariant]: n2 === p.x.CHART_ARTIST }),
              children: m2
            });
        }, [m2, s2, n2]);
        return (0, u.jsxs)("li", {
          className: eh().root,
          style: c2,
          tabIndex: 0,
          children: [
            o2 && (0, u.jsx)(B.Heading, {
              variant: "div",
              size: "l",
              weight: "black",
              className: eh().order,
              children: l2 + 1
            }),
            (0, u.jsx)(L.Paper, {
              radius: a2.coverType === i.CIRCLE ? "round" : "xs",
              className: eh().cover,
              children: (null == (t2 = a2.cover) ? void 0 : t2.uri) && (0, u.jsx)(O.BW, {
                src: a2.cover.uri,
                withAvatarReplace: true,
                fit: "contain",
                className: eh().image,
                size: 100
              })
            }),
            (0, u.jsxs)("div", { className: eh().meta, children: [v2, C2] })
          ]
        });
      }), eN = (e10) => {
        let { items: t2, isOrderVisible: a2, variant: l2 } = e10, r2 = (0, _.useMemo)(() => t2.every((e11) => e11.coverType === i.CIRCLE), [t2]), n2 = (0, _.useMemo)(() => {
          switch (l2) {
            case p.x.CHART_ARTIST:
              return "l";
            case p.x.CHART_FAVORITES:
              return "xxl";
            case p.x.CHART:
              if (r2) return;
              return "m";
            default:
              return null;
          }
        }, [r2, l2]);
        return (0, u.jsx)("ol", {
          className: (0, g.$)(eS().root, eS()["root_spacer_".concat(n2)]),
          tabIndex: -1,
          children: t2.map(
            (e11, t3) => (0, u.jsx)(
              eK,
              { data: e11, index: t3, variant: l2, hasOnlyArtistItems: r2, isOrderVisible: a2 },
              "".concat(e11.title, "-").concat(e11.subtitle)
            )
          )
        });
      };
      var eT = a(82816), eE = a.n(eT);
      let ek = (e10) => {
        var t2;
        let { data: a2 } = e10;
        return (0, u.jsxs)("div", {
          className: eE().root,
          children: [
            (null == (t2 = a2.cover) ? void 0 : t2.uri) && (0, u.jsx)(L.Paper, {
              radius: "round",
              className: eE().cover,
              children: (0, u.jsx)(O.BW, {
                src: a2.cover.uri,
                withAvatarReplace: true,
                fit: "contain",
                className: eE().image,
                size: 200
              })
            }),
            a2.title && (0, u.jsx)(B.Heading, {
              variant: "div",
              size: "xl",
              weight: "bold",
              className: eE().title,
              lineClamp: 2,
              children: a2.title
            }),
            (0, u.jsx)(eN, { items: a2.items, isOrderVisible: false, variant: p.x.CHART_ARTIST })
          ]
        });
      };
      var eI = a(29854), ew = a.n(eI);
      let ef = (e10) => {
        var t2;
        let { data: a2 } = e10;
        return (0, u.jsxs)("div", {
          className: ew().root,
          children: [
            a2.description && (0, u.jsx)(Q, { caption: null != (t2 = a2.description) ? t2 : "", className: ew().text, lineClamp: 3 }),
            (0, u.jsx)(eN, { items: a2.items, variant: p.x.CHART, isOrderVisible: a2.isOrderVisible })
          ]
        });
      };
      var eA = a(94894), eR = a.n(eA);
      let ej = (e10) => {
        let { data: t2 } = e10, a2 = "number" == typeof t2.value, l2 = (0, _.useMemo)(
          () => ({
            value: t2.value,
            valueDescription: t2.valueDescription,
            valueSuffix: t2.valueSuffix,
            footer: t2.footer
          }),
          [t2.footer, t2.value, t2.valueDescription, t2.valueSuffix]
        );
        return (0, u.jsxs)("div", {
          className: eR().root,
          children: [
            a2 && (0, u.jsx)(ea, { data: l2, withAutoResize: true }),
            t2.description && (0, u.jsx)(B.Caption, {
              variant: "span",
              type: "text",
              size: "l",
              weight: "medium",
              className: eR().description,
              lineClamp: 3,
              children: t2.description
            }),
            (0, u.jsx)(eN, { items: t2.items, isOrderVisible: t2.isOrderVisible, variant: p.x.CHART_FAVORITES })
          ]
        });
      };
      !(function(e10) {
        e10.CHOSEN = "CHOSEN", e10.TEXT = "TEXT";
      })(n || (n = {})), (function(e10) {
        e10.CHOSEN_IMAGE = "CHOSEN_IMAGE", e10.IMAGE = "IMAGE";
      })(o || (o = {})), (function(e10) {
        e10.TEXT = "TEXT", e10.COLLAGE = "COLLAGE";
      })(s || (s = {}));
      var eL = a(31016), eB = a.n(eL);
      let eO = (0, m.PA)((e10) => {
        let { data: t2, carouselIndex: a2 = 0, onBackgroundChange: l2, onCarouselReady: i2, onSlideChange: r2 } = e10, {
          slides: { savedChoices: s2 }
        } = (0, b.Pjs)();
        (0, _.useEffect)(() => {
          var e11, i3, r3;
          return null == l2 ? void 0 : l2(null != (r3 = null == (i3 = t2.items[a2]) || null == (e11 = i3.contentBackground) ? void 0 : e11.uri) ? r3 : "");
        }, [t2.items, a2, l2]);
        let d2 = (0, C.c)((e11) => {
          var a3, i3, n2;
          null == l2 || l2(null != (n2 = null == (i3 = t2.items[e11]) || null == (a3 = i3.contentBackground) ? void 0 : a3.uri) ? n2 : ""), null == r2 || r2(e11, t2.items.length);
        });
        return t2.items.length ? (0, u.jsx)("div", {
          className: eB().root,
          children: (0, u.jsx)(eu, {
            initialIndex: a2,
            slidesPerView: 1,
            onCarouselReady: i2,
            onSlideChange: d2,
            children: t2.items.map((e11, t3) => {
              let a3, { topBlock: l3, bottomBlock: i3 } = e11, {
                background: { uri: r3 },
                items: d3
              } = l3.data, c2 = d3.reduce((e12, t4) => {
                let a4, l4, i4;
                if (t4.type === o.IMAGE) a4 = t4.data.uri;
                else if (t4.type === o.CHOSEN_IMAGE) {
                  var r4;
                  let e13 = s2.get(null != (r4 = t4.data.key) ? r4 : "");
                  a4 = null == e13 ? void 0 : e13.data.uri, l4 = null == e13 ? void 0 : e13.data.coverMask, i4 = null == e13 ? void 0 : e13.data.coverBackground;
                }
                if (!a4) return e12;
                let { x: n2, y: d4, z: c3, width: u2, height: g3 } = t4.data.rectangle;
                return e12.push({
                  uri: a4,
                  coverMask: l4,
                  coverBackground: i4,
                  rectangle: {
                    left: "".concat(n2, "%"),
                    top: "".concat(1.25 * d4, "%"),
                    zIndex: c3,
                    width: "".concat(u2, "%"),
                    height: "".concat(1.25 * g3, "%")
                  }
                }), e12;
              }, []), g2 = (a3 = i3.data.items, a3.map((e12) => {
                let t4;
                if (e12.type === n.TEXT) t4 = e12.data.subtitle;
                else if (e12.type === n.CHOSEN) {
                  var a4;
                  let l4 = s2.get(null != (a4 = e12.data.key) ? a4 : "");
                  t4 = null == l4 ? void 0 : l4.data.text;
                }
                return { title: e12.data.title, subtitle: t4 };
              }));
              return (0, u.jsxs)(
                "div",
                {
                  className: eB().slide,
                  children: [
                    (0, u.jsxs)("div", {
                      className: eB().topBlock,
                      children: [
                        r3 && (0, u.jsx)(h.Image, {
                          className: eB().topBlockBackground,
                          src: r3,
                          withAvatarReplace: true
                        }),
                        c2.map((e12, t4) => {
                          let { uri: a4, coverMask: l4, coverBackground: i4, rectangle: r4 } = e12;
                          return (0, u.jsx)(
                            "div",
                            {
                              className: eB().topBlockImageWrapper,
                              style: r4,
                              children: (0, u.jsx)(O.pU, {
                                backgroundSrc: i4,
                                className: eB().topBlockImage,
                                fit: "contain",
                                maskSrc: l4,
                                size: en.e0,
                                src: a4,
                                withAvatarReplace: true,
                                withSrcSet: false
                              })
                            },
                            t4
                          );
                        })
                      ]
                    }),
                    (0, u.jsx)("div", {
                      className: eB().bottomBlock,
                      children: g2.map((e12, t4) => {
                        let { title: a4, subtitle: l4 } = e12;
                        return (0, u.jsxs)(
                          "div",
                          {
                            className: eB().bottomBlock_item,
                            children: [
                              a4 && (0, u.jsx)(Q, { caption: a4, className: eB().title, lineClamp: 1 }),
                              l4 && (0, u.jsx)(e_, {
                                heading: l4,
                                className: eB().subtitle,
                                lineClamp: 1 === t4 ? 1 : 2
                              })
                            ]
                          },
                          a4
                        );
                      })
                    })
                  ]
                },
                t3
              );
            })
          })
        }) : null;
      });
      var eP = a(45058), eD = a.n(eP);
      let eG = (e10) => {
        let { data: t2 } = e10;
        return (0, u.jsxs)("div", {
          className: eD().root,
          children: [
            (0, u.jsx)(B.Caption, {
              variant: "span",
              type: "text",
              size: "l",
              weight: "medium",
              className: (0, g.$)(eD().description, eD().text),
              lineClamp: 3,
              children: t2.description
            }),
            t2.artwork && (0, u.jsx)(h.Image, {
              src: t2.artwork,
              size: 300,
              fit: "cover",
              withAvatarReplace: true,
              "aria-hidden": true,
              className: eD().artwork
            }),
            (0, u.jsx)(B.Heading, {
              variant: "h2",
              size: "xl",
              weight: "black",
              className: (0, g.$)(eD().title, eD().text),
              lineClamp: 2,
              children: t2.title
            })
          ]
        });
      };
      (d || (d = {})).REWIND = "REWIND";
      let eX = { src: "/_next/static/media/trailer_animated.aa3fd227.gif" };
      var eH = a(69282), eM = a.n(eH);
      let ez = (0, m.PA)((e10) => {
        var t2, a2, i2;
        let { data: r2, withPersonalColor: n2 } = e10, { user: o2 } = (0, b.Pjs)(), s2 = r2.entityType === d.REWIND || !!(null == (t2 = r2.smallRoundCover) ? void 0 : t2.uri), c2 = (0, _.useMemo)(() => {
          if (!n2 || !o2.collectionHue) {
            var e11;
            return {
              "--cover-background-color": r2.cover.color,
              "--small-round-cover-background-color": null == (e11 = r2.smallRoundCover) ? void 0 : e11.color
            };
          }
          return {
            "--cover-background-color": (0, b.eWZ)(o2.collectionHue, 0.8, 0.6),
            "--small-round-cover-background-color": (0, b.eWZ)(o2.collectionHue, 1, 0.35)
          };
        }, [r2.cover.color, null == (a2 = r2.smallRoundCover) ? void 0 : a2.color, o2.collectionHue, n2]), m2 = (0, _.useMemo)(() => {
          var e11;
          return r2.entityType === d.REWIND ? (0, u.jsx)(L.Paper, {
            radius: "round",
            className: eM().smallRoundCover,
            children: (0, u.jsx)(h.Image, {
              src: eX.src,
              withFallback: false,
              withLoadingIndicator: false,
              fit: "contain",
              className: eM().trailer,
              "aria-hidden": true
            })
          }) : (null == (e11 = r2.smallRoundCover) ? void 0 : e11.uri) ? (0, u.jsx)(L.Paper, {
            radius: "round",
            className: (0, g.$)(eM().smallRoundCover, eM().smallRoundCover_withShadow),
            children: (0, u.jsx)(O.BW, {
              src: r2.smallRoundCover.uri,
              withAvatarReplace: true,
              fit: "contain",
              size: 100,
              className: eM().image
            })
          }) : void 0;
        }, [r2.entityType, null == (i2 = r2.smallRoundCover) ? void 0 : i2.uri]), v2 = r2.align === l.BOTTOM;
        return (0, u.jsxs)("div", {
          className: eM().root,
          style: c2,
          children: [
            !v2 && r2.description && (0, u.jsx)(Q, { caption: r2.description, className: eM().description, lineClamp: 3 }),
            (0, u.jsx)(L.Paper, {
              className: (0, g.$)(eM().cover, { [eM().cover_small]: v2 }),
              children: r2.cover.uri && (0, u.jsx)(O.pU, {
                backgroundSrc: r2.coverBackground,
                className: eM().image,
                fit: "contain",
                maskSrc: r2.coverMask,
                size: en.e0,
                src: r2.cover.uri,
                withAvatarReplace: true,
                withSrcSet: false
              })
            }),
            (0, u.jsxs)("div", {
              className: (0, g.$)(eM().meta, { [eM().meta_withCover]: s2 }),
              children: [
                m2,
                r2.subtitle && (0, u.jsx)(Q, { caption: r2.subtitle, className: eM().subtitle, lineClamp: 3 }),
                r2.title && (0, u.jsx)(e_, { heading: r2.title, lineClamp: 3 }),
                v2 && r2.description && (0, u.jsx)(Q, { caption: r2.description, className: eM().description, lineClamp: 3 })
              ]
            })
          ]
        });
      });
      var eV = a(76064), eU = a.n(eV);
      let eF = (e10) => {
        var t2, a2;
        let { data: l2 } = e10;
        return (0, u.jsxs)("div", {
          className: eU().root,
          children: [
            (0, u.jsx)(Q, { caption: null != (t2 = l2.header) ? t2 : "", className: eU().text, lineClamp: 3 }),
            l2.stats.map(
              (e11) => (0, u.jsx)(
                ea,
                { data: e11, descriptionLineClamp: 2, withAutoResize: true, withOpacity: true },
                "".concat(e11.value, "-").concat(e11.valueDescription)
              )
            ),
            (0, u.jsx)(Q, { caption: null != (a2 = l2.footer) ? a2 : "", className: eU().text, lineClamp: 3 })
          ]
        });
      };
      !(function(e10) {
        e10.SMALL = "SMALL", e10.BIG = "BIG";
      })(c || (c = {}));
      var e$ = a(45186), eW = a.n(e$);
      let eY = (e10) => {
        var t2;
        let { data: a2 } = e10, l2 = a2.titleSize === c.BIG ? "xxl" : "xl";
        return (0, u.jsxs)("div", {
          className: eW().root,
          children: [
            (0, u.jsx)(B.Heading, { variant: "h2", size: l2, weight: "black", className: eW().text, children: a2.title }),
            (0, u.jsx)(Q, { caption: null != (t2 = a2.subtitle) ? t2 : "", className: eW().text, lineClamp: 3 })
          ]
        });
      };
      var eJ = a(69914), eZ = a.n(eJ);
      let eq = (e10) => {
        let {
          data: { title: t2, subtitle: a2, description: l2 }
        } = e10;
        return (0, u.jsxs)("div", {
          className: eZ().root,
          children: [
            (0, u.jsx)(B.Heading, {
              variant: "h2",
              size: "xxxl",
              weight: "black",
              className: (0, g.$)(eZ().text, eZ().header),
              dangerouslySetInnerHTML: { __html: (0, y.sanitizeDOM)(t2 || "") }
            }),
            (0, u.jsx)(B.Heading, {
              variant: "h3",
              size: "xl",
              weight: "black",
              className: eZ().text,
              dangerouslySetInnerHTML: { __html: (0, y.sanitizeDOM)(a2 || "") }
            }),
            l2 && (0, u.jsx)(B.Caption, {
              variant: "span",
              type: "text",
              size: "l",
              weight: "medium",
              className: eZ().text,
              dangerouslySetInnerHTML: { __html: (0, y.sanitizeDOM)(l2) }
            })
          ]
        });
      };
      var eQ = a(67958), e0 = a.n(eQ);
      let e1 = (e10) => {
        let { data: t2 } = e10, a2 = t2.coverType === i.CIRCLE ? "round" : "xs";
        return (0, u.jsxs)("div", {
          className: e0().root,
          children: [
            t2.smallCover && (0, u.jsx)(L.Paper, {
              radius: a2,
              className: e0().cover,
              children: (0, u.jsx)(O.BW, {
                src: t2.smallCover,
                withAvatarReplace: true,
                fit: "contain",
                size: 100,
                className: e0().image
              })
            }),
            t2.coverTitle && (0, u.jsx)(B.Heading, {
              variant: "span",
              weight: "bold",
              size: "l",
              className: e0().text,
              lineClamp: 3,
              children: t2.coverTitle
            }),
            (0, u.jsx)(ea, { data: t2, withAutoResize: true })
          ]
        });
      };
      var e2 = a(12978), e8 = a.n(e2);
      let e3 = (e10) => {
        let { label: t2, description: a2, artistsName: l2, trackTitle: i2, coverUri: r2 } = e10, n2 = [l2, i2].filter(Boolean).join(" • ");
        return (0, u.jsxs)("div", {
          children: [
            (0, u.jsx)(B.Heading, {
              className: (0, g.$)(e8().textSecondary, e8().itemLabel),
              variant: "h3",
              size: "s",
              weight: "black",
              children: t2
            }),
            (0, u.jsx)(h.Image, {
              className: e8().cover,
              src: r2,
              fit: "cover",
              withLoadingIndicator: false,
              withFallback: true,
              withAvatarReplace: true,
              withAspectRatio: true,
              "aria-hidden": true
            }),
            (0, u.jsx)(B.Caption, {
              className: (0, g.$)(e8().textPrimary, e8().itemMeta),
              variant: "div",
              type: "text",
              size: "l",
              weight: "medium",
              lineClamp: 2,
              children: n2
            }),
            (0, u.jsx)(B.Heading, {
              className: (0, g.$)(e8().textSecondary, e8().header),
              variant: "h3",
              size: "xl",
              weight: "black",
              children: a2
            })
          ]
        });
      }, e5 = (0, m.PA)((e10) => {
        var t2, a2, l2, i2, r2, n2, o2, s2, d2, c2, m2, _2;
        let { data: v2 } = e10, { title: p2, subtitle: C2, firstItem: x2, secondItem: S2 } = v2;
        return (0, u.jsxs)("div", {
          className: e8().root,
          children: [
            (0, u.jsxs)("div", {
              className: e8().row,
              children: [
                (0, u.jsx)(B.Heading, {
                  className: (0, g.$)(e8().textPrimary, e8().header),
                  variant: "h2",
                  size: "xxxl",
                  weight: "black",
                  children: p2
                }),
                (0, u.jsx)(B.Heading, {
                  className: e8().textPrimary,
                  variant: "h3",
                  size: "s",
                  weight: "black",
                  children: C2
                })
              ]
            }),
            x2 && (0, u.jsx)("div", {
              className: e8().row,
              children: (0, u.jsx)(e3, {
                label: x2.label,
                description: x2.description,
                artistsName: null != (o2 = null == (t2 = x2.track) ? void 0 : t2.artistsName) ? o2 : null,
                trackTitle: null != (s2 = null == (a2 = x2.track) ? void 0 : a2.title) ? s2 : null,
                coverUri: null != (d2 = null == (l2 = x2.track) ? void 0 : l2.coverUri) ? d2 : void 0
              })
            }),
            S2 && (0, u.jsx)("div", {
              className: e8().row,
              children: (0, u.jsx)(e3, {
                label: S2.label,
                description: S2.description,
                artistsName: null != (c2 = null == (i2 = S2.track) ? void 0 : i2.artistsName) ? c2 : null,
                trackTitle: null != (m2 = null == (r2 = S2.track) ? void 0 : r2.title) ? m2 : null,
                coverUri: null != (_2 = null == (n2 = S2.track) ? void 0 : n2.coverUri) ? _2 : void 0
              })
            })
          ]
        });
      }), e6 = (e10) => {
        let { content: t2, withPersonalColor: a2, ...l2 } = e10;
        if (null == t2 ? void 0 : t2.data)
          switch (t2.type) {
            case p.x.TEXT:
              return (0, u.jsx)(eY, { data: t2.data });
            case p.x.STATS:
              return (0, u.jsx)(eF, { data: t2.data });
            case p.x.CHART:
              return (0, u.jsx)(ef, { data: t2.data });
            case p.x.CHART_FAVORITES:
              return (0, u.jsx)(ej, { data: t2.data });
            case p.x.SINGLE_ENTITY:
              return (0, u.jsx)(ez, { data: t2.data, withPersonalColor: a2 });
            case p.x.TEXT_FACT:
              return (0, u.jsx)(e1, { data: t2.data });
            case p.x.CHART_ARTIST:
              return (0, u.jsx)(ek, { data: t2.data });
            case p.x.ARTISTS:
              return (0, u.jsx)(er, { data: t2.data });
            case p.x.TEXT_EXTENDED:
              return (0, u.jsx)(eq, { data: t2.data });
            case p.x.THEN_NOW_COMPARISON:
              return (0, u.jsx)(e5, { data: t2.data });
            case p.x.PAY_CARD:
              return (0, u.jsx)(eG, { data: t2.data });
            case p.x.CAROUSEL:
              return (0, u.jsx)(eC, { data: t2.data, ...l2 });
            case p.x.COLLAGE:
              return (0, u.jsx)(eO, { data: t2.data, onBackgroundChange: l2.onBackgroundChange, ...l2 });
          }
        return null;
      };
      var e4 = a(82071), e7 = a.n(e4);
      let e9 = true, te = (0, m.PA)((e10) => {
        var t2;
        let { slide: a2, isActive: i2 } = e10, {
          slides: { savedChoice: r2, saveChoice: n2, isMuted: o2 }
        } = (0, b.Pjs)(), s2 = (0, b.mFl)(), { carouselIndex: d2 = 0, setCarouselIndex: c2 } = a2, m2 = (0, b.jjz)(), y2 = (0, _.useRef)(null), [h2, K2] = (0, _.useState)(void 0), [N2, T2] = (0, _.useState)(0), [E2, I2] = (0, _.useState)(a2.background), { state: w2, toggleTrue: f2, toggleFalse: A2 } = (0, x.e)(false), R2 = (0, _.useMemo)(() => {
          let e11 = a2.content;
          if ((null == e11 ? void 0 : e11.data) && "align" in e11.data) {
            var t3;
            switch (null == (t3 = e11.data) ? void 0 : t3.align) {
              case l.TOP:
                return "top";
              case l.CENTER:
                break;
              case l.BOTTOM:
                return "bottom";
            }
          }
          return "center";
        }, [a2]);
        (0, _.useEffect)(() => {
          var e11, t3, l2, i3, r3;
          ((null == (e11 = a2.content) ? void 0 : e11.type) === p.x.CAROUSEL || (null == (t3 = a2.content) ? void 0 : t3.type) === p.x.COLLAGE) && T2(null != (r3 = null == (i3 = a2.content.data) || null == (l2 = i3.items) ? void 0 : l2.length) ? r3 : 0);
        }, [a2.content]), (0, _.useEffect)(() => {
          o2 || (e9 = true), o2 && e9 && (s2({ actionType: v.X2.MuteTrailer }), e9 = false);
        }, [o2, s2]);
        let j2 = (0, C.c)((e11) => K2(e11)), L2 = (0, C.c)(() => null == h2 ? void 0 : h2.slidePrev()), B2 = (0, C.c)(() => null == h2 ? void 0 : h2.slideNext()), O2 = (0, C.c)(() => {
          r2 && a2.savedChoiceKey && n2(a2.savedChoiceKey, { ...r2, isSaved: false });
        }), P2 = (0, C.c)(() => {
          var e11, t3, l2, i3, r3;
          if (!a2.savedChoiceKey || (null == (e11 = a2.content) ? void 0 : e11.type) !== p.x.CAROUSEL) return;
          let o3 = null == (i3 = a2.content.data) || null == (l2 = i3.items) || null == (t3 = l2[d2]) ? void 0 : t3.data;
          if (!o3) return;
          s2({ actionType: v.X2.SelectSlideItem, objectPosX: d2 + 1 });
          let { coverMask: c3, coverBackground: u2, title: g2, cover: m3 } = o3;
          n2(a2.savedChoiceKey, {
            data: { coverMask: c3, coverBackground: u2, text: g2, uri: null != (r3 = m3.uri) ? r3 : void 0 },
            index: d2,
            isSaved: true
          });
        }), D2 = (0, C.c)((e11, t3) => {
          c2(e11), T2(t3);
        }), G2 = (0, C.c)((e11) => I2({ ...E2, bgImageUrl: e11 }));
        return (0, u.jsx)("div", {
          className: (0, g.$)(e7().root, {
            [e7().wideContent]: (null == (t2 = a2.content) ? void 0 : t2.type) === p.x.COLLAGE
          }),
          ref: y2,
          children: (0, u.jsxs)(k, {
            isActive: i2,
            isContentVisible: w2,
            setContentVisible: f2,
            setContentInvisible: A2,
            background: E2,
            className: e7().background,
            children: [
              a2.logo && (0, u.jsx)(S.gu, { alignIcon: "center", className: e7().logo, "data-scale": true, lang: m2 }),
              a2.content && w2 && (0, u.jsx)("div", {
                className: (0, g.$)(e7().content, e7()["content_align_".concat(R2)], { [e7().playAnimation]: w2 }),
                children: (0, u.jsx)(e6, {
                  carouselIndex: d2,
                  content: a2.content,
                  withPersonalColor: a2.background.withPersonalColor,
                  onCarouselReady: j2,
                  onSlideChange: D2,
                  onBackgroundChange: G2
                })
              }),
              (0, u.jsx)("div", {
                "data-screenshot-hidden": true,
                className: e7().buttonsContainer,
                children: (0, u.jsx)($, {
                  cardRef: y2,
                  className: e7().button,
                  slide: a2,
                  onEditChoice: O2,
                  onSaveChoice: P2,
                  onSlidePrev: L2,
                  onSlideNext: B2,
                  hasLeft: d2 > 0,
                  hasRight: d2 < N2 - 1
                })
              })
            ]
          })
        });
      });
    },
    29854: (e) => {
      e.exports = { root: "ChartContent_root__MFONP", text: "ChartContent_text__cB18f" };
    },
    31016: (e) => {
      e.exports = {
        root: "CollageContent_root__NLzGo",
        slide: "CollageContent_slide__5PvMl",
        topBlock: "CollageContent_topBlock__7ckc_",
        topBlockBackground: "CollageContent_topBlockBackground__y6HYf",
        topBlockImageWrapper: "CollageContent_topBlockImageWrapper__Yc87n",
        topBlockImage: "CollageContent_topBlockImage__tePia",
        subtitle: "CollageContent_subtitle__M4cCR",
        title: "CollageContent_title__35r5H",
        bottomBlock: "CollageContent_bottomBlock__lSJaw",
        bottomBlock_item: "CollageContent_bottomBlock_item__kSW3C"
      };
    },
    31756: (e, t, a) => {
      "use strict";
      a.d(t, {
        EK: () => d,
        GF: () => n,
        Tu: () => o,
        VI: () => s,
        bF: () => c,
        bg: () => g,
        e0: () => m,
        fZ: () => r,
        g2: () => l,
        ur: () => u,
        wO: () => i
      });
      let l = "avatars.mds.yandex.net/get-music-misc/28592/img.68eebe12749d24738fe2018e/%%", i = "avatars.mds.yandex.net/get-music-misc/28592/img.68eebdb294053d016bcd7bf0/%%", r = 0.5, n = 1.5, o = 1, s = 1920, d = 20, c = 1.7, u = 16, g = ".swiper-pagination,[data-screenshot-hidden]", m = 600;
    },
    34340: (e) => {
      e.exports = {
        root: "ActionButton_root__YMLj2",
        cover: "ActionButton_cover__04uzU",
        image: "ActionButton_image__Lrf7N",
        text: "ActionButton_text__wPgyi",
        icon: "ActionButton_icon__fKoaq"
      };
    },
    45058: (e) => {
      e.exports = {
        root: "PayCard_root__wjBVD",
        title: "PayCard_title__t7qpS",
        description: "PayCard_description__hh2_O",
        text: "PayCard_text__w251H",
        artwork: "PayCard_artwork__9oAUA"
      };
    },
    45186: (e) => {
      e.exports = {
        root: "TextContent_root__A4Qmc",
        subtitle: "TextContent_subtitle__Xe_FH",
        text: "TextContent_text__xsfVD"
      };
    },
    67958: (e) => {
      e.exports = {
        root: "TextFactContent_root__vmKoy",
        text: "TextFactContent_text__e_xOX",
        cover: "TextFactContent_cover__xYsLC",
        image: "TextFactContent_image__FnWmg"
      };
    },
    68280: (e) => {
      e.exports = {
        root: "Carousel_root__2FSoC",
        "swiper-pagination-disabled": "Carousel_swiper-pagination-disabled__vC0R2",
        "swiper-pagination-clickable": "Carousel_swiper-pagination-clickable__M6UTw",
        "swiper-rtl": "Carousel_swiper-rtl__3mF21",
        "swiper-horizontal": "Carousel_swiper-horizontal__zEpGi",
        "swiper-vertical": "Carousel_swiper-vertical__1ADsJ",
        swiper: "Carousel_swiper__ivHi0",
        slide: "Carousel_slide__wgnHc",
        wrapper: "Carousel_wrapper__ruBr5"
      };
    },
    69282: (e) => {
      e.exports = {
        root: "SingleEntityContent_root__N2vvp",
        description: "SingleEntityContent_description__3pg2A",
        cover: "SingleEntityContent_cover__zeDqH",
        cover_withShadow: "SingleEntityContent_cover_withShadow__tMIE1",
        cover_small: "SingleEntityContent_cover_small___jnS4",
        meta: "SingleEntityContent_meta__XxJqA",
        meta_withCover: "SingleEntityContent_meta_withCover__Bp0Tx",
        smallRoundCover: "SingleEntityContent_smallRoundCover__jicWf",
        smallRoundCover_withShadow: "SingleEntityContent_smallRoundCover_withShadow__cjRgd",
        image: "SingleEntityContent_image__P6nK2",
        trailer: "SingleEntityContent_trailer__uYOk0",
        subtitle: "SingleEntityContent_subtitle__KuJyA"
      };
    },
    69914: (e) => {
      e.exports = {
        root: "TextExtendedContent_root__vzsuG",
        text: "TextExtendedContent_text__ksTX_",
        header: "TextExtendedContent_header__yn1Ej"
      };
    },
    75146: (e) => {
      e.exports = {
        root: "CarouselContent_root__fLntt",
        slide: "CarouselContent_slide__MdGZO",
        slideActive: "CarouselContent_slideActive__fECY6",
        disabled: "CarouselContent_disabled__fuxnG",
        description: "CarouselContent_description__IYsQ8",
        cover: "CarouselContent_cover__Oc6UR",
        meta: "CarouselContent_meta__0S_Xt",
        image: "CarouselContent_image__EKRdr",
        title: "CarouselContent_title__LHzEy",
        subtitle: "CarouselContent_subtitle__vZKi2"
      };
    },
    76064: (e) => {
      e.exports = { root: "StatsContent_root__yJVzS", text: "StatsContent_text__l2xi_" };
    },
    79074: (e) => {
      e.exports = {
        root: "StatItem_root__L7Uw0",
        root_withOpacity: "StatItem_root_withOpacity__pOgaf",
        valueContainer: "StatItem_valueContainer__HlYQZ",
        value: "StatItem_value__IkJBB",
        unit: "StatItem_unit__cO46p",
        footer: "StatItem_footer__QZ7q6"
      };
    },
    82071: (e) => {
      e.exports = {
        root: "SlideCard_root__RSnvj",
        background: "SlideCard_background__dftlE",
        logo: "SlideCard_logo__ocv3o",
        buttonsContainer: "SlideCard_buttonsContainer__ynOyN",
        wideContent: "SlideCard_wideContent__TSSJ9",
        playAnimation: "SlideCard_playAnimation__rFZZ3",
        fade: "SlideCard_fade__2HpC6",
        content: "SlideCard_content__7Y6aU",
        content_align_top: "SlideCard_content_align_top__fDfyz",
        content_align_center: "SlideCard_content_align_center__QFnxv",
        content_align_bottom: "SlideCard_content_align_bottom__nsslT",
        button: "SlideCard_button__EYX_G"
      };
    },
    82816: (e) => {
      e.exports = {
        root: "ChartArtistContent_root__OPxPJ",
        cover: "ChartArtistContent_cover__flhXs",
        image: "ChartArtistContent_image__D2isT",
        title: "ChartArtistContent_title__a_d_4"
      };
    },
    82864: (e) => {
      e.exports = { root: "SlideHeading_root__naZ6V" };
    },
    83510: (e, t, a) => {
      "use strict";
      var l;
      a.d(t, { x: () => l }), (function(e2) {
        e2.TEXT = "TEXT", e2.TEXT_FACT = "TEXT_FACT", e2.STATS = "STATS", e2.CHART = "CHART", e2.CHART_FAVORITES = "CHART_FAVORITES", e2.SINGLE_ENTITY = "SINGLE_ENTITY", e2.ARTISTS = "ARTISTS", e2.CHART_ARTIST = "CHART_ARTIST", e2.TEXT_EXTENDED = "TEXT_EXTENDED", e2.THEN_NOW_COMPARISON = "THEN_NOW_COMPARISON", e2.PAY_CARD = "PAY_CARD", e2.CAROUSEL = "CAROUSEL", e2.COLLAGE = "COLLAGE";
      })(l || (l = {}));
    },
    85511: (e) => {
      e.exports = {
        root: "ChartItem_root__nAl8B",
        animation: "ChartItem_animation__P8XVq",
        cover: "ChartItem_cover__jybex",
        order: "ChartItem_order__rTmAw",
        image: "ChartItem_image__enYFm",
        meta: "ChartItem_meta__apT_y",
        text: "ChartItem_text__qRsWe",
        textVariant: "ChartItem_textVariant__0NuuM",
        subTitle: "ChartItem_subTitle__J2Znt",
        stat: "ChartItem_stat__ofy5i",
        statValueContainer: "ChartItem_statValueContainer__pn9Ck",
        statValue: "ChartItem_statValue__fu5js"
      };
    },
    91453: (e) => {
      e.exports = {
        buttonsContainer: "SlideButtons_buttonsContainer__82Z3p",
        contractButton: "SlideButtons_contractButton__46CMy",
        editButton: "SlideButtons_editButton__r2XNo",
        iconButton: "SlideButtons_iconButton__oC0it",
        arrowLeftButton: "SlideButtons_arrowLeftButton__LL3LY",
        arrowRightButton: "SlideButtons_arrowRightButton__405wl",
        mainButtonContainer: "SlideButtons_mainButtonContainer__4htPC"
      };
    },
    92757: (e) => {
      e.exports = {
        root: "Background_root__s7ccu",
        media_withPersonalColor: "Background_media_withPersonalColor__KuaB0",
        firstFrame: "Background_firstFrame__c5Gw0",
        lastFrame: "Background_lastFrame__sfpL7",
        media: "Background_media__8DaeZ",
        hidden: "Background_hidden__7fdP5"
      };
    },
    92830: (e, t, a) => {
      "use strict";
      a.d(t, { AR: () => e_.SlideCard, z6: () => l, M1: () => em });
      var l = (function(e2) {
        return e2.USER = "user", e2.ARTIST = "artist", e2.PODCAST = "podcast", e2.SPECIAL = "special", e2.KIDS = "kids", e2;
      })({}), i = a(93064), r = a(83510), n = a(74125), o = a(7754), s = a(31756);
      let d = (e2) => (0, i.wg)({
        uri: null == e2 ? void 0 : e2.uri,
        color: null == e2 ? void 0 : e2.color,
        videoUrl: null == e2 ? void 0 : e2.videoUrl
      }), c = (e2) => {
        let { coverMask: t2, coverBackground: a2 } = e2;
        return t2 && a2 || (t2 = s.g2, a2 = s.wO), { coverMask: t2, coverBackground: a2 };
      }, u = (e2) => (0, i.wg)({
        value: e2.value,
        title: e2.title,
        titleType: e2.titleType,
        subtitle: e2.subtitle,
        cover: e2.cover,
        coverType: e2.coverType
      }), g = (e2) => (0, i.wg)({
        value: e2.value,
        valueDescription: e2.valueDescription,
        valueSuffix: e2.valueSuffix,
        footer: e2.footer
      }), m = (e2) => {
        var t2, a2, l2, i2, r2, n2, o2;
        return {
          label: null != (l2 = e2.label) ? l2 : null,
          description: null != (i2 = e2.description) ? i2 : null,
          track: {
            title: null != (r2 = e2.track.title) ? r2 : null,
            coverUri: null != (n2 = null == (t2 = e2.track.cover) ? void 0 : t2.uri) ? n2 : null,
            artistsName: null != (o2 = null == (a2 = e2.track.artists) ? void 0 : a2.map((e3) => e3.name).join(", ")) ? o2 : null
          }
        };
      }, _ = (e2, t2) => {
        var a2, l2, n2, _2, v2, p2, C2, x2, S2, b2, y2, h2, K2, N2, T2;
        let E2, k2, I2;
        if (null == (a2 = e2.button) ? void 0 : a2.type)
          switch (e2.button.type) {
            case o.m.ACTION:
              E2 = ((e3) => {
                var t3;
                return (0, i.wg)({
                  type: o.m.ACTION,
                  data: {
                    title: e3.data.title,
                    imageUrl: e3.data.imageUrl,
                    url: null == (t3 = e3.data.action) ? void 0 : t3.weblink
                  }
                });
              })(e2.button);
              break;
            case o.m.SIMPLE:
              E2 = ((e3) => (0, i.wg)({
                type: o.m.SIMPLE,
                data: {
                  title: e3.data.title,
                  buttonColor: e3.data.buttonColor,
                  textColor: e3.data.textColor,
                  url: e3.data.action.weblink
                }
              }))(e2.button);
              break;
            case o.m.SHARE:
              E2 = ((e3) => {
                let { data: t3 } = e3;
                return (0, i.wg)({
                  type: o.m.SHARE,
                  data: { title: t3.title, buttonColor: t3.bgColor, textColor: t3.titleColor }
                });
              })(e2.button);
          }
        let w2 = null != (p2 = e2.background.videoUrl) ? p2 : "";
        if (null == (l2 = e2.content) ? void 0 : l2.type)
          switch (null == (C2 = e2.content) ? void 0 : C2.type) {
            case r.x.CHART:
              k2 = ((e3) => (0, i.wg)({
                type: e3.type,
                data: {
                  description: e3.data.description,
                  isOrderVisible: !!e3.data.isOrderVisible,
                  items: e3.data.items.map(u)
                }
              }))(e2.content);
              break;
            case r.x.CHART_FAVORITES:
              k2 = ((e3) => (0, i.wg)({
                type: e3.type,
                data: {
                  value: e3.data.value,
                  valueDescription: e3.data.valueDescription,
                  valueSuffix: e3.data.valueSuffix,
                  footer: e3.data.footer,
                  description: e3.data.description,
                  isOrderVisible: !!e3.data.isOrderVisible,
                  items: e3.data.items.map(u)
                }
              }))(e2.content);
              break;
            case r.x.SINGLE_ENTITY:
              k2 = ((e3) => (0, i.wg)({
                type: e3.type,
                data: {
                  title: e3.data.title,
                  subtitle: e3.data.subtitle,
                  description: e3.data.description,
                  entityType: e3.data.entityType,
                  cover: d(e3.data.cover),
                  align: e3.data.align,
                  smallRoundCover: e3.data.smallRoundCover ? d(e3.data.smallRoundCover) : void 0,
                  ...c(e3.data)
                }
              }))(e2.content);
              break;
            case r.x.STATS:
              k2 = ((e3) => {
                var t3;
                return (0, i.wg)({
                  type: e3.type,
                  data: {
                    header: e3.data.header,
                    footer: null != (t3 = e3.data.footer) ? t3 : void 0,
                    align: e3.data.align,
                    stats: e3.data.stats.map(g)
                  }
                });
              })(e2.content);
              break;
            case r.x.TEXT:
              k2 = ((e3) => (0, i.wg)({
                type: e3.type,
                data: {
                  title: e3.data.title,
                  subtitle: e3.data.subtitle,
                  align: e3.data.align,
                  titleSize: e3.data.titleSize
                }
              }))(e2.content);
              break;
            case r.x.TEXT_FACT:
              k2 = ((e3) => {
                var t3, a3, l3;
                return (0, i.wg)({
                  type: e3.type,
                  data: {
                    ...g(e3.data),
                    coverType: null != (t3 = e3.data.coverType) ? t3 : null,
                    coverTitle: null != (a3 = e3.data.coverTitle) ? a3 : null,
                    smallCover: null != (l3 = e3.data.smallCover) ? l3 : null
                  }
                });
              })(e2.content);
              break;
            case r.x.CHART_ARTIST:
              k2 = ((e3) => {
                let t3 = e3.data.cover ? d(e3.data.cover) : null;
                return (0, i.wg)({
                  type: e3.type,
                  data: { title: e3.data.title, cover: t3, items: e3.data.items.map(u) }
                });
              })(e2.content);
              break;
            case r.x.ARTISTS:
              k2 = ((e3) => {
                let t3 = e3.data.covers ? e3.data.covers.slice(0, 3).map(d) : [];
                return (0, i.wg)({
                  type: e3.type,
                  data: {
                    value: e3.data.value,
                    valueDescription: e3.data.valueDescription,
                    valueSuffix: e3.data.valueSuffix,
                    footer: e3.data.footer,
                    covers: t3
                  }
                });
              })(e2.content);
              break;
            case r.x.TEXT_EXTENDED:
              k2 = ((e3) => {
                var t3, a3, l3;
                return {
                  type: e3.type,
                  data: {
                    title: null != (t3 = e3.data.title) ? t3 : null,
                    subtitle: null != (a3 = e3.data.subtitle) ? a3 : null,
                    description: null != (l3 = e3.data.description) ? l3 : null
                  }
                };
              })(e2.content);
              break;
            case r.x.THEN_NOW_COMPARISON:
              k2 = ((e3) => {
                var t3, a3;
                return {
                  type: e3.type,
                  data: {
                    title: null != (t3 = e3.data.title) ? t3 : null,
                    subtitle: null != (a3 = e3.data.subtitle) ? a3 : null,
                    firstItem: e3.data.firstItem ? m(e3.data.firstItem) : null,
                    secondItem: e3.data.secondItem ? m(e3.data.secondItem) : null
                  }
                };
              })(e2.content);
              break;
            case r.x.PAY_CARD:
              k2 = ((e3) => {
                var t3, a3, l3;
                return {
                  type: e3.type,
                  data: {
                    title: null != (t3 = e3.data.title) ? t3 : null,
                    description: null != (a3 = e3.data.description) ? a3 : null,
                    artwork: null != (l3 = e3.data.artwork) ? l3 : null
                  }
                };
              })(e2.content);
              break;
            case r.x.CAROUSEL:
              k2 = ((e3) => {
                let t3 = e3.data.items.map((e4) => ({
                  data: {
                    title: e4.data.title,
                    subtitle: e4.data.subtitle,
                    description: e4.data.description,
                    cover: d(e4.data.cover),
                    coverPlaceholder: e4.data.coverPlaceholder,
                    ...c(e4.data)
                  }
                }));
                return (0, i.wg)({ type: e3.type, data: { savedChoiceKey: e3.data.savedChoiceKey, items: t3 } });
              })(e2.content), I2 = null == (S2 = e2.content) || null == (x2 = S2.data) ? void 0 : x2.savedChoiceKey;
              break;
            case r.x.COLLAGE:
              k2 = ((e3) => {
                let {
                  data: { items: t3 },
                  type: a3
                } = e3, l3 = t3.map((e4) => ({
                  contentBackground: { uri: e4.contentBackground.uri },
                  bottomBlock: {
                    type: e4.bottomBlock.type,
                    data: {
                      items: e4.bottomBlock.data.items.map((e5) => {
                        let { type: t4, data: a4 } = e5;
                        return { type: t4, data: { key: a4.key, title: a4.title, subtitle: a4.subtitle } };
                      })
                    }
                  },
                  topBlock: {
                    type: e4.topBlock.type,
                    data: {
                      background: { uri: e4.topBlock.data.background.uri },
                      items: e4.topBlock.data.items.map((e5) => {
                        let { type: t4, data: a4 } = e5;
                        return {
                          type: t4,
                          data: {
                            key: a4.key,
                            uri: a4.uri,
                            rectangle: {
                              x: a4.rectangle.x,
                              y: a4.rectangle.y,
                              z: a4.rectangle.z,
                              width: a4.rectangle.width,
                              height: a4.rectangle.height
                            }
                          }
                        };
                      })
                    }
                  }
                }));
                return (0, i.wg)({ type: a3, data: { items: l3 } });
              })(e2.content), w2 = "";
          }
        let f2 = null != (b2 = null == (n2 = e2.trailer) ? void 0 : n2.tracks) ? b2 : [], A2 = null != (y2 = null == (_2 = e2.meta) ? void 0 : _2.animationDelay) ? y2 : s.fZ;
        return (0, i.wg)({
          id: e2.id,
          background: {
            animationDelay: A2,
            bgImageUrl: null != (h2 = e2.background.bgImageUrl) ? h2 : "",
            videoUrl: w2,
            withSound: !!e2.background.withSound,
            firstFrameVideoUrl: null != (K2 = e2.background.firstFrameVideoUrl) ? K2 : "",
            lastFrameVideoUrl: null != (N2 = e2.background.lastFrameVideoUrl) ? N2 : "",
            withPersonalColor: !!e2.background.withPersonalColor,
            videoLoopEnabled: !!e2.background.videoLoopEnabled
          },
          slideColor: null == (v2 = e2.meta) ? void 0 : v2.color,
          button: E2,
          content: k2,
          trailerRawTracks: f2,
          logo: null != (T2 = null == t2 ? void 0 : t2.logo) ? T2 : null,
          savedChoiceKey: I2
        });
      };
      var v = a(5693);
      let p = i.gK.model("SlideButtonActionData", {
        title: i.gK.maybeNull(i.gK.string),
        imageUrl: i.gK.maybeNull(i.gK.string),
        url: i.gK.maybeNull(i.gK.string)
      }), C = i.gK.model("SlideButtonAction", { type: i.gK.literal(o.m.ACTION), data: p }), x = i.gK.model("SlideButtonSimpleData", {
        title: i.gK.maybeNull(i.gK.string),
        buttonColor: i.gK.maybeNull(i.gK.string),
        textColor: i.gK.maybeNull(i.gK.string)
      }), S = i.gK.model("SlideButtonShare", { type: i.gK.literal(o.m.SHARE), data: x }), b = i.gK.model("SlideButtonSimpleData", {
        title: i.gK.maybeNull(i.gK.string),
        buttonColor: i.gK.maybeNull(i.gK.string),
        textColor: i.gK.maybeNull(i.gK.string),
        url: i.gK.maybeNull(i.gK.string)
      }), y = i.gK.model("SlideButtonSimple", { type: i.gK.literal(o.m.SIMPLE), data: b }), h = i.gK.model("SlideContentCover", {
        uri: i.gK.maybeNull(i.gK.string),
        color: i.gK.maybeNull(i.gK.string),
        videoUrl: i.gK.maybeNull(i.gK.string)
      }), K = i.gK.model("SlideContentStat", {
        value: i.gK.maybeNull(i.gK.number),
        valueDescription: i.gK.maybeNull(i.gK.string),
        valueSuffix: i.gK.maybeNull(i.gK.string),
        footer: i.gK.maybeNull(i.gK.string)
      }), N = i.gK.compose(i.gK.model("SlideContentArtistsModelData", { covers: i.gK.array(h) }), K), T = i.gK.model("SlideContentArtistsModel", { type: i.gK.literal(r.x.ARTISTS), data: i.gK.maybe(N) }), E = i.gK.model("SlideContentCarouselItemData", {
        title: i.gK.maybe(i.gK.string),
        subtitle: i.gK.maybe(i.gK.string),
        description: i.gK.maybe(i.gK.string),
        cover: h,
        coverMask: i.gK.maybe(i.gK.string),
        coverBackground: i.gK.maybe(i.gK.string),
        coverPlaceholder: i.gK.maybe(i.gK.string)
      }), k = i.gK.model("SlideContentCarouselItem", { data: E }), I = i.gK.model("SlideContentCarouselData", { savedChoiceKey: i.gK.maybe(i.gK.string), items: i.gK.array(k) }), w = i.gK.model("SlideContentCarousel", { type: i.gK.literal(r.x.CAROUSEL), data: i.gK.maybe(I) }), f = i.gK.model("SlideContentItem", {
        value: i.gK.maybeNull(i.gK.number),
        title: i.gK.maybeNull(i.gK.string),
        titleType: i.gK.maybeNull(i.gK.string),
        subtitle: i.gK.maybeNull(i.gK.string),
        cover: i.gK.maybeNull(h),
        coverType: i.gK.maybeNull(i.gK.string)
      }), A = i.gK.model("SlideContentChartArtistData", {
        title: i.gK.maybeNull(i.gK.string),
        cover: i.gK.maybeNull(h),
        items: i.gK.array(f)
      }), R = i.gK.model("SlideContentChartArtist", { type: i.gK.literal(r.x.CHART_ARTIST), data: i.gK.maybe(A) }), j = i.gK.compose(
        i.gK.model("SlideContentChartFavoritesData", {
          description: i.gK.maybeNull(i.gK.string),
          isOrderVisible: i.gK.boolean,
          items: i.gK.array(f)
        }),
        K
      ), L = i.gK.model("SlideContentChartFavorites", { type: i.gK.literal(r.x.CHART_FAVORITES), data: i.gK.maybe(j) }), B = i.gK.model("SlideContentChartData", {
        description: i.gK.maybeNull(i.gK.string),
        isOrderVisible: i.gK.boolean,
        items: i.gK.array(f)
      }), O = i.gK.model("SlideContentChart", { type: i.gK.literal(r.x.CHART), data: i.gK.maybe(B) }), P = i.gK.model("SlideContentCollageRectangle", {
        x: i.gK.number,
        y: i.gK.number,
        z: i.gK.number,
        width: i.gK.number,
        height: i.gK.number
      }), D = i.gK.model("SlideContentCollageBottomBlockItemData", {
        key: i.gK.maybe(i.gK.string),
        title: i.gK.maybe(i.gK.string),
        subtitle: i.gK.maybe(i.gK.string)
      }), G = i.gK.model("SlideContentCollageBottomBlockItem", { type: i.gK.string, data: D }), X = i.gK.model("SlideContentCollageBottomBlockData", { items: i.gK.array(G) }), H = i.gK.model("SlideContentCollageTopBlockItemData", {
        key: i.gK.maybe(i.gK.string),
        uri: i.gK.maybe(i.gK.string),
        rectangle: P
      }), M = i.gK.model("SlideContentCollageTopBlockItem", { type: i.gK.string, data: H }), z = i.gK.model("SlideContentCollageTopBlockData", {
        background: i.gK.model("SlideContentCollageTopBlockBackground", { uri: i.gK.maybe(i.gK.string) }),
        items: i.gK.array(M)
      }), V = i.gK.model("SlideContentCollageItem", {
        contentBackground: i.gK.model("SlideContentCollageContentBackground", { uri: i.gK.maybe(i.gK.string) }),
        bottomBlock: i.gK.model("SlideContentCollageBottomBlock", { type: i.gK.string, data: X }),
        topBlock: i.gK.model("SlideContentCollageTopBlock", { type: i.gK.string, data: z })
      }), U = i.gK.model("SlideContentCollageData", { items: i.gK.array(V) }), F = i.gK.model("SlideContentCollage", { type: i.gK.literal(r.x.COLLAGE), data: U }), $ = i.gK.model("SlideContentPayCardData", {
        title: i.gK.maybeNull(i.gK.string),
        description: i.gK.maybeNull(i.gK.string),
        artwork: i.gK.maybeNull(i.gK.string)
      }), W = i.gK.model("SlideContentPayCard", { type: i.gK.literal(r.x.PAY_CARD), data: i.gK.maybe($) }), Y = i.gK.model("SlideContentSingleEntityData", {
        title: i.gK.maybeNull(i.gK.string),
        subtitle: i.gK.maybeNull(i.gK.string),
        description: i.gK.maybeNull(i.gK.string),
        entityType: i.gK.maybeNull(i.gK.string),
        cover: h,
        coverMask: i.gK.string,
        coverBackground: i.gK.string,
        align: i.gK.maybe(i.gK.string),
        smallRoundCover: i.gK.maybeNull(h)
      }), J = i.gK.model("SlideContentSingleEntity", { type: i.gK.literal(r.x.SINGLE_ENTITY), data: i.gK.maybe(Y) }), Z = i.gK.model("SlideContentStatsData", {
        header: i.gK.maybeNull(i.gK.string),
        footer: i.gK.maybeNull(i.gK.string),
        align: i.gK.maybeNull(i.gK.string),
        stats: i.gK.array(K)
      }), q = i.gK.model("SlideContentStats", { type: i.gK.literal(r.x.STATS), data: i.gK.maybe(Z) }), Q = i.gK.model("SlideContentTextExtendedData", {
        title: i.gK.maybeNull(i.gK.string),
        subtitle: i.gK.maybeNull(i.gK.string),
        description: i.gK.maybeNull(i.gK.string)
      }), ee = i.gK.model("SlideContentTextExtended", { type: i.gK.literal(r.x.TEXT_EXTENDED), data: i.gK.maybe(Q) }), et = i.gK.compose(
        i.gK.model("SlideContentTextFactDataModel", {
          coverType: i.gK.maybeNull(i.gK.string),
          coverTitle: i.gK.maybeNull(i.gK.string),
          smallCover: i.gK.maybeNull(i.gK.string)
        }),
        K
      ), ea = i.gK.model("SlideContentTextFact", { type: i.gK.literal(r.x.TEXT_FACT), data: i.gK.maybe(et) }), el = i.gK.model("SlideContentTextData", {
        title: i.gK.maybeNull(i.gK.string),
        subtitle: i.gK.maybeNull(i.gK.string),
        align: i.gK.maybeNull(i.gK.string),
        titleSize: i.gK.maybeNull(i.gK.string)
      }), ei = i.gK.model("SlideContentText", { type: i.gK.literal(r.x.TEXT), data: i.gK.maybe(el) }), er = i.gK.model("SlideContentThenNowComparisonItemTrack", {
        title: i.gK.maybeNull(i.gK.string),
        coverUri: i.gK.maybeNull(i.gK.string),
        artistsName: i.gK.maybeNull(i.gK.string)
      }), en = i.gK.model("SlideContentThenNowComparisonItem", {
        label: i.gK.maybeNull(i.gK.string),
        description: i.gK.maybeNull(i.gK.string),
        track: i.gK.maybeNull(er)
      }), eo = i.gK.model("SlideContentThenNowComparisonData", {
        title: i.gK.maybeNull(i.gK.string),
        subtitle: i.gK.maybeNull(i.gK.string),
        firstItem: i.gK.maybeNull(en),
        secondItem: i.gK.maybeNull(en)
      }), es = i.gK.model("SlideContentThenNowComparison", {
        type: i.gK.literal(r.x.THEN_NOW_COMPARISON),
        data: i.gK.maybe(eo)
      }), ed = i.gK.model("SlideBackground", {
        animationDelay: i.gK.number,
        bgImageUrl: i.gK.string,
        videoUrl: i.gK.string,
        withSound: i.gK.boolean,
        firstFrameVideoUrl: i.gK.string,
        lastFrameVideoUrl: i.gK.string,
        withPersonalColor: i.gK.boolean,
        videoLoopEnabled: i.gK.boolean
      }), ec = i.gK.model("Slide", {
        id: i.gK.string,
        background: ed,
        button: i.gK.maybe(i.gK.union(C, S, y)),
        slideColor: i.gK.maybeNull(i.gK.string),
        content: i.gK.maybe(i.gK.union(O, L, J, ei, q, ea, R, T, ee, es, W, w, F)),
        trailerRawTracks: i.gK.maybeNull(i.gK.frozen()),
        logo: i.gK.maybeNull(i.gK.string),
        savedChoiceKey: i.gK.maybe(i.gK.string),
        carouselIndex: i.gK.maybe(i.gK.number)
      }).views((e2) => ({
        get hasTrailer() {
          var t2;
          return !!(null == (t2 = e2.trailerRawTracks) ? void 0 : t2.length);
        },
        get entitiesData() {
          if (!e2.trailerRawTracks) return [];
          return e2.trailerRawTracks.map((e3) => ({ type: v.R.SmartPreview, meta: e3 }));
        }
      })).actions((e2) => ({
        setCarouselIndex(t2) {
          e2.carouselIndex = t2;
        }
      })), eu = i.gK.model("SavedChoiceData", {
        text: i.gK.maybe(i.gK.string),
        uri: i.gK.maybe(i.gK.string),
        coverMask: i.gK.maybe(i.gK.string),
        coverBackground: i.gK.maybe(i.gK.string)
      }), eg = i.gK.model("SavedChoice", { index: i.gK.number, isSaved: i.gK.boolean, data: eu }), em = i.gK.model("Slides", {
        userSlidesLoadingState: i.gK.enumeration(Object.values(n.GuX)),
        artistSlidesLoadingState: i.gK.enumeration(Object.values(n.GuX)),
        podcastSlidesLoadingState: i.gK.enumeration(Object.values(n.GuX)),
        specialSlidesLoadingState: i.gK.enumeration(Object.values(n.GuX)),
        kidsSlidesLoadingState: i.gK.enumeration(Object.values(n.GuX)),
        consumer: i.gK.maybe(i.gK.enumeration(Object.values(l))),
        artistId: i.gK.maybe(i.gK.string),
        podcastId: i.gK.maybe(i.gK.number),
        campaignId: i.gK.maybe(i.gK.string),
        activeSlide: i.gK.optional(i.gK.number, 0),
        userItems: i.gK.array(ec),
        artistItems: i.gK.array(ec),
        podcastItems: i.gK.array(ec),
        specialItems: i.gK.array(ec),
        kidsItems: i.gK.array(ec),
        isMuted: i.gK.boolean,
        savedChoices: i.gK.map(eg),
        mainObjectId: i.gK.optional(i.gK.string, "")
      }).views((e2) => ({
        get isLoaded() {
          return e2.userSlidesLoadingState === n.GuX.RESOLVE || e2.artistSlidesLoadingState === n.GuX.RESOLVE || e2.podcastSlidesLoadingState === n.GuX.RESOLVE || e2.specialSlidesLoadingState === n.GuX.RESOLVE || e2.kidsSlidesLoadingState === n.GuX.RESOLVE;
        },
        get savedChoice() {
          var t2, a2;
          if (e2.consumer !== l.USER) return;
          return e2.savedChoices.get(
            null != (a2 = null == (t2 = e2.userItems[e2.activeSlide]) ? void 0 : t2.savedChoiceKey) ? a2 : ""
          );
        }
      })).actions((e2) => {
        let t2 = {
          setIsMuted: (t3) => {
            e2.isMuted = t3;
          },
          toggleMute: () => {
            e2.isMuted = !e2.isMuted;
          },
          getUserSlides: (0, i.L3)(function* () {
            let { slidesResource: a2, modelActionsLogger: r2 } = (0, i._$)(e2);
            if (e2.userSlidesLoadingState !== n.GuX.PENDING)
              try {
                e2.userSlidesLoadingState = n.GuX.PENDING;
                let r3 = yield a2.getUserSlides();
                e2.userSlidesLoadingState !== n.GuX.IDLE && (e2.userSlidesLoadingState = n.GuX.RESOLVE), r3.slides && (e2.consumer = l.USER, e2.mainObjectId = e2.consumer, e2.userItems = (0, i.wg)(t2.processSlidesResponse(r3))), e2.userSlidesLoadingState = n.GuX.RESOLVE;
              } catch (t3) {
                r2.error(t3), e2.userSlidesLoadingState !== n.GuX.IDLE && (e2.userSlidesLoadingState = n.GuX.REJECT, e2.userItems = (0, i.wg)([]));
              }
          }),
          getArtistSlides: (0, i.L3)(function* (a2) {
            let { slidesResource: r2, modelActionsLogger: o2 } = (0, i._$)(e2);
            if (e2.artistSlidesLoadingState !== n.GuX.PENDING) {
              e2.artistId = a2.artistId;
              try {
                e2.artistSlidesLoadingState = n.GuX.PENDING;
                let o3 = yield r2.getArtistSlides(a2);
                e2.artistSlidesLoadingState !== n.GuX.IDLE && (e2.artistSlidesLoadingState = n.GuX.RESOLVE), o3.slides && (e2.consumer = l.ARTIST, e2.mainObjectId = "".concat(e2.consumer, ":").concat(e2.artistId), e2.artistItems = (0, i.wg)(t2.processSlidesResponse(o3))), e2.artistSlidesLoadingState = n.GuX.RESOLVE;
              } catch (t3) {
                o2.error(t3), e2.artistSlidesLoadingState !== n.GuX.IDLE && (e2.artistSlidesLoadingState = n.GuX.REJECT, e2.artistItems = (0, i.wg)([]));
              }
            }
          }),
          getPodcastSlides: (0, i.L3)(function* (a2) {
            let { slidesResource: r2, modelActionsLogger: o2 } = (0, i._$)(e2);
            if (e2.podcastSlidesLoadingState !== n.GuX.PENDING) {
              e2.podcastId = a2.podcastId;
              try {
                e2.podcastSlidesLoadingState = n.GuX.PENDING;
                let o3 = yield r2.getPodcastSlides(a2);
                e2.podcastSlidesLoadingState !== n.GuX.IDLE && (e2.podcastSlidesLoadingState = n.GuX.RESOLVE), o3.slides && (e2.consumer = l.PODCAST, e2.mainObjectId = "".concat(e2.consumer, ":").concat(e2.podcastId), e2.podcastItems = (0, i.wg)(t2.processSlidesResponse(o3))), e2.podcastSlidesLoadingState = n.GuX.RESOLVE;
              } catch (t3) {
                o2.error(t3), e2.podcastSlidesLoadingState !== n.GuX.IDLE && (e2.podcastSlidesLoadingState = n.GuX.REJECT, e2.podcastItems = (0, i.wg)([]));
              }
            }
          }),
          getSpecialSlides: (0, i.L3)(function* (a2) {
            let { slidesResource: r2, modelActionsLogger: o2 } = (0, i._$)(e2);
            if (e2.specialSlidesLoadingState !== n.GuX.PENDING) {
              e2.campaignId = a2.campaignId;
              try {
                e2.specialSlidesLoadingState = n.GuX.PENDING;
                let o3 = yield r2.getSpecialSlides(a2);
                e2.specialSlidesLoadingState !== n.GuX.IDLE && (e2.specialSlidesLoadingState = n.GuX.RESOLVE), o3.slides && (e2.consumer = l.SPECIAL, e2.mainObjectId = "".concat(e2.consumer, ":").concat(e2.campaignId), e2.specialItems = (0, i.wg)(t2.processSlidesResponse(o3))), e2.specialSlidesLoadingState = n.GuX.RESOLVE;
              } catch (t3) {
                o2.error(t3), e2.specialSlidesLoadingState !== n.GuX.IDLE && (e2.specialSlidesLoadingState = n.GuX.REJECT, e2.specialItems = (0, i.wg)([]));
              }
            }
          }),
          getKidsSlides: (0, i.L3)(function* () {
            let { slidesResource: a2, modelActionsLogger: r2 } = (0, i._$)(e2);
            if (e2.kidsSlidesLoadingState !== n.GuX.PENDING)
              try {
                e2.kidsSlidesLoadingState = n.GuX.PENDING;
                let r3 = yield a2.getKidsSlides();
                e2.kidsSlidesLoadingState !== n.GuX.IDLE && (e2.kidsSlidesLoadingState = n.GuX.RESOLVE), r3.slides && (e2.consumer = l.KIDS, e2.mainObjectId = e2.consumer, e2.kidsItems = (0, i.wg)(t2.processSlidesResponse(r3))), e2.kidsSlidesLoadingState = n.GuX.RESOLVE;
              } catch (t3) {
                r2.error(t3), e2.kidsSlidesLoadingState !== n.GuX.IDLE && (e2.kidsSlidesLoadingState = n.GuX.REJECT, e2.kidsItems = (0, i.wg)([]));
              }
          }),
          setActiveSlide(t3) {
            e2.activeSlide = t3;
          },
          resetUser() {
            e2.userSlidesLoadingState = n.GuX.IDLE, e2.userItems = (0, i.wg)([]);
          },
          resetArtist() {
            e2.artistSlidesLoadingState = n.GuX.IDLE, e2.artistItems = (0, i.wg)([]);
          },
          resetPodcast() {
            e2.podcastSlidesLoadingState = n.GuX.IDLE, e2.podcastItems = (0, i.wg)([]);
          },
          resetKids() {
            e2.kidsSlidesLoadingState = n.GuX.IDLE, e2.kidsItems = (0, i.wg)([]);
          },
          resetSpecial() {
            e2.specialSlidesLoadingState = n.GuX.IDLE, e2.specialItems = (0, i.wg)([]);
          },
          saveChoice(t3, a2) {
            e2.savedChoices.set(t3, a2);
          },
          processSlidesResponse(e3) {
            let a2 = [];
            for (let c2 of e3.slides) {
              var l2, i2, n2, o2, s2, d2;
              let u2 = _(c2, { logo: e3.logo });
              if (a2.push(u2), u2.savedChoiceKey && (null == (l2 = u2.content) ? void 0 : l2.type) === r.x.CAROUSEL) {
                let e4 = null == (o2 = u2.content) || null == (n2 = o2.data) || null == (i2 = n2.items[0]) ? void 0 : i2.data;
                if (!e4) continue;
                t2.saveChoice(u2.savedChoiceKey, {
                  index: 0,
                  isSaved: false,
                  data: {
                    coverBackground: e4.coverBackground,
                    coverMask: e4.coverMask,
                    text: e4.title,
                    uri: null != (d2 = null == (s2 = e4.cover) ? void 0 : s2.uri) ? d2 : void 0
                  }
                });
              }
            }
            return a2;
          }
        };
        return t2;
      });
      var e_ = a(18259);
    },
    93988: (e) => {
      e.exports = { root: "SlideCaption_root__JumhY" };
    },
    94894: (e) => {
      e.exports = { root: "ChartFavoriteContent_root__ksE_w", description: "ChartFavoriteContent_description__CCBKM" };
    },
    99020: (e) => {
      e.exports = { root: "CommonButton_root__thXs_" };
    }
  }
]);
