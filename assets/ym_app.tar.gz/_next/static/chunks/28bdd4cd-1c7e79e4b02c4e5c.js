"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6706],
  {
    63930: (e, t, n) => {
      function r(e10) {
        for (var t10 = arguments.length, n2 = Array(t10 > 1 ? t10 - 1 : 0), r2 = 1; r2 < t10; r2++) n2[r2 - 1] = arguments[r2];
        throw Error(
          "number" == typeof e10 ? "[MobX] minified error nr: " + e10 + (n2.length ? " " + n2.map(String).join(",") : "") + ". Find the full error at: https://github.com/mobxjs/mobx/blob/main/packages/mobx/src/errors.ts" : "[MobX] " + e10
        );
      }
      n.d(t, {
        EW: () => eL,
        Es: () => nf,
        Fq: () => nc,
        Gn: () => t5,
        HO: () => tZ,
        MN: () => en,
        Mr: () => nC,
        OB: () => nw,
        XI: () => tA,
        Zc: () => tq,
        _t: () => tS,
        go: () => nV,
        hZ: () => function e10(t10, n2, i2) {
          if (2 == arguments.length && !np(t10)) {
            to();
            var o2 = n2;
            try {
              for (var a2 in o2) e10(t10, a2, o2[a2]);
            } finally {
              ta();
            }
            return;
          }
          nw(t10) ? t10[Q].set_(n2, i2) : n_(t10) ? t10.set(n2, i2) : np(t10) ? t10.add(n2) : nc(t10) ? ("number" != typeof n2 && (n2 = parseInt(n2, 10)), n2 < 0 && r("Invalid index: '" + n2 + "'"), to(), n2 >= t10.length && (t10.length = n2 + 1), t10[n2] = i2, ta()) : r(8);
        },
        jK: () => tC,
        jO: () => tF,
        lB: () => tY,
        mJ: () => tP,
        n8: () => tX,
        pA: () => tG,
        qT: () => tc,
        sG: () => tn,
        sH: () => eV,
        yl: () => tR,
        z7: () => tQ,
        zu: () => tz
      });
      var i, o, a, s, u, c, l, h, f, _, v = {};
      function d() {
        return "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : void 0 !== n.g ? n.g : "undefined" != typeof self ? self : v;
      }
      var p = Object.assign, b = Object.getOwnPropertyDescriptor, g = Object.defineProperty, y = Object.prototype, m = [];
      Object.freeze(m);
      var O = {};
      Object.freeze(O);
      var A = "undefined" != typeof Proxy, w = Object.toString();
      function S() {
        A || r("Proxy not available");
      }
      function j(e10) {
        var t10 = false;
        return function() {
          if (!t10) return t10 = true, e10.apply(this, arguments);
        };
      }
      var E = function() {
      };
      function x(e10) {
        return "function" == typeof e10;
      }
      function k(e10) {
        switch (typeof e10) {
          case "string":
          case "symbol":
          case "number":
            return true;
        }
        return false;
      }
      function P(e10) {
        return null !== e10 && "object" == typeof e10;
      }
      function T(e10) {
        if (!P(e10)) return false;
        var t10 = Object.getPrototypeOf(e10);
        if (null == t10) return true;
        var n2 = Object.hasOwnProperty.call(t10, "constructor") && t10.constructor;
        return "function" == typeof n2 && n2.toString() === w;
      }
      function N(e10) {
        var t10 = null == e10 ? void 0 : e10.constructor;
        return !!t10 && ("GeneratorFunction" === t10.name || "GeneratorFunction" === t10.displayName);
      }
      function V(e10, t10, n2) {
        g(e10, t10, { enumerable: false, writable: true, configurable: true, value: n2 });
      }
      function C(e10, t10, n2) {
        g(e10, t10, { enumerable: false, writable: false, configurable: true, value: n2 });
      }
      function R(e10, t10) {
        var n2 = "isMobX" + e10;
        return t10.prototype[n2] = true, function(e11) {
          return P(e11) && true === e11[n2];
        };
      }
      function D(e10) {
        return e10 instanceof Map;
      }
      function L(e10) {
        return e10 instanceof Set;
      }
      var B = void 0 !== Object.getOwnPropertySymbols, M = "undefined" != typeof Reflect && Reflect.ownKeys ? Reflect.ownKeys : B ? function(e10) {
        return Object.getOwnPropertyNames(e10).concat(Object.getOwnPropertySymbols(e10));
      } : Object.getOwnPropertyNames;
      function I(e10) {
        return null === e10 ? null : "object" == typeof e10 ? "" + e10 : e10;
      }
      function U(e10, t10) {
        return y.hasOwnProperty.call(e10, t10);
      }
      var K = Object.getOwnPropertyDescriptors || function(e10) {
        var t10 = {};
        return M(e10).forEach(function(n2) {
          t10[n2] = b(e10, n2);
        }), t10;
      };
      function G(e10, t10) {
        for (var n2 = 0; n2 < t10.length; n2++) {
          var r2 = t10[n2];
          r2.enumerable = r2.enumerable || false, r2.configurable = true, "value" in r2 && (r2.writable = true), Object.defineProperty(
            e10,
            (function(e11) {
              var t11 = (function(e12, t12) {
                if ("object" != typeof e12 || null === e12) return e12;
                var n3 = e12[Symbol.toPrimitive];
                if (void 0 !== n3) {
                  var r3 = n3.call(e12, t12 || "default");
                  if ("object" != typeof r3) return r3;
                  throw TypeError("@@toPrimitive must return a primitive value.");
                }
                return ("string" === t12 ? String : Number)(e12);
              })(e11, "string");
              return "symbol" == typeof t11 ? t11 : String(t11);
            })(r2.key),
            r2
          );
        }
      }
      function q(e10, t10, n2) {
        return t10 && G(e10.prototype, t10), n2 && G(e10, n2), Object.defineProperty(e10, "prototype", { writable: false }), e10;
      }
      function H() {
        return (H = Object.assign ? Object.assign.bind() : function(e10) {
          for (var t10 = 1; t10 < arguments.length; t10++) {
            var n2 = arguments[t10];
            for (var r2 in n2) Object.prototype.hasOwnProperty.call(n2, r2) && (e10[r2] = n2[r2]);
          }
          return e10;
        }).apply(this, arguments);
      }
      function W(e10, t10) {
        e10.prototype = Object.create(t10.prototype), e10.prototype.constructor = e10, z(e10, t10);
      }
      function z(e10, t10) {
        return (z = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e11, t11) {
          return e11.__proto__ = t11, e11;
        })(e10, t10);
      }
      function F(e10) {
        if (void 0 === e10) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
        return e10;
      }
      function X(e10, t10) {
        (null == t10 || t10 > e10.length) && (t10 = e10.length);
        for (var n2 = 0, r2 = Array(t10); n2 < t10; n2++) r2[n2] = e10[n2];
        return r2;
      }
      function Y(e10, t10) {
        var n2 = "undefined" != typeof Symbol && e10[Symbol.iterator] || e10["@@iterator"];
        if (n2) return (n2 = n2.call(e10)).next.bind(n2);
        if (Array.isArray(e10) || (n2 = (function(e11, t11) {
          if (e11) {
            if ("string" == typeof e11) return X(e11, void 0);
            var n3 = Object.prototype.toString.call(e11).slice(8, -1);
            if ("Object" === n3 && e11.constructor && (n3 = e11.constructor.name), "Map" === n3 || "Set" === n3)
              return Array.from(e11);
            if ("Arguments" === n3 || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n3)) return X(e11, void 0);
          }
        })(e10)) || t10 && e10 && "number" == typeof e10.length) {
          n2 && (e10 = n2);
          var r2 = 0;
          return function() {
            return r2 >= e10.length ? { done: true } : { done: false, value: e10[r2++] };
          };
        }
        throw TypeError(
          "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      }
      var J = /* @__PURE__ */ Symbol("mobx-stored-annotations");
      function Z(e10) {
        return Object.assign(function(t10, n2) {
          $(t10, n2, e10);
        }, e10);
      }
      function $(e10, t10, n2) {
        U(e10, J) || V(e10, J, H({}, e10[J])), "override" !== n2.annotationType_ && (e10[J][t10] = n2);
      }
      var Q = /* @__PURE__ */ Symbol("mobx administration"), ee = (function() {
        function e10(e11) {
          void 0 === e11 && (e11 = "Atom"), this.name_ = void 0, this.isPendingUnobservation_ = false, this.isBeingObserved_ = false, this.observers_ = /* @__PURE__ */ new Set(), this.diffValue_ = 0, this.lastAccessedBy_ = 0, this.lowestObserverState_ = u.NOT_TRACKING_, this.onBOL = void 0, this.onBUOL = void 0, this.name_ = e11;
        }
        var t10 = e10.prototype;
        return t10.onBO = function() {
          this.onBOL && this.onBOL.forEach(function(e11) {
            return e11();
          });
        }, t10.onBUO = function() {
          this.onBUOL && this.onBUOL.forEach(function(e11) {
            return e11();
          });
        }, t10.reportObserved = function() {
          return ts(this);
        }, t10.reportChanged = function() {
          to(), tu(this), tt.stateVersion = tt.stateVersion < Number.MAX_SAFE_INTEGER ? tt.stateVersion + 1 : Number.MIN_SAFE_INTEGER, ta();
        }, t10.toString = function() {
          return this.name_;
        }, e10;
      })(), et = R("Atom", ee);
      function en(e10, t10, n2) {
        void 0 === t10 && (t10 = E), void 0 === n2 && (n2 = E);
        var r2 = new ee(e10);
        return t10 !== E && tN("onBO", r2, t10, void 0), n2 !== E && tT(r2, n2), r2;
      }
      var er = {
        structural: function(e10, t10) {
          return nL(e10, t10);
        },
        default: function(e10, t10) {
          return Object.is ? Object.is(e10, t10) : e10 === t10 ? 0 !== e10 || 1 / e10 == 1 / t10 : e10 != e10 && t10 != t10;
        }
      };
      function ei(e10, t10, n2) {
        if (tH(e10)) return e10;
        if (Array.isArray(e10)) return eV.array(e10, { name: n2 });
        if (T(e10)) return eV.object(e10, void 0, { name: n2 });
        if (D(e10)) return eV.map(e10, { name: n2 });
        if (L(e10)) return eV.set(e10, { name: n2 });
        if ("function" == typeof e10 && !tj(e10) && !tK(e10))
          if (N(e10)) return tI(e10);
          else return tw(n2, e10);
        return e10;
      }
      function eo(e10) {
        return e10;
      }
      function ea(e10, t10) {
        return { annotationType_: e10, options_: t10, make_: es, extend_: eu };
      }
      function es(e10, t10, n2, r2) {
        if (null != (i2 = this.options_) && i2.bound) return +(null !== this.extend_(e10, t10, n2, false));
        if (r2 === e10.target_) return 2 * (null !== this.extend_(e10, t10, n2, false));
        if (tj(n2.value)) return 1;
        var i2, o2 = ec(e10, this, t10, n2, false);
        return g(r2, t10, o2), 2;
      }
      function eu(e10, t10, n2, r2) {
        var i2 = ec(e10, this, t10, n2);
        return e10.defineProperty_(t10, i2, r2);
      }
      function ec(e10, t10, n2, r2, i2) {
        void 0 === i2 && (i2 = tt.safeDescriptors), t10.annotationType_, r2.value;
        var o2, a2, s2, u2, c2, l2, h2, f2, _2 = r2.value;
        return null != (o2 = t10.options_) && o2.bound && (_2 = _2.bind(null != (f2 = e10.proxy_) ? f2 : e10.target_)), {
          value: eK(
            null != (a2 = null == (s2 = t10.options_) ? void 0 : s2.name) ? a2 : n2.toString(),
            _2,
            null != (u2 = null == (c2 = t10.options_) ? void 0 : c2.autoAction) && u2,
            null != (l2 = t10.options_) && l2.bound ? null != (h2 = e10.proxy_) ? h2 : e10.target_ : void 0
          ),
          configurable: !i2 || e10.isPlainObject_,
          enumerable: false,
          writable: !i2
        };
      }
      function el(e10, t10) {
        return { annotationType_: e10, options_: t10, make_: eh, extend_: ef };
      }
      function eh(e10, t10, n2, r2) {
        if (r2 === e10.target_) return 2 * (null !== this.extend_(e10, t10, n2, false));
        if (null != (i2 = this.options_) && i2.bound && (!U(e10.target_, t10) || !tK(e10.target_[t10])) && null === this.extend_(e10, t10, n2, false))
          return 0;
        if (tK(n2.value)) return 1;
        var i2, o2 = e_(e10, this, t10, n2, false, false);
        return g(r2, t10, o2), 2;
      }
      function ef(e10, t10, n2, r2) {
        var i2, o2 = e_(e10, this, t10, n2, null == (i2 = this.options_) ? void 0 : i2.bound);
        return e10.defineProperty_(t10, o2, r2);
      }
      function e_(e10, t10, n2, r2, i2, o2) {
        void 0 === o2 && (o2 = tt.safeDescriptors), t10.annotationType_, r2.value;
        var a2, s2 = r2.value;
        return tK(s2) || (s2 = tI(s2)), i2 && ((s2 = s2.bind(null != (a2 = e10.proxy_) ? a2 : e10.target_)).isMobXFlow = true), { value: s2, configurable: !o2 || e10.isPlainObject_, enumerable: false, writable: !o2 };
      }
      function ev(e10, t10) {
        return { annotationType_: e10, options_: t10, make_: ed, extend_: ep };
      }
      function ed(e10, t10, n2) {
        return +(null !== this.extend_(e10, t10, n2, false));
      }
      function ep(e10, t10, n2, r2) {
        var i2, o2;
        return i2 = this, o2 = n2, i2.annotationType_, o2.get, e10.defineComputedProperty_(t10, H({}, this.options_, { get: n2.get, set: n2.set }), r2);
      }
      function eb(e10, t10) {
        return { annotationType_: e10, options_: t10, make_: eg, extend_: ey };
      }
      function eg(e10, t10, n2) {
        return +(null !== this.extend_(e10, t10, n2, false));
      }
      function ey(e10, t10, n2, r2) {
        var i2, o2, a2;
        return a2 = this, a2.annotationType_, e10.defineObservableProperty_(
          t10,
          n2.value,
          null != (i2 = null == (o2 = this.options_) ? void 0 : o2.enhancer) ? i2 : ei,
          r2
        );
      }
      var em = eO();
      function eO(e10) {
        return { annotationType_: "true", options_: e10, make_: eA, extend_: ew };
      }
      function eA(e10, t10, n2, r2) {
        if (n2.get) return eL.make_(e10, t10, n2, r2);
        if (n2.set) {
          var i2, o2, a2, s2, u2, c2 = eK(t10.toString(), n2.set);
          return r2 === e10.target_ ? 2 * (null !== e10.defineProperty_(t10, { configurable: !tt.safeDescriptors || e10.isPlainObject_, set: c2 })) : (g(r2, t10, { configurable: true, set: c2 }), 2);
        }
        if (r2 !== e10.target_ && "function" == typeof n2.value)
          return N(n2.value) ? (null != (s2 = this.options_) && s2.autoBind ? tI.bound : tI).make_(e10, t10, n2, r2) : (null != (a2 = this.options_) && a2.autoBind ? tw.bound : tw).make_(e10, t10, n2, r2);
        var l2 = (null == (i2 = this.options_) ? void 0 : i2.deep) === false ? eV.ref : eV;
        return "function" == typeof n2.value && null != (o2 = this.options_) && o2.autoBind && (n2.value = n2.value.bind(null != (u2 = e10.proxy_) ? u2 : e10.target_)), l2.make_(e10, t10, n2, r2);
      }
      function ew(e10, t10, n2, r2) {
        var i2, o2, a2;
        return n2.get ? eL.extend_(e10, t10, n2, r2) : n2.set ? e10.defineProperty_(
          t10,
          { configurable: !tt.safeDescriptors || e10.isPlainObject_, set: eK(t10.toString(), n2.set) },
          r2
        ) : ("function" == typeof n2.value && null != (i2 = this.options_) && i2.autoBind && (n2.value = n2.value.bind(null != (a2 = e10.proxy_) ? a2 : e10.target_)), ((null == (o2 = this.options_) ? void 0 : o2.deep) === false ? eV.ref : eV).extend_(e10, t10, n2, r2));
      }
      var eS = { deep: true, name: void 0, defaultDecorator: void 0, proxy: true };
      Object.freeze(eS);
      var ej = eb("observable"), eE = eb("observable.ref", { enhancer: eo }), ex = eb("observable.shallow", {
        enhancer: function(e10, t10, n2) {
          return null == e10 || nw(e10) || nc(e10) || n_(e10) || np(e10) ? e10 : Array.isArray(e10) ? eV.array(e10, { name: n2, deep: false }) : T(e10) ? eV.object(e10, void 0, { name: n2, deep: false }) : D(e10) ? eV.map(e10, { name: n2, deep: false }) : L(e10) ? eV.set(e10, { name: n2, deep: false }) : void 0;
        }
      }), ek = eb("observable.struct", {
        enhancer: function(e10, t10) {
          return nL(e10, t10) ? t10 : e10;
        }
      }), eP = Z(ej);
      function eT(e10) {
        var t10, n2, r2;
        return true === e10.deep ? ei : false === e10.deep ? eo : (t10 = e10.defaultDecorator) && null != (n2 = null == (r2 = t10.options_) ? void 0 : r2.enhancer) ? n2 : ei;
      }
      function eN(e10, t10, n2) {
        return k(t10) ? void $(e10, t10, ej) : tH(e10) ? e10 : T(e10) ? eV.object(e10, t10, n2) : Array.isArray(e10) ? eV.array(e10, t10) : D(e10) ? eV.map(e10, t10) : L(e10) ? eV.set(e10, t10) : "object" == typeof e10 && null !== e10 ? e10 : eV.box(e10, t10);
      }
      p(eN, eP);
      var eV = p(eN, {
        box: function(e10, t10) {
          var n2 = t10 || eS;
          return new ez(e10, eT(n2), n2.name, true, n2.equals);
        },
        array: function(e10, t10) {
          var n2 = t10 || eS;
          return (false === tt.useProxies || false === n2.proxy ? function(e11, t11, n3) {
            return new nP(e11, t11, n3);
          } : function(e11, t11, n3, r2) {
            void 0 === n3 && (n3 = "ObservableArray"), void 0 === r2 && (r2 = false), S();
            var i2 = new nn(n3, t11, r2, false);
            C(i2.values_, Q, i2);
            var o2 = new Proxy(i2.values_, nt);
            if (i2.proxy_ = o2, e11 && e11.length) {
              var a2 = eH(true);
              i2.spliceWithArray_(0, 0, e11), eW(a2);
            }
            return o2;
          })(e10, eT(n2), n2.name);
        },
        map: function(e10, t10) {
          var n2 = t10 || eS;
          return new nf(e10, eT(n2), n2.name);
        },
        set: function(e10, t10) {
          var n2 = t10 || eS;
          return new nd(e10, eT(n2), n2.name);
        },
        object: function(e10, t10, n2) {
          var r2, i2, o2, a2;
          return (function(e11, t11, n3, r3) {
            var i3 = K(t11), o3 = nm(e11, void 0)[Q];
            to();
            try {
              M(i3).forEach(function(e12) {
                o3.extend_(e12, i3[e12], !n3 || !(e12 in n3) || n3[e12]);
              });
            } finally {
              ta();
            }
            return e11;
          })(
            false === tt.useProxies || (null == n2 ? void 0 : n2.proxy) === false ? nm({}, n2) : (r2 = {}, i2 = n2, S(), null != (a2 = (o2 = (r2 = nm(r2, i2))[Q]).proxy_) ? a2 : o2.proxy_ = new Proxy(r2, t1)),
            e10,
            t10
          );
        },
        ref: Z(eE),
        shallow: Z(ex),
        deep: eP,
        struct: Z(ek)
      }), eC = "computed", eR = ev(eC), eD = ev("computed.struct", { equals: er.structural }), eL = function(e10, t10) {
        if (k(t10)) return $(e10, t10, eR);
        if (T(e10)) return Z(ev(eC, e10));
        var n2 = T(t10) ? t10 : {};
        return n2.get = e10, n2.name || (n2.name = e10.name || ""), new eX(n2);
      };
      Object.assign(eL, eR), eL.struct = Z(eD);
      var eB = 0, eM = 1, eI = null != (i = null == (o = b(function() {
      }, "name")) ? void 0 : o.configurable) && i, eU = { value: "action", configurable: true, writable: false, enumerable: false };
      function eK(e10, t10, n2, r2) {
        function i2() {
          return eG(e10, n2, t10, r2 || this, arguments);
        }
        return void 0 === n2 && (n2 = false), i2.isMobxAction = true, eI && (eU.value = e10, g(i2, "name", eU)), i2;
      }
      function eG(e10, t10, n2, i2, o2) {
        var a2, s2, u2, c2, l2, h2, f2 = (a2 = t10, s2 = tt.trackingDerivation, u2 = !a2 || !s2, to(), c2 = tt.allowStateChanges, u2 && (e3(), c2 = eH(true)), eB = (l2 = {
          runAsAction_: u2,
          prevDerivation_: s2,
          prevAllowStateChanges_: c2,
          prevAllowStateReads_: e7(true),
          notifySpy_: false,
          startTime_: 0,
          actionId_: eM++,
          parentActionId_: eB
        }).actionId_, l2);
        try {
          return n2.apply(i2, o2);
        } catch (e11) {
          throw f2.error_ = e11, e11;
        } finally {
          eB !== (h2 = f2).actionId_ && r(30), eB = h2.parentActionId_, void 0 !== h2.error_ && (tt.suppressReactionErrors = true), eW(h2.prevAllowStateChanges_), e8(h2.prevAllowStateReads_), ta(), h2.runAsAction_ && e6(h2.prevDerivation_), tt.suppressReactionErrors = false;
        }
      }
      function eq(e10, t10) {
        var n2 = eH(e10);
        try {
          return t10();
        } finally {
          eW(n2);
        }
      }
      function eH(e10) {
        var t10 = tt.allowStateChanges;
        return tt.allowStateChanges = e10, t10;
      }
      function eW(e10) {
        tt.allowStateChanges = e10;
      }
      a = Symbol.toPrimitive;
      var ez = (function(e10) {
        function t10(t11, n3, r2, i2, o2) {
          var a2;
          return void 0 === r2 && (r2 = "ObservableValue"), void 0 === i2 && (i2 = true), void 0 === o2 && (o2 = er.default), (a2 = e10.call(this, r2) || this).enhancer = void 0, a2.name_ = void 0, a2.equals = void 0, a2.hasUnreportedChange_ = false, a2.interceptors_ = void 0, a2.changeListeners_ = void 0, a2.value_ = void 0, a2.dehancer = void 0, a2.enhancer = n3, a2.name_ = r2, a2.equals = o2, a2.value_ = n3(t11, void 0, r2), a2;
        }
        W(t10, e10);
        var n2 = t10.prototype;
        return n2.dehanceValue = function(e11) {
          return void 0 !== this.dehancer ? this.dehancer(e11) : e11;
        }, n2.set = function(e11) {
          this.value_, (e11 = this.prepareNewValue_(e11)) !== tt.UNCHANGED && this.setNewValue_(e11);
        }, n2.prepareNewValue_ = function(e11) {
          if (eQ(this), t2(this)) {
            var t11 = t6(this, { object: this, type: ne, newValue: e11 });
            if (!t11) return tt.UNCHANGED;
            e11 = t11.newValue;
          }
          return e11 = this.enhancer(e11, this.value_, this.name_), this.equals(this.value_, e11) ? tt.UNCHANGED : e11;
        }, n2.setNewValue_ = function(e11) {
          var t11 = this.value_;
          this.value_ = e11, this.reportChanged(), t7(this) && t4(this, { type: ne, object: this, newValue: e11, oldValue: t11 });
        }, n2.get = function() {
          return this.reportObserved(), this.dehanceValue(this.value_);
        }, n2.intercept_ = function(e11) {
          return t3(this, e11);
        }, n2.observe_ = function(e11, t11) {
          return t11 && e11({
            observableKind: "value",
            debugObjectName: this.name_,
            object: this,
            type: ne,
            newValue: this.value_,
            oldValue: void 0
          }), t8(this, e11);
        }, n2.raw = function() {
          return this.value_;
        }, n2.toJSON = function() {
          return this.get();
        }, n2.toString = function() {
          return this.name_ + "[" + this.value_ + "]";
        }, n2.valueOf = function() {
          return I(this.get());
        }, n2[a] = function() {
          return this.valueOf();
        }, t10;
      })(ee), eF = R("ObservableValue", ez);
      s = Symbol.toPrimitive;
      var eX = (function() {
        function e10(e11) {
          this.dependenciesState_ = u.NOT_TRACKING_, this.observing_ = [], this.newObserving_ = null, this.isBeingObserved_ = false, this.isPendingUnobservation_ = false, this.observers_ = /* @__PURE__ */ new Set(), this.diffValue_ = 0, this.runId_ = 0, this.lastAccessedBy_ = 0, this.lowestObserverState_ = u.UP_TO_DATE_, this.unboundDepsCount_ = 0, this.value_ = new eJ(null), this.name_ = void 0, this.triggeredBy_ = void 0, this.isComputing_ = false, this.isRunningSetter_ = false, this.derivation = void 0, this.setter_ = void 0, this.isTracing_ = c.NONE, this.scope_ = void 0, this.equals_ = void 0, this.requiresReaction_ = void 0, this.keepAlive_ = void 0, this.onBOL = void 0, this.onBUOL = void 0, e11.get || r(31), this.derivation = e11.get, this.name_ = e11.name || "ComputedValue", e11.set && (this.setter_ = eK("ComputedValue-setter", e11.set)), this.equals_ = e11.equals || (e11.compareStructural || e11.struct ? er.structural : er.default), this.scope_ = e11.context, this.requiresReaction_ = e11.requiresReaction, this.keepAlive_ = !!e11.keepAlive;
        }
        var t10 = e10.prototype;
        return t10.onBecomeStale_ = function() {
          var e11;
          e11 = this, e11.lowestObserverState_ === u.UP_TO_DATE_ && (e11.lowestObserverState_ = u.POSSIBLY_STALE_, e11.observers_.forEach(function(e12) {
            e12.dependenciesState_ === u.UP_TO_DATE_ && (e12.dependenciesState_ = u.POSSIBLY_STALE_, e12.onBecomeStale_());
          }));
        }, t10.onBO = function() {
          this.onBOL && this.onBOL.forEach(function(e11) {
            return e11();
          });
        }, t10.onBUO = function() {
          this.onBUOL && this.onBUOL.forEach(function(e11) {
            return e11();
          });
        }, t10.get = function() {
          if (this.isComputing_ && r(32, this.name_, this.derivation), 0 !== tt.inBatch || 0 !== this.observers_.size || this.keepAlive_) {
            if (ts(this), e$(this)) {
              var e11, t11 = tt.trackingContext;
              this.keepAlive_ && !t11 && (tt.trackingContext = this), this.trackAndCompute() && (e11 = this, e11.lowestObserverState_ !== u.STALE_ && (e11.lowestObserverState_ = u.STALE_, e11.observers_.forEach(function(t12) {
                t12.dependenciesState_ === u.POSSIBLY_STALE_ ? t12.dependenciesState_ = u.STALE_ : t12.dependenciesState_ === u.UP_TO_DATE_ && (e11.lowestObserverState_ = u.UP_TO_DATE_);
              }))), tt.trackingContext = t11;
            }
          } else e$(this) && (this.warnAboutUntrackedRead_(), to(), this.value_ = this.computeValue_(false), ta());
          var n2 = this.value_;
          if (eZ(n2)) throw n2.cause;
          return n2;
        }, t10.set = function(e11) {
          if (this.setter_) {
            this.isRunningSetter_ && r(33, this.name_), this.isRunningSetter_ = true;
            try {
              this.setter_.call(this.scope_, e11);
            } finally {
              this.isRunningSetter_ = false;
            }
          } else r(34, this.name_);
        }, t10.trackAndCompute = function() {
          var e11 = this.value_, t11 = this.dependenciesState_ === u.NOT_TRACKING_, n2 = this.computeValue_(true), r2 = t11 || eZ(e11) || eZ(n2) || !this.equals_(e11, n2);
          return r2 && (this.value_ = n2), r2;
        }, t10.computeValue_ = function(e11) {
          this.isComputing_ = true;
          var t11, n2 = eH(false);
          if (e11) t11 = e0(this, this.derivation, this.scope_);
          else if (true === tt.disableErrorBoundaries) t11 = this.derivation.call(this.scope_);
          else
            try {
              t11 = this.derivation.call(this.scope_);
            } catch (e12) {
              t11 = new eJ(e12);
            }
          return eW(n2), this.isComputing_ = false, t11;
        }, t10.suspend_ = function() {
          this.keepAlive_ || (e1(this), this.value_ = void 0);
        }, t10.observe_ = function(e11, t11) {
          var n2 = this, r2 = true, i2 = void 0;
          return tE(function() {
            var o2 = n2.get();
            if (!r2 || t11) {
              var a2 = e3();
              e11({
                observableKind: "computed",
                debugObjectName: n2.name_,
                type: ne,
                object: n2,
                newValue: o2,
                oldValue: i2
              }), e6(a2);
            }
            r2 = false, i2 = o2;
          });
        }, t10.warnAboutUntrackedRead_ = function() {
        }, t10.toString = function() {
          return this.name_ + "[" + this.derivation.toString() + "]";
        }, t10.valueOf = function() {
          return I(this.get());
        }, t10[s] = function() {
          return this.valueOf();
        }, e10;
      })(), eY = R("ComputedValue", eX);
      !(function(e10) {
        e10[e10.NOT_TRACKING_ = -1] = "NOT_TRACKING_", e10[e10.UP_TO_DATE_ = 0] = "UP_TO_DATE_", e10[e10.POSSIBLY_STALE_ = 1] = "POSSIBLY_STALE_", e10[e10.STALE_ = 2] = "STALE_";
      })(u || (u = {})), (function(e10) {
        e10[e10.NONE = 0] = "NONE", e10[e10.LOG = 1] = "LOG", e10[e10.BREAK = 2] = "BREAK";
      })(c || (c = {}));
      var eJ = function(e10) {
        this.cause = void 0, this.cause = e10;
      };
      function eZ(e10) {
        return e10 instanceof eJ;
      }
      function e$(e10) {
        switch (e10.dependenciesState_) {
          case u.UP_TO_DATE_:
            return false;
          case u.NOT_TRACKING_:
          case u.STALE_:
            return true;
          case u.POSSIBLY_STALE_:
            for (var t10 = e7(true), n2 = e3(), r2 = e10.observing_, i2 = r2.length, o2 = 0; o2 < i2; o2++) {
              var a2 = r2[o2];
              if (eY(a2)) {
                if (tt.disableErrorBoundaries) a2.get();
                else
                  try {
                    a2.get();
                  } catch (e11) {
                    return e6(n2), e8(t10), true;
                  }
                if (e10.dependenciesState_ === u.STALE_) return e6(n2), e8(t10), true;
              }
            }
            return e4(e10), e6(n2), e8(t10), false;
        }
      }
      function eQ(e10) {
      }
      function e0(e10, t10, n2) {
        var r2, i2 = e7(true);
        e4(e10), e10.newObserving_ = Array(e10.observing_.length + 100), e10.unboundDepsCount_ = 0, e10.runId_ = ++tt.runId;
        var o2 = tt.trackingDerivation;
        if (tt.trackingDerivation = e10, tt.inBatch++, true === tt.disableErrorBoundaries) r2 = t10.call(n2);
        else
          try {
            r2 = t10.call(n2);
          } catch (e11) {
            r2 = new eJ(e11);
          }
        return tt.inBatch--, tt.trackingDerivation = o2, (function(e11) {
          for (var t11 = e11.observing_, n3 = e11.observing_ = e11.newObserving_, r3 = u.UP_TO_DATE_, i3 = 0, o3 = e11.unboundDepsCount_, a2 = 0; a2 < o3; a2++) {
            var s2 = n3[a2];
            0 === s2.diffValue_ && (s2.diffValue_ = 1, i3 !== a2 && (n3[i3] = s2), i3++), s2.dependenciesState_ > r3 && (r3 = s2.dependenciesState_);
          }
          for (n3.length = i3, e11.newObserving_ = null, o3 = t11.length; o3--; ) {
            var c2 = t11[o3];
            0 === c2.diffValue_ && tr(c2, e11), c2.diffValue_ = 0;
          }
          for (; i3--; ) {
            var l2, h2, f2 = n3[i3];
            1 === f2.diffValue_ && (f2.diffValue_ = 0, l2 = f2, h2 = e11, l2.observers_.add(h2), l2.lowestObserverState_ > h2.dependenciesState_ && (l2.lowestObserverState_ = h2.dependenciesState_));
          }
          r3 !== u.UP_TO_DATE_ && (e11.dependenciesState_ = r3, e11.onBecomeStale_());
        })(e10), e8(i2), r2;
      }
      function e1(e10) {
        var t10 = e10.observing_;
        e10.observing_ = [];
        for (var n2 = t10.length; n2--; ) tr(t10[n2], e10);
        e10.dependenciesState_ = u.NOT_TRACKING_;
      }
      function e2(e10) {
        var t10 = e3();
        try {
          return e10();
        } finally {
          e6(t10);
        }
      }
      function e3() {
        var e10 = tt.trackingDerivation;
        return tt.trackingDerivation = null, e10;
      }
      function e6(e10) {
        tt.trackingDerivation = e10;
      }
      function e7(e10) {
        var t10 = tt.allowStateReads;
        return tt.allowStateReads = e10, t10;
      }
      function e8(e10) {
        tt.allowStateReads = e10;
      }
      function e4(e10) {
        if (e10.dependenciesState_ !== u.UP_TO_DATE_) {
          e10.dependenciesState_ = u.UP_TO_DATE_;
          for (var t10 = e10.observing_, n2 = t10.length; n2--; ) t10[n2].lowestObserverState_ = u.UP_TO_DATE_;
        }
      }
      var e5 = function() {
        this.version = 6, this.UNCHANGED = {}, this.trackingDerivation = null, this.trackingContext = null, this.runId = 0, this.mobxGuid = 0, this.inBatch = 0, this.pendingUnobservations = [], this.pendingReactions = [], this.isRunningReactions = false, this.allowStateChanges = false, this.allowStateReads = true, this.enforceActions = true, this.spyListeners = [], this.globalReactionErrorHandlers = [], this.computedRequiresReaction = false, this.reactionRequiresObservable = false, this.observableRequiresReaction = false, this.disableErrorBoundaries = false, this.suppressReactionErrors = false, this.useProxies = true, this.verifyProxies = false, this.safeDescriptors = true, this.stateVersion = Number.MIN_SAFE_INTEGER;
      }, e9 = true, te = false, tt = (function() {
        var e10 = d();
        return (e10.__mobxInstanceCount > 0 && !e10.__mobxGlobals && (e9 = false), e10.__mobxGlobals && e10.__mobxGlobals.version !== new e5().version && (e9 = false), e9) ? e10.__mobxGlobals ? (e10.__mobxInstanceCount += 1, e10.__mobxGlobals.UNCHANGED || (e10.__mobxGlobals.UNCHANGED = {}), e10.__mobxGlobals) : (e10.__mobxInstanceCount = 1, e10.__mobxGlobals = new e5()) : (setTimeout(function() {
          te || r(35);
        }, 1), new e5());
      })();
      function tn() {
        return tt;
      }
      function tr(e10, t10) {
        e10.observers_.delete(t10), 0 === e10.observers_.size && ti(e10);
      }
      function ti(e10) {
        false === e10.isPendingUnobservation_ && (e10.isPendingUnobservation_ = true, tt.pendingUnobservations.push(e10));
      }
      function to() {
        tt.inBatch++;
      }
      function ta() {
        if (0 == --tt.inBatch) {
          th();
          for (var e10 = tt.pendingUnobservations, t10 = 0; t10 < e10.length; t10++) {
            var n2 = e10[t10];
            n2.isPendingUnobservation_ = false, 0 === n2.observers_.size && (n2.isBeingObserved_ && (n2.isBeingObserved_ = false, n2.onBUO()), n2 instanceof eX && n2.suspend_());
          }
          tt.pendingUnobservations = [];
        }
      }
      function ts(e10) {
        var t10 = tt.trackingDerivation;
        return null !== t10 ? (t10.runId_ !== e10.lastAccessedBy_ && (e10.lastAccessedBy_ = t10.runId_, t10.newObserving_[t10.unboundDepsCount_++] = e10, !e10.isBeingObserved_ && tt.trackingContext && (e10.isBeingObserved_ = true, e10.onBO())), e10.isBeingObserved_) : (0 === e10.observers_.size && tt.inBatch > 0 && ti(e10), false);
      }
      function tu(e10) {
        e10.lowestObserverState_ !== u.STALE_ && (e10.lowestObserverState_ = u.STALE_, e10.observers_.forEach(function(e11) {
          e11.dependenciesState_ === u.UP_TO_DATE_ && e11.onBecomeStale_(), e11.dependenciesState_ = u.STALE_;
        }));
      }
      var tc = (function() {
        function e10(e11, t11, n2, r2) {
          void 0 === e11 && (e11 = "Reaction"), this.name_ = void 0, this.onInvalidate_ = void 0, this.errorHandler_ = void 0, this.requiresObservable_ = void 0, this.observing_ = [], this.newObserving_ = [], this.dependenciesState_ = u.NOT_TRACKING_, this.diffValue_ = 0, this.runId_ = 0, this.unboundDepsCount_ = 0, this.isDisposed_ = false, this.isScheduled_ = false, this.isTrackPending_ = false, this.isRunning_ = false, this.isTracing_ = c.NONE, this.name_ = e11, this.onInvalidate_ = t11, this.errorHandler_ = n2, this.requiresObservable_ = r2;
        }
        var t10 = e10.prototype;
        return t10.onBecomeStale_ = function() {
          this.schedule_();
        }, t10.schedule_ = function() {
          this.isScheduled_ || (this.isScheduled_ = true, tt.pendingReactions.push(this), th());
        }, t10.isScheduled = function() {
          return this.isScheduled_;
        }, t10.runReaction_ = function() {
          if (!this.isDisposed_) {
            to(), this.isScheduled_ = false;
            var e11 = tt.trackingContext;
            if (tt.trackingContext = this, e$(this)) {
              this.isTrackPending_ = true;
              try {
                this.onInvalidate_();
              } catch (e12) {
                this.reportExceptionInDerivation_(e12);
              }
            }
            tt.trackingContext = e11, ta();
          }
        }, t10.track = function(e11) {
          if (!this.isDisposed_) {
            to(), this.isRunning_ = true;
            var t11 = tt.trackingContext;
            tt.trackingContext = this;
            var n2 = e0(this, e11, void 0);
            tt.trackingContext = t11, this.isRunning_ = false, this.isTrackPending_ = false, this.isDisposed_ && e1(this), eZ(n2) && this.reportExceptionInDerivation_(n2.cause), ta();
          }
        }, t10.reportExceptionInDerivation_ = function(e11) {
          var t11 = this;
          if (this.errorHandler_) return void this.errorHandler_(e11, this);
          if (tt.disableErrorBoundaries) throw e11;
          tt.suppressReactionErrors || console.error("[mobx] uncaught error in '" + this + "'", e11), tt.globalReactionErrorHandlers.forEach(function(n2) {
            return n2(e11, t11);
          });
        }, t10.dispose = function() {
          !this.isDisposed_ && (this.isDisposed_ = true, this.isRunning_ || (to(), e1(this), ta()));
        }, t10.getDisposer_ = function() {
          var e11 = this.dispose.bind(this);
          return e11[Q] = this, e11;
        }, t10.toString = function() {
          return "Reaction[" + this.name_ + "]";
        }, t10.trace = function(e11) {
          void 0 === e11 && (e11 = false);
        }, e10;
      })(), tl = function(e10) {
        return e10();
      };
      function th() {
        tt.inBatch > 0 || tt.isRunningReactions || tl(tf);
      }
      function tf() {
        tt.isRunningReactions = true;
        for (var e10 = tt.pendingReactions, t10 = 0; e10.length > 0; ) {
          100 == ++t10 && (console.error("[mobx] cycle in reaction: " + e10[0]), e10.splice(0));
          for (var n2 = e10.splice(0), r2 = 0, i2 = n2.length; r2 < i2; r2++) n2[r2].runReaction_();
        }
        tt.isRunningReactions = false;
      }
      var t_ = R("Reaction", tc), tv = "action", td = "autoAction", tp = "<unnamed action>", tb = ea(tv), tg = ea("action.bound", { bound: true }), ty = ea(td, { autoAction: true }), tm = ea("autoAction.bound", { autoAction: true, bound: true });
      function tO(e10) {
        return function(t10, n2) {
          return x(t10) ? eK(t10.name || tp, t10, e10) : x(n2) ? eK(t10, n2, e10) : k(n2) ? $(t10, n2, e10 ? ty : tb) : k(t10) ? Z(ea(e10 ? td : tv, { name: t10, autoAction: e10 })) : void 0;
        };
      }
      var tA = tO(false);
      Object.assign(tA, tb);
      var tw = tO(true);
      function tS(e10) {
        return eG(e10.name || tp, false, e10, this, void 0);
      }
      function tj(e10) {
        return x(e10) && true === e10.isMobxAction;
      }
      function tE(e10, t10) {
        void 0 === t10 && (t10 = O);
        var n2, r2, i2, o2 = null != (n2 = null == (r2 = t10) ? void 0 : r2.name) ? n2 : "Autorun";
        if (t10.scheduler || t10.delay) {
          var a2 = tk(t10), s2 = false;
          i2 = new tc(
            o2,
            function() {
              s2 || (s2 = true, a2(function() {
                s2 = false, i2.isDisposed_ || i2.track(u2);
              }));
            },
            t10.onError,
            t10.requiresObservable
          );
        } else
          i2 = new tc(
            o2,
            function() {
              this.track(u2);
            },
            t10.onError,
            t10.requiresObservable
          );
        function u2() {
          e10(i2);
        }
        return i2.schedule_(), i2.getDisposer_();
      }
      Object.assign(tw, ty), tA.bound = Z(tg), tw.bound = Z(tm);
      var tx = function(e10) {
        return e10();
      };
      function tk(e10) {
        return e10.scheduler ? e10.scheduler : e10.delay ? function(t10) {
          return setTimeout(t10, e10.delay);
        } : tx;
      }
      function tP(e10, t10, n2) {
        void 0 === n2 && (n2 = O);
        var r2, i2, o2, a2, s2, u2 = null != (o2 = n2.name) ? o2 : "Reaction", c2 = tA(
          u2,
          n2.onError ? (r2 = n2.onError, i2 = t10, function() {
            try {
              return i2.apply(this, arguments);
            } catch (e11) {
              r2.call(this, e11);
            }
          }) : t10
        ), l2 = !n2.scheduler && !n2.delay, h2 = tk(n2), f2 = true, _2 = false, v2 = n2.compareStructural ? er.structural : n2.equals || er.default, d2 = new tc(
          u2,
          function() {
            f2 || l2 ? p2() : _2 || (_2 = true, h2(p2));
          },
          n2.onError,
          n2.requiresObservable
        );
        function p2() {
          if (_2 = false, !d2.isDisposed_) {
            var t11 = false;
            d2.track(function() {
              var n3 = eq(false, function() {
                return e10(d2);
              });
              t11 = f2 || !v2(a2, n3), s2 = a2, a2 = n3;
            }), f2 && n2.fireImmediately ? c2(a2, s2, d2) : !f2 && t11 && c2(a2, s2, d2), f2 = false;
          }
        }
        return d2.schedule_(), d2.getDisposer_();
      }
      function tT(e10, t10, n2) {
        return tN("onBUO", e10, t10, n2);
      }
      function tN(e10, t10, n2, r2) {
        var i2 = "function" == typeof r2 ? nV(t10, n2) : nV(t10), o2 = x(r2) ? r2 : n2, a2 = e10 + "L";
        return i2[a2] ? i2[a2].add(o2) : i2[a2] = /* @__PURE__ */ new Set([o2]), function() {
          var e11 = i2[a2];
          e11 && (e11.delete(o2), 0 === e11.size && delete i2[a2]);
        };
      }
      var tV = "always";
      function tC(e10) {
        true === e10.isolateGlobalState && (function() {
          if ((tt.pendingReactions.length || tt.inBatch || tt.isRunningReactions) && r(36), te = true, e9) {
            var e11 = d();
            0 == --e11.__mobxInstanceCount && (e11.__mobxGlobals = void 0), tt = new e5();
          }
        })();
        var t10, n2, i2 = e10.useProxies, o2 = e10.enforceActions;
        if (void 0 !== i2 && (tt.useProxies = i2 === tV || "never" !== i2 && "undefined" != typeof Proxy), "ifavailable" === i2 && (tt.verifyProxies = true), void 0 !== o2) {
          var a2 = o2 === tV ? tV : "observed" === o2;
          tt.enforceActions = a2, tt.allowStateChanges = true !== a2 && a2 !== tV;
        }
        [
          "computedRequiresReaction",
          "reactionRequiresObservable",
          "observableRequiresReaction",
          "disableErrorBoundaries",
          "safeDescriptors"
        ].forEach(function(t11) {
          t11 in e10 && (tt[t11] = !!e10[t11]);
        }), tt.allowStateReads = !tt.observableRequiresReaction, e10.reactionScheduler && (t10 = e10.reactionScheduler, n2 = tl, tl = function(e11) {
          return t10(function() {
            return n2(e11);
          });
        });
      }
      function tR(e10, t10) {
        return (function e11(t11) {
          var n2 = { name: t11.name_ };
          return t11.observing_ && t11.observing_.length > 0 && (n2.dependencies = Array.from(new Set(t11.observing_)).map(e11)), n2;
        })(nV(e10, t10));
      }
      var tD = 0;
      function tL() {
        this.message = "FLOW_CANCELLED";
      }
      tL.prototype = Object.create(Error.prototype);
      var tB = el("flow"), tM = el("flow.bound", { bound: true }), tI = Object.assign(function(e10, t10) {
        if (k(t10)) return $(e10, t10, tB);
        var n2 = e10.name || "<unnamed flow>", r2 = function() {
          var t11, r3 = arguments, i2 = ++tD, o2 = tA(n2 + " - runid: " + i2 + " - init", e10).apply(this, r3), a2 = void 0, s2 = new Promise(function(e11, r4) {
            var s3 = 0;
            function u2(e12) {
              var t12;
              a2 = void 0;
              try {
                t12 = tA(n2 + " - runid: " + i2 + " - yield " + s3++, o2.next).call(o2, e12);
              } catch (e13) {
                return r4(e13);
              }
              l2(t12);
            }
            function c2(e12) {
              var t12;
              a2 = void 0;
              try {
                t12 = tA(n2 + " - runid: " + i2 + " - yield " + s3++, o2.throw).call(o2, e12);
              } catch (e13) {
                return r4(e13);
              }
              l2(t12);
            }
            function l2(t12) {
              return x(null == t12 ? void 0 : t12.then) ? void t12.then(l2, r4) : t12.done ? e11(t12.value) : (a2 = Promise.resolve(t12.value)).then(u2, c2);
            }
            t11 = r4, u2(void 0);
          });
          return s2.cancel = tA(n2 + " - runid: " + i2 + " - cancel", function() {
            try {
              a2 && tU(a2);
              var e11 = o2.return(void 0), n3 = Promise.resolve(e11.value);
              n3.then(E, E), tU(n3), t11(new tL());
            } catch (e12) {
              t11(e12);
            }
          }), s2;
        };
        return r2.isMobXFlow = true, r2;
      }, tB);
      function tU(e10) {
        x(e10.cancel) && e10.cancel();
      }
      function tK(e10) {
        return (null == e10 ? void 0 : e10.isMobXFlow) === true;
      }
      function tG(e10, t10, n2) {
        var r2;
        return n_(e10) || nc(e10) || eF(e10) ? r2 = nC(e10) : nw(e10) && (r2 = nC(e10, t10)), r2.dehancer = "function" == typeof t10 ? t10 : n2, function() {
          r2.dehancer = void 0;
        };
      }
      function tq(e10, t10, n2) {
        var r2, i2, o2, a2, s2;
        return x(n2) ? (r2 = e10, i2 = t10, o2 = n2, nC(r2, i2).intercept_(o2)) : (a2 = e10, s2 = t10, nC(a2).intercept_(s2));
      }
      function tH(e10) {
        return !!e10 && (nw(e10) || !!e10[Q] || et(e10) || t_(e10) || eY(e10));
      }
      function tW(e10) {
        return nw(e10) ? e10[Q].keys_() : n_(e10) || np(e10) ? Array.from(e10.keys()) : nc(e10) ? e10.map(function(e11, t10) {
          return t10;
        }) : void r(5);
      }
      function tz(e10) {
        return nw(e10) ? tW(e10).map(function(t10) {
          return e10[t10];
        }) : n_(e10) ? tW(e10).map(function(t10) {
          return e10.get(t10);
        }) : np(e10) ? Array.from(e10.values()) : nc(e10) ? e10.slice() : void r(6);
      }
      function tF(e10) {
        return nw(e10) ? tW(e10).map(function(t10) {
          return [t10, e10[t10]];
        }) : n_(e10) ? tW(e10).map(function(t10) {
          return [t10, e10.get(t10)];
        }) : np(e10) ? Array.from(e10.entries()) : nc(e10) ? e10.map(function(e11, t10) {
          return [t10, e11];
        }) : void r(7);
      }
      function tX(e10, t10, n2) {
        if (nw(e10)) return e10[Q].defineProperty_(t10, n2);
        r(39);
      }
      function tY(e10, t10, n2, r2) {
        var i2, o2, a2, s2, u2, c2, l2;
        return x(n2) ? (i2 = e10, o2 = t10, a2 = n2, s2 = r2, nC(i2, o2).observe_(a2, s2)) : (u2 = e10, c2 = t10, l2 = n2, nC(u2).observe_(c2, l2));
      }
      function tJ(e10, t10, n2) {
        return e10.set(t10, n2), n2;
      }
      function tZ(e10, t10) {
        return (function e11(t11, n2) {
          if (null == t11 || "object" != typeof t11 || t11 instanceof Date || !tH(t11)) return t11;
          if (eF(t11) || eY(t11)) return e11(t11.get(), n2);
          if (n2.has(t11)) return n2.get(t11);
          if (nc(t11)) {
            var i2 = tJ(n2, t11, Array(t11.length));
            return t11.forEach(function(t12, r2) {
              i2[r2] = e11(t12, n2);
            }), i2;
          }
          if (np(t11)) {
            var o2 = tJ(n2, t11, /* @__PURE__ */ new Set());
            return t11.forEach(function(t12) {
              o2.add(e11(t12, n2));
            }), o2;
          }
          if (n_(t11)) {
            var a2 = tJ(n2, t11, /* @__PURE__ */ new Map());
            return t11.forEach(function(t12, r2) {
              a2.set(r2, e11(t12, n2));
            }), a2;
          }
          var s2 = tJ(n2, t11, {});
          return (function(e12) {
            if (nw(e12)) return e12[Q].ownKeys_();
            r(38);
          })(t11).forEach(function(r2) {
            y.propertyIsEnumerable.call(t11, r2) && (s2[r2] = e11(t11[r2], n2));
          }), s2;
        })(e10, /* @__PURE__ */ new Map());
      }
      function t$(e10, t10) {
        void 0 === t10 && (t10 = void 0), to();
        try {
          return e10.apply(t10);
        } finally {
          ta();
        }
      }
      function tQ(e10, t10, n2) {
        return 1 == arguments.length || t10 && "object" == typeof t10 ? (function(e11, t11) {
          if (null != t11 && null != (n3 = t11.signal) && n3.aborted)
            return Object.assign(Promise.reject(Error("WHEN_ABORTED")), {
              cancel: function() {
                return null;
              }
            });
          var n3, r2, i2, o2 = new Promise(function(n4, o3) {
            var a2, s2 = t0(e11, n4, H({}, t11, { onError: o3 }));
            r2 = function() {
              s2(), o3(Error("WHEN_CANCELLED"));
            }, i2 = function() {
              s2(), o3(Error("WHEN_ABORTED"));
            }, null == t11 || null == (a2 = t11.signal) || null == a2.addEventListener || a2.addEventListener("abort", i2);
          }).finally(function() {
            var e12;
            return null == t11 || null == (e12 = t11.signal) || null == e12.removeEventListener ? void 0 : e12.removeEventListener("abort", i2);
          });
          return o2.cancel = r2, o2;
        })(e10, t10) : t0(e10, t10, n2 || {});
      }
      function t0(e10, t10, n2) {
        if ("number" == typeof n2.timeout) {
          var r2, i2 = Error("WHEN_TIMEOUT");
          r2 = setTimeout(function() {
            if (!a2[Q].isDisposed_)
              if (a2(), n2.onError) n2.onError(i2);
              else throw i2;
          }, n2.timeout);
        }
        n2.name = "When";
        var o2 = eK("When-effect", t10), a2 = tE(function(t11) {
          eq(false, e10) && (t11.dispose(), r2 && clearTimeout(r2), o2());
        }, n2);
        return a2;
      }
      tI.bound = Z(tM);
      var t1 = {
        has: function(e10, t10) {
          return e10[Q].has_(t10);
        },
        get: function(e10, t10) {
          return e10[Q].get_(t10);
        },
        set: function(e10, t10, n2) {
          var r2;
          return !!k(t10) && (null == (r2 = e10[Q].set_(t10, n2, true)) || r2);
        },
        deleteProperty: function(e10, t10) {
          var n2;
          return !!k(t10) && (null == (n2 = e10[Q].delete_(t10, true)) || n2);
        },
        defineProperty: function(e10, t10, n2) {
          var r2;
          return null == (r2 = e10[Q].defineProperty_(t10, n2)) || r2;
        },
        ownKeys: function(e10) {
          return e10[Q].ownKeys_();
        },
        preventExtensions: function(e10) {
          r(13);
        }
      };
      function t2(e10) {
        return void 0 !== e10.interceptors_ && e10.interceptors_.length > 0;
      }
      function t3(e10, t10) {
        var n2 = e10.interceptors_ || (e10.interceptors_ = []);
        return n2.push(t10), j(function() {
          var e11 = n2.indexOf(t10);
          -1 !== e11 && n2.splice(e11, 1);
        });
      }
      function t6(e10, t10) {
        var n2 = e3();
        try {
          for (var i2 = [].concat(e10.interceptors_ || []), o2 = 0, a2 = i2.length; o2 < a2 && ((t10 = i2[o2](t10)) && !t10.type && r(14), t10); o2++) ;
          return t10;
        } finally {
          e6(n2);
        }
      }
      function t7(e10) {
        return void 0 !== e10.changeListeners_ && e10.changeListeners_.length > 0;
      }
      function t8(e10, t10) {
        var n2 = e10.changeListeners_ || (e10.changeListeners_ = []);
        return n2.push(t10), j(function() {
          var e11 = n2.indexOf(t10);
          -1 !== e11 && n2.splice(e11, 1);
        });
      }
      function t4(e10, t10) {
        var n2 = e3(), r2 = e10.changeListeners_;
        if (r2) {
          r2 = r2.slice();
          for (var i2 = 0, o2 = r2.length; i2 < o2; i2++) r2[i2](t10);
          e6(n2);
        }
      }
      function t5(e10, t10, n2) {
        var r2 = nm(e10, n2)[Q];
        to();
        try {
          null != t10 || (U(e10, J) || V(e10, J, H({}, e10[J])), t10 = e10[J]), M(t10).forEach(function(e11) {
            return r2.make_(e11, t10[e11]);
          });
        } finally {
          ta();
        }
        return e10;
      }
      var t9 = "splice", ne = "update", nt = {
        get: function(e10, t10) {
          var n2 = e10[Q];
          return t10 === Q ? n2 : "length" === t10 ? n2.getArrayLength_() : "string" != typeof t10 || isNaN(t10) ? U(nr, t10) ? nr[t10] : e10[t10] : n2.get_(parseInt(t10));
        },
        set: function(e10, t10, n2) {
          var r2 = e10[Q];
          return "length" === t10 && r2.setArrayLength_(n2), "symbol" == typeof t10 || isNaN(t10) ? e10[t10] = n2 : r2.set_(parseInt(t10), n2), true;
        },
        preventExtensions: function() {
          r(15);
        }
      }, nn = (function() {
        function e10(e11, t11, n2, r2) {
          void 0 === e11 && (e11 = "ObservableArray"), this.owned_ = void 0, this.legacyMode_ = void 0, this.atom_ = void 0, this.values_ = [], this.interceptors_ = void 0, this.changeListeners_ = void 0, this.enhancer_ = void 0, this.dehancer = void 0, this.proxy_ = void 0, this.lastKnownLength_ = 0, this.owned_ = n2, this.legacyMode_ = r2, this.atom_ = new ee(e11), this.enhancer_ = function(e12, n3) {
            return t11(e12, n3, "ObservableArray[..]");
          };
        }
        var t10 = e10.prototype;
        return t10.dehanceValue_ = function(e11) {
          return void 0 !== this.dehancer ? this.dehancer(e11) : e11;
        }, t10.dehanceValues_ = function(e11) {
          return void 0 !== this.dehancer && e11.length > 0 ? e11.map(this.dehancer) : e11;
        }, t10.intercept_ = function(e11) {
          return t3(this, e11);
        }, t10.observe_ = function(e11, t11) {
          return void 0 === t11 && (t11 = false), t11 && e11({
            observableKind: "array",
            object: this.proxy_,
            debugObjectName: this.atom_.name_,
            type: "splice",
            index: 0,
            added: this.values_.slice(),
            addedCount: this.values_.length,
            removed: [],
            removedCount: 0
          }), t8(this, e11);
        }, t10.getArrayLength_ = function() {
          return this.atom_.reportObserved(), this.values_.length;
        }, t10.setArrayLength_ = function(e11) {
          ("number" != typeof e11 || isNaN(e11) || e11 < 0) && r("Out of range: " + e11);
          var t11 = this.values_.length;
          if (e11 !== t11)
            if (e11 > t11) {
              for (var n2 = Array(e11 - t11), i2 = 0; i2 < e11 - t11; i2++) n2[i2] = void 0;
              this.spliceWithArray_(t11, 0, n2);
            } else this.spliceWithArray_(e11, t11 - e11);
        }, t10.updateArrayLength_ = function(e11, t11) {
          e11 !== this.lastKnownLength_ && r(16), this.lastKnownLength_ += t11, this.legacyMode_ && t11 > 0 && nN(e11 + t11 + 1);
        }, t10.spliceWithArray_ = function(e11, t11, n2) {
          var r2 = this;
          this.atom_;
          var i2 = this.values_.length;
          if (void 0 === e11 ? e11 = 0 : e11 > i2 ? e11 = i2 : e11 < 0 && (e11 = Math.max(0, i2 + e11)), t11 = 1 == arguments.length ? i2 - e11 : null == t11 ? 0 : Math.max(0, Math.min(t11, i2 - e11)), void 0 === n2 && (n2 = m), t2(this)) {
            var o2 = t6(this, { object: this.proxy_, type: t9, index: e11, removedCount: t11, added: n2 });
            if (!o2) return m;
            t11 = o2.removedCount, n2 = o2.added;
          }
          if (n2 = 0 === n2.length ? n2 : n2.map(function(e12) {
            return r2.enhancer_(e12, void 0);
          }), this.legacyMode_) {
            var a2 = n2.length - t11;
            this.updateArrayLength_(i2, a2);
          }
          var s2 = this.spliceItemsIntoValues_(e11, t11, n2);
          return (0 !== t11 || 0 !== n2.length) && this.notifyArraySplice_(e11, n2, s2), this.dehanceValues_(s2);
        }, t10.spliceItemsIntoValues_ = function(e11, t11, n2) {
          if (n2.length < 1e4) {
            var r2;
            return (r2 = this.values_).splice.apply(r2, [e11, t11].concat(n2));
          }
          var i2 = this.values_.slice(e11, e11 + t11), o2 = this.values_.slice(e11 + t11);
          this.values_.length += n2.length - t11;
          for (var a2 = 0; a2 < n2.length; a2++) this.values_[e11 + a2] = n2[a2];
          for (var s2 = 0; s2 < o2.length; s2++) this.values_[e11 + n2.length + s2] = o2[s2];
          return i2;
        }, t10.notifyArrayChildUpdate_ = function(e11, t11, n2) {
          var r2 = !this.owned_ && false, i2 = t7(this), o2 = i2 || r2 ? {
            observableKind: "array",
            object: this.proxy_,
            type: ne,
            debugObjectName: this.atom_.name_,
            index: e11,
            newValue: t11,
            oldValue: n2
          } : null;
          this.atom_.reportChanged(), i2 && t4(this, o2);
        }, t10.notifyArraySplice_ = function(e11, t11, n2) {
          var r2 = !this.owned_ && false, i2 = t7(this), o2 = i2 || r2 ? {
            observableKind: "array",
            object: this.proxy_,
            debugObjectName: this.atom_.name_,
            type: t9,
            index: e11,
            removed: n2,
            added: t11,
            removedCount: n2.length,
            addedCount: t11.length
          } : null;
          this.atom_.reportChanged(), i2 && t4(this, o2);
        }, t10.get_ = function(e11) {
          return this.legacyMode_ && e11 >= this.values_.length ? void console.warn("[mobx] Out of bounds read: " + e11) : (this.atom_.reportObserved(), this.dehanceValue_(this.values_[e11]));
        }, t10.set_ = function(e11, t11) {
          var n2 = this.values_;
          if (this.legacyMode_ && e11 > n2.length && r(17, e11, n2.length), e11 < n2.length) {
            this.atom_;
            var i2 = n2[e11];
            if (t2(this)) {
              var o2 = t6(this, { type: ne, object: this.proxy_, index: e11, newValue: t11 });
              if (!o2) return;
              t11 = o2.newValue;
            }
            (t11 = this.enhancer_(t11, i2)) !== i2 && (n2[e11] = t11, this.notifyArrayChildUpdate_(e11, t11, i2));
          } else {
            for (var a2 = Array(e11 + 1 - n2.length), s2 = 0; s2 < a2.length - 1; s2++) a2[s2] = void 0;
            a2[a2.length - 1] = t11, this.spliceWithArray_(n2.length, 0, a2);
          }
        }, e10;
      })(), nr = {
        clear: function() {
          return this.splice(0);
        },
        replace: function(e10) {
          var t10 = this[Q];
          return t10.spliceWithArray_(0, t10.values_.length, e10);
        },
        toJSON: function() {
          return this.slice();
        },
        splice: function(e10, t10) {
          for (var n2 = arguments.length, r2 = Array(n2 > 2 ? n2 - 2 : 0), i2 = 2; i2 < n2; i2++) r2[i2 - 2] = arguments[i2];
          var o2 = this[Q];
          switch (arguments.length) {
            case 0:
              return [];
            case 1:
              return o2.spliceWithArray_(e10);
            case 2:
              return o2.spliceWithArray_(e10, t10);
          }
          return o2.spliceWithArray_(e10, t10, r2);
        },
        spliceWithArray: function(e10, t10, n2) {
          return this[Q].spliceWithArray_(e10, t10, n2);
        },
        push: function() {
          for (var e10 = this[Q], t10 = arguments.length, n2 = Array(t10), r2 = 0; r2 < t10; r2++) n2[r2] = arguments[r2];
          return e10.spliceWithArray_(e10.values_.length, 0, n2), e10.values_.length;
        },
        pop: function() {
          return this.splice(Math.max(this[Q].values_.length - 1, 0), 1)[0];
        },
        shift: function() {
          return this.splice(0, 1)[0];
        },
        unshift: function() {
          for (var e10 = this[Q], t10 = arguments.length, n2 = Array(t10), r2 = 0; r2 < t10; r2++) n2[r2] = arguments[r2];
          return e10.spliceWithArray_(0, 0, n2), e10.values_.length;
        },
        reverse: function() {
          return tt.trackingDerivation && r(37, "reverse"), this.replace(this.slice().reverse()), this;
        },
        sort: function() {
          tt.trackingDerivation && r(37, "sort");
          var e10 = this.slice();
          return e10.sort.apply(e10, arguments), this.replace(e10), this;
        },
        remove: function(e10) {
          var t10 = this[Q], n2 = t10.dehanceValues_(t10.values_).indexOf(e10);
          return n2 > -1 && (this.splice(n2, 1), true);
        }
      };
      function ni(e10, t10) {
        "function" == typeof Array.prototype[e10] && (nr[e10] = t10(e10));
      }
      function no(e10) {
        return function() {
          var t10 = this[Q];
          t10.atom_.reportObserved();
          var n2 = t10.dehanceValues_(t10.values_);
          return n2[e10].apply(n2, arguments);
        };
      }
      function na(e10) {
        return function(t10, n2) {
          var r2 = this, i2 = this[Q];
          return i2.atom_.reportObserved(), i2.dehanceValues_(i2.values_)[e10](function(e11, i3) {
            return t10.call(n2, e11, i3, r2);
          });
        };
      }
      function ns(e10) {
        return function() {
          var t10 = this, n2 = this[Q];
          n2.atom_.reportObserved();
          var r2 = n2.dehanceValues_(n2.values_), i2 = arguments[0];
          return arguments[0] = function(e11, n3, r3) {
            return i2(e11, n3, r3, t10);
          }, r2[e10].apply(r2, arguments);
        };
      }
      ni("concat", no), ni("flat", no), ni("includes", no), ni("indexOf", no), ni("join", no), ni("lastIndexOf", no), ni("slice", no), ni("toString", no), ni("toLocaleString", no), ni("every", na), ni("filter", na), ni("find", na), ni("findIndex", na), ni("flatMap", na), ni("forEach", na), ni("map", na), ni("some", na), ni("reduce", ns), ni("reduceRight", ns);
      var nu = R("ObservableArrayAdministration", nn);
      function nc(e10) {
        return P(e10) && nu(e10[Q]);
      }
      var nl = {}, nh = "delete";
      l = Symbol.iterator, h = Symbol.toStringTag;
      var nf = (function() {
        function e10(e11, t11, n2) {
          var i2 = this;
          void 0 === t11 && (t11 = ei), void 0 === n2 && (n2 = "ObservableMap"), this.enhancer_ = void 0, this.name_ = void 0, this[Q] = nl, this.data_ = void 0, this.hasMap_ = void 0, this.keysAtom_ = void 0, this.interceptors_ = void 0, this.changeListeners_ = void 0, this.dehancer = void 0, this.enhancer_ = t11, this.name_ = n2, x(Map) || r(18), this.keysAtom_ = en("ObservableMap.keys()"), this.data_ = /* @__PURE__ */ new Map(), this.hasMap_ = /* @__PURE__ */ new Map(), eq(true, function() {
            i2.merge(e11);
          });
        }
        var t10 = e10.prototype;
        return t10.has_ = function(e11) {
          return this.data_.has(e11);
        }, t10.has = function(e11) {
          var t11 = this;
          if (!tt.trackingDerivation) return this.has_(e11);
          var n2 = this.hasMap_.get(e11);
          if (!n2) {
            var r2 = n2 = new ez(this.has_(e11), eo, "ObservableMap.key?", false);
            this.hasMap_.set(e11, r2), tT(r2, function() {
              return t11.hasMap_.delete(e11);
            });
          }
          return n2.get();
        }, t10.set = function(e11, t11) {
          var n2 = this.has_(e11);
          if (t2(this)) {
            var r2 = t6(this, { type: n2 ? ne : "add", object: this, newValue: t11, name: e11 });
            if (!r2) return this;
            t11 = r2.newValue;
          }
          return n2 ? this.updateValue_(e11, t11) : this.addValue_(e11, t11), this;
        }, t10.delete = function(e11) {
          var t11 = this;
          if (eQ(this.keysAtom_), t2(this) && !t6(this, { type: nh, object: this, name: e11 })) return false;
          if (this.has_(e11)) {
            var n2 = t7(this), r2 = n2 ? {
              observableKind: "map",
              debugObjectName: this.name_,
              type: nh,
              object: this,
              oldValue: this.data_.get(e11).value_,
              name: e11
            } : null;
            return t$(function() {
              var n3;
              t11.keysAtom_.reportChanged(), null == (n3 = t11.hasMap_.get(e11)) || n3.setNewValue_(false), t11.data_.get(e11).setNewValue_(void 0), t11.data_.delete(e11);
            }), n2 && t4(this, r2), true;
          }
          return false;
        }, t10.updateValue_ = function(e11, t11) {
          var n2 = this.data_.get(e11);
          if ((t11 = n2.prepareNewValue_(t11)) !== tt.UNCHANGED) {
            var r2 = t7(this), i2 = r2 ? {
              observableKind: "map",
              debugObjectName: this.name_,
              type: ne,
              object: this,
              oldValue: n2.value_,
              name: e11,
              newValue: t11
            } : null;
            n2.setNewValue_(t11), r2 && t4(this, i2);
          }
        }, t10.addValue_ = function(e11, t11) {
          var n2 = this;
          this.keysAtom_, t$(function() {
            var r3, i3 = new ez(t11, n2.enhancer_, "ObservableMap.key", false);
            n2.data_.set(e11, i3), t11 = i3.value_, null == (r3 = n2.hasMap_.get(e11)) || r3.setNewValue_(true), n2.keysAtom_.reportChanged();
          });
          var r2 = t7(this), i2 = r2 ? {
            observableKind: "map",
            debugObjectName: this.name_,
            type: "add",
            object: this,
            name: e11,
            newValue: t11
          } : null;
          r2 && t4(this, i2);
        }, t10.get = function(e11) {
          return this.has(e11) ? this.dehanceValue_(this.data_.get(e11).get()) : this.dehanceValue_(void 0);
        }, t10.dehanceValue_ = function(e11) {
          return void 0 !== this.dehancer ? this.dehancer(e11) : e11;
        }, t10.keys = function() {
          return this.keysAtom_.reportObserved(), this.data_.keys();
        }, t10.values = function() {
          var e11 = this, t11 = this.keys();
          return nM({
            next: function() {
              var n2 = t11.next(), r2 = n2.done, i2 = n2.value;
              return { done: r2, value: r2 ? void 0 : e11.get(i2) };
            }
          });
        }, t10.entries = function() {
          var e11 = this, t11 = this.keys();
          return nM({
            next: function() {
              var n2 = t11.next(), r2 = n2.done, i2 = n2.value;
              return { done: r2, value: r2 ? void 0 : [i2, e11.get(i2)] };
            }
          });
        }, t10[l] = function() {
          return this.entries();
        }, t10.forEach = function(e11, t11) {
          for (var n2, r2 = Y(this); !(n2 = r2()).done; ) {
            var i2 = n2.value, o2 = i2[0], a2 = i2[1];
            e11.call(t11, a2, o2, this);
          }
        }, t10.merge = function(e11) {
          var t11 = this;
          return n_(e11) && (e11 = new Map(e11)), t$(function() {
            T(e11) ? (function(e12) {
              var t12 = Object.keys(e12);
              if (!B) return t12;
              var n2 = Object.getOwnPropertySymbols(e12);
              return n2.length ? [].concat(
                t12,
                n2.filter(function(t13) {
                  return y.propertyIsEnumerable.call(e12, t13);
                })
              ) : t12;
            })(e11).forEach(function(n2) {
              return t11.set(n2, e11[n2]);
            }) : Array.isArray(e11) ? e11.forEach(function(e12) {
              var n2 = e12[0], r2 = e12[1];
              return t11.set(n2, r2);
            }) : D(e11) ? (e11.constructor !== Map && r(19, e11), e11.forEach(function(e12, n2) {
              return t11.set(n2, e12);
            })) : null != e11 && r(20, e11);
          }), this;
        }, t10.clear = function() {
          var e11 = this;
          t$(function() {
            e2(function() {
              for (var t11, n2 = Y(e11.keys()); !(t11 = n2()).done; ) {
                var r2 = t11.value;
                e11.delete(r2);
              }
            });
          });
        }, t10.replace = function(e11) {
          var t11 = this;
          return t$(function() {
            for (var n2, i2 = (function(e12) {
              if (D(e12) || n_(e12)) return e12;
              if (Array.isArray(e12)) return new Map(e12);
              if (!T(e12)) return r(21, e12);
              var t12 = /* @__PURE__ */ new Map();
              for (var n3 in e12) t12.set(n3, e12[n3]);
              return t12;
            })(e11), o2 = /* @__PURE__ */ new Map(), a2 = false, s2 = Y(t11.data_.keys()); !(n2 = s2()).done; ) {
              var u2 = n2.value;
              if (!i2.has(u2))
                if (t11.delete(u2)) a2 = true;
                else {
                  var c2 = t11.data_.get(u2);
                  o2.set(u2, c2);
                }
            }
            for (var l2, h2 = Y(i2.entries()); !(l2 = h2()).done; ) {
              var f2 = l2.value, _2 = f2[0], v2 = f2[1], d2 = t11.data_.has(_2);
              if (t11.set(_2, v2), t11.data_.has(_2)) {
                var p2 = t11.data_.get(_2);
                o2.set(_2, p2), d2 || (a2 = true);
              }
            }
            if (!a2)
              if (t11.data_.size !== o2.size) t11.keysAtom_.reportChanged();
              else
                for (var b2 = t11.data_.keys(), g2 = o2.keys(), y2 = b2.next(), m2 = g2.next(); !y2.done; ) {
                  if (y2.value !== m2.value) {
                    t11.keysAtom_.reportChanged();
                    break;
                  }
                  y2 = b2.next(), m2 = g2.next();
                }
            t11.data_ = o2;
          }), this;
        }, t10.toString = function() {
          return "[object ObservableMap]";
        }, t10.toJSON = function() {
          return Array.from(this);
        }, t10.observe_ = function(e11, t11) {
          return t8(this, e11);
        }, t10.intercept_ = function(e11) {
          return t3(this, e11);
        }, q(e10, [
          {
            key: "size",
            get: function() {
              return this.keysAtom_.reportObserved(), this.data_.size;
            }
          },
          {
            key: h,
            get: function() {
              return "Map";
            }
          }
        ]), e10;
      })(), n_ = R("ObservableMap", nf), nv = {};
      f = Symbol.iterator, _ = Symbol.toStringTag;
      var nd = (function() {
        function e10(e11, t11, n2) {
          void 0 === t11 && (t11 = ei), void 0 === n2 && (n2 = "ObservableSet"), this.name_ = void 0, this[Q] = nv, this.data_ = /* @__PURE__ */ new Set(), this.atom_ = void 0, this.changeListeners_ = void 0, this.interceptors_ = void 0, this.dehancer = void 0, this.enhancer_ = void 0, this.name_ = n2, x(Set) || r(22), this.atom_ = en(this.name_), this.enhancer_ = function(e12, r2) {
            return t11(e12, r2, n2);
          }, e11 && this.replace(e11);
        }
        var t10 = e10.prototype;
        return t10.dehanceValue_ = function(e11) {
          return void 0 !== this.dehancer ? this.dehancer(e11) : e11;
        }, t10.clear = function() {
          var e11 = this;
          t$(function() {
            e2(function() {
              for (var t11, n2 = Y(e11.data_.values()); !(t11 = n2()).done; ) {
                var r2 = t11.value;
                e11.delete(r2);
              }
            });
          });
        }, t10.forEach = function(e11, t11) {
          for (var n2, r2 = Y(this); !(n2 = r2()).done; ) {
            var i2 = n2.value;
            e11.call(t11, i2, i2, this);
          }
        }, t10.add = function(e11) {
          var t11 = this;
          if (eQ(this.atom_), t2(this) && !t6(this, { type: "add", object: this, newValue: e11 })) return this;
          if (!this.has(e11)) {
            t$(function() {
              t11.data_.add(t11.enhancer_(e11, void 0)), t11.atom_.reportChanged();
            });
            var n2 = t7(this), r2 = n2 ? { observableKind: "set", debugObjectName: this.name_, type: "add", object: this, newValue: e11 } : null;
            n2 && t4(this, r2);
          }
          return this;
        }, t10.delete = function(e11) {
          var t11 = this;
          if (t2(this) && !t6(this, { type: nh, object: this, oldValue: e11 })) return false;
          if (this.has(e11)) {
            var n2 = t7(this), r2 = n2 ? { observableKind: "set", debugObjectName: this.name_, type: nh, object: this, oldValue: e11 } : null;
            return t$(function() {
              t11.atom_.reportChanged(), t11.data_.delete(e11);
            }), n2 && t4(this, r2), true;
          }
          return false;
        }, t10.has = function(e11) {
          return this.atom_.reportObserved(), this.data_.has(this.dehanceValue_(e11));
        }, t10.entries = function() {
          var e11 = 0, t11 = Array.from(this.keys()), n2 = Array.from(this.values());
          return nM({
            next: function() {
              var r2 = e11;
              return e11 += 1, r2 < n2.length ? { value: [t11[r2], n2[r2]], done: false } : { done: true };
            }
          });
        }, t10.keys = function() {
          return this.values();
        }, t10.values = function() {
          this.atom_.reportObserved();
          var e11 = this, t11 = 0, n2 = Array.from(this.data_.values());
          return nM({
            next: function() {
              return t11 < n2.length ? { value: e11.dehanceValue_(n2[t11++]), done: false } : { done: true };
            }
          });
        }, t10.replace = function(e11) {
          var t11 = this;
          return np(e11) && (e11 = new Set(e11)), t$(function() {
            Array.isArray(e11) ? (t11.clear(), e11.forEach(function(e12) {
              return t11.add(e12);
            })) : L(e11) ? (t11.clear(), e11.forEach(function(e12) {
              return t11.add(e12);
            })) : null != e11 && r("Cannot initialize set from " + e11);
          }), this;
        }, t10.observe_ = function(e11, t11) {
          return t8(this, e11);
        }, t10.intercept_ = function(e11) {
          return t3(this, e11);
        }, t10.toJSON = function() {
          return Array.from(this);
        }, t10.toString = function() {
          return "[object ObservableSet]";
        }, t10[f] = function() {
          return this.values();
        }, q(e10, [
          {
            key: "size",
            get: function() {
              return this.atom_.reportObserved(), this.data_.size;
            }
          },
          {
            key: _,
            get: function() {
              return "Set";
            }
          }
        ]), e10;
      })(), np = R("ObservableSet", nd), nb = /* @__PURE__ */ Object.create(null), ng = "remove", ny = (function() {
        function e10(e11, t11, n2, r2) {
          void 0 === t11 && (t11 = /* @__PURE__ */ new Map()), void 0 === r2 && (r2 = em), this.target_ = void 0, this.values_ = void 0, this.name_ = void 0, this.defaultAnnotation_ = void 0, this.keysAtom_ = void 0, this.changeListeners_ = void 0, this.interceptors_ = void 0, this.proxy_ = void 0, this.isPlainObject_ = void 0, this.appliedAnnotations_ = void 0, this.pendingKeys_ = void 0, this.target_ = e11, this.values_ = t11, this.name_ = n2, this.defaultAnnotation_ = r2, this.keysAtom_ = new ee("ObservableObject.keys"), this.isPlainObject_ = T(this.target_);
        }
        var t10 = e10.prototype;
        return t10.getObservablePropValue_ = function(e11) {
          return this.values_.get(e11).get();
        }, t10.setObservablePropValue_ = function(e11, t11) {
          var n2 = this.values_.get(e11);
          if (n2 instanceof eX) return n2.set(t11), true;
          if (t2(this)) {
            var r2 = t6(this, { type: ne, object: this.proxy_ || this.target_, name: e11, newValue: t11 });
            if (!r2) return null;
            t11 = r2.newValue;
          }
          if ((t11 = n2.prepareNewValue_(t11)) !== tt.UNCHANGED) {
            var i2 = t7(this), o2 = i2 ? {
              type: ne,
              observableKind: "object",
              debugObjectName: this.name_,
              object: this.proxy_ || this.target_,
              oldValue: n2.value_,
              name: e11,
              newValue: t11
            } : null;
            n2.setNewValue_(t11), i2 && t4(this, o2);
          }
          return true;
        }, t10.get_ = function(e11) {
          return tt.trackingDerivation && !U(this.target_, e11) && this.has_(e11), this.target_[e11];
        }, t10.set_ = function(e11, t11, n2) {
          return (void 0 === n2 && (n2 = false), U(this.target_, e11)) ? this.values_.has(e11) ? this.setObservablePropValue_(e11, t11) : n2 ? Reflect.set(this.target_, e11, t11) : (this.target_[e11] = t11, true) : this.extend_(
            e11,
            { value: t11, enumerable: true, writable: true, configurable: true },
            this.defaultAnnotation_,
            n2
          );
        }, t10.has_ = function(e11) {
          if (!tt.trackingDerivation) return e11 in this.target_;
          this.pendingKeys_ || (this.pendingKeys_ = /* @__PURE__ */ new Map());
          var t11 = this.pendingKeys_.get(e11);
          return t11 || (t11 = new ez(e11 in this.target_, eo, "ObservableObject.key?", false), this.pendingKeys_.set(e11, t11)), t11.get();
        }, t10.make_ = function(e11, t11) {
          if (true === t11 && (t11 = this.defaultAnnotation_), false !== t11) {
            if (nj(this, t11, e11), !(e11 in this.target_)) {
              var n2;
              if (null != (n2 = this.target_[J]) && n2[e11]) return;
              r(1, t11.annotationType_, this.name_ + "." + e11.toString());
            }
            for (var i2 = this.target_; i2 && i2 !== y; ) {
              var o2 = b(i2, e11);
              if (o2) {
                var a2 = t11.make_(this, e11, o2, i2);
                if (0 === a2) return;
                if (1 === a2) break;
              }
              i2 = Object.getPrototypeOf(i2);
            }
            nS(this, t11, e11);
          }
        }, t10.extend_ = function(e11, t11, n2, r2) {
          if (void 0 === r2 && (r2 = false), true === n2 && (n2 = this.defaultAnnotation_), false === n2)
            return this.defineProperty_(e11, t11, r2);
          var i2 = n2.extend_(this, e11, t11, r2);
          return i2 && nS(this, n2, e11), i2;
        }, t10.defineProperty_ = function(e11, t11, n2) {
          void 0 === n2 && (n2 = false);
          try {
            to();
            var r2 = this.delete_(e11);
            if (!r2) return r2;
            if (t2(this)) {
              var i2 = t6(this, { object: this.proxy_ || this.target_, name: e11, type: "add", newValue: t11.value });
              if (!i2) return null;
              var o2 = i2.newValue;
              t11.value !== o2 && (t11 = H({}, t11, { value: o2 }));
            }
            if (n2) {
              if (!Reflect.defineProperty(this.target_, e11, t11)) return false;
            } else g(this.target_, e11, t11);
            this.notifyPropertyAddition_(e11, t11.value);
          } finally {
            ta();
          }
          return true;
        }, t10.defineObservableProperty_ = function(e11, t11, n2, r2) {
          void 0 === r2 && (r2 = false);
          try {
            to();
            var i2 = this.delete_(e11);
            if (!i2) return i2;
            if (t2(this)) {
              var o2 = t6(this, { object: this.proxy_ || this.target_, name: e11, type: "add", newValue: t11 });
              if (!o2) return null;
              t11 = o2.newValue;
            }
            var a2 = nA(e11), s2 = {
              configurable: !tt.safeDescriptors || this.isPlainObject_,
              enumerable: true,
              get: a2.get,
              set: a2.set
            };
            if (r2) {
              if (!Reflect.defineProperty(this.target_, e11, s2)) return false;
            } else g(this.target_, e11, s2);
            var u2 = new ez(t11, n2, "ObservableObject.key", false);
            this.values_.set(e11, u2), this.notifyPropertyAddition_(e11, u2.value_);
          } finally {
            ta();
          }
          return true;
        }, t10.defineComputedProperty_ = function(e11, t11, n2) {
          void 0 === n2 && (n2 = false);
          try {
            to();
            var r2 = this.delete_(e11);
            if (!r2) return r2;
            if (t2(this) && !t6(this, { object: this.proxy_ || this.target_, name: e11, type: "add", newValue: void 0 }))
              return null;
            t11.name || (t11.name = "ObservableObject.key"), t11.context = this.proxy_ || this.target_;
            var i2 = nA(e11), o2 = {
              configurable: !tt.safeDescriptors || this.isPlainObject_,
              enumerable: false,
              get: i2.get,
              set: i2.set
            };
            if (n2) {
              if (!Reflect.defineProperty(this.target_, e11, o2)) return false;
            } else g(this.target_, e11, o2);
            this.values_.set(e11, new eX(t11)), this.notifyPropertyAddition_(e11, void 0);
          } finally {
            ta();
          }
          return true;
        }, t10.delete_ = function(e11, t11) {
          if (void 0 === t11 && (t11 = false), !U(this.target_, e11)) return true;
          if (t2(this) && !t6(this, { object: this.proxy_ || this.target_, name: e11, type: ng })) return null;
          try {
            to();
            var n2, r2, i2, o2 = t7(this), a2 = this.values_.get(e11), s2 = void 0;
            if (!a2 && (o2 || 0) && (s2 = null == (i2 = b(this.target_, e11)) ? void 0 : i2.value), t11) {
              if (!Reflect.deleteProperty(this.target_, e11)) return false;
            } else delete this.target_[e11];
            if (a2 && (this.values_.delete(e11), a2 instanceof ez && (s2 = a2.value_), tu(a2)), this.keysAtom_.reportChanged(), null == (n2 = this.pendingKeys_) || null == (r2 = n2.get(e11)) || r2.set(e11 in this.target_), o2 || 0) {
              var u2 = {
                type: ng,
                observableKind: "object",
                object: this.proxy_ || this.target_,
                debugObjectName: this.name_,
                oldValue: s2,
                name: e11
              };
              o2 && t4(this, u2);
            }
          } finally {
            ta();
          }
          return true;
        }, t10.observe_ = function(e11, t11) {
          return t8(this, e11);
        }, t10.intercept_ = function(e11) {
          return t3(this, e11);
        }, t10.notifyPropertyAddition_ = function(e11, t11) {
          var n2, r2, i2 = t7(this);
          if (i2) {
            var o2 = i2 ? {
              type: "add",
              observableKind: "object",
              debugObjectName: this.name_,
              object: this.proxy_ || this.target_,
              name: e11,
              newValue: t11
            } : null;
            i2 && t4(this, o2);
          }
          null == (n2 = this.pendingKeys_) || null == (r2 = n2.get(e11)) || r2.set(true), this.keysAtom_.reportChanged();
        }, t10.ownKeys_ = function() {
          return this.keysAtom_.reportObserved(), M(this.target_);
        }, t10.keys_ = function() {
          return this.keysAtom_.reportObserved(), Object.keys(this.target_);
        }, e10;
      })();
      function nm(e10, t10) {
        if (U(e10, Q)) return e10;
        var n2, r2, i2 = null != (r2 = null == t10 ? void 0 : t10.name) ? r2 : "ObservableObject", o2 = new ny(e10, /* @__PURE__ */ new Map(), String(i2), t10 ? null != (n2 = t10.defaultDecorator) ? n2 : eO(t10) : void 0);
        return V(e10, Q, o2), e10;
      }
      var nO = R("ObservableObjectAdministration", ny);
      function nA(e10) {
        return nb[e10] || (nb[e10] = {
          get: function() {
            return this[Q].getObservablePropValue_(e10);
          },
          set: function(t10) {
            return this[Q].setObservablePropValue_(e10, t10);
          }
        });
      }
      function nw(e10) {
        return !!P(e10) && nO(e10[Q]);
      }
      function nS(e10, t10, n2) {
        var r2;
        null == (r2 = e10.target_[J]) || delete r2[n2];
      }
      function nj(e10, t10, n2) {
      }
      var nE = nT(0), nx = 0, nk = function() {
      };
      !(function(e10, t10) {
        Object.setPrototypeOf ? Object.setPrototypeOf(e10.prototype, t10) : void 0 !== e10.prototype.__proto__ ? e10.prototype.__proto__ = t10 : e10.prototype = t10;
      })(nk, Array.prototype);
      var nP = (function(e10, t10, n2) {
        function r2(t11, n3, r3, i3) {
          void 0 === r3 && (r3 = "ObservableArray"), void 0 === i3 && (i3 = false);
          var o2 = e10.call(this) || this, a2 = new nn(r3, n3, i3, true);
          if (a2.proxy_ = F(o2), C(F(o2), Q, a2), t11 && t11.length) {
            var s2 = eH(true);
            o2.spliceWithArray(0, 0, t11), eW(s2);
          }
          return Object.defineProperty(F(o2), "0", nE), o2;
        }
        W(r2, e10);
        var i2 = r2.prototype;
        return i2.concat = function() {
          this[Q].atom_.reportObserved();
          for (var e11 = arguments.length, t11 = Array(e11), n3 = 0; n3 < e11; n3++) t11[n3] = arguments[n3];
          return Array.prototype.concat.apply(
            this.slice(),
            t11.map(function(e12) {
              return nc(e12) ? e12.slice() : e12;
            })
          );
        }, i2[n2] = function() {
          var e11 = this, t11 = 0;
          return nM({
            next: function() {
              return t11 < e11.length ? { value: e11[t11++], done: false } : { done: true, value: void 0 };
            }
          });
        }, q(r2, [
          {
            key: "length",
            get: function() {
              return this[Q].getArrayLength_();
            },
            set: function(e11) {
              this[Q].setArrayLength_(e11);
            }
          },
          {
            key: t10,
            get: function() {
              return "Array";
            }
          }
        ]), r2;
      })(nk, Symbol.toStringTag, Symbol.iterator);
      function nT(e10) {
        return {
          enumerable: false,
          configurable: true,
          get: function() {
            return this[Q].get_(e10);
          },
          set: function(t10) {
            this[Q].set_(e10, t10);
          }
        };
      }
      function nN(e10) {
        if (e10 > nx) {
          for (var t10, n2 = nx; n2 < e10 + 100; n2++) t10 = n2, g(nP.prototype, "" + t10, nT(t10));
          nx = e10;
        }
      }
      function nV(e10, t10) {
        if ("object" == typeof e10 && null !== e10) {
          if (nc(e10)) return void 0 !== t10 && r(23), e10[Q].atom_;
          if (np(e10)) return e10.atom_;
          if (n_(e10)) {
            if (void 0 === t10) return e10.keysAtom_;
            var n2 = e10.data_.get(t10) || e10.hasMap_.get(t10);
            return n2 || r(25, t10, nR(e10)), n2;
          }
          if (nw(e10)) {
            if (!t10) return r(26);
            var i2 = e10[Q].values_.get(t10);
            return i2 || r(27, t10, nR(e10)), i2;
          }
          if (et(e10) || eY(e10) || t_(e10)) return e10;
        } else if (x(e10) && t_(e10[Q])) return e10[Q];
        r(28);
      }
      function nC(e10, t10) {
        return (e10 || r(29), void 0 !== t10) ? nC(nV(e10, t10)) : et(e10) || eY(e10) || t_(e10) || n_(e10) || np(e10) ? e10 : e10[Q] ? e10[Q] : void r(24, e10);
      }
      function nR(e10, t10) {
        var n2;
        if (void 0 !== t10) n2 = nV(e10, t10);
        else {
          if (tj(e10)) return e10.name;
          n2 = nw(e10) || n_(e10) || np(e10) ? nC(e10) : nV(e10);
        }
        return n2.name_;
      }
      Object.entries(nr).forEach(function(e10) {
        var t10 = e10[0], n2 = e10[1];
        "concat" !== t10 && V(nP.prototype, t10, n2);
      }), nN(1e3);
      var nD = y.toString;
      function nL(e10, t10, n2) {
        return void 0 === n2 && (n2 = -1), (function e11(t11, n3, r2, i2, o2) {
          if (t11 === n3) return 0 !== t11 || 1 / t11 == 1 / n3;
          if (null == t11 || null == n3) return false;
          if (t11 != t11) return n3 != n3;
          var a2 = typeof t11;
          if ("function" !== a2 && "object" !== a2 && "object" != typeof n3) return false;
          var s2 = nD.call(t11);
          if (s2 !== nD.call(n3)) return false;
          switch (s2) {
            case "[object RegExp]":
            case "[object String]":
              return "" + t11 == "" + n3;
            case "[object Number]":
              if (+t11 != +t11) return +n3 != +n3;
              return 0 == +t11 ? 1 / t11 == 1 / n3 : +t11 == +n3;
            case "[object Date]":
            case "[object Boolean]":
              return +t11 == +n3;
            case "[object Symbol]":
              return "undefined" != typeof Symbol && Symbol.valueOf.call(t11) === Symbol.valueOf.call(n3);
            case "[object Map]":
            case "[object Set]":
              r2 >= 0 && r2++;
          }
          t11 = nB(t11), n3 = nB(n3);
          var u2 = "[object Array]" === s2;
          if (!u2) {
            if ("object" != typeof t11 || "object" != typeof n3) return false;
            var c2 = t11.constructor, l2 = n3.constructor;
            if (c2 !== l2 && !(x(c2) && c2 instanceof c2 && x(l2) && l2 instanceof l2) && "constructor" in t11 && "constructor" in n3)
              return false;
          }
          if (0 === r2) return false;
          r2 < 0 && (r2 = -1), o2 = o2 || [];
          for (var h2 = (i2 = i2 || []).length; h2--; ) if (i2[h2] === t11) return o2[h2] === n3;
          if (i2.push(t11), o2.push(n3), u2) {
            if ((h2 = t11.length) !== n3.length) return false;
            for (; h2--; ) if (!e11(t11[h2], n3[h2], r2 - 1, i2, o2)) return false;
          } else {
            var f2, _2 = Object.keys(t11);
            if (h2 = _2.length, Object.keys(n3).length !== h2) return false;
            for (; h2--; ) if (!(U(n3, f2 = _2[h2]) && e11(t11[f2], n3[f2], r2 - 1, i2, o2))) return false;
          }
          return i2.pop(), o2.pop(), true;
        })(e10, t10, n2);
      }
      function nB(e10) {
        return nc(e10) ? e10.slice() : D(e10) || n_(e10) || L(e10) || np(e10) ? Array.from(e10.entries()) : e10;
      }
      function nM(e10) {
        return e10[Symbol.iterator] = nI, e10;
      }
      function nI() {
        return this;
      }
      ["Symbol", "Map", "Set"].forEach(function(e10) {
        void 0 === d()[e10] && r("MobX requires global '" + e10 + "' to be available or polyfilled");
      }), "object" == typeof __MOBX_DEVTOOLS_GLOBAL_HOOK__ && __MOBX_DEVTOOLS_GLOBAL_HOOK__.injectMobx({
        spy: function(e10) {
          return console.warn("[mobx.spy] Is a no-op in production builds"), function() {
          };
        },
        extras: { getDebugName: nR },
        $mobx: Q
      });
    }
  }
]);
