(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3143],
  {
    26870: (e) => {
      e.exports = {
        root: "EqualizerSlider_root__oyr_3",
        container: "EqualizerSlider_container__J9Te7",
        slider: "EqualizerSlider_slider__YC0_X",
        important: "EqualizerSlider_important____ilL",
        serif: "EqualizerSlider_serif__CJgYC",
        label: "EqualizerSlider_label__4wtBj",
        label_disabled: "EqualizerSlider_label_disabled___26v5"
      };
    },
    28584: (e, a, l) => {
      "use strict";
      l.d(a, { A: () => o });
      var r, t = l(61910), u = {
        5881: (e2, a2, l2) => {
          function r2() {
            for (var e3, a3, l3 = 0, r3 = ""; l3 < arguments.length; )
              (e3 = arguments[l3++]) && (a3 = (function e4(a4) {
                var l4, r4, t3 = "";
                if ("string" == typeof a4 || "number" == typeof a4) t3 += a4;
                else if ("object" == typeof a4)
                  if (Array.isArray(a4))
                    for (l4 = 0; l4 < a4.length; l4++) a4[l4] && (r4 = e4(a4[l4])) && (t3 && (t3 += " "), t3 += r4);
                  else for (l4 in a4) a4[l4] && (t3 && (t3 += " "), t3 += l4);
                return t3;
              })(e3)) && (r3 && (r3 += " "), r3 += a3);
            return r3;
          }
          l2.r(a2), l2.d(a2, { clsx: () => r2, default: () => t2 });
          let t2 = r2;
        },
        4525: (e2, a2, l2) => {
          l2.r(a2), l2.d(a2, { default: () => r2 });
          let r2 = {
            root: "JkKcxRVvjK7lcakkEliC",
            root_alwaysThumb: "cOKDtLfDZAuPXftfS2WM",
            root_trackSize_xxs: "d6VuG0HnwpGO47uPjPeb",
            root_trackSize_xs: "IB_XOYAyYPK4aszY9R1F",
            root_trackSize_s: "SHvrm0VRiLVwGqJJjNO8",
            root_thumbSize_xs: "BlvJwKLYTicnbJ3Qyuou",
            root_neverThumb: "dDJBVBTkzY5zY7vtSbyr",
            root_thumbSize_s: "qpvIbN4_hF6CqK0bjCq7",
            root_thumbSize_m: "P8_ABi1YnAOS8p8EY87f",
            root_thumbSize_l: "D21lBltSEiwHAaG39z6x"
          };
        },
        9097: (e2, a2) => {
          var l2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function r2(e3, a3, r3) {
            var t2 = null;
            if (void 0 !== r3 && (t2 = "" + r3), void 0 !== a3.key && (t2 = "" + a3.key), "key" in a3)
              for (var u2 in r3 = {}, a3) "key" !== u2 && (r3[u2] = a3[u2]);
            else r3 = a3;
            return { $$typeof: l2, type: e3, key: t2, ref: void 0 !== (a3 = r3.ref) ? a3 : null, props: r3 };
          }
          a2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), a2.jsx = r2, a2.jsxs = r2;
        },
        4377: (e2, a2, l2) => {
          e2.exports = l2(9097);
        },
        2342: (e2, a2) => {
          Object.defineProperty(a2, "__esModule", { value: true }), a2.ThumbVariant = a2.DEFAULT_MAX_VALUE = a2.SliderMode = void 0, a2.SliderMode = { NORMAL: "normal", DEFERRED: "deferred" }, a2.DEFAULT_MAX_VALUE = 100, a2.ThumbVariant = { HOVER: "hover", NEVER: "never", ALWAYS: "always" };
        },
        7886: function(e2, a2, l2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(a2, "__esModule", { value: true }), a2.Slider = void 0;
          let t2 = l2(4377), u2 = l2(5881), i2 = l2(810), s2 = l2(2342), n2 = r2(l2(4525)), o2 = (e3) => {
            let {
              forwardRef: a3,
              className: l3,
              value: r3,
              secondaryValue: o3 = s2.DEFAULT_MAX_VALUE,
              maxValue: v = s2.DEFAULT_MAX_VALUE,
              thumbSize: c = "l",
              trackSize: d = "s",
              mode: y = s2.SliderMode.NORMAL,
              onChange: _,
              showThumbVariant: k = s2.ThumbVariant.HOVER,
              ...m
            } = e3, [E, p] = (0, i2.useState)(null != r3 ? r3 : 0), [f, A] = (0, i2.useState)(false), [b, q] = (0, i2.useState)(false);
            (0, i2.useEffect)(() => {
              f || p(r3);
            }, [r3, f]), (0, i2.useEffect)(() => {
              !f && b && y === s2.SliderMode.DEFERRED && (_(E, true), q(false));
            }, [y, f, _, E, b]);
            let h = (0, i2.useCallback)(
              (e4) => {
                let a4 = Number(e4.target.value);
                p(a4), q(true), "normal" === y ? (_(a4, true), q(false)) : _(a4, false);
              },
              [p, _, y]
            ), S = (0, i2.useCallback)(
              (e4) => {
                let a4 = false, l4 = false;
                e4.stopPropagation(), e4.nativeEvent instanceof window.MouseEvent ? (a4 = 0 === e4.nativeEvent.button, l4 = "mousedown" === e4.nativeEvent.type) : (a4 = 1 === e4.nativeEvent.touches.length || "touchend" === e4.nativeEvent.type, l4 = "touchstart" === e4.nativeEvent.type), a4 && A(l4);
              },
              [A]
            ), C = (0, i2.useCallback)(() => {
              A(false);
            }, [A]), z = (0, i2.useMemo)(() => {
              let e4 = 100 * Math.min(E, v) / v, a4 = 100 * Math.min(o3, v) / v;
              return {
                backgroundSize: "".concat(e4, "% 100%"),
                "--seek-before-width": "".concat(e4, "%"),
                "--buffered-width": "".concat(a4, "%")
              };
            }, [E, o3, v]);
            return (0, t2.jsx)("input", {
              ref: a3,
              className: (0, u2.clsx)(
                n2.default.root,
                {
                  [n2.default["root_thumbSize_".concat(c)]]: c,
                  [n2.default["root_trackSize_".concat(d)]]: d,
                  [n2.default["root_".concat(k, "Thumb")]]: k
                },
                l3
              ),
              type: "range",
              max: v,
              value: E,
              style: z,
              onTouchStart: S,
              onTouchEnd: S,
              onMouseDown: S,
              onMouseUp: S,
              onMouseOut: C,
              onBlur: C,
              onChange: h,
              ...m
            });
          };
          a2.Slider = (0, i2.forwardRef)((e3, a3) => (0, t2.jsx)(o2, { forwardRef: a3, ...e3 }));
        },
        810: (e2) => {
          e2.exports = r || (r = l.t(t, 2));
        }
      }, i = {};
      function s(e2) {
        var a2 = i[e2];
        if (void 0 !== a2) return a2.exports;
        var l2 = i[e2] = { exports: {} };
        return u[e2].call(l2.exports, l2, l2.exports, s), l2.exports;
      }
      s.d = (e2, a2) => {
        for (var l2 in a2) s.o(a2, l2) && !s.o(e2, l2) && Object.defineProperty(e2, l2, { enumerable: true, get: a2[l2] });
      }, s.o = (e2, a2) => Object.prototype.hasOwnProperty.call(e2, a2), s.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var n = {};
      (() => {
        Object.defineProperty(n, "X", { value: true }), n.i = void 0;
        var e2 = s(7886);
        Object.defineProperty(n, "i", {
          enumerable: true,
          get: function() {
            return e2.Slider;
          }
        });
      })();
      var o = n.i;
      n.X;
    },
    35100: (e) => {
      e.exports = {
        root: "EqualizerPresets_root__b2gp7",
        buttonIcon: "EqualizerPresets_buttonIcon__DgPG8",
        buttonText: "EqualizerPresets_buttonText__cy2_S",
        button: "EqualizerPresets_button__D8s_l",
        button_disabled: "EqualizerPresets_button_disabled__BcN1s",
        container: "EqualizerPresets_container__ABVY8"
      };
    },
    40320: (e, a, l) => {
      "use strict";
      l.d(a, { rk: () => w, iV: () => i, MZ: () => M, ML: () => k, Sq: () => s });
      var r, t = l(56258), u = l(61910);
      let i = (0, u.createContext)(null), s = () => {
        let e2 = (0, u.useContext)(i);
        if (!e2)
          throw new t.t("Equalizer cannot be null, please add a context provider", {
            code: "E_CONTEXT_EQUALIZER_NULL"
          });
        return e2;
      };
      var n = l(63930), o = l(93064);
      !(function(e2) {
        e2.CUSTOM = "CUSTOM", e2.DEFAULT = "DEFAULT", e2.CLASSICAL = "CLASSICAL", e2.CLUB = "CLUB", e2.DANCE = "DANCE", e2.BASS_BOOST = "BASS_BOOST", e2.BASS_AND_TREBLE_BOOST = "BASS_AND_TREBLE_BOOST", e2.TREBLE_BOOST = "TREBLE_BOOST", e2.SPEAKERS = "SPEAKERS", e2.LARGE_HALL = "LARGE_HALL", e2.CONCERT = "CONCERT", e2.PARTY = "PARTY", e2.POP = "POP", e2.REGGAE = "REGGAE", e2.ROCK = "ROCK", e2.SKA = "SKA", e2.SOFT = "SOFT", e2.SOFT_ROCK = "SOFT_ROCK", e2.TECHNO = "TECHNO";
      })(r || (r = {}));
      let v = {
        [r.CUSTOM]: {
          id: r.CUSTOM,
          preamp: 1,
          frequencies: [
            { key: 60, value: 0 },
            { key: 170, value: 0 },
            { key: 310, value: 0 },
            { key: 600, value: 0 },
            { key: 1e3, value: 0 },
            { key: 3e3, value: 0 },
            { key: 6e3, value: 0 },
            { key: 12e3, value: 0 },
            { key: 14e3, value: 0 },
            { key: 16e3, value: 0 }
          ]
        },
        [r.DEFAULT]: {
          id: r.DEFAULT,
          preamp: 1,
          frequencies: [
            { key: 60, value: 0 },
            { key: 170, value: 0 },
            { key: 310, value: 0 },
            { key: 600, value: 0 },
            { key: 1e3, value: 0 },
            { key: 3e3, value: 0 },
            { key: 6e3, value: 0 },
            { key: 12e3, value: 0 },
            { key: 14e3, value: 0 },
            { key: 16e3, value: 0 }
          ]
        },
        [r.CLASSICAL]: {
          id: r.CLASSICAL,
          preamp: 1,
          frequencies: [
            { key: 60, value: -0.5 },
            { key: 170, value: -0.5 },
            { key: 310, value: -0.5 },
            { key: 600, value: -0.5 },
            { key: 1e3, value: -0.5 },
            { key: 3e3, value: -0.5 },
            { key: 6e3, value: -3.5 },
            { key: 12e3, value: -3.5 },
            { key: 14e3, value: -3.5 },
            { key: 16e3, value: -4.5 }
          ]
        },
        [r.CLUB]: {
          id: r.CLUB,
          preamp: 1,
          frequencies: [
            { key: 60, value: -0.5 },
            { key: 170, value: -0.5 },
            { key: 310, value: 4 },
            { key: 600, value: 2.5 },
            { key: 1e3, value: 2.5 },
            { key: 3e3, value: 2.5 },
            { key: 6e3, value: 1.5 },
            { key: 12e3, value: -0.5 },
            { key: 14e3, value: -0.5 },
            { key: 16e3, value: -0.5 }
          ]
        },
        [r.DANCE]: {
          id: r.DANCE,
          preamp: 1,
          frequencies: [
            { key: 60, value: 4.5 },
            { key: 170, value: 3.5 },
            { key: 310, value: 1 },
            { key: 600, value: -0.5 },
            { key: 1e3, value: -0.5 },
            { key: 3e3, value: -2.5 },
            { key: 6e3, value: -3.5 },
            { key: 12e3, value: -3.5 },
            { key: 14e3, value: -0.5 },
            { key: 16e3, value: -0.5 }
          ]
        },
        [r.BASS_BOOST]: {
          id: r.BASS_BOOST,
          preamp: 1,
          frequencies: [
            { key: 60, value: 4 },
            { key: 170, value: 4.5 },
            { key: 310, value: 4.5 },
            { key: 600, value: 2.5 },
            { key: 1e3, value: 0.5 },
            { key: 3e3, value: -2 },
            { key: 6e3, value: -4 },
            { key: 12e3, value: -5 },
            { key: 14e3, value: -5.5 },
            { key: 16e3, value: -5.5 }
          ]
        },
        [r.BASS_AND_TREBLE_BOOST]: {
          id: r.BASS_AND_TREBLE_BOOST,
          preamp: 1,
          frequencies: [
            { key: 60, value: 3.5 },
            { key: 170, value: 2.5 },
            { key: 310, value: -0.5 },
            { key: 600, value: -3.5 },
            { key: 1e3, value: -2 },
            { key: 3e3, value: 0.5 },
            { key: 6e3, value: 4 },
            { key: 12e3, value: 5.5 },
            { key: 14e3, value: 6 },
            { key: 16e3, value: 6 }
          ]
        },
        [r.TREBLE_BOOST]: {
          id: r.TREBLE_BOOST,
          preamp: 1,
          frequencies: [
            { key: 60, value: -4.5 },
            { key: 170, value: -4.5 },
            { key: 310, value: -4.5 },
            { key: 600, value: -2 },
            { key: 1e3, value: 1 },
            { key: 3e3, value: 5.5 },
            { key: 6e3, value: 8 },
            { key: 12e3, value: 8 },
            { key: 14e3, value: 8 },
            { key: 16e3, value: 8 }
          ]
        },
        [r.SPEAKERS]: {
          id: r.SPEAKERS,
          preamp: 1,
          frequencies: [
            { key: 60, value: 2 },
            { key: 170, value: 5.5 },
            { key: 310, value: 2.5 },
            { key: 600, value: -1.5 },
            { key: 1e3, value: -1 },
            { key: 3e3, value: 0.5 },
            { key: 6e3, value: 2 },
            { key: 12e3, value: 4.5 },
            { key: 14e3, value: 6 },
            { key: 16e3, value: 7 }
          ]
        },
        [r.LARGE_HALL]: {
          id: r.LARGE_HALL,
          preamp: 1,
          frequencies: [
            { key: 60, value: 5 },
            { key: 170, value: 5 },
            { key: 310, value: 2.5 },
            { key: 600, value: 2.5 },
            { key: 1e3, value: -0.5 },
            { key: 3e3, value: -2 },
            { key: 6e3, value: -2 },
            { key: 12e3, value: -2 },
            { key: 14e3, value: -0.5 },
            { key: 16e3, value: -0.5 }
          ]
        },
        [r.CONCERT]: {
          id: r.CONCERT,
          preamp: 1,
          frequencies: [
            { key: 60, value: -2 },
            { key: 170, value: -0.5 },
            { key: 310, value: 2 },
            { key: 600, value: 2.5 },
            { key: 1e3, value: 2.5 },
            { key: 3e3, value: 2.5 },
            { key: 6e3, value: 2 },
            { key: 12e3, value: 1 },
            { key: 14e3, value: 1 },
            { key: 16e3, value: 1 }
          ]
        },
        [r.PARTY]: {
          id: r.PARTY,
          preamp: 1,
          frequencies: [
            { key: 60, value: 3.5 },
            { key: 170, value: 3.5 },
            { key: 310, value: -0.5 },
            { key: 600, value: -0.5 },
            { key: 1e3, value: -0.5 },
            { key: 3e3, value: -0.5 },
            { key: 6e3, value: -0.5 },
            { key: 12e3, value: -0.5 },
            { key: 14e3, value: 3.5 },
            { key: 16e3, value: 3.5 }
          ]
        },
        [r.POP]: {
          id: r.POP,
          preamp: 1,
          frequencies: [
            { key: 60, value: -0.5 },
            { key: 170, value: 2 },
            { key: 310, value: 3.5 },
            { key: 600, value: 4 },
            { key: 1e3, value: 2.5 },
            { key: 3e3, value: -0.5 },
            { key: 6e3, value: -1 },
            { key: 12e3, value: -1 },
            { key: 14e3, value: -0.5 },
            { key: 16e3, value: -0.5 }
          ]
        },
        [r.REGGAE]: {
          id: r.REGGAE,
          preamp: 1,
          frequencies: [
            { key: 60, value: -0.5 },
            { key: 170, value: -0.5 },
            { key: 310, value: -0.5 },
            { key: 600, value: -2.5 },
            { key: 1e3, value: -0.5 },
            { key: 3e3, value: 3 },
            { key: 6e3, value: 3 },
            { key: 12e3, value: -0.5 },
            { key: 14e3, value: -0.5 },
            { key: 16e3, value: -0.5 }
          ]
        },
        [r.ROCK]: {
          id: r.ROCK,
          preamp: 1,
          frequencies: [
            { key: 60, value: 4 },
            { key: 170, value: 2 },
            { key: 310, value: -2.5 },
            { key: 600, value: -4 },
            { key: 1e3, value: -1.5 },
            { key: 3e3, value: 2 },
            { key: 6e3, value: 4 },
            { key: 12e3, value: 5.5 },
            { key: 14e3, value: 5.5 },
            { key: 16e3, value: 5.5 }
          ]
        },
        [r.SKA]: {
          id: r.SKA,
          preamp: 1,
          frequencies: [
            { key: 60, value: -1 },
            { key: 170, value: -2 },
            { key: 310, value: -2 },
            { key: 600, value: -0.5 },
            { key: 1e3, value: 2 },
            { key: 3e3, value: 2.5 },
            { key: 6e3, value: 4 },
            { key: 12e3, value: 4.5 },
            { key: 14e3, value: 5.5 },
            { key: 16e3, value: 4.5 }
          ]
        },
        [r.SOFT]: {
          id: r.SOFT,
          preamp: 1,
          frequencies: [
            { key: 60, value: 2 },
            { key: 170, value: 0.5 },
            { key: 310, value: -0.5 },
            { key: 600, value: -1 },
            { key: 1e3, value: -0.5 },
            { key: 3e3, value: 2 },
            { key: 6e3, value: 4 },
            { key: 12e3, value: 4.5 },
            { key: 14e3, value: 5.5 },
            { key: 16e3, value: 6 }
          ]
        },
        [r.SOFT_ROCK]: {
          id: r.SOFT_ROCK,
          preamp: 1,
          frequencies: [
            { key: 60, value: 2 },
            { key: 170, value: 2 },
            { key: 310, value: 1 },
            { key: 600, value: -0.5 },
            { key: 1e3, value: -2 },
            { key: 3e3, value: -2.5 },
            { key: 6e3, value: -1.5 },
            { key: 12e3, value: -0.5 },
            { key: 14e3, value: 1 },
            { key: 16e3, value: 4 }
          ]
        },
        [r.TECHNO]: {
          id: r.TECHNO,
          preamp: 1,
          frequencies: [
            { key: 60, value: 4 },
            { key: 170, value: 2.5 },
            { key: 310, value: -0.5 },
            { key: 600, value: -2.5 },
            { key: 1e3, value: -2 },
            { key: 3e3, value: -0.5 },
            { key: 6e3, value: 4 },
            { key: 12e3, value: 4.5 },
            { key: 14e3, value: 4.5 },
            { key: 16e3, value: 4 }
          ]
        }
      };
      var c = l(74125), d = l(26433);
      let y = o.gK.model("EqualizerFrequency", { key: o.gK.number, value: o.gK.number }), _ = o.gK.model("EqualizerPreset", {
        id: o.gK.enumeration(Object.values(r)),
        preamp: o.gK.number,
        frequencies: o.gK.array(y)
      }).actions((e2) => ({
        setPreamp(a2) {
          e2.preamp = a2;
        },
        setAmp(a2, l2) {
          e2.frequencies.forEach((e3) => {
            e3.key === a2 && (e3.value = l2);
          });
        }
      })), k = o.gK.model("Equalizer", {
        modal: d.qt,
        isAvailable: o.gK.optional(o.gK.boolean, false),
        isEnabled: o.gK.boolean,
        currentPreset: o.gK.optional(_, v[r.DEFAULT]),
        customPreset: o.gK.optional(_, v[r.CUSTOM])
      }).actions((e2) => ({
        setIsAvailable(a2) {
          e2.isAvailable = a2;
        },
        setEnabled(a2) {
          let { localStorage: l2 } = (0, o._$)(e2);
          e2.isEnabled = a2;
          let r2 = l2.get(c.cYZ.EqualizerConfig);
          l2.set(c.cYZ.EqualizerConfig, { ...r2, isEnabled: a2, version: "6" });
        },
        loadPresets() {
          let { localStorage: a2 } = (0, o._$)(e2), l2 = a2.get(c.cYZ.EqualizerConfig);
          if ((null == l2 ? void 0 : l2.version) !== "6" && (a2.remove(c.cYZ.EqualizerConfig), l2 = null), l2 && (e2.isEnabled = l2.isEnabled, l2.customPreset && (e2.customPreset = (0, o.wg)(l2.customPreset)), l2.lastPresetId)) {
            if (l2.lastPresetId === r.CUSTOM) {
              e2.currentPreset = (0, o.o8)(e2.customPreset);
              return;
            }
            let a3 = v[l2.lastPresetId];
            e2.currentPreset = _.create(a3);
          }
        },
        changeCurrentPreset(a2) {
          let { localStorage: l2 } = (0, o._$)(e2), t2 = l2.get(c.cYZ.EqualizerConfig);
          if (l2.set(c.cYZ.EqualizerConfig, { ...t2, lastPresetId: a2, version: "6" }), a2 === r.CUSTOM) {
            e2.currentPreset = (0, o.o8)(e2.customPreset);
            return;
          }
          let u2 = v[a2];
          e2.currentPreset = _.create(u2);
        },
        changePreamp(a2) {
          let { localStorage: l2 } = (0, o._$)(e2), t2 = (0, o.dV)(e2.currentPreset);
          e2.customPreset = (0, o.wg)({ ...t2, id: r.CUSTOM }), e2.customPreset.setPreamp(a2), e2.currentPreset = (0, o.o8)(e2.customPreset);
          let u2 = l2.get(c.cYZ.EqualizerConfig);
          l2.set(c.cYZ.EqualizerConfig, {
            ...u2,
            customPreset: (0, n.HO)(e2.customPreset),
            lastPresetId: r.CUSTOM,
            version: "6"
          });
        },
        changeAmp(a2, l2) {
          let { localStorage: t2 } = (0, o._$)(e2), u2 = (0, o.dV)(e2.currentPreset);
          e2.customPreset = (0, o.wg)({ ...u2, id: r.CUSTOM }), e2.customPreset.setAmp(a2, l2), e2.currentPreset = (0, o.o8)(e2.customPreset);
          let i2 = t2.get(c.cYZ.EqualizerConfig);
          t2.set(c.cYZ.EqualizerConfig, {
            ...i2,
            customPreset: (0, n.HO)(e2.customPreset),
            lastPresetId: r.CUSTOM,
            version: "6"
          });
        }
      }));
      var m = l(54486), E = l(50420), p = l(28303), f = l(43426), A = l(63664), b = l(31500), q = l(61609), h = l(97800), S = l(61915), C = l.n(S), z = l(47713), T = l(77881), O = l(71656), x = l(5956), P = l(35100), R = l.n(P);
      let g = {
        [r.DEFAULT]: (0, m.jsx)(z.A, { id: "equalizer.default-preset" }),
        [r.CUSTOM]: (0, m.jsx)(z.A, { id: "equalizer.custom-preset" }),
        [r.CLASSICAL]: (0, m.jsx)(z.A, { id: "equalizer.classical-preset" }),
        [r.CLUB]: (0, m.jsx)(z.A, { id: "equalizer.club-preset" }),
        [r.DANCE]: (0, m.jsx)(z.A, { id: "equalizer.dance-preset" }),
        [r.BASS_BOOST]: (0, m.jsx)(z.A, { id: "equalizer.bass-boost-preset" }),
        [r.BASS_AND_TREBLE_BOOST]: (0, m.jsx)(z.A, { id: "equalizer.bass-and-treble-boost-preset" }),
        [r.TREBLE_BOOST]: (0, m.jsx)(z.A, { id: "equalizer.treble-boost-preset" }),
        [r.SPEAKERS]: (0, m.jsx)(z.A, { id: "equalizer.speakers-preset" }),
        [r.LARGE_HALL]: (0, m.jsx)(z.A, { id: "equalizer.large-hall-preset" }),
        [r.CONCERT]: (0, m.jsx)(z.A, { id: "equalizer.concert-preset" }),
        [r.PARTY]: (0, m.jsx)(z.A, { id: "equalizer.party-preset" }),
        [r.POP]: (0, m.jsx)(z.A, { id: "equalizer.pop-preset" }),
        [r.REGGAE]: (0, m.jsx)(z.A, { id: "equalizer.reggae-preset" }),
        [r.ROCK]: (0, m.jsx)(z.A, { id: "equalizer.rock-preset" }),
        [r.SKA]: (0, m.jsx)(z.A, { id: "equalizer.ska-preset" }),
        [r.SOFT]: (0, m.jsx)(z.A, { id: "equalizer.soft-preset" }),
        [r.SOFT_ROCK]: (0, m.jsx)(z.A, { id: "equalizer.soft-rock-preset" }),
        [r.TECHNO]: (0, m.jsx)(z.A, { id: "equalizer.techno-preset" })
      }, L = (0, p.PA)((e2) => {
        let { isDisabled: a2 } = e2, l2 = s(), t2 = (0, u.useCallback)(
          (e3) => {
            l2.changeCurrentPreset(e3.id);
          },
          [l2]
        );
        return (0, m.jsx)(O.ms, {
          isDisabled: a2,
          className: R().root,
          onSelect: t2,
          reference: (0, m.jsxs)(T.$, {
            radius: "xxxl",
            className: (0, E.$)(R().button, { [R().button_disabled]: a2 }),
            ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_PRESETS_BUTTON),
            children: [
              (0, m.jsx)(h.Caption, {
                className: R().buttonText,
                variant: "span",
                size: "s",
                weight: "medium",
                children: g[l2.currentPreset.id]
              }),
              (0, m.jsx)(x.Icon, { className: R().buttonIcon, size: "xxs", variant: "arrowDown" })
            ]
          }),
          placement: "top",
          offsetOptions: -40,
          defaultValue: l2.currentPreset.id,
          containerClassName: R().container,
          ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_PRESETS_DROPDOWN),
          children: Object.values(r).map((e3) => (0, m.jsx)(O.c$, { id: e3, label: g[e3] }, e3))
        });
      });
      var j = l(28584), N = l(26870), K = l.n(N);
      let U = (e2) => {
        let { minValue: a2, maxValue: l2, className: r2, label: t2, isDisabled: u2, onChange: i2, value: s2, ...n2 } = e2;
        return (0, m.jsxs)("div", {
          className: (0, E.$)(K().root, r2),
          ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_SLIDER_CONTAINER),
          children: [
            (0, m.jsxs)("div", {
              className: K().container,
              children: [
                (0, m.jsx)("div", { className: K().serif }),
                (0, m.jsx)(j.A, {
                  disabled: u2,
                  className: (0, E.$)(K().slider, K().important),
                  thumbSize: "m",
                  trackSize: "xxs",
                  onChange: i2,
                  value: s2,
                  showThumbVariant: "always",
                  step: 0.1,
                  min: a2,
                  max: l2,
                  ...n2
                })
              ]
            }),
            (0, m.jsx)(h.Caption, {
              "aria-hidden": true,
              className: (0, E.$)(K().label, { [K().label_disabled]: u2 }),
              variant: "div",
              weight: "normal",
              size: "xs",
              children: t2
            })
          ]
        });
      }, B = {
        enter: C().equalizer_enter,
        enterActive: C().equalizer_enter_active,
        exit: C().equalizer_exit,
        exitActive: C().equalizer_exit_active
      }, w = (0, p.PA)((e2) => {
        let { title: a2, className: l2, isExpanded: r2, isDisabled: t2 } = e2, i2 = (0, u.useRef)(null), { formatMessage: n2 } = (0, f.A)(), o2 = s(), v2 = o2.isEnabled ? n2({ id: "equalizer.disable-equalizer" }) : n2({ id: "equalizer.enable-equalizer" }), c2 = (0, u.useCallback)(
          (e3) => {
            o2.setEnabled(e3);
          },
          [o2]
        ), d2 = (0, u.useCallback)(
          (e3) => (a3) => {
            o2.changeAmp(e3, a3);
          },
          [o2]
        ), y2 = (0, u.useCallback)(
          (e3) => {
            o2.changePreamp(e3);
          },
          [o2]
        );
        return (0, m.jsxs)("div", {
          className: (0, E.$)(C().root, l2),
          ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_CONTAINER),
          children: [
            (0, m.jsxs)("div", {
              className: C().header,
              children: [
                (0, m.jsx)(h.Caption, {
                  className: C().title,
                  variant: "span",
                  size: "l",
                  weight: "medium",
                  ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_TITLE),
                  children: a2
                }),
                (0, m.jsx)(q.l, {
                  "aria-label": v2,
                  isChecked: o2.isEnabled,
                  onChange: c2,
                  ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_TOGGLE)
                })
              ]
            }),
            (0, m.jsx)(A.A, {
              in: r2,
              nodeRef: i2,
              timeout: 200,
              unmountOnExit: true,
              classNames: B,
              children: (0, m.jsxs)("div", {
                ref: i2,
                className: (0, E.$)(C().equalizer, { [C().equalizer_disabled]: t2 }),
                ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_FREQUENCIES_CONTAINER),
                children: [
                  (0, m.jsxs)("div", {
                    className: C().container,
                    children: [
                      (0, m.jsxs)("div", {
                        className: C().preamp,
                        children: [
                          (0, m.jsx)(U, {
                            isDisabled: t2,
                            minValue: 0.5,
                            maxValue: 1.5,
                            value: o2.currentPreset.preamp,
                            onChange: y2,
                            label: n2({ id: "equalizer.preamp-level" }),
                            "aria-label": n2({ id: "equalizer.slider-preamp-label" }),
                            ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_PREAMP_SLIDER)
                          }),
                          (0, m.jsxs)("div", {
                            className: C().labels,
                            "aria-hidden": true,
                            children: [
                              (0, m.jsx)(h.Caption, {
                                className: C().label,
                                variant: "div",
                                weight: "normal",
                                size: "xs",
                                children: n2({ id: "equalizer.amp-label" }, { value: 12 })
                              }),
                              (0, m.jsx)(h.Caption, {
                                className: C().label,
                                variant: "div",
                                weight: "normal",
                                size: "xs",
                                children: n2({ id: "equalizer.amp-label" }, { value: 0 })
                              }),
                              (0, m.jsx)(h.Caption, {
                                className: C().label,
                                variant: "div",
                                weight: "normal",
                                size: "xs",
                                children: n2({ id: "equalizer.amp-label" }, { value: -12 })
                              })
                            ]
                          })
                        ]
                      }),
                      (0, m.jsx)("div", {
                        className: C().frequencies,
                        children: o2.currentPreset.frequencies.map((e3) => {
                          let a3 = ((e4, a4) => e4 < 1e3 ? e4.toString() : a4({ id: "equalizer.frequency-label" }, { value: (e4 / 1e3).toFixed(0) }))(e3.key, n2), l3 = Math.round(10 * e3.value) / 10;
                          return (0, m.jsx)(
                            U,
                            {
                              isDisabled: t2,
                              minValue: -12,
                              maxValue: 12,
                              value: e3.value,
                              label: a3,
                              onChange: d2(e3.key),
                              "aria-label": n2({ id: "equalizer.slider-frequency-label" }, { label: a3, value: l3 }),
                              ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_FREQUENCY_SLIDER)
                            },
                            a3
                          );
                        })
                      })
                    ]
                  }),
                  (0, m.jsx)(L, { isDisabled: t2 })
                ]
              })
            })
          ]
        });
      });
      var D = l(32692);
      let M = (0, p.PA)(() => {
        let { formatMessage: e2 } = (0, f.A)(), a2 = s();
        return (0, m.jsx)(D.a, {
          className: C().modal,
          headerClassName: C().modalHeader,
          contentClassName: C().modalContent,
          title: e2({ id: "equalizer.title" }),
          open: a2.modal.isOpened,
          onOpenChange: a2.modal.onOpenChange,
          onClose: a2.modal.close,
          size: "fitContent",
          placement: "center",
          overlayColor: "full",
          labelClose: e2({ id: "interface-actions.close" }),
          closeButtonProps: (0, b.Am)(b.Kq.equalizer.EQUALIZER_MODAL_CLOSE_BUTTON),
          ...(0, b.Am)(b.Kq.equalizer.EQUALIZER_MODAL),
          children: (0, m.jsx)(w, { title: e2({ id: "equalizer.enable" }), isExpanded: true, isDisabled: !a2.isEnabled })
        });
      });
    },
    50873: (e) => {
      e.exports = { root: "CustomPlayerThumb_root__hZTw6", container: "CustomPlayerThumb_container__lBm2j" };
    },
    59672: (e, a, l) => {
      "use strict";
      l.d(a, { zf: () => s, rI: () => n, Th: () => T, KB: () => u, ls: () => o, Jy: () => v });
      var r = l(74125), t = l(93064);
      let u = t.gK.model("CustomPlayerThumb", { href: t.gK.string, width: t.gK.number, height: t.gK.number }), i = t.gK.model("CustomPlayerThumbItem", {
        id: t.gK.enumeration(Object.values(r.TZj)),
        name: t.gK.string,
        thumb: u
      }), s = {
        [r.TZj.DUCK]: () => l.e(8962).then(l.t.bind(l, 68962, 17)).then((e2) => e2.default),
        [r.TZj.CAR]: () => l.e(8765).then(l.t.bind(l, 68765, 17)).then((e2) => e2.default)
      }, n = (e2) => /* @__PURE__ */ new Map([
        [
          r.TZj.DUCK,
          i.create({
            id: r.TZj.DUCK,
            name: e2({ id: "branded-player.duck" }),
            thumb: { href: r.TZj.DUCK, width: 50, height: 50 }
          })
        ],
        [
          r.TZj.CAR,
          i.create({
            id: r.TZj.CAR,
            name: e2({ id: "branded-player.car" }),
            thumb: { href: r.TZj.CAR, width: 143, height: 38 }
          })
        ]
      ]), o = (e2) => !!("object" == typeof e2 && null !== e2 && "href" in e2 && "string" == typeof e2.href && "width" in e2 && "number" == typeof e2.width && "height" in e2 && "number" == typeof e2.height), v = (e2) => e2.startsWith(r.nl3);
      var c = l(54486), d = l(38974), y = l(57249), _ = l(50420), k = l(28303), m = l(83645), E = l(61910), p = l(43426), f = l(8817), A = l(27510), b = l(77881), q = l(89461), h = l(50873), S = l.n(h), C = l(49124);
      let z = m.default.default(
        () => Promise.resolve().then(l.bind(l, 38974)).then((e2) => e2.DotLottieWorkerReact),
        { ssr: false }
      );
      {
        let e2 = C.env.USE_CDN_FOR_STATIC ? "https://yastatic-net.ru/s3/music-frontend-static/music/vundefined" : window.location.origin;
        (0, d.setWasmUrl)(new URL(y, e2).href);
      }
      let T = (0, k.PA)((e2) => {
        let { className: a2, thumbData: l2, onThumbAction: t2 } = e2, { sonataState: u2 } = (0, r.Pjs)(), { formatMessage: i2 } = (0, p.A)(), [n2, o2] = (0, E.useState)(null), [d2, y2] = (0, E.useState)(null), k2 = (0, E.useRef)(null), m2 = (0, E.useRef)(null), h2 = (0, f.c)(() => {
          u2.status === q.MT.PLAYING ? null == n2 || n2.play() : null == n2 || n2.pause();
        });
        (0, E.useEffect)(() => {
          if (!l2) return;
          if (v(l2.href)) return void y2(l2.href);
          let e3 = s[l2.href];
          e3 ? e3().then((e4) => {
            v(e4) ? y2(e4) : y2("".concat(window.location.origin).concat(e4));
          }) : y2(l2.href);
        }, [l2]), (0, E.useEffect)(() => {
          n2 && (n2.setUseFrameInterpolation(false), n2.setRenderConfig({ devicePixelRatio: 0.1 }));
        }, [n2]), (0, E.useEffect)(() => {
          if (n2)
            return n2.addEventListener("load", h2), () => {
              n2.removeEventListener("load", h2);
            };
        }, [n2, h2, u2.status]), (0, E.useEffect)(() => {
          h2();
        }, [n2, h2, u2.status]), (0, E.useEffect)(
          () => () => {
            m2.current && clearTimeout(m2.current);
          },
          []
        );
        let C2 = (0, f.c)(() => {
          m2.current && (clearTimeout(m2.current), m2.current = null), null == t2 || t2();
        }), T2 = (0, f.c)(() => {
          t2 && (m2.current && clearTimeout(m2.current), m2.current = setTimeout(() => {
            null == t2 || t2(), m2.current = null;
          }, 800));
        }), O = (0, f.c)(() => {
          m2.current && (clearTimeout(m2.current), m2.current = null);
        }), x = (0, A.L)(() => {
          if (l2)
            return {
              "--thumb-width": "".concat(l2.width, "px"),
              "--thumb-height": "".concat(l2.height, "px"),
              "--thumb-cursor": t2 ? "pointer" : "auto"
            };
        });
        return d2 ? t2 ? (0, c.jsx)("div", {
          className: S().root,
          style: x,
          children: (0, c.jsx)(b.$, {
            ref: k2,
            className: (0, _.$)(S().container, a2),
            onClick: C2,
            onMouseEnter: T2,
            onMouseLeave: O,
            withRipple: false,
            "aria-label": i2({ id: "branded-player.branding-integration" }),
            children: (0, c.jsx)(z, { src: d2, loop: true, dotLottieRefCallback: o2, layout: { align: [0, 1] } }, d2)
          })
        }) : (0, c.jsx)("div", {
          className: S().root,
          style: x,
          children: (0, c.jsx)("div", {
            ref: k2,
            className: (0, _.$)(S().container, a2),
            children: (0, c.jsx)(z, { src: d2, loop: true, dotLottieRefCallback: o2, layout: { align: [0, 1] } }, d2)
          })
        }) : null;
      });
    },
    61915: (e) => {
      e.exports = {
        header: "Equalizer_header__oL2Ii",
        modal: "Equalizer_modal__yW0lz",
        modalHeader: "Equalizer_modalHeader__BaeWi",
        modalContent: "Equalizer_modalContent__xbClm",
        title: "Equalizer_title__oP3e2",
        frequencies: "Equalizer_frequencies__M9bt3",
        label: "Equalizer_label__cAYfh",
        equalizer: "Equalizer_equalizer__M9Utp",
        equalizer_disabled: "Equalizer_equalizer_disabled__NciRX",
        equalizer_enter: "Equalizer_equalizer_enter___0_xp",
        equalizer_enter_active: "Equalizer_equalizer_enter_active__hRAgb",
        "enter-collapse": "Equalizer_enter-collapse__Ypuhz",
        equalizer_exit: "Equalizer_equalizer_exit__wroQI",
        equalizer_exit_active: "Equalizer_equalizer_exit_active__68Faq",
        "exit-collapse": "Equalizer_exit-collapse____a2I",
        preamp: "Equalizer_preamp__hfuqj",
        container: "Equalizer_container__wK7dV",
        labels: "Equalizer_labels__rE8Hc"
      };
    }
  }
]);
