(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3205],
  {
    5594: (e, t, a) => {
      "use strict";
      a.d(t, { WithDownloadMobileAppModal: () => n });
      var s = a(28303), o = a(61910), l = a(74125);
      let n = (0, s.PA)((e2) => {
        let { children: t2 } = e2, { downloadMobileApp: a2 } = (0, l.Pjs)();
        return (0, o.useEffect)(() => {
          a2.shouldShow() && a2.openModal();
        }, [a2]), t2;
      });
    },
    6438: (e) => {
      e.exports = {
        root: "Login_root__VtFg_",
        title: "Login_title__dqQz1",
        important: "Login_important__Z8S9I",
        text: "Login_text__1uju5",
        button: "Login_button__ZYvZY"
      };
    },
    15778: (e, t, a) => {
      "use strict";
      a.d(t, { useRefreshTracksAvailability: () => l });
      var s = a(61910), o = a(74125);
      let l = () => {
        let e2 = (0, o.jRO)(), t2 = (0, s.useCallback)(() => {
          e2.tracksController && e2.tracksController.refreshTracksAvailability().then(() => {
            var e3;
            null == (e3 = window.desktopEvents) || e3.send(o.EE.TRACKS_AVAILABILITY_UPDATED);
          });
        }, [e2.tracksController]);
        (0, s.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(o.EE.REFRESH_TRACKS_AVAILABILITY, t2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(o.EE.REFRESH_TRACKS_AVAILABILITY, t2);
          };
        }, [t2]);
      };
    },
    15855: (e, t, a) => {
      "use strict";
      a.d(t, { useProbabilityBucket: () => l });
      var s = a(61910), o = a(74125);
      let l = () => {
        let e2 = (0, o.NFA)().get(o.vgk), t2 = (0, s.useCallback)(
          (t3, a2) => {
            a2 && e2.count(a2, "probabilityBucket");
          },
          [e2]
        );
        (0, s.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(o.EE.PROBABILITY_BUCKET, t2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(o.EE.PROBABILITY_BUCKET, t2);
          };
        }, [t2]);
      };
    },
    19781: (e, t, a) => {
      "use strict";
      a.d(t, { WithAuth: () => p });
      var s = a(54486), o = a(28303), l = a(97396), n = a(50420), r = a(47713), i = a(97800), d = a(80585), c = a(6438), u = a.n(c);
      let _ = (0, o.PA)(
        () => (0, s.jsxs)("div", {
          className: u().root,
          children: [
            (0, s.jsx)(i.Heading, {
              className: (0, n.$)(u().title, u().important),
              variant: "h3",
              size: "xs",
              children: (0, s.jsx)(r.A, { id: "authorization.enter-title" })
            }),
            (0, s.jsx)(i.Caption, {
              className: (0, n.$)(u().text, u().important),
              variant: "span",
              type: "text",
              size: "l",
              weight: "normal",
              children: (0, s.jsx)(r.A, { id: "authorization.enter-text" })
            }),
            (0, s.jsx)(d.Hi, { size: "l", className: u().button })
          ]
        })
      );
      var h = a(74125);
      let p = (0, o.PA)((e2) => {
        let { children: t2, withRedirectToMainPage: a2 } = e2, { user: o2 } = (0, h.Pjs)();
        return o2.isAuthorized ? t2 : (a2 && (0, l.redirect)(h.Zyd.main.href), (0, s.jsx)(_, {}));
      });
    },
    22329: (e, t, a) => {
      "use strict";
      a.d(t, { WithBetaUser: () => g });
      var s = a(54486), o = a(28303), l = a(50420), n = a(61910), r = a(47713), i = a(31500), d = a(77881), c = a(14342), u = a(39610), _ = a(97800), h = a(68317), p = a(49320), m = a(74125), v = a(80585), x = a(96034), C = a.n(x);
      let A = (0, o.PA)((e2) => {
        let { withoutExperiment: t2 = false, showLoginButton: o2 = false, showUserProfile: x2 = false, withOffer: A2 = false } = e2, g2 = (0, m.NFA)(), {
          settings: { isMobile: E }
        } = (0, m.Pjs)(), w = (0, m.jjz)(), N = g2.get(m.twC), f = (0, m._lF)(N.oldWebHost), k = (0, n.useMemo)(() => E ? a(66130).A.src : a(75806).A.src, [E]), b = (0, n.useCallback)(() => {
          let e3 = "https://".concat(f, "/pay");
          window.open(e3, "_blank", "noreferrer noopener");
        }, [f]);
        (0, m.Jzs)(true);
        let j = (0, n.useMemo)(
          () => A2 ? (0, s.jsx)(_.Heading, {
            variant: "h1",
            size: "xl",
            weight: "bold",
            className: C().text,
            children: (0, s.jsx)(r.A, { id: "welcome-page.offer-header" })
          }) : t2 ? (0, s.jsx)(_.Heading, {
            variant: "h1",
            size: "xxl",
            weight: "bold",
            className: C().text,
            children: (0, s.jsx)(r.A, {
              id: "welcome-page.beta-header",
              values: { br: (0, s.jsx)("br", {}) }
            })
          }) : (0, s.jsx)(_.Heading, {
            variant: "h1",
            size: "xxl",
            weight: "bold",
            className: C().text,
            children: (0, s.jsx)(r.A, {
              id: "welcome-page.not-auth-header",
              values: { br: (0, s.jsx)("br", {}) }
            })
          }),
          [A2, t2]
        ), P = (0, n.useMemo)(
          () => t2 ? (0, s.jsxs)(s.Fragment, {
            children: [
              (0, s.jsx)(_.Caption, {
                variant: "span",
                type: "text",
                size: "l",
                className: C().text,
                children: (0, s.jsx)(r.A, { id: "welcome-page.beta-text-short" })
              }),
              (0, s.jsx)(u.q, {
                children: (0, s.jsx)(_.Heading, {
                  variant: "h2",
                  children: (0, s.jsx)(r.A, { id: "welcome-page.beta-text-short" })
                })
              })
            ]
          }) : A2 ? (0, s.jsxs)(s.Fragment, {
            children: [
              (0, s.jsx)(_.Caption, {
                variant: "span",
                type: "text",
                size: "l",
                className: C().offerText,
                children: (0, s.jsx)(r.A, { id: "welcome-page.offer-text" })
              }),
              (0, s.jsx)(u.q, {
                children: (0, s.jsx)(_.Heading, {
                  variant: "h2",
                  children: (0, s.jsx)(r.A, { id: "welcome-page.offer-text" })
                })
              })
            ]
          }) : (0, s.jsxs)(s.Fragment, {
            children: [
              (0, s.jsx)(_.Caption, {
                variant: "span",
                type: "text",
                size: "l",
                className: C().text,
                children: (0, s.jsx)(r.A, {
                  id: "welcome-page.not-auth-text",
                  values: { br: (0, s.jsx)("br", {}) }
                })
              }),
              (0, s.jsx)(u.q, {
                children: (0, s.jsx)(_.Heading, {
                  variant: "h2",
                  children: (0, s.jsx)(r.A, {
                    id: "welcome-page.not-auth-text",
                    values: { br: (0, s.jsx)("br", {}) }
                  })
                })
              })
            ]
          }),
          [A2, t2]
        ), R = (0, n.useMemo)(
          () => o2 ? (0, s.jsx)(v.Hi, { size: "m", className: C().loginButton }) : A2 ? (0, s.jsx)(d.$, {
            onClick: b,
            className: (0, l.$)(C().offerButton, C().offerButton_important),
            role: "link",
            color: "plus",
            size: "l",
            radius: "m",
            withRipple: false,
            children: (0, s.jsx)(r.A, { id: "payment.offer-button" })
          }) : void 0,
          [b, o2, A2]
        );
        return (0, m.NBO)(true), (0, s.jsxs)("div", {
          className: (0, l.$)(C().root),
          ...(0, i.Am)(i.Xk.welcome.WELCOME_PAGE),
          children: [
            (0, s.jsx)(h.cq, { withSecondaryColor: true }),
            (0, s.jsx)("div", {
              className: C().logoContainer,
              children: (0, s.jsx)(c.gu, { alignIcon: "center", lang: w, className: C().logo })
            }),
            j,
            P,
            R,
            (0, s.jsx)("img", { className: C().image, src: k }),
            x2 && (0, s.jsx)(p.YS, {
              className: C().user,
              withMeta: !E,
              variant: E ? "mobile" : "desktop",
              usernameClassName: (0, l.$)(C().username, C().important)
            })
          ]
        });
      }), g = (0, o.PA)((e2) => {
        let { children: t2 } = e2, { user: a2, experiments: o2 } = (0, m.Pjs)(), { hasFreeUserAccess: l2 } = (0, m.XCI)();
        if (a2.isAuthorized, a2.isAuthorized)
          return o2.checkExperiment(m.zal.WebNext, "on") ? a2.hasPlus || l2 ? t2 : (0, s.jsx)(A, { withOffer: true, showUserProfile: true }) : (0, s.jsx)(A, { withoutExperiment: true, showUserProfile: true });
        return (0, s.jsx)(A, { showLoginButton: true });
      });
    },
    24783: (e, t, a) => {
      "use strict";
      a.d(t, { LO: () => l, N5: () => n, vZ: () => o });
      var s = a(74125);
      let o = () => {
        var e2;
        null == (e2 = window.desktopEvents) || e2.send(s.EE.WINDOW_MINIMIZE);
      }, l = () => {
        var e2;
        null == (e2 = window.desktopEvents) || e2.send(s.EE.WINDOW_MAXIMIZE);
      }, n = () => {
        var e2;
        null == (e2 = window.desktopEvents) || e2.send(s.EE.WINDOW_CLOSE);
      };
    },
    45631: (e) => {
      e.exports = {
        root: "ReleaseNotesModal_root__RSw1p",
        modalOverlay: "ReleaseNotesModal_modalOverlay__GYUgU",
        modalHeader: "ReleaseNotesModal_modalHeader__gp9SA",
        modalContent: "ReleaseNotesModal_modalContent__g8OTu",
        scrollableContent: "ReleaseNotesModal_scrollableContent__zGdbH",
        important: "ReleaseNotesModal_important__u8yP4",
        notes: "ReleaseNotesModal_notes__bVAoa",
        date: "ReleaseNotesModal_date__s3_ux",
        description: "ReleaseNotesModal_description__B_yLI",
        paragraph: "ReleaseNotesModal_paragraph___laDJ",
        note: "ReleaseNotesModal_note__S9E6z",
        version: "ReleaseNotesModal_version__4Mcd5",
        item: "ReleaseNotesModal_item___CYml",
        code: "ReleaseNotesModal_code__Yv3QD"
      };
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    47770: (e, t, a) => {
      "use strict";
      a.d(t, { useApplicationUpdate: () => p });
      var s = a(54486), o = a(61910), l = a(43426), n = a(74125), r = a(50420), i = a(77881), d = a(97800), c = a(80585), u = a(79413), _ = a.n(u);
      let h = (e2) => {
        let { version: t2, formatMessage: a2, closeToast: l2 } = e2, u2 = (0, o.useCallback)(() => {
          var e3;
          null == (e3 = window.desktopEvents) || e3.send(n.EE.INSTALL_UPDATE), null == l2 || l2();
        }, [l2]), h2 = (0, o.useMemo)(
          () => (0, s.jsxs)("div", {
            className: _().message,
            children: [
              (0, s.jsx)(d.Caption, {
                className: _().text,
                variant: "div",
                type: "controls",
                size: "m",
                children: a2({ id: "desktop.on-update-available" }, { version: t2 })
              }),
              (0, s.jsx)(i.$, {
                className: _().button,
                onClick: u2,
                variant: "default",
                color: "secondary",
                size: "xs",
                radius: "xxxl",
                children: (0, s.jsx)(d.Caption, {
                  variant: "div",
                  type: "controls",
                  size: "m",
                  children: a2({ id: "desktop.update" })
                })
              })
            ]
          }),
          [a2, u2, t2]
        );
        return (0, s.jsx)(c.$W, { className: (0, r.$)(_().root, _().important), message: h2 });
      }, p = () => {
        let { formatMessage: e2 } = (0, l.A)(), { notify: t2 } = (0, n.lkh)(), a2 = (0, o.useRef)(""), r2 = (0, o.useCallback)(
          (o2, l2) => {
            a2.current !== l2 && (a2.current = l2, t2((0, s.jsx)(h, { formatMessage: e2, version: l2 }), { containerId: n.uQT.IMPORTANT }));
          },
          [e2, a2, t2]
        );
        (0, o.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(n.EE.UPDATE_AVAILABLE, r2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(n.EE.UPDATE_AVAILABLE, r2);
          };
        }, [r2]);
      };
    },
    49475: (e) => {
      e.exports = {
        root: "TitleBar_root__QjdOZ",
        button: "TitleBar_button__9MptL",
        button_withSecondaryColor: "TitleBar_button_withSecondaryColor__oIkuo",
        icon: "TitleBar_icon__8Wji9",
        icon_withSecondaryColor: "TitleBar_icon_withSecondaryColor__vuw6G",
        closeButton: "TitleBar_closeButton__Epxh7"
      };
    },
    53376: (e, t, a) => {
      "use strict";
      a.d(t, { WithMobilePaywall: () => d });
      var s = a(54486), o = a(28303), l = a(13193), n = a(74125), r = a(70470), i = a.n(r);
      let d = (0, o.PA)((e2) => {
        var t2;
        let { children: a2 } = e2, { user: o2, settings: r2 } = (0, n.Pjs)(), { isFreemium: d2 } = (0, n.XCI)(), { setPaywallRef: c } = (0, n.gKY)();
        return (null == (t2 = r2.browserInfo) ? void 0 : t2.isTouch) && (!o2.isAuthorized || d2) ? (0, s.jsx)("div", {
          ref: c,
          className: i().paywallContainer,
          children: (0, s.jsx)(l.pU, { useOverlayScroll: false })
        }) : a2;
      });
    },
    53466: (e, t, a) => {
      "use strict";
      a.d(t, { useReleaseNotes: () => l });
      var s = a(61910), o = a(74125);
      let l = () => {
        let [e2, t2] = (0, s.useState)(false), {
          releaseNotes: { setTranslationsReleaseNotes: a2, isReady: l2, modal: n, setSortedDescReleaseNotesKeys: r }
        } = (0, o.Pjs)(), i = (0, s.useCallback)(
          (e3, s2) => {
            let { needToShowReleaseNotes: o2, sortedDescReleaseNotesKeys: l3, translationsReleaseNotes: n2 } = s2;
            a2(n2), r(l3), o2 && t2(true);
          },
          [r, a2]
        );
        (0, s.useEffect)(() => {
          e2 && l2 && (n.open(), t2(false));
        }, [l2, n, e2]), (0, s.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(o.EE.LOAD_RELEASE_NOTES, i), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(o.EE.LOAD_RELEASE_NOTES, i);
          };
        }, [i]);
      };
    },
    61337: (e, t, a) => {
      "use strict";
      a.d(t, { useRefreshApplicationData: () => n });
      var s = a(61910), o = a(6024), l = a(74125);
      let n = () => {
        let { library: e2, collection: t2, experiments: a2, main: n2, user: r } = (0, l.Pjs)(), i = (0, s.useCallback)(() => {
          a2.getData(), e2.getData(), n2.landing.isLoaded && n2.landing.getSkeleton(
            { id: o.p.WEB_MAIN, showWizard: r.settings.showWizard },
            { preloadBlocksCount: 2 }
          ), t2.landing.isLoaded && t2.landing.getSkeleton(
            { id: o.p.WEB_COLLECTION, showWizard: r.settings.showWizard },
            { preloadBlocksCount: 2 }
          );
        }, [t2.landing, a2, e2, n2.landing, r.settings.showWizard]);
        (0, s.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(l.EE.REFRESH_APPLICATION_DATA, i), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(l.EE.REFRESH_APPLICATION_DATA, i);
          };
        }, [i]);
      };
    },
    65034: (e, t, a) => {
      "use strict";
      a.d(t, { NotFound: () => m });
      var s = a(54486), o = a(50420), l = a(28303), n = a(47713), r = a(77881), i = a(5956), d = a(97800), c = a(74125), u = a(80585), _ = a(61910), h = a(46215), p = a.n(h);
      let m = (0, l.PA)((e2) => {
        let { className: t2, title: a2, description: l2, iconVariant: h2 = "musicLogo", iconClassName: m2, iconSize: v } = e2, { contentRef: x } = (0, c.gKY)(), C = (0, c.ZpR)(c.Zyd.main.href);
        (0, c.LZB)();
        let { handleNavigateToMain: A } = (0, c.D5F)(C);
        return (0, c.NBO)(true), !(function() {
          let { location: e3 } = (0, c.Pjs)();
          (0, _.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, s.jsxs)("div", {
          className: (0, o.$)(p().root, { [p().root_desktop]: !x }, t2),
          children: [
            (0, s.jsx)(u.Lh, { withBackwardFallback: "/", className: p().navigation, withForwardControl: false }),
            (0, s.jsxs)("div", {
              className: p().content,
              children: [
                (0, s.jsx)(i.Icon, { className: (0, o.$)(p().icon, m2), variant: h2, size: v }),
                (0, s.jsx)(d.Heading, {
                  className: (0, o.$)(p().title, p().important),
                  variant: "h3",
                  size: "xs",
                  children: a2 || (0, s.jsx)(n.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, s.jsx)(d.Caption, {
                  className: (0, o.$)(p().text, p().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: l2 || (0, s.jsx)(n.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, s.jsx)(r.$, {
                  onClick: A,
                  className: p().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, s.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, s.jsx)(n.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    66130: (e, t, a) => {
      "use strict";
      a.d(t, { A: () => s });
      let s = {
        src: "/_next/static/media/mobile.3fa5bdc0.webp",
        height: 1270,
        width: 750,
        blurDataURL: "data:image/webp;base64,UklGRkQAAABXRUJQVlA4IDgAAADQAQCdASoFAAgAAkA4JQBOgCHh3c/IAAD+/eovkSS/bwVeZYW8gP0CqVSvDPwORMoGN02KRYOAAA==",
        blurWidth: 5,
        blurHeight: 8
      };
    },
    66164: (e, t, a) => {
      "use strict";
      a.d(t, { useRefreshRepositoryMeta: () => l });
      var s = a(61910), o = a(74125);
      let l = () => {
        let e2 = (0, o.jRO)(), t2 = (0, s.useCallback)(() => {
          e2.tracksController && e2.tracksController.refreshTracksMeta().then(() => {
            var e3;
            null == (e3 = window.desktopEvents) || e3.send(o.EE.REPOSITORY_META_UPDATED);
          });
        }, [e2.tracksController]);
        (0, s.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(o.EE.REFRESH_REPOSITORY_META, t2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(o.EE.REFRESH_REPOSITORY_META, t2);
          };
        }, [t2]);
      };
    },
    68317: (e, t, a) => {
      "use strict";
      a.d(t, {
        qw: () => E.ReleaseNotesModal,
        _o: () => g,
        cq: () => w.TitleBar,
        CA: () => s,
        M4: () => l,
        _E: () => n,
        LD: () => r.useApplicationDeeplinks,
        P4: () => i.useApplicationUpdate,
        Fn: () => d.useLaunch,
        H: () => c.usePlayerAction,
        t4: () => u.useProbabilityBucket,
        bk: () => _.useRefreshApplicationData,
        eP: () => h.useRefreshRepositoryMeta,
        sb: () => p.useRefreshTracksAvailability,
        sq: () => m.useReleaseNotes,
        OM: () => v.useSendPlayerState
      });
      let s = () => {
        document.addEventListener("auxclick", (e2) => e2.preventDefault()), document.addEventListener("click", (e2) => {
          (e2.ctrlKey || e2.metaKey || e2.shiftKey) && e2.preventDefault();
        });
      };
      var o = a(74125);
      let l = (e2) => {
        var t2;
        null == (t2 = window.desktopEvents) || t2.send(o.EE.APPLICATION_READY, e2);
      }, n = (e2) => {
        let t2 = e2 === o.Sxu.Light ? "#FFFFFF" : "#000000";
        window.desktopEvents.send(o.EE.APPLICATION_THEME, t2);
      };
      a(24783);
      var r = a(99175), i = a(47770), d = a(71117), c = a(89473), u = a(15855), _ = a(61337), h = a(66164), p = a(15778), m = a(53466), v = a(96798), x = a(93064), C = a(26433);
      let A = x.gK.model("TranslationsModel", { data: x.gK.frozen() }), g = x.gK.model("ReleaseNotes", {
        modal: C.qt,
        translations: x.gK.maybeNull(A),
        sortedDescReleaseNotesKeys: x.gK.maybeNull(x.gK.array(x.gK.string))
      }).views((e2) => ({
        get isReady() {
          var t2;
          return !!((null == (t2 = e2.translations) ? void 0 : t2.data) && "object" == typeof e2.translations.data && Object.keys(e2.translations.data).length > 0);
        }
      })).actions((e2) => ({
        setSortedDescReleaseNotesKeys: (t2) => {
          e2.sortedDescReleaseNotesKeys = (0, x.wg)(t2);
        },
        setTranslationsReleaseNotes: (t2) => {
          t2 && (e2.translations = A.create({ data: t2 }));
        }
      }));
      var E = a(81733), w = a(83573);
    },
    70470: (e) => {
      e.exports = {
        paywallContainer: "WithMobilePaywall_paywallContainer__Mk1l_",
        shimmer: "WithMobilePaywall_shimmer__fg4QA"
      };
    },
    71117: (e, t, a) => {
      "use strict";
      a.d(t, { useLaunch: () => l });
      var s = a(61910), o = a(74125);
      let l = () => {
        let e2 = (0, o.NFA)().get(o.vgk), t2 = (0, s.useCallback)(() => {
          let t3 = (0, o.HFS)();
          t3 && e2.count(t3, "installsCount");
        }, [e2]);
        (0, s.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(o.EE.FIRST_LAUNCH, t2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(o.EE.FIRST_LAUNCH, t2);
          };
        }, [t2]);
      };
    },
    73488: (e, t, a) => {
      "use strict";
      a.d(t, { WithBlockChildUser: () => l });
      var s = a(28303), o = a(74125);
      let l = (0, s.PA)(() => {
        let e2 = (0, o.NFA)(), { user: t2 } = (0, o.Pjs)(), a2 = e2.get(o.QGx);
        t2.isChild && a2.redirectToChildPageUrl();
      });
    },
    75806: (e, t, a) => {
      "use strict";
      a.d(t, { A: () => s });
      let s = {
        src: "/_next/static/media/desktop.1e0910e6.webp",
        height: 1800,
        width: 2880,
        blurDataURL: "data:image/webp;base64,UklGRkIAAABXRUJQVlA4IDYAAADQAQCdASoIAAUAAkA4JZQCdAEOaA+wuAD+/SCh9NmVu/p31WSFlBGQJpSkM3AKDGRsZhmAAAA=",
        blurWidth: 8,
        blurHeight: 5
      };
    },
    79413: (e) => {
      e.exports = {
        root: "NotificationUpdate_root__hpSQi",
        important: "NotificationUpdate_important___0WHj",
        text: "NotificationUpdate_text__YylYD",
        button: "NotificationUpdate_button__F3O16",
        message: "NotificationUpdate_message__rLYpW"
      };
    },
    81733: (e, t, a) => {
      "use strict";
      a.d(t, { ReleaseNotesModal: () => v });
      var s = a(54486), o = a(50420), l = a(28303), n = a(43426), r = a(50722), i = a(47713), d = a(32692), c = a(56231), u = a(97800), _ = a(74125), h = a(45631), p = a.n(h);
      let m = {
        ul: (e2) => (0, s.jsx)("ul", { className: p().description, children: e2 }),
        li: (e2) => (0, s.jsx)("li", { className: p().item, children: e2 }),
        code: (e2) => (0, s.jsx)("code", { className: p().code, children: e2 }),
        date: (e2) => (0, s.jsx)("span", { className: p().date, children: e2 }),
        p: (e2) => (0, s.jsx)("p", { className: p().paragraph, children: e2 }),
        br: (0, s.jsx)("br", {})
      }, v = (0, l.PA)(() => {
        let {
          releaseNotes: { translations: e2, sortedDescReleaseNotesKeys: t2, modal: a2 }
        } = (0, _.Pjs)(), { formatMessage: l2 } = (0, n.A)(), { language: h2, defaultLanguage: v2 } = (0, _.h6b)(), x = (0, _.Crf)();
        return (0, s.jsx)(d.a, {
          title: l2({ id: "desktop.release-notes-modal-title" }),
          open: a2.isOpened,
          onOpenChange: a2.onOpenChange,
          onClose: a2.close,
          size: "fitContent",
          placement: "center",
          overlayClassName: p().modalOverlay,
          overlayColor: "full",
          labelClose: l2({ id: "interface-actions.close" }),
          className: p().root,
          headerClassName: p().modalHeader,
          contentClassName: p().modalContent,
          children: (0, s.jsx)(r.A, {
            onError: x,
            defaultLocale: v2,
            locale: h2,
            messages: null == e2 ? void 0 : e2.data,
            children: (0, s.jsx)(c.N, {
              className: (0, o.$)(p().scrollableContent, p().important),
              containerClassName: (0, o.$)(p().notes, p().important),
              children: null == t2 ? void 0 : t2.map(
                (e3) => (0, s.jsxs)(
                  "div",
                  {
                    className: p().note,
                    children: [
                      (0, s.jsx)(u.Heading, {
                        variant: "h4",
                        className: (0, o.$)(p().version, p().important),
                        children: (0, _.Grs)(e3)
                      }),
                      (0, s.jsx)(i.A, { id: e3, values: m })
                    ]
                  },
                  e3
                )
              )
            })
          })
        });
      });
    },
    83573: (e, t, a) => {
      "use strict";
      a.d(t, { TitleBar: () => h });
      var s = a(54486), o = a(50420), l = a(28303), n = a(61910), r = a(43426), i = a(74125), d = a(24783), c = a(49475), u = a.n(c);
      let _ = (e2) => {
        let { children: t2, className: a2, onClick: l2, ariaLabel: n2, withSecondaryColor: r2 } = e2;
        return (0, s.jsx)("button", {
          type: "button",
          className: (0, o.$)(u().button, { [u().button_withSecondaryColor]: r2 }, a2),
          onClick: l2,
          "aria-label": n2,
          children: t2
        });
      }, h = (0, l.PA)((e2) => {
        let { withSecondaryColor: t2 } = e2, { settings: a2 } = (0, i.Pjs)(), l2 = a2.isWindowsApplication || a2.isLinuxApplication, { formatMessage: c2 } = (0, r.A)(), h2 = (0, n.useCallback)(() => {
          (0, d.vZ)();
        }, []), p = (0, n.useCallback)(() => {
          (0, d.LO)();
        }, []), m = (0, n.useCallback)(() => {
          (0, d.N5)();
        }, []);
        return (0, s.jsx)("div", {
          className: u().root,
          onDoubleClick: p,
          children: l2 && (0, s.jsxs)(s.Fragment, {
            children: [
              (0, s.jsx)(_, {
                onClick: h2,
                ariaLabel: c2({ id: "windows-menu.roll-up" }),
                withSecondaryColor: t2,
                children: (0, s.jsx)("svg", {
                  width: "10",
                  height: "1",
                  viewBox: "0 0 10 1",
                  xmlns: "http://www.w3.org/2000/svg",
                  className: (0, o.$)(u().icon, { [u().icon_withSecondaryColor]: t2 }),
                  children: (0, s.jsx)("path", {
                    d: "M0.498047 1C0.429688 1 0.364583 0.986979 0.302734 0.960938C0.244141 0.934896 0.192057 0.899089 0.146484 0.853516C0.100911 0.807943 0.0651042 0.755859 0.0390625 0.697266C0.0130208 0.635417 0 0.570312 0 0.501953C0 0.433594 0.0130208 0.370117 0.0390625 0.311523C0.0651042 0.249674 0.100911 0.195964 0.146484 0.150391C0.192057 0.101562 0.244141 0.0641276 0.302734 0.0380859C0.364583 0.0120443 0.429688 -0.000976562 0.498047 -0.000976562H9.50195C9.57031 -0.000976562 9.63379 0.0120443 9.69238 0.0380859C9.75423 0.0641276 9.80794 0.101562 9.85352 0.150391C9.89909 0.195964 9.9349 0.249674 9.96094 0.311523C9.98698 0.370117 10 0.433594 10 0.501953C10 0.570312 9.98698 0.635417 9.96094 0.697266C9.9349 0.755859 9.89909 0.807943 9.85352 0.853516C9.80794 0.899089 9.75423 0.934896 9.69238 0.960938C9.63379 0.986979 9.57031 1 9.50195 1H0.498047Z",
                    fill: "currentColor"
                  })
                })
              }),
              (0, s.jsx)(_, {
                onClick: p,
                ariaLabel: c2({ id: "windows-menu.unwrap" }),
                withSecondaryColor: t2,
                children: (0, s.jsx)("svg", {
                  width: "10",
                  height: "10",
                  viewBox: "0 0 10 10",
                  xmlns: "http://www.w3.org/2000/svg",
                  className: (0, o.$)(u().icon, { [u().icon_withSecondaryColor]: t2 }),
                  children: (0, s.jsx)("path", {
                    d: "M1.47461 10C1.2793 10 1.09212 9.96094 0.913086 9.88281C0.734049 9.80143 0.576172 9.69401 0.439453 9.56055C0.30599 9.42383 0.198568 9.26595 0.117188 9.08691C0.0390625 8.90788 0 8.7207 0 8.52539V1.47461C0 1.2793 0.0390625 1.09212 0.117188 0.913086C0.198568 0.734049 0.30599 0.577799 0.439453 0.444336C0.576172 0.307617 0.734049 0.200195 0.913086 0.12207C1.09212 0.0406901 1.2793 0 1.47461 0H8.52539C8.7207 0 8.90788 0.0406901 9.08691 0.12207C9.26595 0.200195 9.4222 0.307617 9.55566 0.444336C9.69238 0.577799 9.7998 0.734049 9.87793 0.913086C9.95931 1.09212 10 1.2793 10 1.47461V8.52539C10 8.7207 9.95931 8.90788 9.87793 9.08691C9.7998 9.26595 9.69238 9.42383 9.55566 9.56055C9.4222 9.69401 9.26595 9.80143 9.08691 9.88281C8.90788 9.96094 8.7207 10 8.52539 10H1.47461ZM8.50098 8.99902C8.56934 8.99902 8.63281 8.986 8.69141 8.95996C8.75326 8.93392 8.80697 8.89811 8.85254 8.85254C8.89811 8.80697 8.93392 8.75488 8.95996 8.69629C8.986 8.63444 8.99902 8.56934 8.99902 8.50098V1.49902C8.99902 1.43066 8.986 1.36719 8.95996 1.30859C8.93392 1.24674 8.89811 1.19303 8.85254 1.14746C8.80697 1.10189 8.75326 1.06608 8.69141 1.04004C8.63281 1.014 8.56934 1.00098 8.50098 1.00098H1.49902C1.43066 1.00098 1.36556 1.014 1.30371 1.04004C1.24512 1.06608 1.19303 1.10189 1.14746 1.14746C1.10189 1.19303 1.06608 1.24674 1.04004 1.30859C1.014 1.36719 1.00098 1.43066 1.00098 1.49902V8.50098C1.00098 8.56934 1.014 8.63444 1.04004 8.69629C1.06608 8.75488 1.10189 8.80697 1.14746 8.85254C1.19303 8.89811 1.24512 8.93392 1.30371 8.95996C1.36556 8.986 1.43066 8.99902 1.49902 8.99902H8.50098Z",
                    fill: "currentColor"
                  })
                })
              }),
              (0, s.jsx)(_, {
                className: u().closeButton,
                onClick: m,
                ariaLabel: c2({ id: "windows-menu.close" }),
                children: (0, s.jsx)("svg", {
                  width: "10",
                  height: "10",
                  viewBox: "0 0 10 10",
                  xmlns: "http://www.w3.org/2000/svg",
                  className: (0, o.$)(u().icon, { [u().icon_withSecondaryColor]: t2 }),
                  children: (0, s.jsx)("path", {
                    d: "M5 5.70801L0.854492 9.85352C0.756836 9.95117 0.639648 10 0.50293 10C0.359701 10 0.239258 9.9528 0.141602 9.8584C0.0472005 9.76074 0 9.6403 0 9.49707C0 9.36035 0.0488281 9.24316 0.146484 9.14551L4.29199 5L0.146484 0.854492C0.0488281 0.756836 0 0.638021 0 0.498047C0 0.429688 0.0130208 0.364583 0.0390625 0.302734C0.0651042 0.240885 0.100911 0.188802 0.146484 0.146484C0.192057 0.100911 0.245768 0.0651042 0.307617 0.0390625C0.369466 0.0130208 0.43457 0 0.50293 0C0.639648 0 0.756836 0.0488281 0.854492 0.146484L5 4.29199L9.14551 0.146484C9.24316 0.0488281 9.36198 0 9.50195 0C9.57031 0 9.63379 0.0130208 9.69238 0.0390625C9.75423 0.0651042 9.80794 0.100911 9.85352 0.146484C9.89909 0.192057 9.9349 0.245768 9.96094 0.307617C9.98698 0.366211 10 0.429688 10 0.498047C10 0.638021 9.95117 0.756836 9.85352 0.854492L5.70801 5L9.85352 9.14551C9.95117 9.24316 10 9.36035 10 9.49707C10 9.56543 9.98698 9.63053 9.96094 9.69238C9.9349 9.75423 9.89909 9.80794 9.85352 9.85352C9.8112 9.89909 9.75911 9.9349 9.69727 9.96094C9.63542 9.98698 9.57031 10 9.50195 10C9.36198 10 9.24316 9.95117 9.14551 9.85352L5 5.70801Z",
                    fill: "currentColor"
                  })
                })
              })
            ]
          })
        });
      });
    },
    88495: (e, t, a) => {
      "use strict";
      a.d(t, { WithBlockFullscreen: () => m });
      var s = a(54486), o = a(28303), l = a(97396), n = a(61910), r = a(43426), i = a(77881), d = a(97800), c = a(68317), u = a(74125), _ = a(98744), h = a.n(_);
      let p = (0, o.PA)((e2) => {
        var t2, a2, o2, _2;
        let { isAuthorizedUser: p2 = false } = e2, { formatMessage: m2 } = (0, r.A)(), v = (0, l.useRouter)(), {
          experiments: x,
          settings: { isMobile: C }
        } = (0, u.Pjs)(), A = (0, u.NFA)().get(u.QGx), g = x.getExperiment(u.zal.WebNextBlockFullscreen), E = null == g || null == (t2 = g.value) ? void 0 : t2.metadata, w = (0, n.useCallback)(() => {
          A.authorizationUrl && v.push(A.authorizationUrl);
        }, [A.authorizationUrl, v]), N = (0, n.useCallback)(() => {
          var e3;
          let t3 = new URLSearchParams({
            origin: "music_button-header",
            retpath: encodeURIComponent(
              "https://music.yandex.ru/settings?reqid=527383194170610471317084142111361467&from-passport"
            )
          }), a3 = (null == E || null == (e3 = E.redirectButton) ? void 0 : e3.link) || A.getAuthorizationUrlWithParams(t3);
          a3 && window.open(a3, "_self", "noreferrer noopener");
        }, [A, null == E || null == (a2 = E.redirectButton) ? void 0 : a2.link]), f = (null == E || null == (o2 = E.redirectButton) ? void 0 : o2.text) || m2({ id: "snegir.redirect-button-text" }), k = (null == E || null == (_2 = E.authButton) ? void 0 : _2.text) || m2({ id: "snegir.auth-button-text" }), b = (0, n.useMemo)(
          () => p2 ? (0, s.jsx)(i.$, {
            onClick: N,
            className: h().button,
            role: "link",
            color: "primary",
            size: "l",
            radius: "xxxl",
            children: f
          }) : (0, s.jsx)(i.$, {
            onClick: w,
            className: h().button,
            role: "link",
            color: "primary",
            size: "l",
            radius: "xxxl",
            children: k
          }),
          [p2, w, k, N, f]
        ), j = (null == E ? void 0 : E.mainText) || m2({ id: "snegir.main-text" }, { br: "\r\n" });
        return (0, s.jsxs)("div", {
          className: h().root,
          children: [
            (0, s.jsx)(c.cq, { withSecondaryColor: true }),
            (0, s.jsxs)("div", {
              className: h().container,
              children: [
                (0, s.jsxs)("div", {
                  className: h().content,
                  children: [
                    (0, s.jsx)(d.Heading, {
                      variant: "h1",
                      size: C ? "xl" : "xxl",
                      weight: "bold",
                      className: h().title,
                      children: j
                    }),
                    b
                  ]
                }),
                (0, s.jsx)("div", { className: h().image })
              ]
            })
          ]
        });
      }), m = (0, o.PA)((e2) => {
        let { children: t2 } = e2, { experiments: a2, user: o2 } = (0, u.Pjs)(), l2 = a2.checkExperiment(u.zal.WebNextBlockFullscreen, "on") || !o2.isServiceAvailable;
        return ((0, u.QVD)(l2), l2) ? o2.isAuthorized ? (0, s.jsx)(p, { isAuthorizedUser: true }) : (0, s.jsx)(p, {}) : t2;
      });
    },
    89473: (e, t, a) => {
      "use strict";
      a.d(t, { usePlayerAction: () => n });
      var s = a(61910), o = a(74125), l = (function(e2) {
        return e2.PLAY = "PLAY", e2.PAUSE = "PAUSE", e2.MOVE_BACKWARD = "MOVE_BACKWARD", e2.MOVE_FORWARD = "MOVE_FORWARD", e2;
      })(l || {});
      let n = (e2) => {
        let t2 = (0, s.useCallback)(
          (t3, a2) => {
            switch (a2) {
              case "PLAY":
              case "PAUSE":
                null == e2 || e2.togglePause();
                break;
              case "MOVE_BACKWARD":
                null == e2 || e2.moveBackward();
                break;
              case "MOVE_FORWARD":
                null == e2 || e2.moveForward();
            }
          },
          [e2]
        );
        (0, s.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(o.EE.PLAYER_ACTION, t2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(o.EE.PLAYER_ACTION, t2);
          };
        }, [t2]);
      };
    },
    96034: (e) => {
      e.exports = {
        root: "WelcomePage_root__JK3Pb",
        image: "WelcomePage_image__7_fpW",
        loginButton: "WelcomePage_loginButton__AJHcG",
        secondBackground: "WelcomePage_secondBackground__55zFI",
        offerButton: "WelcomePage_offerButton__MRs_g",
        offerButton_important: "WelcomePage_offerButton_important__0wf60",
        text: "WelcomePage_text__A4aXp",
        offerText: "WelcomePage_offerText__ZvXKN",
        logoContainer: "WelcomePage_logoContainer__72W3y",
        logo: "WelcomePage_logo__oMU8g",
        user: "WelcomePage_user__WNc4W",
        username: "WelcomePage_username__yXGsn",
        important: "WelcomePage_important__MJxEk"
      };
    },
    96798: (e, t, a) => {
      "use strict";
      a.d(t, { useSendPlayerState: () => r });
      var s = a(61910), o = a(8817), l = a(89461), n = a(74125);
      let r = (e2) => {
        let { sonata: t2 } = e2, a2 = (0, o.c)((e3) => {
          var t3;
          let { isPlaying: a3, canMoveBackward: s2, canMoveForward: o2 } = e3;
          null == (t3 = window.desktopEvents) || t3.send(n.EE.PLAYER_STATE, { isPlaying: a3, canMoveBackward: s2, canMoveForward: o2 });
        });
        (0, s.useEffect)(() => {
          let e3, s2, o2 = null == t2 ? void 0 : t2.state.playerState.status.onChange((e4) => {
            e4 && a2({ isPlaying: e4 === l.MT.PLAYING });
          }), n2 = null == t2 ? void 0 : t2.state.currentContext.onChange(() => {
            var o3, l2;
            null == e3 || e3(), null == s2 || s2(), e3 = null == t2 || null == (o3 = t2.state.currentContext.value) ? void 0 : o3.availableActions.moveBackward.onChange((e4) => {
              a2({ canMoveBackward: !!e4 });
            }), s2 = null == t2 || null == (l2 = t2.state.currentContext.value) ? void 0 : l2.availableActions.moveForward.onChange((e4) => {
              a2({ canMoveForward: !!e4 });
            });
          });
          return () => {
            null == o2 || o2(), null == n2 || n2(), null == s2 || s2(), null == s2 || s2();
          };
        }, [a2, null == t2 ? void 0 : t2.state.currentContext, null == t2 ? void 0 : t2.state.playerState.status]);
      };
    },
    98744: (e) => {
      e.exports = {
        root: "BlockPage_root__crGK_",
        container: "BlockPage_container__my_l0",
        content: "BlockPage_content__4nK4D",
        title: "BlockPage_title__sAejV",
        button: "BlockPage_button__KoFZX",
        image: "BlockPage_image__C02Db"
      };
    },
    99175: (e, t, a) => {
      "use strict";
      a.d(t, { useApplicationDeeplinks: () => i });
      var s = a(97396), o = a(61910), l = a(8817), n = a(74125);
      let r = [
        [
          /^\/home\/([^/?]+)(\?.*)?$/,
          (e2) => {
            let t2 = e2.match(/^\/home\/([^/?]+)(\?.*)?$/);
            if (!t2) return e2;
            let a2 = t2[1], s2 = t2[2] || "";
            if (!a2) return e2;
            let o2 = new URLSearchParams(s2.startsWith("?") ? s2.substring(1) : "");
            return o2.set("tab", a2), "/?".concat(o2.toString());
          }
        ],
        [/^\/home$/, () => n.Zyd.main.href],
        [/^\/users\/(.*)\/playlists$/, () => n.Zyd.collection.href],
        [/^\/users\/(.*)\/artists$/, () => n.Zyd.collection.href],
        [/^\/users\/(.*)\/albums$/, () => n.Zyd.collection.href],
        [/^\/users\/(.*)\/tracks$/, () => n.Zyd.collection.href],
        [/^\/users\/(.*)\/podcasts$/, () => n.Zyd.collection.href],
        [/^\/users\/(.*)\/kids$/, () => n.Zyd.collection.href],
        [/^\/users\/(.*)\/history$/, () => n.Zyd.musicHistory.href],
        [
          /^\/play-vibe/,
          (e2) => {
            let t2 = new URLSearchParams(e2.split("?")[1]);
            t2.set(n.K3F.DEEPLINK, n.vEM.PLAY_VIBE);
            let a2 = new URLSearchParams(window.location.search), s2 = (0, n.$cg)(a2, t2);
            return "landing" === t2.get(n.K3F.SCREEN) ? "/?".concat(s2.toString()) : "".concat(window.location.pathname, "?").concat(s2.toString());
          }
        ]
      ], i = () => {
        let e2 = (0, s.useRouter)(), t2 = (0, l.c)((t3, a2) => {
          for (let [t4, s3] of r) if (t4.test(a2)) return void e2.push(s3(a2));
          let { href: s2 } = (0, n.uvd)(null != a2 ? a2 : n.Zyd.main.href);
          e2.push(s2);
        });
        (0, o.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(n.EE.OPEN_DEEPLINK, t2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(n.EE.OPEN_DEEPLINK, t2);
          };
        }, [t2]);
      };
    }
  }
]);
