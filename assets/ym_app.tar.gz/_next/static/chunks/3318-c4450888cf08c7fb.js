(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3318],
  {
    2405: (e, t, s) => {
      "use strict";
      s.d(t, { SortDropdown: () => g });
      var i = s(54486), n = s(28303), o = s(61910), r = s(47713), l = s(31500), a = s(11405), d = s(8817), m = s(77881), b = s(71656), h = s(5956), c = s(97800), v = s(74125), u = s(90229), P = s(46353), p = s.n(P);
      let _ = {
        [a.g.RATING]: (0, i.jsx)(r.A, { id: "sort.sort-by-rating" }),
        [a.g.YEAR]: (0, i.jsx)(r.A, { id: "sort.sort-by-year" })
      }, g = (0, n.PA)((e2) => {
        var t2;
        let { sortModel: s2, onSort: n2 } = e2, {
          settings: { isMobile: P2 }
        } = (0, v.Pjs)(), g2 = (0, d.c)((e3) => {
          (0, u.W)(e3.id) && s2.sortBy !== e3.id && (s2.setSortBy(e3.id), n2());
        }), x = (0, o.useMemo)(
          () => P2 ? (0, i.jsx)(m.$, {
            radius: "xxxl",
            className: p().button,
            icon: (0, i.jsx)(h.Icon, { variant: "filter", size: "xs" })
          }) : (0, i.jsxs)(m.$, {
            radius: "xxxl",
            className: p().button,
            ...(0, l.Am)(l.Kq.sort.SORT_DROPDOWN_BUTTON),
            children: [
              (0, i.jsx)(c.Caption, {
                variant: "span",
                size: "m",
                weight: "medium",
                ...(0, l.Am)(l.Kq.sort.SORT_DROPDOWN_BUTTON_CAPTION),
                children: s2.sortBy ? _[s2.sortBy] : (0, i.jsx)(r.A, { id: "sort.select-filter" })
              }),
              (0, i.jsx)(h.Icon, {
                size: "xxs",
                variant: "arrowDown",
                ...(0, l.Am)(l.Kq.sort.SORT_DROPDOWN_BUTTON_ICON)
              })
            ]
          }),
          [P2, s2.sortBy]
        );
        return (0, i.jsx)(b.ms, {
          placement: P2 ? "bottom" : "top",
          isMobile: P2,
          strategy: "fixed",
          className: p().root,
          onSelect: g2,
          reference: x,
          offsetOptions: { mainAxis: 10, crossAxis: -50 },
          defaultValue: null != (t2 = s2.sortBy) ? t2 : a.g.YEAR,
          containerClassName: p().container,
          header: P2 ? (0, i.jsx)("div", { className: p().header }) : void 0,
          ...(0, l.Am)(l.Kq.sort.SORT_DROPDOWN),
          children: Object.values(a.g).map(
            (e3) => (0, i.jsx)(b.c$, { id: e3, label: _[e3], ...(0, l.Am)(l.Kq.sort.SORT_DROPDOWN_ITEM) }, e3)
          )
        });
      });
    },
    4499: (e, t, s) => {
      "use strict";
      s.d(t, { M: () => n });
      var i = s(74125);
      async function n(e2, t2) {
        var s2, n2, o;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let r = await (0, i.WGy)(t2.locale), l = r({ id: "metadata.label-artists-title" }, { labelName: e2.name, labelType: e2.type }), a = r({ id: "metadata.label-artists-description" }, { labelName: e2.name, labelType: e2.type });
        return {
          title: l,
          description: a,
          openGraph: (0, i.i$E)({
            ogTitle: l,
            ogDescription: a,
            fullUrl: null != (s2 = t2.fullUrl) ? s2 : "",
            locale: t2.locale,
            siteName: r({ id: "metadata.yandex-music" }),
            ogType: "music.playlist"
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: l,
            url: t2.url,
            appName: r({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (n2 = t2.url) ? n2 : "",
              fullUrl: null != (o = t2.fullUrl) ? o : "",
              host: t2.host
            },
            appName: r({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/label/:labelId/artists", t2.tld, { params: { labelId: e2.id } })
        };
      }
    },
    6094: (e, t, s) => {
      "use strict";
      s.d(t, { LabelAlbumsPage: () => N });
      var i = s(54486), n = s(50420), o = s(28303), r = s(97396), l = s(61910), a = s(43426), d = s(31500), m = s(8817), b = s(97800), h = s(82644), c = s(94376), v = s(33276), u = s(40502), P = s(74125), p = s(80585), _ = s(18569), g = s(52456), x = s.n(g);
      let N = (0, o.PA)((e2) => {
        let { labelId: t2, preloadedLabel: s2, preloadedAlbums: o2, sortBy: g2 } = e2, {
          label: {
            id: N2,
            type: y,
            name: j,
            albumsSubpage: A,
            reset: f,
            isNeededToLoad: L,
            getData: S,
            isPublisher: w
          },
          settings: { isMobile: k },
          experiments: T
        } = (0, P.Pjs)(), { formatMessage: C } = (0, a.A)(), { contentScrollRef: B, setContentScrollRef: E } = (0, P.gKY)(), R = (0, P.W6M)(), W = w ? C({ id: "page.label-podcast-header" }, { labelName: j }) : C({ id: "page.label-albums-header" }, { labelName: j }), O = (0, m.c)((e3) => {
          var s3;
          A.getData({ labelId: Number(t2), page: e3, pageSize: 20, sortBy: null != (s3 = A.sort.sortBy) ? s3 : g2 });
        }), I = (0, m.c)(() => {
          A.reset(), O(0);
        });
        (0, u.y8)({ sortModel: A.sort }), (0, P.XcE)(A.pagesLoader, O), (0, l.useEffect)(
          () => () => {
            f(), A.reset();
          },
          [f, A]
        ), (A.isNotFound || !T.checkExperiment(P.zal.WebNextLabelPage, "on")) && (0, r.notFound)(), (0, _.Q)({ id: Number(N2), name: null != j ? j : "", type: null != y ? y : "" }, _.T.ALBUMS), (0, P.Jzs)(A.isResolved);
        let F = (0, l.useMemo)(
          () => ({ Footer: () => (0, i.jsx)(p.A, { children: (0, i.jsx)(p.wi, { className: x().footer }) }) }),
          []
        ), z = C({ id: "entity-names.label-albums-list" }), D = [];
        if (A.isNeededToLoad) {
          var U;
          let e3 = A.sort.sortBy === g2 || void 0 === A.sort.sortBy;
          D.push(
            A.getData({
              labelId: Number(t2),
              page: 0,
              pageSize: 20,
              preloadedAlbums: e3 ? o2 : void 0,
              sortBy: null != (U = A.sort.sortBy) ? U : g2
            })
          );
        }
        if (L && D.push(S({ labelId: Number(t2), preloadedLabel: s2, withLabelEntities: false })), D.length && (0, l.use)(Promise.allSettled(D)), A.isRejected && !A.isNotFound)
          return (0, i.jsx)(h.w, {});
        let $ = A.isShimmerVisible ? 20 : A.items.length;
        return (0, i.jsx)(P.nVz, {
          pageId: P._Q$.LABEL_ALBUMS,
          children: (0, i.jsx)(v.hO, {
            scrollElement: B,
            outerTitle: W,
            children: (0, i.jsxs)("div", {
              className: x().root,
              ...(0, d.Am)(d.Xk.label.LABEL_ALBUMS_PAGE),
              children: [
                (0, i.jsxs)(p.Y9, {
                  variant: p.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: R.canBack,
                  children: [
                    (0, i.jsx)(b.Heading, { variant: "h1", weight: "bold", size: "xl", lineClamp: 1, children: W }),
                    (0, i.jsx)(u.mi, { sortModel: A.sort, onSort: I })
                  ]
                }),
                (0, i.jsx)(p.$$, {
                  className: (0, n.$)(x().scrollContainer, x().important),
                  listClassName: x().content,
                  itemClassName: x().item,
                  customComponents: F,
                  itemContentCallback: (e3) => {
                    let t3 = A.items[e3], s3 = C(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: C({ id: "entity-names.album" }) }
                    );
                    return t3 ? (0, i.jsx)(
                      c.aX,
                      { album: t3, contentLinesCount: 4, withAddition: !t3.isNonMusic, withLikesCount: t3.isNonMusic },
                      t3.id
                    ) : (0, i.jsx)(p.Vt, { "aria-label": s3, linesCount: 4 });
                  },
                  totalCount: $,
                  onGetDataByPage: O,
                  pageSize: 20,
                  totalRequests: A.requestsCount,
                  handleRef: E,
                  context: { listAriaLabel: z },
                  isMobileLayout: k,
                  useWindowScroll: k
                })
              ]
            })
          })
        });
      });
    },
    18569: (e, t, s) => {
      "use strict";
      s.d(t, { Q: () => d, T: () => a });
      var i = s(61910), n = s(74125), o = s(94687), r = s(4499), l = s(84227), a = (function(e2) {
        return e2.ROOT = "root", e2.ALBUMS = "albums", e2.ARTISTS = "artists", e2;
      })({});
      let d = (e2, t2) => {
        (0, i.useEffect)(() => {
          switch (t2) {
            case "root":
              (0, l.I)(e2, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e3) => {
                (0, n.jxB)(e3);
              });
              break;
            case "albums":
              (0, o._)(e2, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e3) => {
                (0, n.jxB)(e3);
              });
              break;
            case "artists":
              (0, r.M)(e2, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e3) => {
                (0, n.jxB)(e3);
              });
          }
        }, [null == e2 ? void 0 : e2.id, null == e2 ? void 0 : e2.type, null == e2 ? void 0 : e2.name, t2, e2]);
      };
    },
    23318: (e, t, s) => {
      Promise.resolve().then(s.bind(s, 58360)), Promise.resolve().then(s.bind(s, 14342)), Promise.resolve().then(s.bind(s, 62662)), Promise.resolve().then(s.bind(s, 6971)), Promise.resolve().then(s.bind(s, 22674)), Promise.resolve().then(s.bind(s, 51321)), Promise.resolve().then(s.bind(s, 97800)), Promise.resolve().then(s.bind(s, 42520)), Promise.resolve().then(s.bind(s, 30662)), Promise.resolve().then(s.bind(s, 31757)), Promise.resolve().then(s.bind(s, 51672)), Promise.resolve().then(s.bind(s, 63449)), Promise.resolve().then(s.bind(s, 65134)), Promise.resolve().then(s.bind(s, 96819)), Promise.resolve().then(s.bind(s, 38868)), Promise.resolve().then(s.bind(s, 77163)), Promise.resolve().then(s.bind(s, 96025)), Promise.resolve().then(s.bind(s, 51887)), Promise.resolve().then(s.bind(s, 25577)), Promise.resolve().then(s.bind(s, 65327)), Promise.resolve().then(s.bind(s, 3119)), Promise.resolve().then(s.bind(s, 74808)), Promise.resolve().then(s.bind(s, 92088)), Promise.resolve().then(s.bind(s, 83154)), Promise.resolve().then(s.bind(s, 14476)), Promise.resolve().then(s.bind(s, 88332)), Promise.resolve().then(s.bind(s, 16855)), Promise.resolve().then(s.bind(s, 28795)), Promise.resolve().then(s.bind(s, 69536)), Promise.resolve().then(s.bind(s, 11472)), Promise.resolve().then(s.bind(s, 2438)), Promise.resolve().then(s.bind(s, 46540)), Promise.resolve().then(s.bind(s, 40188)), Promise.resolve().then(s.bind(s, 2405)), Promise.resolve().then(s.bind(s, 6094)), Promise.resolve().then(s.bind(s, 73910)), Promise.resolve().then(s.bind(s, 33265)), Promise.resolve().then(s.bind(s, 77120)), Promise.resolve().then(s.bind(s, 8394)), Promise.resolve().then(s.bind(s, 3192)), Promise.resolve().then(s.bind(s, 7286)), Promise.resolve().then(s.bind(s, 60305)), Promise.resolve().then(s.bind(s, 47203)), Promise.resolve().then(s.bind(s, 34286)), Promise.resolve().then(s.bind(s, 224)), Promise.resolve().then(s.bind(s, 24449)), Promise.resolve().then(s.bind(s, 79893)), Promise.resolve().then(s.bind(s, 81789)), Promise.resolve().then(s.bind(s, 87466)), Promise.resolve().then(s.bind(s, 39034)), Promise.resolve().then(s.bind(s, 17917)), Promise.resolve().then(s.bind(s, 11337)), Promise.resolve().then(s.bind(s, 19683)), Promise.resolve().then(s.bind(s, 53779)), Promise.resolve().then(s.bind(s, 12359)), Promise.resolve().then(s.bind(s, 88564)), Promise.resolve().then(s.bind(s, 95639)), Promise.resolve().then(s.bind(s, 57630)), Promise.resolve().then(s.bind(s, 25342)), Promise.resolve().then(s.bind(s, 34028)), Promise.resolve().then(s.bind(s, 99564)), Promise.resolve().then(s.bind(s, 95348)), Promise.resolve().then(s.bind(s, 52347)), Promise.resolve().then(s.bind(s, 61015)), Promise.resolve().then(s.bind(s, 1771)), Promise.resolve().then(s.bind(s, 80043)), Promise.resolve().then(s.bind(s, 12235)), Promise.resolve().then(s.bind(s, 8941)), Promise.resolve().then(s.bind(s, 38433)), Promise.resolve().then(s.bind(s, 8732)), Promise.resolve().then(s.bind(s, 43369)), Promise.resolve().then(s.bind(s, 47564)), Promise.resolve().then(s.bind(s, 41017)), Promise.resolve().then(s.bind(s, 27252)), Promise.resolve().then(s.bind(s, 65286)), Promise.resolve().then(s.bind(s, 45198)), Promise.resolve().then(s.bind(s, 46814)), Promise.resolve().then(s.bind(s, 92508)), Promise.resolve().then(s.bind(s, 40126)), Promise.resolve().then(s.bind(s, 83726)), Promise.resolve().then(s.bind(s, 90410)), Promise.resolve().then(s.bind(s, 13246)), Promise.resolve().then(s.bind(s, 26040)), Promise.resolve().then(s.bind(s, 92446)), Promise.resolve().then(s.bind(s, 42593)), Promise.resolve().then(s.bind(s, 70570)), Promise.resolve().then(s.bind(s, 88416)), Promise.resolve().then(s.bind(s, 24174)), Promise.resolve().then(s.bind(s, 78458)), Promise.resolve().then(s.bind(s, 59457)), Promise.resolve().then(s.bind(s, 6690)), Promise.resolve().then(s.bind(s, 88370)), Promise.resolve().then(s.bind(s, 66904)), Promise.resolve().then(s.bind(s, 39937)), Promise.resolve().then(s.bind(s, 33019)), Promise.resolve().then(s.bind(s, 38808)), Promise.resolve().then(s.bind(s, 58094)), Promise.resolve().then(s.bind(s, 78009)), Promise.resolve().then(s.bind(s, 33427)), Promise.resolve().then(s.bind(s, 30878)), Promise.resolve().then(s.bind(s, 53115)), Promise.resolve().then(s.bind(s, 52398)), Promise.resolve().then(s.bind(s, 82327)), Promise.resolve().then(s.bind(s, 17012)), Promise.resolve().then(s.bind(s, 9275)), Promise.resolve().then(s.bind(s, 17658)), Promise.resolve().then(s.bind(s, 36578)), Promise.resolve().then(s.bind(s, 66989)), Promise.resolve().then(s.bind(s, 58863)), Promise.resolve().then(s.bind(s, 60899)), Promise.resolve().then(s.bind(s, 59437)), Promise.resolve().then(s.bind(s, 43367)), Promise.resolve().then(s.bind(s, 66446)), Promise.resolve().then(s.bind(s, 86840)), Promise.resolve().then(s.bind(s, 75181)), Promise.resolve().then(s.bind(s, 99538)), Promise.resolve().then(s.bind(s, 45252)), Promise.resolve().then(s.bind(s, 59226)), Promise.resolve().then(s.bind(s, 75961)), Promise.resolve().then(s.bind(s, 33964)), Promise.resolve().then(s.bind(s, 33967)), Promise.resolve().then(s.bind(s, 64410)), Promise.resolve().then(s.bind(s, 91350)), Promise.resolve().then(s.bind(s, 4500)), Promise.resolve().then(s.bind(s, 55846)), Promise.resolve().then(s.bind(s, 65689)), Promise.resolve().then(s.bind(s, 99386)), Promise.resolve().then(s.bind(s, 5222)), Promise.resolve().then(s.bind(s, 60440)), Promise.resolve().then(s.bind(s, 37271)), Promise.resolve().then(s.bind(s, 66688)), Promise.resolve().then(s.bind(s, 76472)), Promise.resolve().then(s.bind(s, 41682)), Promise.resolve().then(s.bind(s, 77666)), Promise.resolve().then(s.bind(s, 8765)), Promise.resolve().then(s.bind(s, 48670)), Promise.resolve().then(s.bind(s, 22096)), Promise.resolve().then(s.bind(s, 33655)), Promise.resolve().then(s.bind(s, 27754)), Promise.resolve().then(s.bind(s, 47347)), Promise.resolve().then(s.bind(s, 45591)), Promise.resolve().then(s.bind(s, 52862)), Promise.resolve().then(s.bind(s, 79326)), Promise.resolve().then(s.bind(s, 73922)), Promise.resolve().then(s.bind(s, 10790)), Promise.resolve().then(s.bind(s, 78684)), Promise.resolve().then(s.bind(s, 76877)), Promise.resolve().then(s.bind(s, 61176)), Promise.resolve().then(s.bind(s, 62108)), Promise.resolve().then(s.bind(s, 75053)), Promise.resolve().then(s.bind(s, 23035)), Promise.resolve().then(s.bind(s, 82315)), Promise.resolve().then(s.bind(s, 60673)), Promise.resolve().then(s.bind(s, 5048)), Promise.resolve().then(s.bind(s, 50215)), Promise.resolve().then(s.bind(s, 78308)), Promise.resolve().then(s.bind(s, 10084)), Promise.resolve().then(s.bind(s, 58681)), Promise.resolve().then(s.bind(s, 18658)), Promise.resolve().then(s.bind(s, 6323)), Promise.resolve().then(s.bind(s, 78817)), Promise.resolve().then(s.bind(s, 7230)), Promise.resolve().then(s.bind(s, 38378)), Promise.resolve().then(s.bind(s, 35609)), Promise.resolve().then(s.bind(s, 18606)), Promise.resolve().then(s.bind(s, 68014)), Promise.resolve().then(s.bind(s, 12126)), Promise.resolve().then(s.bind(s, 52742)), Promise.resolve().then(s.bind(s, 68098)), Promise.resolve().then(s.bind(s, 89190)), Promise.resolve().then(s.bind(s, 3270)), Promise.resolve().then(s.bind(s, 1220)), Promise.resolve().then(s.bind(s, 96584)), Promise.resolve().then(s.bind(s, 54598)), Promise.resolve().then(s.bind(s, 14196)), Promise.resolve().then(s.bind(s, 20576)), Promise.resolve().then(s.bind(s, 29070)), Promise.resolve().then(s.bind(s, 35203)), Promise.resolve().then(s.bind(s, 39450)), Promise.resolve().then(s.bind(s, 77607)), Promise.resolve().then(s.bind(s, 7430)), Promise.resolve().then(s.bind(s, 24786)), Promise.resolve().then(s.bind(s, 24036)), Promise.resolve().then(s.bind(s, 34932)), Promise.resolve().then(s.bind(s, 56204)), Promise.resolve().then(s.bind(s, 75450)), Promise.resolve().then(s.bind(s, 60608)), Promise.resolve().then(s.bind(s, 33648)), Promise.resolve().then(s.bind(s, 43548)), Promise.resolve().then(s.bind(s, 69672)), Promise.resolve().then(s.bind(s, 50711)), Promise.resolve().then(s.bind(s, 5185)), Promise.resolve().then(s.bind(s, 90555)), Promise.resolve().then(s.bind(s, 5602)), Promise.resolve().then(s.bind(s, 12390)), Promise.resolve().then(s.bind(s, 58376)), Promise.resolve().then(s.bind(s, 24491)), Promise.resolve().then(s.bind(s, 61993)), Promise.resolve().then(s.bind(s, 38644)), Promise.resolve().then(s.bind(s, 93668)), Promise.resolve().then(s.bind(s, 85949)), Promise.resolve().then(s.bind(s, 17519)), Promise.resolve().then(s.bind(s, 62010)), Promise.resolve().then(s.bind(s, 16372)), Promise.resolve().then(s.bind(s, 64434)), Promise.resolve().then(s.bind(s, 33158)), Promise.resolve().then(s.bind(s, 27314)), Promise.resolve().then(s.bind(s, 93206)), Promise.resolve().then(s.bind(s, 37226)), Promise.resolve().then(s.bind(s, 13811)), Promise.resolve().then(s.bind(s, 45645)), Promise.resolve().then(s.bind(s, 24126)), Promise.resolve().then(s.bind(s, 20406)), Promise.resolve().then(s.bind(s, 21940)), Promise.resolve().then(s.bind(s, 26086)), Promise.resolve().then(s.bind(s, 96838)), Promise.resolve().then(s.bind(s, 10358)), Promise.resolve().then(s.bind(s, 23143)), Promise.resolve().then(s.bind(s, 51828)), Promise.resolve().then(s.bind(s, 51725)), Promise.resolve().then(s.bind(s, 23834)), Promise.resolve().then(s.bind(s, 88343)), Promise.resolve().then(s.bind(s, 24624));
    },
    33265: (e, t, s) => {
      "use strict";
      s.d(t, { LabelNotFoundPage: () => o });
      var i = s(54486), n = s(42421);
      let o = () => (0, i.jsx)(n.M, {});
    },
    39656: (e) => {
      e.exports = {
        root: "LabelArtistsPage_root__smTJJ",
        scrollContainer: "LabelArtistsPage_scrollContainer__alDjs",
        important: "LabelArtistsPage_important__pOZpi",
        footer: "LabelArtistsPage_footer__JU2P3",
        item: "LabelArtistsPage_item__kol2m",
        content: "LabelArtistsPage_content__4hjcX"
      };
    },
    40188: (e, t, s) => {
      "use strict";
      s.d(t, { useSort: () => l });
      var i = s(61910), n = s(11405), o = s(74125), r = s(90229);
      let l = (e2) => {
        let { sortModel: t2 } = e2, s2 = (0, o.XJ9)();
        (0, i.useLayoutEffect)(() => {
          let e3 = new URL(window.location.href).searchParams.get(o.K3F.SORT);
          e3 && (0, r.W)(e3) ? t2.setSortBy(e3) : t2.setSortBy(n.g.YEAR);
        }, [t2]), (0, i.useEffect)(() => {
          if (t2.sortBy) {
            let e3 = (0, o.bJ)(o.K3F.SORT, t2.sortBy);
            e3 && s2(e3);
          }
        }, [s2, t2.sortBy]);
      };
    },
    40502: (e, t, s) => {
      "use strict";
      s.d(t, { mi: () => m.SortDropdown, wY: () => d, WG: () => i.W, hl: () => o, y8: () => r.useSort });
      var i = s(90229), n = s(61288);
      let o = (e2) => !!e2 && (e2 === n.x.ASC || e2 === n.x.DESC);
      var r = s(40188), l = s(93064), a = s(11405);
      let d = l.gK.model("Sort", {
        sortBy: l.gK.maybe(l.gK.enumeration(Object.values(a.g))),
        sortOrder: l.gK.maybe(l.gK.enumeration(Object.values(n.x)))
      }).actions((e2) => ({
        setSortBy(t2) {
          e2.sortBy = t2;
        },
        setSortOrder(t2) {
          e2.sortOrder = t2;
        }
      }));
      var m = s(2405);
    },
    40846: (e) => {
      e.exports = {
        root: "LabelPage_root__jquyP",
        content: "LabelPage_content__9st_X",
        header: "LabelPage_header__G2xY_",
        title: "LabelPage_title__BNxeX",
        button: "LabelPage_button__JXw3C",
        carouselBlock: "LabelPage_carouselBlock__zPJmW",
        carouselBlockHeader: "LabelPage_carouselBlockHeader__dvYqJ",
        carouselContainer: "LabelPage_carouselContainer__bRVMp",
        footer: "LabelPage_footer__lvKmF"
      };
    },
    42421: (e, t, s) => {
      "use strict";
      s.d(t, { M: () => i.NotFound });
      var i = s(65034);
    },
    42520: (e, t, s) => {
      "use strict";
      let i;
      s.d(t, { useMetrika: () => r });
      var n = s(61910), o = s(80506);
      let r = () => {
        let e2 = (i || (i = (0, o.a)()), i), t2 = (0, n.useSyncExternalStore)(e2.isLoaded.onChange, () => e2.isLoaded.value);
        return (0, n.useMemo)(() => ({ ...e2, isLoaded: t2 }), [t2]);
      };
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    46353: (e) => {
      e.exports = {
        root: "SortDropdown_root__d1JmQ",
        button: "SortDropdown_button__SjTI7",
        header: "SortDropdown_header__kj8yV",
        container: "SortDropdown_container__dyVF_"
      };
    },
    52456: (e) => {
      e.exports = {
        root: "LabelAlbumsPage_root__xyWi4",
        scrollContainer: "LabelAlbumsPage_scrollContainer__zRUlM",
        important: "LabelAlbumsPage_important__s18oL",
        footer: "LabelAlbumsPage_footer__dcXFk",
        item: "LabelAlbumsPage_item__Qjz9F",
        content: "LabelAlbumsPage_content__jOWKZ"
      };
    },
    61288: (e, t, s) => {
      "use strict";
      var i;
      s.d(t, { x: () => i }), (function(e2) {
        e2.ASC = "asc", e2.DESC = "desc";
      })(i || (i = {}));
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65034: (e, t, s) => {
      "use strict";
      s.d(t, { NotFound: () => u });
      var i = s(54486), n = s(50420), o = s(28303), r = s(47713), l = s(77881), a = s(5956), d = s(97800), m = s(74125), b = s(80585), h = s(61910), c = s(46215), v = s.n(c);
      let u = (0, o.PA)((e2) => {
        let { className: t2, title: s2, description: o2, iconVariant: c2 = "musicLogo", iconClassName: u2, iconSize: P } = e2, { contentRef: p } = (0, m.gKY)(), _ = (0, m.ZpR)(m.Zyd.main.href);
        (0, m.LZB)();
        let { handleNavigateToMain: g } = (0, m.D5F)(_);
        return (0, m.NBO)(true), !(function() {
          let { location: e3 } = (0, m.Pjs)();
          (0, h.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, i.jsxs)("div", {
          className: (0, n.$)(v().root, { [v().root_desktop]: !p }, t2),
          children: [
            (0, i.jsx)(b.Lh, { withBackwardFallback: "/", className: v().navigation, withForwardControl: false }),
            (0, i.jsxs)("div", {
              className: v().content,
              children: [
                (0, i.jsx)(a.Icon, { className: (0, n.$)(v().icon, u2), variant: c2, size: P }),
                (0, i.jsx)(d.Heading, {
                  className: (0, n.$)(v().title, v().important),
                  variant: "h3",
                  size: "xs",
                  children: s2 || (0, i.jsx)(r.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, i.jsx)(d.Caption, {
                  className: (0, n.$)(v().text, v().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: o2 || (0, i.jsx)(r.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, i.jsx)(l.$, {
                  onClick: g,
                  className: v().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, i.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, i.jsx)(r.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    73910: (e, t, s) => {
      "use strict";
      s.d(t, { LabelArtistsPage: () => x });
      var i = s(54486), n = s(50420), o = s(28303), r = s(97396), l = s(61910), a = s(43426), d = s(31500), m = s(8817), b = s(97800), h = s(82644), c = s(55616), v = s(33276), u = s(74125), P = s(80585), p = s(18569), _ = s(39656), g = s.n(_);
      let x = (0, o.PA)((e2) => {
        let { labelId: t2, preloadedLabel: s2, preloadedArtists: o2 } = e2, {
          label: { id: _2, name: x2, type: N, artistsSubpage: y, reset: j, isNeededToLoad: A, getData: f },
          settings: { isMobile: L },
          experiments: S
        } = (0, u.Pjs)(), { formatMessage: w } = (0, a.A)(), { contentScrollRef: k, setContentScrollRef: T } = (0, u.gKY)(), C = (0, u.W6M)(), B = w({ id: "page.label-artists-header" }, { labelName: x2 }), E = (0, m.c)((e3) => {
          y.getData({ labelId: Number(t2), page: e3, pageSize: 20 });
        });
        (0, u.XcE)(y.pagesLoader, E), (0, l.useEffect)(
          () => () => {
            j(), y.reset();
          },
          [j, y]
        ), (y.isNotFound || !S.checkExperiment(u.zal.WebNextLabelPage, "on")) && (0, r.notFound)(), (0, p.Q)({ id: Number(_2), name: null != x2 ? x2 : "", type: null != N ? N : "" }, p.T.ARTISTS), (0, u.Jzs)(y.isResolved);
        let R = (0, l.useMemo)(
          () => ({ Footer: () => (0, i.jsx)(P.A, { children: (0, i.jsx)(P.wi, { className: g().footer }) }) }),
          []
        ), W = w({ id: "entity-names.label-artists-list" }), O = [];
        if (y.isNeededToLoad && O.push(y.getData({ labelId: Number(t2), page: 0, pageSize: 20, preloadedArtists: o2 })), A && O.push(f({ labelId: Number(t2), preloadedLabel: s2, withLabelEntities: false })), O.length && (0, l.use)(Promise.allSettled(O)), y.isRejected && !y.isNotFound)
          return (0, i.jsx)(h.w, {});
        let I = y.isShimmerVisible ? 20 : y.items.length;
        return (0, i.jsx)(u.nVz, {
          pageId: u._Q$.LABEL_ARTISTS,
          children: (0, i.jsx)(v.hO, {
            scrollElement: k,
            outerTitle: B,
            children: (0, i.jsxs)("div", {
              className: g().root,
              ...(0, d.Am)(d.Xk.label.LABEL_ARTISTS_PAGE),
              children: [
                (0, i.jsx)(P.Y9, {
                  variant: P.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: C.canBack,
                  className: g().header,
                  children: (0, i.jsx)(b.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: B
                  })
                }),
                (0, i.jsx)(P.$$, {
                  className: (0, n.$)(g().scrollContainer, g().important),
                  listClassName: g().content,
                  itemClassName: g().item,
                  customComponents: R,
                  itemContentCallback: (e3) => {
                    let t3 = y.items[e3], s3 = w(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: w({ id: "entity-names.artist" }) }
                    );
                    return t3 ? (0, i.jsx)(c.ao, { artist: t3, contentLinesCount: 4 }, t3.id) : (0, i.jsx)(P.Vt, { "aria-label": s3, round: true, centered: true, linesCount: 4 });
                  },
                  totalCount: I,
                  onGetDataByPage: E,
                  pageSize: 20,
                  totalRequests: y.requestsCount,
                  handleRef: T,
                  context: { listAriaLabel: W },
                  isMobileLayout: L,
                  useWindowScroll: L
                })
              ]
            })
          })
        });
      });
    },
    75312: (e, t, s) => {
      "use strict";
      s.d(t, { SomethingWentWrong: () => P });
      var i = s(54486), n = s(50420), o = s(28303), r = s(61910), l = s(43426), a = s(47713), d = s(77881), m = s(5956), b = s(97800), h = s(74125), c = s(80585), v = s(63708), u = s.n(v);
      let P = (0, o.PA)((e2) => {
        let { className: t2, withBackwardControl: s2 = true } = e2, { formatMessage: o2 } = (0, l.A)(), v2 = o2({ id: "error-messages.something-went-wrong" });
        (0, h.CgZ)(v2);
        let { sendRefreshEvent: P2 } = (0, h.cYT)(), p = (0, r.useCallback)(() => {
          P2(), window.location.href = h.Zyd.main.href;
        }, [P2]), { contentRef: _ } = (0, h.gKY)();
        return (0, i.jsxs)("div", {
          className: (0, n.$)(u().root, t2),
          children: [
            s2 && (0, i.jsx)(c.Lh, {
              withBackwardFallback: "/",
              className: (0, n.$)(u().navigation, { [u().navigation_desktop]: !_ }),
              withForwardControl: false
            }),
            (0, i.jsxs)("div", {
              className: (0, n.$)(u().content, { [u().content_shrink]: !s2 }),
              children: [
                (0, i.jsx)(m.Icon, { className: u().icon, variant: "attention", size: "xxl" }),
                (0, i.jsx)(b.Heading, {
                  className: (0, n.$)(u().title, u().important),
                  variant: "h3",
                  size: "xs",
                  children: v2
                }),
                (0, i.jsxs)(b.Caption, {
                  className: (0, n.$)(u().text, u().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, i.jsx)(a.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, i.jsx)(d.$, {
                  onClick: p,
                  className: u().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, i.jsxs)(b.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, i.jsx)(a.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    77120: (e, t, s) => {
      "use strict";
      s.d(t, { LabelPage: () => L });
      var i = s(54486), n = s(50420), o = s(28303), r = s(97396), l = s(61910), a = s(43426), d = s(47713), m = s(31500), b = s(8817), h = s(77881), c = s(5956), v = s(56231), u = s(97800), P = s(32353), p = s(82644), _ = s(94376), g = s(55616), x = s(33276), N = s(74125), y = s(80585), j = s(18569), A = s(40846), f = s.n(A);
      let L = (0, o.PA)((e2) => {
        var t2, s2, o2, A2;
        let { labelId: L2, preloadedLabel: S } = e2, {
          label: w,
          settings: { isMobile: k },
          experiments: T
        } = (0, N.Pjs)(), { formatMessage: C } = (0, a.A)(), { contentScrollRef: B, setContentScrollRef: E } = (0, N.gKY)(), { notify: R } = (0, N.lkh)(), { shareLink: W } = (0, N.bNS)("/label/:labelId", { params: { labelId: null != (s2 = w.id) ? s2 : "" } }), O = (0, l.useRef)(null), I = (0, l.useRef)(0);
        (0, j.Q)(
          { id: Number(w.id), name: null != (o2 = w.name) ? o2 : "", type: null != (A2 = w.type) ? A2 : "" },
          j.T.ROOT
        );
        let F = (0, b.c)(async () => {
          await window.navigator.clipboard.writeText(W), R((0, i.jsx)(y.Do, { entityVariant: N.Yxq.LABEL, entityTitle: w.name || "" }), {
            containerId: N.uQT.INFO
          });
        }), z = (0, l.useMemo)(
          () => k ? (0, i.jsx)(h.$, {
            className: f().button,
            onClick: F,
            icon: (0, i.jsx)(c.Icon, { variant: "share", size: "xxs" }),
            size: "l",
            radius: "xxxl",
            ...(0, m.Am)(m.Xk.label.SHARE_COPY_LINK_BUTTON)
          }) : (0, i.jsx)(h.$, {
            className: f().button,
            onClick: F,
            icon: (0, i.jsx)(c.Icon, { variant: "share", size: "xxs" }),
            size: "l",
            radius: "xxxl",
            ...(0, m.Am)(m.Xk.label.SHARE_COPY_LINK_BUTTON),
            children: (0, i.jsx)(d.A, { id: "interface-actions.share" })
          }),
          [k, F]
        ), D = w.isPublisher ? C({ id: "entity-names.publisher" }) : C({ id: "entity-names.label" }), U = w.isPublisher ? C({ id: "entity-names.non-music-releases" }) : C({ id: "entity-names.releases" });
        return ((0, l.useEffect)(
          () => () => {
            w.reset();
          },
          [w]
        ), (w.isNotFound || !T.checkExperiment(N.zal.WebNextLabelPage, "on")) && (0, r.notFound)(), (0, l.useEffect)(
          () => () => {
            I.current = 0;
          },
          [w]
        ), (0, l.useEffect)(() => {
          w.isRejected && I && !(I.current > 0) && (R((0, i.jsx)(y.hT, { error: C({ id: "error-messages.error-load-part-page" }) }), {
            containerId: N.uQT.ERROR
          }), I.current++);
        }, [w.isRejected, R, C]), (0, N.Jzs)(w.isResolved), w.isNeededToLoad && (0, l.use)(w.getData({ labelId: Number(L2), preloadedLabel: S })), w.isRejected && !w.isNotFound) ? (0, i.jsx)(p.w, {}) : (0, i.jsx)(N.nVz, {
          pageId: N._Q$.LABEL,
          children: (0, i.jsxs)(x.hO, {
            scrollElement: B,
            children: [
              (0, i.jsx)(y.Y9, { innerHeaderRef: O }),
              (0, i.jsxs)(v.N, {
                className: f().root,
                containerClassName: f().content,
                ref: E,
                ...(0, m.Am)(m.Xk.label.LABEL_PAGE),
                children: [
                  (0, i.jsxs)("div", {
                    className: f().header,
                    children: [
                      (0, i.jsx)(u.Caption, {
                        variant: "div",
                        type: "text",
                        size: "m",
                        weight: "medium",
                        children: D
                      }),
                      (0, i.jsx)(P.RR, { className: f().title, title: w.name || "", headingVariant: "h1" }),
                      z
                    ]
                  }),
                  w.hasAlbums && w.albums && (0, i.jsx)(_.pZ, {
                    isShimmerVisible: w.isLoading,
                    isShimmerActive: true,
                    className: f().carouselContainer,
                    headerClassName: (0, n.$)(f().carouselBlock, f().carouselBlockHeader),
                    containerClassName: f().carouselBlock,
                    title: U,
                    viewAllActionLink: w.albumsUrl,
                    albums: w.albums,
                    headingVariant: "h2",
                    ...(0, m.Am)(m.Xk.label.RELEASES_CAROUSEL)
                  }),
                  w.hasArtists && (0, i.jsx)(y.OY, {
                    isShimmerVisible: w.isLoading,
                    isShimmerActive: true,
                    headerClassName: (0, n.$)(f().carouselBlockHeader, f().carouselBlock),
                    containerClassName: f().carouselBlock,
                    viewAllActionLink: w.artistsUrl,
                    title: C({ id: "entity-names.artists" }),
                    headingVariant: "h2",
                    ...(0, m.Am)(m.Xk.label.ARTISTS_CAROUSEL),
                    children: null == (t2 = w.artists) ? void 0 : t2.map((e3) => (0, i.jsx)(g.ao, { artist: e3, contentLinesCount: 3 }, e3.id))
                  }),
                  (0, i.jsx)(y.A, { children: (0, i.jsx)(y.wi, { className: f().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    80506: (e, t, s) => {
      "use strict";
      s.d(t, { a: () => n });
      var i = s(87965);
      let n = () => {
        let e2 = null, t2 = new i.cJ(false), s2 = [];
        return {
          isLoaded: t2,
          init: (i2) => {
            var n2, o;
            if (void 0 !== (null == (n2 = window.Ya) ? void 0 : n2.Metrika2) && !t2.value)
              try {
                e2 = new window.Ya.Metrika2({ ...i2 }), t2.value = true, o = e2, s2.forEach((e3) => {
                  e3(o);
                }), s2.length = 0;
              } catch (e3) {
                ("string" == typeof e3 || e3 instanceof Error) && i2.logger.error(e3);
              }
          },
          count: function(t3) {
            let i2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "counter";
            e2 ? e2.params({ [i2]: t3 }) : s2.push((e3) => {
              e3.params({ [i2]: t3 });
            });
          },
          hit: (t3) => {
            e2 ? e2.hit(t3) : s2.push((e3) => {
              e3.hit(t3);
            });
          },
          reachGoal: (t3, i2) => {
            if (!e2) return void s2.push((e3) => e3.reachGoal(t3, i2));
            e2.reachGoal(t3, i2);
          }
        };
      };
    },
    82644: (e, t, s) => {
      "use strict";
      s.d(t, { w: () => i.SomethingWentWrong });
      var i = s(75312);
    },
    84227: (e, t, s) => {
      "use strict";
      s.d(t, { I: () => n });
      var i = s(74125);
      async function n(e2, t2) {
        var s2, n2, o;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let r = await (0, i.WGy)(t2.locale), l = r({ id: "metadata.label-title" }, { labelTitle: e2.name, labelType: e2.type }), a = r({ id: "metadata.label-description" }, { labelTitle: e2.name, labelType: e2.type });
        return {
          title: l,
          description: a,
          openGraph: (0, i.i$E)({
            ogTitle: l,
            ogDescription: a,
            fullUrl: null != (s2 = t2.fullUrl) ? s2 : "",
            locale: t2.locale,
            siteName: r({ id: "metadata.yandex-music" }),
            ogType: "music.playlist"
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: l,
            url: t2.url,
            appName: r({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (n2 = t2.url) ? n2 : "",
              fullUrl: null != (o = t2.fullUrl) ? o : "",
              host: t2.host
            },
            appName: r({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/label/:labelId", t2.tld, { params: { labelId: e2.id } })
        };
      }
    },
    90229: (e, t, s) => {
      "use strict";
      s.d(t, { W: () => n });
      var i = s(11405);
      let n = (e2) => !!e2 && (e2 === i.g.RATING || e2 === i.g.YEAR);
    },
    94687: (e, t, s) => {
      "use strict";
      s.d(t, { _: () => n });
      var i = s(74125);
      async function n(e2, t2) {
        var s2, n2, o;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let r = await (0, i.WGy)(t2.locale), l = r({ id: "metadata.label-albums-title" }, { labelName: e2.name, labelType: e2.type }), a = r({ id: "metadata.label-albums-description" }, { labelName: e2.name, labelType: e2.type });
        return {
          title: l,
          description: a,
          openGraph: (0, i.i$E)({
            ogTitle: l,
            ogDescription: a,
            fullUrl: null != (s2 = t2.fullUrl) ? s2 : "",
            locale: t2.locale,
            siteName: r({ id: "metadata.yandex-music" }),
            ogType: "music.playlist"
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: l,
            url: t2.url,
            appName: r({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (n2 = t2.url) ? n2 : "",
              fullUrl: null != (o = t2.fullUrl) ? o : "",
              host: t2.host
            },
            appName: r({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/label/:labelId/albums", t2.tld, { params: { labelId: e2.id } })
        };
      }
    }
  }
]);
