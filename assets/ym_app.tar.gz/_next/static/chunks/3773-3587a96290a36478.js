"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3773],
  {
    8981: (e, t, i) => {
      i.d(t, {
        a: () => w,
        b: () => m,
        c: () => h,
        d: () => l,
        e: () => p,
        f: () => S,
        h: () => b,
        j: () => n,
        k: () => y,
        m: () => T,
        n: () => a,
        o: () => v,
        p: () => g,
        q: () => f,
        r: () => c,
        s: () => d,
        t: () => u,
        u: () => function e2() {
          let t2 = Object(arguments.length <= 0 ? void 0 : arguments[0]), i2 = ["__proto__", "constructor", "prototype"];
          for (let s2 = 1; s2 < arguments.length; s2 += 1) {
            let r2 = s2 < 0 || arguments.length <= s2 ? void 0 : arguments[s2];
            if (null != r2 && ("undefined" != typeof window && void 0 !== window.HTMLElement ? !(r2 instanceof HTMLElement) : !r2 || 1 !== r2.nodeType && 11 !== r2.nodeType)) {
              let s3 = Object.keys(Object(r2)).filter((e3) => 0 > i2.indexOf(e3));
              for (let i3 = 0, a2 = s3.length; i3 < a2; i3 += 1) {
                let a3 = s3[i3], l2 = Object.getOwnPropertyDescriptor(r2, a3);
                void 0 !== l2 && l2.enumerable && (o(t2[a3]) && o(r2[a3]) ? r2[a3].__swiper__ ? t2[a3] = r2[a3] : e2(t2[a3], r2[a3]) : !o(t2[a3]) && o(r2[a3]) ? (t2[a3] = {}, r2[a3].__swiper__ ? t2[a3] = r2[a3] : e2(t2[a3], r2[a3])) : t2[a3] = r2[a3]);
              }
            }
          }
          return t2;
        },
        v: () => r
      });
      var s = i(27854);
      function r(e2) {
        Object.keys(e2).forEach((t2) => {
          try {
            e2[t2] = null;
          } catch (e3) {
          }
          try {
            delete e2[t2];
          } catch (e3) {
          }
        });
      }
      function a(e2, t2) {
        return void 0 === t2 && (t2 = 0), setTimeout(e2, t2);
      }
      function l() {
        return Date.now();
      }
      function n(e2, t2) {
        let i2, r2, a2;
        void 0 === t2 && (t2 = "x");
        let l2 = (0, s.a)(), n2 = (function(e3) {
          let t3, i3 = (0, s.a)();
          return i3.getComputedStyle && (t3 = i3.getComputedStyle(e3, null)), !t3 && e3.currentStyle && (t3 = e3.currentStyle), t3 || (t3 = e3.style), t3;
        })(e2);
        return l2.WebKitCSSMatrix ? ((r2 = n2.transform || n2.webkitTransform).split(",").length > 6 && (r2 = r2.split(", ").map((e3) => e3.replace(",", ".")).join(", ")), a2 = new l2.WebKitCSSMatrix("none" === r2 ? "" : r2)) : i2 = (a2 = n2.MozTransform || n2.OTransform || n2.MsTransform || n2.msTransform || n2.transform || n2.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,")).toString().split(","), "x" === t2 && (r2 = l2.WebKitCSSMatrix ? a2.m41 : 16 === i2.length ? parseFloat(i2[12]) : parseFloat(i2[4])), "y" === t2 && (r2 = l2.WebKitCSSMatrix ? a2.m42 : 16 === i2.length ? parseFloat(i2[13]) : parseFloat(i2[5])), r2 || 0;
      }
      function o(e2) {
        return "object" == typeof e2 && null !== e2 && e2.constructor && "Object" === Object.prototype.toString.call(e2).slice(8, -1);
      }
      function d(e2, t2, i2) {
        e2.style.setProperty(t2, i2);
      }
      function c(e2) {
        let t2, { swiper: i2, targetPosition: r2, side: a2 } = e2, l2 = (0, s.a)(), n2 = -i2.translate, o2 = null, d2 = i2.params.speed;
        i2.wrapperEl.style.scrollSnapType = "none", l2.cancelAnimationFrame(i2.cssModeFrameID);
        let c2 = r2 > n2 ? "next" : "prev", p2 = (e3, t3) => "next" === c2 && e3 >= t3 || "prev" === c2 && e3 <= t3, u2 = () => {
          t2 = (/* @__PURE__ */ new Date()).getTime(), null === o2 && (o2 = t2);
          let e3 = n2 + (0.5 - Math.cos(Math.max(Math.min((t2 - o2) / d2, 1), 0) * Math.PI) / 2) * (r2 - n2);
          if (p2(e3, r2) && (e3 = r2), i2.wrapperEl.scrollTo({ [a2]: e3 }), p2(e3, r2)) {
            i2.wrapperEl.style.overflow = "hidden", i2.wrapperEl.style.scrollSnapType = "", setTimeout(() => {
              i2.wrapperEl.style.overflow = "", i2.wrapperEl.scrollTo({ [a2]: e3 });
            }), l2.cancelAnimationFrame(i2.cssModeFrameID);
            return;
          }
          i2.cssModeFrameID = l2.requestAnimationFrame(u2);
        };
        u2();
      }
      function p(e2, t2) {
        return void 0 === t2 && (t2 = ""), [...e2.children].filter((e3) => e3.matches(t2));
      }
      function u(e2) {
        try {
          console.warn(e2);
          return;
        } catch (e3) {
        }
      }
      function h(e2, t2) {
        var i2;
        void 0 === t2 && (t2 = []);
        let s2 = document.createElement(e2);
        return s2.classList.add(
          ...Array.isArray(t2) ? t2 : (void 0 === (i2 = t2) && (i2 = ""), i2.trim().split(" ").filter((e3) => !!e3.trim()))
        ), s2;
      }
      function m(e2) {
        let t2 = (0, s.a)(), i2 = (0, s.g)(), r2 = e2.getBoundingClientRect(), a2 = i2.body, l2 = e2.clientTop || a2.clientTop || 0, n2 = e2.clientLeft || a2.clientLeft || 0, o2 = e2 === t2 ? t2.scrollY : e2.scrollTop, d2 = e2 === t2 ? t2.scrollX : e2.scrollLeft;
        return { top: r2.top + o2 - l2, left: r2.left + d2 - n2 };
      }
      function f(e2, t2) {
        let i2 = [];
        for (; e2.previousElementSibling; ) {
          let s2 = e2.previousElementSibling;
          t2 ? s2.matches(t2) && i2.push(s2) : i2.push(s2), e2 = s2;
        }
        return i2;
      }
      function g(e2, t2) {
        let i2 = [];
        for (; e2.nextElementSibling; ) {
          let s2 = e2.nextElementSibling;
          t2 ? s2.matches(t2) && i2.push(s2) : i2.push(s2), e2 = s2;
        }
        return i2;
      }
      function v(e2, t2) {
        return (0, s.a)().getComputedStyle(e2, null).getPropertyValue(t2);
      }
      function b(e2) {
        let t2, i2 = e2;
        if (i2) {
          for (t2 = 0; null !== (i2 = i2.previousSibling); ) 1 === i2.nodeType && (t2 += 1);
          return t2;
        }
      }
      function w(e2, t2) {
        let i2 = [], s2 = e2.parentElement;
        for (; s2; ) t2 ? s2.matches(t2) && i2.push(s2) : i2.push(s2), s2 = s2.parentElement;
        return i2;
      }
      function y(e2, t2) {
        t2 && e2.addEventListener("transitionend", function i2(s2) {
          s2.target === e2 && (t2.call(e2, s2), e2.removeEventListener("transitionend", i2));
        });
      }
      function S(e2, t2, i2) {
        let r2 = (0, s.a)();
        return i2 ? e2["width" === t2 ? "offsetWidth" : "offsetHeight"] + parseFloat(r2.getComputedStyle(e2, null).getPropertyValue("width" === t2 ? "margin-right" : "margin-top")) + parseFloat(r2.getComputedStyle(e2, null).getPropertyValue("width" === t2 ? "margin-left" : "margin-bottom")) : e2.offsetWidth;
      }
      function T(e2) {
        return (Array.isArray(e2) ? e2 : [e2]).filter((e3) => !!e3);
      }
    },
    27854: (e, t, i) => {
      function s(e2) {
        return null !== e2 && "object" == typeof e2 && "constructor" in e2 && e2.constructor === Object;
      }
      function r(e2, t2) {
        void 0 === e2 && (e2 = {}), void 0 === t2 && (t2 = {}), Object.keys(t2).forEach((i2) => {
          void 0 === e2[i2] ? e2[i2] = t2[i2] : s(t2[i2]) && s(e2[i2]) && Object.keys(t2[i2]).length > 0 && r(e2[i2], t2[i2]);
        });
      }
      i.d(t, { a: () => o, g: () => l });
      let a = {
        body: {},
        addEventListener() {
        },
        removeEventListener() {
        },
        activeElement: { blur() {
        }, nodeName: "" },
        querySelector: () => null,
        querySelectorAll: () => [],
        getElementById: () => null,
        createEvent: () => ({ initEvent() {
        } }),
        createElement: () => ({
          children: [],
          childNodes: [],
          style: {},
          setAttribute() {
          },
          getElementsByTagName: () => []
        }),
        createElementNS: () => ({}),
        importNode: () => null,
        location: { hash: "", host: "", hostname: "", href: "", origin: "", pathname: "", protocol: "", search: "" }
      };
      function l() {
        let e2 = "undefined" != typeof document ? document : {};
        return r(e2, a), e2;
      }
      let n = {
        document: a,
        navigator: { userAgent: "" },
        location: { hash: "", host: "", hostname: "", href: "", origin: "", pathname: "", protocol: "", search: "" },
        history: { replaceState() {
        }, pushState() {
        }, go() {
        }, back() {
        } },
        CustomEvent: function() {
          return this;
        },
        addEventListener() {
        },
        removeEventListener() {
        },
        getComputedStyle: () => ({ getPropertyValue: () => "" }),
        Image() {
        },
        Date() {
        },
        screen: {},
        setTimeout() {
        },
        clearTimeout() {
        },
        matchMedia: () => ({}),
        requestAnimationFrame: (e2) => "undefined" == typeof setTimeout ? (e2(), null) : setTimeout(e2, 0),
        cancelAnimationFrame(e2) {
          "undefined" != typeof setTimeout && clearTimeout(e2);
        }
      };
      function o() {
        let e2 = "undefined" != typeof window ? window : {};
        return r(e2, n), e2;
      }
    },
    31622: (e, t, i) => {
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return o;
        }
      });
      let s = i(54486), r = i(61910), a = i(91165);
      function l(e2) {
        return { default: e2 && "default" in e2 ? e2.default : e2 };
      }
      i(98944);
      let n = { loader: () => Promise.resolve(l(() => null)), loading: null, ssr: true }, o = function(e2) {
        let t2 = { ...n, ...e2 }, i2 = (0, r.lazy)(() => t2.loader().then(l)), o2 = t2.loading;
        function d(e3) {
          let l2 = o2 ? (0, s.jsx)(o2, { isLoading: true, pastDelay: true, error: null }) : null, n2 = !t2.ssr || !!t2.loading, d2 = n2 ? r.Suspense : r.Fragment, c = t2.ssr ? (0, s.jsxs)(s.Fragment, { children: [null, (0, s.jsx)(i2, { ...e3 })] }) : (0, s.jsx)(a.BailoutToCSR, { reason: "next/dynamic", children: (0, s.jsx)(i2, { ...e3 }) });
          return (0, s.jsx)(d2, { ...n2 ? { fallback: l2 } : {}, children: c });
        }
        return d.displayName = "LoadableComponent", d;
      };
    },
    36446: (e, t, i) => {
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return r;
        }
      });
      let s = i(45221)._(i(31622));
      function r(e2, t2) {
        var i2;
        let r2 = {};
        "function" == typeof e2 && (r2.loader = e2);
        let a = { ...r2, ...t2 };
        return (0, s.default)({ ...a, modules: null == (i2 = a.loadableGenerated) ? void 0 : i2.modules });
      }
      ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", { value: true }), Object.assign(t.default, t), e.exports = t.default);
    },
    36553: (e, t, i) => {
      let s, r, a;
      i.d(t, { RC: () => H, qr: () => q, Mn: () => R, JO: () => V });
      var l = i(61910), n = i(27854), o = i(8981);
      function d() {
        return s || (s = (function() {
          let e2 = (0, n.a)(), t2 = (0, n.g)();
          return {
            smoothScroll: t2.documentElement && t2.documentElement.style && "scrollBehavior" in t2.documentElement.style,
            touch: !!("ontouchstart" in e2 || e2.DocumentTouch && t2 instanceof e2.DocumentTouch)
          };
        })()), s;
      }
      function c(e2) {
        return void 0 === e2 && (e2 = {}), r || (r = (function(e3) {
          let { userAgent: t2 } = void 0 === e3 ? {} : e3, i2 = d(), s2 = (0, n.a)(), r2 = s2.navigator.platform, a2 = t2 || s2.navigator.userAgent, l2 = { ios: false, android: false }, o2 = s2.screen.width, c2 = s2.screen.height, p2 = a2.match(/(Android);?[\s\/]+([\d.]+)?/), u2 = a2.match(/(iPad).*OS\s([\d_]+)/), h2 = a2.match(/(iPod)(.*OS\s([\d_]+))?/), m2 = !u2 && a2.match(/(iPhone\sOS|iOS)\s([\d_]+)/), f2 = "MacIntel" === r2;
          return !u2 && f2 && i2.touch && [
            "1024x1366",
            "1366x1024",
            "834x1194",
            "1194x834",
            "834x1112",
            "1112x834",
            "768x1024",
            "1024x768",
            "820x1180",
            "1180x820",
            "810x1080",
            "1080x810"
          ].indexOf(`${o2}x${c2}`) >= 0 && ((u2 = a2.match(/(Version)\/([\d.]+)/)) || (u2 = [0, 1, "13_0_0"]), f2 = false), p2 && "Win32" !== r2 && (l2.os = "android", l2.android = true), (u2 || m2 || h2) && (l2.os = "ios", l2.ios = true), l2;
        })(e2)), r;
      }
      let p = (e2, t2) => {
        if (!e2 || e2.destroyed || !e2.params) return;
        let i2 = t2.closest(e2.isElement ? "swiper-slide" : `.${e2.params.slideClass}`);
        if (i2) {
          let t3 = i2.querySelector(`.${e2.params.lazyPreloaderClass}`);
          !t3 && e2.isElement && (i2.shadowRoot ? t3 = i2.shadowRoot.querySelector(`.${e2.params.lazyPreloaderClass}`) : requestAnimationFrame(() => {
            i2.shadowRoot && (t3 = i2.shadowRoot.querySelector(`.${e2.params.lazyPreloaderClass}`)) && t3.remove();
          })), t3 && t3.remove();
        }
      }, u = (e2, t2) => {
        if (!e2.slides[t2]) return;
        let i2 = e2.slides[t2].querySelector('[loading="lazy"]');
        i2 && i2.removeAttribute("loading");
      }, h = (e2) => {
        if (!e2 || e2.destroyed || !e2.params) return;
        let t2 = e2.params.lazyPreloadPrevNext, i2 = e2.slides.length;
        if (!i2 || !t2 || t2 < 0) return;
        t2 = Math.min(t2, i2);
        let s2 = "auto" === e2.params.slidesPerView ? e2.slidesPerViewDynamic() : Math.ceil(e2.params.slidesPerView), r2 = e2.activeIndex;
        if (e2.params.grid && e2.params.grid.rows > 1) {
          let i3 = [r2 - t2];
          i3.push(...Array.from({ length: t2 }).map((e3, t3) => r2 + s2 + t3)), e2.slides.forEach((t3, s3) => {
            i3.includes(t3.column) && u(e2, s3);
          });
          return;
        }
        let a2 = r2 + s2 - 1;
        if (e2.params.rewind || e2.params.loop)
          for (let s3 = r2 - t2; s3 <= a2 + t2; s3 += 1) {
            let t3 = (s3 % i2 + i2) % i2;
            (t3 < r2 || t3 > a2) && u(e2, t3);
          }
        else
          for (let s3 = Math.max(r2 - t2, 0); s3 <= Math.min(a2 + t2, i2 - 1); s3 += 1)
            s3 !== r2 && (s3 > a2 || s3 < r2) && u(e2, s3);
      };
      function m(e2) {
        let { swiper: t2, runCallbacks: i2, direction: s2, step: r2 } = e2, { activeIndex: a2, previousIndex: l2 } = t2, n2 = s2;
        if (n2 || (n2 = a2 > l2 ? "next" : a2 < l2 ? "prev" : "reset"), t2.emit(`transition${r2}`), i2 && a2 !== l2) {
          if ("reset" === n2) return void t2.emit(`slideResetTransition${r2}`);
          t2.emit(`slideChangeTransition${r2}`), "next" === n2 ? t2.emit(`slideNextTransition${r2}`) : t2.emit(`slidePrevTransition${r2}`);
        }
      }
      function f(e2, t2, i2) {
        let s2 = (0, n.a)(), { params: r2 } = e2, a2 = r2.edgeSwipeDetection, l2 = r2.edgeSwipeThreshold;
        return !a2 || !(i2 <= l2) && !(i2 >= s2.innerWidth - l2) || "prevent" === a2 && (t2.preventDefault(), true);
      }
      function g(e2) {
        let t2 = (0, n.g)(), i2 = e2;
        i2.originalEvent && (i2 = i2.originalEvent);
        let s2 = this.touchEventsData;
        if ("pointerdown" === i2.type) {
          if (null !== s2.pointerId && s2.pointerId !== i2.pointerId) return;
          s2.pointerId = i2.pointerId;
        } else "touchstart" === i2.type && 1 === i2.targetTouches.length && (s2.touchId = i2.targetTouches[0].identifier);
        if ("touchstart" === i2.type) return void f(this, i2, i2.targetTouches[0].pageX);
        let { params: r2, touches: a2, enabled: l2 } = this;
        if (!l2 || !r2.simulateTouch && "mouse" === i2.pointerType || this.animating && r2.preventInteractionOnTransition)
          return;
        !this.animating && r2.cssMode && r2.loop && this.loopFix();
        let d2 = i2.target;
        if ("wrapper" === r2.touchEventsTarget && !this.wrapperEl.contains(d2) || "which" in i2 && 3 === i2.which || "button" in i2 && i2.button > 0 || s2.isTouched && s2.isMoved)
          return;
        let c2 = !!r2.noSwipingClass && "" !== r2.noSwipingClass, p2 = i2.composedPath ? i2.composedPath() : i2.path;
        c2 && i2.target && i2.target.shadowRoot && p2 && (d2 = p2[0]);
        let u2 = r2.noSwipingSelector ? r2.noSwipingSelector : `.${r2.noSwipingClass}`, h2 = !!(i2.target && i2.target.shadowRoot);
        if (r2.noSwiping && (h2 ? (function(e3, t3) {
          return void 0 === t3 && (t3 = this), (function t4(i3) {
            if (!i3 || i3 === (0, n.g)() || i3 === (0, n.a)()) return null;
            i3.assignedSlot && (i3 = i3.assignedSlot);
            let s3 = i3.closest(e3);
            return s3 || i3.getRootNode ? s3 || t4(i3.getRootNode().host) : null;
          })(t3);
        })(u2, d2) : d2.closest(u2))) {
          this.allowClick = true;
          return;
        }
        if (r2.swipeHandler && !d2.closest(r2.swipeHandler)) return;
        a2.currentX = i2.pageX, a2.currentY = i2.pageY;
        let m2 = a2.currentX, g2 = a2.currentY;
        if (!f(this, i2, m2)) return;
        Object.assign(s2, {
          isTouched: true,
          isMoved: false,
          allowTouchCallbacks: true,
          isScrolling: void 0,
          startMoving: void 0
        }), a2.startX = m2, a2.startY = g2, s2.touchStartTime = (0, o.d)(), this.allowClick = true, this.updateSize(), this.swipeDirection = void 0, r2.threshold > 0 && (s2.allowThresholdMove = false);
        let v2 = true;
        d2.matches(s2.focusableElements) && (v2 = false, "SELECT" === d2.nodeName && (s2.isTouched = false)), t2.activeElement && t2.activeElement.matches(s2.focusableElements) && t2.activeElement !== d2 && t2.activeElement.blur();
        let b2 = v2 && this.allowTouchMove && r2.touchStartPreventDefault;
        (r2.touchStartForcePreventDefault || b2) && !d2.isContentEditable && i2.preventDefault(), r2.freeMode && r2.freeMode.enabled && this.freeMode && this.animating && !r2.cssMode && this.freeMode.onTouchStart(), this.emit("touchStart", i2);
      }
      function v(e2) {
        let t2, i2, s2 = (0, n.g)(), r2 = this.touchEventsData, { params: a2, touches: l2, rtlTranslate: d2, enabled: c2 } = this;
        if (!c2 || !a2.simulateTouch && "mouse" === e2.pointerType) return;
        let p2 = e2;
        if (p2.originalEvent && (p2 = p2.originalEvent), "pointermove" === p2.type && (null !== r2.touchId || p2.pointerId !== r2.pointerId))
          return;
        if ("touchmove" === p2.type) {
          if (!(t2 = [...p2.changedTouches].filter((e3) => e3.identifier === r2.touchId)[0]) || t2.identifier !== r2.touchId)
            return;
        } else t2 = p2;
        if (!r2.isTouched) {
          r2.startMoving && r2.isScrolling && this.emit("touchMoveOpposite", p2);
          return;
        }
        let u2 = t2.pageX, h2 = t2.pageY;
        if (p2.preventedByNestedSwiper) {
          l2.startX = u2, l2.startY = h2;
          return;
        }
        if (!this.allowTouchMove) {
          p2.target.matches(r2.focusableElements) || (this.allowClick = false), r2.isTouched && (Object.assign(l2, { startX: u2, startY: h2, currentX: u2, currentY: h2 }), r2.touchStartTime = (0, o.d)());
          return;
        }
        if (a2.touchReleaseOnEdges && !a2.loop) {
          if (this.isVertical()) {
            if (h2 < l2.startY && this.translate <= this.maxTranslate() || h2 > l2.startY && this.translate >= this.minTranslate()) {
              r2.isTouched = false, r2.isMoved = false;
              return;
            }
          } else if (u2 < l2.startX && this.translate <= this.maxTranslate() || u2 > l2.startX && this.translate >= this.minTranslate())
            return;
        }
        if (s2.activeElement && p2.target === s2.activeElement && p2.target.matches(r2.focusableElements)) {
          r2.isMoved = true, this.allowClick = false;
          return;
        }
        r2.allowTouchCallbacks && this.emit("touchMove", p2), l2.previousX = l2.currentX, l2.previousY = l2.currentY, l2.currentX = u2, l2.currentY = h2;
        let m2 = l2.currentX - l2.startX, f2 = l2.currentY - l2.startY;
        if (this.params.threshold && Math.sqrt(m2 ** 2 + f2 ** 2) < this.params.threshold) return;
        if (void 0 === r2.isScrolling) {
          let e3;
          this.isHorizontal() && l2.currentY === l2.startY || this.isVertical() && l2.currentX === l2.startX ? r2.isScrolling = false : m2 * m2 + f2 * f2 >= 25 && (e3 = 180 * Math.atan2(Math.abs(f2), Math.abs(m2)) / Math.PI, r2.isScrolling = this.isHorizontal() ? e3 > a2.touchAngle : 90 - e3 > a2.touchAngle);
        }
        if (r2.isScrolling && this.emit("touchMoveOpposite", p2), void 0 === r2.startMoving && (l2.currentX !== l2.startX || l2.currentY !== l2.startY) && (r2.startMoving = true), r2.isScrolling) {
          r2.isTouched = false;
          return;
        }
        if (!r2.startMoving) return;
        this.allowClick = false, !a2.cssMode && p2.cancelable && p2.preventDefault(), a2.touchMoveStopPropagation && !a2.nested && p2.stopPropagation();
        let g2 = this.isHorizontal() ? m2 : f2, v2 = this.isHorizontal() ? l2.currentX - l2.previousX : l2.currentY - l2.previousY;
        a2.oneWayMovement && (g2 = Math.abs(g2) * (d2 ? 1 : -1), v2 = Math.abs(v2) * (d2 ? 1 : -1)), l2.diff = g2, g2 *= a2.touchRatio, d2 && (g2 = -g2, v2 = -v2);
        let b2 = this.touchesDirection;
        this.swipeDirection = g2 > 0 ? "prev" : "next", this.touchesDirection = v2 > 0 ? "prev" : "next";
        let w2 = this.params.loop && !a2.cssMode, y2 = "next" === this.touchesDirection && this.allowSlideNext || "prev" === this.touchesDirection && this.allowSlidePrev;
        if (!r2.isMoved) {
          if (w2 && y2 && this.loopFix({ direction: this.swipeDirection }), r2.startTranslate = this.getTranslate(), this.setTransition(0), this.animating) {
            let e3 = new window.CustomEvent("transitionend", { bubbles: true, cancelable: true });
            this.wrapperEl.dispatchEvent(e3);
          }
          r2.allowMomentumBounce = false, a2.grabCursor && (true === this.allowSlideNext || true === this.allowSlidePrev) && this.setGrabCursor(true), this.emit("sliderFirstMove", p2);
        }
        if ((/* @__PURE__ */ new Date()).getTime(), r2.isMoved && r2.allowThresholdMove && b2 !== this.touchesDirection && w2 && y2 && Math.abs(g2) >= 1) {
          Object.assign(l2, { startX: u2, startY: h2, currentX: u2, currentY: h2, startTranslate: r2.currentTranslate }), r2.loopSwapReset = true, r2.startTranslate = r2.currentTranslate;
          return;
        }
        this.emit("sliderMove", p2), r2.isMoved = true, r2.currentTranslate = g2 + r2.startTranslate;
        let S2 = true, T2 = a2.resistanceRatio;
        if (a2.touchReleaseOnEdges && (T2 = 0), g2 > 0 ? (w2 && y2 && !i2 && r2.allowThresholdMove && r2.currentTranslate > (a2.centeredSlides ? this.minTranslate() - this.slidesSizesGrid[this.activeIndex + 1] : this.minTranslate()) && this.loopFix({ direction: "prev", setTranslate: true, activeSlideIndex: 0 }), r2.currentTranslate > this.minTranslate() && (S2 = false, a2.resistance && (r2.currentTranslate = this.minTranslate() - 1 + (-this.minTranslate() + r2.startTranslate + g2) ** T2))) : g2 < 0 && (w2 && y2 && !i2 && r2.allowThresholdMove && r2.currentTranslate < (a2.centeredSlides ? this.maxTranslate() + this.slidesSizesGrid[this.slidesSizesGrid.length - 1] : this.maxTranslate()) && this.loopFix({
          direction: "next",
          setTranslate: true,
          activeSlideIndex: this.slides.length - ("auto" === a2.slidesPerView ? this.slidesPerViewDynamic() : Math.ceil(parseFloat(a2.slidesPerView, 10)))
        }), r2.currentTranslate < this.maxTranslate() && (S2 = false, a2.resistance && (r2.currentTranslate = this.maxTranslate() + 1 - (this.maxTranslate() - r2.startTranslate - g2) ** T2))), S2 && (p2.preventedByNestedSwiper = true), !this.allowSlideNext && "next" === this.swipeDirection && r2.currentTranslate < r2.startTranslate && (r2.currentTranslate = r2.startTranslate), !this.allowSlidePrev && "prev" === this.swipeDirection && r2.currentTranslate > r2.startTranslate && (r2.currentTranslate = r2.startTranslate), this.allowSlidePrev || this.allowSlideNext || (r2.currentTranslate = r2.startTranslate), a2.threshold > 0)
          if (Math.abs(g2) > a2.threshold || r2.allowThresholdMove) {
            if (!r2.allowThresholdMove) {
              r2.allowThresholdMove = true, l2.startX = l2.currentX, l2.startY = l2.currentY, r2.currentTranslate = r2.startTranslate, l2.diff = this.isHorizontal() ? l2.currentX - l2.startX : l2.currentY - l2.startY;
              return;
            }
          } else {
            r2.currentTranslate = r2.startTranslate;
            return;
          }
        a2.followFinger && !a2.cssMode && ((a2.freeMode && a2.freeMode.enabled && this.freeMode || a2.watchSlidesProgress) && (this.updateActiveIndex(), this.updateSlidesClasses()), a2.freeMode && a2.freeMode.enabled && this.freeMode && this.freeMode.onTouchMove(), this.updateProgress(r2.currentTranslate), this.setTranslate(r2.currentTranslate));
      }
      function b(e2) {
        let t2, i2, s2 = this, r2 = s2.touchEventsData, a2 = e2;
        if (a2.originalEvent && (a2 = a2.originalEvent), "touchend" === a2.type || "touchcancel" === a2.type) {
          if (!(t2 = [...a2.changedTouches].filter((e3) => e3.identifier === r2.touchId)[0]) || t2.identifier !== r2.touchId)
            return;
        } else {
          if (null !== r2.touchId || a2.pointerId !== r2.pointerId) return;
          t2 = a2;
        }
        if (["pointercancel", "pointerout", "pointerleave", "contextmenu"].includes(a2.type) && !(["pointercancel", "contextmenu"].includes(a2.type) && (s2.browser.isSafari || s2.browser.isWebView)))
          return;
        r2.pointerId = null, r2.touchId = null;
        let { params: l2, touches: n2, rtlTranslate: d2, slidesGrid: c2, enabled: p2 } = s2;
        if (!p2 || !l2.simulateTouch && "mouse" === a2.pointerType) return;
        if (r2.allowTouchCallbacks && s2.emit("touchEnd", a2), r2.allowTouchCallbacks = false, !r2.isTouched) {
          r2.isMoved && l2.grabCursor && s2.setGrabCursor(false), r2.isMoved = false, r2.startMoving = false;
          return;
        }
        l2.grabCursor && r2.isMoved && r2.isTouched && (true === s2.allowSlideNext || true === s2.allowSlidePrev) && s2.setGrabCursor(false);
        let u2 = (0, o.d)(), h2 = u2 - r2.touchStartTime;
        if (s2.allowClick) {
          let e3 = a2.path || a2.composedPath && a2.composedPath();
          s2.updateClickedSlide(e3 && e3[0] || a2.target, e3), s2.emit("tap click", a2), h2 < 300 && u2 - r2.lastClickTime < 300 && s2.emit("doubleTap doubleClick", a2);
        }
        if (r2.lastClickTime = (0, o.d)(), (0, o.n)(() => {
          s2.destroyed || (s2.allowClick = true);
        }), !r2.isTouched || !r2.isMoved || !s2.swipeDirection || 0 === n2.diff && !r2.loopSwapReset || r2.currentTranslate === r2.startTranslate && !r2.loopSwapReset) {
          r2.isTouched = false, r2.isMoved = false, r2.startMoving = false;
          return;
        }
        if (r2.isTouched = false, r2.isMoved = false, r2.startMoving = false, i2 = l2.followFinger ? d2 ? s2.translate : -s2.translate : -r2.currentTranslate, l2.cssMode)
          return;
        if (l2.freeMode && l2.freeMode.enabled) return void s2.freeMode.onTouchEnd({ currentPos: i2 });
        let m2 = i2 >= -s2.maxTranslate() && !s2.params.loop, f2 = 0, g2 = s2.slidesSizesGrid[0];
        for (let e3 = 0; e3 < c2.length; e3 += e3 < l2.slidesPerGroupSkip ? 1 : l2.slidesPerGroup) {
          let t3 = e3 < l2.slidesPerGroupSkip - 1 ? 1 : l2.slidesPerGroup;
          void 0 !== c2[e3 + t3] ? (m2 || i2 >= c2[e3] && i2 < c2[e3 + t3]) && (f2 = e3, g2 = c2[e3 + t3] - c2[e3]) : (m2 || i2 >= c2[e3]) && (f2 = e3, g2 = c2[c2.length - 1] - c2[c2.length - 2]);
        }
        let v2 = null, b2 = null;
        l2.rewind && (s2.isBeginning ? b2 = l2.virtual && l2.virtual.enabled && s2.virtual ? s2.virtual.slides.length - 1 : s2.slides.length - 1 : s2.isEnd && (v2 = 0));
        let w2 = (i2 - c2[f2]) / g2, y2 = f2 < l2.slidesPerGroupSkip - 1 ? 1 : l2.slidesPerGroup;
        if (h2 > l2.longSwipesMs) {
          if (!l2.longSwipes) return void s2.slideTo(s2.activeIndex);
          "next" === s2.swipeDirection && (w2 >= l2.longSwipesRatio ? s2.slideTo(l2.rewind && s2.isEnd ? v2 : f2 + y2) : s2.slideTo(f2)), "prev" === s2.swipeDirection && (w2 > 1 - l2.longSwipesRatio ? s2.slideTo(f2 + y2) : null !== b2 && w2 < 0 && Math.abs(w2) > l2.longSwipesRatio ? s2.slideTo(b2) : s2.slideTo(f2));
        } else {
          if (!l2.shortSwipes) return void s2.slideTo(s2.activeIndex);
          s2.navigation && (a2.target === s2.navigation.nextEl || a2.target === s2.navigation.prevEl) ? a2.target === s2.navigation.nextEl ? s2.slideTo(f2 + y2) : s2.slideTo(f2) : ("next" === s2.swipeDirection && s2.slideTo(null !== v2 ? v2 : f2 + y2), "prev" === s2.swipeDirection && s2.slideTo(null !== b2 ? b2 : f2));
        }
      }
      function w() {
        let e2 = this, { params: t2, el: i2 } = e2;
        if (i2 && 0 === i2.offsetWidth) return;
        t2.breakpoints && e2.setBreakpoint();
        let { allowSlideNext: s2, allowSlidePrev: r2, snapGrid: a2 } = e2, l2 = e2.virtual && e2.params.virtual.enabled;
        e2.allowSlideNext = true, e2.allowSlidePrev = true, e2.updateSize(), e2.updateSlides(), e2.updateSlidesClasses();
        let n2 = l2 && t2.loop;
        "auto" !== t2.slidesPerView && !(t2.slidesPerView > 1) || !e2.isEnd || e2.isBeginning || e2.params.centeredSlides || n2 ? e2.params.loop && !l2 ? e2.slideToLoop(e2.realIndex, 0, false, true) : e2.slideTo(e2.activeIndex, 0, false, true) : e2.slideTo(e2.slides.length - 1, 0, false, true), e2.autoplay && e2.autoplay.running && e2.autoplay.paused && (clearTimeout(e2.autoplay.resizeTimeout), e2.autoplay.resizeTimeout = setTimeout(() => {
          e2.autoplay && e2.autoplay.running && e2.autoplay.paused && e2.autoplay.resume();
        }, 500)), e2.allowSlidePrev = r2, e2.allowSlideNext = s2, e2.params.watchOverflow && a2 !== e2.snapGrid && e2.checkOverflow();
      }
      function y(e2) {
        this.enabled && !this.allowClick && (this.params.preventClicks && e2.preventDefault(), this.params.preventClicksPropagation && this.animating && (e2.stopPropagation(), e2.stopImmediatePropagation()));
      }
      function S() {
        let { wrapperEl: e2, rtlTranslate: t2, enabled: i2 } = this;
        if (!i2) return;
        this.previousTranslate = this.translate, this.isHorizontal() ? this.translate = -e2.scrollLeft : this.translate = -e2.scrollTop, 0 === this.translate && (this.translate = 0), this.updateActiveIndex(), this.updateSlidesClasses();
        let s2 = this.maxTranslate() - this.minTranslate();
        (0 === s2 ? 0 : (this.translate - this.minTranslate()) / s2) !== this.progress && this.updateProgress(t2 ? -this.translate : this.translate), this.emit("setTranslate", this.translate, false);
      }
      function T(e2) {
        p(this, e2.target), !this.params.cssMode && ("auto" === this.params.slidesPerView || this.params.autoHeight) && this.update();
      }
      function E() {
        !this.documentTouchHandlerProceeded && (this.documentTouchHandlerProceeded = true, this.params.touchReleaseOnEdges && (this.el.style.touchAction = "auto"));
      }
      let x = (e2, t2) => {
        let i2 = (0, n.g)(), { params: s2, el: r2, wrapperEl: a2, device: l2 } = e2, o2 = !!s2.nested, d2 = "on" === t2 ? "addEventListener" : "removeEventListener";
        i2[d2]("touchstart", e2.onDocumentTouchStart, { passive: false, capture: o2 }), r2[d2]("touchstart", e2.onTouchStart, { passive: false }), r2[d2]("pointerdown", e2.onTouchStart, { passive: false }), i2[d2]("touchmove", e2.onTouchMove, { passive: false, capture: o2 }), i2[d2]("pointermove", e2.onTouchMove, { passive: false, capture: o2 }), i2[d2]("touchend", e2.onTouchEnd, { passive: true }), i2[d2]("pointerup", e2.onTouchEnd, { passive: true }), i2[d2]("pointercancel", e2.onTouchEnd, { passive: true }), i2[d2]("touchcancel", e2.onTouchEnd, { passive: true }), i2[d2]("pointerout", e2.onTouchEnd, { passive: true }), i2[d2]("pointerleave", e2.onTouchEnd, { passive: true }), i2[d2]("contextmenu", e2.onTouchEnd, { passive: true }), (s2.preventClicks || s2.preventClicksPropagation) && r2[d2]("click", e2.onClick, true), s2.cssMode && a2[d2]("scroll", e2.onScroll), s2.updateOnWindowResize ? e2[t2](l2.ios || l2.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", w, true) : e2[t2]("observerUpdate", w, true), r2[d2]("load", e2.onLoad, { capture: true });
      }, C = (e2, t2) => e2.grid && t2.grid && t2.grid.rows > 1;
      var M = {
        init: true,
        direction: "horizontal",
        oneWayMovement: false,
        swiperElementNodeName: "SWIPER-CONTAINER",
        touchEventsTarget: "wrapper",
        initialSlide: 0,
        speed: 300,
        cssMode: false,
        updateOnWindowResize: true,
        resizeObserver: true,
        nested: false,
        createElements: false,
        eventsPrefix: "swiper",
        enabled: true,
        focusableElements: "input, select, option, textarea, button, video, label",
        width: null,
        height: null,
        preventInteractionOnTransition: false,
        userAgent: null,
        url: null,
        edgeSwipeDetection: false,
        edgeSwipeThreshold: 20,
        autoHeight: false,
        setWrapperSize: false,
        virtualTranslate: false,
        effect: "slide",
        breakpoints: void 0,
        breakpointsBase: "window",
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerGroup: 1,
        slidesPerGroupSkip: 0,
        slidesPerGroupAuto: false,
        centeredSlides: false,
        centeredSlidesBounds: false,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        normalizeSlideIndex: true,
        centerInsufficientSlides: false,
        watchOverflow: true,
        roundLengths: false,
        touchRatio: 1,
        touchAngle: 45,
        simulateTouch: true,
        shortSwipes: true,
        longSwipes: true,
        longSwipesRatio: 0.5,
        longSwipesMs: 300,
        followFinger: true,
        allowTouchMove: true,
        threshold: 5,
        touchMoveStopPropagation: false,
        touchStartPreventDefault: true,
        touchStartForcePreventDefault: false,
        touchReleaseOnEdges: false,
        uniqueNavElements: true,
        resistance: true,
        resistanceRatio: 0.85,
        watchSlidesProgress: false,
        grabCursor: false,
        preventClicks: true,
        preventClicksPropagation: true,
        slideToClickedSlide: false,
        loop: false,
        loopAddBlankSlides: true,
        loopAdditionalSlides: 0,
        loopPreventsSliding: true,
        rewind: false,
        allowSlidePrev: true,
        allowSlideNext: true,
        swipeHandler: null,
        noSwiping: true,
        noSwipingClass: "swiper-no-swiping",
        noSwipingSelector: null,
        passiveListeners: true,
        maxBackfaceHiddenSlides: 10,
        containerModifierClass: "swiper-",
        slideClass: "swiper-slide",
        slideBlankClass: "swiper-slide-blank",
        slideActiveClass: "swiper-slide-active",
        slideVisibleClass: "swiper-slide-visible",
        slideFullyVisibleClass: "swiper-slide-fully-visible",
        slideNextClass: "swiper-slide-next",
        slidePrevClass: "swiper-slide-prev",
        wrapperClass: "swiper-wrapper",
        lazyPreloaderClass: "swiper-lazy-preloader",
        lazyPreloadPrevNext: 0,
        runCallbacksOnInit: true,
        _emitClasses: false
      };
      let P = {
        eventsEmitter: {
          on(e2, t2, i2) {
            let s2 = this;
            if (!s2.eventsListeners || s2.destroyed || "function" != typeof t2) return s2;
            let r2 = i2 ? "unshift" : "push";
            return e2.split(" ").forEach((e3) => {
              s2.eventsListeners[e3] || (s2.eventsListeners[e3] = []), s2.eventsListeners[e3][r2](t2);
            }), s2;
          },
          once(e2, t2, i2) {
            let s2 = this;
            if (!s2.eventsListeners || s2.destroyed || "function" != typeof t2) return s2;
            function r2() {
              s2.off(e2, r2), r2.__emitterProxy && delete r2.__emitterProxy;
              for (var i3 = arguments.length, a2 = Array(i3), l2 = 0; l2 < i3; l2++) a2[l2] = arguments[l2];
              t2.apply(s2, a2);
            }
            return r2.__emitterProxy = t2, s2.on(e2, r2, i2);
          },
          onAny(e2, t2) {
            return !this.eventsListeners || this.destroyed || "function" != typeof e2 || 0 > this.eventsAnyListeners.indexOf(e2) && this.eventsAnyListeners[t2 ? "unshift" : "push"](e2), this;
          },
          offAny(e2) {
            if (!this.eventsListeners || this.destroyed || !this.eventsAnyListeners) return this;
            let t2 = this.eventsAnyListeners.indexOf(e2);
            return t2 >= 0 && this.eventsAnyListeners.splice(t2, 1), this;
          },
          off(e2, t2) {
            let i2 = this;
            return i2.eventsListeners && !i2.destroyed && i2.eventsListeners && e2.split(" ").forEach((e3) => {
              void 0 === t2 ? i2.eventsListeners[e3] = [] : i2.eventsListeners[e3] && i2.eventsListeners[e3].forEach((s2, r2) => {
                (s2 === t2 || s2.__emitterProxy && s2.__emitterProxy === t2) && i2.eventsListeners[e3].splice(r2, 1);
              });
            }), i2;
          },
          emit() {
            let e2, t2, i2, s2 = this;
            if (!s2.eventsListeners || s2.destroyed || !s2.eventsListeners) return s2;
            for (var r2 = arguments.length, a2 = Array(r2), l2 = 0; l2 < r2; l2++) a2[l2] = arguments[l2];
            return "string" == typeof a2[0] || Array.isArray(a2[0]) ? (e2 = a2[0], t2 = a2.slice(1, a2.length), i2 = s2) : (e2 = a2[0].events, t2 = a2[0].data, i2 = a2[0].context || s2), t2.unshift(i2), (Array.isArray(e2) ? e2 : e2.split(" ")).forEach((e3) => {
              s2.eventsAnyListeners && s2.eventsAnyListeners.length && s2.eventsAnyListeners.forEach((s3) => {
                s3.apply(i2, [e3, ...t2]);
              }), s2.eventsListeners && s2.eventsListeners[e3] && s2.eventsListeners[e3].forEach((e4) => {
                e4.apply(i2, t2);
              });
            }), s2;
          }
        },
        update: {
          updateSize: function() {
            let e2, t2, i2 = this.el;
            e2 = void 0 !== this.params.width && null !== this.params.width ? this.params.width : i2.clientWidth, t2 = void 0 !== this.params.height && null !== this.params.height ? this.params.height : i2.clientHeight, 0 === e2 && this.isHorizontal() || 0 === t2 && this.isVertical() || (e2 = e2 - parseInt((0, o.o)(i2, "padding-left") || 0, 10) - parseInt((0, o.o)(i2, "padding-right") || 0, 10), t2 = t2 - parseInt((0, o.o)(i2, "padding-top") || 0, 10) - parseInt((0, o.o)(i2, "padding-bottom") || 0, 10), Number.isNaN(e2) && (e2 = 0), Number.isNaN(t2) && (t2 = 0), Object.assign(this, { width: e2, height: t2, size: this.isHorizontal() ? e2 : t2 }));
          },
          updateSlides: function() {
            let e2, t2 = this;
            function i2(e3, i3) {
              return parseFloat(e3.getPropertyValue(t2.getDirectionLabel(i3)) || 0);
            }
            let s2 = t2.params, { wrapperEl: r2, slidesEl: a2, size: l2, rtlTranslate: n2, wrongRTL: d2 } = t2, c2 = t2.virtual && s2.virtual.enabled, p2 = c2 ? t2.virtual.slides.length : t2.slides.length, u2 = (0, o.e)(a2, `.${t2.params.slideClass}, swiper-slide`), h2 = c2 ? t2.virtual.slides.length : u2.length, m2 = [], f2 = [], g2 = [], v2 = s2.slidesOffsetBefore;
            "function" == typeof v2 && (v2 = s2.slidesOffsetBefore.call(t2));
            let b2 = s2.slidesOffsetAfter;
            "function" == typeof b2 && (b2 = s2.slidesOffsetAfter.call(t2));
            let w2 = t2.snapGrid.length, y2 = t2.slidesGrid.length, S2 = s2.spaceBetween, T2 = -v2, E2 = 0, x2 = 0;
            if (void 0 === l2) return;
            "string" == typeof S2 && S2.indexOf("%") >= 0 ? S2 = parseFloat(S2.replace("%", "")) / 100 * l2 : "string" == typeof S2 && (S2 = parseFloat(S2)), t2.virtualSize = -S2, u2.forEach((e3) => {
              n2 ? e3.style.marginLeft = "" : e3.style.marginRight = "", e3.style.marginBottom = "", e3.style.marginTop = "";
            }), s2.centeredSlides && s2.cssMode && ((0, o.s)(r2, "--swiper-centered-offset-before", ""), (0, o.s)(r2, "--swiper-centered-offset-after", ""));
            let C2 = s2.grid && s2.grid.rows > 1 && t2.grid;
            C2 ? t2.grid.initSlides(u2) : t2.grid && t2.grid.unsetSlides();
            let M2 = "auto" === s2.slidesPerView && s2.breakpoints && Object.keys(s2.breakpoints).filter((e3) => void 0 !== s2.breakpoints[e3].slidesPerView).length > 0;
            for (let r3 = 0; r3 < h2; r3 += 1) {
              let a3;
              if (e2 = 0, u2[r3] && (a3 = u2[r3]), C2 && t2.grid.updateSlide(r3, a3, u2), !u2[r3] || "none" !== (0, o.o)(a3, "display")) {
                if ("auto" === s2.slidesPerView) {
                  M2 && (u2[r3].style[t2.getDirectionLabel("width")] = "");
                  let l3 = getComputedStyle(a3), n3 = a3.style.transform, d3 = a3.style.webkitTransform;
                  if (n3 && (a3.style.transform = "none"), d3 && (a3.style.webkitTransform = "none"), s2.roundLengths)
                    e2 = t2.isHorizontal() ? (0, o.f)(a3, "width", true) : (0, o.f)(a3, "height", true);
                  else {
                    let t3 = i2(l3, "width"), s3 = i2(l3, "padding-left"), r4 = i2(l3, "padding-right"), n4 = i2(l3, "margin-left"), o2 = i2(l3, "margin-right"), d4 = l3.getPropertyValue("box-sizing");
                    if (d4 && "border-box" === d4) e2 = t3 + n4 + o2;
                    else {
                      let { clientWidth: i3, offsetWidth: l4 } = a3;
                      e2 = t3 + s3 + r4 + n4 + o2 + (l4 - i3);
                    }
                  }
                  n3 && (a3.style.transform = n3), d3 && (a3.style.webkitTransform = d3), s2.roundLengths && (e2 = Math.floor(e2));
                } else
                  e2 = (l2 - (s2.slidesPerView - 1) * S2) / s2.slidesPerView, s2.roundLengths && (e2 = Math.floor(e2)), u2[r3] && (u2[r3].style[t2.getDirectionLabel("width")] = `${e2}px`);
                u2[r3] && (u2[r3].swiperSlideSize = e2), g2.push(e2), s2.centeredSlides ? (T2 = T2 + e2 / 2 + E2 / 2 + S2, 0 === E2 && 0 !== r3 && (T2 = T2 - l2 / 2 - S2), 0 === r3 && (T2 = T2 - l2 / 2 - S2), 1e-3 > Math.abs(T2) && (T2 = 0), s2.roundLengths && (T2 = Math.floor(T2)), x2 % s2.slidesPerGroup == 0 && m2.push(T2), f2.push(T2)) : (s2.roundLengths && (T2 = Math.floor(T2)), (x2 - Math.min(t2.params.slidesPerGroupSkip, x2)) % t2.params.slidesPerGroup == 0 && m2.push(T2), f2.push(T2), T2 = T2 + e2 + S2), t2.virtualSize += e2 + S2, E2 = e2, x2 += 1;
              }
            }
            if (t2.virtualSize = Math.max(t2.virtualSize, l2) + b2, n2 && d2 && ("slide" === s2.effect || "coverflow" === s2.effect) && (r2.style.width = `${t2.virtualSize + S2}px`), s2.setWrapperSize && (r2.style[t2.getDirectionLabel("width")] = `${t2.virtualSize + S2}px`), C2 && t2.grid.updateWrapperSize(e2, m2), !s2.centeredSlides) {
              let e3 = [];
              for (let i3 = 0; i3 < m2.length; i3 += 1) {
                let r3 = m2[i3];
                s2.roundLengths && (r3 = Math.floor(r3)), m2[i3] <= t2.virtualSize - l2 && e3.push(r3);
              }
              m2 = e3, Math.floor(t2.virtualSize - l2) - Math.floor(m2[m2.length - 1]) > 1 && m2.push(t2.virtualSize - l2);
            }
            if (c2 && s2.loop) {
              let e3 = g2[0] + S2;
              if (s2.slidesPerGroup > 1) {
                let i3 = Math.ceil((t2.virtual.slidesBefore + t2.virtual.slidesAfter) / s2.slidesPerGroup), r3 = e3 * s2.slidesPerGroup;
                for (let e4 = 0; e4 < i3; e4 += 1) m2.push(m2[m2.length - 1] + r3);
              }
              for (let i3 = 0; i3 < t2.virtual.slidesBefore + t2.virtual.slidesAfter; i3 += 1)
                1 === s2.slidesPerGroup && m2.push(m2[m2.length - 1] + e3), f2.push(f2[f2.length - 1] + e3), t2.virtualSize += e3;
            }
            if (0 === m2.length && (m2 = [0]), 0 !== S2) {
              let e3 = t2.isHorizontal() && n2 ? "marginLeft" : t2.getDirectionLabel("marginRight");
              u2.filter((e4, t3) => !s2.cssMode || !!s2.loop || t3 !== u2.length - 1).forEach((t3) => {
                t3.style[e3] = `${S2}px`;
              });
            }
            if (s2.centeredSlides && s2.centeredSlidesBounds) {
              let e3 = 0;
              g2.forEach((t4) => {
                e3 += t4 + (S2 || 0);
              });
              let t3 = (e3 -= S2) - l2;
              m2 = m2.map((e4) => e4 <= 0 ? -v2 : e4 > t3 ? t3 + b2 : e4);
            }
            if (s2.centerInsufficientSlides) {
              let e3 = 0;
              if (g2.forEach((t3) => {
                e3 += t3 + (S2 || 0);
              }), (e3 -= S2) < l2) {
                let t3 = (l2 - e3) / 2;
                m2.forEach((e4, i3) => {
                  m2[i3] = e4 - t3;
                }), f2.forEach((e4, i3) => {
                  f2[i3] = e4 + t3;
                });
              }
            }
            if (Object.assign(t2, { slides: u2, snapGrid: m2, slidesGrid: f2, slidesSizesGrid: g2 }), s2.centeredSlides && s2.cssMode && !s2.centeredSlidesBounds) {
              (0, o.s)(r2, "--swiper-centered-offset-before", `${-m2[0]}px`), (0, o.s)(r2, "--swiper-centered-offset-after", `${t2.size / 2 - g2[g2.length - 1] / 2}px`);
              let e3 = -t2.snapGrid[0], i3 = -t2.slidesGrid[0];
              t2.snapGrid = t2.snapGrid.map((t3) => t3 + e3), t2.slidesGrid = t2.slidesGrid.map((e4) => e4 + i3);
            }
            if (h2 !== p2 && t2.emit("slidesLengthChange"), m2.length !== w2 && (t2.params.watchOverflow && t2.checkOverflow(), t2.emit("snapGridLengthChange")), f2.length !== y2 && t2.emit("slidesGridLengthChange"), s2.watchSlidesProgress && t2.updateSlidesOffset(), t2.emit("slidesUpdated"), !c2 && !s2.cssMode && ("slide" === s2.effect || "fade" === s2.effect)) {
              let e3 = `${s2.containerModifierClass}backface-hidden`, i3 = t2.el.classList.contains(e3);
              h2 <= s2.maxBackfaceHiddenSlides ? i3 || t2.el.classList.add(e3) : i3 && t2.el.classList.remove(e3);
            }
          },
          updateAutoHeight: function(e2) {
            let t2, i2 = this, s2 = [], r2 = i2.virtual && i2.params.virtual.enabled, a2 = 0;
            "number" == typeof e2 ? i2.setTransition(e2) : true === e2 && i2.setTransition(i2.params.speed);
            let l2 = (e3) => r2 ? i2.slides[i2.getSlideIndexByData(e3)] : i2.slides[e3];
            if ("auto" !== i2.params.slidesPerView && i2.params.slidesPerView > 1)
              if (i2.params.centeredSlides)
                (i2.visibleSlides || []).forEach((e3) => {
                  s2.push(e3);
                });
              else
                for (t2 = 0; t2 < Math.ceil(i2.params.slidesPerView); t2 += 1) {
                  let e3 = i2.activeIndex + t2;
                  if (e3 > i2.slides.length && !r2) break;
                  s2.push(l2(e3));
                }
            else s2.push(l2(i2.activeIndex));
            for (t2 = 0; t2 < s2.length; t2 += 1)
              if (void 0 !== s2[t2]) {
                let e3 = s2[t2].offsetHeight;
                a2 = e3 > a2 ? e3 : a2;
              }
            (a2 || 0 === a2) && (i2.wrapperEl.style.height = `${a2}px`);
          },
          updateSlidesOffset: function() {
            let e2 = this.slides, t2 = this.isElement ? this.isHorizontal() ? this.wrapperEl.offsetLeft : this.wrapperEl.offsetTop : 0;
            for (let i2 = 0; i2 < e2.length; i2 += 1)
              e2[i2].swiperSlideOffset = (this.isHorizontal() ? e2[i2].offsetLeft : e2[i2].offsetTop) - t2 - this.cssOverflowAdjustment();
          },
          updateSlidesProgress: function(e2) {
            void 0 === e2 && (e2 = this && this.translate || 0);
            let t2 = this.params, { slides: i2, rtlTranslate: s2, snapGrid: r2 } = this;
            if (0 === i2.length) return;
            void 0 === i2[0].swiperSlideOffset && this.updateSlidesOffset();
            let a2 = -e2;
            s2 && (a2 = e2), i2.forEach((e3) => {
              e3.classList.remove(t2.slideVisibleClass, t2.slideFullyVisibleClass);
            }), this.visibleSlidesIndexes = [], this.visibleSlides = [];
            let l2 = t2.spaceBetween;
            "string" == typeof l2 && l2.indexOf("%") >= 0 ? l2 = parseFloat(l2.replace("%", "")) / 100 * this.size : "string" == typeof l2 && (l2 = parseFloat(l2));
            for (let e3 = 0; e3 < i2.length; e3 += 1) {
              let n2 = i2[e3], o2 = n2.swiperSlideOffset;
              t2.cssMode && t2.centeredSlides && (o2 -= i2[0].swiperSlideOffset);
              let d2 = (a2 + (t2.centeredSlides ? this.minTranslate() : 0) - o2) / (n2.swiperSlideSize + l2), c2 = (a2 - r2[0] + (t2.centeredSlides ? this.minTranslate() : 0) - o2) / (n2.swiperSlideSize + l2), p2 = -(a2 - o2), u2 = p2 + this.slidesSizesGrid[e3], h2 = p2 >= 0 && p2 <= this.size - this.slidesSizesGrid[e3];
              (p2 >= 0 && p2 < this.size - 1 || u2 > 1 && u2 <= this.size || p2 <= 0 && u2 >= this.size) && (this.visibleSlides.push(n2), this.visibleSlidesIndexes.push(e3), i2[e3].classList.add(t2.slideVisibleClass)), h2 && i2[e3].classList.add(t2.slideFullyVisibleClass), n2.progress = s2 ? -d2 : d2, n2.originalProgress = s2 ? -c2 : c2;
            }
          },
          updateProgress: function(e2) {
            if (void 0 === e2) {
              let t3 = this.rtlTranslate ? -1 : 1;
              e2 = this && this.translate && this.translate * t3 || 0;
            }
            let t2 = this.params, i2 = this.maxTranslate() - this.minTranslate(), { progress: s2, isBeginning: r2, isEnd: a2, progressLoop: l2 } = this, n2 = r2, o2 = a2;
            if (0 === i2) s2 = 0, r2 = true, a2 = true;
            else {
              s2 = (e2 - this.minTranslate()) / i2;
              let t3 = 1 > Math.abs(e2 - this.minTranslate()), l3 = 1 > Math.abs(e2 - this.maxTranslate());
              r2 = t3 || s2 <= 0, a2 = l3 || s2 >= 1, t3 && (s2 = 0), l3 && (s2 = 1);
            }
            if (t2.loop) {
              let t3 = this.getSlideIndexByData(0), i3 = this.getSlideIndexByData(this.slides.length - 1), s3 = this.slidesGrid[t3], r3 = this.slidesGrid[i3], a3 = this.slidesGrid[this.slidesGrid.length - 1], n3 = Math.abs(e2);
              (l2 = n3 >= s3 ? (n3 - s3) / a3 : (n3 + a3 - r3) / a3) > 1 && (l2 -= 1);
            }
            Object.assign(this, { progress: s2, progressLoop: l2, isBeginning: r2, isEnd: a2 }), (t2.watchSlidesProgress || t2.centeredSlides && t2.autoHeight) && this.updateSlidesProgress(e2), r2 && !n2 && this.emit("reachBeginning toEdge"), a2 && !o2 && this.emit("reachEnd toEdge"), (n2 && !r2 || o2 && !a2) && this.emit("fromEdge"), this.emit("progress", s2);
          },
          updateSlidesClasses: function() {
            let e2, t2, i2, { slides: s2, params: r2, slidesEl: a2, activeIndex: l2 } = this, n2 = this.virtual && r2.virtual.enabled, d2 = this.grid && r2.grid && r2.grid.rows > 1, c2 = (e3) => (0, o.e)(a2, `.${r2.slideClass}${e3}, swiper-slide${e3}`)[0];
            if (s2.forEach((e3) => {
              e3.classList.remove(r2.slideActiveClass, r2.slideNextClass, r2.slidePrevClass);
            }), n2)
              if (r2.loop) {
                let t3 = l2 - this.virtual.slidesBefore;
                t3 < 0 && (t3 = this.virtual.slides.length + t3), t3 >= this.virtual.slides.length && (t3 -= this.virtual.slides.length), e2 = c2(`[data-swiper-slide-index="${t3}"]`);
              } else e2 = c2(`[data-swiper-slide-index="${l2}"]`);
            else
              d2 ? (e2 = s2.filter((e3) => e3.column === l2)[0], i2 = s2.filter((e3) => e3.column === l2 + 1)[0], t2 = s2.filter((e3) => e3.column === l2 - 1)[0]) : e2 = s2[l2];
            e2 && (e2.classList.add(r2.slideActiveClass), d2 ? i2 && i2.classList.add(r2.slideNextClass) : (i2 = (0, o.p)(e2, `.${r2.slideClass}, swiper-slide`)[0], r2.loop && !i2 && (i2 = s2[0]), i2 && i2.classList.add(r2.slideNextClass), t2 = (0, o.q)(e2, `.${r2.slideClass}, swiper-slide`)[0], r2.loop), t2 && t2.classList.add(r2.slidePrevClass)), this.emitSlidesClasses();
          },
          updateActiveIndex: function(e2) {
            let t2, i2, s2 = this, r2 = s2.rtlTranslate ? s2.translate : -s2.translate, { snapGrid: a2, params: l2, activeIndex: n2, realIndex: o2, snapIndex: d2 } = s2, c2 = e2, p2 = (e3) => {
              let t3 = e3 - s2.virtual.slidesBefore;
              return t3 < 0 && (t3 = s2.virtual.slides.length + t3), t3 >= s2.virtual.slides.length && (t3 -= s2.virtual.slides.length), t3;
            };
            if (void 0 === c2 && (c2 = (function(e3) {
              let t3, { slidesGrid: i3, params: s3 } = e3, r3 = e3.rtlTranslate ? e3.translate : -e3.translate;
              for (let e4 = 0; e4 < i3.length; e4 += 1)
                void 0 !== i3[e4 + 1] ? r3 >= i3[e4] && r3 < i3[e4 + 1] - (i3[e4 + 1] - i3[e4]) / 2 ? t3 = e4 : r3 >= i3[e4] && r3 < i3[e4 + 1] && (t3 = e4 + 1) : r3 >= i3[e4] && (t3 = e4);
              return s3.normalizeSlideIndex && (t3 < 0 || void 0 === t3) && (t3 = 0), t3;
            })(s2)), a2.indexOf(r2) >= 0)
              t2 = a2.indexOf(r2);
            else {
              let e3 = Math.min(l2.slidesPerGroupSkip, c2);
              t2 = e3 + Math.floor((c2 - e3) / l2.slidesPerGroup);
            }
            if (t2 >= a2.length && (t2 = a2.length - 1), c2 === n2 && !s2.params.loop) {
              t2 !== d2 && (s2.snapIndex = t2, s2.emit("snapIndexChange"));
              return;
            }
            if (c2 === n2 && s2.params.loop && s2.virtual && s2.params.virtual.enabled) {
              s2.realIndex = p2(c2);
              return;
            }
            let u2 = s2.grid && l2.grid && l2.grid.rows > 1;
            if (s2.virtual && l2.virtual.enabled && l2.loop) i2 = p2(c2);
            else if (u2) {
              let e3 = s2.slides.filter((e4) => e4.column === c2)[0], t3 = parseInt(e3.getAttribute("data-swiper-slide-index"), 10);
              Number.isNaN(t3) && (t3 = Math.max(s2.slides.indexOf(e3), 0)), i2 = Math.floor(t3 / l2.grid.rows);
            } else if (s2.slides[c2]) {
              let e3 = s2.slides[c2].getAttribute("data-swiper-slide-index");
              i2 = e3 ? parseInt(e3, 10) : c2;
            } else i2 = c2;
            Object.assign(s2, {
              previousSnapIndex: d2,
              snapIndex: t2,
              previousRealIndex: o2,
              realIndex: i2,
              previousIndex: n2,
              activeIndex: c2
            }), s2.initialized && h(s2), s2.emit("activeIndexChange"), s2.emit("snapIndexChange"), (s2.initialized || s2.params.runCallbacksOnInit) && (o2 !== i2 && s2.emit("realIndexChange"), s2.emit("slideChange"));
          },
          updateClickedSlide: function(e2, t2) {
            let i2, s2 = this.params, r2 = e2.closest(`.${s2.slideClass}, swiper-slide`);
            !r2 && this.isElement && t2 && t2.length > 1 && t2.includes(e2) && [...t2.slice(t2.indexOf(e2) + 1, t2.length)].forEach((e3) => {
              !r2 && e3.matches && e3.matches(`.${s2.slideClass}, swiper-slide`) && (r2 = e3);
            });
            let a2 = false;
            if (r2) {
              for (let e3 = 0; e3 < this.slides.length; e3 += 1)
                if (this.slides[e3] === r2) {
                  a2 = true, i2 = e3;
                  break;
                }
            }
            if (r2 && a2)
              this.clickedSlide = r2, this.virtual && this.params.virtual.enabled ? this.clickedIndex = parseInt(r2.getAttribute("data-swiper-slide-index"), 10) : this.clickedIndex = i2;
            else {
              this.clickedSlide = void 0, this.clickedIndex = void 0;
              return;
            }
            s2.slideToClickedSlide && void 0 !== this.clickedIndex && this.clickedIndex !== this.activeIndex && this.slideToClickedSlide();
          }
        },
        translate: {
          getTranslate: function(e2) {
            void 0 === e2 && (e2 = this.isHorizontal() ? "x" : "y");
            let { params: t2, rtlTranslate: i2, translate: s2, wrapperEl: r2 } = this;
            if (t2.virtualTranslate) return i2 ? -s2 : s2;
            if (t2.cssMode) return s2;
            let a2 = (0, o.j)(r2, e2);
            return a2 += this.cssOverflowAdjustment(), i2 && (a2 = -a2), a2 || 0;
          },
          setTranslate: function(e2, t2) {
            let { rtlTranslate: i2, params: s2, wrapperEl: r2, progress: a2 } = this, l2 = 0, n2 = 0;
            this.isHorizontal() ? l2 = i2 ? -e2 : e2 : n2 = e2, s2.roundLengths && (l2 = Math.floor(l2), n2 = Math.floor(n2)), this.previousTranslate = this.translate, this.translate = this.isHorizontal() ? l2 : n2, s2.cssMode ? r2[this.isHorizontal() ? "scrollLeft" : "scrollTop"] = this.isHorizontal() ? -l2 : -n2 : s2.virtualTranslate || (this.isHorizontal() ? l2 -= this.cssOverflowAdjustment() : n2 -= this.cssOverflowAdjustment(), r2.style.transform = `translate3d(${l2}px, ${n2}px, 0px)`);
            let o2 = this.maxTranslate() - this.minTranslate();
            (0 === o2 ? 0 : (e2 - this.minTranslate()) / o2) !== a2 && this.updateProgress(e2), this.emit("setTranslate", this.translate, t2);
          },
          minTranslate: function() {
            return -this.snapGrid[0];
          },
          maxTranslate: function() {
            return -this.snapGrid[this.snapGrid.length - 1];
          },
          translateTo: function(e2, t2, i2, s2, r2) {
            let a2;
            void 0 === e2 && (e2 = 0), void 0 === t2 && (t2 = this.params.speed), void 0 === i2 && (i2 = true), void 0 === s2 && (s2 = true);
            let l2 = this, { params: n2, wrapperEl: d2 } = l2;
            if (l2.animating && n2.preventInteractionOnTransition) return false;
            let c2 = l2.minTranslate(), p2 = l2.maxTranslate();
            if (a2 = s2 && e2 > c2 ? c2 : s2 && e2 < p2 ? p2 : e2, l2.updateProgress(a2), n2.cssMode) {
              let e3 = l2.isHorizontal();
              if (0 === t2) d2[e3 ? "scrollLeft" : "scrollTop"] = -a2;
              else {
                if (!l2.support.smoothScroll)
                  return (0, o.r)({ swiper: l2, targetPosition: -a2, side: e3 ? "left" : "top" }), true;
                d2.scrollTo({ [e3 ? "left" : "top"]: -a2, behavior: "smooth" });
              }
              return true;
            }
            return 0 === t2 ? (l2.setTransition(0), l2.setTranslate(a2), i2 && (l2.emit("beforeTransitionStart", t2, r2), l2.emit("transitionEnd"))) : (l2.setTransition(t2), l2.setTranslate(a2), i2 && (l2.emit("beforeTransitionStart", t2, r2), l2.emit("transitionStart")), l2.animating || (l2.animating = true, l2.onTranslateToWrapperTransitionEnd || (l2.onTranslateToWrapperTransitionEnd = function(e3) {
              l2 && !l2.destroyed && e3.target === this && (l2.wrapperEl.removeEventListener("transitionend", l2.onTranslateToWrapperTransitionEnd), l2.onTranslateToWrapperTransitionEnd = null, delete l2.onTranslateToWrapperTransitionEnd, i2 && l2.emit("transitionEnd"));
            }), l2.wrapperEl.addEventListener("transitionend", l2.onTranslateToWrapperTransitionEnd))), true;
          }
        },
        transition: {
          setTransition: function(e2, t2) {
            this.params.cssMode || (this.wrapperEl.style.transitionDuration = `${e2}ms`, this.wrapperEl.style.transitionDelay = 0 === e2 ? "0ms" : ""), this.emit("setTransition", e2, t2);
          },
          transitionStart: function(e2, t2) {
            void 0 === e2 && (e2 = true);
            let { params: i2 } = this;
            i2.cssMode || (i2.autoHeight && this.updateAutoHeight(), m({ swiper: this, runCallbacks: e2, direction: t2, step: "Start" }));
          },
          transitionEnd: function(e2, t2) {
            void 0 === e2 && (e2 = true);
            let { params: i2 } = this;
            this.animating = false, i2.cssMode || (this.setTransition(0), m({ swiper: this, runCallbacks: e2, direction: t2, step: "End" }));
          }
        },
        slide: {
          slideTo: function(e2, t2, i2, s2, r2) {
            let a2;
            void 0 === e2 && (e2 = 0), void 0 === t2 && (t2 = this.params.speed), void 0 === i2 && (i2 = true), "string" == typeof e2 && (e2 = parseInt(e2, 10));
            let l2 = this, n2 = e2;
            n2 < 0 && (n2 = 0);
            let {
              params: d2,
              snapGrid: c2,
              slidesGrid: p2,
              previousIndex: u2,
              activeIndex: h2,
              rtlTranslate: m2,
              wrapperEl: f2,
              enabled: g2
            } = l2;
            if (l2.animating && d2.preventInteractionOnTransition || !g2 && !s2 && !r2 || l2.destroyed) return false;
            let v2 = Math.min(l2.params.slidesPerGroupSkip, n2), b2 = v2 + Math.floor((n2 - v2) / l2.params.slidesPerGroup);
            b2 >= c2.length && (b2 = c2.length - 1);
            let w2 = -c2[b2];
            if (d2.normalizeSlideIndex)
              for (let e3 = 0; e3 < p2.length; e3 += 1) {
                let t3 = -Math.floor(100 * w2), i3 = Math.floor(100 * p2[e3]), s3 = Math.floor(100 * p2[e3 + 1]);
                void 0 !== p2[e3 + 1] ? t3 >= i3 && t3 < s3 - (s3 - i3) / 2 ? n2 = e3 : t3 >= i3 && t3 < s3 && (n2 = e3 + 1) : t3 >= i3 && (n2 = e3);
              }
            if (l2.initialized && n2 !== h2 && (!l2.allowSlideNext && (m2 ? w2 > l2.translate && w2 > l2.minTranslate() : w2 < l2.translate && w2 < l2.minTranslate()) || !l2.allowSlidePrev && w2 > l2.translate && w2 > l2.maxTranslate() && (h2 || 0) !== n2))
              return false;
            if (n2 !== (u2 || 0) && i2 && l2.emit("beforeSlideChangeStart"), l2.updateProgress(w2), a2 = n2 > h2 ? "next" : n2 < h2 ? "prev" : "reset", m2 && -w2 === l2.translate || !m2 && w2 === l2.translate)
              return l2.updateActiveIndex(n2), d2.autoHeight && l2.updateAutoHeight(), l2.updateSlidesClasses(), "slide" !== d2.effect && l2.setTranslate(w2), "reset" !== a2 && (l2.transitionStart(i2, a2), l2.transitionEnd(i2, a2)), false;
            if (d2.cssMode) {
              let e3 = l2.isHorizontal(), i3 = m2 ? w2 : -w2;
              if (0 === t2) {
                let t3 = l2.virtual && l2.params.virtual.enabled;
                t3 && (l2.wrapperEl.style.scrollSnapType = "none", l2._immediateVirtual = true), t3 && !l2._cssModeVirtualInitialSet && l2.params.initialSlide > 0 ? (l2._cssModeVirtualInitialSet = true, requestAnimationFrame(() => {
                  f2[e3 ? "scrollLeft" : "scrollTop"] = i3;
                })) : f2[e3 ? "scrollLeft" : "scrollTop"] = i3, t3 && requestAnimationFrame(() => {
                  l2.wrapperEl.style.scrollSnapType = "", l2._immediateVirtual = false;
                });
              } else {
                if (!l2.support.smoothScroll)
                  return (0, o.r)({ swiper: l2, targetPosition: i3, side: e3 ? "left" : "top" }), true;
                f2.scrollTo({ [e3 ? "left" : "top"]: i3, behavior: "smooth" });
              }
              return true;
            }
            return l2.setTransition(t2), l2.setTranslate(w2), l2.updateActiveIndex(n2), l2.updateSlidesClasses(), l2.emit("beforeTransitionStart", t2, s2), l2.transitionStart(i2, a2), 0 === t2 ? l2.transitionEnd(i2, a2) : l2.animating || (l2.animating = true, l2.onSlideToWrapperTransitionEnd || (l2.onSlideToWrapperTransitionEnd = function(e3) {
              l2 && !l2.destroyed && e3.target === this && (l2.wrapperEl.removeEventListener("transitionend", l2.onSlideToWrapperTransitionEnd), l2.onSlideToWrapperTransitionEnd = null, delete l2.onSlideToWrapperTransitionEnd, l2.transitionEnd(i2, a2));
            }), l2.wrapperEl.addEventListener("transitionend", l2.onSlideToWrapperTransitionEnd)), true;
          },
          slideToLoop: function(e2, t2, i2, s2) {
            void 0 === e2 && (e2 = 0), void 0 === t2 && (t2 = this.params.speed), void 0 === i2 && (i2 = true), "string" == typeof e2 && (e2 = parseInt(e2, 10));
            let r2 = this;
            if (r2.destroyed) return;
            let a2 = r2.grid && r2.params.grid && r2.params.grid.rows > 1, l2 = e2;
            if (r2.params.loop)
              if (r2.virtual && r2.params.virtual.enabled) l2 += r2.virtual.slidesBefore;
              else {
                let e3;
                if (a2) {
                  let t4 = l2 * r2.params.grid.rows;
                  e3 = r2.slides.filter((e4) => +e4.getAttribute("data-swiper-slide-index") === t4)[0].column;
                } else e3 = r2.getSlideIndexByData(l2);
                let t3 = a2 ? Math.ceil(r2.slides.length / r2.params.grid.rows) : r2.slides.length, { centeredSlides: i3 } = r2.params, s3 = r2.params.slidesPerView;
                "auto" === s3 ? s3 = r2.slidesPerViewDynamic() : (s3 = Math.ceil(parseFloat(r2.params.slidesPerView, 10)), i3 && s3 % 2 == 0 && (s3 += 1));
                let n2 = t3 - e3 < s3;
                if (i3 && (n2 = n2 || e3 < Math.ceil(s3 / 2)), n2) {
                  let s4 = i3 ? e3 < r2.activeIndex ? "prev" : "next" : e3 - r2.activeIndex - 1 < r2.params.slidesPerView ? "next" : "prev";
                  r2.loopFix({
                    direction: s4,
                    slideTo: true,
                    activeSlideIndex: "next" === s4 ? e3 + 1 : e3 - t3 + 1,
                    slideRealIndex: "next" === s4 ? r2.realIndex : void 0
                  });
                }
                if (a2) {
                  let e4 = l2 * r2.params.grid.rows;
                  l2 = r2.slides.filter((t4) => +t4.getAttribute("data-swiper-slide-index") === e4)[0].column;
                } else l2 = r2.getSlideIndexByData(l2);
              }
            return requestAnimationFrame(() => {
              r2.slideTo(l2, t2, i2, s2);
            }), r2;
          },
          slideNext: function(e2, t2, i2) {
            void 0 === e2 && (e2 = this.params.speed), void 0 === t2 && (t2 = true);
            let s2 = this, { enabled: r2, params: a2, animating: l2 } = s2;
            if (!r2 || s2.destroyed) return s2;
            let n2 = a2.slidesPerGroup;
            "auto" === a2.slidesPerView && 1 === a2.slidesPerGroup && a2.slidesPerGroupAuto && (n2 = Math.max(s2.slidesPerViewDynamic("current", true), 1));
            let o2 = s2.activeIndex < a2.slidesPerGroupSkip ? 1 : n2, d2 = s2.virtual && a2.virtual.enabled;
            if (a2.loop) {
              if (l2 && !d2 && a2.loopPreventsSliding) return false;
              if (s2.loopFix({ direction: "next" }), s2._clientLeft = s2.wrapperEl.clientLeft, s2.activeIndex === s2.slides.length - 1 && a2.cssMode)
                return requestAnimationFrame(() => {
                  s2.slideTo(s2.activeIndex + o2, e2, t2, i2);
                }), true;
            }
            return a2.rewind && s2.isEnd ? s2.slideTo(0, e2, t2, i2) : s2.slideTo(s2.activeIndex + o2, e2, t2, i2);
          },
          slidePrev: function(e2, t2, i2) {
            void 0 === e2 && (e2 = this.params.speed), void 0 === t2 && (t2 = true);
            let s2 = this, { params: r2, snapGrid: a2, slidesGrid: l2, rtlTranslate: n2, enabled: o2, animating: d2 } = s2;
            if (!o2 || s2.destroyed) return s2;
            let c2 = s2.virtual && r2.virtual.enabled;
            if (r2.loop) {
              if (d2 && !c2 && r2.loopPreventsSliding) return false;
              s2.loopFix({ direction: "prev" }), s2._clientLeft = s2.wrapperEl.clientLeft;
            }
            function p2(e3) {
              return e3 < 0 ? -Math.floor(Math.abs(e3)) : Math.floor(e3);
            }
            let u2 = p2(n2 ? s2.translate : -s2.translate), h2 = a2.map((e3) => p2(e3)), m2 = a2[h2.indexOf(u2) - 1];
            if (void 0 === m2 && r2.cssMode) {
              let e3;
              a2.forEach((t3, i3) => {
                u2 >= t3 && (e3 = i3);
              }), void 0 !== e3 && (m2 = a2[e3 > 0 ? e3 - 1 : e3]);
            }
            let f2 = 0;
            if (void 0 !== m2 && ((f2 = l2.indexOf(m2)) < 0 && (f2 = s2.activeIndex - 1), "auto" === r2.slidesPerView && 1 === r2.slidesPerGroup && r2.slidesPerGroupAuto && (f2 = Math.max(f2 = f2 - s2.slidesPerViewDynamic("previous", true) + 1, 0))), r2.rewind && s2.isBeginning) {
              let r3 = s2.params.virtual && s2.params.virtual.enabled && s2.virtual ? s2.virtual.slides.length - 1 : s2.slides.length - 1;
              return s2.slideTo(r3, e2, t2, i2);
            }
            return r2.loop && 0 === s2.activeIndex && r2.cssMode ? (requestAnimationFrame(() => {
              s2.slideTo(f2, e2, t2, i2);
            }), true) : s2.slideTo(f2, e2, t2, i2);
          },
          slideReset: function(e2, t2, i2) {
            if (void 0 === e2 && (e2 = this.params.speed), void 0 === t2 && (t2 = true), !this.destroyed)
              return this.slideTo(this.activeIndex, e2, t2, i2);
          },
          slideToClosest: function(e2, t2, i2, s2) {
            if (void 0 === e2 && (e2 = this.params.speed), void 0 === t2 && (t2 = true), void 0 === s2 && (s2 = 0.5), this.destroyed)
              return;
            let r2 = this.activeIndex, a2 = Math.min(this.params.slidesPerGroupSkip, r2), l2 = a2 + Math.floor((r2 - a2) / this.params.slidesPerGroup), n2 = this.rtlTranslate ? this.translate : -this.translate;
            if (n2 >= this.snapGrid[l2]) {
              let e3 = this.snapGrid[l2];
              n2 - e3 > (this.snapGrid[l2 + 1] - e3) * s2 && (r2 += this.params.slidesPerGroup);
            } else {
              let e3 = this.snapGrid[l2 - 1];
              n2 - e3 <= (this.snapGrid[l2] - e3) * s2 && (r2 -= this.params.slidesPerGroup);
            }
            return r2 = Math.min(r2 = Math.max(r2, 0), this.slidesGrid.length - 1), this.slideTo(r2, e2, t2, i2);
          },
          slideToClickedSlide: function() {
            let e2, t2 = this;
            if (t2.destroyed) return;
            let { params: i2, slidesEl: s2 } = t2, r2 = "auto" === i2.slidesPerView ? t2.slidesPerViewDynamic() : i2.slidesPerView, a2 = t2.clickedIndex, l2 = t2.isElement ? "swiper-slide" : `.${i2.slideClass}`;
            if (i2.loop) {
              if (t2.animating) return;
              e2 = parseInt(t2.clickedSlide.getAttribute("data-swiper-slide-index"), 10), i2.centeredSlides ? a2 < t2.loopedSlides - r2 / 2 || a2 > t2.slides.length - t2.loopedSlides + r2 / 2 ? (t2.loopFix(), a2 = t2.getSlideIndex((0, o.e)(s2, `${l2}[data-swiper-slide-index="${e2}"]`)[0]), (0, o.n)(() => {
                t2.slideTo(a2);
              })) : t2.slideTo(a2) : a2 > t2.slides.length - r2 ? (t2.loopFix(), a2 = t2.getSlideIndex((0, o.e)(s2, `${l2}[data-swiper-slide-index="${e2}"]`)[0]), (0, o.n)(() => {
                t2.slideTo(a2);
              })) : t2.slideTo(a2);
            } else t2.slideTo(a2);
          }
        },
        loop: {
          loopCreate: function(e2) {
            let t2 = this, { params: i2, slidesEl: s2 } = t2;
            if (!i2.loop || t2.virtual && t2.params.virtual.enabled) return;
            let r2 = t2.grid && i2.grid && i2.grid.rows > 1, a2 = i2.slidesPerGroup * (r2 ? i2.grid.rows : 1), l2 = t2.slides.length % a2 != 0, n2 = r2 && t2.slides.length % i2.grid.rows != 0, d2 = (e3) => {
              for (let s3 = 0; s3 < e3; s3 += 1) {
                let e4 = t2.isElement ? (0, o.c)("swiper-slide", [i2.slideBlankClass]) : (0, o.c)("div", [i2.slideClass, i2.slideBlankClass]);
                t2.slidesEl.append(e4);
              }
            };
            l2 ? i2.loopAddBlankSlides ? (d2(a2 - t2.slides.length % a2), t2.recalcSlides(), t2.updateSlides()) : (0, o.t)(
              "Swiper Loop Warning: The number of slides is not even to slidesPerGroup, loop mode may not function properly. You need to add more slides (or make duplicates, or empty slides)"
            ) : n2 && (i2.loopAddBlankSlides ? (d2(i2.grid.rows - t2.slides.length % i2.grid.rows), t2.recalcSlides(), t2.updateSlides()) : (0, o.t)(
              "Swiper Loop Warning: The number of slides is not even to grid.rows, loop mode may not function properly. You need to add more slides (or make duplicates, or empty slides)"
            )), (0, o.e)(s2, `.${i2.slideClass}, swiper-slide`).forEach((e3, t3) => {
              e3.setAttribute("data-swiper-slide-index", t3);
            }), t2.loopFix({ slideRealIndex: e2, direction: i2.centeredSlides ? void 0 : "next" });
          },
          loopFix: function(e2) {
            let {
              slideRealIndex: t2,
              slideTo: i2 = true,
              direction: s2,
              setTranslate: r2,
              activeSlideIndex: a2,
              byController: l2,
              byMousewheel: n2
            } = void 0 === e2 ? {} : e2, d2 = this;
            if (!d2.params.loop) return;
            d2.emit("beforeLoopFix");
            let { slides: c2, allowSlidePrev: p2, allowSlideNext: u2, slidesEl: h2, params: m2 } = d2, { centeredSlides: f2 } = m2;
            if (d2.allowSlidePrev = true, d2.allowSlideNext = true, d2.virtual && m2.virtual.enabled) {
              i2 && (m2.centeredSlides || 0 !== d2.snapIndex ? m2.centeredSlides && d2.snapIndex < m2.slidesPerView ? d2.slideTo(d2.virtual.slides.length + d2.snapIndex, 0, false, true) : d2.snapIndex === d2.snapGrid.length - 1 && d2.slideTo(d2.virtual.slidesBefore, 0, false, true) : d2.slideTo(d2.virtual.slides.length, 0, false, true)), d2.allowSlidePrev = p2, d2.allowSlideNext = u2, d2.emit("loopFix");
              return;
            }
            let g2 = m2.slidesPerView;
            "auto" === g2 ? g2 = d2.slidesPerViewDynamic() : (g2 = Math.ceil(parseFloat(m2.slidesPerView, 10)), f2 && g2 % 2 == 0 && (g2 += 1));
            let v2 = m2.slidesPerGroupAuto ? g2 : m2.slidesPerGroup, b2 = v2;
            b2 % v2 != 0 && (b2 += v2 - b2 % v2), d2.loopedSlides = b2 += m2.loopAdditionalSlides;
            let w2 = d2.grid && m2.grid && m2.grid.rows > 1;
            c2.length < g2 + b2 ? (0, o.t)(
              "Swiper Loop Warning: The number of slides is not enough for loop mode, it will be disabled and not function properly. You need to add more slides (or make duplicates) or lower the values of slidesPerView and slidesPerGroup parameters"
            ) : w2 && "row" === m2.grid.fill && (0, o.t)("Swiper Loop Warning: Loop mode is not compatible with grid.fill = `row`");
            let y2 = [], S2 = [], T2 = d2.activeIndex;
            void 0 === a2 ? a2 = d2.getSlideIndex(c2.filter((e3) => e3.classList.contains(m2.slideActiveClass))[0]) : T2 = a2;
            let E2 = "next" === s2 || !s2, x2 = "prev" === s2 || !s2, C2 = 0, M2 = 0, P2 = w2 ? Math.ceil(c2.length / m2.grid.rows) : c2.length, k2 = (w2 ? c2[a2].column : a2) + (f2 && void 0 === r2 ? -g2 / 2 + 0.5 : 0);
            if (k2 < b2) {
              C2 = Math.max(b2 - k2, v2);
              for (let e3 = 0; e3 < b2 - k2; e3 += 1) {
                let t3 = e3 - Math.floor(e3 / P2) * P2;
                if (w2) {
                  let e4 = P2 - t3 - 1;
                  for (let t4 = c2.length - 1; t4 >= 0; t4 -= 1) c2[t4].column === e4 && y2.push(t4);
                } else y2.push(P2 - t3 - 1);
              }
            } else if (k2 + g2 > P2 - b2) {
              M2 = Math.max(k2 - (P2 - 2 * b2), v2);
              for (let e3 = 0; e3 < M2; e3 += 1) {
                let t3 = e3 - Math.floor(e3 / P2) * P2;
                w2 ? c2.forEach((e4, i3) => {
                  e4.column === t3 && S2.push(i3);
                }) : S2.push(t3);
              }
            }
            if (d2.__preventObserver__ = true, requestAnimationFrame(() => {
              d2.__preventObserver__ = false;
            }), x2 && y2.forEach((e3) => {
              c2[e3].swiperLoopMoveDOM = true, h2.prepend(c2[e3]), c2[e3].swiperLoopMoveDOM = false;
            }), E2 && S2.forEach((e3) => {
              c2[e3].swiperLoopMoveDOM = true, h2.append(c2[e3]), c2[e3].swiperLoopMoveDOM = false;
            }), d2.recalcSlides(), "auto" === m2.slidesPerView ? d2.updateSlides() : w2 && (y2.length > 0 && x2 || S2.length > 0 && E2) && d2.slides.forEach((e3, t3) => {
              d2.grid.updateSlide(t3, e3, d2.slides);
            }), m2.watchSlidesProgress && d2.updateSlidesOffset(), i2) {
              if (y2.length > 0 && x2) {
                if (void 0 === t2) {
                  let e3 = d2.slidesGrid[T2], t3 = d2.slidesGrid[T2 + C2] - e3;
                  n2 ? d2.setTranslate(d2.translate - t3) : (d2.slideTo(T2 + Math.ceil(C2), 0, false, true), r2 && (d2.touchEventsData.startTranslate = d2.touchEventsData.startTranslate - t3, d2.touchEventsData.currentTranslate = d2.touchEventsData.currentTranslate - t3));
                } else if (r2) {
                  let e3 = w2 ? y2.length / m2.grid.rows : y2.length;
                  d2.slideTo(d2.activeIndex + e3, 0, false, true), d2.touchEventsData.currentTranslate = d2.translate;
                }
              } else if (S2.length > 0 && E2)
                if (void 0 === t2) {
                  let e3 = d2.slidesGrid[T2], t3 = d2.slidesGrid[T2 - M2] - e3;
                  n2 ? d2.setTranslate(d2.translate - t3) : (d2.slideTo(T2 - M2, 0, false, true), r2 && (d2.touchEventsData.startTranslate = d2.touchEventsData.startTranslate - t3, d2.touchEventsData.currentTranslate = d2.touchEventsData.currentTranslate - t3));
                } else {
                  let e3 = w2 ? S2.length / m2.grid.rows : S2.length;
                  d2.slideTo(d2.activeIndex - e3, 0, false, true);
                }
            }
            if (d2.allowSlidePrev = p2, d2.allowSlideNext = u2, d2.controller && d2.controller.control && !l2) {
              let e3 = { slideRealIndex: t2, direction: s2, setTranslate: r2, activeSlideIndex: a2, byController: true };
              Array.isArray(d2.controller.control) ? d2.controller.control.forEach((t3) => {
                !t3.destroyed && t3.params.loop && t3.loopFix({ ...e3, slideTo: t3.params.slidesPerView === m2.slidesPerView && i2 });
              }) : d2.controller.control instanceof d2.constructor && d2.controller.control.params.loop && d2.controller.control.loopFix({
                ...e3,
                slideTo: d2.controller.control.params.slidesPerView === m2.slidesPerView && i2
              });
            }
            d2.emit("loopFix");
          },
          loopDestroy: function() {
            let { params: e2, slidesEl: t2 } = this;
            if (!e2.loop || this.virtual && this.params.virtual.enabled) return;
            this.recalcSlides();
            let i2 = [];
            this.slides.forEach((e3) => {
              i2[void 0 === e3.swiperSlideIndex ? +e3.getAttribute("data-swiper-slide-index") : e3.swiperSlideIndex] = e3;
            }), this.slides.forEach((e3) => {
              e3.removeAttribute("data-swiper-slide-index");
            }), i2.forEach((e3) => {
              t2.append(e3);
            }), this.recalcSlides(), this.slideTo(this.realIndex, 0);
          }
        },
        grabCursor: {
          setGrabCursor: function(e2) {
            let t2 = this;
            if (!t2.params.simulateTouch || t2.params.watchOverflow && t2.isLocked || t2.params.cssMode) return;
            let i2 = "container" === t2.params.touchEventsTarget ? t2.el : t2.wrapperEl;
            t2.isElement && (t2.__preventObserver__ = true), i2.style.cursor = "move", i2.style.cursor = e2 ? "grabbing" : "grab", t2.isElement && requestAnimationFrame(() => {
              t2.__preventObserver__ = false;
            });
          },
          unsetGrabCursor: function() {
            let e2 = this;
            e2.params.watchOverflow && e2.isLocked || e2.params.cssMode || (e2.isElement && (e2.__preventObserver__ = true), e2["container" === e2.params.touchEventsTarget ? "el" : "wrapperEl"].style.cursor = "", e2.isElement && requestAnimationFrame(() => {
              e2.__preventObserver__ = false;
            }));
          }
        },
        events: {
          attachEvents: function() {
            let { params: e2 } = this;
            this.onTouchStart = g.bind(this), this.onTouchMove = v.bind(this), this.onTouchEnd = b.bind(this), this.onDocumentTouchStart = E.bind(this), e2.cssMode && (this.onScroll = S.bind(this)), this.onClick = y.bind(this), this.onLoad = T.bind(this), x(this, "on");
          },
          detachEvents: function() {
            x(this, "off");
          }
        },
        breakpoints: {
          setBreakpoint: function() {
            let e2 = this, { realIndex: t2, initialized: i2, params: s2, el: r2 } = e2, a2 = s2.breakpoints;
            if (!a2 || a2 && 0 === Object.keys(a2).length) return;
            let l2 = e2.getBreakpoint(a2, e2.params.breakpointsBase, e2.el);
            if (!l2 || e2.currentBreakpoint === l2) return;
            let n2 = (l2 in a2 ? a2[l2] : void 0) || e2.originalParams, d2 = C(e2, s2), c2 = C(e2, n2), p2 = s2.enabled;
            d2 && !c2 ? (r2.classList.remove(`${s2.containerModifierClass}grid`, `${s2.containerModifierClass}grid-column`), e2.emitContainerClasses()) : !d2 && c2 && (r2.classList.add(`${s2.containerModifierClass}grid`), (n2.grid.fill && "column" === n2.grid.fill || !n2.grid.fill && "column" === s2.grid.fill) && r2.classList.add(`${s2.containerModifierClass}grid-column`), e2.emitContainerClasses()), ["navigation", "pagination", "scrollbar"].forEach((t3) => {
              if (void 0 === n2[t3]) return;
              let i3 = s2[t3] && s2[t3].enabled, r3 = n2[t3] && n2[t3].enabled;
              i3 && !r3 && e2[t3].disable(), !i3 && r3 && e2[t3].enable();
            });
            let u2 = n2.direction && n2.direction !== s2.direction, h2 = s2.loop && (n2.slidesPerView !== s2.slidesPerView || u2), m2 = s2.loop;
            u2 && i2 && e2.changeDirection(), (0, o.u)(e2.params, n2);
            let f2 = e2.params.enabled, g2 = e2.params.loop;
            Object.assign(e2, {
              allowTouchMove: e2.params.allowTouchMove,
              allowSlideNext: e2.params.allowSlideNext,
              allowSlidePrev: e2.params.allowSlidePrev
            }), p2 && !f2 ? e2.disable() : !p2 && f2 && e2.enable(), e2.currentBreakpoint = l2, e2.emit("_beforeBreakpoint", n2), i2 && (h2 ? (e2.loopDestroy(), e2.loopCreate(t2), e2.updateSlides()) : !m2 && g2 ? (e2.loopCreate(t2), e2.updateSlides()) : m2 && !g2 && e2.loopDestroy()), e2.emit("breakpoint", n2);
          },
          getBreakpoint: function(e2, t2, i2) {
            if (void 0 === t2 && (t2 = "window"), !e2 || "container" === t2 && !i2) return;
            let s2 = false, r2 = (0, n.a)(), a2 = "window" === t2 ? r2.innerHeight : i2.clientHeight, l2 = Object.keys(e2).map(
              (e3) => "string" == typeof e3 && 0 === e3.indexOf("@") ? { value: a2 * parseFloat(e3.substr(1)), point: e3 } : { value: e3, point: e3 }
            );
            l2.sort((e3, t3) => parseInt(e3.value, 10) - parseInt(t3.value, 10));
            for (let e3 = 0; e3 < l2.length; e3 += 1) {
              let { point: a3, value: n2 } = l2[e3];
              "window" === t2 ? r2.matchMedia(`(min-width: ${n2}px)`).matches && (s2 = a3) : n2 <= i2.clientWidth && (s2 = a3);
            }
            return s2 || "max";
          }
        },
        checkOverflow: {
          checkOverflow: function() {
            let { isLocked: e2, params: t2 } = this, { slidesOffsetBefore: i2 } = t2;
            if (i2) {
              let e3 = this.slides.length - 1, t3 = this.slidesGrid[e3] + this.slidesSizesGrid[e3] + 2 * i2;
              this.isLocked = this.size > t3;
            } else this.isLocked = 1 === this.snapGrid.length;
            true === t2.allowSlideNext && (this.allowSlideNext = !this.isLocked), true === t2.allowSlidePrev && (this.allowSlidePrev = !this.isLocked), e2 && e2 !== this.isLocked && (this.isEnd = false), e2 !== this.isLocked && this.emit(this.isLocked ? "lock" : "unlock");
          }
        },
        classes: {
          addClasses: function() {
            let { classNames: e2, params: t2, rtl: i2, el: s2, device: r2 } = this, a2 = (function(e3, t3) {
              let i3 = [];
              return e3.forEach((e4) => {
                "object" == typeof e4 ? Object.keys(e4).forEach((s3) => {
                  e4[s3] && i3.push(t3 + s3);
                }) : "string" == typeof e4 && i3.push(t3 + e4);
              }), i3;
            })(
              [
                "initialized",
                t2.direction,
                { "free-mode": this.params.freeMode && t2.freeMode.enabled },
                { autoheight: t2.autoHeight },
                { rtl: i2 },
                { grid: t2.grid && t2.grid.rows > 1 },
                { "grid-column": t2.grid && t2.grid.rows > 1 && "column" === t2.grid.fill },
                { android: r2.android },
                { ios: r2.ios },
                { "css-mode": t2.cssMode },
                { centered: t2.cssMode && t2.centeredSlides },
                { "watch-progress": t2.watchSlidesProgress }
              ],
              t2.containerModifierClass
            );
            e2.push(...a2), s2.classList.add(...e2), this.emitContainerClasses();
          },
          removeClasses: function() {
            let { el: e2, classNames: t2 } = this;
            e2.classList.remove(...t2), this.emitContainerClasses();
          }
        }
      }, k = {};
      class L {
        constructor() {
          let e2, t2;
          for (var i2 = arguments.length, s2 = Array(i2), r2 = 0; r2 < i2; r2++) s2[r2] = arguments[r2];
          1 === s2.length && s2[0].constructor && "Object" === Object.prototype.toString.call(s2[0]).slice(8, -1) ? t2 = s2[0] : [e2, t2] = s2, t2 || (t2 = {}), t2 = (0, o.u)({}, t2), e2 && !t2.el && (t2.el = e2);
          let l2 = (0, n.g)();
          if (t2.el && "string" == typeof t2.el && l2.querySelectorAll(t2.el).length > 1) {
            let e3 = [];
            return l2.querySelectorAll(t2.el).forEach((i3) => {
              let s3 = (0, o.u)({}, t2, { el: i3 });
              e3.push(new L(s3));
            }), e3;
          }
          let p2 = this;
          p2.__swiper__ = true, p2.support = d(), p2.device = c({ userAgent: t2.userAgent }), a || (a = (function() {
            let e3 = (0, n.a)(), t3 = c(), i3 = false;
            function s3() {
              let t4 = e3.navigator.userAgent.toLowerCase();
              return t4.indexOf("safari") >= 0 && 0 > t4.indexOf("chrome") && 0 > t4.indexOf("android");
            }
            if (s3()) {
              let t4 = String(e3.navigator.userAgent);
              if (t4.includes("Version/")) {
                let [e4, s4] = t4.split("Version/")[1].split(" ")[0].split(".").map((e5) => Number(e5));
                i3 = e4 < 16 || 16 === e4 && s4 < 2;
              }
            }
            let r3 = /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(e3.navigator.userAgent), a2 = s3(), l3 = a2 || r3 && t3.ios;
            return { isSafari: i3 || a2, needPerspectiveFix: i3, need3dFix: l3, isWebView: r3 };
          })()), p2.browser = a, p2.eventsListeners = {}, p2.eventsAnyListeners = [], p2.modules = [...p2.__modules__], t2.modules && Array.isArray(t2.modules) && p2.modules.push(...t2.modules);
          let u2 = {};
          p2.modules.forEach((e3) => {
            e3({
              params: t2,
              swiper: p2,
              extendParams: /* @__PURE__ */ (function(e4, t3) {
                return function(i3) {
                  void 0 === i3 && (i3 = {});
                  let s3 = Object.keys(i3)[0], r3 = i3[s3];
                  return "object" != typeof r3 || null === r3 ? void (0, o.u)(t3, i3) : (true === e4[s3] && (e4[s3] = { enabled: true }), "navigation" === s3 && e4[s3] && e4[s3].enabled && !e4[s3].prevEl && !e4[s3].nextEl && (e4[s3].auto = true), ["pagination", "scrollbar"].indexOf(s3) >= 0 && e4[s3] && e4[s3].enabled && !e4[s3].el && (e4[s3].auto = true), s3 in e4 && "enabled" in r3) ? void ("object" == typeof e4[s3] && !("enabled" in e4[s3]) && (e4[s3].enabled = true), !e4[s3] && (e4[s3] = { enabled: false }), (0, o.u)(t3, i3)) : void (0, o.u)(t3, i3);
                };
              })(t2, u2),
              on: p2.on.bind(p2),
              once: p2.once.bind(p2),
              off: p2.off.bind(p2),
              emit: p2.emit.bind(p2)
            });
          });
          let h2 = (0, o.u)({}, M, u2);
          return p2.params = (0, o.u)({}, h2, k, t2), p2.originalParams = (0, o.u)({}, p2.params), p2.passedParams = (0, o.u)({}, t2), p2.params && p2.params.on && Object.keys(p2.params.on).forEach((e3) => {
            p2.on(e3, p2.params.on[e3]);
          }), p2.params && p2.params.onAny && p2.onAny(p2.params.onAny), Object.assign(p2, {
            enabled: p2.params.enabled,
            el: e2,
            classNames: [],
            slides: [],
            slidesGrid: [],
            snapGrid: [],
            slidesSizesGrid: [],
            isHorizontal: () => "horizontal" === p2.params.direction,
            isVertical: () => "vertical" === p2.params.direction,
            activeIndex: 0,
            realIndex: 0,
            isBeginning: true,
            isEnd: false,
            translate: 0,
            previousTranslate: 0,
            progress: 0,
            velocity: 0,
            animating: false,
            cssOverflowAdjustment() {
              return 8388608 * Math.trunc(this.translate / 8388608);
            },
            allowSlideNext: p2.params.allowSlideNext,
            allowSlidePrev: p2.params.allowSlidePrev,
            touchEventsData: {
              isTouched: void 0,
              isMoved: void 0,
              allowTouchCallbacks: void 0,
              touchStartTime: void 0,
              isScrolling: void 0,
              currentTranslate: void 0,
              startTranslate: void 0,
              allowThresholdMove: void 0,
              focusableElements: p2.params.focusableElements,
              lastClickTime: 0,
              clickTimeout: void 0,
              velocities: [],
              allowMomentumBounce: void 0,
              startMoving: void 0,
              pointerId: null,
              touchId: null
            },
            allowClick: true,
            allowTouchMove: p2.params.allowTouchMove,
            touches: { startX: 0, startY: 0, currentX: 0, currentY: 0, diff: 0 },
            imagesToLoad: [],
            imagesLoaded: 0
          }), p2.emit("_swiper"), p2.params.init && p2.init(), p2;
        }
        getDirectionLabel(e2) {
          return this.isHorizontal() ? e2 : {
            width: "height",
            "margin-top": "margin-left",
            "margin-bottom ": "margin-right",
            "margin-left": "margin-top",
            "margin-right": "margin-bottom",
            "padding-left": "padding-top",
            "padding-right": "padding-bottom",
            marginRight: "marginBottom"
          }[e2];
        }
        getSlideIndex(e2) {
          let { slidesEl: t2, params: i2 } = this, s2 = (0, o.e)(t2, `.${i2.slideClass}, swiper-slide`), r2 = (0, o.h)(s2[0]);
          return (0, o.h)(e2) - r2;
        }
        getSlideIndexByData(e2) {
          return this.getSlideIndex(this.slides.filter((t2) => +t2.getAttribute("data-swiper-slide-index") === e2)[0]);
        }
        recalcSlides() {
          let { slidesEl: e2, params: t2 } = this;
          this.slides = (0, o.e)(e2, `.${t2.slideClass}, swiper-slide`);
        }
        enable() {
          this.enabled || (this.enabled = true, this.params.grabCursor && this.setGrabCursor(), this.emit("enable"));
        }
        disable() {
          this.enabled && (this.enabled = false, this.params.grabCursor && this.unsetGrabCursor(), this.emit("disable"));
        }
        setProgress(e2, t2) {
          e2 = Math.min(Math.max(e2, 0), 1);
          let i2 = this.minTranslate(), s2 = (this.maxTranslate() - i2) * e2 + i2;
          this.translateTo(s2, void 0 === t2 ? 0 : t2), this.updateActiveIndex(), this.updateSlidesClasses();
        }
        emitContainerClasses() {
          let e2 = this;
          if (!e2.params._emitClasses || !e2.el) return;
          let t2 = e2.el.className.split(" ").filter((t3) => 0 === t3.indexOf("swiper") || 0 === t3.indexOf(e2.params.containerModifierClass));
          e2.emit("_containerClasses", t2.join(" "));
        }
        getSlideClasses(e2) {
          let t2 = this;
          return t2.destroyed ? "" : e2.className.split(" ").filter((e3) => 0 === e3.indexOf("swiper-slide") || 0 === e3.indexOf(t2.params.slideClass)).join(" ");
        }
        emitSlidesClasses() {
          let e2 = this;
          if (!e2.params._emitClasses || !e2.el) return;
          let t2 = [];
          e2.slides.forEach((i2) => {
            let s2 = e2.getSlideClasses(i2);
            t2.push({ slideEl: i2, classNames: s2 }), e2.emit("_slideClass", i2, s2);
          }), e2.emit("_slideClasses", t2);
        }
        slidesPerViewDynamic(e2, t2) {
          void 0 === e2 && (e2 = "current"), void 0 === t2 && (t2 = false);
          let { params: i2, slides: s2, slidesGrid: r2, slidesSizesGrid: a2, size: l2, activeIndex: n2 } = this, o2 = 1;
          if ("number" == typeof i2.slidesPerView) return i2.slidesPerView;
          if (i2.centeredSlides) {
            let e3, t3 = s2[n2] ? Math.ceil(s2[n2].swiperSlideSize) : 0;
            for (let i3 = n2 + 1; i3 < s2.length; i3 += 1)
              s2[i3] && !e3 && (t3 += Math.ceil(s2[i3].swiperSlideSize), o2 += 1, t3 > l2 && (e3 = true));
            for (let i3 = n2 - 1; i3 >= 0; i3 -= 1)
              s2[i3] && !e3 && (t3 += s2[i3].swiperSlideSize, o2 += 1, t3 > l2 && (e3 = true));
          } else if ("current" === e2)
            for (let e3 = n2 + 1; e3 < s2.length; e3 += 1) (t2 ? r2[e3] + a2[e3] - r2[n2] < l2 : r2[e3] - r2[n2] < l2) && (o2 += 1);
          else for (let e3 = n2 - 1; e3 >= 0; e3 -= 1) r2[n2] - r2[e3] < l2 && (o2 += 1);
          return o2;
        }
        update() {
          let e2, t2 = this;
          if (!t2 || t2.destroyed) return;
          let { snapGrid: i2, params: s2 } = t2;
          function r2() {
            let e3 = Math.min(
              Math.max(t2.rtlTranslate ? -1 * t2.translate : t2.translate, t2.maxTranslate()),
              t2.minTranslate()
            );
            t2.setTranslate(e3), t2.updateActiveIndex(), t2.updateSlidesClasses();
          }
          if (s2.breakpoints && t2.setBreakpoint(), [...t2.el.querySelectorAll('[loading="lazy"]')].forEach((e3) => {
            e3.complete && p(t2, e3);
          }), t2.updateSize(), t2.updateSlides(), t2.updateProgress(), t2.updateSlidesClasses(), s2.freeMode && s2.freeMode.enabled && !s2.cssMode)
            r2(), s2.autoHeight && t2.updateAutoHeight();
          else {
            if (("auto" === s2.slidesPerView || s2.slidesPerView > 1) && t2.isEnd && !s2.centeredSlides) {
              let i3 = t2.virtual && s2.virtual.enabled ? t2.virtual.slides : t2.slides;
              e2 = t2.slideTo(i3.length - 1, 0, false, true);
            } else e2 = t2.slideTo(t2.activeIndex, 0, false, true);
            e2 || r2();
          }
          s2.watchOverflow && i2 !== t2.snapGrid && t2.checkOverflow(), t2.emit("update");
        }
        changeDirection(e2, t2) {
          void 0 === t2 && (t2 = true);
          let i2 = this.params.direction;
          return e2 || (e2 = "horizontal" === i2 ? "vertical" : "horizontal"), e2 === i2 || "horizontal" !== e2 && "vertical" !== e2 || (this.el.classList.remove(`${this.params.containerModifierClass}${i2}`), this.el.classList.add(`${this.params.containerModifierClass}${e2}`), this.emitContainerClasses(), this.params.direction = e2, this.slides.forEach((t3) => {
            "vertical" === e2 ? t3.style.width = "" : t3.style.height = "";
          }), this.emit("changeDirection"), t2 && this.update()), this;
        }
        changeLanguageDirection(e2) {
          (!this.rtl || "rtl" !== e2) && (this.rtl || "ltr" !== e2) && (this.rtl = "rtl" === e2, this.rtlTranslate = "horizontal" === this.params.direction && this.rtl, this.rtl ? (this.el.classList.add(`${this.params.containerModifierClass}rtl`), this.el.dir = "rtl") : (this.el.classList.remove(`${this.params.containerModifierClass}rtl`), this.el.dir = "ltr"), this.update());
        }
        mount(e2) {
          let t2 = this;
          if (t2.mounted) return true;
          let i2 = e2 || t2.params.el;
          if ("string" == typeof i2 && (i2 = document.querySelector(i2)), !i2) return false;
          i2.swiper = t2, i2.parentNode && i2.parentNode.host && i2.parentNode.host.nodeName === t2.params.swiperElementNodeName.toUpperCase() && (t2.isElement = true);
          let s2 = () => `.${(t2.params.wrapperClass || "").trim().split(" ").join(".")}`, r2 = i2 && i2.shadowRoot && i2.shadowRoot.querySelector ? i2.shadowRoot.querySelector(s2()) : (0, o.e)(i2, s2())[0];
          return !r2 && t2.params.createElements && (r2 = (0, o.c)("div", t2.params.wrapperClass), i2.append(r2), (0, o.e)(i2, `.${t2.params.slideClass}`).forEach((e3) => {
            r2.append(e3);
          })), Object.assign(t2, {
            el: i2,
            wrapperEl: r2,
            slidesEl: t2.isElement && !i2.parentNode.host.slideSlots ? i2.parentNode.host : r2,
            hostEl: t2.isElement ? i2.parentNode.host : i2,
            mounted: true,
            rtl: "rtl" === i2.dir.toLowerCase() || "rtl" === (0, o.o)(i2, "direction"),
            rtlTranslate: "horizontal" === t2.params.direction && ("rtl" === i2.dir.toLowerCase() || "rtl" === (0, o.o)(i2, "direction")),
            wrongRTL: "-webkit-box" === (0, o.o)(r2, "display")
          }), true;
        }
        init(e2) {
          let t2 = this;
          if (t2.initialized || false === t2.mount(e2)) return t2;
          t2.emit("beforeInit"), t2.params.breakpoints && t2.setBreakpoint(), t2.addClasses(), t2.updateSize(), t2.updateSlides(), t2.params.watchOverflow && t2.checkOverflow(), t2.params.grabCursor && t2.enabled && t2.setGrabCursor(), t2.params.loop && t2.virtual && t2.params.virtual.enabled ? t2.slideTo(t2.params.initialSlide + t2.virtual.slidesBefore, 0, t2.params.runCallbacksOnInit, false, true) : t2.slideTo(t2.params.initialSlide, 0, t2.params.runCallbacksOnInit, false, true), t2.params.loop && t2.loopCreate(), t2.attachEvents();
          let i2 = [...t2.el.querySelectorAll('[loading="lazy"]')];
          return t2.isElement && i2.push(...t2.hostEl.querySelectorAll('[loading="lazy"]')), i2.forEach((e3) => {
            e3.complete ? p(t2, e3) : e3.addEventListener("load", (e4) => {
              p(t2, e4.target);
            });
          }), h(t2), t2.initialized = true, h(t2), t2.emit("init"), t2.emit("afterInit"), t2;
        }
        destroy(e2, t2) {
          void 0 === e2 && (e2 = true), void 0 === t2 && (t2 = true);
          let i2 = this, { params: s2, el: r2, wrapperEl: a2, slides: l2 } = i2;
          return void 0 === i2.params || i2.destroyed || (i2.emit("beforeDestroy"), i2.initialized = false, i2.detachEvents(), s2.loop && i2.loopDestroy(), t2 && (i2.removeClasses(), r2.removeAttribute("style"), a2.removeAttribute("style"), l2 && l2.length && l2.forEach((e3) => {
            e3.classList.remove(
              s2.slideVisibleClass,
              s2.slideFullyVisibleClass,
              s2.slideActiveClass,
              s2.slideNextClass,
              s2.slidePrevClass
            ), e3.removeAttribute("style"), e3.removeAttribute("data-swiper-slide-index");
          })), i2.emit("destroy"), Object.keys(i2.eventsListeners).forEach((e3) => {
            i2.off(e3);
          }), false !== e2 && (i2.el.swiper = null, (0, o.v)(i2)), i2.destroyed = true), null;
        }
        static extendDefaults(e2) {
          (0, o.u)(k, e2);
        }
        static get extendedDefaults() {
          return k;
        }
        static get defaults() {
          return M;
        }
        static installModule(e2) {
          L.prototype.__modules__ || (L.prototype.__modules__ = []);
          let t2 = L.prototype.__modules__;
          "function" == typeof e2 && 0 > t2.indexOf(e2) && t2.push(e2);
        }
        static use(e2) {
          return Array.isArray(e2) ? e2.forEach((e3) => L.installModule(e3)) : L.installModule(e2), L;
        }
      }
      Object.keys(P).forEach((e2) => {
        Object.keys(P[e2]).forEach((t2) => {
          L.prototype[t2] = P[e2][t2];
        });
      }), L.use([
        function(e2) {
          let { swiper: t2, on: i2, emit: s2 } = e2, r2 = (0, n.a)(), a2 = null, l2 = null, o2 = () => {
            t2 && !t2.destroyed && t2.initialized && (s2("beforeResize"), s2("resize"));
          }, d2 = () => {
            t2 && !t2.destroyed && t2.initialized && s2("orientationchange");
          };
          i2("init", () => {
            if (t2.params.resizeObserver && void 0 !== r2.ResizeObserver)
              return void (t2 && !t2.destroyed && t2.initialized && (a2 = new ResizeObserver((e3) => {
                l2 = r2.requestAnimationFrame(() => {
                  let { width: i3, height: s3 } = t2, r3 = i3, a3 = s3;
                  e3.forEach((e4) => {
                    let { contentBoxSize: i4, contentRect: s4, target: l3 } = e4;
                    l3 && l3 !== t2.el || (r3 = s4 ? s4.width : (i4[0] || i4).inlineSize, a3 = s4 ? s4.height : (i4[0] || i4).blockSize);
                  }), (r3 !== i3 || a3 !== s3) && o2();
                });
              })).observe(t2.el));
            r2.addEventListener("resize", o2), r2.addEventListener("orientationchange", d2);
          }), i2("destroy", () => {
            l2 && r2.cancelAnimationFrame(l2), a2 && a2.unobserve && t2.el && (a2.unobserve(t2.el), a2 = null), r2.removeEventListener("resize", o2), r2.removeEventListener("orientationchange", d2);
          });
        },
        function(e2) {
          let { swiper: t2, extendParams: i2, on: s2, emit: r2 } = e2, a2 = [], l2 = (0, n.a)(), d2 = function(e3, i3) {
            void 0 === i3 && (i3 = {});
            let s3 = new (l2.MutationObserver || l2.WebkitMutationObserver)((e4) => {
              if (t2.__preventObserver__) return;
              if (1 === e4.length) return void r2("observerUpdate", e4[0]);
              let i4 = function() {
                r2("observerUpdate", e4[0]);
              };
              l2.requestAnimationFrame ? l2.requestAnimationFrame(i4) : l2.setTimeout(i4, 0);
            });
            s3.observe(e3, {
              attributes: void 0 === i3.attributes || i3.attributes,
              childList: void 0 === i3.childList || i3.childList,
              characterData: void 0 === i3.characterData || i3.characterData
            }), a2.push(s3);
          };
          i2({ observer: false, observeParents: false, observeSlideChildren: false }), s2("init", () => {
            if (t2.params.observer) {
              if (t2.params.observeParents) {
                let e3 = (0, o.a)(t2.hostEl);
                for (let t3 = 0; t3 < e3.length; t3 += 1) d2(e3[t3]);
              }
              d2(t2.hostEl, { childList: t2.params.observeSlideChildren }), d2(t2.wrapperEl, { attributes: false });
            }
          }), s2("destroy", () => {
            a2.forEach((e3) => {
              e3.disconnect();
            }), a2.splice(0, a2.length);
          });
        }
      ]);
      let O = [
        "eventsPrefix",
        "injectStyles",
        "injectStylesUrls",
        "modules",
        "init",
        "_direction",
        "oneWayMovement",
        "swiperElementNodeName",
        "touchEventsTarget",
        "initialSlide",
        "_speed",
        "cssMode",
        "updateOnWindowResize",
        "resizeObserver",
        "nested",
        "focusableElements",
        "_enabled",
        "_width",
        "_height",
        "preventInteractionOnTransition",
        "userAgent",
        "url",
        "_edgeSwipeDetection",
        "_edgeSwipeThreshold",
        "_freeMode",
        "_autoHeight",
        "setWrapperSize",
        "virtualTranslate",
        "_effect",
        "breakpoints",
        "breakpointsBase",
        "_spaceBetween",
        "_slidesPerView",
        "maxBackfaceHiddenSlides",
        "_grid",
        "_slidesPerGroup",
        "_slidesPerGroupSkip",
        "_slidesPerGroupAuto",
        "_centeredSlides",
        "_centeredSlidesBounds",
        "_slidesOffsetBefore",
        "_slidesOffsetAfter",
        "normalizeSlideIndex",
        "_centerInsufficientSlides",
        "_watchOverflow",
        "roundLengths",
        "touchRatio",
        "touchAngle",
        "simulateTouch",
        "_shortSwipes",
        "_longSwipes",
        "longSwipesRatio",
        "longSwipesMs",
        "_followFinger",
        "allowTouchMove",
        "_threshold",
        "touchMoveStopPropagation",
        "touchStartPreventDefault",
        "touchStartForcePreventDefault",
        "touchReleaseOnEdges",
        "uniqueNavElements",
        "_resistance",
        "_resistanceRatio",
        "_watchSlidesProgress",
        "_grabCursor",
        "preventClicks",
        "preventClicksPropagation",
        "_slideToClickedSlide",
        "_loop",
        "loopAdditionalSlides",
        "loopAddBlankSlides",
        "loopPreventsSliding",
        "_rewind",
        "_allowSlidePrev",
        "_allowSlideNext",
        "_swipeHandler",
        "_noSwiping",
        "noSwipingClass",
        "noSwipingSelector",
        "passiveListeners",
        "containerModifierClass",
        "slideClass",
        "slideActiveClass",
        "slideVisibleClass",
        "slideFullyVisibleClass",
        "slideNextClass",
        "slidePrevClass",
        "slideBlankClass",
        "wrapperClass",
        "lazyPreloaderClass",
        "lazyPreloadPrevNext",
        "runCallbacksOnInit",
        "observer",
        "observeParents",
        "observeSlideChildren",
        "a11y",
        "_autoplay",
        "_controller",
        "coverflowEffect",
        "cubeEffect",
        "fadeEffect",
        "flipEffect",
        "creativeEffect",
        "cardsEffect",
        "hashNavigation",
        "history",
        "keyboard",
        "mousewheel",
        "_navigation",
        "_pagination",
        "parallax",
        "_scrollbar",
        "_thumbs",
        "virtual",
        "zoom",
        "control"
      ];
      function A(e2) {
        return "object" == typeof e2 && null !== e2 && e2.constructor && "Object" === Object.prototype.toString.call(e2).slice(8, -1) && !e2.__swiper__;
      }
      function _(e2, t2) {
        let i2 = ["__proto__", "constructor", "prototype"];
        Object.keys(t2).filter((e3) => 0 > i2.indexOf(e3)).forEach((i3) => {
          void 0 === e2[i3] ? e2[i3] = t2[i3] : A(t2[i3]) && A(e2[i3]) && Object.keys(t2[i3]).length > 0 ? t2[i3].__swiper__ ? e2[i3] = t2[i3] : _(e2[i3], t2[i3]) : e2[i3] = t2[i3];
        });
      }
      function I(e2) {
        return void 0 === e2 && (e2 = {}), e2.navigation && void 0 === e2.navigation.nextEl && void 0 === e2.navigation.prevEl;
      }
      function z(e2) {
        return void 0 === e2 && (e2 = {}), e2.pagination && void 0 === e2.pagination.el;
      }
      function D(e2) {
        return void 0 === e2 && (e2 = {}), e2.scrollbar && void 0 === e2.scrollbar.el;
      }
      function $(e2) {
        void 0 === e2 && (e2 = "");
        let t2 = e2.split(" ").map((e3) => e3.trim()).filter((e3) => !!e3), i2 = [];
        return t2.forEach((e3) => {
          0 > i2.indexOf(e3) && i2.push(e3);
        }), i2.join(" ");
      }
      function N() {
        return (N = Object.assign ? Object.assign.bind() : function(e2) {
          for (var t2 = 1; t2 < arguments.length; t2++) {
            var i2 = arguments[t2];
            for (var s2 in i2) Object.prototype.hasOwnProperty.call(i2, s2) && (e2[s2] = i2[s2]);
          }
          return e2;
        }).apply(this, arguments);
      }
      function B(e2) {
        return e2.type && e2.type.displayName && e2.type.displayName.includes("SwiperSlide");
      }
      function G(e2, t2) {
        return "undefined" == typeof window ? (0, l.useEffect)(e2, t2) : (0, l.useLayoutEffect)(e2, t2);
      }
      let j = (0, l.createContext)(null), V = () => (0, l.useContext)(j), F = (0, l.createContext)(null), R = () => (0, l.useContext)(F), H = (0, l.forwardRef)(function(e2, t2) {
        var i2;
        let {
          className: s2,
          tag: r2 = "div",
          wrapperTag: a2 = "div",
          children: n2,
          onSwiper: o2,
          ...d2
        } = void 0 === e2 ? {} : e2, c2 = false, [p2, u2] = (0, l.useState)("swiper"), [h2, m2] = (0, l.useState)(null), [f2, g2] = (0, l.useState)(false), v2 = (0, l.useRef)(false), b2 = (0, l.useRef)(null), w2 = (0, l.useRef)(null), y2 = (0, l.useRef)(null), S2 = (0, l.useRef)(null), T2 = (0, l.useRef)(null), E2 = (0, l.useRef)(null), x2 = (0, l.useRef)(null), C2 = (0, l.useRef)(null), {
          params: P2,
          passedParams: k2,
          rest: j2,
          events: V2
        } = (function(e3, t3) {
          void 0 === e3 && (e3 = {}), void 0 === t3 && (t3 = true);
          let i3 = { on: {} }, s3 = {}, r3 = {};
          _(i3, M), i3._emitClasses = true, i3.init = false;
          let a3 = {}, l2 = O.map((e4) => e4.replace(/_/, ""));
          return Object.keys(Object.assign({}, e3)).forEach((n3) => {
            void 0 !== e3[n3] && (l2.indexOf(n3) >= 0 ? A(e3[n3]) ? (i3[n3] = {}, r3[n3] = {}, _(i3[n3], e3[n3]), _(r3[n3], e3[n3])) : (i3[n3] = e3[n3], r3[n3] = e3[n3]) : 0 === n3.search(/on[A-Z]/) && "function" == typeof e3[n3] ? t3 ? s3[`${n3[2].toLowerCase()}${n3.substr(3)}`] = e3[n3] : i3.on[`${n3[2].toLowerCase()}${n3.substr(3)}`] = e3[n3] : a3[n3] = e3[n3]);
          }), ["navigation", "pagination", "scrollbar"].forEach((e4) => {
            true === i3[e4] && (i3[e4] = {}), false === i3[e4] && delete i3[e4];
          }), { params: i3, passedParams: r3, rest: a3, events: s3 };
        })(d2), { slides: R2, slots: H2 } = (function(e3) {
          let t3 = [], i3 = { "container-start": [], "container-end": [], "wrapper-start": [], "wrapper-end": [] };
          return l.Children.toArray(e3).forEach((e4) => {
            if (B(e4)) t3.push(e4);
            else if (e4.props && e4.props.slot && i3[e4.props.slot]) i3[e4.props.slot].push(e4);
            else if (e4.props && e4.props.children) {
              let s3 = (function e5(t4) {
                let i4 = [];
                return l.Children.toArray(t4).forEach((t5) => {
                  B(t5) ? i4.push(t5) : t5.props && t5.props.children && e5(t5.props.children).forEach((e6) => i4.push(e6));
                }), i4;
              })(e4.props.children);
              s3.length > 0 ? s3.forEach((e5) => t3.push(e5)) : i3["container-end"].push(e4);
            } else i3["container-end"].push(e4);
          }), { slides: t3, slots: i3 };
        })(n2), q2 = () => {
          g2(!f2);
        };
        Object.assign(P2.on, {
          _containerClasses(e3, t3) {
            u2(t3);
          }
        });
        let Y = () => {
          Object.assign(P2.on, V2), c2 = true;
          let e3 = { ...P2 };
          if (delete e3.wrapperClass, w2.current = new L(e3), w2.current.virtual && w2.current.params.virtual.enabled) {
            w2.current.virtual.slides = R2;
            let e4 = { cache: false, slides: R2, renderExternal: m2, renderExternalUpdate: false };
            _(w2.current.params.virtual, e4), _(w2.current.originalParams.virtual, e4);
          }
        };
        return b2.current || Y(), w2.current && w2.current.on("_beforeBreakpoint", q2), (0, l.useEffect)(() => () => {
          w2.current && w2.current.off("_beforeBreakpoint", q2);
        }), (0, l.useEffect)(() => {
          !v2.current && w2.current && (w2.current.emitSlidesClasses(), v2.current = true);
        }), G(() => {
          if (t2 && (t2.current = b2.current), b2.current)
            return w2.current.destroyed && Y(), !(function(e3, t3) {
              let { el: i3, nextEl: s3, prevEl: r3, paginationEl: a3, scrollbarEl: l2, swiper: n3 } = e3;
              I(t3) && s3 && r3 && (n3.params.navigation.nextEl = s3, n3.originalParams.navigation.nextEl = s3, n3.params.navigation.prevEl = r3, n3.originalParams.navigation.prevEl = r3), z(t3) && a3 && (n3.params.pagination.el = a3, n3.originalParams.pagination.el = a3), D(t3) && l2 && (n3.params.scrollbar.el = l2, n3.originalParams.scrollbar.el = l2), n3.init(i3);
            })(
              {
                el: b2.current,
                nextEl: T2.current,
                prevEl: E2.current,
                paginationEl: x2.current,
                scrollbarEl: C2.current,
                swiper: w2.current
              },
              P2
            ), o2 && !w2.current.destroyed && o2(w2.current), () => {
              w2.current && !w2.current.destroyed && w2.current.destroy(true, false);
            };
        }, []), G(() => {
          !c2 && V2 && w2.current && Object.keys(V2).forEach((e4) => {
            w2.current.on(e4, V2[e4]);
          });
          let e3 = (function(e4, t3, i3, s3, r3) {
            let a3 = [];
            if (!t3) return a3;
            let l2 = (e5) => {
              0 > a3.indexOf(e5) && a3.push(e5);
            };
            if (i3 && s3) {
              let e5 = s3.map(r3), t4 = i3.map(r3);
              e5.join("") !== t4.join("") && l2("children"), s3.length !== i3.length && l2("children");
            }
            return O.filter((e5) => "_" === e5[0]).map((e5) => e5.replace(/_/, "")).forEach((i4) => {
              if (i4 in e4 && i4 in t3)
                if (A(e4[i4]) && A(t3[i4])) {
                  let s4 = Object.keys(e4[i4]), r4 = Object.keys(t3[i4]);
                  s4.length !== r4.length ? l2(i4) : (s4.forEach((s5) => {
                    e4[i4][s5] !== t3[i4][s5] && l2(i4);
                  }), r4.forEach((s5) => {
                    e4[i4][s5] !== t3[i4][s5] && l2(i4);
                  }));
                } else e4[i4] !== t3[i4] && l2(i4);
            }), a3;
          })(k2, y2.current, R2, S2.current, (e4) => e4.key);
          return y2.current = k2, S2.current = R2, e3.length && w2.current && !w2.current.destroyed && (function(e4) {
            let t3, i3, s3, r3, a3, l2, n3, o3, {
              swiper: d3,
              slides: c3,
              passedParams: p3,
              changedParams: u3,
              nextEl: h3,
              prevEl: m3,
              scrollbarEl: f3,
              paginationEl: g3
            } = e4, v3 = u3.filter((e5) => "children" !== e5 && "direction" !== e5 && "wrapperClass" !== e5), { params: b3, pagination: w3, navigation: y3, scrollbar: S3, virtual: T3, thumbs: E3 } = d3;
            u3.includes("thumbs") && p3.thumbs && p3.thumbs.swiper && b3.thumbs && !b3.thumbs.swiper && (t3 = true), u3.includes("controller") && p3.controller && p3.controller.control && b3.controller && !b3.controller.control && (i3 = true), u3.includes("pagination") && p3.pagination && (p3.pagination.el || g3) && (b3.pagination || false === b3.pagination) && w3 && !w3.el && (s3 = true), u3.includes("scrollbar") && p3.scrollbar && (p3.scrollbar.el || f3) && (b3.scrollbar || false === b3.scrollbar) && S3 && !S3.el && (r3 = true), u3.includes("navigation") && p3.navigation && (p3.navigation.prevEl || m3) && (p3.navigation.nextEl || h3) && (b3.navigation || false === b3.navigation) && y3 && !y3.prevEl && !y3.nextEl && (a3 = true);
            let x3 = (e5) => {
              d3[e5] && (d3[e5].destroy(), "navigation" === e5 ? (d3.isElement && (d3[e5].prevEl.remove(), d3[e5].nextEl.remove()), b3[e5].prevEl = void 0, b3[e5].nextEl = void 0, d3[e5].prevEl = void 0, d3[e5].nextEl = void 0) : (d3.isElement && d3[e5].el.remove(), b3[e5].el = void 0, d3[e5].el = void 0));
            };
            u3.includes("loop") && d3.isElement && (b3.loop && !p3.loop ? l2 = true : !b3.loop && p3.loop ? n3 = true : o3 = true), v3.forEach((e5) => {
              if (A(b3[e5]) && A(p3[e5]))
                Object.assign(b3[e5], p3[e5]), ("navigation" === e5 || "pagination" === e5 || "scrollbar" === e5) && "enabled" in p3[e5] && !p3[e5].enabled && x3(e5);
              else {
                let t4 = p3[e5];
                (true === t4 || false === t4) && ("navigation" === e5 || "pagination" === e5 || "scrollbar" === e5) ? false === t4 && x3(e5) : b3[e5] = p3[e5];
              }
            }), v3.includes("controller") && !i3 && d3.controller && d3.controller.control && b3.controller && b3.controller.control && (d3.controller.control = b3.controller.control), u3.includes("children") && c3 && T3 && b3.virtual.enabled ? (T3.slides = c3, T3.update(true)) : u3.includes("virtual") && T3 && b3.virtual.enabled && (c3 && (T3.slides = c3), T3.update(true)), u3.includes("children") && c3 && b3.loop && (o3 = true), t3 && E3.init() && E3.update(true), i3 && (d3.controller.control = b3.controller.control), s3 && (d3.isElement && (!g3 || "string" == typeof g3) && ((g3 = document.createElement("div")).classList.add("swiper-pagination"), g3.part.add("pagination"), d3.el.appendChild(g3)), g3 && (b3.pagination.el = g3), w3.init(), w3.render(), w3.update()), r3 && (d3.isElement && (!f3 || "string" == typeof f3) && ((f3 = document.createElement("div")).classList.add("swiper-scrollbar"), f3.part.add("scrollbar"), d3.el.appendChild(f3)), f3 && (b3.scrollbar.el = f3), S3.init(), S3.updateSize(), S3.setTranslate()), a3 && (d3.isElement && (h3 && "string" != typeof h3 || ((h3 = document.createElement("div")).classList.add("swiper-button-next"), h3.innerHTML = d3.hostEl.constructor.nextButtonSvg, h3.part.add("button-next"), d3.el.appendChild(h3)), m3 && "string" != typeof m3 || ((m3 = document.createElement("div")).classList.add("swiper-button-prev"), m3.innerHTML = d3.hostEl.constructor.prevButtonSvg, m3.part.add("button-prev"), d3.el.appendChild(m3))), h3 && (b3.navigation.nextEl = h3), m3 && (b3.navigation.prevEl = m3), y3.init(), y3.update()), u3.includes("allowSlideNext") && (d3.allowSlideNext = p3.allowSlideNext), u3.includes("allowSlidePrev") && (d3.allowSlidePrev = p3.allowSlidePrev), u3.includes("direction") && d3.changeDirection(p3.direction, false), (l2 || o3) && d3.loopDestroy(), (n3 || o3) && d3.loopCreate(), d3.update();
          })({
            swiper: w2.current,
            slides: R2,
            passedParams: k2,
            changedParams: e3,
            nextEl: T2.current,
            prevEl: E2.current,
            scrollbarEl: C2.current,
            paginationEl: x2.current
          }), () => {
            V2 && w2.current && Object.keys(V2).forEach((e4) => {
              w2.current.off(e4, V2[e4]);
            });
          };
        }), G(() => {
          var e3;
          (e3 = w2.current) && !e3.destroyed && e3.params.virtual && (!e3.params.virtual || e3.params.virtual.enabled) && (e3.updateSlides(), e3.updateProgress(), e3.updateSlidesClasses(), e3.parallax && e3.params.parallax && e3.params.parallax.enabled && e3.parallax.setTranslate());
        }, [h2]), l.createElement(
          r2,
          N({ ref: b2, className: $(`${p2}${s2 ? ` ${s2}` : ""}`) }, j2),
          l.createElement(
            F.Provider,
            { value: w2.current },
            H2["container-start"],
            l.createElement(
              a2,
              {
                className: (void 0 === (i2 = P2.wrapperClass) && (i2 = ""), i2) ? i2.includes("swiper-wrapper") ? i2 : `swiper-wrapper ${i2}` : "swiper-wrapper"
              },
              H2["wrapper-start"],
              P2.virtual ? (function(e3, t3, i3) {
                if (!i3) return null;
                let s3 = (e4) => {
                  let i4 = e4;
                  return e4 < 0 ? i4 = t3.length + e4 : i4 >= t3.length && (i4 -= t3.length), i4;
                }, r3 = e3.isHorizontal() ? { [e3.rtlTranslate ? "right" : "left"]: `${i3.offset}px` } : { top: `${i3.offset}px` }, { from: a3, to: n3 } = i3, o3 = e3.params.loop ? -t3.length : 0, d3 = e3.params.loop ? 2 * t3.length : t3.length, c3 = [];
                for (let e4 = o3; e4 < d3; e4 += 1) e4 >= a3 && e4 <= n3 && c3.push(t3[s3(e4)]);
                return c3.map(
                  (t4, i4) => l.cloneElement(t4, {
                    swiper: e3,
                    style: r3,
                    key: t4.props.virtualIndex || t4.key || `slide-${i4}`
                  })
                );
              })(w2.current, R2, h2) : R2.map((e3, t3) => l.cloneElement(e3, { swiper: w2.current, swiperSlideIndex: t3 })),
              H2["wrapper-end"]
            ),
            I(P2) && l.createElement(
              l.Fragment,
              null,
              l.createElement("div", { ref: E2, className: "swiper-button-prev" }),
              l.createElement("div", { ref: T2, className: "swiper-button-next" })
            ),
            D(P2) && l.createElement("div", { ref: C2, className: "swiper-scrollbar" }),
            z(P2) && l.createElement("div", { ref: x2, className: "swiper-pagination" }),
            H2["container-end"]
          )
        );
      });
      H.displayName = "Swiper";
      let q = (0, l.forwardRef)(function(e2, t2) {
        let {
          tag: i2 = "div",
          children: s2,
          className: r2 = "",
          swiper: a2,
          zoom: n2,
          lazy: o2,
          virtualIndex: d2,
          swiperSlideIndex: c2,
          ...p2
        } = void 0 === e2 ? {} : e2, u2 = (0, l.useRef)(null), [h2, m2] = (0, l.useState)("swiper-slide"), [f2, g2] = (0, l.useState)(false);
        function v2(e3, t3, i3) {
          t3 === u2.current && m2(i3);
        }
        G(() => {
          if (void 0 !== c2 && (u2.current.swiperSlideIndex = c2), t2 && (t2.current = u2.current), u2.current && a2) {
            if (a2.destroyed) {
              "swiper-slide" !== h2 && m2("swiper-slide");
              return;
            }
            return a2.on("_slideClass", v2), () => {
              a2 && a2.off("_slideClass", v2);
            };
          }
        }), G(() => {
          a2 && u2.current && !a2.destroyed && m2(a2.getSlideClasses(u2.current));
        }, [a2]);
        let b2 = {
          isActive: h2.indexOf("swiper-slide-active") >= 0,
          isVisible: h2.indexOf("swiper-slide-visible") >= 0,
          isPrev: h2.indexOf("swiper-slide-prev") >= 0,
          isNext: h2.indexOf("swiper-slide-next") >= 0
        }, w2 = () => "function" == typeof s2 ? s2(b2) : s2;
        return l.createElement(
          i2,
          N(
            {
              ref: u2,
              className: $(`${h2}${r2 ? ` ${r2}` : ""}`),
              "data-swiper-slide-index": d2,
              onLoad: () => {
                g2(true);
              }
            },
            p2
          ),
          n2 && l.createElement(
            j.Provider,
            { value: b2 },
            l.createElement(
              "div",
              { className: "swiper-zoom-container", "data-swiper-zoom": "number" == typeof n2 ? n2 : void 0 },
              w2(),
              o2 && !f2 && l.createElement("div", { className: "swiper-lazy-preloader" })
            )
          ),
          !n2 && l.createElement(
            j.Provider,
            { value: b2 },
            w2(),
            o2 && !f2 && l.createElement("div", { className: "swiper-lazy-preloader" })
          )
        );
      });
      q.displayName = "SwiperSlide";
    },
    83645: (e, t, i) => {
      i.d(t, { default: () => r.a });
      var s = i(36446), r = i.n(s);
    },
    91657: (e, t, i) => {
      i.d(t, { Jq: () => p, U1: () => u, s3: () => a, FJ: () => l, Vx: () => o, dK: () => c });
      var s = i(27854), r = i(8981);
      function a(e2) {
        let { swiper: t2, extendParams: i2, on: a2, emit: l2 } = e2, n2 = (0, s.g)(), o2 = (0, s.a)();
        function d2(e3) {
          if (!t2.enabled) return;
          let { rtlTranslate: i3 } = t2, s2 = e3;
          s2.originalEvent && (s2 = s2.originalEvent);
          let a3 = s2.keyCode || s2.charCode, d3 = t2.params.keyboard.pageUpDown, c3 = d3 && 33 === a3, p3 = d3 && 34 === a3, u2 = 37 === a3, h = 39 === a3, m = 38 === a3, f = 40 === a3;
          if (!t2.allowSlideNext && (t2.isHorizontal() && h || t2.isVertical() && f || p3) || !t2.allowSlidePrev && (t2.isHorizontal() && u2 || t2.isVertical() && m || c3))
            return false;
          if (!s2.shiftKey && !s2.altKey && !s2.ctrlKey && !s2.metaKey && (!n2.activeElement || !n2.activeElement.nodeName || "input" !== n2.activeElement.nodeName.toLowerCase() && "textarea" !== n2.activeElement.nodeName.toLowerCase())) {
            if (t2.params.keyboard.onlyInViewport && (c3 || p3 || u2 || h || m || f)) {
              let e4 = false;
              if ((0, r.a)(t2.el, `.${t2.params.slideClass}, swiper-slide`).length > 0 && 0 === (0, r.a)(t2.el, `.${t2.params.slideActiveClass}`).length)
                return;
              let s3 = t2.el, a4 = s3.clientWidth, l3 = s3.clientHeight, n3 = o2.innerWidth, d4 = o2.innerHeight, c4 = (0, r.b)(s3);
              i3 && (c4.left -= s3.scrollLeft);
              let p4 = [
                [c4.left, c4.top],
                [c4.left + a4, c4.top],
                [c4.left, c4.top + l3],
                [c4.left + a4, c4.top + l3]
              ];
              for (let t3 = 0; t3 < p4.length; t3 += 1) {
                let i4 = p4[t3];
                if (i4[0] >= 0 && i4[0] <= n3 && i4[1] >= 0 && i4[1] <= d4) {
                  if (0 === i4[0] && 0 === i4[1]) continue;
                  e4 = true;
                }
              }
              if (!e4) return;
            }
            t2.isHorizontal() ? ((c3 || p3 || u2 || h) && (s2.preventDefault ? s2.preventDefault() : s2.returnValue = false), ((p3 || h) && !i3 || (c3 || u2) && i3) && t2.slideNext(), ((c3 || u2) && !i3 || (p3 || h) && i3) && t2.slidePrev()) : ((c3 || p3 || m || f) && (s2.preventDefault ? s2.preventDefault() : s2.returnValue = false), (p3 || f) && t2.slideNext(), (c3 || m) && t2.slidePrev()), l2("keyPress", a3);
          }
        }
        function c2() {
          t2.keyboard.enabled || (n2.addEventListener("keydown", d2), t2.keyboard.enabled = true);
        }
        function p2() {
          t2.keyboard.enabled && (n2.removeEventListener("keydown", d2), t2.keyboard.enabled = false);
        }
        t2.keyboard = { enabled: false }, i2({ keyboard: { enabled: false, onlyInViewport: true, pageUpDown: true } }), a2("init", () => {
          t2.params.keyboard.enabled && c2();
        }), a2("destroy", () => {
          t2.keyboard.enabled && p2();
        }), Object.assign(t2.keyboard, { enable: c2, disable: p2 });
      }
      function l(e2) {
        let t2, i2, { swiper: a2, extendParams: l2, on: n2, emit: o2 } = e2, d2 = (0, s.a)();
        l2({
          mousewheel: {
            enabled: false,
            releaseOnEdges: false,
            invert: false,
            forceToAxis: false,
            sensitivity: 1,
            eventsTarget: "container",
            thresholdDelta: null,
            thresholdTime: null,
            noMousewheelClass: "swiper-no-mousewheel"
          }
        }), a2.mousewheel = { enabled: false };
        let c2 = (0, r.d)(), p2 = [];
        function u2() {
          a2.enabled && (a2.mouseEntered = true);
        }
        function h() {
          a2.enabled && (a2.mouseEntered = false);
        }
        function m(e3) {
          return !(a2.params.mousewheel.thresholdDelta && e3.delta < a2.params.mousewheel.thresholdDelta || a2.params.mousewheel.thresholdTime && (0, r.d)() - c2 < a2.params.mousewheel.thresholdTime) && (!!(e3.delta >= 6 && (0, r.d)() - c2 < 60) || (e3.direction < 0 ? a2.isEnd && !a2.params.loop || a2.animating || (a2.slideNext(), o2("scroll", e3.raw)) : a2.isBeginning && !a2.params.loop || a2.animating || (a2.slidePrev(), o2("scroll", e3.raw)), c2 = new d2.Date().getTime(), false));
        }
        function f(e3) {
          var s2;
          let l3, n3, d3, c3, u3 = e3;
          if (!a2.enabled || e3.target.closest(`.${a2.params.mousewheel.noMousewheelClass}`)) return;
          let h2 = a2.params.mousewheel;
          a2.params.cssMode && u3.preventDefault();
          let f2 = a2.el;
          "container" !== a2.params.mousewheel.eventsTarget && (f2 = document.querySelector(a2.params.mousewheel.eventsTarget));
          let g2 = f2 && f2.contains(u3.target);
          if (!a2.mouseEntered && !g2 && !h2.releaseOnEdges) return true;
          u3.originalEvent && (u3 = u3.originalEvent);
          let v2 = 0, b2 = a2.rtlTranslate ? -1 : 1, w = (l3 = 0, n3 = 0, d3 = 0, c3 = 0, "detail" in (s2 = u3) && (n3 = s2.detail), "wheelDelta" in s2 && (n3 = -s2.wheelDelta / 120), "wheelDeltaY" in s2 && (n3 = -s2.wheelDeltaY / 120), "wheelDeltaX" in s2 && (l3 = -s2.wheelDeltaX / 120), "axis" in s2 && s2.axis === s2.HORIZONTAL_AXIS && (l3 = n3, n3 = 0), d3 = 10 * l3, c3 = 10 * n3, "deltaY" in s2 && (c3 = s2.deltaY), "deltaX" in s2 && (d3 = s2.deltaX), s2.shiftKey && !d3 && (d3 = c3, c3 = 0), (d3 || c3) && s2.deltaMode && (1 === s2.deltaMode ? (d3 *= 40, c3 *= 40) : (d3 *= 800, c3 *= 800)), d3 && !l3 && (l3 = d3 < 1 ? -1 : 1), c3 && !n3 && (n3 = c3 < 1 ? -1 : 1), { spinX: l3, spinY: n3, pixelX: d3, pixelY: c3 });
          if (h2.forceToAxis)
            if (a2.isHorizontal())
              if (!(Math.abs(w.pixelX) > Math.abs(w.pixelY))) return true;
              else v2 = -w.pixelX * b2;
            else {
              if (!(Math.abs(w.pixelY) > Math.abs(w.pixelX))) return true;
              v2 = -w.pixelY;
            }
          else v2 = Math.abs(w.pixelX) > Math.abs(w.pixelY) ? -w.pixelX * b2 : -w.pixelY;
          if (0 === v2) return true;
          h2.invert && (v2 = -v2);
          let y = a2.getTranslate() + v2 * h2.sensitivity;
          if (y >= a2.minTranslate() && (y = a2.minTranslate()), y <= a2.maxTranslate() && (y = a2.maxTranslate()), (a2.params.loop || y !== a2.minTranslate() && y !== a2.maxTranslate()) && a2.params.nested && u3.stopPropagation(), a2.params.freeMode && a2.params.freeMode.enabled) {
            let e4 = { time: (0, r.d)(), delta: Math.abs(v2), direction: Math.sign(v2) }, s3 = i2 && e4.time < i2.time + 500 && e4.delta <= i2.delta && e4.direction === i2.direction;
            if (!s3) {
              i2 = void 0;
              let l4 = a2.getTranslate() + v2 * h2.sensitivity, n4 = a2.isBeginning, d4 = a2.isEnd;
              if (l4 >= a2.minTranslate() && (l4 = a2.minTranslate()), l4 <= a2.maxTranslate() && (l4 = a2.maxTranslate()), a2.setTransition(0), a2.setTranslate(l4), a2.updateProgress(), a2.updateActiveIndex(), a2.updateSlidesClasses(), (!n4 && a2.isBeginning || !d4 && a2.isEnd) && a2.updateSlidesClasses(), a2.params.loop && a2.loopFix({ direction: e4.direction < 0 ? "next" : "prev", byMousewheel: true }), a2.params.freeMode.sticky) {
                clearTimeout(t2), t2 = void 0, p2.length >= 15 && p2.shift();
                let s4 = p2.length ? p2[p2.length - 1] : void 0, l5 = p2[0];
                if (p2.push(e4), s4 && (e4.delta > s4.delta || e4.direction !== s4.direction)) p2.splice(0);
                else if (p2.length >= 15 && e4.time - l5.time < 500 && l5.delta - e4.delta >= 1 && e4.delta <= 6) {
                  let s5 = v2 > 0 ? 0.8 : 0.2;
                  i2 = e4, p2.splice(0), t2 = (0, r.n)(() => {
                    a2.slideToClosest(a2.params.speed, true, void 0, s5);
                  }, 0);
                }
                t2 || (t2 = (0, r.n)(() => {
                  i2 = e4, p2.splice(0), a2.slideToClosest(a2.params.speed, true, void 0, 0.5);
                }, 500));
              }
              if (s3 || o2("scroll", u3), a2.params.autoplay && a2.params.autoplayDisableOnInteraction && a2.autoplay.stop(), h2.releaseOnEdges && (l4 === a2.minTranslate() || l4 === a2.maxTranslate()))
                return true;
            }
          } else {
            let t3 = { time: (0, r.d)(), delta: Math.abs(v2), direction: Math.sign(v2), raw: e3 };
            p2.length >= 2 && p2.shift();
            let i3 = p2.length ? p2[p2.length - 1] : void 0;
            if (p2.push(t3), i3 ? (t3.direction !== i3.direction || t3.delta > i3.delta || t3.time > i3.time + 150) && m(t3) : m(t3), (function(e4) {
              let t4 = a2.params.mousewheel;
              if (e4.direction < 0) {
                if (a2.isEnd && !a2.params.loop && t4.releaseOnEdges) return true;
              } else if (a2.isBeginning && !a2.params.loop && t4.releaseOnEdges) return true;
              return false;
            })(t3))
              return true;
          }
          return u3.preventDefault ? u3.preventDefault() : u3.returnValue = false, false;
        }
        function g(e3) {
          let t3 = a2.el;
          "container" !== a2.params.mousewheel.eventsTarget && (t3 = document.querySelector(a2.params.mousewheel.eventsTarget)), t3[e3]("mouseenter", u2), t3[e3]("mouseleave", h), t3[e3]("wheel", f);
        }
        function v() {
          return a2.params.cssMode ? (a2.wrapperEl.removeEventListener("wheel", f), true) : !a2.mousewheel.enabled && (g("addEventListener"), a2.mousewheel.enabled = true, true);
        }
        function b() {
          return a2.params.cssMode ? (a2.wrapperEl.addEventListener(event, f), true) : !!a2.mousewheel.enabled && (g("removeEventListener"), a2.mousewheel.enabled = false, true);
        }
        n2("init", () => {
          !a2.params.mousewheel.enabled && a2.params.cssMode && b(), a2.params.mousewheel.enabled && v();
        }), n2("destroy", () => {
          a2.params.cssMode && v(), a2.mousewheel.enabled && b();
        }), Object.assign(a2.mousewheel, { enable: v, disable: b });
      }
      function n(e2, t2, i2, s2) {
        return e2.params.createElements && Object.keys(s2).forEach((a2) => {
          if (!i2[a2] && true === i2.auto) {
            let l2 = (0, r.e)(e2.el, `.${s2[a2]}`)[0];
            l2 || ((l2 = (0, r.c)("div", s2[a2])).className = s2[a2], e2.el.append(l2)), i2[a2] = l2, t2[a2] = l2;
          }
        }), i2;
      }
      function o(e2) {
        let { swiper: t2, extendParams: i2, on: s2, emit: a2 } = e2;
        function l2(e3) {
          let i3;
          return e3 && "string" == typeof e3 && t2.isElement && (i3 = t2.el.querySelector(e3)) ? i3 : (e3 && ("string" == typeof e3 && (i3 = [...document.querySelectorAll(e3)]), t2.params.uniqueNavElements && "string" == typeof e3 && i3.length > 1 && 1 === t2.el.querySelectorAll(e3).length && (i3 = t2.el.querySelector(e3))), e3 && !i3) ? e3 : i3;
        }
        function o2(e3, i3) {
          let s3 = t2.params.navigation;
          (e3 = (0, r.m)(e3)).forEach((e4) => {
            e4 && (e4.classList[i3 ? "add" : "remove"](...s3.disabledClass.split(" ")), "BUTTON" === e4.tagName && (e4.disabled = i3), t2.params.watchOverflow && t2.enabled && e4.classList[t2.isLocked ? "add" : "remove"](s3.lockClass));
          });
        }
        function d2() {
          let { nextEl: e3, prevEl: i3 } = t2.navigation;
          if (t2.params.loop) {
            o2(i3, false), o2(e3, false);
            return;
          }
          o2(i3, t2.isBeginning && !t2.params.rewind), o2(e3, t2.isEnd && !t2.params.rewind);
        }
        function c2(e3) {
          e3.preventDefault(), (!t2.isBeginning || t2.params.loop || t2.params.rewind) && (t2.slidePrev(), a2("navigationPrev"));
        }
        function p2(e3) {
          e3.preventDefault(), (!t2.isEnd || t2.params.loop || t2.params.rewind) && (t2.slideNext(), a2("navigationNext"));
        }
        function u2() {
          let e3 = t2.params.navigation;
          if (t2.params.navigation = n(t2, t2.originalParams.navigation, t2.params.navigation, {
            nextEl: "swiper-button-next",
            prevEl: "swiper-button-prev"
          }), !(e3.nextEl || e3.prevEl))
            return;
          let i3 = l2(e3.nextEl), s3 = l2(e3.prevEl);
          Object.assign(t2.navigation, { nextEl: i3, prevEl: s3 }), i3 = (0, r.m)(i3), s3 = (0, r.m)(s3);
          let a3 = (i4, s4) => {
            i4 && i4.addEventListener("click", "next" === s4 ? p2 : c2), !t2.enabled && i4 && i4.classList.add(...e3.lockClass.split(" "));
          };
          i3.forEach((e4) => a3(e4, "next")), s3.forEach((e4) => a3(e4, "prev"));
        }
        function h() {
          let { nextEl: e3, prevEl: i3 } = t2.navigation;
          e3 = (0, r.m)(e3), i3 = (0, r.m)(i3);
          let s3 = (e4, i4) => {
            e4.removeEventListener("click", "next" === i4 ? p2 : c2), e4.classList.remove(...t2.params.navigation.disabledClass.split(" "));
          };
          e3.forEach((e4) => s3(e4, "next")), i3.forEach((e4) => s3(e4, "prev"));
        }
        i2({
          navigation: {
            nextEl: null,
            prevEl: null,
            hideOnClick: false,
            disabledClass: "swiper-button-disabled",
            hiddenClass: "swiper-button-hidden",
            lockClass: "swiper-button-lock",
            navigationDisabledClass: "swiper-navigation-disabled"
          }
        }), t2.navigation = { nextEl: null, prevEl: null }, s2("init", () => {
          false === t2.params.navigation.enabled ? m() : (u2(), d2());
        }), s2("toEdge fromEdge lock unlock", () => {
          d2();
        }), s2("destroy", () => {
          h();
        }), s2("enable disable", () => {
          let { nextEl: e3, prevEl: i3 } = t2.navigation;
          if (e3 = (0, r.m)(e3), i3 = (0, r.m)(i3), t2.enabled) return void d2();
          [...e3, ...i3].filter((e4) => !!e4).forEach((e4) => e4.classList.add(t2.params.navigation.lockClass));
        }), s2("click", (e3, i3) => {
          let { nextEl: s3, prevEl: l3 } = t2.navigation;
          s3 = (0, r.m)(s3), l3 = (0, r.m)(l3);
          let n2 = i3.target;
          if (t2.params.navigation.hideOnClick && !l3.includes(n2) && !s3.includes(n2)) {
            let e4;
            if (t2.pagination && t2.params.pagination && t2.params.pagination.clickable && (t2.pagination.el === n2 || t2.pagination.el.contains(n2)))
              return;
            s3.length ? e4 = s3[0].classList.contains(t2.params.navigation.hiddenClass) : l3.length && (e4 = l3[0].classList.contains(t2.params.navigation.hiddenClass)), true === e4 ? a2("navigationShow") : a2("navigationHide"), [...s3, ...l3].filter((e5) => !!e5).forEach((e5) => e5.classList.toggle(t2.params.navigation.hiddenClass));
          }
        });
        let m = () => {
          t2.el.classList.add(...t2.params.navigation.navigationDisabledClass.split(" ")), h();
        };
        Object.assign(t2.navigation, {
          enable: () => {
            t2.el.classList.remove(...t2.params.navigation.navigationDisabledClass.split(" ")), u2(), d2();
          },
          disable: m,
          update: d2,
          init: u2,
          destroy: h
        });
      }
      function d(e2) {
        return void 0 === e2 && (e2 = ""), `.${e2.trim().replace(/([\.:!+\/])/g, "\\$1").replace(/ /g, ".")}`;
      }
      function c(e2) {
        let t2, { swiper: i2, extendParams: s2, on: a2, emit: l2 } = e2, o2 = "swiper-pagination";
        s2({
          pagination: {
            el: null,
            bulletElement: "span",
            clickable: false,
            hideOnClick: false,
            renderBullet: null,
            renderProgressbar: null,
            renderFraction: null,
            renderCustom: null,
            progressbarOpposite: false,
            type: "bullets",
            dynamicBullets: false,
            dynamicMainBullets: 1,
            formatFractionCurrent: (e3) => e3,
            formatFractionTotal: (e3) => e3,
            bulletClass: `${o2}-bullet`,
            bulletActiveClass: `${o2}-bullet-active`,
            modifierClass: `${o2}-`,
            currentClass: `${o2}-current`,
            totalClass: `${o2}-total`,
            hiddenClass: `${o2}-hidden`,
            progressbarFillClass: `${o2}-progressbar-fill`,
            progressbarOppositeClass: `${o2}-progressbar-opposite`,
            clickableClass: `${o2}-clickable`,
            lockClass: `${o2}-lock`,
            horizontalClass: `${o2}-horizontal`,
            verticalClass: `${o2}-vertical`,
            paginationDisabledClass: `${o2}-disabled`
          }
        }), i2.pagination = { el: null, bullets: [] };
        let c2 = 0;
        function p2() {
          return !i2.params.pagination.el || !i2.pagination.el || Array.isArray(i2.pagination.el) && 0 === i2.pagination.el.length;
        }
        function u2(e3, t3) {
          let { bulletActiveClass: s3 } = i2.params.pagination;
          e3 && (e3 = e3[`${"prev" === t3 ? "previous" : "next"}ElementSibling`]) && (e3.classList.add(`${s3}-${t3}`), (e3 = e3[`${"prev" === t3 ? "previous" : "next"}ElementSibling`]) && e3.classList.add(`${s3}-${t3}-${t3}`));
        }
        function h(e3) {
          let t3 = e3.target.closest(d(i2.params.pagination.bulletClass));
          if (!t3) return;
          e3.preventDefault();
          let s3 = (0, r.h)(t3) * i2.params.slidesPerGroup;
          if (i2.params.loop) {
            if (i2.realIndex === s3) return;
            i2.slideToLoop(s3);
          } else i2.slideTo(s3);
        }
        function m() {
          let e3, s3, a3 = i2.rtl, n2 = i2.params.pagination;
          if (p2()) return;
          let o3 = i2.pagination.el;
          o3 = (0, r.m)(o3);
          let h2 = i2.virtual && i2.params.virtual.enabled ? i2.virtual.slides.length : i2.slides.length, m2 = i2.params.loop ? Math.ceil(h2 / i2.params.slidesPerGroup) : i2.snapGrid.length;
          if (i2.params.loop ? (s3 = i2.previousRealIndex || 0, e3 = i2.params.slidesPerGroup > 1 ? Math.floor(i2.realIndex / i2.params.slidesPerGroup) : i2.realIndex) : void 0 !== i2.snapIndex ? (e3 = i2.snapIndex, s3 = i2.previousSnapIndex) : (s3 = i2.previousIndex || 0, e3 = i2.activeIndex || 0), "bullets" === n2.type && i2.pagination.bullets && i2.pagination.bullets.length > 0) {
            let l3, d2, p3, h3 = i2.pagination.bullets;
            if (n2.dynamicBullets && (t2 = (0, r.f)(h3[0], i2.isHorizontal() ? "width" : "height", true), o3.forEach((e4) => {
              e4.style[i2.isHorizontal() ? "width" : "height"] = `${t2 * (n2.dynamicMainBullets + 4)}px`;
            }), n2.dynamicMainBullets > 1 && void 0 !== s3 && ((c2 += e3 - (s3 || 0)) > n2.dynamicMainBullets - 1 ? c2 = n2.dynamicMainBullets - 1 : c2 < 0 && (c2 = 0)), p3 = ((d2 = (l3 = Math.max(e3 - c2, 0)) + (Math.min(h3.length, n2.dynamicMainBullets) - 1)) + l3) / 2), h3.forEach((e4) => {
              let t3 = [
                ...["", "-next", "-next-next", "-prev", "-prev-prev", "-main"].map(
                  (e5) => `${n2.bulletActiveClass}${e5}`
                )
              ].map((e5) => "string" == typeof e5 && e5.includes(" ") ? e5.split(" ") : e5).flat();
              e4.classList.remove(...t3);
            }), o3.length > 1)
              h3.forEach((t3) => {
                let s4 = (0, r.h)(t3);
                s4 === e3 ? t3.classList.add(...n2.bulletActiveClass.split(" ")) : i2.isElement && t3.setAttribute("part", "bullet"), n2.dynamicBullets && (s4 >= l3 && s4 <= d2 && t3.classList.add(...`${n2.bulletActiveClass}-main`.split(" ")), s4 === l3 && u2(t3, "prev"), s4 === d2 && u2(t3, "next"));
              });
            else {
              let t3 = h3[e3];
              if (t3 && t3.classList.add(...n2.bulletActiveClass.split(" ")), i2.isElement && h3.forEach((t4, i3) => {
                t4.setAttribute("part", i3 === e3 ? "bullet-active" : "bullet");
              }), n2.dynamicBullets) {
                let e4 = h3[l3], t4 = h3[d2];
                for (let e5 = l3; e5 <= d2; e5 += 1) h3[e5] && h3[e5].classList.add(...`${n2.bulletActiveClass}-main`.split(" "));
                u2(e4, "prev"), u2(t4, "next");
              }
            }
            if (n2.dynamicBullets) {
              let e4 = Math.min(h3.length, n2.dynamicMainBullets + 4), s4 = (t2 * e4 - t2) / 2 - p3 * t2, r2 = a3 ? "right" : "left";
              h3.forEach((e5) => {
                e5.style[i2.isHorizontal() ? r2 : "top"] = `${s4}px`;
              });
            }
          }
          o3.forEach((t3, s4) => {
            if ("fraction" === n2.type && (t3.querySelectorAll(d(n2.currentClass)).forEach((t4) => {
              t4.textContent = n2.formatFractionCurrent(e3 + 1);
            }), t3.querySelectorAll(d(n2.totalClass)).forEach((e4) => {
              e4.textContent = n2.formatFractionTotal(m2);
            })), "progressbar" === n2.type) {
              let s5;
              s5 = n2.progressbarOpposite ? i2.isHorizontal() ? "vertical" : "horizontal" : i2.isHorizontal() ? "horizontal" : "vertical";
              let r2 = (e3 + 1) / m2, a4 = 1, l3 = 1;
              "horizontal" === s5 ? a4 = r2 : l3 = r2, t3.querySelectorAll(d(n2.progressbarFillClass)).forEach((e4) => {
                e4.style.transform = `translate3d(0,0,0) scaleX(${a4}) scaleY(${l3})`, e4.style.transitionDuration = `${i2.params.speed}ms`;
              });
            }
            "custom" === n2.type && n2.renderCustom ? (t3.innerHTML = n2.renderCustom(i2, e3 + 1, m2), 0 === s4 && l2("paginationRender", t3)) : (0 === s4 && l2("paginationRender", t3), l2("paginationUpdate", t3)), i2.params.watchOverflow && i2.enabled && t3.classList[i2.isLocked ? "add" : "remove"](n2.lockClass);
          });
        }
        function f() {
          let e3 = i2.params.pagination;
          if (p2()) return;
          let t3 = i2.virtual && i2.params.virtual.enabled ? i2.virtual.slides.length : i2.grid && i2.params.grid.rows > 1 ? i2.slides.length / Math.ceil(i2.params.grid.rows) : i2.slides.length, s3 = i2.pagination.el;
          s3 = (0, r.m)(s3);
          let a3 = "";
          if ("bullets" === e3.type) {
            let s4 = i2.params.loop ? Math.ceil(t3 / i2.params.slidesPerGroup) : i2.snapGrid.length;
            i2.params.freeMode && i2.params.freeMode.enabled && s4 > t3 && (s4 = t3);
            for (let t4 = 0; t4 < s4; t4 += 1)
              e3.renderBullet ? a3 += e3.renderBullet.call(i2, t4, e3.bulletClass) : a3 += `<${e3.bulletElement} ${i2.isElement ? 'part="bullet"' : ""} class="${e3.bulletClass}"></${e3.bulletElement}>`;
          }
          "fraction" === e3.type && (a3 = e3.renderFraction ? e3.renderFraction.call(i2, e3.currentClass, e3.totalClass) : `<span class="${e3.currentClass}"></span> / <span class="${e3.totalClass}"></span>`), "progressbar" === e3.type && (a3 = e3.renderProgressbar ? e3.renderProgressbar.call(i2, e3.progressbarFillClass) : `<span class="${e3.progressbarFillClass}"></span>`), i2.pagination.bullets = [], s3.forEach((t4) => {
            "custom" !== e3.type && (t4.innerHTML = a3 || ""), "bullets" === e3.type && i2.pagination.bullets.push(...t4.querySelectorAll(d(e3.bulletClass)));
          }), "custom" !== e3.type && l2("paginationRender", s3[0]);
        }
        function g() {
          let e3;
          i2.params.pagination = n(i2, i2.originalParams.pagination, i2.params.pagination, { el: "swiper-pagination" });
          let t3 = i2.params.pagination;
          t3.el && ("string" == typeof t3.el && i2.isElement && (e3 = i2.el.querySelector(t3.el)), e3 || "string" != typeof t3.el || (e3 = [...document.querySelectorAll(t3.el)]), e3 || (e3 = t3.el), e3 && 0 !== e3.length && (i2.params.uniqueNavElements && "string" == typeof t3.el && Array.isArray(e3) && e3.length > 1 && (e3 = [...i2.el.querySelectorAll(t3.el)]).length > 1 && (e3 = e3.filter((e4) => (0, r.a)(e4, ".swiper")[0] === i2.el)[0]), Array.isArray(e3) && 1 === e3.length && (e3 = e3[0]), Object.assign(i2.pagination, { el: e3 }), (e3 = (0, r.m)(e3)).forEach((e4) => {
            "bullets" === t3.type && t3.clickable && e4.classList.add(...(t3.clickableClass || "").split(" ")), e4.classList.add(t3.modifierClass + t3.type), e4.classList.add(i2.isHorizontal() ? t3.horizontalClass : t3.verticalClass), "bullets" === t3.type && t3.dynamicBullets && (e4.classList.add(`${t3.modifierClass}${t3.type}-dynamic`), c2 = 0, t3.dynamicMainBullets < 1 && (t3.dynamicMainBullets = 1)), "progressbar" === t3.type && t3.progressbarOpposite && e4.classList.add(t3.progressbarOppositeClass), t3.clickable && e4.addEventListener("click", h), i2.enabled || e4.classList.add(t3.lockClass);
          })));
        }
        function v() {
          let e3 = i2.params.pagination;
          if (p2()) return;
          let t3 = i2.pagination.el;
          t3 && (t3 = (0, r.m)(t3)).forEach((t4) => {
            t4.classList.remove(e3.hiddenClass), t4.classList.remove(e3.modifierClass + e3.type), t4.classList.remove(i2.isHorizontal() ? e3.horizontalClass : e3.verticalClass), e3.clickable && (t4.classList.remove(...(e3.clickableClass || "").split(" ")), t4.removeEventListener("click", h));
          }), i2.pagination.bullets && i2.pagination.bullets.forEach((t4) => t4.classList.remove(...e3.bulletActiveClass.split(" ")));
        }
        a2("changeDirection", () => {
          if (!i2.pagination || !i2.pagination.el) return;
          let e3 = i2.params.pagination, { el: t3 } = i2.pagination;
          (t3 = (0, r.m)(t3)).forEach((t4) => {
            t4.classList.remove(e3.horizontalClass, e3.verticalClass), t4.classList.add(i2.isHorizontal() ? e3.horizontalClass : e3.verticalClass);
          });
        }), a2("init", () => {
          false === i2.params.pagination.enabled ? b() : (g(), f(), m());
        }), a2("activeIndexChange", () => {
          void 0 === i2.snapIndex && m();
        }), a2("snapIndexChange", () => {
          m();
        }), a2("snapGridLengthChange", () => {
          f(), m();
        }), a2("destroy", () => {
          v();
        }), a2("enable disable", () => {
          let { el: e3 } = i2.pagination;
          e3 && (e3 = (0, r.m)(e3)).forEach(
            (e4) => e4.classList[i2.enabled ? "remove" : "add"](i2.params.pagination.lockClass)
          );
        }), a2("lock unlock", () => {
          m();
        }), a2("click", (e3, t3) => {
          let s3 = t3.target, a3 = (0, r.m)(i2.pagination.el);
          if (i2.params.pagination.el && i2.params.pagination.hideOnClick && a3 && a3.length > 0 && !s3.classList.contains(i2.params.pagination.bulletClass)) {
            if (i2.navigation && (i2.navigation.nextEl && s3 === i2.navigation.nextEl || i2.navigation.prevEl && s3 === i2.navigation.prevEl))
              return;
            true === a3[0].classList.contains(i2.params.pagination.hiddenClass) ? l2("paginationShow") : l2("paginationHide"), a3.forEach((e4) => e4.classList.toggle(i2.params.pagination.hiddenClass));
          }
        });
        let b = () => {
          i2.el.classList.add(i2.params.pagination.paginationDisabledClass);
          let { el: e3 } = i2.pagination;
          e3 && (e3 = (0, r.m)(e3)).forEach((e4) => e4.classList.add(i2.params.pagination.paginationDisabledClass)), v();
        };
        Object.assign(i2.pagination, {
          enable: () => {
            i2.el.classList.remove(i2.params.pagination.paginationDisabledClass);
            let { el: e3 } = i2.pagination;
            e3 && (e3 = (0, r.m)(e3)).forEach((e4) => e4.classList.remove(i2.params.pagination.paginationDisabledClass)), g(), f(), m();
          },
          disable: b,
          render: f,
          update: m,
          init: g,
          destroy: v
        });
      }
      function p(e2) {
        let { swiper: t2, extendParams: i2, on: s2 } = e2;
        i2({
          a11y: {
            enabled: true,
            notificationClass: "swiper-notification",
            prevSlideMessage: "Previous slide",
            nextSlideMessage: "Next slide",
            firstSlideMessage: "This is the first slide",
            lastSlideMessage: "This is the last slide",
            paginationBulletMessage: "Go to slide {{index}}",
            slideLabelMessage: "{{index}} / {{slidesLength}}",
            containerMessage: null,
            containerRoleDescriptionMessage: null,
            itemRoleDescriptionMessage: null,
            slideRole: "group",
            id: null
          }
        }), t2.a11y = { clicked: false };
        let a2 = null;
        function l2(e3) {
          let t3 = a2;
          0 !== t3.length && (t3.innerHTML = "", t3.innerHTML = e3);
        }
        function n2(e3) {
          (e3 = (0, r.m)(e3)).forEach((e4) => {
            e4.setAttribute("tabIndex", "0");
          });
        }
        function o2(e3) {
          (e3 = (0, r.m)(e3)).forEach((e4) => {
            e4.setAttribute("tabIndex", "-1");
          });
        }
        function c2(e3, t3) {
          (e3 = (0, r.m)(e3)).forEach((e4) => {
            e4.setAttribute("role", t3);
          });
        }
        function p2(e3, t3) {
          (e3 = (0, r.m)(e3)).forEach((e4) => {
            e4.setAttribute("aria-roledescription", t3);
          });
        }
        function u2(e3, t3) {
          (e3 = (0, r.m)(e3)).forEach((e4) => {
            e4.setAttribute("aria-label", t3);
          });
        }
        function h(e3) {
          (e3 = (0, r.m)(e3)).forEach((e4) => {
            e4.setAttribute("aria-disabled", true);
          });
        }
        function m(e3) {
          (e3 = (0, r.m)(e3)).forEach((e4) => {
            e4.setAttribute("aria-disabled", false);
          });
        }
        function f(e3) {
          if (13 !== e3.keyCode && 32 !== e3.keyCode) return;
          let i3 = t2.params.a11y, s3 = e3.target;
          (!(t2.pagination && t2.pagination.el && (s3 === t2.pagination.el || t2.pagination.el.contains(e3.target))) || e3.target.matches(d(t2.params.pagination.bulletClass))) && (t2.navigation && t2.navigation.nextEl && s3 === t2.navigation.nextEl && (t2.isEnd && !t2.params.loop || t2.slideNext(), t2.isEnd ? l2(i3.lastSlideMessage) : l2(i3.nextSlideMessage)), t2.navigation && t2.navigation.prevEl && s3 === t2.navigation.prevEl && (t2.isBeginning && !t2.params.loop || t2.slidePrev(), t2.isBeginning ? l2(i3.firstSlideMessage) : l2(i3.prevSlideMessage)), t2.pagination && s3.matches(d(t2.params.pagination.bulletClass)) && s3.click());
        }
        function g() {
          return t2.pagination && t2.pagination.bullets && t2.pagination.bullets.length;
        }
        function v() {
          return g() && t2.params.pagination.clickable;
        }
        let b = (e3, t3, i3) => {
          var s3;
          n2(e3), "BUTTON" !== e3.tagName && (c2(e3, "button"), e3.addEventListener("keydown", f)), u2(e3, i3), s3 = e3, (s3 = (0, r.m)(s3)).forEach((e4) => {
            e4.setAttribute("aria-controls", t3);
          });
        }, w = () => {
          t2.a11y.clicked = true;
        }, y = () => {
          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              t2.destroyed || (t2.a11y.clicked = false);
            });
          });
        }, S = (e3) => {
          if (t2.a11y.clicked) return;
          let i3 = e3.target.closest(`.${t2.params.slideClass}, swiper-slide`);
          if (!i3 || !t2.slides.includes(i3)) return;
          let s3 = t2.slides.indexOf(i3) === t2.activeIndex, r2 = t2.params.watchSlidesProgress && t2.visibleSlides && t2.visibleSlides.includes(i3);
          !s3 && !r2 && (e3.sourceCapabilities && e3.sourceCapabilities.firesTouchEvents || (t2.isHorizontal() ? t2.el.scrollLeft = 0 : t2.el.scrollTop = 0, t2.slideTo(t2.slides.indexOf(i3), 0)));
        }, T = () => {
          let e3 = t2.params.a11y;
          e3.itemRoleDescriptionMessage && p2(t2.slides, e3.itemRoleDescriptionMessage), e3.slideRole && c2(t2.slides, e3.slideRole);
          let i3 = t2.slides.length;
          e3.slideLabelMessage && t2.slides.forEach((s3, r2) => {
            let a3 = t2.params.loop ? parseInt(s3.getAttribute("data-swiper-slide-index"), 10) : r2;
            u2(s3, e3.slideLabelMessage.replace(/\{\{index\}\}/, a3 + 1).replace(/\{\{slidesLength\}\}/, i3));
          });
        };
        s2("beforeInit", () => {
          (a2 = (0, r.c)("span", t2.params.a11y.notificationClass)).setAttribute("aria-live", "assertive"), a2.setAttribute("aria-atomic", "true");
        }), s2("afterInit", () => {
          t2.params.a11y.enabled && (() => {
            var e3, i3;
            let s3 = t2.params.a11y;
            t2.el.append(a2);
            let l3 = t2.el;
            s3.containerRoleDescriptionMessage && p2(l3, s3.containerRoleDescriptionMessage), s3.containerMessage && u2(l3, s3.containerMessage);
            let n3 = t2.wrapperEl, o3 = s3.id || n3.getAttribute("id") || `swiper-wrapper-${"x".repeat(16).replace(/x/g, () => Math.round(16 * Math.random()).toString(16))}`, d2 = t2.params.autoplay && t2.params.autoplay.enabled ? "off" : "polite";
            e3 = n3, (e3 = (0, r.m)(e3)).forEach((e4) => {
              e4.setAttribute("id", o3);
            }), i3 = n3, (i3 = (0, r.m)(i3)).forEach((e4) => {
              e4.setAttribute("aria-live", d2);
            }), T();
            let { nextEl: c3, prevEl: h2 } = t2.navigation ? t2.navigation : {};
            c3 = (0, r.m)(c3), h2 = (0, r.m)(h2), c3 && c3.forEach((e4) => b(e4, o3, s3.nextSlideMessage)), h2 && h2.forEach((e4) => b(e4, o3, s3.prevSlideMessage)), v() && (0, r.m)(t2.pagination.el).forEach((e4) => {
              e4.addEventListener("keydown", f);
            }), t2.el.addEventListener("focus", S, true), t2.el.addEventListener("pointerdown", w, true), t2.el.addEventListener("pointerup", y, true);
          })();
        }), s2("slidesLengthChange snapGridLengthChange slidesGridLengthChange", () => {
          t2.params.a11y.enabled && T();
        }), s2("fromEdge toEdge afterInit lock unlock", () => {
          t2.params.a11y.enabled && (function() {
            if (t2.params.loop || t2.params.rewind || !t2.navigation) return;
            let { nextEl: e3, prevEl: i3 } = t2.navigation;
            i3 && (t2.isBeginning ? (h(i3), o2(i3)) : (m(i3), n2(i3))), e3 && (t2.isEnd ? (h(e3), o2(e3)) : (m(e3), n2(e3)));
          })();
        }), s2("paginationUpdate", () => {
          if (t2.params.a11y.enabled) {
            let e3 = t2.params.a11y;
            g() && t2.pagination.bullets.forEach((i3) => {
              t2.params.pagination.clickable && (n2(i3), t2.params.pagination.renderBullet || (c2(i3, "button"), u2(i3, e3.paginationBulletMessage.replace(/\{\{index\}\}/, (0, r.h)(i3) + 1)))), i3.matches(d(t2.params.pagination.bulletActiveClass)) ? i3.setAttribute("aria-current", "true") : i3.removeAttribute("aria-current");
            });
          }
        }), s2("destroy", () => {
          t2.params.a11y.enabled && (function() {
            a2 && a2.remove();
            let { nextEl: e3, prevEl: i3 } = t2.navigation ? t2.navigation : {};
            e3 = (0, r.m)(e3), i3 = (0, r.m)(i3), e3 && e3.forEach((e4) => e4.removeEventListener("keydown", f)), i3 && i3.forEach((e4) => e4.removeEventListener("keydown", f)), v() && (0, r.m)(t2.pagination.el).forEach((e4) => {
              e4.removeEventListener("keydown", f);
            }), t2.el.removeEventListener("focus", S, true), t2.el.removeEventListener("pointerdown", w, true), t2.el.removeEventListener("pointerup", y, true);
          })();
        });
      }
      function u(e2) {
        let { swiper: t2, extendParams: i2, emit: s2, once: a2 } = e2;
        i2({
          freeMode: {
            enabled: false,
            momentum: true,
            momentumRatio: 1,
            momentumBounce: true,
            momentumBounceRatio: 1,
            momentumVelocityRatio: 1,
            sticky: false,
            minimumVelocity: 0.02
          }
        }), Object.assign(t2, {
          freeMode: {
            onTouchStart: function() {
              if (t2.params.cssMode) return;
              let e3 = t2.getTranslate();
              t2.setTranslate(e3), t2.setTransition(0), t2.touchEventsData.velocities.length = 0, t2.freeMode.onTouchEnd({ currentPos: t2.rtl ? t2.translate : -t2.translate });
            },
            onTouchMove: function() {
              if (t2.params.cssMode) return;
              let { touchEventsData: e3, touches: i3 } = t2;
              0 === e3.velocities.length && e3.velocities.push({ position: i3[t2.isHorizontal() ? "startX" : "startY"], time: e3.touchStartTime }), e3.velocities.push({ position: i3[t2.isHorizontal() ? "currentX" : "currentY"], time: (0, r.d)() });
            },
            onTouchEnd: function(e3) {
              let { currentPos: i3 } = e3;
              if (t2.params.cssMode) return;
              let { params: l2, wrapperEl: n2, rtlTranslate: o2, snapGrid: d2, touchEventsData: c2 } = t2, p2 = (0, r.d)() - c2.touchStartTime;
              if (i3 < -t2.minTranslate()) return void t2.slideTo(t2.activeIndex);
              if (i3 > -t2.maxTranslate())
                return void (t2.slides.length < d2.length ? t2.slideTo(d2.length - 1) : t2.slideTo(t2.slides.length - 1));
              if (l2.freeMode.momentum) {
                let e4, i4;
                if (c2.velocities.length > 1) {
                  let e5 = c2.velocities.pop(), i5 = c2.velocities.pop(), s3 = e5.position - i5.position, a3 = e5.time - i5.time;
                  t2.velocity = s3 / a3, t2.velocity /= 2, Math.abs(t2.velocity) < l2.freeMode.minimumVelocity && (t2.velocity = 0), (a3 > 150 || (0, r.d)() - e5.time > 300) && (t2.velocity = 0);
                } else t2.velocity = 0;
                t2.velocity *= l2.freeMode.momentumVelocityRatio, c2.velocities.length = 0;
                let p3 = 1e3 * l2.freeMode.momentumRatio, u2 = t2.velocity * p3, h = t2.translate + u2;
                o2 && (h = -h);
                let m = false, f = 20 * Math.abs(t2.velocity) * l2.freeMode.momentumBounceRatio;
                if (h < t2.maxTranslate())
                  l2.freeMode.momentumBounce ? (h + t2.maxTranslate() < -f && (h = t2.maxTranslate() - f), e4 = t2.maxTranslate(), m = true, c2.allowMomentumBounce = true) : h = t2.maxTranslate(), l2.loop && l2.centeredSlides && (i4 = true);
                else if (h > t2.minTranslate())
                  l2.freeMode.momentumBounce ? (h - t2.minTranslate() > f && (h = t2.minTranslate() + f), e4 = t2.minTranslate(), m = true, c2.allowMomentumBounce = true) : h = t2.minTranslate(), l2.loop && l2.centeredSlides && (i4 = true);
                else if (l2.freeMode.sticky) {
                  let e5;
                  for (let t3 = 0; t3 < d2.length; t3 += 1)
                    if (d2[t3] > -h) {
                      e5 = t3;
                      break;
                    }
                  h = -(h = Math.abs(d2[e5] - h) < Math.abs(d2[e5 - 1] - h) || "next" === t2.swipeDirection ? d2[e5] : d2[e5 - 1]);
                }
                if (i4 && a2("transitionEnd", () => {
                  t2.loopFix();
                }), 0 !== t2.velocity) {
                  if (p3 = o2 ? Math.abs((-h - t2.translate) / t2.velocity) : Math.abs((h - t2.translate) / t2.velocity), l2.freeMode.sticky) {
                    let e5 = Math.abs((o2 ? -h : h) - t2.translate), i5 = t2.slidesSizesGrid[t2.activeIndex];
                    p3 = e5 < i5 ? l2.speed : e5 < 2 * i5 ? 1.5 * l2.speed : 2.5 * l2.speed;
                  }
                } else if (l2.freeMode.sticky) return void t2.slideToClosest();
                l2.freeMode.momentumBounce && m ? (t2.updateProgress(e4), t2.setTransition(p3), t2.setTranslate(h), t2.transitionStart(true, t2.swipeDirection), t2.animating = true, (0, r.k)(n2, () => {
                  t2 && !t2.destroyed && c2.allowMomentumBounce && (s2("momentumBounce"), t2.setTransition(l2.speed), setTimeout(() => {
                    t2.setTranslate(e4), (0, r.k)(n2, () => {
                      t2 && !t2.destroyed && t2.transitionEnd();
                    });
                  }, 0));
                })) : t2.velocity ? (s2("_freeModeNoMomentumRelease"), t2.updateProgress(h), t2.setTransition(p3), t2.setTranslate(h), t2.transitionStart(true, t2.swipeDirection), t2.animating || (t2.animating = true, (0, r.k)(n2, () => {
                  t2 && !t2.destroyed && t2.transitionEnd();
                }))) : t2.updateProgress(h), t2.updateActiveIndex(), t2.updateSlidesClasses();
              } else {
                if (l2.freeMode.sticky) return void t2.slideToClosest();
                l2.freeMode && s2("_freeModeNoMomentumRelease");
              }
              (!l2.freeMode.momentum || p2 >= l2.longSwipesMs) && (s2("_freeModeStaticRelease"), t2.updateProgress(), t2.updateActiveIndex(), t2.updateSlidesClasses());
            }
          }
        });
      }
    }
  }
]);
