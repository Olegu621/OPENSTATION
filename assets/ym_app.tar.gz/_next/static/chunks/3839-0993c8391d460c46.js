(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3839],
  {
    7588: (e, t, n) => {
      "use strict";
      n.d(t, { M: () => o });
      var i = n(74125), r = n(11723), s = n(49124);
      async function o(e2, t2) {
        let { locale: n2, fullUrl: o2, url: l, tld: a, host: d } = t2, m = await (0, i.WGy)(n2), h = e2.title.fullTitle, c = m({ id: "metadata.genre-title" }, { genreTitle: h }), v = "artists" in e2 ? e2.artists : void 0, u = (0, r.f)({ genreTitle: h, artists: v, messageFormatter: m }), b = s.env.ASSET_PREFIX || "", P = "".concat(d).concat(b, "/meta/og-image.png");
        return {
          title: c,
          description: u,
          openGraph: (0, i.i$E)({
            ogTitle: (0, i.NsT)(h),
            ogDescription: u,
            fullUrl: null != o2 ? o2 : "",
            locale: n2,
            siteName: m({ id: "metadata.yandex-music" }),
            ogImage: P
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: c,
            url: null != l ? l : "",
            appName: m({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: { tld: a, url: null != l ? l : "", fullUrl: null != o2 ? o2 : "", host: d },
            appName: m({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/genre/:metatagId", t2.tld, { params: { metatagId: e2.id } })
        };
      }
    },
    11723: (e, t, n) => {
      "use strict";
      function i(e2) {
        let { genreTitle: t2, artists: n2, messageFormatter: i2 } = e2, r = null;
        return Array.isArray(n2) && (r = n2.slice(0, 3).map((e3) => "artist" in e3 ? e3.artist.name : e3.name).join(", ")), r ? i2({ id: "metadata.genre-description" }, { genreTitle: t2, artistsList: r }) : i2({ id: "metadata.genre-description-short" }, { genreTitle: t2 });
      }
      n.d(t, { f: () => i });
    },
    15136: (e) => {
      e.exports = { root: "VirtualGridRow_root___UfbI" };
    },
    18753: (e) => {
      e.exports = {
        root: "GenrePlaylistsPage_root__WZwkl",
        scrollContainer: "GenrePlaylistsPage_scrollContainer__N3BZw",
        important: "GenrePlaylistsPage_important__986BX",
        footer: "GenrePlaylistsPage_footer__aMDul",
        item: "GenrePlaylistsPage_item__tUsqJ",
        content: "GenrePlaylistsPage_content__2rKJY"
      };
    },
    33839: (e, t, n) => {
      Promise.resolve().then(n.bind(n, 58360)), Promise.resolve().then(n.bind(n, 14342)), Promise.resolve().then(n.bind(n, 62662)), Promise.resolve().then(n.bind(n, 6971)), Promise.resolve().then(n.bind(n, 22674)), Promise.resolve().then(n.bind(n, 51321)), Promise.resolve().then(n.bind(n, 97800)), Promise.resolve().then(n.bind(n, 42520)), Promise.resolve().then(n.bind(n, 30662)), Promise.resolve().then(n.bind(n, 31757)), Promise.resolve().then(n.bind(n, 51672)), Promise.resolve().then(n.bind(n, 63449)), Promise.resolve().then(n.bind(n, 65134)), Promise.resolve().then(n.bind(n, 96819)), Promise.resolve().then(n.bind(n, 38868)), Promise.resolve().then(n.bind(n, 77163)), Promise.resolve().then(n.bind(n, 96025)), Promise.resolve().then(n.bind(n, 51887)), Promise.resolve().then(n.bind(n, 25577)), Promise.resolve().then(n.bind(n, 65327)), Promise.resolve().then(n.bind(n, 3119)), Promise.resolve().then(n.bind(n, 74808)), Promise.resolve().then(n.bind(n, 92088)), Promise.resolve().then(n.bind(n, 83154)), Promise.resolve().then(n.bind(n, 14476)), Promise.resolve().then(n.bind(n, 88332)), Promise.resolve().then(n.bind(n, 16855)), Promise.resolve().then(n.bind(n, 28795)), Promise.resolve().then(n.bind(n, 93099)), Promise.resolve().then(n.bind(n, 15640)), Promise.resolve().then(n.bind(n, 82885)), Promise.resolve().then(n.bind(n, 99733)), Promise.resolve().then(n.bind(n, 18355)), Promise.resolve().then(n.bind(n, 42691)), Promise.resolve().then(n.bind(n, 37235)), Promise.resolve().then(n.bind(n, 3781)), Promise.resolve().then(n.bind(n, 33829)), Promise.resolve().then(n.bind(n, 39906)), Promise.resolve().then(n.bind(n, 50119)), Promise.resolve().then(n.bind(n, 21179)), Promise.resolve().then(n.bind(n, 7912)), Promise.resolve().then(n.bind(n, 50193)), Promise.resolve().then(n.bind(n, 83399)), Promise.resolve().then(n.bind(n, 11450)), Promise.resolve().then(n.bind(n, 62345)), Promise.resolve().then(n.bind(n, 37408)), Promise.resolve().then(n.bind(n, 48392)), Promise.resolve().then(n.bind(n, 42488)), Promise.resolve().then(n.bind(n, 5207)), Promise.resolve().then(n.bind(n, 69536)), Promise.resolve().then(n.bind(n, 11472)), Promise.resolve().then(n.bind(n, 2438)), Promise.resolve().then(n.bind(n, 46540)), Promise.resolve().then(n.bind(n, 72467)), Promise.resolve().then(n.bind(n, 66894)), Promise.resolve().then(n.bind(n, 45318)), Promise.resolve().then(n.bind(n, 3283)), Promise.resolve().then(n.bind(n, 49943)), Promise.resolve().then(n.bind(n, 73896)), Promise.resolve().then(n.bind(n, 51843)), Promise.resolve().then(n.bind(n, 38139)), Promise.resolve().then(n.bind(n, 93405)), Promise.resolve().then(n.bind(n, 8394)), Promise.resolve().then(n.bind(n, 3192)), Promise.resolve().then(n.bind(n, 7286)), Promise.resolve().then(n.bind(n, 60305)), Promise.resolve().then(n.bind(n, 47203)), Promise.resolve().then(n.bind(n, 34286)), Promise.resolve().then(n.bind(n, 224)), Promise.resolve().then(n.bind(n, 24449)), Promise.resolve().then(n.bind(n, 79893)), Promise.resolve().then(n.bind(n, 81789)), Promise.resolve().then(n.bind(n, 87466)), Promise.resolve().then(n.bind(n, 39034)), Promise.resolve().then(n.bind(n, 17917)), Promise.resolve().then(n.bind(n, 11337)), Promise.resolve().then(n.bind(n, 19683)), Promise.resolve().then(n.bind(n, 53779)), Promise.resolve().then(n.bind(n, 12359)), Promise.resolve().then(n.bind(n, 88564)), Promise.resolve().then(n.bind(n, 95639)), Promise.resolve().then(n.bind(n, 57630)), Promise.resolve().then(n.bind(n, 25342)), Promise.resolve().then(n.bind(n, 34028)), Promise.resolve().then(n.bind(n, 99564)), Promise.resolve().then(n.bind(n, 95348)), Promise.resolve().then(n.bind(n, 52347)), Promise.resolve().then(n.bind(n, 61015)), Promise.resolve().then(n.bind(n, 1771)), Promise.resolve().then(n.bind(n, 80043)), Promise.resolve().then(n.bind(n, 12235)), Promise.resolve().then(n.bind(n, 8941)), Promise.resolve().then(n.bind(n, 38433)), Promise.resolve().then(n.bind(n, 8732)), Promise.resolve().then(n.bind(n, 43369)), Promise.resolve().then(n.bind(n, 47564)), Promise.resolve().then(n.bind(n, 41017)), Promise.resolve().then(n.bind(n, 27252)), Promise.resolve().then(n.bind(n, 65286)), Promise.resolve().then(n.bind(n, 45198)), Promise.resolve().then(n.bind(n, 46814)), Promise.resolve().then(n.bind(n, 92508)), Promise.resolve().then(n.bind(n, 40126)), Promise.resolve().then(n.bind(n, 83726)), Promise.resolve().then(n.bind(n, 90410)), Promise.resolve().then(n.bind(n, 13246)), Promise.resolve().then(n.bind(n, 26040)), Promise.resolve().then(n.bind(n, 92446)), Promise.resolve().then(n.bind(n, 42593)), Promise.resolve().then(n.bind(n, 70570)), Promise.resolve().then(n.bind(n, 88416)), Promise.resolve().then(n.bind(n, 24174)), Promise.resolve().then(n.bind(n, 78458)), Promise.resolve().then(n.bind(n, 59457)), Promise.resolve().then(n.bind(n, 6690)), Promise.resolve().then(n.bind(n, 88370)), Promise.resolve().then(n.bind(n, 66904)), Promise.resolve().then(n.bind(n, 39937)), Promise.resolve().then(n.bind(n, 33019)), Promise.resolve().then(n.bind(n, 38808)), Promise.resolve().then(n.bind(n, 58094)), Promise.resolve().then(n.bind(n, 78009)), Promise.resolve().then(n.bind(n, 33427)), Promise.resolve().then(n.bind(n, 30878)), Promise.resolve().then(n.bind(n, 53115)), Promise.resolve().then(n.bind(n, 52398)), Promise.resolve().then(n.bind(n, 82327)), Promise.resolve().then(n.bind(n, 17012)), Promise.resolve().then(n.bind(n, 9275)), Promise.resolve().then(n.bind(n, 17658)), Promise.resolve().then(n.bind(n, 36578)), Promise.resolve().then(n.bind(n, 66989)), Promise.resolve().then(n.bind(n, 58863)), Promise.resolve().then(n.bind(n, 60899)), Promise.resolve().then(n.bind(n, 59437)), Promise.resolve().then(n.bind(n, 43367)), Promise.resolve().then(n.bind(n, 66446)), Promise.resolve().then(n.bind(n, 86840)), Promise.resolve().then(n.bind(n, 75181)), Promise.resolve().then(n.bind(n, 99538)), Promise.resolve().then(n.bind(n, 45252)), Promise.resolve().then(n.bind(n, 59226)), Promise.resolve().then(n.bind(n, 75961)), Promise.resolve().then(n.bind(n, 33964)), Promise.resolve().then(n.bind(n, 33967)), Promise.resolve().then(n.bind(n, 64410)), Promise.resolve().then(n.bind(n, 91350)), Promise.resolve().then(n.bind(n, 4500)), Promise.resolve().then(n.bind(n, 55846)), Promise.resolve().then(n.bind(n, 65689)), Promise.resolve().then(n.bind(n, 99386)), Promise.resolve().then(n.bind(n, 5222)), Promise.resolve().then(n.bind(n, 60440)), Promise.resolve().then(n.bind(n, 37271)), Promise.resolve().then(n.bind(n, 66688)), Promise.resolve().then(n.bind(n, 76472)), Promise.resolve().then(n.bind(n, 41682)), Promise.resolve().then(n.bind(n, 77666)), Promise.resolve().then(n.bind(n, 8765)), Promise.resolve().then(n.bind(n, 48670)), Promise.resolve().then(n.bind(n, 22096)), Promise.resolve().then(n.bind(n, 33655)), Promise.resolve().then(n.bind(n, 27754)), Promise.resolve().then(n.bind(n, 47347)), Promise.resolve().then(n.bind(n, 45591)), Promise.resolve().then(n.bind(n, 52862)), Promise.resolve().then(n.bind(n, 79326)), Promise.resolve().then(n.bind(n, 73922)), Promise.resolve().then(n.bind(n, 10790)), Promise.resolve().then(n.bind(n, 78684)), Promise.resolve().then(n.bind(n, 76877)), Promise.resolve().then(n.bind(n, 61176)), Promise.resolve().then(n.bind(n, 62108)), Promise.resolve().then(n.bind(n, 75053)), Promise.resolve().then(n.bind(n, 23035)), Promise.resolve().then(n.bind(n, 82315)), Promise.resolve().then(n.bind(n, 60673)), Promise.resolve().then(n.bind(n, 5048)), Promise.resolve().then(n.bind(n, 50215)), Promise.resolve().then(n.bind(n, 78308)), Promise.resolve().then(n.bind(n, 10084)), Promise.resolve().then(n.bind(n, 58681)), Promise.resolve().then(n.bind(n, 18658)), Promise.resolve().then(n.bind(n, 6323)), Promise.resolve().then(n.bind(n, 78817)), Promise.resolve().then(n.bind(n, 7230)), Promise.resolve().then(n.bind(n, 38378)), Promise.resolve().then(n.bind(n, 35609)), Promise.resolve().then(n.bind(n, 18606)), Promise.resolve().then(n.bind(n, 68014)), Promise.resolve().then(n.bind(n, 12126)), Promise.resolve().then(n.bind(n, 52742)), Promise.resolve().then(n.bind(n, 68098)), Promise.resolve().then(n.bind(n, 89190)), Promise.resolve().then(n.bind(n, 3270)), Promise.resolve().then(n.bind(n, 1220)), Promise.resolve().then(n.bind(n, 96584)), Promise.resolve().then(n.bind(n, 54598)), Promise.resolve().then(n.bind(n, 14196)), Promise.resolve().then(n.bind(n, 20576)), Promise.resolve().then(n.bind(n, 29070)), Promise.resolve().then(n.bind(n, 35203)), Promise.resolve().then(n.bind(n, 39450)), Promise.resolve().then(n.bind(n, 77607)), Promise.resolve().then(n.bind(n, 7430)), Promise.resolve().then(n.bind(n, 24786)), Promise.resolve().then(n.bind(n, 24036)), Promise.resolve().then(n.bind(n, 34932)), Promise.resolve().then(n.bind(n, 56204)), Promise.resolve().then(n.bind(n, 75450)), Promise.resolve().then(n.bind(n, 60608)), Promise.resolve().then(n.bind(n, 33648)), Promise.resolve().then(n.bind(n, 43548)), Promise.resolve().then(n.bind(n, 69672)), Promise.resolve().then(n.bind(n, 50711)), Promise.resolve().then(n.bind(n, 5185)), Promise.resolve().then(n.bind(n, 90555)), Promise.resolve().then(n.bind(n, 5602)), Promise.resolve().then(n.bind(n, 12390)), Promise.resolve().then(n.bind(n, 58376)), Promise.resolve().then(n.bind(n, 24491)), Promise.resolve().then(n.bind(n, 61993)), Promise.resolve().then(n.bind(n, 38644)), Promise.resolve().then(n.bind(n, 93668)), Promise.resolve().then(n.bind(n, 85949)), Promise.resolve().then(n.bind(n, 17519)), Promise.resolve().then(n.bind(n, 62010)), Promise.resolve().then(n.bind(n, 16372)), Promise.resolve().then(n.bind(n, 64434)), Promise.resolve().then(n.bind(n, 33158)), Promise.resolve().then(n.bind(n, 27314)), Promise.resolve().then(n.bind(n, 93206)), Promise.resolve().then(n.bind(n, 37226)), Promise.resolve().then(n.bind(n, 13811)), Promise.resolve().then(n.bind(n, 45645)), Promise.resolve().then(n.bind(n, 24126)), Promise.resolve().then(n.bind(n, 20406)), Promise.resolve().then(n.bind(n, 21940)), Promise.resolve().then(n.bind(n, 26086)), Promise.resolve().then(n.bind(n, 96838)), Promise.resolve().then(n.bind(n, 10358)), Promise.resolve().then(n.bind(n, 23143)), Promise.resolve().then(n.bind(n, 51828)), Promise.resolve().then(n.bind(n, 51725)), Promise.resolve().then(n.bind(n, 23834)), Promise.resolve().then(n.bind(n, 88343)), Promise.resolve().then(n.bind(n, 24624));
    },
    33868: (e, t, n) => {
      "use strict";
      n.d(t, { g: () => o });
      var i = n(74125), r = n(11723), s = n(49124);
      async function o(e2, t2) {
        let { locale: n2, fullUrl: o2, url: l, tld: a, host: d } = t2, m = await (0, i.WGy)(n2), h = e2.title.fullTitle, c = m({ id: "metadata.genre-title" }, { genreTitle: h }), v = (0, r.f)({ genreTitle: h, messageFormatter: m }), u = s.env.ASSET_PREFIX || "", b = "".concat(d).concat(u, "/meta/og-image.png");
        return {
          title: c,
          description: v,
          openGraph: (0, i.i$E)({
            ogTitle: (0, i.NsT)(h),
            ogDescription: v,
            fullUrl: null != o2 ? o2 : "",
            locale: n2,
            siteName: m({ id: "metadata.yandex-music" }),
            ogImage: b
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: c,
            url: null != l ? l : "",
            appName: m({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: { tld: a, url: null != l ? l : "", fullUrl: null != o2 ? o2 : "", host: d },
            appName: m({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/genre/:metatagId/albums", t2.tld, { params: { metatagId: e2.id } })
        };
      }
    },
    38139: (e, t, n) => {
      "use strict";
      n.d(t, { GenrePage: () => S });
      var i = n(54486), r = n(50420), s = n(28303), o = n(97396), l = n(61910), a = n(43426), d = n(56231), m = n(97800), h = n(82644), c = n(94376), v = n(55616), u = n(33276), b = n(83909), P = n(74125), g = n(80585), p = n(7588), _ = n(63695), x = n(13611), f = n(50153), N = n.n(f);
      let S = (0, s.PA)((e2) => {
        let { metatagId: t2, preloadedMeta: n2 } = e2, { genre: s2 } = (0, P.Pjs)(), { formatMessage: f2 } = (0, a.A)(), { contentScrollRef: S2, setContentScrollRef: k } = (0, P.gKY)(), j = (0, P.W6M)();
        return (s2.isNotFound && (0, o.notFound)(), (0, l.useEffect)(
          () => () => {
            s2.reset();
          },
          [s2]
        ), (0, P.Jzs)(s2.isResolved), ((e3) => {
          (0, l.useEffect)(() => {
            if (!e3) return;
            let t3 = ((e4) => ({
              id: "",
              title: { title: "", fullTitle: e4.fullTitle || "" },
              liked: false,
              tracks: [],
              artists: e4.artists.map(_.NE),
              composers: [],
              albums: e4.albums.map(c.fO),
              playlists: e4.playlists.map(x.Ji)
            }))(e3);
            (0, p.M)(t3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, P.jxB)(e4);
            });
          }, [e3]);
        })(s2), t2 && s2.isNeededToLoad && (0, l.use)(s2.getData({ id: t2, preloadedMeta: n2 })), s2.isRejected && !s2.isNotFound) ? (0, i.jsx)(h.w, {}) : (0, i.jsx)(P.nVz, {
          pageId: P._Q$.GENRE,
          children: (0, i.jsxs)(u.hO, {
            scrollElement: S2,
            outerTitle: s2.fullTitle,
            children: [
              (0, i.jsx)(g.Y9, {
                variant: g.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: j.canBack,
                children: (0, i.jsx)(m.Heading, {
                  variant: "h2",
                  weight: "bold",
                  size: "xl",
                  lineClamp: 1,
                  children: s2.fullTitle
                })
              }),
              (0, i.jsx)(d.N, {
                className: N().root,
                containerClassName: N().content,
                ref: k,
                children: (0, i.jsxs)("div", {
                  className: N().carouselBlocks,
                  children: [
                    s2.hasPlaylists && (0, i.jsx)(P.FoH, {
                      blockId: P.hf$.PLAYLISTS_CAROUSEL,
                      blockType: P.hf$.PLAYLISTS_CAROUSEL,
                      blockPosX: 1,
                      blockPosY: 1,
                      blockIdForFrom: P.hf$.PLAYLISTS_CAROUSEL,
                      objectsCount: s2.albums.length,
                      children: (0, i.jsx)(b.EC, {
                        isShimmerVisible: s2.isLoading,
                        isShimmerActive: true,
                        headerClassName: (0, r.$)(N().carouselBlockHeader, N().carouselBlock),
                        containerClassName: N().carouselBlock,
                        playlists: s2.playlists,
                        title: f2({ id: "entity-names.popular-playlists" }),
                        viewAllActionLink: "/genre/".concat(s2.id, "/playlists")
                      })
                    }),
                    s2.hasAlbums && (0, i.jsx)(P.FoH, {
                      blockId: P.hf$.ALBUMS_CAROUSEL,
                      blockType: P.hf$.ALBUMS_CAROUSEL,
                      blockPosX: 1,
                      blockPosY: 2,
                      blockIdForFrom: P.hf$.ALBUMS_CAROUSEL,
                      objectsCount: s2.albums.length,
                      children: (0, i.jsx)(c.pZ, {
                        isShimmerVisible: s2.isLoading,
                        isShimmerActive: true,
                        headerClassName: (0, r.$)(N().carouselBlockHeader, N().carouselBlock),
                        containerClassName: N().carouselBlock,
                        albums: s2.albums,
                        title: f2({ id: "entity-names.new-albums" }),
                        viewAllActionLink: "/genre/".concat(s2.id, "/albums")
                      })
                    }),
                    s2.hasArtists && (0, i.jsx)(P.FoH, {
                      blockId: P.hf$.ARTISTS_CAROUSEL,
                      blockType: P.hf$.ARTISTS_CAROUSEL,
                      blockPosX: 1,
                      blockPosY: 3,
                      blockIdForFrom: P.hf$.ARTISTS_CAROUSEL,
                      objectsCount: s2.albums.length,
                      children: (0, i.jsx)(g.OY, {
                        isShimmerVisible: s2.isLoading,
                        isShimmerActive: true,
                        headerClassName: (0, r.$)(N().carouselBlockHeader, N().carouselBlock),
                        containerClassName: N().carouselBlock,
                        title: f2({ id: "entity-names.popular-artists" }),
                        viewAllActionLink: "/genre/".concat(s2.id, "/artists"),
                        children: s2.artists.map(
                          (e3) => (0, i.jsx)(v.ao, { artist: e3, contentLinesCount: 3 }, e3.id)
                        )
                      })
                    })
                  ]
                })
              })
            ]
          })
        });
      });
    },
    42421: (e, t, n) => {
      "use strict";
      n.d(t, { M: () => i.NotFound });
      var i = n(65034);
    },
    42520: (e, t, n) => {
      "use strict";
      let i;
      n.d(t, { useMetrika: () => o });
      var r = n(61910), s = n(80506);
      let o = () => {
        let e2 = (i || (i = (0, s.a)()), i), t2 = (0, r.useSyncExternalStore)(e2.isLoaded.onChange, () => e2.isLoaded.value);
        return (0, r.useMemo)(() => ({ ...e2, isLoaded: t2 }), [t2]);
      };
    },
    45126: (e, t, n) => {
      "use strict";
      n.d(t, { i: () => o });
      var i = n(74125), r = n(11723), s = n(49124);
      async function o(e2, t2) {
        let { locale: n2, fullUrl: o2, url: l, tld: a, host: d } = t2, m = await (0, i.WGy)(n2), h = e2.title.fullTitle, c = m({ id: "metadata.genre-title" }, { genreTitle: h }), v = "artists" in e2 ? e2.artists : void 0, u = (0, r.f)({ genreTitle: h, artists: v, messageFormatter: m }), b = s.env.ASSET_PREFIX || "", P = "".concat(d).concat(b, "/meta/og-image.png");
        return {
          title: c,
          description: u,
          openGraph: (0, i.i$E)({
            ogTitle: (0, i.NsT)(h),
            ogDescription: u,
            fullUrl: null != o2 ? o2 : "",
            locale: n2,
            siteName: m({ id: "metadata.yandex-music" }),
            ogImage: P
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: c,
            url: null != l ? l : "",
            appName: m({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: { tld: a, url: null != l ? l : "", fullUrl: null != o2 ? o2 : "", host: d },
            appName: m({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/genre/:metatagId/artists", t2.tld, { params: { metatagId: e2.id } })
        };
      }
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    49811: (e, t, n) => {
      "use strict";
      n.d(t, { c: () => i });
      let i = 30;
    },
    49943: (e, t, n) => {
      "use strict";
      n.d(t, { GenreAlbumsPage: () => x });
      var i = n(54486), r = n(50420), s = n(28303), o = n(97396), l = n(61910), a = n(43426), d = n(31500), m = n(97800), h = n(82644), c = n(94376), v = n(33276), u = n(74125), b = n(80585), P = n(49811), g = n(33868), p = n(94189), _ = n.n(p);
      let x = (0, s.PA)((e2) => {
        let { metatagId: t2, preloadedMeta: n2 } = e2, {
          genre: { albumsSubpage: s2 },
          settings: { isMobile: p2 }
        } = (0, u.Pjs)(), { formatMessage: x2 } = (0, a.A)(), { contentScrollRef: f, setContentScrollRef: N } = (0, u.gKY)(), S = (0, u.W6M)(), k = (0, l.useCallback)(
          (e3) => {
            t2 && s2.getData({ metatagId: t2, page: e3, pageSize: P.c });
          },
          [s2, t2]
        );
        (0, u.XcE)(s2.pagesLoader, k), (0, l.useEffect)(
          () => () => {
            s2.reset();
          },
          [s2]
        ), s2.isNotFound && (0, o.notFound)(), (0, u.Jzs)(s2.isResolved), ((e3) => {
          (0, l.useEffect)(() => {
            if (!e3) return;
            let t3 = ((e4) => {
              var t4, n3, i2;
              return {
                id: "",
                title: { title: "", fullTitle: e4.fullTitle || "" },
                albums: e4.items.map(c.fO),
                pager: {
                  page: (null == (t4 = e4.pagesLoader.pager) ? void 0 : t4.page) || 0,
                  perPage: (null == (n3 = e4.pagesLoader.pager) ? void 0 : n3.perPage) || 0,
                  total: (null == (i2 = e4.pagesLoader.pager) ? void 0 : i2.total) || 0
                }
              };
            })(e3);
            (0, g.g)(t3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, u.jxB)(e4);
            });
          }, [e3]);
        })(s2);
        let j = (0, l.useMemo)(
          () => ({ Footer: () => (0, i.jsx)(b.A, { children: (0, i.jsx)(b.wi, { className: _().footer }) }) }),
          []
        );
        if (t2 && s2.isNeededToLoad && (0, l.use)(s2.getData({ preloadedMeta: n2, metatagId: t2, page: 0, pageSize: P.c })), s2.isSomethingWrong)
          return (0, i.jsx)(h.w, {});
        let A = s2.isShimmerVisible ? 20 : s2.items.length;
        return (0, i.jsx)(u.nVz, {
          pageId: u._Q$.GENRE_ALBUMS,
          children: (0, i.jsx)(v.hO, {
            scrollElement: f,
            outerTitle: s2.fullTitle,
            children: (0, i.jsxs)("div", {
              className: _().root,
              ...(0, d.Am)(d.Xk.genre.GENRE_ALBUMS_PAGE),
              children: [
                (0, i.jsx)(b.Y9, {
                  variant: b.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: S.canBack,
                  children: (0, i.jsx)(m.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: s2.fullTitle
                  })
                }),
                (0, i.jsx)(b.$$, {
                  className: (0, r.$)(_().scrollContainer, _().important),
                  customComponents: j,
                  itemContentCallback: (e3) => {
                    let t3 = s2.items[e3], n3 = x2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: x2({ id: "entity-names.album" }) }
                    );
                    return t3 ? (0, i.jsx)(c.aX, { album: t3, contentLinesCount: 4 }, t3.id) : (0, i.jsx)(b.Vt, { "aria-label": n3, linesCount: 4 });
                  },
                  totalCount: A,
                  onGetDataByPage: k,
                  pageSize: P.c,
                  totalRequests: s2.requestsCount,
                  listClassName: _().content,
                  itemClassName: _().item,
                  handleRef: N,
                  context: { listAriaLabel: x2({ id: "mixes.albums-list" }, { genreName: s2.fullTitle || "" }) },
                  isMobileLayout: p2,
                  useWindowScroll: p2
                })
              ]
            })
          })
        });
      });
    },
    50153: (e) => {
      e.exports = {
        root: "GenrePage_root___kL_v",
        content: "GenrePage_content__NRwAJ",
        shimmerTitle: "GenrePage_shimmerTitle__hrgjK",
        carouselBlocks: "GenrePage_carouselBlocks__kR63B",
        carouselBlock: "GenrePage_carouselBlock__QCkpK",
        carouselBlockHeader: "GenrePage_carouselBlockHeader__u12sn"
      };
    },
    51843: (e, t, n) => {
      "use strict";
      n.d(t, { GenreNotFoundPage: () => o });
      var i = n(54486), r = n(28303), s = n(42421);
      let o = (0, r.PA)(() => (0, i.jsx)(s.M, {}));
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65034: (e, t, n) => {
      "use strict";
      n.d(t, { NotFound: () => b });
      var i = n(54486), r = n(50420), s = n(28303), o = n(47713), l = n(77881), a = n(5956), d = n(97800), m = n(74125), h = n(80585), c = n(61910), v = n(46215), u = n.n(v);
      let b = (0, s.PA)((e2) => {
        let { className: t2, title: n2, description: s2, iconVariant: v2 = "musicLogo", iconClassName: b2, iconSize: P } = e2, { contentRef: g } = (0, m.gKY)(), p = (0, m.ZpR)(m.Zyd.main.href);
        (0, m.LZB)();
        let { handleNavigateToMain: _ } = (0, m.D5F)(p);
        return (0, m.NBO)(true), !(function() {
          let { location: e3 } = (0, m.Pjs)();
          (0, c.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, i.jsxs)("div", {
          className: (0, r.$)(u().root, { [u().root_desktop]: !g }, t2),
          children: [
            (0, i.jsx)(h.Lh, { withBackwardFallback: "/", className: u().navigation, withForwardControl: false }),
            (0, i.jsxs)("div", {
              className: u().content,
              children: [
                (0, i.jsx)(a.Icon, { className: (0, r.$)(u().icon, b2), variant: v2, size: P }),
                (0, i.jsx)(d.Heading, {
                  className: (0, r.$)(u().title, u().important),
                  variant: "h3",
                  size: "xs",
                  children: n2 || (0, i.jsx)(o.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, i.jsx)(d.Caption, {
                  className: (0, r.$)(u().text, u().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: s2 || (0, i.jsx)(o.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, i.jsx)(l.$, {
                  onClick: _,
                  className: u().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, i.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, i.jsx)(o.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    73896: (e, t, n) => {
      "use strict";
      n.d(t, { GenreArtistsPage: () => S });
      var i = n(54486), r = n(28303), s = n(97396), o = n(61910), l = n(43426), a = n(31500), d = n(8817), m = n(56231), h = n(97800), c = n(82644), v = n(55616), u = n(33276), b = n(77516), P = n(74125), g = n(80585), p = n(49811), _ = n(45126), x = n(63695), f = n(82975), N = n.n(f);
      let S = (0, r.PA)((e2) => {
        let { metatagId: t2, preloadedMeta: n2 } = e2, {
          genre: { artistsSubpage: r2 }
        } = (0, P.Pjs)(), { formatMessage: f2 } = (0, l.A)(), { contentScrollRef: S2, setContentScrollRef: k } = (0, P.gKY)(), j = (0, P.W6M)(), A = (0, d.c)(() => 315), y = (0, d.c)(() => {
          var e3;
          return !r2.isShimmerVisible && (null == (e3 = r2.pagesLoader.pager) ? void 0 : e3.total) ? r2.pagesLoader.pager.total : 30;
        }), w = (0, o.useCallback)(
          (e3) => {
            t2 && r2.getData({ metatagId: t2, page: e3, pageSize: p.c });
          },
          [r2, t2]
        ), C = (0, P.ws4)({ pageSize: p.c, callback: w });
        (0, P.XcE)(r2.pagesLoader, w);
        let T = (0, d.c)((e3) => {
          let t3 = r2.items[e3], n3 = f2({ id: "loading-messages.entity-is-loading" }, { entityName: f2({ id: "entity-names.artist" }) });
          return t3 ? (0, i.jsx)(v.ao, { artist: t3, contentLinesCount: 3 }, t3.id) : (0, i.jsx)(g.Vt, { "aria-label": n3, round: true, centered: true });
        });
        return ((0, o.useEffect)(
          () => () => {
            r2.reset();
          },
          [r2]
        ), r2.isNotFound && (0, s.notFound)(), (0, P.Jzs)(r2.isResolved), ((e3) => {
          (0, o.useEffect)(() => {
            if (!e3) return;
            let t3 = ((e4) => {
              var t4, n3, i2;
              return {
                id: "",
                title: { title: "", fullTitle: e4.fullTitle || "" },
                artists: e4.items.map((e5) => ({ artist: (0, x.NE)(e5), popularTracks: [] })),
                pager: {
                  page: (null == (t4 = e4.pagesLoader.pager) ? void 0 : t4.page) || 0,
                  perPage: (null == (n3 = e4.pagesLoader.pager) ? void 0 : n3.perPage) || 0,
                  total: (null == (i2 = e4.pagesLoader.pager) ? void 0 : i2.total) || 0
                }
              };
            })(e3);
            (0, _.i)(t3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, P.jxB)(e4);
            });
          }, [e3]);
        })(r2), t2 && r2.isNeededToLoad && (0, o.use)(r2.getData({ preloadedMeta: n2, metatagId: t2, page: 0, pageSize: p.c })), r2.isSomethingWrong) ? (0, i.jsx)(c.w, {}) : (0, i.jsx)(P.nVz, {
          pageId: P._Q$.GENRE_ARTISTS,
          children: (0, i.jsx)(u.hO, {
            scrollElement: S2,
            outerTitle: r2.fullTitle,
            children: (0, i.jsxs)("div", {
              className: N().root,
              ...(0, a.Am)(a.Xk.genre.GENRE_ARTISTS_PAGE),
              children: [
                (0, i.jsx)(g.Y9, {
                  variant: g.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: j.canBack,
                  children: (0, i.jsx)(h.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: r2.fullTitle
                  })
                }),
                (0, i.jsxs)(m.N, {
                  ref: k,
                  className: N().root,
                  containerClassName: N().container,
                  children: [
                    (0, i.jsx)(b.Q$, {
                      maxColumnCount: 7,
                      count: y(),
                      rowGap: 16,
                      columnGap: 16,
                      getEstimateRowSize: A,
                      minColumnWidth: 170,
                      maxColumnWidth: 270,
                      onChangeRange: C,
                      renderItemByIndex: T
                    }),
                    (0, i.jsx)(g.A, { children: (0, i.jsx)(g.wi, { className: N().footer }) })
                  ]
                })
              ]
            })
          })
        });
      });
    },
    75312: (e, t, n) => {
      "use strict";
      n.d(t, { SomethingWentWrong: () => P });
      var i = n(54486), r = n(50420), s = n(28303), o = n(61910), l = n(43426), a = n(47713), d = n(77881), m = n(5956), h = n(97800), c = n(74125), v = n(80585), u = n(63708), b = n.n(u);
      let P = (0, s.PA)((e2) => {
        let { className: t2, withBackwardControl: n2 = true } = e2, { formatMessage: s2 } = (0, l.A)(), u2 = s2({ id: "error-messages.something-went-wrong" });
        (0, c.CgZ)(u2);
        let { sendRefreshEvent: P2 } = (0, c.cYT)(), g = (0, o.useCallback)(() => {
          P2(), window.location.href = c.Zyd.main.href;
        }, [P2]), { contentRef: p } = (0, c.gKY)();
        return (0, i.jsxs)("div", {
          className: (0, r.$)(b().root, t2),
          children: [
            n2 && (0, i.jsx)(v.Lh, {
              withBackwardFallback: "/",
              className: (0, r.$)(b().navigation, { [b().navigation_desktop]: !p }),
              withForwardControl: false
            }),
            (0, i.jsxs)("div", {
              className: (0, r.$)(b().content, { [b().content_shrink]: !n2 }),
              children: [
                (0, i.jsx)(m.Icon, { className: b().icon, variant: "attention", size: "xxl" }),
                (0, i.jsx)(h.Heading, {
                  className: (0, r.$)(b().title, b().important),
                  variant: "h3",
                  size: "xs",
                  children: u2
                }),
                (0, i.jsxs)(h.Caption, {
                  className: (0, r.$)(b().text, b().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, i.jsx)(a.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, i.jsx)(d.$, {
                  onClick: g,
                  className: b().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, i.jsxs)(h.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, i.jsx)(a.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    77516: (e, t, n) => {
      "use strict";
      n.d(t, { Q$: () => f, Ux: () => p, LW: () => h, rA: () => m });
      var i = n(44282), r = n(27510), s = n(74125), o = n(4885), l = n(61910), a = n(8817);
      let d = { width: 400, height: 400 }, m = (e2) => {
        let { count: t2, getEstimateSize: n2, gap: i2, containerRef: r2 } = e2, {
          settings: { isMobile: m2 }
        } = (0, s.Pjs)(), { contentScrollRef: h2 } = (0, s.gKY)(), c2 = (0, l.useRef)(/* @__PURE__ */ new Map()), v2 = (0, l.useRef)(void 0), u2 = {
          count: t2,
          gap: i2,
          estimateSize: (e3) => {
            let t3 = c2.current.get(String(e3));
            return null != t3 ? t3 : n2(e3);
          },
          overscan: 2,
          initialRect: d,
          isScrollingResetDelay: 50,
          scrollMargin: ((e3, t3, n3) => {
            if (!t3) return 0;
            let i3 = t3.getBoundingClientRect().top;
            return e3 && 1 ? i3 + window.scrollY : !e3 && n3 ? i3 + n3.scrollTop : 0;
          })(m2, r2, h2)
        }, b2 = (0, o.XW)(u2), P2 = (0, o.Te)({ ...u2, getScrollElement: () => h2, initialOffset: null == h2 ? void 0 : h2.scrollTop }), g2 = m2 ? b2 : P2, p2 = (0, a.c)(() => {
          g2.measure();
        });
        return (0, l.useEffect)(() => {
          v2.current || (v2.current = new ResizeObserver((e3) => {
            let t3 = false;
            e3.forEach((e4) => {
              let n3 = e4.target.getAttribute("data-index");
              if (e4.target && n3) {
                let i3 = e4.contentRect.height;
                i3 && i3 !== c2.current.get(n3) && (c2.current.set(n3, e4.contentRect.height), t3 = true);
              }
            }), t3 && p2();
          }));
        }, [p2]), { virtualizer: g2, resizeObserver: v2.current };
      }, h = (e2) => {
        let {
          count: t2,
          getEstimateRowSize: n2,
          rowGap: o2,
          columnGap: l2,
          minColumnWidth: a2,
          maxColumnWidth: d2,
          minColumnCount: h2,
          maxColumnCount: c2,
          containerRef: v2
        } = e2, { rowCount: u2, columnCount: b2 } = (0, s.E11)({
          totalCount: t2,
          columnGap: null != l2 ? l2 : 0,
          minColumnCount: h2,
          maxColumnWidth: d2,
          minColumnWidth: a2,
          maxColumnCount: c2,
          containerRef: v2
        }), { virtualizer: P2, resizeObserver: g2 } = m({ count: u2, getEstimateSize: n2, gap: o2, containerRef: v2 }), p2 = (0, i.A)(
          Array.from({ length: t2 }, (e3, t3) => t3),
          b2
        ), _2 = (0, r.L)(() => {
          var e3, t3;
          if (!P2.range) return null;
          let n3 = null == (e3 = p2[P2.range.startIndex]) ? void 0 : e3.at(0), i2 = null == (t3 = p2[P2.range.endIndex]) ? void 0 : t3.at(-1);
          return void 0 !== n3 && void 0 !== i2 ? { startIndex: n3, endIndex: i2 } : null;
        });
        return { virtualizer: P2, rowResizeObserver: g2, indices: p2, columnCount: b2, visibleRange: _2 };
      };
      var c = n(54486), v = n(28303), u = n(67648), b = n(50420), P = n(15136), g = n.n(P);
      let p = (0, v.PA)((e2) => {
        let {
          indices: t2,
          virtualItem: n2,
          renderItemByIndex: i2,
          columnClassName: r2,
          className: s2,
          resizeObserver: o2,
          scrollMargin: a2
        } = e2, d2 = (0, l.useRef)(null), m2 = t2[n2.index], h2 = { "--virtual-grid-row-vertical-offset": "".concat(n2.start - a2, "px") };
        return (0, l.useEffect)(() => {
          let e3 = d2.current;
          if (e3)
            return null == o2 || o2.observe(e3), () => {
              null == o2 || o2.unobserve(e3);
            };
        }, [o2]), (0, c.jsx)("div", {
          "data-index": n2.index,
          ref: d2,
          style: h2,
          className: (0, b.$)(g().root, s2),
          children: null == m2 ? void 0 : m2.map((e3) => (0, c.jsx)("div", { className: r2, children: i2(e3) }, "".concat(n2.key, "_").concat(e3)))
        });
      });
      var _ = n(97712), x = n.n(_);
      let f = (0, v.PA)((e2) => {
        let {
          count: t2,
          rowGap: n2,
          columnGap: i2,
          getEstimateRowSize: r2,
          minColumnCount: s2 = 2,
          minColumnWidth: o2,
          maxColumnWidth: a2,
          maxColumnCount: d2,
          renderItemByIndex: m2,
          onChangeRange: v2
        } = e2, [b2, P2] = (0, u.d)(), {
          virtualizer: g2,
          rowResizeObserver: _2,
          columnCount: f2,
          indices: N
        } = h({
          count: t2,
          rowGap: n2,
          columnGap: i2,
          getEstimateRowSize: r2,
          minColumnCount: s2,
          minColumnWidth: o2,
          maxColumnWidth: a2,
          maxColumnCount: d2,
          containerRef: b2
        });
        (0, l.useEffect)(() => {
          !g2.isScrolling && g2.range && (null == v2 || v2(g2.range, f2));
        }, [v2, g2.isScrolling, g2.range, f2]);
        let S = { "--virtual-grid-height": "".concat(g2.getTotalSize(), "px"), "--virtual-grid-column-count": f2 };
        return (0, c.jsx)("div", {
          ref: P2,
          style: S,
          className: x().root,
          children: g2.getVirtualItems().map(
            (e3) => (0, c.jsx)(
              p,
              {
                className: x().row,
                columnClassName: x().column,
                virtualItem: e3,
                resizeObserver: _2,
                indices: N,
                renderItemByIndex: m2,
                scrollMargin: g2.options.scrollMargin
              },
              e3.key
            )
          )
        });
      });
    },
    80506: (e, t, n) => {
      "use strict";
      n.d(t, { a: () => r });
      var i = n(87965);
      let r = () => {
        let e2 = null, t2 = new i.cJ(false), n2 = [];
        return {
          isLoaded: t2,
          init: (i2) => {
            var r2, s;
            if (void 0 !== (null == (r2 = window.Ya) ? void 0 : r2.Metrika2) && !t2.value)
              try {
                e2 = new window.Ya.Metrika2({ ...i2 }), t2.value = true, s = e2, n2.forEach((e3) => {
                  e3(s);
                }), n2.length = 0;
              } catch (e3) {
                ("string" == typeof e3 || e3 instanceof Error) && i2.logger.error(e3);
              }
          },
          count: function(t3) {
            let i2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "counter";
            e2 ? e2.params({ [i2]: t3 }) : n2.push((e3) => {
              e3.params({ [i2]: t3 });
            });
          },
          hit: (t3) => {
            e2 ? e2.hit(t3) : n2.push((e3) => {
              e3.hit(t3);
            });
          },
          reachGoal: (t3, i2) => {
            if (!e2) return void n2.push((e3) => e3.reachGoal(t3, i2));
            e2.reachGoal(t3, i2);
          }
        };
      };
    },
    82644: (e, t, n) => {
      "use strict";
      n.d(t, { w: () => i.SomethingWentWrong });
      var i = n(75312);
    },
    82975: (e) => {
      e.exports = {
        root: "GenreArtistsPage_root__PgtIz",
        container: "GenreArtistsPage_container__NruTu",
        footer: "GenreArtistsPage_footer__fYaCO"
      };
    },
    93405: (e, t, n) => {
      "use strict";
      n.d(t, { GenrePlaylistsPage: () => f });
      var i = n(54486), r = n(50420), s = n(28303), o = n(97396), l = n(61910), a = n(43426), d = n(31500), m = n(97800), h = n(82644), c = n(33276), v = n(83909), u = n(74125), b = n(80585), P = n(49811), g = n(96777), p = n(13611), _ = n(18753), x = n.n(_);
      let f = (0, s.PA)((e2) => {
        let { metatagId: t2, preloadedMeta: n2 } = e2, {
          genre: { playlistsSubpage: s2 },
          settings: { isMobile: _2 }
        } = (0, u.Pjs)(), { formatMessage: f2 } = (0, a.A)(), { contentScrollRef: N, setContentScrollRef: S } = (0, u.gKY)(), k = (0, u.W6M)(), j = (0, l.useCallback)(
          (e3) => {
            t2 && s2.getData({ metatagId: t2, page: e3, pageSize: P.c });
          },
          [s2, t2]
        );
        (0, u.XcE)(s2.pagesLoader, j), (0, l.useEffect)(
          () => () => {
            s2.reset();
          },
          [s2]
        ), s2.isNotFound && (0, o.notFound)(), (0, u.Jzs)(s2.isResolved), ((e3) => {
          (0, l.useEffect)(() => {
            if (!e3) return;
            let t3 = ((e4) => {
              var t4, n3, i2;
              return {
                id: "",
                title: { title: "", fullTitle: e4.fullTitle || "" },
                playlists: e4.items.map(p.Ji),
                pager: {
                  page: (null == (t4 = e4.pagesLoader.pager) ? void 0 : t4.page) || 0,
                  perPage: (null == (n3 = e4.pagesLoader.pager) ? void 0 : n3.perPage) || 0,
                  total: (null == (i2 = e4.pagesLoader.pager) ? void 0 : i2.total) || 0
                }
              };
            })(e3);
            (0, g.H)(t3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, u.jxB)(e4);
            });
          }, [e3]);
        })(s2);
        let A = (0, l.useMemo)(
          () => ({ Footer: () => (0, i.jsx)(b.A, { children: (0, i.jsx)(b.wi, { className: x().footer }) }) }),
          []
        );
        if (t2 && s2.isNeededToLoad && (0, l.use)(s2.getData({ preloadedMeta: n2, metatagId: t2, page: 0, pageSize: P.c })), s2.isSomethingWrong)
          return (0, i.jsx)(h.w, {});
        let y = s2.isShimmerVisible ? 20 : s2.items.length;
        return (0, i.jsx)(u.nVz, {
          pageId: u._Q$.GENRE_PLAYLISTS,
          children: (0, i.jsx)(c.hO, {
            scrollElement: N,
            outerTitle: s2.fullTitle,
            children: (0, i.jsxs)("div", {
              className: x().root,
              ...(0, d.Am)(d.Xk.genre.GENRE_PLAYLISTS_PAGE),
              children: [
                (0, i.jsx)(b.Y9, {
                  variant: b.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: k.canBack,
                  children: (0, i.jsx)(m.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: s2.fullTitle
                  })
                }),
                (0, i.jsx)(b.$$, {
                  className: (0, r.$)(x().scrollContainer, x().important),
                  customComponents: A,
                  itemContentCallback: (e3) => {
                    let t3 = s2.items[e3], n3 = f2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: f2({ id: "entity-names.playlist" }) }
                    );
                    return t3 ? (0, i.jsx)(v.B6, { playlist: t3, contentLinesCount: 3 }, t3.key) : (0, i.jsx)(b.Vt, { "aria-label": n3 });
                  },
                  totalCount: y,
                  onGetDataByPage: j,
                  pageSize: P.c,
                  totalRequests: s2.requestsCount,
                  listClassName: x().content,
                  itemClassName: x().item,
                  handleRef: S,
                  context: { listAriaLabel: f2({ id: "mixes.playlists-list" }, { genreName: s2.fullTitle || "" }) },
                  isMobileLayout: _2,
                  useWindowScroll: _2
                })
              ]
            })
          })
        });
      });
    },
    94189: (e) => {
      e.exports = {
        root: "GenreAlbumsPage_root__r_Sts",
        scrollContainer: "GenreAlbumsPage_scrollContainer__K_v_b",
        important: "GenreAlbumsPage_important__r3P2T",
        footer: "GenreAlbumsPage_footer__vmCiR",
        item: "GenreAlbumsPage_item__zRzB0",
        content: "GenreAlbumsPage_content__PRJUm"
      };
    },
    96777: (e, t, n) => {
      "use strict";
      n.d(t, { H: () => o });
      var i = n(74125), r = n(11723), s = n(49124);
      async function o(e2, t2) {
        let { locale: n2, fullUrl: o2, url: l, tld: a, host: d } = t2, m = await (0, i.WGy)(n2), h = e2.title.fullTitle, c = m({ id: "metadata.genre-title" }, { genreTitle: h }), v = (0, r.f)({ genreTitle: h, messageFormatter: m }), u = s.env.ASSET_PREFIX || "", b = "".concat(d).concat(u, "/meta/og-image.png");
        return {
          title: c,
          description: v,
          openGraph: (0, i.i$E)({
            ogTitle: (0, i.NsT)(h),
            ogDescription: v,
            fullUrl: null != o2 ? o2 : "",
            locale: n2,
            siteName: m({ id: "metadata.yandex-music" }),
            ogImage: b
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: c,
            url: null != l ? l : "",
            appName: m({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: { tld: a, url: null != l ? l : "", fullUrl: null != o2 ? o2 : "", host: d },
            appName: m({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/genre/:metatagId/playlists", t2.tld, { params: { metatagId: e2.id } })
        };
      }
    },
    97712: (e) => {
      e.exports = {
        root: "VirtualGrid_root__nSEzJ",
        column: "VirtualGrid_column__P8hJp",
        row: "VirtualGrid_row__PL5V_"
      };
    }
  }
]);
