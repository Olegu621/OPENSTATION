(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3909],
  {
    3283: (t, i, e) => {
      "use strict";
      e.d(i, { PlaylistsCarousel: () => d });
      var l = e(54486), a = e(61910), s = e(43350), r = e(74125), n = e(80585), o = e(45318);
      let c = (t2) => {
        let {
          forwardRef: i2,
          isShimmerVisible: e2,
          isShimmerActive: a2,
          title: c2,
          description: d2,
          playlists: u,
          containerClassName: y,
          className: m,
          headerClassName: p,
          viewAllActionLink: _,
          headingVariant: v,
          ...k
        } = t2;
        return (0, l.jsx)(n.OY, {
          isShimmerVisible: e2,
          isShimmerActive: a2,
          className: m,
          headerClassName: p,
          containerClassName: y,
          ref: i2,
          title: c2,
          description: d2,
          viewAllActionLink: _,
          headingVariant: v,
          ...k,
          children: null == u ? void 0 : u.map(
            (t3, i3) => (0, l.jsx)(
              r.Bki,
              {
                objectType: s.ky.Playlist,
                objectId: t3.id,
                objectPosX: i3 + 1,
                objectPosY: 1,
                objectsCount: u.length,
                children: (0, l.jsx)(o.PlaylistCard, { playlist: t3, contentLinesCount: 3 })
              },
              t3.key
            )
          )
        });
      }, d = (0, a.forwardRef)((t2, i2) => (0, l.jsx)(c, { forwardRef: i2, ...t2 }));
    },
    23265: (t, i, e) => {
      "use strict";
      e.d(i, { r: () => s });
      var l = e(61910), a = e(43426);
      let s = (t2) => {
        let { formatMessage: i2 } = (0, a.A)();
        return (0, l.useMemo)(() => {
          let e2 = "";
          t2.isLiked && !t2.actualLikesCount ? e2 = i2({ id: "entity-names.has-your-like" }) : "number" == typeof t2.actualLikesCount && (e2 = t2.actualLikesCount > 0 ? i2({ id: "entity-names.likes-counter" }, { counter: t2.actualLikesCount }) : i2({ id: "entity-names.likes-counter-empty" }));
          let l2 = i2({ id: "entity-names.playlist-name" }, { playlistName: t2.title });
          return "".concat(l2, " ").concat(e2);
        }, [i2, t2]);
      };
    },
    25325: (t) => {
      t.exports = {
        description: "HorizontalPlaylistCard_description__KYHZF",
        likesCount: "HorizontalPlaylistCard_likesCount__rgUhr",
        tracksCount: "HorizontalPlaylistCard_tracksCount__ZdjzM",
        icon: "HorizontalPlaylistCard_icon__LHymu"
      };
    },
    45318: (t, i, e) => {
      "use strict";
      e.d(i, { PlaylistCard: () => b });
      var l = e(54486), a = e(50420), s = e(28303), r = e(61910), n = e(43426), o = e(43350), c = e(31500), d = e(63585), u = e(8817), y = e(27510), m = e(71712), p = e(5956), _ = e(6971), v = e(97800), k = e(63695), C = e(13611), P = e(74125), x = e(80585), g = e(23265), h = e(61958), j = e(83504);
      let L = (0, s.PA)((t2) => {
        var i2;
        let { playlist: e2, onOpenChange: a2, open: s2, ...r2 } = t2, { shouldShowBuySubscriptionModal: d2, showBuySubscriptionModal: y2 } = (0, P.qBP)(), {
          experiments: m2,
          settings: { isMobile: p2 },
          trailer: _2,
          user: v2
        } = (0, P.Pjs)(), k2 = (0, C.KX)(e2), g2 = (0, C.A7)(e2), L2 = (0, P.Ftl)(), { formatMessage: A2 } = (0, n.A)(), f2 = (0, P.PT7)(), b2 = m2.checkExperiment(P.zal.WebEditorsFeatures, "on"), K = (0, j.A_)({ entityVariant: P.DwC.PLAYLIST, urlParams: { id: e2.uid, kind: e2.kind } });
        (0, P.NBO)(s2);
        let N = (0, u.c)(() => {
          if (d2) return void y2();
          f2() || (_2.openPlaylistTrailer(e2.id), L2(o.ky.Playlist, e2.id));
        });
        return (0, l.jsxs)(h.W1, {
          title: e2.title,
          onOpenChange: a2,
          open: s2,
          offsetOptions: 10,
          isMobile: p2,
          ariaLabel: A2({ id: "interface-actions.context-menu" }),
          containerProps: (0, c.Am)(c.Kq.playlist.PLAYLIST_CONTEXT_MENU),
          ...r2,
          children: [
            b2 && (0, l.jsx)(j.dx, { entityVariant: P.DwC.PLAYLIST, adminUrl: e2.isFavouritePlaylist ? void 0 : K }),
            !p2 && (0, l.jsx)(x.L1, { onClick: g2, isPinned: e2.isPinned }),
            !e2.isFavouritePlaylist && (0, l.jsx)(x.TW, { onClick: k2, isLiked: e2.isLiked, disabled: !v2.isAuthorized }),
            (null == (i2 = e2.trailer) ? void 0 : i2.isAvailable) && (0, l.jsx)(x.No, { onClick: N, disabled: !e2.isAvailable })
          ]
        });
      });
      var A = e(57333), f = e.n(A);
      let b = (0, s.PA)((t2) => {
        let { className: i2, playlist: e2, children: s2, contentLinesCount: h2, customDescription: j2 } = t2, { ref: A2, intersectionPropertyId: b2 } = (0, P.nMI)(), { trailer: K, user: N } = (0, P.Pjs)(), { from: B, utmLink: T } = (0, P.fyy)({ contextId: e2.uuid, contextType: d.K.Playlist }), { formatMessage: w } = (0, n.A)(), { sendLikeSearchFeedback: z, sendNavigateSearchFeedback: E, sendPlaySearchFeedback: I } = (0, P.zEv)(), [F, S] = (0, r.useState)(false), [R, M] = (0, r.useState)(false), [O, $] = (0, r.useState)(false), Y = (0, g.r)(e2), D = (0, C.KX)(e2), U = (0, C.A7)(e2), q = (0, P.NKK)(), H = (0, P.brA)(), Z = (0, P.ZpR)(e2.url), X = (0, P.Ftl)(), W = (0, P.PT7)(), Q = (0, u.c)((t3) => {
          if (t3.stopPropagation(), W()) return void t3.preventDefault();
          K.setUtmLink(T), K.openPlaylistTrailer(e2.id), X(o.ky.Playlist, e2.id);
        }), [V, J] = (0, r.useState)(false), { isPlaying: G, togglePlay: tt } = (0, P.Dx4)({
          playContextParams: {
            contextData: { type: d.K.Playlist, meta: { id: e2.id, uuid: e2.uuid }, from: B, utmLink: T },
            loadContextMeta: true
          }
        }), ti = (0, u.c)(() => {
          q({ to: o.QT.PlaylistScreen }), null == E || E();
        }), te = (0, u.c)((t3) => {
          ti(), Z(t3);
        }), tl = (0, u.c)(() => {
          W() || (F || G || (S(true), null == I || I()), tt(), H(!G));
        }), ta = (0, u.c)(() => {
          R || e2.isLiked || (M(true), null == z || z()), D();
        }), ts = (0, u.c)((t3) => {
          t3.preventDefault(), t3.stopPropagation();
        }), tr = (0, u.c)((t3) => {
          $(t3), J(t3);
        }), tn = (0, r.useMemo)(() => {
          var t3;
          return j2 ? (0, l.jsx)(
            v.Caption,
            { variant: "span", type: "entity", size: "s", weight: "medium", lineClamp: 2, children: j2 },
            e2.getKey("description")
          ) : (null == (t3 = e2.artists) ? void 0 : t3.length) ? (0, l.jsx)(
            k.iQ,
            {
              className: f().artists,
              artists: e2.artists,
              lineClamp: 1,
              linkClassName: f().artistLink,
              captionSize: "s"
            },
            e2.getKey("description")
          ) : void 0;
        }, [j2, e2]), to = (0, y.L)(() => {
          if (!e2.isFavouritePlaylist)
            return (0, l.jsx)(
              x.cy,
              {
                className: (0, a.$)(f().likeButton, f().control),
                isLiked: e2.isLiked,
                onClick: ta,
                variant: "default",
                size: "s",
                iconSize: "xxs",
                disabled: !N.isAuthorized
              },
              e2.getKey("LikeButton")
            );
        }), tc = (0, r.useMemo)(() => {
          var t3;
          if (null == e2 || null == (t3 = e2.trailer) ? void 0 : t3.isAvailable)
            return (0, l.jsx)(
              x.nE,
              {
                children: (0, l.jsx)(
                  x.kJ,
                  {
                    className: (0, a.$)(f().trailerButton, f().control),
                    radius: "round",
                    size: "s",
                    iconSize: "xxs",
                    onClick: Q
                  },
                  e2.getKey("TrailerButton")
                )
              },
              e2.getKey("PlaylilstCardTrailerTooltip")
            );
        }, [Q, e2]), td = (0, r.useMemo)(
          () => (0, l.jsx)(
            x.O0,
            { onClick: U, isPinned: e2.isPinned, className: (0, a.$)(f().pinButton, f().control), withRipple: false },
            e2.getKey("PinButton")
          ),
          [U, e2]
        ), tu = (0, r.useMemo)(
          () => (0, l.jsx)(_.Paper, {
            className: f().cover,
            radius: "s",
            withShadow: true,
            ...(0, c.Am)(c.Kq.playlist.PLAYLIST_CARD),
            children: (0, l.jsxs)("div", {
              className: f().coverBlock,
              onClick: te,
              children: [
                (0, l.jsx)(x.BW, {
                  className: f().image,
                  src: e2.coverUri,
                  size: 200,
                  fit: "cover",
                  alt: Y,
                  withAvatarReplace: true,
                  "aria-hidden": true
                }),
                (0, l.jsx)(m.hg, {
                  isVisible: O || V,
                  className: f().controls,
                  playControl: (0, l.jsx)(
                    x.DM,
                    {
                      className: (0, a.$)(f().playButton, f().control),
                      buttonVariant: "default",
                      withHover: false,
                      iconSize: "xl",
                      variant: "filled",
                      onClick: tl,
                      isPlaying: G,
                      disabled: !e2.isAvailable
                    },
                    e2.getKey("PlayButton")
                  ),
                  likeControl: to,
                  menuControl: (0, l.jsx)(
                    L,
                    {
                      playlist: e2,
                      onOpenChange: tr,
                      open: O,
                      onClick: ts,
                      className: (0, a.$)(f().menuButton, f().control),
                      icon: (0, l.jsx)(p.Icon, { size: "xxs", variant: "more" }),
                      size: "s",
                      ...(0, c.Am)(c.Kq.playlist.PLAYLIST_CONTEXT_MENU_BUTTON)
                    },
                    e2.getKey("PlaylistContextMenu")
                  ),
                  pinControl: td,
                  trailerControl: tc
                })
              ]
            })
          }),
          [te, e2, Y, O, V, tl, G, to, tr, ts, td, tc]
        ), ty = !!e2.actualLikesCount && !e2.isLikesCountHidden;
        return (0, l.jsxs)(m.MN, {
          ref: A2,
          "aria-label": Y,
          className: (0, a.$)(f().root, i2),
          title: (0, l.jsx)(v.Caption, {
            variant: "div",
            type: "entity",
            size: "s",
            weight: "medium",
            lineClamp: 2,
            ...(0, c.Am)(c.Kq.playlist.PLAYLIST_TITLE),
            children: (0, l.jsx)(x.N_, { className: f().titleLink, href: e2.url, onClick: ti, children: e2.title })
          }),
          srTitle: (0, l.jsx)(x.N_, { href: e2.url, onClick: ti, children: e2.title }),
          "data-intersection-property-id": b2,
          contentLinesCount: h2,
          view: tu,
          description: tn,
          ...(0, c.Am)(c.Kq.playlist.PLAYLIST_ITEM),
          children: [
            ty && (0, l.jsx)(x.xW, {
              ariaLabel: w({ id: "entity-names.likes-counter" }, { counter: e2.actualLikesCount }),
              likesCount: e2.actualLikesCount,
              isLiked: e2.isLiked,
              handleLikeClick: D
            }),
            s2
          ]
        });
      });
    },
    57333: (t) => {
      t.exports = {
        root: "PlaylistCard_root__i3pR4",
        controls: "PlaylistCard_controls__Ej8Rz",
        cover: "PlaylistCard_cover__tpK5L",
        coverBlock: "PlaylistCard_coverBlock__1slsN",
        image: "PlaylistCard_image__Li6oy",
        titleLink: "PlaylistCard_titleLink__H8qEc",
        artists: "PlaylistCard_artists__HtVIF",
        artistLink: "PlaylistCard_artistLink__jx3KB",
        playButton: "PlaylistCard_playButton__eaduk",
        likeButton: "PlaylistCard_likeButton__RYXJz",
        menuButton: "PlaylistCard_menuButton__jFcWr",
        pinButton: "PlaylistCard_pinButton__jhWnL",
        trailerButton: "PlaylistCard_trailerButton__Qjg_U",
        control: "PlaylistCard_control__73YUq"
      };
    },
    61352: (t) => {
      t.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "ControlsBar_root__mf9o_",
        item: "ControlsBar_item__4YJMp",
        item_buttonArrow: "ControlsBar_item_buttonArrow__9hTqa",
        controls: "ControlsBar_controls__DcFpX",
        likeIcon: "ControlsBar_likeIcon__g8y02",
        trailerIcon: "ControlsBar_trailerIcon__iH6eY",
        controls_disabled: "ControlsBar_controls_disabled___hlf6"
      };
    },
    66894: (t, i, e) => {
      "use strict";
      e.d(i, { HorizontalPlaylistCard: () => A });
      var l = e(54486), a = e(50420), s = e(28303), r = e(61910), n = e(43426), o = e(47713), c = e(43350), d = e(31500), u = e(63585), y = e(8817), m = e(73633), p = e(5956), _ = e(97800), v = e(74125), k = e(80585), C = e(23265), P = e(13611), x = e(61352), g = e.n(x);
      let h = (0, s.PA)((t2) => {
        var i2;
        let { className: e2, playlist: s2, likeIconSize: n2 = "xxs" } = t2, { user: o2, trailer: d2 } = (0, v.Pjs)(), u2 = (0, v.PT7)(), { sendLikeSearchFeedback: m2 } = (0, v.zEv)(), _2 = (0, P.KX)(s2), [C2, x2] = (0, r.useState)(false), h2 = (0, y.c)(async () => {
          C2 || s2.isLiked || (x2(true), null == m2 || m2()), await _2();
        }), j2 = (0, v.Ftl)(), L2 = (0, y.c)((t3) => {
          if (t3.stopPropagation(), u2()) return void t3.preventDefault();
          d2.openPlaylistTrailer(s2.id), j2(c.ky.Playlist, s2.id);
        });
        return (0, l.jsxs)("div", {
          className: (0, a.$)(g().root, g().controls, e2, { [g().controls_disabled]: !s2.isAvailable }),
          children: [
            s2.isAvailable && (0, l.jsxs)(l.Fragment, {
              children: [
                (0, l.jsx)(k.aQ, {
                  fallback: (0, l.jsx)(k.cy, {
                    size: "xs",
                    iconSize: n2,
                    className: (0, a.$)(g().item, g().likeIcon),
                    isLiked: s2.isLiked,
                    onClick: h2,
                    disabled: !o2.isAuthorized
                  })
                }),
                (null == (i2 = s2.trailer) ? void 0 : i2.isAvailable) && (0, l.jsx)(k.aQ, {
                  fallback: (0, l.jsx)(k.kJ, {
                    className: (0, a.$)(g().item, g().trailerIcon),
                    iconSize: "xs",
                    variant: "text",
                    onClick: L2,
                    withRipple: false
                  })
                })
              ]
            }),
            (0, l.jsx)("div", {
              className: (0, a.$)(g().item, g().item_buttonArrow),
              children: (0, l.jsx)(p.Icon, { className: k.$f.buttonArrow, variant: "arrowRight", size: "xs" })
            })
          ]
        });
      });
      var j = e(25325), L = e.n(j);
      let A = (0, s.PA)((t2) => {
        let { className: i2, playlist: e2, pageId: s2, coverClassName: P2, playButtonIconSize: x2, likeIconSize: g2 } = t2, { ref: j2, intersectionPropertyId: A2 } = (0, v.nMI)(), { from: f } = (0, v.fyy)({ pageId: s2 }), [b, K] = (0, r.useState)(false), N = (0, v.brA)(), B = (0, C.r)(e2), T = e2.title || "", { formatMessage: w, formatNumber: z } = (0, n.A)(), E = (0, v.PT7)(), { sendNavigateSearchFeedback: I, sendPlaySearchFeedback: F } = (0, v.zEv)(), S = (0, v.NKK)(), {
          isPlaying: R,
          isCurrent: M,
          togglePlay: O
        } = (0, v.Dx4)({
          playContextParams: {
            contextData: { type: u.K.Playlist, meta: { id: e2.id, uuid: e2.uuid }, from: f },
            loadContextMeta: true
          }
        }), $ = (0, v.ZpR)(e2.url), Y = (0, y.c)((t3) => {
          null == I || I(), S({ to: c.QT.PlaylistScreen }), t3.preventDefault(), $(t3);
        }), D = (0, y.c)(() => {
          E() || (b || R || (K(true), null == F || F()), O(), N(!R));
        }), U = (0, y.c)((t3) => {
          (0, m.P)(t3, k.$f.ripple), Y(t3);
        }), q = (0, y.c)((t3) => {
          t3.stopPropagation(), Y(t3);
        }), H = (0, r.useCallback)(
          (t3) => (0, l.jsx)(k.q1, {
            isAvailable: e2.isAvailable,
            isDisliked: false,
            coverUri: e2.coverUri,
            title: T,
            className: (0, a.$)(k.$f.playButtonCell, P2),
            alt: w({ id: "entity-names.playlist-name" }, { playlistName: T }),
            radius: "xs",
            ...t3
          }),
          [e2, T, P2, w]
        ), Z = null == H ? void 0 : H({ onPlayButtonClick: D, isPlaying: R, isCurrent: M, playButtonIconSize: x2 }), X = (0, r.useMemo)(
          () => e2.url && e2.isAvailable ? (0, l.jsx)(k.N_, {
            className: (0, a.$)(k.$f.text, k.$f.titleLink),
            href: e2.url,
            onClick: q,
            children: T
          }) : (0, l.jsx)(_.Caption, {
            className: (0, a.$)(k.$f.text, k.$f.titleText),
            size: "m",
            variant: "div",
            type: "text",
            children: T
          }),
          [q, e2.isAvailable, e2.url, T]
        ), W = (0, r.useMemo)(() => {
          if (void 0 === e2.actualLikesCount || void 0 === e2.tracksCount) return;
          let t3 = (0, l.jsx)(_.Caption, {
            variant: "span",
            size: "m",
            weight: "medium",
            "aria-hidden": true,
            children: "•"
          }), i3 = e2.isLiked ? "likedVariant" : "likeVariant", a2 = "".concat(B, " ").concat(w({ id: "entity-names.tracks-count" }, { value: e2.tracksCount }));
          return (0, l.jsxs)("div", {
            className: L().description,
            "aria-label": a2,
            children: [
              (0, l.jsxs)("div", {
                className: L().likesCount,
                "aria-hidden": true,
                children: [
                  (0, l.jsx)(p.Icon, { className: L().icon, variant: i3, size: "xxs" }),
                  (0, l.jsx)(_.Caption, {
                    variant: "span",
                    size: "m",
                    weight: "medium",
                    children: z(e2.actualLikesCount)
                  })
                ]
              }),
              (0, l.jsxs)("div", {
                className: L().tracksCount,
                "aria-hidden": true,
                children: [
                  t3,
                  (0, l.jsx)(_.Caption, {
                    variant: "span",
                    size: "m",
                    weight: "medium",
                    children: (0, l.jsx)(o.A, {
                      id: "entity-names.tracks-count",
                      values: { value: z(e2.tracksCount) }
                    })
                  })
                ]
              })
            ]
          });
        }, [w, z, B, e2.actualLikesCount, e2.isLiked, e2.tracksCount]);
        return (0, l.jsxs)(k.Cj, {
          ref: j2,
          "data-intersection-property-id": A2,
          className: (0, a.$)(k.$f.root, { [k.$f.root_disabled]: !e2.isAvailable }, i2),
          "aria-label": e2.title || w({ id: "entity-names.playlist" }),
          onClick: U,
          ...(0, d.Am)(d.Kq.playlist.HORIZONTAL_PLAYLIST_CARD),
          children: [
            Z,
            (0, l.jsx)(k.ro, { isDisabled: !e2.isAvailable, title: X, description: W }),
            (0, l.jsx)(h, { playlist: e2, likeIconSize: g2 })
          ]
        });
      });
    },
    67317: (t) => {
      t.exports = {
        root: "EmptyPlaylistBlock_root__wpA0j",
        iconBackground: "EmptyPlaylistBlock_iconBackground__pnUlz",
        title: "EmptyPlaylistBlock_title__pQQLf",
        subtitle: "EmptyPlaylistBlock_subtitle__P4Q7x"
      };
    },
    72467: (t, i, e) => {
      "use strict";
      e.d(i, { EmptyPlaylistBlock: () => y });
      var l = e(54486), a = e(50420), s = e(61910), r = e(47713), n = e(31500), o = e(5956), c = e(97800), d = e(67317), u = e.n(d);
      let y = (t2) => {
        let { className: i2, isEmptySearch: e2 } = t2, d2 = (0, s.useMemo)(
          () => e2 ? (0, l.jsx)(r.A, { id: "search-results.not-found-title" }) : (0, l.jsx)(r.A, { id: "error-messages.empty-collection-playlist-title" }),
          [e2]
        ), y2 = (0, s.useMemo)(
          () => e2 ? (0, l.jsx)(r.A, { id: "search-results.not-found-description" }) : (0, l.jsx)(r.A, { id: "error-messages.empty-collection-playlist-description" }),
          [e2]
        );
        return (0, l.jsxs)("div", {
          className: (0, a.$)(u().root, i2),
          ...(0, n.Am)(n.Kq.playlist.PLAYLIST_EMPTY_BLOCK),
          children: [
            (0, l.jsx)("div", {
              className: u().iconBackground,
              children: (0, l.jsx)(o.Icon, {
                variant: "search",
                size: "l",
                className: u().icon,
                ...(0, n.Am)(n.Kq.playlist.PLAYLIST_EMPTY_BLOCK_ICON)
              })
            }),
            (0, l.jsx)(c.Heading, {
              variant: "h3",
              size: "xs",
              className: u().title,
              ...(0, n.Am)(n.Kq.playlist.PLAYLIST_EMPTY_BLOCK_TITLE),
              children: d2
            }),
            (0, l.jsx)(c.Caption, {
              variant: "span",
              size: "l",
              className: u().subtitle,
              ...(0, n.Am)(n.Kq.playlist.PLAYLIST_EMPTY_BLOCK_TEXT),
              children: y2
            })
          ]
        });
      };
    },
    83909: (t, i, e) => {
      "use strict";
      e.d(i, {
        pA: () => g.EmptyPlaylistBlock,
        vf: () => h.HorizontalPlaylistCard,
        B6: () => j.PlaylistCard,
        BL: () => P,
        IP: () => x,
        EC: () => L.PlaylistsCarousel,
        bk: () => s,
        ZC: () => c,
        Ew: () => u,
        pd: () => m
      });
      var l = e(93064), a = e(74125);
      let s = (t2) => {
        var i2, e2;
        let { playlist: s2, generatedPlaylistType: r2, likesCount: n2, trailer: o2, tracksCount: c2 } = t2;
        return (0, l.wg)({
          isAvailable: null == (e2 = s2.available) || e2,
          uuid: s2.playlistUuid,
          title: s2.title,
          uid: s2.uid,
          kind: s2.kind,
          coverUri: null == (i2 = s2.cover) ? void 0 : i2.uri,
          generatedPlaylistType: r2,
          likesCount: n2,
          tracksCount: c2,
          trailer: (0, a.mxW)(o2)
        });
      };
      var r = e(97396), n = e(61910);
      (0, n.cache)(async (t2, i2) => {
        var e2;
        let l2;
        try {
          let {
            container: e3,
            backendHostTld: s2,
            locale: r2,
            host: n2,
            fullUrl: o2,
            isRSC: c2,
            requestUrl: d2
          } = await (0, a.IhE)();
          if (c2) return { playlist: void 0, backendHostTld: s2, locale: r2, host: n2, fullUrl: o2, requestUrl: d2 };
          let u2 = e3.get(a._19);
          l2 = {
            playlist: await u2.getPlaylistWithTracksIds({ userId: t2, playlistKind: i2, resumeStream: false }),
            backendHostTld: s2,
            locale: r2,
            host: n2,
            fullUrl: o2,
            requestUrl: d2
          };
        } catch (t3) {
          return (0, a.tfF)(t3, () => ({ playlist: void 0, ...(0, a.Bj3)() }));
        }
        return (null == (e2 = l2.playlist) ? void 0 : e2.error) === "not-found" && (0, r.notFound)(), l2;
      }), (0, n.cache)(async (t2) => {
        var i2;
        let e2;
        (0, a.sU0)(t2) || (0, r.notFound)();
        try {
          let {
            container: i3,
            backendHostTld: l2,
            locale: s2,
            host: r2,
            fullUrl: n2,
            isRSC: o2,
            requestUrl: c2
          } = await (0, a.IhE)();
          if (o2) return { playlist: void 0, backendHostTld: l2, locale: s2, host: r2, fullUrl: n2, requestUrl: c2 };
          let d2 = i3.get(a.qNr);
          e2 = {
            playlist: await d2.getPlaylist({ playlistUuid: t2, resumeStream: false, richTracks: false }),
            backendHostTld: l2,
            locale: s2,
            host: r2,
            fullUrl: n2,
            requestUrl: c2
          };
        } catch (t3) {
          return (0, a.tfF)(t3, () => ({ playlist: void 0, ...(0, a.Bj3)() }));
        }
        return (null == (i2 = e2.playlist) ? void 0 : i2.error) === "not-found" && (0, r.notFound)(), e2;
      });
      var o = e(13611);
      let c = (t2) => (0, l.wg)({
        ...(0, o.jX)(t2),
        owner: t2.owner ? ((t3) => ({ uid: t3.uid, login: t3.login, name: t3.name, sex: t3.sex, verified: t3.verified }))(t2.owner) : void 0,
        description: t2.description,
        tags: t2.tags,
        modified: t2.modified,
        madeFor: t2.madeFor ? ((t3) => (0, l.wg)({ caseForms: t3.caseForms ? (0, a.NH4)(t3.caseForms) : null }))(t2.madeFor) : null
      });
      var d = e(63695);
      let u = (t2) => {
        var i2, e2;
        return (0, l.wg)({
          ...(0, o.jX)(t2),
          artists: null != (e2 = null == t2 || null == (i2 = t2.artists) ? void 0 : i2.map(d.dM)) ? e2 : []
        });
      };
      var y = e(54460);
      let m = (t2) => {
        var i2, e2;
        return (0, l.wg)({
          ...(0, o.jX)(t2),
          tracks: null != (e2 = null == t2 || null == (i2 = t2.tracks) ? void 0 : i2.map(y.Rw)) ? e2 : []
        });
      };
      var p = e(26433);
      let _ = l.gK.model("PlaylistOwner", { caseForms: l.gK.maybeNull(p.lg) });
      var v = e(66534);
      let k = l.gK.model("PlaylistOwner", {
        uid: l.gK.number,
        login: l.gK.string,
        name: l.gK.string,
        sex: l.gK.enumeration(Object.values(v.U)),
        verified: l.gK.boolean
      }), C = l.gK.model("PlaylistTag", { id: l.gK.string, value: l.gK.string }), P = o.$o.props({
        owner: l.gK.maybe(k),
        modified: l.gK.string,
        description: l.gK.maybe(l.gK.string),
        tags: l.gK.maybeNull(l.gK.array(C)),
        madeFor: l.gK.maybeNull(_)
      }).views((t2) => ({
        get seeds() {
          var i2;
          return ["playlist:".concat(null == (i2 = t2.owner) ? void 0 : i2.login, "_").concat(t2.kind)];
        },
        get tagsString() {
          let { experiments: i2 } = (0, l.Zn)(t2);
          if (!i2.checkExperiment(a.zal.WebEditorsFeatures, "on") || !Array.isArray(t2.tags) || !t2.tags.length)
            return null;
          return t2.tags.map((t3) => t3.value).join(", ");
        }
      })).actions((t2) => ({
        changeDescription: (0, l.L3)(function* (i2) {
          if (!(0, l._n)(t2)) return a.FlZ.ERROR;
          if (t2.description === i2) return a.FlZ.OK;
          if (i2.length > o.iz) return a.FlZ.ERROR;
          let { usersResource: e2, modelActionsLogger: s2 } = (0, l._$)(t2);
          if (t2.canUserChange) {
            let l2 = t2.description;
            t2.description = i2;
            try {
              let l3 = yield e2.changePlaylistDescription({ description: i2, userId: t2.uid, playlistKind: t2.kind });
              return t2.description = l3.description, a.FlZ.OK;
            } catch (i3) {
              t2.description = l2, s2.error(i3);
            }
          }
          return a.FlZ.ERROR;
        }),
        changePlaylistCover: (0, l.L3)(function* (i2) {
          if (!(0, l._n)(t2)) return a.FlZ.ERROR;
          let { usersResource: e2, modelActionsLogger: s2 } = (0, l._$)(t2);
          try {
            let l2 = yield e2.uploadPlaylistCover({ userId: t2.uid, formData: i2, playlistKind: t2.kind });
            return t2.coverUri = l2.cover.uri, a.FlZ.OK;
          } catch (t3) {
            s2.error(t3);
          }
          return a.FlZ.ERROR;
        })
      })).named("PlaylistMeta"), x = o.Zq.props({ artists: l.gK.maybe(l.gK.array(d.PK)) });
      var g = e(72467), h = e(66894), j = e(45318), L = e(3283);
    }
  }
]);
