"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4367],
  {
    36748: (e, t, i) => {
      i.d(t, { dx: () => d, l$: () => R.AlbumPage, MH: () => N, Wh: () => J }), i(2576);
      var l, n, a = i(93064), s = i(74125), r = i(26433);
      let o = a.gK.model("Cpa", { clid: a.gK.string, artistId: a.gK.number }), d = a.gK.compose(a.gK.model("AlbumCpa", { albumId: a.gK.maybeNull(a.gK.number), cpa: a.gK.maybeNull(o) }), r.pl).views((e2) => ({
        isPlusCPAEnabled(t2) {
          let { pageAlbumId: i2, albumId: l2, isNonMusic: n2 } = t2, {
            experiments: s2,
            user: { isAuthorized: r2 }
          } = (0, a.Zn)(e2);
          return false;
        },
        isPlusCPAPlayerBarEnabled(t2, i2) {
          let {
            experiments: l2,
            user: { hasPlus: n2 }
          } = (0, a.Zn)(e2);
          return false;
        },
        isPlusCPABannerEnabled(t2) {
          var i2;
          let { pageAlbumId: l2, albumId: n2, isNonMusic: s2 } = t2, {
            experiments: r2,
            settings: o2,
            user: { hasPlus: d2 }
          } = (0, a.Zn)(e2);
          return null == (i2 = o2.browserInfo) || i2.isTouch, false;
        },
        isHidePlusModalEnabled(t2, i2) {
          var l2;
          let {
            experiments: n2,
            settings: s2,
            user: { hasPlus: r2 }
          } = (0, a.Zn)(e2);
          return null == (l2 = s2.browserInfo) || l2.isTouch, false;
        }
      })).actions((e2) => ({
        getCpa: (0, a.L3)(function* (t2) {
          let { albumId: i2, preloadedCpa: l2 } = t2, { experiments: n2, user: s2 } = (0, a.Zn)(e2);
        }),
        reset() {
          e2.albumId = null, e2.destroyItems([e2.cpa]);
        }
      }));
      var u = i(14287), m = i(58623), g = i(8075);
      (l || (l = {})).RECENT_ALBUMS = "recent-albums", (function(e2) {
        e2[e2.DAY = 1] = "DAY", e2[e2.WEEK = 7] = "WEEK", e2[e2.MONTH = 30] = "MONTH";
      })(n || (n = {}));
      var c = i(12460), b = i(8593), E = i(4542), v = i(94376), A = i(7981), h = i(97719), p = i(21365), S = i(46423);
      let L = (e2) => (0, a.wg)({ type: S.rU.TEXT, data: null != e2 ? e2 : null, loadingState: s.GuX.RESOLVE }), G = (e2) => {
        var t2;
        let { data: i2, ...l2 } = e2;
        return (0, a.wg)({
          type: null != (t2 = null == i2 ? void 0 : i2.type) ? t2 : g.S.TRACK,
          data: null != i2 ? i2 : null,
          ...l2
        });
      }, I = (e2) => "".concat(e2, "-text"), y = (e2) => String(e2), C = (e2) => (0, a.wg)({ id: e2.id, type: e2.type, title: e2.title, albums: e2.albums.map(v.pp) }), f = (e2) => !!(e2 && "position" in e2), T = a.gK.compose(a.gK.model("AlbumDonations", { items: a.gK.maybeNull(a.gK.array(A.eG)) }), r.pl, r.XT).actions((e2) => ({
        reset() {
          e2.loadingState = s.GuX.IDLE, e2.destroyItems([e2.items]);
        }
      })), X = a.gK.model("LabelItem", { id: a.gK.number, name: a.gK.string }), K = a.gK.compose(a.gK.model("RelatedAlbumsPage", { items: a.gK.array(v.JC) }), r.pl, r.XT).actions((e2) => ({
        reset() {
          e2.loadingState = s.GuX.IDLE, e2.destroyItems([e2.items]);
        }
      })), k = a.gK.compose(a.gK.model("RelatedContent", { items: a.gK.maybeNull(a.gK.array(b.N3)) }), r.pl, r.XT).actions((e2) => ({
        reset() {
          e2.loadingState = s.GuX.IDLE, e2.destroyItems([e2.items]);
        }
      })), N = a.gK.compose(
        a.gK.model("AlbumPage", {
          id: a.gK.maybeNull(a.gK.number),
          meta: a.gK.maybeNull(v.JC),
          items: a.gK.array(b.PX),
          indexItems: a.gK.map(a.gK.array(a.gK.number)),
          errorStatusCode: a.gK.maybeNull(a.gK.number),
          deprecationTargetAlbumId: a.gK.maybeNull(a.gK.number),
          latestGenreAlbums: a.gK.maybe(K),
          otherArtistAlbums: a.gK.maybe(K),
          otherAlbumVersions: a.gK.maybe(a.gK.array(v.JC)),
          labels: a.gK.maybeNull(a.gK.array(X)),
          description: a.gK.maybe(a.gK.string),
          donations: a.gK.maybe(T),
          relatedContent: a.gK.maybe(k),
          allTracksUnfinished: a.gK.boolean,
          similarEntities: E.F6
        }),
        r.Ec,
        r.pl,
        r.XT
      ).views((e2) => {
        let t2 = {
          get isOtherArtistAlbumsAvailable() {
            var i2, l2, n2, r2, o2;
            return !!(!(null == (i2 = e2.meta) ? void 0 : i2.isNonMusic) && (null == (n2 = e2.meta) || null == (l2 = n2.artists) ? void 0 : l2.length) === 1 && !(null == (o2 = e2.meta) || null == (r2 = o2.artists[0]) ? void 0 : r2.various));
          },
          get isLatestGenreAlbumsAvailable() {
            var d2, m2;
            return !!(!(null == (d2 = e2.meta) ? void 0 : d2.isNonMusic) && (null == (m2 = e2.meta) ? void 0 : m2.genre));
          },
          get isNotFound() {
            return e2.isRejected && (e2.errorStatusCode === u.X1.NOT_FOUND || e2.errorStatusCode === u.X1.BAD_REQUEST);
          },
          get isSimilarEntitiesEnabled() {
            let { experiments: t3 } = (0, a.Zn)(e2);
            return t3.checkExperiment(s.zal.WebNextWaveAgentExperiment, "on");
          },
          get isCacheNotFound() {
            return e2.isRejected && e2.errorStatusCode === c.FX;
          },
          get hasDonations() {
            var g2;
            return !!((null == (g2 = e2.donations) ? void 0 : g2.isResolved) && e2.donations && e2.donations.items && e2.donations.items.length > 0);
          },
          get hasSimilarEntities() {
            var b2;
            return !!(t2.isSimilarEntitiesEnabled && e2.similarEntities.isLoaded && (null == (b2 = e2.similarEntities.data) ? void 0 : b2.items) && e2.similarEntities.data.items.length > 0);
          },
          get hasOtherAlbumVersions() {
            return !!(e2.isNeededToLoad || e2.loadingState === s.GuX.PENDING || e2.otherAlbumVersions && e2.otherAlbumVersions.length > 0);
          },
          get hasLatestGenreAlbums() {
            var E2, v2;
            let i2 = e2.latestGenreAlbums && e2.latestGenreAlbums.items && e2.latestGenreAlbums.items.length > 0;
            return !!(t2.isLatestGenreAlbumsAvailable && ((null == (E2 = e2.latestGenreAlbums) ? void 0 : E2.isNeededToLoad) || (null == (v2 = e2.latestGenreAlbums) ? void 0 : v2.isLoading) || i2));
          },
          get hasOtherArtistAlbums() {
            var A2, h2;
            let i2 = e2.otherArtistAlbums && e2.otherArtistAlbums.items && e2.otherArtistAlbums.items.length > 0;
            return !!(t2.isOtherArtistAlbumsAvailable && ((null == (A2 = e2.otherArtistAlbums) ? void 0 : A2.isNeededToLoad) || (null == (h2 = e2.otherArtistAlbums) ? void 0 : h2.isLoading) || i2));
          },
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === s.GuX.PENDING;
          },
          get isLatestGenreAlbumsLoading() {
            var p2, L2;
            return !!((null == (p2 = e2.latestGenreAlbums) ? void 0 : p2.isNeededToLoad) || (null == (L2 = e2.latestGenreAlbums) ? void 0 : L2.isLoading));
          },
          get isOtherArtistAlbumsLoading() {
            var G2, I2;
            return !!((null == (G2 = e2.otherArtistAlbums) ? void 0 : G2.isNeededToLoad) || (null == (I2 = e2.otherArtistAlbums) ? void 0 : I2.isLoading));
          },
          get isRelatedContentLoading() {
            var y2, C2;
            return !!((null == (y2 = e2.relatedContent) ? void 0 : y2.isNeededToLoad) || (null == (C2 = e2.relatedContent) ? void 0 : C2.isLoading));
          },
          get contextMeta() {
            var f2, T2, X2, K2, k2, N2, R2, D2, P2;
            return {
              id: e2.meta.id,
              title: null == (f2 = e2.meta) ? void 0 : f2.title,
              coverUri: null == (T2 = e2.meta) ? void 0 : T2.coverUri,
              type: null == (X2 = e2.meta) ? void 0 : X2.type,
              year: null == (K2 = e2.meta) ? void 0 : K2.year,
              version: null == (k2 = e2.meta) ? void 0 : k2.version,
              genre: null == (N2 = e2.meta) ? void 0 : N2.genre,
              likesCount: null == (R2 = e2.meta) ? void 0 : R2.likesCount,
              averageColor: null == (D2 = e2.meta) ? void 0 : D2.averageColor,
              available: null == (P2 = e2.meta) ? void 0 : P2.isAvailable
            };
          },
          get tracks() {
            return e2.items.filter((e3) => e3.type !== S.rU.TEXT);
          },
          get lastEpisodes() {
            return t2.tracks.slice(0, 5);
          },
          get lastEpisodesTrackIds() {
            return t2.lastEpisodes.map((e3) => e3.id);
          },
          get hasLabel() {
            return !!(e2.labels && e2.labels.length);
          },
          get shouldShowLabel() {
            let { experiments: i2 } = (0, a.Zn)(e2);
            return t2.hasLabel && i2.checkExperiment(s.zal.WebNextLabelPage, "on");
          },
          labelUrl(e3) {
            let { href: t3 } = (0, s.uvd)("/label/:labelId", { params: { labelId: e3 } });
            return t3;
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          makeFlatVolumeItems: (t3) => {
            let i2 = 0;
            t3.volumes.forEach((l2) => {
              t3.volumes.length > 1 && l2[0] && (e2.items.push(L()), e2.indexItems.set(I(l2[0].id), [e2.items.length - 1])), l2.forEach((t4) => {
                e2.items.push(G({ id: t4.id, loadingState: s.GuX.IDLE, positionInContext: i2 }));
                let l3 = e2.indexItems.get(String(t4.id));
                e2.indexItems.set(y(t4.id), l3 ? [...l3, e2.items.length - 1] : [e2.items.length - 1]), i2++;
              });
            });
          },
          updateVolumeItemsState: (t3, i2) => {
            t3.forEach((t4) => {
              let l2 = e2.indexItems.get(String(t4));
              null == l2 || l2.forEach((l3) => {
                let n2 = e2.items[l3];
                f(n2) && (e2.items[l3] = G({
                  id: t4,
                  loadingState: i2,
                  positionInContext: n2.positionInContext,
                  hasEverFinished: n2.hasEverFinished
                }));
              });
            });
          },
          insertDataToVolumeItems: (t3) => {
            t3.forEach((t4, i2) => {
              let l2 = e2.indexItems.get(y(t4.id));
              null == l2 || l2.forEach((l3) => {
                var n3, a2, r2, o2, d2;
                let u2 = e2.items[0], m2 = e2.items[l3], g2 = e2.items[l3 - 1];
                if (!f(m2)) return;
                let c2 = f(u2) && u2.id === m2.id ? 1 : null == (r2 = t4.albums) || null == (a2 = r2[0]) || null == (n3 = a2.trackPosition) ? void 0 : n3.index, b2 = null == m2 ? void 0 : m2.positionInContext, E2 = f(g2) && (null == g2 ? void 0 : g2.position) ? g2.position + 1 : c2, v2 = (0, p.vU)(t4, { hasEverFinished: null == m2 ? void 0 : m2.hasEverFinished });
                if (v2.isRemoved) {
                  e2.items[l3] = G({
                    id: t4.id,
                    loadingState: s.GuX.REJECT,
                    positionInContext: b2,
                    position: f(g2) ? g2.position : i2
                  });
                  return;
                }
                e2.items[l3] = G({
                  id: t4.id,
                  loadingState: s.GuX.RESOLVE,
                  positionInContext: b2,
                  data: v2,
                  position: (null == g2 ? void 0 : g2.type) === S.rU.TEXT ? 1 : E2,
                  isBest: null == (d2 = e2.meta) || null == (o2 = d2.bestAlbumTracks) ? void 0 : o2.includes(Number(t4.id)),
                  hasEverFinished: null == m2 ? void 0 : m2.hasEverFinished
                });
              });
              let n2 = e2.indexItems.get(I(t4.id));
              null == n2 || n2.forEach((i3) => {
                var l3, n3, a2;
                e2.items[i3] = L(
                  null == (a2 = t4.albums) || null == (n3 = a2[0]) || null == (l3 = n3.trackPosition) ? void 0 : l3.volume
                );
              });
            });
          },
          setAlbumUnfinished: () => {
            var i2;
            t2.markUnfinished({ albumId: e2.id || 0 }), null == (i2 = e2.meta) || i2.updateFinished(false);
          },
          setAllTracksUnfinished: (t3) => {
            e2.allTracksUnfinished = t3;
          },
          checkAllAlbumTrackFinished: () => {
            var i2, l2;
            e2.items.filter((e3) => {
              let { type: t3, data: i3 } = e3;
              return i3 && t3 !== S.rU.TEXT;
            }).every((e3) => {
              var t3;
              let { data: i3 } = e3;
              return null == i3 || null == (t3 = i3.streamProgress) ? void 0 : t3.hasEverFinished;
            }) && ((null == (i2 = e2.meta) ? void 0 : i2.listeningFinished) || (t2.markFinished({ albumId: Number(e2.id) }), null == (l2 = e2.meta) || l2.updateFinished(true)));
          },
          markTracksFinished: (t3) => {
            let { withoutTracks: i2 = [] } = t3;
            e2.items.forEach((e3) => {
              if (e3.type === S.rU.TEXT) return;
              let { data: t4 } = e3;
              if (!(t4 && i2.includes(t4.id)))
                if (t4) {
                  var l2;
                  null == (l2 = t4.streamProgress) || l2.updateEverFinished(true);
                } else e3.updateEverFinished(true);
            });
          },
          markFinished: (0, a.L3)(function* (t3) {
            let { streamsResource: i2, modelActionsLogger: l2 } = (0, a._$)(e2);
            try {
              return yield i2.markAlbumFinished(t3);
            } catch (e3) {
              return l2.error(e3), m.T.ERROR;
            }
          }),
          markUnfinished: (0, a.L3)(function* (t3) {
            let { streamsResource: i2, modelActionsLogger: l2 } = (0, a._$)(e2);
            try {
              return yield i2.markAlbumUnfinished(t3);
            } catch (e3) {
              return l2.error(e3), m.T.ERROR;
            }
          }),
          setListeningFinishedStatus: (0, a.L3)(function* () {
            var i2;
            return (null == (i2 = e2.meta) ? void 0 : i2.listeningFinished) ? (t2.setAllTracksUnfinished(true), yield t2.markUnfinished({ albumId: Number(e2.id) })) : yield t2.markFinished({ albumId: Number(e2.id) });
          }),
          getLatestGenreAlbums: (0, a.L3)(function* (t3) {
            let { topResource: i2, modelActionsLogger: l2 } = (0, a._$)(e2);
            if (e2.latestGenreAlbums && !e2.latestGenreAlbums.isLoading)
              try {
                e2.latestGenreAlbums.loadingState = s.GuX.PENDING;
                let l3 = yield i2.getTopByGenre(t3);
                e2.latestGenreAlbums.items = (0, a.wg)(l3.albums.map(v.pp)), e2.latestGenreAlbums.loadingState = s.GuX.RESOLVE;
              } catch (t4) {
                l2.error(t4), e2.latestGenreAlbums.loadingState = s.GuX.REJECT;
              }
          }),
          getSimilarEntities: (0, a.L3)(function* (t3) {
            let { albumResource: i2, modelActionsLogger: l2 } = (0, a._$)(e2);
            if (!e2.similarEntities.isLoading)
              try {
                e2.similarEntities.loadingState = E.SQ.PENDING;
                let l3 = yield i2.getSimilarEntities(t3);
                e2.similarEntities.data = (0, E.Ds)(l3), e2.similarEntities.loadingState = E.SQ.RESOLVE;
              } catch (t4) {
                l2.error(t4), e2.similarEntities.loadingState = E.SQ.REJECT;
              }
          }),
          getOtherArtistAlbums: (0, a.L3)(function* (t3, i2) {
            let { artistsResource: l2, modelActionsLogger: n2 } = (0, a._$)(e2);
            if (e2.otherArtistAlbums && !e2.otherArtistAlbums.isLoading)
              try {
                if (!t3.artistId) {
                  e2.otherArtistAlbums.loadingState = s.GuX.REJECT;
                  return;
                }
                e2.otherArtistAlbums.loadingState = s.GuX.PENDING;
                let n3 = yield l2.getSafeDirectAlbums({ ...t3, artistId: t3.artistId });
                e2.otherArtistAlbums.items = (0, a.wg)(
                  n3.albums.filter((e3) => String(e3.id) !== String(i2)).map(v.pp)
                ), e2.otherArtistAlbums.loadingState = s.GuX.RESOLVE;
              } catch (t4) {
                n2.error(t4), e2.otherArtistAlbums.loadingState = s.GuX.REJECT;
              }
          }),
          getTracks: (0, a.L3)(function* (i2) {
            let { trackIds: l2 } = i2, { tracksResource: n2, modelActionsLogger: r2 } = (0, a._$)(e2);
            try {
              var o2, d2;
              let i3;
              if (!(null == (o2 = e2.meta) ? void 0 : o2.id)) return;
              t2.updateVolumeItemsState(l2, s.GuX.PENDING);
              let a2 = yield n2.getTracksMeta({
                trackIds: (i3 = e2.meta.id, l2.map((e3) => "".concat(e3, ":").concat(i3))),
                withProgress: true
              });
              for (let i4 of (t2.insertDataToVolumeItems(a2), a2)) {
                let t3 = e2.items.find((e3) => f(e3) && e3.data && String(e3.data.id) === String(i4.id));
                f(t3) && (null == (d2 = t3.data) ? void 0 : d2.resolveAllDisclaimers) && t3.data.resolveAllDisclaimers();
              }
            } catch (e3) {
              r2.error(e3), t2.updateVolumeItemsState(l2, s.GuX.REJECT);
            }
          }),
          getDonations: (0, a.L3)(function* (t3) {
            let { albumId: i2 } = t3, { experiments: l2 } = (0, a.Zn)(e2), { donationResource: n2, modelActionsLogger: r2 } = (0, a._$)(e2);
            if (l2.checkExperiment(s.zal.WebNextAlbumDonationButton, "on") && e2.donations && !e2.donations.isLoading)
              try {
                e2.donations.loadingState = s.GuX.PENDING;
                let { donations: t4 } = yield n2.getAlbumDonations({ albumId: i2 });
                t4 && (e2.donations.items = (0, a.wg)(
                  t4.map((e3) => {
                    var t5;
                    let { data: i3 } = e3;
                    return (0, A.GT)({
                      url: i3.tipUrl,
                      goal: null == (t5 = i3.goal) ? void 0 : t5.title,
                      artist: i3.artist
                    });
                  })
                )), e2.donations.loadingState = s.GuX.RESOLVE;
              } catch (t4) {
                r2.error(t4), e2.donations.loadingState = s.GuX.REJECT;
              }
          }),
          getData: (0, a.L3)(function* (i2) {
            let {
              albumId: r2,
              resumeStream: o2,
              preloadedAlbum: d2,
              withLatestGenreAlbumsRequest: m2 = true,
              withOtherArtistAlbumsRequest: c2 = true,
              sonataState: b2
            } = i2, { albumResource: E2, modelActionsLogger: A2 } = (0, a._$)(e2);
            if (e2.id = r2, e2.loadingState !== s.GuX.PENDING)
              try {
                var p2, S2, L2, G2;
                let i3, A3;
                e2.loadingState = s.GuX.PENDING;
                let I2 = d2;
                if (I2 || (I2 = yield E2.getAlbumWithTracksIds({ albumId: r2, resumeStream: o2 })), (null == I2 ? void 0 : I2.error) === "not-found") {
                  e2.errorStatusCode = u.X1.NOT_FOUND, e2.loadingState = s.GuX.REJECT, e2.otherArtistAlbums && (e2.otherArtistAlbums.loadingState = s.GuX.REJECT), e2.latestGenreAlbums && (e2.latestGenreAlbums.loadingState = s.GuX.REJECT);
                  return;
                }
                if (null == (p2 = I2.deprecation) ? void 0 : p2.targetAlbumId) {
                  e2.deprecationTargetAlbumId = I2.deprecation.targetAlbumId, e2.loadingState = s.GuX.RESOLVE;
                  return;
                }
                b2.setUnloadedEntitiesData(I2.volumes.flat().map((e3) => (0, h.li)(e3.id))), e2.meta = (0, v.pp)(I2), e2.labels = (0, a.wg)(I2.labels), e2.contentWarning = (0, a.wg)(I2.contentWarning), e2.description = (0, a.wg)(I2.description), (null == (S2 = e2.meta) ? void 0 : S2.resolveAllDisclaimers) && (yield e2.meta.resolveAllDisclaimers()), I2.duplicates && I2.duplicates.length > 0 && (e2.otherAlbumVersions = (0, a.wg)(null == (L2 = I2.duplicates) ? void 0 : L2.map(v.pp))), t2.makeFlatVolumeItems(I2);
                let y2 = [];
                for (let t3 = 0; t3 < 10; t3++) {
                  let i4 = e2.items[t3];
                  (null == i4 ? void 0 : i4.type) === g.S.TRACK && y2.push(String(i4.id));
                }
                yield t2.getTracks({ trackIds: y2 }), e2.isLatestGenreAlbumsAvailable && m2 && (i3 = t2.getLatestGenreAlbums({
                  category: l.RECENT_ALBUMS,
                  period: n.WEEK,
                  pageSize: 8,
                  genre: I2.genre
                })), e2.isOtherArtistAlbumsAvailable && c2 && (A3 = t2.getOtherArtistAlbums(
                  { artistId: String(null == (G2 = I2.artists[0]) ? void 0 : G2.id), limit: 8 },
                  r2
                )), yield Promise.allSettled([i3, A3]), e2.loadingState !== s.GuX.IDLE && (e2.loadingState = s.GuX.RESOLVE);
              } catch (t3) {
                A2.error(t3), t3 instanceof u.GX && (e2.errorStatusCode = t3.statusCode), e2.loadingState !== s.GuX.IDLE && (e2.loadingState = s.GuX.REJECT, e2.otherArtistAlbums && (e2.otherArtistAlbums.loadingState = s.GuX.REJECT), e2.latestGenreAlbums && (e2.latestGenreAlbums.loadingState = s.GuX.REJECT));
              }
          }),
          loadLastEpisodes() {
            t2.getTracks({ trackIds: e2.lastEpisodesTrackIds });
          },
          getRelatedContent: (0, a.L3)(function* () {
            let { albumResource: t3, modelActionsLogger: i2 } = (0, a._$)(e2);
            if (e2.relatedContent && !e2.relatedContent.isLoading)
              try {
                var l2, n2;
                if (!(null == (l2 = e2.meta) ? void 0 : l2.id)) return;
                e2.relatedContent.loadingState = s.GuX.PENDING;
                let i3 = yield t3.getRelatedContent({ albumId: e2.meta.id });
                e2.relatedContent.items = (0, a.wg)(null == (n2 = i3.blocks) ? void 0 : n2.map(C)), e2.relatedContent.loadingState = s.GuX.RESOLVE;
              } catch (t4) {
                i2.error(t4), e2.relatedContent.loadingState = s.GuX.REJECT;
              }
          }),
          reset(t3) {
            var i2, l2, n2, r2;
            let { albumCPA: o2 } = (0, a.Zn)(e2);
            o2.reset(), t3.resetUnloadedEntitiesData(), e2.id = null, e2.errorStatusCode = null, e2.deprecationTargetAlbumId = null, e2.indexItems.clear(), e2.loadingState = s.GuX.IDLE, e2.description = "", e2.allTracksUnfinished = false, null == (i2 = e2.latestGenreAlbums) || i2.reset(), null == (l2 = e2.otherArtistAlbums) || l2.reset(), null == (n2 = e2.relatedContent) || n2.reset(), null == (r2 = e2.donations) || r2.reset(), e2.similarEntities.data = void 0, e2.similarEntities.loadingState = E.SQ.IDLE, e2.destroyItems([e2.meta, e2.items, e2.otherAlbumVersions, e2.labels]);
          }
        };
        return t2;
      });
      i(79119);
      var R = i(53936);
      i(72880), i(70717);
      var D = i(91283), P = i(77217);
      let x = a.gK.compose(a.gK.model("PromoLandingConcerts", { items: a.gK.maybeNull(a.gK.array(P.aR)) }), r.pl, r.XT).views((e2) => ({
        get isResolved() {
          return e2.loadingState === s.GuX.RESOLVE;
        }
      })).actions((e2) => ({
        setItems(t2) {
          e2.items = t2;
        },
        reset() {
          e2.loadingState = s.GuX.IDLE, e2.destroyItems([e2.items]);
        }
      })), O = a.gK.model("ExternalStreamingService", { name: a.gK.string, logoUrl: a.gK.string }), F = a.gK.model("ExternalStreamingLink", { service: O, url: a.gK.string }), U = a.gK.compose(a.gK.model("PromoLandingExternalStreamings", { items: a.gK.maybeNull(a.gK.array(F)) }), r.XT).actions((e2) => ({
        setItems(t2) {
          e2.items = t2;
        },
        reset() {
          e2.loadingState = s.GuX.IDLE, e2.items && e2.items.clear();
        }
      }));
      var w = i(63695);
      let V = a.gK.compose(a.gK.model("PromoLandingSocialLinks", { items: a.gK.maybeNull(a.gK.array(w.dP)) }), r.pl, r.XT).actions((e2) => ({
        setItems(t2) {
          e2.items = t2;
        },
        reset() {
          e2.loadingState = s.GuX.IDLE, e2.items && e2.items.clear();
        }
      })), _ = a.gK.compose(a.gK.model("PromoCampaign", { isActive: a.gK.boolean, artistId: a.gK.maybeNull(a.gK.number) }), r.XT).views((e2) => ({
        get isPromoCampaignActive() {
          return e2.isResolved && e2.isActive;
        },
        get isPromoCampaignInactive() {
          return e2.isRejected || e2.isResolved && !e2.isActive;
        }
      })).actions((e2) => ({
        setArtistId(t2) {
          e2.artistId = t2;
        },
        getData: (0, a.L3)(function* (t2) {
          let { isActive: i2, albumId: l2, campaignId: n2 } = t2, { promoResource: r2, modelActionsLogger: o2 } = (0, a._$)(e2);
          if (!e2.isLoading)
            try {
              if (e2.loadingState = s.GuX.PENDING, "boolean" == typeof i2)
                if (n2) {
                  let t3 = yield r2.getPromoAlbumInfo({ albumId: l2, campaignId: n2 });
                  e2.isActive = t3.active, e2.artistId = t3.artistId || null;
                } else e2.isActive = i2;
              else {
                let t3 = yield r2.getPromoAlbumInfo({ albumId: l2, campaignId: n2 });
                e2.isActive = t3.active, e2.artistId = t3.artistId || null;
              }
              e2.loadingState = s.GuX.RESOLVE;
            } catch (t3) {
              o2.error(t3), e2.loadingState = s.GuX.REJECT;
            }
        })
      })), J = N.props({
        promoCampaign: _,
        state: h.QQ,
        donations: a.gK.optional(T, { loadingState: s.GuX.IDLE }),
        concerts: a.gK.optional(x, { loadingState: s.GuX.IDLE }),
        socialLinks: a.gK.optional(V, { loadingState: s.GuX.IDLE }),
        externalStreamings: a.gK.optional(U, { loadingState: s.GuX.IDLE })
      }).views((e2) => ({
        get hasConcerts() {
          var t2, i2;
          let { experiments: l2 } = (0, a.Zn)(e2);
          if (l2.checkExperiment(s.zal.disableAllConcerts, "on")) return false;
          return !!((null == (t2 = e2.concerts) ? void 0 : t2.isResolved) && (null == (i2 = e2.concerts.items) ? void 0 : i2.length));
        },
        get hasSocialLinks() {
          var l2, n2;
          return !!((null == (l2 = e2.socialLinks) ? void 0 : l2.isResolved) && (null == (n2 = e2.socialLinks.items) ? void 0 : n2.length));
        },
        get hasExternalStreamings() {
          var r2, o2;
          return !!((null == (r2 = e2.externalStreamings) ? void 0 : r2.isResolved) && (null == (o2 = e2.externalStreamings.items) ? void 0 : o2.length));
        }
      })).actions((e2) => {
        let t2 = {
          getArtistConcerts: (0, a.L3)(function* (t3) {
            let { artistId: i2 } = t3, { artistsResource: l2, modelActionsLogger: n2 } = (0, a._$)(e2);
            if (!e2.concerts.isLoading)
              try {
                e2.concerts.loadingState = s.GuX.PENDING;
                let t4 = yield l2.getConcerts({ artistId: i2 });
                t4.concerts && t4.concerts.length > 0 ? e2.concerts.items = (0, a.wg)(t4.concerts.map(P.oP)) : e2.concerts.items = null, e2.concerts.loadingState = s.GuX.RESOLVE;
              } catch (t4) {
                n2.error(t4), e2.concerts.loadingState = s.GuX.REJECT;
              }
          }),
          getArtistDonations: (0, a.L3)(function* (t3) {
            let { artistId: i2 } = t3, { experiments: l2 } = (0, a.Zn)(e2), { artistsResource: n2, modelActionsLogger: r2 } = (0, a._$)(e2);
            if (l2.checkExperiment(s.zal.WebNextAlbumDonationButton, "on") && !e2.donations.isLoading)
              try {
                e2.donations.loadingState = s.GuX.PENDING;
                let { donations: t4 } = yield n2.getDonation({ artistId: i2 });
                t4 && t4.length > 0 ? e2.donations.items = (0, a.wg)(
                  t4.map((e3) => {
                    var t5;
                    let { data: i3 } = e3;
                    return (0, A.GT)({
                      url: i3.tipUrl,
                      goal: null == (t5 = i3.goal) ? void 0 : t5.title,
                      artist: i3.artist
                    });
                  })
                ) : e2.donations.items = null, e2.donations.loadingState = s.GuX.RESOLVE;
              } catch (t4) {
                r2.error(t4), e2.donations.loadingState = s.GuX.REJECT;
              }
          }),
          getArtistSocialLinks: (0, a.L3)(function* (t3) {
            let { artistId: i2 } = t3, { artistsResource: l2, modelActionsLogger: n2 } = (0, a._$)(e2);
            if (!e2.socialLinks.isLoading)
              try {
                var r2;
                e2.socialLinks.loadingState = s.GuX.PENDING;
                let t4 = yield l2.getArtistLinks({ artistId: i2 });
                e2.socialLinks.items = (null == (r2 = t4.links) ? void 0 : r2.length) ? (0, a.wg)(t4.links) : null, e2.socialLinks.loadingState = s.GuX.RESOLVE;
              } catch (t4) {
                n2.error(t4), e2.socialLinks.loadingState = s.GuX.REJECT;
              }
          }),
          getAlbumExternalStreamings: (0, a.L3)(function* (t3) {
            let { albumId: i2 } = t3, { albumResource: l2, modelActionsLogger: n2 } = (0, a._$)(e2);
            if (!e2.externalStreamings.isLoading)
              try {
                var r2;
                e2.externalStreamings.loadingState = s.GuX.PENDING;
                let t4 = yield l2.getExternalStreamingLinks({ albumId: i2 });
                e2.externalStreamings.items = (null == (r2 = t4.links) ? void 0 : r2.length) ? (0, a.wg)(t4.links) : null, e2.externalStreamings.loadingState = s.GuX.RESOLVE;
              } catch (t4) {
                n2.error(t4), e2.externalStreamings.loadingState = s.GuX.REJECT;
              }
          }),
          getDataByCampaign: (0, a.L3)(function* (i2) {
            let { albumId: l2, preloadedAlbum: n2, preloadedCpa: r2, isActive: o2, campaignId: d2 } = i2;
            if (yield e2.promoCampaign.getData({ albumId: l2, isActive: o2, campaignId: d2 }), e2.promoCampaign.isPromoCampaignActive) {
              var u2, m2, g2, c2, b2, E2, v2, A2, h2, p2, S2, L2, G2, I2, y2, C2, f2, T2, X2;
              let { albumCPA: i3, experiments: o3 } = (0, a.Zn)(e2), d3 = [
                e2.getData({
                  albumId: l2,
                  resumeStream: false,
                  preloadedAlbum: n2,
                  withLatestGenreAlbumsRequest: false,
                  withOtherArtistAlbumsRequest: false,
                  sonataState: e2.state
                }),
                i3.getCpa({ albumId: l2, preloadedCpa: r2 })
              ], K2 = o3.getExperiment(s.zal.WebNextPromoLandingLayout), k2 = null == K2 || null == (u2 = K2.value) ? void 0 : u2.params;
              if ((null == k2 || null == (g2 = k2.mobile) || null == (m2 = g2.content) ? void 0 : m2.includes(D.Cq.ExternalStreamings)) || (null == k2 || null == (b2 = k2.desktop) || null == (c2 = b2.content) ? void 0 : c2.includes(D.Cq.ExternalStreamings))) {
                let e3 = t2.getAlbumExternalStreamings({ albumId: l2 });
                d3.push(e3);
              }
              if (e2.promoCampaign.artistId) {
                let i4 = (null == k2 || null == (v2 = k2.mobile) || null == (E2 = v2.header) ? void 0 : E2.includes(D._7.Donation)) || (null == k2 || null == (h2 = k2.mobile) || null == (A2 = h2.content) ? void 0 : A2.includes(D.Cq.Donation)) || (null == k2 || null == (S2 = k2.desktop) || null == (p2 = S2.header) ? void 0 : p2.includes(D._7.Donation)), l3 = (null == k2 || null == (G2 = k2.mobile) || null == (L2 = G2.content) ? void 0 : L2.includes(D.Cq.Concerts)) || (null == k2 || null == (y2 = k2.desktop) || null == (I2 = y2.content) ? void 0 : I2.includes(D.Cq.Concerts)), n3 = (null == k2 || null == (f2 = k2.mobile) || null == (C2 = f2.content) ? void 0 : C2.includes(D.Cq.SocialLinks)) || (null == k2 || null == (X2 = k2.desktop) || null == (T2 = X2.content) ? void 0 : T2.includes(D.Cq.SocialLinks));
                if (i4) {
                  let i5 = t2.getArtistDonations({ artistId: e2.promoCampaign.artistId });
                  d3.push(i5);
                }
                if (l3) {
                  let i5 = t2.getArtistConcerts({ artistId: e2.promoCampaign.artistId });
                  d3.push(i5);
                }
                if (n3) {
                  let i5 = t2.getArtistSocialLinks({ artistId: e2.promoCampaign.artistId });
                  d3.push(i5);
                }
              }
              yield Promise.allSettled(d3);
            }
          }),
          sendLikeFeedback: (0, a.L3)(function* (t3) {
            let { promoResource: i2, modelActionsLogger: l2 } = (0, a._$)(e2);
            try {
              yield i2.sendFeedback(t3);
            } catch (e3) {
              l2.error(e3);
            }
          })
        };
        return t2;
      }).named("PromoLandingAlbumPage");
    }
  }
]);
