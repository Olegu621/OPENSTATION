(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4460],
  {
    5207: (e, t, i) => {
      "use strict";
      i.d(t, { RemoveButton: () => u });
      var r = i(54486), n = i(61910), a = i(43426), l = i(31500), s = i(77881), o = i(5956);
      let u = (e2) => {
        let {
          className: t2,
          variant: i2 = "text",
          onClick: u2,
          iconClassName: d,
          iconSize: c,
          size: m = "s",
          ariaLabel: g
        } = e2, { formatMessage: v } = (0, a.A)(), E = null != g ? g : v({ id: "play-queue.delete-from-queue" }), I = (0, n.useCallback)(
          (e3) => {
            null == u2 || u2(), e3.stopPropagation();
          },
          [u2]
        );
        return (0, r.jsx)(s.$, {
          className: t2,
          withRipple: false,
          variant: i2,
          size: m,
          radius: "round",
          "aria-label": E,
          onClick: I,
          icon: (0, r.jsx)(o.Icon, { size: c, className: d, variant: "bucket" }),
          ...(0, l.Am)(l.OA.track.REMOVE_BUTTON)
        });
      };
    },
    5693: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { R: () => r }), (function(e2) {
        e2.Music = "music", e2.DownloadedMusic = "downloadedMusic", e2.VibeTrack = "vibeTrack", e2.Generative = "generative", e2.Unknown = "unknown", e2.SmartPreview = "smartPreview", e2.Clip = "clip", e2.Radio = "fm_radio";
      })(r || (r = {}));
    },
    5988: (e) => {
      e.exports = {
        entityTitle: "NotificationPlayQueue_entityTitle__XCIsa",
        entityLink: "NotificationPlayQueue_entityLink__O7tHL",
        text: "NotificationPlayQueue_text___1DWX",
        image: "NotificationPlayQueue_image__SLXsp"
      };
    },
    7912: (e, t, i) => {
      "use strict";
      i.d(t, { useOnModifyPlayQueue: () => p });
      var r = i(54486), n = i(8817), a = i(89461), l = i(74125), s = i(61910), o = i(47713), u = i(31500), d = i(97800), c = i(80585), m = i(34946), g = i(5988), v = i.n(g);
      let E = (e2) => {
        let { closeToast: t2, entityVariant: i2, entityTitle: n2, coverUri: a2, variant: l2 } = e2, g2 = (0, s.useMemo)(
          () => (0, r.jsxs)(d.Caption, {
            className: v().entityTitle,
            variant: "span",
            type: "controls",
            size: "m",
            lineClamp: 1,
            children: [" ", n2, " "]
          }),
          [n2]
        ), E2 = (0, s.useMemo)(() => {
          switch (l2) {
            case m.N.NEXT:
              return ((e3, t3) => {
                switch (e3) {
                  case c.cp.TRACK:
                    return (0, r.jsx)(o.A, { id: "play-queue.track-will-be-played-next", values: { title: t3 } });
                  case c.cp.PODCAST_EPISODE:
                    return (0, r.jsx)(o.A, {
                      id: "play-queue.podcast-episode-will-be-played-next",
                      values: { title: t3 }
                    });
                  case c.cp.AUDIOBOOK_EPISODE:
                    return (0, r.jsx)(o.A, {
                      id: "play-queue.audiobook-episode-will-be-played-next",
                      values: { title: t3 }
                    });
                }
              })(i2, g2);
            case m.N.LAST:
              return ((e3, t3) => {
                switch (e3) {
                  case c.cp.TRACK:
                    return (0, r.jsx)(o.A, { id: "play-queue.track-will-be-played-last", values: { title: t3 } });
                  case c.cp.PODCAST_EPISODE:
                    return (0, r.jsx)(o.A, {
                      id: "play-queue.podcast-episode-will-be-played-last",
                      values: { title: t3 }
                    });
                  case c.cp.AUDIOBOOK_EPISODE:
                    return (0, r.jsx)(o.A, {
                      id: "play-queue.audiobook-episode-will-be-played-last",
                      values: { title: t3 }
                    });
                }
              })(i2, g2);
            case m.N.HIDE:
            case m.N.REMOVE:
              return ((e3, t3) => {
                switch (e3) {
                  case c.cp.TRACK:
                    return (0, r.jsx)(o.A, { id: "play-queue.track-will-be-removed", values: { title: t3 } });
                  case c.cp.PODCAST_EPISODE:
                    return (0, r.jsx)(o.A, {
                      id: "play-queue.podcast-episode-will-be-removed",
                      values: { title: t3 }
                    });
                  case c.cp.AUDIOBOOK_EPISODE:
                    return (0, r.jsx)(o.A, {
                      id: "play-queue.audiobook-episode-will-be-removed",
                      values: { title: t3 }
                    });
                }
              })(i2, g2);
          }
        }, [l2, i2, g2]);
        return (0, r.jsx)(c.$W, {
          message: (0, r.jsx)(d.Caption, {
            className: v().text,
            variant: "div",
            type: "controls",
            size: "m",
            ...(0, u.Am)(u.OA.track.PLAY_QUEUE_NOTIFICATION_TEXT),
            children: E2
          }),
          cover: (0, r.jsx)(c.BW, {
            className: v().image,
            src: a2,
            size: 100,
            fit: "cover",
            alt: n2,
            withAvatarReplace: true
          }),
          closeToast: t2,
          coverRadius: "s"
        });
      };
      var I = i(68568);
      function p(e2, t2, i2) {
        let { notify: s2 } = (0, l.lkh)(), { fullscreenPlayer: o2 } = (0, l.Pjs)(), u2 = (0, l.eGp)(), d2 = (0, I.b)(e2);
        return (0, n.c)(() => {
          if (!e2) return;
          let n2 = t2 === m.N.LAST || t2 === m.N.NEXT, c2 = n2 ? i2 : void 0, g2 = n2 ? void 0 : i2;
          switch (t2) {
            case m.N.LAST:
              null == u2 || u2.injectLast({
                entitiesData: [{ type: a.z4.Unloaded, meta: { id: e2.entityId } }],
                sourceContextData: c2
              });
              break;
            case m.N.NEXT:
              null == u2 || u2.injectNext({
                entitiesData: [{ type: a.z4.Unloaded, meta: { id: e2.entityId } }],
                sourceContextData: c2
              });
              break;
            case m.N.REMOVE:
              g2 && (null == u2 || u2.removeAndLoadEntities({ positions: g2 }));
              break;
            case m.N.HIDE:
              (null == g2 ? void 0 : g2.length) && (null == u2 || u2.hide({ positions: g2 }));
          }
          let v2 = o2.modal.isOpened ? l.uQT.FULLSCREEN_INFO : l.uQT.INFO;
          s2((0, r.jsx)(E, { entityVariant: d2, variant: t2, entityTitle: e2.title, coverUri: e2.coverUri }), {
            containerId: v2
          });
        });
      }
    },
    11450: (e, t, i) => {
      "use strict";
      i.d(t, { useTimeLeftText: () => a });
      var r = i(61910), n = i(43426);
      let a = () => {
        let { formatMessage: e2 } = (0, n.A)();
        return (0, r.useCallback)(
          function(t2) {
            let i2 = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1], r2 = Math.floor(t2 / 60), n2 = function(t3) {
              let i3 = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], r3 = e2({ id: "time.minutes-left" }, { minutes: t3 });
              return i3 ? "".concat(e2({ id: "time.left" }, { time: t3 }), " ").concat(r3) : r3;
            };
            if (t2 < 1) return e2({ id: "time.finished" });
            if (t2 < 60)
              return (function(t3) {
                let i3 = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], r3 = e2({ id: "time.seconds-left" }, { seconds: t3 });
                return i3 ? "".concat(e2({ id: "time.left" }, { time: t3 }), " ").concat(r3) : r3;
              })(Math.floor(t2), i2);
            if (r2 < 60) return n2(r2, i2);
            let a2 = Math.floor(r2 / 60), l = r2 % 60, s = (function(t3) {
              let i3 = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
              return i3 ? e2({ id: "time.hours-left" }, { hours: t3 }) : e2({ id: "time.hours" }, { hours: t3 });
            })(a2, i2);
            return l > 0 ? "".concat(s, " ").concat(n2(l)) : s;
          },
          [e2]
        );
      };
    },
    13596: (e, t, i) => {
      "use strict";
      i.d(t, { t: () => a });
      var r = i(29064), n = i(63585);
      function a(e2) {
        var t2;
        let i2 = null != (t2 = e2.entityContextType) ? t2 : r.h.BASED_ON_ENTITY_BY_DEFAULT;
        switch (e2.contextType) {
          case n.K.Playlist: {
            let t3 = void 0 !== e2.playlistUid && void 0 !== e2.playlistKind;
            return {
              type: n.K.Playlist,
              from: "",
              meta: { id: String(e2.contextId), ...t3 && { uid: e2.playlistUid, kind: e2.playlistKind } },
              sourceContextType: i2,
              filter: e2.filter
            };
          }
          case n.K.Album:
            return { type: n.K.Album, from: "", meta: { id: e2.contextId }, sourceContextType: i2 };
          case n.K.Artist:
            return { type: n.K.Artist, from: "", meta: { id: e2.contextId }, sourceContextType: i2 };
          default:
            return { type: n.K.Various, from: "", meta: { id: e2.contextId }, sourceContextType: i2 };
        }
      }
    },
    21179: (e, t, i) => {
      "use strict";
      i.d(t, { useOnLikeClick: () => u });
      var r = i(54486), n = i(43426), a = i(8817), l = i(74125), s = i(80585), o = i(27098);
      let u = (e2) => {
        let { user: t2, fullscreenPlayer: i2 } = (0, l.Pjs)(), { notify: u2 } = (0, l.lkh)(), { formatMessage: d } = (0, n.A)(), c = (0, o.f)();
        return (0, a.c)(async () => {
          if (!e2) return;
          let n2 = i2.modal.isOpened ? l.uQT.FULLSCREEN_INFO : l.uQT.INFO, a2 = i2.modal.isOpened ? l.uQT.FULLSCREEN_ERROR : l.uQT.ERROR;
          return t2.isAuthorized ? c({ track: e2, errorContainerId: a2, infoContainerId: n2 }) : void u2((0, r.jsx)(s.hT, { error: d({ id: "authorization-messages.need-to-authorizate" }) }), {
            containerId: a2
          });
        });
      };
    },
    27098: (e, t, i) => {
      "use strict";
      i.d(t, { f: () => v });
      var r = i(54486), n = i(63930), a = i(61910), l = i(43426), s = i(70140), o = i(77534), u = i(84321), d = i(8817), c = i(74125), m = i(80585), g = i(42488);
      let v = () => {
        let { notify: e2 } = (0, c.lkh)(), [t2, i2] = (0, a.useState)(false), { formatMessage: v2 } = (0, l.A)(), E = (0, c.eGp)();
        return (0, d.c)(async (a2) => {
          let {
            track: l2,
            withLink: d2 = true,
            infoContainerId: c2,
            errorContainerId: I,
            withNotification: p = true,
            playbackId: y
          } = a2;
          if (t2) return;
          let T = { ...(0, n.HO)(l2), isLiked: !l2.isLiked };
          i2(true);
          let S = await l2.toggleLike();
          if (i2(false), S === o.f.OK) {
            let e3 = T.isLiked ? u.O.LIKE : u.O.UNLIKE, t3 = null == E ? void 0 : E.getState(y);
            if (t3 && (0, s.i)(null == t3 ? void 0 : t3.currentContext.value)) {
              let i3 = t3.queueState.entityList.value.find((e4) => {
                let { entity: t4 } = e4;
                return t4.data.meta.id === T.id;
              });
              i3 && t3.currentContext.value.sendFeedback({ type: e3, entity: i3.entity });
            }
          }
          p && (S === o.f.OK ? e2((0, r.jsx)(g.NotificationLike, { withLink: d2, track: T }), { containerId: c2 }) : e2((0, r.jsx)(m.hT, { error: v2({ id: "error-messages.error-during-action" }) }), { containerId: I }));
        });
      };
    },
    29064: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { h: () => r }), (function(e2) {
        e2.BASED_ON_ENTITY_BY_DEFAULT = "BASED_ON_ENTITY_BY_DEFAULT", e2.USER_TRACKS = "USER_TRACKS", e2.DOWNLOADED_TRACKS = "DOWNLOADED_TRACKS", e2.SEARCH = "SEARCH", e2.MUSIC_HISTORY = "MUSIC_HISTORY", e2.MUSIC_HISTORY_SEARCH = "MUSIC_HISTORY_SEARCH", e2.ARTIST_MY_COLLECTION = "ARTIST_MY_COLLECTION", e2.ARTIST_FAMILIAR_FROM_WAVE = "ARTIST_FAMILIAR_FROM_WAVE";
      })(r || (r = {}));
    },
    34946: (e, t, i) => {
      "use strict";
      i.d(t, { N: () => r });
      var r = (function(e2) {
        return e2.NEXT = "NEXT", e2.LAST = "LAST", e2.REMOVE = "REMOVE", e2.HIDE = "HIDE", e2;
      })({});
    },
    36332: (e) => {
      e.exports = {
        root: "ListeningProgress_root__Rvlcn",
        text_withoutTimeLeft: "ListeningProgress_text_withoutTimeLeft__eAmOF",
        checkIcon: "ListeningProgress_checkIcon___yh49"
      };
    },
    37408: (e, t, i) => {
      "use strict";
      i.d(t, { ListeningProgress: () => y });
      var r = i(54486), n = i(50420), a = i(28303), l = i(61910), s = i(47713), o = i(31500), u = i(35190), d = i(5956), c = i(97800), m = i(89461), g = i(74125), v = i(83399), E = i(11450), I = i(36332), p = i.n(I);
      let y = (0, a.PA)((e2) => {
        var t2, i2, a2, I2, y2, T, S, _, O;
        let {
          className: f,
          id: k,
          albumId: A,
          streamProgress: h,
          durationMs: b,
          playContextParams: L,
          withTimeLeftText: N = true,
          isFinishedLabelHidden: R
        } = e2, K = (0, g.eGp)(), { sonataState: P, album: C } = (0, g.Pjs)(), D = Math.floor(b / 1e3), [U, x] = (0, l.useState)(false), F = (0, E.useTimeLeftText)(), { isPlaying: M, isCurrent: w } = (0, g.Dx4)({
          playContextParams: L,
          entityId: A ? "".concat(k, ":").concat(A) : k
        });
        (0, l.useEffect)(() => {
          if (!w) return void x(false);
          let e3 = null == K ? void 0 : K.state.playerState.status.onChange(() => {
            (null == K ? void 0 : K.state.playerState.status.value) === m.MT.BUFFERING && x(true);
          });
          return () => {
            null == e3 || e3();
          };
        }, [K, h, w, M]), (0, l.useEffect)(() => {
          var e3;
          (null == C || null == (e3 = C.meta) ? void 0 : e3.listeningFinished) ? (h.updateEndPositionSec(0), h.updateEverFinished(true)) : (null == C ? void 0 : C.allTracksUnfinished) && h.updateEverFinished(false);
        }, [
          h,
          null == C ? void 0 : C.allTracksUnfinished,
          null == C || null == (t2 = C.meta) ? void 0 : t2.listeningFinished
        ]), (0, l.useEffect)(() => {
          var e3, t3;
          w && (null == P || null == (e3 = P.entityMeta) ? void 0 : e3.streamProgress) && h && P.entityMeta.streamProgress.hasEverFinished !== h.hasEverFinished && h.updateEverFinished(!!P.entityMeta.streamProgress.hasEverFinished), D - ((null == h ? void 0 : h.endPositionSec) || 0) < 1 && ((null == P || null == (t3 = P.entityMeta) ? void 0 : t3.streamProgress) && w && (P.entityMeta.streamProgress.updateEverFinished(true), P.entityMeta.streamProgress.updateEndPositionSec(0)), null == h || h.updateEverFinished(true));
        }, [
          w,
          null == P || null == (i2 = P.entityMeta) ? void 0 : i2.streamProgress,
          null == P || null == (I2 = P.entityMeta) || null == (a2 = I2.streamProgress) ? void 0 : a2.hasEverFinished,
          h,
          h.hasEverFinished,
          h.endPositionSec,
          D
        ]), (0, l.useEffect)(() => {
          if (!w) return;
          let e3 = null == K ? void 0 : K.state.playerState.progress.onChange(() => {
            var e4;
            let t3 = K.state.playerState.progress.value, i3 = null == P || null == (e4 = P.entityMeta) ? void 0 : e4.streamProgress;
            0 !== t3.position && U && h.updateEndPositionSec(t3.position), w && parseInt("".concat(null == i3 ? void 0 : i3.endPositionSec), 10) !== parseInt("".concat(t3.position), 10) && (null == i3 || i3.updateEndPositionSec(t3.position));
          });
          return () => {
            null == e3 || e3();
          };
        }, [K, h, w, M, U, k, null == P ? void 0 : P.entityMeta]);
        let j = w && (null == P || null == (T = P.entityMeta) || null == (y2 = T.streamProgress) ? void 0 : y2.endPositionSec) || h.endPositionSec, G = (0, v.useProgressTimeNonMusic)(null != j ? j : 0, D), B = (0, l.useMemo)(() => {
          var e3, t3, i3;
          if ((w && (null == P || null == (t3 = P.entityMeta) || null == (e3 = t3.streamProgress) ? void 0 : e3.hasEverFinished) || (null == h ? void 0 : h.hasEverFinished) || (null == C || null == (i3 = C.meta) ? void 0 : i3.listeningFinished)) && !R)
            return (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(c.Caption, {
                  lineClamp: 1,
                  variant: "div",
                  className: (0, n.$)(p().text, { [p().text_withoutTimeLeft]: !N }),
                  ...(0, o.Am)(o.OA.track.LISTENING_PROGRESS_FINISHED_TEXT),
                  children: (0, r.jsx)(s.A, { id: "time.finished" })
                }),
                (0, r.jsx)(d.Icon, {
                  size: "xxs",
                  variant: "check",
                  className: p().checkIcon,
                  ...(0, o.Am)(o.OA.track.LISTENING_PROGRESS_FINISHED_ICON)
                })
              ]
            });
          if (!j || 0 === j) return;
          let a3 = D - j, l2 = F(a3);
          return (0, r.jsxs)(r.Fragment, {
            children: [
              (0, r.jsx)(c.Caption, {
                lineClamp: 1,
                variant: "div",
                className: (0, n.$)(p().text, { [p().text_withoutTimeLeft]: !N }),
                ...(0, o.Am)(o.OA.track.LISTENING_PROGRESS_TIMINGS_TEXT),
                children: l2
              }),
              a3 > 1 || R ? (0, r.jsx)(u.q, {
                "aria-valuetext": G,
                "aria-busy": w && M,
                value: j,
                max: D,
                ...(0, o.Am)(o.OA.track.LISTENING_PROGRESS_TIMINGS_PROGRESS)
              }) : (0, r.jsx)(d.Icon, {
                size: "xxs",
                variant: "check",
                className: p().checkIcon,
                ...(0, o.Am)(o.OA.track.LISTENING_PROGRESS_TIMINGS_ICON)
              })
            ]
          });
        }, [
          D,
          null == h ? void 0 : h.hasEverFinished,
          N,
          F,
          w,
          M,
          null == P || null == (_ = P.entityMeta) || null == (S = _.streamProgress) ? void 0 : S.hasEverFinished,
          null == C || null == (O = C.meta) ? void 0 : O.listeningFinished,
          R,
          j,
          G
        ]);
        return (0, r.jsx)("div", {
          className: (0, n.$)(p().root, f),
          ...(0, o.Am)(o.OA.track.LISTENING_PROGRESS),
          children: B
        });
      });
    },
    39906: (e, t, i) => {
      "use strict";
      i.d(t, { useMarkListenedClick: () => d });
      var r = i(54486), n = i(43426), a = i(95167), l = i(58623), s = i(8817), o = i(74125), u = i(80585);
      let d = (e2) => {
        let {
          user: t2,
          fullscreenPlayer: i2,
          sonataState: { entityMeta: d2 },
          album: c
        } = (0, o.Pjs)(), { notify: m } = (0, o.lkh)(), { formatMessage: g } = (0, n.A)(), v = (0, o.eGp)();
        return (0, s.c)(async () => {
          if (!e2) return;
          let n2 = i2.modal.isOpened ? o.uQT.FULLSCREEN_ERROR : o.uQT.ERROR;
          if (!t2.isAuthorized)
            return void m((0, r.jsx)(u.hT, { error: g({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: n2
            });
          let s2 = e2.streamProgress, E = (null == d2 ? void 0 : d2.id) === e2.id && (null == d2 ? void 0 : d2.albumId) === e2.albumId;
          if (await e2.setListeningFinishedStatus() !== l.T.OK)
            m((0, r.jsx)(u.hT, { error: g({ id: "error-messages.error-during-action" }) }), { containerId: n2 });
          else {
            var I, p;
            let t3 = !(null == s2 ? void 0 : s2.hasEverFinished), i3 = null == v ? void 0 : v.state.queueState.entityList.value, r2 = null == i3 ? void 0 : i3.find((t4) => {
              let { entity: i4 } = t4;
              if ((0, a.b)(i4)) {
                var r3, n3;
                let t5 = i4.data.meta;
                return t5.realId === e2.id && (null == (n3 = t5.albums) || null == (r3 = n3[0]) ? void 0 : r3.id) === e2.albumId;
              }
              return false;
            });
            r2 && (r2.entity.everFinished = !!t3), E && (null == d2 ? void 0 : d2.streamProgress) && (null == (I = d2.streamProgress) ? void 0 : I.hasEverFinished) !== t3 && (d2.streamProgress.updateEverFinished(t3), t3 && d2.streamProgress.updateEndPositionSec(0)), (null == (p = c.meta) ? void 0 : p.listeningFinished) && !t3 && (c.markTracksFinished({ withoutTracks: [e2.id] }), c.setAlbumUnfinished(), c.setAllTracksUnfinished(false)), null == s2 || s2.updateEverFinished(t3), c.meta && t3 && c.checkAllAlbumTrackFinished();
          }
        });
      };
    },
    42488: (e, t, i) => {
      "use strict";
      i.d(t, { NotificationLike: () => u });
      var r = i(54486), n = i(28303), a = i(80585), l = i(68568), s = i(8075), o = i(74125);
      let u = (0, n.PA)((e2) => {
        let { track: t2, closeToast: i2, withLink: n2 } = e2, u2 = ((e3) => {
          switch (e3.type) {
            case s.S.PODCAST:
            case s.S.AUDIOBOOK:
              return o.Zyd.collectionShelfLiked.href;
            default:
              return o.Zyd.collection.href;
          }
        })(t2), d = (0, l.b)(t2);
        return (0, r.jsx)(a.OM, {
          closeToast: i2,
          entityVariant: d,
          entityTitle: t2.title,
          collectionUrl: u2,
          coverUri: t2.coverUri,
          isLiked: t2.isLiked,
          withLink: n2
        });
      });
    },
    48392: (e, t, i) => {
      "use strict";
      i.d(t, { NotificationDislike: () => m });
      var r = i(54486), n = i(50420), a = i(43426), l = i(6971), s = i(39610), o = i(97800), u = i(80585), d = i(90516), c = i.n(d);
      let m = (e2) => {
        let t2, { coverUri: i2, title: d2, isDisliked: m2, closeToast: g, className: v, entityVariant: E } = e2, { formatMessage: I } = (0, a.A)();
        if (m2)
          switch (E) {
            case u.cp.PODCAST_EPISODE:
              t2 = I({ id: "notifications-info.podcast-episode-unavailable-in-recommendations" });
              break;
            case u.cp.AUDIOBOOK_EPISODE:
              t2 = I({ id: "notifications-info.audiobook-episode-unavailable-in-recommendations" });
              break;
            default:
              t2 = I({ id: "notifications-info.track-unavailable-in-recommendations" });
          }
        else
          switch (E) {
            case u.cp.PODCAST_EPISODE:
              t2 = I({ id: "notifications-info.podcast-episode-available-in-recommendations" });
              break;
            case u.cp.AUDIOBOOK_EPISODE:
              t2 = I({ id: "notifications-info.audiobook-episode-available-in-recommendations" });
              break;
            default:
              t2 = I({ id: "notifications-info.track-available-in-recommendations" });
          }
        return (0, r.jsx)(u.$W, {
          className: (0, n.$)(c().root, v),
          closeToast: g,
          message: (0, r.jsxs)("div", {
            className: c().message,
            children: [
              (0, r.jsx)(s.q, { children: (0, r.jsx)("p", { role: "alert", "aria-label": t2 }) }),
              (0, r.jsx)(l.Paper, {
                className: c().cover,
                radius: "s",
                children: (0, r.jsx)(u.BW, {
                  className: c().image,
                  src: i2,
                  alt: d2,
                  size: 100,
                  fit: "cover",
                  withAvatarReplace: true
                })
              }),
              (0, r.jsx)(o.Caption, {
                className: c().text,
                variant: "div",
                type: "controls",
                size: "m",
                "aria-hidden": true,
                children: t2
              })
            ]
          })
        });
      };
    },
    50119: (e, t, i) => {
      "use strict";
      i.d(t, { useOnDislikeClick: () => E });
      var r = i(54486), n = i(63930), a = i(61910), l = i(43426), s = i(70140), o = i(77534), u = i(84321), d = i(8817), c = i(74125), m = i(80585), g = i(48392), v = i(68568);
      let E = (e2) => {
        let { user: t2, fullscreenPlayer: i2 } = (0, c.Pjs)(), E2 = (0, c.eGp)(), { notify: I } = (0, c.lkh)(), [p, y] = (0, a.useState)(false), { formatMessage: T } = (0, l.A)(), S = (0, v.b)(e2);
        return (0, d.c)(async () => {
          if (e2) {
            let l2 = i2.modal.isOpened ? c.uQT.FULLSCREEN_INFO : c.uQT.INFO, d2 = i2.modal.isOpened ? c.uQT.FULLSCREEN_ERROR : c.uQT.ERROR;
            if (!t2.isAuthorized)
              return void I((0, r.jsx)(m.hT, { error: T({ id: "authorization-messages.need-to-authorizate" }) }), {
                containerId: d2
              });
            if (p) return;
            let v2 = { ...(0, n.HO)(e2), isDisliked: !e2.isDisliked };
            y(true);
            let _ = await e2.toggleDislike();
            if (y(false), _ === o.f.OK) {
              var a2;
              I(
                (0, r.jsx)(g.NotificationDislike, {
                  coverUri: v2.coverUri,
                  isDisliked: v2.isDisliked,
                  title: v2.title,
                  entityVariant: S
                }),
                { containerId: l2 }
              );
              let e3 = v2.isDisliked ? u.O.DISLIKE : u.O.UNDISLIKE;
              if (E2 && (0, s.i)(E2.state.currentContext.value)) {
                let t3 = E2.state.queueState.entityList.value.find((e4) => {
                  let { entity: t4 } = e4;
                  return t4.data.meta.id === v2.id;
                });
                t3 && await E2.state.currentContext.value.sendFeedback({ type: e3, entity: t3.entity });
              }
              v2.isDisliked && v2.id === (null == E2 || null == (a2 = E2.state.queueState.currentEntity.value) ? void 0 : a2.entity.data.meta.id) && (null == E2 || E2.moveForward());
            } else I((0, r.jsx)(m.hT, { error: T({ id: "error-messages.error-during-action" }) }), { containerId: d2 });
          }
        });
      };
    },
    50193: (e, t, i) => {
      "use strict";
      i.d(t, { useOnPromoLandingLikeClick: () => o });
      var r = i(97396), n = i(34132), a = i(8817), l = i(74125), s = i(27098);
      let o = (e2) => {
        let {
          user: t2,
          modals: { promoLandingBuySubscriptionModal: i2, crackdownModal: o2 },
          settings: { isMobile: u },
          promolanding: d
        } = (0, l.Pjs)(), { isFreemium: c } = (0, l.XCI)(), m = (0, s.f)(), g = (0, r.useSearchParams)();
        return (0, a.c)(async () => {
          if ((!c || (null == e2 ? void 0 : e2.isLiked) || (u ? i2.open() : o2.open()), t2.isAuthorized) && e2) {
            if (!e2.isLiked) {
              var r2, a2;
              d.sendLikeFeedback({
                reaction: n.g.LIKE,
                yclid: null != (r2 = g.get(l.K3F.YCLID)) ? r2 : "",
                campaignId: null != (a2 = g.get(l.K3F.UTM_CAMPAIGN)) ? a2 : "",
                trackId: e2.id
              });
            }
            return m({
              track: e2,
              errorContainerId: l.uQT.ERROR,
              infoContainerId: l.uQT.INFO,
              withLink: false,
              withNotification: t2.hasPlus,
              playbackId: l.V_r.PROMO_LANDING
            });
          }
        });
      };
    },
    54460: (e, t, i) => {
      "use strict";
      i.d(t, {
        OQ: () => P,
        Bg: () => x.ListeningProgress,
        t$: () => C,
        NM: () => v.N,
        d0: () => F.RemoveButton,
        B9: () => L,
        oQ: () => m,
        pK: () => g,
        vz: () => D,
        jU: () => U,
        gK: () => s,
        tW: () => o.t,
        eK: () => I.e,
        $O: () => u,
        LT: () => d,
        Rw: () => c,
        TH: () => E.useMarkListenedClick,
        mW: () => p.useOnDislikeClick,
        KX: () => y.useOnLikeClick,
        iQ: () => T.useOnModifyPlayQueue,
        c5: () => S.useOnPromoLandingLikeClick,
        mw: () => _.useProgressTimeNonMusic,
        $4: () => O.useTimeLeftText,
        Dv: () => f.useTrackSourceContext
      });
      var r, n, a = i(93064);
      (r || (r = {})).SMART_PREVIEW = "smart_preview";
      var l = i(74125);
      let s = (e2, t2) => {
        var i2, n2, s2, o2, u2, d2, c2, m2, g2, v2;
        e2 = e2 || {};
        let { isSmartPreview: E2, hasEverFinished: I2 } = t2 || {}, p2 = (0, l.QBb)(null == e2 ? void 0 : e2.derivedColors), y2 = E2 ? null == (i2 = e2.smartPreviewParams) ? void 0 : i2.durationMs : null == e2 ? void 0 : e2.durationMs, T2 = (0, a.wg)({
          available: !!(null == (n2 = e2.specialAudioResources) ? void 0 : n2.includes(r.SMART_PREVIEW))
        });
        return (0, a.wg)({
          id: (e2.id || 0).toString(),
          isAvailable: !!(null == e2 ? void 0 : e2.available),
          isRemoved: (null == e2 ? void 0 : e2.error) === "not-found",
          title: null != (g2 = null == e2 ? void 0 : e2.title) ? g2 : "",
          version: null == e2 ? void 0 : e2.version,
          durationMs: y2,
          coverUri: null == e2 ? void 0 : e2.coverUri,
          averageColor: p2,
          trackParameters: ((e3) => (0, a.wg)({
            bpm: null == e3 ? void 0 : e3.bpm,
            energy: null == e3 ? void 0 : e3.energy,
            hue: null == e3 ? void 0 : e3.hue,
            userCollectionHue: null == e3 ? void 0 : e3.userCollectionHue
          }))(null == e2 ? void 0 : e2.trackParameters),
          trackSource: null == e2 ? void 0 : e2.trackSource,
          albumId: null == (o2 = e2.albums) || null == (s2 = o2[0]) ? void 0 : s2.id,
          disclaimers: e2.disclaimers,
          type: e2.type,
          pubDate: e2.pubDate,
          hasLyrics: null == (u2 = e2.lyricsInfo) ? void 0 : u2.hasAvailableTextLyrics,
          hasSyncLyrics: null == (d2 = e2.lyricsInfo) ? void 0 : d2.hasAvailableSyncLyrics,
          shouldRememberPosition: e2.rememberPosition,
          streamProgress: ((e3, t3) => (0, a.wg)({
            endPositionSec: null == e3 ? void 0 : e3.endPositionSec,
            hasEverFinished: (null == t3 ? void 0 : t3.hasEverFinished) || (null == e3 ? void 0 : e3.everFinished)
          }))(null == e2 ? void 0 : e2.streamProgress, { hasEverFinished: I2 }),
          shortDescription: null != (v2 = e2.shortDescription) ? v2 : "",
          trailer: T2,
          clipIds: e2.clipIds,
          major: e2.major,
          genre: null == (m2 = e2.albums) || null == (c2 = m2[0]) ? void 0 : c2.genre,
          realId: e2.realId
        });
      };
      var o = i(13596);
      let u = (e2, t2) => {
        if (!t2) {
          let { href: t3 } = (0, l.uvd)("/track/:trackId", { params: { trackId: e2 } });
          return t3;
        }
        let { href: i2 } = (0, l.uvd)("/album/:albumId/track/:trackId", { params: { albumId: t2, trackId: e2 } });
        return i2;
      }, d = (e2) => (0, a.wg)({ id: e2.id, name: e2.name, prettyName: e2.prettyName }), c = (e2) => ({ id: e2.id, albumId: e2.albumId, timestamp: e2.timestamp });
      var m = (function(e2) {
        return e2.TOO_MANY_FILES = "TOO_MANY_FILES", e2.UNKNOWN_ERROR = "UNKNOWN_ERROR", e2;
      })({}), g = (function(e2) {
        return e2.IDLE = "IDLE", e2.PREPARE = "PREPARE", e2.UPLOADING = "UPLOADING", e2.PROCESSING = "PROCESSING", e2.RESOLVE = "RESOLVE", e2.REJECT = "REJECT", e2.CANCELLED = "CANCELLED", e2;
      })({}), v = i(34946), E = i(39906), I = i(68568), p = i(50119), y = i(21179), T = i(7912), S = i(50193), _ = i(83399), O = i(11450), f = i(62345), k = i(8075), A = i(54906), h = i(26433), b = i(58623);
      let L = a.gK.model("StreamProgress", {
        endPositionSec: a.gK.maybe(a.gK.number),
        hasEverFinished: a.gK.maybe(a.gK.boolean)
      }).actions((e2) => ({
        updateEndPositionSec: (t2) => {
          e2.endPositionSec = t2;
        },
        updateEverFinished: (t2) => {
          e2.hasEverFinished = t2;
        },
        markListened: (0, a.L3)(function* (t2) {
          let { streamsResource: i2, modelActionsLogger: r2 } = (0, a._$)(e2);
          try {
            return yield i2.markFinished(t2);
          } catch (e3) {
            return r2.error(e3), b.T.ERROR;
          }
        }),
        markUnlistened: (0, a.L3)(function* (t2) {
          let { streamsResource: i2, modelActionsLogger: r2 } = (0, a._$)(e2);
          try {
            return yield i2.markUnfinished(t2);
          } catch (e3) {
            return r2.error(e3), b.T.ERROR;
          }
        })
      })), N = a.gK.model("TrackMajor", { id: a.gK.maybeNull(a.gK.number), name: a.gK.maybeNull(a.gK.string) }), R = a.gK.model("TrackParameters", {
        bpm: a.gK.maybe(a.gK.number),
        energy: a.gK.maybe(a.gK.number),
        hue: a.gK.maybe(a.gK.number),
        userCollectionHue: a.gK.maybe(a.gK.number)
      }), K = [k.S.MUSIC, k.S.TRACK, k.S.NOISE, k.S.ASMR], P = a.gK.compose(
        a.gK.model("BaseTrack", {
          id: a.gK.string,
          isAvailable: a.gK.boolean,
          isRemoved: a.gK.boolean,
          title: a.gK.string,
          trackSource: a.gK.maybe(a.gK.enumeration(Object.values(A.J))),
          version: a.gK.maybe(a.gK.string),
          durationMs: a.gK.maybe(a.gK.number),
          coverUri: a.gK.maybe(a.gK.string),
          averageColor: a.gK.maybe(a.gK.string),
          trackParameters: a.gK.maybe(R),
          albumId: a.gK.maybe(a.gK.number),
          disclaimers: a.gK.maybe(a.gK.array(a.gK.string)),
          type: a.gK.maybe(a.gK.enumeration(Object.values(k.S))),
          pubDate: a.gK.maybe(a.gK.string),
          hasLyrics: a.gK.maybe(a.gK.boolean),
          hasSyncLyrics: a.gK.maybe(a.gK.boolean),
          trailer: a.gK.maybe(h.aQ),
          shouldRememberPosition: a.gK.maybe(a.gK.boolean),
          streamProgress: a.gK.maybe(L),
          shortDescription: a.gK.maybe(a.gK.string),
          major: a.gK.maybeNull(N),
          clipIds: a.gK.maybeNull(a.gK.array(a.gK.number)),
          genre: a.gK.maybeNull(a.gK.string),
          realId: a.gK.maybe(a.gK.string)
        }),
        h.Ec
      ).views((e2) => {
        let t2 = {
          get isLiked() {
            if ((0, a._n)(e2)) {
              let { library: t3 } = (0, a.Zn)(e2);
              return t3.isTrackLiked(e2.id);
            }
            return false;
          },
          get isDownloaded() {
            if (!(0, a._n)(e2)) return false;
            let { slam: t3 } = (0, a.Zn)(e2);
            return t3.isTrackDownloaded(e2.id);
          },
          get isDownloading() {
            if (!(0, a._n)(e2)) return false;
            let { slam: t3 } = (0, a.Zn)(e2);
            return t3.isTrackDownloading(e2.id);
          },
          get downloadingProgress() {
            if (!(0, a._n)(e2)) return 0;
            let { slam: t3 } = (0, a.Zn)(e2);
            return t3.getTrackDownloadingProgress(e2.id);
          },
          get isAvailableForDownload() {
            if (!(0, a._n)(e2)) return false;
            return e2.type && K.includes(e2.type) || !!t2.isUGC;
          },
          getUrl(t3) {
            let i2 = e2.albumId ? "/album/:albumId/track/:trackId" : "/track/:trackId", r2 = e2.albumId ? { albumId: e2.albumId, trackId: e2.id } : { trackId: e2.id }, { href: n2 } = (0, l.uvd)(i2, { params: r2, query: t3 });
            return n2;
          },
          get url() {
            return t2.getUrl();
          },
          get isDisliked() {
            if ((0, a._n)(e2)) {
              let { library: t3 } = (0, a.Zn)(e2);
              return t3.isTrackDisliked(e2.id);
            }
            return false;
          },
          get isTrackPodcast() {
            if ((0, a._n)(e2)) return e2.type === k.S.PODCAST;
            return false;
          },
          get isPlusSubscribed() {
            if (!(0, a._n)(e2)) return false;
            let { user: t3 } = (0, a.Zn)(e2);
            return t3.hasPlus;
          },
          get isSyncLyricsAvailableWithOfflineFeature() {
            if (!(0, a._n)(e2)) return false;
            let { slam: t3 } = (0, a.Zn)(e2);
            return !!e2.hasSyncLyrics && !t3.isOfflineModeEnabled;
          },
          get isSyncLyricsAvailable() {
            return this.isPlusSubscribed && this.isSyncLyricsAvailableWithOfflineFeature;
          },
          get isLyricsAvailable() {
            if (!(0, a._n)(e2)) return false;
            let { slam: t3, user: i2 } = (0, a.Zn)(e2);
            if (!i2.hasPlus) return false;
            return !!e2.hasLyrics && !t3.isOfflineModeEnabled;
          },
          get isTrackAudiobook() {
            if ((0, a._n)(e2)) return e2.type === k.S.AUDIOBOOK;
            return false;
          },
          get isTrackFairyTale() {
            if ((0, a._n)(e2)) return e2.type === k.S.FAIRY_TALE;
            return false;
          },
          get isTrackNonMusic() {
            return this.isTrackPodcast || this.isTrackAudiobook || this.isTrackFairyTale;
          },
          get isTrackMusic() {
            if ((0, a._n)(e2)) return e2.type === k.S.TRACK || e2.type === k.S.MUSIC;
            return false;
          },
          get isUGC() {
            if ((0, a._n)(e2)) return e2.trackSource === A.J.UGC;
            return;
          },
          get isOwn() {
            if ((0, a._n)(e2)) return e2.trackSource === A.J.OWN;
            return;
          },
          get isOwnReplacedToUGC() {
            if ((0, a._n)(e2)) return e2.trackSource === A.J.OWN_REPLACED_TO_UGC;
            return;
          },
          get seeds() {
            return ["track:".concat(e2.id)];
          },
          get isLegalRejected() {
            return e2.getIsLegalRejected(e2.isAvailable);
          },
          get isUnsafeLegal() {
            return e2.getIsUnsafeLegal(e2.isAvailable);
          },
          get entityId() {
            if (e2.albumId) return "".concat(e2.id, ":").concat(e2.albumId);
            return e2.id;
          },
          get hasAlbumLink() {
            if (!(0, a._n)(e2)) return false;
            return !!(e2.albumId && this.isOwn && e2.isAvailable);
          },
          get hasTrackLink() {
            if (!(0, a._n)(e2)) return false;
            let {
              settings: { isMobile: t3 },
              slam: i2
            } = (0, a.Zn)(e2);
            return e2.isAvailable && !this.isUGC && !this.isOwnReplacedToUGC && !t3 && !i2.isOfflineModeEnabled;
          },
          get isNonUserGenerated() {
            if (!(0, a._n)(e2)) return false;
            return !t2.isUGC && !t2.isOwnReplacedToUGC;
          },
          get hasModalAccess() {
            return e2.hasModalDisclaimer;
          },
          getDisclaimerEntityRef: (i2) => i2 ? { entityType: i2, entityId: e2.id } : t2.isTrackPodcast ? { entityType: l.nPY.PODCAST, entityId: e2.id } : t2.isTrackAudiobook ? { entityType: l.nPY.AUDIOBOOK, entityId: e2.id } : { entityType: l.nPY.TRACK, entityId: e2.id }
        };
        return t2;
      }).actions((e2) => ({
        afterCreate() {
          e2.trackType = e2.type;
        },
        toggleLike: (0, a.L3)(function* () {
          if (!(0, a._n)(e2)) return;
          let { library: t2, user: i2 } = (0, a.Zn)(e2);
          if (i2.isAuthorized)
            return yield t2.toggleTrackLike({ entityId: e2.id, albumId: e2.albumId, userId: i2.account.data.uid });
        }),
        toggleDislike: (0, a.L3)(function* () {
          if (!(0, a._n)(e2)) return;
          let { library: t2, user: i2 } = (0, a.Zn)(e2);
          if (i2.isAuthorized)
            return yield t2.toggleTrackDislike({ entityId: e2.id, albumId: e2.albumId, userId: i2.account.data.uid });
        }),
        setListeningFinishedStatus: (0, a.L3)(function* () {
          let t2 = e2.streamProgress;
          if (t2)
            return (null == t2 ? void 0 : t2.hasEverFinished) ? yield null == t2 ? void 0 : t2.markUnlistened({ trackId: Number(e2.id) }) : yield null == t2 ? void 0 : t2.markListened({ trackId: Number(e2.id) });
        }),
        getKey: (t2) => "".concat(t2, "_").concat(e2.id)
      })), C = a.gK.model("MajorModel", { id: a.gK.number, name: a.gK.string, prettyName: a.gK.maybeNull(a.gK.string) });
      (n || (n = {})).TOO_MANY_FILES = "TOO_MANY_FILES";
      let D = a.gK.model("TrackUgcUploadModel", {
        loadingState: a.gK.enumeration(Object.values(g)),
        errorReason: a.gK.maybeNull(a.gK.enumeration(Object.values(m))),
        playlistKind: a.gK.number,
        trackId: a.gK.maybeNull(a.gK.string),
        uploadUrl: a.gK.maybeNull(a.gK.string)
      }).volatile(() => ({ file: null, abortController: null })).actions((e2) => {
        let t2 = {
          setFile(t3) {
            e2.file = t3;
          },
          getUploadUrl: (0, a.L3)(function* () {
            if (!(0, a._n)(e2)) return;
            let { loaderResource: t3, modelActionsLogger: i2 } = (0, a._$)(e2), { user: r2 } = (0, a.Zn)(e2);
            if (![g.IDLE, g.REJECT].includes(e2.loadingState)) return;
            e2.loadingState = g.PREPARE;
            let l2 = r2.account.data.uid;
            if (l2)
              try {
                var s2;
                let i3 = null == (s2 = e2.file) ? void 0 : s2.name, r3 = yield t3.getUploadUrl({
                  playlistId: "".concat(l2, ":").concat(e2.playlistKind),
                  uid: l2,
                  path: i3
                });
                if (r3 && "result" in r3 && r3.result === n.TOO_MANY_FILES) {
                  e2.loadingState = g.REJECT, e2.errorReason = m.TOO_MANY_FILES;
                  return;
                }
                if (r3 && "post-target" in r3 && "ugc-track-id" in r3) {
                  e2.uploadUrl = r3["post-target"], e2.trackId = r3["ugc-track-id"];
                  return;
                }
                e2.errorReason = m.UNKNOWN_ERROR, e2.loadingState = g.REJECT;
                return;
              } catch (t4) {
                e2.loadingState = g.REJECT, i2.error(t4);
                return;
              }
          }),
          uploadFile: (0, a.L3)(function* () {
            if (!(0, a._n)(e2)) return;
            let { prefixlessResource: t3, modelActionsLogger: i2 } = (0, a._$)(e2);
            if (e2.loadingState === g.PREPARE && e2.uploadUrl && e2.file) {
              e2.loadingState = g.UPLOADING;
              try {
                let i3 = new FormData();
                i3.append("file", e2.file);
                let r2 = new AbortController(), n2 = r2.signal;
                e2.abortController = r2, yield t3.uploadFile({ url: e2.uploadUrl, formData: i3 }, { signal: n2 }), e2.loadingState = g.PROCESSING;
                return;
              } catch (t4) {
                e2.loadingState = g.REJECT, i2.error(t4);
                return;
              }
            }
          }),
          runUpload: (0, a.L3)(function* () {
            (0, a._n)(e2) && (yield t2.getUploadUrl(), e2.loadingState !== g.REJECT && (yield t2.uploadFile()));
          }),
          retryUpload() {
            if (this.reset(), !(0, a._n)(e2)) return;
            let { ugcUploadCenter: t3 } = (0, a.Zn)(e2);
            t3.runUploadTracksQueue();
          },
          abortUpload() {
            var t3;
            if (e2.loadingState = g.CANCELLED, null == (t3 = e2.abortController) || t3.abort(), !(0, a._n)(e2))
              return;
            let { ugcUploadCenter: i2 } = (0, a.Zn)(e2);
            i2.clearCancelledUploads();
          },
          reset() {
            e2.loadingState = g.IDLE, e2.trackId = null, e2.uploadUrl = null, e2.abortController = null;
          }
        };
        return t2;
      }), U = a.gK.model("Ugc");
      var x = i(37408);
      i(48392), i(42488);
      var F = i(5207);
    },
    54906: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { J: () => r }), (function(e2) {
        e2.OWN = "OWN", e2.UGC = "UGC", e2.OWN_REPLACED_TO_UGC = "OWN_REPLACED_TO_UGC", e2.EXTERNAL = "EXTERNAL";
      })(r || (r = {}));
    },
    62345: (e, t, i) => {
      "use strict";
      i.d(t, { useTrackSourceContext: () => u });
      var r = i(61910), n = i(63585), a = i(74125), l = i(13596), s = i(29064);
      let o = {
        [a._Q$.SEARCH]: s.h.SEARCH,
        [a._Q$.DOWNLOADS_TRACKS]: s.h.DOWNLOADED_TRACKS,
        [a._Q$.HISTORY]: s.h.MUSIC_HISTORY
      };
      function u(e2) {
        var t2, i2;
        let { album: u2, playlist: d, artist: c, track: m } = (0, a.Pjs)(), { sourceContextData: g } = (0, a.SsQ)(), { pageId: v } = (0, a.$au)();
        return (0, r.useMemo)(() => {
          var t3, i3, r2, a2;
          let E = null == g ? void 0 : g.sourceContextType, I = null != E ? E : v && o[v] ? o[v] : s.h.BASED_ON_ENTITY_BY_DEFAULT, p = !!(null == g || null == (t3 = g.meta) ? void 0 : t3.id);
          if (g && (g.type !== n.K.Various || p)) return g;
          let y = m.isOpened ? m.albumId : null;
          return y ? (0, l.t)({ contextType: n.K.Album, contextId: y, entityContextType: I }) : (null == (i3 = d.meta) ? void 0 : i3.uid) && (null == (r2 = d.meta) ? void 0 : r2.kind) ? (0, l.t)({
            contextType: n.K.Playlist,
            contextId: "".concat(d.meta.uid, ":").concat(d.meta.kind),
            playlistUid: d.meta.uid,
            playlistKind: d.meta.kind,
            filter: d.filters.activeFilter,
            entityContextType: I
          }) : u2.id ? (0, l.t)({ contextType: n.K.Album, contextId: u2.id, entityContextType: I }) : c.id ? (0, l.t)({ contextType: n.K.Artist, contextId: c.id, entityContextType: I }) : (null == e2 ? void 0 : e2.albumId) ? (0, l.t)({ contextType: n.K.Album, contextId: e2.albumId, entityContextType: I }) : (0, l.t)({
            contextType: n.K.Various,
            contextId: null != (a2 = null == e2 ? void 0 : e2.id) ? a2 : "",
            entityContextType: I
          });
        }, [
          g,
          v,
          m.isOpened,
          m.albumId,
          u2.id,
          null == (t2 = d.meta) ? void 0 : t2.uid,
          null == (i2 = d.meta) ? void 0 : i2.kind,
          d.filters.activeFilter,
          c.id,
          null == e2 ? void 0 : e2.albumId,
          null == e2 ? void 0 : e2.id
        ]);
      }
    },
    68568: (e, t, i) => {
      "use strict";
      i.d(t, { b: () => l, e: () => a });
      var r = i(8075), n = i(80585);
      let a = (e2) => {
        if (!e2) return n.cp.TRACK;
        switch (e2.type) {
          case r.S.PODCAST:
            return n.cp.PODCAST_EPISODE;
          case r.S.AUDIOBOOK:
            return n.cp.AUDIOBOOK_EPISODE;
          default:
            return n.cp.TRACK;
        }
      }, l = (e2) => a(e2);
    },
    83399: (e, t, i) => {
      "use strict";
      i.d(t, { useProgressTimeNonMusic: () => a });
      var r = i(43426), n = i(74125);
      let a = (e2, t2) => {
        let { formatMessage: i2 } = (0, r.A)(), { hours: a2, minutes: l, seconds: s } = (0, n.e6v)(e2), { hours: o, minutes: u, seconds: d } = (0, n.e6v)(t2);
        return i2(
          { id: "non-music.non-music-progress" },
          {
            progress: Math.round(e2 / t2 * 100),
            beginHours: a2,
            beginMinutes: l,
            beginSeconds: s,
            endHours: o,
            endMinutes: u,
            endSeconds: d
          }
        );
      };
    },
    84321: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { O: () => r }), (function(e2) {
        e2.RADIO_STARTED = "radioStarted", e2.TRACK_STARTED = "trackStarted", e2.TRACK_FINISHED = "trackFinished", e2.SKIP = "skip", e2.SKIP_FAILED = "skipFailed", e2.LIKE = "like", e2.DISLIKE = "dislike", e2.AD = "ad", e2.JINGLE = "jingle", e2.UNLIKE = "unlike", e2.UNDISLIKE = "undislike", e2.COMBINED_QUEUE_STARTED = "combinedQueueStarted", e2.PLAYABLE_ITEM_STARTED = "playableItemStarted", e2.PLAYABLE_ITEM_FINISHED = "playableItemFinished", e2.PLAYABLE_ITEM_SKIP = "playableItemSkip", e2.PLAYABLE_ITEM_LIKE = "playableItemLike", e2.PLAYABLE_ITEM_DISLIKE = "playableItemDislike", e2.PLAYABLE_ITEM_UNLIKE = "playableItemUnlike", e2.PLAYABLE_ITEM_UNDISLIKE = "playableItemUndislike";
      })(r || (r = {}));
    },
    90516: (e) => {
      e.exports = {
        message: "NotificationDislike_message__R2jfZ",
        text: "NotificationDislike_text__xmrnn",
        cover: "NotificationDislike_cover__bvqFM",
        image: "NotificationDislike_image__h0_EO"
      };
    },
    95167: (e, t, i) => {
      "use strict";
      i.d(t, { b: () => n });
      var r = i(5693);
      function n(e2) {
        return (null == e2 ? void 0 : e2.data.type) === r.R.Music;
      }
    }
  }
]);
