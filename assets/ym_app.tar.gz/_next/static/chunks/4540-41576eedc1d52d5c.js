(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4540],
  {
    7032: (e, t, i) => {
      "use strict";
      i.d(t, { m: () => u });
      var n = i(54486), a = i(50420), s = i(15209), r = i(39610), o = i(97800), l = i(18433), c = i.n(l);
      let u = (e2) => {
        let { title: t2, children: i2, restrictionsClassName: l2, ...u2 } = e2;
        return (0, n.jsxs)("section", {
          className: c().root,
          ...(0, s.getDataAttrFromProps)(u2),
          children: [
            t2 && (0, n.jsxs)(n.Fragment, {
              children: [
                (0, n.jsx)(o.Caption, {
                  variant: "span",
                  type: "text",
                  size: "m",
                  weight: "medium",
                  "aria-hidden": true,
                  children: t2
                }),
                (0, n.jsx)(r.q, { children: (0, n.jsx)(o.Heading, { variant: "h4", children: t2 }) })
              ]
            }),
            (0, n.jsx)("div", { className: (0, a.$)(c().restrictions, l2), children: i2 })
          ]
        });
      };
    },
    16020: (e, t, i) => {
      "use strict";
      i.d(t, { s$: () => W, LL: () => p });
      var n = i(74125), a = i(93064), s = i(26433);
      let r = (e2) => {
        let { type: t2, tag: i2 } = e2.id;
        return {
          title: e2.name,
          seed: "".concat(t2, ":").concat(i2),
          specialContext: e2.specialContext,
          specialContextImage: e2.specialContextImage
        };
      }, o = (e2, t2) => {
        let i2 = [];
        return t2.possibleValues.forEach((e3) => {
          e3.unspecified || i2.push(((e4) => ({ value: e4.value, title: e4.name, seed: e4.serializedSeed, imageUrl: e4.imageUrl }))(e3));
        }), { type: e2, title: t2.name, values: (0, a.wg)(i2) };
      };
      var l = (function(e2) {
        return e2.DIVERSITY = "diversity", e2.MOOD_ENERGY = "moodEnergy", e2.LANGUAGE = "language", e2;
      })({});
      let c = a.gK.model("ContextItem", {
        title: a.gK.string,
        seed: a.gK.string,
        specialContext: a.gK.boolean,
        specialContextImage: a.gK.optional(a.gK.string, "")
      }), u = a.gK.model("RestrictonValue", {
        value: a.gK.string,
        title: a.gK.string,
        seed: a.gK.string,
        imageUrl: a.gK.maybe(a.gK.string)
      }), d = a.gK.model("Restricton", {
        type: a.gK.enumeration(Object.values(l)),
        title: a.gK.string,
        values: a.gK.array(u)
      }), p = a.gK.compose(
        a.gK.model("VibeSettings", {
          contextItems: a.gK.array(c),
          diversity: a.gK.maybeNull(d),
          moodEnergy: a.gK.maybeNull(d),
          language: a.gK.maybeNull(d)
        }),
        s.XT
      ).actions((e2) => ({
        getData: (0, a.L3)(function* (t2) {
          let { rotorResource: i2, modelActionsLogger: s2 } = (0, a._$)(e2);
          if (e2.loadingState !== n.GuX.PENDING)
            try {
              var c2, u2, d2, p2;
              e2.loadingState = n.GuX.PENDING;
              let s3 = yield i2.waveSettings(t2);
              (null == s3 || null == (c2 = s3.settingRestrictions) ? void 0 : c2.diversity) && (e2.diversity = o(l.DIVERSITY, s3.settingRestrictions.diversity)), (null == s3 || null == (u2 = s3.settingRestrictions) ? void 0 : u2.moodEnergy) && (e2.moodEnergy = o(l.MOOD_ENERGY, s3.settingRestrictions.moodEnergy)), (null == s3 || null == (d2 = s3.settingRestrictions) ? void 0 : d2.language) && (e2.language = o(l.LANGUAGE, s3.settingRestrictions.language));
              let m2 = Array.isArray(null == s3 ? void 0 : s3.blocks) && (null == s3 || null == (p2 = s3.blocks) ? void 0 : p2.find((e3) => (null == e3 ? void 0 : e3.type) === "contexts"));
              m2 && Array.isArray(m2.items) && (e2.contextItems = (0, a.wg)(m2.items.map(r))), e2.loadingState !== n.GuX.IDLE && (e2.loadingState = n.GuX.RESOLVE);
            } catch (t3) {
              s2.error(t3), e2.loadingState !== n.GuX.IDLE && (e2.loadingState = n.GuX.REJECT);
            }
        }),
        reset() {
          e2.loadingState = n.GuX.IDLE, e2.contextItems = (0, a.wg)([]), e2.diversity = null, e2.moodEnergy = null, e2.language = null;
        }
      }));
      var m = i(54486), g = i(28303), b = i(61910), _ = i.t(b, 2), v = i(43426), h = i(47713), x = i(31500), y = i(8817), f = {
        4490: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { DOWN: () => o2, LEFT: () => a2, RIGHT: () => s2, UP: () => r2, useSwipeable: () => m2 });
          var n2 = i2(810);
          let a2 = "Left", s2 = "Right", r2 = "Up", o2 = "Down", l2 = {
            delta: 10,
            preventScrollOnSwipe: false,
            rotationAngle: 0,
            trackMouse: false,
            trackTouch: true,
            swipeDuration: 1 / 0,
            touchEventOptions: { passive: true }
          }, c2 = { first: true, initial: [0, 0], start: 0, swiping: false, xy: [0, 0] }, u2 = "mousemove", d2 = "mouseup";
          function p2(e3, t3) {
            if (0 === t3) return e3;
            let i3 = Math.PI / 180 * t3;
            return [e3[0] * Math.cos(i3) + e3[1] * Math.sin(i3), e3[1] * Math.cos(i3) - e3[0] * Math.sin(i3)];
          }
          function m2(e3) {
            var t3, i3, m3;
            let g2, { trackMouse: b2 } = e3, _2 = n2.useRef(Object.assign({}, c2)), v2 = n2.useRef(Object.assign({}, l2)), h2 = n2.useRef(Object.assign({}, v2.current));
            for (g2 in h2.current = Object.assign({}, v2.current), v2.current = Object.assign(Object.assign({}, l2), e3), l2)
              void 0 === v2.current[g2] && (v2.current[g2] = l2[g2]);
            let [x2, y2] = n2.useMemo(
              () => (function(e4, t4) {
                let i4 = (t5) => {
                  let i5 = "touches" in t5;
                  i5 && t5.touches.length > 1 || e4((e5, a3) => {
                    a3.trackMouse && !i5 && (document.addEventListener(u2, n3), document.addEventListener(d2, g3));
                    let { clientX: s3, clientY: r3 } = i5 ? t5.touches[0] : t5, o3 = p2([s3, r3], a3.rotationAngle);
                    return a3.onTouchStartOrOnMouseDown && a3.onTouchStartOrOnMouseDown({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), {
                      initial: o3.slice(),
                      xy: o3,
                      start: t5.timeStamp || 0
                    });
                  });
                }, n3 = (t5) => {
                  e4((e5, i5) => {
                    var n4, c3, u3, d3;
                    let m5 = "touches" in t5;
                    if (m5 && t5.touches.length > 1) return e5;
                    if (t5.timeStamp - e5.start > i5.swipeDuration)
                      return e5.swiping ? Object.assign(Object.assign({}, e5), { swiping: false }) : e5;
                    let { clientX: g4, clientY: b4 } = m5 ? t5.touches[0] : t5, [_4, v3] = p2([g4, b4], i5.rotationAngle), h3 = _4 - e5.xy[0], x3 = v3 - e5.xy[1], y3 = Math.abs(h3), f2 = Math.abs(x3), S2 = (t5.timeStamp || 0) - e5.start, N2 = Math.sqrt(y3 * y3 + f2 * f2) / (S2 || 1), E2 = [h3 / (S2 || 1), x3 / (S2 || 1)], j2 = (n4 = y3, c3 = f2, u3 = h3, d3 = x3, n4 > c3 ? u3 > 0 ? s2 : a2 : d3 > 0 ? o2 : r2), T2 = "number" == typeof i5.delta ? i5.delta : i5.delta[j2.toLowerCase()] || l2.delta;
                    if (y3 < T2 && f2 < T2 && !e5.swiping) return e5;
                    let A2 = {
                      absX: y3,
                      absY: f2,
                      deltaX: h3,
                      deltaY: x3,
                      dir: j2,
                      event: t5,
                      first: e5.first,
                      initial: e5.initial,
                      velocity: N2,
                      vxvy: E2
                    };
                    A2.first && i5.onSwipeStart && i5.onSwipeStart(A2), i5.onSwiping && i5.onSwiping(A2);
                    let O2 = false;
                    return (i5.onSwiping || i5.onSwiped || i5["onSwiped".concat(j2)]) && (O2 = true), O2 && i5.preventScrollOnSwipe && i5.trackTouch && t5.cancelable && t5.preventDefault(), Object.assign(Object.assign({}, e5), { first: false, eventData: A2, swiping: true });
                  });
                }, m4 = (t5) => {
                  e4((e5, i5) => {
                    let n4;
                    if (e5.swiping && e5.eventData) {
                      if (t5.timeStamp - e5.start < i5.swipeDuration) {
                        n4 = Object.assign(Object.assign({}, e5.eventData), { event: t5 }), i5.onSwiped && i5.onSwiped(n4);
                        let a3 = i5["onSwiped".concat(n4.dir)];
                        a3 && a3(n4);
                      }
                    } else i5.onTap && i5.onTap({ event: t5 });
                    return i5.onTouchEndOrOnMouseUp && i5.onTouchEndOrOnMouseUp({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), { eventData: n4 });
                  });
                }, g3 = (e5) => {
                  document.removeEventListener(u2, n3), document.removeEventListener(d2, g3), m4(e5);
                }, b3 = (e5, t5) => {
                  let a3 = () => {
                  };
                  if (e5 && e5.addEventListener) {
                    let s3 = Object.assign(Object.assign({}, l2.touchEventOptions), t5.touchEventOptions), r3 = [
                      ["touchstart", i4, s3],
                      [
                        "touchmove",
                        n3,
                        Object.assign(Object.assign({}, s3), t5.preventScrollOnSwipe ? { passive: false } : {})
                      ],
                      ["touchend", m4, s3]
                    ];
                    r3.forEach((t6) => {
                      let [i5, n4, a4] = t6;
                      return e5.addEventListener(i5, n4, a4);
                    }), a3 = () => r3.forEach((t6) => {
                      let [i5, n4] = t6;
                      return e5.removeEventListener(i5, n4);
                    });
                  }
                  return a3;
                }, _3 = {
                  ref: (t5) => {
                    null !== t5 && e4((e5, i5) => {
                      if (e5.el === t5) return e5;
                      let n4 = {};
                      return e5.el && e5.el !== t5 && e5.cleanUpTouch && (e5.cleanUpTouch(), n4.cleanUpTouch = void 0), i5.trackTouch && t5 && (n4.cleanUpTouch = b3(t5, i5)), Object.assign(Object.assign(Object.assign({}, e5), { el: t5 }), n4);
                    });
                  }
                };
                return t4.trackMouse && (_3.onMouseDown = i4), [_3, b3];
              })((e4) => _2.current = e4(_2.current, v2.current), { trackMouse: b2 }),
              [b2]
            );
            return t3 = _2.current, i3 = v2.current, m3 = h2.current, _2.current = i3.trackTouch && t3.el ? t3.cleanUpTouch ? i3.preventScrollOnSwipe !== m3.preventScrollOnSwipe || i3.touchEventOptions.passive !== m3.touchEventOptions.passive ? (t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: y2(t3.el, i3) })) : t3 : Object.assign(Object.assign({}, t3), { cleanUpTouch: y2(t3.el, i3) }) : (t3.cleanUpTouch && t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: void 0 })), x2;
          }
        },
        8691: (e2, t2, i2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useCallbackRef = void 0;
          let n2 = i2(810);
          t2.useCallbackRef = function(e3) {
            let t3 = (0, n2.useRef)({
              stableFn: function() {
                for (var e4 = arguments.length, i3 = Array(e4), n3 = 0; n3 < e4; n3++) i3[n3] = arguments[n3];
                return t3.current.callback(...i3);
              },
              callback: e3
            });
            return (0, n2.useInsertionEffect)(() => {
              t3.current.callback = e3;
            }), t3.current.stableFn;
          };
        },
        1381: (e2, t2, i2) => {
          var n2;
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useComponentSwipeable = t2.SwipeablePlacement = void 0;
          let a2 = i2(4490), s2 = i2(8691);
          !(function(e3) {
            e3.TOP = "top", e3.BOTTOM = "bottom", e3.RIGHT = "right", e3.LEFT = "left";
          })(n2 || (t2.SwipeablePlacement = n2 = {}));
          let r2 = (e3) => {
            let { ref: t3, deltaY: i3, deltaX: a3, placement: s3 } = e3;
            requestAnimationFrame(() => {
              t3.current && (t3.current.style.willChange = "transform", t3.current.style.transform = s3 === n2.TOP || s3 === n2.BOTTOM ? "translateY(".concat(i3 || 0, "px)") : "translateX(".concat(a3 || 0, "px)"));
            });
          }, o2 = (e3) => {
            requestAnimationFrame(() => {
              e3.current && (e3.current.style.transition = "none", e3.current.style.willChange = "", e3.current.style.transform = "");
            });
          };
          t2.useComponentSwipeable = (e3) => {
            let { ref: t3, swipeableProps: i3 = {}, onClose: l2, disableSwipe: c2, placement: u2, threshold: d2 } = e3, p2 = (0, s2.useCallbackRef)(() => {
              l2 && (o2(t3), l2());
            }), m2 = (0, s2.useCallbackRef)((e4) => {
              c2 || ((e5) => {
                let { ref: t4, deltaY: i4, deltaX: a3, placement: s3 } = e5;
                switch (s3) {
                  case n2.TOP:
                    i4 <= 0 && r2({ ref: t4, deltaY: i4, deltaX: a3, placement: s3 });
                    break;
                  case n2.RIGHT:
                    a3 >= 0 && r2({ ref: t4, deltaY: i4, deltaX: a3, placement: s3 });
                    break;
                  case n2.LEFT:
                    a3 <= 0 && r2({ ref: t4, deltaY: i4, deltaX: a3, placement: s3 });
                    break;
                  default:
                    i4 >= 0 && r2({ ref: t4, deltaY: i4, deltaX: a3, placement: s3 });
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2 });
            }), g2 = (0, s2.useCallbackRef)((e4) => {
              !c2 && (((e5) => {
                let { ref: t4, deltaY: i4, deltaX: a3, placement: s3, threshold: r3 = 25 } = e5;
                if (!t4.current) return false;
                let o3 = r3 / 100 * (s3 === n2.TOP || s3 === n2.BOTTOM ? t4.current.offsetHeight : t4.current.offsetWidth);
                switch (s3) {
                  case n2.TOP:
                    return i4 < 0 && Math.abs(i4) >= o3;
                  case n2.RIGHT:
                    return a3 > 0 && a3 >= o3;
                  case n2.LEFT:
                    return a3 < 0 && Math.abs(a3) >= o3;
                  default:
                    return i4 > 0 && i4 >= o3;
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2, threshold: d2 }) ? l2 && (o2(t3), l2()) : o2(t3));
            });
            return {
              handlers: (0, a2.useSwipeable)({ onSwiped: g2, onSwiping: m2, trackMouse: true, trackTouch: true, ...i3 }),
              onCloseCallback: p2
            };
          };
        },
        810: (e2) => {
          e2.exports = _;
        }
      }, S = {};
      function N(e2) {
        var t2 = S[e2];
        if (void 0 !== t2) return t2.exports;
        var i2 = S[e2] = { exports: {} };
        return f[e2](i2, i2.exports, N), i2.exports;
      }
      N.d = (e2, t2) => {
        for (var i2 in t2) N.o(t2, i2) && !N.o(e2, i2) && Object.defineProperty(e2, i2, { enumerable: true, get: t2[i2] });
      }, N.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), N.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var E = {};
      (() => {
        Object.defineProperty(E, "__esModule", { value: true }), E.usePopoverSwipeable = void 0;
        let e2 = N(810), t2 = N(1381);
        E.usePopoverSwipeable = (i2) => {
          let { ref: n2, swipeableProps: a2 = {}, onClose: s2, disableSwipe: r2, placement: o2, threshold: l2 } = i2, c2 = (0, e2.useMemo)(() => {
            switch (o2) {
              case "top":
              case "top-end":
              case "top-start":
                return t2.SwipeablePlacement.TOP;
              case "right":
              case "right-end":
              case "right-start":
                return t2.SwipeablePlacement.RIGHT;
              case "left":
              case "left-end":
              case "left-start":
                return t2.SwipeablePlacement.LEFT;
              default:
                return t2.SwipeablePlacement.BOTTOM;
            }
          }, [o2]);
          return (0, t2.useComponentSwipeable)({
            ref: n2,
            swipeableProps: a2,
            onClose: s2,
            disableSwipe: r2,
            placement: c2,
            threshold: l2
          });
        };
      })(), E.__esModule;
      var j = E.usePopoverSwipeable, T = i(62443), A = i(73633), O = i(77881), C = i(5956), I = i(92304), B = i(93666), w = i(97800);
      let R = function() {
        let e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, [t2, i2] = (0, b.useState)(e2), { contentRef: a2 } = (0, n.gKY)();
        return (0, b.useEffect)(() => {
          let e3 = new ResizeObserver((e4) => {
            let [n2] = e4 || [];
            n2 && n2.contentRect.height !== t2 && i2(n2.contentRect.height);
          });
          return a2 && e3.observe(a2), () => {
            e3.disconnect();
          };
        }, [t2, a2]), { contentHeight: t2 };
      };
      var k = i(7032), M = i(50420), P = i(58360);
      let V = (e2) => {
        var t2, i2, a2;
        let { seed: s2, title: r2, isStation: o2 } = e2, { vibe: l2 } = (0, n.Pjs)(), { applySetting: c2 } = (0, n.B0S)({
          seeds: null != (a2 = null == (t2 = l2.meta) ? void 0 : t2.seeds) ? a2 : [],
          pageIdForFrom: n._Q$.HOME,
          blockIdForFrom: n.hf$.RUP_MAIN_RADIO
        }), { formatMessage: u2 } = (0, v.A)(), d2 = !!(null == (i2 = l2.meta) ? void 0 : i2.seeds.includes(s2)), p2 = l2.applyingSetting === s2, m2 = (0, b.useMemo)(
          () => d2 ? "".concat(u2({ id: "vibe-actions.remove" }), " ").concat(r2) : "".concat(u2({ id: "vibe-actions.apply" }), " ").concat(r2),
          [d2, r2, u2]
        );
        return {
          isApplying: p2,
          isSelected: d2,
          ariaLabel: m2,
          ariaPressed: d2,
          onClickHandler: (0, b.useCallback)(async () => {
            l2.setApplyingSetting(s2), await c2(s2, o2), l2.setApplyingSetting();
          }, [c2, o2, s2, l2])
        };
      };
      var L = i(65061), z = i.n(L);
      let G = (0, g.PA)((e2) => {
        let { item: t2 } = e2, { vibe: i2 } = (0, n.Pjs)(), a2 = (0, b.useRef)(null), {
          isApplying: s2,
          isSelected: r2,
          ariaPressed: o2,
          onClickHandler: l2
        } = V({ seed: t2.seed, title: t2.title, isStation: true }), c2 = (0, b.useCallback)(
          (e3) => {
            i2.isApplying || (a2.current && (0, A.P)(e3, z().ripple, a2.current), l2());
          },
          [l2, i2.isApplying]
        );
        return (0, m.jsxs)(O.$, {
          radius: "xxxl",
          className: (0, M.$)(z().button, z().textButton, {
            [z().button_selected]: r2,
            [z().button_applying]: s2,
            [z().specialButton]: t2.specialContext
          }),
          onClick: c2,
          "aria-disabled": i2.isApplying,
          "aria-pressed": o2,
          withRipple: false,
          ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_CONTEXT_BUTTON),
          children: [
            t2.specialContext && (0, m.jsx)(P.Image, {
              className: z().specialImage,
              src: t2.specialContextImage,
              size: 100,
              fit: "cover",
              withAvatarReplace: true
            }),
            (0, m.jsx)(w.Caption, {
              variant: "span",
              type: "controls",
              size: "m",
              weight: "medium",
              className: z().title,
              children: t2.title
            }),
            (0, m.jsx)("div", { className: z().rippleContainer, ref: a2 })
          ]
        });
      }), U = (0, g.PA)((e2) => {
        let { type: t2, restrictionValue: i2 } = e2, { vibe: a2 } = (0, n.Pjs)(), s2 = (0, b.useRef)(null), { isApplying: r2, isSelected: o2, ariaPressed: c2, onClickHandler: u2 } = V({ seed: i2.seed, title: i2.title }), d2 = (0, b.useCallback)(
          (e3) => {
            a2.isApplying || (s2.current && (0, A.P)(e3, z().ripple, s2.current), u2());
          },
          [u2, a2.isApplying]
        ), p2 = (0, b.useMemo)(
          () => (0, m.jsx)(w.Caption, {
            variant: "span",
            type: "controls",
            size: "m",
            weight: "medium",
            className: z().title,
            children: i2.title
          }),
          [i2.title]
        );
        switch (t2) {
          case l.DIVERSITY:
            return (0, m.jsxs)(O.$, {
              className: (0, M.$)(z().button, z().diversityButton, {
                [z().button_selected]: o2,
                [z().button_applying]: r2
              }),
              radius: "xl",
              "aria-disabled": a2.isApplying,
              "aria-pressed": c2,
              onClick: d2,
              withRipple: false,
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_DIVERSITY_BUTTON),
              children: [
                (0, m.jsx)(P.Image, {
                  "aria-hidden": true,
                  src: i2.imageUrl,
                  fit: "contain",
                  width: 40,
                  height: 40,
                  withAvatarReplace: true,
                  className: z().diversityButtonImage
                }),
                p2,
                (0, m.jsx)("div", { className: z().rippleContainer, ref: s2 })
              ]
            });
          case l.MOOD_ENERGY:
            return (0, m.jsxs)("div", {
              className: z().moodEnergy,
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_MOOD_ENERGY_BUTTON),
              children: [
                (0, m.jsx)(O.$, {
                  variant: "text",
                  className: (0, M.$)(z().button, z().moodEnergyButton, {
                    [z().button_selected]: o2,
                    [z().button_applying]: r2
                  }),
                  radius: "round",
                  onClick: d2,
                  withRipple: false,
                  "aria-disabled": a2.isApplying,
                  "aria-pressed": c2,
                  "aria-label": i2.title,
                  children: (0, m.jsx)(P.Image, {
                    src: i2.imageUrl,
                    fit: "contain",
                    width: 52,
                    height: 52,
                    "aria-hidden": true,
                    withAvatarReplace: true,
                    className: z().moodEnergyButtonImage
                  })
                }),
                (0, m.jsx)("span", { "aria-hidden": true, children: p2 })
              ]
            });
          case l.LANGUAGE:
            return (0, m.jsxs)(O.$, {
              radius: "xxxl",
              className: (0, M.$)(z().button, z().textButton, { [z().button_selected]: o2, [z().button_applying]: r2 }),
              onClick: d2,
              withRipple: false,
              "aria-disabled": a2.isApplying,
              "aria-pressed": c2,
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_LANGUAGE_BUTTON),
              children: [p2, (0, m.jsx)("div", { className: z().rippleContainer, ref: s2 })]
            });
          default:
            return null;
        }
      });
      var D = i(87709), K = i.n(D);
      let F = (0, g.PA)(() => {
        let { vibeSettings: e2 } = (0, n.Pjs)(), { formatMessage: t2 } = (0, v.A)();
        return e2.isNeededToLoad && e2.getData(), (0, m.jsxs)("div", {
          className: K().root,
          children: [
            e2.contextItems.length > 0 && (0, m.jsx)(k.m, {
              title: t2({ id: "interface-actions.my-vibe-context-settings" }),
              restrictionsClassName: K().contextItems,
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_CONTEXT_BLOCK),
              children: e2.contextItems.map(
                (e3) => (0, m.jsx)(G, { item: e3, ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_CONTEXT_BUTTON) }, e3.seed)
              )
            }),
            e2.diversity && (0, m.jsx)(k.m, {
              title: e2.diversity.title,
              restrictionsClassName: K().diversity,
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_DIVERSITY_BLOCK),
              children: e2.diversity.values.map((t3) => {
                var i2;
                return (0, m.jsx)(
                  U,
                  { type: null == (i2 = e2.diversity) ? void 0 : i2.type, restrictionValue: t3 },
                  t3.value
                );
              })
            }),
            e2.moodEnergy && (0, m.jsx)(k.m, {
              title: e2.moodEnergy.title,
              restrictionsClassName: K().moodEnergy,
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_MOOD_ENERGY_BLOCK),
              children: e2.moodEnergy.values.map((t3) => {
                var i2;
                return (0, m.jsx)(
                  U,
                  { type: null == (i2 = e2.moodEnergy) ? void 0 : i2.type, restrictionValue: t3 },
                  t3.value
                );
              })
            }),
            e2.language && (0, m.jsx)(k.m, {
              title: e2.language.title,
              restrictionsClassName: K().contextItems,
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_LANGUAGE_BLOCK),
              children: e2.language.values.map((t3) => {
                var i2;
                return (0, m.jsx)(
                  U,
                  { type: null == (i2 = e2.language) ? void 0 : i2.type, restrictionValue: t3 },
                  t3.value
                );
              })
            })
          ]
        });
      });
      var H = i(77901), X = i.n(H);
      let W = (0, g.PA)(() => {
        var e2, t2, i2, a2;
        let { formatMessage: s2 } = (0, v.A)(), {
          vibe: r2,
          settings: { isMobile: o2 },
          vibeSettings: l2
        } = (0, n.Pjs)(), { pageId: c2 } = (0, n.$au)(), { blockIdForFrom: u2 } = (0, n.N8n)(), d2 = (0, b.useRef)(null), p2 = (0, b.useRef)(null), g2 = (0, b.useRef)(null), { resetSettings: _2 } = (0, n.B0S)({
          seeds: null != (a2 = null == (e2 = r2.meta) ? void 0 : e2.seeds) ? a2 : [],
          pageIdForFrom: c2,
          blockIdForFrom: u2
        }), { contentRef: f2 } = (0, n.gKY)(), { contentHeight: S2 } = R(0), { state: N2, setState: E2, toggleFalse: k2 } = (0, T.e)(false);
        (0, b.useEffect)(
          () => () => {
            l2.reset();
          },
          [l2]
        );
        let M2 = (0, b.useMemo)(
          () => o2 ? { height: "88vh", transitionProperty: "opacity" } : f2 ? { insetInlineEnd: 7, insetBlockStart: f2.offsetTop + 7, height: S2 - 16 } : {},
          [S2, f2, o2]
        ), P2 = !!(r2.isApplying || r2.isMyVibe), V2 = (0, y.c)((e3) => {
          if (!r2.isApplying) {
            var t3;
            d2.current && (0, A.P)(e3, X().ripple, d2.current), _2(), null == (t3 = p2.current) || t3.focus();
          }
        }), L2 = (0, b.useMemo)(() => {
          var e3, t3;
          if (((e4) => !!e4 && e4.some((e5) => {
            let [t4] = (null == e5 ? void 0 : e5.split(":")) || [];
            return e5 === n.M19 || t4 && n.UMA.includes(t4);
          }))(null == (e3 = r2.meta) ? void 0 : e3.seeds))
            return (null == (t3 = r2.meta) ? void 0 : t3.context) ? (0, m.jsx)(O.$, {
              className: X().toggleSettingsButton,
              size: "m",
              radius: "round",
              icon: (0, m.jsx)(C.Icon, { variant: "filter", size: "xs" }),
              "aria-label": s2({ id: "vibe-actions.aria-label-settings" }),
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_BUTTON)
            }) : (0, m.jsx)(O.$, {
              className: X().toggleSettingsButton,
              size: "default",
              radius: "xxxl",
              icon: (0, m.jsx)(C.Icon, { variant: "filter", size: "xxs" }),
              "aria-label": s2({ id: "vibe-actions.aria-label-settings" }),
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_BUTTON),
              children: (0, m.jsx)(w.Caption, {
                variant: "span",
                type: "controls",
                size: "m",
                weight: "medium",
                children: (0, m.jsx)(h.A, { id: "interface-actions.configure-my-vibe" })
              })
            });
        }, [s2, null == (t2 = r2.meta) ? void 0 : t2.context, null == (i2 = r2.meta) ? void 0 : i2.seeds]), { handlers: z2 } = j({
          ref: g2,
          onClose: k2,
          placement: "bottom",
          disableSwipe: !o2,
          swipeableProps: { preventScrollOnSwipe: true }
        });
        return (0, m.jsxs)(I.AM, {
          placement: o2 ? "bottom" : "right",
          isMobile: o2,
          strategy: "fixed",
          transform: false,
          portalNode: f2,
          positionElement: f2,
          disableFloatingStyles: !o2,
          open: N2,
          onOpenChange: E2,
          style: M2,
          overlayClassName: X().overlay,
          popoverContentRef: g2,
          children: [
            L2,
            (0, m.jsx)(I.hl, {
              className: X().popover,
              ref: g2,
              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_BLOCK),
              children: (0, m.jsxs)("div", {
                className: X().root,
                children: [
                  o2 && (0, m.jsx)("div", { ref: z2.ref, onMouseDown: z2.onMouseDown, className: X().swipeableArea }),
                  (0, m.jsxs)("div", {
                    className: X().header,
                    children: [
                      (0, m.jsx)(w.Heading, {
                        variant: "h3",
                        size: "s",
                        weight: "bold",
                        ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_TITLE),
                        children: (0, m.jsx)(h.A, { id: "interface-actions.my-vibe-settings" })
                      }),
                      (0, m.jsxs)("div", {
                        className: X().actions,
                        children: [
                          (0, m.jsx)(B.m_, {
                            offsetOptions: 4,
                            placement: "left",
                            text: s2({ id: "interface-actions.reset-my-vibe-settings" }),
                            children: (0, m.jsx)(O.$, {
                              variant: "outline",
                              radius: "round",
                              size: "xxxs",
                              icon: (0, m.jsx)(C.Icon, { variant: "reset", size: "xxxs" }),
                              onClick: V2,
                              disabled: !!r2.isMyVibe,
                              "aria-hidden": !!r2.isMyVibe,
                              "aria-disabled": P2,
                              "aria-label": s2({ id: "interface-actions.reset-my-vibe-settings" }),
                              ref: d2,
                              ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_RESET_BUTTON)
                            })
                          }),
                          (0, m.jsx)(O.$, {
                            radius: "round",
                            color: "secondary",
                            size: "xxs",
                            icon: (0, m.jsx)(C.Icon, { variant: "close", size: "xxs" }),
                            onClick: k2,
                            "aria-label": s2({ id: "interface-actions.close-my-vibe-settings" }),
                            ref: p2,
                            ...(0, x.Am)(x.Kq.vibeSettings.VIBE_SETTINGS_CLOSE_BUTTON)
                          })
                        ]
                      })
                    ]
                  }),
                  (0, m.jsx)(F, {})
                ]
              })
            })
          ]
        });
      });
    },
    18433: (e) => {
      e.exports = { root: "RestrictionBlock_root__qzBtp", restrictions: "RestrictionBlock_restrictions__6V1zc" };
    },
    18467: (e) => {
      e.exports = { root: "VibeWidget_root__Chpsm", meta: "VibeWidget_meta__WQ7zn", wheel: "VibeWidget_wheel__SrYUt" };
    },
    22317: (e) => {
      e.exports = {
        root: "PlayButton_root__nYKdN",
        root_isLoading: "PlayButton_root_isLoading__925Sa",
        "applying-setting": "PlayButton_applying-setting__3nbT9",
        icon: "PlayButton_icon__t_THQ"
      };
    },
    29015: (e) => {
      e.exports = {
        root: "VibeContext_root__dbiNv",
        context: "VibeContext_context__Z_82k",
        pinButton: "VibeContext_pinButton__b6SNF",
        resetButton: "VibeContext_resetButton__9KK4S"
      };
    },
    35929: (e) => {
      e.exports = {
        vibeAnimation: "VibeBlock_vibeAnimation__XVEE6",
        controls: "VibeBlock_controls__BpDFL",
        root: "VibeBlock_root__z7LtR",
        root_freemium: "VibeBlock_root_freemium__4i2rV",
        playButton: "VibeBlock_playButton__6xU55",
        settingsButton: "VibeBlock_settingsButton__GeMtO",
        subscriptionText: "VibeBlock_subscriptionText__ODUZN",
        button: "VibeBlock_button__fWXM_"
      };
    },
    47198: (e) => {
      e.exports = {
        content: "MainPage_content__kskSM",
        root: "MainPage_root__STXqc",
        container: "MainPage_container__CB86l",
        vibe: "MainPage_vibe__XEBbh",
        vibeWidgetContainer: "MainPage_vibeWidgetContainer__i5T4X",
        landing: "MainPage_landing___FGNm",
        actionsContainer: "MainPage_actionsContainer__t90JB",
        beta: "MainPage_beta__y32vb",
        beta_withReleaseNotes: "MainPage_beta_withReleaseNotes__WOjUk",
        specialHeaderContainer: "MainPage_specialHeaderContainer__L3C6E",
        specialHeader: "MainPage_specialHeader__aqdvj",
        specialHeaderImage: "MainPage_specialHeaderImage__4GlXq",
        footer: "MainPage_footer__2rGy2",
        error: "MainPage_error__u_UCm"
      };
    },
    47486: (e) => {
      e.exports = { root: "VibeWidgetMeta_root__7N4Yf", artist: "VibeWidgetMeta_artist__qN0Fe" };
    },
    54722: (e, t, i) => {
      "use strict";
      i.d(t, { D7: () => l, CT: () => G, jF: () => er });
      var n, a = i(93064);
      (n || (n = {})).OK = "ok";
      var s = i(76866), r = i(74125), o = i(26433);
      let l = a.gK.compose(
        a.gK.model("VibeActions", {
          meta: a.gK.maybeNull(s.Gh),
          applyingSetting: a.gK.maybeNull(a.gK.string),
          isApplying: a.gK.boolean,
          vibeResetLoadingState: a.gK.enumeration(Object.values(r.GuX))
        }),
        o.XT
      ).views((e2) => ({
        get isMyVibe() {
          return e2.meta && 1 === e2.meta.seeds.length && e2.meta.seeds[0] === r.M19;
        }
      })).actions((e2) => ({
        getLastVibe: (0, a.L3)(function* () {
          let { rotorResource: t2, modelActionsLogger: i2 } = (0, a._$)(e2);
          if (e2.loadingState !== r.GuX.PENDING)
            try {
              e2.loadingState = r.GuX.PENDING;
              let i3 = yield t2.waveLast();
              e2.meta = (0, s.lb)(i3), e2.loadingState = r.GuX.RESOLVE;
            } catch (t3) {
              i2.error(t3), e2.loadingState = r.GuX.REJECT;
            }
        }),
        vibeReset: (0, a.L3)(function* () {
          let { rotorResource: t2, modelActionsLogger: i2 } = (0, a._$)(e2);
          if (e2.vibeResetLoadingState !== r.GuX.PENDING)
            try {
              e2.vibeResetLoadingState = r.GuX.PENDING, (yield t2.waveLastReset()) === n.OK && (e2.meta = (0, s.lb)({ name: "", seeds: [r.M19] })), e2.vibeResetLoadingState = r.GuX.RESOLVE;
            } catch (t3) {
              i2.error(t3), e2.vibeResetLoadingState = r.GuX.REJECT;
            }
        }),
        setApplyingSetting(t2) {
          t2 ? e2.applyingSetting = (0, a.wg)(t2) : e2.applyingSetting = null;
        },
        setIsApplying(t2) {
          e2.isApplying = t2;
        },
        setVibe(t2) {
          e2.meta = (0, s.lb)(t2);
        },
        reset() {
          e2.meta = null, e2.vibeResetLoadingState = r.GuX.IDLE, e2.loadingState = r.GuX.IDLE;
        }
      }));
      var c = i(54486), u = i(50420), d = i(28303), p = i(97396), m = i(61910), g = i.t(m, 2), b = i(47713), _ = i(31500), v = i(8817), h = i(67648), x = i(85360), y = i(77881), f = i(97800);
      let S = (0, m.lazy)(
        async () => Promise.all([i.e(1375), i.e(7533)]).then(i.bind(i, 7533)).then((e2) => ({ default: e2.VibeFallbackAnimation }))
      ), N = (0, m.lazy)(
        async () => Promise.all([i.e(1375), i.e(5067)]).then(i.bind(i, 45067)).then((e2) => ({ default: e2.VibeAnimation }))
      );
      var E = i(80585), j = i(43426), T = i(5956), A = i(22317), O = i.n(A);
      let C = true, I = (0, d.PA)((e2) => {
        let { isPlaying: t2, onClick: i2, ariaDisabled: n2, className: a2 } = e2, { vibe: s2 } = (0, r.Pjs)(), { formatMessage: o2 } = (0, j.A)(), l2 = (0, r.W6M)(), d2 = (0, r.D60)(), p2 = t2 ? "pauseVibe" : "playVibe", g2 = t2 ? _.e8.vibe.MY_VIBE_PAUSE_BUTTON : _.e8.vibe.MY_VIBE_PLAY_BUTTON, v2 = (0, m.useMemo)(
          () => t2 ? o2({ id: "vibe-actions.aria-label-pause" }) : o2({ id: "vibe-actions.aria-label-play" }),
          [o2, t2]
        ), h2 = (0, m.useCallback)(
          (e3) => {
            s2.isApplying || null == i2 || i2(), e3.stopPropagation(), e3.preventDefault();
          },
          [i2, s2.isApplying]
        );
        return (0, m.useEffect)(() => {
          if ("production" === d2 && 1 === l2.length && C) {
            var e3, t3;
            let i3 = Math.round(performance.now());
            null == (t3 = window.Ya) || null == (e3 = t3.Rum) || e3.sendTimeMark("my-vibe-button-loading-time", i3), C = false;
          }
        }, []), (0, c.jsx)(y.$, {
          className: (0, u.$)(O().root, { [O().root_isVibeLoading]: s2.isApplying }, a2),
          withRipple: false,
          withHover: false,
          onClick: h2,
          variant: "text",
          "aria-disabled": s2.isApplying || n2,
          "aria-label": v2,
          icon: (0, c.jsx)(T.Icon, { size: "s", className: O().icon, variant: p2 }),
          ...(0, _.Am)(g2),
          children: (0, c.jsx)(b.A, { id: "entity-names.my-vibe" })
        });
      });
      I.displayName = "PlayButton";
      var B = i(35929), w = i.n(B), R = i(27510), k = i(16020), M = i(29015), P = i.n(M);
      let V = (0, d.PA)((e2) => {
        var t2;
        let { context: i2, onResetClick: n2, className: a2 } = e2, {
          vibe: o2,
          settings: { isMobile: l2 },
          experiments: d2
        } = (0, r.Pjs)(), { formatMessage: p2 } = (0, j.A)(), m2 = (0, s.A7)(o2.meta), g2 = i2 && !l2, b2 = (0, R.L)(() => {
          var e3;
          return d2.checkExperiment(r.zal.WebNextVibeDescription, "on") && (null == (e3 = o2.meta) ? void 0 : e3.isMix) ? p2({ id: "vibe-actions.vibe-context" }, { type: o2.meta.type, name: i2 }) : i2;
        });
        return (0, c.jsxs)("div", {
          className: (0, u.$)(P().root, a2),
          children: [
            g2 && (0, c.jsx)(E.O0, {
              size: "m",
              iconSize: "xs",
              withScaleAnimation: false,
              isPinned: null == (t2 = o2.meta) ? void 0 : t2.isPinned,
              onClick: m2,
              className: P().pinButton
            }),
            (0, c.jsx)(k.s$, {}),
            i2 && (0, c.jsxs)("div", {
              className: (0, u.$)(P().context),
              ...(0, _.Am)(_.e8.vibe.VIBE_CONTEXT),
              children: [
                (0, c.jsx)(f.Caption, {
                  variant: "span",
                  type: "controls",
                  size: "m",
                  weight: "medium",
                  lineClamp: 1,
                  children: b2
                }),
                (0, c.jsx)(y.$, {
                  className: P().resetButton,
                  variant: "text",
                  radius: "round",
                  withRipple: false,
                  icon: (0, c.jsx)(T.Icon, { variant: "close", size: "xxs" }),
                  onClick: n2,
                  "aria-label": "".concat(p2({ id: "vibe-actions.reset-settings" }), " ").concat(b2),
                  ...(0, _.Am)(_.e8.vibe.RESET_VIBE_CONTEXT_BUTTON)
                })
              ]
            })
          ]
        });
      }), L = "vibe-block", z = "vibe-block-controls", G = (0, d.PA)((e2) => {
        var t2, i2, n2, a2;
        let { className: s2 } = e2, o2 = (0, p.useRouter)(), { vibe: l2, experiments: d2, user: g2 } = (0, r.Pjs)(), j2 = (0, m.useRef)(null), [T2, A2] = (0, h.d)(), { pageId: O2 } = (0, r.$au)(), { blockIdForFrom: C2 } = (0, r.N8n)(), { isFreemium: B2 } = (0, r.XCI)(), {
          openPaymentWidgetModal: R2,
          saveOfferAndAuthorize: k2,
          isShimmerActive: M2,
          isShimmerVisible: P2,
          mainText: G2,
          mainTextA11y: U2,
          additionText: D2
        } = (0, r.DpZ)({
          storeName: "music",
          isEnabled: B2,
          offerElement: { element: T2, intersectionPropertyId: z }
        }), { isIntersecting: K2 } = null != (n2 = (0, x.BL)([j2], { preflightCheck: false }, !j2.current)[L]) ? n2 : {}, F2 = (0, r.NFA)().get(r.QGx), {
          isVibeContext: H2,
          isPlaying: X2,
          togglePlay: W2,
          resetSettings: $2
        } = (0, r.B0S)({
          seeds: null != (a2 = null == (t2 = l2.meta) ? void 0 : t2.seeds) ? a2 : [],
          pageIdForFrom: O2,
          blockIdForFrom: C2
        }), Y2 = d2.checkExperiment(r.zal.WebNextDisableVibeSettings, "on") || B2 || !g2.isAuthorized, q2 = (0, m.useCallback)(() => {
          H2 ? $2() : l2.vibeResetLoadingState !== r.GuX.PENDING && l2.vibeReset();
        }, [H2, l2, $2]), Z2 = (0, m.useCallback)(() => {
          if (!g2.isAuthorized) {
            if (!F2.authorizationUrl) return;
            o2.push(F2.authorizationUrl);
            return;
          }
          B2 && R2();
        }, [g2.isAuthorized, F2.authorizationUrl, o2, B2, R2]), J2 = (0, m.useCallback)(
          (e3) => {
            e3.stopPropagation(), e3.preventDefault(), Z2();
          },
          [Z2]
        ), Q2 = (0, m.useCallback)(() => {
          if (B2 || !g2.isAuthorized) return void Z2();
          W2();
        }, [B2, g2.isAuthorized, W2, Z2]), ee2 = (0, m.useMemo)(
          () => d2.checkExperiment(r.zal.WebNextShaderFallbackEnabled, "on") ? (0, c.jsx)(S, { className: w().vibeAnimation }) : (0, c.jsx)(N, { isIntersecting: K2, className: w().vibeAnimation }),
          [d2, K2]
        ), et2 = (0, v.c)(() => {
          if (!g2.isAuthorized) return void k2();
          R2();
        }), ei2 = (0, m.useMemo)(
          () => d2.checkExperiment(r.zal.WebNextUnauthorizedSubscriptionButton, "on") ? (0, c.jsxs)(y.$, {
            isBlock: true,
            radius: "xxxl",
            size: "l",
            color: "plus",
            className: w().button,
            onClick: et2,
            ...(0, _.Am)(_.e8.vibe.MY_VIBE_SUBSCRIPTION_BUTTON_UNAUTH),
            children: [
              (0, c.jsx)(f.Caption, { className: w().text_main, variant: "div", size: "l", children: G2 }),
              D2 && (0, c.jsx)(f.Caption, {
                className: w().text_addition,
                variant: "div",
                size: "m",
                children: D2
              })
            ]
          }) : (0, c.jsx)(E.Hi, { size: "l", className: w().button }),
          [D2, d2, et2, G2]
        );
        return (0, m.useEffect)(
          () => () => {
            l2.reset();
          },
          [l2]
        ), g2.isAuthorized && l2.isNeededToLoad && (0, m.use)(l2.getLastVibe()), (0, c.jsxs)("div", {
          className: (0, u.$)(w().root, { [w().root_freemium]: B2 || !g2.isAuthorized }, s2),
          ref: j2,
          "data-intersection-property-id": L,
          ...(0, _.Am)(_.e8.vibe.VIBE_BLOCK),
          children: [
            ee2,
            (0, c.jsxs)("div", {
              className: w().controls,
              onClick: J2,
              ref: A2,
              "data-intersection-property-id": z,
              children: [
                (0, c.jsx)(I, {
                  className: w().playButton,
                  isPlaying: X2,
                  ariaDisabled: B2 || !g2.isAuthorized,
                  onClick: Q2
                }),
                !Y2 && (0, c.jsx)(V, {
                  className: w().settingsButton,
                  context: null == (i2 = l2.meta) ? void 0 : i2.context,
                  onResetClick: q2
                }),
                (B2 || !g2.isAuthorized) && (0, c.jsx)(f.Caption, {
                  className: w().subscriptionText,
                  variant: "div",
                  size: "l",
                  ...(0, _.Am)(_.e8.vibe.MY_VIBE_SUBSCRIPTION_TEXT),
                  children: (0, c.jsx)(b.A, {
                    id: "vibe-freemium.available-in-plus",
                    values: { br: (0, c.jsx)("br", {}) }
                  })
                }),
                !g2.isAuthorized && ei2,
                g2.isAuthorized && B2 && (0, c.jsx)(E.b4, {
                  isShimmerActive: M2,
                  isShimmerVisible: P2,
                  onClick: R2,
                  mainText: G2,
                  ariaLabel: U2,
                  additionText: D2,
                  className: w().button,
                  ...(0, _.Am)(_.e8.vibe.MY_VIBE_SUBSCRIPTION_BUTTON)
                })
              ]
            })
          ]
        });
      });
      G.displayName = "VibeBlock";
      var U = i(18467), D = i.n(U), K = i(58360), F = i(58202), H = i.n(F);
      let X = (0, d.PA)((e2) => {
        var t2;
        let { artist: i2 } = e2, { formatMessage: n2 } = (0, j.A)(), a2 = null == (t2 = i2.cutoutCover) ? void 0 : t2.uri, s2 = i2.coverUri, r2 = n2({ id: "entity-names.artist-name" }, { artistName: i2.name }), o2 = (0, R.L)(
          () => a2 ? (0, c.jsx)(K.Image, {
            className: (0, u.$)(H().image, H().cutout),
            fit: "contain",
            src: a2,
            size: 400,
            withAvatarReplace: true,
            withLoadingIndicator: false,
            alt: r2,
            "aria-hidden": true
          }) : s2 ? (0, c.jsx)(E.jL, {
            className: (0, u.$)(H().image, H().circle),
            fit: "cover",
            src: s2,
            maskSrc: "avatars.mds.yandex.net/get-music-misc/70683/img.6985fe688f488f26128bbd64/%%",
            size: 400,
            withAvatarReplace: true,
            withLoadingIndicator: false,
            alt: r2,
            "aria-hidden": true
          }) : null
        );
        return o2 ? (0, c.jsx)(E.N_, { href: i2.url, "aria-label": r2, children: o2 }) : null;
      });
      var W = {
        5969: (e2, t2, i2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.findOptimalFontSize = void 0;
          let n2 = i2(810), a2 = (e3) => {
            e3.style.wordBreak = "keep-all", e3.style.overflowWrap = "normal", e3.style.maxHeight = "none", e3.style.height = "auto", e3.style.overflow = "visible", Array.from(e3.children).forEach((e4) => {
              e4 instanceof HTMLElement && a2(e4);
            });
          };
          t2.findOptimalFontSize = (e3) => {
            let {
              container: t3,
              containerWidth: i3,
              containerHeight: n3,
              minFontSize: s2,
              maxFontSize: r2,
              lineHeight: o2,
              maxLines: l2
            } = e3, c2 = ((e4, t4, i4) => {
              let n4 = e4.cloneNode(true);
              return n4.style.cssText = "\n        position: absolute !important;\n        visibility: hidden !important;\n        pointer-events: none !important;\n        width: ".concat(
                t4,
                "px !important;\n    "
              ), a2(n4), n4.style.setProperty("--dynamic-line-height", String(i4)), document.body.appendChild(n4), n4;
            })(t3, i3, o2);
            try {
              let e4 = s2, t4 = r2, a3 = s2;
              for (; e4 <= t4; ) {
                let s3 = Math.floor((e4 + t4) / 2);
                c2.style.setProperty("--dynamic-font-size", "".concat(s3, "px"));
                let r3 = Math.min(l2 * s3 * o2, n3), u2 = c2.scrollHeight <= r3, d2 = c2.scrollWidth <= i3 + 1;
                u2 && d2 ? (a3 = s3, e4 = s3 + 1) : t4 = s3 - 1;
              }
              return a3 - 1;
            } finally {
              c2.remove();
            }
          }, t2.useDynamicText = (e3, i3) => {
            (0, n2.useLayoutEffect)(() => {
              if (null === e3) return;
              e3.style.setProperty("--dynamic-line-height", String(i3.lineHeight));
              let n3 = () => {
                let { width: n4, height: a4 } = e3.getBoundingClientRect(), s3 = e3.childNodes.length > 0;
                if (0 === n4 || 0 === a4 || !s3) return;
                let r2 = (0, t2.findOptimalFontSize)({ container: e3, containerWidth: n4, containerHeight: a4, ...i3 });
                e3.style.setProperty("--dynamic-font-size", "".concat(r2, "px"));
              }, a3 = new ResizeObserver(n3), s2 = new MutationObserver(n3);
              return a3.observe(e3), s2.observe(e3, { childList: true, characterData: true, subtree: true }), document.fonts.ready.then(n3), n3(), () => {
                a3.disconnect(), s2.disconnect();
              };
            }, [e3, i3]);
          };
        },
        810: (e2) => {
          e2.exports = g;
        }
      }, $ = {}, Y = (function e2(t2) {
        var i2 = $[t2];
        if (void 0 !== i2) return i2.exports;
        var n2 = $[t2] = { exports: {} };
        return W[t2](n2, n2.exports, e2), n2.exports;
      })(5969);
      Y.__esModule, Y.findOptimalFontSize;
      var q = Y.useDynamicText, Z = i(63695), J = i(82682), Q = i.n(J);
      let ee = { minFontSize: 24, maxFontSize: 64, maxLines: 2, lineHeight: 1.1 }, et = { minFontSize: 48, maxFontSize: 200, maxLines: 5, lineHeight: 1.1 }, ei = (e2) => {
        let { artists: t2, hasCover: i2, withLink: n2 } = e2, [a2, s2] = (0, h.d)(), r2 = i2 ? ee : et;
        return q(a2, r2), (0, c.jsx)("div", {
          ref: s2,
          className: (0, u.$)(Q().root, { [Q().root_withCover]: i2 }),
          children: (0, c.jsx)(Z.iQ, {
            artists: t2,
            captionClassName: Q().artists,
            linkClassName: Q().artists,
            className: Q().artists,
            lineClamp: r2.maxLines,
            withLink: n2,
            variant: "breakWord"
          })
        });
      };
      var en = i(47486), ea = i.n(en);
      let es = (0, d.PA)((e2) => {
        var t2, i2, n2;
        let { className: a2 } = e2, { sonataState: s2 } = (0, r.Pjs)(), o2 = null == (t2 = s2.entityMeta) ? void 0 : t2.mainArtist, l2 = null == (i2 = s2.entityMeta) ? void 0 : i2.artists, d2 = !!(null == (n2 = s2.entityMeta) ? void 0 : n2.isNonUserGenerated), p2 = !!((null == o2 ? void 0 : o2.coverUri) && !o2.isCoverFromAlbum && d2), m2 = p2 && o2;
        return (0, c.jsx)("div", {
          className: (0, u.$)(ea().root, a2),
          children: (0, c.jsxs)("div", {
            className: ea().artist,
            children: [
              l2 && (0, c.jsx)(ei, { artists: l2, hasCover: p2, withLink: d2 }),
              m2 && (0, c.jsx)(X, { artist: o2 })
            ]
          })
        });
      }), er = (0, d.PA)(() => {
        var e2;
        let { sonataState: t2 } = (0, r.Pjs)(), i2 = (0, m.useMemo)(() => {
          var e3;
          return {
            "--vibe-background-color": ((e4) => {
              if (!e4) return "#5C7B9B";
              let { h: t3, s: i3, l: n2 } = (0, r.g8k)(e4);
              return "hsl(".concat(t3, ", ").concat(i3 + 15, "%, ").concat(n2 + 5, "%)");
            })(null == (e3 = t2.entityMeta) ? void 0 : e3.averageColor)
          };
        }, [null == (e2 = t2.entityMeta) ? void 0 : e2.averageColor]);
        return (0, c.jsxs)("div", {
          className: D().root,
          style: i2,
          children: [(0, c.jsx)(es, { className: D().meta }), (0, c.jsx)("div", { className: D().wheel })]
        });
      });
    },
    58202: (e) => {
      e.exports = {
        image: "VibeWidgetArtistCover_image___IMdT",
        cutout: "VibeWidgetArtistCover_cutout__82qxa",
        circle: "VibeWidgetArtistCover_circle__NnPhZ"
      };
    },
    65061: (e) => {
      e.exports = {
        button: "RestrictionButton_button__eLMkU",
        button_selected: "RestrictionButton_button_selected__LHD20",
        button_applying: "RestrictionButton_button_applying___ik5f",
        "applying-setting": "RestrictionButton_applying-setting__utqyc",
        diversityButton: "RestrictionButton_diversityButton__uclSi",
        diversityButtonImage: "RestrictionButton_diversityButtonImage__21oME",
        moodEnergy: "RestrictionButton_moodEnergy__q_I4y",
        moodEnergyButton: "RestrictionButton_moodEnergyButton__yKkaS",
        moodEnergyButtonImage: "RestrictionButton_moodEnergyButtonImage__zxT2C",
        textButton: "RestrictionButton_textButton__HC_AE",
        title: "RestrictionButton_title__UZn0O",
        specialButton: "RestrictionButton_specialButton__Di6B9",
        specialImage: "RestrictionButton_specialImage__0E3x2",
        rippleContainer: "RestrictionButton_rippleContainer__xPANO",
        ripple: "RestrictionButton_ripple__Rsu8b"
      };
    },
    77901: (e) => {
      e.exports = {
        root: "VibeSettings_root__ufZlV",
        popover: "VibeSettings_popover__VKqUc",
        overlay: "VibeSettings_overlay__pusb4",
        toggleSettingsButton: "VibeSettings_toggleSettingsButton__j6fIU",
        header: "VibeSettings_header__OAWe2",
        actions: "VibeSettings_actions__ckbMt",
        swipeableArea: "VibeSettings_swipeableArea__Xx0nx",
        ripple: "VibeSettings_ripple__kmFX6"
      };
    },
    82682: (e) => {
      e.exports = {
        root: "VibeWidgetDynamicArtists_root__kPBES",
        root_withCover: "VibeWidgetDynamicArtists_root_withCover__kxQkK",
        artists: "VibeWidgetDynamicArtists_artists__gByOn"
      };
    },
    87709: (e) => {
      e.exports = {
        root: "VibeRestrictions_root__efJez",
        diversity: "VibeRestrictions_diversity__qfOls",
        moodEnergy: "VibeRestrictions_moodEnergy__Le0Cy",
        contextItems: "VibeRestrictions_contextItems__JrF7D"
      };
    },
    94540: (e, t, i) => {
      "use strict";
      i.d(t, { MainPage: () => O });
      var n = i(54486), a = i(50420), s = i(28303), r = i(97396), o = i(61910), l = i(43426), c = i(31500), u = i(6024), d = i(67648), p = i(27510), m = i(77881), g = i(58360), b = i(56231), _ = i(93666), v = i(97800), h = i(4542), x = i(82644), y = i(54722), f = i(65779), S = i(33276), N = i(54830), E = i(74125), j = i(80585), T = i(47198), A = i.n(T);
      let O = (0, s.PA)((e2) => {
        var t2, i2;
        let { withVideoModal: s2 } = e2, { main: T2, user: O2, experiments: C, releaseNotes: I, fullscreenVideoPlayer: B } = (0, E.Pjs)(), { formatMessage: w } = (0, l.A)(), R = (0, E.HFS)(), { contentScrollRef: k, setContentScrollRef: M } = (0, E.gKY)(), [P, V] = (0, d.d)(), L = (0, r.useSearchParams)(), z = L.get(E.K3F.IDS), G = L.get(E.K3F.ACTIVE_INDEX), { clipIds: U, activeClipIndex: D } = (0, f.V1)(z, G), K = (0, N.df)(), F = (0, N.Cc)(), { theme: H } = (0, E.DPo)(), X = C.checkExperiment(E.zal.WebNextNewWaveTab, "on"), W = (0, E.ZpR)(null != (i2 = null == (t2 = T2.specialHeader) ? void 0 : t2.url) ? i2 : "");
        (0, o.useLayoutEffect)(() => {
          s2 && K && (F(U, D), B.setOpenedFromMain());
        }, [s2, K, B, U, D, F]), (0, o.useEffect)(
          () => () => {
            T2.reset(), T2.landing.reset();
          },
          [T2, T2.landing]
        ), (0, E.Jzs)(T2.landing.isResolved);
        let $ = C.checkExperiment(E.zal.WebNextDisableVibe, "on"), Y = (0, o.useCallback)(() => {
          I.isReady && I.modal.open();
        }, [I.isReady, I.modal]), q = (0, o.useMemo)(() => $ ? { "margin-block-start": "1vh" } : {}, [$]), Z = (0, o.useMemo)(() => {
          if (C.checkExperiment(E.zal.WebNextBetaLabel, "off")) return null;
          {
            let e3 = C.checkExperiment(E.zal.WebNextBetaLabel, "version"), t3 = w({ id: "desktop.app-version" }, { version: R }), i3 = e3 ? R : "Beta";
            return (0, n.jsxs)(_.m_, {
              placement: "left",
              offsetOptions: 4,
              children: [
                (0, n.jsx)(m.$, {
                  color: "secondary",
                  radius: "xl",
                  "aria-label": e3 ? t3 : "Beta ".concat(t3),
                  className: (0, a.$)(A().beta, { [A().beta_withReleaseNotes]: I.isReady }),
                  onClick: Y,
                  children: (0, n.jsx)(v.Caption, {
                    variant: "div",
                    type: "text",
                    size: "s",
                    weight: "medium",
                    children: i3
                  })
                }),
                (0, n.jsx)(_.ZI, { children: R })
              ]
            });
          }
        }, [C, w, Y, I.isReady, R]), J = (0, o.useMemo)(() => {
          if (!T2.specialHeader) return {};
          let e3 = H === E.Sxu.Light ? T2.specialHeader.lightTheme : T2.specialHeader.darkTheme;
          return { "--special-button-background": e3.backgroundColor, "--special-button-color": e3.textColor };
        }, [T2.specialHeader, H]), Q = (0, p.L)(() => {
          let e3 = C.checkExperiment(E.zal.WebNextRewind2024, "on");
          return T2.specialHeader ? (0, n.jsxs)("div", {
            className: A().specialHeaderContainer,
            children: [
              e3 && (0, n.jsx)(g.Image, {
                src: "avatars.mds.yandex.net/get-music-misc/28052/img.69203c15cffc41172f18a125/orig",
                withAvatarReplace: true,
                className: A().specialHeaderImage,
                fit: "contain"
              }),
              (0, n.jsx)(m.$, {
                color: "secondary",
                size: "default",
                radius: "xxxl",
                role: "link",
                className: A().specialHeader,
                withHover: false,
                style: J,
                onClick: W,
                children: T2.specialHeader.title
              })
            ]
          }) : null;
        }), ee = (0, p.L)(
          () => X ? null : C.checkExperiment(E.zal.WebNextFooterDisclaimer, "on") ? (0, n.jsx)(j.wi, { className: A().footer }) : (0, n.jsx)(j.A, { children: (0, n.jsx)(j.wi, { className: A().footer }) })
        );
        if (T2.landing.isNeededToLoad && !X) {
          let e3 = O2.isAuthorized ? u.p.MAIN : u.p.MAIN_NOLOGIN, t3 = [
            T2.landing.getSkeleton({ id: e3, showWizard: O2.settings.showWizard }, { preloadBlocksCount: 2 }),
            T2.getSpecialHeader()
          ];
          (0, o.use)(Promise.allSettled(t3));
        }
        s2 && !K && (0, r.notFound)();
        let et = (0, p.L)(
          () => X ? (0, n.jsxs)("div", {
            className: A().vibeWidgetContainer,
            ...(0, c.Am)(c.Xk.main.MAIN_PAGE),
            children: [
              (0, n.jsxs)("div", { className: A().actionsContainer, children: [Q, Z] }),
              (0, n.jsx)(y.jF, {})
            ]
          }) : (0, n.jsx)(S.hO, {
            scrollElement: k,
            headerElement: P,
            children: (0, n.jsxs)(b.N, {
              className: A().root,
              containerClassName: A().content,
              ref: M,
              ...(0, c.Am)(c.Xk.main.MAIN_PAGE),
              children: [
                (0, n.jsxs)("div", { className: A().actionsContainer, children: [Q, Z] }),
                !$ && (0, n.jsx)(E.FoH, {
                  blockIdForFrom: E.hf$.RUP_MAIN_RADIO,
                  blockId: E.UfI.RUP,
                  blockType: E.UfI.RUP,
                  blockPosX: 0,
                  blockPosY: 0,
                  objectsCount: 0,
                  children: (0, n.jsx)(y.CT, { className: A().vibe })
                }),
                (0, n.jsx)(h.EA, {
                  landing: T2.landing,
                  headerConcealerComponent: (0, n.jsx)("div", { ref: V }),
                  errorComponent: (0, n.jsx)(x.w, { className: A().error, withBackwardControl: false }),
                  containerClassName: A().landing,
                  containerStyle: q,
                  tabWithHeadingTitle: true,
                  tabWithCovers: true,
                  tabWithSubtitle: true
                }),
                ee
              ]
            })
          })
        );
        return (0, n.jsx)(E.nVz, {
          pageId: E._Q$.HOME,
          children: (0, n.jsx)(E.rtM, { page: E.l7W.HOME_SCREEN, places: [E.RBW.MY_WAVE], children: et })
        });
      });
    }
  }
]);
