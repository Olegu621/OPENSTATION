(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4542],
  {
    1316: (e) => {
      e.exports = {
        root: "Skeleton_root__ANDaF",
        upperBlocks: "Skeleton_upperBlocks__zI__5",
        tab: "Skeleton_tab__Jn6By",
        tabPanel: "Skeleton_tabPanel__Ke42U",
        tabCarousel: "Skeleton_tabCarousel__E2kLf",
        important: "Skeleton_important__ob12_",
        header: "Skeleton_header__Ir5f4",
        stickyTabs: "Skeleton_stickyTabs__I_uuk"
      };
    },
    2885: (e) => {
      e.exports = {
        blocksContainer: "ContinueListen_blocksContainer__tQ80F",
        container: "ContinueListen_container__1oxhK",
        item: "ContinueListen_item__jGg_0",
        item_lastPlayed: "ContinueListen_item_lastPlayed__AkN1T",
        important: "ContinueListen_important__xwCU5"
      };
    },
    3095: (e, t, a) => {
      "use strict";
      a.d(t, { Vf: () => n.MixesGridMixCard, bv: () => o, rc: () => l });
      var i = a(93064), s = a(74125);
      let l = (e2) => (0, i.wg)({ id: e2.id, title: e2.title, weblink: e2.action.weblink, covers: e2.covers.map(s.pX4) });
      var r = a(26433);
      let o = i.gK.model("MixesGridMixCardItem", {
        id: i.gK.string,
        title: i.gK.string,
        weblink: i.gK.maybeNull(i.gK.string),
        covers: i.gK.maybeNull(i.gK.array(r.$B))
      });
      var n = a(27574);
    },
    3892: (e) => {
      e.exports = {
        root: "AlbumPromoCard_root__dAUet",
        artistImage: "AlbumPromoCard_artistImage__fWVxn",
        artistImage_withTopPosition: "AlbumPromoCard_artistImage_withTopPosition__tRrcO",
        artistCover: "AlbumPromoCard_artistCover__Gfhab",
        albumCover: "AlbumPromoCard_albumCover__QYYKH",
        button: "AlbumPromoCard_button__mpQr6",
        buttonIcon: "AlbumPromoCard_buttonIcon__WredC",
        buttonText: "AlbumPromoCard_buttonText__pI3Ot",
        albumImage: "AlbumPromoCard_albumImage__v8021",
        albumLink: "AlbumPromoCard_albumLink__dnGvR",
        artistLink: "AlbumPromoCard_artistLink__AD9__",
        title: "AlbumPromoCard_title__uzmho",
        titleLink: "AlbumPromoCard_titleLink__4DLNk",
        titleContainer: "AlbumPromoCard_titleContainer__f1k8Y",
        artists: "AlbumPromoCard_artists__UYpyB",
        artistsLink: "AlbumPromoCard_artistsLink__8gTlH"
      };
    },
    4111: (e, t, a) => {
      "use strict";
      a.d(t, { BlockEntities: () => I });
      var i = a(54486), s = a(50420), l = a(28303), r = a(61910), o = a(43426), n = a(31500), d = a(35620), c = a(60049), m = a(56231), u = a(97800), _ = a(94376), g = a(55616), p = a(33276), b = a(83909), v = a(3095), A = a(74125), T = a(80585), C = a(13991), h = a.n(C);
      let I = (0, l.PA)((e2) => {
        let { blockId: t2, blockType: a2 } = e2, { landingBlockEntities: l2 } = (0, A.Pjs)(), { formatMessage: C2 } = (0, o.A)(), { contentScrollRef: I2, setContentScrollRef: L } = (0, A.gKY)(), y = (0, A.W6M)(), S = (0, r.useMemo)(() => {
          if (l2.isLoading) {
            let e3 = C2({ id: "loading-messages.content-is-loading" }), t3 = [
              d.t.COLLECTION_ARTISTS,
              d.t.COLLECTION_ARTISTS_AND_TOP,
              d.t.PERSONAL_ARTISTS,
              d.t.NEW_STARS_ARTISTS,
              d.t.EDITORIAL_ARTISTS
            ].includes(a2), l3 = a2 === d.t.MIXES_GRID;
            return (0, i.jsx)(T.eI, {
              itemClassName: (0, s.$)({ [h().shimmerWithSubcover]: l3 }),
              withSubcover: l3,
              isActive: true,
              "aria-label": e3,
              centered: t3 || l3,
              round: t3
            });
          }
          return l2.items.map((e3) => {
            switch (e3.type) {
              case c._.MIX_CARD_ITEM:
                return (0, i.jsx)(
                  v.Vf,
                  { title: e3.data.title, weblink: e3.data.weblink, covers: e3.data.covers },
                  e3.data.id
                );
              case c._.ALBUM_ITEM:
                return (0, i.jsx)(_.aX, { album: e3.data, contentLinesCount: 3 }, e3.data.id);
              case c._.CHART_ALBUM_ITEM:
              case c._.NON_MUSIC_ALBUM_ITEM:
                return (0, i.jsx)(
                  _.aX,
                  { withChart: true, withLikesCount: true, album: e3.data, contentLinesCount: 3 },
                  e3.data.id
                );
              case c._.ARTIST_ITEM:
                return (0, i.jsx)(g.ao, { artist: e3.data, contentLinesCount: 3 }, e3.data.id);
              case c._.PLAYLIST_ITEM:
                return (0, i.jsx)(b.B6, { playlist: e3.data, contentLinesCount: 3 }, e3.data.key);
              case c._.PERSONAL_PLAYLIST_ITEM:
                return (0, i.jsx)(
                  b.B6,
                  { playlist: e3.data.playlist, customDescription: e3.data.description, contentLinesCount: 4 },
                  e3.data.playlist.key
                );
              case c._.LIKED_PLAYLIST_ITEM:
                return (0, i.jsx)(b.B6, { playlist: e3.data, contentLinesCount: 3 }, e3.data.key);
            }
          });
        }, [a2, l2.isLoading, l2.items, C2]);
        return t2 && l2.isNeededToLoad && (0, r.use)(l2.getData({ blockId: t2 })), (0, i.jsx)(p.hO, {
          scrollElement: I2,
          outerTitle: l2.title,
          children: (0, i.jsxs)("div", {
            className: h().root,
            children: [
              (0, i.jsx)(T.Y9, {
                variant: T.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: y.canBack,
                children: (0, i.jsx)(u.Heading, {
                  id: "block-entities-header",
                  variant: "h1",
                  weight: "bold",
                  size: "xl",
                  lineClamp: 1,
                  children: l2.title
                })
              }),
              (0, i.jsx)(m.N, {
                ref: L,
                className: h().scrollableContent,
                containerClassName: h().scrollableContainer,
                ...(0, n.Am)(n.e8.landing.BLOCK_ENTITY_PAGE),
                children: (0, i.jsxs)("div", {
                  className: h().container,
                  children: [
                    (0, i.jsx)("div", {
                      className: h().content,
                      "aria-labelledby": "block-entities-header",
                      tabIndex: 0,
                      children: S
                    }),
                    (0, i.jsx)(T.A, { children: (0, i.jsx)(T.wi, { className: h().footer }) })
                  ]
                })
              })
            ]
          })
        });
      });
    },
    4319: (e) => {
      e.exports = {
        root: "CollectionAlbumsPresavesEmpty_root__3w6b7",
        root_oneEmptyTab: "CollectionAlbumsPresavesEmpty_root_oneEmptyTab__UIaL3",
        root_twoEmptyTabs: "CollectionAlbumsPresavesEmpty_root_twoEmptyTabs__4Ct2l"
      };
    },
    4542: (e, t, a) => {
      "use strict";
      a.d(t, {
        bX: () => a$.BlockEntities,
        Qh: () => aG.EntitiesCarousel,
        F6: () => w,
        RO: () => S,
        hn: () => ee,
        SQ: () => I,
        Ju: () => aY,
        h9: () => V,
        Od: () => U,
        qh: () => aW.MixesGridBlock,
        zt: () => aX.S,
        tl: () => aF.t,
        nM: () => aH.Promotions,
        fv: () => M,
        g0: () => az.g,
        EA: () => aq.Skeleton,
        Rj: () => aJ.R,
        Ds: () => b,
        _9: () => l,
        dF: () => _,
        vj: () => T,
        vI: () => h
      });
      var i, s = a(35620);
      let l = (e10) => {
        var t10, a2, i2, l2;
        return !!Array.isArray(e10.tabs.data) && 1 === e10.tabs.data.length && (null == (a2 = e10.tabs.data[0]) || null == (t10 = a2.blocks) ? void 0 : t10.length) === 1 && (null == (l2 = e10.tabs.data[0]) || null == (i2 = l2.blocks[0]) ? void 0 : i2.type) === s.t.WIZARD;
      };
      var r = a(93064), o = a(60049), n = a(94376);
      let d = (e10, t10, a2, i2) => ({
        type: o._.ALBUM_ITEM,
        data: (0, n.sK)({ album: e10, artists: t10, trailer: a2, releaseDate: i2 })
      });
      var c = a(63695);
      let m = (e10, t10) => ({ type: o._.ARTIST_ITEM, data: (0, c.as)({ artist: e10, trailer: t10 }) });
      var u = a(83909);
      let _ = (e10) => {
        let { playlist: t10, likesCount: a2, trailer: i2, tracksCount: s2 } = e10;
        return {
          type: o._.LIKED_PLAYLIST_ITEM,
          data: (0, u.bk)({ playlist: t10, likesCount: a2, trailer: i2, tracksCount: s2 })
        };
      };
      var g = a(76866);
      let p = (e10) => (0, r.wg)({ type: o._.WAVE_AGENT_ITEM, data: (0, g.lb)(e10.data.wave, e10.data.agent) }), b = (e10) => {
        var t10;
        let a2 = null == (t10 = (e10 || {}).items) ? void 0 : t10.map((e11) => {
          switch (e11.type) {
            case o._.LIKED_PLAYLIST_ITEM:
              return _({ playlist: e11.data.playlist, likesCount: e11.data.likesCount, trailer: e11.data.trailer });
            case o._.ALBUM_ITEM:
              return d(e11.data.album, e11.data.artists, e11.data.trailer, e11.data.releaseDate);
            case o._.ARTIST_ITEM:
              return m(e11.data.artist, e11.data.trailer);
            case o._.WAVE_AGENT_ITEM:
              return p(e11);
          }
        });
        return (0, r.wg)({ items: a2 });
      };
      var v = a(65779);
      let A = (e10) => ({ type: e10.type, data: (0, v.SZ)({ clip: e10.data.clip, artists: e10.data.artists }) }), T = (e10) => {
        let { album: t10, artists: a2, likesCount: i2, bookmateOptionRequired: s2 } = e10;
        return {
          type: o._.NON_MUSIC_ALBUM_ITEM,
          data: (0, n.sK)({ album: t10, likesCount: i2, bookmateOptionRequired: s2, artists: a2 })
        };
      };
      var C = a(21365);
      let h = (e10) => ({ type: o._.TRACK_ITEM, data: (0, C.vU)(e10.data.track) });
      var I = (function(e10) {
        return e10.IDLE = "IDLE", e10.PENDING = "PENDING", e10.RESOLVE = "RESOLVE", e10.REJECT = "REJECT", e10.OUTDATED = "OUTDATED", e10;
      })({}), L = a(17390);
      let y = (e10) => {
        let {
          showPolicy: t10,
          isNeededToLoad: a2,
          isLoading: i2,
          isLoaded: s2,
          isRejected: l2,
          isNotEmpty: r2,
          isOutdated: o2,
          isNeededToHide: n2
        } = e10;
        if (n2) return false;
        switch (t10) {
          case L.E.SHOW_AND_LOAD:
            if (i2 || l2 || a2) return true;
            return r2;
          case L.E.LOAD_AND_SHOW:
            return s2 && r2 || !!o2;
          default:
            return true;
        }
      }, S = r.gK.model("LandingAlbumItem", { type: r.gK.literal(o._.ALBUM_ITEM), data: n.JC }), E = r.gK.model("LandingArtistItem", { type: r.gK.literal(o._.ARTIST_ITEM), data: c.PK }), N = r.gK.model("LandingLikedPlaylistItem", { type: r.gK.literal(o._.LIKED_PLAYLIST_ITEM), data: u.IP }), j = r.gK.model("LandingVibeAgentItem", { type: r.gK.literal(o._.WAVE_AGENT_ITEM), data: g.Gh }), k = r.gK.model("LandingBaseBlock", {
        loadingState: r.gK.enumeration(Object.values(I)),
        id: r.gK.string,
        isNotFound: r.gK.boolean,
        hasSentAnalyticsOnLoaded: r.gK.boolean,
        meta: r.gK.maybe(r.gK.frozen())
      }).views((e10) => ({
        get isNeededToLoad() {
          return e10.loadingState === I.IDLE;
        },
        get isLoading() {
          return e10.loadingState === I.PENDING;
        },
        get isLoaded() {
          return e10.loadingState === I.RESOLVE;
        },
        get isRejected() {
          return e10.loadingState === I.REJECT;
        },
        get isOutdated() {
          return e10.loadingState === I.OUTDATED;
        },
        get isShimmerVisible() {
          return this.isNeededToLoad || this.isLoading || this.isRejected;
        },
        get isShimmerActive() {
          return this.isLoading;
        }
      })).actions((e10) => ({
        setHasSentAnalyticsOnLoaded(t10) {
          e10.hasSentAnalyticsOnLoaded = t10;
        },
        setOutdated() {
          e10.loadingState = I.OUTDATED;
        },
        setIsNeededToLoad() {
          e10.loadingState = I.IDLE;
        }
      })), x = r.gK.model("LandingBlockFetchableMetaSource", {
        uri: r.gK.string,
        countWeb: r.gK.maybe(r.gK.number),
        count: r.gK.maybe(r.gK.number)
      }), R = r.gK.model("LandingBlockFetchableMeta", {
        title: r.gK.maybe(r.gK.string),
        description: r.gK.maybe(r.gK.string),
        viewAllActionLink: r.gK.maybeNull(r.gK.string),
        source: r.gK.maybe(x),
        showPolicy: r.gK.maybe(r.gK.string),
        coverStyle: r.gK.maybe(r.gK.string)
      }), f = r.gK.union(N, S, E, j), P = r.gK.model("EntitiesCarouselData", { items: r.gK.array(f) }), w = k.props({
        type: r.gK.union(
          r.gK.literal(s.t.NEW_PLAYLISTS),
          r.gK.literal(s.t.EDITORIAL_COMPILATION),
          r.gK.literal(s.t.RECOMMENDED_PLAYLISTS),
          r.gK.literal(s.t.META_TAG_POPULAR_PLAYLISTS),
          r.gK.literal(s.t.META_TAG_NEW_ALBUMS),
          r.gK.literal(s.t.META_TAG_PLAYLISTS),
          r.gK.literal(s.t.MICRO_GENRE_ALBUMS),
          r.gK.literal(s.t.META_TAG_ALBUMS),
          r.gK.literal(s.t.ARTIST_PLAYLISTS),
          r.gK.literal(s.t.ARTIST_ALBUMS),
          r.gK.literal(s.t.ARTIST_COMPILATIONS),
          r.gK.literal(s.t.ARTIST_STUDIO_ALBUMS),
          r.gK.literal(s.t.ARTIST_SIMILAR_ENTITIES),
          r.gK.literal(s.t.COLLECTION_SIMILAR_ENTITIES)
        ),
        data: r.gK.maybe(P),
        meta: R
      }).named("EntitiesCarousel").views((e10) => ({
        get isVisible() {
          var t10;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (t10 = e10.data) ? void 0 : t10.items.length) !== 0
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      })), K = r.gK.model("NonMusicChartAlbumData", { items: r.gK.array(n.JC) }), O = k.props({ type: r.gK.literal(s.t.CHART_ALBUMS), data: r.gK.maybe(K), meta: R }).named("NonMusicChartAlbum").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), M = r.gK.model("PromotionsDataItem", {
        featureId: r.gK.string,
        title: r.gK.string,
        subtitle: r.gK.string,
        weblink: r.gK.string,
        imageUrl: r.gK.string
      }), D = r.gK.model("PromotionsData", { items: r.gK.array(M) }), B = k.props({
        type: r.gK.union(
          r.gK.literal(s.t.PROMOTIONS),
          r.gK.literal(s.t.EDITORIAL_PROMOTIONS),
          r.gK.literal(s.t.NON_MUSIC_PROMOTIONS)
        ),
        data: r.gK.maybe(D),
        meta: R
      }).named("Promotions").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), V = r.gK.model("LandingNonMusicAlbumItem", { type: r.gK.literal(o._.NON_MUSIC_ALBUM_ITEM), data: n.JC }), U = r.gK.model("LandingPlaylistItem", { type: r.gK.literal(o._.PLAYLIST_ITEM), data: u.IP }), Y = r.gK.model("LandingTrackItem", { type: r.gK.literal(o._.TRACK_ITEM), data: C.vj });
      var G = a(74125), W = a(26433), X = a(3095);
      let F = (e10) => ({
        type: o._.PERSONAL_PLAYLIST_ITEM,
        data: {
          playlist: (0, u.bk)({ playlist: e10.data.playlist, trailer: e10.data.trailer }),
          playlistType: e10.data.playlistType,
          description: e10.data.description
        }
      }), H = (e10, t10) => ({ type: o._.PLAYLIST_ITEM, data: (0, u.bk)({ playlist: e10, trailer: t10 }) }), z = (e10) => {
        switch (e10.type) {
          case o._.MIX_CARD_ITEM:
            return (0, r.wg)({ type: o._.MIX_CARD_ITEM, data: (0, X.rc)(e10.data) });
          case o._.NON_MUSIC_ALBUM_ITEM:
            return T({
              album: e10.data.album,
              likesCount: e10.data.likesCount,
              bookmateOptionRequired: e10.data.bookmateOptionRequired
            });
          case o._.ALBUM_ITEM:
            return d(e10.data.album, e10.data.artists, e10.data.trailer);
          case o._.CHART_ALBUM_ITEM:
            let t10, a2, i2, s2;
            return t10 = e10.data.album, a2 = e10.data.chart, i2 = e10.data.likesCount, s2 = e10.data.trailer, { type: o._.CHART_ALBUM_ITEM, data: (0, n.sK)({ album: t10, chart: a2, likesCount: i2, trailer: s2 }) };
          case o._.ARTIST_ITEM:
            return m(e10.data.artist, e10.data.trailer);
          case o._.PLAYLIST_ITEM:
            return H(e10.data.playlist, e10.data.trailer);
          case o._.PERSONAL_PLAYLIST_ITEM:
            return F(e10);
          case o._.LIKED_PLAYLIST_ITEM:
            return _({ playlist: e10.data.playlist, likesCount: e10.data.likesCount, trailer: e10.data.trailer });
        }
      }, $ = r.gK.model("LandingChartAlbumItem", { type: r.gK.literal(o._.CHART_ALBUM_ITEM), data: n.JC }), q = r.gK.model("LandingMixCardItemModel", { type: r.gK.literal(o._.MIX_CARD_ITEM), data: X.bv }), J = r.gK.model("LandingPersonalPlaylistItem", {
        playlist: u.IP,
        playlistType: r.gK.string,
        description: r.gK.maybe(r.gK.string)
      }), Z = r.gK.model("LandingPersonalPlaylistItem", { type: r.gK.literal(o._.PERSONAL_PLAYLIST_ITEM), data: J }), Q = r.gK.union(S, E, U, Z, N, $, V, q), ee = r.gK.compose(
        r.gK.model("LandingBlockEntities", { title: r.gK.maybeNull(r.gK.string), items: r.gK.array(Q) }),
        W.XT
      ).views((e10) => ({
        get isLoading() {
          return e10.isNeededToLoad || e10.loadingState === G.GuX.PENDING;
        },
        get isNotFound() {
          return e10.isRejected;
        }
      })).actions((e10) => ({
        getData: (0, r.L3)(function* (t10) {
          let { blockId: a2 } = t10, { landingResource: i2, modelActionsLogger: s2 } = (0, r._$)(e10);
          if (e10.loadingState !== G.GuX.PENDING)
            try {
              e10.loadingState = G.GuX.PENDING;
              let t11 = yield i2.getBlockEntities({ blockId: a2, page: 0, pageSize: 100 });
              e10.title = t11.title, e10.items = (0, r.wg)(t11.items.map(z)), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.RESOLVE);
            } catch (t11) {
              s2.error(t11), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.REJECT);
            }
        }),
        reset() {
          e10.loadingState = G.GuX.IDLE, e10.items = (0, r.wg)([]), e10.title = null;
        }
      }));
      var et = a(14287);
      let ea = [s.t.COLLECTION_FAVOURITE_PLAYLIST], ei = (e10) => ea.includes(e10);
      var es = a(72107);
      let el = [s.t.COLLECTION_DOWNLOADED_TRACKS];
      var er = a(77217);
      !(function(e10) {
        e10.RADIO = "radio", e10.PROMOTIONS = "promotions", e10.EDITORIAL_PLAYLISTS = "editorial-playlists", e10.PLAYLIST_WITH_TRACKS = "playlist-with-tracks";
      })(i || (i = {}));
      let eo = (e10) => !!(e10 && "object" == typeof e10 && e10[0] && "owner" in e10[0].data);
      var en = a(15099), ed = a(93729), ec = a(73975);
      let em = (e10) => e10.every((e11) => Object.values(ec.M).includes(e11)), eu = (e10) => {
        var t10, a2, i2;
        let s2 = (0, c.FA)(e10.decomposed), l2 = e10.disclaimers && em(e10.disclaimers) ? e10.disclaimers : void 0;
        return (0, r.wg)({
          id: String(e10.id),
          name: null != (a2 = e10.name) ? a2 : "",
          various: e10.various,
          isAvailable: null == (i2 = e10.available) || i2,
          isComposer: e10.composer,
          coverUri: null == (t10 = e10.cover) ? void 0 : t10.uri,
          decomposed: s2,
          disclaimers: l2
        });
      };
      var e_ = a(13611);
      let eg = (e10) => {
        switch (e10.type) {
          case o._.ALBUM_ITEM:
            return d(e10.data.album, e10.data.artists, e10.data.trailer);
          case o._.PRESAVED_ALBUM_ITEM:
            return ((e11) => {
              var t10;
              let {
                album: a2,
                artists: i2,
                releaseDate: s2,
                millisecondsUntilRelease: l2,
                presaveDate: r2
              } = e11.data || {};
              return {
                type: o._.PRESAVED_ALBUM_ITEM,
                data: (0, n.lO)({
                  ...a2,
                  artists: i2,
                  releaseDate: s2,
                  millisecondsUntilRelease: l2,
                  presaveDate: r2,
                  coverUri: null == (t10 = a2.cover) ? void 0 : t10.uri
                })
              };
            })(e10);
        }
      }, ep = (e10) => (0, r.wg)({
        type: o._.MENU_ITEM,
        data: {
          title: e10.data.title,
          viewAllActionLink: e10.data.viewAllAction.weblink,
          cover: e10.data.cover ? (0, G.pX4)(e10.data.cover) : void 0
        }
      });
      var eb = a(42140);
      let ev = (e10) => "object" == typeof e10 && null !== e10 && "type" in e10 && e10.type === s.t.TABS, eA = (e10) => Object.values(s.t).includes(e10), eT = r.gK.model("ArtistPopularTracksData", { items: r.gK.array(C.vj) }), eC = k.props({ type: r.gK.literal(s.t.ARTIST_POPULAR_TRACKS), data: r.gK.maybe(eT), meta: R }).named("ArtistPopularTracks").views((e10) => ({
        get isVisible() {
          var t10;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (t10 = e10.data) ? void 0 : t10.items.length) !== 0
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      })), eh = r.gK.model("ArtistReleaseData", { album: n.JC, releaseDate: r.gK.maybe(r.gK.string) }), eI = k.props({ type: r.gK.literal(s.t.ARTIST_RELEASE), data: r.gK.maybe(eh), meta: R }).named("ArtistRelease").views((e10) => ({
        get isVisible() {
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: !!e10.data
          });
        },
        get objectsCount() {
          return +!!e10.data;
        }
      })), eL = r.gK.model("ArtistUpcomingReleaseData", { album: n.VH }), ey = k.props({ type: r.gK.literal(s.t.ARTIST_UPCOMING_RELEASE), data: r.gK.maybe(eL), meta: R }).named("ArtistUpcomingRelease").views((e10) => ({
        get isVisible() {
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: !!e10.data
          });
        },
        get objectsCount() {
          return +!!e10.data;
        }
      }));
      var eS = a(46758), eE = a(97774);
      let eN = (e10) => ({
        loadingState: I.IDLE,
        id: e10.id,
        type: e10.type,
        meta: ((e11) => (0, eS.v)(e11) ? ((e12) => {
          var t10;
          return (0, r.wg)({
            title: e12.title,
            description: e12.description,
            source: e12.source,
            viewAllActionLink: null == (t10 = e12.viewAllAction) ? void 0 : t10.weblink,
            showPolicy: e12.showPolicy,
            coverStyle: e12.coverStyle
          });
        })(e11) : ((e12) => !!(e12 && "object" == typeof e12 && "cover" in e12 && !("source" in e12)))(e11) ? ((e12) => {
          var t10;
          return (0, r.wg)({ ...e12, coverUri: null == (t10 = e12.cover) ? void 0 : t10.uri });
        })(e11) : ((e12) => !!(e12 && "object" == typeof e12 && ("message" in e12 || "title" in e12 || "expandable" in e12 || "visibleLines" in e12)))(e11) ? ((e12) => {
          var t10;
          return (0, r.wg)({
            ...(0, eE.t)(e12),
            showPolicy: e12.showPolicy,
            viewAllActionLink: null == (t10 = e12.viewAllAction) ? void 0 : t10.weblink
          });
        })(e11) : void 0)(e10.data),
        data: void 0,
        isNeededToLoad: true,
        isLoading: true,
        isLoaded: false,
        isRejected: false,
        isVisible: true,
        isNotFound: false,
        hasSentAnalyticsOnLoaded: false,
        objectsCount: 0,
        setHasSentAnalyticsOnLoaded: () => {
        }
      }), ej = r.gK.model("ArtistPickData", { playlist: e_.$o, artists: r.gK.array(c.PK) }), ek = k.props({ type: r.gK.literal(s.t.ARTIST_PICK), data: r.gK.maybe(ej), meta: R }).named("ArtistPick").views((e10) => ({
        get isVisible() {
          if (e10.isRejected || e10.isLoaded && !e10.data) return false;
          return true;
        },
        get objectsCount() {
          return e10.data && 1;
        }
      })), ex = r.gK.model("FamiliarYouData", {
        vibeTrackCount: r.gK.optional(r.gK.number, 0),
        collectionTrackCount: r.gK.optional(r.gK.number, 0),
        collectionAlbumCount: r.gK.optional(r.gK.number, 0)
      }).views((e10) => {
        let t10 = {
          get hasTracks() {
            return e10.collectionTrackCount > 0 || e10.vibeTrackCount > 0;
          },
          get hasFamiliarInfo() {
            return t10.hasTracks || e10.collectionAlbumCount > 0;
          },
          get tracksCount() {
            return e10.collectionTrackCount + e10.vibeTrackCount;
          },
          get hasCollectionEntities() {
            return e10.collectionTrackCount > 0 || e10.collectionAlbumCount > 0;
          },
          get hasVibeEntities() {
            return e10.vibeTrackCount > 0;
          },
          href(e11) {
            if (!e11) return "";
            if (t10.hasCollectionEntities) {
              let { href: t11 } = (0, G.uvd)("/artist/:artistId/familiar", {
                params: { artistId: e11 },
                query: { tab: G.JCK.COLLECTION }
              });
              return t11;
            }
            if (t10.hasVibeEntities) {
              let { href: t11 } = (0, G.uvd)("/artist/:artistId/familiar", {
                params: { artistId: e11 },
                query: { tab: G.JCK.VIBE }
              });
              return t11;
            }
            let { href: a2 } = (0, G.uvd)("/artist/:artistId/familiar", { params: { artistId: e11 } });
            return a2;
          }
        };
        return t10;
      }), eR = k.props({ type: r.gK.literal(s.t.FAMILIAR_YOU), data: r.gK.maybe(ex), meta: R }).named("FamiliarYou").views((e10) => ({
        get isVisible() {
          var t10;
          if (e10.isRejected || e10.isLoaded && !(null == (t10 = e10.data) ? void 0 : t10.hasFamiliarInfo)) return false;
          return true;
        },
        get objectsCount() {
          return e10.data && 1;
        }
      })), ef = (e10) => {
        let t10 = eN(e10);
        if ((0, es.Q)(t10) && ((e11) => !!(e11 && "object" == typeof e11 && "blocks" in e11))(e10.data))
          switch (t10.type) {
            case s.t.ARTIST_POPULAR_TRACKS_AND_RELEASES:
              t10.data = ((e11) => {
                var t11;
                let a2 = null == (t11 = e11.blocks) ? void 0 : t11.reduce((e12, t12) => {
                  let a3 = eN(t12);
                  return (eC.is(a3) || eI.is(a3) || ey.is(a3)) && e12.push(a3), e12;
                }, []);
                return (0, r.wg)({ blocks: a2 });
              })(e10.data);
              break;
            case s.t.FAMILIAR_YOU_AND_ARTIST_PICK:
              t10.data = ((e11) => {
                var t11;
                let a2 = null == (t11 = e11.blocks) ? void 0 : t11.reduce((e12, t12) => {
                  let a3 = eN(t12);
                  return (eR.is(a3) || ek.is(a3)) && e12.push(a3), e12;
                }, []);
                return (0, r.wg)({ blocks: a2 });
              })(e10.data);
          }
        return t10;
      }, eP = (e10) => (0, r.wg)({
        meta: { id: e10.id, title: e10.title },
        shouldReloadNotification: false,
        blocks: e10.blocks.filter((e11) => eA(e11.type)).map(ef)
      }), ew = (e10) => {
        let t10 = [], a2 = null;
        for (let i2 of e10) ev(i2) ? a2 = i2 : t10.push(i2);
        return ((e11) => {
          let { tabData: t11, upperBlocks: a3 } = e11, i2 = { loadingState: G.GuX.IDLE, isLoading: true };
          return t11 && (i2.meta = { selectedTabIndex: t11.selectedTabIndex, source: t11.source }, i2.tabs = { loadingState: G.GuX.IDLE, data: t11.tabs.map(eP) }), a3 && (i2.upperBlocks = a3.filter((e12) => eA(e12.type)).map(ef)), (0, r.wg)(i2);
        })({ tabData: null == a2 ? void 0 : a2.data, upperBlocks: t10 });
      };
      var eK = a(61715);
      let eO = (e10) => ({ uri: e10.uri, color: e10.color });
      var eM = a(7981);
      let eD = (e10) => {
        var t10;
        let { data: a2 } = e10;
        return (0, r.wg)({
          type: o._.DONATION_ITEM,
          data: (0, eM.GT)({ url: a2.tipUrl, artist: a2.artist, goal: null == (t10 = a2.goal) ? void 0 : t10.title })
        });
      };
      var eB = a(27906), eV = a(34960);
      let eU = (e10) => (0, r.wg)({
        buttonColor: null == e10 ? void 0 : e10.buttonColor,
        textColor: null == e10 ? void 0 : e10.textColor,
        bgImageUrl: null == e10 ? void 0 : e10.bgImageUrl,
        imageUrl: null == e10 ? void 0 : e10.imageUrl,
        buttonTextColor: null == e10 ? void 0 : e10.buttonTextColor
      }), eY = r.gK.model("AlbumPromoDataItem", {
        album: n.JC,
        artists: r.gK.array(c.PK),
        cover: W.$B,
        coverContentMode: r.gK.maybe(r.gK.string),
        clickUrl: r.gK.string,
        yclid: r.gK.string,
        utm: r.gK.frozen(),
        hasClicked: r.gK.optional(r.gK.boolean, false)
      }).views((e10) => {
        let t10 = {
          get reportingProperties() {
            return { ...e10.utm, yclid: e10.yclid };
          },
          get albumUrl() {
            let { href: a2 } = (0, G.uvd)(e10.album.url, { query: t10.reportingProperties });
            return a2;
          }
        };
        return t10;
      }).actions((e10) => ({
        setClicked: (0, r.L3)(function* () {
          if (!(0, r._n)(e10)) return;
          let { prefixlessResource: t10, modelActionsLogger: a2 } = (0, r._$)(e10);
          if (!e10.hasClicked)
            try {
              e10.hasClicked = true, yield t10.reportForAlbumPromo(e10.clickUrl);
            } catch (e11) {
              a2.error(e11);
            }
        })
      })), eG = r.gK.model("AlbumPromoDataReportingOptions", { url: r.gK.string, timeMs: r.gK.number }), eW = r.gK.model("AlbumPromoDataReporting", { blockRender: eG, blockImpression: eG, adImpressions: eG }), eX = r.gK.model("AlbumPromoData", { items: r.gK.array(eY), reporting: r.gK.maybe(eW) }).actions((e10) => ({
        report: (0, r.L3)(function* (t10) {
          if (!(0, r._n)(e10)) return;
          let { prefixlessResource: a2, modelActionsLogger: i2 } = (0, r._$)(e10);
          try {
            yield a2.reportForAlbumPromo(t10);
          } catch (e11) {
            i2.error(e11);
          }
        })
      })), eF = k.props({
        type: r.gK.union(r.gK.literal(s.t.ALBUM_PROMO), r.gK.literal(s.t.SIMPLE_ALBUM_PROMO)),
        data: r.gK.maybe(eX),
        meta: R
      }).named("AlbumPromo").views((e10) => ({
        get isVisible() {
          var t10;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: !!((null == (t10 = e10.data) ? void 0 : t10.items) && e10.data.items.length > 0),
            isOutdated: e10.isOutdated
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      })), eH = r.gK.model("ArtistConcertsData", { items: r.gK.array(er.aR) }), ez = k.props({ type: r.gK.union(r.gK.literal(s.t.ARTIST_CONCERTS)), data: r.gK.maybe(eH), meta: R }).named("ArtistConcerts").views((e10) => ({
        get isVisible() {
          var t10;
          let { experiments: a2 } = (0, r.Zn)(e10);
          if (a2.checkExperiment(G.zal.disableAllConcerts, "on")) return false;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (t10 = e10.data) ? void 0 : t10.items.length) !== 0
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      })), e$ = r.gK.model("ArtistPopularTracksAndReleasesData", { blocks: r.gK.array(r.gK.union(eC, eI, ey)) }).views((e10) => ({
        get popularTracks() {
          return e10.blocks.find((e11) => eC.is(e11));
        },
        get upcomingRelese() {
          return e10.blocks.find((e11) => ey.is(e11));
        },
        get release() {
          return e10.blocks.find((e11) => eI.is(e11));
        }
      })), eq = k.props({ type: r.gK.literal(s.t.ARTIST_POPULAR_TRACKS_AND_RELEASES), data: r.gK.maybe(e$) }).named("ArtistPopularTracksAndReleases").views((e10) => ({
        get isVisible() {
          return true;
        },
        get objectsCount() {
          var t10, a2;
          return null != (a2 = null == (t10 = e10.data) ? void 0 : t10.blocks.length) ? a2 : 0;
        }
      })), eJ = r.gK.model("ChartTracksItem", { type: r.gK.literal(o._.TRACK_ITEM), data: C.vj }), eZ = r.gK.model("ChartTracksData", { items: r.gK.array(eJ), playlist: e_.$o }), eQ = k.props({ type: r.gK.literal(s.t.CHART_TRACKS), data: r.gK.maybe(eZ), meta: R }).named("ChartTracks").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          let t10 = null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
          return t10 < 8 ? t10 : 8;
        }
      })), e0 = r.gK.model("LandingClipItem", {
        type: r.gK.union(r.gK.literal(o._.CLIP), r.gK.literal(o._.CLIP_ITEM)),
        data: v.kv
      }), e1 = r.gK.model("ClipsData", { items: r.gK.array(e0), canShowEmptyBlock: r.gK.optional(r.gK.boolean, false) }).views((e10) => ({
        get isEmptyBlock() {
          return e10.canShowEmptyBlock && 0 === e10.items.length;
        }
      })), e3 = k.props({
        type: r.gK.union(
          r.gK.literal(s.t.CLIPS),
          r.gK.literal(s.t.ARTIST_CLIPS),
          r.gK.literal(s.t.COLLECTION_CLIPS)
        ),
        data: r.gK.maybe(e1),
        meta: R
      }).named("Clips").views((e10) => ({
        get isVisible() {
          var t10, a2;
          let { settings: i2 } = (0, r.Zn)(e10);
          if (null == (t10 = e10.data) ? void 0 : t10.canShowEmptyBlock) return true;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (a2 = e10.data) ? void 0 : a2.items.length) !== 0,
            isNeededToHide: i2.isMobile
          });
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), e4 = r.gK.model("CollectionAlbumsData", {
        items: r.gK.array(n.JC),
        canShowEmptyBlock: r.gK.optional(r.gK.boolean, false)
      }).views((e10) => ({
        get isEmptyBlock() {
          return e10.canShowEmptyBlock && 0 === e10.items.length;
        }
      })), e2 = k.props({ type: r.gK.literal(s.t.COLLECTION_ALBUMS), data: r.gK.maybe(e4), meta: R }).named("CollectionAlbums").views((e10) => ({
        get isVisible() {
          var t10, a2, i2;
          if ((null == (t10 = e10.data) ? void 0 : t10.canShowEmptyBlock) || e10.isLoading || e10.isRejected || e10.isNeededToLoad)
            return true;
          return (null == (i2 = e10.data) || null == (a2 = i2.items) ? void 0 : a2.length) !== 0;
        },
        get objectsCount() {
          var s2, l2;
          return null != (l2 = null == (s2 = e10.data) ? void 0 : s2.items.length) ? l2 : 0;
        }
      }));
      var e6 = a(75468);
      let e8 = r.gK.model("LandingUpcomingAlbumItem", { type: r.gK.literal(o._.PRESAVED_ALBUM_ITEM), data: n.VH }), e5 = r.gK.union(S, e8), e7 = r.gK.model("CollectionAlbumsPresavesTab", {
        id: r.gK.string,
        title: r.gK.string,
        type: r.gK.enumeration(Object.values(e6.n)),
        items: r.gK.array(e5),
        canShowEmptyBlock: r.gK.optional(r.gK.boolean, false)
      }).views((e10) => ({
        get isEmptyTab() {
          return !!(e10.canShowEmptyBlock && 0 === e10.items.length);
        }
      })), e9 = r.gK.model("CollectionAlbumsPresavesTabs", { tabs: r.gK.array(e7) }).views((e10) => ({
        get isFirstTabEmpty() {
          var t10;
          return (null == (t10 = e10.tabs[0]) ? void 0 : t10.items.length) === 0;
        },
        get isSecondTabEmpty() {
          var a2;
          return (null == (a2 = e10.tabs[1]) ? void 0 : a2.items.length) === 0;
        },
        get areBothTabsEmpty() {
          return this.isFirstTabEmpty && this.isSecondTabEmpty;
        },
        get activeIndexTab() {
          if (this.isFirstTabEmpty && !this.isSecondTabEmpty) return 1;
          return 0;
        }
      })), te = k.props({ type: r.gK.literal(s.t.COLLECTION_ALBUMS_PRESAVES), data: r.gK.maybe(e9), meta: R }).named("CollectionAlbumsPresaves").views((e10) => ({
        get isVisible() {
          return true;
        },
        get objectsCount() {
          if (e10.data) return e10.data.tabs.reduce((e11, t10) => e11 + t10.items.length, 0);
          return 0;
        }
      })), tt = r.gK.model("LandingMenuItem", {
        type: r.gK.literal(o._.MENU_ITEM),
        data: r.gK.model({
          title: r.gK.string,
          viewAllActionLink: r.gK.maybe(r.gK.maybeNull(r.gK.string)),
          cover: r.gK.maybe(W.$B)
        })
      }).views((e10) => ({
        get key() {
          return "".concat(e10.data.title, "_").concat(e10.data.viewAllActionLink);
        }
      })), ta = r.gK.union(tt, j), ti = r.gK.model("CollectionArtistsAndTopWithItemsArtist", { artist: c.PK, items: r.gK.array(ta) }), ts = r.gK.model("CollectionArtistsAndTopWithItemsData", { artists: r.gK.array(ti) }), tl = k.props({ type: r.gK.literal(s.t.COLLECTION_ARTISTS_AND_TOP_WITH_ITEMS), data: r.gK.maybe(ts), meta: R }).named("CollectionArtistsAndTopWithItems").views((e10) => ({
        get isVisible() {
          var t10;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: !!(null == (t10 = e10.data) ? void 0 : t10.artists.length)
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.artists.length) ? i2 : 0;
        }
      })), tr = r.gK.model("CollectionArtistData", {
        items: r.gK.array(c.PK),
        canShowEmptyBlock: r.gK.optional(r.gK.boolean, false)
      }).views((e10) => ({
        get isEmptyBlock() {
          return e10.canShowEmptyBlock && 0 === e10.items.length;
        }
      })), to = k.props({
        type: r.gK.union(
          r.gK.literal(s.t.COLLECTION_ARTISTS),
          r.gK.literal(s.t.COLLECTION_ARTISTS_AND_TOP),
          r.gK.literal(s.t.PERSONAL_ARTISTS),
          r.gK.literal(s.t.NEW_STARS_ARTISTS),
          r.gK.literal(s.t.EDITORIAL_ARTISTS),
          r.gK.literal(s.t.META_TAG_POPULAR_ARTISTS),
          r.gK.literal(s.t.MICRO_GENRE_TOP_ARTISTS),
          r.gK.literal(s.t.MICRO_GENRE_ARTISTS),
          r.gK.literal(s.t.META_TAG_ARTISTS),
          r.gK.literal(s.t.SIMILAR_ARTISTS)
        ),
        data: r.gK.maybe(tr),
        meta: R
      }).named("CollectionArtist").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (null == (t10 = e10.data) ? void 0 : t10.canShowEmptyBlock) return true;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (a2 = e10.data) ? void 0 : a2.items.length) !== 0
          });
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), tn = r.gK.model("CollectionPlaylistsData", { items: r.gK.array(u.IP) }), td = k.props({ type: r.gK.literal(s.t.COLLECTION_PLAYLISTS_CREATED), data: r.gK.maybe(tn), meta: R }).named("CollectionCreatedPlaylists").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      }));
      var tc = a(5693);
      let tm = r.gK.model("CollectionDownloadedTracksData", { items: r.gK.array(C.vj), rawTracks: r.gK.frozen() }).views((e10) => ({
        get entitiesData() {
          return e10.rawTracks.map((e11) => ({ type: tc.R.DownloadedMusic, meta: e11 }));
        }
      })), tu = k.props({ type: r.gK.literal(s.t.COLLECTION_DOWNLOADED_TRACKS), data: r.gK.maybe(tm), meta: R }).named("CollectionDownloadedTracks").views((e10) => ({
        get isVisible() {
          var t10;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (t10 = e10.data) ? void 0 : t10.items.length) !== 0
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      })), t_ = r.gK.union(N, V, Y), tg = r.gK.model("CollectionKidsData", { items: r.gK.array(t_) }), tp = k.props({ type: r.gK.literal(s.t.COLLECTION_KIDS), data: r.gK.maybe(tg), meta: R }).named("CollectionKids").views((e10) => ({
        get isVisible() {
          var t10;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (t10 = e10.data) ? void 0 : t10.items.length) !== 0
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      })), tb = r.gK.model("CollectionLikedPlaylistsData", { items: r.gK.array(u.IP) }), tv = k.props({ type: r.gK.literal(s.t.COLLECTION_PLAYLISTS_LIKED), data: r.gK.maybe(tb), meta: R }).named("CollectionLikedPlaylists").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      }));
      var tA = a(11090);
      let tT = r.gK.model("CollectionPlaylistsTab", {
        id: r.gK.string,
        title: r.gK.string,
        type: r.gK.enumeration(Object.values(tA.l)),
        items: r.gK.array(u.IP),
        canShowEmptyBlock: r.gK.optional(r.gK.boolean, false)
      }).views((e10) => ({
        get isEmptyTab() {
          return !!(e10.canShowEmptyBlock && 0 === e10.items.length);
        }
      })), tC = r.gK.model("CollectionPlaylistsTabs", { tabs: r.gK.array(tT) }).views((e10) => ({
        get isFirstTabEmpty() {
          var t10;
          return (null == (t10 = e10.tabs[0]) ? void 0 : t10.items.length) === 0;
        },
        get isSecondTabEmpty() {
          var a2;
          return (null == (a2 = e10.tabs[1]) ? void 0 : a2.items.length) === 0;
        },
        get areBothTabsEmpty() {
          return this.isFirstTabEmpty && this.isSecondTabEmpty;
        },
        get activeIndexTab() {
          if (this.isFirstTabEmpty && !this.isSecondTabEmpty) return 1;
          return 0;
        }
      })), th = k.props({ type: r.gK.literal(s.t.COLLECTION_PLAYLISTS_LIKED_AND_CREATED), data: r.gK.maybe(tC), meta: R }).named("CollectionPlaylists").views((e10) => ({
        get isVisible() {
          return true;
        },
        get objectsCount() {
          if (e10.data) return e10.data.tabs.reduce((e11, t10) => e11 + t10.items.length, 0);
          return 0;
        }
      }));
      var tI = a(55616);
      let tL = r.gK.model("CollectionTopArtistsData", { items: r.gK.array(tI.GV) }), ty = k.props({ type: r.gK.literal(s.t.COLLECTION_TOP_ARTISTS), data: r.gK.maybe(tL), meta: R }).named("CollectionTopArtists").views((e10) => ({
        get isVisible() {
          var t10;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (t10 = e10.data) ? void 0 : t10.items.length) !== 0
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      })), tS = r.gK.model("CollectionVibeAgentDataModel", { vibe: g.Gh }), tE = k.props({ type: r.gK.literal(s.t.COLLECTION_WAVE_AGENT), data: r.gK.maybe(tS), meta: R }).named("CollectionVibeAgent").views((e10) => ({
        get isVisible() {
          var t10;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return null == (t10 = e10.data) ? void 0 : t10.vibe;
        },
        get objectsCount() {
          var a2;
          return +(null != (a2 = e10.data) && !!a2.vibe);
        }
      })), tN = k.props({ type: r.gK.literal(s.t.CONCERT_PLACE), data: r.gK.maybe(eK.fc), meta: R }).named("ConcertPlace").views((e10) => ({
        get isVisible() {
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: void 0 !== e10.data
          });
        },
        get objectsCount() {
          return +(null !== e10.data);
        }
      })), tj = r.gK.model("ConcertsData", { items: r.gK.array(er.aR) }), tk = k.props({
        type: r.gK.union(
          r.gK.literal(s.t.CONCERTS_TOP),
          r.gK.literal(s.t.CONCERTS_PERSONAL),
          r.gK.literal(s.t.EDITORIAL_CONCERTS),
          r.gK.literal(s.t.VIEWED_CONCERTS)
        ),
        data: r.gK.maybe(tj),
        meta: R
      }).named("Concerts").views((e10) => ({
        get isVisible() {
          var t10;
          let { experiments: a2 } = (0, r.Zn)(e10);
          if (a2.checkExperiment(G.zal.disableAllConcerts, "on")) return false;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (t10 = e10.data) ? void 0 : t10.items.length) !== 0
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      }));
      var tx = a(14032), tR = a(46423);
      let tf = r.gK.model("ContinueListenTrackData", {
        album: r.gK.maybe(tR.GI),
        playlist: r.gK.maybe(e_.$o),
        track: C.vj,
        trackLoadingState: r.gK.optional(r.gK.enumeration(Object.values(G.GuX)), G.GuX.IDLE),
        playlistLoadingState: r.gK.optional(r.gK.enumeration(Object.values(G.GuX)), G.GuX.IDLE),
        albumDuration: r.gK.maybe(r.gK.number),
        albumDurationLeft: r.gK.maybe(r.gK.number)
      }).views((e10) => ({
        get isNeededToLoad() {
          return e10.trackLoadingState === G.GuX.IDLE;
        },
        get isLoading() {
          return e10.trackLoadingState === G.GuX.PENDING || e10.playlistLoadingState === G.GuX.PENDING;
        },
        get isRejected() {
          return e10.trackLoadingState === G.GuX.REJECT || e10.playlistLoadingState === G.GuX.REJECT;
        }
      })).actions((e10) => ({
        getTrackMeta: (0, r.L3)(function* () {
          let { tracksResource: t10, modelActionsLogger: a2 } = (0, r._$)(e10), { continueListen: i2 } = (0, r.Zn)(e10);
          if (i2.track && "number" == typeof i2.track.durationMs) {
            e10.trackLoadingState = G.GuX.RESOLVE;
            return;
          }
          e10.trackLoadingState = G.GuX.PENDING;
          try {
            var s2;
            let a3 = (0, tx.V)(e10.track.id, null == (s2 = e10.album) ? void 0 : s2.id), [i3] = yield t10.getTracksMeta({ trackIds: [a3], withProgress: true });
            if (e10.trackLoadingState = G.GuX.RESOLVE, i3) return (0, C.vU)(i3);
          } catch (t11) {
            a2.error(t11), e10.trackLoadingState = G.GuX.REJECT;
          }
        }),
        getPlaylistMeta: (0, r.L3)(function* () {
          let { usersResource: t10, modelActionsLogger: a2 } = (0, r._$)(e10), { continueListen: i2 } = (0, r.Zn)(e10);
          if (i2.track && "number" == typeof i2.trackIndex || !e10.playlist) {
            e10.playlistLoadingState = G.GuX.RESOLVE;
            return;
          }
          e10.playlistLoadingState = G.GuX.PENDING;
          try {
            let { tracks: a3 } = yield t10.getPlaylistWithTracksIds({
              userId: String(e10.playlist.uid),
              playlistKind: e10.playlist.kind,
              resumeStream: false
            }), i3 = a3.findIndex((t11) => String(t11.id) === e10.track.id);
            if (e10.playlistLoadingState = G.GuX.RESOLVE, e10.track.durationMs && -1 !== i3) return i3;
          } catch (t11) {
            a2.error(t11), e10.playlistLoadingState = G.GuX.REJECT;
          }
        })
      })), tP = r.gK.model("ContinueListenTrack", { type: r.gK.string, data: tf }), tw = r.gK.model("ContinueListenBaseItem", { uri: r.gK.string, color: r.gK.maybe(r.gK.string) }), tK = r.gK.model("ContinueListenBaseItem", {
        title: r.gK.string,
        covers: r.gK.array(tw),
        bookCount: r.gK.maybe(r.gK.number),
        podcastCount: r.gK.maybe(r.gK.number),
        trackCount: r.gK.maybe(r.gK.number)
      }), tO = r.gK.model("ContinueListenData", { lastPlayed: r.gK.maybe(tP), bookshelf: tK, newEpisodes: tK }), tM = k.props({ type: r.gK.literal(s.t.CONTINUE_LISTEN), data: r.gK.maybe(tO), meta: R }).named("ContinueListen").views((e10) => ({
        get isVisible() {
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: !!e10.data
          });
        },
        get objectsCount() {
          return Object.keys(e10.data || {}).length;
        }
      })), tD = a(985).kv.named("LandingBlockOverviewMeta").props({ showPolicy: r.gK.maybe(r.gK.string), viewAllActionLink: r.gK.maybeNull(r.gK.string) }), tB = k.props({ type: r.gK.literal(s.t.DISLIKES), data: r.gK.undefined, meta: tD }).named("Dislikes").views(() => ({
        get isVisible() {
          return true;
        },
        get objectsCount() {
          return 0;
        }
      })), tV = r.gK.model("LandingDonationItem", { type: r.gK.literal(o._.DONATION_ITEM), data: eM.eG }), tU = r.gK.model("DonationsData", { items: r.gK.array(tV) }), tY = k.props({ type: r.gK.literal(s.t.DONATIONS), data: r.gK.maybe(tU), meta: R }).named("Donations").views((e10) => ({
        get isVisible() {
          var t10;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (t10 = e10.data) ? void 0 : t10.items.length) !== 0
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      })), tG = r.gK.model("EditorialVibesDataModel", { items: r.gK.array(g.Gh) }), tW = k.props({
        type: r.gK.union(
          r.gK.literal(s.t.EDITORIAL_WAVES),
          r.gK.literal(s.t.META_TAG_WAVE),
          r.gK.literal(s.t.MICRO_GENRE_WAVE),
          r.gK.literal(s.t.MICRO_GENRE_SIMILAR_WAVE),
          r.gK.literal(s.t.META_TAG_SIMILAR_WAVE),
          r.gK.literal(s.t.EDITORIAL_WAVES_AGENT),
          r.gK.literal(s.t.META_TAG_WAVE_AGENT),
          r.gK.literal(s.t.MICRO_GENRE_WAVE_AGENT),
          r.gK.literal(s.t.MICRO_GENRE_SIMILAR_WAVE_AGENT),
          r.gK.literal(s.t.META_TAG_SIMILAR_WAVE_AGENT)
        ),
        data: r.gK.maybe(tG),
        meta: R
      }).named("EditorialVibes").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), tX = r.gK.model("FamiliarYouAndArtistPickData", { blocks: r.gK.array(r.gK.union(eR, ek)) }).views((e10) => ({
        get familiarYou() {
          return e10.blocks.find((e11) => eR.is(e11));
        },
        get artistPick() {
          return e10.blocks.find((e11) => ek.is(e11));
        }
      })), tF = k.props({ type: r.gK.literal(s.t.FAMILIAR_YOU_AND_ARTIST_PICK), data: r.gK.maybe(tX) }).named("FamiliarYouAndArtistPick").views((e10) => ({
        get isVisible() {
          var t10, a2, i2, s2, l2, r2;
          if ((null == (t10 = e10.data) ? void 0 : t10.familiarYou) || (null == (a2 = e10.data) ? void 0 : a2.artistPick))
            return !!((null == (s2 = e10.data) || null == (i2 = s2.familiarYou) ? void 0 : i2.isVisible) || (null == (r2 = e10.data) || null == (l2 = r2.artistPick) ? void 0 : l2.isVisible));
          return false;
        },
        get objectsCount() {
          var o2, n2;
          return null != (n2 = null == (o2 = e10.data) ? void 0 : o2.blocks.length) ? n2 : 0;
        }
      })), tH = r.gK.model("InStyleDataItemTab", { id: r.gK.number, title: r.gK.string, covers: r.gK.array(r.gK.string) }), tz = r.gK.model("InStyleDataItem", { tab: tH, data: r.gK.array(n.JC) }), t$ = r.gK.model("InStyleData", { items: r.gK.array(tz) }), tq = k.props({ type: r.gK.literal(s.t.IN_STYLE), data: r.gK.maybe(t$), meta: R }).named("InStyle").views((e10) => ({
        get isVisible() {
          var t10, a2, i2;
          let s2 = (null == (t10 = e10.data) ? void 0 : t10.items.length) === 0, l2 = null == (i2 = e10.data) || null == (a2 = i2.items) ? void 0 : a2.every((e11) => !(null == e11 ? void 0 : e11.data));
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: !s2 || !l2
          });
        },
        get objectsCount() {
          var s2, l2;
          return null != (l2 = null == (s2 = e10.data) ? void 0 : s2.items.length) ? l2 : 0;
        }
      })), tJ = r.gK.model("ItemListData", { items: r.gK.array(tt) }), tZ = k.props({ type: r.gK.literal(s.t.ITEM_LIST), data: r.gK.maybe(tJ), meta: R }).named("ItemList").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), tQ = r.gK.model("LikesData", {
        title: r.gK.string,
        cover: W.$B,
        playlistUuid: r.gK.maybe(r.gK.string),
        trackCovers: r.gK.array(W.$B),
        count: r.gK.number
      }).views((e10) => ({
        get id() {
          return e10.playlistUuid;
        },
        get url() {
          let { href: t10 } = (0, G.uvd)("/playlists/:playlistUuid", { params: { playlistUuid: e10.playlistUuid } });
          return t10;
        }
      })), t0 = r.gK.model("HistoryData", { title: r.gK.string, trackCovers: r.gK.array(W.$B), artists: r.gK.array(r.gK.string) }).views(() => ({
        get id() {
          return "music-history";
        },
        get url() {
          let { href: e10 } = (0, G.uvd)("/music-history");
          return e10;
        }
      })), t1 = r.gK.model("LikesAndHistoryData", { favorites: tQ, history: t0 }), t3 = k.props({ type: r.gK.literal(s.t.LIKES_AND_HISTORY), data: r.gK.maybe(t1), meta: R }).named("LikesAndCount").views((e10) => ({
        get isVisible() {
          return !(e10.isLoading || e10.isRejected || e10.isNeededToLoad);
        },
        get objectsCount() {
          return 2;
        }
      })), t4 = r.gK.model("MixesGridData", { items: r.gK.array(X.bv) }), t2 = k.props({
        type: r.gK.union(r.gK.literal(s.t.MIXES_GRID), r.gK.literal(s.t.MIXES_MUSIC)),
        data: r.gK.maybe(t4),
        meta: R
      }).named("MixesGrid").views((e10) => ({
        get isVisible() {
          var t10, a2;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNotEmpty: (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0,
            isLoaded: e10.isLoaded,
            isLoading: e10.isLoading,
            isRejected: e10.isRejected,
            isNeededToLoad: e10.isNeededToLoad
          });
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), t6 = r.gK.model("MixesData", { items: r.gK.array(eB.f) }), t8 = k.props({ type: r.gK.literal(s.t.MIXES), data: r.gK.maybe(t6), meta: R }).named("Mixes").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), t5 = r.gK.model("NeuromusicData", { items: r.gK.array(eV.R6) }), t7 = k.props({ type: r.gK.literal(s.t.NEUROMUSIC), data: r.gK.maybe(t5), meta: R }).named("Neuromusic").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), t9 = [
        "avatars.mds.yandex.net/get-music-misc/30221/img.68678806f4c3467d82bab43b/%%",
        "avatars.mds.yandex.net/get-music-misc/34161/img.68678811e40cd01bff989e50/%%",
        "avatars.mds.yandex.net/get-music-misc/30221/img.6867881aea3b324d5df9692f/%%"
      ], ae = [
        "avatars.mds.yandex.net/get-music-misc/2419084/img.686688add03ee35062c02822/%%",
        "avatars.mds.yandex.net/get-music-misc/28592/img.6867878964ece217d515ffda/%%",
        "avatars.mds.yandex.net/get-music-misc/30221/img.686787926dccf85a8a06c771/%%"
      ], at = r.gK.model("NewReleasesDataItem", {
        album: n.JC,
        releaseDate: r.gK.maybe(r.gK.string),
        coverUri: r.gK.maybe(r.gK.string),
        coverColor: r.gK.maybe(r.gK.string)
      }).views((e10) => ({
        coverUriWithPlaceholder: (t10) => (function(e11) {
          let { coverUri: t11, artistId: a2, theme: i2 } = e11;
          if (!(null == t11 ? void 0 : t11.includes("2419084/img.6568f242071da73cabc5846c"))) return t11;
          let s2 = (Number(a2) || 0) % 3;
          return i2 === G.Sxu.Light ? t9[s2] : ae[s2];
        })({ coverUri: e10.coverUri, artistId: e10.album.artistId, theme: t10 })
      })), aa = r.gK.model("NewReleasesData", { items: r.gK.array(at) }), ai = k.props({
        type: r.gK.union(r.gK.literal(s.t.NEW_RELEASES), r.gK.literal(s.t.EDITORIAL_NEW_RELEASES)),
        data: r.gK.maybe(aa),
        meta: R
      }).named("NewReleases").views((e10) => ({
        get isVisible() {
          var t10;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (t10 = e10.data) ? void 0 : t10.items.length) !== 0
          });
        },
        get objectsCount() {
          var a2, i2;
          return null != (i2 = null == (a2 = e10.data) ? void 0 : a2.items.length) ? i2 : 0;
        }
      })), as = r.gK.model("NonMusicEditorialCompilationData", { items: r.gK.array(r.gK.union(V, N)) }), al = k.props({ type: r.gK.literal(s.t.NON_MUSIC_EDITORIAL_COMPILATION), data: r.gK.maybe(as), meta: R }).named("NonMusicEditorialCompilation").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), ar = k.props({ type: r.gK.literal(s.t.OVERVIEW), data: r.gK.undefined, meta: tD }).named("Overview").views((e10) => ({
        get isVisible() {
          return !!e10.meta.message;
        },
        get objectsCount() {
          return 1;
        }
      })), ao = r.gK.model("PersonalPlaylistsData", { items: r.gK.array(Z) }), an = k.props({
        type: r.gK.union(r.gK.literal(s.t.PERSONAL_PLAYLISTS), r.gK.literal(s.t.REWIND_PLAYLISTS)),
        data: r.gK.maybe(ao),
        meta: R
      }).named("PersonalPlaylists").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      }));
      var ad = (function(e10) {
        return e10.ALL = "all", e10;
      })({});
      let ac = (e10) => {
        var t10;
        let a2 = (null == (t10 = e10.tracks) ? void 0 : t10.length) ? e10.tracks.map((e11) => ({ id: e11 })) : [];
        return { id: e10.id, name: e10.name, tracks: (0, r.wg)(a2) };
      }, am = r.gK.model("PlaylistFiltersTrack", { id: r.gK.union(r.gK.string, r.gK.number) }), au = r.gK.model("PlaylistFiltersItem", { id: r.gK.string, name: r.gK.string, tracks: r.gK.array(am) }), a_ = r.gK.model("LandingBlockClientMeta", {
        title: r.gK.maybe(r.gK.string),
        description: r.gK.maybe(r.gK.string),
        viewAllActionLink: r.gK.maybeNull(r.gK.string),
        showPolicy: r.gK.maybe(r.gK.string),
        coverUri: r.gK.maybe(r.gK.string)
      });
      var ag = a(92437);
      let ap = r.gK.model("PlaylistWithTracksDataBase", {
        totalItemsCount: r.gK.maybe(r.gK.number),
        items: r.gK.array(C.vj),
        playlist: e_.$o,
        coverUri: r.gK.maybe(r.gK.string),
        canShowEmptyBlock: r.gK.maybe(r.gK.boolean),
        withRewindTrailerButton: r.gK.maybe(r.gK.boolean)
      }).views((e10) => ({
        getCoverUri(t10) {
          switch (t10) {
            case ag.z.DEFAULT:
              return e10.playlist.coverUri;
            case ag.z.CUSTOM:
              return e10.coverUri;
            default:
              var a2;
              return null != (a2 = e10.coverUri) ? a2 : e10.playlist.coverUri;
          }
        }
      })), ab = r.gK.compose(
        r.gK.model("PlaylistWithTracksAndFiltersFilters", {
          items: r.gK.maybeNull(r.gK.array(au)),
          activeFilter: r.gK.maybe(r.gK.string),
          shouldSendEventOnTabOpened: r.gK.optional(r.gK.boolean, true),
          shouldSendEventOnTabLoaded: r.gK.optional(r.gK.boolean, true)
        }),
        W.XT,
        W.pl
      ).views((e10) => ({
        get isShimmerVisible() {
          return e10.isRejected || e10.isLoading;
        },
        get activeFilterIndex() {
          var t10;
          let a2 = null == (t10 = e10.items) ? void 0 : t10.findIndex((t11) => t11.id === e10.activeFilter);
          return void 0 !== a2 && a2 > -1 ? a2 : 0;
        },
        get shouldSendEventOnTabOpenedNow() {
          var a2;
          return e10.shouldSendEventOnTabOpened && !!(null == (a2 = e10.items) ? void 0 : a2.length);
        },
        get shouldSendEventOnTabLoadedNow() {
          var i2;
          return e10.shouldSendEventOnTabLoaded && !!(null == (i2 = e10.items) ? void 0 : i2.length);
        }
      })).actions((e10) => ({
        setActiveFilter(t10) {
          t10 !== ad.ALL ? e10.activeFilter = t10 : e10.activeFilter = void 0;
        },
        setShouldSendEventOnTabOpened(t10) {
          e10.shouldSendEventOnTabOpened = t10;
        },
        setShouldSendEventOnTabLoaded(t10) {
          e10.shouldSendEventOnTabLoaded = t10;
        }
      })), av = r.gK.compose(
        ap.props({
          likedTrackIds: r.gK.optional(r.gK.array(r.gK.string), () => []),
          trackDetailsMap: r.gK.optional(r.gK.map(C.vj), {}),
          tracksLoading: r.gK.optional(W.XT, () => ({ loadingState: G.GuX.IDLE })),
          playlistLoading: r.gK.optional(W.XT, () => ({ loadingState: G.GuX.IDLE })),
          filters: r.gK.optional(ab, () => ({ loadingState: G.GuX.IDLE }))
        }),
        W.pl
      ).named("PlaylistWithTracksAndFiltersData").views((e10) => ({
        get shouldShowEmptyPlaylist() {
          return 0 === e10.items.length && !e10.tracksLoading.isLoading && !!e10.canShowEmptyBlock;
        },
        get shouldLoadTracksMeta() {
          return e10.likedTrackIds.length > 0 && e10.tracksLoading.isNeededToLoad;
        },
        get shouldLoadFilters() {
          return e10.likedTrackIds.length > 0 && e10.filters.isNeededToLoad;
        },
        get visibleTrackIds() {
          if (e10.filters.activeFilter) {
            var t10;
            let a2 = null == (t10 = e10.filters.items) ? void 0 : t10.find((t11) => t11.id === e10.filters.activeFilter);
            if (a2) return a2.tracks.slice(0, 8).map((e11) => String(e11.id));
          }
          return e10.likedTrackIds.slice(0, 8);
        },
        get isLoading() {
          return e10.playlistLoading.isLoading || e10.tracksLoading.isLoading;
        },
        get isRejected() {
          return e10.playlistLoading.isRejected || e10.tracksLoading.isRejected;
        }
      })).actions((e10) => {
        let t10 = {
          getPlaylist: (0, r.L3)(function* () {
            let { modelActionsLogger: a2, usersResource: i2, playlistResource: s2 } = (0, r._$)(e10), { user: l2 } = (0, r.Zn)(e10), o2 = l2.account.data.uid;
            if ((0, r._n)(e10) && o2) {
              e10.playlistLoading.loadingState = G.GuX.PENDING;
              try {
                let a3 = yield i2.getPlaylistWithTracksIds({
                  userId: String(o2),
                  playlistKind: e_.ji.LIKE,
                  resumeStream: false,
                  trackMetaType: "music"
                }), l3 = yield s2.getPlaylist({ playlistUuid: a3.playlistUuid, resumeStream: false, richTracks: false });
                e10.likedTrackIds = (0, r.wg)(l3.tracks.map((e11) => String(e11.id))), e10.totalItemsCount = e10.likedTrackIds.length, 0 === e10.totalItemsCount && (e10.canShowEmptyBlock = true), e10.playlist = (0, e_.jX)(l3), e10.playlistLoading.loadingState = G.GuX.RESOLVE, yield Promise.allSettled([t10.getTracksMeta(), t10.getFilters()]);
              } catch (t11) {
                a2.error(t11), e10.playlistLoading.loadingState = G.GuX.REJECT;
              }
            }
          }),
          updateItemsFromCache() {
            let a2 = [];
            e10.visibleTrackIds.forEach((t11) => {
              let i2 = e10.trackDetailsMap.get(t11);
              i2 && a2.push(i2);
            }), t10.setItems(a2);
          },
          getTracksMeta: (0, r.L3)(function* () {
            if (!(0, r._n)(e10)) return;
            let { tracksResource: a2, modelActionsLogger: i2 } = (0, r._$)(e10);
            e10.tracksLoading.loadingState = G.GuX.PENDING;
            let s2 = e10.visibleTrackIds.filter((t11) => !e10.trackDetailsMap.has(t11));
            if (!s2.length) {
              t10.updateItemsFromCache(), e10.tracksLoading.loadingState = G.GuX.RESOLVE;
              return;
            }
            try {
              (yield a2.getTracksMeta({ trackIds: s2 })).forEach((t11) => {
                let a3 = (0, C.vU)(t11);
                e10.trackDetailsMap.set(String(t11.id), a3);
              }), t10.updateItemsFromCache(), e10.tracksLoading.loadingState = G.GuX.RESOLVE;
            } catch (t11) {
              i2.error(t11), e10.tracksLoading.loadingState = G.GuX.REJECT;
            }
          }),
          getFilters: (0, r.L3)(function* () {
            if (!(0, r._n)(e10)) return;
            let { filtersResource: t11, modelActionsLogger: a2 } = (0, r._$)(e10);
            try {
              e10.filters.loadingState = G.GuX.PENDING;
              let a3 = yield t11.getTracksFilters({ trackIds: e10.likedTrackIds }), i2 = ((e11) => {
                let t12 = e11.filters.map(ac);
                if (t12.length < 3) return [];
                let a4 = t12.find((e12) => e12.id === ad.ALL);
                if (!a4) return [];
                let i3 = t12.filter((e12) => e12.tracks.length >= 8);
                return i3.length < 2 ? [] : [a4, ...i3.slice(0, 7)];
              })(a3);
              e10.filters.items = (0, r.wg)(i2), e10.filters.loadingState = G.GuX.RESOLVE;
            } catch (t12) {
              a2.error(t12), e10.filters.loadingState = G.GuX.REJECT;
            }
          }),
          setItems(t11) {
            e10.items.forEach((e11) => {
              (0, r.Yo)(e11);
            });
            let a2 = t11.map((e11) => (0, r.dV)(e11));
            e10.items.replace(a2);
          },
          handleFilterClick: (0, r.L3)(function* (a2) {
            e10.filters.setActiveFilter(a2.id), yield t10.getTracksMeta(), e10.filters.setShouldSendEventOnTabOpened(true);
          })
        };
        return t10;
      }), aA = k.props({
        type: r.gK.literal(s.t.COLLECTION_FAVOURITE_PLAYLIST),
        data: r.gK.optional(av, () => ({
          items: [],
          playlist: { uuid: "", isAvailable: true, uid: 0, kind: e_.ji.LIKE, likesCount: 0, pendingLikesCount: 0 }
        })),
        meta: a_
      }).named("PlaylistWithTracksAndFilters").views((e10) => ({
        get isVisible() {
          var t10, a2, i2, s2, l2, r2, o2, n2, d2, c2, m2;
          if (e10.isLoaded && 0 === e10.data.items.length || (null == (t10 = e10.data) ? void 0 : t10.canShowEmptyBlock))
            return true;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: !!(e10.isNeededToLoad || (null == (a2 = e10.data) ? void 0 : a2.playlistLoading.isNeededToLoad) || (null == (i2 = e10.data) ? void 0 : i2.tracksLoading.isNeededToLoad)),
            isLoading: !!(e10.isLoading || (null == (s2 = e10.data) ? void 0 : s2.playlistLoading.isLoading) || (null == (l2 = e10.data) ? void 0 : l2.tracksLoading.isLoading)),
            isLoaded: !!(e10.isLoaded && (null == (r2 = e10.data) ? void 0 : r2.playlistLoading.isResolved) && (null == (o2 = e10.data) ? void 0 : o2.tracksLoading.isResolved)),
            isRejected: !!(e10.isRejected || (null == (n2 = e10.data) ? void 0 : n2.playlistLoading.isRejected) || (null == (d2 = e10.data) ? void 0 : d2.tracksLoading.isRejected)),
            isNotEmpty: !!((null == (c2 = e10.data) ? void 0 : c2.items.length) || (null == (m2 = e10.data) ? void 0 : m2.canShowEmptyBlock))
          });
        },
        get objectsCount() {
          var u2, _2;
          let t10 = null != (_2 = null == (u2 = e10.data) ? void 0 : u2.items.length) ? _2 : 0;
          return t10 < 8 ? t10 : 8;
        }
      })), aT = ap.named("PlaylistWithTracksData"), aC = k.props({
        type: r.gK.union(
          r.gK.literal(s.t.OPEN_PLAYLIST),
          r.gK.literal(s.t.SMART_OPEN_PLAYLIST),
          r.gK.literal(s.t.NON_MUSIC_OPEN_PLAYLIST),
          r.gK.literal(s.t.COLLECTION_PLAYLIST_WITH_LIKES)
        ),
        data: r.gK.maybe(aT),
        meta: R
      }).named("PlaylistWithTracks").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (null == (t10 = e10.data) ? void 0 : t10.canShowEmptyBlock) return true;
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: (null == (a2 = e10.data) ? void 0 : a2.items.length) !== 0
          });
        },
        get objectsCount() {
          var i2, s2;
          let t10 = null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
          return t10 < 8 ? t10 : 8;
        }
      })), ah = r.gK.union(S, U, E), aI = r.gK.model("RecentlyPlayedData", { items: r.gK.array(ah) }), aL = k.props({ type: r.gK.literal(s.t.RECENTLY_PLAYED), data: r.gK.maybe(aI), meta: R }).named("RecentlyPlayed").views((e10) => ({
        get isVisible() {
          var t10, a2;
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return (null == (a2 = e10.data) || null == (t10 = a2.items) ? void 0 : t10.length) !== 0;
        },
        get objectsCount() {
          var i2, s2;
          return null != (s2 = null == (i2 = e10.data) ? void 0 : i2.items.length) ? s2 : 0;
        }
      })), ay = r.gK.model("LandingVibeItemData", { vibe: g.Gh, cover: r.gK.maybeNull(W.$B) }), aS = r.gK.model("LandingVibeItem", { type: r.gK.literal(o._.WAVE_ITEM), data: ay }), aE = r.gK.union(E, N, S, V, Y, aS, j, e0), aN = r.gK.model("SearchHistoryData", { items: r.gK.array(aE) }), aj = k.props({
        type: r.gK.union(r.gK.literal(s.t.HISTORY), r.gK.literal(s.t.SEARCH_HISTORY)),
        data: r.gK.maybe(aN),
        meta: R
      }).named("SearchHistory").views((e10) => ({
        get isVisible() {
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: true
          });
        },
        get objectsCount() {
          var t10, a2;
          return null != (a2 = null == (t10 = e10.data) ? void 0 : t10.items.length) ? a2 : 0;
        }
      })), ak = r.gK.model("SpecialThemeSettings", {
        buttonColor: r.gK.maybeNull(r.gK.string),
        textColor: r.gK.maybeNull(r.gK.string),
        bgImageUrl: r.gK.maybeNull(r.gK.string),
        imageUrl: r.gK.maybeNull(r.gK.string),
        buttonTextColor: r.gK.maybeNull(r.gK.string)
      }), ax = r.gK.model("SpecialData", {
        title: r.gK.maybe(r.gK.string),
        subtitle: r.gK.maybe(r.gK.string),
        buttonTitle: r.gK.maybe(r.gK.string),
        imageUrl: r.gK.maybe(r.gK.string),
        align: r.gK.maybeNull(r.gK.string),
        weblink: r.gK.maybeNull(r.gK.string),
        lightTheme: r.gK.maybeNull(ak),
        darkTheme: r.gK.maybeNull(ak)
      }), aR = k.props({ type: r.gK.literal(s.t.SPECIAL), data: r.gK.maybe(ax), meta: R }).named("Special").views((e10) => ({
        get isVisible() {
          if (e10.isLoading || e10.isRejected || e10.isNeededToLoad) return true;
          return !!e10.data;
        },
        get objectsCount() {
          return 0;
        }
      })), af = r.gK.model("VibesDataItemTab", { id: r.gK.number, title: r.gK.string }), aP = r.gK.model("VibesDataItem", { tab: af, data: r.gK.array(g.Gh) }), aw = r.gK.model("VibesData", { items: r.gK.array(aP) }), aK = k.props({
        type: r.gK.union(
          r.gK.literal(s.t.WAVES),
          r.gK.literal(s.t.SETS_BY_WAVES),
          r.gK.literal(s.t.WAVES_AGENT),
          r.gK.literal(s.t.SETS_BY_WAVES_AGENT)
        ),
        data: r.gK.maybe(aw),
        meta: R
      }).named("Vibes").views((e10) => ({
        get isVisible() {
          var t10, a2, i2;
          let s2 = (null == (t10 = e10.data) ? void 0 : t10.items.length) === 0, l2 = null == (i2 = e10.data) || null == (a2 = i2.items) ? void 0 : a2.every((e11) => !(null == e11 ? void 0 : e11.data));
          return y({
            showPolicy: e10.meta.showPolicy,
            isNeededToLoad: e10.isNeededToLoad,
            isLoading: e10.isLoading,
            isLoaded: e10.isLoaded,
            isRejected: e10.isRejected,
            isNotEmpty: !s2 || !l2
          });
        },
        get objectsCount() {
          var s2, l2, r2;
          return null != (r2 = null == (l2 = e10.data) || null == (s2 = l2.items[0]) ? void 0 : s2.data.length) ? r2 : 0;
        }
      })), aO = r.gK.model("WizardData", {
        title: r.gK.string,
        description: r.gK.maybe(r.gK.string),
        artists: r.gK.array(c.PK)
      }), aM = k.props({ type: r.gK.literal(s.t.WIZARD), data: r.gK.maybe(aO), meta: R }).named("Wizard").views(() => ({
        get isVisible() {
          return true;
        },
        get objectsCount() {
          return 0;
        }
      })), aD = r.gK.union(
        eQ,
        e2,
        to,
        ty,
        tv,
        td,
        aC,
        aA,
        ai,
        w,
        B,
        aL,
        tq,
        an,
        aR,
        aM,
        aK,
        t8,
        t7,
        t3,
        al,
        O,
        te,
        tk,
        th,
        tW,
        tZ,
        ar,
        tu,
        tY,
        e3,
        eF,
        tM,
        tB,
        aj,
        t2,
        tp,
        ez,
        eC,
        eI,
        eR,
        ek,
        ey,
        eq,
        tF,
        tN,
        tE,
        tl
      ), aB = r.gK.model("TabData", {
        id: r.gK.string,
        title: r.gK.string,
        subtitle: r.gK.maybe(r.gK.string),
        covers: r.gK.maybe(r.gK.array(r.gK.string))
      }), aV = r.gK.model("Tab", {
        meta: r.gK.model({ id: r.gK.string, title: r.gK.string }),
        data: r.gK.maybe(aB),
        blocks: r.gK.array(aD),
        shouldReloadNotification: r.gK.boolean
      }).views((e10) => ({
        get hasErrorBlocks() {
          return e10.blocks.some((e11) => e11.isRejected && e11.isVisible);
        }
      })).actions((e10) => ({
        setShouldReloadNotification(t10) {
          e10.shouldReloadNotification = t10;
        }
      })), aU = r.gK.compose(r.gK.model("TabsData", { data: r.gK.maybeNull(r.gK.array(aV)) }), W.pl, W.XT).actions((e10) => ({
        reset() {
          e10.loadingState = G.GuX.IDLE, e10.destroyItems([e10.data]);
        }
      })), aY = r.gK.compose(
        r.gK.model("Tabs", {
          meta: r.gK.maybeNull(r.gK.model({ selectedTabIndex: r.gK.number, source: r.gK.maybe(x) })),
          upperBlocks: r.gK.maybeNull(r.gK.array(aD)),
          tabs: aU
        }),
        W.XT
      ).views((e10) => {
        let t10 = {
          get isEmpty() {
            var a2, i2;
            return !(null == (a2 = e10.tabs.data) ? void 0 : a2.length) && !(null == (i2 = e10.upperBlocks) ? void 0 : i2.length);
          },
          get isLoadedAndEmpty() {
            return [G.GuX.RESOLVE, G.GuX.REJECT].includes(e10.loadingState) && t10.isEmpty;
          },
          get hasUpperBlocks() {
            var s2;
            return !!(null == (s2 = e10.upperBlocks) ? void 0 : s2.length);
          }
        };
        return t10;
      }).props({ id: r.gK.optional(r.gK.string, ""), title: r.gK.optional(r.gK.string, "") }).views((e10) => ({
        get isLoaded() {
          return e10.loadingState === G.GuX.RESOLVE || e10.loadingState === G.GuX.REJECT;
        }
      })).actions((e10) => {
        let t10 = {
          getBlock: (0, r.L3)(function* (a2) {
            var i2, l2, L2, y2, S2, E2, N2;
            let j2;
            if (!a2 || !("source" in a2.meta) && (j2 = a2.type, !el.includes(j2)) && !ei(a2.type)) return;
            if ((0, es.Q)(a2)) {
              null == (i2 = a2.data) || i2.blocks.forEach(t10.getBlock);
              return;
            }
            let { landingResource: k2, modelActionsLogger: x2 } = (0, r._$)(e10);
            try {
              if (a2.loadingState = I.PENDING, ei(a2.type)) {
                a2.loadingState = I.RESOLVE;
                return;
              }
              let e11 = yield k2.getBlock({ source: "source" in a2.meta ? a2.meta.source : void 0, type: a2.type });
              if (!(0, r._n)(a2)) {
                a2.loadingState = I.REJECT;
                return;
              }
              switch (a2.type) {
                case s.t.CLIPS:
                case s.t.ARTIST_CLIPS:
                case s.t.COLLECTION_CLIPS:
                  let t11, i3;
                  "object" == typeof e11 && null !== e11 && "items" in e11 && Array.isArray(e11.items) && (!e11.items.length || (t11 = e11.items[0], "object" == typeof t11 && null !== t11 && "type" in t11 && (t11.type === o._.CLIP || t11.type === o._.CLIP_ITEM))) && (i3 = a2.type, a2.data = (0, r.wg)({ items: e11.items.map(A), canShowEmptyBlock: i3 === s.t.COLLECTION_CLIPS }));
                  break;
                case s.t.WIZARD:
                  "object" == typeof e11 && null !== e11 && "title" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (null == e12 ? void 0 : e12.artists) || []) ? void 0 : t12.map((e13) => (0, c.as)({ artist: e13 }));
                    return (0, r.wg)({ title: e12.title, description: e12.description, artists: a3 });
                  })(e11));
                  break;
                case s.t.CHART_TRACKS:
                  "chart" in e11 && (a2.data = ((e12) => {
                    var t12, a3;
                    let i4 = null == (a3 = (e12 || {}).chart) || null == (t12 = a3.tracks) ? void 0 : t12.map((e13) => {
                      let { track: t13, chart: a4 } = e13;
                      return { type: o._.TRACK_ITEM, data: (0, C.bV)(t13, a4) };
                    });
                    return (0, r.wg)({
                      items: i4,
                      playlist: (0, u.bk)({ playlist: null == e12 ? void 0 : e12.chart })
                    });
                  })(e11));
                  break;
                case s.t.NON_MUSIC_EDITORIAL_COMPILATION:
                  "object" == typeof e11 && null !== e11 && "items" in e11 && (a2.data = ((e12) => {
                    let t12 = e12.items.map(
                      (e13) => e13.type === o._.NON_MUSIC_ALBUM_ITEM ? T({
                        album: e13.data.album,
                        artists: e13.data.artists,
                        likesCount: e13.data.likesCount,
                        bookmateOptionRequired: e13.data.bookmateOptionRequired
                      }) : _({
                        playlist: e13.data.playlist,
                        likesCount: e13.data.likesCount,
                        trailer: e13.data.trailer
                      })
                    );
                    return (0, r.wg)({ items: t12 });
                  })(e11));
                  break;
                case s.t.CHART_ALBUMS:
                  ((e12) => {
                    let t12, a3 = e12.items;
                    return !a3.length || !!((t12 = a3[0]) && "object" == typeof t12 && "type" in t12 && t12.type === o._.CHART_ALBUM_ITEM);
                  })(e11) && (a2.data = ((e12) => {
                    let t12 = e12.items.map(
                      (e13) => (0, n.EV)({ album: e13.data.album, likesCount: e13.data.likesCount, chart: e13.data.chart })
                    );
                    return (0, r.wg)({ items: t12 });
                  })(e11));
                  break;
                case s.t.COLLECTION_ALBUMS:
                  "likedAlbums" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).likedAlbums) ? void 0 : t12.map(
                      (e13) => (0, n.sK)({ album: e13.data.album, artists: e13.data.artists, trailer: e13.data.trailer })
                    );
                    return (0, r.wg)({ items: a3, canShowEmptyBlock: true });
                  })(e11));
                  break;
                case s.t.COLLECTION_ARTISTS:
                  "likedArtists" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).likedArtists) ? void 0 : t12.map((e13) => (0, c.as)({ artist: e13.data.artist, trailer: e13.data.trailer }));
                    return (0, r.wg)({ items: a3, canShowEmptyBlock: true });
                  })(e11));
                  break;
                case s.t.COLLECTION_ARTISTS_AND_TOP:
                  e11 && "object" == typeof e11 && "items" in e11 && (a2.data = ((e12) => {
                    let t12 = e12.items.map((e13) => (0, c.as)({ artist: e13.data.artist, trailer: e13.data.trailer }));
                    return (0, r.wg)({ items: t12, canShowEmptyBlock: true });
                  })(e11));
                  break;
                case s.t.COLLECTION_TOP_ARTISTS:
                  e11 && "object" == typeof e11 && "artists" in e11 && Array.isArray(e11.artists) && (a2.data = (0, r.wg)(
                    ((e12) => {
                      let t12 = ((null == e12 ? void 0 : e12.artists) || []).map((e13) => ({
                        artist: (0, c.as)({ artist: e13.artist }),
                        listenTimeSeconds: e13.listenTimeSeconds,
                        top: (0, eb.ws)({ position: e13.top.position, progress: e13.top.progress })
                      }));
                      return (0, r.wg)({ items: t12 });
                    })(e11)
                  ));
                  break;
                case s.t.PERSONAL_ARTISTS:
                case s.t.NEW_STARS_ARTISTS:
                case s.t.EDITORIAL_ARTISTS:
                case s.t.META_TAG_POPULAR_ARTISTS:
                case s.t.MICRO_GENRE_ARTISTS:
                case s.t.MICRO_GENRE_TOP_ARTISTS:
                case s.t.META_TAG_ARTISTS:
                case s.t.SIMILAR_ARTISTS:
                  "items" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).items) ? void 0 : t12.map((e13) => (0, c.as)({ artist: e13.data.artist, trailer: e13.data.trailer }));
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.COLLECTION_PLAYLISTS_CREATED:
                  "createdPlaylists" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).createdPlaylists) ? void 0 : t12.map(
                      (e13) => (0, u.bk)({
                        playlist: e13.data.playlist,
                        likesCount: e13.data.likesCount,
                        trailer: e13.data.trailer
                      })
                    );
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.COLLECTION_PLAYLISTS_LIKED:
                  "likedPlaylists" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).likedPlaylists) ? void 0 : t12.map(
                      (e13) => (0, u.bk)({
                        playlist: e13.data.playlist,
                        generatedPlaylistType: e13.data.generatedPlaylistType,
                        likesCount: e13.data.likesCount,
                        trailer: e13.data.trailer
                      })
                    );
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.OPEN_PLAYLIST:
                case s.t.SMART_OPEN_PLAYLIST:
                case s.t.NON_MUSIC_OPEN_PLAYLIST:
                  "playlist" in e11 && (l2 = a2.id, a2.data = (0, r.wg)({
                    items: e11.tracks.map((e12) => (0, C.vU)(e12)),
                    playlist: (0, e_.jX)(e11.playlist),
                    coverUri: null == (L2 = e11.cover) ? void 0 : L2.uri,
                    withRewindTrailerButton: "rewind2024" === l2
                  }));
                  break;
                case s.t.COLLECTION_PLAYLIST_WITH_LIKES:
                  "playlist" in e11 && (a2.data = ((e12) => {
                    var t12, a3, i4;
                    let s2 = e12 || {};
                    return (0, r.wg)({
                      items: null != (i4 = null == (t12 = s2.tracks) ? void 0 : t12.map((e13) => (0, C.vU)(e13))) ? i4 : [],
                      playlist: (0, e_.jX)(s2.playlist),
                      totalItemsCount: null == (a3 = s2.summary) ? void 0 : a3.count,
                      canShowEmptyBlock: true
                    });
                  })(e11));
                  break;
                case s.t.NEW_RELEASES:
                case s.t.EDITORIAL_NEW_RELEASES:
                  "newReleases" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).newReleases) ? void 0 : t12.map((e13) => {
                      let { album: t13, artists: a4, releaseDate: i4, cover: s2, trailer: l3 } = e13;
                      return {
                        album: (0, n.sK)({ album: t13, artists: a4, trailer: l3 }),
                        releaseDate: i4,
                        coverUri: null == s2 ? void 0 : s2.uri,
                        coverColor: null == s2 ? void 0 : s2.color
                      };
                    });
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.NEW_PLAYLISTS:
                case s.t.EDITORIAL_COMPILATION:
                case s.t.RECOMMENDED_PLAYLISTS:
                case s.t.META_TAG_POPULAR_PLAYLISTS:
                case s.t.META_TAG_NEW_ALBUMS:
                case s.t.META_TAG_PLAYLISTS:
                case s.t.MICRO_GENRE_ALBUMS:
                case s.t.META_TAG_ALBUMS:
                case s.t.ARTIST_PLAYLISTS:
                case s.t.ARTIST_COMPILATIONS:
                case s.t.ARTIST_ALBUMS:
                case s.t.ARTIST_STUDIO_ALBUMS:
                case s.t.ARTIST_SIMILAR_ENTITIES:
                case s.t.COLLECTION_SIMILAR_ENTITIES:
                  "items" in e11 && (a2.data = b(e11));
                  break;
                case s.t.RECENTLY_PLAYED:
                  "items" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).items) ? void 0 : t12.map((e13) => {
                      switch (e13.type) {
                        case o._.PLAYLIST_ITEM:
                          return H(e13.data.playlist, e13.data.trailer);
                        case o._.ALBUM_ITEM:
                          return d(e13.data.album, e13.data.artists, e13.data.trailer);
                        case o._.ARTIST_ITEM:
                          return m(e13.data.artist, e13.data.trailer);
                      }
                    });
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.IN_STYLE:
                  "inStyleTabs" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).inStyleTabs) ? void 0 : t12.map((e13, t13) => {
                      var a4;
                      let i4 = null == e13 ? void 0 : e13.items.map((e14) => {
                        let { album: t14, artists: a5, trailer: i5 } = e14;
                        return (0, n.sK)({ album: t14, artists: a5, trailer: i5 });
                      }), s2 = (null == e13 || null == (a4 = e13.cover) ? void 0 : a4.uri) && [
                        null == e13 ? void 0 : e13.cover.uri
                      ] || [];
                      return { tab: { id: t13, title: e13.title, covers: (0, r.wg)(s2) }, data: (0, r.wg)(i4) };
                    });
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.PROMOTIONS:
                case s.t.EDITORIAL_PROMOTIONS:
                case s.t.NON_MUSIC_PROMOTIONS:
                  "promotions" in e11 && (a2.data = ((e12) => {
                    if (!Array.isArray(null == e12 ? void 0 : e12.promotions)) return (0, r.wg)({});
                    let t12 = null == e12 ? void 0 : e12.promotions.map((e13) => {
                      var t13, a3;
                      return {
                        featureId: (e13 = e13 || {}).featureId,
                        title: e13.title,
                        subtitle: e13.subtitle,
                        weblink: null != (a3 = null == (t13 = e13.action) ? void 0 : t13.weblink) ? a3 : "",
                        imageUrl: e13.imageUrl
                      };
                    });
                    return (0, r.wg)({ items: t12 });
                  })(e11));
                  break;
                case s.t.REWIND_PLAYLISTS:
                case s.t.PERSONAL_PLAYLISTS:
                  "items" in e11 && (a2.data = ((e12) => {
                    if (!e12 || !Array.isArray(e12.items)) return (0, r.wg)({});
                    let t12 = e12.items.map(F);
                    return (0, r.wg)({ items: t12 });
                  })(e11));
                  break;
                case s.t.SPECIAL:
                  "title" in e11 && (a2.data = (0, r.wg)({
                    title: null == e11 ? void 0 : e11.title,
                    subtitle: null == e11 ? void 0 : e11.subtitle,
                    buttonTitle: null == e11 ? void 0 : e11.buttonTitle,
                    imageUrl: null == e11 ? void 0 : e11.imageUrl,
                    align: null == e11 ? void 0 : e11.align,
                    weblink: null == e11 || null == (y2 = e11.action) ? void 0 : y2.weblink,
                    lightTheme: eU(null == e11 ? void 0 : e11.lightTheme),
                    darkTheme: eU(null == e11 ? void 0 : e11.darkTheme)
                  }));
                  break;
                case s.t.COLLECTION_ALBUMS_PRESAVES:
                  void 0 !== e11.tabs && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).tabs) ? void 0 : t12.map((e13) => {
                      let t13 = null == e13 ? void 0 : e13.items.map(eg);
                      return (0, r.wg)({
                        id: e13.id,
                        title: e13.title,
                        type: e13.type,
                        items: t13,
                        canShowEmptyBlock: true
                      });
                    });
                    return (0, r.wg)({ tabs: a3 });
                  })(e11));
                  break;
                case s.t.WAVES:
                case s.t.SETS_BY_WAVES:
                  "waves" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).waves) ? void 0 : t12.map((e13, t13) => ({
                      tab: { id: t13, title: null == e13 ? void 0 : e13.title },
                      data: null == e13 ? void 0 : e13.items.map(g.er)
                    }));
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.WAVES_AGENT:
                case s.t.SETS_BY_WAVES_AGENT:
                  e11 && "object" == typeof e11 && "waves" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).waves) ? void 0 : t12.map((e13, t13) => {
                      var a4;
                      return {
                        tab: { id: t13, title: null == e13 ? void 0 : e13.title },
                        data: (null == e13 || null == (a4 = e13.items) ? void 0 : a4.map((e14) => {
                          let { wave: t14, agent: a5 } = e14;
                          return (0, g.lb)(t14, a5);
                        })) || []
                      };
                    });
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.MIXES_GRID:
                case s.t.MIXES_MUSIC:
                  "object" == typeof e11 && null !== e11 && "items" in e11 && (a2.data = { items: (0, r.wg)(e11.items.map((e12) => (0, X.rc)(e12.data))) });
                  break;
                case s.t.MIXES:
                  "items" in e11 && (a2.data = { items: (0, r.wg)(e11.items.map((e12) => (0, eB.Ju)(e12.data))) });
                  break;
                case s.t.NEUROMUSIC:
                  "items" in e11 && (a2.data = (0, r.wg)({ items: e11.items.map((e12) => (0, eV.xf)(e12)) }));
                  break;
                case s.t.LIKES_AND_HISTORY:
                  "favorites" in e11 && (a2.data = ((e12) => {
                    let { favorites: t12, history: a3 } = e12, i4 = (0, G.pX4)(t12.cover), s2 = t12.trackCovers.map(G.pX4), l3 = (0, r.wg)({
                      title: t12.title,
                      cover: i4,
                      playlistUuid: t12.playlistUuid || void 0,
                      count: t12.count,
                      trackCovers: s2
                    }), o2 = a3.trackCovers.map(G.pX4), n2 = (0, r.wg)({ title: a3.title, trackCovers: o2, artists: a3.subtitleElements });
                    return (0, r.wg)({ favorites: l3, history: n2 });
                  })(e11));
                  break;
                case s.t.CONCERTS_TOP:
                case s.t.CONCERTS_PERSONAL:
                case s.t.EDITORIAL_CONCERTS:
                case s.t.VIEWED_CONCERTS:
                  void 0 !== e11.concerts && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).concerts) ? void 0 : t12.map((e13) => (0, er.ho)(e13));
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.COLLECTION_PLAYLISTS_LIKED_AND_CREATED:
                  "tabs" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).tabs) ? void 0 : t12.map((e13) => {
                      let t13 = null == e13 ? void 0 : e13.items.map(
                        (e14) => (0, u.bk)({
                          playlist: e14.data.playlist,
                          generatedPlaylistType: e14.data.generatedPlaylistType,
                          likesCount: e14.data.likesCount,
                          trailer: e14.data.trailer
                        })
                      );
                      return (0, r.wg)({
                        id: e13.id,
                        title: e13.title,
                        type: e13.type,
                        items: t13,
                        canShowEmptyBlock: true
                      });
                    });
                    return (0, r.wg)({ tabs: a3 });
                  })(e11));
                  break;
                case s.t.EDITORIAL_WAVES:
                case s.t.META_TAG_WAVE:
                case s.t.MICRO_GENRE_WAVE:
                case s.t.MICRO_GENRE_SIMILAR_WAVE:
                case s.t.META_TAG_SIMILAR_WAVE:
                  "items" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).items) ? void 0 : t12.map(g.er);
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.EDITORIAL_WAVES_AGENT:
                case s.t.META_TAG_WAVE_AGENT:
                case s.t.MICRO_GENRE_WAVE_AGENT:
                case s.t.MICRO_GENRE_SIMILAR_WAVE_AGENT:
                case s.t.META_TAG_SIMILAR_WAVE_AGENT:
                  e11 && "object" == typeof e11 && "items" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).items) ? void 0 : t12.map((e13) => (0, g.lb)(e13.wave, e13.agent));
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.ITEM_LIST:
                  "items" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).items) ? void 0 : t12.map(ep);
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.DONATIONS:
                  void 0 !== e11.donations && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = (e12 || {}).donations) ? void 0 : t12.map(eD);
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.CONTINUE_LISTEN:
                  "object" == typeof e11 && null !== e11 && "bookshelf" in e11 && (a2.data = ((e12) => {
                    let { bookshelf: t12, newEpisodes: a3, lastPlayed: i4 } = e12;
                    return (0, r.wg)({
                      bookshelf: {
                        title: t12.title,
                        covers: (t12.covers || []).map(eO),
                        bookCount: t12.bookCount,
                        podcastCount: t12.podcastCount
                      },
                      newEpisodes: { title: a3.title, covers: (a3.covers || []).map(eO), trackCount: a3.trackCount },
                      lastPlayed: i4 && ((e13) => {
                        let {
                          type: t13,
                          data: { track: a4, album: i5, playlist: s2, durationTotal: l3, durationLeft: o2 }
                        } = e13;
                        return (0, r.wg)({
                          type: t13,
                          data: {
                            album: t13 === en._.ALBUM && i5 ? (0, n.sK)({ album: i5 }) : void 0,
                            playlist: t13 !== en._.ALBUM && s2 ? (0, u.bk)({ playlist: s2 }) : void 0,
                            track: (0, C.vU)(a4),
                            albumDuration: l3,
                            albumDurationLeft: o2
                          }
                        });
                      })(i4)
                    });
                  })(e11));
                  break;
                case s.t.SIMPLE_ALBUM_PROMO:
                case s.t.ALBUM_PROMO:
                  e11 && "object" == typeof e11 && "albumBanners" in e11 && (a2.data = (0, r.wg)({
                    reporting: ((e12) => {
                      if (e12)
                        return {
                          adImpressions: e12.adImpressions,
                          blockImpression: e12.blockImpression,
                          blockRender: e12.blockRender
                        };
                    })(e11.reporting),
                    items: e11.albumBanners.map((e12) => ({
                      album: (0, n.sK)({ album: e12.album, artists: e12.artists }),
                      artists: e12.artists.map((e13) => (0, c.as)({ artist: e13 })),
                      cover: e12.cover,
                      coverContentMode: e12.coverContentMode,
                      clickUrl: e12.reporting.clickUrl,
                      yclid: e12.playbackParams.yclid,
                      utm: e12.playbackParams.utm
                    }))
                  }));
                  break;
                case s.t.COLLECTION_DOWNLOADED_TRACKS:
                  e11 && "object" == typeof e11 && "tracks" in e11 && (a2.data = ((e12) => {
                    let t12 = (null == e12 ? void 0 : e12.tracks) || [], a3 = t12.slice(0, 8).map((e13) => (0, C.vU)(e13));
                    return (0, r.wg)({ items: a3, rawTracks: t12 });
                  })(e11));
                  break;
                case s.t.HISTORY:
                case s.t.SEARCH_HISTORY:
                  e11 && "object" == typeof e11 && "items" in e11 && Array.isArray(e11.items) && (a2.data = ((e12) => {
                    let t12 = e12.items.map((e13) => {
                      switch (e13.type) {
                        case o._.ALBUM_ITEM:
                          return d(e13.data.album, e13.data.artists, e13.data.trailer);
                        case o._.ARTIST_ITEM:
                          return m(e13.data.artist, e13.data.trailer);
                        case o._.TRACK_ITEM:
                          return h(e13);
                        case o._.LIKED_PLAYLIST_ITEM:
                          return _({
                            playlist: e13.data.playlist,
                            likesCount: e13.data.likesCount,
                            trailer: e13.data.trailer,
                            tracksCount: e13.data.trackCount
                          });
                        case o._.WAVE_ITEM:
                          let t13;
                          return t13 = e13, (0, r.wg)({
                            type: o._.WAVE_ITEM,
                            data: {
                              cover: t13.data.cover ? (0, G.pX4)(t13.data.cover) : void 0,
                              vibe: (0, g.er)(t13.data.wave)
                            }
                          });
                        case o._.WAVE_AGENT_ITEM:
                          return p(e13);
                        case o._.NON_MUSIC_ALBUM_ITEM:
                          return T({
                            album: e13.data.album,
                            likesCount: e13.data.likesCount,
                            bookmateOptionRequired: e13.data.bookmateOptionRequired
                          });
                        case o._.CLIP_ITEM:
                        case o._.CLIP:
                          return {
                            type: e13.type,
                            data: (0, v.SZ)({ clip: e13.data.clip, artists: e13.data.artists })
                          };
                        default:
                          return;
                      }
                    }).filter((e13) => e13);
                    return (0, r.wg)({ items: t12 });
                  })(e11));
                  break;
                case s.t.COLLECTION_KIDS:
                  e11 && "object" == typeof e11 && "items" in e11 && Array.isArray(e11.items) && (a2.data = ((e12) => {
                    let t12 = e12.items.map((e13) => {
                      switch (e13.type) {
                        case o._.TRACK_ITEM:
                          return h(e13);
                        case o._.LIKED_PLAYLIST_ITEM:
                          return _({
                            playlist: e13.data.playlist,
                            likesCount: e13.data.likesCount,
                            trailer: e13.data.trailer,
                            tracksCount: e13.data.trackCount
                          });
                        case o._.NON_MUSIC_ALBUM_ITEM:
                          return T({
                            album: e13.data.album,
                            likesCount: e13.data.likesCount,
                            bookmateOptionRequired: e13.data.bookmateOptionRequired
                          });
                      }
                    });
                    return (0, r.wg)({ items: t12 });
                  })(e11));
                  break;
                case s.t.ARTIST_CONCERTS:
                  e11 && "object" == typeof e11 && "concerts" in e11 && (a2.data = ((e12) => {
                    var t12;
                    let a3 = null == (t12 = e12.concerts) ? void 0 : t12.map((e13) => {
                      let { concert: t13, minPrice: a4 } = e13;
                      return { ...(0, er.ho)(t13, a4) };
                    });
                    return (0, r.wg)({ items: a3 });
                  })(e11));
                  break;
                case s.t.ARTIST_POPULAR_TRACKS:
                  e11 && "object" == typeof e11 && "tracks" in e11 && e11.tracks && (a2.data = (0, r.wg)({ items: e11.tracks.map((e12) => (0, C.vU)(e12)) }));
                  break;
                case s.t.ARTIST_RELEASE:
                  e11 && "object" == typeof e11 && "release" in e11 && e11.release && (a2.data = ((e12) => {
                    let { album: t12, artists: a3, releaseDate: i4, trailer: s2 } = e12.release;
                    return {
                      album: (0, n.sK)({ album: t12, artists: a3, trailer: s2, releaseDate: i4 }),
                      releaseDate: i4
                    };
                  })(e11));
                  break;
                case s.t.FAMILIAR_YOU:
                  e11 && "object" == typeof e11 && (a2.data = (0, r.wg)({
                    vibeTrackCount: null == (S2 = e11.wave) ? void 0 : S2.trackCount,
                    collectionTrackCount: null == (E2 = e11.collection) ? void 0 : E2.trackCount,
                    collectionAlbumCount: null == (N2 = e11.collection) ? void 0 : N2.albumCount
                  }));
                  break;
                case s.t.ARTIST_PICK:
                  e11 && "object" == typeof e11 && "artists" in e11 && e11.artists && "playlist" in e11 && e11.playlist && (a2.data = ((e12) => {
                    let t12 = e12.artists.map((e13) => (0, c.as)({ artist: e13 }));
                    return (0, r.wg)({ playlist: (0, u.bk)({ playlist: e12.playlist }), artists: t12 });
                  })(e11));
                  break;
                case s.t.ARTIST_UPCOMING_RELEASE:
                  e11 && "object" == typeof e11 && "release" in e11 && e11.release && "presaved" in e11 && (a2.data = ((e12) => {
                    let { album: t12, artists: a3, releaseDate: i4 } = e12.release;
                    return { album: (0, n.h)({ album: t12, artists: a3, releaseDate: i4, isPresave: e12.presaved }) };
                  })(e11));
                  break;
                case s.t.CONCERT_PLACE:
                  "object" == typeof e11 && null !== e11 && "map" in e11 && (a2.data = ((e12) => {
                    let t12 = e12.metroStations ? e12.metroStations.map(eK.P5) : null;
                    return (0, r.wg)({
                      place: e12.place,
                      city: e12.city,
                      address: e12.address,
                      metroStations: t12,
                      map: e12.map
                    });
                  })(e11));
                  break;
                case s.t.COLLECTION_WAVE_AGENT:
                  e11 && "object" == typeof e11 && "wave" in e11 && "agent" in e11 && (a2.data = (0, r.wg)({ vibe: (0, g.lb)(e11.wave, e11.agent) }));
                  break;
                case s.t.COLLECTION_ARTISTS_AND_TOP_WITH_ITEMS:
                  e11 && "object" == typeof e11 && "artists" in e11 && (a2.data = ((e12) => {
                    let t12 = e12.artists.map((e13) => {
                      let t13 = e13.items.map((e14) => {
                        switch (e14.type) {
                          case o._.MENU_ITEM:
                            return ep(e14);
                          case o._.WAVE_AGENT_ITEM:
                            return p(e14);
                          default:
                            return;
                        }
                      }).filter((e14) => void 0 !== e14);
                      return { artist: (0, c.as)({ artist: e13.artist }), items: t13 };
                    });
                    return (0, r.wg)({ artists: t12 });
                  })(e11));
              }
              a2.loadingState = I.RESOLVE;
            } catch (e11) {
              x2.error(e11), (0, r._n)(a2) && (a2.loadingState = I.REJECT, e11 instanceof et.GX && (e11.statusCode === et.X1.NOT_FOUND || e11.statusCode === et.X1.BAD_REQUEST) && (a2.isNotFound = true));
            }
          }),
          getTabData: (0, r.L3)(function* (t11) {
            let { landingResource: a2, modelActionsLogger: i2 } = (0, r._$)(e10);
            try {
              var s2, l2;
              e10.tabs.loadingState = G.GuX.PENDING;
              let i3 = (null == (l2 = ((yield a2.getBlock({ source: t11 })) || {}).tabs) ? void 0 : l2.map(
                (e11) => (0, r.wg)({ id: e11.id, title: e11.title, subtitle: e11.subtitle, covers: e11.covers })
              )) || [];
              null == (s2 = e10.tabs.data) || s2.forEach((e11, t12) => {
                let a3 = i3.find((t13) => t13.title === e11.meta.title);
                e11.data = a3 || i3[t12];
              }), e10.tabs.loadingState = G.GuX.RESOLVE;
            } catch (t12) {
              i2.error(t12), e10.loadingState = G.GuX.REJECT;
            }
          }),
          async prefetchBlocks(a2) {
            var i2, s2, l2;
            let r2 = null != a2 ? a2 : 0, o2 = [];
            (null == (i2 = e10.meta) ? void 0 : i2.source) && o2.push(t10.getTabData(e10.meta.source)), null == (s2 = e10.upperBlocks) || s2.forEach((e11) => {
              r2 > 0 && ((0, eS.v)(e11.meta) || ei(e11.type)) && (r2--, o2.push(t10.getBlock(e11)));
            }), null == (l2 = e10.tabs.data) || l2.forEach((e11) => {
              e11.blocks.slice(0, r2).forEach((e12) => {
                ((0, eS.v)(e12.meta) || ei(e12.type)) && o2.push(t10.getBlock(e12));
              });
            }), o2.length > 0 && await Promise.allSettled(o2);
          },
          getChildrenSkeleton: (0, r.L3)(function* (t11) {
            let { childrenLandingResource: a2, modelActionsLogger: l2 } = (0, r._$)(e10), { experiments: n2 } = (0, r.Zn)(e10);
            try {
              e10.loadingState = G.GuX.PENDING;
              let l3 = yield a2.getSkeleton(t11), d2 = n2.checkExperiment(G.zal.WebNextWaveAgentExperiment, "on"), c2 = ((e11, t12) => {
                let a3 = { loadingState: G.GuX.RESOLVE, isLoading: false };
                return a3.meta = { selectedTabIndex: 0 }, a3.tabs = {
                  loadingState: G.GuX.RESOLVE,
                  data: [
                    {
                      meta: { id: e11.title, title: e11.title },
                      shouldReloadNotification: false,
                      blocks: e11.blocks.filter((e12) => {
                        let t13;
                        return t13 = e12.type, Object.values(i).includes(t13);
                      }).map(
                        (e12) => ((e13, t13) => {
                          let a4, l4, n3, { isWaveAgentEnabled: d3 } = t13, c3 = {
                            loadingState: I.RESOLVE,
                            id: e13.id,
                            type: void 0,
                            meta: (a4 = e13, (0, r.wg)({
                              title: a4.title,
                              viewAllActionLink: a4.viewAllUrl,
                              showPolicy: L.E.SHOW_AND_LOAD
                            })),
                            data: void 0,
                            isNeededToLoad: false,
                            isLoading: false,
                            isLoaded: true,
                            isRejected: false,
                            isVisible: true,
                            isNotFound: false,
                            hasSentAnalyticsOnLoaded: false,
                            objectsCount: e13.entities.length,
                            setHasSentAnalyticsOnLoaded: () => {
                            }
                          };
                          switch (e13.type) {
                            case i.RADIO: {
                              let t14, a5 = d3 ? s.t.EDITORIAL_WAVES_AGENT : s.t.EDITORIAL_WAVES;
                              if ((t14 = e13.entities)[0] && "data" in t14[0] && "object" == typeof t14[0].data && t14[0].data && "data" in t14[0].data) {
                                let t15;
                                return (0, r.wg)({
                                  ...c3,
                                  type: a5,
                                  data: (t15 = e13.entities, (0, r.wg)({
                                    items: t15.map((e14) => {
                                      var t16, a6, i2, s2, l5, o2;
                                      let n4 = (null == (i2 = e14.data.data) || null == (a6 = i2.station) || null == (t16 = a6.icon) ? void 0 : t16.backgroundColor) ? (0, C.ye)(G.Sxu.Dark, e14.data.data.station.icon.backgroundColor) : void 0;
                                      return (0, r.wg)({
                                        title: null == (l5 = e14.data.data) || null == (s2 = l5.station) ? void 0 : s2.name,
                                        backgroundImageUrl: "avatars.mds.yandex.net/get-music-misc/34161/custom-wave-default-waves-background.image/%%",
                                        seeds: [null != (o2 = e14.data.blockEntityDataId) ? o2 : ""],
                                        colors: { average: n4 },
                                        agent: (0, g.KU)(e14.data.data.agent)
                                      });
                                    })
                                  }))
                                });
                              }
                              return (0, r.wg)({ ...c3, type: a5 });
                            }
                            case i.PROMOTIONS:
                              if ((l4 = e13.entities) && l4[0] && "promoId" in l4[0].data) {
                                let t14;
                                return (0, r.wg)({
                                  ...c3,
                                  type: s.t.PROMOTIONS,
                                  data: (t14 = e13.entities, (0, r.wg)({
                                    items: t14.map((e14) => {
                                      var t15, a5, i2, s2, l5;
                                      return (0, r.wg)({
                                        featureId: null != (t15 = e14.data.promoId) ? t15 : "",
                                        title: null != (a5 = e14.data.title) ? a5 : "",
                                        subtitle: null != (i2 = e14.data.subtitle) ? i2 : "",
                                        imageUrl: null != (s2 = e14.data.image) ? s2 : "",
                                        weblink: null != (l5 = e14.data.url) ? l5 : ""
                                      });
                                    })
                                  }))
                                });
                              }
                              return (0, r.wg)({ ...c3, type: s.t.PROMOTIONS });
                            case i.EDITORIAL_PLAYLISTS:
                              if ((n3 = e13.entities) && n3[0] && "artists" in n3[0].data) {
                                let t14;
                                return (0, r.wg)({
                                  ...c3,
                                  type: s.t.NON_MUSIC_EDITORIAL_COMPILATION,
                                  data: (t14 = e13.entities, (0, r.wg)({
                                    items: t14.map((e14) => {
                                      var t15, a5, i2;
                                      let s2 = e14.data.type && Object.values(en._).includes(e14.data.type) ? e14.data.type : void 0, l5 = !e14.data.availableForPremiumUsers && e14.data.availableForOptions.includes(ed.E.BOOKMATE), n4 = e14.data.disclaimers && em(e14.data.disclaimers) ? e14.data.disclaimers : void 0;
                                      return (0, r.wg)({
                                        type: o._.NON_MUSIC_ALBUM_ITEM,
                                        data: {
                                          id: e14.data.id,
                                          title: null != (a5 = e14.data.title) ? a5 : "",
                                          type: s2,
                                          likesCount: e14.data.likesCount,
                                          isAvailable: null == (i2 = e14.data.available) || i2,
                                          coverUri: e14.data.coverUri,
                                          availableForPremiumUsers: e14.data.availableForPremiumUsers,
                                          availableForOptions: e14.data.availableForOptions,
                                          genre: e14.data.genre,
                                          bestAlbumTracks: e14.data.bests,
                                          bookmateOptionRequired: l5,
                                          trackCount: e14.data.trackCount,
                                          year: e14.data.year,
                                          listeningFinished: e14.data.listeningFinished,
                                          disclaimers: n4,
                                          artists: null == (t15 = e14.data.artists) ? void 0 : t15.map(eu)
                                        }
                                      });
                                    })
                                  }))
                                });
                              }
                              if (eo(e13.entities)) {
                                let t14;
                                return (0, r.wg)({
                                  ...c3,
                                  type: s.t.NON_MUSIC_EDITORIAL_COMPILATION,
                                  data: (t14 = e13.entities, (0, r.wg)({
                                    items: t14.map((e14) => {
                                      var t15, a5, i2;
                                      return (0, r.wg)({
                                        type: o._.LIKED_PLAYLIST_ITEM,
                                        data: {
                                          uuid: null != (a5 = e14.data.playlistUuid) ? a5 : "",
                                          isAvailable: null == (i2 = e14.data.available) || i2,
                                          uid: e14.data.uid,
                                          kind: e14.data.kind,
                                          revision: e14.data.revision,
                                          title: e14.data.title,
                                          coverUri: null == (t15 = e14.data.cover) ? void 0 : t15.uri,
                                          likesCount: e14.data.likesCount,
                                          tracksCount: e14.data.trackCount,
                                          visibility: e14.data.visibility
                                        }
                                      });
                                    })
                                  }))
                                });
                              }
                              return (0, r.wg)({ ...c3, type: s.t.NON_MUSIC_EDITORIAL_COMPILATION });
                            case i.PLAYLIST_WITH_TRACKS:
                              if (eo(e13.entities) && e13.entities[0]) {
                                var m2, u2;
                                return (0, r.wg)({
                                  ...c3,
                                  type: s.t.OPEN_PLAYLIST,
                                  data: (m2 = e13.entities[0], (0, r.wg)({
                                    items: m2.data.tracks.map((e14) => {
                                      let { track: t14 } = e14;
                                      return (0, C.vU)(t14);
                                    }),
                                    playlist: (0, e_.jX)(m2.data),
                                    coverUri: null == (u2 = m2.data.cover) ? void 0 : u2.uri
                                  }))
                                });
                              }
                              return (0, r.wg)({ ...c3, type: s.t.OPEN_PLAYLIST });
                          }
                        })(e12, t12)
                      )
                    }
                  ]
                }, (0, r.wg)(a3);
              })(l3, { isWaveAgentEnabled: d2 });
              c2 && (e10.id = l3.category, e10.title = l3.title, e10.meta = (0, r.wg)(c2.meta), e10.tabs.data = (0, r.wg)(c2.tabs.data)), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.RESOLVE);
            } catch (t12) {
              l2.error(t12), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.REJECT);
            }
          }),
          getSkeleton: (0, r.L3)(function* (a2, i2) {
            let { landingResource: s2, modelActionsLogger: l2 } = (0, r._$)(e10);
            if (e10.loadingState !== G.GuX.PENDING)
              try {
                e10.loadingState = G.GuX.PENDING;
                let l3 = yield s2.getSkeleton(a2), o2 = ew(null == l3 ? void 0 : l3.blocks);
                o2 && (e10.id = l3.id, e10.title = l3.title, e10.meta = (0, r.wg)(o2.meta), e10.upperBlocks = (0, r.wg)(o2.upperBlocks), e10.tabs.data = (0, r.wg)(o2.tabs.data), yield t10.prefetchBlocks(null == i2 ? void 0 : i2.preloadBlocksCount)), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.RESOLVE);
              } catch (t11) {
                l2.error(t11), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.REJECT);
              }
          }),
          getArtistSkeleton: (0, r.L3)(function* (a2, i2) {
            let { artistsResource: s2, modelActionsLogger: l2 } = (0, r._$)(e10);
            if (e10.loadingState !== G.GuX.PENDING)
              try {
                e10.loadingState = G.GuX.PENDING;
                let l3 = yield s2.getSkeleton(a2), o2 = ew(null == l3 ? void 0 : l3.blocks);
                o2 && (e10.id = l3.id, e10.title = l3.title, e10.meta = (0, r.wg)(o2.meta), e10.upperBlocks = (0, r.wg)(o2.upperBlocks), void 0 !== o2.tabs && (e10.tabs.data = (0, r.wg)(o2.tabs.data)), yield t10.prefetchBlocks(null == i2 ? void 0 : i2.preloadBlocksCount)), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.RESOLVE);
              } catch (t11) {
                l2.error(t11), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.REJECT);
              }
          }),
          getConcertSkeleton: (0, r.L3)(function* (a2, i2) {
            let { concertsResource: s2, modelActionsLogger: l2 } = (0, r._$)(e10);
            if (e10.loadingState !== G.GuX.PENDING)
              try {
                e10.loadingState = G.GuX.PENDING;
                let l3 = yield s2.getSkeleton(a2), o2 = ew(null == l3 ? void 0 : l3.blocks);
                o2 && (e10.id = l3.id, e10.title = l3.title, e10.meta = (0, r.wg)(o2.meta), e10.upperBlocks = (0, r.wg)(o2.upperBlocks), void 0 !== o2.tabs && (e10.tabs.data = (0, r.wg)(o2.tabs.data)), yield t10.prefetchBlocks(null == i2 ? void 0 : i2.preloadBlocksCount)), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.RESOLVE);
              } catch (t11) {
                l2.error(t11), e10.loadingState !== G.GuX.IDLE && (e10.loadingState = G.GuX.REJECT);
              }
          }),
          reset() {
            e10.loadingState = G.GuX.IDLE, e10.meta = null, e10.tabs.reset(), e10.upperBlocks = null;
          }
        };
        return t10;
      });
      a(14170);
      var aG = a(62277), aW = a(84359), aX = a(7333), aF = a(94124), aH = a(25743), az = a(52239), a$ = a(4111), aq = a(20773), aJ = a(34282);
    },
    6197: (e, t, a) => {
      "use strict";
      a.d(t, { A: () => A });
      var i = a(54486), s = a(50420), l = a(28303), r = a(61910), o = a(27510), n = a(74125), d = a(80585), c = a(29715), m = a.n(c);
      let u = (0, l.PA)((e2) => {
        let { className: t2, isActive: a2 = true, shimmerClassName: l2 } = e2;
        return (0, i.jsx)(d.wI, {
          className: (0, s.$)(m().root, t2),
          isShimmerVisible: true,
          value: 0,
          shimmer: (0, i.jsx)(d.zr, {
            className: (0, s.$)(m().root, l2),
            shimmerClassName: m().shimmer,
            count: 3,
            isActive: a2
          })
        });
      });
      var _ = a(66049), g = a.n(_);
      let p = { [n.u40.Desktop]: { start: 40, end: 20 }, [n.u40.Mobile]: { start: 40, end: 40 } }, b = { [n.u40.Desktop]: { start: 40, end: 20 }, [n.u40.Mobile]: { start: 20, end: 50 } }, v = (0, l.PA)((e2) => {
        let {
          tabsState: t2,
          handleFilterClick: a2,
          className: l2,
          forwardRef: c2,
          carouselClassName: m2,
          shimmerClassName: _2,
          isSticky: v2,
          items: A2,
          isShimmerVisible: T,
          isShimmerActive: C,
          skipSearchCheck: h = false
        } = e2, {
          playlist: I,
          settings: { isMobile: L }
        } = (0, n.Pjs)(), { playlistStickyFiltersRef: y, playlistStaticFiltersRef: S, contentScrollRef: E } = (0, n.gKY)(), N = null != A2 ? A2 : I.filters.items, j = (0, o.L)(
          () => (0, i.jsx)(d.wI, {
            ref: c2,
            className: (0, s.$)(g().carousel, m2),
            ...t2,
            onTabChange: a2,
            children: null == N ? void 0 : N.map(
              (e3, a3) => (0, i.jsx)(
                d.oz,
                {
                  tabIndex: v2 ? -1 : 0,
                  className: (0, s.$)(g().filter, { [g().filter_selected]: a3 === t2.value }),
                  title: e3.name,
                  value: a3
                },
                a3
              )
            )
          })
        ), k = (0, r.useCallback)(() => {
          S && y && (S.scrollLeft = y.scrollLeft);
        }, [S, y]), x = (0, r.useCallback)(() => {
          S && y && (y.classList.add(g().carousel_noSmooth), y.scrollLeft = S.scrollLeft, y.classList.remove(g().carousel_noSmooth));
        }, [S, y]), [R, f] = (0, r.useState)(false);
        (0, r.useEffect)(() => {
          R && x();
        }, [R, x]);
        let P = (0, r.useCallback)(() => {
          f((null == y ? void 0 : y.checkVisibility({ checkOpacity: true })) || false);
        }, [y]);
        return (0, r.useEffect)(() => {
          let e3 = new AbortController(), t3 = { signal: e3.signal };
          return v2 ? (null == y || y.addEventListener("scroll", k, t3), null == y || y.addEventListener("resize", k, t3)) : L ? (window.addEventListener("scroll", P, t3), window.addEventListener("resize", P, t3)) : (null == E || E.addEventListener("scroll", P, t3), null == E || E.addEventListener("resize", P, t3)), () => {
            e3.abort();
          };
        }, [v2, E, y, P, k, L]), (null != T ? T : I.filters.isShimmerVisible) ? (0, i.jsx)(u, { isActive: null == C || C, shimmerClassName: _2 }) : N && 0 !== N.length && (h || I.search.isNeededToLoad) ? (0, i.jsx)(d.FY, { className: l2, carouselElement: j, ref: c2, scrollPadding: v2 ? b : p }) : void 0;
      }), A = (0, r.forwardRef)((e2, t2) => (0, i.jsx)(v, { forwardRef: t2, ...e2 }));
    },
    6789: (e) => {
      e.exports = {
        root: "NewReleaseCard_root__IY5m_",
        ripple: "NewReleaseCard_ripple__VoybZ",
        image: "NewReleaseCard_image__oxm2S",
        info: "NewReleaseCard_info__rcfoY",
        type: "NewReleaseCard_type__cW58D",
        title: "NewReleaseCard_title__N5soS",
        description: "NewReleaseCard_description__Daz5q",
        container: "NewReleaseCard_container__XvwZC",
        explicitMark: "NewReleaseCard_explicitMark__isgxE",
        explicitMarkContainer: "NewReleaseCard_explicitMarkContainer__QHRoH",
        button: "NewReleaseCard_button__WPk82",
        paperLink: "NewReleaseCard_paperLink__NN_8o"
      };
    },
    7333: (e, t, a) => {
      "use strict";
      a.d(t, { S: () => c });
      var i = a(54486), s = a(61910), l = a(43350), r = a(94376), o = a(74125), n = a(80585);
      let d = (e2) => {
        let {
          forwardRef: t2,
          isShimmerVisible: a2,
          isShimmerActive: s2,
          containerClassName: d2,
          headerClassName: c2,
          meta: m,
          data: u,
          headingVariant: _,
          className: g,
          ...p
        } = e2;
        return (0, i.jsx)(n.OY, {
          className: g,
          ...p,
          isShimmerVisible: a2,
          isShimmerActive: s2,
          headerClassName: c2,
          containerClassName: d2,
          title: m.title,
          description: m.description,
          viewAllActionLink: m.viewAllActionLink,
          ref: t2,
          headingVariant: _,
          children: null == u ? void 0 : u.items.map(
            (e3, t3) => (0, i.jsx)(
              o.Bki,
              {
                objectType: l.ky.Album,
                objectId: String(e3.id),
                objectPosX: t3 + 1,
                objectPosY: 1,
                objectsCount: u.items.length,
                children: (0, i.jsx)(r.aX, {
                  album: e3,
                  contentLinesCount: 3,
                  withLikesCount: true,
                  withChart: true,
                  withAddition: false
                })
              },
              e3.id
            )
          )
        });
      }, c = (0, s.forwardRef)((e2, t2) => (0, i.jsx)(d, { forwardRef: t2, ...e2 }));
    },
    7809: (e) => {
      e.exports = {
        root: "MixCard_root__9tPLV",
        header: "MixCard_header__j7Zpo",
        title: "MixCard_title__nhghp",
        cover: "MixCard_cover__oSu73",
        covers: "MixCard_covers__S61hz",
        covers_stack: "MixCard_covers_stack__VeHDp",
        covers_radial: "MixCard_covers_radial__orE40"
      };
    },
    8008: (e) => {
      e.exports = {
        container: "SkeletonBlock_container__9IxUi",
        important: "SkeletonBlock_important__faY0E",
        container_withContentVisibility: "SkeletonBlock_container_withContentVisibility__QzL5d",
        headerContainer: "SkeletonBlock_headerContainer__fl8EX",
        tracksContainer: "SkeletonBlock_tracksContainer__uF8Tg"
      };
    },
    11090: (e, t, a) => {
      "use strict";
      var i;
      a.d(t, { l: () => i }), (function(e2) {
        e2.PLAYLIST_LIKED_TAB = "liked_playlist_tab", e2.PLAYLIST_CREATED_TAB = "created_playlist_tab";
      })(i || (i = {}));
    },
    12110: (e) => {
      e.exports = {
        root: "NewRelease_root__W0T4a",
        image: "NewRelease_image__Vw6_k",
        cover: "NewRelease_cover__EVFNR",
        coverImage: "NewRelease_coverImage__9x6Uk",
        card: "NewRelease_card__yn06x",
        fade: "NewRelease_fade__rVE0_",
        artists: "NewRelease_artists__wGTaP",
        artistLink: "NewRelease_artistLink__CO3Zn",
        artistCaption: "NewRelease_artistCaption__1F8A9",
        trailerButton: "NewRelease_trailerButton__OYAW6",
        descriptionContainer: "NewRelease_descriptionContainer__g56GG"
      };
    },
    13991: (e) => {
      e.exports = {
        root: "BlockEntities_root__sHn14",
        scrollableContent: "BlockEntities_scrollableContent__4A0tK",
        scrollableContainer: "BlockEntities_scrollableContainer__KXyas",
        container: "BlockEntities_container__1XiOc",
        content: "BlockEntities_content__bfoTn",
        shimmerWithSubcover: "BlockEntities_shimmerWithSubcover__dYd6P",
        footer: "BlockEntities_footer__eEuix"
      };
    },
    14170: (e, t, a) => {
      "use strict";
      a.d(t, { Concert: () => T });
      var i = a(54486), s = a(50420), l = a(61910), r = a(43426), o = a(43350), n = a(8817), d = a(62443), c = a(58360), m = a(6971), u = a(39610), _ = a(97800), g = a(77217), p = a(74125), b = a(66417), v = a.n(b), A = (function(e2) {
        return e2.SPACE = "Space", e2.ENTER = "Enter", e2;
      })(A || {});
      let T = (e2) => {
        let { concert: t2 } = e2, {
          title: a2,
          datetime: b2,
          city: A2,
          place: T2,
          contentRating: C,
          cover: h,
          dataSessionId: I,
          rank: L,
          isCashbackExperimentEnabled: y,
          cashbackTitle: S
        } = t2, { formatDate: E } = (0, r.A)(), { ref: N, intersectionPropertyId: j } = (0, p.nMI)(), k = (0, p.NKK)(), { state: x, toggleTrue: R, toggleFalse: f } = (0, d.e)(false), { experiments: P } = (0, p.Pjs)(), { href: w } = (0, p.uvd)("/concert/:concertId", { params: { concertId: t2.id } }), K = (0, p.ZpR)(w), O = P.checkExperiment(p.zal.WebNextConcertPage, "on"), M = (0, l.useMemo)(() => {
          if (y && S)
            return (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsx)(u.q, { children: E(b2, (0, p.fS8)()) }),
                (0, i.jsxs)(_.Caption, {
                  variant: "span",
                  type: "text",
                  size: "m",
                  weight: "medium",
                  className: v().descriptionContainer,
                  children: [
                    (0, i.jsx)(_.Caption, {
                      variant: "span",
                      type: "text",
                      size: "m",
                      weight: "medium",
                      lineClamp: 1,
                      className: v().description,
                      children: T2
                    }),
                    (0, i.jsx)(_.Caption, {
                      variant: "span",
                      type: "text",
                      size: "m",
                      weight: "medium",
                      className: v().description,
                      "aria-hidden": true,
                      children: " • "
                    }),
                    C && (0, i.jsx)(_.Caption, {
                      variant: "span",
                      type: "text",
                      size: "m",
                      weight: "medium",
                      className: v().description,
                      children: C
                    })
                  ]
                }),
                (0, i.jsx)(g.mi, { className: v().cashback, title: S })
              ]
            });
          let e3 = [];
          return b2 && e3.push(E(b2, (0, p.fS8)())), C && e3.push(C), (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)(_.Caption, {
                variant: "span",
                type: "text",
                size: "m",
                weight: "medium",
                lineClamp: 1,
                className: v().description,
                children: T2
              }),
              (0, i.jsxs)(u.q, { children: [E(b2, (0, p.fS8)()), " ", C] }),
              (0, i.jsx)(_.Caption, {
                variant: "span",
                type: "text",
                size: "m",
                weight: "medium",
                lineClamp: 1,
                className: v().description,
                "aria-hidden": true,
                children: e3.join(" • ")
              })
            ]
          });
        }, [S, C, b2, E, y, T2]), D = (0, l.useCallback)(
          (e3) => {
            k({ to: o.QT.ConcertPurchaseScreen }), R(), null == e3 || e3.stopPropagation();
          },
          [R, k]
        ), B = (0, n.c)((e3) => {
          if (!O) return void D(e3);
          K(e3);
        }), V = (0, l.useCallback)(
          (e3) => {
            ("Space" === e3.code || "Enter" === e3.code) && (e3.preventDefault(), B());
          },
          [B]
        );
        return (0, i.jsxs)(i.Fragment, {
          children: [
            (0, i.jsxs)(m.Paper, {
              className: v().root,
              style: ((e3) => {
                let t3;
                if (e3) {
                  let { h: a3, s: i2, l: s2 } = (0, p.g8k)(e3);
                  t3 = "linear-gradient(\n            180deg, \n            transparent 0%, \n            hsla(".concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0) 40%, \n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0.1) 43%,\n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0.2) 46%,\n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0.3) 49%,\n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0.4) 52%,\n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0.5) 55%,\n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0.6) 58%,\n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0.7) 61%,\n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0.8) 64%,\n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 0.9) 67%, \n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 1) 70%, \n            hsla(").concat(a3, "deg, ").concat(i2, "%, ").concat(s2, "%, 1) 100%\n        )");
                }
                return { "--concert-card-linear-gradient": t3 };
              })(null == h ? void 0 : h.color),
              radius: "l",
              role: "button",
              tabIndex: 0,
              onClick: B,
              onKeyDown: V,
              ref: N,
              "data-intersection-property-id": j,
              children: [
                (0, i.jsx)(c.Image, {
                  className: v().cover,
                  src: null == h ? void 0 : h.uri,
                  size: 400,
                  fit: "cover",
                  withAvatarReplace: true,
                  withLoadingIndicator: false
                }),
                void 0 !== L && (0, i.jsx)(_.Caption, {
                  variant: "span",
                  size: "l",
                  weight: "bold",
                  className: (0, s.$)(v().index, v().title),
                  "aria-hidden": true,
                  children: L
                }),
                (0, i.jsxs)("div", {
                  className: v().meta,
                  children: [
                    (0, i.jsx)(_.Heading, {
                      variant: "h3",
                      size: "xs",
                      weight: "bold",
                      lineClamp: 3,
                      className: (0, s.$)(v().title, v().concertTitle),
                      children: a2
                    }),
                    (0, i.jsxs)("div", {
                      className: v().textContainer,
                      children: [
                        b2 && (0, i.jsx)(g.dE, {
                          datetime: b2,
                          className: v().date,
                          monthClassName: v().description,
                          dayClassName: v().title,
                          withWeekday: false
                        }),
                        (0, i.jsxs)("div", {
                          className: v().info,
                          children: [
                            (0, i.jsx)(_.Caption, {
                              variant: "span",
                              type: "controls",
                              size: "m",
                              weight: "medium",
                              lineClamp: 1,
                              className: v().title,
                              children: A2
                            }),
                            M
                          ]
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            (0, i.jsx)(g.hW, { dataSessionId: I, isOpened: x, onOpen: R, onClose: f })
          ]
        });
      };
    },
    15136: (e) => {
      e.exports = { root: "VirtualGridRow_root___UfbI" };
    },
    17390: (e, t, a) => {
      "use strict";
      var i;
      a.d(t, { E: () => i }), (function(e2) {
        e2.SHOW_AND_LOAD = "SHOW_AND_LOAD", e2.LOAD_AND_SHOW = "LOAD_AND_SHOW";
      })(i || (i = {}));
    },
    17813: (e) => {
      e.exports = {
        root: "Promotions_root__Osgj2",
        controls: "Promotions_controls__IEqvq",
        item: "Promotions_item__ycc9P",
        important: "Promotions_important__x_kQK"
      };
    },
    20645: (e) => {
      e.exports = { trailer: "PlaylistWithTracks_trailer__dOp1u", root: "PlaylistWithTracks_root__jchZL" };
    },
    20773: (e, t, a) => {
      "use strict";
      a.d(t, { Skeleton: () => sr });
      var i, s = a(54486), l = a(50420), r = a(28303), o = a(97396), n = a(61910), d = a(31500), c = a(8817), m = a(85360), u = a(51321), _ = a(74125), g = a(80585), p = a(46758), b = a(72107), v = a(27510), A = a(8008), T = a.n(A), C = a(35620), h = a(43350), I = a(43426), L = a(47713), y = a(63585);
      !(function(e10) {
        e10.TOP = "top", e10.CENTER = "center";
      })(i || (i = {}));
      var S = a(6971), E = a(97800), N = a(46423), j = a(63695), k = a(3892), x = a.n(k);
      let R = (0, r.PA)((e10) => {
        let { promo: t10 } = e10, { formatMessage: a10 } = (0, I.A)(), { ref: r2, intersectionPropertyId: o2 } = (0, _.nMI)(), n2 = (0, _.NKK)(), m2 = (0, _.ZpR)(t10.albumUrl), u2 = (0, N.cp)({ album: t10.album, callback: m2 }), p2 = (0, _.brA)(), b2 = (0, _.PT7)(), { from: v2 } = (0, _.fyy)({ contextId: t10.album.id, contextType: y.K.Album }), { isPlaying: A2, togglePlay: T2 } = (0, _.Dx4)({
          playContextParams: {
            contextData: {
              type: y.K.Album,
              meta: { id: t10.album.id },
              from: v2,
              utmLink: (0, _.ZQO)(t10.reportingProperties)
            },
            loadContextMeta: true
          }
        }), C2 = (0, c.c)((e11) => {
          t10.setClicked(), n2({ to: h.QT.AlbumScreen }), u2(e11);
        }), k2 = (0, c.c)(() => {
          t10.setClicked(), T2();
        }), R2 = (0, N.cp)({ album: t10.album, callback: k2 }), f2 = (0, c.c)(() => {
          b2() || (R2(), p2(!A2));
        }), P2 = a10({ id: "entity-names.album-name" }, { albumName: t10.album.title }), w2 = t10.coverContentMode === i.TOP;
        return (0, s.jsxs)("div", {
          className: x().root,
          ref: r2,
          "data-intersection-property-id": o2,
          ...(0, d.Am)(d.Kq.albumPromo.ALBUM_PROMO_CARD),
          children: [
            (0, s.jsxs)(S.Paper, {
              className: x().artistCover,
              radius: "m",
              withShadow: true,
              ...(0, d.Am)(d.Kq.albumPromo.ALBUM_PROMO_CARD_ARTIST_COVER),
              children: [
                (0, s.jsx)(g.N_, {
                  className: x().artistLink,
                  href: t10.albumUrl,
                  onClick: C2,
                  "aria-label": P2,
                  children: (0, s.jsx)(g.BW, {
                    className: (0, l.$)(x().artistImage, { [x().artistImage_withTopPosition]: w2 }),
                    src: t10.cover.uri,
                    withAvatarReplace: true,
                    withAspectRatio: true,
                    size: 600,
                    fit: "cover",
                    "aria-hidden": true
                  })
                }),
                (0, s.jsx)(S.Paper, {
                  className: x().albumCover,
                  radius: "xs",
                  ...(0, d.Am)(d.Kq.albumPromo.ALBUM_PROMO_CARD_ALBUM_COVER),
                  children: (0, s.jsx)(g.N_, {
                    className: x().albumLink,
                    href: t10.albumUrl,
                    onClick: C2,
                    "aria-label": P2,
                    children: (0, s.jsx)(g.BW, {
                      className: x().albumImage,
                      src: t10.album.coverUri,
                      withAvatarReplace: true,
                      size: 300,
                      fit: "cover",
                      "aria-hidden": true
                    })
                  })
                }),
                (0, s.jsx)(g.DM, {
                  className: x().button,
                  withRipple: false,
                  withHover: false,
                  buttonVariant: "default",
                  radius: "xxxl",
                  size: "default",
                  color: "secondary",
                  iconSize: "xxs",
                  isPlaying: A2,
                  onClick: f2,
                  iconClassName: x().buttonIcon,
                  disabled: !t10.album.isAvailable,
                  children: (0, s.jsx)(E.Caption, {
                    className: x().buttonText,
                    variant: "span",
                    type: "controls",
                    size: "m",
                    weight: "medium",
                    children: (0, s.jsx)(L.A, { id: "player-actions.listen" })
                  })
                })
              ]
            }),
            (0, s.jsxs)("div", {
              className: x().meta,
              children: [
                (0, s.jsxs)("div", {
                  className: x().titleContainer,
                  ...(0, d.Am)(d.Kq.albumPromo.ALBUM_PROMO_CARD_TITLE),
                  children: [
                    (0, s.jsx)(E.Caption, {
                      className: x().title,
                      variant: "div",
                      lineClamp: 1,
                      type: "entity",
                      size: "s",
                      weight: "medium",
                      children: (0, s.jsx)(g.N_, {
                        className: x().titleLink,
                        href: t10.albumUrl,
                        onClick: C2,
                        ...(0, d.Am)(d.Kq.albumPromo.ALBUM_PROMO_CARD_TITLE_LINK),
                        children: t10.album.title
                      })
                    }),
                    t10.album.explicitDisclaimer && (0, s.jsx)(g.Nq, {
                      getDescriptionTexts: t10.album.getDescriptionTexts,
                      variant: t10.album.explicitDisclaimer,
                      size: "xxxs"
                    })
                  ]
                }),
                (0, s.jsx)(j.iQ, {
                  className: x().artists,
                  linkClassName: x().artistsLink,
                  artists: t10.artists,
                  lineClamp: 1,
                  captionSize: "s"
                })
              ]
            })
          ]
        });
      });
      var f = a(15209), P = a(81203), w = a(88834), K = {
        1964: (e10) => {
          e10.exports = w;
        }
      }, O = {}, M = {};
      (() => {
        Object.defineProperty(M, "X", { value: true }), M.q = void 0;
        var e10 = (function e11(t10) {
          var a10 = O[t10];
          if (void 0 !== a10) return a10.exports;
          var i10 = O[t10] = { exports: {} };
          return K[t10](i10, i10.exports, e11), i10.exports;
        })(1964);
        Object.defineProperty(M, "q", {
          enumerable: true,
          get: function() {
            return e10.useMergeRefs;
          }
        });
      })(), M.X;
      var D = M.q;
      let B = (e10) => {
        let t10, { callback: a10, visibleTime: i10, threshold: s2 } = e10;
        return (0, m.Gv)(
          (e11, s3) => {
            e11.isIntersecting && (t10 = setTimeout(() => {
              a10(), s3.disconnect();
            }, i10)), e11.isIntersecting || clearTimeout(t10);
          },
          { threshold: s2 }
        );
      };
      var V = a(29206), U = a.n(V);
      let Y = (e10) => {
        let {
          forwardRef: t10,
          isLoaded: a10,
          setOutdated: i10,
          headerClassName: r2,
          containerClassName: o2,
          data: d2,
          meta: c2,
          headingVariant: m2,
          className: u2,
          children: _2,
          ...p2
        } = e10, { intersectionPropertyId: b2, ref: v2 } = ((e11) => {
          let { forwardedRef: t11, isLoaded: a11, data: i11, setOutdated: s2 } = e11, { report: l2, reporting: r3 } = null != i11 ? i11 : {}, { ref: o3, intersectionPropertyId: d3 } = ((e12) => {
            let { params: t12, isLoaded: a12 } = e12, i12 = (0, n.useRef)(null), s3 = (0, n.useId)(), l3 = (0, n.useMemo)(() => {
              if (a12) return t12.map(B);
            }, [a12, t12]);
            return (0, n.useEffect)(
              () => (null == l3 || l3.forEach((e13) => {
                i12.current && e13.observe(i12.current);
              }), () => {
                null == l3 || l3.forEach((e13) => {
                  e13.disconnect();
                });
              }),
              [l3]
            ), { intersectionPropertyId: s3, ref: i12 };
          })({
            isLoaded: a11,
            params: (0, n.useMemo)(() => {
              var e12, t12, a12;
              return [
                {
                  threshold: 0,
                  visibleTime: null != (e12 = null == r3 ? void 0 : r3.blockRender.timeMs) ? e12 : 0,
                  callback: () => {
                    let e13 = null == r3 ? void 0 : r3.blockRender.url;
                    e13 && (null == l2 || l2(e13));
                  }
                },
                {
                  threshold: 0.5,
                  visibleTime: null != (t12 = null == r3 ? void 0 : r3.blockImpression.timeMs) ? t12 : 2100,
                  callback: () => {
                    let e13 = null == r3 ? void 0 : r3.blockImpression.url;
                    e13 && (null == l2 || l2(e13)), s2();
                  }
                },
                {
                  threshold: 0,
                  visibleTime: null != (a12 = null == r3 ? void 0 : r3.adImpressions.timeMs) ? a12 : 2100,
                  callback: () => {
                    let e13 = null == r3 ? void 0 : r3.adImpressions.url;
                    e13 && (null == l2 || l2(e13));
                  }
                }
              ];
            }, [
              l2,
              null == r3 ? void 0 : r3.adImpressions.timeMs,
              null == r3 ? void 0 : r3.adImpressions.url,
              null == r3 ? void 0 : r3.blockImpression.timeMs,
              null == r3 ? void 0 : r3.blockImpression.url,
              null == r3 ? void 0 : r3.blockRender.timeMs,
              null == r3 ? void 0 : r3.blockRender.url,
              s2
            ])
          });
          return { intersectionPropertyId: d3, ref: D([o3, t11]) };
        })({ forwardedRef: t10, data: d2, isLoaded: a10, setOutdated: i10 }), A2 = (0, n.useRef)(null);
        return (0, s.jsxs)("section", {
          className: (0, l.$)(U().root, u2),
          ref: v2,
          "data-intersection-property-id": b2,
          ...(0, f.getDataAttrFromProps)(p2),
          children: [
            (0, s.jsx)(g.Tw, {
              className: r2,
              title: c2.title,
              controls: (0, s.jsx)(g.X9, { className: U().controls, carouselRef: A2 }),
              headingVariant: m2
            }),
            (0, s.jsx)(P.Carousel, {
              className: o2,
              ref: A2,
              itemClassName: (0, l.$)(U().item, U().important),
              children: _2
            })
          ]
        });
      }, G = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(Y, { forwardRef: t10, ...e10 })), W = (e10) => {
        let { forwardRef: t10, data: a10, ...i10 } = e10;
        return (0, s.jsx)(G, {
          ref: t10,
          data: a10,
          ...i10,
          children: null == a10 ? void 0 : a10.items.map(
            (e11, t11) => (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Album,
                objectId: String(e11.album.id),
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: null == a10 ? void 0 : a10.items.length,
                children: (0, s.jsx)(R, { promo: e11 })
              },
              e11.album.getKey(t11)
            )
          )
        });
      }, X = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(W, { forwardRef: t10, ...e10 }));
      var F = a(73633), H = a(6789), z = a.n(H);
      let $ = (0, r.PA)((e10) => {
        let {
          className: t10,
          forwardRef: a10,
          album: i10,
          description: r2,
          trailerButton: o2,
          entityName: m2,
          onClick: u2,
          albumUrl: p2,
          from: b2,
          utmLink: v2,
          coverColor: A2,
          ...T2
        } = e10, C2 = (0, _.ZpR)(p2), L2 = (0, _.PT7)(), j2 = (0, _.brA)(), { formatMessage: k2 } = (0, I.A)(), { isPlaying: x2, togglePlay: R2 } = (0, _.Dx4)({
          playContextParams: {
            contextData: { type: y.K.Album, meta: { id: i10.id }, from: b2, utmLink: v2 },
            loadContextMeta: true
          }
        }), P2 = (0, c.c)(() => {
          null == u2 || u2(), R2();
        }), w2 = (0, N.cp)({ album: i10, callback: C2 }), K2 = (0, N.cp)({ album: i10, callback: P2 }), O2 = (0, _.NKK)(), M2 = (0, c.c)((e11) => {
          (0, F.P)(e11, z().ripple), e11.stopPropagation(), null == u2 || u2(), O2({ to: h.QT.AlbumScreen }), w2(e11);
        }), D2 = (0, c.c)(() => {
          L2() || (K2(), j2(!x2));
        }), B2 = (0, n.useMemo)(() => {
          let e11;
          if (A2) {
            let { h: t11, s: a11 } = (0, _.g8k)(A2);
            e11 = "hsl(".concat(t11, ", ").concat(a11, "%, ", 20, "%)");
          }
          return { "--new-release-cover-color": e11, "--new-release-color": null == i10 ? void 0 : i10.averageColor };
        }, [null == i10 ? void 0 : i10.averageColor, A2]), V2 = m2 ? "".concat(m2, " ").concat(i10.title) : i10.title;
        return (0, s.jsxs)(S.Paper, {
          radius: "l",
          className: (0, l.$)(z().root, t10),
          ref: a10,
          style: B2,
          ...(0, f.getDataAttrFromProps)(T2),
          children: [
            (0, s.jsx)(g.N_, { href: p2, className: z().paperLink, onClick: M2, "aria-label": V2 }),
            (0, s.jsx)(g.BW, {
              className: z().image,
              src: i10.coverUri,
              alt: k2({ id: "entity-names.album-name" }, { albumName: i10.title }),
              size: 100,
              fit: "cover",
              withAvatarReplace: true
            }),
            (0, s.jsxs)("div", {
              className: z().info,
              children: [
                (0, s.jsx)(E.Caption, {
                  className: z().title,
                  variant: "div",
                  type: "entity",
                  size: "m",
                  weight: "medium",
                  lineClamp: 2,
                  "aria-label": V2,
                  ...(0, d.Am)(d.Kq.newRelease.NEW_RELEASE_CARD_TITLE),
                  children: i10.title
                }),
                r2 && (0, s.jsx)(E.Caption, {
                  className: z().description,
                  variant: "div",
                  type: "entity",
                  size: "s",
                  weight: "medium",
                  lineClamp: 1,
                  ...(0, d.Am)(d.Kq.newRelease.NEW_RELEASE_CARD_DESCRIPTION),
                  children: r2
                })
              ]
            }),
            (0, s.jsxs)("div", {
              className: z().container,
              children: [
                i10.explicitDisclaimer && (0, s.jsx)(g.Nq, {
                  className: z().explicitMark,
                  containerClassName: z().explicitMarkContainer,
                  getDescriptionTexts: i10.getDescriptionTexts,
                  variant: i10.explicitDisclaimer
                }),
                o2,
                (0, s.jsx)(g.DM, {
                  buttonVariant: "default",
                  withHover: false,
                  className: z().button,
                  iconClassName: z().buttonIcon,
                  variant: "filled",
                  iconSize: "m",
                  isPlaying: x2,
                  onClick: D2
                })
              ]
            })
          ]
        });
      }), q = (0, n.forwardRef)((e10, t10) => (0, s.jsx)($, { forwardRef: t10, ...e10 })), J = (0, r.PA)((e10) => {
        let { promo: t10 } = e10, { ref: a10, intersectionPropertyId: i10 } = (0, _.nMI)(), { from: l2 } = (0, _.fyy)({ contextId: t10.album.id, contextType: y.K.Album });
        return (0, s.jsx)(q, {
          onClick: t10.setClicked,
          album: t10.album,
          albumUrl: t10.albumUrl,
          utmLink: (0, _.ZQO)(t10.reportingProperties),
          from: l2,
          ref: a10,
          "data-intersection-property-id": i10,
          description: t10.album.artistNames,
          ...(0, d.Am)(d.Kq.simpleAlbumPromo.SIMPLE_ALBUM_PROMO_CARD)
        });
      }), Z = (e10) => {
        let { forwardRef: t10, data: a10, ...i10 } = e10;
        return (0, s.jsx)(G, {
          ref: t10,
          data: a10,
          ...i10,
          children: null == a10 ? void 0 : a10.items.map(
            (e11, t11) => (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Album,
                objectId: String(e11.album.id),
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: null == a10 ? void 0 : a10.items.length,
                children: (0, s.jsx)(J, { promo: e11 })
              },
              e11.album.getKey(t11)
            )
          )
        });
      }, Q = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(Z, { forwardRef: t10, ...e10 }));
      var ee = a(77217);
      let et = (0, r.PA)((e10) => {
        var t10, a10, i10, l2;
        let {
          forwardRef: r2,
          isShimmerVisible: o2,
          isShimmerActive: n2,
          containerClassName: d2,
          headerClassName: c2,
          meta: m2,
          data: u2,
          headingVariant: g2,
          className: p2,
          ...b2
        } = e10, { artist: v2, concert: A2 } = (0, _.Pjs)(), T2 = null != (i10 = null != (a10 = v2.id) ? a10 : A2.leadArtistId) ? i10 : "";
        return (0, s.jsx)(_.Bki, {
          objectType: h.ky.Shortcut,
          objectId: String(T2),
          objectPosX: 0,
          objectPosY: 0,
          objectsCount: null != (l2 = null == u2 || null == (t10 = u2.items) ? void 0 : t10.length) ? l2 : 0,
          children: (0, s.jsx)(ee.BD, {
            ref: r2,
            artistId: String(T2),
            title: m2.title,
            viewAllActionLink: m2.viewAllActionLink,
            isLoading: o2 || n2,
            headingVariant: g2,
            className: p2,
            headerClassName: c2,
            containerClassName: d2,
            ...(0, f.getDataAttrFromProps)(b2),
            children: null == u2 ? void 0 : u2.items.map((e11, t11) => {
              var a11, i11;
              let {
                objectPosX: l3,
                objectPosY: r3,
                objectsCount: o3
              } = (0, _.$tp)({
                index: t11,
                count: null != (i11 = null == (a11 = u2.items) ? void 0 : a11.length) ? i11 : 0,
                itemsCountPerColumn: 2
              });
              return (0, s.jsx)(
                _.Bki,
                {
                  objectType: h.ky.Concert,
                  objectId: String(e11.id),
                  objectPosX: l3,
                  objectPosY: r3,
                  objectsCount: o3,
                  children: (0, s.jsx)(ee.VN, { artistId: String(T2), concert: e11, meta: (0, s.jsx)(ee.ZH, {}) })
                },
                e11.id
              );
            })
          })
        });
      }), ea = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(et, { forwardRef: t10, ...e10 }));
      var ei = a(39610), es = a(73665), el = a.n(es);
      let er = (0, r.PA)((e10) => {
        var t10, a10, i10;
        let { isShimmerVisible: l2, isShimmerActive: r2, headerClassName: o2, data: n2, headingVariant: d2 } = e10, { ref: c2, intersectionPropertyId: m2 } = (0, _.nMI)(), { playlist: u2, artists: p2 } = n2 || {}, { artist: b2 } = (0, _.Pjs)(), v2 = !!(null == (t10 = b2.meta) ? void 0 : t10.artist.isAvailable), A2 = null == (a10 = b2.meta) ? void 0 : a10.artist.coverUri, T2 = null == (i10 = b2.meta) ? void 0 : i10.artist.name;
        return (0, s.jsx)(g.Tw, {
          ref: c2,
          "data-intersection-property-id": m2,
          coverUrl: null == u2 ? void 0 : u2.coverUri,
          withCover: true,
          withDescription: true,
          viewAllActionLink: null == u2 ? void 0 : u2.url,
          title: null == u2 ? void 0 : u2.title,
          controls: false,
          coverContainerClassName: el().cover,
          shimmerCoverClassName: el().shimmerCover,
          titleLineClamp: 1,
          withDescriptionWidthLimit: false,
          isShimmerVisible: l2,
          isShimmerActive: r2,
          headingVariant: d2,
          className: o2,
          subTitle: (0, s.jsxs)("div", {
            className: el().subTitle,
            children: [
              (0, s.jsx)(ei.q, {
                children: (0, s.jsx)(E.Heading, {
                  variant: "h4",
                  children: (0, s.jsx)(L.A, { id: "page.artist-pick-aria-label", values: { artistName: T2 } })
                })
              }),
              (0, s.jsx)(E.Caption, {
                variant: "span",
                size: "l",
                weight: "medium",
                className: el().text,
                "aria-hidden": true,
                children: (0, s.jsx)(L.A, { id: "page.artist-pick-subtitle" })
              }),
              (0, s.jsx)(S.Paper, {
                radius: "round",
                className: el().smallCoverContainer,
                children: (0, s.jsx)(g.BW, {
                  fit: "cover",
                  src: A2,
                  size: 50,
                  className: el().smallCover,
                  withAvatarReplace: true,
                  isAvailable: v2,
                  "aria-hidden": true
                })
              }),
              T2 && (0, s.jsx)(E.Caption, {
                variant: "span",
                size: "l",
                weight: "medium",
                className: el().text,
                lineClamp: 1,
                "aria-hidden": true,
                children: T2
              })
            ]
          }),
          description: (0, s.jsx)(j.iQ, {
            artists: p2,
            linkClassName: el().artistLink,
            spoilerClassName: el().artistsSpoiler,
            lineClamp: 1,
            visibleArtistsCount: 3,
            spoilerComponent: (0, s.jsx)(L.A, { id: "entity-names.and-more-artists", values: { artists: "" } })
          })
        });
      }), eo = (0, r.PA)((e10) => {
        var t10, a10;
        let { forwardRef: i10, className: l2, ...r2 } = e10;
        return (0, s.jsx)("section", {
          ref: i10,
          className: l2,
          ...(0, f.getDataAttrFromProps)(r2),
          children: (0, s.jsx)(_.Bki, {
            objectType: h.ky.Playlist,
            objectPosX: 1,
            objectPosY: 1,
            objectsCount: 1,
            objectId: null != (a10 = null == (t10 = r2.data) ? void 0 : t10.playlist.id) ? a10 : "",
            children: (0, s.jsx)(er, { ...r2 })
          })
        });
      }), en = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(eo, { forwardRef: t10, ...e10 }));
      var ed = a(21365), ec = a(31879), em = a.n(ec);
      let eu = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          tracksContainerClassName: r2,
          meta: o2,
          data: n2,
          headerClassName: d2,
          headingVariant: c2,
          className: m2,
          ...u2
        } = e10, p2 = (function() {
          var e11;
          let { artist: t11, concert: a11 } = (0, _.Pjs)();
          return null != (e11 = t11.id) ? e11 : a11.leadArtistId;
        })(), { from: b2, utmLink: v2 } = (0, _.fyy)({ contextType: y.K.Artist, contextId: p2 });
        return null === p2 ? null : (0, s.jsx)(g.$2, {
          className: m2,
          ref: t10,
          shimmer: (0, s.jsx)(g.DS, { variant: _.Xjt.PLAYLIST, isActive: i10 }),
          maxColumnsCount: g.DI.ONE,
          itemsCountPerColumn: 5,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          carouselClassName: r2,
          carouselItemClassName: (0, l.$)(em().item, em().important),
          blockHeaderClassName: d2,
          blockHeaderTitle: o2.title,
          blockHeaderDescription: o2.description,
          blockHeaderHeadingVariant: c2,
          viewAllActionLink: o2.viewAllActionLink,
          ...u2,
          children: null == n2 ? void 0 : n2.items.map((e11, t11) => {
            var a11;
            let {
              objectPosX: i11,
              objectPosY: l2,
              objectsCount: r3
            } = (0, _.$tp)({ index: t11, count: n2.items.length });
            return (0, s.jsx)(
              _.Bki,
              {
                objectId: e11.id,
                objectType: h.ky.Track,
                objectPosX: i11,
                objectPosY: l2,
                objectsCount: r3,
                children: (0, s.jsx)(ed.Kt, {
                  track: e11,
                  playContextParams: (a11 = e11.id, n2 && p2 ? {
                    contextData: { type: y.K.Artist, meta: { id: p2 }, from: b2, utmLink: v2 },
                    queueParams: { index: t11, entityId: a11 },
                    loadContextMeta: true
                  } : { contextData: { type: y.K.Artist, meta: { id: "" }, from: b2, utmLink: v2 } })
                })
              },
              e11.id
            );
          })
        });
      }), e_ = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(eu, { forwardRef: t10, ...e10 }));
      var eg = a(94376);
      let ep = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: n2,
          headingVariant: d2,
          className: c2,
          ...m2
        } = e10, u2 = (0, v.L)(
          () => a10 || !n2 ? (0, s.jsx)(g.Vt, { className: l2, isActive: i10 }) : (0, s.jsx)(_.Bki, {
            objectType: h.ky.Album,
            objectId: String(n2.album.id),
            objectPosX: 1,
            objectPosY: 1,
            objectsCount: 1,
            children: (0, s.jsx)(eg.aX, { className: l2, album: n2.album })
          })
        );
        return (0, s.jsxs)("section", {
          className: c2,
          ref: t10,
          ...(0, f.getDataAttrFromProps)(m2),
          children: [(0, s.jsx)(g.Tw, { className: r2, title: o2.title, headingVariant: d2, titleLineClamp: 1 }), u2]
        });
      }, eb = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(ep, { forwardRef: t10, ...e10 })), ev = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: n2,
          headingVariant: d2,
          className: c2,
          ...m2
        } = e10, u2 = (0, v.L)(
          () => a10 || !n2 ? (0, s.jsx)(g.Vt, { className: l2, isActive: i10 }) : (0, s.jsx)(_.Bki, {
            objectType: h.ky.UpcomingAlbum,
            objectId: String(n2.album.id),
            objectPosX: 1,
            objectPosY: 1,
            objectsCount: 1,
            children: (0, s.jsx)(eg.M3, { className: l2, upcomingAlbum: n2.album })
          })
        );
        return (0, s.jsxs)("section", {
          className: c2,
          ref: t10,
          ...(0, f.getDataAttrFromProps)(m2),
          children: [(0, s.jsx)(g.Tw, { className: r2, title: o2.title, headingVariant: d2, titleLineClamp: 1 }), u2]
        });
      }, eA = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(ev, { forwardRef: t10, ...e10 }));
      var eT = a(54460);
      let eC = (e10) => {
        let { playlistId: t10, filter: a10 } = e10;
        return (0, n.useMemo)(
          () => t10 ? (0, eT.tW)({ contextType: y.K.Playlist, contextId: t10, filter: a10 }) : null,
          [t10, a10]
        );
      }, eh = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          tracksContainerClassName: l2,
          meta: r2,
          data: o2,
          headerClassName: n2,
          headingVariant: d2,
          className: c2,
          ...m2
        } = e10, { from: u2, utmLink: p2 } = (0, _.fyy)({
          contextType: y.K.Playlist,
          contextId: null == o2 ? void 0 : o2.playlist.id
        }), b2 = eC({ playlistId: null == o2 ? void 0 : o2.playlist.id });
        return (0, s.jsx)(_._Fn, {
          sourceContextData: b2,
          children: (0, s.jsx)(g.$2, {
            className: c2,
            ref: t10,
            shimmer: (0, s.jsx)(g.DS, { variant: _.Xjt.PLAYLIST, isActive: i10 }),
            maxColumnsCount: g.DI.TWO,
            itemsCountPerColumn: 4,
            isShimmerVisible: a10,
            isShimmerActive: i10,
            carouselClassName: l2,
            blockHeaderClassName: n2,
            blockHeaderTitle: r2.title,
            blockHeaderDescription: r2.description,
            blockHeaderHeadingVariant: d2,
            viewAllActionLink: r2.viewAllActionLink,
            ...m2,
            children: null == o2 ? void 0 : o2.items.map((e11, t11) => {
              let {
                objectPosX: a11,
                objectPosY: i11,
                objectsCount: l3
              } = (0, _.$tp)({ index: t11, count: o2.items.length });
              return (0, s.jsx)(
                _.Bki,
                {
                  objectId: e11.data.id,
                  objectType: h.ky.Track,
                  objectPosX: a11,
                  objectPosY: i11,
                  objectsCount: l3,
                  children: (0, s.jsx)(ed.QB, {
                    track: e11.data,
                    playContextParams: ((e12) => o2 ? {
                      contextData: {
                        type: y.K.Playlist,
                        meta: { id: o2.playlist.id },
                        from: u2,
                        utmLink: p2
                      },
                      queueParams: { index: o2.items.findIndex((t12) => t12.data.id === e12), entityId: e12 },
                      loadContextMeta: true
                    } : { contextData: { type: y.K.Playlist, meta: { id: "" }, from: u2, utmLink: p2 } })(
                      e11.data.id
                    )
                  })
                },
                e11.data.id
              );
            })
          })
        });
      }), eI = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(eh, { forwardRef: t10, ...e10 }));
      var eL = a(65779);
      let ey = function() {
        let e10 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return e10.map((e11) => e11.data);
      }, eS = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          data: l2,
          meta: r2,
          containerClassName: o2,
          headerClassName: n2,
          className: d2,
          ...c2
        } = e10;
        return (0, s.jsx)(eL.KR, {
          className: d2,
          ref: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          clips: ey(null == l2 ? void 0 : l2.items),
          title: r2.title,
          description: r2.description,
          viewAllActionLink: r2.viewAllActionLink,
          containerClassName: o2,
          headerClassName: n2,
          ...c2
        });
      }, eE = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(eS, { forwardRef: t10, ...e10 }));
      var eN = a(40492), ej = a.n(eN);
      let ek = (e10) => {
        let {
          title: t10,
          description: a10,
          viewAllActionLink: i10,
          headerClassName: r2,
          containerClassName: o2,
          headingVariant: n2
        } = e10, { formatMessage: d2 } = (0, I.A)();
        return (0, s.jsxs)("div", {
          className: ej().root,
          children: [
            (0, s.jsx)(g.Tw, {
              className: r2,
              title: t10,
              description: a10,
              viewAllActionLink: i10,
              "aria-label": d2({ id: "error-messages.empty-collection-podcasts" }),
              headingVariant: n2,
              withDescription: !!a10
            }),
            (0, s.jsx)("div", {
              className: (0, l.$)(ej().text, o2),
              children: (0, s.jsx)(L.A, { id: "error-messages.empty-collection-podcasts" })
            })
          ]
        });
      }, ex = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: n2,
          headingVariant: d2,
          className: c2,
          ...m2
        } = e10;
        return (null == n2 ? void 0 : n2.isEmptyBlock) ? (0, s.jsx)(ek, {
          title: o2.title,
          description: o2.description,
          viewAllActionLink: o2.viewAllActionLink,
          containerClassName: l2,
          headerClassName: r2,
          headingVariant: d2
        }) : (0, s.jsx)(g.OY, {
          className: c2,
          ...m2,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          headerClassName: r2,
          containerClassName: l2,
          title: o2.title,
          description: o2.description,
          viewAllActionLink: o2.viewAllActionLink,
          ref: t10,
          headingVariant: d2,
          children: null == n2 ? void 0 : n2.items.map(
            (e11, t11) => (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Album,
                objectId: String(e11.id),
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: n2.items.length,
                children: (0, s.jsx)(eg.aX, { album: e11, contentLinesCount: 3 })
              },
              e11.id
            )
          )
        });
      }, eR = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(ex, { forwardRef: t10, ...e10 }));
      var ef = a(60049), eP = a(45779), ew = a.n(eP), eK = a(75468), eO = a(4319), eM = a.n(eO);
      let eD = (e10) => {
        let { tab: t10, areBothTabsEmpty: a10 } = e10, i10 = (0, n.useMemo)(() => {
          switch (t10) {
            case eK.n.ALBUM:
              return (0, s.jsx)(L.A, { id: "error-messages.empty-collection-albums" });
            case eK.n.PRESAVED_ALBUM:
              return (0, s.jsx)(L.A, { id: "error-messages.empty-collection-upcoming-albums-title" });
          }
        }, [t10]);
        return (0, s.jsx)("div", {
          className: (0, l.$)(eM().root, { [eM().root_oneEmptyTab]: !a10, [eM().root_twoEmptyTabs]: a10 }),
          children: i10
        });
      }, eB = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          headingVariant: m2,
          className: p2,
          ...b2
        } = e10, { objectsCount: v2 } = (0, _.N8n)(), A2 = (0, n.useId)(), T2 = (0, n.useRef)(null), C2 = (0, n.useId)(), I2 = "".concat(A2, " ").concat(A2, "-description"), L2 = (0, u.useTabsState)((null == c2 ? void 0 : c2.activeIndexTab) || 0), y2 = (0, n.useMemo)(() => {
          var e11;
          return (null == c2 || null == (e11 = c2.tabs[L2.value]) ? void 0 : e11.items.length) === 0;
        }, [null == c2 ? void 0 : c2.tabs, L2.value]), S2 = (0, n.useCallback)(
          (e11) => e11.isEmptyTab ? (0, s.jsxs)(s.Fragment, {
            children: [
              !(null == c2 ? void 0 : c2.areBothTabsEmpty) && (0, s.jsx)(P.Carousel, {
                className: (0, l.$)(ew().carouselEmpty, r2),
                itemClassName: (0, l.$)(ew().item, ew().important),
                tabIndex: -1,
                children: (0, g.km)({ isActive: false, withInfo: true, linesCount: 4 })
              }),
              (0, s.jsx)(eD, { tab: e11.type, areBothTabsEmpty: null == c2 ? void 0 : c2.areBothTabsEmpty })
            ]
          }) : (0, s.jsx)(P.Carousel, {
            ref: T2,
            itemClassName: (0, l.$)(ew().item, ew().important),
            className: r2,
            "aria-labelledby": I2,
            children: e11.items.map((t11, a11) => {
              switch (t11.type) {
                case ef._.ALBUM_ITEM:
                  return (0, s.jsx)(
                    _.Bki,
                    {
                      objectType: h.ky.Album,
                      objectId: String(t11.data.id),
                      objectPosX: a11 + 1,
                      objectPosY: 1,
                      objectsCount: e11.items.length,
                      children: (0, s.jsx)(eg.aX, { contentLinesCount: 4, album: t11.data })
                    },
                    t11.data.id
                  );
                case ef._.PRESAVED_ALBUM_ITEM:
                  return (0, s.jsx)(
                    _.Bki,
                    {
                      objectType: h.ky.UpcomingAlbum,
                      objectId: String(t11.data.id),
                      objectPosX: a11 + 1,
                      objectPosY: 1,
                      objectsCount: e11.items.length,
                      children: (0, s.jsx)(eg.M3, { contentLinesCount: 4, upcomingAlbum: t11.data })
                    },
                    t11.data.id
                  );
              }
            })
          }),
          [I2, r2, null == c2 ? void 0 : c2.areBothTabsEmpty]
        ), E2 = (0, n.useMemo)(
          () => a10 ? (0, s.jsx)(P.Carousel, {
            ref: T2,
            itemClassName: (0, l.$)(ew().item, ew().important),
            className: r2,
            "aria-labelledby": I2,
            children: (0, g.km)({ isActive: i10, withInfo: true, linesCount: 4 })
          }) : null == c2 ? void 0 : c2.tabs.map(
            (e11, t11) => (0, s.jsx)(
              u.TabPanel,
              { name: t11, value: L2.value, elementId: C2, className: ew().tabPanel, children: S2(e11) },
              e11.id
            )
          ),
          [a10, null == c2 ? void 0 : c2.tabs, r2, I2, i10, L2.value, C2, S2]
        );
        return (0, s.jsxs)("section", {
          className: (0, l.$)(ew().root, p2, { [ew().root_withControls]: !y2 }),
          ref: t10,
          ...(0, f.getDataAttrFromProps)(b2),
          children: [
            (0, s.jsx)(_.Bki, {
              objectType: h.ky.Shortcut,
              objectId: String(d2.viewAllActionLink),
              objectPosX: 0,
              objectPosY: 0,
              objectsCount: null != v2 ? v2 : 0,
              children: (0, s.jsx)(g.Tw, {
                className: (0, l.$)(o2, ew().header, ew().important),
                title: d2.title,
                description: d2.description,
                labeledForId: A2,
                viewAllActionLink: d2.viewAllActionLink,
                controls: (0, s.jsx)(g.X9, { className: ew().controls, carouselRef: T2 }),
                headingVariant: m2,
                withDescription: !!d2.description
              })
            }),
            (0, s.jsx)(g.wI, {
              className: (0, l.$)(r2, ew().tabCarousel, ew().important),
              isShimmerVisible: a10,
              elementId: C2,
              shimmer: (0, s.jsx)(g.zr, {
                isActive: i10,
                className: (0, l.$)(r2, ew().tabCarousel, ew().important),
                shimmerClassName: ew().tabShimmer
              }),
              "aria-labelledby": A2,
              ...L2,
              children: null == c2 ? void 0 : c2.tabs.map(
                (e11, t11) => (0, s.jsx)(
                  g.oz,
                  {
                    value: t11,
                    "aria-label": e11.title,
                    title: e11.title,
                    className: (0, l.$)(ew().tab, ew().important)
                  },
                  e11.id
                )
              )
            }),
            E2
          ]
        });
      }), eV = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(eB, { forwardRef: t10, ...e10 }));
      var eU = a(55616), eY = a(42922), eG = a.n(eY);
      let eW = (e10) => {
        let { title: t10, description: a10, viewAllActionLink: i10, headerClassName: r2, containerClassName: o2 } = e10, { formatMessage: n2 } = (0, I.A)();
        return (0, s.jsxs)("div", {
          className: eG().root,
          children: [
            (0, s.jsx)(g.Tw, {
              className: r2,
              title: t10,
              description: a10,
              viewAllActionLink: i10,
              "aria-label": n2({ id: "error-messages.empty-collection-artists-title" }),
              withDescription: !!a10
            }),
            (0, s.jsx)("div", {
              className: (0, l.$)(eG().text, o2),
              children: (0, s.jsx)(L.A, { id: "error-messages.empty-collection-artists-title" })
            })
          ]
        });
      }, eX = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          className: o2,
          meta: n2,
          data: d2,
          headingVariant: c2,
          ...m2
        } = e10;
        return (null == d2 ? void 0 : d2.isEmptyBlock) ? (0, s.jsx)(eW, {
          title: n2.title,
          description: n2.description,
          viewAllActionLink: n2.viewAllActionLink,
          containerClassName: l2,
          headerClassName: r2
        }) : (0, s.jsx)(g.OY, {
          ...m2,
          className: o2,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          isShimmerCentered: true,
          isShimmerRounded: true,
          containerClassName: l2,
          headerClassName: r2,
          title: n2.title,
          description: n2.description,
          viewAllActionLink: n2.viewAllActionLink,
          ref: t10,
          headingVariant: c2,
          children: null == d2 ? void 0 : d2.items.map(
            (e11, t11) => (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Artist,
                objectId: e11.id,
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: d2.items.length,
                children: (0, s.jsx)(eU.ao, { artist: e11, contentLinesCount: 3 })
              },
              e11.id
            )
          )
        });
      }, eF = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(eX, { forwardRef: t10, ...e10 }));
      var eH = a(62443), ez = a(58360), e$ = a(76866), eq = a(32156), eJ = a.n(eq);
      let eZ = (e10) => {
        var t10;
        let { item: a10 } = e10, i10 = (0, c.c)((e11) => {
          (0, F.P)(e11, eJ().ripple);
        });
        return (0, s.jsxs)(g.N_, {
          href: a10.data.viewAllActionLink,
          className: (0, l.$)(eJ().item, eJ().menuItem),
          onClick: i10,
          children: [
            (0, s.jsx)(ez.Image, {
              src: null == (t10 = a10.data.cover) ? void 0 : t10.uri,
              className: eJ().cover,
              fit: "cover",
              withAvatarReplace: true,
              "aria-hidden": true
            }),
            (0, s.jsx)(E.Caption, {
              className: eJ().text,
              variant: "div",
              type: "entity",
              size: "m",
              weight: "medium",
              lineClamp: 2,
              children: a10.data.title
            })
          ]
        });
      }, eQ = (0, r.PA)((e10) => {
        let { item: t10, artistId: a10 } = e10, [i10, l2] = (0, n.useState)(false), { state: r2, setState: o2 } = (0, eH.e)(false), d2 = (0, _.PT7)(), { isFreemium: m2 } = (0, _.XCI)(), u2 = (0, _.brA)(), p2 = "".concat(_.UfI.ARTIST, "-").concat(a10), {
          isPlaying: b2,
          togglePlay: A2,
          isCurrent: T2
        } = (0, _.B0S)({ seeds: t10.data.seeds, pageIdForFrom: _._Q$.RADIO, blockIdForFrom: p2, parentContextId: a10 }), C2 = (0, c.c)(async () => m2 ? void o2(true) : A2()), h2 = (0, c.c)(() => {
          d2() || (l2(true), C2().finally(() => {
            l2(false);
          }), u2(!b2));
        }), I2 = (0, c.c)((e11) => {
          (0, F.P)(e11, eJ().ripple), h2();
        }), L2 = (0, v.L)(() => {
          var e11;
          return t10.data.shouldShowAgent && t10.data.agent ? (0, s.jsx)(e$.nr, {
            agent: t10.data.agent,
            isCurrent: T2,
            isPlaying: b2,
            onPlayButtonClick: h2,
            playButtonIconSize: "m"
          }) : (0, s.jsx)(g.q1, {
            isCurrent: T2,
            isPlaying: b2,
            isAvailable: true,
            isPlayButtonLoading: i10,
            onPlayButtonClick: h2,
            title: t10.data.title,
            entityCoverStyle: { backgroundColor: null == (e11 = t10.data.agent) ? void 0 : e11.cover.color },
            coverUri: "avatars.mds.yandex.net/get-music-misc/2419084/img.64426eadaa320f4f1b4b633a/%%",
            radius: "round",
            withLoadingIndicator: false,
            playButtonIconSize: "m"
          });
        }), y2 = (0, n.useCallback)(
          () => (0, s.jsxs)(g.Cj, {
            className: eJ().item,
            onClick: I2,
            children: [
              L2,
              (0, s.jsx)(E.Caption, {
                className: eJ().text,
                variant: "div",
                type: "entity",
                size: "m",
                weight: "medium",
                lineClamp: 2,
                children: t10.data.title
              })
            ]
          }),
          [I2, L2, t10.data.title]
        );
        return (0, s.jsx)(g.SU, {
          isEnabled: m2,
          isOpened: r2,
          onOpenChange: o2,
          placement: "right",
          textVariant: "vibe",
          vibeTextVariant: t10.data.stationType,
          renderChildren: y2
        });
      }), e0 = (e10) => {
        let { items: t10, className: a10, artistId: i10 } = e10;
        return (0, s.jsx)("div", {
          className: (0, l.$)(eJ().root, a10),
          children: t10.map((e11, t11) => {
            switch (e11.type) {
              case ef._.MENU_ITEM:
                return (0, s.jsx)(eZ, { item: e11 }, e11.key);
              case ef._.WAVE_AGENT_ITEM:
                return (0, s.jsx)(eQ, { item: e11, artistId: i10 }, t11);
              default:
                return null;
            }
          })
        });
      };
      var e1 = a(22674), e3 = a(69422), e4 = a.n(e3);
      let e2 = (e10) => {
        let { isActive: t10, itemClassName: a10, actionItemClassName: i10 } = e10;
        return (0, s.jsxs)("div", {
          className: e4().root,
          children: [
            (0, s.jsx)(g.Vt, { isActive: t10, className: a10, round: true, centered: true }),
            (0, s.jsxs)("div", {
              className: (0, l.$)(e4().actionItems, i10),
              children: [
                (0, s.jsxs)("div", {
                  className: e4().actionItem,
                  children: [
                    (0, s.jsx)(e1.Shimmer, { isActive: t10, className: e4().actionCover, radius: "s" }),
                    (0, s.jsxs)("div", {
                      className: e4().actionTextContainer,
                      children: [
                        (0, s.jsx)(e1.Shimmer, {
                          isActive: t10,
                          className: (0, l.$)(e4().actionText, e4().actionText_title),
                          radius: "s"
                        }),
                        (0, s.jsx)(e1.Shimmer, { isActive: t10, className: e4().actionText, radius: "s" })
                      ]
                    })
                  ]
                }),
                (0, s.jsxs)("div", {
                  className: e4().actionItem,
                  children: [
                    (0, s.jsx)(e1.Shimmer, { isActive: t10, className: e4().actionCover, radius: "round" }),
                    (0, s.jsxs)("div", {
                      className: e4().actionTextContainer,
                      children: [
                        (0, s.jsx)(e1.Shimmer, {
                          isActive: t10,
                          className: (0, l.$)(e4().actionText, e4().actionText_title),
                          radius: "s"
                        }),
                        (0, s.jsx)(e1.Shimmer, { isActive: t10, className: e4().actionText, radius: "s" })
                      ]
                    })
                  ]
                })
              ]
            })
          ]
        });
      }, e6 = function() {
        var e10;
        let t10 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return Array.from({ length: null != (e10 = t10.countWeb) ? e10 : 5 }, (e11, a10) => (0, s.jsx)(e2, { ...t10 }, a10));
      };
      var e8 = a(37645), e5 = a.n(e8);
      let e7 = (e10) => {
        var t10;
        let {
          forwardRef: a10,
          isShimmerVisible: i10,
          isShimmerActive: r2,
          containerClassName: o2,
          headerClassName: d2,
          className: c2,
          meta: m2,
          data: u2,
          headingVariant: p2,
          ...b2
        } = e10, { formatMessage: v2 } = (0, I.A)(), A2 = (0, n.useRef)(null);
        return (0, s.jsxs)("section", {
          ref: a10,
          className: (0, l.$)(e5().root, c2),
          ...(0, f.getDataAttrFromProps)(b2),
          children: [
            (0, s.jsx)(g.Tw, {
              className: d2,
              title: m2.title,
              description: m2.description,
              viewAllActionLink: m2.viewAllActionLink,
              headingVariant: p2,
              controls: (0, s.jsx)(g.X9, { className: e5().controls, carouselRef: A2 })
            }),
            (0, s.jsx)(P.Carousel, {
              className: o2,
              ref: A2,
              children: i10 ? e6({
                isActive: r2,
                itemClassName: (0, l.$)(e5().item, e5().important),
                actionItemClassName: (0, l.$)(e5().actionItem, e5().important),
                countWeb: null == (t10 = m2.source) ? void 0 : t10.countWeb
              }) : null == u2 ? void 0 : u2.artists.map(
                (e11, t11) => (0, s.jsx)(
                  _.Bki,
                  {
                    objectType: h.ky.Artist,
                    objectId: e11.artist.id,
                    objectPosX: t11 + 1,
                    objectPosY: 1,
                    objectsCount: u2.artists.length,
                    children: (0, s.jsxs)("div", {
                      className: e5().itemContainer,
                      "aria-label": v2({ id: "entity-names.artist-name" }, { artistName: e11.artist.name }),
                      children: [
                        (0, s.jsx)(eU.ao, {
                          className: (0, l.$)(e5().item, e5().important),
                          artist: e11.artist,
                          contentLinesCount: 2
                        }),
                        (0, s.jsx)(e0, {
                          className: (0, l.$)(e5().actionItem, e5().important),
                          items: e11.items,
                          artistId: e11.artist.id
                        })
                      ]
                    })
                  },
                  e11.artist.id
                )
              )
            })
          ]
        });
      }, e9 = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(e7, { forwardRef: t10, ...e10 }));
      var te = a(97433), tt = a.n(te);
      let ta = (e10) => {
        let {
          title: t10,
          description: a10,
          viewAllActionLink: i10,
          headerClassName: r2,
          containerClassName: o2,
          headingVariant: n2
        } = e10, { formatMessage: c2 } = (0, I.A)();
        return (0, s.jsxs)("div", {
          className: tt().root,
          ...(0, d.Am)(d.e8.landing.COLLECTION_CLIPS),
          children: [
            (0, s.jsx)(g.Tw, {
              className: r2,
              title: t10,
              description: a10,
              viewAllActionLink: i10,
              "aria-label": c2({ id: "error-messages.empty-collection-clips-title" }),
              headingVariant: n2,
              withDescription: !!a10
            }),
            (0, s.jsx)(E.Caption, {
              className: (0, l.$)(tt().text, o2),
              variant: "div",
              size: "l",
              weight: "normal",
              ...(0, d.Am)(d.e8.landing.COLLECTION_CLIPS_BLOCK_LIKED_EMPTY_BLOCK_TITLE),
              children: (0, s.jsx)(L.A, { id: "error-messages.empty-collection-clips-title" })
            })
          ]
        });
      }, ti = (e10) => {
        let {
          forwardRef: t10,
          containerClassName: a10,
          headerClassName: i10,
          meta: l2,
          data: r2,
          headingVariant: o2,
          ...n2
        } = e10;
        return (null == r2 ? void 0 : r2.isEmptyBlock) ? (0, s.jsx)(ta, {
          title: l2.title,
          description: l2.description,
          viewAllActionLink: l2.viewAllActionLink,
          containerClassName: a10,
          headerClassName: i10,
          headingVariant: o2
        }) : (0, s.jsx)(eE, {
          ref: t10,
          meta: l2,
          data: r2,
          containerClassName: a10,
          headerClassName: i10,
          headingVariant: o2,
          ...n2
        });
      }, ts = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(ti, { forwardRef: t10, ...e10 }));
      var tl = a(83909), tr = a(13611);
      let to = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: d2,
          headingVariant: c2,
          className: m2,
          ...u2
        } = e10, p2 = (0, n.useMemo)(() => {
          let e11 = null == d2 ? void 0 : d2.items.map(
            (e12, t11) => (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Playlist,
                objectId: e12.id,
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: d2.items.length,
                children: (0, s.jsx)(tl.B6, { playlist: e12, contentLinesCount: 3 })
              },
              e12.key
            )
          );
          return null == e11 || e11.unshift((0, s.jsx)(tr.Bw, {}, "create-playlist-card")), e11;
        }, [null == d2 ? void 0 : d2.items]);
        return (0, s.jsx)(g.OY, {
          className: m2,
          ...u2,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          title: o2.title,
          description: o2.description,
          viewAllActionLink: o2.viewAllActionLink,
          ref: t10,
          headingVariant: c2,
          children: p2
        });
      }), tn = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(to, { forwardRef: t10, ...e10 })), td = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          tracksContainerClassName: l2,
          headerClassName: r2,
          className: o2,
          meta: n2,
          data: d2,
          headingVariant: c2,
          ...m2
        } = e10, { from: u2 } = (0, _.fyy)(), { formatMessage: p2 } = (0, I.A)(), b2 = Array.isArray(null == d2 ? void 0 : d2.rawTracks) ? p2({ id: "entity-names.number-of-tracks" }, { counter: null == d2 ? void 0 : d2.rawTracks.length }) : n2.description;
        return (0, s.jsx)(g.$2, {
          className: o2,
          shimmer: (0, s.jsx)(g.DS, { variant: _.Xjt.PLAYLIST, isActive: i10 }),
          maxColumnsCount: g.DI.TWO,
          itemsCountPerColumn: 4,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          blockHeaderClassName: r2,
          carouselClassName: l2,
          blockHeaderTitle: n2.title,
          viewAllActionLink: n2.viewAllActionLink,
          blockHeaderDescription: b2,
          ref: t10,
          blockHeaderHeadingVariant: c2,
          withBlockHeaderDescription: true,
          ...m2,
          children: null == d2 ? void 0 : d2.items.map((e11, t11) => {
            let a11, {
              objectPosX: i11,
              objectPosY: l3,
              objectsCount: r3
            } = (0, _.$tp)({ index: t11, count: d2.items.length });
            return (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Track,
                objectId: e11.id,
                objectPosX: i11,
                objectPosY: l3,
                objectsCount: r3,
                children: (0, s.jsx)(ed.Kt, {
                  track: e11,
                  playContextParams: (a11 = e11.id, {
                    contextData: {
                      type: y.K.Various,
                      meta: { id: C.t.COLLECTION_DOWNLOADED_TRACKS },
                      from: u2
                    },
                    entitiesData: null == d2 ? void 0 : d2.entitiesData,
                    queueParams: { index: t11, entityId: a11 },
                    loadContextMeta: false
                  })
                })
              },
              e11.id
            );
          })
        });
      }), tc = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(td, { forwardRef: t10, ...e10 })), tm = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: n2,
          headingVariant: d2,
          className: c2,
          ...m2
        } = e10;
        return (0, s.jsx)(g.OY, {
          className: c2,
          ...m2,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          title: o2.title,
          description: o2.description,
          viewAllActionLink: o2.viewAllActionLink,
          ref: t10,
          headingVariant: d2,
          children: null == n2 ? void 0 : n2.items.map((e11, t11) => {
            switch (e11.type) {
              case ef._.TRACK_ITEM:
                return (0, s.jsx)(
                  _.Bki,
                  {
                    objectType: h.ky.Track,
                    objectId: String(e11.data.id),
                    objectPosX: t11 + 1,
                    objectPosY: 1,
                    objectsCount: n2.items.length,
                    children: (0, s.jsx)(
                      ed.wO,
                      { track: e11.data, contentLinesCount: 3 },
                      e11.data.getKey("track")
                    )
                  },
                  e11.data.id
                );
              case ef._.LIKED_PLAYLIST_ITEM:
                return (0, s.jsx)(
                  _.Bki,
                  {
                    objectType: h.ky.Playlist,
                    objectId: e11.data.id,
                    objectPosX: t11 + 1,
                    objectPosY: 1,
                    objectsCount: n2.items.length,
                    children: (0, s.jsx)(
                      tl.B6,
                      { playlist: e11.data, contentLinesCount: 3 },
                      e11.data.getKey("playlist")
                    )
                  },
                  e11.data.key
                );
              case ef._.NON_MUSIC_ALBUM_ITEM:
                return (0, s.jsx)(
                  _.Bki,
                  {
                    objectType: h.ky.Album,
                    objectId: String(e11.data.id),
                    objectPosX: t11 + 1,
                    objectPosY: 1,
                    objectsCount: n2.items.length,
                    children: (0, s.jsx)(
                      eg.aX,
                      { album: e11.data, contentLinesCount: 3 },
                      e11.data.getKey("album")
                    )
                  },
                  e11.data.id
                );
            }
          })
        });
      }, tu = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(tm, { forwardRef: t10, ...e10 })), t_ = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: n2,
          headingVariant: d2,
          className: c2,
          ...m2
        } = e10;
        return (0, s.jsx)(g.OY, {
          className: c2,
          ...m2,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          headerClassName: r2,
          containerClassName: l2,
          title: o2.title,
          description: o2.description,
          viewAllActionLink: o2.viewAllActionLink,
          ref: t10,
          headingVariant: d2,
          children: null == n2 ? void 0 : n2.items.map(
            (e11, t11) => (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Playlist,
                objectId: e11.id,
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: n2.items.length,
                children: (0, s.jsx)(tl.B6, { playlist: e11, contentLinesCount: 3 })
              },
              e11.key
            )
          )
        });
      }, tg = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(t_, { forwardRef: t10, ...e10 }));
      var tp = a(11090), tb = a(59699), tv = a.n(tb), tA = a(61313), tT = a.n(tA);
      let tC = (e10) => {
        let { className: t10 } = e10;
        return (0, s.jsx)("div", {
          className: (0, l.$)(tT().root, t10),
          ...(0, d.Am)(d.e8.landing.COLLECTION_PLAYLISTS_BLOCK_LIKED_EMPTY_BLOCK_TEXT),
          children: (0, s.jsx)(L.A, { id: "error-messages.empty-collection-liked-playlists" })
        });
      }, th = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          headingVariant: m2,
          className: p2,
          ...b2
        } = e10, { objectsCount: v2 } = (0, _.N8n)(), A2 = (0, n.useId)(), T2 = (0, n.useRef)(null), C2 = (0, n.useId)(), I2 = "".concat(A2, " ").concat(A2, "-description"), L2 = (0, u.useTabsState)((null == c2 ? void 0 : c2.activeIndexTab) || 0), y2 = (0, n.useMemo)(() => {
          var e11, t11;
          return (null == c2 || null == (e11 = c2.tabs[L2.value]) ? void 0 : e11.type) !== tp.l.PLAYLIST_CREATED_TAB && (null == c2 || null == (t11 = c2.tabs[L2.value]) ? void 0 : t11.items.length) === 0;
        }, [null == c2 ? void 0 : c2.tabs, L2.value]), S2 = (0, n.useCallback)(
          (e11) => {
            if (e11.isEmptyTab && e11.type !== tp.l.PLAYLIST_CREATED_TAB)
              return (0, s.jsxs)(s.Fragment, {
                children: [
                  (0, s.jsx)(P.Carousel, {
                    className: (0, l.$)(tv().carouselEmpty, r2),
                    itemClassName: (0, l.$)(tv().item, tv().important),
                    tabIndex: -1,
                    children: (0, g.km)({ isActive: false, withInfo: true, linesCount: 4 })
                  }),
                  (0, s.jsx)(tC, {})
                ]
              });
            let t11 = e11.items.map(
              (t12, a11) => (0, s.jsx)(
                _.Bki,
                {
                  objectType: h.ky.Playlist,
                  objectId: String(t12.id),
                  objectPosX: a11 + 1,
                  objectPosY: 1,
                  objectsCount: e11.items.length,
                  children: (0, s.jsx)(tl.B6, { contentLinesCount: 4, playlist: t12 })
                },
                t12.id
              )
            );
            return e11.type === tp.l.PLAYLIST_CREATED_TAB && t11.unshift((0, s.jsx)(tr.Bw, { className: tv().createPlaylistCard }, "create-playlist-card")), (0, s.jsx)(P.Carousel, {
              ref: T2,
              itemClassName: (0, l.$)(tv().item, tv().important),
              className: r2,
              "aria-labelledby": I2,
              children: t11
            });
          },
          [I2, r2]
        ), E2 = (0, n.useMemo)(
          () => a10 ? (0, s.jsx)(P.Carousel, {
            ref: T2,
            itemClassName: (0, l.$)(tv().item, tv().important),
            className: r2,
            "aria-labelledby": I2,
            children: (0, g.km)({ isActive: i10, withInfo: true, linesCount: 4 })
          }) : null == c2 ? void 0 : c2.tabs.map(
            (e11, t11) => (0, s.jsx)(
              u.TabPanel,
              { name: t11, value: L2.value, elementId: C2, className: tv().tabPanel, children: S2(e11) },
              e11.id
            )
          ),
          [a10, null == c2 ? void 0 : c2.tabs, r2, I2, i10, L2.value, C2, S2]
        );
        return (0, s.jsxs)("section", {
          className: (0, l.$)(tv().root, p2, { [tv().root_withControls]: !y2 }),
          ref: t10,
          ...(0, f.getDataAttrFromProps)(b2),
          children: [
            (0, s.jsx)(_.Bki, {
              objectType: h.ky.Shortcut,
              objectId: String(d2.viewAllActionLink),
              objectPosX: 0,
              objectPosY: 0,
              objectsCount: null != v2 ? v2 : 0,
              children: (0, s.jsx)(g.Tw, {
                className: (0, l.$)(o2, tv().header, tv().important),
                title: d2.title,
                description: d2.description,
                labeledForId: A2,
                viewAllActionLink: d2.viewAllActionLink,
                controls: (0, s.jsx)(g.X9, { className: tv().controls, carouselRef: T2 }),
                headingVariant: m2,
                withDescription: !!d2.description
              })
            }),
            (0, s.jsx)(g.wI, {
              isShimmerVisible: a10,
              className: (0, l.$)(r2, tv().tabCarousel, tv().important),
              elementId: C2,
              shimmer: (0, s.jsx)(g.zr, {
                isActive: i10,
                className: (0, l.$)(r2, tv().tabCarousel, tv().important),
                shimmerClassName: tv().tabShimmer
              }),
              "aria-labelledby": A2,
              ...L2,
              children: null == c2 ? void 0 : c2.tabs.map(
                (e11, t11) => (0, s.jsx)(
                  g.oz,
                  {
                    value: t11,
                    "aria-label": e11.title,
                    title: e11.title,
                    className: (0, l.$)(tv().tab, tv().important)
                  },
                  e11.id
                )
              )
            }),
            E2
          ]
        });
      }), tI = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(th, { forwardRef: t10, ...e10 })), tL = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          className: o2,
          meta: n2,
          data: d2,
          headingVariant: c2,
          ...m2
        } = e10;
        return a10 || (null == d2 ? void 0 : d2.items.length) ? (0, s.jsx)(g.OY, {
          ...m2,
          className: o2,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          isShimmerCentered: true,
          isShimmerRounded: true,
          containerClassName: l2,
          headerClassName: r2,
          title: n2.title,
          description: n2.description,
          viewAllActionLink: n2.viewAllActionLink,
          ref: t10,
          headingVariant: c2,
          children: null == d2 ? void 0 : d2.items.map((e11, t11) => {
            var a11, i11;
            return (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Artist,
                objectId: e11.artist.id,
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: d2.items.length,
                children: (0, s.jsx)(eU.NN, {
                  artist: e11.artist,
                  position: null == (a11 = e11.top) ? void 0 : a11.position,
                  progress: null == (i11 = e11.top) ? void 0 : i11.progress,
                  listenTimeSeconds: e11.listenTimeSeconds
                })
              },
              e11.artist.id
            );
          })
        }) : (0, s.jsx)(eW, {
          title: n2.title,
          description: n2.description,
          viewAllActionLink: n2.viewAllActionLink,
          containerClassName: l2,
          headerClassName: r2
        });
      }), ty = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(tL, { forwardRef: t10, ...e10 }));
      var tS = a(35863), tE = a.n(tS);
      let tN = (0, r.PA)((e10) => {
        var t10;
        let {
          containerClassName: a10,
          meta: i10,
          data: r2,
          forwardRef: o2,
          isShimmerVisible: d2,
          isShimmerActive: c2,
          headingVariant: m2 = "h2",
          ...u2
        } = e10, {
          settings: { isMobile: p2 }
        } = (0, _.Pjs)(), { pageId: b2 } = (0, _.$au)(), { blockIdForFrom: A2 } = (0, _.N8n)(), { isFreemium: T2 } = (0, _.XCI)(), [C2, h2] = (0, n.useState)(false), { isPlaying: I2, togglePlay: y2 } = (0, _.B0S)({
          seeds: null != (t10 = null == r2 ? void 0 : r2.vibe.seeds) ? t10 : [],
          pageIdForFrom: b2,
          blockIdForFrom: A2
        }), S2 = (0, _.brA)(), N2 = (0, n.useCallback)(() => {
          T2 || (y2(), S2(!I2));
        }, [T2, y2, S2, I2]), j2 = (0, n.useCallback)(
          () => (0, s.jsx)(g.DM, {
            withRipple: true,
            buttonVariant: "default",
            radius: "xxxl",
            size: "s",
            color: "primary",
            iconSize: "xxs",
            isPlaying: I2,
            onClick: N2,
            className: tE().playButton,
            children: (0, s.jsx)(L.A, { id: "player-actions.listen" })
          }),
          [N2, I2]
        ), k2 = (0, v.L)(
          () => (0, s.jsx)(g.SU, {
            isEnabled: T2,
            isOpened: C2,
            onOpenChange: h2,
            placement: "top",
            textVariant: "vibe",
            vibeTextVariant: null == r2 ? void 0 : r2.vibe.stationType,
            renderChildren: j2
          })
        ), x2 = (0, v.L)(
          () => d2 || !r2 ? (0, s.jsxs)("div", {
            className: tE().root,
            children: [
              (0, s.jsxs)("div", {
                className: tE().shimmerContainer,
                children: [
                  (0, s.jsx)(e1.Shimmer, {
                    isActive: c2,
                    radius: "xs",
                    className: (0, l.$)(tE().coverShimmer, tE().item, tE().important)
                  }),
                  p2 && (0, s.jsx)(e1.Shimmer, { radius: "l", isActive: c2, width: 150, height: 24 })
                ]
              }),
              !p2 && (0, s.jsxs)("div", {
                className: tE().container,
                children: [
                  (0, s.jsx)(e1.Shimmer, { radius: "l", isActive: c2, width: 300, height: 32 }),
                  (0, s.jsx)(e1.Shimmer, { radius: "xxxl", isActive: c2, width: 124, height: 48 })
                ]
              })
            ]
          }) : (0, s.jsxs)("div", {
            className: tE().root,
            children: [
              (0, s.jsx)(e$.yi, {
                vibe: r2.vibe,
                shouldShowPlayButton: false,
                className: (0, l.$)(tE().item, tE().important),
                shouldShowAdditionals: p2,
                additionalsLinesCount: 1
              }),
              !p2 && (0, s.jsxs)("div", {
                className: tE().container,
                children: [
                  (0, s.jsx)(E.Heading, {
                    weight: "bold",
                    size: "m",
                    className: tE().text,
                    lineClamp: 2,
                    variant: m2,
                    children: null == r2 ? void 0 : r2.vibe.title
                  }),
                  k2
                ]
              })
            ]
          })
        );
        return (0, s.jsx)("section", {
          ref: o2,
          title: i10.title,
          className: a10,
          ...(0, f.getDataAttrFromProps)(u2),
          children: x2
        });
      }), tj = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(tN, { forwardRef: t10, ...e10 }));
      var tk = a(61715);
      let tx = (0, r.PA)((e10) => {
        var t10, a10;
        let {
          forwardRef: i10,
          containerClassName: l2,
          isShimmerVisible: r2,
          isShimmerActive: o2,
          id: n2,
          data: d2,
          ...c2
        } = e10, { concert: m2 } = (0, _.Pjs)(), u2 = null != (a10 = null == (t10 = m2.meta) ? void 0 : t10.id) ? a10 : "", g2 = (0, v.L)(() => r2 ? (0, s.jsx)(tk.rI, { isActive: o2 }) : d2 ? (0, s.jsx)(tk.Gd, { data: d2 }) : void 0);
        return (0, s.jsx)("section", {
          ref: i10,
          className: l2,
          ...(0, f.getDataAttrFromProps)(c2),
          children: (0, s.jsx)(
            _.Bki,
            { objectId: u2, objectType: h.ky.Concert, objectPosX: 1, objectPosY: 1, objectsCount: 1, children: g2 },
            n2
          )
        });
      }), tR = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(tx, { forwardRef: t10, ...e10 }));
      var tf = a(14170), tP = a(36311), tw = a.n(tP);
      let tK = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          headingVariant: m2,
          className: u2,
          ...p2
        } = e10, b2 = (0, n.useId)(), { experiments: v2 } = (0, _.Pjs)(), A2 = (0, n.useRef)(null), T2 = v2.checkExperiment(_.zal.WebNextNewConcertCard, "on"), C2 = (0, n.useMemo)(
          () => a10 ? ((e11, t11) => Array.from(
            { length: 10 },
            (a11, i11) => e11 ? (0, s.jsx)(ee.LY, { isActive: t11 }, i11) : (0, s.jsx)(e1.Shimmer, { isActive: t11, className: tw().shimmer }, i11)
          ))(T2, i10) : null == c2 ? void 0 : c2.items.map(
            (e11, t11) => (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Concert,
                objectId: e11.id,
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: c2.items.length,
                children: T2 ? (0, s.jsx)(ee.Qb, { concert: e11 }) : (0, s.jsx)(tf.Concert, { concert: e11 })
              },
              e11.id
            )
          ),
          [null == c2 ? void 0 : c2.items, i10, a10, T2]
        );
        return (0, s.jsxs)("section", {
          ref: t10,
          className: (0, l.$)(tw().root, { [tw().root_withNewConcertCards]: T2 }, u2),
          ...(0, f.getDataAttrFromProps)(p2),
          children: [
            (0, s.jsx)(g.Tw, {
              className: o2,
              labeledForId: b2,
              title: d2.title,
              viewAllActionLink: d2.viewAllActionLink,
              controls: (0, s.jsx)(g.X9, { className: tw().controls, carouselRef: A2 }),
              headingVariant: m2
            }),
            (0, s.jsx)(P.Carousel, {
              ref: A2,
              itemClassName: (0, l.$)(tw().item, tw().important),
              className: r2,
              "aria-labelledby": b2,
              children: C2
            })
          ]
        });
      }), tO = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(tK, { forwardRef: t10, ...e10 }));
      var tM = a(2885), tD = a.n(tM), tB = a(5956), tV = a(91228), tU = a.n(tV);
      let tY = (e10) => {
        let { className: t10, title: a10, subtitle: i10, covers: r2, link: o2, type: c2, withLastPlayed: m2 } = e10, u2 = (0, _.NKK)(), p2 = (0, n.useMemo)(() => {
          if (0 !== r2.length)
            return (0, s.jsx)("div", {
              className: tU().covers,
              ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_BASE_ITEM_COVERS),
              children: r2.slice(0, 2).map(
                (e11, t11) => (0, s.jsx)(
                  S.Paper,
                  {
                    className: tU().coverContainer,
                    radius: "xs",
                    children: (0, s.jsx)(ez.Image, {
                      className: tU().cover,
                      size: 80,
                      src: e11.uri,
                      fit: "contain",
                      withAvatarReplace: true,
                      fallbackIconSize: "s",
                      ...(0, d.Am)("".concat(d.e8.landing.CONTINUE_LISTEN_BASE_ITEM_COVERS, "_").concat(t11))
                    })
                  },
                  t11
                )
              )
            });
        }, [r2]), b2 = (0, n.useCallback)(() => {
          u2({ to: h.QT.Link });
        }, [u2]);
        return (0, s.jsx)(S.Paper, {
          className: (0, l.$)(
            tU().root,
            tU()["root_".concat(c2)],
            { [tU().root_withCovers]: r2.length > 0, [tU().root_withLastPlayed]: m2 },
            t10
          ),
          radius: "l",
          ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_BASE_ITEM),
          children: (0, s.jsx)(g.N_, {
            className: tU().link,
            href: o2,
            onClick: b2,
            ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_BASE_ITEM_LINK),
            children: (0, s.jsxs)("div", {
              className: tU().content,
              children: [
                (0, s.jsxs)("div", {
                  className: tU().textContainer,
                  children: [
                    (0, s.jsxs)(E.Caption, {
                      className: tU().title,
                      size: "m",
                      variant: "div",
                      ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_BASE_ITEM_LINK_TITLE),
                      children: [
                        a10,
                        (0, s.jsx)(tB.Icon, { className: tU().titleIcon, size: "xs", variant: "arrowRight" })
                      ]
                    }),
                    i10 && (0, s.jsx)(E.Caption, {
                      className: tU().subtitle,
                      size: "m",
                      variant: "div",
                      lineClamp: 2,
                      ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_BASE_ITEM_LINK_SUBTITLE),
                      children: i10
                    })
                  ]
                }),
                p2
              ]
            })
          })
        });
      };
      var tG = a(1365), tW = a(35190), tX = a(22142), tF = a.n(tX);
      let tH = (0, r.PA)((e10) => {
        var t10, a10, i10, r2, o2;
        let { className: m2, lastPlayed: u2 } = e10, { objectsCount: p2 } = (0, _.N8n)(), { formatMessage: b2 } = (0, I.A)(), { sonataState: A2, continueListen: T2 } = (0, _.Pjs)(), C2 = (0, _.eGp)(), L2 = (0, eT.$4)(), {
          album: N2,
          playlist: j2,
          track: k2,
          getTrackMeta: x2,
          getPlaylistMeta: R2,
          isNeededToLoad: f2,
          isRejected: P2,
          albumDuration: w2,
          albumDurationLeft: K2
        } = u2.data, {
          track: O2,
          trackIndex: M2,
          contextType: D2,
          contextId: B2,
          albumDuration: V2,
          albumStreamProgress: U2,
          trackTempStreamProgress: Y2
        } = T2, G2 = (0, _.brA)(), W2 = (0, _.PT7)(), X2 = (0, n.useMemo)(() => O2 || k2, [O2, k2]), F2 = (null == (t10 = A2.entityMeta) ? void 0 : t10.isPodcast) || (null == (a10 = A2.entityMeta) ? void 0 : a10.isAudiobook), H2 = (0, n.useCallback)(async () => {
          let e11 = await x2();
          !T2.track && e11 && (T2.saveTrack({
            contextType: N2 ? y.K.Album : y.K.Playlist,
            contextId: N2 ? N2.id : String(null == j2 ? void 0 : j2.id),
            track: e11,
            isDefaultTrack: true
          }), w2 && K2 && (T2.saveAlbumDuration(w2), T2.albumStreamProgress.updateEndPositionSec(w2 - K2)));
        }, [T2, N2, w2, K2, x2, null == j2 ? void 0 : j2.id]), z2 = (0, n.useCallback)(async () => {
          let e11 = await R2();
          T2.trackIndex || "number" != typeof e11 || T2.saveTrackIndex(e11);
        }, [R2, T2]);
        (0, n.useEffect)(() => {
          f2 && (H2(), z2());
        }, [f2, H2, z2]);
        let $2 = D2 === y.K.Album && X2.mainAlbum && (null == X2 ? void 0 : X2.mainAlbum.isAudiobook), q2 = (0, n.useCallback)(
          (e11) => {
            var t11, a11;
            if (e11 && e11.duration && (e11.duration === 1 / 0 ? null == (t11 = X2.streamProgress) || t11.updateEndPositionSec(0) : null == (a11 = X2.streamProgress) || a11.updateEndPositionSec(e11.position), $2)) {
              let t12 = (null == U2 ? void 0 : U2.endPositionSec) || 0, a12 = e11.position, i11 = a12 - ((null == Y2 ? void 0 : Y2.endPositionSec) || 0);
              null == U2 || U2.updateEndPositionSec(t12 + i11), null == Y2 || Y2.updateEndPositionSec(a12);
            }
          },
          [X2.streamProgress, U2, Y2, $2]
        ), J2 = $2 ? (null == U2 ? void 0 : U2.endPositionSec) || 0 : (null == (i10 = X2.streamProgress) ? void 0 : i10.endPositionSec) || 0, Z2 = X2.durationMs ? X2.durationMs / 1e3 : 0, Q2 = $2 ? V2 || 0 : Z2, ee2 = (0, eT.mw)(J2, Q2), et2 = (0, n.useMemo)(() => (0, tG.A)(q2, 500), [q2]), { isPlaying: ea2, togglePlay: ei2 } = ((e11) => {
          let { track: t11, trackIndex: a11, contextType: i11, contextId: s2 } = e11, l2 = (0, n.useMemo)(() => {
            switch (i11) {
              case y.K.Playlist:
                return { type: y.K.Playlist, meta: { id: String(s2) } };
              case y.K.Album:
                return { type: y.K.Album, meta: { id: Number(s2) } };
              case y.K.Various:
                return { type: y.K.Various, meta: { id: Number(s2) } };
              case y.K.Artist:
                return { type: y.K.Artist, meta: { id: Number(s2) } };
              case y.K.Generative:
                return { type: y.K.Generative, meta: { id: Number(s2) } };
              case y.K.Vibe:
                return { type: y.K.Vibe, meta: { id: String(s2) } };
              default:
                return { type: y.K.Various, meta: { id: "" } };
            }
          }, [i11, s2]), { from: r3, utmLink: o3 } = (0, _.fyy)({ contextId: l2.meta.id, contextType: l2.type }), d2 = (0, v.L)(() => {
            switch (i11) {
              case y.K.Playlist:
                return { type: y.K.Playlist, meta: { id: String(s2) }, from: r3, utmLink: o3 };
              case y.K.Album:
                return { type: y.K.Album, meta: { id: Number(s2) }, from: r3, utmLink: o3 };
              case y.K.Various:
                return { type: y.K.Various, meta: { id: Number(s2) }, from: r3, utmLink: o3 };
              case y.K.Artist:
                return { type: y.K.Artist, meta: { id: Number(s2) }, from: r3, utmLink: o3 };
              case y.K.Generative:
                return { type: y.K.Generative, meta: { id: Number(s2) }, from: r3, utmLink: o3 };
              case y.K.Vibe:
                return {
                  type: y.K.Vibe,
                  meta: { id: String(s2) },
                  seeds: [String(s2)],
                  includeTracksInResponse: true,
                  trackToStartFrom: t11.id,
                  from: r3,
                  utmLink: o3
                };
              default:
                return { type: y.K.Playlist, meta: { id: "" }, from: r3, utmLink: o3 };
            }
          });
          return (0, _.Dx4)({
            playContextParams: { contextData: d2, queueParams: { entityId: t11.id, index: a11 }, loadContextMeta: true },
            entityId: t11.entityId
          });
        })({ track: X2, trackIndex: M2, contextType: D2, contextId: B2 }), es2 = (0, c.c)(() => {
          W2() || (ei2(), G2(!ea2));
        }), el2 = (0, n.useMemo)(() => ({ "--color-background": X2.averageColor }), [X2.averageColor]);
        (0, n.useEffect)(() => {
          let e11, t11 = null == C2 ? void 0 : C2.state.queueState.currentEntity.onChange(() => {
            null == e11 || e11(), e11 = C2.state.playerState.progress.onChange(() => {
              let e12 = C2.state.playerState.progress.value;
              F2 && et2(e12);
            });
          });
          return () => {
            null == t11 || t11(), null == e11 || e11();
          };
        }, [C2, et2, F2, X2.streamProgress]);
        let er2 = $2 ? X2.mainAlbum.title : X2.title, eo2 = $2 ? X2.mainAlbum.coverUri : X2.coverUri, en2 = (0, n.useMemo)(() => {
          var e11;
          return b2({ id: "entity-names.album-name" }, { albumName: null == (e11 = X2.mainAlbum) ? void 0 : e11.title });
        }, [b2, null == (r2 = X2.mainAlbum) ? void 0 : r2.title]), ed2 = (0, n.useMemo)(
          () => $2 ? en2 : b2({ id: "entity-names.track-name" }, { trackName: X2.title }),
          [b2, $2, en2, X2.title]
        ), ec2 = $2 ? X2.mainAlbum.explicitDisclaimer : X2.explicitDisclaimer, em2 = L2(Q2 - J2, false);
        return P2 ? null : (0, s.jsx)(
          _.Bki,
          {
            objectType: h.ky.Track,
            objectId: String(X2.id),
            objectPosX: 0,
            objectPosY: 1,
            objectsCount: p2,
            children: (0, s.jsxs)(S.Paper, {
              className: (0, l.$)(tF().root, m2),
              radius: "l",
              style: el2,
              "aria-label": er2,
              ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_TRACK),
              children: [
                (0, s.jsxs)("div", {
                  className: tF().content,
                  children: [
                    (0, s.jsx)(g.BW, {
                      className: (0, l.$)(tF().cover, tF().important),
                      src: eo2,
                      size: 50,
                      alt: ed2,
                      fit: "cover",
                      withAvatarReplace: true,
                      isAvailable: X2.isAvailable,
                      fallbackIconSize: "xs",
                      "aria-hidden": true
                    }),
                    (0, s.jsxs)("div", {
                      className: tF().metaTrack,
                      children: [
                        (0, s.jsxs)(g.N_, {
                          className: tF().metaContainer,
                          href: null == (o2 = X2.mainAlbum) ? void 0 : o2.url,
                          ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_TRACK_META_LINK),
                          children: [
                            (0, s.jsx)(E.Caption, {
                              className: tF().title,
                              type: "entity",
                              size: "m",
                              weight: "medium",
                              variant: "span",
                              lineClamp: 1,
                              "aria-label": en2,
                              ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_TRACK_META_LINK_TITLE),
                              children: er2
                            }),
                            ec2 && (0, s.jsx)(g.Nq, {
                              getDescriptionTexts: X2.getDescriptionTexts,
                              size: "xs",
                              variant: ec2,
                              className: tF().explicitMark
                            }),
                            (0, s.jsx)(tB.Icon, { className: tF().titleIcon, size: "xs", variant: "arrowRight" })
                          ]
                        }),
                        (0, s.jsx)("div", {
                          className: tF().progress,
                          children: !!Q2 && (0, s.jsxs)(s.Fragment, {
                            children: [
                              (0, s.jsx)(tW.q, {
                                "aria-valuetext": ee2,
                                "aria-busy": ea2 && F2,
                                fullCircleClassName: tF().fullCircle,
                                progressCircleClassName: tF().progressCircle,
                                value: J2,
                                max: Q2,
                                ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_TRACK_META_CIRCLE_PROGRESS)
                              }),
                              (0, s.jsx)(E.Caption, {
                                lineClamp: 1,
                                variant: "div",
                                size: "m",
                                ...(0, d.Am)(d.e8.landing.CONTINUE_LISTEN_TRACK_META_PROGRESS_TEXT),
                                children: em2
                              })
                            ]
                          })
                        })
                      ]
                    })
                  ]
                }),
                (0, s.jsx)(g.DM, {
                  variant: "filled",
                  className: tF().playButton,
                  isPlaying: ea2 && F2,
                  onClick: es2,
                  iconSize: "m"
                })
              ]
            })
          },
          X2.id
        );
      }), tz = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          headerClassName: r2,
          containerClassName: o2,
          headingVariant: d2,
          data: c2,
          ...m2
        } = e10, { formatMessage: u2 } = (0, I.A)(), p2 = (0, n.useId)(), { objectsCount: b2 } = (0, _.N8n)(), v2 = (0, n.useMemo)(() => {
          if (!c2 || a10)
            return Array.from(
              { length: 3 },
              (e12, t12) => (0, s.jsx)(e1.Shimmer, { className: tD().item, isActive: i10 }, t12)
            );
          let e11 = [
            c2.bookshelf.bookCount ? u2({ id: "entity-names.number-of-books" }, { counter: c2.bookshelf.bookCount }) : void 0,
            c2.bookshelf.podcastCount ? u2({ id: "entity-names.number-of-podcasts" }, { counter: c2.bookshelf.podcastCount }) : void 0
          ].filter(Boolean).join(",\n"), t11 = c2.newEpisodes.trackCount ? u2({ id: "entity-names.number-of-episodes" }, { counter: c2.newEpisodes.trackCount }) : void 0, r3 = [];
          return c2.lastPlayed && r3.push(
            (0, s.jsx)(
              tH,
              { className: (0, l.$)(tD().item, tD().item_lastPlayed), lastPlayed: c2.lastPlayed },
              c2.lastPlayed.type
            )
          ), r3.push(
            (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Text,
                objectId: "bookshelf",
                objectPosX: 1,
                objectPosY: 1,
                objectsCount: b2,
                children: (0, s.jsx)(tY, {
                  className: tD().item,
                  type: "bookshelf",
                  link: _.Zyd.collectionShelf.href,
                  title: c2.bookshelf.title,
                  subtitle: e11,
                  covers: c2.bookshelf.covers,
                  withLastPlayed: !!c2.lastPlayed
                })
              },
              c2.bookshelf.title
            ),
            (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Text,
                objectId: "newEpisodes",
                objectPosX: 2,
                objectPosY: 1,
                objectsCount: b2,
                children: (0, s.jsx)(tY, {
                  className: tD().item,
                  type: "newEpisodes",
                  link: _.Zyd.collectionShelfNewEpisodes.href,
                  title: c2.newEpisodes.title,
                  subtitle: t11,
                  covers: c2.newEpisodes.covers,
                  withLastPlayed: !!c2.lastPlayed
                })
              },
              c2.newEpisodes.title
            )
          ), r3;
        }, [u2, c2, i10, a10, b2]);
        return (0, s.jsxs)("section", {
          ref: t10,
          ...(0, f.getDataAttrFromProps)(m2),
          children: [
            (0, s.jsx)(g.Tw, {
              className: r2,
              labeledForId: p2,
              title: u2({ id: "non-music.continue-listen-landing-block-title" }),
              headingVariant: d2
            }),
            (0, s.jsx)("div", {
              className: tD().blocksContainer,
              children: (0, s.jsx)("div", {
                className: (0, l.$)(tD().container, o2),
                "aria-labelledby": p2,
                children: v2
              })
            })
          ]
        });
      }, t$ = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(tz, { forwardRef: t10, ...e10 })), tq = (e10) => {
        let { forwardRef: t10, headerClassName: a10, headingVariant: i10, meta: l2, ...r2 } = e10;
        return (0, s.jsx)(_.Bki, {
          objectType: h.ky.Text,
          objectId: String(l2.viewAllActionLink),
          objectPosX: 1,
          objectPosY: 1,
          objectsCount: 0,
          children: (0, s.jsx)("section", {
            ref: t10,
            ...(0, f.getDataAttrFromProps)(r2),
            children: (0, s.jsx)(g.Tw, {
              className: a10,
              title: l2.title,
              headingVariant: i10,
              viewAllActionLink: l2.viewAllActionLink
            })
          })
        });
      }, tJ = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(tq, { forwardRef: t10, ...e10 }));
      var tZ = a(7981);
      let tQ = (0, r.PA)((e10) => {
        let { donation: t10 } = e10, { ref: a10, intersectionPropertyId: i10 } = (0, _.nMI)(), l2 = (0, tZ.Q$)()(t10.url), r2 = (0, _.ZpR)(l2), o2 = (0, _.ZpR)(t10.artist.url), n2 = (0, _.NKK)(), d2 = (0, c.c)(() => {
          n2({ to: h.QT.ArtistScreen }), o2();
        }), m2 = (0, c.c)(() => {
          n2({ to: h.QT.Link, deepLink: l2 }), r2();
        }), u2 = (0, j.SA)({ artist: t10.artist, callback: d2 });
        return (0, s.jsx)(tZ.Xx, {
          ref: a10,
          "data-intersection-property-id": i10,
          artist: t10.artist,
          goal: t10.goal,
          onNavigateToArtist: u2,
          onNavigateToDonation: m2
        });
      }), t0 = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: d2,
          headingVariant: c2,
          className: m2,
          ...u2
        } = e10, g2 = (0, n.useMemo)(
          () => !a10 && (null == d2 ? void 0 : d2.items) ? d2.items.map((e11, t11) => {
            let { data: a11 } = e11;
            return (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Donation,
                objectId: a11.artist.id,
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: d2.items.length,
                children: (0, s.jsx)(tQ, { donation: a11 })
              },
              a11.artist.id
            );
          }) : (0, tZ.kZ)(i10),
          [null == d2 ? void 0 : d2.items, i10, a10]
        );
        return (0, s.jsx)(tZ.x0, {
          containerClassName: l2,
          headerClassName: r2,
          headingVariant: c2,
          className: m2,
          forwardRef: t10,
          description: o2.description,
          viewAllActionLink: o2.viewAllActionLink,
          title: o2.title,
          ...u2,
          children: g2
        });
      }, t1 = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(t0, { forwardRef: t10, ...e10 }));
      var t3 = a(91549), t4 = a(34282), t2 = a(66149), t6 = a.n(t2);
      let t8 = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          className: m2,
          headingVariant: u2,
          ..._2
        } = e10, p2 = (0, n.useId)(), b2 = (0, n.useRef)(null), { shouldHideControls: v2 } = (0, t3.Y)(b2), A2 = !!(d2.description || d2.title || !v2), T2 = (0, n.useMemo)(
          () => a10 ? (0, s.jsx)(t4.R, { isActive: i10, ref: b2, containerClassName: r2, ariaLabelledBy: p2, length: 9 }) : (0, s.jsx)(t4.k, {
            ref: b2,
            containerClassName: r2,
            ariaLabelledBy: p2,
            items: null == c2 ? void 0 : c2.items
          }),
          [null == c2 ? void 0 : c2.items, i10, a10, r2, p2]
        );
        return (0, s.jsxs)("section", {
          className: (0, l.$)(t6().root, m2),
          ref: t10,
          ...(0, f.getDataAttrFromProps)(_2),
          children: [
            A2 && (0, s.jsx)(g.Tw, {
              className: o2,
              title: d2.title,
              description: d2.description,
              labeledForId: p2,
              viewAllActionLink: d2.viewAllActionLink,
              controls: (0, s.jsx)(g.X9, { className: t6().controls, carouselRef: b2 }),
              headingVariant: u2,
              withDescription: !!d2.description
            }),
            T2
          ]
        });
      }, t5 = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(t8, { forwardRef: t10, ...e10 }));
      var t7 = a(44547), t9 = a.n(t7);
      let ae = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          className: m2,
          headingVariant: u2,
          ...p2
        } = e10, b2 = (0, n.useId)(), v2 = (0, n.useRef)(null), { shouldHideControls: A2 } = (0, t3.Y)(v2), T2 = !!(d2.description || d2.title || !A2), C2 = (0, n.useMemo)(() => {
          var e11;
          return a10 ? (0, s.jsx)(P.Carousel, {
            ref: v2,
            itemClassName: (0, l.$)(t9().item, t9().important),
            className: r2,
            "aria-labelledby": "".concat(b2, " ").concat(b2, "-description"),
            children: (0, g.km)({ isActive: i10, centered: true })
          }) : (0, s.jsx)(P.Carousel, {
            ref: v2,
            itemClassName: (0, l.$)(t9().item, t9().important),
            className: r2,
            "aria-labelledby": "".concat(b2, " ").concat(b2, "-description"),
            children: null == c2 || null == (e11 = c2.items) ? void 0 : e11.map((e12, t11) => {
              var a11;
              return (0, s.jsx)(
                _.Bki,
                {
                  objectType: h.ky.Wave,
                  objectId: e12.stationId,
                  objectPosX: t11 + 1,
                  objectPosY: 1,
                  objectsCount: null == (a11 = c2.items) ? void 0 : a11.length,
                  children: (0, s.jsx)(e$.yi, { vibe: e12 })
                },
                e12.stationId
              );
            })
          });
        }, [null == c2 ? void 0 : c2.items, i10, a10, r2, b2]);
        return (0, s.jsxs)("section", {
          className: (0, l.$)(t9().root, m2),
          ref: t10,
          ...(0, f.getDataAttrFromProps)(p2),
          children: [
            T2 && (0, s.jsx)(g.Tw, {
              className: o2,
              title: d2.title,
              description: d2.description,
              labeledForId: b2,
              viewAllActionLink: d2.viewAllActionLink,
              controls: (0, s.jsx)(g.X9, { className: t9().controls, carouselRef: v2 }),
              headingVariant: u2,
              withDescription: !!d2.description
            }),
            C2
          ]
        });
      }, at = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(ae, { forwardRef: t10, ...e10 }));
      var aa = a(62277), ai = a(33519), as = a.n(ai);
      let al = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          headerClassName: l2,
          meta: r2,
          data: o2,
          headingVariant: n2,
          className: d2,
          ...c2
        } = e10, { artist: m2 } = (0, _.Pjs)(), { formatMessage: u2 } = (0, I.A)(), p2 = (0, v.L)(() => {
          if (!o2) return;
          let e11 = [];
          return o2.tracksCount && e11.push(u2({ id: "entity-names.tracks-count" }, { value: o2.tracksCount })), o2.collectionAlbumCount && e11.push(u2({ id: "entity-names.albums-count" }, { value: o2.collectionAlbumCount })), e11.join(" • ");
        });
        return (0, s.jsx)("section", {
          ref: t10,
          className: d2,
          ...(0, f.getDataAttrFromProps)(c2),
          children: (0, s.jsx)(g.Tw, {
            className: l2,
            title: r2.title,
            coverUrl: "avatars.mds.yandex.net/get-music-misc/2419084/img.65faec7dd0866004f49a38bc/%%",
            controls: false,
            viewAllActionLink: null == o2 ? void 0 : o2.href(m2.id),
            coverContainerClassName: as().cover,
            shimmerCoverClassName: as().shimmerCover,
            headingVariant: n2,
            titleLineClamp: 1,
            withDescription: true,
            description: p2,
            isShimmerActive: i10,
            isShimmerVisible: a10
          })
        });
      }), ar = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(al, { forwardRef: t10, ...e10 }));
      var ao = a(54895), an = a.n(ao);
      let ad = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          headingVariant: m2,
          className: p2,
          ...b2
        } = e10, { objectsCount: v2 } = (0, _.N8n)(), A2 = (0, u.useTabsState)(0), T2 = (0, n.useId)(), C2 = (0, n.useRef)(null), I2 = (0, n.useId)(), L2 = (0, n.useMemo)(
          () => a10 ? (0, s.jsx)(P.Carousel, {
            ref: C2,
            itemClassName: (0, l.$)(an().item, an().important),
            className: r2,
            "aria-labelledby": "".concat(T2, " ").concat(T2, "-description"),
            children: (0, g.km)({ isActive: i10 })
          }) : null == c2 ? void 0 : c2.items.map(
            (e11) => (0, s.jsx)(
              u.TabPanel,
              {
                name: e11.tab.id,
                value: A2.value,
                elementId: I2,
                children: (0, s.jsx)(P.Carousel, {
                  ref: C2,
                  itemClassName: (0, l.$)(an().item, an().important),
                  className: r2,
                  "aria-labelledby": "".concat(T2, " ").concat(T2, "-description"),
                  children: e11.data.map(
                    (t11, a11) => (0, s.jsx)(
                      _.Bki,
                      {
                        objectType: h.ky.Album,
                        objectId: String(t11.id),
                        objectPosX: a11 + 1,
                        objectPosY: 1,
                        objectsCount: e11.data.length,
                        children: (0, s.jsx)(eg.aX, { contentLinesCount: 3, album: t11 })
                      },
                      t11.id
                    )
                  )
                })
              },
              e11.tab.id
            )
          ),
          [a10, null == c2 ? void 0 : c2.items, r2, T2, i10, A2.value, I2]
        );
        return (0, s.jsxs)("section", {
          className: (0, l.$)(an().root, p2),
          ref: t10,
          ...(0, f.getDataAttrFromProps)(b2),
          children: [
            (0, s.jsx)(_.Bki, {
              objectType: h.ky.Shortcut,
              objectId: String(d2.viewAllActionLink),
              objectPosX: 0,
              objectPosY: 0,
              objectsCount: null != v2 ? v2 : 0,
              children: (0, s.jsx)(g.Tw, {
                className: (0, l.$)(o2, an().header, an().important),
                title: d2.title,
                description: d2.description,
                labeledForId: T2,
                viewAllActionLink: d2.viewAllActionLink,
                controls: (0, s.jsx)(g.X9, { className: an().controls, carouselRef: C2 }),
                headingVariant: m2,
                withDescription: !!d2.description
              })
            }),
            (0, s.jsx)(g.wI, {
              isShimmerVisible: a10,
              className: (0, l.$)(r2, an().tabCarousel, an().important),
              elementId: I2,
              shimmer: (0, s.jsx)(g.nR, { isActive: i10, className: (0, l.$)(r2, an().tabCarousel, an().important) }),
              "aria-labelledby": T2,
              ...A2,
              children: null == c2 ? void 0 : c2.items.map((e11) => {
                let { tab: t11 } = e11;
                return (0, s.jsx)(
                  g.oz,
                  {
                    value: t11.id,
                    "aria-label": t11.title,
                    title: t11.title,
                    covers: t11.covers,
                    className: (0, l.$)(an().tab, an().important),
                    withCovers: true
                  },
                  t11.id
                );
              })
            }),
            L2
          ]
        });
      }), ac = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(ad, { forwardRef: t10, ...e10 }));
      var am = a(56259), au = a.n(am);
      let a_ = (e10) => {
        var t10;
        let {
          containerClassName: a10,
          meta: i10,
          data: l2,
          forwardRef: r2,
          isShimmerVisible: o2,
          isShimmerActive: c2,
          headingVariant: m2
        } = e10, u2 = (0, n.useMemo)(() => {
          if (o2) {
            var e11;
            return (0, g.q$)({
              className: au().root,
              shimmerClassName: au().shimmer,
              isActive: c2,
              count: (null == (e11 = i10.source) ? void 0 : e11.countWeb) || 10,
              minWidth: 30,
              maxWidth: 70
            });
          }
          return (0, s.jsx)("div", {
            className: au().root,
            children: null == l2 ? void 0 : l2.items.map(
              (e12) => (0, s.jsx)(
                g.Tw,
                {
                  titleLineClamp: 1,
                  title: e12.data.title,
                  viewAllActionLink: e12.data.viewAllActionLink,
                  headingVariant: m2
                },
                e12.key
              )
            )
          });
        }, [null == l2 ? void 0 : l2.items, m2, c2, o2, null == (t10 = i10.source) ? void 0 : t10.countWeb]);
        return (0, s.jsx)("section", {
          ref: r2,
          title: i10.title,
          className: a10,
          ...(0, d.Am)(d.e8.landing.ITEM_LIST),
          children: u2
        });
      }, ag = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(a_, { forwardRef: t10, ...e10 }));
      var ap = a(48771), ab = a.n(ap), av = a(75987), aA = a.n(av);
      let aT = (0, r.PA)((e10) => {
        let { title: t10, subtitle: a10, link: i10, testId: l2, icon: r2, covers: o2, navigateTo: c2 } = e10, {
          settings: { isMobile: m2 }
        } = (0, _.Pjs)(), u2 = (0, _.NKK)(), { ref: p2, intersectionPropertyId: b2 } = (0, _.nMI)(), v2 = (0, n.useMemo)(() => {
          if (0 !== o2.length)
            return (0, s.jsx)("div", {
              className: aA().covers,
              children: o2.map(
                (e11, t11) => (0, s.jsx)(
                  S.Paper,
                  {
                    className: aA().coverContainer,
                    radius: "xs",
                    ...(0, d.Am)(d.e8.landing.LIKES_HISTORY_COVERS),
                    children: (0, s.jsx)(ez.Image, {
                      size: 80,
                      className: aA().cover,
                      src: e11.uri,
                      fit: "cover",
                      withAvatarReplace: true
                    })
                  },
                  t11
                )
              )
            });
        }, [o2]), A2 = (0, n.useCallback)(() => {
          u2({ to: c2 });
        }, [c2, u2]);
        return (0, s.jsx)("div", {
          ref: p2,
          "data-intersection-property-id": b2,
          className: aA().root,
          ...(0, d.Am)(l2),
          children: (0, s.jsxs)(g.N_, {
            className: aA().link,
            href: i10,
            onClick: A2,
            children: [
              (0, s.jsxs)("div", {
                className: aA().start,
                children: [
                  r2,
                  (0, s.jsxs)("div", {
                    className: aA().textContainer,
                    children: [
                      (0, s.jsxs)(E.Heading, {
                        className: aA().title,
                        size: m2 ? "xs" : "m",
                        variant: "h2",
                        ...(0, d.Am)(d.e8.landing.LIKES_HISTORY_TITLE),
                        children: [
                          t10,
                          (0, s.jsx)(tB.Icon, { className: aA().titleIcon, size: "xs", variant: "arrowRight" })
                        ]
                      }),
                      (0, s.jsx)(E.Caption, {
                        className: aA().subtitle,
                        size: "m",
                        variant: "div",
                        lineClamp: 1,
                        ...(0, d.Am)(d.e8.landing.LIKES_HISTORY_SUBTITLE),
                        children: a10
                      })
                    ]
                  })
                ]
              }),
              v2
            ]
          })
        });
      }), aC = (e10) => {
        let { isActive: t10 } = e10;
        return (0, s.jsx)(e1.Shimmer, { isActive: t10, className: aA().root, height: 82 });
      }, ah = (e10) => {
        let { forwardRef: t10, isShimmerVisible: a10, isShimmerActive: i10, data: l2, ...r2 } = e10, { formatMessage: o2 } = (0, I.A)(), { favorites: c2, history: m2 } = l2 || {}, u2 = (0, n.useMemo)(
          () => c2 && m2 && !a10 ? [
            (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Playlist,
                objectId: c2.id,
                objectPosX: 1,
                objectPosY: 1,
                objectsCount: 2,
                children: (0, s.jsx)(aT, {
                  title: c2.title,
                  subtitle: o2({ id: "entity-names.number-of-tracks" }, { counter: c2.count }),
                  link: c2.url,
                  navigateTo: h.QT.PlaylistScreen,
                  testId: d.e8.landing.LIKES_BLOCK,
                  icon: (0, s.jsx)(S.Paper, {
                    className: ab().favoritesCoverContainer,
                    radius: "m",
                    children: (0, s.jsx)(ez.Image, {
                      className: ab().favoritesCover,
                      size: 80,
                      src: c2.cover.uri,
                      fit: "cover",
                      withAvatarReplace: true,
                      alt: c2.title
                    })
                  }),
                  covers: c2.trackCovers
                })
              },
              c2.id
            ),
            (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Shortcut,
                objectId: m2.id,
                objectPosX: 2,
                objectPosY: 1,
                objectsCount: 2,
                children: (0, s.jsx)(aT, {
                  title: m2.title,
                  subtitle: m2.artists.join(", "),
                  link: m2.url,
                  navigateTo: h.QT.MusicHistoryScreen,
                  testId: d.e8.landing.HISTORY_BLOCK,
                  icon: (0, s.jsx)(S.Paper, {
                    className: ab().historyIconContainer,
                    radius: "m",
                    children: (0, s.jsx)(tB.Icon, {
                      className: ab().historyIcon,
                      variant: "history",
                      size: "m"
                    })
                  }),
                  covers: m2.trackCovers
                })
              },
              m2.id
            )
          ] : [(0, s.jsx)(aC, { isActive: i10 }, 0), (0, s.jsx)(aC, { isActive: i10 }, 1)],
          [c2, o2, m2, i10, a10]
        );
        return (0, s.jsx)("section", {
          ref: t10,
          className: ab().root,
          ...(0, f.getDataAttrFromProps)(r2),
          children: (0, s.jsx)(P.Carousel, {
            className: ab().carousel,
            itemClassName: ab().carouselItem,
            children: u2
          })
        });
      }, aI = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(ah, { forwardRef: t10, ...e10 }));
      var aL = a(27906), ay = a(42167), aS = a.n(ay);
      let aE = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: n2,
          headingVariant: c2,
          className: m2,
          ...u2
        } = e10;
        return (0, s.jsx)(g.OY, {
          className: m2,
          ...u2,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          title: o2.title,
          description: o2.description,
          viewAllActionLink: o2.viewAllActionLink,
          itemClassName: aS().item,
          showShimmerInfo: false,
          ref: t10,
          headingVariant: c2,
          ...(0, d.Am)(d.e8.landing.MIXES_BLOCK),
          children: null == n2 ? void 0 : n2.items.map(
            (e11) => (0, s.jsx)(
              aL.NZ,
              {
                title: e11.title,
                weblink: e11.weblink,
                covers: e11.covers,
                imagesLayoutType: e11.imagesLayoutType,
                headingVariant: "h3"
              },
              e11.id
            )
          )
        });
      }, aN = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(aE, { forwardRef: t10, ...e10 }));
      var aj = a(84359), ak = a(3095), ax = a(69731), aR = a.n(ax);
      let af = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: n2,
          headingVariant: c2,
          className: m2,
          ...u2
        } = e10;
        return (0, s.jsx)(g.OY, {
          className: m2,
          ...u2,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          isShimmerWithSubcover: true,
          isShimmerCentered: true,
          shimmerClassName: aR().shimmer,
          containerClassName: l2,
          headerClassName: r2,
          title: o2.title,
          description: o2.description,
          viewAllActionLink: o2.viewAllActionLink,
          itemClassName: aR().item,
          showShimmerInfo: true,
          ref: t10,
          headingVariant: c2,
          ...(0, d.Am)(d.e8.landing.MIXES_MUSIC),
          children: null == n2 ? void 0 : n2.items.map(
            (e11, t11) => (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Shortcut,
                objectId: String(e11.id),
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: n2.items.length,
                children: (0, s.jsx)(
                  ak.Vf,
                  {
                    linkClassName: aR().item,
                    title: e11.title,
                    weblink: e11.weblink,
                    covers: e11.covers,
                    captionVariant: "h3"
                  },
                  e11.id
                )
              },
              e11.id
            )
          )
        });
      }, aP = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(af, { forwardRef: t10, ...e10 }));
      var aw = a(90937), aK = a.n(aw), aO = a(77881), aM = a(60916), aD = a.n(aM);
      let aB = (e10) => {
        let { isActive: t10 } = e10;
        return (0, s.jsx)(e1.Shimmer, { isActive: t10, className: aD().root });
      }, aV = (0, r.PA)((e10) => {
        var t10, a10;
        let { neuromusic: i10 } = e10, { from: r2 } = (0, _.fyy)(), { isPlaying: o2, togglePlay: c2 } = (0, _.Dx4)({
          playContextParams: {
            contextData: { type: y.K.Generative, meta: { id: i10.stationId }, from: r2 },
            loadContextMeta: true
          }
        }), m2 = (0, n.useCallback)(
          (e11) => {
            (0, F.P)(e11, aD().ripple), c2();
          },
          [c2]
        ), u2 = (0, n.useMemo)(() => {
          var e11, t11;
          return {
            "--neuromusic-button-background": null == i10 || null == (e11 = i10.style) ? void 0 : e11.backgroundColor,
            "--neuromusic-button-color": null == i10 || null == (t11 = i10.style) ? void 0 : t11.titleColor
          };
        }, [
          null == i10 || null == (t10 = i10.style) ? void 0 : t10.backgroundColor,
          null == i10 || null == (a10 = i10.style) ? void 0 : a10.titleColor
        ]), g2 = o2 ? d.e8.landing.NEUROMUSIC_BLOCK_ITEM_PAUSE_ICON : d.e8.landing.NEUROMUSIC_BLOCK_ITEM_PLAY_ICON;
        return (0, s.jsx)(aO.$, {
          style: u2,
          withRipple: false,
          withHover: false,
          variant: "text",
          onClick: m2,
          className: (0, l.$)(aD().root, aD().button),
          ...(0, d.Am)(d.e8.landing.NEUROMUSIC_BLOCK_ITEM),
          children: (0, s.jsxs)("div", {
            className: aD().textContainer,
            children: [
              (0, s.jsx)(tB.Icon, {
                className: aD().icon,
                size: "xxs",
                variant: o2 ? "pause" : "play",
                ...(0, d.Am)(g2)
              }),
              (0, s.jsx)(E.Caption, {
                className: aD().title,
                variant: "span",
                size: "s",
                weight: "bold",
                lineClamp: 1,
                children: i10.title
              })
            ]
          })
        });
      }), aU = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          className: m2,
          headingVariant: u2,
          ..._2
        } = e10, p2 = (0, n.useId)(), b2 = (0, n.useRef)(null), v2 = (0, n.useMemo)(
          () => a10 ? Array.from({ length: 3 }, (e11, t11) => (0, s.jsx)(aB, { isActive: i10 }, t11)) : null == c2 ? void 0 : c2.items.map((e11, t11) => (0, s.jsx)(aV, { neuromusic: e11 }, t11)),
          [null == c2 ? void 0 : c2.items, i10, a10]
        );
        return (0, s.jsxs)("section", {
          ref: t10,
          className: (0, l.$)(aK().root, m2),
          ...(0, f.getDataAttrFromProps)(_2),
          children: [
            (0, s.jsx)(g.Tw, {
              className: o2,
              labeledForId: p2,
              title: d2.title,
              description: d2.description,
              controls: (0, s.jsx)(g.X9, { className: aK().controls, carouselRef: b2 }),
              headingVariant: u2,
              withDescription: !!d2.description
            }),
            (0, s.jsx)(P.Carousel, {
              ref: b2,
              itemClassName: (0, l.$)(aK().item, aK().important),
              className: r2,
              "aria-labelledby": p2,
              children: v2
            })
          ]
        });
      }, aY = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(aU, { forwardRef: t10, ...e10 })), aG = /^#[a-fA-F\d]{2}[a-fA-F\d]{2}[a-fA-F\d]{2}$/i;
      var aW = a(12110), aX = a.n(aW);
      let aF = (0, r.PA)((e10) => {
        var t10, a10, i10;
        let { album: l2, releaseDate: r2, coverColor: o2, coverUri: m2 } = e10, u2 = null == l2 || null == (t10 = l2.artists) ? void 0 : t10[0], { formatDate: p2 } = (0, I.A)(), { trailer: b2 } = (0, _.Pjs)(), { ref: v2, intersectionPropertyId: A2 } = (0, _.nMI)(), T2 = (0, _.ZpR)(null != (i10 = null == u2 ? void 0 : u2.url) ? i10 : ""), C2 = (0, j.SA)({ artist: u2, callback: T2 }), L2 = (0, _.Ftl)(), k2 = (0, N.r_)(l2.type), x2 = (0, _.PT7)(), { from: R2, utmLink: f2 } = (0, _.fyy)({ contextId: l2.id, contextType: y.K.Album }), P2 = (0, _.NKK)(), w2 = (0, c.c)((e11) => {
          P2({ to: h.QT.ArtistScreen, objectId: null == u2 ? void 0 : u2.id, objectType: h.ky.Artist }), C2(e11);
        }), K2 = (0, c.c)((e11) => {
          if (x2()) {
            e11.stopPropagation(), e11.preventDefault();
            return;
          }
          (null == l2 ? void 0 : l2.id) && (e11.stopPropagation(), b2.openAlbumTrailer(l2.id), L2(h.ky.Album, String(l2.id)));
        }), O2 = (0, n.useMemo)(() => {
          var e11;
          if (null == l2 || null == (e11 = l2.trailer) ? void 0 : e11.isAvailable)
            return (0, s.jsx)(g.cv, {
              children: (0, s.jsx)(g.kJ, {
                variant: "text",
                iconSize: "xs",
                className: aX().trailerButton,
                withRipple: false,
                onClick: K2
              })
            });
        }, [null == l2 || null == (a10 = l2.trailer) ? void 0 : a10.isAvailable, K2]), M2 = (0, n.useMemo)(() => {
          if (r2)
            return (0, s.jsxs)(E.Caption, {
              variant: "span",
              type: "text",
              size: "s",
              weight: "medium",
              className: aX().descriptionContainer,
              children: [
                (0, s.jsx)(E.Caption, {
                  variant: "span",
                  type: "text",
                  size: "s",
                  weight: "medium",
                  children: k2.toLowerCase()
                }),
                (0, s.jsx)(E.Caption, {
                  variant: "span",
                  type: "text",
                  size: "s",
                  weight: "medium",
                  children: " • "
                }),
                (0, s.jsx)(E.Caption, {
                  variant: "span",
                  type: "text",
                  size: "s",
                  weight: "medium",
                  children: p2(new Date(r2), (0, _.QB4)())
                })
              ]
            });
        }, [k2, p2, r2]);
        return (0, s.jsxs)("div", {
          className: aX().root,
          ref: v2,
          "data-intersection-property-id": A2,
          children: [
            (0, s.jsxs)("div", {
              className: aX().cover,
              children: [
                (0, s.jsxs)(S.Paper, {
                  className: aX().coverImage,
                  radius: "round",
                  withShadow: true,
                  children: [
                    (0, s.jsx)(g.BW, {
                      className: aX().image,
                      src: m2,
                      alt: null == u2 ? void 0 : u2.name,
                      size: 300,
                      fit: "cover",
                      withAvatarReplace: true,
                      "aria-hidden": true
                    }),
                    (0, s.jsx)("div", {
                      className: aX().fade,
                      style: {
                        background: ((e11) => {
                          e11 && aG.test(e11) || (e11 = "#000000");
                          let { r: t11, g: a11, b: i11 } = (0, _.E2N)(e11);
                          return "linear-gradient(180.14deg, rgba(".concat(t11, ", ").concat(a11, ", ").concat(i11, ", 0) 30.88%, rgba(").concat(t11, ", ").concat(a11, ", ").concat(i11, ", 0.4) 70.8%, rgba(").concat(t11, ", ").concat(a11, ", ").concat(i11, ", 0.9) 80.88%)");
                        })(null == l2 ? void 0 : l2.averageColor)
                      }
                    })
                  ]
                }),
                (0, s.jsx)(g.N_, {
                  className: aX().fade,
                  "aria-label": null == u2 ? void 0 : u2.name,
                  href: null == u2 ? void 0 : u2.url,
                  onClick: w2
                }),
                (0, s.jsx)(j.iQ, {
                  className: aX().artists,
                  lineClamp: 2,
                  artists: null == l2 ? void 0 : l2.artists,
                  linkClassName: aX().artistLink,
                  captionClassName: aX().artistCaption,
                  variant: "breakWord"
                })
              ]
            }),
            (0, s.jsx)(q, {
              className: aX().card,
              album: l2,
              albumUrl: l2.url,
              from: R2,
              utmLink: f2,
              trailerButton: O2,
              description: M2,
              entityName: k2,
              coverColor: o2,
              ...(0, d.Am)(d.Kq.newRelease.NEW_RELEASE_CARD)
            })
          ]
        });
      });
      var aH = a(53403), az = a.n(aH);
      let a$ = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerActive: a10,
          isShimmerVisible: i10,
          containerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          headingVariant: m2,
          className: u2,
          ...p2
        } = e10, { objectsCount: b2 } = (0, _.N8n)(), v2 = (0, n.useId)(), A2 = (0, n.useRef)(null), { theme: T2 } = (0, _.DPo)(), C2 = (0, n.useMemo)(
          () => i10 ? ((e11) => Array.from(
            { length: 6 },
            (t11, a11) => (0, s.jsxs)(
              "div",
              {
                children: [
                  (0, s.jsx)(e1.Shimmer, { isActive: e11, radius: "round", className: az().shimmerImage }),
                  (0, s.jsx)(e1.Shimmer, { isActive: e11, radius: "l", className: az().shimmerCard })
                ]
              },
              a11
            )
          ))(a10) : null == c2 ? void 0 : c2.items.map((e11, t11) => {
            let a11 = e11.coverUriWithPlaceholder(T2);
            return (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Album,
                objectId: String(e11.album.id),
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: c2.items.length,
                children: (0, s.jsx)(aF, { ...e11, coverUri: a11 })
              },
              e11.album.id
            );
          }),
          [null == c2 ? void 0 : c2.items, a10, i10, T2]
        );
        return (0, s.jsxs)("section", {
          ref: t10,
          className: (0, l.$)(az().root, u2),
          ...(0, f.getDataAttrFromProps)(p2),
          children: [
            (0, s.jsx)(_.Bki, {
              objectType: h.ky.Shortcut,
              objectId: String(d2.viewAllActionLink),
              objectPosX: 0,
              objectPosY: 0,
              objectsCount: null != b2 ? b2 : 0,
              children: (0, s.jsx)(g.Tw, {
                className: o2,
                labeledForId: v2,
                title: d2.title,
                viewAllActionLink: d2.viewAllActionLink,
                controls: (0, s.jsx)(g.X9, { className: az().controls, carouselRef: A2 }),
                headingVariant: m2
              })
            }),
            (0, s.jsx)(P.Carousel, {
              ref: A2,
              itemClassName: (0, l.$)(az().item, az().important),
              className: r2,
              "aria-labelledby": v2,
              children: C2
            })
          ]
        });
      }), aq = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(a$, { forwardRef: t10, ...e10 }));
      var aJ = a(7333), aZ = a(94124), aQ = a(985), a0 = a(22243), a1 = a.n(a0);
      let a3 = (e10) => {
        let { forwardRef: t10, containerClassName: a10, id: i10, meta: r2, ...o2 } = e10, { formatMessage: n2 } = (0, I.A)();
        return (0, s.jsx)("section", {
          ref: t10,
          className: (0, l.$)(a1().root, a10),
          ...(0, f.getDataAttrFromProps)(o2),
          children: (0, s.jsx)(
            _.Bki,
            {
              objectType: h.ky.Text,
              objectId: i10,
              objectPosX: 1,
              objectPosY: 1,
              objectsCount: 1,
              children: (0, s.jsx)(aQ.Fn, { textButton: n2({ id: "interface-actions.further" }), meta: r2 })
            },
            i10
          )
        });
      }, a4 = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(a3, { forwardRef: t10, ...e10 })), a2 = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: l2,
          headerClassName: r2,
          meta: o2,
          data: n2,
          headingVariant: d2,
          className: c2,
          ...m2
        } = e10;
        return (0, s.jsx)(g.OY, {
          className: c2,
          ...m2,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          headerClassName: r2,
          containerClassName: l2,
          title: o2.title,
          description: o2.description,
          viewAllActionLink: o2.viewAllActionLink,
          ref: t10,
          headingVariant: d2,
          children: null == n2 ? void 0 : n2.items.map(
            (e11, t11) => (0, s.jsx)(
              _.Bki,
              {
                objectType: h.ky.Playlist,
                objectId: e11.data.playlist.id,
                objectPosX: t11 + 1,
                objectPosY: 1,
                objectsCount: n2.items.length,
                children: (0, s.jsx)(tl.B6, {
                  playlist: e11.data.playlist,
                  customDescription: e11.data.description,
                  contentLinesCount: 4
                })
              },
              e11.data.playlist.key
            )
          )
        });
      }, a6 = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(a2, { forwardRef: t10, ...e10 }));
      var a8 = a(92437), a5 = a(97719);
      let a7 = (e10) => {
        let { items: t10, playlistId: a10, playlistUuid: i10, from: l2, utmLink: r2 } = e10;
        return t10.slice(0, 8).map((e11, o2) => {
          let n2, { objectPosX: d2, objectPosY: c2, objectsCount: m2 } = (0, _.$tp)({ index: o2, count: t10.length }), u2 = (n2 = e11.id, {
            contextData: {
              type: y.K.Playlist,
              meta: { id: a10, uuid: i10 },
              from: l2,
              utmLink: r2,
              completeEntitesDataByLoadedMeta: true
            },
            queueParams: { index: o2, entityId: n2 },
            loadContextMeta: true,
            entitiesData: t10.map((e12) => (0, a5.li)(e12.id, e12.albumId ? String(e12.albumId) : void 0))
          });
          return (0, s.jsx)(
            _.Bki,
            {
              objectType: h.ky.Track,
              objectId: e11.id,
              objectPosX: d2,
              objectPosY: c2,
              objectsCount: m2,
              children: e11.isTrackNonMusic ? (0, s.jsx)(ed.Kd, { track: e11, playContextParams: u2, withPodcastName: true, withTimeLeftText: false }) : (0, s.jsx)(ed.Kt, { track: e11, playContextParams: u2 })
            },
            e11.id
          );
        });
      }, a9 = { src: "/_next/static/media/heart.602389ae.png" };
      var ie = a(77561), it = a.n(ie);
      let ia = (0, r.PA)(() => {
        var e10, t10;
        let { vibe: a10 } = (0, _.Pjs)(), { pageId: i10 } = (0, _.$au)(), { blockIdForFrom: l2 } = (0, _.N8n)(), r2 = (0, _.ZpR)(_.Zyd.main.href), { formatMessage: o2 } = (0, I.A)(), { isFreemium: c2 } = (0, _.XCI)(), m2 = o2({ id: "vibe-actions.play-vibe" }), { isPlaying: u2, togglePlay: p2 } = (0, _.B0S)({
          seeds: null != (t10 = null == (e10 = a10.meta) ? void 0 : e10.seeds) ? t10 : [],
          pageIdForFrom: i10,
          blockIdForFrom: l2
        });
        (0, n.useEffect)(
          () => () => {
            a10.reset();
          },
          [a10]
        );
        let b2 = (0, n.useCallback)(() => {
          c2 || (u2 || p2(), r2());
        }, [c2, u2, r2, p2]), v2 = (0, n.useCallback)(
          () => (0, s.jsx)(aO.$, {
            withRipple: true,
            radius: "xxxl",
            size: "l",
            color: "primary",
            className: it().myWaveButton,
            "aria-label": m2,
            onClick: b2,
            ...(0, d.Am)(d.e8.landing.COLLECTION_PLAYLIST_WITH_LIKES_EMPTY_BLOCK_MY_VIBE_BUTTON),
            children: (0, s.jsx)(E.Caption, {
              variant: "span",
              size: "m",
              children: (0, s.jsx)(E.Caption, {
                variant: "span",
                size: "m",
                weight: "medium",
                className: it().myWaveButtonText,
                children: m2
              })
            })
          }),
          [m2, b2]
        );
        return a10.isNeededToLoad && (0, n.use)(a10.getLastVibe()), (0, s.jsxs)("div", {
          className: it().root,
          ...(0, d.Am)(d.e8.landing.COLLECTION_PLAYLIST_WITH_LIKES_EMPTY_BLOCK),
          children: [
            (0, s.jsx)(ez.Image, {
              src: a9.src,
              className: it().image,
              ...(0, d.Am)(d.e8.landing.COLLECTION_PLAYLIST_WITH_LIKES_EMPTY_BLOCK_IMAGE)
            }),
            (0, s.jsx)(E.Heading, {
              variant: "h3",
              size: "xs",
              className: it().header,
              ...(0, d.Am)(d.e8.landing.COLLECTION_PLAYLIST_WITH_LIKES_EMPTY_BLOCK_TITLE),
              children: (0, s.jsx)(L.A, { id: "collection.empty-liked-tracks-title" })
            }),
            (0, s.jsx)(E.Caption, {
              variant: "div",
              size: "l",
              weight: "normal",
              className: it().text,
              ...(0, d.Am)(d.e8.landing.COLLECTION_PLAYLIST_WITH_LIKES_EMPTY_BLOCK_TEXT),
              children: (0, s.jsx)(L.A, { id: "collection.empty-liked-tracks-text" })
            }),
            (0, s.jsx)(g.SU, { isEnabled: c2, placement: "top", textVariant: "vibe", renderChildren: v2 })
          ]
        });
      });
      var ii = a(20645), is = a.n(ii);
      let il = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          tracksContainerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          type: m2,
          headingVariant: u2,
          className: p2,
          ...b2
        } = e10, { from: v2, utmLink: A2 } = (0, _.fyy)({
          contextId: null == c2 ? void 0 : c2.playlist.id,
          contextType: y.K.Playlist
        }), {
          trailer: T2,
          settings: { isMobile: S2 }
        } = (0, _.Pjs)(), E2 = (0, _.Ftl)(), { formatMessage: N2 } = (0, I.A)(), j2 = eC({ playlistId: null == c2 ? void 0 : c2.playlist.id }), k2 = (null == c2 ? void 0 : c2.totalItemsCount) ? N2({ id: "entity-names.number-of-tracks" }, { counter: null == c2 ? void 0 : c2.totalItemsCount }) : d2.description, x2 = [C.t.COLLECTION_PLAYLIST_WITH_LIKES, C.t.SMART_OPEN_PLAYLIST].includes(m2), R2 = d2.coverStyle !== a8.z.NONE, f2 = (0, n.useCallback)(() => {
          (null == c2 ? void 0 : c2.playlist.id) && (T2.setUtmLink(A2), T2.openPlaylistTrailer(null == c2 ? void 0 : c2.playlist.id), E2(h.ky.Playlist, String(c2.playlist.id)));
        }, [T2, null == c2 ? void 0 : c2.playlist.id, E2, A2]), P2 = (0, n.useMemo)(() => {
          if (null == c2 ? void 0 : c2.withRewindTrailerButton)
            return S2 ? (0, s.jsx)(g.kJ, {
              className: is().trailer,
              radius: "round",
              size: "s",
              iconSize: "xs",
              onClick: f2
            }) : (0, s.jsx)(g.kJ, {
              size: "s",
              radius: "xxxl",
              iconSize: "xxs",
              className: is().trailer,
              onClick: f2,
              children: (0, s.jsx)(L.A, { id: "entity-names.trailer" })
            });
        }, [null == c2 ? void 0 : c2.withRewindTrailerButton, S2, f2]);
        return (null == c2 ? void 0 : c2.playlist.isFavouritePlaylist) && (null == c2 ? void 0 : c2.totalItemsCount) === 0 && (null == c2 ? void 0 : c2.canShowEmptyBlock) ? (0, s.jsx)(ia, {}) : (0, s.jsx)(_._Fn, {
          sourceContextData: j2,
          children: (0, s.jsx)(g.$2, {
            isShimmerActive: i10,
            shimmer: (0, s.jsx)(g.DS, { variant: _.Xjt.PLAYLIST, isActive: i10 }),
            maxColumnsCount: g.DI.TWO,
            itemsCountPerColumn: 4,
            className: (0, l.$)(is().root, p2),
            isShimmerVisible: a10,
            blockHeaderClassName: o2,
            carouselClassName: r2,
            blockHeaderTitle: d2.title,
            blockHeaderCoverUrl: null == c2 ? void 0 : c2.getCoverUri(d2.coverStyle),
            blockHeaderDescription: k2,
            viewAllActionLink: null == c2 ? void 0 : c2.playlist.url,
            ref: t10,
            blockHeaderHeadingVariant: u2,
            additionalControl: P2,
            withBlockHeaderDescription: x2,
            withBlockHeaderCover: R2,
            ...b2,
            children: (null == c2 ? void 0 : c2.items) && a7({
              items: c2.items,
              playlistId: c2.playlist.id,
              playlistUuid: c2.playlist.uuid,
              from: v2,
              utmLink: A2
            })
          })
        });
      }), ir = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(il, { forwardRef: t10, ...e10 }));
      var io = a(6197), id = a(80937), ic = a.n(id);
      let im = (0, r.PA)((e10) => {
        var t10, a10, i10;
        let {
          forwardRef: l2,
          isShimmerVisible: r2,
          isShimmerActive: o2,
          tracksContainerClassName: d2,
          headerClassName: m2,
          meta: p2,
          data: b2,
          headingVariant: A2,
          className: T2,
          ...C2
        } = e10, { formatMessage: h2 } = (0, I.A)(), { from: L2, utmLink: S2 } = (0, _.fyy)({
          contextId: null == b2 ? void 0 : b2.playlist.id,
          contextType: y.K.Playlist
        }), E2 = eC({
          playlistId: null == b2 ? void 0 : b2.playlist.id,
          filter: null == b2 ? void 0 : b2.filters.activeFilter
        }), N2 = (0, u.useTabsState)((null == b2 ? void 0 : b2.filters.activeFilterIndex) || 0), j2 = (0, n.useRef)(null), k2 = (0, _.QUC)({ objectId: null == b2 ? void 0 : b2.playlist.uuid }), x2 = null == b2 || null == (t10 = b2.filters.items) ? void 0 : t10[N2.value], R2 = (0, _.s4Q)({
          objectId: null == b2 ? void 0 : b2.playlist.uuid,
          tabId: null == x2 ? void 0 : x2.id,
          tabPos: N2.value
        }), f2 = (null == b2 ? void 0 : b2.totalItemsCount) ? h2({ id: "entity-names.number-of-tracks" }, { counter: b2.totalItemsCount }) : p2.description, P2 = (0, c.c)((e11) => {
          var t11;
          if (!N2.onTabChange || e11 === N2.value || !b2) return;
          setTimeout(() => {
            var t12, a12, i11;
            null == (i11 = j2.current) || null == (a12 = i11.children[e11]) || null == (t12 = a12.focus) || t12.call(a12);
          }), N2.onTabChange(e11);
          let a11 = null == (t11 = b2.filters.items) ? void 0 : t11[e11];
          a11 && b2.handleFilterClick(a11);
        });
        if ((0, n.useEffect)(() => {
          (null == b2 ? void 0 : b2.filters.shouldSendEventOnTabOpenedNow) && (R2(), b2.filters.setShouldSendEventOnTabOpened(false));
        }, [null == b2 ? void 0 : b2.filters, null == b2 ? void 0 : b2.filters.shouldSendEventOnTabOpenedNow, R2]), (0, n.useEffect)(() => {
          if (null == b2 ? void 0 : b2.filters.shouldSendEventOnTabLoadedNow) {
            var e11;
            null == (e11 = b2.filters.items) || e11.forEach((e12, t11) => {
              k2({ tabId: e12.id, tabPos: t11 });
            }), b2.filters.setShouldSendEventOnTabLoaded(false);
          }
        }, [null == b2 ? void 0 : b2.filters, null == b2 ? void 0 : b2.filters.shouldSendEventOnTabLoadedNow, k2]), (null == b2 ? void 0 : b2.playlistLoading.isNeededToLoad) && (0, n.use)(b2.getPlaylist()), null == b2 ? void 0 : b2.shouldShowEmptyPlaylist)
          return (0, s.jsx)(ia, {});
        let w2 = o2 || !!(null == b2 ? void 0 : b2.isLoading), K2 = r2 || !!(null == b2 ? void 0 : b2.isLoading) || !!(null == b2 ? void 0 : b2.isRejected), O2 = b2 && 0 === b2.items.length, M2 = !!(null == b2 || null == (a10 = b2.filters.items) ? void 0 : a10.length), D2 = !b2 || (null == b2 ? void 0 : b2.isLoading) || (null == b2 || null == (i10 = b2.filters) ? void 0 : i10.isShimmerVisible) || O2 || M2, B2 = (0, v.L)(() => {
          var e11, t11, a11, i11;
          if (D2)
            return (0, s.jsx)(io.A, {
              className: ic().filters,
              tabsState: N2,
              handleFilterClick: P2,
              ref: j2,
              items: null != (i11 = null == b2 || null == (e11 = b2.filters) ? void 0 : e11.items) ? i11 : void 0,
              isShimmerVisible: null == b2 || null == (t11 = b2.filters) ? void 0 : t11.isShimmerVisible,
              isShimmerActive: null == b2 || null == (a11 = b2.filters) ? void 0 : a11.isLoading,
              skipSearchCheck: true,
              shimmerClassName: ic().shimmer
            });
        });
        return (0, s.jsx)(_._Fn, {
          sourceContextData: E2,
          children: (0, s.jsx)(g.$2, {
            isShimmerActive: w2,
            shimmer: (0, s.jsx)(g.DS, { variant: _.Xjt.PLAYLIST, isActive: w2 }),
            maxColumnsCount: g.DI.TWO,
            itemsCountPerColumn: 4,
            className: T2,
            isShimmerVisible: r2,
            isColumnsShimmerVisible: K2,
            isHeaderWithoutControls: true,
            blockHeaderClassName: m2,
            carouselClassName: d2,
            blockHeaderTitle: p2.title,
            blockHeaderCoverUrl: p2.coverUri,
            blockHeaderDescription: f2,
            viewAllActionLink: null == b2 ? void 0 : b2.playlist.url,
            ref: l2,
            blockHeaderHeadingVariant: A2,
            withBlockHeaderDescription: true,
            withBlockHeaderCover: p2.coverStyle !== a8.z.NONE,
            beforeCarousel: B2,
            ...C2,
            children: (null == b2 ? void 0 : b2.items) && a7({ items: b2.items, playlistId: b2.playlist.id, playlistUuid: b2.playlist.uuid, from: L2, utmLink: S2 })
          })
        });
      }), iu = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(im, { forwardRef: t10, ...e10 }));
      var i_ = a(25743), ig = a(52239), ip = a(54830), ib = a(42827), iv = a.n(ib);
      let iA = (0, r.PA)((e10) => {
        let {
          forwardRef: t10,
          isShimmerActive: a10,
          isShimmerVisible: i10,
          data: r2,
          meta: o2,
          isLoaded: c2,
          headerClassName: m2,
          setIsNeededToLoad: u2,
          tracksContainerClassName: p2,
          className: b2,
          ...v2
        } = e10, { formatMessage: A2 } = (0, I.A)(), {
          search: { history: T2 }
        } = (0, _.Pjs)(), C2 = (0, ip.df)(), y2 = !(null == r2 ? void 0 : r2.items.length) && c2;
        return ((0, n.useLayoutEffect)(
          () => (T2.shouldUpdateHistory && (u2(), T2.setShouldUpdateHistory(false)), () => {
            T2.hasCleared && u2(), T2.reset();
          }),
          [T2, u2]
        ), y2 || T2.hasCleared) ? (0, s.jsx)("div", {
          ref: t10,
          className: (0, l.$)(iv().root, iv().fallback),
          ...(0, f.getDataAttrFromProps)(v2),
          ...(0, d.Am)(d.e8.landing.SEARCH_HISTORY_EMPTY),
          children: (0, s.jsx)(E.Caption, {
            variant: "span",
            type: "text",
            size: "l",
            weight: "normal",
            children: (0, s.jsx)(L.A, { id: "search.recent-requests-fallback" })
          })
        }) : (0, s.jsxs)("div", {
          ref: t10,
          className: iv().root,
          ...(0, f.getDataAttrFromProps)(v2),
          ...(0, d.Am)(d.e8.landing.SEARCH_HISTORY),
          children: [
            (0, s.jsx)(g.$2, {
              className: b2,
              shimmer: (0, s.jsx)(g.RJ, { isActive: a10 }),
              isShimmerActive: a10,
              isShimmerVisible: i10,
              itemsCountPerColumn: 5,
              maxColumnsCount: g.DI.TWO,
              blockHeaderClassName: m2,
              carouselClassName: p2,
              blockHeaderTitle: o2.title,
              blockHeaderDescription: o2.description,
              viewAllActionLink: o2.viewAllActionLink,
              children: null == r2 ? void 0 : r2.items.map((e11, t11) => {
                var a11, i11;
                let {
                  objectPosX: l2,
                  objectPosY: o3,
                  objectsCount: n2
                } = (0, _.$tp)({
                  index: t11,
                  count: r2.items.length,
                  itemsCountPerColumn: 5,
                  showedItemsCountInBlock: 10
                });
                switch (e11.type) {
                  case ef._.NON_MUSIC_ALBUM_ITEM:
                  case ef._.ALBUM_ITEM:
                    return (0, s.jsx)(
                      _.Bki,
                      {
                        objectType: h.ky.Album,
                        objectId: String(e11.data.id),
                        objectPosX: l2,
                        objectPosY: o3,
                        objectsCount: n2,
                        children: (0, s.jsx)(eg.M_, { album: e11.data })
                      },
                      e11.data.getKey(t11)
                    );
                  case ef._.ARTIST_ITEM:
                    return (0, s.jsx)(
                      _.Bki,
                      {
                        objectType: h.ky.Artist,
                        objectId: e11.data.id,
                        objectPosX: l2,
                        objectPosY: o3,
                        objectsCount: n2,
                        children: (0, s.jsx)(eU.cz, {
                          description: A2({ id: "entity-names.singer" }),
                          artist: e11.data
                        })
                      },
                      e11.data.getKey(t11)
                    );
                  case ef._.TRACK_ITEM:
                    return (0, s.jsx)(
                      _.Bki,
                      {
                        objectType: h.ky.Track,
                        objectId: e11.data.id,
                        objectPosX: l2,
                        objectPosY: o3,
                        objectsCount: n2,
                        children: (0, s.jsx)(ed.c8, { track: e11.data })
                      },
                      e11.data.getKey(t11)
                    );
                  case ef._.LIKED_PLAYLIST_ITEM:
                    return (0, s.jsx)(
                      _.Bki,
                      {
                        objectType: h.ky.Playlist,
                        objectId: e11.data.id,
                        objectPosX: l2,
                        objectPosY: o3,
                        objectsCount: n2,
                        children: (0, s.jsx)(tl.vf, { playlist: e11.data })
                      },
                      e11.data.getKey(t11)
                    );
                  case ef._.WAVE_ITEM:
                    return (0, s.jsx)(
                      _.Bki,
                      {
                        objectType: h.ky.Wave,
                        objectId: null != (a11 = e11.data.vibe.seeds[0]) ? a11 : "",
                        objectPosX: l2,
                        objectPosY: o3,
                        objectsCount: n2,
                        children: (0, s.jsx)(e$.H2, {
                          vibe: e11.data.vibe,
                          cover: e11.data.cover,
                          description: e11.data.vibe.getDescription(A2({ id: "entity-names.my-vibe" }))
                        })
                      },
                      e11.data.vibe.getKey(t11)
                    );
                  case ef._.WAVE_AGENT_ITEM:
                    return (0, s.jsx)(
                      _.Bki,
                      {
                        objectType: h.ky.Wave,
                        objectId: null != (i11 = e11.data.seeds[0]) ? i11 : "",
                        objectPosX: l2,
                        objectPosY: o3,
                        objectsCount: n2,
                        children: (0, s.jsx)(e$.H2, {
                          vibe: e11.data,
                          description: e11.data.getDescription(A2({ id: "entity-names.my-vibe" })),
                          agentVariant: e$.hl.SMALL
                        })
                      },
                      e11.data.getKey(t11)
                    );
                  case ef._.CLIP_ITEM:
                    if (!C2) return null;
                    return (0, s.jsx)(eL.Nk, { clip: e11.data }, e11.data.clipId);
                  default:
                    return null;
                }
              })
            }),
            c2 && (0, s.jsx)(aO.$, {
              onClick: T2.clear,
              className: iv().button,
              radius: "xxxl",
              variant: "default",
              size: "default",
              ...(0, d.Am)(d.e8.landing.SEARCH_HISTORY_CLEAR_BUTTON),
              children: (0, s.jsx)(L.A, { id: "search.clear-history" })
            })
          ]
        });
      }), iT = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(iA, { forwardRef: t10, ...e10 }));
      var iC = a(87043), ih = a.n(iC);
      let iI = (e10) => {
        var t10, a10, i10, l2, r2, o2, d2, c2, m2;
        let { containerClassName: u2, meta: g2, data: p2, forwardRef: b2, headingVariant: v2 = "h2", ...A2 } = e10, T2 = (0, _.ZpR)(null != (m2 = null == p2 ? void 0 : p2.weblink) ? m2 : ""), { theme: C2 } = (0, _.DPo)(), h2 = C2 === _.Sxu.Light ? null == p2 || null == (t10 = p2.lightTheme) ? void 0 : t10.imageUrl : null == p2 || null == (a10 = p2.darkTheme) ? void 0 : a10.imageUrl, I2 = (0, n.useMemo)(() => {
          var e11, t11;
          return {
            "--text-color": C2 === _.Sxu.Light ? null == p2 || null == (e11 = p2.lightTheme) ? void 0 : e11.textColor : null == p2 || null == (t11 = p2.darkTheme) ? void 0 : t11.textColor
          };
        }, [
          C2,
          null == p2 || null == (i10 = p2.darkTheme) ? void 0 : i10.textColor,
          null == p2 || null == (l2 = p2.lightTheme) ? void 0 : l2.textColor
        ]), L2 = (0, n.useMemo)(() => {
          var e11, t11, a11, i11;
          return {
            "--button-color": C2 === _.Sxu.Light ? null == p2 || null == (e11 = p2.lightTheme) ? void 0 : e11.buttonColor : null == p2 || null == (t11 = p2.darkTheme) ? void 0 : t11.buttonColor,
            "--button-text-color": C2 === _.Sxu.Light ? null == p2 || null == (a11 = p2.lightTheme) ? void 0 : a11.buttonTextColor : null == p2 || null == (i11 = p2.darkTheme) ? void 0 : i11.buttonTextColor
          };
        }, [
          C2,
          null == p2 || null == (r2 = p2.darkTheme) ? void 0 : r2.buttonColor,
          null == p2 || null == (o2 = p2.lightTheme) ? void 0 : o2.buttonColor,
          null == p2 || null == (d2 = p2.darkTheme) ? void 0 : d2.buttonTextColor,
          null == p2 || null == (c2 = p2.lightTheme) ? void 0 : c2.buttonTextColor
        ]);
        return (0, s.jsx)("section", {
          ref: b2,
          title: g2.title,
          className: u2,
          ...(0, f.getDataAttrFromProps)(A2),
          children: (0, s.jsxs)("div", {
            className: ih().root,
            children: [
              (0, s.jsxs)("div", {
                className: ih().actions,
                children: [
                  (0, s.jsxs)("div", {
                    className: ih().textContainer,
                    children: [
                      !!(null == p2 ? void 0 : p2.title) && (0, s.jsx)(E.Heading, {
                        weight: "black",
                        size: "xl",
                        className: ih().textColor,
                        lineClamp: 2,
                        variant: v2,
                        style: I2,
                        children: null == p2 ? void 0 : p2.title
                      }),
                      !!(null == p2 ? void 0 : p2.subtitle) && (0, s.jsx)(E.Caption, {
                        className: ih().textColor,
                        variant: "span",
                        type: "text",
                        size: "l",
                        weight: "medium",
                        lineClamp: 2,
                        style: I2,
                        children: null == p2 ? void 0 : p2.subtitle
                      })
                    ]
                  }),
                  !!(null == p2 ? void 0 : p2.weblink) && !!(null == p2 ? void 0 : p2.buttonTitle) && (0, s.jsx)(aO.$, {
                    color: "primary",
                    radius: "xxxl",
                    className: ih().button,
                    role: "link",
                    onClick: T2,
                    style: L2,
                    children: (0, s.jsx)(E.Caption, {
                      variant: "span",
                      type: "controls",
                      size: "m",
                      weight: "medium",
                      children: null == p2 ? void 0 : p2.buttonTitle
                    })
                  })
                ]
              }),
              (0, s.jsx)("div", {
                className: ih().imageContainer,
                children: (0, s.jsx)(ez.Image, {
                  src: h2 || (null == p2 ? void 0 : p2.imageUrl),
                  withAvatarReplace: true,
                  fit: "cover",
                  size: 300,
                  withFallback: false,
                  className: ih().image,
                  withLoadingIndicator: false
                })
              })
            ]
          })
        });
      }, iL = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(iI, { forwardRef: t10, ...e10 }));
      var iy = a(76015), iS = a.n(iy);
      let iE = (e10) => {
        let {
          forwardRef: t10,
          isShimmerVisible: a10,
          isShimmerActive: i10,
          containerClassName: r2,
          headerClassName: o2,
          meta: d2,
          data: c2,
          headingVariant: m2,
          className: _2,
          ...p2
        } = e10, b2 = (0, n.useId)(), v2 = (0, u.useTabsState)(0), A2 = (0, n.useRef)(null), T2 = (0, n.useId)(), C2 = (0, n.useMemo)(
          () => a10 ? (0, s.jsx)(t4.R, {
            isActive: i10,
            ref: A2,
            containerClassName: r2,
            ariaLabelledBy: "".concat(b2, " ").concat(b2, "-description"),
            length: 9
          }) : null == c2 ? void 0 : c2.items.map(
            (e11) => (0, s.jsx)(
              u.TabPanel,
              {
                name: e11.tab.id,
                value: v2.value,
                elementId: T2,
                children: (0, s.jsx)(t4.k, {
                  ref: A2,
                  containerClassName: r2,
                  ariaLabelledBy: "".concat(b2, " ").concat(b2, "-description"),
                  items: e11.data
                })
              },
              e11.tab.id
            )
          ),
          [null == c2 ? void 0 : c2.items, a10, i10, r2, b2, v2.value, T2]
        );
        return (0, s.jsxs)("section", {
          className: (0, l.$)(iS().root, _2),
          ref: t10,
          ...(0, f.getDataAttrFromProps)(p2),
          children: [
            (0, s.jsx)(g.Tw, {
              className: (0, l.$)(o2, iS().header, iS().important),
              title: d2.title,
              description: d2.description,
              labeledForId: b2,
              viewAllActionLink: d2.viewAllActionLink,
              controls: (0, s.jsx)(g.X9, { className: iS().controls, carouselRef: A2 }),
              headingVariant: m2,
              withDescription: !!d2.description
            }),
            (0, s.jsx)(g.wI, {
              isShimmerVisible: a10,
              className: (0, l.$)(r2, iS().tabCarousel, iS().important),
              elementId: T2,
              shimmer: (0, s.jsx)(g.zr, {
                isActive: i10,
                className: (0, l.$)(r2, iS().tabCarousel, iS().important),
                shimmerClassName: iS().tabShimmer
              }),
              "aria-labelledby": b2,
              ...v2,
              children: null == c2 ? void 0 : c2.items.map((e11) => {
                let { tab: t11 } = e11;
                return (0, s.jsx)(
                  g.oz,
                  {
                    className: (0, l.$)(iS().tab, iS().important),
                    value: t11.id,
                    "aria-label": t11.title,
                    title: t11.title
                  },
                  t11.id
                );
              })
            }),
            C2
          ]
        });
      }, iN = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(iE, { forwardRef: t10, ...e10 }));
      var ij = a(54861), ik = a.n(ij);
      let ix = (e10) => {
        var t10;
        let {
          forwardRef: a10,
          isShimmerVisible: i10,
          isShimmerActive: r2,
          containerClassName: o2,
          headerClassName: d2,
          meta: c2,
          data: m2,
          headingVariant: p2,
          className: b2,
          ...v2
        } = e10, A2 = (0, n.useId)(), T2 = (0, u.useTabsState)(0), C2 = (0, n.useRef)(null), I2 = (0, n.useId)(), L2 = (0, n.useMemo)(
          () => i10 ? (0, s.jsx)(P.Carousel, {
            ref: C2,
            itemClassName: (0, l.$)(ik().item, ik().important),
            className: o2,
            "aria-labelledby": "".concat(A2, " ").concat(A2, "-description"),
            children: (0, g.km)({ isActive: r2, centered: true })
          }) : null == m2 ? void 0 : m2.items.map((e11) => {
            var t11;
            return (0, s.jsx)(
              u.TabPanel,
              {
                name: e11.tab.id,
                value: T2.value,
                elementId: I2,
                children: (0, s.jsx)(P.Carousel, {
                  ref: C2,
                  itemClassName: (0, l.$)(ik().item, ik().important),
                  className: o2,
                  "aria-labelledby": "".concat(A2, " ").concat(A2, "-description"),
                  children: null == (t11 = e11.data) ? void 0 : t11.map((t12, a11) => {
                    var i11;
                    return (0, s.jsx)(
                      _.Bki,
                      {
                        objectType: h.ky.Wave,
                        objectId: t12.stationId,
                        objectPosX: a11 + 1,
                        objectPosY: 1,
                        objectsCount: null == (i11 = e11.data) ? void 0 : i11.length,
                        children: (0, s.jsx)(e$.yi, { vibe: t12 })
                      },
                      t12.stationId
                    );
                  })
                })
              },
              e11.tab.id
            );
          }),
          [null == m2 ? void 0 : m2.items, i10, r2, o2, A2, T2.value, I2]
        );
        return (0, s.jsxs)("section", {
          className: (0, l.$)(ik().root, b2),
          ref: a10,
          ...(0, f.getDataAttrFromProps)(v2),
          children: [
            (0, s.jsx)(g.Tw, {
              className: (0, l.$)(d2, ik().header, ik().important),
              title: c2.title,
              description: c2.description,
              labeledForId: A2,
              viewAllActionLink: c2.viewAllActionLink,
              controls: (0, s.jsx)(g.X9, { className: ik().controls, carouselRef: C2 }),
              headingVariant: p2,
              withDescription: !!c2.description
            }),
            (0, s.jsx)(g.wI, {
              isShimmerVisible: i10,
              className: (0, l.$)(o2, ik().tabCarousel, ik().important),
              elementId: I2,
              shimmer: (0, s.jsx)(g.zr, {
                isActive: r2,
                className: (0, l.$)(o2, ik().tabCarousel, ik().important),
                shimmerClassName: ik().tabShimmer
              }),
              "aria-labelledby": A2,
              ...T2,
              children: null == m2 || null == (t10 = m2.items) ? void 0 : t10.map((e11) => {
                let { tab: t11 } = e11;
                return (0, s.jsx)(
                  g.oz,
                  {
                    className: (0, l.$)(ik().tab, ik().important),
                    value: t11.id,
                    "aria-label": t11.title,
                    title: t11.title
                  },
                  t11.id
                );
              })
            }),
            L2
          ]
        });
      }, iR = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(ix, { forwardRef: t10, ...e10 }));
      var iP = a(84683), iw = a.n(iP), iK = a(45825), iO = a.n(iK);
      let iM = (0, r.PA)(() => {
        let {
          settings: { isMobile: e10 }
        } = (0, _.Pjs)();
        return (0, s.jsxs)(s.Fragment, {
          children: [
            (0, s.jsx)(g.nN, { isActive: true, className: iO().titleShimmer, textClassName: iO().titleTextShimmer }),
            (0, s.jsx)(g.nN, { isActive: true, className: iO().descriptionShimmer, textClassName: iO().textShimmer }),
            (0, s.jsx)(g.nN, { isActive: true, className: iO().descriptionShimmer, textClassName: iO().textShimmer }),
            (0, s.jsx)(g.nN, { isActive: true, className: iO().descriptionShimmer, textClassName: iO().textShimmer }),
            e10 && (0, s.jsxs)(s.Fragment, {
              children: [
                (0, s.jsx)(g.nN, {
                  isActive: true,
                  className: iO().descriptionShimmer,
                  textClassName: iO().textShimmer
                }),
                (0, s.jsx)(g.nN, {
                  isActive: true,
                  className: iO().descriptionShimmer,
                  textClassName: iO().textShimmer
                })
              ]
            })
          ]
        });
      }), iD = Array.from({ length: 3 }, () => g.v2.src), iB = (0, r.PA)((e10) => {
        let { forwardRef: t10, isShimmerVisible: a10, data: i10, headingVariant: l2 = "h2" } = e10, { formatMessage: r2 } = (0, I.A)(), { wizard: o2 } = (0, _.Pjs)(), c2 = (0, n.useMemo)(
          () => (0, s.jsx)("div", {
            className: iw().images,
            ...(0, d.Am)(d.e8.landing.WIZARD_BLOCK_ARTISTS),
            children: iD.map((e11, t11) => {
              var a11;
              let l3 = null == i10 || null == (a11 = i10.artists[t11]) ? void 0 : a11.coverUri;
              return (0, s.jsx)(
                S.Paper,
                {
                  className: iw().paper,
                  radius: "round",
                  children: (0, s.jsx)(ez.Image, {
                    className: iw().image,
                    src: l3 || e11,
                    fit: "contain",
                    withAvatarReplace: !!l3,
                    "aria-hidden": true,
                    fallbackIconSize: "s",
                    ...(0, d.Am)("".concat(d.e8.landing.WIZARD_BLOCK_ARTIST_COVER, "_").concat(t11))
                  })
                },
                t11
              );
            })
          }),
          [null == i10 ? void 0 : i10.artists]
        ), m2 = (0, n.useMemo)(
          () => a10 ? (0, s.jsx)(iM, {}) : (0, s.jsxs)(s.Fragment, {
            children: [
              (0, s.jsx)(E.Heading, {
                variant: l2,
                size: "xs",
                className: iw().title,
                ...(0, d.Am)(d.e8.landing.WIZARD_BLOCK_TITLE),
                children: null == i10 ? void 0 : i10.title
              }),
              (null == i10 ? void 0 : i10.description) && (0, s.jsx)(E.Heading, {
                variant: "h3",
                size: "l",
                className: iw().description,
                lineClamp: 5,
                ...(0, d.Am)(d.e8.landing.WIZARD_BLOCK_TEXT),
                children: i10.description
              })
            ]
          }),
          [a10, l2, null == i10 ? void 0 : i10.title, null == i10 ? void 0 : i10.description]
        );
        return (0, s.jsxs)("section", {
          className: iw().root,
          ref: t10,
          ...(0, d.Am)(d.e8.landing.WIZARD_BLOCK),
          children: [
            c2,
            m2,
            (0, s.jsx)(aO.$, {
              className: iw().button,
              icon: (0, s.jsx)(tB.Icon, { variant: "link", size: "xxs", className: iw().buttonIcon }),
              color: "secondary",
              size: "m",
              iconPosition: "right",
              radius: "xxxl",
              onClick: o2.modal.open,
              ...(0, d.Am)(d.e8.landing.WIZARD_BLOCK_BUTTON),
              children: r2({ id: "wizard.buttonText" })
            })
          ]
        });
      }), iV = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(iB, { forwardRef: t10, ...e10 })), iU = {
        [C.t.COLLECTION_PLAYLIST_WITH_LIKES]: ir,
        [C.t.COLLECTION_FAVOURITE_PLAYLIST]: iu,
        [C.t.OPEN_PLAYLIST]: ir,
        [C.t.SMART_OPEN_PLAYLIST]: ir,
        [C.t.NON_MUSIC_OPEN_PLAYLIST]: ir,
        [C.t.COLLECTION_ARTISTS]: eF,
        [C.t.COLLECTION_ARTISTS_AND_TOP]: eF,
        [C.t.PERSONAL_ARTISTS]: eF,
        [C.t.NEW_STARS_ARTISTS]: eF,
        [C.t.EDITORIAL_ARTISTS]: eF,
        [C.t.META_TAG_POPULAR_ARTISTS]: eF,
        [C.t.MICRO_GENRE_ARTISTS]: eF,
        [C.t.MICRO_GENRE_TOP_ARTISTS]: eF,
        [C.t.META_TAG_ARTISTS]: eF,
        [C.t.SIMILAR_ARTISTS]: eF,
        [C.t.NEW_RELEASES]: aq,
        [C.t.EDITORIAL_NEW_RELEASES]: aq,
        [C.t.NEW_PLAYLISTS]: aa.EntitiesCarousel,
        [C.t.EDITORIAL_COMPILATION]: aa.EntitiesCarousel,
        [C.t.RECOMMENDED_PLAYLISTS]: aa.EntitiesCarousel,
        [C.t.META_TAG_POPULAR_PLAYLISTS]: aa.EntitiesCarousel,
        [C.t.META_TAG_PLAYLISTS]: aa.EntitiesCarousel,
        [C.t.META_TAG_NEW_ALBUMS]: aa.EntitiesCarousel,
        [C.t.MICRO_GENRE_ALBUMS]: aa.EntitiesCarousel,
        [C.t.META_TAG_ALBUMS]: aa.EntitiesCarousel,
        [C.t.ARTIST_PLAYLISTS]: aa.EntitiesCarousel,
        [C.t.ARTIST_ALBUMS]: aa.EntitiesCarousel,
        [C.t.ARTIST_COMPILATIONS]: aa.EntitiesCarousel,
        [C.t.ARTIST_STUDIO_ALBUMS]: aa.EntitiesCarousel,
        [C.t.ARTIST_SIMILAR_ENTITIES]: aa.EntitiesCarousel,
        [C.t.COLLECTION_SIMILAR_ENTITIES]: aa.EntitiesCarousel,
        [C.t.PROMOTIONS]: i_.Promotions,
        [C.t.EDITORIAL_PROMOTIONS]: i_.Promotions,
        [C.t.NON_MUSIC_PROMOTIONS]: i_.Promotions,
        [C.t.PERSONAL_PLAYLISTS]: a6,
        [C.t.REWIND_PLAYLISTS]: a6,
        [C.t.MICRO_GENRE_SIMILAR_WAVE]: t5,
        [C.t.META_TAG_SIMILAR_WAVE]: t5,
        [C.t.EDITORIAL_WAVES]: t5,
        [C.t.META_TAG_WAVE]: t5,
        [C.t.MICRO_GENRE_WAVE]: t5,
        [C.t.EDITORIAL_WAVES_AGENT]: at,
        [C.t.META_TAG_WAVE_AGENT]: at,
        [C.t.MICRO_GENRE_WAVE_AGENT]: at,
        [C.t.MICRO_GENRE_SIMILAR_WAVE_AGENT]: at,
        [C.t.META_TAG_SIMILAR_WAVE_AGENT]: at,
        [C.t.CONCERTS_PERSONAL]: tO,
        [C.t.CONCERTS_TOP]: tO,
        [C.t.EDITORIAL_CONCERTS]: tO,
        [C.t.VIEWED_CONCERTS]: tO,
        [C.t.CLIPS]: eE,
        [C.t.ARTIST_CLIPS]: eE,
        [C.t.WAVES]: iN,
        [C.t.SETS_BY_WAVES]: iN,
        [C.t.WAVES_AGENT]: iR,
        [C.t.SETS_BY_WAVES_AGENT]: iR,
        [C.t.CHART_TRACKS]: eI,
        [C.t.COLLECTION_KIDS]: tu,
        [C.t.COLLECTION_PLAYLISTS_LIKED_AND_CREATED]: tI,
        [C.t.COLLECTION_PLAYLISTS_CREATED]: tn,
        [C.t.COLLECTION_PLAYLISTS_LIKED]: tg,
        [C.t.ALBUM_PROMO]: X,
        [C.t.SIMPLE_ALBUM_PROMO]: Q,
        [C.t.ITEM_LIST]: ag,
        [C.t.OVERVIEW]: a4,
        [C.t.COLLECTION_ALBUMS]: eR,
        [C.t.COLLECTION_CLIPS]: ts,
        [C.t.COLLECTION_TOP_ARTISTS]: ty,
        [C.t.RECENTLY_PLAYED]: ig.g,
        [C.t.IN_STYLE]: ac,
        [C.t.SPECIAL]: iL,
        [C.t.WIZARD]: iV,
        [C.t.MIXES]: aN,
        [C.t.MIXES_GRID]: aj.MixesGridBlock,
        [C.t.MIXES_MUSIC]: aP,
        [C.t.NEUROMUSIC]: aY,
        [C.t.CONCERT_PLACE]: tR,
        [C.t.LIKES_AND_HISTORY]: aI,
        [C.t.NON_MUSIC_EDITORIAL_COMPILATION]: aZ.t,
        [C.t.COLLECTION_ALBUMS_PRESAVES]: eV,
        [C.t.CHART_ALBUMS]: aJ.S,
        [C.t.DONATIONS]: t1,
        [C.t.CONTINUE_LISTEN]: t$,
        [C.t.DISLIKES]: tJ,
        [C.t.COLLECTION_DOWNLOADED_TRACKS]: tc,
        [C.t.HISTORY]: iT,
        [C.t.SEARCH_HISTORY]: iT,
        [C.t.ARTIST_CONCERTS]: ea,
        [C.t.ARTIST_POPULAR_TRACKS]: e_,
        [C.t.ARTIST_RELEASE]: eb,
        [C.t.FAMILIAR_YOU]: ar,
        [C.t.ARTIST_PICK]: en,
        [C.t.ARTIST_UPCOMING_RELEASE]: eA,
        [C.t.COLLECTION_WAVE_AGENT]: tj,
        [C.t.COLLECTION_ARTISTS_AND_TOP_WITH_ITEMS]: e9
      }, iY = (0, r.PA)((e10) => {
        let {
          landing: t10,
          block: a10,
          isIntersecting: i10,
          forwardRef: r2,
          onLoad: o2,
          className: c2,
          containerClassName: m2,
          ...u2
        } = e10, {
          isNeededToLoad: g2,
          isLoading: A2,
          isLoaded: C2,
          isRejected: h2,
          isShimmerVisible: I2,
          isShimmerActive: L2,
          isVisible: y2,
          id: S2,
          type: E2,
          meta: N2,
          data: j2,
          hasSentAnalyticsOnLoaded: k2,
          setHasSentAnalyticsOnLoaded: x2,
          setOutdated: R2,
          setIsNeededToLoad: f2
        } = a10;
        if ((0, b.Q)(a10)) return null;
        let P2 = iU[a10.type], w2 = (0, _.fBs)(), { settings: K2, experiments: O2 } = (0, _.Pjs)(), M2 = !O2.checkExperiment(_.zal.WebNextVirtualSkeleton, "on") && K2.browserInfo && !K2.browserInfo.isSafari;
        (0, n.useEffect)(() => {
          (i10 || !y2) && g2 && (0, p.v)(N2) && t10.getBlock(a10);
        }, [a10, i10, g2, y2, t10, N2]), (0, n.useEffect)(() => {
          (C2 || h2) && (null == o2 || o2());
        }, [C2, h2, o2]), (0, n.useEffect)(() => {
          !k2 && C2 && (w2(), x2(true));
        }, [k2, C2, w2, x2]);
        let D2 = (0, v.L)(() => {
          if (((e12) => !!(e12 && "object" == typeof e12 && "current" in e12))(r2)) {
            var e11;
            return null == (e11 = r2.current) ? void 0 : e11.clientHeight;
          }
          return 0;
        });
        return y2 ? (0, s.jsx)(
          P2,
          {
            setIsNeededToLoad: f2,
            setOutdated: R2,
            isLoaded: C2,
            isLoading: A2,
            isShimmerVisible: I2,
            isShimmerActive: L2,
            isRejected: h2,
            tracksContainerClassName: T().tracksContainer,
            containerClassName: (0, l.$)(T().container, T().important, m2),
            className: (0, l.$)({ [T().container_withContentVisibility]: M2 && D2 }, c2),
            headerClassName: T().headerContainer,
            meta: N2,
            data: j2,
            type: E2,
            ref: r2,
            headingVariant: "h2",
            "data-intersection-property-id": a10.id,
            ...(0, d.Am)(a10.type),
            ...u2
          },
          S2
        ) : null;
      }), iG = (0, r.PA)((e10) => {
        let { ...t10 } = e10;
        return (0, s.jsx)(_.FoH, {
          blockId: t10.block.id,
          blockType: t10.block.type,
          blockIdForFrom: "".concat(_.hf$.DISCOVERY_BLOCK, "-").concat(t10.block.id),
          blockPosX: 1,
          blockPosY: t10.blockIndex + 1,
          objectsCount: t10.block.objectsCount,
          children: (0, s.jsx)(iY, { ...t10 })
        });
      });
      var iW = a(83407), iX = a.n(iW);
      let iF = (0, r.PA)((e10) => {
        let { forwardRef: t10, data: a10, ...i10 } = e10, r2 = (0, v.L)(() => {
          if (null == a10 ? void 0 : a10.release)
            return (0, s.jsx)(iG, {
              ...i10,
              className: iX().release,
              containerClassName: iX().releaseCard,
              block: a10.release
            });
        }), o2 = (0, v.L)(() => {
          if (null == a10 ? void 0 : a10.upcomingRelese)
            return (0, s.jsx)(iG, {
              ...i10,
              className: iX().release,
              containerClassName: iX().releaseCard,
              block: a10.upcomingRelese
            });
        }), n2 = (0, v.L)(() => {
          if (null == a10 ? void 0 : a10.popularTracks)
            return (0, s.jsx)(iG, {
              ...i10,
              className: (0, l.$)(iX().popularTracks, {
                [iX().popularTracks_withReleaseBlock]: !!(null != o2 ? o2 : r2)
              }),
              block: a10.popularTracks
            });
        });
        return (0, s.jsx)("section", {
          ref: t10,
          className: iX().root,
          ...(0, f.getDataAttrFromProps)(i10),
          children: (0, s.jsxs)("div", { className: iX().container, children: [n2, null != o2 ? o2 : r2] })
        });
      }), iH = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(iF, { forwardRef: t10, ...e10 }));
      var iz = a(34195), i$ = a.n(iz);
      let iq = (0, r.PA)((e10) => {
        let { forwardRef: t10, data: a10, ...i10 } = e10, l2 = (0, v.L)(() => {
          if (null == a10 ? void 0 : a10.familiarYou) return (0, s.jsx)(iG, { ...i10, block: a10.familiarYou });
        }), r2 = (0, v.L)(() => {
          if (null == a10 ? void 0 : a10.artistPick) return (0, s.jsx)(iG, { ...i10, block: a10.artistPick });
        });
        return (0, s.jsxs)("section", {
          ref: t10,
          className: i$().root,
          ...(0, f.getDataAttrFromProps)(i10),
          children: [r2, l2]
        });
      }), iJ = (0, n.forwardRef)((e10, t10) => (0, s.jsx)(iq, { forwardRef: t10, ...e10 })), iZ = { [C.t.ARTIST_POPULAR_TRACKS_AND_RELEASES]: iH, [C.t.FAMILIAR_YOU_AND_ARTIST_PICK]: iJ }, iQ = (0, r.PA)((e10) => {
        let { block: t10, forwardRef: a10, onLoad: i10, ...l2 } = e10;
        if ((0, n.useEffect)(() => {
          null == i10 || i10();
        }, [t10.isVisible, i10]), !(0, b.Q)(t10) || !t10.isVisible)
          return null;
        let r2 = iZ[t10.type];
        return (0, s.jsx)(r2, { data: t10.data, ref: a10, "data-intersection-property-id": t10.id, ...l2 });
      }), i0 = (0, r.PA)((e10) => {
        let { ...t10 } = e10;
        return (0, s.jsx)(_.FoH, {
          blockId: t10.block.id,
          blockType: t10.block.type,
          blockIdForFrom: "".concat(_.hf$.DISCOVERY_BLOCK, "-").concat(t10.block.id),
          blockPosX: 1,
          blockPosY: t10.blockIndex + 1,
          objectsCount: t10.block.objectsCount,
          children: (0, s.jsx)(iQ, { ...t10 })
        });
      }), i1 = (0, r.PA)((e10) => (0, b.Q)(e10.block) ? (0, s.jsx)(i0, { ...e10 }) : (0, s.jsx)(iG, { ...e10 }));
      var i3 = a(1316), i4 = a.n(i3), i2 = a(93064);
      let i6 = (e10) => {
        let { landing: t10, tab: a10 } = e10, { notify: i10, dismiss: l2 } = (0, _.lkh)(), r2 = (0, n.useRef)(void 0), o2 = (0, c.c)(() => {
          a10.blocks.forEach((e11) => {
            e11.isRejected && (0, p.v)(e11.meta) && t10.getBlock(e11);
          }), l2({ notificationId: r2.current }), a10.setShouldReloadNotification(false);
        });
        (0, n.useEffect)(() => {
          a10.hasErrorBlocks && !a10.shouldReloadNotification && setTimeout(() => {
            r2.current = i10((0, s.jsx)(g.LV, { reloadBlocks: o2 }), { containerId: _.uQT.ERROR, autoClose: false }), a10.setShouldReloadNotification(true);
          });
        }, [i10, o2, a10.hasErrorBlocks, a10.shouldReloadNotification, a10]), (0, n.useEffect)(
          () => () => {
            l2(), (0, i2._n)(a10) && a10.setShouldReloadNotification(false);
          },
          [l2, a10]
        );
      }, i8 = (0, r.PA)((e10) => {
        var t10;
        let { landing: a10, tab: i10, tabIndex: l2 } = e10, r2 = (0, n.useMemo)(() => i10.blocks.map(() => (0, n.createRef)()), [i10.blocks]), o2 = (0, m.BL)(r2, { freezeOnceVisible: true });
        return i6({ landing: a10, tab: i10 }), (0, s.jsx)(_.jPc, {
          children: (0, s.jsx)(_.hjC, {
            tabId: i10.meta.id,
            tabPos: l2 + 1,
            isTabSelectedByDefault: (null == (t10 = a10.meta) ? void 0 : t10.selectedTabIndex) === l2,
            children: (0, s.jsx)("div", {
              className: i4().root,
              children: i10.blocks.map((e11, t11) => {
                let { isIntersecting: i11 } = o2[e11.id] || {};
                return (0, s.jsx)(
                  i1,
                  { landing: a10, block: e11, blockIndex: t11, isIntersecting: i11, forwardRef: r2[t11] },
                  e11.id
                );
              })
            })
          })
        });
      });
      var i5 = a(17390), i7 = a(67648), i9 = a(77516);
      let se = {
        [C.t.ALBUM_PROMO]: 314,
        [C.t.ARTIST_PICK]: 102,
        [C.t.ARTIST_CONCERTS]: 232,
        [C.t.ARTIST_PLAYLISTS]: 316,
        [C.t.ARTIST_POPULAR_TRACKS_AND_RELEASES]: 340,
        [C.t.ARTIST_POPULAR_TRACKS]: 340,
        [C.t.ARTIST_RELEASE]: 340,
        [C.t.ARTIST_UPCOMING_RELEASE]: 340,
        [C.t.ARTIST_ALBUMS]: 316,
        [C.t.ARTIST_COMPILATIONS]: 316,
        [C.t.ARTIST_CLIPS]: 292,
        [C.t.ARTIST_STUDIO_ALBUMS]: 316,
        [C.t.FAMILIAR_YOU_AND_ARTIST_PICK]: 102,
        [C.t.SIMPLE_ALBUM_PROMO]: 140,
        [C.t.CHART_ALBUMS]: 322,
        [C.t.CHART_TRACKS]: 284,
        [C.t.COLLECTION_ALBUMS]: 320,
        [C.t.COLLECTION_ALBUMS_PRESAVES]: 378,
        [C.t.COLLECTION_ARTISTS]: 336,
        [C.t.COLLECTION_ARTISTS_AND_TOP]: 336,
        [C.t.COLLECTION_TOP_ARTISTS]: 336,
        [C.t.COLLECTION_CLIPS]: 292,
        [C.t.COLLECTION_FAVOURITE_PLAYLIST]: 370,
        [C.t.COLLECTION_PLAYLISTS_CREATED]: 316,
        [C.t.COLLECTION_PLAYLISTS_LIKED]: 316,
        [C.t.COLLECTION_PLAYLISTS_LIKED_AND_CREATED]: 378,
        [C.t.COLLECTION_PLAYLIST_WITH_LIKES]: 310,
        [C.t.COLLECTION_KIDS]: 320,
        [C.t.CONCERTS_PERSONAL]: 442,
        [C.t.COLLECTION_DOWNLOADED_TRACKS]: 298,
        [C.t.CONCERTS_TOP]: 442,
        [C.t.EDITORIAL_ARTISTS]: 336,
        [C.t.EDITORIAL_CONCERTS]: 442,
        [C.t.VIEWED_CONCERTS]: 442,
        [C.t.EDITORIAL_COMPILATION]: 316,
        [C.t.EDITORIAL_NEW_RELEASES]: 410,
        [C.t.EDITORIAL_PROMOTIONS]: 342,
        [C.t.EDITORIAL_WAVES]: 138,
        [C.t.EDITORIAL_WAVES_AGENT]: 319,
        [C.t.META_TAG_WAVE_AGENT]: 319,
        [C.t.MICRO_GENRE_WAVE_AGENT]: 319,
        [C.t.MICRO_GENRE_SIMILAR_WAVE_AGENT]: 319,
        [C.t.META_TAG_SIMILAR_WAVE_AGENT]: 319,
        [C.t.IN_STYLE]: 370,
        [C.t.ITEM_LIST]: 250,
        [C.t.LIKES_AND_HISTORY]: 106,
        [C.t.META_TAG_ALBUMS]: 316,
        [C.t.META_TAG_ARTISTS]: 336,
        [C.t.META_TAG_NEW_ALBUMS]: 316,
        [C.t.META_TAG_PLAYLISTS]: 316,
        [C.t.META_TAG_POPULAR_ARTISTS]: 336,
        [C.t.META_TAG_POPULAR_PLAYLISTS]: 316,
        [C.t.META_TAG_SIMILAR_WAVE]: 138,
        [C.t.META_TAG_WAVE]: 64,
        [C.t.MICRO_GENRE_ALBUMS]: 316,
        [C.t.MICRO_GENRE_ARTISTS]: 336,
        [C.t.MICRO_GENRE_SIMILAR_WAVE]: 138,
        [C.t.MICRO_GENRE_TOP_ARTISTS]: 336,
        [C.t.MICRO_GENRE_WAVE]: 64,
        [C.t.MIXES]: 260,
        [C.t.MIXES_GRID]: 240,
        [C.t.MIXES_MUSIC]: 264,
        [C.t.NEUROMUSIC]: 138,
        [C.t.NEW_PLAYLISTS]: 316,
        [C.t.ARTIST_SIMILAR_ENTITIES]: 316,
        [C.t.COLLECTION_SIMILAR_ENTITIES]: 316,
        [C.t.NEW_RELEASES]: 410,
        [C.t.NEW_STARS_ARTISTS]: 336,
        [C.t.NON_MUSIC_EDITORIAL_COMPILATION]: 316,
        [C.t.NON_MUSIC_OPEN_PLAYLIST]: 310,
        [C.t.NON_MUSIC_PROMOTIONS]: 342,
        [C.t.OPEN_PLAYLIST]: 310,
        [C.t.OVERVIEW]: 84,
        [C.t.PERSONAL_ARTISTS]: 336,
        [C.t.PERSONAL_PLAYLISTS]: 342,
        [C.t.PROMOTIONS]: 342,
        [C.t.RECENTLY_PLAYED]: 316,
        [C.t.RECOMMENDED_PLAYLISTS]: 316,
        [C.t.REWIND_PLAYLISTS]: 342,
        [C.t.SMART_OPEN_PLAYLIST]: 310,
        [C.t.SPECIAL]: 192,
        [C.t.SIMILAR_ARTISTS]: 336,
        [C.t.TABS]: 60,
        [C.t.WAVES]: 176,
        [C.t.WAVES_AGENT]: 370,
        [C.t.SETS_BY_WAVES_AGENT]: 370,
        [C.t.SETS_BY_WAVES]: 176,
        [C.t.WIZARD]: 328,
        [C.t.DONATIONS]: 216,
        [C.t.CLIPS]: 292,
        [C.t.CONTINUE_LISTEN]: 138,
        [C.t.DISLIKES]: 54,
        [C.t.HISTORY]: 402,
        [C.t.SEARCH_HISTORY]: 402,
        [C.t.FAMILIAR_YOU]: 102,
        [C.t.CONCERT_PLACE]: 324,
        [C.t.COLLECTION_WAVE_AGENT]: 186,
        [C.t.COLLECTION_ARTISTS_AND_TOP_WITH_ITEMS]: 336
      };
      var st = a(78791), sa = a.n(st);
      let si = (0, r.PA)((e10) => {
        var t10;
        let { virtualItem: a10, resizeObserver: i10, isScrolling: l2, style: r2, ...o2 } = e10, [d2, c2] = (0, i7.d)(), [u2, _2] = (0, i7.d)(), { isIntersecting: g2 } = null != (t10 = (0, m.BL)(
          [{ current: d2 }],
          !d2 || (null == d2 ? void 0 : d2.dataset.intersectionPropertyId) !== o2.block.id
        )[o2.block.id]) ? t10 : {};
        return (0, n.useEffect)(
          () => (u2 && i10 && i10.observe(u2), () => {
            u2 && i10 && i10.unobserve(u2);
          }),
          [u2, i10]
        ), (0, s.jsx)("div", {
          "data-index": a10.index,
          className: sa().root,
          ref: _2,
          style: r2,
          children: (0, s.jsx)(i1, { ...o2, forwardRef: c2, isIntersecting: g2 && !l2 })
        });
      }), ss = (0, r.PA)((e10) => {
        var t10, a10;
        let { landing: i10, tab: l2, tabIndex: r2 } = e10, d2 = (0, o.useSearchParams)(), {
          settings: { isMobile: m2 }
        } = (0, _.Pjs)(), [u2, g2] = (0, i7.d)(), p2 = (0, n.useRef)(true), [b2, v2] = (0, n.useState)(() => Array.from({ length: l2.blocks.length }, (e11, t11) => t11)), A2 = (0, c.c)(() => {
          let e11 = [];
          l2.blocks.forEach((t11, a11) => {
            var i11;
            (t11.isVisible || (null == (i11 = t11.meta) ? void 0 : i11.showPolicy) === i5.E.LOAD_AND_SHOW && t11.isNeededToLoad) && e11.push(a11);
          }), v2(e11);
        }), T2 = (0, c.c)((e11) => {
          let t11 = b2[e11];
          if (void 0 === t11) return 300;
          let a11 = l2.blocks[t11];
          return (null == a11 ? void 0 : a11.isVisible) ? se[a11.type] : 0;
        }), { virtualizer: C2, resizeObserver: h2 } = (0, i9.rA)({
          count: null != (a10 = b2.length) ? a10 : 0,
          gap: m2 ? 16 : 24,
          getEstimateSize: T2,
          containerRef: u2
        });
        (0, n.useEffect)(() => {
          var e11;
          if (!p2.current) return;
          let t11 = d2.get(_.K3F.BLOCK), a11 = l2.blocks.findIndex((e12) => e12.id === t11);
          if (!b2.includes(a11)) return;
          let i11 = null == (e11 = C2.getOffsetForIndex(a11, "center")) ? void 0 : e11[0];
          C2.scrollToIndex(a11, { align: "center", behavior: "auto" }), C2.scrollOffset && i11 && 100 > Math.abs(C2.scrollOffset - i11) && (p2.current = false);
        }, [b2, d2, l2.blocks, C2]);
        let I2 = C2.getTotalSize(), L2 = C2.getVirtualItems();
        return i6({ landing: i10, tab: l2 }), (0, s.jsx)(_.jPc, {
          children: (0, s.jsx)(_.hjC, {
            tabId: l2.meta.id,
            tabPos: r2 + 1,
            isTabSelectedByDefault: (null == (t10 = i10.meta) ? void 0 : t10.selectedTabIndex) === r2,
            children: (0, s.jsx)("div", {
              className: i4().root,
              style: { height: "".concat(I2, "px") },
              ref: g2,
              children: L2.map((e11) => {
                let t11 = b2[e11.index], a11 = l2.blocks[Number(t11)];
                return a11 ? (0, s.jsx)(
                  si,
                  {
                    virtualItem: e11,
                    resizeObserver: h2,
                    landing: i10,
                    block: a11,
                    blockIndex: Number(t11),
                    isScrolling: C2.isScrolling,
                    onLoad: A2,
                    style: { transform: "translate3d(0, ".concat(e11.start - C2.options.scrollMargin, "px, 0)") }
                  },
                  e11.key
                ) : null;
              })
            })
          })
        });
      }), sl = (0, r.PA)((e10) => {
        var t10, a10, i10;
        let {
          landing: r2,
          upperBlocks: o2,
          headerConcealerComponent: m2,
          tabsState: p2,
          containerClassName: b2,
          containerStyle: v2,
          headerClassName: A2,
          tabWithHeadingTitle: T2,
          tabWithCovers: C2,
          tabWithSubtitle: h2,
          stickyHeaderClassName: I2,
          staticHeaderClassName: L2,
          stickyHeaderTabIndex: y2,
          headerVariant: S2 = g.Vw.COMPOSITE
        } = e10, { tabs: E2 } = r2, N2 = (0, n.useId)(), { isScrolling: j2 } = (0, n.useContext)(g.B9), { contentScrollRef: k2 } = (0, _.gKY)(), {
          experiments: x2,
          settings: { isMobile: R2 }
        } = (0, _.Pjs)(), f2 = x2.checkExperiment(_.zal.WebNextVirtualSkeleton, "on") ? ss : i8, P2 = (0, c.c)((e11) => {
          var t11;
          R2 ? window.scrollTo(0, 0) : k2 && (k2.scrollTop = 0), null == (t11 = p2.onTabChange) || t11.call(p2, e11);
        });
        return (0, s.jsxs)(s.Fragment, {
          children: [
            o2,
            m2,
            (0, s.jsx)(g.Y9, {
              className: (0, l.$)(i4().header, A2),
              variant: S2,
              stickyClassName: I2,
              staticClassName: L2,
              stickyChild: (0, s.jsx)(g.wI, {
                isShimmerVisible: E2.isLoading || r2.isLoading,
                className: i4().stickyTabs,
                shimmer: (0, s.jsx)(g.zr, {}),
                elementId: N2,
                ...(0, d.Am)(d.e8.landing.MAIN_TABS),
                value: p2.value,
                onTabChange: P2,
                children: null == (t10 = E2.data) ? void 0 : t10.map((e11, t11) => {
                  let { meta: a11 } = e11;
                  return (0, s.jsx)(
                    g.oz,
                    {
                      className: i4().tab,
                      value: t11,
                      "aria-label": a11.title,
                      title: a11.title,
                      "aria-hidden": !j2 && S2 !== g.Vw.STICKY,
                      tabIndex: null != y2 ? y2 : j2 ? 0 : -1
                    },
                    a11.id
                  );
                })
              }),
              children: (0, s.jsx)(g.wI, {
                className: (0, l.$)(i4().tabCarousel, i4().important),
                elementId: N2,
                ...(0, d.Am)(d.e8.landing.MAIN_TABS),
                ...p2,
                children: null == (a10 = E2.data) ? void 0 : a10.map((e11, t11) => {
                  let { meta: a11, data: i11 } = e11;
                  return (0, s.jsx)(
                    g.oz,
                    {
                      className: i4().tab,
                      value: t11,
                      "aria-label": a11.title,
                      title: a11.title,
                      subtitle: null == i11 ? void 0 : i11.subtitle,
                      covers: null == i11 ? void 0 : i11.covers,
                      "aria-hidden": j2,
                      tabIndex: j2 ? -1 : 0,
                      withCovers: C2,
                      withSubtitle: h2,
                      withHeading: T2,
                      isShimmerVisible: E2.loadingState === _.GuX.PENDING
                    },
                    a11.id
                  );
                })
              })
            }),
            (0, s.jsx)("div", {
              className: b2,
              style: v2,
              children: null == (i10 = E2.data) ? void 0 : i10.map(
                (e11, t11) => (0, s.jsx)(
                  u.TabPanel,
                  {
                    className: i4().tabPanel,
                    name: t11,
                    value: p2.value,
                    elementId: N2,
                    children: (0, s.jsx)(f2, { landing: r2, tab: e11, tabIndex: t11 })
                  },
                  e11.meta.id
                )
              )
            })
          ]
        });
      }), sr = (0, r.PA)((e10) => {
        var t10, a10, i10, l2;
        let {
          landing: r2,
          headerConcealerComponent: d2,
          errorComponent: c2,
          containerClassName: g2,
          headerClassName: b2,
          containerStyle: v2,
          tabWithHeadingTitle: A2,
          tabWithCovers: T2,
          tabWithSubtitle: C2,
          staticHeaderClassName: h2,
          stickyHeaderClassName: I2,
          stickyHeaderTabIndex: L2,
          headerVariant: y2
        } = e10, S2 = (0, o.useSearchParams)(), E2 = (0, _.XJ9)(), N2 = ((e11) => (0, n.useCallback)(
          (t11) => {
            var a11;
            let i11 = null == (a11 = e11.tabs.data) ? void 0 : a11[t11];
            null == i11 || i11.blocks.forEach((t12) => {
              t12.isOutdated && (0, p.v)(t12.meta) && (t12.setHasSentAnalyticsOnLoaded(false), e11.getBlock(t12));
            });
          },
          [e11]
        ))(r2), { experiments: j2 } = (0, _.Pjs)(), k2 = j2.checkExperiment(_.zal.WebNextVirtualSkeleton, "on") ? ss : i8, x2 = (0, n.useMemo)(() => {
          var e11;
          if (!r2.isLoaded) return null;
          let t11 = S2.get(_.K3F.TAB), a11 = null == (e11 = r2.tabs.data) ? void 0 : e11.findIndex((e12) => e12.meta.id === t11);
          return "number" == typeof a11 && a11 >= 0 ? a11 : null;
        }, [r2.isLoaded, r2.tabs.data, S2]), R2 = (0, u.useTabsState)(
          null != (l2 = null != x2 ? x2 : null == (t10 = r2.meta) ? void 0 : t10.selectedTabIndex) ? l2 : 0
        ), f2 = (0, n.useCallback)(
          (e11) => {
            var t11, a11, i11;
            let s2 = null == (a11 = r2.tabs.data) || null == (t11 = a11[e11]) ? void 0 : t11.meta.id;
            if (e11 !== R2.value && N2(R2.value), null == (i11 = R2.onTabChange) || i11.call(R2, e11), s2) {
              let e12 = (0, _.bJ)(_.K3F.TAB, s2);
              e12 && E2(e12);
            }
          },
          [E2, r2.tabs.data, N2, R2]
        ), P2 = !!(r2.tabs.data && r2.tabs.data.length > 1), w2 = null == (a10 = r2.tabs.data) ? void 0 : a10[0], K2 = (0, n.useMemo)(() => {
          var e11, t11;
          return null != (t11 = null == (e11 = r2.upperBlocks) ? void 0 : e11.map(() => (0, n.createRef)())) ? t11 : [];
        }, [r2.upperBlocks]), O2 = (0, m.BL)(K2, { freezeOnceVisible: true }), M2 = (0, n.useMemo)(() => {
          var e11;
          if (null == (e11 = r2.upperBlocks) ? void 0 : e11.length)
            return (0, s.jsx)(_.hjC, {
              tabId: "",
              tabPos: -1,
              isTabSelectedByDefault: false,
              children: (0, s.jsx)("div", {
                className: i4().upperBlocks,
                children: r2.upperBlocks.map((e12, t11) => {
                  let { isIntersecting: a11 } = O2[e12.id] || {};
                  return (0, s.jsx)(
                    i1,
                    { landing: r2, block: e12, blockIndex: t11, isIntersecting: a11, forwardRef: K2[t11] },
                    e12.id
                  );
                })
              })
            });
        }, [null == (i10 = r2.upperBlocks) ? void 0 : i10.length, r2, O2, K2]);
        return P2 ? (0, s.jsx)(sl, {
          landing: r2,
          upperBlocks: M2,
          headerConcealerComponent: d2,
          tabsState: { value: R2.value, onTabChange: f2 },
          containerClassName: g2,
          containerStyle: v2,
          headerClassName: b2,
          tabWithHeadingTitle: A2,
          tabWithCovers: T2,
          tabWithSubtitle: C2,
          staticHeaderClassName: h2,
          stickyHeaderClassName: I2,
          stickyHeaderTabIndex: L2,
          headerVariant: y2
        }) : w2 ? (0, s.jsxs)("div", {
          className: g2,
          style: v2,
          children: [M2, d2, (0, s.jsx)(k2, { landing: r2, tab: w2, tabIndex: 0 })]
        }) : M2 ? (0, s.jsx)(_.jPc, { children: (0, s.jsxs)("div", { className: g2, style: v2, children: [M2, d2] }) }) : r2.isLoadedAndEmpty ? (0, s.jsx)("div", { className: g2, style: v2, children: c2 }) : null;
      });
    },
    22142: (e) => {
      e.exports = {
        root: "ContinueListenTrack_root__JFzVe",
        cover: "ContinueListenTrack_cover__E5zob",
        important: "ContinueListenTrack_important__4_84V",
        metaTrack: "ContinueListenTrack_metaTrack__hSIYC",
        content: "ContinueListenTrack_content__xU2R9",
        textContainer: "ContinueListenTrack_textContainer__zisLi",
        titleIcon: "ContinueListenTrack_titleIcon__smcf_",
        title: "ContinueListenTrack_title__LBdpD",
        explicitMark: "ContinueListenTrack_explicitMark___eXOa",
        metaContainer: "ContinueListenTrack_metaContainer__Yoo2N",
        playButton: "ContinueListenTrack_playButton__5tT4s",
        progress: "ContinueListenTrack_progress__CfJQP",
        fullCircle: "ContinueListenTrack_fullCircle__xrROh",
        progressCircle: "ContinueListenTrack_progressCircle__msDye"
      };
    },
    22243: (e) => {
      e.exports = { root: "Overview_root__2deXs" };
    },
    25743: (e, t, a) => {
      "use strict";
      a.d(t, { Promotions: () => y });
      var i = a(54486), s = a(50420), l = a(61910), r = a(43350), o = a(15209), n = a(81203), d = a(74125), c = a(80585), m = a(58360), u = a(6971), _ = a(97800), g = a(63463), p = a.n(g);
      let b = (e2) => {
        let { promotion: t2 } = e2, { ref: a2, intersectionPropertyId: o2 } = (0, d.nMI)(), n2 = (0, d.NKK)(), g2 = (0, l.useCallback)(() => {
          n2({ to: r.QT.Link });
        }, [n2]);
        return (0, i.jsxs)("div", {
          className: (0, s.$)(p().root, p().card),
          ref: a2,
          "data-intersection-property-id": o2,
          children: [
            (0, i.jsx)(c.N_, {
              className: p().coverLink,
              href: t2.weblink,
              onClick: g2,
              children: (0, i.jsx)(u.Paper, {
                className: p().cover,
                radius: "m",
                withShadow: true,
                children: (0, i.jsx)(m.Image, {
                  className: p().image,
                  src: t2.imageUrl,
                  alt: t2.title,
                  withAvatarReplace: true,
                  withAspectRatio: true,
                  size: 400,
                  fit: "cover"
                })
              })
            }),
            (0, i.jsxs)("div", {
              className: p().meta,
              children: [
                (0, i.jsx)(c.N_, {
                  className: p().titleLink,
                  href: t2.weblink,
                  onClick: g2,
                  children: (0, i.jsx)(_.Caption, {
                    variant: "div",
                    lineClamp: 1,
                    type: "entity",
                    size: "s",
                    weight: "medium",
                    children: t2.title
                  })
                }),
                (0, i.jsx)(_.Caption, {
                  className: p().subtitle,
                  variant: "div",
                  lineClamp: 1,
                  type: "entity",
                  size: "s",
                  weight: "medium",
                  children: t2.subtitle
                })
              ]
            })
          ]
        });
      };
      var v = a(17813), A = a.n(v), T = a(22674), C = a(76024), h = a.n(C);
      let I = (e2) => {
        let { isActive: t2, withHeadingShimmer: a2 } = e2;
        return (0, i.jsxs)("div", {
          className: h().root,
          children: [
            (0, i.jsx)(T.Shimmer, { isActive: t2, className: h().cover, radius: "l" }),
            (0, i.jsxs)("div", {
              className: h().meta,
              children: [
                a2 && (0, i.jsx)(T.Shimmer, { isActive: t2, className: h().heading, radius: "s" }),
                (0, i.jsx)(T.Shimmer, { isActive: t2, className: h().title, radius: "s" }),
                (0, i.jsx)(T.Shimmer, { isActive: t2, className: h().subtitle, radius: "s" })
              ]
            })
          ]
        });
      }, L = (e2) => {
        let {
          forwardRef: t2,
          isShimmerVisible: a2,
          isShimmerActive: m2,
          data: u2,
          meta: _2,
          containerClassName: g2,
          headerClassName: p2,
          headingVariant: v2,
          className: T2,
          ...C2
        } = e2, h2 = (0, l.useId)(), L2 = (0, l.useRef)(null), y2 = (0, l.useMemo)(() => {
          if (a2)
            return Array.from({ length: 6 }, (e3, t3) => (0, i.jsx)(I, { isActive: m2, withHeadingShimmer: true }, t3));
          return null == u2 ? void 0 : u2.items.map(
            (e3, t3) => (0, i.jsx)(
              d.Bki,
              {
                objectType: r.ky.Feature,
                objectId: e3.featureId,
                objectPosX: t3 + 1,
                objectPosY: 1,
                objectsCount: u2.items.length,
                children: (0, i.jsx)(b, { promotion: e3 })
              },
              e3.featureId
            )
          );
        }, [null == u2 ? void 0 : u2.items, m2, a2]);
        return (0, i.jsxs)("section", {
          className: (0, s.$)(A().root, T2),
          ref: t2,
          ...(0, o.getDataAttrFromProps)(C2),
          children: [
            (0, i.jsx)(c.Tw, {
              className: p2,
              labeledForId: h2,
              title: _2.title,
              controls: (0, i.jsx)(c.X9, { className: A().controls, carouselRef: L2 }),
              headingVariant: v2
            }),
            (0, i.jsx)(n.Carousel, {
              className: g2,
              ref: L2,
              itemClassName: (0, s.$)(A().item, A().important),
              "aria-labelledby": h2,
              children: y2
            })
          ]
        });
      }, y = (0, l.forwardRef)((e2, t2) => (0, i.jsx)(L, { forwardRef: t2, ...e2 }));
    },
    27574: (e, t, a) => {
      "use strict";
      a.d(t, { MixesGridMixCard: () => g });
      var i = a(54486), s = a(50420), l = a(28303), r = a(61910), o = a(31500), n = a(58360), d = a(6971), c = a(97800), m = a(80585), u = a(52494), _ = a.n(u);
      let g = (0, l.PA)((e2) => {
        var t2;
        let {
          className: a2,
          title: l2,
          weblink: u2,
          linkClassName: g2,
          covers: p,
          coverSize: b = 100,
          captionVariant: v = "div"
        } = e2, A = (0, r.useMemo)(() => {
          var e3;
          if (null == p || null == (e3 = p[0]) ? void 0 : e3.color)
            return { "--subcover-background-color": p[0].color };
        }, [p]);
        return (0, i.jsx)(m.N_, {
          href: u2,
          className: (0, s.$)(_().link, g2),
          ...(0, o.Am)(o.OA.mix.MIX_CARD),
          children: (0, i.jsxs)(d.Paper, {
            radius: "m",
            style: A,
            className: (0, s.$)(_().root, a2),
            children: [
              (0, i.jsxs)("div", {
                className: _().plate,
                ...(0, o.Am)(o.OA.mix.MIX_CARD_PLATE),
                children: [
                  (0, i.jsx)("div", { className: _().subcover, ...(0, o.Am)(o.OA.mix.MIX_CARD_SUBCOVER) }),
                  (0, i.jsx)(n.Image, {
                    src: null == p || null == (t2 = p[0]) ? void 0 : t2.uri,
                    withAvatarReplace: true,
                    fit: "contain",
                    className: _().cover,
                    size: b,
                    ...(0, o.Am)(o.OA.mix.MIX_CARD_COVER)
                  })
                ]
              }),
              (0, i.jsx)("div", {
                className: _().header,
                children: (0, i.jsx)(c.Caption, {
                  variant: v,
                  size: "xs",
                  weight: "bold",
                  className: _().title,
                  lineClamp: 2,
                  ...(0, o.Am)(o.OA.mix.MIX_CARD_HEADER),
                  children: l2
                })
              })
            ]
          })
        });
      });
    },
    27906: (e, t, a) => {
      "use strict";
      a.d(t, { NZ: () => o.MixCard, f: () => r, Ju: () => s });
      var i = a(93064);
      let s = (e2) => {
        var t2;
        return {
          id: e2.id,
          title: e2.title,
          weblink: null != (t2 = e2.action.weblink) ? t2 : "",
          covers: (0, i.wg)(e2.covers || []),
          imagesLayoutType: e2.style.imagesLayoutType
        };
      };
      var l = a(41704);
      let r = i.gK.model("MixItem", {
        id: i.gK.string,
        title: i.gK.string,
        weblink: i.gK.string,
        covers: i.gK.maybe(i.gK.array(i.gK.string)),
        imagesLayoutType: i.gK.enumeration(Object.values(l.R))
      });
      var o = a(64409);
    },
    29206: (e) => {
      e.exports = {
        root: "BaseAlbumPromo_root__wgbC3",
        controls: "BaseAlbumPromo_controls__NiVRJ",
        item: "BaseAlbumPromo_item__coi3X",
        important: "BaseAlbumPromo_important__OiNRT"
      };
    },
    29468: (e, t, a) => {
      "use strict";
      a.d(t, { MapBlock: () => T });
      var i = a(54486), s = a(28303), l = a(43426), r = a(43350), o = a(8817), n = a(58360), d = a(97800), c = a(74125), m = a(80585), u = a(61910), _ = a(15209), g = a(79367), p = a.n(g), b = a(73097), v = a.n(b);
      let A = (0, s.PA)((e2) => {
        let { title: t2, colors: a2 } = e2;
        return (0, i.jsxs)(d.Caption, {
          size: "m",
          variant: "span",
          className: v().station,
          children: [
            (0, i.jsx)("div", {
              className: v().stationColors,
              children: a2.map(
                (e3, t3) => (0, i.jsx)("span", { className: v().colorSpan, style: { "--metro-station-color-line": e3 } }, t3)
              )
            }),
            t2
          ]
        });
      }), T = (0, s.PA)((e2) => {
        var t2, a2, s2;
        let { data: g2 } = e2, { place: b2, city: v2, address: T2, map: C } = g2, h = (() => {
          let { theme: e3 } = (0, c.DPo)();
          return (0, u.useCallback)(
            (t3) => {
              let a3 = (0, _.httpsReplacer)(t3.replace("%%", "1300,1000")), { href: i2 } = (0, c.uvd)(a3, { query: { theme: null != e3 ? e3 : "" } });
              return i2;
            },
            [e3]
          );
        })(), { formatMessage: I } = (0, l.A)(), { href: L, target: y } = ((e3) => {
          let { theme: t3 } = (0, c.DPo)();
          return (0, c.uvd)(null != e3 ? e3 : "", {
            query: { theme: null != t3 ? t3 : "" },
            options: { isExternalLink: true }
          });
        })(null != (s2 = null == g2 || null == (t2 = g2.map) ? void 0 : t2.url) ? s2 : ""), S = (0, c.NKK)(), { ref: E, intersectionPropertyId: N } = (0, c.nMI)(), j = (0, o.c)(() => {
          S({ to: r.QT.Link, deepLink: L });
        });
        return (0, i.jsxs)("div", {
          ref: E,
          "data-intersection-property-id": N,
          className: p().root,
          children: [
            (0, i.jsx)(d.Heading, { size: "m", variant: "h3", className: p().heading, children: b2 }),
            (0, i.jsx)(m.N_, {
              onClick: j,
              "aria-label": I({ id: "entity-names.map-url" }),
              href: L,
              className: p().linkContainer,
              target: y,
              children: (0, i.jsx)(n.Image, {
                createUrlReplacer: h,
                className: p().mapImage,
                alt: b2,
                fit: "cover",
                size: 600,
                src: null == C ? void 0 : C.imageUrl,
                withAvatarReplace: true
              })
            }),
            (0, i.jsxs)("div", {
              className: p().addressContainer,
              children: [
                (0, i.jsx)(d.Caption, {
                  variant: "span",
                  size: "m",
                  weight: "medium",
                  className: p().address,
                  children: "".concat(v2, ", ").concat(T2)
                }),
                (0, i.jsx)("div", {
                  "aria-label": I({ id: "entity-names.metro-stations" }),
                  className: p().metroStations,
                  children: null == (a2 = g2.groupedMetroStations) ? void 0 : a2.map((e3, t3) => (0, i.jsx)(A, { title: e3.title, colors: e3.colors }, t3))
                })
              ]
            })
          ]
        });
      });
    },
    29715: (e) => {
      e.exports = { root: "PlaylistFiltersShimmer_root__Pam_a", shimmer: "PlaylistFiltersShimmer_shimmer__Grx4y" };
    },
    31879: (e) => {
      e.exports = { item: "ArtistPopularTracks_item__PsKwP", important: "ArtistPopularTracks_important__hdfzU" };
    },
    32156: (e) => {
      e.exports = {
        root: "ArtistActionItems_root__r3J3K",
        item: "ArtistActionItems_item__8DYtg",
        ripple: "ArtistActionItems_ripple__3t0gz",
        menuItem: "ArtistActionItems_menuItem__qWymt",
        cover: "ArtistActionItems_cover__4E3qx",
        text: "ArtistActionItems_text__RcAY_"
      };
    },
    33519: (e) => {
      e.exports = { cover: "FamiliarYou_cover__nY4e8", shimmerCover: "FamiliarYou_shimmerCover__HFgkx" };
    },
    34195: (e) => {
      e.exports = { root: "FamiliarYouAndArtistPick_root___Ihxe" };
    },
    34282: (e, t, a) => {
      "use strict";
      a.d(t, { R: () => p, k: () => g });
      var i = a(54486), s = a(50420), l = a(61910), r = a(43350), o = a(81203), n = a(76866), d = a(74125), c = a(90372), m = a.n(c);
      let u = (e2) => {
        let { forwardRef: t2, items: a2, itemClassName: l2, containerClassName: c2, ariaLabelledBy: u2 } = e2;
        return (0, i.jsx)(o.Carousel, {
          ref: t2,
          className: c2,
          itemClassName: (0, s.$)(m().item, m().important, l2),
          "aria-labelledby": u2,
          children: null == a2 ? void 0 : a2.map(
            (e3, t3) => (0, i.jsx)(
              d.Bki,
              {
                objectType: r.ky.Wave,
                objectId: e3.stationId,
                objectPosX: t3 + 1,
                objectPosY: 1,
                objectsCount: null == a2 ? void 0 : a2.length,
                children: (0, i.jsx)(n.xy, { vibe: e3 })
              },
              e3.stationId
            )
          )
        });
      }, _ = (e2) => {
        let { forwardRef: t2, isActive: a2, itemClassName: l2, containerClassName: r2, ariaLabelledBy: d2, length: c2 } = e2;
        return (0, i.jsx)(o.Carousel, {
          ref: t2,
          className: r2,
          itemClassName: (0, s.$)(m().item, m().important, l2),
          "aria-labelledby": d2,
          children: Array.from({ length: c2 }, (e3, t3) => (0, i.jsx)(n.Eb, { isActive: a2 }, t3))
        });
      }, g = (0, l.forwardRef)((e2, t2) => (0, i.jsx)(u, { forwardRef: t2, ...e2 })), p = (0, l.forwardRef)((e2, t2) => (0, i.jsx)(_, { forwardRef: t2, ...e2 }));
    },
    35863: (e) => {
      e.exports = {
        root: "CollectionVibeAgent_root__Ckkcd",
        container: "CollectionVibeAgent_container__Vnapv",
        text: "CollectionVibeAgent_text__WYNR_",
        playButton: "CollectionVibeAgent_playButton__YANpE",
        coverShimmer: "CollectionVibeAgent_coverShimmer__q32bW",
        shimmerContainer: "CollectionVibeAgent_shimmerContainer__4wBoC",
        item: "CollectionVibeAgent_item__X8a1I",
        important: "CollectionVibeAgent_important__FEcUJ"
      };
    },
    36311: (e) => {
      e.exports = {
        root_withNewConcertCards: "Concerts_root_withNewConcertCards__42M3w",
        item: "Concerts_item__jetvg",
        important: "Concerts_important__rvXs6",
        root: "Concerts_root__12jay",
        controls: "Concerts_controls__n4qr8",
        shimmer: "Concerts_shimmer__ujsLv"
      };
    },
    37645: (e) => {
      e.exports = {
        root: "CollectionArtistsAndTopWithItems_root__tR4BR",
        controls: "CollectionArtistsAndTopWithItems_controls__Z_VQb",
        itemContainer: "CollectionArtistsAndTopWithItems_itemContainer__xF00m",
        actionItem: "CollectionArtistsAndTopWithItems_actionItem__7xPUf",
        important: "CollectionArtistsAndTopWithItems_important__TEa6m",
        item: "CollectionArtistsAndTopWithItems_item__fPqL0"
      };
    },
    40492: (e) => {
      e.exports = { root: "CollectionAlbumsEmpty_root__xtfuI", text: "CollectionAlbumsEmpty_text__fRpx_" };
    },
    41704: (e, t, a) => {
      "use strict";
      var i;
      a.d(t, { R: () => i }), (function(e2) {
        e2.RADIAL = "RADIAL", e2.STACK = "STACK";
      })(i || (i = {}));
    },
    42167: (e) => {
      e.exports = { item: "Mixes_item__Om7aR" };
    },
    42827: (e) => {
      e.exports = {
        root: "SearchHistory_root__0z_bV",
        fallback: "SearchHistory_fallback____oTN",
        button: "SearchHistory_button__LBJeT"
      };
    },
    42922: (e) => {
      e.exports = { root: "CollectionArtistsEmpty_root__i2XSM", text: "CollectionArtistsEmpty_text__E_gjT" };
    },
    44547: (e) => {
      e.exports = {
        root: "EditorialVibesAgent_root__DWv1O",
        controls: "EditorialVibesAgent_controls__8zmg0",
        item: "EditorialVibesAgent_item__D8lQA",
        important: "EditorialVibesAgent_important__xnrnN"
      };
    },
    45779: (e) => {
      e.exports = {
        root_withControls: "CollectionAlbumsPresaves_root_withControls__qE_u_",
        controls: "CollectionAlbumsPresaves_controls__8twKX",
        header: "CollectionAlbumsPresaves_header__1flkp",
        important: "CollectionAlbumsPresaves_important__EkdBU",
        tab: "CollectionAlbumsPresaves_tab__V6yvN",
        tabShimmer: "CollectionAlbumsPresaves_tabShimmer__T6w2W",
        tabCarousel: "CollectionAlbumsPresaves_tabCarousel__hobTn",
        tabPanel: "CollectionAlbumsPresaves_tabPanel__ZHz6v",
        carouselEmpty: "CollectionAlbumsPresaves_carouselEmpty__8szhR",
        item: "CollectionAlbumsPresaves_item__to1P9"
      };
    },
    45825: (e) => {
      e.exports = {
        titleShimmer: "WizardTextShimmer_titleShimmer__g__ye",
        titleTextShimmer: "WizardTextShimmer_titleTextShimmer__ThHNk",
        textShimmer: "WizardTextShimmer_textShimmer__QokKt",
        descriptionShimmer: "WizardTextShimmer_descriptionShimmer__Z9daY"
      };
    },
    46758: (e, t, a) => {
      "use strict";
      a.d(t, { v: () => i });
      let i = (e2) => !!(e2 && "object" == typeof e2 && "source" in e2);
    },
    48771: (e) => {
      e.exports = {
        root: "LikesAndHistory_root__KCuz_",
        carousel: "LikesAndHistory_carousel__579RD",
        carouselItem: "LikesAndHistory_carouselItem__Yq5Xw",
        favoritesCoverContainer: "LikesAndHistory_favoritesCoverContainer__UUIDf",
        favoritesCover: "LikesAndHistory_favoritesCover__Nt7Gm",
        historyIcon: "LikesAndHistory_historyIcon__2FAMu",
        historyIconContainer: "LikesAndHistory_historyIconContainer__KPPbS"
      };
    },
    52239: (e, t, a) => {
      "use strict";
      a.d(t, { g: () => _ });
      var i = a(54486), s = a(61910), l = a(43350), r = a(60049), o = a(94376), n = a(55616), d = a(83909), c = a(74125), m = a(80585);
      let u = (e2) => {
        let {
          forwardRef: t2,
          isShimmerVisible: a2,
          isShimmerActive: s2,
          containerClassName: u2,
          headerClassName: _2,
          meta: g,
          data: p,
          headingVariant: b,
          className: v,
          ...A
        } = e2;
        return (0, i.jsx)(m.OY, {
          className: v,
          ...A,
          isShimmerVisible: a2,
          isShimmerActive: s2,
          headerClassName: _2,
          containerClassName: u2,
          title: g.title,
          description: g.description,
          viewAllActionLink: g.viewAllActionLink,
          ref: t2,
          headingVariant: b,
          children: null == p ? void 0 : p.items.map((e3, t3) => {
            switch (e3.type) {
              case r._.ALBUM_ITEM:
                return (0, i.jsx)(
                  c.Bki,
                  {
                    objectType: l.ky.Album,
                    objectId: String(e3.data.id),
                    objectPosX: t3 + 1,
                    objectPosY: 1,
                    objectsCount: p.items.length,
                    children: (0, i.jsx)(o.aX, { withLikesCount: true, album: e3.data, contentLinesCount: 3 })
                  },
                  e3.data.id
                );
              case r._.ARTIST_ITEM:
                return (0, i.jsx)(
                  c.Bki,
                  {
                    objectType: l.ky.Artist,
                    objectId: e3.data.id,
                    objectPosX: t3 + 1,
                    objectPosY: 1,
                    objectsCount: p.items.length,
                    children: (0, i.jsx)(n.ao, { artist: e3.data, contentLinesCount: 3 }, e3.data.id)
                  },
                  e3.data.id
                );
              case r._.PLAYLIST_ITEM:
                return (0, i.jsx)(
                  c.Bki,
                  {
                    objectType: l.ky.Playlist,
                    objectId: e3.data.id,
                    objectPosX: t3 + 1,
                    objectPosY: 1,
                    objectsCount: p.items.length,
                    children: (0, i.jsx)(d.B6, { playlist: e3.data, contentLinesCount: 3 }, e3.data.id)
                  },
                  e3.data.id
                );
            }
          })
        });
      }, _ = (0, s.forwardRef)((e2, t2) => (0, i.jsx)(u, { forwardRef: t2, ...e2 }));
    },
    52494: (e) => {
      e.exports = {
        plate: "MixesGridMixCard_plate__ONH3P",
        root: "MixesGridMixCard_root__HHE7z",
        subcover: "MixesGridMixCard_subcover__z5sBj",
        link: "MixesGridMixCard_link__D3_S6",
        header: "MixesGridMixCard_header__t24VH",
        title: "MixesGridMixCard_title__fKTCy",
        cover: "MixesGridMixCard_cover__Ra3ic"
      };
    },
    53403: (e) => {
      e.exports = {
        root: "NewReleases_root__4ONiw",
        controls: "NewReleases_controls__zlJZF",
        shimmerImage: "NewReleases_shimmerImage__8IEd_",
        shimmerCard: "NewReleases_shimmerCard__S1gfL",
        item: "NewReleases_item__Gv0iR",
        important: "NewReleases_important__qkt9x"
      };
    },
    54861: (e) => {
      e.exports = {
        root: "VibesAgent_root__vZxtE",
        controls: "VibesAgent_controls__6jNJF",
        header: "VibesAgent_header__PrZP3",
        important: "VibesAgent_important__5yfOt",
        tab: "VibesAgent_tab__Wwcd_",
        tabShimmer: "VibesAgent_tabShimmer__TnlQU",
        tabCarousel: "VibesAgent_tabCarousel__q__hc",
        item: "VibesAgent_item__UBIWG"
      };
    },
    54895: (e) => {
      e.exports = {
        root: "InStyle_root__ZsdXE",
        controls: "InStyle_controls__mGqhj",
        header: "InStyle_header__C2AWP",
        important: "InStyle_important__msPsl",
        tab: "InStyle_tab__DeURY",
        tabCarousel: "InStyle_tabCarousel__SXqBO",
        item: "InStyle_item__e5_Qz"
      };
    },
    56259: (e) => {
      e.exports = { root: "ItemList_root__0fUbd", shimmer: "ItemList_shimmer__hIZtA" };
    },
    59699: (e) => {
      e.exports = {
        root_withControls: "CollectionPlaylists_root_withControls__YV7o_",
        controls: "CollectionPlaylists_controls___7XSv",
        header: "CollectionPlaylists_header__EDtBS",
        important: "CollectionPlaylists_important__oumcA",
        tab: "CollectionPlaylists_tab__PppbA",
        tabShimmer: "CollectionPlaylists_tabShimmer__U_ZFn",
        tabCarousel: "CollectionPlaylists_tabCarousel__hWuL_",
        tabPanel: "CollectionPlaylists_tabPanel__wSwRR",
        carouselEmpty: "CollectionPlaylists_carouselEmpty__SVn6E",
        createPlaylistCard: "CollectionPlaylists_createPlaylistCard__1cMca",
        item: "CollectionPlaylists_item__YeviY"
      };
    },
    60916: (e) => {
      e.exports = {
        root: "NeuromusicButton_root__OMwq0",
        ripple: "NeuromusicButton_ripple__B9e3A",
        textContainer: "NeuromusicButton_textContainer__2rb8y",
        title: "NeuromusicButton_title__mTAB8",
        button: "NeuromusicButton_button__kT4GN",
        icon: "NeuromusicButton_icon__HTDr2"
      };
    },
    61313: (e) => {
      e.exports = { root: "CollectionPlaylistsEmpty_root__KGNv_" };
    },
    61715: (e, t, a) => {
      "use strict";
      a.d(t, { fc: () => o, Gd: () => n.MapBlock, rI: () => d.ShimmerMapBlock, P5: () => i });
      let i = (e2) => ({ title: e2.title, lineColor: e2["line-color"] });
      var s = a(93064);
      let l = s.gK.model("MapUrl", { imageUrl: s.gK.string, url: s.gK.string }), r = s.gK.model("MetroStation", { title: s.gK.string, lineColor: s.gK.string }), o = s.gK.model("BaseMap", {
        place: s.gK.string,
        city: s.gK.string,
        address: s.gK.string,
        metroStations: s.gK.maybeNull(s.gK.array(r)),
        map: s.gK.maybeNull(l)
      }).views((e2) => ({
        get groupedMetroStations() {
          if (!e2.metroStations) return [];
          let t2 = /* @__PURE__ */ new Map();
          return e2.metroStations.forEach((e3) => {
            let a2 = t2.get(e3.title);
            a2 || (a2 = /* @__PURE__ */ new Set(), t2.set(e3.title, a2)), a2.add(e3.lineColor);
          }), Array.from(t2.entries()).map((e3) => {
            let [t3, a2] = e3;
            return { title: t3, colors: Array.from(a2) };
          });
        }
      }));
      var n = a(29468), d = a(69573);
    },
    62277: (e, t, a) => {
      "use strict";
      a.d(t, { EntitiesCarousel: () => p });
      var i = a(54486), s = a(28303), l = a(61910), r = a(43350), o = a(60049), n = a(94376), d = a(55616), c = a(83909), m = a(76866), u = a(74125), _ = a(80585);
      let g = (0, s.PA)((e2) => {
        let {
          forwardRef: t2,
          isShimmerVisible: a2,
          isShimmerActive: s2,
          containerClassName: g2,
          headerClassName: p2,
          meta: b,
          data: v,
          headingVariant: A,
          className: T,
          isLoaded: C,
          shouldSentAnalyticsOnLoaded: h,
          hasSentAnalyticsOnLoaded: I,
          setHasSentAnalyticsOnLoaded: L,
          ...y
        } = e2, S = (0, u.fBs)();
        return (0, l.useEffect)(() => {
          h && !I && C && (S(), L(true));
        }, [I, C, S, L, h]), (0, i.jsx)(_.OY, {
          className: T,
          ...y,
          isShimmerVisible: a2,
          isShimmerActive: s2,
          containerClassName: g2,
          headerClassName: p2,
          title: b.title,
          description: b.description,
          viewAllActionLink: b.viewAllActionLink,
          ref: t2,
          headingVariant: A,
          children: null == v ? void 0 : v.items.map((e3, t3) => {
            switch (e3.type) {
              case o._.LIKED_PLAYLIST_ITEM:
                return (0, i.jsx)(
                  u.Bki,
                  {
                    objectType: r.ky.Playlist,
                    objectId: e3.data.id,
                    objectPosX: t3 + 1,
                    objectPosY: 1,
                    objectsCount: v.items.length,
                    children: (0, i.jsx)(c.B6, { playlist: e3.data, contentLinesCount: 3 })
                  },
                  e3.data.key
                );
              case o._.ALBUM_ITEM:
                return (0, i.jsx)(
                  u.Bki,
                  {
                    objectType: r.ky.Album,
                    objectId: String(e3.data.id),
                    objectPosX: t3 + 1,
                    objectPosY: 1,
                    objectsCount: v.items.length,
                    children: (0, i.jsx)(n.aX, {
                      album: e3.data,
                      contentLinesCount: 3,
                      releaseDateFormatter: u.mtR
                    })
                  },
                  e3.data.id
                );
              case o._.ARTIST_ITEM:
                return (0, i.jsx)(
                  u.Bki,
                  {
                    objectType: r.ky.Artist,
                    objectId: String(e3.data.id),
                    objectPosX: t3 + 1,
                    objectPosY: 1,
                    objectsCount: v.items.length,
                    children: (0, i.jsx)(d.ao, { artist: e3.data, contentLinesCount: 3 })
                  },
                  e3.data.id
                );
              case o._.WAVE_AGENT_ITEM:
                return (0, i.jsx)(
                  u.Bki,
                  {
                    objectType: r.ky.Wave,
                    objectId: e3.data.stationId,
                    objectPosX: t3 + 1,
                    objectPosY: 1,
                    objectsCount: v.items.length,
                    children: (0, i.jsx)(m.yi, { vibe: e3.data })
                  },
                  e3.data.stationId
                );
            }
          })
        });
      }), p = (0, l.forwardRef)((e2, t2) => (0, i.jsx)(g, { forwardRef: t2, ...e2 }));
    },
    63463: (e) => {
      e.exports = {
        root: "PromotionsCard_root__1yY_m",
        coverLink: "PromotionsCard_coverLink__masNa",
        image: "PromotionsCard_image__4lmYk",
        titleLink: "PromotionsCard_titleLink__3q_M5",
        subtitle: "PromotionsCard_subtitle__fGfn9"
      };
    },
    64409: (e, t, a) => {
      "use strict";
      a.d(t, { MixCard: () => g });
      var i = a(54486), s = a(50420), l = a(28303), r = a(31500), o = a(41704), n = a(58360), d = a(6971), c = a(97800), m = a(80585), u = a(7809), _ = a.n(u);
      let g = (0, l.PA)((e2) => {
        let {
          className: t2,
          title: a2,
          weblink: l2,
          covers: u2 = [],
          coverSize: g2 = 100,
          imagesLayoutType: p,
          headingVariant: b = "h3"
        } = e2;
        return (0, i.jsx)(m.N_, {
          href: l2,
          ...(0, r.Am)(r.OA.mix.MIX_CARD),
          children: (0, i.jsxs)(d.Paper, {
            className: (0, s.$)(_().root, t2),
            radius: "l",
            children: [
              (0, i.jsx)("div", {
                className: _().header,
                children: (0, i.jsx)(c.Caption, {
                  variant: b,
                  size: "xs",
                  weight: "bold",
                  className: _().title,
                  lineClamp: 2,
                  ...(0, r.Am)(r.OA.mix.MIX_CARD_HEADER),
                  children: a2
                })
              }),
              (0, i.jsxs)("div", {
                className: (0, s.$)(_().covers, {
                  [_().covers_radial]: p === o.R.RADIAL,
                  [_().covers_stack]: p === o.R.STACK
                }),
                ...(0, r.Am)(r.OA.mix.MIX_CARD_COVERS),
                children: [
                  (0, i.jsx)(n.Image, {
                    src: u2[2],
                    withAvatarReplace: true,
                    fit: "contain",
                    className: _().cover,
                    size: g2,
                    ...(0, r.Am)(r.OA.mix.MIX_CARD_COVER_IMAGE_3)
                  }),
                  (0, i.jsx)(n.Image, {
                    src: u2[1],
                    withAvatarReplace: true,
                    fit: "contain",
                    className: _().cover,
                    size: g2,
                    ...(0, r.Am)(r.OA.mix.MIX_CARD_COVER_IMAGE_2)
                  }),
                  (0, i.jsx)(n.Image, {
                    src: u2[0],
                    withAvatarReplace: true,
                    fit: "contain",
                    className: _().cover,
                    size: g2,
                    ...(0, r.Am)(r.OA.mix.MIX_CARD_COVER_IMAGE_1)
                  })
                ]
              })
            ]
          })
        });
      });
    },
    66049: (e) => {
      e.exports = {
        carousel: "PlaylistFilters_carousel__pO6nw",
        carousel_noSmooth: "PlaylistFilters_carousel_noSmooth__cqaBs",
        filter: "PlaylistFilters_filter__i2ZUG",
        filter_selected: "PlaylistFilters_filter_selected__LA9gY"
      };
    },
    66149: (e) => {
      e.exports = { root: "EditorialVibes_root__MPgdy", controls: "EditorialVibes_controls__sKvZK" };
    },
    66417: (e) => {
      e.exports = {
        root: "Concert_root__INQJc",
        cover: "Concert_cover__POyDO",
        index: "Concert_index__cPRuN",
        meta: "Concert_meta__s_lsH",
        textContainer: "Concert_textContainer__50dZP",
        date: "Concert_date__3xwWB",
        info: "Concert_info__viObm",
        concertTitle: "Concert_concertTitle__kngHo",
        description: "Concert_description__JTZtZ",
        descriptionContainer: "Concert_descriptionContainer__cPF3d",
        cashback: "Concert_cashback__b7feO",
        title: "Concert_title__tX2Mj"
      };
    },
    69422: (e) => {
      e.exports = {
        root: "ArtistWithItemsShimmer_root__0UQ8u",
        actionItems: "ArtistWithItemsShimmer_actionItems__drxv9",
        actionItem: "ArtistWithItemsShimmer_actionItem__NksfP",
        actionCover: "ArtistWithItemsShimmer_actionCover__4LUi8",
        actionTextContainer: "ArtistWithItemsShimmer_actionTextContainer__Qijsx",
        actionText: "ArtistWithItemsShimmer_actionText__nUSLH",
        actionText_title: "ArtistWithItemsShimmer_actionText_title__cXusB"
      };
    },
    69573: (e, t, a) => {
      "use strict";
      a.d(t, { ShimmerMapBlock: () => n });
      var i = a(54486), s = a(28303), l = a(22674), r = a(72685), o = a.n(r);
      let n = (0, s.PA)((e2) => {
        let { isActive: t2 } = e2;
        return (0, i.jsxs)("div", {
          className: o().root,
          children: [
            (0, i.jsx)(l.Shimmer, { className: o().heading, radius: "s", isActive: t2 }),
            (0, i.jsx)(l.Shimmer, { className: o().mapImage, radius: "s", isActive: t2 }),
            (0, i.jsx)(l.Shimmer, { className: o().address, radius: "s", isActive: t2 }),
            (0, i.jsx)(l.Shimmer, { className: o().metroStations, radius: "s", isActive: t2 })
          ]
        });
      });
    },
    69731: (e) => {
      e.exports = { item: "MixesMusic_item__9QVmW", shimmer: "MixesMusic_shimmer__rJ3xa" };
    },
    72107: (e, t, a) => {
      "use strict";
      a.d(t, { Q: () => l });
      var i = a(35620);
      let s = [i.t.ARTIST_POPULAR_TRACKS_AND_RELEASES, i.t.FAMILIAR_YOU_AND_ARTIST_PICK], l = (e2) => s.includes(e2.type);
    },
    72685: (e) => {
      e.exports = {
        root: "ShimmerMapBlock_root__TAa25",
        heading: "ShimmerMapBlock_heading__rF7ts",
        mapImage: "ShimmerMapBlock_mapImage__bQbYD",
        address: "ShimmerMapBlock_address__GgNdC",
        metroStations: "ShimmerMapBlock_metroStations__omTcd"
      };
    },
    73097: (e) => {
      e.exports = {
        station: "MetroStation_station__mCvqj",
        stationColors: "MetroStation_stationColors__MgJFV",
        colorSpan: "MetroStation_colorSpan__cFHsy"
      };
    },
    73665: (e) => {
      e.exports = {
        artistLink: "ArtistPick_artistLink__WYRFP",
        artistsSpoiler: "ArtistPick_artistsSpoiler__HBKka",
        subTitle: "ArtistPick_subTitle__5SJFj",
        text: "ArtistPick_text__sIhNG",
        smallCoverContainer: "ArtistPick_smallCoverContainer__iBgJu",
        cover: "ArtistPick_cover__9utVr",
        smallCover: "ArtistPick_smallCover__6NSnL",
        shimmerCover: "ArtistPick_shimmerCover__HIauy"
      };
    },
    75468: (e, t, a) => {
      "use strict";
      var i;
      a.d(t, { n: () => i }), (function(e2) {
        e2.ALBUM = "album_tab", e2.PRESAVED_ALBUM = "presaved_album_tab";
      })(i || (i = {}));
    },
    75987: (e) => {
      e.exports = {
        root: "LikesAndHistoryItem_root__oI1gk",
        link: "LikesAndHistoryItem_link__snTl_",
        start: "LikesAndHistoryItem_start__wdtiV",
        textContainer: "LikesAndHistoryItem_textContainer__yGdOu",
        titleIcon: "LikesAndHistoryItem_titleIcon__2D_yS",
        title: "LikesAndHistoryItem_title__hdi2H",
        subtitle: "LikesAndHistoryItem_subtitle__ghuKi",
        covers: "LikesAndHistoryItem_covers__9k_yw",
        coverContainer: "LikesAndHistoryItem_coverContainer__fwXXJ",
        cover: "LikesAndHistoryItem_cover__QlRhz"
      };
    },
    76015: (e) => {
      e.exports = {
        root: "Vibes_root__Bk6PF",
        controls: "Vibes_controls__bUp2H",
        header: "Vibes_header__RcW5b",
        important: "Vibes_important__Vew_4",
        tab: "Vibes_tab__uOfqW",
        tabShimmer: "Vibes_tabShimmer__hjehH",
        tabCarousel: "Vibes_tabCarousel__bSvp0"
      };
    },
    76024: (e) => {
      e.exports = {
        root: "PromotionShimmer_root__Nb8vU",
        cover: "PromotionShimmer_cover__WYwD7",
        meta: "PromotionShimmer_meta__9eRwi",
        heading: "PromotionShimmer_heading__38lLU",
        title: "PromotionShimmer_title__TLj1g",
        subtitle: "PromotionShimmer_subtitle__LS5v_"
      };
    },
    77516: (e, t, a) => {
      "use strict";
      a.d(t, { Q$: () => h, Ux: () => A, LW: () => m, rA: () => c });
      var i = a(44282), s = a(27510), l = a(74125), r = a(4885), o = a(61910), n = a(8817);
      let d = { width: 400, height: 400 }, c = (e2) => {
        let { count: t2, getEstimateSize: a2, gap: i2, containerRef: s2 } = e2, {
          settings: { isMobile: c2 }
        } = (0, l.Pjs)(), { contentScrollRef: m2 } = (0, l.gKY)(), u2 = (0, o.useRef)(/* @__PURE__ */ new Map()), _2 = (0, o.useRef)(void 0), g2 = {
          count: t2,
          gap: i2,
          estimateSize: (e3) => {
            let t3 = u2.current.get(String(e3));
            return null != t3 ? t3 : a2(e3);
          },
          overscan: 2,
          initialRect: d,
          isScrollingResetDelay: 50,
          scrollMargin: ((e3, t3, a3) => {
            if (!t3) return 0;
            let i3 = t3.getBoundingClientRect().top;
            return e3 && 1 ? i3 + window.scrollY : !e3 && a3 ? i3 + a3.scrollTop : 0;
          })(c2, s2, m2)
        }, p2 = (0, r.XW)(g2), b2 = (0, r.Te)({ ...g2, getScrollElement: () => m2, initialOffset: null == m2 ? void 0 : m2.scrollTop }), v2 = c2 ? p2 : b2, A2 = (0, n.c)(() => {
          v2.measure();
        });
        return (0, o.useEffect)(() => {
          _2.current || (_2.current = new ResizeObserver((e3) => {
            let t3 = false;
            e3.forEach((e4) => {
              let a3 = e4.target.getAttribute("data-index");
              if (e4.target && a3) {
                let i3 = e4.contentRect.height;
                i3 && i3 !== u2.current.get(a3) && (u2.current.set(a3, e4.contentRect.height), t3 = true);
              }
            }), t3 && A2();
          }));
        }, [A2]), { virtualizer: v2, resizeObserver: _2.current };
      }, m = (e2) => {
        let {
          count: t2,
          getEstimateRowSize: a2,
          rowGap: r2,
          columnGap: o2,
          minColumnWidth: n2,
          maxColumnWidth: d2,
          minColumnCount: m2,
          maxColumnCount: u2,
          containerRef: _2
        } = e2, { rowCount: g2, columnCount: p2 } = (0, l.E11)({
          totalCount: t2,
          columnGap: null != o2 ? o2 : 0,
          minColumnCount: m2,
          maxColumnWidth: d2,
          minColumnWidth: n2,
          maxColumnCount: u2,
          containerRef: _2
        }), { virtualizer: b2, resizeObserver: v2 } = c({ count: g2, getEstimateSize: a2, gap: r2, containerRef: _2 }), A2 = (0, i.A)(
          Array.from({ length: t2 }, (e3, t3) => t3),
          p2
        ), T2 = (0, s.L)(() => {
          var e3, t3;
          if (!b2.range) return null;
          let a3 = null == (e3 = A2[b2.range.startIndex]) ? void 0 : e3.at(0), i2 = null == (t3 = A2[b2.range.endIndex]) ? void 0 : t3.at(-1);
          return void 0 !== a3 && void 0 !== i2 ? { startIndex: a3, endIndex: i2 } : null;
        });
        return { virtualizer: b2, rowResizeObserver: v2, indices: A2, columnCount: p2, visibleRange: T2 };
      };
      var u = a(54486), _ = a(28303), g = a(67648), p = a(50420), b = a(15136), v = a.n(b);
      let A = (0, _.PA)((e2) => {
        let {
          indices: t2,
          virtualItem: a2,
          renderItemByIndex: i2,
          columnClassName: s2,
          className: l2,
          resizeObserver: r2,
          scrollMargin: n2
        } = e2, d2 = (0, o.useRef)(null), c2 = t2[a2.index], m2 = { "--virtual-grid-row-vertical-offset": "".concat(a2.start - n2, "px") };
        return (0, o.useEffect)(() => {
          let e3 = d2.current;
          if (e3)
            return null == r2 || r2.observe(e3), () => {
              null == r2 || r2.unobserve(e3);
            };
        }, [r2]), (0, u.jsx)("div", {
          "data-index": a2.index,
          ref: d2,
          style: m2,
          className: (0, p.$)(v().root, l2),
          children: null == c2 ? void 0 : c2.map((e3) => (0, u.jsx)("div", { className: s2, children: i2(e3) }, "".concat(a2.key, "_").concat(e3)))
        });
      });
      var T = a(97712), C = a.n(T);
      let h = (0, _.PA)((e2) => {
        let {
          count: t2,
          rowGap: a2,
          columnGap: i2,
          getEstimateRowSize: s2,
          minColumnCount: l2 = 2,
          minColumnWidth: r2,
          maxColumnWidth: n2,
          maxColumnCount: d2,
          renderItemByIndex: c2,
          onChangeRange: _2
        } = e2, [p2, b2] = (0, g.d)(), {
          virtualizer: v2,
          rowResizeObserver: T2,
          columnCount: h2,
          indices: I
        } = m({
          count: t2,
          rowGap: a2,
          columnGap: i2,
          getEstimateRowSize: s2,
          minColumnCount: l2,
          minColumnWidth: r2,
          maxColumnWidth: n2,
          maxColumnCount: d2,
          containerRef: p2
        });
        (0, o.useEffect)(() => {
          !v2.isScrolling && v2.range && (null == _2 || _2(v2.range, h2));
        }, [_2, v2.isScrolling, v2.range, h2]);
        let L = { "--virtual-grid-height": "".concat(v2.getTotalSize(), "px"), "--virtual-grid-column-count": h2 };
        return (0, u.jsx)("div", {
          ref: b2,
          style: L,
          className: C().root,
          children: v2.getVirtualItems().map(
            (e3) => (0, u.jsx)(
              A,
              {
                className: C().row,
                columnClassName: C().column,
                virtualItem: e3,
                resizeObserver: T2,
                indices: I,
                renderItemByIndex: c2,
                scrollMargin: v2.options.scrollMargin
              },
              e3.key
            )
          )
        });
      });
    },
    77561: (e) => {
      e.exports = {
        root: "PlaylistWithTracksEmpty_root__secDB",
        image: "PlaylistWithTracksEmpty_image__JH2uE",
        header: "PlaylistWithTracksEmpty_header__pD30X",
        text: "PlaylistWithTracksEmpty_text__b69Q_",
        myWaveButton: "PlaylistWithTracksEmpty_myWaveButton__Kswfl",
        myWaveButtonText: "PlaylistWithTracksEmpty_myWaveButtonText__AfIg9"
      };
    },
    78791: (e) => {
      e.exports = { root: "VirtualizedSkeletonBlock_root__njUFa" };
    },
    79367: (e) => {
      e.exports = {
        root: "MapBlock_root__lcL__",
        heading: "MapBlock_heading__20gje",
        linkContainer: "MapBlock_linkContainer__iO0dw",
        mapImage: "MapBlock_mapImage__Qch0h",
        addressContainer: "MapBlock_addressContainer__gFnzq",
        address: "MapBlock_address__UofT6",
        metroStations: "MapBlock_metroStations__T3Zpc"
      };
    },
    80937: (e) => {
      e.exports = {
        filters: "PlaylistWithTracksAndFilters_filters__koC2A",
        shimmer: "PlaylistWithTracksAndFilters_shimmer__vrNPe"
      };
    },
    82227: (e) => {
      e.exports = {
        shimmerWithSubcover: "MixesGridBlock_shimmerWithSubcover__3EtzK",
        header: "MixesGridBlock_header__wz5KI",
        mixesGrid: "MixesGridBlock_mixesGrid__LSeyw",
        item: "MixesGridBlock_item__TVzNE",
        important: "MixesGridBlock_important__DQE7T"
      };
    },
    83407: (e) => {
      e.exports = {
        root: "ArtistPopularTracksAndReleases_root__rN5Wk",
        container: "ArtistPopularTracksAndReleases_container__EQIVk",
        popularTracks: "ArtistPopularTracksAndReleases_popularTracks__HEZ73",
        popularTracks_withReleaseBlock: "ArtistPopularTracksAndReleases_popularTracks_withReleaseBlock__WwiJr",
        release: "ArtistPopularTracksAndReleases_release__9NDdR",
        releaseCard: "ArtistPopularTracksAndReleases_releaseCard__uHtao"
      };
    },
    84359: (e, t, a) => {
      "use strict";
      a.d(t, { MixesGridBlock: () => g });
      var i = a(54486), s = a(50420), l = a(61910), r = a(43350), o = a(15209), n = a(3095), d = a(74125), c = a(80585), m = a(82227), u = a.n(m);
      let _ = (e2) => {
        var t2;
        let {
          forwardRef: a2,
          headerClassName: m2,
          meta: _2,
          data: g2,
          headingVariant: p,
          isShimmerActive: b,
          containerClassName: v,
          isShimmerVisible: A,
          className: T,
          ...C
        } = e2, h = (0, l.useId)(), I = (0, l.useMemo)(() => {
          if (A) {
            var e3;
            return (0, i.jsx)(c.eI, {
              itemClassName: (0, s.$)(u().item, u().important, u().shimmerWithSubcover),
              isActive: b,
              centered: true,
              withInfo: true,
              withSubcover: true,
              count: null == (e3 = _2.source) ? void 0 : e3.count
            });
          }
          return null == g2 ? void 0 : g2.items.map(
            (e4, t3) => (0, i.jsx)(
              d.Bki,
              {
                objectType: r.ky.Shortcut,
                objectId: String(e4.id),
                objectPosX: t3 + 1,
                objectPosY: 1,
                objectsCount: g2.items.length,
                children: (0, i.jsx)(
                  n.Vf,
                  {
                    linkClassName: (0, s.$)(u().item, u().important),
                    title: e4.title,
                    weblink: e4.weblink,
                    covers: e4.covers,
                    captionVariant: "h3"
                  },
                  e4.id
                )
              },
              e4.id
            )
          );
        }, [b, A, null == g2 ? void 0 : g2.items, null == (t2 = _2.source) ? void 0 : t2.count]);
        return (0, i.jsxs)("section", {
          ref: a2,
          className: T,
          ...(0, o.getDataAttrFromProps)(C),
          children: [
            (0, i.jsx)(c.Tw, {
              className: (0, s.$)(u().header, m2),
              labeledForId: h,
              title: _2.title,
              viewAllActionLink: _2.viewAllActionLink,
              headingVariant: p
            }),
            (0, i.jsx)("div", { className: (0, s.$)(u().mixesGrid, v), children: I })
          ]
        });
      }, g = (0, l.forwardRef)((e2, t2) => (0, i.jsx)(_, { forwardRef: t2, ...e2 }));
    },
    84683: (e) => {
      e.exports = {
        root: "Wizard_root__aW2c2",
        title: "Wizard_title__L8ktt",
        description: "Wizard_description__RFf2U",
        button: "Wizard_button__lr8pa",
        buttonIcon: "Wizard_buttonIcon__eOX3P",
        imagesWrapper: "Wizard_imagesWrapper__tyqWr",
        images: "Wizard_images__5rxec",
        paper: "Wizard_paper__ijUgq",
        image: "Wizard_image__k9AXl"
      };
    },
    87043: (e) => {
      e.exports = {
        root: "Special_root__FOrBZ",
        actions: "Special_actions__XYuvB",
        textContainer: "Special_textContainer__pN_TF",
        textColor: "Special_textColor__dySbq",
        imageContainer: "Special_imageContainer__V1_E3",
        image: "Special_image__1sSXR",
        button: "Special_button__j8gGH"
      };
    },
    90372: (e) => {
      e.exports = { item: "VibesCarousel_item__AupL0", important: "VibesCarousel_important__JkzUC" };
    },
    90937: (e) => {
      e.exports = {
        root: "Neuromusic_root__wTkG_",
        controls: "Neuromusic_controls__8kH7t",
        item: "Neuromusic_item__Q_JI_",
        important: "Neuromusic_important__8Ib5E"
      };
    },
    91228: (e) => {
      e.exports = {
        content: "ContinueListenBaseItem_content__Rdrbh",
        root: "ContinueListenBaseItem_root__FH7Jk",
        root_bookshelf: "ContinueListenBaseItem_root_bookshelf__cKQqb",
        root_newEpisodes: "ContinueListenBaseItem_root_newEpisodes__OTZgU",
        root_withLastPlayed: "ContinueListenBaseItem_root_withLastPlayed__1Z2P5",
        title: "ContinueListenBaseItem_title__vvDta",
        root_withCovers: "ContinueListenBaseItem_root_withCovers__Y4w7V",
        link: "ContinueListenBaseItem_link__3xuh7",
        textContainer: "ContinueListenBaseItem_textContainer__1nvoM",
        titleIcon: "ContinueListenBaseItem_titleIcon__4lGcT",
        subtitle: "ContinueListenBaseItem_subtitle__jFLLT",
        covers: "ContinueListenBaseItem_covers__bCLfi",
        coverContainer: "ContinueListenBaseItem_coverContainer__qdnAa",
        cover: "ContinueListenBaseItem_cover__gSp5J"
      };
    },
    92437: (e, t, a) => {
      "use strict";
      var i;
      a.d(t, { z: () => i }), (function(e2) {
        e2.NONE = "none", e2.DEFAULT = "default", e2.CUSTOM = "custom";
      })(i || (i = {}));
    },
    94124: (e, t, a) => {
      "use strict";
      a.d(t, { t: () => u });
      var i = a(54486), s = a(61910), l = a(43350), r = a(60049), o = a(94376), n = a(83909), d = a(74125), c = a(80585);
      let m = (e2) => {
        let {
          forwardRef: t2,
          isShimmerVisible: a2,
          isShimmerActive: s2,
          containerClassName: m2,
          headerClassName: u2,
          meta: _,
          data: g,
          headingVariant: p,
          className: b,
          ...v
        } = e2;
        return (0, i.jsx)(c.OY, {
          className: b,
          ...v,
          isShimmerVisible: a2,
          isShimmerActive: s2,
          headerClassName: u2,
          containerClassName: m2,
          title: _.title,
          description: _.description,
          viewAllActionLink: _.viewAllActionLink,
          ref: t2,
          headingVariant: p,
          children: null == g ? void 0 : g.items.map(
            (e3, t3) => e3.type === r._.NON_MUSIC_ALBUM_ITEM ? (0, i.jsx)(
              d.Bki,
              {
                objectType: l.ky.Album,
                objectId: String(e3.data.id),
                objectPosX: t3 + 1,
                objectPosY: 1,
                objectsCount: g.items.length,
                children: (0, i.jsx)(o.aX, { album: e3.data, contentLinesCount: 3, withLikesCount: true })
              },
              e3.data.id
            ) : (0, i.jsx)(
              d.Bki,
              {
                objectType: l.ky.Playlist,
                objectId: String(e3.data.id),
                objectPosX: t3 + 1,
                objectPosY: 1,
                objectsCount: g.items.length,
                children: (0, i.jsx)(n.B6, { playlist: e3.data, contentLinesCount: 3 })
              },
              e3.data.id
            )
          )
        });
      }, u = (0, s.forwardRef)((e2, t2) => (0, i.jsx)(m, { forwardRef: t2, ...e2 }));
    },
    97433: (e) => {
      e.exports = { root: "CollectionClipsEmpty_root__LwgZS", text: "CollectionClipsEmpty_text__cZfLW" };
    },
    97712: (e) => {
      e.exports = {
        root: "VirtualGrid_root__nSEzJ",
        column: "VirtualGrid_column__P8hJp",
        row: "VirtualGrid_row__PL5V_"
      };
    }
  }
]);
