(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4561],
  {
    3119: (e, t, i) => {
      "use strict";
      i.d(t, { useOnLikeClick: () => u });
      var r = i(54486), a = i(63930), l = i(61910), n = i(43426), s = i(77534), o = i(74125), c = i(80585);
      let d = (e2) => {
        let { artist: t2, closeToast: i2 } = e2;
        return (0, r.jsx)(c.OM, {
          closeToast: i2,
          entityVariant: c.cp.ARTIST,
          entityUrl: t2.url,
          collectionUrl: o.Zyd.collectionArtists.href,
          coverUri: t2.coverUri,
          entityTitle: t2.name,
          isLiked: t2.isLiked
        });
      }, u = (e2) => {
        let { user: t2 } = (0, o.Pjs)(), { notify: i2 } = (0, o.lkh)(), [u2, _] = (0, l.useState)(false), { formatMessage: m } = (0, n.A)();
        return (0, l.useCallback)(async () => {
          if (!e2) return;
          if (!t2.isAuthorized)
            return void i2((0, r.jsx)(c.hT, { error: m({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: o.uQT.ERROR
            });
          if (u2) return;
          let l2 = { ...(0, a.HO)(e2), isLiked: !e2.isLiked };
          _(true);
          let n2 = await e2.toggleLike();
          _(false), n2 === s.f.OK ? i2((0, r.jsx)(d, { artist: l2 }), { containerId: o.uQT.INFO }) : i2((0, r.jsx)(c.hT, { error: m({ id: "error-messages.error-during-action" }) }), {
            containerId: o.uQT.ERROR
          });
        }, [e2, t2.isAuthorized, u2, m, i2]);
      };
    },
    3781: (e, t, i) => {
      "use strict";
      i.d(t, { NotificationAddToPlaylist: () => m });
      var r = i(54486), a = i(28303), l = i(61910), n = i(47713), s = i(8817), o = i(97800), c = i(74125), d = i(80585), u = i(39267), _ = i.n(u);
      let m = (0, a.PA)((e2) => {
        let { entityTitle: t2, entityVariant: i2, entityCoverUri: a2, playlist: u2, closeToast: m2 } = e2, { fullscreenPlayer: p } = (0, c.Pjs)(), v = (0, s.c)(() => {
          p.modal.isOpened && p.modal.close();
        }), f = (0, l.useMemo)(() => {
          let e3, a3 = {
            trackName: (0, r.jsxs)(o.Caption, {
              className: _().title,
              variant: "div",
              type: "controls",
              size: "m",
              lineClamp: 1,
              children: [" ", t2, " "]
            }),
            playlistName: (0, r.jsx)(d.N_, {
              className: _().link,
              href: u2.url,
              onClick: v,
              children: (0, r.jsxs)(o.Caption, {
                className: _().playlistTitle,
                variant: "div",
                type: "controls",
                size: "m",
                lineClamp: 1,
                children: [" ", u2.title, " "]
              })
            })
          };
          switch (i2) {
            case d.cp.PODCAST_EPISODE:
              e3 = (0, r.jsx)(n.A, { id: "notifications-info.added-podcast-episode-to-playlist", values: a3 });
              break;
            case d.cp.AUDIOBOOK_EPISODE:
              e3 = (0, r.jsx)(n.A, { id: "notifications-info.added-audiobook-episode-to-playlist", values: a3 });
              break;
            default:
              e3 = (0, r.jsx)(n.A, { id: "notifications-info.added-track-to-playlist", values: a3 });
          }
          return (0, r.jsx)(o.Caption, {
            className: _().message,
            variant: "div",
            type: "controls",
            size: "m",
            lineClamp: 1,
            children: e3
          });
        }, [t2, i2, v, u2.title, u2.url]);
        return (0, r.jsx)(d.$W, {
          closeToast: m2,
          message: f,
          cover: (0, r.jsx)(d.BW, {
            className: _().image,
            src: a2,
            withAvatarReplace: true,
            size: 100,
            fit: "cover",
            alt: t2
          }),
          coverRadius: "s"
        });
      });
    },
    8070: (e) => {
      e.exports = {
        root_clamp: "SeparatedArtists_root_clamp__SyvjM",
        root_variant_breakAll: "SeparatedArtists_root_variant_breakAll__34YbW",
        root_variant_breakWord: "SeparatedArtists_root_variant_breakWord__1sziE",
        ellipsis: "SeparatedArtists_ellipsis__0SUCv"
      };
    },
    13611: (e, t, i) => {
      "use strict";
      i.d(t, {
        $o: () => C,
        Y9: () => o,
        uY: () => j.ContextMenuPlaylistPrivacyItem,
        Bw: () => P.CreatePlaylistCard,
        Co: () => k,
        iz: () => c,
        kc: () => d,
        mZ: () => E.NotificationAddToPlaylist,
        pw: () => R.NotificationFailedAddToPlaylist,
        HB: () => O.NotificationFailedRemoveFromPlaylist,
        mM: () => S.NotificationRemoveFromPlaylist,
        yC: () => p,
        ji: () => v,
        Zq: () => T,
        xG: () => m.TrackPlaylistContext,
        Ji: () => a,
        jX: () => s,
        Mp: () => _,
        KX: () => f.useOnLikeClick,
        A7: () => y.useOnPinClick
      });
      var r = i(80769);
      let a = (e2) => {
        var t2;
        return e2 ? {
          playlistUuid: e2.uuid,
          available: e2.isAvailable,
          uid: e2.uid,
          kind: e2.kind,
          title: e2.title || "",
          revision: e2.revision || 0,
          snapshot: 0,
          trackCount: e2.tracksCount || 0,
          visibility: e2.visibility || "public",
          collective: false,
          created: "",
          modified: "",
          isBanner: false,
          isPremiere: false,
          durationMs: 0,
          cover: { uri: e2.coverUri || "", type: r.Q.PIC, prefix: "", custom: false },
          ogImage: e2.coverUri || "",
          tags: [],
          likesCount: e2.likesCount || 0,
          generatedPlaylistType: e2.generatedPlaylistType || "",
          trailer: { available: !!(null == (t2 = e2.trailer) ? void 0 : t2.isAvailable) }
        } : {
          playlistUuid: "",
          available: true,
          uid: 0,
          kind: 0,
          title: "",
          revision: 0,
          snapshot: 0,
          trackCount: 0,
          visibility: "public",
          collective: false,
          created: "",
          modified: "",
          isBanner: false,
          isPremiere: false,
          durationMs: 0,
          cover: { uri: "", type: r.Q.PIC, prefix: "", custom: false },
          ogImage: "",
          tags: [],
          likesCount: 0,
          generatedPlaylistType: "",
          trailer: { available: true }
        };
      };
      var l = i(93064), n = i(74125);
      let s = (e2) => {
        var t2, i2, r2, a2, s2;
        e2 = e2 || {};
        let o2 = (0, n.mxW)(e2.trailer);
        return (0, l.wg)({
          isAvailable: null == (a2 = e2.available) || a2,
          uid: e2.uid,
          uuid: null != (s2 = e2.playlistUuid) ? s2 : "",
          kind: e2.kind,
          title: e2.title,
          coverUri: (null == e2 || null == (t2 = e2.cover) ? void 0 : t2.uri) || (null == e2 || null == (r2 = e2.cover) || null == (i2 = r2.itemsUri) ? void 0 : i2[0]),
          likesCount: e2.likesCount,
          averageColor: (0, n.QBb)(null == e2 ? void 0 : e2.derivedColors),
          revision: e2.revision,
          generatedPlaylistType: e2.generatedPlaylistType,
          personalColor: e2.personalColor,
          visibility: e2.visibility,
          trailer: o2
        });
      };
      var o = (function(e2) {
        return e2.OK = "ok", e2.ERROR = "error", e2.RELOAD = "reload", e2;
      })({});
      let c = 1e3, d = 100;
      var u = i(15209);
      let _ = (e2) => {
        let { operation: t2, position: i2, startPosition: r2, endPosition: a2, tracks: l2 } = e2, n2 = ((e3) => Object.keys(e3).filter((t3) => void 0 !== e3[t3]).reduce((t3, i3) => (t3[i3] = e3[i3], t3), {}))({ op: t2, at: i2, from: r2, to: a2, tracks: l2 });
        return (0, u.stringifyJSONSafely)([n2]);
      };
      var m = i(93099), p = (function(e2) {
        return e2.INSERT = "insert", e2.DELETE = "delete", e2.MOVE = "move", e2;
      })({}), v = (function(e2) {
        return e2[e2.LIKE = 3] = "LIKE", e2[e2.CHART = 1076] = "CHART", e2;
      })({}), f = i(15640), y = i(82885), g = i(14287), x = i(31905), h = i(60049), A = i(77534), b = i(26433);
      let C = l.gK.compose(
        l.gK.model({
          uuid: l.gK.string,
          isAvailable: l.gK.boolean,
          revision: l.gK.maybe(l.gK.number),
          uid: l.gK.number,
          kind: l.gK.number,
          title: l.gK.maybe(l.gK.string),
          coverUri: l.gK.maybe(l.gK.string),
          tracksCount: l.gK.maybe(l.gK.number),
          averageColor: l.gK.maybe(l.gK.string),
          generatedPlaylistType: l.gK.maybe(l.gK.string),
          personalColor: l.gK.maybeNull(l.gK.number),
          visibility: l.gK.maybe(l.gK.string),
          trailer: l.gK.maybe(b.aQ)
        }),
        b.tP
      ).views((e2) => ({
        get key() {
          return "".concat(e2.uuid, "_").concat(e2.uid, "_").concat(e2.kind);
        },
        get url() {
          let { href: t2 } = (0, n.uvd)("/playlists/:playlistUuid", { params: { playlistUuid: e2.uuid } });
          return t2;
        },
        get isLikesCountHidden() {
          return e2.kind === v.LIKE || e2.kind === v.CHART || e2.generatedPlaylistType;
        },
        get isFavouritePlaylist() {
          return e2.kind === v.LIKE;
        },
        get isPublic() {
          return e2.visibility === x.L.PUBLIC;
        },
        get isLiked() {
          if (!(0, l._n)(e2)) return false;
          let { library: t2 } = (0, l.Zn)(e2);
          return t2.isPlaylistLiked("".concat(e2.uid, ":").concat(e2.kind));
        },
        get pinId() {
          return "".concat(h._.PLAYLIST_ITEM).concat(e2.uid, "_").concat(e2.kind);
        },
        get id() {
          return "".concat(e2.uid, ":").concat(e2.kind);
        },
        get isPinned() {
          if (!(0, l._n)(e2)) return false;
          let { pinsCollection: t2 } = (0, l.Zn)(e2);
          return t2.isPinned(this.pinId);
        },
        get isOwnPlaylist() {
          let { user: t2 } = (0, l.Zn)(e2);
          return !!(t2.isAuthorized && e2.uid && t2.account.data.uid && e2.uid === t2.account.data.uid);
        },
        get canUserChange() {
          if (!(0, l._n)(e2)) return false;
          return this.isOwnPlaylist && !this.isFavouritePlaylist;
        },
        get isOwnFavouritePlaylist() {
          if (!(0, l._n)(e2)) return false;
          return this.isFavouritePlaylist && this.isOwnPlaylist;
        }
      })).actions((e2) => ({
        toggleLike: (0, l.L3)(function* () {
          if (!(0, l._n)(e2)) return;
          let { library: t2, user: i2 } = (0, l.Zn)(e2);
          if (i2.isAuthorized) {
            let r2 = yield t2.togglePlaylistLike({
              userId: i2.account.data.uid,
              entityId: e2.id,
              ownerId: e2.uid,
              kindId: e2.kind
            });
            return (0, l._n)(e2) && r2 === A.f.OK && (e2.isLiked ? e2.likePending() : e2.unlikePending()), r2;
          }
        }),
        togglePin: (0, l.L3)(function* () {
          if (!(0, l._n)(e2)) return;
          let { pinsCollection: t2, user: i2 } = (0, l.Zn)(e2);
          if (i2.isAuthorized) return yield t2.togglePlaylistPin({ uid: e2.uid, kind: e2.kind }, e2.pinId);
        }),
        changePlaylist: (0, l.L3)(function* (t2) {
          if (!(0, l._n)(e2)) return o.ERROR;
          let { usersResource: i2, modelActionsLogger: r2 } = (0, l._$)(e2);
          try {
            var a2, n2;
            let r3 = yield i2.changePlaylistRelative({
              userId: e2.uid,
              diff: t2,
              revision: null != (a2 = e2.revision) ? a2 : 0,
              playlistKind: e2.kind
            });
            return e2.revision = r3.revision, e2.isAvailable = null == (n2 = r3.available) || n2, o.OK;
          } catch (e3) {
            if (r2.error(e3), e3 && "object" == typeof e3 && "statusCode" in e3 && e3.statusCode === g.X1.PRECONDITION_FAILED)
              return o.RELOAD;
            return o.ERROR;
          }
        }),
        changeTitle: (0, l.L3)(function* (t2) {
          if (!(0, l._n)(e2)) return n.FlZ.ERROR;
          if (e2.title === t2) return n.FlZ.OK;
          let { usersResource: i2, modelActionsLogger: r2 } = (0, l._$)(e2);
          if (e2.canUserChange) {
            if (t2.length < 1 || t2.length > d) return n.FlZ.ERROR;
            let a2 = e2.title;
            e2.title = t2;
            try {
              let r3 = yield i2.changePlaylistTitle({ title: t2, userId: e2.uid, playlistKind: e2.kind });
              if (!(null == r3 ? void 0 : r3.title)) return e2.title = a2, n.FlZ.ERROR;
              return e2.title = r3.title, n.FlZ.OK;
            } catch (t3) {
              e2.title = a2, r2.error(t3);
            }
          }
          return n.FlZ.ERROR;
        }),
        deletePlaylist: (0, l.L3)(function* () {
          if (!(0, l._n)(e2) || !e2.canUserChange) return n.FlZ.ERROR;
          let { pinsCollection: t2 } = (0, l.Zn)(e2), { usersResource: i2, modelActionsLogger: r2 } = (0, l._$)(e2);
          try {
            return yield i2.deletePlaylist({ userId: e2.uid, playlistKind: e2.kind }), t2.isPinned(e2.pinId) && t2.deletePin(e2.pinId), n.FlZ.OK;
          } catch (e3) {
            r2.error(e3);
          }
          return n.FlZ.ERROR;
        }),
        toggleVisibility: (0, l.L3)(function* (t2) {
          if (!(0, l._n)(e2) || !e2.canUserChange && !e2.isOwnFavouritePlaylist) return n.FlZ.ERROR;
          let { usersResource: i2, modelActionsLogger: r2 } = (0, l._$)(e2), { user: a2 } = (0, l.Zn)(e2), s2 = e2.visibility, o2 = e2.isPublic ? x.L.PRIVATE : x.L.PUBLIC;
          t2 && (o2 = t2);
          try {
            return e2.visibility = o2, e2.isOwnFavouritePlaylist ? yield a2.setSettings({ userMusicVisibility: o2 }) : yield i2.togglePlaylistVisibility({ visibility: o2, userId: e2.uid, playlistKind: e2.kind }), n.FlZ.OK;
          } catch (e3) {
            r2.error(e3);
          }
          return e2.visibility = s2, n.FlZ.ERROR;
        }),
        getKey: (t2) => "".concat(t2, "_").concat(e2.id)
      })), k = l.gK.model("CreatePlaylist", { meta: l.gK.maybeNull(C) }).actions((e2) => ({
        create: (0, l.L3)(function* (t2) {
          if (!(0, l._n)(e2)) return null;
          let { usersResource: i2, modelActionsLogger: r2 } = (0, l._$)(e2), { user: a2 } = (0, l.Zn)(e2);
          if (!a2.isAuthorized) return null;
          let n2 = a2.account.data.uid;
          try {
            let r3 = yield i2.createPlaylist({ userId: String(n2), ...t2 });
            return e2.meta = s(r3), e2.meta.uuid;
          } catch (e3) {
            return r2.error(e3), null;
          }
        }),
        reset() {
          e2.meta = null;
        }
      })), T = C.props({ tracks: l.gK.maybe(l.gK.array(b.eD)) }).actions((e2) => ({
        getKey: (t2) => "".concat(t2, "_").concat(e2.id)
      }));
      var j = i(99733), P = i(18355), R = i(42691), O = i(37235), E = i(3781), S = i(33829);
    },
    14476: (e, t, i) => {
      "use strict";
      i.d(t, { ArtistSocialLinks: () => d });
      var r = i(54486), a = i(43426), l = i(31500), n = i(58360), s = i(80585), o = i(95806), c = i.n(o);
      let d = (e2) => {
        let { links: t2, artistName: i2 } = e2, { formatMessage: o2 } = (0, a.A)();
        return (0, r.jsx)("div", {
          className: c().root,
          ...(0, l.Am)(l.e8.content.ARTIST_ABOUT_SOCIAL_LINKS),
          children: t2.map((e3, t3) => {
            var a2;
            return (0, r.jsx)(
              s.N_,
              {
                href: e3.url,
                className: c().link,
                target: "_blank",
                "aria-label": o2({ id: "artist.artist-links-label" }, { artistName: i2, linkName: e3.title }),
                children: (0, r.jsx)(n.Image, {
                  fit: "contain",
                  className: c().icon,
                  size: 100,
                  src: null != (a2 = e3.imgUrl) ? a2 : void 0,
                  fallbackIconVariant: "site",
                  fallbackIconSize: "xs",
                  withAvatarReplace: true
                })
              },
              t3
            );
          })
        });
      };
    },
    15640: (e, t, i) => {
      "use strict";
      i.d(t, { useOnLikeClick: () => u });
      var r = i(54486), a = i(63930), l = i(61910), n = i(43426), s = i(77534), o = i(74125), c = i(80585);
      let d = (e2) => {
        let { playlist: t2, closeToast: i2 } = e2;
        return (0, r.jsx)(c.OM, {
          entityVariant: c.cp.PLAYLIST,
          entityUrl: t2.url,
          collectionUrl: "/collection",
          entityTitle: t2.title,
          isLiked: t2.isLiked,
          closeToast: i2,
          coverUri: t2.coverUri
        });
      }, u = (e2) => {
        let { user: t2 } = (0, o.Pjs)(), { notify: i2 } = (0, o.lkh)(), [u2, _] = (0, l.useState)(false), { formatMessage: m } = (0, n.A)();
        return (0, l.useCallback)(async () => {
          if (!t2.isAuthorized)
            return void i2((0, r.jsx)(c.hT, { error: m({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: o.uQT.ERROR
            });
          if (u2) return;
          let l2 = { ...(0, a.HO)(e2), url: e2.url, isLiked: !e2.isLiked };
          _(true);
          let n2 = await e2.toggleLike();
          _(false), n2 === s.f.OK ? i2((0, r.jsx)(d, { playlist: l2 }), { containerId: o.uQT.INFO }) : i2((0, r.jsx)(c.hT, { error: m({ id: "error-messages.error-during-action" }) }), {
            containerId: o.uQT.ERROR
          });
        }, [t2.isAuthorized, u2, e2, m, i2]);
      };
    },
    16855: (e, t, i) => {
      "use strict";
      i.d(t, { SeparatedArtists: () => w });
      var r = i(54486), a = i(50420), l = i(28303), n = i(61910), s = i(93666), o = i(74125), c = i(8070), d = i.n(c), u = i(43426), _ = i(43350), m = i(31500), p = i(8817), v = i(97800), f = i(80585);
      let y = (0, l.PA)((e2) => {
        let {
          artist: t2,
          withLink: i2 = true,
          linkClassName: a2,
          captionClassName: l2,
          captionSize: n2 = "m",
          allArtistsTitle: c2,
          withCustomTooltip: d2,
          hoverSettings: y2
        } = e2, { formatMessage: g2 } = (0, u.A)(), {
          track: x2,
          settings: { isMobile: h2 }
        } = (0, o.Pjs)(), A2 = (0, o.ZpR)(t2.url), { sendNavigateSearchFeedback: b2 } = (0, o.zEv)(), C2 = (0, o.NKK)(), k2 = ((e3) => {
          let { artist: t3, callback: i3 } = e3, { currentTrackInfo: r2, fullscreenPlayer: a3, fullscreenVideoPlayer: l3 } = (0, o.Pjs)(), { modal: n3 } = r2;
          return (0, o.lVe)({
            entity: t3,
            callback: i3,
            onBeforeHandle: (e4) => {
              null == e4 || e4.stopPropagation(), n3.isOpened && (r2.reset(), n3.close()), a3.modal.isOpened && a3.modal.close();
            },
            onAfterHandled: () => {
              l3.modal.isOpened && (l3.modal.close(), l3.reset());
            },
            preventDefaultWhenSafe: true
          });
        })({
          artist: t2,
          callback: (0, p.c)((e3) => {
            h2 && x2.isOpened && x2.close(), A2(e3);
          })
        }), T2 = (0, p.c)((e3) => {
          C2({ to: _.QT.ArtistScreen }), null == b2 || b2(), k2(e3);
        });
        return i2 && !t2.various ? (0, r.jsx)(f.N_, {
          "aria-label": g2({ id: "entity-names.artist-name" }, { artistName: t2.name }),
          className: a2,
          href: t2.url,
          onClick: T2,
          title: d2 ? void 0 : c2 || t2.name,
          ...(0, m.Am)(m.OA.artists.SEPARATED_ARTIST_TITLE),
          children: (0, r.jsx)(s.m_, {
            enabled: !c2 && d2,
            offsetOptions: 4,
            placement: "top",
            text: c2 || t2.name,
            hoverSettings: y2,
            children: (0, r.jsx)(v.Caption, {
              variant: "span",
              type: "entity",
              size: n2,
              weight: "medium",
              className: l2,
              children: t2.name
            })
          })
        }) : (0, r.jsx)(s.m_, {
          enabled: !c2 && d2,
          offsetOptions: 4,
          placement: "top",
          text: c2 || t2.name,
          hoverSettings: y2,
          children: (0, r.jsx)(v.Caption, {
            variant: "span",
            type: "entity",
            size: n2,
            weight: "medium",
            className: l2,
            title: d2 ? void 0 : c2 || t2.name,
            ...(0, m.Am)(m.OA.artists.SEPARATED_ARTIST_TITLE),
            children: t2.name
          })
        });
      }), g = (e2) => {
        let {
          artist: t2,
          withLink: i2 = true,
          linkClassName: a2,
          captionClassName: l2,
          captionSize: s2,
          allArtistsTitle: o2,
          withCustomTooltip: c2,
          hoverSettings: d2,
          shouldUseSeparator: u2 = true
        } = e2, _2 = (0, n.useMemo)(() => {
          var e3;
          return null == (e3 = t2.decomposed) ? void 0 : e3.reduce(
            (e4, t3) => e4.concat([
              u2 ? t3.separator : "",
              (0, r.jsx)(
                y,
                {
                  artist: t3,
                  withLink: i2,
                  linkClassName: a2,
                  captionClassName: l2,
                  captionSize: s2,
                  allArtistsTitle: o2,
                  withCustomTooltip: c2,
                  hoverSettings: d2
                },
                t3.id
              )
            ]),
            []
          );
        }, [t2.decomposed, u2, i2, a2, l2, s2, o2, c2, d2]);
        return (0, r.jsxs)(r.Fragment, {
          children: [
            (0, r.jsx)(y, {
              artist: t2,
              withLink: i2,
              linkClassName: a2,
              captionClassName: l2,
              captionSize: s2,
              allArtistsTitle: o2,
              withCustomTooltip: c2,
              hoverSettings: d2
            }),
            _2
          ]
        });
      };
      var x = i(47713), h = i(65749);
      let A = (e2) => {
        let { spoilerArtistsCount: t2, spoilerClassName: i2, handleOnSpoilerClick: l2 } = e2;
        return (0, r.jsxs)(r.Fragment, {
          children: [
            " ",
            (0, r.jsx)(h.N, {
              role: "button",
              href: "",
              className: (0, a.$)(d().spoiler, i2),
              onClick: l2,
              rel: "nofollow",
              ...(0, m.Am)(m.OA.artists.SEPARATED_ARTISTS_SPOILER),
              children: (0, r.jsx)(x.A, { id: "entity-names.number-of-more-artists", values: { counter: t2 } })
            })
          ]
        });
      };
      var b = i(1365), C = i(27510), k = i(88834), T = i(83154), j = i(89864), P = i.n(j);
      let R = (0, l.PA)((e2) => {
        let { label: t2, artists: i2, forwardRef: a2 } = e2;
        return (0, r.jsxs)(s.m_, {
          enableAriaDescribedby: false,
          isFocusEnabled: false,
          placement: "top",
          hoverSettings: { delay: 200, handleClose: (0, k.safePolygon)({ blockPointerEvents: true }) },
          children: [
            (0, r.jsx)("div", { ref: a2, children: t2 }),
            (0, r.jsx)(s.ZI, {
              className: P().tooltipContent,
              children: i2.map((e3) => (0, r.jsx)(T.ArtistItem, { artist: e3 }, e3.id))
            })
          ]
        });
      }), O = (0, n.forwardRef)((e2, t2) => (0, r.jsx)(R, { forwardRef: t2, ...e2 }));
      var E = i(61958), S = i(57152), I = i.n(S);
      let N = (0, l.PA)((e2) => {
        let { label: t2, artists: i2 } = e2, { formatMessage: l2 } = (0, u.A)();
        return (0, r.jsx)(E.W1, {
          isMobile: true,
          className: (0, a.$)(I().root, I().important),
          label: t2,
          ariaLabel: l2({ id: "interface-actions.context-menu-artists" }),
          children: i2.map((e3) => (0, r.jsx)(T.ArtistItem, { artist: e3 }, e3.id))
        });
      }), L = (0, l.PA)((e2) => {
        let { artists: t2 = [], label: i2, labelRef: a2 } = e2, [l2, s2] = (0, n.useState)(false), {
          settings: { isMobile: c2 }
        } = (0, o.Pjs)(), d2 = (0, p.c)(() => {
          let e3 = a2.current;
          e3 && s2(e3.scrollHeight > e3.clientHeight || e3.scrollWidth > e3.clientWidth);
        }), u2 = (0, C.L)(
          () => (0, b.A)(() => {
            d2();
          }, 100)
        );
        if ((0, n.useEffect)(
          () => (window.addEventListener("resize", u2), d2(), () => {
            window.removeEventListener("resize", u2);
          }),
          [u2, d2]
        ), (0, n.useEffect)(() => {
          d2();
        }, [t2, d2]), 0 !== t2.length)
          return (l2 || c2) && (!c2 || 1 !== t2.length) ? c2 ? (0, r.jsx)(N, { artists: t2, label: i2 }) : (0, r.jsx)(O, { artists: t2, label: i2 }) : i2;
      }), w = (0, l.PA)((e2) => {
        let {
          className: t2,
          artists: i2 = [],
          separator: l2 = ", ",
          lineClamp: c2,
          visibleArtistsCount: u2,
          withLink: _2 = true,
          spoilerClassName: m2,
          linkClassName: p2,
          captionClassName: v2,
          captionSize: f2,
          variant: y2 = "breakAll",
          withAllArtistsTitle: x2 = true,
          withComposer: h2 = true,
          spoilerComponent: b2,
          withCustomTooltip: C2 = true,
          artistIdWithoutLink: k2,
          withContextMenu: T2
        } = e2, j2 = (0, n.useRef)(null), [P2, R2] = (0, n.useState)(false), O2 = x2 ? i2.reduce(function() {
          let e3 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t3 = arguments.length > 1 ? arguments[1] : void 0;
          if (t3.decomposed) {
            let i3 = t3.decomposed.reduce((e4, t4) => e4.concat([t4.name]), []);
            return e3.length ? e3.concat([t3.name, ...i3]) : [t3.name, ...i3];
          }
          return e3.length ? (e3.push(t3.name), e3) : [t3.name];
        }, []).join(l2) : "", {
          settings: { isMobile: E2 }
        } = (0, o.Pjs)(), S2 = 1 === i2.length, I2 = (0, n.useCallback)((e3) => {
          R2(true), e3.preventDefault();
        }, []), N2 = (0, n.useMemo)(() => {
          let e3 = i2;
          return u2 && !P2 && (e3 = i2.slice(0, u2)), e3.reduce((e4, t3) => {
            if (!h2 && t3.isComposer) return e4.length ? e4 : [];
            let i3 = (0, r.jsx)(
              g,
              {
                artist: t3,
                linkClassName: p2,
                captionClassName: v2,
                withLink: _2 && t3.id !== k2 && ((!E2 || S2) && T2 || !T2),
                captionSize: f2,
                allArtistsTitle: O2,
                withCustomTooltip: C2,
                hoverSettings: o.VP$,
                shouldUseSeparator: !!l2
              },
              t3.key
            );
            return e4.length ? e4.concat([l2, i3]) : [i3];
          }, []);
        }, [i2, u2, P2, h2, E2, S2, T2, p2, v2, _2, k2, f2, O2, C2, l2]), w2 = (0, n.useMemo)(() => {
          if (!P2 && u2 && u2 < i2.length) {
            let e3 = i2.length - u2;
            return (0, n.isValidElement)(b2) ? b2 : (0, r.jsx)(A, { spoilerClassName: m2, spoilerArtistsCount: e3, handleOnSpoilerClick: I2 });
          }
        }, [i2.length, I2, P2, m2, b2, u2]), M = (0, n.useMemo)(() => {
          if (c2) return { WebkitLineClamp: c2 };
        }, [c2]), K = (0, r.jsx)(s.m_, {
          referenceRef: j2,
          enabled: !!(x2 && O2) && C2 && !T2 && !E2,
          offsetOptions: 4,
          placement: "top",
          text: O2,
          hoverSettings: o.VP$,
          children: (0, r.jsxs)("div", {
            style: M,
            className: (0, a.$)(
              d().root,
              d()["root_variant_".concat(y2)],
              { [d().root_clamp]: c2 && c2 > 0 },
              { [d().ellipsis]: !c2 },
              t2
            ),
            title: x2 && O2 && !C2 && !T2 ? O2 : void 0,
            children: [N2, w2]
          })
        });
        return T2 ? (0, r.jsx)(L, { labelRef: j2, artists: i2, label: K }) : K;
      });
    },
    18355: (e, t, i) => {
      "use strict";
      i.d(t, { CreatePlaylistCard: () => x });
      var r = i(54486), a = i(50420), l = i(28303), n = i(97396), s = i(61910), o = i(43426), c = i(47713), d = i(31500), u = i(31905), _ = i(77881), m = i(5956), p = i(97800), v = i(74125), f = i(80585), y = i(85413), g = i.n(y);
      let x = (0, l.PA)((e2) => {
        let { className: t2 } = e2, { formatMessage: i2 } = (0, o.A)(), { createPlaylist: l2 } = (0, v.Pjs)(), { notify: y2 } = (0, v.lkh)(), x2 = (0, n.useRouter)(), h = (0, s.useRef)(false), A = (0, s.useCallback)(async () => {
          if (h.current) return;
          h.current = true;
          let e3 = await l2.create({ title: i2({ id: "entity-names.new-playlist" }), visibility: u.L.PUBLIC });
          if (e3) {
            let { href: t3 } = (0, v.uvd)("/playlists/:playlistUuid", { params: { playlistUuid: e3 } });
            x2.push(t3);
          } else
            y2((0, r.jsx)(f.hT, { error: i2({ id: "playlist-errors.failed-to-create-playlist" }) }), {
              containerId: v.uQT.ERROR
            }), h.current = false;
        }, [l2, i2, x2, y2]);
        return (0, s.useEffect)(
          () => () => {
            l2.reset();
          },
          [l2]
        ), (0, r.jsxs)("div", {
          className: (0, a.$)(g().root, t2),
          ...(0, d.Am)(d.OA.playlist.CREATE_PLAYLIST_CARD),
          children: [
            (0, r.jsx)(_.$, {
              className: g().button,
              icon: (0, r.jsx)(m.Icon, { className: g().icon, variant: "add", size: "l" }),
              radius: "s",
              "aria-label": i2({ id: "playlist-actions.create-playlist" }),
              onClick: A,
              flexIcon: true,
              isBlock: true,
              ...(0, d.Am)(d.OA.playlist.CREATE_PLAYLIST_BUTTON)
            }),
            (0, r.jsx)(p.Caption, {
              weight: "medium",
              size: "s",
              variant: "div",
              className: g().text,
              ...(0, d.Am)(d.OA.playlist.CREATE_PLAYLIST_TITLE),
              children: (0, r.jsx)(c.A, { id: "collection.new-playlist" })
            })
          ]
        });
      });
    },
    25577: (e, t, i) => {
      "use strict";
      i.d(t, { useGetArtistTypeName: () => l });
      var r = i(43426), a = i(46163);
      let l = (e2) => {
        let { formatMessage: t2 } = (0, r.A)();
        return t2(e2 === a.o.COMPOSER ? { id: "entity-names.composer" } : { id: "entity-names.singer" });
      };
    },
    28233: (e) => {
      e.exports = { message: "FailedPlaylistNotification_message__wxrzi" };
    },
    31905: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { L: () => r }), (function(e2) {
        e2.PUBLIC = "public", e2.PRIVATE = "private";
      })(r || (r = {}));
    },
    33829: (e, t, i) => {
      "use strict";
      i.d(t, { NotificationRemoveFromPlaylist: () => m });
      var r = i(54486), a = i(28303), l = i(61910), n = i(47713), s = i(8817), o = i(97800), c = i(74125), d = i(80585), u = i(39267), _ = i.n(u);
      let m = (0, a.PA)((e2) => {
        let { entityTitle: t2, entityVariant: i2, entityCoverUri: a2, playlist: u2, closeToast: m2 } = e2, { fullscreenPlayer: p } = (0, c.Pjs)(), v = (0, s.c)(() => {
          p.modal.isOpened && p.modal.close();
        }), f = (0, l.useMemo)(() => {
          let e3, a3 = {
            trackName: (0, r.jsxs)(o.Caption, {
              className: _().title,
              variant: "div",
              type: "controls",
              size: "m",
              lineClamp: 1,
              children: [" ", t2, " "]
            }),
            playlistName: (0, r.jsx)(d.N_, {
              className: _().link,
              href: u2.url,
              onClick: v,
              children: (0, r.jsxs)(o.Caption, {
                className: _().playlistTitle,
                variant: "div",
                type: "controls",
                size: "m",
                lineClamp: 1,
                children: [" ", u2.title, " "]
              })
            })
          };
          switch (i2) {
            case d.cp.PODCAST_EPISODE:
              e3 = (0, r.jsx)(n.A, { id: "notifications-info.removed-podcast-episode-from-playlist", values: a3 });
              break;
            case d.cp.AUDIOBOOK_EPISODE:
              e3 = (0, r.jsx)(n.A, { id: "notifications-info.removed-audiobook-episode-from-playlist", values: a3 });
              break;
            default:
              e3 = (0, r.jsx)(n.A, { id: "notifications-info.removed-track-from-playlist", values: a3 });
          }
          return (0, r.jsx)(o.Caption, {
            className: _().message,
            variant: "div",
            type: "controls",
            size: "m",
            lineClamp: 1,
            children: e3
          });
        }, [t2, i2, v, u2.title, u2.url]);
        return (0, r.jsx)(d.$W, {
          closeToast: m2,
          message: f,
          cover: (0, r.jsx)(d.BW, {
            className: _().image,
            src: a2,
            withAvatarReplace: true,
            size: 100,
            fit: "cover",
            alt: t2
          }),
          coverRadius: "s"
        });
      });
    },
    34132: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { g: () => r }), (function(e2) {
        e2.LIKE = "like", e2.DISLIKE = "dislike";
      })(r || (r = {}));
    },
    37235: (e, t, i) => {
      "use strict";
      i.d(t, { NotificationFailedRemoveFromPlaylist: () => c });
      var r = i(54486), a = i(47713), l = i(97800), n = i(80585), s = i(28233), o = i.n(s);
      let c = () => (0, r.jsx)(n.$W, {
        message: (0, r.jsx)(l.Caption, {
          className: o().message,
          variant: "div",
          type: "controls",
          size: "m",
          children: (0, r.jsx)(a.A, { id: "playlist-errors.failed-to-remove-track" })
        })
      });
    },
    39267: (e) => {
      e.exports = {
        message: "PlaylistNotification_message__nEykK",
        text: "PlaylistNotification_text__kTfi1",
        title: "PlaylistNotification_title__Q5IKF",
        link: "PlaylistNotification_link__HezVx",
        playlistTitle: "PlaylistNotification_playlistTitle__HweEg",
        image: "PlaylistNotification_image__QvYVD"
      };
    },
    39604: (e) => {
      e.exports = { message: "EditorsFeaturesFailedNotification_message__EIgMe" };
    },
    42522: (e) => {
      e.exports = {
        root: "ArtistBandlinkScanner_root__D3cAC",
        descriptionTitleButton: "ArtistBandlinkScanner_descriptionTitleButton__0M8Ag",
        icon: "ArtistBandlinkScanner_icon__n5ntO",
        description: "ArtistBandlinkScanner_description__n8ypX",
        descriptionTitle: "ArtistBandlinkScanner_descriptionTitle__9Z1MT",
        descriptionTitleText: "ArtistBandlinkScanner_descriptionTitleText__xWvIS",
        descriptionArtist: "ArtistBandlinkScanner_descriptionArtist__7ZvJo"
      };
    },
    42691: (e, t, i) => {
      "use strict";
      i.d(t, { NotificationFailedAddToPlaylist: () => c });
      var r = i(54486), a = i(47713), l = i(97800), n = i(80585), s = i(28233), o = i.n(s);
      let c = () => (0, r.jsx)(n.$W, {
        message: (0, r.jsx)(l.Caption, {
          className: o().message,
          variant: "div",
          type: "controls",
          size: "m",
          children: (0, r.jsx)(a.A, { id: "playlist-errors.failed-add-track-to-playlist" })
        })
      });
    },
    46163: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { o: () => r }), (function(e2) {
        e2.ARTIST = "artist", e2.COMPOSER = "composer";
      })(r || (r = {}));
    },
    51887: (e, t, i) => {
      "use strict";
      i.d(t, { useArtistDisclaimer: () => a });
      var r = i(74125);
      let a = (e2) => {
        let { artist: t2, callback: i2, shouldHistoryBack: a2 } = e2;
        return (0, r.lVe)({
          entity: t2,
          callback: i2,
          modalBehavior: void 0 === a2 ? void 0 : { shouldHistoryBack: a2 },
          preventDefaultWhenSafe: true
        });
      };
    },
    57152: (e) => {
      e.exports = {
        root: "SeparatedArtistsWithContextMenuMobile_root__4BiJL",
        important: "SeparatedArtistsWithContextMenuMobile_important__fSF1h"
      };
    },
    58623: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { T: () => r }), (function(e2) {
        e2.OK = "ok", e2.ERROR = "error";
      })(r || (r = {}));
    },
    58627: (e) => {
      e.exports = {
        root: "ContextMenuPlaylistPrivacyItem_root__kz3gc",
        caption: "ContextMenuPlaylistPrivacyItem_caption__0VuXh"
      };
    },
    60049: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { _: () => r }), (function(e2) {
        e2.ALBUM_ITEM = "album_item", e2.ARTIST_ITEM = "artist_item", e2.PLAYLIST_ITEM = "playlist_item", e2.TRACK_ITEM = "track_item", e2.LIKED_PLAYLIST_ITEM = "liked_playlist_item", e2.PERSONAL_PLAYLIST_ITEM = "personal_playlist_item", e2.WAVE_ITEM = "wave_item", e2.WAVE_AGENT_ITEM = "wave_agent_item", e2.MIX = "mix", e2.MIX_CARD_ITEM = "mix_card_item", e2.LIKED_ALBUM_ITEM = "liked_album_item", e2.PRESAVED_ALBUM_ITEM = "presaved_album_item", e2.CHART_ALBUM_ITEM = "chart_album_item", e2.NON_MUSIC_ALBUM_ITEM = "non_music_album_item", e2.MENU_ITEM = "menu_item", e2.DONATION_ITEM = "donation_item", e2.CLIP = "clip", e2.CLIP_ITEM = "clip_item", e2.CONCERT_ITEM = "concert_item";
      })(r || (r = {}));
    },
    61609: (e, t, i) => {
      "use strict";
      i.d(t, { l: () => c });
      var r, a = i(61910), l = {
        5881: (e2, t2, i2) => {
          function r2() {
            for (var e3, t3, i3 = 0, r3 = ""; i3 < arguments.length; )
              (e3 = arguments[i3++]) && (t3 = (function e4(t4) {
                var i4, r4, a3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) a3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (i4 = 0; i4 < t4.length; i4++) t4[i4] && (r4 = e4(t4[i4])) && (a3 && (a3 += " "), a3 += r4);
                  else for (i4 in t4) t4[i4] && (a3 && (a3 += " "), a3 += i4);
                return a3;
              })(e3)) && (r3 && (r3 += " "), r3 += t3);
            return r3;
          }
          i2.r(t2), i2.d(t2, { clsx: () => r2, default: () => a2 });
          let a2 = r2;
        },
        1920: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { default: () => r2 });
          let r2 = {
            contentContainer: "JjlbHZ4FaP9EAcR_1DxF",
            contentContainer_block: "iOlzvyUREgDkthkrx7Sf",
            flexIcon: "WsKeF73pWotx9W1tWdYY",
            root: "cpeagBA1_PblpJn8Xgtv",
            root_withoutBorder: "qU2apWBO1yyEK0lZ3lPO",
            root_radius_xs: "MmZbSs387gu2qrJ1lDWd",
            root_radius_s: "mlcrraysn7mW6xrBXSBF",
            root_radius_m: "dgV08FKVLZKFsucuiryn",
            root_radius_l: "S97_5dtzhpxo_amtfYRg",
            root_radius_xl: "nNBJnDHRlyLTniWosJhk",
            root_radius_xxxl: "zIMibMuH7wcqUoW7KH1B",
            root_radius_round: "uwk3hfWzB2VT7kE13SQk",
            root_size: "IlG7b1K0AD7E7AMx6F5p",
            root_size_default: "C_QGmfTz6UFX93vfPt6Z",
            root_size_xxxs: "eQt33MLDiQ6DRSuLaYEp",
            root_size_xxs: "oR11LfCBVqMbUJiAgknd",
            root_size_xs: "j1jXIVckFgZECecFzZMe",
            root_size_s: "WtFdWDF44egSVM_YiMUX",
            root_size_m: "Y2uqxoU7xa_AZ8FUCVOW",
            root_size_l: "SGYcNjvjmMsXeEVGUV2Z",
            root_icon_left: "kc5CjvU5hT9KEj0iTt3C",
            root_icon_right: "et24Jf7pT_X9Fvc7TznR",
            root_primary: "fXlFz1qMkliFUWOkHo8T",
            root_primary_default: "_eTRQi5ADZCUvUKMZqJU",
            ripple: "spMT3NcRD9Yb0ntNaNct",
            root_primary_outline: "fCUSh2B0Ye9kEvceE8zc",
            root_primary_text: "qlPp6CSQQEMVZPqtqLiQ",
            root_primary_withHover: "KZF6_4K1p_Y_GMIAxaAn",
            root_primary_withHover_default: "rWukOKAJh5Ga7JuIp62L",
            root_primary_withHover_outline: "fdwWCJKgUqml5wNqrRcN",
            root_primary_withHover_text: "IgYbZLnYjW0nMahgpkus",
            root_secondary: "_T4p_w41oaq6L4sztSdw",
            root_secondary_default: "iJVAJMgccD4vj4E4o068",
            root_secondary_outline: "pnM3iSP9keZOELI2oohr",
            root_secondary_text: "UDMYhpDjiAFT3xUx268O",
            root_secondary_withHover: "qUbrkhZIOVrvM0roV1QF",
            root_secondary_withHover_default: "nHWc2sto1C6Gm0Dpw_l0",
            root_secondary_withHover_outline: "i5WuBm5mfG0mflk_1jH_",
            root_secondary_withHover_text: "HbaqudSqu7Q3mv3zMPGr",
            root_plus: "ixLRsIJ2FvXO2k04n_QY",
            root_plus_default: "yRHwHzEGfDgRXGzYJqw2",
            root_plus_outline: "e777irPFmyQFFrURLF_U",
            root_plus_text: "vRqDhvmt3gt8TFp45_Zw",
            root_plus_withHover: "TZif6q3I2RwBEYXwK_iA",
            root_plus_withHover_default: "k3DhvmzpnM_Fb9oFdE4q",
            root_plus_withHover_outline: "RiDWYwGIxqbrUPR699DM",
            root_plus_withHover_text: "hC_mMCzWjkTn2j9xZzGc",
            root_accent: "jqD2jMT6n7F0WKyqwMsn",
            root_accent_default: "bDp0r9MtoYECZ8ObMoCh",
            root_accent_outline: "rXNyGp8NBAw2MUjACZNj",
            root_accent_text: "hmV4ERaXWAJc4uPLZL30",
            root_accent_withHover: "uKuxXu1N4TP5cWaEK5Ke",
            root_accent_withHover_default: "t_hequUaUgAMhFuxizLb",
            root_accent_withHover_outline: "Oy9sPFTxNTo1_E29U4aF",
            root_accent_withHover_text: "LcKRSd3DLoh7k60Oqox8",
            root_withActiveSpinner: "nAGvO87rLs15SJgft6Hh",
            block: "BbCxxIjBGupN28bq2lSP",
            icon: "J9wTKytjOWG73QMoN5WP",
            icon_position_left: "elJfazUBui03YWZgHCbW",
            icon_position_right: "RBoEbyJKP5rEtLsXM1ji",
            icon_withButtonSize: "cE17_kCWJgx8kzQEkeVr",
            spinnerContainer: "STbBDGqYjUEcLuNvhu9w"
          };
        },
        5682: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { default: () => r2 });
          let r2 = {
            root: "rqUESGQ8jp3tbDawOzuG",
            root_checked: "GJh5PwV9GyFuKhlG6pQz",
            icon: "aw9IoPC0GuAC7Hmf825u",
            icon_checked: "KC8t9NStVmQ1_VY54KH4"
          };
        },
        9097: (e2, t2) => {
          var i2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function r2(e3, t3, r3) {
            var a2 = null;
            if (void 0 !== r3 && (a2 = "" + r3), void 0 !== t3.key && (a2 = "" + t3.key), "key" in t3)
              for (var l2 in r3 = {}, t3) "key" !== l2 && (r3[l2] = t3[l2]);
            else r3 = t3;
            return { $$typeof: i2, type: e3, key: a2, ref: void 0 !== (t3 = r3.ref) ? t3 : null, props: r3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = r2, t2.jsxs = r2;
        },
        4377: (e2, t2, i2) => {
          e2.exports = i2(9097);
        },
        8796: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.createRipple = void 0, t2.createRipple = function(e3, t3, i2) {
            let r2 = null != i2 ? i2 : e3.currentTarget, a2 = document.createElement("span"), l2 = Math.max(r2.clientWidth, r2.clientHeight), n2 = l2 / 2, s2 = r2.getBoundingClientRect(), o2 = 0 === e3.clientX ? Math.round(s2.width / 2) : e3.clientX - s2.left, c2 = 0 === e3.clientY ? Math.round(s2.height / 2) : e3.clientY - s2.top;
            a2.style.width = "".concat(l2, "px"), a2.style.height = "".concat(l2, "px"), a2.style.left = 0 === e3.clientX ? "0px" : "".concat(o2 - n2, "px"), a2.style.top = "".concat(c2 - n2, "px"), a2.classList.add(t3);
            let d = r2.getElementsByClassName(t3)[0];
            d && d.remove(), r2.insertBefore(a2, r2.firstChild);
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        8216: (e2, t2, i2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = t2.createRipple = void 0;
          var r2 = i2(8796);
          Object.defineProperty(t2, "createRipple", {
            enumerable: true,
            get: function() {
              return r2.createRipple;
            }
          });
          var a2 = i2(361);
          Object.defineProperty(t2, "getElementFromRefOrElement", {
            enumerable: true,
            get: function() {
              return a2.getElementFromRefOrElement;
            }
          });
        },
        8119: function(e2, t2, i2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          let a2 = i2(4377), l2 = i2(810), n2 = i2(5881), s2 = i2(8216), o2 = r2(i2(1920)), c2 = (e3) => {
            let {
              forwardRef: t3,
              isBlock: i3,
              iconPosition: r3 = "left",
              children: c3,
              className: d,
              color: u = "secondary",
              flexIcon: _,
              icon: m,
              spinner: p,
              role: v,
              onClick: f,
              radius: y = "m",
              size: g,
              type: x = "button",
              variant: h = "default",
              withRipple: A = true,
              withHover: b = true,
              withBorder: C = false,
              disabled: k,
              iconClassName: T,
              contentContainerClassName: j,
              ...P
            } = e3, R = (0, l2.useId)(), O = !l2.Children.toArray(c3).filter(Boolean).length, E = "left" === r3, S = null, I = (0, l2.isValidElement)(p);
            if (m) {
              var N, L;
              S = (0, l2.cloneElement)(m, {
                className: (0, n2.clsx)(
                  o2.default.icon,
                  {
                    [o2.default["icon_position_".concat(r3)]]: r3 && !O,
                    [o2.default.icon_withButtonSize]: !(null == (N = m.props) ? void 0 : N.size)
                  },
                  null == (L = m.props) ? void 0 : L.className,
                  T
                ),
                key: R
              });
            }
            let w = (0, l2.useMemo)(
              () => I ? (0, a2.jsx)("div", { className: o2.default.spinnerContainer, children: p }) : null,
              [I, p]
            ), M = (0, l2.useCallback)(
              (e4) => {
                I || (A && (0, s2.createRipple)(e4, o2.default.ripple), null == f || f(e4));
              },
              [I, f, A]
            );
            return (0, a2.jsx)("button", {
              ref: t3,
              className: (0, n2.clsx)(
                o2.default.root,
                o2.default["root_".concat(u, "_").concat(h)],
                o2.default["root_radius_".concat(y)],
                o2.default.root_size,
                {
                  [o2.default["root_".concat(u, "_withHover_").concat(h)]]: b && !k && !I,
                  [o2.default["root_size_".concat(g)]]: g,
                  [o2.default.root_withoutBorder]: !C,
                  [o2.default.root_withActiveSpinner]: I,
                  [o2.default.block]: i3,
                  [o2.default.flexIcon]: _,
                  [o2.default.iconOnly]: O,
                  [o2.default.root_icon_left]: m && !O && E,
                  [o2.default.root_icon_right]: m && !O && !E
                },
                d
              ),
              type: x,
              role: v,
              onClick: M,
              ...P,
              disabled: k,
              "aria-live": I ? "polite" : "off",
              "aria-busy": I,
              children: m || I ? (0, a2.jsxs)("span", {
                className: (0, n2.clsx)(
                  o2.default.contentContainer,
                  { [o2.default.contentContainer_block]: i3 },
                  j
                ),
                children: [m && E && S, !O && c3, m && !E && S, w]
              }) : c3
            });
          };
          t2.Button = (0, l2.forwardRef)((e3, t3) => (0, a2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        5928: (e2, t2, i2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          var r2 = i2(8119);
          Object.defineProperty(t2, "Button", {
            enumerable: true,
            get: function() {
              return r2.Button;
            }
          });
        },
        7459: function(e2, t2, i2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Toggle = void 0;
          let a2 = i2(4377), l2 = i2(5881), n2 = i2(810), s2 = i2(5928), o2 = r2(i2(5682)), c2 = (e3) => {
            let { isChecked: t3 } = e3;
            return (0, a2.jsx)("div", { className: (0, l2.clsx)(o2.default.icon, { [o2.default.icon_checked]: t3 }) });
          };
          t2.Toggle = (e3) => {
            let { className: t3, isChecked: i3 = false, onChange: r3, "aria-label": d, "aria-describedby": u, ..._ } = e3, [m, p] = (0, n2.useState)(i3), v = (0, n2.useCallback)(() => {
              let e4 = !m;
              p(e4), null == r3 || r3(e4);
            }, [m, r3]);
            return (0, n2.useEffect)(() => {
              p(i3);
            }, [i3]), (0, a2.jsx)(s2.Button, {
              className: (0, l2.clsx)(o2.default.root, { [o2.default.root_checked]: m }, t3),
              radius: "xxxl",
              variant: "default",
              icon: (0, a2.jsx)(c2, { isChecked: m }),
              withRipple: false,
              onClick: v,
              role: "switch",
              "aria-checked": m,
              "aria-label": d,
              "aria-describedby": u,
              ..._,
              color: m ? "primary" : "secondary"
            });
          };
        },
        810: (e2) => {
          e2.exports = r || (r = i.t(a, 2));
        }
      }, n = {};
      function s(e2) {
        var t2 = n[e2];
        if (void 0 !== t2) return t2.exports;
        var i2 = n[e2] = { exports: {} };
        return l[e2].call(i2.exports, i2, i2.exports, s), i2.exports;
      }
      s.d = (e2, t2) => {
        for (var i2 in t2) s.o(t2, i2) && !s.o(e2, i2) && Object.defineProperty(e2, i2, { enumerable: true, get: t2[i2] });
      }, s.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), s.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var o = {};
      (() => {
        Object.defineProperty(o, "X", { value: true }), o.Z = void 0;
        var e2 = s(7459);
        Object.defineProperty(o, "Z", {
          enumerable: true,
          get: function() {
            return e2.Toggle;
          }
        });
      })();
      var c = o.Z;
      o.X;
    },
    63695: (e, t, i) => {
      "use strict";
      i.d(t, {
        lW: () => T.ArtistBandlinkScanner,
        V8: () => j.ArtistItem,
        dP: () => y,
        PK: () => k,
        KH: () => P.ArtistSocialLinks,
        FO: () => R.ArtistStats,
        iQ: () => O.SeparatedArtists,
        DZ: () => r,
        NE: () => l,
        dM: () => c,
        FA: () => o,
        as: () => d,
        Uw: () => u,
        SA: () => _.useArtistDisclaimer,
        eI: () => m.useGetArtistTypeName,
        mW: () => p.useOnDislikeClick,
        KX: () => v.useOnLikeClick,
        A7: () => f.useOnPinClick
      });
      let r = (e2) => ({ imgUrl: e2.imgUrl, title: e2.title, url: e2.url });
      var a = i(80769);
      let l = (e2) => {
        var t2, i2, r2, l2, n2;
        return e2 ? {
          id: Number(e2.id),
          decomposed: (null == (t2 = e2.decomposed) ? void 0 : t2.map((e3) => {
            var t3;
            return {
              id: Number(e3.id),
              name: e3.name,
              various: e3.various || false,
              composer: e3.isComposer || false,
              item: e3.separator,
              available: null == (t3 = e3.isAvailable) || t3,
              disclaimers: e3.disclaimers
            };
          })) || [],
          name: e2.name,
          cover: { uri: e2.coverUri || "", type: a.Q.PIC, prefix: "", custom: false },
          ogImage: "",
          derivedColors: { accent: "", average: e2.averageColor || "", miniPlayer: "", waveText: "" },
          available: e2.isAvailable,
          disclaimers: e2.disclaimers,
          counts: {
            directAlbums: (null == (i2 = e2.counts) ? void 0 : i2.albums) || 0,
            alsoAlbums: (null == (r2 = e2.counts) ? void 0 : r2.compilations) || 0,
            tracks: (null == (l2 = e2.counts) ? void 0 : l2.tracks) || 0,
            alsoTracks: 0
          },
          trailer: { available: !!(null == (n2 = e2.trailer) ? void 0 : n2.isAvailable) },
          hasPromotions: false,
          genres: [],
          links: [],
          ticketsAvailable: false,
          ratings: { week: 0, month: 0, day: 0 },
          composer: e2.isComposer || false,
          various: e2.various || false
        } : {
          id: "",
          name: "",
          various: false,
          composer: false,
          decomposed: [],
          ogImage: "",
          hasPromotions: false,
          genres: [],
          ticketsAvailable: false,
          links: [],
          ratings: { week: 0, month: 0, day: 0 },
          counts: { directAlbums: 0, alsoAlbums: 0, tracks: 0, alsoTracks: 0 },
          available: false,
          disclaimers: []
        };
      };
      var n = i(93064), s = i(74125);
      let o = function() {
        let e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t2 = [];
        return e2.forEach((i2, r2) => {
          let a2 = e2[r2 + 1];
          if ("string" == typeof i2 && "object" == typeof a2) {
            var l2, s2;
            t2.push(
              (0, n.wg)({
                id: String(a2.id),
                name: a2.name,
                various: a2.various,
                isComposer: a2.composer,
                separator: i2,
                isAvailable: null == (s2 = a2.available) || s2,
                disclaimers: a2.disclaimers,
                coverUri: null == (l2 = a2.cover) ? void 0 : l2.uri
              })
            );
          }
        }), t2.length > 0 ? t2 : void 0;
      }, c = (e2) => {
        var t2, i2, r2;
        let a2 = o(e2.decomposed), l2 = (null == e2 ? void 0 : e2.counts) ? ((e3) => ({ albums: e3.directAlbums, compilations: e3.alsoAlbums, tracks: e3.tracks }))(e2.counts) : void 0, c2 = (0, s.mxW)(e2.trailer), d2 = e2.cutoutCover ? (0, s.pX4)(e2.cutoutCover) : void 0;
        return (0, n.wg)({
          id: String(e2.id),
          name: e2.name,
          isComposer: e2.composer,
          coverUri: null == (t2 = e2.cover) ? void 0 : t2.uri,
          coverType: null == (i2 = e2.cover) ? void 0 : i2.type,
          various: e2.various,
          averageColor: (0, s.QBb)(null == e2 ? void 0 : e2.derivedColors),
          decomposed: a2,
          counts: l2,
          isAvailable: null == (r2 = null == e2 ? void 0 : e2.available) || r2,
          disclaimers: e2.disclaimers,
          trailer: c2,
          cutoutCover: d2
        });
      }, d = (e2) => {
        var t2, i2;
        let { artist: r2, trailer: a2, isComposer: l2, likesCount: c2 } = e2, d2 = o(r2.decomposed), { available: u2, disclaimers: _2 } = (0, s.fyr)(r2);
        return (0, n.wg)({
          id: String(r2.id),
          name: r2.name,
          coverUri: null == (t2 = r2.cover) ? void 0 : t2.uri,
          various: r2.various,
          decomposed: d2,
          isAvailable: u2,
          disclaimers: _2,
          isComposer: l2,
          averageColor: null == (i2 = r2.cover) ? void 0 : i2.color,
          trailer: (0, s.mxW)(a2),
          likesCount: c2
        });
      }, u = (e2, t2) => {
        let i2 = e2 / 60;
        return i2 <= 45 ? t2({ id: "time.minutes-left" }, { minutes: Math.round(i2) }) : t2({ id: "time.hours" }, { hours: Math.round(i2 / 60 * 2) / 2 });
      };
      var _ = i(51887), m = i(25577), p = i(65327), v = i(3119), f = i(74808);
      let y = n.gK.model("ArtistLink", {
        imgUrl: n.gK.maybeNull(n.gK.string),
        title: n.gK.maybeNull(n.gK.string),
        url: n.gK.maybeNull(n.gK.string)
      });
      var g = i(60049), x = i(77534), h = i(26433);
      let A = n.gK.compose(
        n.gK.model("BaseArtist", {
          id: n.gK.string,
          name: n.gK.string,
          various: n.gK.maybe(n.gK.boolean),
          isComposer: n.gK.maybe(n.gK.boolean),
          isAvailable: n.gK.boolean,
          trailer: n.gK.maybe(h.aQ),
          coverUri: n.gK.maybe(n.gK.string),
          coverType: n.gK.maybe(n.gK.string),
          cutoutCover: n.gK.maybe(h.$B)
        }),
        h.tP,
        h.Ec
      ).views((e2) => ({
        get key() {
          return "".concat(e2.id, "_").concat(e2.name);
        },
        get url() {
          let { href: t2 } = (0, s.uvd)("/artist/:artistId", { params: { artistId: e2.id } });
          return t2;
        },
        get isLiked() {
          if (!(0, n._n)(e2)) return false;
          let { library: t2 } = (0, n.Zn)(e2);
          return t2.isArtistLiked(e2.id);
        },
        get isDisliked() {
          if (!(0, n._n)(e2)) return false;
          let { library: t2 } = (0, n.Zn)(e2);
          return t2.isArtistDisliked(e2.id);
        },
        get pinId() {
          return "".concat(g._.ARTIST_ITEM).concat(e2.id);
        },
        get seeds() {
          return ["artist:".concat(e2.id)];
        },
        get isPinned() {
          if (!(0, n._n)(e2)) return false;
          let { pinsCollection: t2 } = (0, n.Zn)(e2);
          return t2.isPinned(this.pinId);
        },
        get isLegalRejected() {
          return e2.getIsLegalRejected(e2.isAvailable);
        },
        get isUnsafeLegal() {
          return e2.getIsUnsafeLegal(e2.isAvailable);
        },
        get isCoverFromAlbum() {
          if (!(0, n._n)(e2)) return false;
          return e2.coverType === a.Q.FROM_ALBUM_COVER;
        },
        getDisclaimerEntityRef: (t2) => ({ entityType: null != t2 ? t2 : s.nPY.ARTIST, entityId: e2.id })
      })).actions((e2) => ({
        toggleLike: (0, n.L3)(function* () {
          if (!(0, n._n)(e2)) return;
          let { library: t2, user: i2 } = (0, n.Zn)(e2);
          if (i2.isAuthorized) {
            let r2 = yield t2.toggleArtistLike({ entityId: e2.id, userId: i2.account.data.uid });
            return (0, n._n)(e2) && r2 === x.f.OK && (e2.isLiked ? e2.likePending() : e2.unlikePending()), r2;
          }
        }),
        toggleDislike() {
          if (!(0, n._n)(e2)) return;
          let { library: t2, user: i2 } = (0, n.Zn)(e2);
          return t2.toggleArtistDislike({ entityId: e2.id, userId: i2.account.data.uid });
        },
        togglePin: (0, n.L3)(function* () {
          if (!(0, n._n)(e2)) return;
          let { pinsCollection: t2, user: i2 } = (0, n.Zn)(e2);
          if (i2.isAuthorized) return yield t2.toggleArtistPin({ id: e2.id }, e2.pinId);
        }),
        getKey: (t2) => "".concat(t2, "_").concat(e2.id)
      })), b = n.gK.model("Counts", { albums: n.gK.number, compilations: n.gK.number, tracks: n.gK.number }), C = A.props({ separator: n.gK.maybe(n.gK.string) }), k = A.props({
        decomposed: n.gK.maybe(n.gK.array(C)),
        averageColor: n.gK.maybe(n.gK.string),
        counts: n.gK.maybe(b)
      }).views((e2) => ({
        get isAvailableForPlaying() {
          if (void 0 === e2.counts) return true;
          return e2.counts.tracks > 0;
        }
      }));
      var T = i(92088), j = i(83154), P = i(14476), R = i(88332), O = i(16855);
    },
    65327: (e, t, i) => {
      "use strict";
      i.d(t, { useOnDislikeClick: () => y });
      var r = i(54486), a = i(63930), l = i(61910), n = i(43426), s = i(77534), o = i(8817), c = i(74125), d = i(80585), u = i(6971), _ = i(39610), m = i(97800), p = i(84934), v = i.n(p);
      let f = (e2) => {
        let { coverUri: t2, title: i2, isDisliked: a2, closeToast: l2 } = e2, { formatMessage: s2 } = (0, n.A)(), o2 = s2(
          a2 ? { id: "notifications-info.artist-unavailable-in-recommendations" } : { id: "notifications-info.artist-available-in-recommendations" }
        );
        return (0, r.jsx)(d.$W, {
          closeToast: l2,
          message: (0, r.jsxs)("div", {
            className: v().message,
            children: [
              (0, r.jsx)(_.q, { children: (0, r.jsx)("p", { role: "alert", "aria-label": o2 }) }),
              (0, r.jsx)(u.Paper, {
                className: v().cover,
                radius: "round",
                children: (0, r.jsx)(d.BW, {
                  className: v().image,
                  src: t2,
                  alt: i2,
                  size: 100,
                  fit: "cover",
                  withAvatarReplace: true
                })
              }),
              (0, r.jsx)(m.Caption, {
                className: v().text,
                variant: "div",
                type: "controls",
                size: "m",
                "aria-hidden": true,
                children: o2
              })
            ]
          })
        });
      }, y = (e2) => {
        let { user: t2 } = (0, c.Pjs)(), { notify: i2 } = (0, c.lkh)(), [u2, _2] = (0, l.useState)(false), { formatMessage: m2 } = (0, n.A)();
        return (0, o.c)(async () => {
          if (!e2) return;
          if (!t2.isAuthorized)
            return void i2((0, r.jsx)(d.hT, { error: m2({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: c.uQT.ERROR
            });
          if (u2) return;
          let l2 = { ...(0, a.HO)(e2), isDisliked: !e2.isDisliked };
          _2(true);
          let n2 = await e2.toggleDislike();
          _2(false), n2 === s.f.OK ? i2((0, r.jsx)(f, { coverUri: l2.coverUri, title: l2.name, isDisliked: l2.isDisliked }), {
            containerId: c.uQT.INFO
          }) : i2((0, r.jsx)(d.hT, { error: m2({ id: "error-messages.error-during-action" }) }), {
            containerId: c.uQT.ERROR
          });
        });
      };
    },
    71712: (e, t, i) => {
      "use strict";
      i.d(t, { MN: () => d, hg: () => c });
      var r, a = i(61910), l = {
        5881: (e2, t2, i2) => {
          function r2() {
            for (var e3, t3, i3 = 0, r3 = ""; i3 < arguments.length; )
              (e3 = arguments[i3++]) && (t3 = (function e4(t4) {
                var i4, r4, a3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) a3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (i4 = 0; i4 < t4.length; i4++) t4[i4] && (r4 = e4(t4[i4])) && (a3 && (a3 += " "), a3 += r4);
                  else for (i4 in t4) t4[i4] && (a3 && (a3 += " "), a3 += i4);
                return a3;
              })(e3)) && (r3 && (r3 += " "), r3 += t3);
            return r3;
          }
          i2.r(t2), i2.d(t2, { clsx: () => r2, default: () => a2 });
          let a2 = r2;
        },
        4881: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { default: () => r2 });
          let r2 = {
            root: "KL50tMDvfAdw_9MzcVht",
            bottom: "bL0wE1Bui8zpIZbvMVL3",
            top: "P6gOmyFtXyetUz0dqhF3",
            bottom_left: "RvWjZle1erRBXzJEF9Zj",
            bottom_right: "bBh7lvgdfF7bqNqlK78Q",
            label: "FgncHYHPDU14dLddn0wF",
            controls: "PBhQ1krUFiAybu_BS2YE",
            controls_radius_default: "cSCPJSa6Lx6OnpM4ljX9",
            controls_radius_round: "kHUOlGxOaBwL4P3jEBXU",
            controls_visible: "QZC5vQL9p11QsEkdkTtZ"
          };
        },
        4247: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { default: () => r2 });
          let r2 = {
            root: "laBJlJAaqEVS0i_4Ot3l",
            titleContainer: "LmhA6nlLyzxwYIX31gYa",
            wrapper: "IO4kvpDGNI2J0CHwcKSf",
            content: "l8SktNpJd30JWp1owp_b",
            content_left: "Mb33JzAWx9EjbQAeScFt",
            description: "kbcBH9meMfY6Du_xQNnI",
            content_center: "Dp41JRuLGzwV3MHBYHMC",
            content_right: "eOsuNCgUirwAw16iUKLu",
            title: "FAmeEGy52GX1k0xZuPDn",
            content_linesCount_1: "Cfj1Wkh1bvQMCfk1mZwK",
            content_linesCount_2: "lV4OXsCTURC5K1s9Q5mx",
            content_linesCount_3: "PVBDIXF2RTUThmbNT9sV",
            content_linesCount_4: "ND4XIwkIYtNoU89EOISr"
          };
        },
        9474: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { default: () => r2 });
          let r2 = { root: "LizdJ2L0HW7JWOvPrfly" };
        },
        7238: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { default: () => r2 });
          let r2 = { root: "eaYyesBmJL_NbkgoYR1c", focusable: "uL1dD5rxgI4bPmfyMMe7" };
        },
        3641: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { default: () => r2 });
          let r2 = {
            root_controls_xxs: "tRaaBpDMg9Qu8v6gKjtn",
            root_entity_xxs: "M9zvtlcpLUVn6DKdcHhj",
            root_text_xxs: "ln0PYYwDmFnfYxCDJsFU",
            root_controls_xs: "n5AeWEsJC3_AYXcbK4Lt",
            root_entity_xs: "__hrMKGmNbw54T54IUyh",
            root_text_xs: "SehSa7OyRpC2nzYTVb2Q",
            root_controls_s: "_oBLf5gprWsKjCw4Ce58",
            root_entity_s: "mxSPe5xpZnie9gpIqacd",
            root_text_s: "Ai2iRN9elHpk_u5splD6",
            root_controls_m: "tk7ahHRDYXJMMB879KUA",
            root_entity_m: "Z_WIr2W8JU4MPQek3hgR",
            root_text_m: "g3qWNP6xl__7qxNmtrvd",
            root_controls_l: "grvxapJE3vGArOKDWf6n",
            root_entity_l: "Esj5A1UeSi4xV4tZ839D",
            root_text_l: "V3WU123oO65AxsprotU9",
            root_weight_normal: "ZYV27jeWd30QDXu4GhaH",
            root_weight_medium: "_3_Mxw7Si7j2g4kWjlpR",
            root_weight_bold: "Vi7Rd0SZWqD17F0872TB"
          };
        },
        5153: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { default: () => r2 });
          let r2 = {
            root_size_xs: "qJJ288377iHlWN_RXeEE",
            root_size_s: "_sd8Q9d_Ttn0Ufe4ISWS",
            root_size_m: "Ctk8dbecq31Qh7isOJPQ",
            root_size_l: "M_Djh6ppIkCO3A2k_BTA",
            root_size_xl: "dtxlzGQMPAbM2MEndXWX",
            root_size_xxl: "IUb9XLplTAoZqne9rNUL",
            root_size_xxxl: "ZYZamUwql_rfFR4RpI2B",
            root_size_xxxxl: "ZBZyxow5njdq8z5dnRPY",
            root_size_xxxxxl: "WdvQQNwdDNCdRSwRkAtT",
            root_weight_bold: "nSU6fV9y80WrZEfafvww",
            root_weight_black: "KBeGPPK4DinQzAP41Y_N"
          };
        },
        5818: (e2, t2, i2) => {
          i2.r(t2), i2.d(t2, { default: () => r2 });
          let r2 = {
            root: "_MWOVuZRvUQdXKTMcOPx",
            root_clamp: "LezmJlldtbHWqU7l1950",
            root_clamp_oneline: "oyQL2RSmoNbNQf3Vc6YI",
            root_clamp_multiline: "jMyoZB5J9iZbzJmWOrF0"
          };
        },
        9097: (e2, t2) => {
          var i2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function r2(e3, t3, r3) {
            var a2 = null;
            if (void 0 !== r3 && (a2 = "" + r3), void 0 !== t3.key && (a2 = "" + t3.key), "key" in t3)
              for (var l2 in r3 = {}, t3) "key" !== l2 && (r3[l2] = t3[l2]);
            else r3 = t3;
            return { $$typeof: i2, type: e3, key: a2, ref: void 0 !== (t3 = r3.ref) ? t3 : null, props: r3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = r2, t2.jsxs = r2;
        },
        4377: (e2, t2, i2) => {
          e2.exports = i2(9097);
        },
        5817: function(e2, t2, i2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.CardControls = void 0;
          let a2 = i2(4377), l2 = i2(5881), n2 = i2(9e3), s2 = r2(i2(4881));
          t2.CardControls = (e3) => {
            let {
              className: t3,
              playControl: i3,
              likeControl: r3,
              menuControl: o2,
              pinControl: c2,
              trailerControl: d2,
              isVisible: u,
              radius: _ = "default",
              bottomContainerClassName: m,
              labelText: p
            } = e3, v = d2 || i3, f = o2 || r3;
            return (0, a2.jsxs)("div", {
              className: (0, l2.clsx)(
                s2.default.root,
                s2.default.controls,
                { [s2.default.controls_visible]: u },
                s2.default["controls_radius_".concat(_)],
                t3
              ),
              children: [
                (0, a2.jsx)("div", { className: s2.default.top, children: c2 }),
                (0, a2.jsxs)("div", {
                  className: (0, l2.clsx)(s2.default.bottom, m),
                  children: [
                    v && (0, a2.jsxs)("div", { className: s2.default.bottom_left, children: [d2, i3] }),
                    f && (0, a2.jsxs)("div", { className: s2.default.bottom_right, children: [o2, r3] })
                  ]
                }),
                !!p && (0, a2.jsx)(n2.Label, { className: s2.default.label, children: p })
              ]
            });
          };
        },
        440: function(e2, t2, i2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.EntityCard = void 0;
          let a2 = i2(4377), l2 = i2(810), n2 = i2(5881), s2 = i2(2582), o2 = i2(3758), c2 = r2(i2(4247)), d2 = (e3) => {
            let {
              forwardRef: t3,
              view: i3,
              className: r3,
              textPosition: l3 = "left",
              contentLinesCount: d3 = 2,
              title: u,
              description: _,
              explicitMarkComponent: m,
              chart: p,
              children: v,
              srTitle: f,
              wrapperClassName: y,
              ...g
            } = e3;
            return (0, a2.jsxs)("div", {
              className: (0, n2.clsx)(c2.default.root, r3),
              ref: t3,
              ...g,
              children: [
                (0, a2.jsx)(o2.SROnly, { tabIndex: -1, children: null != f ? f : u }),
                (0, a2.jsx)("div", { className: c2.default.viewContainer, children: i3 }),
                (0, a2.jsxs)("div", {
                  className: (0, n2.clsx)(c2.default.wrapper, y),
                  children: [
                    p,
                    (0, a2.jsxs)("div", {
                      className: (0, n2.clsx)(
                        c2.default.content,
                        c2.default["content_".concat(l3)],
                        c2.default["content_linesCount_".concat(d3)]
                      ),
                      children: [
                        (0, a2.jsxs)("div", {
                          className: c2.default.titleContainer,
                          children: [
                            (0, a2.jsx)(s2.Caption, {
                              className: c2.default.title,
                              variant: "div",
                              type: "entity",
                              size: "s",
                              weight: "medium",
                              lineClamp: 2,
                              children: u
                            }),
                            m
                          ]
                        }),
                        _,
                        v
                      ]
                    })
                  ]
                })
              ]
            });
          };
          t2.EntityCard = (0, l2.forwardRef)((e3, t3) => (0, a2.jsx)(d2, { forwardRef: t3, ...e3 }));
        },
        2: function(e2, t2, i2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Label = void 0;
          let a2 = i2(4377), l2 = i2(5881), n2 = i2(2582), s2 = r2(i2(9474));
          t2.Label = (e3) => {
            let { children: t3, className: i3, size: r3 = "s", ...o2 } = e3;
            return (0, a2.jsx)(n2.Caption, {
              variant: "div",
              type: "text",
              size: r3,
              lineClamp: 1,
              className: (0, l2.clsx)(s2.default.root, i3),
              ...o2,
              children: t3
            });
          };
        },
        9e3: (e2, t2, i2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Label = void 0;
          var r2 = i2(2);
          Object.defineProperty(t2, "Label", {
            enumerable: true,
            get: function() {
              return r2.Label;
            }
          });
        },
        2865: function(e2, t2, i2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.SROnly = void 0;
          let a2 = i2(4377), l2 = i2(5881), n2 = i2(810), s2 = r2(i2(7238));
          t2.SROnly = (e3) => {
            let { className: t3, focusable: i3, children: r3, ...o2 } = e3, c2 = (0, l2.clsx)(s2.default.root, { [s2.default.focusable]: i3 }, t3);
            return (0, n2.isValidElement)(r3) ? (0, n2.cloneElement)(r3, { ...o2, className: (0, l2.clsx)(c2, r3.props.className) }) : (0, a2.jsx)("span", { className: c2, ...o2, children: r3 });
          };
        },
        3758: (e2, t2, i2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.SROnly = void 0;
          var r2 = i2(2865);
          Object.defineProperty(t2, "SROnly", {
            enumerable: true,
            get: function() {
              return r2.SROnly;
            }
          });
        },
        7743: function(e2, t2, i2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Caption = t2.CaptionComponent = void 0;
          let a2 = i2(4377), l2 = i2(5881), n2 = i2(810), s2 = i2(4721), o2 = r2(i2(3641));
          t2.CaptionComponent = (e3) => {
            let {
              forwardRef: t3,
              variant: i3,
              type: r3 = "text",
              size: n3 = "s",
              className: c2,
              children: d2,
              weight: u = "medium",
              ..._
            } = e3;
            return (0, a2.jsx)(s2.Typography, {
              variant: i3,
              ref: t3,
              className: (0, l2.clsx)(
                o2.default.root,
                o2.default["root_".concat(r3, "_").concat(n3)],
                o2.default["root_weight_".concat(u)],
                c2
              ),
              ..._,
              children: d2
            });
          }, t2.Caption = (0, n2.forwardRef)((e3, i3) => (0, a2.jsx)(t2.CaptionComponent, { forwardRef: i3, ...e3 }));
        },
        404: function(e2, t2, i2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.HeadingComponent = void 0;
          let a2 = i2(4377), l2 = i2(5881), n2 = i2(810), s2 = i2(4721), o2 = r2(i2(5153));
          t2.HeadingComponent = (e3) => {
            let { forwardRef: t3, variant: i3, weight: r3 = "bold", size: n3 = "s", className: c2, children: d2, ...u } = e3;
            return (0, a2.jsx)(s2.Typography, {
              variant: i3,
              ref: t3,
              className: (0, l2.clsx)(
                o2.default.root,
                o2.default["root_size_".concat(n3)],
                o2.default["root_weight_".concat(r3)],
                c2
              ),
              ...u,
              children: d2
            });
          }, t2.Heading = (0, n2.forwardRef)((e3, i3) => (0, a2.jsx)(t2.HeadingComponent, { forwardRef: i3, ...e3 }));
        },
        4721: function(e2, t2, i2) {
          var r2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Typography = t2.TypographyComponent = void 0;
          let a2 = i2(4377), l2 = i2(5881), n2 = i2(810), s2 = r2(i2(5818));
          function o2(e3) {
            let { forwardRef: t3, style: i3, className: r3, children: n3, variant: o3, lineClamp: c2, ...d2 } = e3, u = c2 && "string" == typeof n3 ? n3 : void 0;
            return (0, a2.jsx)(o3, {
              style: { ...i3, WebkitLineClamp: c2 },
              ref: t3,
              title: u,
              className: (0, l2.clsx)(
                s2.default.root,
                {
                  [s2.default.root_clamp]: c2 && c2 > 0,
                  [s2.default.root_clamp_oneline]: c2 && 1 === c2,
                  [s2.default.root_clamp_multiline]: c2 && c2 > 1
                },
                r3
              ),
              ...d2,
              children: n3
            });
          }
          t2.TypographyComponent = o2, t2.Typography = (0, n2.forwardRef)((e3, t3) => (0, a2.jsx)(o2, { forwardRef: t3, ...e3 }));
        },
        2582: (e2, t2, i2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.Caption = void 0;
          var r2 = i2(7743);
          Object.defineProperty(t2, "Caption", {
            enumerable: true,
            get: function() {
              return r2.Caption;
            }
          });
          var a2 = i2(404);
          Object.defineProperty(t2, "Heading", {
            enumerable: true,
            get: function() {
              return a2.Heading;
            }
          });
        },
        810: (e2) => {
          e2.exports = r || (r = i.t(a, 2));
        }
      }, n = {};
      function s(e2) {
        var t2 = n[e2];
        if (void 0 !== t2) return t2.exports;
        var i2 = n[e2] = { exports: {} };
        return l[e2].call(i2.exports, i2, i2.exports, s), i2.exports;
      }
      s.d = (e2, t2) => {
        for (var i2 in t2) s.o(t2, i2) && !s.o(e2, i2) && Object.defineProperty(e2, i2, { enumerable: true, get: t2[i2] });
      }, s.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), s.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var o = {};
      (() => {
        Object.defineProperty(o, "X$", { value: true }), o.kk = o.m7 = void 0;
        var e2 = s(440);
        Object.defineProperty(o, "m7", {
          enumerable: true,
          get: function() {
            return e2.EntityCard;
          }
        });
        var t2 = s(5817);
        Object.defineProperty(o, "kk", {
          enumerable: true,
          get: function() {
            return t2.CardControls;
          }
        });
      })();
      var c = o.kk, d = o.m7;
      o.X$;
    },
    73633: (e, t, i) => {
      "use strict";
      i.d(t, { P: () => a });
      var r = {};
      Object.defineProperty(r, "__esModule", { value: true }), r.createRipple = void 0, r.createRipple = function(e2, t2, i2) {
        let r2 = null != i2 ? i2 : e2.currentTarget, a2 = document.createElement("span"), l = Math.max(r2.clientWidth, r2.clientHeight), n = l / 2, s = r2.getBoundingClientRect(), o = 0 === e2.clientX ? Math.round(s.width / 2) : e2.clientX - s.left, c = 0 === e2.clientY ? Math.round(s.height / 2) : e2.clientY - s.top;
        a2.style.width = "".concat(l, "px"), a2.style.height = "".concat(l, "px"), a2.style.left = 0 === e2.clientX ? "0px" : "".concat(o - n, "px"), a2.style.top = "".concat(c - n, "px"), a2.classList.add(t2);
        let d = r2.getElementsByClassName(t2)[0];
        d && d.remove(), r2.insertBefore(a2, r2.firstChild);
      }, r.__esModule;
      var a = r.createRipple;
    },
    74808: (e, t, i) => {
      "use strict";
      i.d(t, { useOnPinClick: () => d });
      var r = i(54486), a = i(63930), l = i(61910), n = i(43426), s = i(74125), o = i(80585);
      let c = (e2) => {
        let { artist: t2, closeToast: i2 } = e2;
        return (0, r.jsx)(o.k4, {
          closeToast: i2,
          entityVariant: o.cp.ARTIST,
          coverUri: t2.coverUri,
          entityUrl: t2.url,
          entityTitle: t2.name,
          isPinned: t2.isPinned,
          radius: "round"
        });
      }, d = (e2) => {
        let { user: t2 } = (0, s.Pjs)(), { notify: i2 } = (0, s.lkh)(), { formatMessage: d2 } = (0, n.A)(), [u, _] = (0, l.useState)(false);
        return (0, l.useCallback)(async () => {
          if (!e2) return;
          if (!t2.isAuthorized)
            return void i2((0, r.jsx)(o.hT, { error: d2({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: s.uQT.ERROR
            });
          if (u) return;
          let l2 = { ...(0, a.HO)(e2), isPinned: !e2.isPinned };
          _(true);
          let n2 = await e2.togglePin();
          _(false), n2 ? i2((0, r.jsx)(c, { artist: l2 }), { containerId: s.uQT.INFO }) : i2((0, r.jsx)(o.hT, { error: d2({ id: "error-messages.error-during-action" }) }), {
            containerId: s.uQT.ERROR
          });
        }, [e2, t2.isAuthorized, u, d2, i2]);
      };
    },
    80769: (e, t, i) => {
      "use strict";
      var r;
      i.d(t, { Q: () => r }), (function(e2) {
        e2.FROM_ALBUM_COVER = "from-album-cover", e2.FROM_ARTIST_PHOTOS = "from-artist-photos", e2.PIC = "pic", e2.MOSAIC = "mosaic";
      })(r || (r = {}));
    },
    82885: (e, t, i) => {
      "use strict";
      i.d(t, { useOnPinClick: () => d });
      var r = i(54486), a = i(63930), l = i(61910), n = i(43426), s = i(74125), o = i(80585);
      let c = (e2) => {
        let { playlist: t2, closeToast: i2 } = e2;
        return (0, r.jsx)(o.k4, {
          closeToast: i2,
          entityVariant: o.cp.PLAYLIST,
          entityUrl: t2.url,
          coverUri: t2.coverUri,
          entityTitle: t2.title,
          isPinned: t2.isPinned,
          radius: "s"
        });
      }, d = (e2) => {
        let { user: t2 } = (0, s.Pjs)(), { notify: i2 } = (0, s.lkh)(), { formatMessage: d2 } = (0, n.A)(), [u, _] = (0, l.useState)(false);
        return (0, l.useCallback)(async () => {
          if (!t2.isAuthorized)
            return void i2((0, r.jsx)(o.hT, { error: d2({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: s.uQT.ERROR
            });
          if (u) return;
          let l2 = { ...(0, a.HO)(e2), url: e2.url, isPinned: !e2.isPinned };
          _(true);
          let n2 = await e2.togglePin();
          _(false), n2 ? i2((0, r.jsx)(c, { playlist: l2 }), { containerId: s.uQT.INFO }) : i2((0, r.jsx)(o.hT, { error: d2({ id: "error-messages.error-during-action" }) }), {
            containerId: s.uQT.ERROR
          });
        }, [t2.isAuthorized, u, e2, i2, d2]);
      };
    },
    83154: (e, t, i) => {
      "use strict";
      i.d(t, { ArtistItem: () => p });
      var r = i(54486), a = i(28303), l = i(61910), n = i(8817), s = i(58360), o = i(61958), c = i(6971), d = i(97800), u = i(74125), _ = i(99592), m = i.n(_);
      let p = (0, a.PA)((e2) => {
        let { artist: t2 } = e2, { fullscreenPlayer: i2 } = (0, u.Pjs)(), a2 = (0, u.ZpR)(t2.url), _2 = (0, l.useMemo)(() => {
          var e3;
          return "decomposed" in t2 && (null == (e3 = t2.decomposed) ? void 0 : e3.reduce((e4, t3) => (e4.push((0, r.jsx)(p, { artist: t3 }, t3.id)), e4), []));
        }, [t2]), v = (0, n.c)((e3) => {
          i2.modal.isOpened && i2.modal.close(), a2(e3);
        });
        return (0, r.jsxs)(r.Fragment, {
          children: [
            (0, r.jsxs)(o.Dr, {
              className: m().root,
              onClick: v,
              children: [
                (0, r.jsx)(c.Paper, {
                  radius: "round",
                  className: m().cover,
                  children: (0, r.jsx)(s.Image, {
                    withAvatarReplace: true,
                    src: t2.coverUri,
                    size: 100,
                    fit: "contain",
                    className: m().image
                  })
                }),
                (0, r.jsx)(d.Caption, { variant: "span", size: "m", weight: "medium", lineClamp: 1, children: t2.name })
              ]
            }),
            _2
          ]
        });
      });
    },
    83504: (e, t, i) => {
      "use strict";
      i.d(t, { dx: () => O, A_: () => a });
      var r = i(74125);
      let a = (e2) => {
        let t2, { entityVariant: i2, urlParams: a2 } = e2, l2 = (0, r.D60)();
        if (!a2.id || !(t2 = "production" === l2 ? ((e3) => {
          switch (e3) {
            case r.DwC.ALBUM:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYayuozEyrP10MJSgYaW1Y2SxoJyhY3McMKpgLJkvqJ0/LJkvqJ1WMQ06nJD=";
            case r.DwC.PLAYLIST:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYayuozEyrP10MJSgYaW1Y2SxoJyhY3OfLKyfnKA0pl92nJI3YKOfLKyfnKA0YzSwqTyiow91nJD9BzyxWzgcozD9BzgcozD=";
            case r.DwC.ARTIST:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYayuozEyrP10MJSgYaW1Y2SxoJyhY3McMKpgLKW0nKA0C2SlqTymqRyxCGccMN==";
            case r.DwC.TRACK:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYayuozEyrP10MJSgYaW1Y2SxoJyhY3McMKpgqUWuL2f/qUWuL2gWMQ06nJD=";
            case r.DwC.UGC_TRACK:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYayuozEyrP10MJSgYaW1Y2SxoJyhY3IaLl92nJI3YKElLJAeC3ElLJAeFJD9Bzyx";
          }
        })(i2) : ((e3) => {
          switch (e3) {
            case r.DwC.ALBUM:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYaSuYayuozEyrP10MJSgYaW1Y2SxoJyhY3McMKpgLJkvqJ0/LJkvqJ1WMQ06nJD=";
            case r.DwC.PLAYLIST:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYaSuYayuozEyrP10MJSgYaW1Y2SxoJyhY3OfLKyfnKA0pl92nJI3YKOfLKyfnKA0YzSwqTyiow91nJD9BzyxWzgcozD9BzgcozD=";
            case r.DwC.ARTIST:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYaSuYayuozEyrP10MJSgYaW1Y2SxoJyhY3McMKpgLKW0nKA0C2SlqTymqRyxCGccMN==";
            case r.DwC.TRACK:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYaSuYayuozEyrP10MJSgYaW1Y2SxoJyhY3McMKpgqUWuL2f/qUWuL2gWMQ06nJD=";
            case r.DwC.UGC_TRACK:
              return "nUE0pUZ6Yl9vLKAyYz11p2ywYaSuYayuozEyrP10MJSgYaW1Y2SxoJyhY3IaLl92nJI3YKElLJAeC3ElLJAeFJD9Bzyx";
          }
        })(i2)))
          return;
        let n2 = atob(
          t2.replace(/[A-Za-z]/g, function(e3) {
            return String.fromCharCode(e3.charCodeAt(0) + ("M" >= e3.toUpperCase() ? 13 : -13));
          })
        );
        return (0, r.BcX)(n2, a2);
      };
      var l = i(54486), n = i(28303), s = i(43426), o = i(31500), c = i(61958), d = i(61910), u = i(47713), _ = i(97800), m = i(80585), p = i(39604), v = i.n(p);
      let f = (e2) => {
        let { closeToast: t2 } = e2;
        return (0, l.jsx)(m.$W, {
          message: (0, l.jsx)(_.Caption, {
            className: v().message,
            variant: "div",
            type: "controls",
            size: "m",
            children: (0, l.jsx)(u.A, { id: "playlist-errors.failed-part-tracks-download-xlsx" })
          }),
          closeToast: t2
        });
      }, y = (e2) => {
        let { closeToast: t2 } = e2;
        return (0, l.jsx)(m.$W, {
          message: (0, l.jsx)(_.Caption, {
            className: v().message,
            variant: "div",
            type: "controls",
            size: "m",
            children: (0, l.jsx)(u.A, { id: "playlist-errors.failed-download-xlsx" })
          }),
          closeToast: t2
        });
      };
      var g = i(95087), x = i.n(g);
      let h = (e2) => {
        let { closeToast: t2 } = e2;
        return (0, l.jsx)(m.$W, {
          message: (0, l.jsx)(_.Caption, {
            variant: "div",
            size: "m",
            className: x().text,
            children: (0, l.jsx)(u.A, { id: "notifications-info.xlsx-success" })
          }),
          closeToast: t2,
          coverRadius: "s"
        });
      }, A = () => (0, l.jsx)(m.$W, {
        message: (0, l.jsx)(_.Caption, {
          variant: "div",
          size: "m",
          className: x().text,
          children: (0, l.jsx)(u.A, { id: "notifications-info.xlsx-loading" })
        }),
        coverRadius: "s"
      }), b = function() {
        let e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 40, { fullscreenPlayer: t2, playlist: i2 } = (0, r.Pjs)(), { notify: a2, dismiss: n2 } = (0, r.lkh)(), s2 = (0, d.useRef)(null), o2 = t2.modal.isOpened ? r.uQT.FULLSCREEN_INFO : r.uQT.INFO;
        return (0, d.useCallback)(async () => {
          s2.current = a2((0, l.jsx)(A, {}), { containerId: o2, autoClose: false }), await i2.editorFeature.getAllPlaylistItems({ batchSize: e2 }), await i2.editorFeature.exportToExcel() === r.FlZ.OK ? i2.areAllTracksUploaded ? a2((0, l.jsx)(h, {}), { containerId: o2 }) : a2((0, l.jsx)(f, {}), {
            containerId: t2.modal.isOpened ? r.uQT.FULLSCREEN_ERROR : r.uQT.ERROR,
            autoClose: false
          }) : a2((0, l.jsx)(y, {}), {
            containerId: t2.modal.isOpened ? r.uQT.FULLSCREEN_ERROR : r.uQT.ERROR,
            autoClose: false
          }), n2({ notificationId: s2.current, forceClose: true });
        }, [e2, n2, t2.modal.isOpened, o2, a2, i2.areAllTracksUploaded, i2.editorFeature]);
      }, C = (0, n.PA)(() => {
        let {
          playlist: { editorFeature: e2 }
        } = (0, r.Pjs)(), { toggleShouldShowDuplicate: t2, shouldShowDuplicate: i2 } = e2, { formatMessage: a2 } = (0, s.A)();
        return (0, l.jsx)(m.Kb, {
          "aria-label": a2({ id: "entity-names.editor-feature-is-show" }),
          text: a2({ id: "interface-actions.show-duplicates" }),
          onClick: t2,
          isActive: i2
        });
      }), k = (0, n.PA)(() => {
        let {
          playlist: { editorFeature: e2 }
        } = (0, r.Pjs)(), { toggleShouldShowGenre: t2, shouldShowGenre: i2 } = e2, { formatMessage: a2 } = (0, s.A)();
        return (0, l.jsx)(m.Kb, {
          "aria-label": a2({ id: "entity-names.editor-feature-is-show" }),
          text: a2({ id: "interface-actions.show-genres" }),
          onClick: t2,
          isActive: i2
        });
      }), T = (0, n.PA)(() => {
        let {
          playlist: { editorFeature: e2 }
        } = (0, r.Pjs)(), { toggleShouldShowMajor: t2, shouldShowMajor: i2 } = e2, { formatMessage: a2 } = (0, s.A)();
        return (0, l.jsx)(m.Kb, {
          "aria-label": a2({ id: "entity-names.editor-feature-is-show" }),
          text: a2({ id: "interface-actions.show-majors" }),
          onClick: t2,
          isActive: i2
        });
      });
      var j = i(97396), P = i(8817);
      let R = (0, n.PA)((e2) => {
        let { adminUrl: t2 } = e2;
        (0, j.useRouter)();
        let i2 = (0, P.c)(() => {
          window.open(t2, "_blank");
        });
        return (0, l.jsx)(c.Dr, {
          onClick: i2,
          isSubMenu: true,
          children: (0, l.jsx)(_.Caption, {
            variant: "div",
            lineClamp: 1,
            children: (0, l.jsx)(u.A, { id: "interface-actions.navigate-to-admin" })
          })
        });
      }), O = (0, n.PA)((e2) => {
        let { entityVariant: t2, adminUrl: i2, withPlaylistPageFeatures: a2, className: n2, isDisabled: d2 } = e2, {
          settings: { isMobile: u2 }
        } = (0, r.Pjs)(), { formatMessage: _2 } = (0, s.A)();
        b();
        let m2 = t2 === r.DwC.PLAYLIST && a2, p2 = t2 === r.DwC.PLAYLIST && a2, v2 = t2 === r.DwC.PLAYLIST && a2, f2 = t2 === r.DwC.PLAYLIST && a2;
        return (0, l.jsxs)(c.W1, {
          label: _2({ id: "interface-actions.editorial-tools" }),
          menuClassName: n2,
          offsetOptions: 3,
          isMobile: u2,
          disabled: d2,
          ...(0, o.Am)(o.OA.playlist.CONTEXT_MENU_EDITOR_FEATURES_BUTTON),
          children: [
            i2 && (0, l.jsx)(R, { adminUrl: i2 }),
            m2 && (0, l.jsx)(T, {}),
            p2 && (0, l.jsx)(k, {}),
            v2 && (0, l.jsx)(C, {}),
            f2 && false
          ]
        });
      });
    },
    84934: (e) => {
      e.exports = {
        message: "NotificationDislike_message__RoxZH",
        text: "NotificationDislike_text__fJHts",
        cover: "NotificationDislike_cover__N5Oqu",
        image: "NotificationDislike_image__jn4_4"
      };
    },
    85413: (e) => {
      e.exports = {
        root: "CreatePlaylistCard_root__pMDua",
        button: "CreatePlaylistCard_button__ZaAtb",
        icon: "CreatePlaylistCard_icon__09K9N",
        text: "CreatePlaylistCard_text__dd9Q6"
      };
    },
    88332: (e, t, i) => {
      "use strict";
      i.d(t, { ArtistStats: () => u });
      var r = i(54486), a = i(50420), l = i(61910), n = i(47713), s = i(31500), o = i(97800), c = i(97118), d = i.n(c);
      let u = (e2) => {
        let { lastMonthListeners: t2, lastMonthListenersDelta: i2 } = e2, c2 = (0, l.useMemo)(() => {
          let e3 = (0, r.jsx)("br", {});
          if (0 === i2) return (0, r.jsx)(n.A, { id: "artist.stats-same-listeners-per-month", values: { br: e3 } });
          let t3 = (0, r.jsx)(o.Caption, {
            variant: "span",
            className: (0, a.$)({ [d().statsNumber_positive]: i2 > 0, [d().statsNumber_negative]: i2 < 0 }),
            size: "l",
            weight: "medium",
            children: Math.abs(i2).toLocaleString("ru")
          });
          return i2 > 0 ? (0, r.jsx)(n.A, {
            id: "artist.stats-more-listeners-per-month",
            values: { number: t3, br: e3, nbsp: " " }
          }) : (0, r.jsx)(n.A, {
            id: "artist.stats-less-listeners-per-month",
            values: { number: t3, br: e3, nbsp: " " }
          });
        }, [i2]);
        return (0, r.jsxs)("div", {
          ...(0, s.Am)(s.e8.content.ARTIST_ABOUT_STATS),
          children: [
            (0, r.jsx)(o.Caption, {
              variant: "div",
              className: d().title,
              size: "l",
              weight: "medium",
              ...(0, s.Am)(s.e8.content.ARTIST_ABOUT_STATS_TITLE),
              children: (0, r.jsx)(n.A, { id: "artist.stats-listeners-per-month" })
            }),
            (0, r.jsx)(o.Heading, {
              size: "xxl",
              variant: "div",
              className: d().count,
              ...(0, s.Am)(s.e8.content.ARTIST_ABOUT_STATS_COUNT),
              children: t2.toLocaleString("ru")
            }),
            (0, r.jsx)(o.Caption, {
              variant: "div",
              className: d().stats,
              size: "l",
              weight: "medium",
              ...(0, s.Am)(s.e8.content.ARTIST_ABOUT_STATS_DYNAMIC),
              children: c2
            })
          ]
        });
      };
    },
    89864: (e) => {
      e.exports = { tooltipContent: "SeparatedArtistsWithContextMenuDesktop_tooltipContent___PtDD" };
    },
    92088: (e, t, i) => {
      "use strict";
      i.d(t, { ArtistBandlinkScanner: () => _ });
      var r = i(54486), a = i(50420), l = i(47713), n = i(31500), s = i(5956), o = i(97800), c = i(80585), d = i(42522), u = i.n(d);
      let _ = (e2) => {
        let { className: t2, artistId: i2, artistName: d2 } = e2;
        return (0, r.jsxs)(c.N_, {
          href: "https://band.link/scanner?search=".concat(i2, "&type=artist_id&service=yandex_music"),
          className: (0, a.$)(u().root, t2),
          ...(0, n.Am)(n.e8.content.ARTIST_ABOUT_BANDLINK_SCANNER),
          children: [
            (0, r.jsx)(s.Icon, { className: u().icon, variant: "bandlink" }),
            (0, r.jsxs)("div", {
              className: u().description,
              children: [
                (0, r.jsxs)("div", {
                  className: u().descriptionTitle,
                  children: [
                    (0, r.jsx)(o.Caption, {
                      variant: "div",
                      size: "l",
                      weight: "medium",
                      className: u().descriptionTitleText,
                      children: (0, r.jsx)(l.A, { id: "artist.artist-in-playlists" })
                    }),
                    (0, r.jsx)(s.Icon, { variant: "link", size: "xxs", className: u().descriptionTitleButton })
                  ]
                }),
                (0, r.jsx)(o.Caption, {
                  variant: "div",
                  size: "l",
                  weight: "medium",
                  className: u().descriptionArtist,
                  children: null != d2 ? d2 : ""
                })
              ]
            })
          ]
        });
      };
    },
    93099: (e, t, i) => {
      "use strict";
      i.d(t, { TrackPlaylistContext: () => r });
      let r = (0, i(61910).createContext)(null);
    },
    95087: (e) => {
      e.exports = {
        message: "EditorsFeaturesNotification_message__Q__9v",
        text: "EditorsFeaturesNotification_text__b79yA",
        title: "EditorsFeaturesNotification_title__BuJZ_",
        link: "EditorsFeaturesNotification_link__deYjx",
        playlistTitle: "EditorsFeaturesNotification_playlistTitle__Hv7bZ",
        image: "EditorsFeaturesNotification_image__AidPK"
      };
    },
    95806: (e) => {
      e.exports = {
        root: "ArtistSocialLinks_root__9wQxA",
        link: "ArtistSocialLinks_link__UFvCL",
        icon: "ArtistSocialLinks_icon__Y9VLu"
      };
    },
    97118: (e) => {
      e.exports = {
        title: "ArtistStats_title__Yxyh1",
        count: "ArtistStats_count__8h5zM",
        stats: "ArtistStats_stats__Hammf",
        statsNumber_positive: "ArtistStats_statsNumber_positive__GlukF",
        statsNumber_negative: "ArtistStats_statsNumber_negative__C0bH5"
      };
    },
    99592: (e) => {
      e.exports = {
        root: "ArtistItem_root__Q_mgJ",
        cover: "ArtistItem_cover__FTvHo",
        image: "ArtistItem_image__5rKWF"
      };
    },
    99733: (e, t, i) => {
      "use strict";
      i.d(t, { ContextMenuPlaylistPrivacyItem: () => y });
      var r = i(54486), a = i(50420), l = i(28303), n = i(61910), s = i(43426), o = i(47713), c = i(31500), d = i(5956), u = i(61958), _ = i(61609), m = i(74125), p = i(80585), v = i(58627), f = i.n(v);
      let y = (0, l.PA)((e2) => {
        let { className: t2, playlist: i2 } = e2, { notify: l2 } = (0, m.lkh)(), { formatMessage: v2 } = (0, s.A)(), y2 = (0, n.useCallback)(async () => {
          await i2.toggleVisibility() === m.FlZ.ERROR && l2((0, r.jsx)(p.hT, { error: v2({ id: "playlist-errors.failed-to-change-privacy-settings" }) }), {
            containerId: m.uQT.ERROR
          });
        }, [v2, l2, i2]);
        return (0, r.jsxs)(u.Dr, {
          className: (0, a.$)(f().root, t2),
          onClick: y2,
          icon: (0, r.jsx)(d.Icon, { variant: "eye_crossed", size: "xxs" }),
          ...(0, c.Am)(c.S7.CONTEXT_MENU_PLAYLIST_PRIVACY_BUTTON),
          role: "menuitemcheckbox",
          "aria-checked": !i2.isPublic,
          isSubMenu: true,
          isBlock: true,
          children: [
            (0, r.jsx)("span", {
              className: f().caption,
              children: (0, r.jsx)(o.A, { id: "playlist-actions.privacy" })
            }),
            (0, r.jsx)(_.l, {
              isChecked: !i2.isPublic,
              ariaLabel: v2({ id: "playlist-actions.privacy-label" }),
              tabIndex: -1
            })
          ]
        });
      });
    }
  }
]);
