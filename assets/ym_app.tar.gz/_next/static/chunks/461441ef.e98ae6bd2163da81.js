(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [714],
  {
    2268: (e, t, r) => {
      var a = r(24634).Buffer, n = r(2683);
      if (!(function(e2) {
        e2.version = "0.20.3";
        var t2, s, i, o, c, l, f, h, u, d, p, m, g, v, b, w, T, y, E, k, x, _, S, A, C, I, O, R, N, F, D, P, L, M, U, B, W, z, H, V, G, X, j, K, Y, Z, J = 1200, q = 1252, Q = [874, 932, 936, 949, 950, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258, 1e4], ee = {
          0: 1252,
          1: 65001,
          2: 65001,
          77: 1e4,
          128: 932,
          129: 949,
          130: 1361,
          134: 936,
          136: 950,
          161: 1253,
          162: 1254,
          163: 1258,
          177: 1255,
          178: 1256,
          186: 1257,
          204: 1251,
          222: 874,
          238: 1250,
          255: 1252,
          69: 6969
        }, et = function(e10) {
          -1 != Q.indexOf(e10) && (q = ee[0] = e10);
        }, er = function(e10) {
          J = e10, et(e10);
        };
        function ea() {
          er(1200), et(1252);
        }
        function en(e10) {
          for (var t10 = [], r10 = 0, a10 = e10.length; r10 < a10; ++r10) t10[r10] = e10.charCodeAt(r10);
          return t10;
        }
        function es(e10) {
          for (var t10 = [], r10 = 0; r10 < e10.length >> 1; ++r10)
            t10[r10] = String.fromCharCode(e10.charCodeAt(2 * r10) + (e10.charCodeAt(2 * r10 + 1) << 8));
          return t10.join("");
        }
        function ei(e10) {
          for (var t10 = [], r10 = 0; r10 < e10.length >> 1; ++r10)
            t10[r10] = String.fromCharCode(e10.charCodeAt(2 * r10 + 1) + (e10.charCodeAt(2 * r10) << 8));
          return t10.join("");
        }
        var eo = function(e10) {
          var t10 = e10.charCodeAt(0), r10 = e10.charCodeAt(1);
          return 255 == t10 && 254 == r10 ? es(e10.slice(2)) : 254 == t10 && 255 == r10 ? ei(e10.slice(2)) : 65279 == t10 ? e10.slice(1) : e10;
        }, ec = function(e10) {
          return String.fromCharCode(e10);
        }, el = function(e10) {
          return String.fromCharCode(e10);
        };
        function ef(e10) {
          G = e10, er = function(e11) {
            J = e11, et(e11);
          }, eo = function(e11) {
            return 255 === e11.charCodeAt(0) && 254 === e11.charCodeAt(1) ? G.utils.decode(1200, en(e11.slice(2))) : e11;
          }, ec = function(e11) {
            return 1200 === J ? String.fromCharCode(e11) : G.utils.decode(J, [255 & e11, e11 >> 8])[0];
          }, el = function(e11) {
            return G.utils.decode(q, [e11])[0];
          }, r1();
        }
        var eh = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        function eu(e10) {
          for (var t10 = "", r10 = 0, a10 = 0, n10 = 0, s10 = 0, i10 = 0, o10 = 0, c10 = 0, l2 = 0; l2 < e10.length; )
            s10 = (r10 = e10.charCodeAt(l2++)) >> 2, i10 = (3 & r10) << 4 | (a10 = e10.charCodeAt(l2++)) >> 4, o10 = (15 & a10) << 2 | (n10 = e10.charCodeAt(l2++)) >> 6, c10 = 63 & n10, isNaN(a10) ? o10 = c10 = 64 : isNaN(n10) && (c10 = 64), t10 += eh.charAt(s10) + eh.charAt(i10) + eh.charAt(o10) + eh.charAt(c10);
          return t10;
        }
        function ed(e10) {
          var t10 = "", r10 = 0, a10 = 0, n10 = 0, s10 = 0, i10 = 0, o10 = 0;
          if ("data:" == e10.slice(0, 5)) {
            var c10 = e10.slice(0, 1024).indexOf(";base64,");
            c10 > -1 && (e10 = e10.slice(c10 + 8));
          }
          e10 = e10.replace(/[^\w\+\/\=]/g, "");
          for (var c10 = 0; c10 < e10.length; )
            t10 += String.fromCharCode(
              (n10 = eh.indexOf(e10.charAt(c10++))) << 2 | (s10 = eh.indexOf(e10.charAt(c10++))) >> 4
            ), r10 = (15 & s10) << 4 | (i10 = eh.indexOf(e10.charAt(c10++))) >> 2, 64 !== i10 && (t10 += String.fromCharCode(r10)), a10 = (3 & i10) << 6 | (o10 = eh.indexOf(e10.charAt(c10++))), 64 !== o10 && (t10 += String.fromCharCode(a10));
          return t10;
        }
        var ep = void 0 !== a && void 0 !== n && void 0 !== n.versions && !!n.versions.node, em = (function() {
          if (void 0 !== a) {
            var e10 = !a.from;
            if (!e10)
              try {
                a.from("foo", "utf8");
              } catch (t10) {
                e10 = true;
              }
            return e10 ? function(e11, t10) {
              return t10 ? new a(e11, t10) : new a(e11);
            } : a.from.bind(a);
          }
          return function() {
          };
        })(), eg = (function() {
          if (void 0 === a) return false;
          var e10 = em([65, 0]);
          return !!e10 && 1 == e10.toString("utf16le").length;
        })();
        function ev(e10) {
          return ep ? a.alloc ? a.alloc(e10) : new a(e10) : "undefined" != typeof Uint8Array ? new Uint8Array(e10) : Array(e10);
        }
        function eb(e10) {
          return ep ? a.allocUnsafe ? a.allocUnsafe(e10) : new a(e10) : "undefined" != typeof Uint8Array ? new Uint8Array(e10) : Array(e10);
        }
        var ew = function(e10) {
          return ep ? em(e10, "binary") : e10.split("").map(function(e11) {
            return 255 & e11.charCodeAt(0);
          });
        };
        function eT(e10) {
          if ("undefined" == typeof ArrayBuffer) return ew(e10);
          for (var t10 = new ArrayBuffer(e10.length), r10 = new Uint8Array(t10), a10 = 0; a10 != e10.length; ++a10)
            r10[a10] = 255 & e10.charCodeAt(a10);
          return t10;
        }
        function ey(e10) {
          if (Array.isArray(e10))
            return e10.map(function(e11) {
              return String.fromCharCode(e11);
            }).join("");
          for (var t10 = [], r10 = 0; r10 < e10.length; ++r10) t10[r10] = String.fromCharCode(e10[r10]);
          return t10.join("");
        }
        function eE(e10) {
          if ("undefined" == typeof ArrayBuffer) throw Error("Unsupported");
          if (e10 instanceof ArrayBuffer) return eE(new Uint8Array(e10));
          for (var t10 = Array(e10.length), r10 = 0; r10 < e10.length; ++r10) t10[r10] = e10[r10];
          return t10;
        }
        var ek = ep ? function(e10) {
          return a.concat(
            e10.map(function(e11) {
              return a.isBuffer(e11) ? e11 : em(e11);
            })
          );
        } : function(e10) {
          if ("undefined" != typeof Uint8Array) {
            var t10 = 0, r10 = 0;
            for (t10 = 0; t10 < e10.length; ++t10) r10 += e10[t10].length;
            var a10 = new Uint8Array(r10), n10 = 0;
            for (t10 = 0, r10 = 0; t10 < e10.length; r10 += n10, ++t10)
              n10 = e10[t10].length, e10[t10] instanceof Uint8Array ? a10.set(e10[t10], r10) : "string" == typeof e10[t10] ? a10.set(new Uint8Array(ew(e10[t10])), r10) : a10.set(new Uint8Array(e10[t10]), r10);
            return a10;
          }
          return [].concat.apply(
            [],
            e10.map(function(e11) {
              return Array.isArray(e11) ? e11 : [].slice.call(e11);
            })
          );
        }, ex = /\u0000/g, e_ = /[\u0001-\u0006]/g;
        function eS(e10) {
          for (var t10 = "", r10 = e10.length - 1; r10 >= 0; ) t10 += e10.charAt(r10--);
          return t10;
        }
        function eA(e10, t10) {
          var r10 = "" + e10;
          return r10.length >= t10 ? r10 : tT("0", t10 - r10.length) + r10;
        }
        function eC(e10, t10) {
          var r10 = "" + e10;
          return r10.length >= t10 ? r10 : tT(" ", t10 - r10.length) + r10;
        }
        function eI(e10, t10) {
          var r10 = "" + e10;
          return r10.length >= t10 ? r10 : r10 + tT(" ", t10 - r10.length);
        }
        function eO(e10, t10) {
          var r10, a10;
          return e10 > 4294967296 || e10 < -4294967296 ? (r10 = "" + Math.round(e10)).length >= t10 ? r10 : tT("0", t10 - r10.length) + r10 : (a10 = "" + Math.round(e10)).length >= t10 ? a10 : tT("0", t10 - a10.length) + a10;
        }
        function eR(e10, t10) {
          return t10 = t10 || 0, e10.length >= 7 + t10 && (32 | e10.charCodeAt(t10)) == 103 && (32 | e10.charCodeAt(t10 + 1)) == 101 && (32 | e10.charCodeAt(t10 + 2)) == 110 && (32 | e10.charCodeAt(t10 + 3)) == 101 && (32 | e10.charCodeAt(t10 + 4)) == 114 && (32 | e10.charCodeAt(t10 + 5)) == 97 && (32 | e10.charCodeAt(t10 + 6)) == 108;
        }
        var eN = [
          ["Sun", "Sunday"],
          ["Mon", "Monday"],
          ["Tue", "Tuesday"],
          ["Wed", "Wednesday"],
          ["Thu", "Thursday"],
          ["Fri", "Friday"],
          ["Sat", "Saturday"]
        ], eF = [
          ["J", "Jan", "January"],
          ["F", "Feb", "February"],
          ["M", "Mar", "March"],
          ["A", "Apr", "April"],
          ["M", "May", "May"],
          ["J", "Jun", "June"],
          ["J", "Jul", "July"],
          ["A", "Aug", "August"],
          ["S", "Sep", "September"],
          ["O", "Oct", "October"],
          ["N", "Nov", "November"],
          ["D", "Dec", "December"]
        ], eD = {
          0: "General",
          1: "0",
          2: "0.00",
          3: "#,##0",
          4: "#,##0.00",
          9: "0%",
          10: "0.00%",
          11: "0.00E+00",
          12: "# ?/?",
          13: "# ??/??",
          14: "m/d/yy",
          15: "d-mmm-yy",
          16: "d-mmm",
          17: "mmm-yy",
          18: "h:mm AM/PM",
          19: "h:mm:ss AM/PM",
          20: "h:mm",
          21: "h:mm:ss",
          22: "m/d/yy h:mm",
          37: "#,##0 ;(#,##0)",
          38: "#,##0 ;[Red](#,##0)",
          39: "#,##0.00;(#,##0.00)",
          40: "#,##0.00;[Red](#,##0.00)",
          45: "mm:ss",
          46: "[h]:mm:ss",
          47: "mmss.0",
          48: "##0.0E+0",
          49: "@",
          56: '"上午/下午 "hh"時"mm"分"ss"秒 "'
        }, eP = {
          5: 37,
          6: 38,
          7: 39,
          8: 40,
          23: 0,
          24: 0,
          25: 0,
          26: 0,
          27: 14,
          28: 14,
          29: 14,
          30: 14,
          31: 14,
          50: 14,
          51: 14,
          52: 14,
          53: 14,
          54: 14,
          55: 14,
          56: 14,
          57: 14,
          58: 14,
          59: 1,
          60: 2,
          61: 3,
          62: 4,
          67: 9,
          68: 10,
          69: 12,
          70: 13,
          71: 14,
          72: 14,
          73: 15,
          74: 16,
          75: 17,
          76: 20,
          77: 21,
          78: 22,
          79: 45,
          80: 46,
          81: 47,
          82: 0
        }, eL = {
          5: '"$"#,##0_);\\("$"#,##0\\)',
          63: '"$"#,##0_);\\("$"#,##0\\)',
          6: '"$"#,##0_);[Red]\\("$"#,##0\\)',
          64: '"$"#,##0_);[Red]\\("$"#,##0\\)',
          7: '"$"#,##0.00_);\\("$"#,##0.00\\)',
          65: '"$"#,##0.00_);\\("$"#,##0.00\\)',
          8: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
          66: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
          41: '_(* #,##0_);_(* \\(#,##0\\);_(* "-"_);_(@_)',
          42: '_("$"* #,##0_);_("$"* \\(#,##0\\);_("$"* "-"_);_(@_)',
          43: '_(* #,##0.00_);_(* \\(#,##0.00\\);_(* "-"??_);_(@_)',
          44: '_("$"* #,##0.00_);_("$"* \\(#,##0.00\\);_("$"* "-"??_);_(@_)'
        };
        function eM(e10, t10, r10) {
          for (var a10 = e10 < 0 ? -1 : 1, n10 = e10 * a10, s10 = 0, i10 = 1, o10 = 0, c10 = 1, l2 = 0, f2 = 0, h2 = Math.floor(n10); l2 < t10 && (o10 = (h2 = Math.floor(n10)) * i10 + s10, f2 = h2 * l2 + c10, !(n10 - h2 < 5e-8)); )
            n10 = 1 / (n10 - h2), s10 = i10, i10 = o10, c10 = l2, l2 = f2;
          if (f2 > t10 && (l2 > t10 ? (f2 = c10, o10 = s10) : (f2 = l2, o10 = i10)), !r10) return [0, a10 * o10, f2];
          var u2 = Math.floor(a10 * o10 / f2);
          return [u2, a10 * o10 - u2 * f2, f2];
        }
        function eU(e10, t10, r10) {
          if (e10 > 2958465 || e10 < 0) return null;
          var a10 = 0 | (e10 = (function(e11) {
            var t11 = e11.toPrecision(16);
            if (t11.indexOf("e") > -1) {
              var r11 = t11.slice(0, t11.indexOf("e"));
              return (r11 = r11.indexOf(".") > -1 ? r11.slice(0, "0." == r11.slice(0, 2) ? 17 : 16) : r11.slice(0, 15) + tT("0", r11.length - 15)) + t11.slice(t11.indexOf("e"));
            }
            return Number(
              t11.indexOf(".") > -1 ? t11.slice(0, "0." == t11.slice(0, 2) ? 17 : 16) : t11.slice(0, 15) + tT("0", t11.length - 15)
            );
          })(e10)), n10 = Math.floor(86400 * (e10 - a10)), s10 = 0, i10 = [], o10 = { D: a10, T: n10, u: 86400 * (e10 - a10) - n10, y: 0, m: 0, d: 0, H: 0, M: 0, S: 0, q: 0 };
          if (1e-6 > Math.abs(o10.u) && (o10.u = 0), t10 && t10.date1904 && (a10 += 1462), o10.u > 0.9999 && (o10.u = 0, 86400 == ++n10 && (o10.T = n10 = 0, ++a10, ++o10.D)), 60 === a10)
            i10 = r10 ? [1317, 10, 29] : [1900, 2, 29], s10 = 3;
          else if (0 === a10) i10 = r10 ? [1317, 8, 29] : [1900, 1, 0], s10 = 6;
          else {
            a10 > 60 && --a10;
            var c10, l2, f2, h2 = new Date(1900, 0, 1);
            h2.setDate(h2.getDate() + a10 - 1), i10 = [h2.getFullYear(), h2.getMonth() + 1, h2.getDate()], s10 = h2.getDay(), a10 < 60 && (s10 = (s10 + 6) % 7), r10 && (c10 = h2, l2 = i10, l2[0] -= 581, f2 = c10.getDay(), c10 < 60 && (f2 = (f2 + 6) % 7), s10 = f2);
          }
          return o10.y = i10[0], o10.m = i10[1], o10.d = i10[2], o10.S = n10 % 60, o10.M = (n10 = Math.floor(n10 / 60)) % 60, o10.H = n10 = Math.floor(n10 / 60), o10.q = s10, o10;
        }
        function eB(e10) {
          return -1 == e10.indexOf(".") ? e10 : e10.replace(/(?:\.0*|(\.\d*[1-9])0+)$/, "$1");
        }
        function eW(e10) {
          if (!isFinite(e10)) return isNaN(e10) ? "#NUM!" : "#DIV/0!";
          var t10, r10, a10, n10, s10, i10 = Math.floor(Math.log(Math.abs(e10)) * Math.LOG10E);
          return i10 >= -4 && i10 <= -1 ? s10 = e10.toPrecision(10 + i10) : 9 >= Math.abs(i10) ? (t10 = e10 < 0 ? 12 : 11, s10 = (r10 = eB(e10.toFixed(12))).length <= t10 || (r10 = e10.toPrecision(10)).length <= t10 ? r10 : e10.toExponential(5)) : s10 = 10 === i10 ? e10.toFixed(10).substr(0, 12) : (a10 = eB(e10.toFixed(11))).length > (e10 < 0 ? 12 : 11) || "0" === a10 || "-0" === a10 ? e10.toPrecision(6) : a10, eB(
            -1 == (n10 = s10.toUpperCase()).indexOf("E") ? n10 : n10.replace(/(?:\.0*|(\.\d*[1-9])0+)[Ee]/, "$1E").replace(/(E[+-])(\d)$/, "$10$2")
          );
        }
        function ez(e10, t10) {
          switch (typeof e10) {
            case "string":
              return e10;
            case "boolean":
              return e10 ? "TRUE" : "FALSE";
            case "number":
              return (0 | e10) === e10 ? e10.toString(10) : eW(e10);
            case "undefined":
              return "";
            case "object":
              if (null == e10) return "";
              if (e10 instanceof Date) return e22(14, tu(e10, t10 && t10.date1904), t10);
          }
          throw Error("unsupported value in General format: " + e10);
        }
        function eH(e10) {
          if (e10.length <= 3) return e10;
          for (var t10 = e10.length % 3, r10 = e10.substr(0, t10); t10 != e10.length; t10 += 3)
            r10 += (r10.length > 0 ? "," : "") + e10.substr(t10, 3);
          return r10;
        }
        var eV = /%/g, e$ = /# (\?+)( ?)\/( ?)(\d+)/, eG = /^#*0*\.([0#]+)/, eX = /\)[^)]*[0#]/, ej = /\(###\) ###\\?-####/;
        function eK(e10) {
          for (var t10, r10 = "", a10 = 0; a10 != e10.length; ++a10)
            switch (t10 = e10.charCodeAt(a10)) {
              case 35:
                break;
              case 63:
                r10 += " ";
                break;
              case 48:
                r10 += "0";
                break;
              default:
                r10 += String.fromCharCode(t10);
            }
          return r10;
        }
        function eY(e10, t10) {
          var r10 = Math.pow(10, t10);
          return "" + Math.round(e10 * r10) / r10;
        }
        function eZ(e10, t10) {
          var r10 = e10 - Math.floor(e10), a10 = Math.pow(10, t10);
          return t10 < ("" + Math.round(r10 * a10)).length ? 0 : Math.round(r10 * a10);
        }
        function eJ(e10, t10, r10) {
          return (0 | r10) === r10 ? (function e11(t11, r11, a10) {
            if (40 === t11.charCodeAt(0) && !r11.match(eX)) {
              var n10, s10 = r11.replace(/\( */, "").replace(/ \)/, "").replace(/\)/, "");
              return a10 >= 0 ? e11("n", s10, a10) : "(" + e11("n", s10, -a10) + ")";
            }
            if (44 === r11.charCodeAt(r11.length - 1)) {
              for (var i10 = r11, o10 = i10.length - 1; 44 === i10.charCodeAt(o10 - 1); ) --o10;
              return eJ(t11, i10.substr(0, o10), a10 / Math.pow(10, 3 * (i10.length - o10)));
            }
            if (-1 !== r11.indexOf("%"))
              return l2 = (c10 = r11).replace(eV, ""), f2 = c10.length - l2.length, eJ(t11, l2, a10 * Math.pow(10, 2 * f2)) + tT("%", f2);
            if (-1 !== r11.indexOf("E"))
              return (function e12(t12, r12) {
                var a11, n11 = t12.indexOf("E") - t12.indexOf(".") - 1;
                if (t12.match(/^#+0.0E\+0$/)) {
                  if (0 == r12) return "0.0E+0";
                  if (r12 < 0) return "-" + e12(t12, -r12);
                  var s11 = t12.indexOf(".");
                  -1 === s11 && (s11 = t12.indexOf("E"));
                  var i11 = Math.floor(Math.log(r12) * Math.LOG10E) % s11;
                  if (i11 < 0 && (i11 += s11), !(a11 = (r12 / Math.pow(10, i11)).toPrecision(n11 + 1 + (s11 + i11) % s11)).match(/[Ee]/)) {
                    var o11 = Math.floor(Math.log(r12) * Math.LOG10E);
                    -1 === a11.indexOf(".") ? a11 = a11.charAt(0) + "." + a11.substr(1) + "E+" + (o11 - a11.length + i11) : a11 += "E+" + (o11 - i11), a11 = a11.replace(/\+-/, "-");
                  }
                  a11 = a11.replace(/^([+-]?)(\d*)\.(\d*)[Ee]/, function(e13, t13, r13, a12) {
                    return t13 + r13 + a12.substr(0, (s11 + i11) % s11) + "." + a12.substr(i11) + "E";
                  });
                } else a11 = r12.toExponential(n11);
                return t12.match(/E\+00$/) && a11.match(/e[+-]\d$/) && (a11 = a11.substr(0, a11.length - 1) + "0" + a11.charAt(a11.length - 1)), t12.match(/E\-/) && a11.match(/e\+/) && (a11 = a11.replace(/e\+/, "e")), a11.replace("e", "E");
              })(r11, a10);
            if (36 === r11.charCodeAt(0)) return "$" + e11(t11, r11.substr(" " == r11.charAt(1) ? 2 : 1), a10);
            var c10, l2, f2, h2, u2, d2, p2, m2 = Math.abs(a10), g2 = a10 < 0 ? "-" : "";
            if (r11.match(/^00+$/)) return g2 + eA(m2, r11.length);
            if (r11.match(/^[#?]+$/))
              return h2 = "" + a10, 0 === a10 && (h2 = ""), h2.length > r11.length ? h2 : eK(r11.substr(0, r11.length - h2.length)) + h2;
            if (u2 = r11.match(e$))
              return g2 + (0 === m2 ? "" : "" + m2) + tT(" ", (n10 = u2)[1].length + 2 + n10[4].length);
            if (r11.match(/^#+0+$/)) return g2 + eA(m2, r11.length - r11.indexOf("0"));
            if (u2 = r11.match(eG))
              return h2 = (h2 = ("" + a10).replace(/^([^\.]+)$/, "$1." + eK(u2[1])).replace(/\.$/, "." + eK(u2[1]))).replace(/\.(\d*)$/, function(e12, t12) {
                return "." + t12 + tT("0", eK(u2[1]).length - t12.length);
              }), -1 !== r11.indexOf("0.") ? h2 : h2.replace(/^0\./, ".");
            if (u2 = (r11 = r11.replace(/^#+([0.])/, "$1")).match(/^(0*)\.(#*)$/))
              return g2 + ("" + m2).replace(/\.(\d*[1-9])0*$/, ".$1").replace(/^(-?\d*)$/, "$1.").replace(/^0\./, u2[1].length ? "0." : ".");
            if (u2 = r11.match(/^#{1,3},##0(\.?)$/)) return g2 + eH("" + m2);
            if (u2 = r11.match(/^#,##0\.([#0]*0)$/))
              return a10 < 0 ? "-" + e11(t11, r11, -a10) : eH("" + a10) + "." + tT("0", u2[1].length);
            if (u2 = r11.match(/^#,#*,#0/)) return e11(t11, r11.replace(/^#,#*,/, ""), a10);
            if (u2 = r11.match(/^([0#]+)(\\?-([0#]+))+$/))
              return h2 = eS(e11(t11, r11.replace(/[\\-]/g, ""), a10)), d2 = 0, eS(
                eS(r11.replace(/\\/g, "")).replace(/[0#]/g, function(e12) {
                  return d2 < h2.length ? h2.charAt(d2++) : "0" === e12 ? "0" : "";
                })
              );
            if (r11.match(ej))
              return "(" + (h2 = e11(t11, "##########", a10)).substr(0, 3) + ") " + h2.substr(3, 3) + "-" + h2.substr(6);
            var v2 = "";
            if (u2 = r11.match(/^([#0?]+)( ?)\/( ?)([#0?]+)/))
              return p2 = eM(m2, Math.pow(10, d2 = Math.min(u2[4].length, 7)) - 1, false), h2 = "" + g2, " " == (v2 = eJ("n", u2[1], p2[1])).charAt(v2.length - 1) && (v2 = v2.substr(0, v2.length - 1) + "0"), h2 += v2 + u2[2] + "/" + u2[3], (v2 = eI(p2[2], d2)).length < u2[4].length && (v2 = eK(u2[4].substr(u2[4].length - v2.length)) + v2), h2 += v2;
            if (u2 = r11.match(/^# ([#0?]+)( ?)\/( ?)([#0?]+)/))
              return g2 + ((p2 = eM(m2, Math.pow(10, d2 = Math.min(Math.max(u2[1].length, u2[4].length), 7)) - 1, true))[0] || (p2[1] ? "" : "0")) + " " + (p2[1] ? eC(p2[1], d2) + u2[2] + "/" + u2[3] + eI(p2[2], d2) : tT(" ", 2 * d2 + 1 + u2[2].length + u2[3].length));
            if (u2 = r11.match(/^[#0?]+$/))
              return (h2 = "" + a10, r11.length <= h2.length) ? h2 : eK(r11.substr(0, r11.length - h2.length)) + h2;
            if (u2 = r11.match(/^([#0]+)\.([#0]+)$/)) {
              d2 = (h2 = "" + a10.toFixed(Math.min(u2[2].length, 10)).replace(/([^0])0+$/, "$1")).indexOf(".");
              var b2 = r11.indexOf(".") - d2, w2 = r11.length - h2.length - b2;
              return eK(r11.substr(0, b2) + h2 + r11.substr(r11.length - w2));
            }
            if (u2 = r11.match(/^00,000\.([#0]*0)$/))
              return a10 < 0 ? "-" + e11(t11, r11, -a10) : eH("" + a10).replace(/^\d,\d{3}$/, "0$&").replace(/^\d*$/, function(e12) {
                return "00," + (e12.length < 3 ? eA(0, 3 - e12.length) : "") + e12;
              }) + "." + eA(0, u2[1].length);
            switch (r11) {
              case "###,###":
              case "##,###":
              case "#,###":
                var T2 = eH("" + m2);
                return "0" !== T2 ? g2 + T2 : "";
              default:
                if (r11.match(/\.[0#?]*$/))
                  return e11(t11, r11.slice(0, r11.lastIndexOf(".")), a10) + eK(r11.slice(r11.lastIndexOf(".")));
            }
            throw Error("unsupported format |" + r11 + "|");
          })(e10, t10, r10) : (function e11(t11, r11, a10) {
            if (40 === t11.charCodeAt(0) && !r11.match(eX)) {
              var n10, s10, i10, o10, c10, l2, f2 = r11.replace(/\( */, "").replace(/ \)/, "").replace(/\)/, "");
              return a10 >= 0 ? e11("n", f2, a10) : "(" + e11("n", f2, -a10) + ")";
            }
            if (44 === r11.charCodeAt(r11.length - 1)) {
              for (var h2 = r11, u2 = h2.length - 1; 44 === h2.charCodeAt(u2 - 1); ) --u2;
              return eJ(t11, h2.substr(0, u2), a10 / Math.pow(10, 3 * (h2.length - u2)));
            }
            if (-1 !== r11.indexOf("%"))
              return p2 = (d2 = r11).replace(eV, ""), m2 = d2.length - p2.length, eJ(t11, p2, a10 * Math.pow(10, 2 * m2)) + tT("%", m2);
            if (-1 !== r11.indexOf("E"))
              return (function e12(t12, r12) {
                var a11, n11 = t12.indexOf("E") - t12.indexOf(".") - 1;
                if (t12.match(/^#+0.0E\+0$/)) {
                  if (0 == r12) return "0.0E+0";
                  if (r12 < 0) return "-" + e12(t12, -r12);
                  var s11 = t12.indexOf(".");
                  -1 === s11 && (s11 = t12.indexOf("E"));
                  var i11 = Math.floor(Math.log(r12) * Math.LOG10E) % s11;
                  if (i11 < 0 && (i11 += s11), -1 === (a11 = (r12 / Math.pow(10, i11)).toPrecision(n11 + 1 + (s11 + i11) % s11)).indexOf("e")) {
                    var o11 = Math.floor(Math.log(r12) * Math.LOG10E);
                    for (-1 === a11.indexOf(".") ? a11 = a11.charAt(0) + "." + a11.substr(1) + "E+" + (o11 - a11.length + i11) : a11 += "E+" + (o11 - i11); "0." === a11.substr(0, 2); )
                      a11 = (a11 = a11.charAt(0) + a11.substr(2, s11) + "." + a11.substr(2 + s11)).replace(/^0+([1-9])/, "$1").replace(/^0+\./, "0.");
                    a11 = a11.replace(/\+-/, "-");
                  }
                  a11 = a11.replace(/^([+-]?)(\d*)\.(\d*)[Ee]/, function(e13, t13, r13, a12) {
                    return t13 + r13 + a12.substr(0, (s11 + i11) % s11) + "." + a12.substr(i11) + "E";
                  });
                } else a11 = r12.toExponential(n11);
                return t12.match(/E\+00$/) && a11.match(/e[+-]\d$/) && (a11 = a11.substr(0, a11.length - 1) + "0" + a11.charAt(a11.length - 1)), t12.match(/E\-/) && a11.match(/e\+/) && (a11 = a11.replace(/e\+/, "e")), a11.replace("e", "E");
              })(r11, a10);
            if (36 === r11.charCodeAt(0)) return "$" + e11(t11, r11.substr(" " == r11.charAt(1) ? 2 : 1), a10);
            var d2, p2, m2, g2, v2, b2, w2, T2 = Math.abs(a10), y2 = a10 < 0 ? "-" : "";
            if (r11.match(/^00+$/)) return y2 + eO(T2, r11.length);
            if (r11.match(/^[#?]+$/))
              return "0" === (g2 = eO(a10, 0)) && (g2 = ""), g2.length > r11.length ? g2 : eK(r11.substr(0, r11.length - g2.length)) + g2;
            if (v2 = r11.match(e$))
              return o10 = Math.floor((i10 = Math.round(T2 * (s10 = parseInt((n10 = v2)[4], 10)))) / s10), c10 = i10 - o10 * s10, y2 + (0 === o10 ? "" : "" + o10) + " " + (0 === c10 ? tT(" ", n10[1].length + 1 + n10[4].length) : eC(c10, n10[1].length) + n10[2] + "/" + n10[3] + eA(s10, n10[4].length));
            if (r11.match(/^#+0+$/)) return y2 + eO(T2, r11.length - r11.indexOf("0"));
            if (v2 = r11.match(eG))
              return g2 = eY(a10, v2[1].length).replace(/^([^\.]+)$/, "$1." + eK(v2[1])).replace(/\.$/, "." + eK(v2[1])).replace(/\.(\d*)$/, function(e12, t12) {
                return "." + t12 + tT("0", eK(v2[1]).length - t12.length);
              }), -1 !== r11.indexOf("0.") ? g2 : g2.replace(/^0\./, ".");
            if (v2 = (r11 = r11.replace(/^#+([0.])/, "$1")).match(/^(0*)\.(#*)$/))
              return y2 + eY(T2, v2[2].length).replace(/\.(\d*[1-9])0*$/, ".$1").replace(/^(-?\d*)$/, "$1.").replace(/^0\./, v2[1].length ? "0." : ".");
            if (v2 = r11.match(/^#{1,3},##0(\.?)$/)) return y2 + eH(eO(T2, 0));
            if (v2 = r11.match(/^#,##0\.([#0]*0)$/))
              return a10 < 0 ? "-" + e11(t11, r11, -a10) : eH(
                "" + (Math.floor(a10) + +((l2 = v2[1].length) < ("" + Math.round((a10 - Math.floor(a10)) * Math.pow(10, l2))).length))
              ) + "." + eA(eZ(a10, v2[1].length), v2[1].length);
            if (v2 = r11.match(/^#,#*,#0/)) return e11(t11, r11.replace(/^#,#*,/, ""), a10);
            if (v2 = r11.match(/^([0#]+)(\\?-([0#]+))+$/))
              return g2 = eS(e11(t11, r11.replace(/[\\-]/g, ""), a10)), b2 = 0, eS(
                eS(r11.replace(/\\/g, "")).replace(/[0#]/g, function(e12) {
                  return b2 < g2.length ? g2.charAt(b2++) : "0" === e12 ? "0" : "";
                })
              );
            if (r11.match(ej))
              return "(" + (g2 = e11(t11, "##########", a10)).substr(0, 3) + ") " + g2.substr(3, 3) + "-" + g2.substr(6);
            var E2 = "";
            if (v2 = r11.match(/^([#0?]+)( ?)\/( ?)([#0?]+)/))
              return w2 = eM(T2, Math.pow(10, b2 = Math.min(v2[4].length, 7)) - 1, false), g2 = "" + y2, " " == (E2 = eJ("n", v2[1], w2[1])).charAt(E2.length - 1) && (E2 = E2.substr(0, E2.length - 1) + "0"), g2 += E2 + v2[2] + "/" + v2[3], (E2 = eI(w2[2], b2)).length < v2[4].length && (E2 = eK(v2[4].substr(v2[4].length - E2.length)) + E2), g2 += E2;
            if (v2 = r11.match(/^# ([#0?]+)( ?)\/( ?)([#0?]+)/))
              return y2 + ((w2 = eM(T2, Math.pow(10, b2 = Math.min(Math.max(v2[1].length, v2[4].length), 7)) - 1, true))[0] || (w2[1] ? "" : "0")) + " " + (w2[1] ? eC(w2[1], b2) + v2[2] + "/" + v2[3] + eI(w2[2], b2) : tT(" ", 2 * b2 + 1 + v2[2].length + v2[3].length));
            if (v2 = r11.match(/^[#0?]+$/))
              return (g2 = eO(a10, 0), r11.length <= g2.length) ? g2 : eK(r11.substr(0, r11.length - g2.length)) + g2;
            if (v2 = r11.match(/^([#0?]+)\.([#0]+)$/)) {
              b2 = (g2 = "" + a10.toFixed(Math.min(v2[2].length, 10)).replace(/([^0])0+$/, "$1")).indexOf(".");
              var k2 = r11.indexOf(".") - b2, x2 = r11.length - g2.length - k2;
              return eK(r11.substr(0, k2) + g2 + r11.substr(r11.length - x2));
            }
            if (v2 = r11.match(/^00,000\.([#0]*0)$/))
              return b2 = eZ(a10, v2[1].length), a10 < 0 ? "-" + e11(t11, r11, -a10) : eH(
                a10 < 2147483647 && a10 > -2147483648 ? "" + (a10 >= 0 ? 0 | a10 : a10 - 1 | 0) : "" + Math.floor(a10)
              ).replace(/^\d,\d{3}$/, "0$&").replace(/^\d*$/, function(e12) {
                return "00," + (e12.length < 3 ? eA(0, 3 - e12.length) : "") + e12;
              }) + "." + eA(b2, v2[1].length);
            switch (r11) {
              case "###,##0.00":
                return e11(t11, "#,##0.00", a10);
              case "###,###":
              case "##,###":
              case "#,###":
                var _2 = eH(eO(T2, 0));
                return "0" !== _2 ? y2 + _2 : "";
              case "###,###.00":
                return e11(t11, "###,##0.00", a10).replace(/^0\./, ".");
              case "#,###.00":
                return e11(t11, "#,##0.00", a10).replace(/^0\./, ".");
            }
            throw Error("unsupported format |" + r11 + "|");
          })(e10, t10, r10);
        }
        var eq = /\[[HhMmSs\u0E0A\u0E19\u0E17]*\]/;
        function eQ(e10) {
          for (var t10 = 0, r10 = "", a10 = ""; t10 < e10.length; )
            switch (r10 = e10.charAt(t10)) {
              case "G":
                eR(e10, t10) && (t10 += 6), t10++;
                break;
              case '"':
                for (; 34 !== e10.charCodeAt(++t10) && t10 < e10.length; ) ;
                ++t10;
                break;
              case "\\":
              case "_":
                t10 += 2;
                break;
              case "@":
                ++t10;
                break;
              case "B":
              case "b":
                if ("1" === e10.charAt(t10 + 1) || "2" === e10.charAt(t10 + 1)) return true;
              case "M":
              case "D":
              case "Y":
              case "H":
              case "S":
              case "E":
              case "m":
              case "d":
              case "y":
              case "h":
              case "s":
              case "e":
              case "g":
                return true;
              case "A":
              case "a":
              case "上":
                if ("A/P" === e10.substr(t10, 3).toUpperCase() || "AM/PM" === e10.substr(t10, 5).toUpperCase() || "上午/下午" === e10.substr(t10, 5).toUpperCase())
                  return true;
                ++t10;
                break;
              case "[":
                for (a10 = r10; "]" !== e10.charAt(t10++) && t10 < e10.length; ) a10 += e10.charAt(t10);
                if (a10.match(eq)) return true;
                break;
              case ".":
              case "0":
              case "#":
                for (; t10 < e10.length && ("0#?.,E+-%".indexOf(r10 = e10.charAt(++t10)) > -1 || "\\" == r10 && "-" == e10.charAt(t10 + 1) && "0#".indexOf(e10.charAt(t10 + 2)) > -1); ) ;
                break;
              case "?":
                for (; e10.charAt(++t10) === r10; ) ;
                break;
              case "*":
                ++t10, (" " == e10.charAt(t10) || "*" == e10.charAt(t10)) && ++t10;
                break;
              case "(":
              case ")":
              case " ":
              default:
                ++t10;
                break;
              case "1":
              case "2":
              case "3":
              case "4":
              case "5":
              case "6":
              case "7":
              case "8":
              case "9":
                for (; t10 < e10.length && "0123456789".indexOf(e10.charAt(++t10)) > -1; ) ;
            }
          return false;
        }
        var e0 = /\[(=|>[=]?|<[>=]?)(-?\d+(?:\.\d*)?)\]/;
        function e1(e10, t10) {
          if (null == t10) return false;
          var r10 = parseFloat(t10[2]);
          switch (t10[1]) {
            case "=":
              if (e10 == r10) return true;
              break;
            case ">":
              if (e10 > r10) return true;
              break;
            case "<":
              if (e10 < r10) return true;
              break;
            case "<>":
              if (e10 != r10) return true;
              break;
            case ">=":
              if (e10 >= r10) return true;
              break;
            case "<=":
              if (e10 <= r10) return true;
          }
          return false;
        }
        function e22(e10, t10, r10) {
          null == r10 && (r10 = {});
          var a10 = "";
          switch (typeof e10) {
            case "string":
              a10 = "m/d/yy" == e10 && r10.dateNF ? r10.dateNF : e10;
              break;
            case "number":
              null == (a10 = 14 == e10 && r10.dateNF ? r10.dateNF : (null != r10.table ? r10.table : eD)[e10]) && (a10 = r10.table && r10.table[eP[e10]] || eD[eP[e10]]), null == a10 && (a10 = eL[e10] || "General");
          }
          if (eR(a10, 0)) return ez(t10, r10);
          t10 instanceof Date && (t10 = tu(t10, r10.date1904));
          var n10 = (function(e11, t11) {
            var r11 = (function(e12) {
              for (var t12 = [], r12 = false, a12 = 0, n12 = 0; a12 < e12.length; ++a12)
                switch (e12.charCodeAt(a12)) {
                  case 34:
                    r12 = !r12;
                    break;
                  case 95:
                  case 42:
                  case 92:
                    ++a12;
                    break;
                  case 59:
                    t12[t12.length] = e12.substr(n12, a12 - n12), n12 = a12 + 1;
                }
              if (t12[t12.length] = e12.substr(n12), true === r12) throw Error("Format |" + e12 + "| unterminated string ");
              return t12;
            })(e11), a11 = r11.length, n11 = r11[a11 - 1].indexOf("@");
            if (a11 < 4 && n11 > -1 && --a11, r11.length > 4)
              throw Error("cannot find right format for |" + r11.join("|") + "|");
            if ("number" != typeof t11) return [4, 4 === r11.length || n11 > -1 ? r11[r11.length - 1] : "@"];
            switch ("number" == typeof t11 && !isFinite(t11) && (t11 = 0), r11.length) {
              case 1:
                r11 = n11 > -1 ? ["General", "General", "General", r11[0]] : [r11[0], r11[0], r11[0], "@"];
                break;
              case 2:
                r11 = n11 > -1 ? [r11[0], r11[0], r11[0], r11[1]] : [r11[0], r11[1], r11[0], "@"];
                break;
              case 3:
                r11 = n11 > -1 ? [r11[0], r11[1], r11[0], r11[2]] : [r11[0], r11[1], r11[2], "@"];
            }
            var s10 = t11 > 0 ? r11[0] : t11 < 0 ? r11[1] : r11[2];
            if (-1 === r11[0].indexOf("[") && -1 === r11[1].indexOf("[")) return [a11, s10];
            if (null != r11[0].match(/\[[=<>]/) || null != r11[1].match(/\[[=<>]/)) {
              var i10 = r11[0].match(e0), o10 = r11[1].match(e0);
              return e1(t11, i10) ? [a11, r11[0]] : e1(t11, o10) ? [a11, r11[1]] : [a11, r11[null != i10 && null != o10 ? 2 : 1]];
            }
            return [a11, s10];
          })(a10, t10);
          if (eR(n10[1])) return ez(t10, r10);
          if (true === t10) t10 = "TRUE";
          else if (false === t10) t10 = "FALSE";
          else if ("" === t10 || null == t10) return "";
          else if (isNaN(t10) && n10[1].indexOf("0") > -1) return "#NUM!";
          else if (!isFinite(t10) && n10[1].indexOf("0") > -1) return "#DIV/0!";
          return (function(e11, t11, r11, a11) {
            for (var n11, s10, i10, o10 = [], c10 = "", l2 = 0, f2 = "", h2 = "t", u2 = "H"; l2 < e11.length; )
              switch (f2 = e11.charAt(l2)) {
                case "G":
                  if (!eR(e11, l2)) throw Error("unrecognized character " + f2 + " in " + e11);
                  o10[o10.length] = { t: "G", v: "General" }, l2 += 7;
                  break;
                case '"':
                  for (c10 = ""; 34 !== (i10 = e11.charCodeAt(++l2)) && l2 < e11.length; ) c10 += String.fromCharCode(i10);
                  o10[o10.length] = { t: "t", v: c10 }, ++l2;
                  break;
                case "\\":
                  var d2 = e11.charAt(++l2), p2 = "(" === d2 || ")" === d2 ? d2 : "t";
                  o10[o10.length] = { t: p2, v: d2 }, ++l2;
                  break;
                case "_":
                  o10[o10.length] = { t: "t", v: " " }, l2 += 2;
                  break;
                case "@":
                  o10[o10.length] = { t: "T", v: t11 }, ++l2;
                  break;
                case "B":
                case "b":
                  if ("1" === e11.charAt(l2 + 1) || "2" === e11.charAt(l2 + 1)) {
                    if (null == n11 && null == (n11 = eU(t11, r11, "2" === e11.charAt(l2 + 1)))) return "";
                    o10[o10.length] = { t: "X", v: e11.substr(l2, 2) }, h2 = f2, l2 += 2;
                    break;
                  }
                case "M":
                case "D":
                case "Y":
                case "H":
                case "S":
                case "E":
                  f2 = f2.toLowerCase();
                case "m":
                case "d":
                case "y":
                case "h":
                case "s":
                case "e":
                case "g":
                  if (t11 < 0 || null == n11 && null == (n11 = eU(t11, r11))) return "";
                  for (c10 = f2; ++l2 < e11.length && e11.charAt(l2).toLowerCase() === f2; ) c10 += f2;
                  "m" === f2 && "h" === h2.toLowerCase() && (f2 = "M"), "h" === f2 && (f2 = u2), o10[o10.length] = { t: f2, v: c10 }, h2 = f2;
                  break;
                case "A":
                case "a":
                case "上":
                  var m2 = { t: f2, v: f2 };
                  if (null == n11 && (n11 = eU(t11, r11)), "A/P" === e11.substr(l2, 3).toUpperCase() ? (null != n11 && (m2.v = n11.H >= 12 ? e11.charAt(l2 + 2) : f2), m2.t = "T", u2 = "h", l2 += 3) : "AM/PM" === e11.substr(l2, 5).toUpperCase() ? (null != n11 && (m2.v = n11.H >= 12 ? "PM" : "AM"), m2.t = "T", l2 += 5, u2 = "h") : "上午/下午" === e11.substr(l2, 5).toUpperCase() ? (null != n11 && (m2.v = n11.H >= 12 ? "下午" : "上午"), m2.t = "T", l2 += 5, u2 = "h") : (m2.t = "t", ++l2), null == n11 && "T" === m2.t)
                    return "";
                  o10[o10.length] = m2, h2 = f2;
                  break;
                case "[":
                  for (c10 = f2; "]" !== e11.charAt(l2++) && l2 < e11.length; ) c10 += e11.charAt(l2);
                  if ("]" !== c10.slice(-1)) throw 'unterminated "[" block: |' + c10 + "|";
                  if (c10.match(eq)) {
                    if (null == n11 && null == (n11 = eU(t11, r11))) return "";
                    o10[o10.length] = { t: "Z", v: c10.toLowerCase() }, h2 = c10.charAt(1);
                  } else
                    c10.indexOf("$") > -1 && (c10 = (c10.match(/\$([^-\[\]]*)/) || [])[1] || "$", eQ(e11) || (o10[o10.length] = { t: "t", v: c10 }));
                  break;
                case ".":
                  if (null != n11) {
                    for (c10 = f2; ++l2 < e11.length && "0" === (f2 = e11.charAt(l2)); ) c10 += f2;
                    o10[o10.length] = { t: "s", v: c10 };
                    break;
                  }
                case "0":
                case "#":
                  for (c10 = f2; ++l2 < e11.length && "0#?.,E+-%".indexOf(f2 = e11.charAt(l2)) > -1; ) c10 += f2;
                  o10[o10.length] = { t: "n", v: c10 };
                  break;
                case "?":
                  for (c10 = f2; e11.charAt(++l2) === f2; ) c10 += f2;
                  o10[o10.length] = { t: f2, v: c10 }, h2 = f2;
                  break;
                case "*":
                  ++l2, (" " == e11.charAt(l2) || "*" == e11.charAt(l2)) && ++l2;
                  break;
                case "(":
                case ")":
                  o10[o10.length] = { t: 1 === a11 ? "t" : f2, v: f2 }, ++l2;
                  break;
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                  for (c10 = f2; l2 < e11.length && "0123456789".indexOf(e11.charAt(++l2)) > -1; ) c10 += e11.charAt(l2);
                  o10[o10.length] = { t: "D", v: c10 };
                  break;
                case " ":
                  o10[o10.length] = { t: f2, v: f2 }, ++l2;
                  break;
                case "$":
                  o10[o10.length] = { t: "t", v: "$" }, ++l2;
                  break;
                default:
                  if (-1 === ",$-+/():!^&'~{}<>=€acfijklopqrtuvwxzP".indexOf(f2))
                    throw Error("unrecognized character " + f2 + " in " + e11);
                  o10[o10.length] = { t: "t", v: f2 }, ++l2;
              }
            var g2, v2 = 0, b2 = 0;
            for (l2 = o10.length - 1, h2 = "t"; l2 >= 0; --l2)
              switch (o10[l2].t) {
                case "h":
                case "H":
                  o10[l2].t = u2, h2 = "h", v2 < 1 && (v2 = 1);
                  break;
                case "s":
                  (g2 = o10[l2].v.match(/\.0+$/)) && (b2 = Math.max(b2, g2[0].length - 1), v2 = 4), v2 < 3 && (v2 = 3);
                case "d":
                case "y":
                case "e":
                  h2 = o10[l2].t;
                  break;
                case "M":
                  h2 = o10[l2].t, v2 < 2 && (v2 = 2);
                  break;
                case "m":
                  "s" === h2 && (o10[l2].t = "M", v2 < 2 && (v2 = 2));
                  break;
                case "X":
                  break;
                case "Z":
                  v2 < 1 && o10[l2].v.match(/[Hh]/) && (v2 = 1), v2 < 2 && o10[l2].v.match(/[Mm]/) && (v2 = 2), v2 < 3 && o10[l2].v.match(/[Ss]/) && (v2 = 3);
              }
            switch (v2) {
              case 0:
                break;
              case 1:
              case 2:
              case 3:
                n11.u >= 0.5 && (n11.u = 0, ++n11.S), n11.S >= 60 && (n11.S = 0, ++n11.M), n11.M >= 60 && (n11.M = 0, ++n11.H), n11.H >= 24 && (n11.H = 0, ++n11.D, (w2 = eU(n11.D)).u = n11.u, w2.S = n11.S, w2.M = n11.M, w2.H = n11.H, n11 = w2);
                break;
              case 4:
                switch (b2) {
                  case 1:
                    n11.u = Math.round(10 * n11.u) / 10;
                    break;
                  case 2:
                    n11.u = Math.round(100 * n11.u) / 100;
                    break;
                  case 3:
                    n11.u = Math.round(1e3 * n11.u) / 1e3;
                }
                n11.u >= 1 && (n11.u = 0, ++n11.S), n11.S >= 60 && (n11.S = 0, ++n11.M), n11.M >= 60 && (n11.M = 0, ++n11.H), n11.H >= 24 && (n11.H = 0, ++n11.D, (w2 = eU(n11.D)).u = n11.u, w2.S = n11.S, w2.M = n11.M, w2.H = n11.H, n11 = w2);
            }
            var w2, T2, y2 = "";
            for (l2 = 0; l2 < o10.length; ++l2)
              switch (o10[l2].t) {
                case "t":
                case "T":
                case " ":
                case "D":
                  break;
                case "X":
                  o10[l2].v = "", o10[l2].t = ";";
                  break;
                case "d":
                case "m":
                case "y":
                case "h":
                case "H":
                case "M":
                case "s":
                case "e":
                case "b":
                case "Z":
                  o10[l2].v = (function(e12, t12, r12, a12) {
                    var n12, s11 = "", i11 = 0, o11 = 0, c11 = r12.y, l3 = 0;
                    switch (e12) {
                      case 98:
                        c11 = r12.y + 543;
                      case 121:
                        switch (t12.length) {
                          case 1:
                          case 2:
                            n12 = c11 % 100, l3 = 2;
                            break;
                          default:
                            n12 = c11 % 1e4, l3 = 4;
                        }
                        break;
                      case 109:
                        switch (t12.length) {
                          case 1:
                          case 2:
                            n12 = r12.m, l3 = t12.length;
                            break;
                          case 3:
                            return eF[r12.m - 1][1];
                          case 5:
                            return eF[r12.m - 1][0];
                          default:
                            return eF[r12.m - 1][2];
                        }
                        break;
                      case 100:
                        switch (t12.length) {
                          case 1:
                          case 2:
                            n12 = r12.d, l3 = t12.length;
                            break;
                          case 3:
                            return eN[r12.q][0];
                          default:
                            return eN[r12.q][1];
                        }
                        break;
                      case 104:
                        switch (t12.length) {
                          case 1:
                          case 2:
                            n12 = 1 + (r12.H + 11) % 12, l3 = t12.length;
                            break;
                          default:
                            throw "bad hour format: " + t12;
                        }
                        break;
                      case 72:
                        switch (t12.length) {
                          case 1:
                          case 2:
                            n12 = r12.H, l3 = t12.length;
                            break;
                          default:
                            throw "bad hour format: " + t12;
                        }
                        break;
                      case 77:
                        switch (t12.length) {
                          case 1:
                          case 2:
                            n12 = r12.M, l3 = t12.length;
                            break;
                          default:
                            throw "bad minute format: " + t12;
                        }
                        break;
                      case 115:
                        if ("s" != t12 && "ss" != t12 && ".0" != t12 && ".00" != t12 && ".000" != t12)
                          throw "bad second format: " + t12;
                        if (0 === r12.u && ("s" == t12 || "ss" == t12)) return eA(r12.S, t12.length);
                        if ((i11 = Math.round((o11 = a12 >= 2 ? 3 === a12 ? 1e3 : 100 : 1 === a12 ? 10 : 1) * (r12.S + r12.u))) >= 60 * o11 && (i11 = 0), "s" === t12)
                          return 0 === i11 ? "0" : "" + i11 / o11;
                        if (s11 = eA(i11, 2 + a12), "ss" === t12) return s11.substr(0, 2);
                        return "." + s11.substr(2, t12.length - 1);
                      case 90:
                        switch (t12) {
                          case "[h]":
                          case "[hh]":
                            n12 = 24 * r12.D + r12.H;
                            break;
                          case "[m]":
                          case "[mm]":
                            n12 = (24 * r12.D + r12.H) * 60 + r12.M;
                            break;
                          case "[s]":
                          case "[ss]":
                            n12 = ((24 * r12.D + r12.H) * 60 + r12.M) * 60 + (0 == a12 ? Math.round(r12.S + r12.u) : r12.S);
                            break;
                          default:
                            throw "bad abstime format: " + t12;
                        }
                        l3 = 3 === t12.length ? 1 : 2;
                        break;
                      case 101:
                        n12 = c11, l3 = 1;
                    }
                    return l3 > 0 ? eA(n12, l3) : "";
                  })(o10[l2].t.charCodeAt(0), o10[l2].v, n11, b2), o10[l2].t = "t";
                  break;
                case "n":
                case "?":
                  for (T2 = l2 + 1; null != o10[T2] && ("?" === (f2 = o10[T2].t) || "D" === f2 || (" " === f2 || "t" === f2) && null != o10[T2 + 1] && ("?" === o10[T2 + 1].t || "t" === o10[T2 + 1].t && "/" === o10[T2 + 1].v) || "(" === o10[l2].t && (" " === f2 || "n" === f2 || ")" === f2) || "t" === f2 && ("/" === o10[T2].v || " " === o10[T2].v && null != o10[T2 + 1] && "?" == o10[T2 + 1].t)); )
                    o10[l2].v += o10[T2].v, o10[T2] = { v: "", t: ";" }, ++T2;
                  y2 += o10[l2].v, l2 = T2 - 1;
                  break;
                case "G":
                  o10[l2].t = "t", o10[l2].v = ez(t11, r11);
              }
            var E2, k2, x2 = "";
            if (y2.length > 0) {
              40 == y2.charCodeAt(0) ? (E2 = t11 < 0 && 45 === y2.charCodeAt(0) ? -t11 : t11, k2 = eJ("n", y2, E2)) : (k2 = eJ("n", y2, E2 = t11 < 0 && a11 > 1 ? -t11 : t11), E2 < 0 && o10[0] && "t" == o10[0].t && (k2 = k2.substr(1), o10[0].v = "-" + o10[0].v)), T2 = k2.length - 1;
              var _2 = o10.length;
              for (l2 = 0; l2 < o10.length; ++l2)
                if (null != o10[l2] && "t" != o10[l2].t && o10[l2].v.indexOf(".") > -1) {
                  _2 = l2;
                  break;
                }
              var S2 = o10.length;
              if (_2 === o10.length && -1 === k2.indexOf("E")) {
                for (l2 = o10.length - 1; l2 >= 0; --l2)
                  null != o10[l2] && -1 !== "n?".indexOf(o10[l2].t) && (T2 >= o10[l2].v.length - 1 ? (T2 -= o10[l2].v.length, o10[l2].v = k2.substr(T2 + 1, o10[l2].v.length)) : T2 < 0 ? o10[l2].v = "" : (o10[l2].v = k2.substr(0, T2 + 1), T2 = -1), o10[l2].t = "t", S2 = l2);
                T2 >= 0 && S2 < o10.length && (o10[S2].v = k2.substr(0, T2 + 1) + o10[S2].v);
              } else if (_2 !== o10.length && -1 === k2.indexOf("E")) {
                for (T2 = k2.indexOf(".") - 1, l2 = _2; l2 >= 0; --l2)
                  if (null != o10[l2] && -1 !== "n?".indexOf(o10[l2].t)) {
                    for (s10 = o10[l2].v.indexOf(".") > -1 && l2 === _2 ? o10[l2].v.indexOf(".") - 1 : o10[l2].v.length - 1, x2 = o10[l2].v.substr(s10 + 1); s10 >= 0; --s10)
                      T2 >= 0 && ("0" === o10[l2].v.charAt(s10) || "#" === o10[l2].v.charAt(s10)) && (x2 = k2.charAt(T2--) + x2);
                    o10[l2].v = x2, o10[l2].t = "t", S2 = l2;
                  }
                for (T2 >= 0 && S2 < o10.length && (o10[S2].v = k2.substr(0, T2 + 1) + o10[S2].v), T2 = k2.indexOf(".") + 1, l2 = _2; l2 < o10.length; ++l2)
                  if (null != o10[l2] && (-1 !== "n?(".indexOf(o10[l2].t) || l2 === _2)) {
                    for (s10 = o10[l2].v.indexOf(".") > -1 && l2 === _2 ? o10[l2].v.indexOf(".") + 1 : 0, x2 = o10[l2].v.substr(0, s10); s10 < o10[l2].v.length; ++s10)
                      T2 < k2.length && (x2 += k2.charAt(T2++));
                    o10[l2].v = x2, o10[l2].t = "t", S2 = l2;
                  }
              }
            }
            for (l2 = 0; l2 < o10.length; ++l2)
              null != o10[l2] && "n?".indexOf(o10[l2].t) > -1 && (E2 = a11 > 1 && t11 < 0 && l2 > 0 && "-" === o10[l2 - 1].v ? -t11 : t11, o10[l2].v = eJ(o10[l2].t, o10[l2].v, E2), o10[l2].t = "t");
            var A2 = "";
            for (l2 = 0; l2 !== o10.length; ++l2) null != o10[l2] && (A2 += o10[l2].v);
            return A2;
          })(n10[1], t10, r10, n10[0]);
        }
        function e4(e10, t10) {
          if ("number" != typeof t10) {
            t10 = +t10 || -1;
            for (var r10 = 0; r10 < 392; ++r10) {
              if (void 0 == eD[r10]) {
                t10 < 0 && (t10 = r10);
                continue;
              }
              if (eD[r10] == e10) {
                t10 = r10;
                break;
              }
            }
            t10 < 0 && (t10 = 391);
          }
          return eD[t10] = e10, t10;
        }
        function e3(e10) {
          for (var t10 = 0; 392 != t10; ++t10) void 0 !== e10[t10] && e4(e10[t10], t10);
        }
        function e5() {
          var e10;
          e10 || (e10 = {}), e10[0] = "General", e10[1] = "0", e10[2] = "0.00", e10[3] = "#,##0", e10[4] = "#,##0.00", e10[9] = "0%", e10[10] = "0.00%", e10[11] = "0.00E+00", e10[12] = "# ?/?", e10[13] = "# ??/??", e10[14] = "m/d/yy", e10[15] = "d-mmm-yy", e10[16] = "d-mmm", e10[17] = "mmm-yy", e10[18] = "h:mm AM/PM", e10[19] = "h:mm:ss AM/PM", e10[20] = "h:mm", e10[21] = "h:mm:ss", e10[22] = "m/d/yy h:mm", e10[37] = "#,##0 ;(#,##0)", e10[38] = "#,##0 ;[Red](#,##0)", e10[39] = "#,##0.00;(#,##0.00)", e10[40] = "#,##0.00;[Red](#,##0.00)", e10[45] = "mm:ss", e10[46] = "[h]:mm:ss", e10[47] = "mmss.0", e10[48] = "##0.0E+0", e10[49] = "@", e10[56] = '"上午/下午 "hh"時"mm"分"ss"秒 "', eD = e10;
        }
        var e6 = {
          format: e22,
          load: e4,
          _table: eD,
          load_table: e3,
          parse_date_code: eU,
          is_date: eQ,
          get_table: function() {
            return e6._table = eD;
          }
        }, e8 = {
          5: '"$"#,##0_);\\("$"#,##0\\)',
          6: '"$"#,##0_);[Red]\\("$"#,##0\\)',
          7: '"$"#,##0.00_);\\("$"#,##0.00\\)',
          8: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
          23: "General",
          24: "General",
          25: "General",
          26: "General",
          27: "m/d/yy",
          28: "m/d/yy",
          29: "m/d/yy",
          30: "m/d/yy",
          31: "m/d/yy",
          32: "h:mm:ss",
          33: "h:mm:ss",
          34: "h:mm:ss",
          35: "h:mm:ss",
          36: "m/d/yy",
          41: '_(* #,##0_);_(* (#,##0);_(* "-"_);_(@_)',
          42: '_("$"* #,##0_);_("$"* (#,##0);_("$"* "-"_);_(@_)',
          43: '_(* #,##0.00_);_(* (#,##0.00);_(* "-"??_);_(@_)',
          44: '_("$"* #,##0.00_);_("$"* (#,##0.00);_("$"* "-"??_);_(@_)',
          50: "m/d/yy",
          51: "m/d/yy",
          52: "m/d/yy",
          53: "m/d/yy",
          54: "m/d/yy",
          55: "m/d/yy",
          56: "m/d/yy",
          57: "m/d/yy",
          58: "m/d/yy",
          59: "0",
          60: "0.00",
          61: "#,##0",
          62: "#,##0.00",
          63: '"$"#,##0_);\\("$"#,##0\\)',
          64: '"$"#,##0_);[Red]\\("$"#,##0\\)',
          65: '"$"#,##0.00_);\\("$"#,##0.00\\)',
          66: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
          67: "0%",
          68: "0.00%",
          69: "# ?/?",
          70: "# ??/??",
          71: "m/d/yy",
          72: "m/d/yy",
          73: "d-mmm-yy",
          74: "d-mmm",
          75: "mmm-yy",
          76: "h:mm",
          77: "h:mm:ss",
          78: "m/d/yy h:mm",
          79: "mm:ss",
          80: "[h]:mm:ss",
          81: "mmss.0"
        }, e7 = /[dD]+|[mM]+|[yYeE]+|[Hh]+|[Ss]+/g, e9 = { "d.m": "d\\.m" };
        function te(e10, t10) {
          return e4(e9[e10] || e10, t10);
        }
        var tt = ((t2 = {}).version = "1.2.0", o = (i = (function(e10) {
          var t10 = 0, r10 = 0, a10 = 0, n10 = "undefined" != typeof Int32Array ? new Int32Array(4096) : Array(4096);
          for (a10 = 0; 256 != a10; ++a10) n10[a10] = e10[a10];
          for (a10 = 0; 256 != a10; ++a10)
            for (r10 = e10[a10], t10 = 256 + a10; t10 < 4096; t10 += 256) r10 = n10[t10] = r10 >>> 8 ^ e10[255 & r10];
          var s10 = [];
          for (a10 = 1; 16 != a10; ++a10)
            s10[a10 - 1] = "undefined" != typeof Int32Array && "function" == typeof n10.subarray ? n10.subarray(256 * a10, 256 * a10 + 256) : n10.slice(256 * a10, 256 * a10 + 256);
          return s10;
        })(
          s = (function() {
            for (var e10 = 0, t10 = Array(256), r10 = 0; 256 != r10; ++r10)
              e10 = 1 & (e10 = 1 & (e10 = 1 & (e10 = 1 & (e10 = 1 & (e10 = 1 & (e10 = 1 & (e10 = 1 & (e10 = r10) ? -306674912 ^ e10 >>> 1 : e10 >>> 1) ? -306674912 ^ e10 >>> 1 : e10 >>> 1) ? -306674912 ^ e10 >>> 1 : e10 >>> 1) ? -306674912 ^ e10 >>> 1 : e10 >>> 1) ? -306674912 ^ e10 >>> 1 : e10 >>> 1) ? -306674912 ^ e10 >>> 1 : e10 >>> 1) ? -306674912 ^ e10 >>> 1 : e10 >>> 1) ? -306674912 ^ e10 >>> 1 : e10 >>> 1, t10[r10] = e10;
            return "undefined" != typeof Int32Array ? new Int32Array(t10) : t10;
          })()
        ))[0], c = i[1], l = i[2], f = i[3], h = i[4], u = i[5], d = i[6], p = i[7], m = i[8], g = i[9], v = i[10], b = i[11], w = i[12], T = i[13], y = i[14], t2.table = s, t2.bstr = function(e10, t10) {
          for (var r10 = -1 ^ t10, a10 = 0, n10 = e10.length; a10 < n10; ) r10 = r10 >>> 8 ^ s[(r10 ^ e10.charCodeAt(a10++)) & 255];
          return ~r10;
        }, t2.buf = function(e10, t10) {
          for (var r10 = -1 ^ t10, a10 = e10.length - 15, n10 = 0; n10 < a10; )
            r10 = y[e10[n10++] ^ 255 & r10] ^ T[e10[n10++] ^ r10 >> 8 & 255] ^ w[e10[n10++] ^ r10 >> 16 & 255] ^ b[e10[n10++] ^ r10 >>> 24] ^ v[e10[n10++]] ^ g[e10[n10++]] ^ m[e10[n10++]] ^ p[e10[n10++]] ^ d[e10[n10++]] ^ u[e10[n10++]] ^ h[e10[n10++]] ^ f[e10[n10++]] ^ l[e10[n10++]] ^ c[e10[n10++]] ^ o[e10[n10++]] ^ s[e10[n10++]];
          for (a10 += 15; n10 < a10; ) r10 = r10 >>> 8 ^ s[(r10 ^ e10[n10++]) & 255];
          return ~r10;
        }, t2.str = function(e10, t10) {
          for (var r10 = -1 ^ t10, a10 = 0, n10 = e10.length, i10 = 0, o10 = 0; a10 < n10; )
            (i10 = e10.charCodeAt(a10++)) < 128 ? r10 = r10 >>> 8 ^ s[(r10 ^ i10) & 255] : i10 < 2048 ? r10 = (r10 = r10 >>> 8 ^ s[(r10 ^ (192 | i10 >> 6 & 31)) & 255]) >>> 8 ^ s[(r10 ^ (128 | 63 & i10)) & 255] : i10 >= 55296 && i10 < 57344 ? (i10 = (1023 & i10) + 64, o10 = 1023 & e10.charCodeAt(a10++), r10 = (r10 = (r10 = (r10 = r10 >>> 8 ^ s[(r10 ^ (240 | i10 >> 8 & 7)) & 255]) >>> 8 ^ s[(r10 ^ (128 | i10 >> 2 & 63)) & 255]) >>> 8 ^ s[(r10 ^ (128 | o10 >> 6 & 15 | (3 & i10) << 4)) & 255]) >>> 8 ^ s[(r10 ^ (128 | 63 & o10)) & 255]) : r10 = (r10 = (r10 = r10 >>> 8 ^ s[(r10 ^ (224 | i10 >> 12 & 15)) & 255]) >>> 8 ^ s[(r10 ^ (128 | i10 >> 6 & 63)) & 255]) >>> 8 ^ s[(r10 ^ (128 | 63 & i10)) & 255];
          return ~r10;
        }, t2), tr = (function() {
          var e10, t10, r10 = {};
          function n10(e11) {
            if ("/" == e11.charAt(e11.length - 1)) return -1 === e11.slice(0, -1).indexOf("/") ? e11 : n10(e11.slice(0, -1));
            var t11 = e11.lastIndexOf("/");
            return -1 === t11 ? e11 : e11.slice(0, t11 + 1);
          }
          function s10(e11) {
            if ("/" == e11.charAt(e11.length - 1)) return s10(e11.slice(0, -1));
            var t11 = e11.lastIndexOf("/");
            return -1 === t11 ? e11 : e11.slice(t11 + 1);
          }
          function i10(e11) {
            aa(e11, 0);
            for (var t11 = {}, r11 = 0; e11.l <= e11.length - 4; ) {
              var a10 = e11.read_shift(2), n11 = e11.read_shift(2), s11 = e11.l + n11, i11 = {};
              switch (a10) {
                case 21589:
                  1 & (r11 = e11.read_shift(1)) && (i11.mtime = e11.read_shift(4)), n11 > 5 && (2 & r11 && (i11.atime = e11.read_shift(4)), 4 & r11 && (i11.ctime = e11.read_shift(4))), i11.mtime && (i11.mt = new Date(1e3 * i11.mtime));
                  break;
                case 1:
                  var o11 = e11.read_shift(4), c11 = e11.read_shift(4);
                  i11.usz = 4294967296 * c11 + o11, o11 = e11.read_shift(4), i11.csz = 4294967296 * (c11 = e11.read_shift(4)) + o11;
              }
              e11.l = s11, t11[a10] = i11;
            }
            return t11;
          }
          r10.version = "1.2.2";
          function o10(e11, t11) {
            if (80 == e11[0] && 75 == e11[1]) return q2(e11, t11);
            if ((32 | e11[0]) == 109 && (32 | e11[1]) == 105)
              return (function(e12, t12) {
                if ("mime-version:" != b2(e12.slice(0, 13)).toLowerCase()) throw Error("Unsupported MAD header");
                var r12 = t12 && t12.root || "", n12 = (ep && a.isBuffer(e12) ? e12.toString("binary") : b2(e12)).split("\r\n"), s12 = 0, i12 = "";
                for (s12 = 0; s12 < n12.length; ++s12)
                  if ((i12 = n12[s12], /^Content-Location:/i.test(i12)) && (i12 = i12.slice(i12.indexOf("file")), r12 || (r12 = i12.slice(0, i12.lastIndexOf("/") + 1)), i12.slice(0, r12.length) != r12))
                    for (; r12.length > 0 && (r12 = (r12 = r12.slice(0, r12.length - 1)).slice(0, r12.lastIndexOf("/") + 1), i12.slice(0, r12.length) != r12); ) ;
                var o12 = (n12[1] || "").match(/boundary="(.*?)"/);
                if (!o12) throw Error("MAD cannot find boundary");
                var c11 = "--" + (o12[1] || ""), f4 = { FileIndex: [], FullPaths: [] };
                l2(f4);
                var h4, u3 = 0;
                for (s12 = 0; s12 < n12.length; ++s12) {
                  var d3 = n12[s12];
                  (d3 === c11 || d3 === c11 + "--") && (u3++ && (function(e13, t13, r13) {
                    for (var a10, n13 = "", s13 = "", i13 = "", o13 = 0; o13 < 10; ++o13) {
                      var c12 = t13[o13];
                      if (!c12 || c12.match(/^\s*$/)) break;
                      var l3 = c12.match(/^([^:]*?):\s*([^\s].*)$/);
                      if (l3)
                        switch (l3[1].toLowerCase()) {
                          case "content-location":
                            n13 = l3[2].trim();
                            break;
                          case "content-type":
                            i13 = l3[2].trim();
                            break;
                          case "content-transfer-encoding":
                            s13 = l3[2].trim();
                        }
                    }
                    switch (++o13, s13.toLowerCase()) {
                      case "base64":
                        a10 = ew(ed(t13.slice(o13).join("")));
                        break;
                      case "quoted-printable":
                        a10 = (function(e14) {
                          for (var t14 = [], r14 = 0; r14 < e14.length; ++r14) {
                            for (var a11 = e14[r14]; r14 <= e14.length && "=" == a11.charAt(a11.length - 1); )
                              a11 = a11.slice(0, a11.length - 1) + e14[++r14];
                            t14.push(a11);
                          }
                          for (var n14 = 0; n14 < t14.length; ++n14)
                            t14[n14] = t14[n14].replace(/[=][0-9A-Fa-f]{2}/g, function(e15) {
                              return String.fromCharCode(parseInt(e15.slice(1), 16));
                            });
                          return ew(t14.join("\r\n"));
                        })(t13.slice(o13));
                        break;
                      default:
                        throw Error("Unsupported Content-Transfer-Encoding " + s13);
                    }
                    var f5 = ee2(e13, n13.slice(r13.length), a10, { unsafe: true });
                    i13 && (f5.ctype = i13);
                  })(f4, n12.slice(h4, s12), r12), h4 = s12);
                }
                return f4;
              })(e11, t11);
            if (e11.length < 512) throw Error("CFB file size " + e11.length + " < 512");
            var r11 = 3, n11 = 512, s11 = 0, i11 = 0, o11 = 0, f3 = 0, h3 = 0, m3 = [], g3 = e11.slice(0, 512);
            aa(g3, 0);
            var v3 = (function(e12) {
              if (80 == e12[e12.l] && 75 == e12[e12.l + 1]) return [0, 0];
              e12.chk(p2, "Header Signature: "), e12.l += 16;
              var t12 = e12.read_shift(2, "u");
              return [e12.read_shift(2, "u"), t12];
            })(g3);
            switch (r11 = v3[0]) {
              case 3:
                n11 = 512;
                break;
              case 4:
                n11 = 4096;
                break;
              case 0:
                if (0 == v3[1]) return q2(e11, t11);
              default:
                throw Error("Major Version: Expected 3 or 4 saw " + r11);
            }
            512 !== n11 && aa(g3 = e11.slice(0, n11), 28);
            var w3 = e11.slice(0, n11), T3 = g3, y3 = r11, E3 = 9;
            switch (T3.l += 2, E3 = T3.read_shift(2)) {
              case 9:
                if (3 != y3) throw Error("Sector Shift: Expected 9 saw " + E3);
                break;
              case 12:
                if (4 != y3) throw Error("Sector Shift: Expected 12 saw " + E3);
                break;
              default:
                throw Error("Sector Shift: Expected 9 or 12 saw " + E3);
            }
            T3.chk("0600", "Mini Sector Shift: "), T3.chk("000000000000", "Reserved: ");
            var k3 = g3.read_shift(4, "i");
            if (3 === r11 && 0 !== k3) throw Error("# Directory Sectors: Expected 0 saw " + k3);
            g3.l += 4, o11 = g3.read_shift(4, "i"), g3.l += 4, g3.chk("00100000", "Mini Stream Cutoff Size: "), f3 = g3.read_shift(4, "i"), s11 = g3.read_shift(4, "i"), h3 = g3.read_shift(4, "i"), i11 = g3.read_shift(4, "i");
            for (var x3 = -1, _3 = 0; _3 < 109 && !((x3 = g3.read_shift(4, "i")) < 0); ++_3) m3[_3] = x3;
            var S3 = (function(e12, t12) {
              for (var r12 = Math.ceil(e12.length / t12) - 1, a10 = [], n12 = 1; n12 < r12; ++n12)
                a10[n12 - 1] = e12.slice(n12 * t12, (n12 + 1) * t12);
              return a10[r12 - 1] = e12.slice(r12 * t12), a10;
            })(e11, n11);
            !(function e12(t12, r12, a10, n12, s12) {
              var i12 = d2;
              if (t12 === d2) {
                if (0 !== r12) throw Error("DIFAT chain shorter than expected");
              } else if (-1 !== t12) {
                var o12 = a10[t12], c11 = (n12 >>> 2) - 1;
                if (!o12) return;
                for (var l3 = 0; l3 < c11 && (i12 = r6(o12, 4 * l3)) !== d2; ++l3) s12.push(i12);
                r12 >= 1 && e12(r6(o12, n12 - 4), r12 - 1, a10, n12, s12);
              }
            })(h3, i11, S3, n11, m3);
            var A3 = (function(e12, t12, r12, a10) {
              var n12 = e12.length, s12 = [], i12 = [], o12 = [], c11 = [], l3 = a10 - 1, f4 = 0, h4 = 0, u3 = 0, d3 = 0;
              for (f4 = 0; f4 < n12; ++f4)
                if (o12 = [], (u3 = f4 + t12) >= n12 && (u3 -= n12), !i12[u3]) {
                  c11 = [];
                  var p3 = [];
                  for (h4 = u3; h4 >= 0; ) {
                    p3[h4] = true, i12[h4] = true, o12[o12.length] = h4, c11.push(e12[h4]);
                    var m4 = r12[Math.floor(4 * h4 / a10)];
                    if (a10 < 4 + (d3 = 4 * h4 & l3)) throw Error("FAT boundary crossed: " + h4 + " 4 " + a10);
                    if (!e12[m4] || p3[h4 = r6(e12[m4], d3)]) break;
                  }
                  s12[u3] = { nodes: o12, data: rP([c11]) };
                }
              return s12;
            })(S3, o11, m3, n11);
            o11 < A3.length && (A3[o11].name = "!Directory"), s11 > 0 && f3 !== d2 && (A3[f3].name = "!MiniFAT"), A3[m3[0]].name = "!FAT", A3.fat_addrs = m3, A3.ssz = n11;
            var C3 = [], I3 = [], O3 = [];
            (function(e12, t12, r12, a10, n12, s12, i12, o12) {
              for (var l3, f4 = 0, h4 = 2 * !!a10.length, p3 = t12[e12].data, m4 = 0, g4 = 0; m4 < p3.length; m4 += 128) {
                var v4 = p3.slice(m4, m4 + 128);
                aa(v4, 64), g4 = v4.read_shift(2), l3 = rM(v4, 0, g4 - h4), a10.push(l3);
                var b3 = {
                  name: l3,
                  type: v4.read_shift(1),
                  color: v4.read_shift(1),
                  L: v4.read_shift(4, "i"),
                  R: v4.read_shift(4, "i"),
                  C: v4.read_shift(4, "i"),
                  clsid: v4.read_shift(16),
                  state: v4.read_shift(4, "i"),
                  start: 0,
                  size: 0
                };
                0 !== v4.read_shift(2) + v4.read_shift(2) + v4.read_shift(2) + v4.read_shift(2) && (b3.ct = c10(v4, v4.l - 8)), 0 !== v4.read_shift(2) + v4.read_shift(2) + v4.read_shift(2) + v4.read_shift(2) && (b3.mt = c10(v4, v4.l - 8)), b3.start = v4.read_shift(4, "i"), b3.size = v4.read_shift(4, "i"), b3.size < 0 && b3.start < 0 && (b3.size = b3.type = 0, b3.start = d2, b3.name = ""), 5 === b3.type ? (f4 = b3.start, n12 > 0 && f4 !== d2 && (t12[f4].name = "!StreamData")) : b3.size >= 4096 ? (b3.storage = "fat", void 0 === t12[b3.start] && (t12[b3.start] = (function(e13, t13, r13, a11, n13) {
                  var s13 = [], i13 = [];
                  n13 || (n13 = []);
                  var o13 = a11 - 1, c11 = 0, l4 = 0;
                  for (c11 = t13; c11 >= 0; ) {
                    n13[c11] = true, s13[s13.length] = c11, i13.push(e13[c11]);
                    var f5 = r13[Math.floor(4 * c11 / a11)];
                    if (a11 < 4 + (l4 = 4 * c11 & o13)) throw Error("FAT boundary crossed: " + c11 + " 4 " + a11);
                    if (!e13[f5]) break;
                    c11 = r6(e13[f5], l4);
                  }
                  return { nodes: s13, data: rP([i13]) };
                })(r12, b3.start, t12.fat_addrs, t12.ssz)), t12[b3.start].name = b3.name, b3.content = t12[b3.start].data.slice(0, b3.size)) : (b3.storage = "minifat", b3.size < 0 ? b3.size = 0 : f4 !== d2 && b3.start !== d2 && t12[f4] && (b3.content = (function(e13, t13, r13) {
                  for (var a11 = e13.start, n13 = e13.size, s13 = [], i13 = a11; r13 && n13 > 0 && i13 >= 0; )
                    s13.push(t13.slice(i13 * u2, i13 * u2 + u2)), n13 -= u2, i13 = r6(r13, 4 * i13);
                  return 0 === s13.length ? as(0) : ek(s13).slice(0, e13.size);
                })(b3, t12[f4].data, (t12[o12] || {}).data))), b3.content && aa(b3.content, 0), s12[l3] = b3, i12.push(b3);
              }
            })(o11, A3, S3, C3, s11, {}, I3, f3), (function(e12, t12, r12) {
              for (var a10 = 0, n12 = 0, s12 = 0, i12 = 0, o12 = 0, c11 = r12.length, l3 = [], f4 = []; a10 < c11; ++a10)
                l3[a10] = f4[a10] = a10, t12[a10] = r12[a10];
              for (; o12 < f4.length; ++o12)
                n12 = e12[a10 = f4[o12]].L, s12 = e12[a10].R, i12 = e12[a10].C, l3[a10] === a10 && (-1 !== n12 && l3[n12] !== n12 && (l3[a10] = l3[n12]), -1 !== s12 && l3[s12] !== s12 && (l3[a10] = l3[s12])), -1 !== i12 && (l3[i12] = a10), -1 !== n12 && a10 != l3[a10] && (l3[n12] = l3[a10], f4.lastIndexOf(n12) < o12 && f4.push(n12)), -1 !== s12 && a10 != l3[a10] && (l3[s12] = l3[a10], f4.lastIndexOf(s12) < o12 && f4.push(s12));
              for (a10 = 1; a10 < c11; ++a10)
                l3[a10] === a10 && (-1 !== s12 && l3[s12] !== s12 ? l3[a10] = l3[s12] : -1 !== n12 && l3[n12] !== n12 && (l3[a10] = l3[n12]));
              for (a10 = 1; a10 < c11; ++a10)
                if (0 !== e12[a10].type) {
                  if ((o12 = a10) != l3[o12])
                    do
                      o12 = l3[o12], t12[a10] = t12[o12] + "/" + t12[a10];
                    while (0 !== o12 && -1 !== l3[o12] && o12 != l3[o12]);
                  l3[a10] = -1;
                }
              for (t12[0] += "/", a10 = 1; a10 < c11; ++a10) 2 !== e12[a10].type && (t12[a10] += "/");
            })(I3, O3, C3), C3.shift();
            var R3 = { FileIndex: I3, FullPaths: O3 };
            return t11 && t11.raw && (R3.raw = { header: w3, sectors: S3 }), R3;
          }
          function c10(e11, t11) {
            return new Date((r5(e11, t11 + 4) / 1e7 * 4294967296 + r5(e11, t11) / 1e7 - 11644473600) * 1e3);
          }
          function l2(e11, t11) {
            var r11 = t11 || {}, a10 = r11.root || "Root Entry";
            if (e11.FullPaths || (e11.FullPaths = []), e11.FileIndex || (e11.FileIndex = []), e11.FullPaths.length !== e11.FileIndex.length)
              throw Error("inconsistent CFB structure");
            0 === e11.FullPaths.length && (e11.FullPaths[0] = a10 + "/", e11.FileIndex[0] = { name: a10, type: 5 }), r11.CLSID && (e11.FileIndex[0].clsid = r11.CLSID), (function(e12) {
              var t12 = "Sh33tJ5";
              if (!tr.find(e12, "/" + t12)) {
                var r12 = as(4);
                r12[0] = 55, r12[1] = r12[3] = 50, r12[2] = 54, e12.FileIndex.push({ name: t12, type: 2, content: r12, size: 4, L: 69, R: 69, C: 69 }), e12.FullPaths.push(e12.FullPaths[0] + t12), f2(e12);
              }
            })(e11);
          }
          function f2(e11, t11) {
            l2(e11);
            for (var r11 = false, a10 = false, i11 = e11.FullPaths.length - 1; i11 >= 0; --i11) {
              var o11 = e11.FileIndex[i11];
              switch (o11.type) {
                case 0:
                  a10 ? r11 = true : (e11.FileIndex.pop(), e11.FullPaths.pop());
                  break;
                case 1:
                case 2:
                case 5:
                  a10 = true, isNaN(o11.R * o11.L * o11.C) && (r11 = true), o11.R > -1 && o11.L > -1 && o11.R == o11.L && (r11 = true);
                  break;
                default:
                  r11 = true;
              }
            }
            if (r11 || t11) {
              var c11 = new Date(1987, 1, 19), f3 = 0, h3 = Object.create ? /* @__PURE__ */ Object.create(null) : {}, u3 = [];
              for (i11 = 0; i11 < e11.FullPaths.length; ++i11)
                h3[e11.FullPaths[i11]] = true, 0 !== e11.FileIndex[i11].type && u3.push([e11.FullPaths[i11], e11.FileIndex[i11]]);
              for (i11 = 0; i11 < u3.length; ++i11) {
                var d3 = n10(u3[i11][0]);
                for (a10 = h3[d3]; !a10; ) {
                  for (; n10(d3) && !h3[n10(d3)]; ) d3 = n10(d3);
                  u3.push([d3, { name: s10(d3).replace("/", ""), type: 1, clsid: g2, ct: c11, mt: c11, content: null }]), h3[d3] = true, a10 = h3[d3 = n10(u3[i11][0])];
                }
              }
              for (u3.sort(function(e12, t12) {
                return (function(e13, t13) {
                  for (var r12 = e13.split("/"), a11 = t13.split("/"), n11 = 0, s11 = 0, i12 = Math.min(r12.length, a11.length); n11 < i12; ++n11) {
                    if (s11 = r12[n11].length - a11[n11].length) return s11;
                    if (r12[n11] != a11[n11]) return r12[n11] < a11[n11] ? -1 : 1;
                  }
                  return r12.length - a11.length;
                })(e12[0], t12[0]);
              }), e11.FullPaths = [], e11.FileIndex = [], i11 = 0; i11 < u3.length; ++i11)
                e11.FullPaths[i11] = u3[i11][0], e11.FileIndex[i11] = u3[i11][1];
              for (i11 = 0; i11 < u3.length; ++i11) {
                var p3 = e11.FileIndex[i11], m3 = e11.FullPaths[i11];
                if (p3.name = s10(m3).replace("/", ""), p3.L = p3.R = p3.C = -(p3.color = 1), p3.size = p3.content ? p3.content.length : 0, p3.start = 0, p3.clsid = p3.clsid || g2, 0 === i11)
                  p3.C = u3.length > 1 ? 1 : -1, p3.size = 0, p3.type = 5;
                else if ("/" == m3.slice(-1)) {
                  for (f3 = i11 + 1; f3 < u3.length && n10(e11.FullPaths[f3]) != m3; ++f3) ;
                  for (p3.C = f3 >= u3.length ? -1 : f3, f3 = i11 + 1; f3 < u3.length && n10(e11.FullPaths[f3]) != n10(m3); ++f3) ;
                  p3.R = f3 >= u3.length ? -1 : f3, p3.type = 1;
                } else n10(e11.FullPaths[i11 + 1] || "") == n10(m3) && (p3.R = i11 + 1), p3.type = 2;
              }
            }
          }
          function h2(e11, r11) {
            var n11 = r11 || {};
            if ("mad" == n11.fileType)
              return (function(e12, t11) {
                for (var r12 = t11 || {}, n12 = r12.boundary || "SheetJS", s12 = [
                  "MIME-Version: 1.0",
                  'Content-Type: multipart/related; boundary="' + (n12 = "------=" + n12).slice(2) + '"',
                  "",
                  "",
                  ""
                ], i12 = e12.FullPaths[0], o12 = i12, c12 = e12.FileIndex[0], l4 = 1; l4 < e12.FullPaths.length; ++l4)
                  if (o12 = e12.FullPaths[l4].slice(i12.length), (c12 = e12.FileIndex[l4]).size && c12.content && "Sh33tJ5" != o12) {
                    o12 = o12.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7E-\xFF]/g, function(e13) {
                      return "_x" + e13.charCodeAt(0).toString(16) + "_";
                    }).replace(/[\u0080-\uFFFF]/g, function(e13) {
                      return "_u" + e13.charCodeAt(0).toString(16) + "_";
                    });
                    for (var f3 = c12.content, h4 = ep && a.isBuffer(f3) ? f3.toString("binary") : b2(f3), u4 = 0, d3 = Math.min(1024, h4.length), p4 = 0, m3 = 0; m3 <= d3; ++m3)
                      (p4 = h4.charCodeAt(m3)) >= 32 && p4 < 128 && ++u4;
                    var g4 = u4 >= 4 * d3 / 5;
                    s12.push(n12), s12.push("Content-Location: " + (r12.root || "file:///C:/SheetJS/") + o12), s12.push("Content-Transfer-Encoding: " + (g4 ? "quoted-printable" : "base64")), s12.push(
                      "Content-Type: " + (function(e13, t12) {
                        if (e13.ctype) return e13.ctype;
                        var r13 = e13.name || "", a10 = r13.match(/\.([^\.]+)$/);
                        return a10 && Q2[a10[1]] || t12 && (a10 = (r13 = t12).match(/[\.\\]([^\.\\])+$/)) && Q2[a10[1]] ? Q2[a10[1]] : "application/octet-stream";
                      })(c12, o12)
                    ), s12.push(""), s12.push(
                      g4 ? (function(e13) {
                        var t12 = e13.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7E-\xFF=]/g, function(e14) {
                          var t13 = e14.charCodeAt(0).toString(16).toUpperCase();
                          return "=" + (1 == t13.length ? "0" + t13 : t13);
                        });
                        "\n" == (t12 = t12.replace(/ $/gm, "=20").replace(/\t$/gm, "=09")).charAt(0) && (t12 = "=0D" + t12.slice(1)), t12 = t12.replace(/\r(?!\n)/gm, "=0D").replace(/\n\n/gm, "\n=0A").replace(/([^\r\n])\n/gm, "$1=0A");
                        for (var r13 = [], a10 = t12.split("\r\n"), n13 = 0; n13 < a10.length; ++n13) {
                          var s13 = a10[n13];
                          if (0 == s13.length) {
                            r13.push("");
                            continue;
                          }
                          for (var i13 = 0; i13 < s13.length; ) {
                            var o13 = 76, c13 = s13.slice(i13, i13 + o13);
                            "=" == c13.charAt(o13 - 1) ? o13-- : "=" == c13.charAt(o13 - 2) ? o13 -= 2 : "=" == c13.charAt(o13 - 3) && (o13 -= 3), c13 = s13.slice(i13, i13 + o13), (i13 += o13) < s13.length && (c13 += "="), r13.push(c13);
                          }
                        }
                        return r13.join("\r\n");
                      })(h4) : (function(e13) {
                        for (var t12 = eu(e13), r13 = [], a10 = 0; a10 < t12.length; a10 += 76) r13.push(t12.slice(a10, a10 + 76));
                        return r13.join("\r\n") + "\r\n";
                      })(h4)
                    );
                  }
                return s12.push(n12 + "--\r\n"), s12.join("\r\n");
              })(e11, n11);
            if (f2(e11), "zip" === n11.fileType)
              return (function(e12, r12) {
                var a10 = [], n12 = [], s12 = as(1), i12 = 8 * !!(r12 || {}).compression, o12 = 0, c12 = 0, l4 = 0, f3 = 0, h4 = e12.FullPaths[0], u4 = h4, d3 = e12.FileIndex[0], p4 = [], m3 = 0;
                for (o12 = 1; o12 < e12.FullPaths.length; ++o12)
                  if (u4 = e12.FullPaths[o12].slice(h4.length), !(!(d3 = e12.FileIndex[o12]).size || !d3.content || Array.isArray(d3.content) && 0 == d3.content.length) && "Sh33tJ5" != u4) {
                    var g4, v3 = l4, b3 = as(u4.length);
                    for (c12 = 0; c12 < u4.length; ++c12) b3.write_shift(1, 127 & u4.charCodeAt(c12));
                    b3 = b3.slice(0, b3.l), p4[f3] = "string" == typeof d3.content ? tt.bstr(d3.content, 0) : tt.buf(d3.content, 0);
                    var w4 = "string" == typeof d3.content ? ew(d3.content) : d3.content;
                    8 == i12 && (g4 = w4, w4 = t10 ? t10.deflateRawSync(g4) : H2(g4)), (s12 = as(30)).write_shift(4, 67324752), s12.write_shift(2, 20), s12.write_shift(2, 0), s12.write_shift(2, i12), d3.mt ? (function(e13, t11) {
                      "string" == typeof t11 && (t11 = new Date(t11));
                      var r13 = t11.getHours();
                      r13 = (r13 = r13 << 6 | t11.getMinutes()) << 5 | t11.getSeconds() >>> 1, e13.write_shift(2, r13);
                      var a11 = t11.getFullYear() - 1980;
                      a11 = (a11 = a11 << 4 | t11.getMonth() + 1) << 5 | t11.getDate(), e13.write_shift(2, a11);
                    })(s12, d3.mt) : s12.write_shift(4, 0), s12.write_shift(-4, (0, p4[f3])), s12.write_shift(4, (0, w4.length)), s12.write_shift(4, (0, d3.content.length)), s12.write_shift(2, b3.length), s12.write_shift(2, 0), l4 += s12.length, a10.push(s12), l4 += b3.length, a10.push(b3), l4 += w4.length, a10.push(w4), (s12 = as(46)).write_shift(4, 33639248), s12.write_shift(2, 0), s12.write_shift(2, 20), s12.write_shift(2, 0), s12.write_shift(2, i12), s12.write_shift(4, 0), s12.write_shift(-4, p4[f3]), s12.write_shift(4, w4.length), s12.write_shift(4, d3.content.length), s12.write_shift(2, b3.length), s12.write_shift(2, 0), s12.write_shift(2, 0), s12.write_shift(2, 0), s12.write_shift(2, 0), s12.write_shift(4, 0), s12.write_shift(4, v3), m3 += s12.l, n12.push(s12), m3 += b3.length, n12.push(b3), ++f3;
                  }
                return (s12 = as(22)).write_shift(4, 101010256), s12.write_shift(2, 0), s12.write_shift(2, 0), s12.write_shift(2, f3), s12.write_shift(2, f3), s12.write_shift(4, m3), s12.write_shift(4, l4), s12.write_shift(2, 0), ek([ek(a10), ek(n12), s12]);
              })(e11, n11);
            var s11 = (function(e12) {
              for (var t11 = 0, r12 = 0, a10 = 0; a10 < e12.FileIndex.length; ++a10) {
                var n12 = e12.FileIndex[a10];
                if (n12.content) {
                  var s12 = n12.content.length;
                  s12 > 0 && (s12 < 4096 ? t11 += s12 + 63 >> 6 : r12 += s12 + 511 >> 9);
                }
              }
              for (var i12 = e12.FullPaths.length + 3 >> 2, o12 = t11 + 7 >> 3, c12 = t11 + 127 >> 7, l4 = o12 + r12 + i12 + c12, f3 = l4 + 127 >> 7, h4 = f3 <= 109 ? 0 : Math.ceil((f3 - 109) / 127); l4 + f3 + h4 + 127 >> 7 > f3; )
                h4 = ++f3 <= 109 ? 0 : Math.ceil((f3 - 109) / 127);
              var u4 = [1, h4, f3, c12, i12, r12, t11, 0];
              return e12.FileIndex[0].size = t11 << 6, u4[7] = (e12.FileIndex[0].start = u4[0] + u4[1] + u4[2] + u4[3] + u4[4] + u4[5]) + (u4[6] + 7 >> 3), u4;
            })(e11), i11 = as(s11[7] << 9), o11 = 0, c11 = 0;
            for (o11 = 0; o11 < 8; ++o11) i11.write_shift(1, m2[o11]);
            for (o11 = 0; o11 < 8; ++o11) i11.write_shift(2, 0);
            for (i11.write_shift(2, 62), i11.write_shift(2, 3), i11.write_shift(2, 65534), i11.write_shift(2, 9), i11.write_shift(2, 6), o11 = 0; o11 < 3; ++o11)
              i11.write_shift(2, 0);
            for (i11.write_shift(4, 0), i11.write_shift(4, s11[2]), i11.write_shift(4, s11[0] + s11[1] + s11[2] + s11[3] - 1), i11.write_shift(4, 0), i11.write_shift(4, 4096), i11.write_shift(4, s11[3] ? s11[0] + s11[1] + s11[2] - 1 : d2), i11.write_shift(4, s11[3]), i11.write_shift(-4, s11[1] ? s11[0] - 1 : d2), i11.write_shift(4, s11[1]), o11 = 0; o11 < 109; ++o11)
              i11.write_shift(-4, o11 < s11[2] ? s11[1] + o11 : -1);
            if (s11[1])
              for (c11 = 0; c11 < s11[1]; ++c11) {
                for (; o11 < 236 + 127 * c11; ++o11) i11.write_shift(-4, o11 < s11[2] ? s11[1] + o11 : -1);
                i11.write_shift(-4, c11 === s11[1] - 1 ? d2 : c11 + 1);
              }
            var l3 = function(e12) {
              for (c11 += e12; o11 < c11 - 1; ++o11) i11.write_shift(-4, o11 + 1);
              e12 && (++o11, i11.write_shift(-4, d2));
            };
            for (c11 = (o11 = 0) + s11[1]; o11 < c11; ++o11) i11.write_shift(-4, v2.DIFSECT);
            for (c11 += s11[2]; o11 < c11; ++o11) i11.write_shift(-4, v2.FATSECT);
            l3(s11[3]), l3(s11[4]);
            for (var h3 = 0, u3 = 0, p3 = e11.FileIndex[0]; h3 < e11.FileIndex.length; ++h3)
              (p3 = e11.FileIndex[h3]).content && ((u3 = p3.content.length) < 4096 || (p3.start = c11, l3(u3 + 511 >> 9)));
            for (l3(s11[6] + 7 >> 3); 511 & i11.l; ) i11.write_shift(-4, v2.ENDOFCHAIN);
            for (h3 = 0, c11 = o11 = 0; h3 < e11.FileIndex.length; ++h3)
              (p3 = e11.FileIndex[h3]).content && (u3 = p3.content.length) && !(u3 >= 4096) && (p3.start = c11, l3(u3 + 63 >> 6));
            for (; 511 & i11.l; ) i11.write_shift(-4, v2.ENDOFCHAIN);
            for (o11 = 0; o11 < s11[4] << 2; ++o11) {
              var g3 = e11.FullPaths[o11];
              if (!g3 || 0 === g3.length) {
                for (h3 = 0; h3 < 17; ++h3) i11.write_shift(4, 0);
                for (h3 = 0; h3 < 3; ++h3) i11.write_shift(4, -1);
                for (h3 = 0; h3 < 12; ++h3) i11.write_shift(4, 0);
                continue;
              }
              p3 = e11.FileIndex[o11], 0 === o11 && (p3.start = p3.size ? p3.start - 1 : d2);
              var w3 = 0 === o11 && n11.root || p3.name;
              if (w3.length > 31 && (console.error("Name " + w3 + " will be truncated to " + w3.slice(0, 31)), w3 = w3.slice(0, 31)), u3 = 2 * (w3.length + 1), i11.write_shift(64, w3, "utf16le"), i11.write_shift(2, u3), i11.write_shift(1, p3.type), i11.write_shift(1, p3.color), i11.write_shift(-4, p3.L), i11.write_shift(-4, p3.R), i11.write_shift(-4, p3.C), p3.clsid)
                i11.write_shift(16, p3.clsid, "hex");
              else for (h3 = 0; h3 < 4; ++h3) i11.write_shift(4, 0);
              i11.write_shift(4, p3.state || 0), i11.write_shift(4, 0), i11.write_shift(4, 0), i11.write_shift(4, 0), i11.write_shift(4, 0), i11.write_shift(4, p3.start), i11.write_shift(4, p3.size), i11.write_shift(4, 0);
            }
            for (o11 = 1; o11 < e11.FileIndex.length; ++o11)
              if ((p3 = e11.FileIndex[o11]).size >= 4096)
                if (i11.l = p3.start + 1 << 9, ep && a.isBuffer(p3.content))
                  p3.content.copy(i11, i11.l, 0, p3.size), i11.l += p3.size + 511 & -512;
                else {
                  for (h3 = 0; h3 < p3.size; ++h3) i11.write_shift(1, p3.content[h3]);
                  for (; 511 & h3; ++h3) i11.write_shift(1, 0);
                }
            for (o11 = 1; o11 < e11.FileIndex.length; ++o11)
              if ((p3 = e11.FileIndex[o11]).size > 0 && p3.size < 4096)
                if (ep && a.isBuffer(p3.content)) p3.content.copy(i11, i11.l, 0, p3.size), i11.l += p3.size + 63 & -64;
                else {
                  for (h3 = 0; h3 < p3.size; ++h3) i11.write_shift(1, p3.content[h3]);
                  for (; 63 & h3; ++h3) i11.write_shift(1, 0);
                }
            if (ep) i11.l = i11.length;
            else for (; i11.l < i11.length; ) i11.write_shift(1, 0);
            return i11;
          }
          var u2 = 64, d2 = -2, p2 = "d0cf11e0a1b11ae1", m2 = [208, 207, 17, 224, 161, 177, 26, 225], g2 = "00000000000000000000000000000000", v2 = {
            MAXREGSECT: -6,
            DIFSECT: -4,
            FATSECT: -3,
            ENDOFCHAIN: -2,
            FREESECT: -1,
            HEADER_SIGNATURE: p2,
            HEADER_MINOR_VERSION: "3e00",
            MAXREGSID: -6,
            NOSTREAM: -1,
            HEADER_CLSID: g2,
            EntryTypes: ["unknown", "storage", "stream", "lockbytes", "property", "root"]
          };
          function b2(e11) {
            for (var t11 = Array(e11.length), r11 = 0; r11 < e11.length; ++r11) t11[r11] = String.fromCharCode(e11[r11]);
            return t11.join("");
          }
          for (var w2 = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], T2 = [
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            13,
            15,
            17,
            19,
            23,
            27,
            31,
            35,
            43,
            51,
            59,
            67,
            83,
            99,
            115,
            131,
            163,
            195,
            227,
            258
          ], y2 = [
            1,
            2,
            3,
            4,
            5,
            7,
            9,
            13,
            17,
            25,
            33,
            49,
            65,
            97,
            129,
            193,
            257,
            385,
            513,
            769,
            1025,
            1537,
            2049,
            3073,
            4097,
            6145,
            8193,
            12289,
            16385,
            24577
          ], E2 = "undefined" != typeof Uint8Array, k2 = E2 ? new Uint8Array(256) : [], x2 = 0; x2 < 256; ++x2)
            k2[x2] = (function(e11) {
              var t11 = (e11 << 1 | e11 << 11) & 139536 | (e11 << 5 | e11 << 15) & 558144;
              return (t11 >> 16 | t11 >> 8 | t11) & 255;
            })(x2);
          function _2(e11, t11) {
            var r11 = 7 & t11, a10 = t11 >>> 3;
            return (e11[a10] | (r11 <= 5 ? 0 : e11[a10 + 1] << 8)) >>> r11 & 7;
          }
          function S2(e11, t11) {
            var r11 = 7 & t11, a10 = t11 >>> 3;
            return (e11[a10] | (r11 <= 3 ? 0 : e11[a10 + 1] << 8)) >>> r11 & 31;
          }
          function A2(e11, t11) {
            var r11 = 7 & t11, a10 = t11 >>> 3;
            return (e11[a10] | (r11 <= 1 ? 0 : e11[a10 + 1] << 8)) >>> r11 & 127;
          }
          function C2(e11, t11, r11) {
            var a10 = 7 & t11, n11 = t11 >>> 3, s11 = (1 << r11) - 1, i11 = e11[n11] >>> a10;
            return r11 < 8 - a10 || (i11 |= e11[n11 + 1] << 8 - a10, r11 < 16 - a10 || (i11 |= e11[n11 + 2] << 16 - a10, r11 < 24 - a10)) ? i11 & s11 : (i11 |= e11[n11 + 3] << 24 - a10) & s11;
          }
          function I2(e11, t11, r11) {
            var a10 = 7 & t11, n11 = t11 >>> 3;
            return a10 <= 5 ? e11[n11] |= (7 & r11) << a10 : (e11[n11] |= r11 << a10 & 255, e11[n11 + 1] = (7 & r11) >> 8 - a10), t11 + 3;
          }
          function O2(e11, t11, r11) {
            var a10 = t11 >>> 3;
            return r11 <<= 7 & t11, e11[a10] |= 255 & r11, r11 >>>= 8, e11[a10 + 1] = r11, t11 + 8;
          }
          function R2(e11, t11, r11) {
            var a10 = t11 >>> 3;
            return r11 <<= 7 & t11, e11[a10] |= 255 & r11, r11 >>>= 8, e11[a10 + 1] = 255 & r11, e11[a10 + 2] = r11 >>> 8, t11 + 16;
          }
          function N2(e11, t11) {
            var r11 = e11.length, a10 = 2 * r11 > t11 ? 2 * r11 : t11 + 5, n11 = 0;
            if (r11 >= t11) return e11;
            if (ep) {
              var s11 = eb(a10);
              if (e11.copy) e11.copy(s11);
              else for (; n11 < e11.length; ++n11) s11[n11] = e11[n11];
              return s11;
            }
            if (E2) {
              var i11 = new Uint8Array(a10);
              if (i11.set) i11.set(e11);
              else for (; n11 < r11; ++n11) i11[n11] = e11[n11];
              return i11;
            }
            return e11.length = a10, e11;
          }
          function F2(e11) {
            for (var t11 = Array(e11), r11 = 0; r11 < e11; ++r11) t11[r11] = 0;
            return t11;
          }
          function D2(e11, t11, r11) {
            var a10 = 1, n11 = 0, s11 = 0, i11 = 0, o11 = 0, c11 = e11.length, l3 = E2 ? new Uint16Array(32) : F2(32);
            for (s11 = 0; s11 < 32; ++s11) l3[s11] = 0;
            for (s11 = c11; s11 < r11; ++s11) e11[s11] = 0;
            c11 = e11.length;
            var f3 = E2 ? new Uint16Array(c11) : F2(c11);
            for (s11 = 0; s11 < c11; ++s11) l3[n11 = e11[s11]]++, a10 < n11 && (a10 = n11), f3[s11] = 0;
            for (s11 = 1, l3[0] = 0; s11 <= a10; ++s11) l3[s11 + 16] = o11 = o11 + l3[s11 - 1] << 1;
            for (s11 = 0; s11 < c11; ++s11) 0 != (o11 = e11[s11]) && (f3[s11] = l3[o11 + 16]++);
            var h3 = 0;
            for (s11 = 0; s11 < c11; ++s11)
              if (0 != (h3 = e11[s11]))
                for (o11 = (function(e12, t12) {
                  var r12 = k2[255 & e12];
                  return t12 <= 8 ? r12 >>> 8 - t12 : (r12 = r12 << 8 | k2[e12 >> 8 & 255], t12 <= 16) ? r12 >>> 16 - t12 : (r12 = r12 << 8 | k2[e12 >> 16 & 255]) >>> 24 - t12;
                })(f3[s11], a10) >> a10 - h3, i11 = (1 << a10 + 4 - h3) - 1; i11 >= 0; --i11)
                  t11[o11 | i11 << h3] = 15 & h3 | s11 << 4;
            return a10;
          }
          var P2 = E2 ? new Uint16Array(512) : F2(512), L2 = E2 ? new Uint16Array(32) : F2(32);
          if (!E2) {
            for (var M2 = 0; M2 < 512; ++M2) P2[M2] = 0;
            for (M2 = 0; M2 < 32; ++M2) L2[M2] = 0;
          }
          for (var U2 = [], B2 = 0; B2 < 32; B2++) U2.push(5);
          D2(U2, L2, 32);
          var W2 = [];
          for (B2 = 0; B2 <= 143; B2++) W2.push(8);
          for (; B2 <= 255; B2++) W2.push(9);
          for (; B2 <= 279; B2++) W2.push(7);
          for (; B2 <= 287; B2++) W2.push(8);
          D2(W2, P2, 288);
          var z2 = (function() {
            for (var e11 = E2 ? new Uint8Array(32768) : [], t11 = 0, r11 = 0; t11 < y2.length - 1; ++t11)
              for (; r11 < y2[t11 + 1]; ++r11) e11[r11] = t11;
            for (; r11 < 32768; ++r11) e11[r11] = 29;
            var a10 = E2 ? new Uint8Array(259) : [];
            for (t11 = 0, r11 = 0; t11 < T2.length - 1; ++t11) for (; r11 < T2[t11 + 1]; ++r11) a10[r11] = t11;
            return function(t12, r12) {
              if (t12.length < 8) {
                for (var n11 = 0; n11 < t12.length; ) {
                  var s11 = Math.min(65535, t12.length - n11), i11 = n11 + s11 == t12.length;
                  for (r12.write_shift(1, +i11), r12.write_shift(2, s11), r12.write_shift(2, 65535 & ~s11); s11-- > 0; )
                    r12[r12.l++] = t12[n11++];
                }
                return r12.l;
              }
              return (function(t13, r13) {
                for (var n12 = 0, s12 = 0, i12 = E2 ? new Uint16Array(32768) : []; s12 < t13.length; ) {
                  var o11 = Math.min(65535, t13.length - s12);
                  if (o11 < 10) {
                    for (7 & (n12 = I2(r13, n12, +(s12 + o11 == t13.length))) && (n12 += 8 - (7 & n12)), r13.l = n12 / 8 | 0, r13.write_shift(2, o11), r13.write_shift(2, 65535 & ~o11); o11-- > 0; )
                      r13[r13.l++] = t13[s12++];
                    n12 = 8 * r13.l;
                    continue;
                  }
                  n12 = I2(r13, n12, +(s12 + o11 == t13.length) + 2);
                  for (var c11 = 0; o11-- > 0; ) {
                    var l3, f3, h3 = t13[s12], u3 = -1, d3 = 0;
                    if ((u3 = i12[c11 = (c11 << 5 ^ h3) & 32767]) && ((u3 |= -32768 & s12) > s12 && (u3 -= 32768), u3 < s12))
                      for (; t13[u3 + d3] == t13[s12 + d3] && d3 < 250; ) ++d3;
                    if (d3 > 2) {
                      (h3 = a10[d3]) <= 22 ? n12 = O2(r13, n12, k2[h3 + 1] >> 1) - 1 : (O2(r13, n12, 3), O2(r13, n12 += 5, k2[h3 - 23] >> 5), n12 += 3);
                      var p3 = h3 < 8 ? 0 : h3 - 4 >> 2;
                      p3 > 0 && (R2(r13, n12, d3 - T2[h3]), n12 += p3), n12 = O2(r13, n12, k2[h3 = e11[s12 - u3]] >> 3) - 3;
                      var m3 = h3 < 4 ? 0 : h3 - 2 >> 1;
                      m3 > 0 && (R2(r13, n12, s12 - u3 - y2[h3]), n12 += m3);
                      for (var g3 = 0; g3 < d3; ++g3) i12[c11] = 32767 & s12, c11 = (c11 << 5 ^ t13[s12]) & 32767, ++s12;
                      o11 -= d3 - 1;
                    } else
                      h3 <= 143 ? h3 += 48 : (f3 = (1 & (f3 = 1)) << (7 & (l3 = n12)), r13[l3 >>> 3] |= f3, n12 = l3 + 1), n12 = O2(r13, n12, k2[h3]), i12[c11] = 32767 & s12, ++s12;
                  }
                  n12 = O2(r13, n12, 0) - 1;
                }
                return r13.l = (n12 + 7) / 8 | 0, r13.l;
              })(t12, r12);
            };
          })();
          function H2(e11) {
            var t11 = as(50 + Math.floor(1.1 * e11.length)), r11 = z2(e11, t11);
            return t11.slice(0, r11);
          }
          var V2 = E2 ? new Uint16Array(32768) : F2(32768), G2 = E2 ? new Uint16Array(32768) : F2(32768), j2 = E2 ? new Uint16Array(128) : F2(128), K2 = 1, Y2 = 1;
          function Z2(e11, t11) {
            var r11 = (function(e12, t12) {
              if (3 == e12[0] && !(3 & e12[1])) return [ev(t12), 2];
              for (var r12 = 0, a10 = 0, n11 = eb(t12 || 262144), s11 = 0, i11 = n11.length >>> 0, o11 = 0, c11 = 0; (1 & a10) == 0; ) {
                if (a10 = _2(e12, r12), r12 += 3, a10 >>> 1 == 0) {
                  7 & r12 && (r12 += 8 - (7 & r12));
                  var l3 = e12[r12 >>> 3] | e12[(r12 >>> 3) + 1] << 8;
                  if (r12 += 32, l3 > 0)
                    for (!t12 && i11 < s11 + l3 && (i11 = (n11 = N2(n11, s11 + l3)).length); l3-- > 0; )
                      n11[s11++] = e12[r12 >>> 3], r12 += 8;
                  continue;
                }
                for (a10 >> 1 == 1 ? (o11 = 9, c11 = 5) : (r12 = (function(e13, t13) {
                  var r13, a11, n12, s12 = S2(e13, t13) + 257, i12 = S2(e13, t13 += 5) + 1;
                  t13 += 5;
                  var o12 = (a11 = 7 & (r13 = t13), ((e13[n12 = r13 >>> 3] | (a11 <= 4 ? 0 : e13[n12 + 1] << 8)) >>> a11 & 15) + 4);
                  t13 += 4;
                  for (var c12 = 0, l4 = E2 ? new Uint8Array(19) : F2(19), f4 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], h4 = 1, u4 = E2 ? new Uint8Array(8) : F2(8), d4 = E2 ? new Uint8Array(8) : F2(8), p4 = l4.length, m4 = 0; m4 < o12; ++m4)
                    l4[w2[m4]] = c12 = _2(e13, t13), h4 < c12 && (h4 = c12), u4[c12]++, t13 += 3;
                  var g3 = 0;
                  for (m4 = 1, u4[0] = 0; m4 <= h4; ++m4) d4[m4] = g3 = g3 + u4[m4 - 1] << 1;
                  for (m4 = 0; m4 < p4; ++m4) 0 != (g3 = l4[m4]) && (f4[m4] = d4[g3]++);
                  var v3 = 0;
                  for (m4 = 0; m4 < p4; ++m4)
                    if (0 != (v3 = l4[m4])) {
                      g3 = k2[f4[m4]] >> 8 - v3;
                      for (var b3 = (1 << 7 - v3) - 1; b3 >= 0; --b3) j2[g3 | b3 << v3] = 7 & v3 | m4 << 3;
                    }
                  var T3 = [];
                  for (h4 = 1; T3.length < s12 + i12; )
                    switch (g3 = j2[A2(e13, t13)], t13 += 7 & g3, g3 >>>= 3) {
                      case 16:
                        for (c12 = 3 + (function(e14, t14) {
                          var r14 = 7 & t14, a12 = t14 >>> 3;
                          return (e14[a12] | (r14 <= 6 ? 0 : e14[a12 + 1] << 8)) >>> r14 & 3;
                        })(e13, t13), t13 += 2, g3 = T3[T3.length - 1]; c12-- > 0; )
                          T3.push(g3);
                        break;
                      case 17:
                        for (c12 = 3 + _2(e13, t13), t13 += 3; c12-- > 0; ) T3.push(0);
                        break;
                      case 18:
                        for (c12 = 11 + A2(e13, t13), t13 += 7; c12-- > 0; ) T3.push(0);
                        break;
                      default:
                        T3.push(g3), h4 < g3 && (h4 = g3);
                    }
                  var y3 = T3.slice(0, s12), x3 = T3.slice(s12);
                  for (m4 = s12; m4 < 286; ++m4) y3[m4] = 0;
                  for (m4 = i12; m4 < 30; ++m4) x3[m4] = 0;
                  return K2 = D2(y3, V2, 286), Y2 = D2(x3, G2, 30), t13;
                })(e12, r12), o11 = K2, c11 = Y2); ; ) {
                  !t12 && i11 < s11 + 32767 && (i11 = (n11 = N2(n11, s11 + 32767)).length);
                  var f3 = C2(e12, r12, o11), h3 = a10 >>> 1 == 1 ? P2[f3] : V2[f3];
                  if (r12 += 15 & h3, ((h3 >>>= 4) >>> 8 & 255) == 0) n11[s11++] = h3;
                  else if (256 == h3) break;
                  else {
                    var u3 = (h3 -= 257) < 8 ? 0 : h3 - 4 >> 2;
                    u3 > 5 && (u3 = 0);
                    var d3 = s11 + T2[h3];
                    u3 > 0 && (d3 += C2(e12, r12, u3), r12 += u3), f3 = C2(e12, r12, c11), r12 += 15 & (h3 = a10 >>> 1 == 1 ? L2[f3] : G2[f3]);
                    var p3 = (h3 >>>= 4) < 4 ? 0 : h3 - 2 >> 1, m3 = y2[h3];
                    for (p3 > 0 && (m3 += C2(e12, r12, p3), r12 += p3), !t12 && i11 < d3 && (i11 = (n11 = N2(n11, d3 + 100)).length); s11 < d3; )
                      n11[s11] = n11[s11 - m3], ++s11;
                  }
                }
              }
              return t12 ? [n11, r12 + 7 >>> 3] : [n11.slice(0, s11), r12 + 7 >>> 3];
            })(e11.slice(e11.l || 0), t11);
            return e11.l += r11[1], r11[0];
          }
          function J2(e11, t11) {
            if (e11) "undefined" != typeof console && console.error(t11);
            else throw Error(t11);
          }
          function q2(e11, r11) {
            aa(e11, 0);
            var a10 = { FileIndex: [], FullPaths: [] };
            l2(a10, { root: r11.root });
            for (var n11 = e11.length - 4; (80 != e11[n11] || 75 != e11[n11 + 1] || 5 != e11[n11 + 2] || 6 != e11[n11 + 3]) && n11 >= 0; )
              --n11;
            e11.l = n11 + 4, e11.l += 4;
            var s11 = e11.read_shift(2);
            e11.l += 6;
            var o11 = e11.read_shift(4);
            for (n11 = 0, e11.l = o11; n11 < s11; ++n11) {
              e11.l += 20;
              var c11 = e11.read_shift(4), f3 = e11.read_shift(4), h3 = e11.read_shift(2), u3 = e11.read_shift(2), d3 = e11.read_shift(2);
              e11.l += 8;
              var p3 = e11.read_shift(4), m3 = i10(e11.slice(e11.l + h3, e11.l + h3 + u3));
              e11.l += h3 + u3 + d3;
              var g3 = e11.l;
              e11.l = p3 + 4, m3 && m3[1] && ((m3[1] || {}).usz && (f3 = m3[1].usz), (m3[1] || {}).csz && (c11 = m3[1].csz)), (function(e12, r12, a11, n12, s12) {
                e12.l += 2;
                var o12, c12, l3, f4, h4, u4, d4, p4 = e12.read_shift(2), m4 = e12.read_shift(2), g4 = (o12 = 65535 & e12.read_shift(2), c12 = 65535 & e12.read_shift(2), l3 = /* @__PURE__ */ new Date(), f4 = 31 & c12, h4 = 15 & (c12 >>>= 5), c12 >>>= 4, l3.setMilliseconds(0), l3.setFullYear(c12 + 1980), l3.setMonth(h4 - 1), l3.setDate(f4), u4 = 31 & o12, d4 = 63 & (o12 >>>= 5), o12 >>>= 6, l3.setHours(o12), l3.setMinutes(d4), l3.setSeconds(u4 << 1), l3);
                if (8257 & p4) throw Error("Unsupported ZIP encryption");
                for (var v3 = e12.read_shift(4), b3 = e12.read_shift(4), w3 = e12.read_shift(4), T3 = e12.read_shift(2), y3 = e12.read_shift(2), E3 = "", k3 = 0; k3 < T3; ++k3)
                  E3 += String.fromCharCode(e12[e12.l++]);
                if (y3) {
                  var x3 = i10(e12.slice(e12.l, e12.l + y3));
                  (x3[21589] || {}).mt && (g4 = x3[21589].mt), (x3[1] || {}).usz && (w3 = x3[1].usz), (x3[1] || {}).csz && (b3 = x3[1].csz), s12 && ((s12[21589] || {}).mt && (g4 = s12[21589].mt), (s12[1] || {}).usz && (w3 = s12[1].usz), (s12[1] || {}).csz && (b3 = s12[1].csz));
                }
                e12.l += y3;
                var _3 = e12.slice(e12.l, e12.l + b3);
                switch (m4) {
                  case 8:
                    _3 = (function(e13, r13) {
                      if (!t10) return Z2(e13, r13);
                      var a12 = new t10.InflateRaw(), n13 = a12._processChunk(e13.slice(e13.l), a12._finishFlushFlag);
                      return e13.l += a12.bytesRead, n13;
                    })(e12, w3);
                    break;
                  case 0:
                    e12.l += b3;
                    break;
                  default:
                    throw Error("Unsupported ZIP Compression method " + m4);
                }
                var S3 = false;
                8 & p4 && (134695760 == e12.read_shift(4) && (e12.read_shift(4), S3 = true), b3 = e12.read_shift(4), w3 = e12.read_shift(4)), b3 != r12 && J2(S3, "Bad compressed size: " + r12 + " != " + b3), w3 != a11 && J2(S3, "Bad uncompressed size: " + a11 + " != " + w3), ee2(n12, E3, _3, { unsafe: true, mt: g4 });
              })(e11, c11, f3, a10, m3), e11.l = g3;
            }
            return a10;
          }
          var Q2 = {
            htm: "text/html",
            xml: "text/xml",
            gif: "image/gif",
            jpg: "image/jpeg",
            png: "image/png",
            mso: "application/x-mso",
            thmx: "application/vnd.ms-officetheme",
            sh33tj5: "application/octet-stream"
          };
          function ee2(e11, t11, r11, a10) {
            var n11 = a10 && a10.unsafe;
            n11 || l2(e11);
            var i11 = !n11 && tr.find(e11, t11);
            if (!i11) {
              var o11 = e11.FullPaths[0];
              t11.slice(0, o11.length) == o11 ? o11 = t11 : ("/" != o11.slice(-1) && (o11 += "/"), o11 = (o11 + t11).replace("//", "/")), i11 = { name: s10(t11), type: 2 }, e11.FileIndex.push(i11), e11.FullPaths.push(o11), n11 || tr.utils.cfb_gc(e11);
            }
            return i11.content = r11, i11.size = r11 ? r11.length : 0, a10 && (a10.CLSID && (i11.clsid = a10.CLSID), a10.mt && (i11.mt = a10.mt), a10.ct && (i11.ct = a10.ct)), i11;
          }
          return r10.find = function(e11, t11) {
            var r11 = e11.FullPaths.map(function(e12) {
              return e12.toUpperCase();
            }), a10 = r11.map(function(e12) {
              var t12 = e12.split("/");
              return t12[t12.length - ("/" == e12.slice(-1) ? 2 : 1)];
            }), n11 = false;
            47 === t11.charCodeAt(0) ? (n11 = true, t11 = r11[0].slice(0, -1) + t11) : n11 = -1 !== t11.indexOf("/");
            var s11 = t11.toUpperCase(), i11 = true === n11 ? r11.indexOf(s11) : a10.indexOf(s11);
            if (-1 !== i11) return e11.FileIndex[i11];
            var o11 = !s11.match(e_);
            for (s11 = s11.replace(ex, ""), o11 && (s11 = s11.replace(e_, "!")), i11 = 0; i11 < r11.length; ++i11)
              if ((o11 ? r11[i11].replace(e_, "!") : r11[i11]).replace(ex, "") == s11 || (o11 ? a10[i11].replace(e_, "!") : a10[i11]).replace(ex, "") == s11)
                return e11.FileIndex[i11];
            return null;
          }, r10.read = function(t11, r11) {
            var n11 = r11 && r11.type;
            switch (!n11 && ep && a.isBuffer(t11) && (n11 = "buffer"), n11 || "base64") {
              case "file":
                return e10 || (e10 = X), o10(e10.readFileSync(t11), r11);
              case "base64":
                return o10(ew(ed(t11)), r11);
              case "binary":
                return o10(ew(t11), r11);
            }
            return o10(t11, r11);
          }, r10.parse = o10, r10.write = function(t11, r11) {
            var n11 = h2(t11, r11);
            switch (r11 && r11.type || "buffer") {
              case "file":
                e10 || (e10 = X), e10.writeFileSync(r11.filename, n11);
                break;
              case "binary":
                return "string" == typeof n11 ? n11 : b2(n11);
              case "base64":
                return eu("string" == typeof n11 ? n11 : b2(n11));
              case "buffer":
                if (ep) return a.isBuffer(n11) ? n11 : em(n11);
              case "array":
                return "string" == typeof n11 ? ew(n11) : n11;
            }
            return n11;
          }, r10.writeFile = function(t11, r11, a10) {
            e10 || (e10 = X);
            var n11 = h2(t11, a10);
            e10.writeFileSync(r11, n11);
          }, r10.utils = {
            cfb_new: function(e11) {
              var t11 = {};
              return l2(t11, e11), t11;
            },
            cfb_add: ee2,
            cfb_del: function(e11, t11) {
              l2(e11);
              var r11 = tr.find(e11, t11);
              if (r11) {
                for (var a10 = 0; a10 < e11.FileIndex.length; ++a10)
                  if (e11.FileIndex[a10] == r11) return e11.FileIndex.splice(a10, 1), e11.FullPaths.splice(a10, 1), true;
              }
              return false;
            },
            cfb_mov: function(e11, t11, r11) {
              l2(e11);
              var a10 = tr.find(e11, t11);
              if (a10) {
                for (var n11 = 0; n11 < e11.FileIndex.length; ++n11)
                  if (e11.FileIndex[n11] == a10) return e11.FileIndex[n11].name = s10(r11), e11.FullPaths[n11] = r11, true;
              }
              return false;
            },
            cfb_gc: function(e11) {
              f2(e11, true);
            },
            ReadShift: r8,
            CheckField: ar,
            prep_blob: aa,
            bconcat: ek,
            use_zlib: function(e11) {
              try {
                var r11 = new e11.InflateRaw();
                if (r11._processChunk(new Uint8Array([3, 0]), r11._finishFlushFlag), r11.bytesRead) t10 = e11;
                else throw Error("zlib does not expose bytesRead");
              } catch (e12) {
                console.error("cannot use native zlib: " + (e12.message || e12));
              }
            },
            _deflateRaw: H2,
            _inflateRaw: Z2,
            consts: v2
          }, r10;
        })();
        function ta(e10) {
          if ("string" == typeof e10) return eT(e10);
          if (Array.isArray(e10)) {
            if ("undefined" == typeof Uint8Array) throw Error("Unsupported");
            return new Uint8Array(e10);
          }
          return e10;
        }
        function tn(e10, t10, r10) {
          if (void 0 !== X && X.writeFileSync) return r10 ? X.writeFileSync(e10, t10, r10) : X.writeFileSync(e10, t10);
          if ("undefined" != typeof Deno) {
            if (r10 && "string" == typeof t10)
              switch (r10) {
                case "utf8":
                  t10 = new TextEncoder(r10).encode(t10);
                  break;
                case "binary":
                  t10 = eT(t10);
                  break;
                default:
                  throw Error("Unsupported encoding " + r10);
              }
            return Deno.writeFileSync(e10, t10);
          }
          var a10 = "utf8" == r10 ? rh(t10) : t10;
          if ("undefined" != typeof IE_SaveFile) return IE_SaveFile(a10, e10);
          if ("undefined" != typeof Blob) {
            var n10 = new Blob([ta(a10)], { type: "application/octet-stream" });
            if ("undefined" != typeof navigator && navigator.msSaveBlob) return navigator.msSaveBlob(n10, e10);
            if ("undefined" != typeof saveAs) return saveAs(n10, e10);
            if ("undefined" != typeof URL && "undefined" != typeof document && document.createElement && URL.createObjectURL) {
              var s10 = URL.createObjectURL(n10);
              if ("object" == typeof chrome && "function" == typeof (chrome.downloads || {}).download)
                return URL.revokeObjectURL && "undefined" != typeof setTimeout && setTimeout(function() {
                  URL.revokeObjectURL(s10);
                }, 6e4), chrome.downloads.download({ url: s10, filename: e10, saveAs: true });
              var i10 = document.createElement("a");
              if (null != i10.download)
                return i10.download = e10, i10.href = s10, document.body.appendChild(i10), i10.click(), document.body.removeChild(i10), URL.revokeObjectURL && "undefined" != typeof setTimeout && setTimeout(function() {
                  URL.revokeObjectURL(s10);
                }, 6e4), s10;
            } else if ("undefined" != typeof URL && !URL.createObjectURL && "object" == typeof chrome) {
              var o10 = "data:application/octet-stream;base64," + (function(e11) {
                for (var t11 = "", r11 = 0, a11 = 0, n11 = 0, s11 = 0, i11 = 0, o11 = 0, c11 = 0, l2 = 0; l2 < e11.length; )
                  s11 = (r11 = e11[l2++]) >> 2, i11 = (3 & r11) << 4 | (a11 = e11[l2++]) >> 4, o11 = (15 & a11) << 2 | (n11 = e11[l2++]) >> 6, c11 = 63 & n11, isNaN(a11) ? o11 = c11 = 64 : isNaN(n11) && (c11 = 64), t11 += eh.charAt(s11) + eh.charAt(i11) + eh.charAt(o11) + eh.charAt(c11);
                return t11;
              })(new Uint8Array(ta(a10)));
              return chrome.downloads.download({ url: o10, filename: e10, saveAs: true });
            }
          }
          if ("undefined" != typeof $ && "undefined" != typeof File && "undefined" != typeof Folder)
            try {
              var c10 = File(e10);
              return c10.open("w"), c10.encoding = "binary", Array.isArray(t10) && (t10 = ey(t10)), c10.write(t10), c10.close(), t10;
            } catch (e11) {
              if (!e11.message || -1 == e11.message.indexOf("onstruct")) throw e11;
            }
          throw Error("cannot save file " + e10);
        }
        function ts(e10) {
          for (var t10 = Object.keys(e10), r10 = [], a10 = 0; a10 < t10.length; ++a10)
            Object.prototype.hasOwnProperty.call(e10, t10[a10]) && r10.push(t10[a10]);
          return r10;
        }
        function ti(e10, t10) {
          for (var r10 = [], a10 = ts(e10), n10 = 0; n10 !== a10.length; ++n10) null == r10[e10[a10[n10]][t10]] && (r10[e10[a10[n10]][t10]] = a10[n10]);
          return r10;
        }
        function to(e10) {
          for (var t10 = [], r10 = ts(e10), a10 = 0; a10 !== r10.length; ++a10) t10[e10[r10[a10]]] = r10[a10];
          return t10;
        }
        function tc(e10) {
          for (var t10 = [], r10 = ts(e10), a10 = 0; a10 !== r10.length; ++a10) t10[e10[r10[a10]]] = parseInt(r10[a10], 10);
          return t10;
        }
        var tl = Date.UTC(1899, 11, 30, 0, 0, 0), tf = Date.UTC(1899, 11, 31, 0, 0, 0), th = Date.UTC(1904, 0, 1, 0, 0, 0);
        function tu(e10, t10) {
          var r10 = (e10.getTime() - tl) / 864e5;
          return t10 ? (r10 -= 1462) < -1402 ? r10 - 1 : r10 : r10 < 60 ? r10 - 1 : r10;
        }
        function td(e10) {
          if (e10 >= 60 && e10 < 61) return e10;
          var t10 = /* @__PURE__ */ new Date();
          return t10.setTime((e10 > 60 ? e10 : e10 + 1) * 864e5 + tl), t10;
        }
        var tp = /^(\d+):(\d+)(:\d+)?(\.\d+)?$/, tm = /^(\d+)-(\d+)-(\d+)$/, tg = /^(\d+)-(\d+)-(\d+)[T ](\d+):(\d+)(:\d+)?(\.\d+)?$/;
        function tv(e10, t10) {
          if (e10 instanceof Date) return e10;
          var r10 = e10.match(tp);
          return new Date(
            r10 ? (t10 ? th : tf) + ((60 * parseInt(r10[1], 10) + parseInt(r10[2], 10)) * 60 + (r10[3] ? parseInt(r10[3].slice(1), 10) : 0)) * 1e3 + (r10[4] ? parseInt((r10[4] + "000").slice(1, 4), 10) : 0) : (r10 = e10.match(tm)) ? Date.UTC(+r10[1], r10[2] - 1, +r10[3], 0, 0, 0, 0) : (r10 = e10.match(tg)) ? Date.UTC(
              +r10[1],
              r10[2] - 1,
              +r10[3],
              +r10[4],
              +r10[5],
              r10[6] && parseInt(r10[6].slice(1), 10) || 0,
              r10[7] && parseInt((r10[7] + "0000").slice(1, 4), 10) || 0
            ) : e10
          );
        }
        function tb(e10, t10) {
          if (ep && a.isBuffer(e10)) {
            if (t10 && eg) {
              if (255 == e10[0] && 254 == e10[1]) return rh(e10.slice(2).toString("utf16le"));
              if (254 == e10[1] && 255 == e10[2]) return rh(ei(e10.slice(2).toString("binary")));
            }
            return e10.toString("binary");
          }
          if ("undefined" != typeof TextDecoder)
            try {
              if (t10) {
                if (255 == e10[0] && 254 == e10[1]) return rh(new TextDecoder("utf-16le").decode(e10.slice(2)));
                if (254 == e10[0] && 255 == e10[1]) return rh(new TextDecoder("utf-16be").decode(e10.slice(2)));
              }
              var r10 = {
                "€": "",
                "‚": "",
                ƒ: "",
                "„": "",
                "…": "",
                "†": "",
                "‡": "",
                "ˆ": "",
                "‰": "",
                Š: "",
                "‹": "",
                Œ: "",
                Ž: "",
                "‘": "",
                "’": "",
                "“": "",
                "”": "",
                "•": "",
                "–": "",
                "—": "",
                "˜": "",
                "™": "",
                š: "",
                "›": "",
                œ: "",
                ž: "",
                Ÿ: ""
              };
              return Array.isArray(e10) && (e10 = new Uint8Array(e10)), new TextDecoder("latin1").decode(e10).replace(/[€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—˜™š›œžŸ]/g, function(e11) {
                return r10[e11] || e11;
              });
            } catch (e11) {
            }
          var n10 = [], s10 = 0;
          try {
            for (s10 = 0; s10 < e10.length - 65536; s10 += 65536) n10.push(String.fromCharCode.apply(0, e10.slice(s10, s10 + 65536)));
            n10.push(String.fromCharCode.apply(0, e10.slice(s10)));
          } catch (t11) {
            try {
              for (; s10 < e10.length - 16384; s10 += 16384) n10.push(String.fromCharCode.apply(0, e10.slice(s10, s10 + 16384)));
              n10.push(String.fromCharCode.apply(0, e10.slice(s10)));
            } catch (t12) {
              for (; s10 != e10.length; ++s10) n10.push(String.fromCharCode(e10[s10]));
            }
          }
          return n10.join("");
        }
        function tw(e10) {
          if ("undefined" != typeof JSON && !Array.isArray(e10)) return JSON.parse(JSON.stringify(e10));
          if ("object" != typeof e10 || null == e10) return e10;
          if (e10 instanceof Date) return new Date(e10.getTime());
          var t10 = {};
          for (var r10 in e10) Object.prototype.hasOwnProperty.call(e10, r10) && (t10[r10] = tw(e10[r10]));
          return t10;
        }
        function tT(e10, t10) {
          for (var r10 = ""; r10.length < t10; ) r10 += e10;
          return r10;
        }
        function ty(e10) {
          var t10 = Number(e10);
          if (!isNaN(t10)) return isFinite(t10) ? t10 : NaN;
          if (!/\d/.test(e10)) return t10;
          var r10 = 1, a10 = e10.replace(/([\d]),([\d])/g, "$1$2").replace(/[$]/g, "").replace(/[%]/g, function() {
            return r10 *= 100, "";
          });
          return isNaN(t10 = Number(a10)) && isNaN(
            t10 = Number(
              a10 = a10.replace(/[(]([^()]*)[)]/, function(e11, t11) {
                return r10 = -r10, t11;
              })
            )
          ) ? t10 : t10 / r10;
        }
        var tE = /^(0?\d|1[0-2])(?:|:([0-5]?\d)(?:|(\.\d+)(?:|:([0-5]?\d))|:([0-5]?\d)(|\.\d+)))\s+([ap])m?$/, tk = /^([01]?\d|2[0-3])(?:|:([0-5]?\d)(?:|(\.\d+)(?:|:([0-5]?\d))|:([0-5]?\d)(|\.\d+)))$/, tx = /^(\d+)-(\d+)-(\d+)[T ](\d+):(\d+)(:\d+)(\.\d+)?[Z]?$/, t_ = -177984e5 == (/* @__PURE__ */ new Date("6/9/69 00:00 UTC")).valueOf(), tS = [
          "january",
          "february",
          "march",
          "april",
          "may",
          "june",
          "july",
          "august",
          "september",
          "october",
          "november",
          "december"
        ];
        function tA(e10) {
          if (tx.test(e10)) return -1 == e10.indexOf("Z") ? tO(new Date(e10)) : new Date(e10);
          var t10 = e10.toLowerCase(), r10 = t10.replace(/\s+/g, " ").trim(), a10 = r10.match(tE);
          if (a10) {
            var n10 = a10;
            if (!n10[2]) return new Date(Date.UTC(1899, 11, 31, n10[1] % 12 + 12 * ("p" == n10[7]), 0, 0, 0));
            if (n10[3])
              if (n10[4])
                return new Date(
                  Date.UTC(1899, 11, 31, n10[1] % 12 + 12 * ("p" == n10[7]), +n10[2], +n10[4], 1e3 * parseFloat(n10[3]))
                );
              else return new Date(Date.UTC(1899, 11, 31, 12 * ("p" == n10[7]), +n10[1], +n10[2], 1e3 * parseFloat(n10[3])));
            return new Date(
              n10[5] ? Date.UTC(
                1899,
                11,
                31,
                n10[1] % 12 + 12 * ("p" == n10[7]),
                +n10[2],
                +n10[5],
                n10[6] ? 1e3 * parseFloat(n10[6]) : 0
              ) : Date.UTC(1899, 11, 31, n10[1] % 12 + 12 * ("p" == n10[7]), +n10[2], 0, 0)
            );
          }
          if (a10 = r10.match(tk)) {
            var s10 = a10;
            if (!s10[2]) return new Date(Date.UTC(1899, 11, 31, +s10[1], 0, 0, 0));
            if (s10[3])
              if (s10[4]) return new Date(Date.UTC(1899, 11, 31, +s10[1], +s10[2], +s10[4], 1e3 * parseFloat(s10[3])));
              else return new Date(Date.UTC(1899, 11, 31, 0, +s10[1], +s10[2], 1e3 * parseFloat(s10[3])));
            return new Date(
              s10[5] ? Date.UTC(1899, 11, 31, +s10[1], +s10[2], +s10[5], s10[6] ? 1e3 * parseFloat(s10[6]) : 0) : Date.UTC(1899, 11, 31, +s10[1], +s10[2], 0, 0)
            );
          }
          if (a10 = r10.match(tg))
            return new Date(
              Date.UTC(
                +a10[1],
                a10[2] - 1,
                +a10[3],
                +a10[4],
                +a10[5],
                a10[6] && parseInt(a10[6].slice(1), 10) || 0,
                a10[7] && parseInt((a10[7] + "0000").slice(1, 4), 10) || 0
              )
            );
          var i10 = new Date(t_ && -1 == e10.indexOf("UTC") ? e10 + " UTC" : e10), o10 = /* @__PURE__ */ new Date(NaN), c10 = i10.getYear();
          if (isNaN((i10.getMonth(), i10.getDate()))) return o10;
          if (t10.match(/jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/)) {
            if ((t10 = t10.replace(/[^a-z]/g, "").replace(/([^a-z]|^)[ap]m?([^a-z]|$)/, "")).length > 3 && -1 == tS.indexOf(t10))
              return o10;
          } else if (t10.replace(/[ap]m?/, "").match(/[a-z]/)) return o10;
          return c10 < 0 || c10 > 8099 || e10.match(/[^-0-9:,\/\\\ ]/) ? o10 : i10;
        }
        var tC = (E = 5 == "abacaba".split(/(:?b)/i).length, function(e10, t10, r10) {
          if (E || "string" == typeof t10) return e10.split(t10);
          for (var a10 = e10.split(t10), n10 = [a10[0]], s10 = 1; s10 < a10.length; ++s10) n10.push(r10), n10.push(a10[s10]);
          return n10;
        });
        function tI(e10) {
          return new Date(
            e10.getUTCFullYear(),
            e10.getUTCMonth(),
            e10.getUTCDate(),
            e10.getUTCHours(),
            e10.getUTCMinutes(),
            e10.getUTCSeconds(),
            e10.getUTCMilliseconds()
          );
        }
        function tO(e10) {
          return new Date(
            Date.UTC(
              e10.getFullYear(),
              e10.getMonth(),
              e10.getDate(),
              e10.getHours(),
              e10.getMinutes(),
              e10.getSeconds(),
              e10.getMilliseconds()
            )
          );
        }
        function tR(e10) {
          var t10 = e10.slice(0, 1024).indexOf("<!DOCTYPE");
          if (-1 == t10) return e10;
          var r10 = e10.match(/<[\w]/);
          return r10 ? e10.slice(0, t10) + e10.slice(r10.index) : e10;
        }
        function tN(e10, t10, r10) {
          for (var a10 = [], n10 = e10.indexOf(t10); n10 > -1; ) {
            var s10 = e10.indexOf(r10, n10 + t10.length);
            if (-1 == s10) break;
            a10.push(e10.slice(n10, s10 + r10.length)), n10 = e10.indexOf(t10, s10 + r10.length);
          }
          return a10.length > 0 ? a10 : null;
        }
        function tF(e10, t10, r10) {
          var a10 = [], n10 = 0, s10 = e10.indexOf(t10);
          if (-1 == s10) return e10;
          for (; s10 > -1; ) {
            a10.push(e10.slice(n10, s10));
            var i10 = e10.indexOf(r10, s10 + t10.length);
            if (-1 == i10) break;
            -1 == (s10 = e10.indexOf(t10, n10 = i10 + r10.length)) && a10.push(e10.slice(n10));
          }
          return a10.join("");
        }
        var tD = { " ": 1, "	": 1, "\r": 1, "\n": 1, ">": 1 };
        function tP(e10, t10) {
          for (var r10 = e10.indexOf("<" + t10), a10 = t10.length + 1, n10 = e10.length; r10 >= 0 && r10 <= n10 - a10 && !tD[e10.charAt(r10 + a10)]; )
            r10 = e10.indexOf("<" + t10, r10 + 1);
          if (-1 === r10) return null;
          var s10 = e10.indexOf(">", r10 + t10.length);
          if (-1 === s10) return null;
          var i10 = "</" + t10 + ">", o10 = e10.indexOf(i10, s10);
          return -1 == o10 ? null : [e10.slice(r10, o10 + i10.length), e10.slice(s10 + 1, o10)];
        }
        var tL = (k = {}, function(e10, t10) {
          var r10 = k[t10];
          r10 || (k[t10] = r10 = [RegExp("<(?:\\w+:)?" + t10 + "\\b[^<>]*>", "g"), RegExp("</(?:\\w+:)?" + t10 + ">", "g")]), r10[0].lastIndex = r10[1].lastIndex = 0;
          var a10 = r10[0].exec(e10);
          if (!a10) return null;
          var n10 = a10.index, s10 = r10[0].lastIndex;
          if (r10[1].lastIndex = r10[0].lastIndex, !(a10 = r10[1].exec(e10))) return null;
          var i10 = a10.index, o10 = r10[1].lastIndex;
          return [e10.slice(n10, o10), e10.slice(s10, i10)];
        }), tM = (x = {}, function(e10, t10) {
          var r10, a10 = [], n10 = x[t10];
          for (n10 || (x[t10] = n10 = [RegExp("<(?:\\w+:)?" + t10 + "\\b[^<>]*>", "g"), RegExp("</(?:\\w+:)?" + t10 + ">", "g")]), n10[0].lastIndex = n10[1].lastIndex = 0; r10 = n10[0].exec(e10); ) {
            var s10 = r10.index;
            if (n10[1].lastIndex = n10[0].lastIndex, !(r10 = n10[1].exec(e10))) return null;
            var i10 = n10[1].lastIndex;
            a10.push(e10.slice(s10, i10)), n10[0].lastIndex = n10[1].lastIndex;
          }
          return 0 == a10.length ? null : a10;
        }), tU = (_ = {}, function(e10, t10) {
          var r10, a10 = [], n10 = _[t10];
          n10 || (_[t10] = n10 = [RegExp("<(?:\\w+:)?" + t10 + "\\b[^<>]*>", "g"), RegExp("</(?:\\w+:)?" + t10 + ">", "g")]), n10[0].lastIndex = n10[1].lastIndex = 0;
          for (var s10 = 0, i10 = 0; r10 = n10[0].exec(e10); ) {
            if (s10 = r10.index, a10.push(e10.slice(i10, s10)), i10 = s10, n10[1].lastIndex = n10[0].lastIndex, !(r10 = n10[1].exec(e10)))
              return null;
            i10 = n10[1].lastIndex, n10[0].lastIndex = n10[1].lastIndex;
          }
          return a10.push(e10.slice(i10)), 0 == a10.length ? "" : a10.join("");
        }), tB = (S = {}, function(e10, t10) {
          var r10, a10 = [], n10 = S[t10];
          for (n10 || (S[t10] = n10 = [RegExp("<" + t10 + "\\b[^<>]*>", "ig"), RegExp("</" + t10 + ">", "ig")]), n10[0].lastIndex = n10[1].lastIndex = 0; r10 = n10[0].exec(e10); ) {
            var s10 = r10.index;
            if (n10[1].lastIndex = n10[0].lastIndex, !(r10 = n10[1].exec(e10))) return null;
            var i10 = n10[1].lastIndex;
            a10.push(e10.slice(s10, i10)), n10[0].lastIndex = n10[1].lastIndex;
          }
          return 0 == a10.length ? null : a10;
        });
        function tW(e10) {
          return e10 ? e10.content && e10.type ? tb(e10.content, true) : e10.data ? eo(e10.data) : e10.asNodeBuffer && ep ? eo(e10.asNodeBuffer().toString("binary")) : e10.asBinary ? eo(e10.asBinary()) : e10._data && e10._data.getContent ? eo(tb(Array.prototype.slice.call(e10._data.getContent(), 0))) : null : null;
        }
        function tz(e10) {
          if (!e10) return null;
          if (e10.data) return en(e10.data);
          if (e10.asNodeBuffer && ep) return e10.asNodeBuffer();
          if (e10._data && e10._data.getContent) {
            var t10 = e10._data.getContent();
            return "string" == typeof t10 ? en(t10) : Array.prototype.slice.call(t10);
          }
          return e10.content && e10.type ? e10.content : null;
        }
        function tH(e10, t10) {
          for (var r10 = e10.FullPaths || ts(e10.files), a10 = t10.toLowerCase().replace(/[\/]/g, "\\"), n10 = a10.replace(/\\/g, "/"), s10 = 0; s10 < r10.length; ++s10) {
            var i10 = r10[s10].replace(/^Root Entry[\/]/, "").toLowerCase();
            if (a10 == i10 || n10 == i10) return e10.files ? e10.files[r10[s10]] : e10.FileIndex[s10];
          }
          return null;
        }
        function tV(e10, t10) {
          var r10 = tH(e10, t10);
          if (null == r10) throw Error("Cannot find file " + t10 + " in zip");
          return r10;
        }
        function t$(e10, t10, r10) {
          if (!r10) {
            var a10;
            return (a10 = tV(e10, t10)) && ".bin" === a10.name.slice(-4) ? tz(a10) : tW(a10);
          }
          if (!t10) return null;
          try {
            return t$(e10, t10);
          } catch (e11) {
            return null;
          }
        }
        function tG(e10, t10, r10) {
          if (!r10) return tW(tV(e10, t10));
          if (!t10) return null;
          try {
            return tG(e10, t10);
          } catch (e11) {
            return null;
          }
        }
        function tX(e10) {
          for (var t10 = e10.FullPaths || ts(e10.files), r10 = [], a10 = 0; a10 < t10.length; ++a10)
            "/" != t10[a10].slice(-1) && r10.push(t10[a10].replace(/^Root Entry[\/]/, ""));
          return r10.sort();
        }
        function tj(e10, t10, r10) {
          if (e10.FullPaths) {
            if (Array.isArray(r10) && "string" == typeof r10[0] && (r10 = r10.join("")), "string" == typeof r10) {
              var a10;
              return a10 = ep ? em(r10) : (function(e11) {
                for (var t11 = [], r11 = 0, a11 = e11.length + 250, n10 = ev(e11.length + 255), s10 = 0; s10 < e11.length; ++s10) {
                  var i10 = e11.charCodeAt(s10);
                  if (i10 < 128) n10[r11++] = i10;
                  else if (i10 < 2048) n10[r11++] = 192 | i10 >> 6 & 31, n10[r11++] = 128 | 63 & i10;
                  else if (i10 >= 55296 && i10 < 57344) {
                    i10 = (1023 & i10) + 64;
                    var o10 = 1023 & e11.charCodeAt(++s10);
                    n10[r11++] = 240 | i10 >> 8 & 7, n10[r11++] = 128 | i10 >> 2 & 63, n10[r11++] = 128 | o10 >> 6 & 15 | (3 & i10) << 4, n10[r11++] = 128 | 63 & o10;
                  } else
                    n10[r11++] = 224 | i10 >> 12 & 15, n10[r11++] = 128 | i10 >> 6 & 63, n10[r11++] = 128 | 63 & i10;
                  r11 > a11 && (t11.push(n10.slice(0, r11)), r11 = 0, n10 = ev(65535), a11 = 65530);
                }
                return t11.push(n10.slice(0, r11)), ek(t11);
              })(r10), tr.utils.cfb_add(e10, t10, a10);
            }
            tr.utils.cfb_add(e10, t10, r10);
          } else e10.file(t10, r10);
        }
        function tK() {
          return tr.utils.cfb_new();
        }
        function tY(e10, t10) {
          switch (t10.type) {
            case "base64":
              return tr.read(e10, { type: "base64" });
            case "binary":
              return tr.read(e10, { type: "binary" });
            case "buffer":
            case "array":
              return tr.read(e10, { type: "buffer" });
          }
          throw Error("Unrecognized type " + t10.type);
        }
        function tZ(e10, t10) {
          if ("/" == e10.charAt(0)) return e10.slice(1);
          var r10 = t10.split("/");
          "/" != t10.slice(-1) && r10.pop();
          for (var a10 = e10.split("/"); 0 !== a10.length; ) {
            var n10 = a10.shift();
            ".." === n10 ? r10.pop() : "." !== n10 && r10.push(n10);
          }
          return r10.join("/");
        }
        var tJ = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n', tq = /\s([^"\s?>\/]+)\s*=\s*((?:")([^"]*)(?:")|(?:')([^']*)(?:')|([^'">\s]+))/g, tQ = /<[\/\?]?[a-zA-Z0-9:_-]+(?:\s+[^"\s?<>\/]+\s*=\s*(?:"[^"]*"|'[^']*'|[^'"<>\s=]+))*\s*[\/\?]?>/gm, t0 = tJ.match(tQ) ? tQ : /<[^<>]*>/g, t1 = /<\w*:/, t22 = /<(\/?)\w+:/;
        function t4(e10, t10, r10) {
          for (var a10 = {}, n10 = 0, s10 = 0; n10 !== e10.length && 32 !== (s10 = e10.charCodeAt(n10)) && 10 !== s10 && 13 !== s10; ++n10) ;
          if (t10 || (a10[0] = e10.slice(0, n10)), n10 === e10.length) return a10;
          var i10 = e10.match(tq), o10 = 0, c10 = "", l2 = 0, f2 = "", h2 = "", u2 = 1;
          if (i10)
            for (l2 = 0; l2 != i10.length; ++l2) {
              for (s10 = 0, h2 = i10[l2].slice(1); s10 != h2.length && 61 !== h2.charCodeAt(s10); ++s10) ;
              for (f2 = h2.slice(0, s10).trim(); 32 == h2.charCodeAt(s10 + 1); ) ++s10;
              for (o10 = 0, u2 = +(34 == (n10 = h2.charCodeAt(s10 + 1)) || 39 == n10), c10 = h2.slice(s10 + 1 + u2, h2.length - u2); o10 != f2.length && 58 !== f2.charCodeAt(o10); ++o10) ;
              if (o10 === f2.length)
                f2.indexOf("_") > 0 && (f2 = f2.slice(0, f2.indexOf("_"))), a10[f2] = c10, r10 || (a10[f2.toLowerCase()] = c10);
              else {
                var d2 = (5 === o10 && "xmlns" === f2.slice(0, 5) ? "xmlns" : "") + f2.slice(o10 + 1);
                if (a10[d2] && "ext" == f2.slice(o10 - 3, o10)) continue;
                a10[d2] = c10, r10 || (a10[d2.toLowerCase()] = c10);
              }
            }
          return a10;
        }
        function t3(e10) {
          return e10.replace(t22, "<$1");
        }
        var t5 = { "&quot;": '"', "&apos;": "'", "&gt;": ">", "&lt;": "<", "&amp;": "&" }, t6 = to(t5), t8 = (A = /&(?:quot|apos|gt|lt|amp|#x?([\da-fA-F]+));/gi, C = /_x([\da-fA-F]{4})_/gi, function(e10, t10) {
          var r10 = (function e11(t11) {
            var r11 = t11 + "", a10 = r11.indexOf("<![CDATA[");
            if (-1 == a10)
              return r11.replace(A, function(e12, t12) {
                return t5[e12] || String.fromCharCode(parseInt(t12, e12.indexOf("x") > -1 ? 16 : 10)) || e12;
              }).replace(C, function(e12, t12) {
                return String.fromCharCode(parseInt(t12, 16));
              });
            var n10 = r11.indexOf("]]>");
            return e11(r11.slice(0, a10)) + r11.slice(a10 + 9, n10) + e11(r11.slice(n10 + 3));
          })(e10);
          return t10 ? r10.replace(/\r\n/g, "\n") : r10;
        }), t7 = /[&<>'"]/g, t9 = /[\u0000-\u0008\u000b-\u001f\uFFFE-\uFFFF]/g;
        function re(e10) {
          return (e10 + "").replace(t7, function(e11) {
            return t6[e11];
          }).replace(t9, function(e11) {
            return "_x" + ("000" + e11.charCodeAt(0).toString(16)).slice(-4) + "_";
          });
        }
        function rt(e10) {
          return re(e10).replace(/ /g, "_x0020_");
        }
        var rr = /[\u0000-\u001f]/g;
        function ra(e10) {
          return (e10 + "").replace(t7, function(e11) {
            return t6[e11];
          }).replace(/\n/g, "<br/>").replace(rr, function(e11) {
            return "&#x" + ("000" + e11.charCodeAt(0).toString(16)).slice(-4) + ";";
          });
        }
        var rn = /* @__PURE__ */ (function() {
          var e10 = /&#(\d+);/g;
          function t10(e11, t11) {
            return String.fromCharCode(parseInt(t11, 10));
          }
          return function(r10) {
            return r10.replace(e10, t10);
          };
        })();
        function rs(e10) {
          switch (e10) {
            case 1:
            case true:
            case "1":
            case "true":
              return true;
          }
          return false;
        }
        function ri(e10) {
          for (var t10 = "", r10 = 0, a10 = 0, n10 = 0, s10 = 0, i10 = 0, o10 = 0; r10 < e10.length; ) {
            if ((a10 = e10.charCodeAt(r10++)) < 128) {
              t10 += String.fromCharCode(a10);
              continue;
            }
            if (n10 = e10.charCodeAt(r10++), a10 > 191 && a10 < 224) {
              t10 += String.fromCharCode((31 & a10) << 6 | 63 & n10);
              continue;
            }
            if (s10 = e10.charCodeAt(r10++), a10 < 240) {
              t10 += String.fromCharCode((15 & a10) << 12 | (63 & n10) << 6 | 63 & s10);
              continue;
            }
            t10 += String.fromCharCode(
              55296 + ((o10 = ((7 & a10) << 18 | (63 & n10) << 12 | (63 & s10) << 6 | 63 & e10.charCodeAt(r10++)) - 65536) >>> 10 & 1023)
            ), t10 += String.fromCharCode(56320 + (1023 & o10));
          }
          return t10;
        }
        function ro(e10) {
          var t10, r10, a10, n10 = ev(2 * e10.length), s10 = 1, i10 = 0, o10 = 0;
          for (r10 = 0; r10 < e10.length; r10 += s10)
            s10 = 1, (a10 = e10.charCodeAt(r10)) < 128 ? t10 = a10 : a10 < 224 ? (t10 = (31 & a10) * 64 + (63 & e10.charCodeAt(r10 + 1)), s10 = 2) : a10 < 240 ? (t10 = (15 & a10) * 4096 + (63 & e10.charCodeAt(r10 + 1)) * 64 + (63 & e10.charCodeAt(r10 + 2)), s10 = 3) : (s10 = 4, o10 = 55296 + ((t10 = (7 & a10) * 262144 + (63 & e10.charCodeAt(r10 + 1)) * 4096 + (63 & e10.charCodeAt(r10 + 2)) * 64 + (63 & e10.charCodeAt(r10 + 3)) - 65536) >>> 10 & 1023), t10 = 56320 + (1023 & t10)), 0 !== o10 && (n10[i10++] = 255 & o10, n10[i10++] = o10 >>> 8, o10 = 0), n10[i10++] = t10 % 256, n10[i10++] = t10 >>> 8;
          return n10.slice(0, i10).toString("ucs2");
        }
        function rc(e10) {
          return em(e10, "binary").toString("utf8");
        }
        var rl = "foo bar bazâð£", rf = ep && (rc(rl) == ri(rl) && rc || ro(rl) == ri(rl) && ro) || ri, rh = ep ? function(e10) {
          return em(e10, "utf8").toString("binary");
        } : function(e10) {
          for (var t10 = [], r10 = 0, a10 = 0, n10 = 0; r10 < e10.length; )
            switch (a10 = e10.charCodeAt(r10++), true) {
              case a10 < 128:
                t10.push(String.fromCharCode(a10));
                break;
              case a10 < 2048:
                t10.push(String.fromCharCode(192 + (a10 >> 6))), t10.push(String.fromCharCode(128 + (63 & a10)));
                break;
              case (a10 >= 55296 && a10 < 57344):
                a10 -= 55296, t10.push(String.fromCharCode(240 + ((n10 = e10.charCodeAt(r10++) - 56320 + (a10 << 10)) >> 18 & 7))), t10.push(String.fromCharCode(144 + (n10 >> 12 & 63))), t10.push(String.fromCharCode(128 + (n10 >> 6 & 63))), t10.push(String.fromCharCode(128 + (63 & n10)));
                break;
              default:
                t10.push(String.fromCharCode(224 + (a10 >> 12))), t10.push(String.fromCharCode(128 + (a10 >> 6 & 63))), t10.push(String.fromCharCode(128 + (63 & a10)));
            }
          return t10.join("");
        }, ru = (I = [
          ["nbsp", " "],
          ["middot", "·"],
          ["quot", '"'],
          ["apos", "'"],
          ["gt", ">"],
          ["lt", "<"],
          ["amp", "&"]
        ].map(function(e10) {
          return [RegExp("&" + e10[0] + ";", "ig"), e10[1]];
        }), function(e10) {
          for (var t10 = e10.replace(/^[\t\n\r ]+/, "").replace(/(^|[^\t\n\r ])[\t\n\r ]+$/, "$1").replace(/>\s+/g, ">").replace(/\b\s+</g, "<").replace(/[\t\n\r ]+/g, " ").replace(/<\s*[bB][rR]\s*\/?>/g, "\n").replace(/<[^<>]*>/g, ""), r10 = 0; r10 < I.length; ++r10)
            t10 = t10.replace(I[r10][0], I[r10][1]);
          return t10;
        }), rd = /<\/?(?:vt:)?variant>/g, rp = /<(?:vt:)([^<"'>]*)>([\s\S]*)</;
        function rm(e10, t10) {
          var r10 = t4(e10), a10 = tM(e10, r10.baseType) || [], n10 = [];
          if (a10.length != r10.size) {
            if (t10.WTF) throw Error("unexpected vector length " + a10.length + " != " + r10.size);
            return n10;
          }
          return a10.forEach(function(e11) {
            var t11 = e11.replace(rd, "").match(rp);
            t11 && n10.push({ v: rf(t11[2]), t: t11[1] });
          }), n10;
        }
        var rg = /(^\s|\s$|\n)/;
        function rv(e10, t10) {
          return "<" + e10 + (t10.match(rg) ? ' xml:space="preserve"' : "") + ">" + t10 + "</" + e10 + ">";
        }
        function rb(e10) {
          return ts(e10).map(function(t10) {
            return " " + t10 + '="' + e10[t10] + '"';
          }).join("");
        }
        function rw(e10, t10, r10) {
          return "<" + e10 + (null != r10 ? rb(r10) : "") + (null != t10 ? (t10.match(rg) ? ' xml:space="preserve"' : "") + ">" + t10 + "</" + e10 : "/") + ">";
        }
        function rT(e10, t10) {
          try {
            return e10.toISOString().replace(/\.\d*/, "");
          } catch (e11) {
            if (t10) throw e11;
          }
          return "";
        }
        function ry(e10) {
          if (ep && a.isBuffer(e10)) return e10.toString("utf8");
          if ("string" == typeof e10) return e10;
          if ("undefined" != typeof Uint8Array && e10 instanceof Uint8Array) return rf(ey(eE(e10)));
          throw Error("Bad input format: expected Buffer or string");
        }
        var rE = /<([\/]?)([^\s?><!\/:"]*:|)([^\s?<>:\/"]+)(?:\s+[^<>=?"'\s]+="[^"]*?")*\s*[\/]?>/gm, rk = "http://schemas.openxmlformats.org/package/2006/content-types", rx = "http://schemas.microsoft.com/office/spreadsheetml/2018/threadedcomments", r_ = "http://schemas.openxmlformats.org/officeDocument/2006/relationships", rS = "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes", rA = "http://www.w3.org/2001/XMLSchema-instance", rC = [
          "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
          "http://purl.oclc.org/ooxml/spreadsheetml/main",
          "http://schemas.microsoft.com/office/excel/2006/main",
          "http://schemas.microsoft.com/office/excel/2006/2"
        ], rI = "urn:schemas-microsoft-com:office:office", rO = "urn:schemas-microsoft-com:office:excel", rR = "urn:schemas-microsoft-com:office:spreadsheet", rN = "uuid:C2F41010-65B3-11d1-A29F-00AA00C14882", rF = "http://www.w3.org/TR/REC-html40", rD = function(e10) {
          for (var t10 = [], r10 = 0; r10 < e10[0].length; ++r10)
            if (e10[0][r10])
              for (var a10 = 0, n10 = e10[0][r10].length; a10 < n10; a10 += 10240) t10.push.apply(t10, e10[0][r10].slice(a10, a10 + 10240));
          return t10;
        }, rP = ep ? function(e10) {
          return e10[0].length > 0 && a.isBuffer(e10[0][0]) ? a.concat(
            e10[0].map(function(e11) {
              return a.isBuffer(e11) ? e11 : em(e11);
            })
          ) : rD(e10);
        } : rD, rL = function(e10, t10, r10) {
          for (var a10 = [], n10 = t10; n10 < r10; n10 += 2) a10.push(String.fromCharCode(r4(e10, n10)));
          return a10.join("").replace(ex, "");
        }, rM = ep ? function(e10, t10, r10) {
          return a.isBuffer(e10) && eg ? e10.toString("utf16le", t10, r10).replace(ex, "") : rL(e10, t10, r10);
        } : rL, rU = function(e10, t10, r10) {
          for (var a10 = [], n10 = t10; n10 < t10 + r10; ++n10) a10.push(("0" + e10[n10].toString(16)).slice(-2));
          return a10.join("");
        }, rB = ep ? function(e10, t10, r10) {
          return a.isBuffer(e10) ? e10.toString("hex", t10, t10 + r10) : rU(e10, t10, r10);
        } : rU, rW = function(e10, t10, r10) {
          for (var a10 = [], n10 = t10; n10 < r10; n10++) a10.push(String.fromCharCode(r2(e10, n10)));
          return a10.join("");
        }, rz = ep ? function(e10, t10, r10) {
          return a.isBuffer(e10) ? e10.toString("utf8", t10, r10) : rW(e10, t10, r10);
        } : rW, rH = function(e10, t10) {
          var r10 = r5(e10, t10);
          return r10 > 0 ? rz(e10, t10 + 4, t10 + 4 + r10 - 1) : "";
        }, rV = rH, r$ = function(e10, t10) {
          var r10 = r5(e10, t10);
          return r10 > 0 ? rz(e10, t10 + 4, t10 + 4 + r10 - 1) : "";
        }, rG = r$, rX = function(e10, t10) {
          var r10 = 2 * r5(e10, t10);
          return r10 > 0 ? rz(e10, t10 + 4, t10 + 4 + r10 - 1) : "";
        }, rj = rX, rK = function(e10, t10) {
          var r10 = r5(e10, t10);
          return r10 > 0 ? rM(e10, t10 + 4, t10 + 4 + r10) : "";
        }, rY = rK, rZ = function(e10, t10) {
          var r10 = r5(e10, t10);
          return r10 > 0 ? rz(e10, t10 + 4, t10 + 4 + r10) : "";
        }, rJ = rZ, rq = function(e10, t10) {
          for (var r10 = 1 - 2 * (e10[t10 + 7] >>> 7), a10 = ((127 & e10[t10 + 7]) << 4) + (e10[t10 + 6] >>> 4 & 15), n10 = 15 & e10[t10 + 6], s10 = 5; s10 >= 0; --s10)
            n10 = 256 * n10 + e10[t10 + s10];
          return 2047 == a10 ? 0 == n10 ? 1 / 0 * r10 : NaN : (0 == a10 ? a10 = -1022 : (a10 -= 1023, n10 += 4503599627370496), r10 * Math.pow(2, a10 - 52) * n10);
        }, rQ = rq, r0 = function(e10) {
          return Array.isArray(e10) || "undefined" != typeof Uint8Array && e10 instanceof Uint8Array;
        };
        function r1() {
          rM = function(e10, t10, r10) {
            return G.utils.decode(1200, e10.slice(t10, r10)).replace(ex, "");
          }, rz = function(e10, t10, r10) {
            return G.utils.decode(65001, e10.slice(t10, r10));
          }, rV = function(e10, t10) {
            var r10 = r5(e10, t10);
            return r10 > 0 ? G.utils.decode(q, e10.slice(t10 + 4, t10 + 4 + r10 - 1)) : "";
          }, rG = function(e10, t10) {
            var r10 = r5(e10, t10);
            return r10 > 0 ? G.utils.decode(J, e10.slice(t10 + 4, t10 + 4 + r10 - 1)) : "";
          }, rj = function(e10, t10) {
            var r10 = 2 * r5(e10, t10);
            return r10 > 0 ? G.utils.decode(1200, e10.slice(t10 + 4, t10 + 4 + r10 - 1)) : "";
          }, rY = function(e10, t10) {
            var r10 = r5(e10, t10);
            return r10 > 0 ? G.utils.decode(1200, e10.slice(t10 + 4, t10 + 4 + r10)) : "";
          }, rJ = function(e10, t10) {
            var r10 = r5(e10, t10);
            return r10 > 0 ? G.utils.decode(65001, e10.slice(t10 + 4, t10 + 4 + r10)) : "";
          };
        }
        ep && (rV = function(e10, t10) {
          if (!a.isBuffer(e10)) return rH(e10, t10);
          var r10 = e10.readUInt32LE(t10);
          return r10 > 0 ? e10.toString("utf8", t10 + 4, t10 + 4 + r10 - 1) : "";
        }, rG = function(e10, t10) {
          if (!a.isBuffer(e10)) return r$(e10, t10);
          var r10 = e10.readUInt32LE(t10);
          return r10 > 0 ? e10.toString("utf8", t10 + 4, t10 + 4 + r10 - 1) : "";
        }, rj = function(e10, t10) {
          if (!a.isBuffer(e10) || !eg) return rX(e10, t10);
          var r10 = 2 * e10.readUInt32LE(t10);
          return e10.toString("utf16le", t10 + 4, t10 + 4 + r10 - 1);
        }, rY = function(e10, t10) {
          if (!a.isBuffer(e10) || !eg) return rK(e10, t10);
          var r10 = e10.readUInt32LE(t10);
          return e10.toString("utf16le", t10 + 4, t10 + 4 + r10);
        }, rJ = function(e10, t10) {
          if (!a.isBuffer(e10)) return rZ(e10, t10);
          var r10 = e10.readUInt32LE(t10);
          return e10.toString("utf8", t10 + 4, t10 + 4 + r10);
        }, rQ = function(e10, t10) {
          return a.isBuffer(e10) ? e10.readDoubleLE(t10) : rq(e10, t10);
        }, r0 = function(e10) {
          return a.isBuffer(e10) || Array.isArray(e10) || "undefined" != typeof Uint8Array && e10 instanceof Uint8Array;
        }), void 0 !== G && r1();
        var r2 = function(e10, t10) {
          return e10[t10];
        }, r4 = function(e10, t10) {
          return 256 * e10[t10 + 1] + e10[t10];
        }, r3 = function(e10, t10) {
          var r10 = 256 * e10[t10 + 1] + e10[t10];
          return r10 < 32768 ? r10 : -((65535 - r10 + 1) * 1);
        }, r5 = function(e10, t10) {
          return 16777216 * e10[t10 + 3] + (e10[t10 + 2] << 16) + (e10[t10 + 1] << 8) + e10[t10];
        }, r6 = function(e10, t10) {
          return e10[t10 + 3] << 24 | e10[t10 + 2] << 16 | e10[t10 + 1] << 8 | e10[t10];
        };
        function r8(e10, t10) {
          var r10, n10, s10, i10, o10, c10, l2 = "", f2 = [];
          switch (t10) {
            case "dbcs":
              if (c10 = this.l, ep && a.isBuffer(this) && eg)
                l2 = this.slice(this.l, this.l + 2 * e10).toString("utf16le");
              else for (o10 = 0; o10 < e10; ++o10) l2 += String.fromCharCode(r4(this, c10)), c10 += 2;
              e10 *= 2;
              break;
            case "utf8":
              l2 = rz(this, this.l, this.l + e10);
              break;
            case "utf16le":
              e10 *= 2, l2 = rM(this, this.l, this.l + e10);
              break;
            case "wstr":
              if (void 0 === G) return r8.call(this, e10, "dbcs");
              l2 = G.utils.decode(J, this.slice(this.l, this.l + 2 * e10)), e10 *= 2;
              break;
            case "lpstr-ansi":
              l2 = rV(this, this.l), e10 = 4 + r5(this, this.l);
              break;
            case "lpstr-cp":
              l2 = rG(this, this.l), e10 = 4 + r5(this, this.l);
              break;
            case "lpwstr":
              l2 = rj(this, this.l), e10 = 4 + 2 * r5(this, this.l);
              break;
            case "lpp4":
              e10 = 4 + r5(this, this.l), l2 = rY(this, this.l), 2 & e10 && (e10 += 2);
              break;
            case "8lpp4":
              e10 = 4 + r5(this, this.l), l2 = rJ(this, this.l), 3 & e10 && (e10 += 4 - (3 & e10));
              break;
            case "cstr":
              for (e10 = 0, l2 = ""; 0 !== (s10 = r2(this, this.l + e10++)); ) f2.push(ec(s10));
              l2 = f2.join("");
              break;
            case "_wstr":
              for (e10 = 0, l2 = ""; 0 !== (s10 = r4(this, this.l + e10)); ) f2.push(ec(s10)), e10 += 2;
              e10 += 2, l2 = f2.join("");
              break;
            case "dbcs-cont":
              for (o10 = 0, l2 = "", c10 = this.l; o10 < e10; ++o10) {
                if (this.lens && -1 !== this.lens.indexOf(c10))
                  return s10 = r2(this, c10), this.l = c10 + 1, i10 = r8.call(this, e10 - o10, s10 ? "dbcs-cont" : "sbcs-cont"), f2.join("") + i10;
                f2.push(ec(r4(this, c10))), c10 += 2;
              }
              l2 = f2.join(""), e10 *= 2;
              break;
            case "cpstr":
              if (void 0 !== G) {
                l2 = G.utils.decode(J, this.slice(this.l, this.l + e10));
                break;
              }
            case "sbcs-cont":
              for (o10 = 0, l2 = "", c10 = this.l; o10 != e10; ++o10) {
                if (this.lens && -1 !== this.lens.indexOf(c10))
                  return s10 = r2(this, c10), this.l = c10 + 1, i10 = r8.call(this, e10 - o10, s10 ? "dbcs-cont" : "sbcs-cont"), f2.join("") + i10;
                f2.push(ec(r2(this, c10))), c10 += 1;
              }
              l2 = f2.join("");
              break;
            default:
              switch (e10) {
                case 1:
                  return r10 = r2(this, this.l), this.l++, r10;
                case 2:
                  return r10 = ("i" === t10 ? r3 : r4)(this, this.l), this.l += 2, r10;
                case 4:
                case -4:
                  if ("i" === t10 || (128 & this[this.l + 3]) == 0)
                    return r10 = (e10 > 0 ? r6 : function(e11, t11) {
                      return e11[t11] << 24 | e11[t11 + 1] << 16 | e11[t11 + 2] << 8 | e11[t11 + 3];
                    })(this, this.l), this.l += 4, r10;
                  return n10 = r5(this, this.l), this.l += 4, n10;
                case 8:
                case -8:
                  if ("f" === t10)
                    return n10 = 8 == e10 ? rQ(this, this.l) : rQ(
                      [
                        this[this.l + 7],
                        this[this.l + 6],
                        this[this.l + 5],
                        this[this.l + 4],
                        this[this.l + 3],
                        this[this.l + 2],
                        this[this.l + 1],
                        this[this.l + 0]
                      ],
                      0
                    ), this.l += 8, n10;
                  e10 = 8;
                case 16:
                  l2 = rB(this, this.l, e10);
              }
          }
          return this.l += e10, l2;
        }
        var r7 = function(e10, t10, r10) {
          e10[r10] = 255 & t10, e10[r10 + 1] = t10 >>> 8 & 255, e10[r10 + 2] = t10 >>> 16 & 255, e10[r10 + 3] = t10 >>> 24 & 255;
        }, r9 = function(e10, t10, r10) {
          e10[r10] = 255 & t10, e10[r10 + 1] = t10 >> 8 & 255, e10[r10 + 2] = t10 >> 16 & 255, e10[r10 + 3] = t10 >> 24 & 255;
        }, ae = function(e10, t10, r10) {
          e10[r10] = 255 & t10, e10[r10 + 1] = t10 >>> 8 & 255;
        };
        function at(e10, t10, r10) {
          var a10 = 0, n10 = 0;
          if ("dbcs" === r10) {
            for (n10 = 0; n10 != t10.length; ++n10) ae(this, t10.charCodeAt(n10), this.l + 2 * n10);
            a10 = 2 * t10.length;
          } else if ("sbcs" === r10 || "cpstr" == r10)
            if (void 0 !== G && 874 == q) {
              for (n10 = 0; n10 != t10.length; ++n10) {
                var s10 = G.utils.encode(q, t10.charAt(n10));
                this[this.l + n10] = s10[0];
              }
              a10 = t10.length;
            } else if (void 0 !== G && "cpstr" == r10) {
              if ((s10 = G.utils.encode(J, t10)).length == t10.length)
                for (n10 = 0; n10 < t10.length; ++n10) 0 == s10[n10] && 0 != t10.charCodeAt(n10) && (s10[n10] = 95);
              if (s10.length == 2 * t10.length)
                for (n10 = 0; n10 < t10.length; ++n10)
                  0 == s10[2 * n10] && 0 == s10[2 * n10 + 1] && 0 != t10.charCodeAt(n10) && (s10[2 * n10] = 95);
              for (n10 = 0; n10 < s10.length; ++n10) this[this.l + n10] = s10[n10];
              a10 = s10.length;
            } else {
              for (n10 = 0, t10 = t10.replace(/[^\x00-\x7F]/g, "_"); n10 != t10.length; ++n10)
                this[this.l + n10] = 255 & t10.charCodeAt(n10);
              a10 = t10.length;
            }
          else if ("hex" === r10) {
            for (; n10 < e10; ++n10) this[this.l++] = parseInt(t10.slice(2 * n10, 2 * n10 + 2), 16) || 0;
            return this;
          } else if ("utf16le" === r10) {
            var i10 = Math.min(this.l + e10, this.length);
            for (n10 = 0; n10 < Math.min(t10.length, e10); ++n10) {
              var o10 = t10.charCodeAt(n10);
              this[this.l++] = 255 & o10, this[this.l++] = o10 >> 8;
            }
            for (; this.l < i10; ) this[this.l++] = 0;
            return this;
          } else
            switch (e10) {
              case 1:
                a10 = 1, this[this.l] = 255 & t10;
                break;
              case 2:
                a10 = 2, this[this.l] = 255 & t10, t10 >>>= 8, this[this.l + 1] = 255 & t10;
                break;
              case 3:
                a10 = 3, this[this.l] = 255 & t10, t10 >>>= 8, this[this.l + 1] = 255 & t10, t10 >>>= 8, this[this.l + 2] = 255 & t10;
                break;
              case 4:
                a10 = 4, r7(this, t10, this.l);
                break;
              case 8:
                if (a10 = 8, "f" === r10) {
                  !(function(e11, t11, r11) {
                    var a11 = (t11 < 0 || 1 / t11 == -1 / 0) << 7, n11 = 0, s11 = 0, i11 = a11 ? -t11 : t11;
                    isFinite(i11) ? 0 == i11 ? n11 = s11 = 0 : (n11 = Math.floor(Math.log(i11) / Math.LN2), s11 = i11 * Math.pow(2, 52 - n11), n11 <= -1023 && (!isFinite(s11) || s11 < 4503599627370496) ? n11 = -1022 : (s11 -= 4503599627370496, n11 += 1023)) : (n11 = 2047, s11 = 26985 * !!isNaN(t11));
                    for (var o11 = 0; o11 <= 5; ++o11, s11 /= 256) e11[r11 + o11] = 255 & s11;
                    e11[r11 + 6] = (15 & n11) << 4 | 15 & s11, e11[r11 + 7] = n11 >> 4 | a11;
                  })(this, t10, this.l);
                  break;
                }
              case 16:
                break;
              case -4:
                a10 = 4, r9(this, t10, this.l);
            }
          return this.l += a10, this;
        }
        function ar(e10, t10) {
          var r10 = rB(this, this.l, e10.length >> 1);
          if (r10 !== e10) throw Error(t10 + "Expected " + e10 + " saw " + r10);
          this.l += e10.length >> 1;
        }
        function aa(e10, t10) {
          e10.l = t10, e10.read_shift = r8, e10.chk = ar, e10.write_shift = at;
        }
        function an(e10, t10) {
          e10.l += t10;
        }
        function as(e10) {
          var t10 = ev(e10);
          return aa(t10, 0), t10;
        }
        function ai(e10, t10, r10) {
          if (e10) {
            aa(e10, e10.l || 0);
            for (var a10, n10, s10, i10 = e10.length, o10 = 0, c10 = 0; e10.l < i10; ) {
              128 & (o10 = e10.read_shift(1)) && (o10 = (127 & o10) + ((127 & e10.read_shift(1)) << 7));
              var l2 = oz[o10] || oz[65535];
              for (n10 = 1, s10 = 127 & (a10 = e10.read_shift(1)); n10 < 4 && 128 & a10; ++n10)
                s10 += (127 & (a10 = e10.read_shift(1))) << 7 * n10;
              c10 = e10.l + s10;
              var f2 = l2.f && l2.f(e10, s10, r10);
              if (e10.l = c10, t10(f2, l2, o10)) return;
            }
          }
        }
        function ao() {
          var e10 = [], t10 = ep ? 16384 : 2048;
          ep && as(t10).copy;
          var r10 = function(e11) {
            var t11 = as(e11);
            return aa(t11, 0), t11;
          }, a10 = r10(t10), n10 = function() {
            a10 && (a10.l && (a10.length > a10.l && ((a10 = a10.slice(0, a10.l)).l = a10.length), a10.length > 0 && e10.push(a10)), a10 = null);
          }, s10 = function(e11) {
            return a10 && e11 < a10.length - a10.l ? a10 : (n10(), a10 = r10(Math.max(e11 + 1, t10)));
          };
          return {
            next: s10,
            push: function(e11) {
              n10(), null == (a10 = e11).l && (a10.l = a10.length), s10(t10);
            },
            end: function() {
              return n10(), ek(e10);
            },
            _bufs: e10,
            end2: function() {
              return n10(), e10;
            }
          };
        }
        function ac(e10, t10, r10, a10) {
          var n10, s10 = +t10;
          if (!isNaN(s10)) {
            a10 || (a10 = oz[s10].p || (r10 || []).length || 0), n10 = 1 + +(s10 >= 128) + 1, a10 >= 128 && ++n10, a10 >= 16384 && ++n10, a10 >= 2097152 && ++n10;
            var i10 = e10.next(n10);
            s10 <= 127 ? i10.write_shift(1, s10) : (i10.write_shift(1, (127 & s10) + 128), i10.write_shift(1, s10 >> 7));
            for (var o10 = 0; 4 != o10; ++o10)
              if (a10 >= 128) i10.write_shift(1, (127 & a10) + 128), a10 >>= 7;
              else {
                i10.write_shift(1, a10);
                break;
              }
            a10 > 0 && r0(r10) && e10.push(r10);
          }
        }
        function al(e10, t10, r10) {
          var a10 = tw(e10);
          if (t10.s ? (a10.cRel && (a10.c += t10.s.c), a10.rRel && (a10.r += t10.s.r)) : (a10.cRel && (a10.c += t10.c), a10.rRel && (a10.r += t10.r)), !r10 || r10.biff < 12) {
            for (; a10.c >= 256; ) a10.c -= 256;
            for (; a10.r >= 65536; ) a10.r -= 65536;
          }
          return a10;
        }
        function af(e10, t10, r10) {
          var a10 = tw(e10);
          return a10.s = al(a10.s, t10.s, r10), a10.e = al(a10.e, t10.s, r10), a10;
        }
        function ah(e10, t10) {
          if (e10.cRel && e10.c < 0) for (e10 = tw(e10); e10.c < 0; ) e10.c += t10 > 8 ? 16384 : 256;
          if (e10.rRel && e10.r < 0) for (e10 = tw(e10); e10.r < 0; ) e10.r += t10 > 8 ? 1048576 : t10 > 5 ? 65536 : 16384;
          var r10 = ab(e10);
          return e10.cRel || null == e10.cRel || (r10 = r10.replace(/^([A-Z])/, "$$$1")), e10.rRel || null == e10.rRel || (r10 = r10.replace(/([A-Z]|^)(\d+)$/, "$1$$$2")), r10;
        }
        function au(e10, t10) {
          return 0 != e10.s.r || e10.s.rRel || e10.e.r != (t10.biff >= 12 ? 1048575 : t10.biff >= 8 ? 65536 : 16384) || e10.e.rRel ? 0 != e10.s.c || e10.s.cRel || e10.e.c != (t10.biff >= 12 ? 16383 : 255) || e10.e.cRel ? ah(e10.s, t10.biff) + ":" + ah(e10.e, t10.biff) : (e10.s.rRel ? "" : "$") + ap(e10.s.r) + ":" + (e10.e.rRel ? "" : "$") + ap(e10.e.r) : (e10.s.cRel ? "" : "$") + ag(e10.s.c) + ":" + (e10.e.cRel ? "" : "$") + ag(e10.e.c);
        }
        function ad(e10) {
          return parseInt(e10.replace(/\$(\d+)$/, "$1"), 10) - 1;
        }
        function ap(e10) {
          return "" + (e10 + 1);
        }
        function am(e10) {
          for (var t10 = e10.replace(/^\$([A-Z])/, "$1"), r10 = 0, a10 = 0; a10 !== t10.length; ++a10)
            r10 = 26 * r10 + t10.charCodeAt(a10) - 64;
          return r10 - 1;
        }
        function ag(e10) {
          if (e10 < 0) throw Error("invalid column " + e10);
          var t10 = "";
          for (++e10; e10; e10 = Math.floor((e10 - 1) / 26)) t10 = String.fromCharCode((e10 - 1) % 26 + 65) + t10;
          return t10;
        }
        function av(e10) {
          for (var t10 = 0, r10 = 0, a10 = 0; a10 < e10.length; ++a10) {
            var n10 = e10.charCodeAt(a10);
            n10 >= 48 && n10 <= 57 ? t10 = 10 * t10 + (n10 - 48) : n10 >= 65 && n10 <= 90 && (r10 = 26 * r10 + (n10 - 64));
          }
          return { c: r10 - 1, r: t10 - 1 };
        }
        function ab(e10) {
          for (var t10 = e10.c + 1, r10 = ""; t10; t10 = (t10 - 1) / 26 | 0) r10 = String.fromCharCode((t10 - 1) % 26 + 65) + r10;
          return r10 + (e10.r + 1);
        }
        function aw(e10) {
          var t10 = e10.indexOf(":");
          return -1 == t10 ? { s: av(e10), e: av(e10) } : { s: av(e10.slice(0, t10)), e: av(e10.slice(t10 + 1)) };
        }
        function aT(e10, t10) {
          return void 0 === t10 || "number" == typeof t10 ? aT(e10.s, e10.e) : ("string" != typeof e10 && (e10 = ab(e10)), "string" != typeof t10 && (t10 = ab(t10)), e10 == t10 ? e10 : e10 + ":" + t10);
        }
        function ay(e10) {
          var t10 = aw(e10);
          return "$" + ag(t10.s.c) + "$" + ap(t10.s.r) + ":$" + ag(t10.e.c) + "$" + ap(t10.e.r);
        }
        function aE(e10, t10) {
          if (!e10 && !(t10 && t10.biff <= 5 && t10.biff >= 2)) throw Error("empty sheet name");
          return /[^\w\u4E00-\u9FFF\u3040-\u30FF]/.test(e10) ? "'" + e10.replace(/'/g, "''") + "'" : e10;
        }
        function ak(e10) {
          var t10 = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } }, r10 = 0, a10 = 0, n10 = 0, s10 = e10.length;
          for (r10 = 0; a10 < s10 && !((n10 = e10.charCodeAt(a10) - 64) < 1) && !(n10 > 26); ++a10) r10 = 26 * r10 + n10;
          for (t10.s.c = --r10, r10 = 0; a10 < s10 && !((n10 = e10.charCodeAt(a10) - 48) < 0) && !(n10 > 9); ++a10) r10 = 10 * r10 + n10;
          if (t10.s.r = --r10, a10 === s10 || 10 != n10) return t10.e.c = t10.s.c, t10.e.r = t10.s.r, t10;
          for (++a10, r10 = 0; a10 != s10 && !((n10 = e10.charCodeAt(a10) - 64) < 1) && !(n10 > 26); ++a10) r10 = 26 * r10 + n10;
          for (t10.e.c = --r10, r10 = 0; a10 != s10 && !((n10 = e10.charCodeAt(a10) - 48) < 0) && !(n10 > 9); ++a10) r10 = 10 * r10 + n10;
          return t10.e.r = --r10, t10;
        }
        function ax(e10, t10) {
          var r10 = "d" == e10.t && t10 instanceof Date;
          if (null != e10.z)
            try {
              return e10.w = e22(e10.z, r10 ? tu(t10) : t10);
            } catch (e11) {
            }
          try {
            return e10.w = e22((e10.XF || {}).numFmtId || 14 * !!r10, r10 ? tu(t10) : t10);
          } catch (e11) {
            return "" + t10;
          }
        }
        function a_(e10, t10, r10) {
          return null == e10 || null == e10.t || "z" == e10.t ? "" : void 0 !== e10.w ? e10.w : ("d" == e10.t && !e10.z && r10 && r10.dateNF && (e10.z = r10.dateNF), "e" == e10.t) ? aQ[e10.v] || e10.v : void 0 == t10 ? ax(e10, e10.v) : ax(e10, t10);
        }
        function aS(e10, t10) {
          var r10 = t10 && t10.sheet ? t10.sheet : "Sheet1", a10 = {};
          return a10[r10] = e10, { SheetNames: [r10], Sheets: a10 };
        }
        function aA(e10, t10, r10) {
          var a10 = r10 || {}, n10 = e10 ? null != e10["!data"] : a10.dense, s10 = e10 || (n10 ? { "!data": [] } : {});
          n10 && !s10["!data"] && (s10["!data"] = []);
          var i10 = 0, o10 = 0;
          if (s10 && null != a10.origin)
            if ("number" == typeof a10.origin) i10 = a10.origin;
            else {
              var c10 = "string" == typeof a10.origin ? av(a10.origin) : a10.origin;
              i10 = c10.r, o10 = c10.c;
            }
          var l2 = { s: { c: 1e7, r: 1e7 }, e: { c: 0, r: 0 } };
          if (s10["!ref"]) {
            var f2 = ak(s10["!ref"]);
            l2.s.c = f2.s.c, l2.s.r = f2.s.r, l2.e.c = Math.max(l2.e.c, f2.e.c), l2.e.r = Math.max(l2.e.r, f2.e.r), -1 == i10 && (l2.e.r = i10 = s10["!ref"] ? f2.e.r + 1 : 0);
          } else l2.s.c = l2.e.c = l2.s.r = l2.e.r = 0;
          for (var h2 = [], u2 = false, d2 = 0; d2 != t10.length; ++d2)
            if (t10[d2]) {
              if (!Array.isArray(t10[d2])) throw Error("aoa_to_sheet expects an array of arrays");
              var p2 = i10 + d2;
              n10 && (s10["!data"][p2] || (s10["!data"][p2] = []), h2 = s10["!data"][p2]);
              for (var m2 = t10[d2], g2 = 0; g2 != m2.length; ++g2)
                if (void 0 !== m2[g2]) {
                  var v2 = { v: m2[g2], t: "" }, b2 = o10 + g2;
                  if (l2.s.r > p2 && (l2.s.r = p2), l2.s.c > b2 && (l2.s.c = b2), l2.e.r < p2 && (l2.e.r = p2), l2.e.c < b2 && (l2.e.c = b2), u2 = true, !m2[g2] || "object" != typeof m2[g2] || Array.isArray(m2[g2]) || m2[g2] instanceof Date)
                    if (Array.isArray(v2.v) && (v2.f = m2[g2][1], v2.v = v2.v[0]), null === v2.v)
                      if (v2.f) v2.t = "n";
                      else if (a10.nullError) v2.t = "e", v2.v = 0;
                      else {
                        if (!a10.sheetStubs) continue;
                        v2.t = "z";
                      }
                    else
                      "number" == typeof v2.v ? isFinite(v2.v) ? v2.t = "n" : isNaN(v2.v) ? (v2.t = "e", v2.v = 15) : (v2.t = "e", v2.v = 7) : "boolean" == typeof v2.v ? v2.t = "b" : v2.v instanceof Date ? (v2.z = a10.dateNF || eD[14], a10.UTC || (v2.v = tO(v2.v)), a10.cellDates ? (v2.t = "d", v2.w = e22(v2.z, tu(v2.v, a10.date1904))) : (v2.t = "n", v2.v = tu(v2.v, a10.date1904), v2.w = e22(v2.z, v2.v))) : v2.t = "s";
                  else v2 = m2[g2];
                  if (n10) h2[b2] && h2[b2].z && (v2.z = h2[b2].z), h2[b2] = v2;
                  else {
                    var w2 = ag(b2) + (p2 + 1);
                    s10[w2] && s10[w2].z && (v2.z = s10[w2].z), s10[w2] = v2;
                  }
                }
            }
          return u2 && l2.s.c < 104e5 && (s10["!ref"] = aT(l2)), s10;
        }
        function aC(e10, t10) {
          return aA(null, e10, t10);
        }
        function aI(e10, t10) {
          return t10 || (t10 = as(4)), t10.write_shift(4, e10), t10;
        }
        function aO(e10) {
          var t10 = e10.read_shift(4);
          return 0 === t10 ? "" : e10.read_shift(t10, "dbcs");
        }
        function aR(e10, t10) {
          var r10 = false;
          return null == t10 && (r10 = true, t10 = as(4 + 2 * e10.length)), t10.write_shift(4, e10.length), e10.length > 0 && t10.write_shift(0, e10, "dbcs"), r10 ? t10.slice(0, t10.l) : t10;
        }
        function aN(e10, t10) {
          var r10 = e10.l, a10 = e10.read_shift(1), n10 = aO(e10), s10 = [], i10 = { t: n10, h: n10 };
          if ((1 & a10) != 0) {
            for (var o10 = e10.read_shift(4), c10 = 0; c10 != o10; ++c10) s10.push({ ich: e10.read_shift(2), ifnt: e10.read_shift(2) });
            i10.r = s10;
          } else i10.r = [{ ich: 0, ifnt: 0 }];
          return e10.l = r10 + t10, i10;
        }
        function aF(e10) {
          var t10 = e10.read_shift(4), r10 = e10.read_shift(2);
          return r10 += e10.read_shift(1) << 16, e10.l++, { c: t10, iStyleRef: r10 };
        }
        function aD(e10, t10) {
          return null == t10 && (t10 = as(8)), t10.write_shift(-4, e10.c), t10.write_shift(3, e10.iStyleRef || e10.s), t10.write_shift(1, 0), t10;
        }
        function aP(e10) {
          var t10 = e10.read_shift(2);
          return t10 += e10.read_shift(1) << 16, e10.l++, { c: -1, iStyleRef: t10 };
        }
        function aL(e10, t10) {
          return null == t10 && (t10 = as(4)), t10.write_shift(3, e10.iStyleRef || e10.s), t10.write_shift(1, 0), t10;
        }
        function aM(e10) {
          var t10 = e10.read_shift(4);
          return 0 === t10 || 4294967295 === t10 ? "" : e10.read_shift(t10, "dbcs");
        }
        function aU(e10, t10) {
          var r10 = false;
          return null == t10 && (r10 = true, t10 = as(127)), t10.write_shift(4, e10.length > 0 ? e10.length : 4294967295), e10.length > 0 && t10.write_shift(0, e10, "dbcs"), r10 ? t10.slice(0, t10.l) : t10;
        }
        function aB(e10) {
          var t10 = e10.slice(e10.l, e10.l + 4), r10 = 1 & t10[0], a10 = 2 & t10[0];
          e10.l += 4;
          var n10 = 0 === a10 ? rQ([0, 0, 0, 0, 252 & t10[0], t10[1], t10[2], t10[3]], 0) : r6(t10, 0) >> 2;
          return r10 ? n10 / 100 : n10;
        }
        function aW(e10, t10) {
          null == t10 && (t10 = as(4));
          var r10 = 0, a10 = 0, n10 = 100 * e10;
          if (e10 == (0 | e10) && e10 >= -536870912 && e10 < 536870912 ? a10 = 1 : n10 == (0 | n10) && n10 >= -536870912 && n10 < 536870912 && (a10 = 1, r10 = 1), a10)
            t10.write_shift(-4, ((r10 ? n10 : e10) << 2) + (r10 + 2));
          else throw Error("unsupported RkNumber " + e10);
        }
        function az(e10) {
          var t10 = { s: {}, e: {} };
          return t10.s.r = e10.read_shift(4), t10.e.r = e10.read_shift(4), t10.s.c = e10.read_shift(4), t10.e.c = e10.read_shift(4), t10;
        }
        "undefined" != typeof cptable ? ef(cptable) : ef(r(78500));
        var aH = function(e10, t10) {
          return t10 || (t10 = as(16)), t10.write_shift(4, e10.s.r), t10.write_shift(4, e10.e.r), t10.write_shift(4, e10.s.c), t10.write_shift(4, e10.e.c), t10;
        };
        function aV(e10) {
          if (e10.length - e10.l < 8) throw "XLS Xnum Buffer underflow";
          return e10.read_shift(8, "f");
        }
        function a$(e10, t10) {
          return (t10 || as(8)).write_shift(8, e10, "f");
        }
        function aG(e10, t10) {
          if (t10 || (t10 = as(8)), !e10 || e10.auto) return t10.write_shift(4, 0), t10.write_shift(4, 0), t10;
          null != e10.index ? (t10.write_shift(1, 2), t10.write_shift(1, e10.index)) : null != e10.theme ? (t10.write_shift(1, 6), t10.write_shift(1, e10.theme)) : (t10.write_shift(1, 5), t10.write_shift(1, 0));
          var r10 = e10.tint || 0;
          if (r10 > 0 ? r10 *= 32767 : r10 < 0 && (r10 *= 32768), t10.write_shift(2, r10), e10.rgb && null == e10.theme) {
            var a10 = e10.rgb || "FFFFFF";
            "number" == typeof a10 && (a10 = ("000000" + a10.toString(16)).slice(-6)), t10.write_shift(1, parseInt(a10.slice(0, 2), 16)), t10.write_shift(1, parseInt(a10.slice(2, 4), 16)), t10.write_shift(1, parseInt(a10.slice(4, 6), 16)), t10.write_shift(1, 255);
          } else t10.write_shift(2, 0), t10.write_shift(1, 0), t10.write_shift(1, 0);
          return t10;
        }
        function aX(e10, t10) {
          var r10 = e10.read_shift(4);
          switch (r10) {
            case 0:
              return "";
            case 4294967295:
            case 4294967294:
              return { 2: "BITMAP", 3: "METAFILEPICT", 8: "DIB", 14: "ENHMETAFILE" }[e10.read_shift(4)] || "";
          }
          if (r10 > 400) throw Error("Unsupported Clipboard: " + r10.toString(16));
          return e10.l -= 4, e10.read_shift(0, 1 == t10 ? "lpstr" : "lpwstr");
        }
        var aj = [80, 81], aK = {
          1: { n: "CodePage", t: 2 },
          2: { n: "Category", t: 80 },
          3: { n: "PresentationFormat", t: 80 },
          4: { n: "ByteCount", t: 3 },
          5: { n: "LineCount", t: 3 },
          6: { n: "ParagraphCount", t: 3 },
          7: { n: "SlideCount", t: 3 },
          8: { n: "NoteCount", t: 3 },
          9: { n: "HiddenCount", t: 3 },
          10: { n: "MultimediaClipCount", t: 3 },
          11: { n: "ScaleCrop", t: 11 },
          12: { n: "HeadingPairs", t: 4108 },
          13: { n: "TitlesOfParts", t: 4126 },
          14: { n: "Manager", t: 80 },
          15: { n: "Company", t: 80 },
          16: { n: "LinksUpToDate", t: 11 },
          17: { n: "CharacterCount", t: 3 },
          19: { n: "SharedDoc", t: 11 },
          22: { n: "HyperlinksChanged", t: 11 },
          23: { n: "AppVersion", t: 3, p: "version" },
          24: { n: "DigSig", t: 65 },
          26: { n: "ContentType", t: 80 },
          27: { n: "ContentStatus", t: 80 },
          28: { n: "Language", t: 80 },
          29: { n: "Version", t: 80 },
          255: {},
          2147483648: { n: "Locale", t: 19 },
          2147483651: { n: "Behavior", t: 19 },
          1919054434: {}
        }, aY = {
          1: { n: "CodePage", t: 2 },
          2: { n: "Title", t: 80 },
          3: { n: "Subject", t: 80 },
          4: { n: "Author", t: 80 },
          5: { n: "Keywords", t: 80 },
          6: { n: "Comments", t: 80 },
          7: { n: "Template", t: 80 },
          8: { n: "LastAuthor", t: 80 },
          9: { n: "RevNumber", t: 80 },
          10: { n: "EditTime", t: 64 },
          11: { n: "LastPrinted", t: 64 },
          12: { n: "CreatedDate", t: 64 },
          13: { n: "ModifiedDate", t: 64 },
          14: { n: "PageCount", t: 3 },
          15: { n: "WordCount", t: 3 },
          16: { n: "CharCount", t: 3 },
          17: { n: "Thumbnail", t: 71 },
          18: { n: "Application", t: 80 },
          19: { n: "DocSecurity", t: 3 },
          255: {},
          2147483648: { n: "Locale", t: 19 },
          2147483651: { n: "Behavior", t: 19 },
          1919054434: {}
        }, aZ = {
          1: "US",
          2: "CA",
          3: "",
          7: "RU",
          20: "EG",
          30: "GR",
          31: "NL",
          32: "BE",
          33: "FR",
          34: "ES",
          36: "HU",
          39: "IT",
          41: "CH",
          43: "AT",
          44: "GB",
          45: "DK",
          46: "SE",
          47: "NO",
          48: "PL",
          49: "DE",
          52: "MX",
          55: "BR",
          61: "AU",
          64: "NZ",
          66: "TH",
          81: "JP",
          82: "KR",
          84: "VN",
          86: "CN",
          90: "TR",
          105: "JS",
          213: "DZ",
          216: "MA",
          218: "LY",
          351: "PT",
          354: "IS",
          358: "FI",
          420: "CZ",
          886: "TW",
          961: "LB",
          962: "JO",
          963: "SY",
          964: "IQ",
          965: "KW",
          966: "SA",
          971: "AE",
          972: "IL",
          974: "QA",
          981: "IR",
          65535: "US"
        }, aJ = [
          null,
          "solid",
          "mediumGray",
          "darkGray",
          "lightGray",
          "darkHorizontal",
          "darkVertical",
          "darkDown",
          "darkUp",
          "darkGrid",
          "darkTrellis",
          "lightHorizontal",
          "lightVertical",
          "lightDown",
          "lightUp",
          "lightGrid",
          "lightTrellis",
          "gray125",
          "gray0625"
        ], aq = tw(
          [
            0,
            16777215,
            16711680,
            65280,
            255,
            16776960,
            16711935,
            65535,
            0,
            16777215,
            16711680,
            65280,
            255,
            16776960,
            16711935,
            65535,
            8388608,
            32768,
            128,
            8421376,
            8388736,
            32896,
            12632256,
            8421504,
            10066431,
            10040166,
            16777164,
            13434879,
            6684774,
            16744576,
            26316,
            13421823,
            128,
            16711935,
            16776960,
            65535,
            8388736,
            8388608,
            32896,
            255,
            52479,
            13434879,
            13434828,
            16777113,
            10079487,
            16751052,
            13408767,
            16764057,
            3368703,
            3394764,
            10079232,
            16763904,
            16750848,
            16737792,
            6710937,
            9868950,
            13158,
            3381606,
            13056,
            3355392,
            10040064,
            10040166,
            3355545,
            3355443,
            0,
            16777215,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
          ].map(function(e10) {
            return [e10 >> 16 & 255, e10 >> 8 & 255, 255 & e10];
          })
        ), aQ = {
          0: "#NULL!",
          7: "#DIV/0!",
          15: "#VALUE!",
          23: "#REF!",
          29: "#NAME?",
          36: "#NUM!",
          42: "#N/A",
          43: "#GETTING_DATA",
          255: "#WTF?"
        }, a0 = {
          "#NULL!": 0,
          "#DIV/0!": 7,
          "#VALUE!": 15,
          "#REF!": 23,
          "#NAME?": 29,
          "#NUM!": 36,
          "#N/A": 42,
          "#GETTING_DATA": 43,
          "#WTF?": 255
        }, a1 = [
          "_xlnm.Consolidate_Area",
          "_xlnm.Auto_Open",
          "_xlnm.Auto_Close",
          "_xlnm.Extract",
          "_xlnm.Database",
          "_xlnm.Criteria",
          "_xlnm.Print_Area",
          "_xlnm.Print_Titles",
          "_xlnm.Recorder",
          "_xlnm.Data_Form",
          "_xlnm.Auto_Activate",
          "_xlnm.Auto_Deactivate",
          "_xlnm.Sheet_Title",
          "_xlnm._FilterDatabase"
        ], a2 = {
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml": "workbooks",
          "application/vnd.ms-excel.sheet.macroEnabled.main+xml": "workbooks",
          "application/vnd.ms-excel.sheet.binary.macroEnabled.main": "workbooks",
          "application/vnd.ms-excel.addin.macroEnabled.main+xml": "workbooks",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml": "workbooks",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml": "sheets",
          "application/vnd.ms-excel.worksheet": "sheets",
          "application/vnd.ms-excel.binIndexWs": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml": "charts",
          "application/vnd.ms-excel.chartsheet": "charts",
          "application/vnd.ms-excel.macrosheet+xml": "macros",
          "application/vnd.ms-excel.macrosheet": "macros",
          "application/vnd.ms-excel.intlmacrosheet": "TODO",
          "application/vnd.ms-excel.binIndexMs": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml": "dialogs",
          "application/vnd.ms-excel.dialogsheet": "dialogs",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml": "strs",
          "application/vnd.ms-excel.sharedStrings": "strs",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml": "styles",
          "application/vnd.ms-excel.styles": "styles",
          "application/vnd.openxmlformats-package.core-properties+xml": "coreprops",
          "application/vnd.openxmlformats-officedocument.custom-properties+xml": "custprops",
          "application/vnd.openxmlformats-officedocument.extended-properties+xml": "extprops",
          "application/vnd.openxmlformats-officedocument.customXmlProperties+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.customProperty": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml": "comments",
          "application/vnd.ms-excel.comments": "comments",
          "application/vnd.ms-excel.threadedcomments+xml": "threadedcomments",
          "application/vnd.ms-excel.person+xml": "people",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetMetadata+xml": "metadata",
          "application/vnd.ms-excel.sheetMetadata": "metadata",
          "application/vnd.ms-excel.pivotTable": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotTable+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.drawingml.chart+xml": "TODO",
          "application/vnd.ms-office.chartcolorstyle+xml": "TODO",
          "application/vnd.ms-office.chartstyle+xml": "TODO",
          "application/vnd.ms-office.chartex+xml": "TODO",
          "application/vnd.ms-excel.calcChain": "calcchains",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.calcChain+xml": "calcchains",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.printerSettings": "TODO",
          "application/vnd.ms-office.activeX": "TODO",
          "application/vnd.ms-office.activeX+xml": "TODO",
          "application/vnd.ms-excel.attachedToolbars": "TODO",
          "application/vnd.ms-excel.connections": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.connections+xml": "TODO",
          "application/vnd.ms-excel.externalLink": "links",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.externalLink+xml": "links",
          "application/vnd.ms-excel.pivotCacheDefinition": "TODO",
          "application/vnd.ms-excel.pivotCacheRecords": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheDefinition+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotCacheRecords+xml": "TODO",
          "application/vnd.ms-excel.queryTable": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.queryTable+xml": "TODO",
          "application/vnd.ms-excel.userNames": "TODO",
          "application/vnd.ms-excel.revisionHeaders": "TODO",
          "application/vnd.ms-excel.revisionLog": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionHeaders+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionLog+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.userNames+xml": "TODO",
          "application/vnd.ms-excel.tableSingleCells": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.tableSingleCells+xml": "TODO",
          "application/vnd.ms-excel.slicer": "TODO",
          "application/vnd.ms-excel.slicerCache": "TODO",
          "application/vnd.ms-excel.slicer+xml": "TODO",
          "application/vnd.ms-excel.slicerCache+xml": "TODO",
          "application/vnd.ms-excel.wsSortMap": "TODO",
          "application/vnd.ms-excel.table": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.theme+xml": "themes",
          "application/vnd.openxmlformats-officedocument.themeOverride+xml": "TODO",
          "application/vnd.ms-excel.Timeline+xml": "TODO",
          "application/vnd.ms-excel.TimelineCache+xml": "TODO",
          "application/vnd.ms-office.vbaProject": "vba",
          "application/vnd.ms-office.vbaProjectSignature": "TODO",
          "application/vnd.ms-office.volatileDependencies": "TODO",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.volatileDependencies+xml": "TODO",
          "application/vnd.ms-excel.controlproperties+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.model+data": "TODO",
          "application/vnd.ms-excel.Survey+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.drawing+xml": "drawings",
          "application/vnd.openxmlformats-officedocument.drawingml.chartshapes+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.drawingml.diagramColors+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.drawingml.diagramData+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.drawingml.diagramLayout+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.drawingml.diagramStyle+xml": "TODO",
          "application/vnd.openxmlformats-officedocument.vmlDrawing": "TODO",
          "application/vnd.openxmlformats-package.relationships+xml": "rels",
          "application/vnd.openxmlformats-officedocument.oleObject": "TODO",
          "image/png": "TODO",
          sheet: "js"
        }, a4 = {
          workbooks: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml",
            xlsm: "application/vnd.ms-excel.sheet.macroEnabled.main+xml",
            xlsb: "application/vnd.ms-excel.sheet.binary.macroEnabled.main",
            xlam: "application/vnd.ms-excel.addin.macroEnabled.main+xml",
            xltx: "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml"
          },
          strs: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml",
            xlsb: "application/vnd.ms-excel.sharedStrings"
          },
          comments: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml",
            xlsb: "application/vnd.ms-excel.comments"
          },
          sheets: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml",
            xlsb: "application/vnd.ms-excel.worksheet"
          },
          charts: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml",
            xlsb: "application/vnd.ms-excel.chartsheet"
          },
          dialogs: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml",
            xlsb: "application/vnd.ms-excel.dialogsheet"
          },
          macros: { xlsx: "application/vnd.ms-excel.macrosheet+xml", xlsb: "application/vnd.ms-excel.macrosheet" },
          metadata: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetMetadata+xml",
            xlsb: "application/vnd.ms-excel.sheetMetadata"
          },
          styles: {
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml",
            xlsb: "application/vnd.ms-excel.styles"
          }
        };
        function a3() {
          return {
            workbooks: [],
            sheets: [],
            charts: [],
            dialogs: [],
            macros: [],
            rels: [],
            strs: [],
            comments: [],
            threadedcomments: [],
            links: [],
            coreprops: [],
            extprops: [],
            custprops: [],
            themes: [],
            styles: [],
            calcchains: [],
            vba: [],
            drawings: [],
            metadata: [],
            people: [],
            TODO: [],
            xmlns: ""
          };
        }
        function a5(e10, t10, r10) {
          var a10, n10 = (function(e11) {
            for (var t11 = [], r11 = ts(e11), a11 = 0; a11 !== r11.length; ++a11)
              null == t11[e11[r11[a11]]] && (t11[e11[r11[a11]]] = []), t11[e11[r11[a11]]].push(r11[a11]);
            return t11;
          })(a2), s10 = [];
          r10 || (s10[s10.length] = tJ, s10[s10.length] = rw("Types", null, {
            xmlns: rk,
            "xmlns:xsd": "http://www.w3.org/2001/XMLSchema",
            "xmlns:xsi": rA
          }), s10 = s10.concat(
            [
              ["xml", "application/xml"],
              ["bin", "application/vnd.ms-excel.sheet.binary.macroEnabled.main"],
              ["vml", "application/vnd.openxmlformats-officedocument.vmlDrawing"],
              ["data", "application/vnd.openxmlformats-officedocument.model+data"],
              ["bmp", "image/bmp"],
              ["png", "image/png"],
              ["gif", "image/gif"],
              ["emf", "image/x-emf"],
              ["wmf", "image/x-wmf"],
              ["jpg", "image/jpeg"],
              ["jpeg", "image/jpeg"],
              ["tif", "image/tiff"],
              ["tiff", "image/tiff"],
              ["pdf", "application/pdf"],
              ["rels", "application/vnd.openxmlformats-package.relationships+xml"]
            ].map(function(e11) {
              return rw("Default", null, { Extension: e11[0], ContentType: e11[1] });
            })
          ));
          var i10 = function(r11) {
            e10[r11] && e10[r11].length > 0 && (a10 = e10[r11][0], s10[s10.length] = rw("Override", null, {
              PartName: ("/" == a10[0] ? "" : "/") + a10,
              ContentType: a4[r11][t10.bookType] || a4[r11].xlsx
            }));
          }, o10 = function(r11) {
            (e10[r11] || []).forEach(function(e11) {
              s10[s10.length] = rw("Override", null, {
                PartName: ("/" == e11[0] ? "" : "/") + e11,
                ContentType: a4[r11][t10.bookType] || a4[r11].xlsx
              });
            });
          }, c10 = function(t11) {
            (e10[t11] || []).forEach(function(e11) {
              s10[s10.length] = rw("Override", null, { PartName: ("/" == e11[0] ? "" : "/") + e11, ContentType: n10[t11][0] });
            });
          };
          return i10("workbooks"), o10("sheets"), o10("charts"), c10("themes"), ["strs", "styles"].forEach(i10), ["coreprops", "extprops", "custprops"].forEach(c10), c10("vba"), c10("comments"), c10("threadedcomments"), c10("drawings"), o10("metadata"), c10("people"), !r10 && s10.length > 2 && (s10[s10.length] = "</Types>", s10[1] = s10[1].replace("/>", ">")), s10.join("");
        }
        var a6 = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument", a8 = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", a7 = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing", a9 = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments", ne = "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties", nt = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties", nr = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties", na = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings", nn = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles", ns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme", ni = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/chartsheet", no = [
          "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet",
          "http://purl.oclc.org/ooxml/officeDocument/relationships/worksheet"
        ], nc = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/dialogsheet", nl = "http://schemas.microsoft.com/office/2006/relationships/xlMacrosheet", nf = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sheetMetadata", nh = "http://schemas.microsoft.com/office/2017/10/relationships/threadedComment", nu = "http://schemas.microsoft.com/office/2017/10/relationships/person", nd = "http://schemas.microsoft.com/office/2006/relationships/vbaProject";
        function np(e10) {
          var t10 = e10.lastIndexOf("/");
          return e10.slice(0, t10 + 1) + "_rels/" + e10.slice(t10 + 1) + ".rels";
        }
        function nm(e10, t10) {
          var r10 = { "!id": {} };
          if (!e10) return r10;
          "/" !== t10.charAt(0) && (t10 = "/" + t10);
          var a10 = {};
          return (e10.match(t0) || []).forEach(function(e11) {
            var n10 = t4(e11);
            if ("<Relationship" === n10[0]) {
              var s10 = {};
              s10.Type = n10.Type, s10.Target = t8(n10.Target), s10.Id = n10.Id, n10.TargetMode && (s10.TargetMode = n10.TargetMode), r10["External" === n10.TargetMode ? n10.Target : tZ(n10.Target, t10)] = s10, a10[n10.Id] = s10;
            }
          }), r10["!id"] = a10, r10;
        }
        function ng(e10) {
          var t10 = [
            tJ,
            rw("Relationships", null, { xmlns: "http://schemas.openxmlformats.org/package/2006/relationships" })
          ];
          return ts(e10["!id"]).forEach(function(r10) {
            t10[t10.length] = rw("Relationship", null, e10["!id"][r10]);
          }), t10.length > 2 && (t10[t10.length] = "</Relationships>", t10[1] = t10[1].replace("/>", ">")), t10.join("");
        }
        function nv(e10, t10, r10, a10, n10, s10) {
          if (n10 || (n10 = {}), e10["!id"] || (e10["!id"] = {}), e10["!idx"] || (e10["!idx"] = 1), t10 < 0)
            for (t10 = e10["!idx"]; e10["!id"]["rId" + t10]; ++t10) ;
          if (e10["!idx"] = t10 + 1, n10.Id = "rId" + t10, n10.Type = a10, n10.Target = r10, s10 ? n10.TargetMode = s10 : [
            a8,
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLinkPath",
            "http://schemas.microsoft.com/office/2006/relationships/xlExternalLinkPath/xlPathMissing"
          ].indexOf(n10.Type) > -1 && (n10.TargetMode = "External"), e10["!id"][n10.Id])
            throw Error("Cannot rewrite rId " + t10);
          return e10["!id"][n10.Id] = n10, e10[("/" + n10.Target).replace("//", "/")] = n10, t10;
        }
        function nb(e10, t10, r10) {
          return '  <rdf:Description rdf:about="' + e10 + '">\n' + ('    <rdf:type rdf:resource="http://docs.oasis-open.org/ns/office/1.2/meta/' + (r10 || "odf") + "#") + t10 + '"/>\n  </rdf:Description>\n';
        }
        function nw(t10, r10) {
          return '<office:document-meta xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:xlink="http://www.w3.org/1999/xlink" office:version="1.2"><office:meta><meta:generator>SheetJS ' + e2.version + "</meta:generator></office:meta></office:document-meta>";
        }
        var nT = [
          ["cp:category", "Category"],
          ["cp:contentStatus", "ContentStatus"],
          ["cp:keywords", "Keywords"],
          ["cp:lastModifiedBy", "LastAuthor"],
          ["cp:lastPrinted", "LastPrinted"],
          ["cp:revision", "RevNumber"],
          ["cp:version", "Version"],
          ["dc:creator", "Author"],
          ["dc:description", "Comments"],
          ["dc:identifier", "Identifier"],
          ["dc:language", "Language"],
          ["dc:subject", "Subject"],
          ["dc:title", "Title"],
          ["dcterms:created", "CreatedDate", "date"],
          ["dcterms:modified", "ModifiedDate", "date"]
        ];
        function ny(e10) {
          var t10 = {};
          e10 = rf(e10);
          for (var r10 = 0; r10 < nT.length; ++r10) {
            var a10 = nT[r10], n10 = tP(e10, a10[0]);
            null != n10 && n10.length > 0 && (t10[a10[1]] = t8(n10[1])), "date" === a10[2] && t10[a10[1]] && (t10[a10[1]] = tv(t10[a10[1]]));
          }
          return t10;
        }
        function nE(e10, t10, r10, a10, n10) {
          null == n10[e10] && null != t10 && "" !== t10 && (n10[e10] = t10, t10 = re(t10), a10[a10.length] = r10 ? rw(e10, t10, r10) : rv(e10, t10));
        }
        function nk(e10, t10) {
          var r10 = t10 || {}, a10 = [
            tJ,
            rw("cp:coreProperties", null, {
              "xmlns:cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
              "xmlns:dc": "http://purl.org/dc/elements/1.1/",
              "xmlns:dcterms": "http://purl.org/dc/terms/",
              "xmlns:dcmitype": "http://purl.org/dc/dcmitype/",
              "xmlns:xsi": rA
            })
          ], n10 = {};
          if (!e10 && !r10.Props) return a10.join("");
          e10 && (null != e10.CreatedDate && nE(
            "dcterms:created",
            "string" == typeof e10.CreatedDate ? e10.CreatedDate : rT(e10.CreatedDate, r10.WTF),
            { "xsi:type": "dcterms:W3CDTF" },
            a10,
            n10
          ), null != e10.ModifiedDate && nE(
            "dcterms:modified",
            "string" == typeof e10.ModifiedDate ? e10.ModifiedDate : rT(e10.ModifiedDate, r10.WTF),
            { "xsi:type": "dcterms:W3CDTF" },
            a10,
            n10
          ));
          for (var s10 = 0; s10 != nT.length; ++s10) {
            var i10 = nT[s10], o10 = r10.Props && null != r10.Props[i10[1]] ? r10.Props[i10[1]] : e10 ? e10[i10[1]] : null;
            true === o10 ? o10 = "1" : false === o10 ? o10 = "0" : "number" == typeof o10 && (o10 = String(o10)), null != o10 && nE(i10[0], o10, null, a10, n10);
          }
          return a10.length > 2 && (a10[a10.length] = "</cp:coreProperties>", a10[1] = a10[1].replace("/>", ">")), a10.join("");
        }
        var nx = [
          ["Application", "Application", "string"],
          ["AppVersion", "AppVersion", "string"],
          ["Company", "Company", "string"],
          ["DocSecurity", "DocSecurity", "string"],
          ["Manager", "Manager", "string"],
          ["HyperlinksChanged", "HyperlinksChanged", "bool"],
          ["SharedDoc", "SharedDoc", "bool"],
          ["LinksUpToDate", "LinksUpToDate", "bool"],
          ["ScaleCrop", "ScaleCrop", "bool"],
          ["HeadingPairs", "HeadingPairs", "raw"],
          ["TitlesOfParts", "TitlesOfParts", "raw"]
        ], n_ = ["Worksheets", "SheetNames", "NamedRanges", "DefinedNames", "Chartsheets", "ChartNames"];
        function nS(e10, t10, r10, a10) {
          var n10 = [];
          if ("string" == typeof e10) n10 = rm(e10, a10);
          else
            for (var s10 = 0; s10 < e10.length; ++s10)
              n10 = n10.concat(
                e10[s10].map(function(e11) {
                  return { v: e11 };
                })
              );
          var i10 = "string" == typeof t10 ? rm(t10, a10).map(function(e11) {
            return e11.v;
          }) : t10, o10 = 0, c10 = 0;
          if (i10.length > 0)
            for (var l2 = 0; l2 !== n10.length; l2 += 2) {
              switch (c10 = +n10[l2 + 1].v, n10[l2].v) {
                case "Worksheets":
                case "工作表":
                case "Листы":
                case "أوراق العمل":
                case "ワークシート":
                case "גליונות עבודה":
                case "Arbeitsblätter":
                case "Çalışma Sayfaları":
                case "Feuilles de calcul":
                case "Fogli di lavoro":
                case "Folhas de cálculo":
                case "Planilhas":
                case "Regneark":
                case "Hojas de cálculo":
                case "Werkbladen":
                  r10.Worksheets = c10, r10.SheetNames = i10.slice(o10, o10 + c10);
                  break;
                case "Named Ranges":
                case "Rangos con nombre":
                case "名前付き一覧":
                case "Benannte Bereiche":
                case "Navngivne områder":
                  r10.NamedRanges = c10, r10.DefinedNames = i10.slice(o10, o10 + c10);
                  break;
                case "Charts":
                case "Diagramme":
                  r10.Chartsheets = c10, r10.ChartNames = i10.slice(o10, o10 + c10);
              }
              o10 += c10;
            }
        }
        function nA(e10) {
          var t10 = [];
          return e10 || (e10 = {}), e10.Application = "SheetJS", t10[t10.length] = tJ, t10[t10.length] = rw("Properties", null, {
            xmlns: "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties",
            "xmlns:vt": rS
          }), nx.forEach(function(r10) {
            var a10;
            if (void 0 !== e10[r10[1]]) {
              switch (r10[2]) {
                case "string":
                  a10 = re(String(e10[r10[1]]));
                  break;
                case "bool":
                  a10 = e10[r10[1]] ? "true" : "false";
              }
              void 0 !== a10 && (t10[t10.length] = rw(r10[0], a10));
            }
          }), t10[t10.length] = rw(
            "HeadingPairs",
            rw(
              "vt:vector",
              rw("vt:variant", "<vt:lpstr>Worksheets</vt:lpstr>") + rw("vt:variant", rw("vt:i4", String(e10.Worksheets))),
              { size: 2, baseType: "variant" }
            )
          ), t10[t10.length] = rw(
            "TitlesOfParts",
            rw(
              "vt:vector",
              e10.SheetNames.map(function(e11) {
                return "<vt:lpstr>" + re(e11) + "</vt:lpstr>";
              }).join(""),
              { size: e10.Worksheets, baseType: "lpstr" }
            )
          ), t10.length > 2 && (t10[t10.length] = "</Properties>", t10[1] = t10[1].replace("/>", ">")), t10.join("");
        }
        var nC = /<[^<>]+>[^<]*/g;
        function nI(e10) {
          var t10 = [
            tJ,
            rw("Properties", null, {
              xmlns: "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties",
              "xmlns:vt": rS
            })
          ];
          if (!e10) return t10.join("");
          var r10 = 1;
          return ts(e10).forEach(function(a10) {
            ++r10, t10[t10.length] = rw(
              "property",
              (function(e11, t11) {
                switch (typeof e11) {
                  case "string":
                    var r11 = rw("vt:lpwstr", re(e11));
                    return t11 && (r11 = r11.replace(/&quot;/g, "_x0022_")), r11;
                  case "number":
                    return rw((0 | e11) == e11 ? "vt:i4" : "vt:r8", re(String(e11)));
                  case "boolean":
                    return rw("vt:bool", e11 ? "true" : "false");
                }
                if (e11 instanceof Date) return rw("vt:filetime", rT(e11));
                throw Error("Unable to serialize " + e11);
              })(e10[a10], true),
              { fmtid: "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}", pid: r10, name: re(a10) }
            );
          }), t10.length > 2 && (t10[t10.length] = "</Properties>", t10[1] = t10[1].replace("/>", ">")), t10.join("");
        }
        var nO = {
          Title: "Title",
          Subject: "Subject",
          Author: "Author",
          Keywords: "Keywords",
          Comments: "Description",
          LastAuthor: "LastAuthor",
          RevNumber: "Revision",
          Application: "AppName",
          LastPrinted: "LastPrinted",
          CreatedDate: "Created",
          ModifiedDate: "LastSaved",
          Category: "Category",
          Manager: "Manager",
          Company: "Company",
          AppVersion: "Version",
          ContentStatus: "ContentStatus",
          Identifier: "Identifier",
          Language: "Language"
        };
        function nR(e10) {
          var t10 = e10.read_shift(4);
          return new Date((e10.read_shift(4) / 1e7 * 4294967296 + t10 / 1e7 - 11644473600) * 1e3).toISOString().replace(/\.000/, "");
        }
        function nN(e10, t10, r10) {
          if (31 === t10) return e10.read_shift(0, "lpwstr");
          var a10 = e10.l, n10 = e10.read_shift(0, "lpstr-cp");
          if (r10) for (; e10.l - a10 & 3; ) ++e10.l;
          return n10;
        }
        function nF(e10, t10, r10) {
          return nN(e10, t10, 4 * (false !== r10));
        }
        function nD(e10, t10) {
          for (var r10 = e10.read_shift(4), a10 = {}, n10 = 0; n10 != r10; ++n10) {
            var s10 = e10.read_shift(4), i10 = e10.read_shift(4);
            a10[s10] = e10.read_shift(i10, 1200 === t10 ? "utf16le" : "utf8").replace(ex, "").replace(e_, "!"), 1200 === t10 && i10 % 2 && (e10.l += 2);
          }
          return 3 & e10.l && (e10.l = e10.l >> 3 << 2), a10;
        }
        function nP(e10) {
          var t10 = e10.read_shift(4), r10 = e10.slice(e10.l, e10.l + t10);
          return e10.l += t10, (3 & t10) > 0 && (e10.l += 4 - (3 & t10) & 3), r10;
        }
        function nL(e10, t10, r10) {
          var a10, n10, s10 = e10.read_shift(2), i10 = r10 || {};
          if (e10.l += 2, 12 !== t10 && s10 !== t10 && -1 === aj.indexOf(t10) && ((65534 & t10) != 4126 || (65534 & s10) != 4126))
            throw Error("Expected type " + t10 + " saw " + s10);
          switch (12 === t10 ? s10 : t10) {
            case 2:
              return n10 = e10.read_shift(2, "i"), i10.raw || (e10.l += 2), n10;
            case 3:
              return e10.read_shift(4, "i");
            case 11:
              return 0 !== e10.read_shift(4);
            case 19:
              return e10.read_shift(4);
            case 30:
            case 31:
              e10.l += 4, val = nF(e10, e10[e10.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
              break;
            case 64:
              return nR(e10);
            case 65:
              return nP(e10);
            case 71:
              return (a10 = {}).Size = e10.read_shift(4), e10.l += a10.Size + 3 - (a10.Size - 1) % 4, a10;
            case 80:
              return nF(e10, s10, !i10.raw).replace(ex, "");
            case 81:
              return (function(e11, t11) {
                if (!t11) throw Error("VtUnalignedString must have positive length");
                return nN(e11, t11, 0);
              })(e10, s10).replace(ex, "");
            case 4108:
              for (var o10 = e10.read_shift(4), c10 = [], l2 = 0; l2 < o10 / 2; ++l2)
                c10.push(
                  (function(e11) {
                    var t11 = e11.l, r11 = nL(e11, 81);
                    return 0 == e11[e11.l] && 0 == e11[e11.l + 1] && e11.l - t11 & 2 && (e11.l += 2), [r11, nL(e11, 3)];
                  })(e10)
                );
              return c10;
            case 4126:
            case 4127:
              return 4127 == s10 ? (function(e11) {
                for (var t11 = e11.read_shift(4), r11 = [], a11 = 0; a11 != t11; ++a11) {
                  var n11 = e11.l;
                  r11[a11] = e11.read_shift(0, "lpwstr").replace(ex, ""), e11.l - n11 & 2 && (e11.l += 2);
                }
                return r11;
              })(e10) : (function(e11) {
                for (var t11 = e11.read_shift(4), r11 = [], a11 = 0; a11 != t11; ++a11)
                  r11[a11] = e11.read_shift(0, "lpstr-cp").replace(ex, "");
                return r11;
              })(e10);
            default:
              throw Error("TypedPropertyValue unrecognized type " + t10 + " " + s10);
          }
        }
        function nM(e10, t10) {
          var r10, a10, n10, s10, i10, o10 = as(4), c10 = as(4);
          switch (o10.write_shift(4, 80 == e10 ? 31 : e10), e10) {
            case 3:
              c10.write_shift(-4, t10);
              break;
            case 5:
              (c10 = as(8)).write_shift(8, t10, "f");
              break;
            case 11:
              c10.write_shift(4, +!!t10);
              break;
            case 64:
              a10 = (r10 = ("string" == typeof t10 ? new Date(Date.parse(t10)) : t10).getTime() / 1e3 + 11644473600) % 4294967296, n10 = (r10 - a10) / 4294967296 * 1e7, (s10 = (a10 *= 1e7) / 4294967296 | 0) > 0 && (a10 %= 4294967296, n10 += s10), (i10 = as(8)).write_shift(4, a10), i10.write_shift(4, n10), c10 = i10;
              break;
            case 31:
            case 80:
              for ((c10 = as(4 + 2 * (t10.length + 1) + (t10.length % 2 ? 0 : 2))).write_shift(4, t10.length + 1), c10.write_shift(0, t10, "dbcs"); c10.l != c10.length; )
                c10.write_shift(1, 0);
              break;
            default:
              throw Error("TypedPropertyValue unrecognized type " + e10 + " " + t10);
          }
          return ek([o10, c10]);
        }
        function nU(e10, t10) {
          var r10 = e10.l, a10 = e10.read_shift(4), n10 = e10.read_shift(4), s10 = [], i10 = 0, o10 = 0, c10 = -1, l2 = {};
          for (i10 = 0; i10 != n10; ++i10) {
            var f2 = e10.read_shift(4), h2 = e10.read_shift(4);
            s10[i10] = [f2, h2 + r10];
          }
          s10.sort(function(e11, t11) {
            return e11[1] - t11[1];
          });
          var u2 = {};
          for (i10 = 0; i10 != n10; ++i10) {
            if (e10.l !== s10[i10][1]) {
              var d2 = true;
              if (i10 > 0 && t10)
                switch (t10[s10[i10 - 1][0]].t) {
                  case 2:
                    e10.l + 2 === s10[i10][1] && (e10.l += 2, d2 = false);
                    break;
                  case 80:
                  case 4108:
                    e10.l <= s10[i10][1] && (e10.l = s10[i10][1], d2 = false);
                }
              if ((!t10 || 0 == i10) && e10.l <= s10[i10][1] && (d2 = false, e10.l = s10[i10][1]), d2)
                throw Error("Read Error: Expected address " + s10[i10][1] + " at " + e10.l + " :" + i10);
            }
            if (t10) {
              if (0 == s10[i10][0] && s10.length > i10 + 1 && s10[i10][1] == s10[i10 + 1][1]) continue;
              var p2 = t10[s10[i10][0]];
              if (u2[p2.n] = nL(e10, p2.t, { raw: true }), "version" === p2.p && (u2[p2.n] = String(u2[p2.n] >> 16) + "." + ("0000" + String(65535 & u2[p2.n])).slice(-4)), "CodePage" == p2.n)
                switch (u2[p2.n]) {
                  case 0:
                    u2[p2.n] = 1252;
                  case 874:
                  case 932:
                  case 936:
                  case 949:
                  case 950:
                  case 1250:
                  case 1251:
                  case 1253:
                  case 1254:
                  case 1255:
                  case 1256:
                  case 1257:
                  case 1258:
                  case 1e4:
                  case 1200:
                  case 1201:
                  case 1252:
                  case 65e3:
                  case -536:
                  case 65001:
                  case -535:
                    er(o10 = u2[p2.n] >>> 0 & 65535);
                    break;
                  default:
                    throw Error("Unsupported CodePage: " + u2[p2.n]);
                }
            } else if (1 === s10[i10][0]) {
              if (o10 = u2.CodePage = nL(e10, 2), er(o10), -1 !== c10) {
                var m2 = e10.l;
                e10.l = s10[c10][1], l2 = nD(e10, o10), e10.l = m2;
              }
            } else if (0 === s10[i10][0]) {
              if (0 === o10) {
                c10 = i10, e10.l = s10[i10 + 1][1];
                continue;
              }
              l2 = nD(e10, o10);
            } else {
              var g2, v2 = l2[s10[i10][0]];
              switch (e10[e10.l]) {
                case 65:
                  e10.l += 4, g2 = nP(e10);
                  break;
                case 30:
                case 31:
                  e10.l += 4, g2 = nF(e10, e10[e10.l - 4]).replace(/(^|[^\u0000])\u0000+$/, "$1");
                  break;
                case 3:
                  e10.l += 4, g2 = e10.read_shift(4, "i");
                  break;
                case 19:
                  e10.l += 4, g2 = e10.read_shift(4);
                  break;
                case 5:
                  e10.l += 4, g2 = e10.read_shift(8, "f");
                  break;
                case 11:
                  e10.l += 4, g2 = n$(e10, 4);
                  break;
                case 64:
                  e10.l += 4, g2 = tv(nR(e10));
                  break;
                default:
                  throw Error("unparsed value: " + e10[e10.l]);
              }
              u2[v2] = g2;
            }
          }
          return e10.l = r10 + a10, u2;
        }
        var nB = ["CodePage", "Thumbnail", "_PID_LINKBASE", "_PID_HLINKS", "SystemIdentifier", "FMTID"];
        function nW(e10, t10, r10) {
          var a10 = as(8), n10 = [], s10 = [], i10 = 8, o10 = 0, c10 = as(8), l2 = as(8);
          if (c10.write_shift(4, 2), c10.write_shift(4, 1200), l2.write_shift(4, 1), s10.push(c10), n10.push(l2), i10 += 8 + c10.length, !t10) {
            (l2 = as(8)).write_shift(4, 0), n10.unshift(l2);
            var f2 = [as(4)];
            for (f2[0].write_shift(4, e10.length), o10 = 0; o10 < e10.length; ++o10) {
              var h2 = e10[o10][0];
              for ((c10 = as(8 + 2 * (h2.length + 1) + (h2.length % 2 ? 0 : 2))).write_shift(4, o10 + 2), c10.write_shift(4, h2.length + 1), c10.write_shift(0, h2, "dbcs"); c10.l != c10.length; )
                c10.write_shift(1, 0);
              f2.push(c10);
            }
            c10 = ek(f2), s10.unshift(c10), i10 += 8 + c10.length;
          }
          for (o10 = 0; o10 < e10.length; ++o10)
            if (!(t10 && !t10[e10[o10][0]] || nB.indexOf(e10[o10][0]) > -1 || n_.indexOf(e10[o10][0]) > -1) && null != e10[o10][1]) {
              var u2 = e10[o10][1], d2 = 0;
              if (t10) {
                var p2 = r10[d2 = +t10[e10[o10][0]]];
                if ("version" == p2.p && "string" == typeof u2) {
                  var m2 = u2.split(".");
                  u2 = (m2[0] << 16) + (+m2[1] || 0);
                }
                c10 = nM(p2.t, u2);
              } else {
                var g2 = (function(e11) {
                  switch (typeof e11) {
                    case "boolean":
                      return 11;
                    case "number":
                      return (0 | e11) == e11 ? 3 : 5;
                    case "string":
                      return 31;
                    case "object":
                      if (e11 instanceof Date) return 64;
                  }
                  return -1;
                })(u2);
                -1 == g2 && (g2 = 31, u2 = String(u2)), c10 = nM(g2, u2);
              }
              s10.push(c10), (l2 = as(8)).write_shift(4, t10 ? d2 : 2 + o10), n10.push(l2), i10 += 8 + c10.length;
            }
          var v2 = 8 * (s10.length + 1);
          for (o10 = 0; o10 < s10.length; ++o10) n10[o10].write_shift(4, v2), v2 += s10[o10].length;
          return a10.write_shift(4, i10), a10.write_shift(4, s10.length), ek([a10].concat(n10).concat(s10));
        }
        function nz(e10, t10, r10) {
          var a10, n10 = e10.content;
          if (!n10) return {};
          aa(n10, 0);
          var s10, i10, o10, c10, l2 = 0;
          n10.chk("feff", "Byte Order: "), n10.read_shift(2);
          var f2 = n10.read_shift(4), h2 = n10.read_shift(16);
          if (h2 !== tr.utils.consts.HEADER_CLSID && h2 !== r10) throw Error("Bad PropertySet CLSID " + h2);
          if (1 !== (s10 = n10.read_shift(4)) && 2 !== s10) throw Error("Unrecognized #Sets: " + s10);
          if (i10 = n10.read_shift(16), c10 = n10.read_shift(4), 1 === s10 && c10 !== n10.l)
            throw Error("Length mismatch: " + c10 + " !== " + n10.l);
          2 === s10 && (o10 = n10.read_shift(16), l2 = n10.read_shift(4));
          var u2 = nU(n10, t10), d2 = { SystemIdentifier: f2 };
          for (var p2 in u2) d2[p2] = u2[p2];
          if (d2.FMTID = i10, 1 === s10) return d2;
          if (l2 - n10.l == 2 && (n10.l += 2), n10.l !== l2) throw Error("Length mismatch 2: " + n10.l + " !== " + l2);
          try {
            a10 = nU(n10, null);
          } catch (e11) {
          }
          for (p2 in a10) d2[p2] = a10[p2];
          return d2.FMTID = [i10, o10], d2;
        }
        function nH(e10, t10, r10, a10, n10, s10) {
          var i10 = as(n10 ? 68 : 48), o10 = [i10];
          i10.write_shift(2, 65534), i10.write_shift(2, 0), i10.write_shift(4, 842412599), i10.write_shift(16, tr.utils.consts.HEADER_CLSID, "hex"), i10.write_shift(4, n10 ? 2 : 1), i10.write_shift(16, t10, "hex"), i10.write_shift(4, n10 ? 68 : 48);
          var c10 = nW(e10, r10, a10);
          if (o10.push(c10), n10) {
            var l2 = nW(n10, null, null);
            i10.write_shift(16, s10, "hex"), i10.write_shift(4, 68 + c10.length), o10.push(l2);
          }
          return ek(o10);
        }
        function nV(e10, t10) {
          return e10.read_shift(t10), null;
        }
        function n$(e10, t10) {
          return 1 === e10.read_shift(t10);
        }
        function nG(e10, t10) {
          return t10 || (t10 = as(2)), t10.write_shift(2, +!!e10), t10;
        }
        function nX(e10) {
          return e10.read_shift(2, "u");
        }
        function nj(e10, t10) {
          return t10 || (t10 = as(2)), t10.write_shift(2, e10), t10;
        }
        function nK(e10, t10) {
          for (var r10 = [], a10 = e10.l + t10; e10.l < a10; ) r10.push(nX(e10, a10 - e10.l));
          if (a10 !== e10.l) throw Error("Slurp error");
          return r10;
        }
        function nY(e10) {
          var t10 = e10.read_shift(1);
          return 1 === e10.read_shift(1) ? t10 : 1 === t10;
        }
        function nZ(e10, t10, r10) {
          return r10 || (r10 = as(2)), r10.write_shift(1, "e" == t10 ? +e10 : +!!e10), r10.write_shift(1, +("e" == t10)), r10;
        }
        function nJ(e10, t10, r10) {
          var a10 = e10.read_shift(r10 && r10.biff >= 12 ? 2 : 1), n10 = "sbcs-cont", s10 = J;
          r10 && r10.biff >= 8 && (J = 1200), r10 && 8 != r10.biff ? 12 == r10.biff && (n10 = "wstr") : e10.read_shift(1) && (n10 = "dbcs-cont"), r10.biff >= 2 && r10.biff <= 5 && (n10 = "cpstr");
          var i10 = a10 ? e10.read_shift(a10, n10) : "";
          return J = s10, i10;
        }
        function nq(e10, t10, r10) {
          if (r10) {
            if (r10.biff >= 2 && r10.biff <= 5) return e10.read_shift(t10, "cpstr");
            if (r10.biff >= 12) return e10.read_shift(t10, "dbcs-cont");
          }
          return 0 === e10.read_shift(1) ? e10.read_shift(t10, "sbcs-cont") : e10.read_shift(t10, "dbcs-cont");
        }
        function nQ(e10, t10, r10) {
          var a10 = e10.read_shift(r10 && 2 == r10.biff ? 1 : 2);
          return 0 === a10 ? (e10.l++, "") : nq(e10, a10, r10);
        }
        function n0(e10, t10, r10) {
          if (r10.biff > 5) return nQ(e10, t10, r10);
          var a10 = e10.read_shift(1);
          return 0 === a10 ? (e10.l++, "") : e10.read_shift(a10, r10.biff <= 4 || !e10.lens ? "cpstr" : "sbcs-cont");
        }
        function n1(e10, t10, r10) {
          return r10 || (r10 = as(3 + 2 * e10.length)), r10.write_shift(2, e10.length), r10.write_shift(1, 1), r10.write_shift(31, e10, "utf16le"), r10;
        }
        function n2(e10) {
          var t10 = e10.read_shift(4);
          return t10 > 0 ? e10.read_shift(t10, "utf16le").replace(ex, "") : "";
        }
        function n4(e10, t10) {
          t10 || (t10 = as(6 + 2 * e10.length)), t10.write_shift(4, 1 + e10.length);
          for (var r10 = 0; r10 < e10.length; ++r10) t10.write_shift(2, e10.charCodeAt(r10));
          return t10.write_shift(2, 0), t10;
        }
        function n3(e10) {
          return [e10.read_shift(1), e10.read_shift(1), e10.read_shift(1), e10.read_shift(1)];
        }
        function n5(e10, t10) {
          var r10 = n3(e10, t10);
          return r10[3] = 0, r10;
        }
        function n6(e10, t10, r10) {
          var a10 = { r: e10.read_shift(2), c: e10.read_shift(2), ixfe: 0 };
          return r10 && 2 == r10.biff || 7 == t10 ? (a10.ixfe = 63 & e10.read_shift(1), e10.l += 2) : a10.ixfe = e10.read_shift(2), a10;
        }
        function n8(e10, t10, r10, a10) {
          return a10 || (a10 = as(6)), a10.write_shift(2, e10), a10.write_shift(2, t10), a10.write_shift(2, r10 || 0), a10;
        }
        function n7(e10) {
          return [e10.read_shift(2), aB(e10)];
        }
        function n9(e10) {
          var t10 = e10.read_shift(2), r10 = e10.read_shift(2);
          return { s: { c: e10.read_shift(2), r: t10 }, e: { c: e10.read_shift(2), r: r10 } };
        }
        function se(e10, t10) {
          return t10 || (t10 = as(8)), t10.write_shift(2, e10.s.r), t10.write_shift(2, e10.e.r), t10.write_shift(2, e10.s.c), t10.write_shift(2, e10.e.c), t10;
        }
        function st(e10) {
          var t10 = e10.read_shift(2), r10 = e10.read_shift(2);
          return { s: { c: e10.read_shift(1), r: t10 }, e: { c: e10.read_shift(1), r: r10 } };
        }
        function sr(e10) {
          e10.l += 4;
          var t10 = e10.read_shift(2), r10 = e10.read_shift(2), a10 = e10.read_shift(2);
          return e10.l += 12, [r10, t10, a10];
        }
        function sa(e10) {
          e10.l += 2, e10.l += e10.read_shift(2);
        }
        var sn = {
          0: sa,
          4: sa,
          5: sa,
          6: sa,
          7: function(e10) {
            return e10.l += 4, e10.cf = e10.read_shift(2), {};
          },
          8: sa,
          9: sa,
          10: sa,
          11: sa,
          12: sa,
          13: function(e10) {
            var t10 = {};
            return e10.l += 4, e10.l += 16, t10.fSharedNote = e10.read_shift(2), e10.l += 4, t10;
          },
          14: sa,
          15: sa,
          16: sa,
          17: sa,
          18: sa,
          19: sa,
          20: sa,
          21: sr
        };
        function ss(e10, t10) {
          var r10 = { BIFFVer: 0, dt: 0 };
          switch (r10.BIFFVer = e10.read_shift(2), (t10 -= 2) >= 2 && (r10.dt = e10.read_shift(2), e10.l -= 2), r10.BIFFVer) {
            case 1536:
            case 1280:
            case 1024:
            case 768:
            case 512:
            case 2:
            case 7:
              break;
            default:
              if (t10 > 6) throw Error("Unexpected BIFF Ver " + r10.BIFFVer);
          }
          return e10.read_shift(t10), r10;
        }
        function si(e10, t10, r10) {
          var a10 = 1536, n10 = 16;
          switch (r10.bookType) {
            case "biff8":
            case "xla":
              break;
            case "biff5":
              a10 = 1280, n10 = 8;
              break;
            case "biff4":
              a10 = 4, n10 = 6;
              break;
            case "biff3":
              a10 = 3, n10 = 6;
              break;
            case "biff2":
              a10 = 2, n10 = 4;
              break;
            default:
              throw Error("unsupported BIFF version");
          }
          var s10 = as(n10);
          return s10.write_shift(2, a10), s10.write_shift(2, t10), n10 > 4 && s10.write_shift(2, 29282), n10 > 6 && s10.write_shift(2, 1997), n10 > 8 && (s10.write_shift(2, 49161), s10.write_shift(2, 1), s10.write_shift(2, 1798), s10.write_shift(2, 0)), s10;
        }
        function so(e10, t10, r10) {
          var a10 = 0;
          r10 && 2 == r10.biff || (a10 = e10.read_shift(2));
          var n10 = e10.read_shift(2);
          return r10 && 2 == r10.biff && (a10 = 1 - (n10 >> 15), n10 &= 32767), [{ Unsynced: 1 & a10, DyZero: (2 & a10) >> 1, ExAsc: (4 & a10) >> 2, ExDsc: (8 & a10) >> 3 }, n10];
        }
        function sc(e10, t10, r10) {
          var a10 = e10.l + t10, n10 = 8 != r10.biff && r10.biff ? 2 : 4, s10 = e10.read_shift(n10), i10 = e10.read_shift(n10), o10 = e10.read_shift(2), c10 = e10.read_shift(2);
          return e10.l = a10, { s: { r: s10, c: o10 }, e: { r: i10, c: c10 } };
        }
        function sl(e10, t10, r10, a10) {
          var n10 = r10 && 5 == r10.biff;
          a10 || (a10 = as(n10 ? 16 : 20)), a10.write_shift(2, 0), e10.style ? (a10.write_shift(2, e10.numFmtId || 0), a10.write_shift(2, 65524)) : (a10.write_shift(2, e10.numFmtId || 0), a10.write_shift(2, t10 << 4));
          var s10 = 0;
          return e10.numFmtId > 0 && n10 && (s10 |= 1024), a10.write_shift(4, s10), a10.write_shift(4, 0), n10 || a10.write_shift(4, 0), a10.write_shift(2, 0), a10;
        }
        function sf(e10) {
          var t10 = as(12);
          return t10.l++, t10.write_shift(1, e10.numFmtId), t10.l += 10, t10;
        }
        function sh(e10, t10, r10, a10, n10, s10) {
          var i10 = as(8);
          return n8(e10, t10, a10, i10), nZ(r10, s10, i10), i10;
        }
        var su = function(e10, t10, r10) {
          return 0 === t10 ? "" : n0(e10, t10, r10);
        };
        function sd(e10, t10, r10) {
          var a10, n10 = e10.read_shift(2), s10 = {
            fBuiltIn: 1 & n10,
            fWantAdvise: n10 >>> 1 & 1,
            fWantPict: n10 >>> 2 & 1,
            fOle: n10 >>> 3 & 1,
            fOleLink: n10 >>> 4 & 1,
            cf: n10 >>> 5 & 1023,
            fIcon: n10 >>> 15 & 1
          };
          return 14849 === r10.sbcch && (a10 = (function(e11, t11, r11) {
            e11.l += 4, t11 -= 4;
            var a11 = e11.l + t11, n11 = nJ(e11, t11, r11), s11 = e11.read_shift(2);
            if (s11 !== (a11 -= e11.l)) throw Error("Malformed AddinUdf: padding = " + a11 + " != " + s11);
            return e11.l += s11, n11;
          })(e10, t10 - 2, r10)), s10.body = a10 || e10.read_shift(t10 - 2), "string" == typeof a10 && (s10.Name = a10), s10;
        }
        function sp(e10, t10, r10) {
          var a10, n10, s10, i10, o10, c10, l2, f2 = e10.l + t10, h2 = e10.read_shift(2), u2 = e10.read_shift(1), d2 = e10.read_shift(1), p2 = e10.read_shift(r10 && 2 == r10.biff ? 1 : 2), m2 = 0;
          (!r10 || r10.biff >= 5) && (5 != r10.biff && (e10.l += 2), m2 = e10.read_shift(2), 5 == r10.biff && (e10.l += 2), e10.l += 4);
          var g2 = nq(e10, d2, r10);
          32 & h2 && (g2 = a1[g2.charCodeAt(0)]);
          var v2 = f2 - e10.l;
          return r10 && 2 == r10.biff && --v2, {
            chKey: u2,
            Name: g2,
            itab: m2,
            rgce: f2 != e10.l && 0 !== p2 && v2 > 0 ? (a10 = e10, n10 = v2, s10 = r10, i10 = p2, c10 = a10.l + n10, l2 = iD(a10, i10, s10), c10 !== a10.l && (o10 = iF(a10, c10 - a10.l, l2, s10)), [l2, o10]) : []
          };
        }
        function sm(e10, t10, r10) {
          if (r10.biff < 8 || !(r10.biff > 8) && t10 == e10[e10.l] + +(3 == e10[e10.l + 1]) + 1)
            return (function(e11, t11, r11) {
              3 == e11[e11.l + 1] && e11[e11.l]++;
              var a11 = nJ(e11, t11, r11);
              return 3 == a11.charCodeAt(0) ? a11.slice(1) : a11;
            })(e10, t10, r10);
          for (var a10 = [], n10 = e10.l + t10, s10 = e10.read_shift(r10.biff > 8 ? 4 : 2); 0 != s10--; )
            a10.push(
              (function(e11, t11, r11) {
                var a11 = r11.biff > 8 ? 4 : 2;
                return [e11.read_shift(a11), e11.read_shift(a11, "i"), e11.read_shift(a11, "i")];
              })(e10, r10.biff, r10)
            );
          if (e10.l != n10) throw Error("Bad ExternSheet: " + e10.l + " != " + n10);
          return a10;
        }
        function sg(e10, t10, r10) {
          var a10 = st(e10, 6);
          switch (r10.biff) {
            case 2:
              e10.l++, t10 -= 7;
              break;
            case 3:
            case 4:
              e10.l += 2, t10 -= 8;
              break;
            default:
              e10.l += 6, t10 -= 12;
          }
          return [
            a10,
            (function(e11, t11, r11) {
              var a11, n10, s10 = e11.l + t11, i10 = 2 == r11.biff ? 1 : 2, o10 = e11.read_shift(i10);
              if (65535 == o10) return [[], (a11 = t11 - 2, void (e11.l += a11))];
              var c10 = iD(e11, o10, r11);
              return t11 !== o10 + i10 && (n10 = iF(e11, t11 - o10 - i10, c10, r11)), e11.l = s10, [c10, n10];
            })(e10, t10, r10, a10)
          ];
        }
        function sv(e10, t10, r10, a10) {
          var n10 = as(6 + (a10 || e10.length));
          return n10.write_shift(2, t10), n10.write_shift(2, r10), n10.write_shift(2, a10 || e10.length), n10.write_shift(e10.length, e10, "sbcs"), n10;
        }
        var sb = {
          8: function(e10, t10) {
            var r10 = e10.l + t10;
            e10.l += 10;
            var a10 = e10.read_shift(2);
            e10.l += 4, e10.l += 2, e10.l += 2, e10.l += 2, e10.l += 4;
            var n10 = e10.read_shift(1);
            return e10.l += n10, e10.l = r10, { fmt: a10 };
          }
        };
        function sw(e10, t10, r10) {
          if (!r10.cellStyles) return void (e10.l += t10);
          var a10 = r10 && r10.biff >= 12 ? 4 : 2, n10 = e10.read_shift(a10), s10 = e10.read_shift(a10), i10 = e10.read_shift(a10), o10 = e10.read_shift(a10), c10 = e10.read_shift(2);
          2 == a10 && (e10.l += 2);
          var l2 = { s: n10, e: s10, w: i10, ixfe: o10, flags: c10 };
          return (r10.biff >= 5 || !r10.biff) && (l2.level = c10 >> 8 & 7), l2;
        }
        function sT(e10, t10, r10, a10, n10) {
          return e10 || (e10 = as(7)), e10.write_shift(2, t10), e10.write_shift(2, r10), e10.write_shift(1, a10 || 0), e10.write_shift(1, n10 || 0), e10.write_shift(1, 0), e10;
        }
        var sy = [2, 3, 48, 49, 131, 139, 140, 245], sE = (function() {
          var e10 = {
            1: 437,
            2: 850,
            3: 1252,
            4: 1e4,
            100: 852,
            101: 866,
            102: 865,
            103: 861,
            104: 895,
            105: 620,
            106: 737,
            107: 857,
            120: 950,
            121: 949,
            122: 936,
            123: 932,
            124: 874,
            125: 1255,
            126: 1256,
            150: 10007,
            151: 10029,
            152: 10006,
            200: 1250,
            201: 1251,
            202: 1254,
            203: 1253,
            0: 20127,
            8: 865,
            9: 437,
            10: 850,
            11: 437,
            13: 437,
            14: 850,
            15: 437,
            16: 850,
            17: 437,
            18: 850,
            19: 932,
            20: 850,
            21: 437,
            22: 850,
            23: 865,
            24: 437,
            25: 437,
            26: 850,
            27: 437,
            28: 863,
            29: 850,
            31: 852,
            34: 852,
            35: 852,
            36: 860,
            37: 850,
            38: 866,
            55: 850,
            64: 852,
            77: 936,
            78: 949,
            79: 950,
            80: 874,
            87: 1252,
            88: 1252,
            89: 1252,
            108: 863,
            134: 737,
            135: 852,
            136: 857,
            204: 1257,
            255: 16969
          }, t10 = to({
            1: 437,
            2: 850,
            3: 1252,
            4: 1e4,
            100: 852,
            101: 866,
            102: 865,
            103: 861,
            104: 895,
            105: 620,
            106: 737,
            107: 857,
            120: 950,
            121: 949,
            122: 936,
            123: 932,
            124: 874,
            125: 1255,
            126: 1256,
            150: 10007,
            151: 10029,
            152: 10006,
            200: 1250,
            201: 1251,
            202: 1254,
            203: 1253,
            0: 20127
          });
          function r10(t11, r11) {
            var a11 = r11 || {};
            a11.dateNF || (a11.dateNF = "yyyymmdd");
            var n10 = aC(
              (function(t12, r12) {
                var a12 = [], n11 = ev(1);
                switch (r12.type) {
                  case "base64":
                    n11 = ew(ed(t12));
                    break;
                  case "binary":
                    n11 = ew(t12);
                    break;
                  case "buffer":
                  case "array":
                    n11 = t12;
                }
                aa(n11, 0);
                var s10 = n11.read_shift(1), i10 = !!(136 & s10), o10 = false, c10 = false;
                switch (s10) {
                  case 2:
                  case 3:
                  case 131:
                  case 139:
                  case 245:
                    break;
                  case 48:
                  case 49:
                    o10 = true, i10 = true;
                    break;
                  case 140:
                    c10 = true;
                    break;
                  default:
                    throw Error("DBF Unsupported Version: " + s10.toString(16));
                }
                var l2 = 0, f2 = 521;
                2 == s10 && (l2 = n11.read_shift(2)), n11.l += 3, 2 != s10 && (l2 = n11.read_shift(4)), l2 > 1048576 && (l2 = 1e6), 2 != s10 && (f2 = n11.read_shift(2));
                var h2 = n11.read_shift(2), u2 = r12.codepage || 1252;
                2 != s10 && (n11.l += 16, n11.read_shift(1), 0 !== n11[n11.l] && (u2 = e10[n11[n11.l]]), n11.l += 1, n11.l += 2), c10 && (n11.l += 36);
                for (var d2 = [], p2 = {}, m2 = Math.min(n11.length, 2 == s10 ? 521 : f2 - 10 - 264 * !!o10), g2 = c10 ? 32 : 11; n11.l < m2 && 13 != n11[n11.l]; )
                  switch ((p2 = {}).name = (void 0 !== G ? G.utils.decode(u2, n11.slice(n11.l, n11.l + g2)) : ey(n11.slice(n11.l, n11.l + g2))).replace(/[\u0000\r\n][\S\s]*$/g, ""), n11.l += g2, p2.type = String.fromCharCode(n11.read_shift(1)), 2 != s10 && !c10 && (p2.offset = n11.read_shift(4)), p2.len = n11.read_shift(1), 2 == s10 && (p2.offset = n11.read_shift(2)), p2.dec = n11.read_shift(1), p2.name.length && d2.push(p2), 2 != s10 && (n11.l += c10 ? 13 : 14), p2.type) {
                    case "B":
                      (!o10 || 8 != p2.len) && r12.WTF && console.log("Skipping " + p2.name + ":" + p2.type);
                      break;
                    case "G":
                    case "P":
                      r12.WTF && console.log("Skipping " + p2.name + ":" + p2.type);
                      break;
                    case "+":
                    case "0":
                    case "@":
                    case "C":
                    case "D":
                    case "F":
                    case "I":
                    case "L":
                    case "M":
                    case "N":
                    case "O":
                    case "T":
                    case "Y":
                      break;
                    default:
                      throw Error("Unknown Field Type: " + p2.type);
                  }
                if (13 !== n11[n11.l] && (n11.l = f2 - 1), 13 !== n11.read_shift(1))
                  throw Error("DBF Terminator not found " + n11.l + " " + n11[n11.l]);
                n11.l = f2;
                var v2 = 0, b2 = 0;
                for (b2 = 0, a12[0] = []; b2 != d2.length; ++b2) a12[0][b2] = d2[b2].name;
                for (; l2-- > 0; ) {
                  if (42 === n11[n11.l]) {
                    n11.l += h2;
                    continue;
                  }
                  for (++n11.l, a12[++v2] = [], b2 = 0, b2 = 0; b2 != d2.length; ++b2) {
                    var w2 = n11.slice(n11.l, n11.l + d2[b2].len);
                    n11.l += d2[b2].len, aa(w2, 0);
                    var T2 = void 0 !== G ? G.utils.decode(u2, w2) : ey(w2);
                    switch (d2[b2].type) {
                      case "C":
                        T2.trim().length && (a12[v2][b2] = T2.replace(/([^\s])\s+$/, "$1"));
                        break;
                      case "D":
                        8 === T2.length ? (a12[v2][b2] = new Date(
                          Date.UTC(+T2.slice(0, 4), T2.slice(4, 6) - 1, +T2.slice(6, 8), 0, 0, 0, 0)
                        ), r12 && r12.UTC || (a12[v2][b2] = tI(a12[v2][b2]))) : a12[v2][b2] = T2;
                        break;
                      case "F":
                        a12[v2][b2] = parseFloat(T2.trim());
                        break;
                      case "+":
                      case "I":
                        a12[v2][b2] = c10 ? 2147483648 ^ w2.read_shift(-4, "i") : w2.read_shift(4, "i");
                        break;
                      case "L":
                        switch (T2.trim().toUpperCase()) {
                          case "Y":
                          case "T":
                            a12[v2][b2] = true;
                            break;
                          case "N":
                          case "F":
                            a12[v2][b2] = false;
                            break;
                          case "":
                          case "\0":
                          case "?":
                            break;
                          default:
                            throw Error("DBF Unrecognized L:|" + T2 + "|");
                        }
                        break;
                      case "M":
                        if (!i10) throw Error("DBF Unexpected MEMO for type " + s10.toString(16));
                        a12[v2][b2] = "##MEMO##" + (c10 ? parseInt(T2.trim(), 10) : w2.read_shift(4));
                        break;
                      case "N":
                        (T2 = T2.replace(/\u0000/g, "").trim()) && "." != T2 && (a12[v2][b2] = +T2 || 0);
                        break;
                      case "@":
                        a12[v2][b2] = new Date(w2.read_shift(-8, "f") - 621356832e5);
                        break;
                      case "T":
                        var y2 = w2.read_shift(4), E2 = w2.read_shift(4);
                        if (0 == y2 && 0 == E2) break;
                        a12[v2][b2] = new Date((y2 - 2440588) * 864e5 + E2), r12 && r12.UTC || (a12[v2][b2] = tI(a12[v2][b2]));
                        break;
                      case "Y":
                        a12[v2][b2] = w2.read_shift(4, "i") / 1e4 + w2.read_shift(4, "i") / 1e4 * 4294967296;
                        break;
                      case "O":
                        a12[v2][b2] = -w2.read_shift(-8, "f");
                        break;
                      case "B":
                        if (o10 && 8 == d2[b2].len) {
                          a12[v2][b2] = w2.read_shift(8, "f");
                          break;
                        }
                      case "G":
                      case "P":
                        w2.l += d2[b2].len;
                        break;
                      case "0":
                        if ("_NullFlags" === d2[b2].name) break;
                      default:
                        throw Error("DBF Unsupported data type " + d2[b2].type);
                    }
                  }
                }
                if (2 != s10 && n11.l < n11.length && 26 != n11[n11.l++])
                  throw Error(
                    "DBF EOF Marker missing " + (n11.l - 1) + " of " + n11.length + " " + n11[n11.l - 1].toString(16)
                  );
                return r12 && r12.sheetRows && (a12 = a12.slice(0, r12.sheetRows)), r12.DBF = d2, a12;
              })(t11, a11),
              a11
            );
            return n10["!cols"] = a11.DBF.map(function(e11) {
              return { wch: e11.len, DBF: e11 };
            }), delete a11.DBF, n10;
          }
          var a10 = { B: 8, C: 250, L: 1, D: 8, "?": 0, "": 0 };
          return {
            to_workbook: function(e11, t11) {
              try {
                var a11 = aS(r10(e11, t11), t11);
                return a11.bookType = "dbf", a11;
              } catch (e12) {
                if (t11 && t11.WTF) throw e12;
              }
              return { SheetNames: [], Sheets: {} };
            },
            to_sheet: r10,
            from_sheet: function(r11, n10) {
              if (!r11["!ref"]) throw Error("Cannot export empty sheet to DBF");
              var s10 = n10 || {}, i10 = J;
              if (+s10.codepage >= 0 && er(+s10.codepage), "string" == s10.type)
                throw Error("Cannot write DBF to JS string");
              var o10 = ao(), c10 = c2(r11, { header: 1, raw: true, cellDates: true }), l2 = c10[0], f2 = c10.slice(1), h2 = r11["!cols"] || [], u2 = 0, d2 = 0, p2 = 0, m2 = 1;
              for (u2 = 0; u2 < l2.length; ++u2) {
                if (((h2[u2] || {}).DBF || {}).name) {
                  l2[u2] = h2[u2].DBF.name, ++p2;
                  continue;
                }
                if (null != l2[u2]) {
                  if (++p2, "number" == typeof l2[u2] && (l2[u2] = l2[u2].toString(10)), "string" != typeof l2[u2])
                    throw Error("DBF Invalid column name " + l2[u2] + " |" + typeof l2[u2] + "|");
                  if (l2.indexOf(l2[u2]) !== u2) {
                    for (d2 = 0; d2 < 1024; ++d2)
                      if (-1 == l2.indexOf(l2[u2] + "_" + d2)) {
                        l2[u2] += "_" + d2;
                        break;
                      }
                  }
                }
              }
              var g2 = ak(r11["!ref"]), v2 = [], b2 = [], w2 = [];
              for (u2 = 0; u2 <= g2.e.c - g2.s.c; ++u2) {
                var T2 = "", y2 = "", E2 = 0, k2 = [];
                for (d2 = 0; d2 < f2.length; ++d2) null != f2[d2][u2] && k2.push(f2[d2][u2]);
                if (0 == k2.length || null == l2[u2]) {
                  v2[u2] = "?";
                  continue;
                }
                for (d2 = 0; d2 < k2.length; ++d2) {
                  switch (typeof k2[d2]) {
                    case "number":
                      y2 = "B";
                      break;
                    case "string":
                    default:
                      y2 = "C";
                      break;
                    case "boolean":
                      y2 = "L";
                      break;
                    case "object":
                      y2 = k2[d2] instanceof Date ? "D" : "C";
                  }
                  E2 = Math.max(
                    E2,
                    (void 0 !== G && "string" == typeof k2[d2] ? G.utils.encode(q, k2[d2]) : String(k2[d2])).length
                  ), T2 = T2 && T2 != y2 ? "C" : y2;
                }
                E2 > 250 && (E2 = 250), "C" == (y2 = ((h2[u2] || {}).DBF || {}).type) && h2[u2].DBF.len > E2 && (E2 = h2[u2].DBF.len), "B" == T2 && "N" == y2 && (T2 = "N", w2[u2] = h2[u2].DBF.dec, E2 = h2[u2].DBF.len), b2[u2] = "C" == T2 || "N" == y2 ? E2 : a10[T2] || 0, m2 += b2[u2], v2[u2] = T2;
              }
              var x2 = o10.next(32);
              for (x2.write_shift(4, 318902576), x2.write_shift(4, f2.length), x2.write_shift(2, 296 + 32 * p2), x2.write_shift(2, m2), u2 = 0; u2 < 4; ++u2)
                x2.write_shift(4, 0);
              var _2 = +t10[J] || 3;
              for (x2.write_shift(4, _2 << 8), e10[_2] != +s10.codepage && (s10.codepage && console.error("DBF Unsupported codepage " + J + ", using 1252"), J = 1252), u2 = 0, d2 = 0; u2 < l2.length; ++u2)
                if (null != l2[u2]) {
                  var S2 = o10.next(32), A2 = (l2[u2].slice(-10) + "\0\0\0\0\0\0\0\0\0\0\0").slice(0, 11);
                  S2.write_shift(1, A2, "sbcs"), S2.write_shift(1, "?" == v2[u2] ? "C" : v2[u2], "sbcs"), S2.write_shift(4, d2), S2.write_shift(1, b2[u2] || a10[v2[u2]] || 0), S2.write_shift(1, w2[u2] || 0), S2.write_shift(1, 2), S2.write_shift(4, 0), S2.write_shift(1, 0), S2.write_shift(4, 0), S2.write_shift(4, 0), d2 += b2[u2] || a10[v2[u2]] || 0;
                }
              var C2 = o10.next(264);
              for (C2.write_shift(4, 13), u2 = 0; u2 < 65; ++u2) C2.write_shift(4, 0);
              for (u2 = 0; u2 < f2.length; ++u2) {
                var I2 = o10.next(m2);
                for (I2.write_shift(1, 0), d2 = 0; d2 < l2.length; ++d2)
                  if (null != l2[d2])
                    switch (v2[d2]) {
                      case "L":
                        I2.write_shift(1, null == f2[u2][d2] ? 63 : f2[u2][d2] ? 84 : 70);
                        break;
                      case "B":
                        I2.write_shift(8, f2[u2][d2] || 0, "f");
                        break;
                      case "N":
                        var O2 = "0";
                        for ("number" == typeof f2[u2][d2] && (O2 = f2[u2][d2].toFixed(w2[d2] || 0)), O2.length > b2[d2] && (O2 = O2.slice(0, b2[d2])), p2 = 0; p2 < b2[d2] - O2.length; ++p2)
                          I2.write_shift(1, 32);
                        I2.write_shift(1, O2, "sbcs");
                        break;
                      case "D":
                        f2[u2][d2] ? (I2.write_shift(4, ("0000" + f2[u2][d2].getFullYear()).slice(-4), "sbcs"), I2.write_shift(2, ("00" + (f2[u2][d2].getMonth() + 1)).slice(-2), "sbcs"), I2.write_shift(2, ("00" + f2[u2][d2].getDate()).slice(-2), "sbcs")) : I2.write_shift(8, "00000000", "sbcs");
                        break;
                      case "C":
                        var R2 = I2.l, N2 = String(null != f2[u2][d2] ? f2[u2][d2] : "").slice(0, b2[d2]);
                        for (I2.write_shift(1, N2, "cpstr"), R2 += b2[d2] - I2.l, p2 = 0; p2 < R2; ++p2) I2.write_shift(1, 32);
                    }
              }
              return J = i10, o10.next(1).write_shift(1, 26), o10.end();
            }
          };
        })(), sk = (function() {
          var e10 = {
            AA: "À",
            BA: "Á",
            CA: "Â",
            DA: 195,
            HA: "Ä",
            JA: 197,
            AE: "È",
            BE: "É",
            CE: "Ê",
            HE: "Ë",
            AI: "Ì",
            BI: "Í",
            CI: "Î",
            HI: "Ï",
            AO: "Ò",
            BO: "Ó",
            CO: "Ô",
            DO: 213,
            HO: "Ö",
            AU: "Ù",
            BU: "Ú",
            CU: "Û",
            HU: "Ü",
            Aa: "à",
            Ba: "á",
            Ca: "â",
            Da: 227,
            Ha: "ä",
            Ja: 229,
            Ae: "è",
            Be: "é",
            Ce: "ê",
            He: "ë",
            Ai: "ì",
            Bi: "í",
            Ci: "î",
            Hi: "ï",
            Ao: "ò",
            Bo: "ó",
            Co: "ô",
            Do: 245,
            Ho: "ö",
            Au: "ù",
            Bu: "ú",
            Cu: "û",
            Hu: "ü",
            KC: "Ç",
            Kc: "ç",
            q: "æ",
            z: "œ",
            a: "Æ",
            j: "Œ",
            DN: 209,
            Dn: 241,
            Hy: 255,
            S: 169,
            c: 170,
            R: 174,
            "B ": 180,
            0: 176,
            1: 177,
            2: 178,
            3: 179,
            5: 181,
            6: 182,
            7: 183,
            Q: 185,
            k: 186,
            b: 208,
            i: 216,
            l: 222,
            s: 240,
            y: 248,
            "!": 161,
            '"': 162,
            "#": 163,
            "(": 164,
            "%": 165,
            "'": 167,
            "H ": 168,
            "+": 171,
            ";": 187,
            "<": 188,
            "=": 189,
            ">": 190,
            "?": 191,
            "{": 223
          }, t10 = RegExp(
            "\x1BN(" + ts(e10).join("|").replace(/\|\|\|/, "|\\||").replace(/([?()+])/g, "\\$1").replace("{", "\\{") + "|\\|)",
            "gm"
          );
          try {
            t10 = RegExp(
              "\x1BN(" + ts(e10).join("|").replace(/\|\|\|/, "|\\||").replace(/([?()+])/g, "\\$1") + "|\\|)",
              "gm"
            );
          } catch (e11) {
          }
          var r10 = function(t11, r11) {
            var a10 = e10[r11];
            return "number" == typeof a10 ? el(a10) : a10;
          }, n10 = function(e11, t11, r11) {
            var a10 = t11.charCodeAt(0) - 32 << 4 | r11.charCodeAt(0) - 48;
            return 59 == a10 ? e11 : el(a10);
          };
          function s10(e11, a10) {
            var s11, i10 = e11.split(/[\n\r]+/), o10 = -1, c10 = -1, l2 = 0, f2 = 0, h2 = [], u2 = [], d2 = null, p2 = {}, m2 = [], g2 = [], v2 = [], b2 = 0, w2 = { Workbook: { WBProps: {}, Names: [] } };
            for (+a10.codepage >= 0 && er(+a10.codepage); l2 !== i10.length; ++l2) {
              b2 = 0;
              var T2, y2 = i10[l2].trim().replace(/\x1B([\x20-\x2F])([\x30-\x3F])/g, n10).replace(t10, r10), E2 = y2.replace(/;;/g, "\0").split(";").map(function(e12) {
                return e12.replace(/\u0000/g, ";");
              }), k2 = E2[0];
              if (y2.length > 0)
                switch (k2) {
                  case "ID":
                  case "E":
                  case "B":
                  case "W":
                    break;
                  case "O":
                    for (f2 = 1; f2 < E2.length; ++f2)
                      if ("V" === E2[f2].charAt(0)) {
                        var x2 = parseInt(E2[f2].slice(1), 10);
                        x2 >= 1 && x2 <= 4 && (w2.Workbook.WBProps.date1904 = true);
                      }
                    break;
                  case "P":
                    "P" === E2[1].charAt(0) && u2.push(y2.slice(3).replace(/;;/g, ";"));
                    break;
                  case "NN":
                    var _2 = { Sheet: 0 };
                    for (f2 = 1; f2 < E2.length; ++f2)
                      switch (E2[f2].charAt(0)) {
                        case "N":
                          _2.Name = E2[f2].slice(1);
                          break;
                        case "E":
                          _2.Ref = (a10 && a10.sheet || "Sheet1") + "!" + iu(E2[f2].slice(1));
                      }
                    w2.Workbook.Names.push(_2);
                    break;
                  case "C":
                    var S2 = false, A2 = false, C2 = false, I2 = false, O2 = -1, R2 = -1, N2 = "", F2 = "z", D2 = "";
                    for (f2 = 1; f2 < E2.length; ++f2)
                      switch (E2[f2].charAt(0)) {
                        case "A":
                          D2 = E2[f2].slice(1);
                          break;
                        case "X":
                          c10 = parseInt(E2[f2].slice(1), 10) - 1, A2 = true;
                          break;
                        case "Y":
                          for (o10 = parseInt(E2[f2].slice(1), 10) - 1, A2 || (c10 = 0), s11 = h2.length; s11 <= o10; ++s11)
                            h2[s11] = [];
                          break;
                        case "K":
                          '"' === (T2 = E2[f2].slice(1)).charAt(0) ? (T2 = T2.slice(1, T2.length - 1), F2 = "s") : "TRUE" === T2 || "FALSE" === T2 ? (T2 = "TRUE" === T2, F2 = "b") : "#" == T2.charAt(0) && null != a0[T2] ? (F2 = "e", T2 = a0[T2]) : !isNaN(ty(T2)) && (T2 = ty(T2), F2 = "n", null !== d2 && eQ(d2) && a10.cellDates && (F2 = "number" == typeof (T2 = td(w2.Workbook.WBProps.date1904 ? T2 + 1462 : T2)) ? "n" : "d")), void 0 !== G && "string" == typeof T2 && "string" != (a10 || {}).type && (a10 || {}).codepage && (T2 = G.utils.decode(a10.codepage, T2)), S2 = true;
                          break;
                        case "E":
                          I2 = true, N2 = iu(E2[f2].slice(1), { r: o10, c: c10 });
                          break;
                        case "S":
                          C2 = true;
                          break;
                        case "G":
                          break;
                        case "R":
                          O2 = parseInt(E2[f2].slice(1), 10) - 1;
                          break;
                        case "C":
                          R2 = parseInt(E2[f2].slice(1), 10) - 1;
                          break;
                        default:
                          if (a10 && a10.WTF) throw Error("SYLK bad record " + y2);
                      }
                    if (S2 && (h2[o10][c10] ? (h2[o10][c10].t = F2, h2[o10][c10].v = T2) : h2[o10][c10] = { t: F2, v: T2 }, d2 && (h2[o10][c10].z = d2), false !== a10.cellText && d2 && (h2[o10][c10].w = e22(h2[o10][c10].z, h2[o10][c10].v, { date1904: w2.Workbook.WBProps.date1904 })), d2 = null), C2) {
                      if (I2) throw Error("SYLK shared formula cannot have own formula");
                      var P2 = O2 > -1 && h2[O2][R2];
                      if (!P2 || !P2[1]) throw Error("SYLK shared formula cannot find base");
                      N2 = im(P2[1], { r: o10 - O2, c: c10 - R2 });
                    }
                    N2 && (h2[o10][c10] ? h2[o10][c10].f = N2 : h2[o10][c10] = { t: "n", f: N2 }), D2 && (h2[o10][c10] || (h2[o10][c10] = { t: "z" }), h2[o10][c10].c = [{ a: "SheetJSYLK", t: D2 }]);
                    break;
                  case "F":
                    var L2 = 0;
                    for (f2 = 1; f2 < E2.length; ++f2)
                      switch (E2[f2].charAt(0)) {
                        case "X":
                          c10 = parseInt(E2[f2].slice(1), 10) - 1, ++L2;
                          break;
                        case "Y":
                          for (o10 = parseInt(E2[f2].slice(1), 10) - 1, s11 = h2.length; s11 <= o10; ++s11) h2[s11] = [];
                          break;
                        case "M":
                          b2 = parseInt(E2[f2].slice(1), 10) / 20;
                          break;
                        case "F":
                        case "G":
                        case "S":
                        case "D":
                        case "N":
                          break;
                        case "P":
                          d2 = u2[parseInt(E2[f2].slice(1), 10)];
                          break;
                        case "W":
                          for (s11 = parseInt((v2 = E2[f2].slice(1).split(" "))[0], 10); s11 <= parseInt(v2[1], 10); ++s11)
                            b2 = parseInt(v2[2], 10), g2[s11 - 1] = 0 === b2 ? { hidden: true } : { wch: b2 };
                          break;
                        case "C":
                          g2[c10 = parseInt(E2[f2].slice(1), 10) - 1] || (g2[c10] = {});
                          break;
                        case "R":
                          m2[o10 = parseInt(E2[f2].slice(1), 10) - 1] || (m2[o10] = {}), b2 > 0 ? (m2[o10].hpt = b2, m2[o10].hpx = s2(b2)) : 0 === b2 && (m2[o10].hidden = true);
                          break;
                        default:
                          if (a10 && a10.WTF) throw Error("SYLK bad record " + y2);
                      }
                    L2 < 1 && (d2 = null);
                    break;
                  default:
                    if (a10 && a10.WTF) throw Error("SYLK bad record " + y2);
                }
            }
            return m2.length > 0 && (p2["!rows"] = m2), g2.length > 0 && (p2["!cols"] = g2), g2.forEach(function(e12) {
              s0(e12);
            }), a10 && a10.sheetRows && (h2 = h2.slice(0, a10.sheetRows)), [h2, p2, w2];
          }
          return e10["|"] = 254, {
            to_workbook: function(e11, t11) {
              var r11 = (function(e12, t12) {
                switch (t12.type) {
                  case "base64":
                    return s10(ed(e12), t12);
                  case "binary":
                    return s10(e12, t12);
                  case "buffer":
                    return s10(ep && a.isBuffer(e12) ? e12.toString("binary") : ey(e12), t12);
                  case "array":
                    return s10(tb(e12), t12);
                }
                throw Error("Unrecognized type " + t12.type);
              })(e11, t11), n11 = r11[0], i10 = r11[1], o10 = r11[2], c10 = tw(t11);
              c10.date1904 = (((o10 || {}).Workbook || {}).WBProps || {}).date1904;
              var l2 = aC(n11, c10);
              ts(i10).forEach(function(e12) {
                l2[e12] = i10[e12];
              });
              var f2 = aS(l2, t11);
              return ts(o10).forEach(function(e12) {
                f2[e12] = o10[e12];
              }), f2.bookType = "sylk", f2;
            },
            from_sheet: function(e11, t11, r11) {
              t11 || (t11 = {}), t11._formats = ["General"];
              var a10, n11 = ["ID;PSheetJS;N;E"], s11 = [], i10 = ak(e11["!ref"] || "A1"), o10 = null != e11["!data"], c10 = (((r11 || {}).Workbook || {}).WBProps || {}).date1904;
              n11.push("P;PGeneral");
              var l2 = i10.s.r, f2 = i10.s.c, h2 = [];
              if (e11["!ref"]) {
                for (l2 = i10.s.r; l2 <= i10.e.r; ++l2)
                  if (!o10 || e11["!data"][l2]) {
                    for (h2 = [], f2 = i10.s.c; f2 <= i10.e.c; ++f2)
                      (a10 = o10 ? e11["!data"][l2][f2] : e11[ag(f2) + ap(l2)]) && a10.c && h2.push(
                        (function(e12, t12, r12) {
                          var a11 = "C;Y" + (t12 + 1) + ";X" + (r12 + 1) + ";A";
                          return a11 + e12.map(function(e13) {
                            return e13.t;
                          }).join("").replace(/\n/g, "\x1B :").replace(/\r/g, "\x1B =");
                        })(a10.c, l2, f2)
                      );
                    h2.length && s11.push(h2.join("\r\n"));
                  }
              }
              if (e11["!ref"]) {
                for (l2 = i10.s.r; l2 <= i10.e.r; ++l2)
                  if (!o10 || e11["!data"][l2]) {
                    for (h2 = [], f2 = i10.s.c; f2 <= i10.e.c; ++f2)
                      if ((a10 = o10 ? e11["!data"][l2][f2] : e11[ag(f2) + ap(l2)]) && (null != a10.v || a10.f && !a10.F)) {
                        if ("General" != (a10.z || ("d" == a10.t ? eD[14] : "General"))) {
                          var u2 = t11._formats.indexOf(a10.z);
                          -1 == u2 && (t11._formats.push(a10.z), u2 = t11._formats.length - 1, n11.push("P;P" + a10.z.replace(/;/g, ";;"))), h2.push("F;P" + u2 + ";Y" + (l2 + 1) + ";X" + (f2 + 1));
                        }
                        h2.push(
                          (function(e12, t12, r12, a11, n12, s12) {
                            var i11 = "C;Y" + (r12 + 1) + ";X" + (a11 + 1) + ";K";
                            switch (e12.t) {
                              case "n":
                                i11 += isFinite(e12.v) ? e12.v || 0 : aQ[isNaN(e12.v) ? 36 : 7], e12.f && !e12.F && (i11 += ";E" + ip(e12.f, { r: r12, c: a11 }));
                                break;
                              case "b":
                                i11 += e12.v ? "TRUE" : "FALSE";
                                break;
                              case "e":
                                i11 += e12.w || aQ[e12.v] || e12.v;
                                break;
                              case "d":
                                i11 += tu(tv(e12.v, s12), s12);
                                break;
                              case "s":
                                i11 += '"' + (null == e12.v ? "" : String(e12.v)).replace(/"/g, "").replace(/;/g, ";;") + '"';
                            }
                            return i11;
                          })(a10, 0, l2, f2, 0, c10)
                        );
                      }
                    s11.push(h2.join("\r\n"));
                  }
              }
              return n11.push("F;P0;DG0G8;M255"), e11["!cols"] && e11["!cols"].forEach(function(e12, t12) {
                var r12 = "F;W" + (t12 + 1) + " " + (t12 + 1) + " ";
                e12.hidden ? r12 += "0" : ("number" != typeof e12.width || e12.wpx || (e12.wpx = sY(e12.width)), "number" != typeof e12.wpx || e12.wch || (e12.wch = sZ(e12.wpx)), "number" == typeof e12.wch && (r12 += Math.round(e12.wch))), " " != r12.charAt(r12.length - 1) && n11.push(r12);
              }), e11["!rows"] && e11["!rows"].forEach(function(e12, t12) {
                var r12 = "F;";
                e12.hidden ? r12 += "M0;" : e12.hpt ? r12 += "M" + 20 * e12.hpt + ";" : e12.hpx && (r12 += "M" + 20 * s1(e12.hpx) + ";"), r12.length > 2 && n11.push(r12 + "R" + (t12 + 1));
              }), e11["!ref"] && n11.push(
                "B;Y" + (i10.e.r - i10.s.r + 1) + ";X" + (i10.e.c - i10.s.c + 1) + ";D" + [i10.s.c, i10.s.r, i10.e.c, i10.e.r].join(" ")
              ), n11.push("O;L;D;B" + (c10 ? ";V4" : "") + ";K47;G100 0.001"), delete t11._formats, n11.join("\r\n") + "\r\n" + s11.join("\r\n") + "\r\nE\r\n";
            }
          };
        })(), sx = /* @__PURE__ */ (function() {
          function e10(e11, t11) {
            for (var r11 = e11.split("\n"), a10 = -1, n11 = -1, s10 = 0, i10 = []; s10 !== r11.length; ++s10) {
              if ("BOT" === r11[s10].trim()) {
                i10[++a10] = [], n11 = 0;
                continue;
              }
              if (!(a10 < 0)) {
                for (var o10 = r11[s10].trim().split(","), c10 = o10[0], l2 = o10[1], f2 = r11[++s10] || ""; 1 & (f2.match(/["]/g) || []).length && s10 < r11.length - 1; )
                  f2 += "\n" + r11[++s10];
                switch (f2 = f2.trim(), +c10) {
                  case -1:
                    if ("BOT" === f2) {
                      i10[++a10] = [], n11 = 0;
                      continue;
                    }
                    if ("EOD" !== f2) throw Error("Unrecognized DIF special command " + f2);
                    break;
                  case 0:
                    "TRUE" === f2 ? i10[a10][n11] = true : "FALSE" === f2 ? i10[a10][n11] = false : isNaN(ty(l2)) ? isNaN(tA(l2).getDate()) ? i10[a10][n11] = l2 : (i10[a10][n11] = tv(l2), t11 && t11.UTC || (i10[a10][n11] = tI(i10[a10][n11]))) : i10[a10][n11] = ty(l2), ++n11;
                    break;
                  case 1:
                    (f2 = (f2 = f2.slice(1, f2.length - 1)).replace(/""/g, '"')) && f2.match(/^=".*"$/) && (f2 = f2.slice(2, -1)), i10[a10][n11++] = "" !== f2 ? f2 : null;
                }
                if ("EOD" === f2) break;
              }
            }
            return t11 && t11.sheetRows && (i10 = i10.slice(0, t11.sheetRows)), i10;
          }
          function t10(t11, r11) {
            return aC(
              (function(t12, r12) {
                switch (r12.type) {
                  case "base64":
                    return e10(ed(t12), r12);
                  case "binary":
                    return e10(t12, r12);
                  case "buffer":
                    return e10(ep && a.isBuffer(t12) ? t12.toString("binary") : ey(t12), r12);
                  case "array":
                    return e10(tb(t12), r12);
                }
                throw Error("Unrecognized type " + r12.type);
              })(t11, r11),
              r11
            );
          }
          function r10(e11, t11) {
            return "0," + String(e11) + "\r\n" + t11;
          }
          function n10(e11) {
            return '1,0\r\n"' + e11.replace(/"/g, '""') + '"';
          }
          return {
            to_workbook: function(e11, r11) {
              var a10 = aS(t10(e11, r11), r11);
              return a10.bookType = "dif", a10;
            },
            to_sheet: t10,
            from_sheet: function(e11) {
              if (!e11["!ref"]) throw Error("Cannot export empty sheet to DIF");
              for (var t11 = ak(e11["!ref"]), a10 = null != e11["!data"], s10 = [
                'TABLE\r\n0,1\r\n"sheetjs"\r\n',
                "VECTORS\r\n0," + (t11.e.r - t11.s.r + 1) + '\r\n""\r\n',
                "TUPLES\r\n0," + (t11.e.c - t11.s.c + 1) + '\r\n""\r\n',
                'DATA\r\n0,0\r\n""\r\n'
              ], i10 = t11.s.r; i10 <= t11.e.r; ++i10) {
                for (var o10 = a10 ? e11["!data"][i10] : [], c10 = "-1,0\r\nBOT\r\n", l2 = t11.s.c; l2 <= t11.e.c; ++l2) {
                  var f2 = a10 ? o10 && o10[l2] : e11[ab({ r: i10, c: l2 })];
                  if (null == f2) {
                    c10 += '1,0\r\n""\r\n';
                    continue;
                  }
                  switch (f2.t) {
                    case "n":
                      null != f2.w ? c10 += "0," + f2.w + "\r\nV" : null != f2.v ? c10 += r10(f2.v, "V") : null == f2.f || f2.F ? c10 += '1,0\r\n""' : c10 += n10("=" + f2.f);
                      break;
                    case "b":
                      c10 += f2.v ? r10(1, "TRUE") : r10(0, "FALSE");
                      break;
                    case "s":
                      c10 += n10(isNaN(+f2.v) ? f2.v : '="' + f2.v + '"');
                      break;
                    case "d":
                      f2.w || (f2.w = e22(f2.z || eD[14], tu(tv(f2.v)))), c10 += r10(f2.w, "V");
                      break;
                    default:
                      c10 += '1,0\r\n""';
                  }
                  c10 += "\r\n";
                }
                s10.push(c10);
              }
              return s10.join("") + "-1,0\r\nEOD";
            }
          };
        })(), s_ = /* @__PURE__ */ (function() {
          function e10(e11) {
            return e11.replace(/\\/g, "\\b").replace(/:/g, "\\c").replace(/\n/g, "\\n");
          }
          function t10(e11, t11) {
            return aC(
              (function(e12, t12) {
                for (var r11 = e12.split("\n"), a10 = -1, n10 = -1, s10 = 0, i10 = []; s10 !== r11.length; ++s10) {
                  var o10 = r11[s10].trim().split(":");
                  if ("cell" === o10[0]) {
                    var c10 = av(o10[1]);
                    if (i10.length <= c10.r) for (a10 = i10.length; a10 <= c10.r; ++a10) i10[a10] || (i10[a10] = []);
                    switch (a10 = c10.r, n10 = c10.c, o10[2]) {
                      case "t":
                        i10[a10][n10] = o10[3].replace(/\\b/g, "\\").replace(/\\c/g, ":").replace(/\\n/g, "\n");
                        break;
                      case "v":
                        i10[a10][n10] = +o10[3];
                        break;
                      case "vtf":
                        var l2 = o10[o10.length - 1];
                      case "vtc":
                        "nl" === o10[3] ? i10[a10][n10] = !!+o10[4] : i10[a10][n10] = "#" == o10[o10.length - 1].charAt(0) ? { t: "e", v: a0[o10[o10.length - 1]] } : +o10[4], "vtf" == o10[2] && (i10[a10][n10] = [i10[a10][n10], l2]);
                    }
                  }
                }
                return t12 && t12.sheetRows && (i10 = i10.slice(0, t12.sheetRows)), i10;
              })(e11, t11),
              t11
            );
          }
          var r10 = "--SocialCalcSpreadsheetControlSave\nContent-type: text/plain; charset=UTF-8\n";
          return {
            to_workbook: function(e11, r11) {
              return aS(t10(e11, r11), r11);
            },
            to_sheet: t10,
            from_sheet: function(t11) {
              return [
                "socialcalc:version:1.5\nMIME-Version: 1.0\nContent-Type: multipart/mixed; boundary=SocialCalcSpreadsheetControlSave",
                r10,
                "# SocialCalc Spreadsheet Control Save\npart:sheet",
                r10,
                (function(t12) {
                  if (!t12 || !t12["!ref"]) return "";
                  for (var r11, a10 = [], n10 = [], s10 = "", i10 = aw(t12["!ref"]), o10 = null != t12["!data"], c10 = i10.s.r; c10 <= i10.e.r; ++c10)
                    for (var l2 = i10.s.c; l2 <= i10.e.c; ++l2)
                      if (s10 = ab({ r: c10, c: l2 }), (r11 = o10 ? (t12["!data"][c10] || [])[l2] : t12[s10]) && null != r11.v && "z" !== r11.t) {
                        switch (n10 = ["cell", s10, "t"], r11.t) {
                          case "s":
                            n10.push(e10(r11.v));
                            break;
                          case "b":
                            n10[2] = "vt" + (r11.f ? "f" : "c"), n10[3] = "nl", n10[4] = r11.v ? "1" : "0", n10[5] = e10(r11.f || (r11.v ? "TRUE" : "FALSE"));
                            break;
                          case "d":
                            var f2 = tu(tv(r11.v));
                            n10[2] = "vtc", n10[3] = "nd", n10[4] = "" + f2, n10[5] = r11.w || e22(r11.z || eD[14], f2);
                            break;
                          case "n":
                            isFinite(r11.v) ? r11.f ? (n10[2] = "vtf", n10[3] = "n", n10[4] = r11.v, n10[5] = e10(r11.f)) : (n10[2] = "v", n10[3] = r11.v) : (n10[2] = "vt" + (r11.f ? "f" : "c"), n10[3] = "e" + aQ[isNaN(r11.v) ? 36 : 7], n10[4] = "0", n10[5] = r11.f || n10[3].slice(1), n10[6] = "e", n10[7] = n10[3].slice(1));
                            break;
                          case "e":
                            continue;
                        }
                        a10.push(n10.join(":"));
                      }
                  return a10.push("sheet:c:" + (i10.e.c - i10.s.c + 1) + ":r:" + (i10.e.r - i10.s.r + 1) + ":tvf:1"), a10.push("valueformat:1:text-wiki"), a10.join("\n");
                })(t11),
                "--SocialCalcSpreadsheetControlSave--"
              ].join("\n");
            }
          };
        })(), sS = /* @__PURE__ */ (function() {
          function e10(e11, t11, r11, a10, n11) {
            n11.raw ? t11[r11][a10] = e11 : "" === e11 || ("TRUE" === e11 ? t11[r11][a10] = true : "FALSE" === e11 ? t11[r11][a10] = false : isNaN(ty(e11)) ? isNaN(tA(e11).getDate()) ? 35 == e11.charCodeAt(0) && null != a0[e11] ? t11[r11][a10] = { t: "e", v: a0[e11], w: e11 } : t11[r11][a10] = e11 : t11[r11][a10] = tv(e11) : t11[r11][a10] = ty(e11));
          }
          var t10 = { 44: ",", 9: "	", 59: ";", 124: "|" }, r10 = { 44: 3, 9: 2, 59: 1, 124: 0 };
          function n10(e11) {
            for (var a10 = {}, n11 = false, s11 = 0, i10 = 0; s11 < e11.length; ++s11)
              34 == (i10 = e11.charCodeAt(s11)) ? n11 = !n11 : !n11 && i10 in t10 && (a10[i10] = (a10[i10] || 0) + 1);
            for (s11 in i10 = [], a10) Object.prototype.hasOwnProperty.call(a10, s11) && i10.push([a10[s11], s11]);
            if (!i10.length) for (s11 in a10 = r10) Object.prototype.hasOwnProperty.call(a10, s11) && i10.push([a10[s11], s11]);
            return i10.sort(function(e12, t11) {
              return e12[0] - t11[0] || r10[e12[1]] - r10[t11[1]];
            }), t10[i10.pop()[1]] || 44;
          }
          function s10(t11, r11) {
            var s11, i10 = "", o10 = "string" == r11.type ? [0, 0, 0, 0] : cH(t11, r11);
            switch (r11.type) {
              case "base64":
                i10 = ed(t11);
                break;
              case "binary":
              case "string":
                i10 = t11;
                break;
              case "buffer":
                i10 = 65001 == r11.codepage ? t11.toString("utf8") : r11.codepage && void 0 !== G ? G.utils.decode(r11.codepage, t11) : ep && a.isBuffer(t11) ? t11.toString("binary") : ey(t11);
                break;
              case "array":
                i10 = tb(t11);
                break;
              default:
                throw Error("Unrecognized type " + r11.type);
            }
            return (239 == o10[0] && 187 == o10[1] && 191 == o10[2] ? i10 = rf(i10.slice(3)) : "string" != r11.type && "buffer" != r11.type && 65001 == r11.codepage ? i10 = rf(i10) : "binary" == r11.type && void 0 !== G && r11.codepage && (i10 = G.utils.decode(r11.codepage, G.utils.encode(28591, i10))), "socialcalc:version:" == i10.slice(0, 19)) ? s_.to_sheet("string" == r11.type ? i10 : rf(i10), r11) : (s11 = i10, !(r11 && r11.PRN) || r11.FS || "sep=" == s11.slice(0, 4) || s11.indexOf("	") >= 0 || s11.indexOf(",") >= 0 || s11.indexOf(";") >= 0 ? (function(e11, t12) {
              var r12, a10, s12 = t12 || {}, i11 = "", o11 = {};
              s12.dense && (o11["!data"] = []);
              var c10 = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } };
              "sep=" == e11.slice(0, 4) ? 13 == e11.charCodeAt(5) && 10 == e11.charCodeAt(6) ? (i11 = e11.charAt(4), e11 = e11.slice(7)) : 13 == e11.charCodeAt(5) || 10 == e11.charCodeAt(5) ? (i11 = e11.charAt(4), e11 = e11.slice(6)) : i11 = n10(e11.slice(0, 1024)) : i11 = s12 && s12.FS ? s12.FS : n10(e11.slice(0, 1024));
              var l2 = 0, f2 = 0, h2 = 0, u2 = 0, d2 = 0, p2 = i11.charCodeAt(0), m2 = false, g2 = 0, v2 = e11.charCodeAt(0), b2 = null != s12.dateNF ? (a10 = (a10 = "number" == typeof (r12 = s12.dateNF) ? eD[r12] : r12).replace(e7, "(\\d+)"), e7.lastIndex = 0, RegExp("^" + a10 + "$")) : null;
              function w2() {
                var t13, r13, a11, n11, i12, m3, w3, T2, y2, E2, k2 = e11.slice(u2, d2);
                "\r" == k2.slice(-1) && (k2 = k2.slice(0, -1));
                var x2 = {};
                if ('"' == k2.charAt(0) && '"' == k2.charAt(k2.length - 1) && (k2 = k2.slice(1, -1).replace(/""/g, '"')), false !== s12.cellText && (x2.w = k2), 0 === k2.length)
                  x2.t = "z";
                else if (s12.raw) x2.t = "s", x2.v = k2;
                else if (0 === k2.trim().length) x2.t = "s", x2.v = k2;
                else if (61 == k2.charCodeAt(0))
                  34 == k2.charCodeAt(1) && 34 == k2.charCodeAt(k2.length - 1) ? (x2.t = "s", x2.v = k2.slice(2, -1).replace(/""/g, '"')) : (1 != k2.length ? (x2.t = "s", x2.f = k2.slice(1)) : x2.t = "s", x2.v = k2);
                else
                  "TRUE" == k2 ? (x2.t = "b", x2.v = true) : "FALSE" == k2 ? (x2.t = "b", x2.v = false) : isNaN(h2 = ty(k2)) ? !isNaN((h2 = tA(k2)).getDate()) || b2 && k2.match(b2) ? ((x2.z = s12.dateNF || eD[14], b2 && k2.match(b2)) ? (h2 = tv(
                    (t13 = s12.dateNF, r13 = k2.match(b2) || [], a11 = -1, n11 = -1, i12 = -1, m3 = -1, w3 = -1, T2 = -1, (t13.match(e7) || []).forEach(function(e12, t14) {
                      var s13 = parseInt(r13[t14 + 1], 10);
                      switch (e12.toLowerCase().charAt(0)) {
                        case "y":
                          a11 = s13;
                          break;
                        case "d":
                          i12 = s13;
                          break;
                        case "h":
                          m3 = s13;
                          break;
                        case "s":
                          T2 = s13;
                          break;
                        case "m":
                          m3 >= 0 ? w3 = s13 : n11 = s13;
                      }
                    }), e7.lastIndex = 0, T2 >= 0 && -1 == w3 && n11 >= 0 && (w3 = n11, n11 = -1), 7 == (y2 = ("" + (a11 >= 0 ? a11 : (/* @__PURE__ */ new Date()).getFullYear())).slice(-4) + "-" + ("00" + (n11 >= 1 ? n11 : 1)).slice(-2) + "-" + ("00" + (i12 >= 1 ? i12 : 1)).slice(-2)).length && (y2 = "0" + y2), 8 == y2.length && (y2 = "20" + y2), E2 = ("00" + (m3 >= 0 ? m3 : 0)).slice(-2) + ":" + ("00" + (w3 >= 0 ? w3 : 0)).slice(-2) + ":" + ("00" + (T2 >= 0 ? T2 : 0)).slice(-2), -1 == m3 && -1 == w3 && -1 == T2 ? y2 : -1 == a11 && -1 == n11 && -1 == i12 ? E2 : y2 + "T" + E2)
                  ), s12 && false === s12.UTC && (h2 = tI(h2))) : s12 && false === s12.UTC ? h2 = tI(h2) : false !== s12.cellText && s12.dateNF && (x2.w = e22(x2.z, h2)), s12.cellDates ? (x2.t = "d", x2.v = h2) : (x2.t = "n", x2.v = tu(h2)), s12.cellNF || delete x2.z) : 35 == k2.charCodeAt(0) && null != a0[k2] ? (x2.t = "e", x2.w = k2, x2.v = a0[k2]) : (x2.t = "s", x2.v = k2) : (x2.t = "n", x2.v = h2);
                if ("z" == x2.t || (s12.dense ? (o11["!data"][l2] || (o11["!data"][l2] = []), o11["!data"][l2][f2] = x2) : o11[ab({ c: f2, r: l2 })] = x2), u2 = d2 + 1, v2 = e11.charCodeAt(u2), c10.e.c < f2 && (c10.e.c = f2), c10.e.r < l2 && (c10.e.r = l2), g2 == p2)
                  ++f2;
                else if (f2 = 0, ++l2, s12.sheetRows && s12.sheetRows <= l2) return true;
              }
              e: for (; d2 < e11.length; ++d2)
                switch (g2 = e11.charCodeAt(d2)) {
                  case 34:
                    34 === v2 && (m2 = !m2);
                    break;
                  case 13:
                    if (m2) break;
                    10 == e11.charCodeAt(d2 + 1) && ++d2;
                  case p2:
                  case 10:
                    if (!m2 && w2()) break e;
                }
              return d2 - u2 > 0 && w2(), o11["!ref"] = aT(c10), o11;
            })(s11, r11) : aC(
              (function(t12, r12) {
                var a10 = r12 || {}, n11 = [];
                if (!t12 || 0 === t12.length) return n11;
                for (var s12 = t12.split(/[\r\n]/), i11 = s12.length - 1; i11 >= 0 && 0 === s12[i11].length; ) --i11;
                for (var o11 = 10, c10 = 0, l2 = 0; l2 <= i11; ++l2)
                  -1 == (c10 = s12[l2].indexOf(" ")) ? c10 = s12[l2].length : c10++, o11 = Math.max(o11, c10);
                for (l2 = 0; l2 <= i11; ++l2) {
                  n11[l2] = [];
                  var f2 = 0;
                  for (e10(s12[l2].slice(0, o11).trim(), n11, l2, f2, a10), f2 = 1; f2 <= (s12[l2].length - o11) / 10 + 1; ++f2)
                    e10(s12[l2].slice(o11 + (f2 - 1) * 10, o11 + 10 * f2).trim(), n11, l2, f2, a10);
                }
                return a10.sheetRows && (n11 = n11.slice(0, a10.sheetRows)), n11;
              })(s11, r11),
              r11
            ));
          }
          return {
            to_workbook: function(e11, t11) {
              return aS(s10(e11, t11), t11);
            },
            to_sheet: s10,
            from_sheet: function(e11) {
              var t11 = [];
              if (!e11["!ref"]) return "";
              for (var r11, a10 = ak(e11["!ref"]), n11 = null != e11["!data"], s11 = a10.s.r; s11 <= a10.e.r; ++s11) {
                for (var i10 = [], o10 = a10.s.c; o10 <= a10.e.c; ++o10) {
                  var c10 = ab({ r: s11, c: o10 });
                  if (!(r11 = n11 ? (e11["!data"][s11] || [])[o10] : e11[c10]) || null == r11.v) {
                    i10.push("          ");
                    continue;
                  }
                  for (var l2 = (r11.w || (a_(r11), r11.w) || "").slice(0, 10); l2.length < 10; ) l2 += " ";
                  i10.push(l2 + (0 === o10 ? " " : ""));
                }
                t11.push(i10.join(""));
              }
              return t11.join("\n");
            }
          };
        })(), sA = /* @__PURE__ */ (function() {
          function e10(e11, t11, r11) {
            if (e11) {
              aa(e11, e11.l || 0);
              for (var a11 = r11.Enum || p2; e11.l < e11.length; ) {
                var n11 = e11.read_shift(2), s11 = a11[n11] || a11[65535], i11 = e11.read_shift(2), o11 = e11.l + i11, c11 = s11.f && s11.f(e11, i11, r11);
                if (e11.l = o11, t11(c11, s11, n11)) return;
              }
            }
          }
          var t10 = [
            "mmmm",
            "dd-mmm-yyyy",
            "dd-mmm",
            "mmm-yyyy",
            "@",
            "mm/dd",
            "hh:mm:ss AM/PM",
            "hh:mm AM/PM",
            "mm/dd/yyyy",
            "mm/dd",
            "hh:mm:ss",
            "hh:mm"
          ];
          function r10(r11, a11) {
            if (!r11) return r11;
            var n11 = a11 || {}, s11 = {}, i11 = "Sheet1", o11 = "", c11 = 0, l3 = {}, f3 = [], h3 = [], u3 = [];
            n11.dense && (u3 = s11["!data"] = []);
            var d3 = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, v2 = n11.sheetRows || 0, b2 = {};
            if (81 == r11[4] && 80 == r11[5] && 87 == r11[6])
              return (function(e11, t11) {
                aa(e11, 0);
                var r12 = t11 || {}, a12 = {};
                r12.dense && (a12["!data"] = []);
                var n12 = [], s12 = "", i12 = { s: { r: -1, c: -1 }, e: { r: -1, c: -1 } }, o12 = 0, c12 = 0, l4 = 0, f4 = 0, h4 = { SheetNames: [], Sheets: {} }, u4 = [];
                e: for (; e11.l < e11.length; ) {
                  var d4 = e11.read_shift(2), p3 = e11.read_shift(2), m3 = e11.slice(e11.l, e11.l + p3);
                  switch (aa(m3, 0), d4) {
                    case 1:
                      if (962023505 != m3.read_shift(4)) throw "Bad QPW9 BOF!";
                      break;
                    case 2:
                      break e;
                    case 8:
                    case 1025:
                    case 1026:
                    case 1032:
                      break;
                    case 10:
                      for (var v3 = m3.read_shift(4), b3 = (m3.length - m3.l) / v3 | 0, w3 = 0; w3 < v3; ++w3) {
                        var T3 = m3.l + b3, y3 = {};
                        m3.l += 2, y3.numFmtId = m3.read_shift(2), g2[y3.numFmtId] && (y3.z = g2[y3.numFmtId]), m3.l = T3, u4.push(y3);
                      }
                      break;
                    case 1031:
                      for (m3.l += 12; m3.l < m3.length; )
                        o12 = m3.read_shift(2), c12 = m3.read_shift(1), n12.push(m3.read_shift(o12, "cstr"));
                      break;
                    case 1537:
                      var E2 = m3.read_shift(2);
                      a12 = {}, r12.dense && (a12["!data"] = []), i12.s.c = m3.read_shift(2), i12.e.c = m3.read_shift(2), i12.s.r = m3.read_shift(4), i12.e.r = m3.read_shift(4), m3.l += 4, m3.l + 2 < m3.length && (o12 = m3.read_shift(2), c12 = m3.read_shift(1), s12 = 0 == o12 ? "" : m3.read_shift(o12, "cstr")), s12 || (s12 = ag(E2));
                      break;
                    case 1538:
                      if (i12.s.c > 255 || i12.s.r > 999999) break;
                      i12.e.c < i12.s.c && (i12.e.c = i12.s.c), i12.e.r < i12.s.r && (i12.e.r = i12.s.r), a12["!ref"] = aT(i12), le(h4, a12, s12);
                      break;
                    case 2561:
                      l4 = m3.read_shift(2), i12.e.c < l4 && (i12.e.c = l4), i12.s.c > l4 && (i12.s.c = l4), f4 = m3.read_shift(4), i12.s.r > f4 && (i12.s.r = f4), f4 = m3.read_shift(4), i12.e.r < f4 && (i12.e.r = f4);
                      break;
                    case 3073:
                      f4 = m3.read_shift(4), o12 = m3.read_shift(4), i12.s.r > f4 && (i12.s.r = f4), i12.e.r < f4 + o12 - 1 && (i12.e.r = f4 + o12 - 1);
                      for (var k2 = ag(l4); m3.l < m3.length; ) {
                        var x2 = { t: "z" }, _2 = m3.read_shift(1), S2 = -1;
                        128 & _2 && (S2 = m3.read_shift(2));
                        var A2 = 64 & _2 ? m3.read_shift(2) - 1 : 0;
                        switch (31 & _2) {
                          case 0:
                          case 1:
                            break;
                          case 2:
                            x2 = { t: "n", v: m3.read_shift(2) };
                            break;
                          case 3:
                            x2 = { t: "n", v: m3.read_shift(2, "i") };
                            break;
                          case 4:
                            x2 = { t: "n", v: aB(m3) };
                            break;
                          case 5:
                            x2 = { t: "n", v: m3.read_shift(8, "f") };
                            break;
                          case 7:
                            x2 = { t: "s", v: n12[c12 = m3.read_shift(4) - 1] };
                            break;
                          case 8:
                            x2 = { t: "n", v: m3.read_shift(8, "f") }, m3.l += 2, m3.l += 4, isNaN(x2.v) && (x2 = { t: "e", v: 15 });
                            break;
                          default:
                            throw "Unrecognized QPW cell type " + (31 & _2);
                        }
                        -1 != S2 && (u4[S2 - 1] || {}).z && (x2.z = u4[S2 - 1].z);
                        var C2 = 0;
                        if (32 & _2)
                          switch (31 & _2) {
                            case 2:
                            case 7:
                              C2 = m3.read_shift(2);
                              break;
                            case 3:
                              C2 = m3.read_shift(2, "i");
                              break;
                            default:
                              throw "Unsupported delta for QPW cell type " + (31 & _2);
                          }
                        if (!(!r12.sheetStubs && "z" == x2.t)) {
                          var I2 = tw(x2);
                          "n" == x2.t && x2.z && eQ(x2.z) && r12.cellDates && (I2.v = td(x2.v), I2.t = "number" == typeof I2.v ? "n" : "d"), null != a12["!data"] ? (a12["!data"][f4] || (a12["!data"][f4] = []), a12["!data"][f4][l4] = I2) : a12[k2 + ap(f4)] = I2;
                        }
                        for (++f4, --o12; A2-- > 0 && o12 >= 0; ) {
                          if (32 & _2)
                            switch (31 & _2) {
                              case 2:
                                x2 = { t: "n", v: x2.v + C2 & 65535 };
                                break;
                              case 3:
                                (x2 = { t: "n", v: x2.v + C2 & 65535 }).v > 32767 && (x2.v -= 65536);
                                break;
                              case 7:
                                x2 = { t: "s", v: n12[c12 = c12 + C2 >>> 0] };
                                break;
                              default:
                                throw "Cannot apply delta for QPW cell type " + (31 & _2);
                            }
                          else
                            switch (31 & _2) {
                              case 1:
                                x2 = { t: "z" };
                                break;
                              case 2:
                                x2 = { t: "n", v: m3.read_shift(2) };
                                break;
                              case 7:
                                x2 = { t: "s", v: n12[c12 = m3.read_shift(4) - 1] };
                                break;
                              default:
                                throw "Cannot apply repeat for QPW cell type " + (31 & _2);
                            }
                          (r12.sheetStubs || "z" != x2.t) && (null != a12["!data"] ? (a12["!data"][f4] || (a12["!data"][f4] = []), a12["!data"][f4][l4] = x2) : a12[k2 + ap(f4)] = x2), ++f4, --o12;
                        }
                      }
                      break;
                    case 3074:
                      l4 = m3.read_shift(2), f4 = m3.read_shift(4);
                      var O2 = (function(e12) {
                        var t12 = e12.read_shift(2), r13 = e12.read_shift(1);
                        if (0 != r13) throw "unsupported QPW string type " + r13.toString(16);
                        return e12.read_shift(t12, "sbcs-cont");
                      })(m3);
                      null != a12["!data"] ? (a12["!data"][f4] || (a12["!data"][f4] = []), a12["!data"][f4][l4] = { t: "s", v: O2 }) : a12[ag(l4) + ap(f4)] = { t: "s", v: O2 };
                  }
                  e11.l += p3;
                }
                return h4;
              })(r11, a11);
            if (0 == r11[2] && (8 == r11[3] || 9 == r11[3]) && r11.length >= 16 && 5 == r11[14] && 108 === r11[15])
              throw Error("Unsupported Works 3 for Mac file");
            if (2 == r11[2])
              n11.Enum = p2, e10(
                r11,
                function(e11, r12, a12) {
                  switch (a12) {
                    case 0:
                      n11.vers = e11, e11 >= 4096 && (n11.qpro = true);
                      break;
                    case 255:
                      n11.vers = e11, n11.works = true;
                      break;
                    case 6:
                      d3 = e11;
                      break;
                    case 204:
                      e11 && (o11 = e11);
                      break;
                    case 222:
                      o11 = e11;
                      break;
                    case 15:
                    case 51:
                      (!n11.qpro && !n11.works || 51 == a12) && 48 > e11[1].v.charCodeAt(0) && (e11[1].v = e11[1].v.slice(1)), (n11.works || n11.works2) && (e11[1].v = e11[1].v.replace(/\r\n/g, "\n"));
                    case 13:
                    case 14:
                    case 16:
                      (112 & e11[2]) == 112 && (15 & e11[2]) > 1 && (15 & e11[2]) < 15 && (e11[1].z = n11.dateNF || t10[(15 & e11[2]) - 1] || eD[14], n11.cellDates && (e11[1].v = td(e11[1].v), e11[1].t = "number" == typeof e11[1].v ? "n" : "d")), n11.qpro && e11[3] > c11 && (s11["!ref"] = aT(d3), l3[i11] = s11, f3.push(i11), s11 = {}, n11.dense && (u3 = s11["!data"] = []), d3 = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, c11 = e11[3], i11 = o11 || "Sheet" + (c11 + 1), o11 = "");
                      var h4 = n11.dense ? (u3[e11[0].r] || [])[e11[0].c] : s11[ab(e11[0])];
                      if (h4) {
                        h4.t = e11[1].t, h4.v = e11[1].v, null != e11[1].z && (h4.z = e11[1].z), null != e11[1].f && (h4.f = e11[1].f), b2 = h4;
                        break;
                      }
                      n11.dense ? (u3[e11[0].r] || (u3[e11[0].r] = []), u3[e11[0].r][e11[0].c] = e11[1]) : s11[ab(e11[0])] = e11[1], b2 = e11[1];
                      break;
                    case 21509:
                      n11.works2 = true;
                      break;
                    case 21506:
                      5281 == e11 && (b2.z = "hh:mm:ss", n11.cellDates && "n" == b2.t && (b2.v = td(b2.v), b2.t = "number" == typeof b2.v ? "n" : "d"));
                  }
                },
                n11
              );
            else if (26 == r11[2] || 14 == r11[2])
              n11.Enum = m2, 14 == r11[2] && (n11.qpro = true, r11.l = 0), e10(
                r11,
                function(e11, t11, r12) {
                  switch (r12) {
                    case 204:
                      i11 = e11;
                      break;
                    case 22:
                      48 > e11[1].v.charCodeAt(0) && (e11[1].v = e11[1].v.slice(1)), e11[1].v = e11[1].v.replace(/\x0F./g, function(e12) {
                        return String.fromCharCode(e12.charCodeAt(1) - 32);
                      }).replace(/\r\n/g, "\n");
                    case 23:
                    case 24:
                    case 25:
                    case 37:
                    case 39:
                    case 40:
                      if (e11[3] > c11 && (s11["!ref"] = aT(d3), l3[i11] = s11, f3.push(i11), s11 = {}, n11.dense && (u3 = s11["!data"] = []), d3 = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, i11 = "Sheet" + ((c11 = e11[3]) + 1)), v2 > 0 && e11[0].r >= v2)
                        break;
                      n11.dense ? (u3[e11[0].r] || (u3[e11[0].r] = []), u3[e11[0].r][e11[0].c] = e11[1]) : s11[ab(e11[0])] = e11[1], d3.e.c < e11[0].c && (d3.e.c = e11[0].c), d3.e.r < e11[0].r && (d3.e.r = e11[0].r);
                      break;
                    case 27:
                      e11[14e3] && (h3[e11[14e3][0]] = e11[14e3][1]);
                      break;
                    case 1537:
                      h3[e11[0]] = e11[1], e11[0] == c11 && (i11 = e11[1]);
                  }
                },
                n11
              );
            else throw Error("Unrecognized LOTUS BOF " + r11[2]);
            if (s11["!ref"] = aT(d3), l3[o11 || i11] = s11, f3.push(o11 || i11), !h3.length)
              return { SheetNames: f3, Sheets: l3 };
            for (var w2 = {}, T2 = [], y2 = 0; y2 < h3.length; ++y2)
              l3[f3[y2]] ? (T2.push(h3[y2] || f3[y2]), w2[h3[y2]] = l3[h3[y2]] || l3[f3[y2]]) : (T2.push(h3[y2]), w2[h3[y2]] = { "!ref": "A1" });
            return { SheetNames: T2, Sheets: w2 };
          }
          function a10(e11, t11, r11) {
            var a11 = [{ c: 0, r: 0 }, { t: "n", v: 0 }, 0, 0];
            return r11.qpro && 20768 != r11.vers ? (a11[0].c = e11.read_shift(1), a11[3] = e11.read_shift(1), a11[0].r = e11.read_shift(2), e11.l += 2) : r11.works ? (a11[0].c = e11.read_shift(2), a11[0].r = e11.read_shift(2), a11[2] = e11.read_shift(2)) : (a11[2] = e11.read_shift(1), a11[0].c = e11.read_shift(2), a11[0].r = e11.read_shift(2)), a11;
          }
          function n10(e11) {
            return e11.z && eQ(e11.z) ? 240 | (t10.indexOf(e11.z) + 1 || 2) : 255;
          }
          function s10(e11, t11, r11) {
            var a11 = as(7);
            return a11.write_shift(1, n10(r11)), a11.write_shift(2, t11), a11.write_shift(2, e11), a11.write_shift(2, r11.v, "i"), a11;
          }
          function i10(e11, t11, r11) {
            var a11 = as(13);
            return a11.write_shift(1, n10(r11)), a11.write_shift(2, t11), a11.write_shift(2, e11), a11.write_shift(8, r11.v, "f"), a11;
          }
          function o10(e11, t11, r11) {
            var a11 = 32768 & t11;
            return t11 &= -32769, t11 = (a11 ? e11 : 0) + (t11 >= 8192 ? t11 - 16384 : t11), (a11 ? "" : "$") + (r11 ? ag(t11) : ap(t11));
          }
          var c10 = {
            31: ["NA", 0],
            33: ["ABS", 1],
            34: ["TRUNC", 1],
            35: ["SQRT", 1],
            36: ["LOG", 1],
            37: ["LN", 1],
            38: ["PI", 0],
            39: ["SIN", 1],
            40: ["COS", 1],
            41: ["TAN", 1],
            42: ["ATAN2", 2],
            43: ["ATAN", 1],
            44: ["ASIN", 1],
            45: ["ACOS", 1],
            46: ["EXP", 1],
            47: ["MOD", 2],
            49: ["ISNA", 1],
            50: ["ISERR", 1],
            51: ["FALSE", 0],
            52: ["TRUE", 0],
            53: ["RAND", 0],
            54: ["DATE", 3],
            63: ["ROUND", 2],
            64: ["TIME", 3],
            68: ["ISNUMBER", 1],
            69: ["ISTEXT", 1],
            70: ["LEN", 1],
            71: ["VALUE", 1],
            73: ["MID", 3],
            74: ["CHAR", 1],
            80: ["SUM", 69],
            81: ["AVERAGEA", 69],
            82: ["COUNTA", 69],
            83: ["MINA", 69],
            84: ["MAXA", 69],
            102: ["UPPER", 1],
            103: ["LOWER", 1],
            107: ["PROPER", 1],
            109: ["TRIM", 1],
            111: ["T", 1]
          }, l2 = [
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "+",
            "-",
            "*",
            "/",
            "^",
            "=",
            "<>",
            "<=",
            ">=",
            "<",
            ">",
            "",
            "",
            "",
            "",
            "&",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
          ];
          function f2(e11) {
            var t11 = [{ c: 0, r: 0 }, { t: "n", v: 0 }, 0];
            return t11[0].r = e11.read_shift(2), t11[3] = e11[e11.l++], t11[0].c = e11[e11.l++], t11;
          }
          function h2(e11, t11) {
            var r11 = f2(e11, t11), a11 = e11.read_shift(4), n11 = e11.read_shift(4), s11 = e11.read_shift(2);
            if (65535 == s11)
              return 0 === a11 && 3221225472 === n11 ? (r11[1].t = "e", r11[1].v = 15) : 0 === a11 && 3489660928 === n11 ? (r11[1].t = "e", r11[1].v = 42) : r11[1].v = 0, r11;
            var i11 = 32768 & s11;
            return s11 = (32767 & s11) - 16446, r11[1].v = (1 - 2 * i11) * (n11 * Math.pow(2, s11 + 32) + a11 * Math.pow(2, s11)), r11;
          }
          function u2(e11, t11) {
            var r11 = f2(e11, t11), a11 = e11.read_shift(8, "f");
            return r11[1].v = a11, r11;
          }
          function d2(e11, t11) {
            return 0 == e11[e11.l + t11 - 1] ? e11.read_shift(t11, "cstr") : "";
          }
          var p2 = {
            0: { n: "BOF", f: nX },
            1: { n: "EOF" },
            2: { n: "CALCMODE" },
            3: { n: "CALCORDER" },
            4: { n: "SPLIT" },
            5: { n: "SYNC" },
            6: {
              n: "RANGE",
              f: function(e11, t11, r11) {
                var a11 = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } };
                return 8 == t11 && r11.qpro ? (a11.s.c = e11.read_shift(1), e11.l++, a11.s.r = e11.read_shift(2), a11.e.c = e11.read_shift(1), e11.l++, a11.e.r = e11.read_shift(2)) : (a11.s.c = e11.read_shift(2), a11.s.r = e11.read_shift(2), 12 == t11 && r11.qpro && (e11.l += 2), a11.e.c = e11.read_shift(2), a11.e.r = e11.read_shift(2), 12 == t11 && r11.qpro && (e11.l += 2), 65535 == a11.s.c && (a11.s.c = a11.e.c = a11.s.r = a11.e.r = 0)), a11;
              }
            },
            7: { n: "WINDOW1" },
            8: { n: "COLW1" },
            9: { n: "WINTWO" },
            10: { n: "COLW2" },
            11: { n: "NAME" },
            12: { n: "BLANK" },
            13: {
              n: "INTEGER",
              f: function(e11, t11, r11) {
                var n11 = a10(e11, t11, r11);
                return n11[1].v = e11.read_shift(2, "i"), n11;
              }
            },
            14: {
              n: "NUMBER",
              f: function(e11, t11, r11) {
                var n11 = a10(e11, t11, r11);
                return n11[1].v = e11.read_shift(8, "f"), n11;
              }
            },
            15: {
              n: "LABEL",
              f: function(e11, t11, r11) {
                var n11 = e11.l + t11, s11 = a10(e11, t11, r11);
                if (s11[1].t = "s", (65534 & r11.vers) == 20768) {
                  e11.l++;
                  var i11 = e11.read_shift(1);
                  return s11[1].v = e11.read_shift(i11, "utf8"), s11;
                }
                return r11.qpro && e11.l++, s11[1].v = e11.read_shift(n11 - e11.l, "cstr"), s11;
              }
            },
            16: {
              n: "FORMULA",
              f: function(e11, t11, r11) {
                var n11 = e11.l + t11, s11 = a10(e11, t11, r11);
                if (s11[1].v = e11.read_shift(8, "f"), r11.qpro) e11.l = n11;
                else {
                  var i11 = e11.read_shift(2);
                  (function(e12, t12) {
                    aa(e12, 0);
                    for (var r12 = [], a11 = 0, n12 = "", s12 = "", i12 = "", f3 = ""; e12.l < e12.length; ) {
                      var h3 = e12[e12.l++];
                      switch (h3) {
                        case 0:
                          r12.push(e12.read_shift(8, "f"));
                          break;
                        case 1:
                          s12 = o10(t12[0].c, e12.read_shift(2), true), n12 = o10(t12[0].r, e12.read_shift(2), false), r12.push(s12 + n12);
                          break;
                        case 2:
                          var u3 = o10(t12[0].c, e12.read_shift(2), true), d3 = o10(t12[0].r, e12.read_shift(2), false);
                          s12 = o10(t12[0].c, e12.read_shift(2), true), n12 = o10(t12[0].r, e12.read_shift(2), false), r12.push(u3 + d3 + ":" + s12 + n12);
                          break;
                        case 3:
                          if (e12.l < e12.length) return void console.error("WK1 premature formula end");
                          break;
                        case 4:
                          r12.push("(" + r12.pop() + ")");
                          break;
                        case 5:
                          r12.push(e12.read_shift(2));
                          break;
                        case 6:
                          for (var p3 = ""; h3 = e12[e12.l++]; ) p3 += String.fromCharCode(h3);
                          r12.push('"' + p3.replace(/"/g, '""') + '"');
                          break;
                        case 8:
                          r12.push("-" + r12.pop());
                          break;
                        case 23:
                          r12.push("+" + r12.pop());
                          break;
                        case 22:
                          r12.push("NOT(" + r12.pop() + ")");
                          break;
                        case 20:
                        case 21:
                          f3 = r12.pop(), i12 = r12.pop(), r12.push(["AND", "OR"][h3 - 20] + "(" + i12 + "," + f3 + ")");
                          break;
                        default:
                          if (h3 < 32 && l2[h3]) f3 = r12.pop(), i12 = r12.pop(), r12.push(i12 + l2[h3] + f3);
                          else if (c10[h3]) {
                            if (69 == (a11 = c10[h3][1]) && (a11 = e12[e12.l++]), a11 > r12.length)
                              return void console.error(
                                "WK1 bad formula parse 0x" + h3.toString(16) + ":|" + r12.join("|") + "|"
                              );
                            var m3 = r12.slice(-a11);
                            r12.length -= a11, r12.push(c10[h3][0] + "(" + m3.join(",") + ")");
                          } else if (h3 <= 7) return console.error("WK1 invalid opcode " + h3.toString(16));
                          else if (h3 <= 24) return console.error("WK1 unsupported op " + h3.toString(16));
                          else if (h3 <= 30) return console.error("WK1 invalid opcode " + h3.toString(16));
                          else if (h3 <= 115)
                            return console.error("WK1 unsupported function opcode " + h3.toString(16));
                          else return console.error("WK1 unrecognized opcode " + h3.toString(16));
                      }
                    }
                    1 == r12.length ? t12[1].f = "" + r12[0] : console.error("WK1 bad formula parse |" + r12.join("|") + "|");
                  })(e11.slice(e11.l, e11.l + i11), s11), e11.l += i11;
                }
                return s11;
              }
            },
            24: { n: "TABLE" },
            25: { n: "ORANGE" },
            26: { n: "PRANGE" },
            27: { n: "SRANGE" },
            28: { n: "FRANGE" },
            29: { n: "KRANGE1" },
            32: { n: "HRANGE" },
            35: { n: "KRANGE2" },
            36: { n: "PROTEC" },
            37: { n: "FOOTER" },
            38: { n: "HEADER" },
            39: { n: "SETUP" },
            40: { n: "MARGINS" },
            41: { n: "LABELFMT" },
            42: { n: "TITLES" },
            43: { n: "SHEETJS" },
            45: { n: "GRAPH" },
            46: { n: "NGRAPH" },
            47: { n: "CALCCOUNT" },
            48: { n: "UNFORMATTED" },
            49: { n: "CURSORW12" },
            50: { n: "WINDOW" },
            51: {
              n: "STRING",
              f: function(e11, t11, r11) {
                var n11 = e11.l + t11, s11 = a10(e11, t11, r11);
                if (s11[1].t = "s", 20768 == r11.vers) {
                  var i11 = e11.read_shift(1);
                  return s11[1].v = e11.read_shift(i11, "utf8"), s11;
                }
                return s11[1].v = e11.read_shift(n11 - e11.l, "cstr"), s11;
              }
            },
            55: { n: "PASSWORD" },
            56: { n: "LOCKED" },
            60: { n: "QUERY" },
            61: { n: "QUERYNAME" },
            62: { n: "PRINT" },
            63: { n: "PRINTNAME" },
            64: { n: "GRAPH2" },
            65: { n: "GRAPHNAME" },
            66: { n: "ZOOM" },
            67: { n: "SYMSPLIT" },
            68: { n: "NSROWS" },
            69: { n: "NSCOLS" },
            70: { n: "RULER" },
            71: { n: "NNAME" },
            72: { n: "ACOMM" },
            73: { n: "AMACRO" },
            74: { n: "PARSE" },
            102: { n: "PRANGES??" },
            103: { n: "RRANGES??" },
            104: { n: "FNAME??" },
            105: { n: "MRANGES??" },
            204: { n: "SHEETNAMECS", f: d2 },
            222: {
              n: "SHEETNAMELP",
              f: function(e11, t11) {
                var r11 = e11[e11.l++];
                r11 > t11 - 1 && (r11 = t11 - 1);
                for (var a11 = ""; a11.length < r11; ) a11 += String.fromCharCode(e11[e11.l++]);
                return a11;
              }
            },
            255: { n: "BOF", f: nX },
            21506: { n: "WKSNF", f: nX },
            65535: { n: "" }
          }, m2 = {
            0: { n: "BOF" },
            1: { n: "EOF" },
            2: { n: "PASSWORD" },
            3: { n: "CALCSET" },
            4: { n: "WINDOWSET" },
            5: { n: "SHEETCELLPTR" },
            6: { n: "SHEETLAYOUT" },
            7: { n: "COLUMNWIDTH" },
            8: { n: "HIDDENCOLUMN" },
            9: { n: "USERRANGE" },
            10: { n: "SYSTEMRANGE" },
            11: { n: "ZEROFORCE" },
            12: { n: "SORTKEYDIR" },
            13: { n: "FILESEAL" },
            14: { n: "DATAFILLNUMS" },
            15: { n: "PRINTMAIN" },
            16: { n: "PRINTSTRING" },
            17: { n: "GRAPHMAIN" },
            18: { n: "GRAPHSTRING" },
            19: { n: "??" },
            20: { n: "ERRCELL" },
            21: { n: "NACELL" },
            22: {
              n: "LABEL16",
              f: function(e11, t11) {
                var r11 = f2(e11, t11);
                return r11[1].t = "s", r11[1].v = e11.read_shift(t11 - 4, "cstr"), r11;
              }
            },
            23: { n: "NUMBER17", f: h2 },
            24: {
              n: "NUMBER18",
              f: function(e11, t11) {
                var r11 = f2(e11, t11);
                r11[1].v = e11.read_shift(2);
                var a11 = r11[1].v >> 1;
                if (1 & r11[1].v)
                  switch (7 & a11) {
                    case 0:
                      a11 = (a11 >> 3) * 5e3;
                      break;
                    case 1:
                      a11 = (a11 >> 3) * 500;
                      break;
                    case 2:
                      a11 = (a11 >> 3) / 20;
                      break;
                    case 3:
                      a11 = (a11 >> 3) / 200;
                      break;
                    case 4:
                      a11 = (a11 >> 3) / 2e3;
                      break;
                    case 5:
                      a11 = (a11 >> 3) / 2e4;
                      break;
                    case 6:
                      a11 = (a11 >> 3) / 16;
                      break;
                    case 7:
                      a11 = (a11 >> 3) / 64;
                  }
                return r11[1].v = a11, r11;
              }
            },
            25: {
              n: "FORMULA19",
              f: function(e11, t11) {
                var r11 = h2(e11, 14);
                return e11.l += t11 - 14, r11;
              }
            },
            26: { n: "FORMULA1A" },
            27: {
              n: "XFORMAT",
              f: function(e11, t11) {
                for (var r11 = {}, a11 = e11.l + t11; e11.l < a11; ) {
                  var n11 = e11.read_shift(2);
                  if (14e3 == n11) {
                    for (r11[n11] = [0, ""], r11[n11][0] = e11.read_shift(2); e11[e11.l]; )
                      r11[n11][1] += String.fromCharCode(e11[e11.l]), e11.l++;
                    e11.l++;
                  }
                }
                return r11;
              }
            },
            28: { n: "DTLABELMISC" },
            29: { n: "DTLABELCELL" },
            30: { n: "GRAPHWINDOW" },
            31: { n: "CPA" },
            32: { n: "LPLAUTO" },
            33: { n: "QUERY" },
            34: { n: "HIDDENSHEET" },
            35: { n: "??" },
            37: {
              n: "NUMBER25",
              f: function(e11, t11) {
                var r11 = f2(e11, t11), a11 = e11.read_shift(4);
                return r11[1].v = a11 >> 6, r11;
              }
            },
            38: { n: "??" },
            39: { n: "NUMBER27", f: u2 },
            40: {
              n: "FORMULA28",
              f: function(e11, t11) {
                var r11 = u2(e11, 12);
                return e11.l += t11 - 12, r11;
              }
            },
            142: { n: "??" },
            147: { n: "??" },
            150: { n: "??" },
            151: { n: "??" },
            152: { n: "??" },
            153: { n: "??" },
            154: { n: "??" },
            155: { n: "??" },
            156: { n: "??" },
            163: { n: "??" },
            174: { n: "??" },
            175: { n: "??" },
            176: { n: "??" },
            177: { n: "??" },
            184: { n: "??" },
            185: { n: "??" },
            186: { n: "??" },
            187: { n: "??" },
            188: { n: "??" },
            195: { n: "??" },
            201: { n: "??" },
            204: { n: "SHEETNAMECS", f: d2 },
            205: { n: "??" },
            206: { n: "??" },
            207: { n: "??" },
            208: { n: "??" },
            256: { n: "??" },
            259: { n: "??" },
            260: { n: "??" },
            261: { n: "??" },
            262: { n: "??" },
            263: { n: "??" },
            265: { n: "??" },
            266: { n: "??" },
            267: { n: "??" },
            268: { n: "??" },
            270: { n: "??" },
            271: { n: "??" },
            384: { n: "??" },
            389: { n: "??" },
            390: { n: "??" },
            393: { n: "??" },
            396: { n: "??" },
            512: { n: "??" },
            514: { n: "??" },
            513: { n: "??" },
            516: { n: "??" },
            517: { n: "??" },
            640: { n: "??" },
            641: { n: "??" },
            642: { n: "??" },
            643: { n: "??" },
            644: { n: "??" },
            645: { n: "??" },
            646: { n: "??" },
            647: { n: "??" },
            648: { n: "??" },
            658: { n: "??" },
            659: { n: "??" },
            660: { n: "??" },
            661: { n: "??" },
            662: { n: "??" },
            665: { n: "??" },
            666: { n: "??" },
            768: { n: "??" },
            772: { n: "??" },
            1537: {
              n: "SHEETINFOQP",
              f: function(e11, t11, r11) {
                if (r11.qpro && !(t11 < 21)) {
                  var a11 = e11.read_shift(1);
                  return e11.l += 17, e11.l += 1, e11.l += 2, [a11, e11.read_shift(t11 - 21, "cstr")];
                }
              }
            },
            1600: { n: "??" },
            1602: { n: "??" },
            1793: { n: "??" },
            1794: { n: "??" },
            1795: { n: "??" },
            1796: { n: "??" },
            1920: { n: "??" },
            2048: { n: "??" },
            2049: { n: "??" },
            2052: { n: "??" },
            2688: { n: "??" },
            10998: { n: "??" },
            12849: { n: "??" },
            28233: { n: "??" },
            28484: { n: "??" },
            65535: { n: "" }
          }, g2 = {
            5: "dd-mmm-yy",
            6: "dd-mmm",
            7: "mmm-yy",
            8: "mm/dd/yy",
            10: "hh:mm:ss AM/PM",
            11: "hh:mm AM/PM",
            14: "dd-mmm-yyyy",
            15: "mmm-yyyy",
            34: "0.00",
            50: "0.00;[Red]0.00",
            66: "0.00;(0.00)",
            82: "0.00;[Red](0.00)",
            162: '"$"#,##0.00;\\("$"#,##0.00\\)',
            288: "0%",
            304: "0E+00",
            320: "# ?/?"
          };
          return {
            sheet_to_wk1: function(e11, t11) {
              var r11, a11, n11, o11, c11 = t11 || {};
              if (+c11.codepage >= 0 && er(+c11.codepage), "string" == c11.type)
                throw Error("Cannot write WK1 to JS string");
              var l3 = ao();
              if (!e11["!ref"]) throw Error("Cannot export empty sheet to WK1");
              var f3 = ak(e11["!ref"]), h3 = null != e11["!data"], u3 = [];
              oV(l3, 0, (r11 = 1030, (a11 = as(2)).write_shift(2, 1030), a11)), oV(
                l3,
                6,
                (n11 = f3, (o11 = as(8)).write_shift(2, n11.s.c), o11.write_shift(2, n11.s.r), o11.write_shift(2, n11.e.c), o11.write_shift(2, n11.e.r), o11)
              );
              for (var d3 = Math.min(f3.e.r, 8191), p3 = f3.s.c; p3 <= f3.e.c; ++p3) u3[p3] = ag(p3);
              for (var m3 = f3.s.r; m3 <= d3; ++m3) {
                var g3 = ap(m3);
                for (p3 = f3.s.c; p3 <= f3.e.c; ++p3) {
                  var v2 = h3 ? (e11["!data"][m3] || [])[p3] : e11[u3[p3] + g3];
                  if (v2 && "z" != v2.t)
                    switch (v2.t) {
                      case "n":
                        (0 | v2.v) == v2.v && v2.v >= -32768 && v2.v <= 32767 ? oV(l3, 13, s10(m3, p3, v2)) : oV(l3, 14, i10(m3, p3, v2));
                        break;
                      case "d":
                        var b2 = tu(v2.v);
                        (0 | b2) == b2 && b2 >= -32768 && b2 <= 32767 ? oV(l3, 13, s10(m3, p3, { t: "n", v: b2, z: v2.z || eD[14] })) : oV(l3, 14, i10(m3, p3, { t: "n", v: b2, z: v2.z || eD[14] }));
                        break;
                      default:
                        oV(
                          l3,
                          15,
                          (function(e12, t12, r12) {
                            var a12 = as(7 + r12.length);
                            a12.write_shift(1, 255), a12.write_shift(2, t12), a12.write_shift(2, e12), a12.write_shift(1, 39);
                            for (var n12 = 0; n12 < a12.length; ++n12) {
                              var s11 = r12.charCodeAt(n12);
                              a12.write_shift(1, s11 >= 128 ? 95 : s11);
                            }
                            return a12.write_shift(1, 0), a12;
                          })(m3, p3, a_(v2).slice(0, 239))
                        );
                    }
                }
              }
              return oV(l3, 1), l3.end();
            },
            book_to_wk3: function(e11, t11) {
              var r11 = t11 || {};
              if (+r11.codepage >= 0 && er(+r11.codepage), "string" == r11.type)
                throw Error("Cannot write WK3 to JS string");
              var a11 = ao();
              oV(
                a11,
                0,
                (function(e12) {
                  var t12 = as(26);
                  t12.write_shift(2, 4096), t12.write_shift(2, 4), t12.write_shift(4, 0);
                  for (var r12 = 0, a12 = 0, n12 = 0, s12 = 0; s12 < e12.SheetNames.length; ++s12) {
                    var i12 = e12.SheetNames[s12], o12 = e12.Sheets[i12];
                    if (o12 && o12["!ref"]) {
                      ++n12;
                      var c12 = aw(o12["!ref"]);
                      r12 < c12.e.r && (r12 = c12.e.r), a12 < c12.e.c && (a12 = c12.e.c);
                    }
                  }
                  return r12 > 8191 && (r12 = 8191), t12.write_shift(2, r12), t12.write_shift(1, n12), t12.write_shift(1, a12), t12.write_shift(2, 0), t12.write_shift(2, 0), t12.write_shift(1, 1), t12.write_shift(1, 2), t12.write_shift(4, 0), t12.write_shift(4, 0), t12;
                })(e11)
              );
              for (var n11 = 0, s11 = 0; n11 < e11.SheetNames.length; ++n11)
                (e11.Sheets[e11.SheetNames[n11]] || {})["!ref"] && oV(
                  a11,
                  27,
                  (function(e12, t12) {
                    var r12 = as(5 + e12.length);
                    r12.write_shift(2, 14e3), r12.write_shift(2, t12);
                    for (var a12 = 0; a12 < e12.length; ++a12) {
                      var n12 = e12.charCodeAt(a12);
                      r12[r12.l++] = n12 > 127 ? 95 : n12;
                    }
                    return r12[r12.l++] = 0, r12;
                  })(e11.SheetNames[n11], s11++)
                );
              var i11 = 0;
              for (n11 = 0; n11 < e11.SheetNames.length; ++n11) {
                var o11 = e11.Sheets[e11.SheetNames[n11]];
                if (o11 && o11["!ref"]) {
                  for (var c11 = ak(o11["!ref"]), l3 = null != o11["!data"], f3 = [], h3 = Math.min(c11.e.r, 8191), u3 = c11.s.r; u3 <= h3; ++u3)
                    for (var d3 = ap(u3), p3 = c11.s.c; p3 <= c11.e.c; ++p3) {
                      u3 === c11.s.r && (f3[p3] = ag(p3));
                      var m3 = f3[p3] + d3, g3 = l3 ? (o11["!data"][u3] || [])[p3] : o11[m3];
                      g3 && "z" != g3.t && ("n" == g3.t ? oV(
                        a11,
                        23,
                        (function(e12, t12, r12, a12) {
                          var n12 = as(14);
                          if (n12.write_shift(2, e12), n12.write_shift(1, r12), n12.write_shift(1, t12), 0 == a12)
                            return n12.write_shift(4, 0), n12.write_shift(4, 0), n12.write_shift(2, 65535), n12;
                          var s12 = 0, i12 = 0, o12 = 0, c12 = 0;
                          return a12 < 0 && (s12 = 1, a12 = -a12), i12 = 0 | Math.log2(a12), a12 /= Math.pow(2, i12 - 31), (2147483648 & (c12 = a12 >>> 0)) == 0 && (a12 /= 2, ++i12, c12 = a12 >>> 0), a12 -= c12, c12 |= 2147483648, c12 >>>= 0, a12 *= 4294967296, o12 = a12 >>> 0, n12.write_shift(4, o12), n12.write_shift(4, c12), i12 += 16383 + 32768 * !!s12, n12.write_shift(2, i12), n12;
                        })(u3, p3, i11, g3.v)
                      ) : oV(
                        a11,
                        22,
                        (function(e12, t12, r12, a12) {
                          var n12 = as(6 + a12.length);
                          n12.write_shift(2, e12), n12.write_shift(1, r12), n12.write_shift(1, t12), n12.write_shift(1, 39);
                          for (var s12 = 0; s12 < a12.length; ++s12) {
                            var i12 = a12.charCodeAt(s12);
                            n12.write_shift(1, i12 >= 128 ? 95 : i12);
                          }
                          return n12.write_shift(1, 0), n12;
                        })(u3, p3, i11, a_(g3).slice(0, 239))
                      ));
                    }
                  ++i11;
                }
              }
              return oV(a11, 1), a11.end();
            },
            to_workbook: function(e11, t11) {
              switch (t11.type) {
                case "base64":
                  return r10(ew(ed(e11)), t11);
                case "binary":
                  return r10(ew(e11), t11);
                case "buffer":
                case "array":
                  return r10(e11, t11);
              }
              throw "Unsupported type " + t11.type;
            }
          };
        })(), sC = /* @__PURE__ */ (function() {
          function e10(e11) {
            var t11 = tL(e11, "t");
            if (!t11) return { t: "s", v: "" };
            var r11 = { t: "s", v: t8(t11[1]) }, a10 = tL(e11, "rPr");
            return a10 && (r11.s = (function(e12) {
              var t12 = {}, r12 = e12.match(t0), a11 = 0, n10 = false;
              if (r12)
                for (; a11 != r12.length; ++a11) {
                  var s10 = t4(r12[a11]);
                  switch (s10[0].replace(/<\w*:/g, "<")) {
                    case "<condense":
                    case "<extend":
                      break;
                    case "<shadow":
                      if (!s10.val) break;
                    case "<shadow>":
                    case "<shadow/>":
                      t12.shadow = 1;
                      break;
                    case "</shadow>":
                      break;
                    case "<charset":
                      if ("1" == s10.val) break;
                      t12.cp = ee[parseInt(s10.val, 10)];
                      break;
                    case "<outline":
                      if (!s10.val) break;
                    case "<outline>":
                    case "<outline/>":
                      t12.outline = 1;
                      break;
                    case "</outline>":
                      break;
                    case "<rFont":
                      t12.name = s10.val;
                      break;
                    case "<sz":
                      t12.sz = s10.val;
                      break;
                    case "<strike":
                      if (!s10.val) break;
                    case "<strike>":
                    case "<strike/>":
                      t12.strike = 1;
                      break;
                    case "</strike>":
                      break;
                    case "<u":
                      if (!s10.val) break;
                      switch (s10.val) {
                        case "double":
                          t12.uval = "double";
                          break;
                        case "singleAccounting":
                          t12.uval = "single-accounting";
                          break;
                        case "doubleAccounting":
                          t12.uval = "double-accounting";
                      }
                    case "<u>":
                    case "<u/>":
                      t12.u = 1;
                      break;
                    case "</u>":
                      break;
                    case "<b":
                      if ("0" == s10.val) break;
                    case "<b>":
                    case "<b/>":
                      t12.b = 1;
                      break;
                    case "</b>":
                      break;
                    case "<i":
                      if ("0" == s10.val) break;
                    case "<i>":
                    case "<i/>":
                      t12.i = 1;
                      break;
                    case "</i>":
                    case "<color>":
                    case "<color/>":
                    case "</color>":
                    case "<family>":
                    case "<family/>":
                    case "</family>":
                    case "<vertAlign>":
                    case "<vertAlign/>":
                    case "</vertAlign>":
                    case "<scheme":
                    case "<scheme>":
                    case "<scheme/>":
                    case "</scheme>":
                    case "<extLst":
                    case "<extLst>":
                    case "</extLst>":
                      break;
                    case "<color":
                      s10.rgb && (t12.color = s10.rgb.slice(2, 8));
                      break;
                    case "<family":
                      t12.family = s10.val;
                      break;
                    case "<vertAlign":
                      t12.valign = s10.val;
                      break;
                    case "<ext":
                      n10 = true;
                      break;
                    case "</ext>":
                      n10 = false;
                      break;
                    default:
                      if (47 !== s10[0].charCodeAt(1) && !n10) throw Error("Unrecognized rich format " + s10[0]);
                  }
                }
              return t12;
            })(a10[1])), r11;
          }
          var t10 = /<(?:\w+:)?r>/g, r10 = /<\/(?:\w+:)?r>/;
          return function(a10) {
            return a10.replace(t10, "").split(r10).map(e10).filter(function(e11) {
              return e11.v;
            });
          };
        })(), sI = /* @__PURE__ */ (function() {
          var e10 = /(\r\n|\n)/g;
          function t10(t11) {
            var r10, a10, n10, s10, i10, o10 = [[], t11.v, []];
            return t11.v ? (t11.s && (r10 = t11.s, a10 = o10[0], n10 = o10[2], s10 = [], r10.u && s10.push("text-decoration: underline;"), r10.uval && s10.push("text-underline-style:" + r10.uval + ";"), r10.sz && s10.push("font-size:" + r10.sz + "pt;"), r10.outline && s10.push("text-effect: outline;"), r10.shadow && s10.push("text-shadow: auto;"), a10.push('<span style="' + s10.join("") + '">'), r10.b && (a10.push("<b>"), n10.push("</b>")), r10.i && (a10.push("<i>"), n10.push("</i>")), r10.strike && (a10.push("<s>"), n10.push("</s>")), "superscript" == (i10 = r10.valign || "") || "super" == i10 ? i10 = "sup" : "subscript" == i10 && (i10 = "sub"), "" != i10 && (a10.push("<" + i10 + ">"), n10.push("</" + i10 + ">")), n10.push("</span>")), o10[0].join("") + o10[1].replace(e10, "<br/>") + o10[2].join("")) : "";
          }
          return function(e11) {
            return e11.map(t10).join("");
          };
        })(), sO = /<(?:\w+:)?t\b[^<>]*>([^<]*)<\/(?:\w+:)?t>/g, sR = /<(?:\w+:)?r\b[^<>]*>/;
        function sN(e10, t10) {
          var r10 = !t10 || t10.cellHTML, a10 = {};
          return e10 ? (e10.match(/^\s*<(?:\w+:)?t[^>]*>/) ? (a10.t = t8(rf(e10.slice(e10.indexOf(">") + 1).split(/<\/(?:\w+:)?t>/)[0] || ""), true), a10.r = rf(e10), r10 && (a10.h = ra(a10.t))) : e10.match(sR) && (a10.r = rf(e10), a10.t = t8(rf((tU(e10, "rPh").match(sO) || []).join("").replace(t0, "")), true), r10 && (a10.h = sI(sC(a10.r)))), a10) : { t: "" };
        }
        var sF = /<(?:\w+:)?(?:si|sstItem)>/g, sD = /<\/(?:\w+:)?(?:si|sstItem)>/, sP = /^\s|\s$|[\t\n\r]/, sL = function(e10, t10) {
          var r10 = false;
          return null == t10 && (r10 = true, t10 = as(15 + 4 * e10.t.length)), t10.write_shift(1, 0), aR(e10.t, t10), r10 ? t10.slice(0, t10.l) : t10;
        };
        function sM(e10) {
          if (void 0 !== G) return G.utils.encode(q, e10);
          for (var t10 = [], r10 = e10.split(""), a10 = 0; a10 < r10.length; ++a10) t10[a10] = r10[a10].charCodeAt(0);
          return t10;
        }
        function sU(e10, t10) {
          var r10 = {};
          return r10.Major = e10.read_shift(2), r10.Minor = e10.read_shift(2), t10 >= 4 && (e10.l += t10 - 4), r10;
        }
        function sB(e10, t10) {
          var r10 = e10.l + t10, a10 = {};
          a10.Flags = 63 & e10.read_shift(4), e10.l += 4, a10.AlgID = e10.read_shift(4);
          var n10 = false;
          switch (a10.AlgID) {
            case 26126:
            case 26127:
            case 26128:
              n10 = 36 == a10.Flags;
              break;
            case 26625:
              n10 = 4 == a10.Flags;
              break;
            case 0:
              n10 = 16 == a10.Flags || 4 == a10.Flags || 36 == a10.Flags;
              break;
            default:
              throw "Unrecognized encryption algorithm: " + a10.AlgID;
          }
          if (!n10) throw Error("Encryption Flags/AlgID mismatch");
          return a10.AlgIDHash = e10.read_shift(4), a10.KeySize = e10.read_shift(4), a10.ProviderType = e10.read_shift(4), e10.l += 8, a10.CSPName = e10.read_shift(r10 - e10.l >> 1, "utf16le"), e10.l = r10, a10;
        }
        function sW(e10, t10) {
          var r10 = {}, a10 = e10.l + t10;
          return e10.l += 4, r10.Salt = e10.slice(e10.l, e10.l + 16), e10.l += 16, r10.Verifier = e10.slice(e10.l, e10.l + 16), e10.l += 16, e10.read_shift(4), r10.VerifierHash = e10.slice(e10.l, a10), e10.l = a10, r10;
        }
        function sz(e10) {
          var t10, r10, a10 = 0, n10 = sM(e10), s10 = n10.length + 1;
          for (r10 = 1, (t10 = ev(s10))[0] = n10.length; r10 != s10; ++r10) t10[r10] = n10[r10 - 1];
          for (r10 = s10 - 1; r10 >= 0; --r10) a10 = ((16384 & a10) != 0 | a10 << 1 & 32767) ^ t10[r10];
          return 52811 ^ a10;
        }
        var sH = (O = [187, 255, 255, 186, 255, 255, 185, 128, 0, 190, 15, 0, 191, 15, 0], R = [
          57840,
          7439,
          52380,
          33984,
          4364,
          3600,
          61902,
          12606,
          6258,
          57657,
          54287,
          34041,
          10252,
          43370,
          20163
        ], N = [
          44796,
          19929,
          39858,
          10053,
          20106,
          40212,
          10761,
          31585,
          63170,
          64933,
          60267,
          50935,
          40399,
          11199,
          17763,
          35526,
          1453,
          2906,
          5812,
          11624,
          23248,
          885,
          1770,
          3540,
          7080,
          14160,
          28320,
          56640,
          55369,
          41139,
          20807,
          41614,
          21821,
          43642,
          17621,
          28485,
          56970,
          44341,
          19019,
          38038,
          14605,
          29210,
          60195,
          50791,
          40175,
          10751,
          21502,
          43004,
          24537,
          18387,
          36774,
          3949,
          7898,
          15796,
          31592,
          63184,
          47201,
          24803,
          49606,
          37805,
          14203,
          28406,
          56812,
          17824,
          35648,
          1697,
          3394,
          6788,
          13576,
          27152,
          43601,
          17539,
          35078,
          557,
          1114,
          2228,
          4456,
          30388,
          60776,
          51953,
          34243,
          7079,
          14158,
          28316,
          14128,
          28256,
          56512,
          43425,
          17251,
          34502,
          7597,
          13105,
          26210,
          52420,
          35241,
          883,
          1766,
          3532,
          4129,
          8258,
          16516,
          33032,
          4657,
          9314,
          18628
        ], F = function(e10, t10) {
          var r10;
          return ((r10 = e10 ^ t10) / 2 | 128 * r10) & 255;
        }, D = function(e10) {
          for (var t10 = R[e10.length - 1], r10 = 104, a10 = e10.length - 1; a10 >= 0; --a10)
            for (var n10 = e10[a10], s10 = 0; 7 != s10; ++s10) 64 & n10 && (t10 ^= N[r10]), n10 *= 2, --r10;
          return t10;
        }, function(e10) {
          for (var t10, r10, a10, n10 = sM(e10), s10 = D(n10), i10 = n10.length, o10 = ev(16), c10 = 0; 16 != c10; ++c10) o10[c10] = 0;
          for ((1 & i10) == 1 && (t10 = s10 >> 8, o10[i10] = F(O[0], t10), --i10, t10 = 255 & s10, r10 = n10[n10.length - 1], o10[i10] = F(r10, t10)); i10 > 0; )
            --i10, t10 = s10 >> 8, o10[i10] = F(n10[i10], t10), --i10, t10 = 255 & s10, o10[i10] = F(n10[i10], t10);
          for (i10 = 15, a10 = 15 - n10.length; a10 > 0; )
            t10 = s10 >> 8, o10[i10] = F(O[a10], t10), --i10, --a10, t10 = 255 & s10, o10[i10] = F(n10[i10], t10), --i10, --a10;
          return o10;
        }), sV = function(e10, t10, r10, a10, n10) {
          var s10, i10;
          for (n10 || (n10 = t10), a10 || (a10 = sH(e10)), s10 = 0; s10 != t10.length; ++s10)
            i10 = ((i10 = t10[s10] ^ a10[r10]) >> 5 | i10 << 3) & 255, n10[s10] = i10, ++r10;
          return [n10, r10, a10];
        }, s$ = function(e10) {
          var t10 = 0, r10 = sH(e10);
          return function(e11) {
            var a10 = sV("", e11, t10, r10);
            return t10 = a10[1], a10[0];
          };
        };
        function sG(e10, t10) {
          var r10 = t10 || {}, a10 = {}, n10 = r10.dense;
          n10 && (a10["!data"] = []);
          var s10 = tN(e10, "\\trowd", "\\row");
          if (!s10) throw Error("RTF missing table");
          var i10 = { s: { c: 0, r: 0 }, e: { c: 0, r: s10.length - 1 } }, o10 = [];
          return s10.forEach(function(e11, t11) {
            n10 && (o10 = a10["!data"][t11] = []);
            for (var s11, c10 = /\\[\w\-]+\b/g, l2 = 0, f2 = -1, h2 = []; null != (s11 = c10.exec(e11)); ) {
              var u2 = e11.slice(l2, c10.lastIndex - s11[0].length);
              switch (32 == u2.charCodeAt(0) && (u2 = u2.slice(1)), u2.length && h2.push(u2), s11[0]) {
                case "\\cell":
                  if (++f2, h2.length) {
                    var d2 = { v: h2.join(""), t: "s" };
                    "TRUE" == d2.v || "FALSE" == d2.v ? (d2.v = "TRUE" == d2.v, d2.t = "b") : isNaN(ty(d2.v)) ? null != a0[d2.v] && (d2.t = "e", d2.w = d2.v, d2.v = a0[d2.v]) : (d2.t = "n", false !== r10.cellText && (d2.w = d2.v), d2.v = ty(d2.v)), n10 ? o10[f2] = d2 : a10[ab({ r: t11, c: f2 })] = d2;
                  }
                  h2 = [];
                  break;
                case "\\par":
                  h2.push("\n");
              }
              l2 = c10.lastIndex;
            }
            f2 > i10.e.c && (i10.e.c = f2);
          }), a10["!ref"] = aT(i10), a10;
        }
        function sX(e10) {
          for (var t10 = 0, r10 = 1; 3 != t10; ++t10) r10 = 256 * r10 + (e10[t10] > 255 ? 255 : e10[t10] < 0 ? 0 : e10[t10]);
          return r10.toString(16).toUpperCase().slice(1);
        }
        function sj(e10, t10) {
          if (0 === t10) return e10;
          var r10, a10 = (function(e11) {
            var t11 = e11[0] / 255, r11 = e11[1] / 255, a11 = e11[2] / 255, n10 = Math.max(t11, r11, a11), s10 = Math.min(t11, r11, a11), i10 = n10 - s10;
            if (0 === i10) return [0, 0, t11];
            var o10 = 0, c10 = 0, l2 = n10 + s10;
            switch (c10 = i10 / (l2 > 1 ? 2 - l2 : l2), n10) {
              case t11:
                o10 = ((r11 - a11) / i10 + 6) % 6;
                break;
              case r11:
                o10 = (a11 - t11) / i10 + 2;
                break;
              case a11:
                o10 = (t11 - r11) / i10 + 4;
            }
            return [o10 / 6, c10, l2 / 2];
          })([
            parseInt((r10 = e10.slice(+("#" === e10[0])).slice(0, 6)).slice(0, 2), 16),
            parseInt(r10.slice(2, 4), 16),
            parseInt(r10.slice(4, 6), 16)
          ]);
          return t10 < 0 ? a10[2] = a10[2] * (1 + t10) : a10[2] = 1 - (1 - a10[2]) * (1 - t10), sX(
            (function(e11) {
              var t11, r11 = e11[0], a11 = e11[1], n10 = e11[2], s10 = 2 * a11 * (n10 < 0.5 ? n10 : 1 - n10), i10 = n10 - s10 / 2, o10 = [i10, i10, i10], c10 = 6 * r11;
              if (0 !== a11)
                switch (0 | c10) {
                  case 0:
                  case 6:
                    t11 = s10 * c10, o10[0] += s10, o10[1] += t11;
                    break;
                  case 1:
                    t11 = s10 * (2 - c10), o10[0] += t11, o10[1] += s10;
                    break;
                  case 2:
                    t11 = s10 * (c10 - 2), o10[1] += s10, o10[2] += t11;
                    break;
                  case 3:
                    t11 = s10 * (4 - c10), o10[1] += t11, o10[2] += s10;
                    break;
                  case 4:
                    t11 = s10 * (c10 - 4), o10[2] += s10, o10[0] += t11;
                    break;
                  case 5:
                    t11 = s10 * (6 - c10), o10[2] += t11, o10[0] += s10;
                }
              for (var l2 = 0; 3 != l2; ++l2) o10[l2] = Math.round(255 * o10[l2]);
              return o10;
            })(a10)
          );
        }
        var sK = 6;
        function sY(e10) {
          return Math.floor((e10 + Math.round(128 / sK) / 256) * sK);
        }
        function sZ(e10) {
          return Math.floor((e10 - 5) / sK * 100 + 0.5) / 100;
        }
        function sJ(e10) {
          return Math.round((e10 * sK + 5) / sK * 256) / 256;
        }
        function sq(e10) {
          return sJ(sZ(sY(e10)));
        }
        function sQ(e10) {
          var t10 = Math.abs(e10 - sq(e10)), r10 = sK;
          if (t10 > 5e-3)
            for (sK = 1; sK < 15; ++sK) Math.abs(e10 - sq(e10)) <= t10 && (t10 = Math.abs(e10 - sq(e10)), r10 = sK);
          sK = r10;
        }
        function s0(e10) {
          e10.width ? (e10.wpx = sY(e10.width), e10.wch = sZ(e10.wpx), e10.MDW = sK) : e10.wpx ? (e10.wch = sZ(e10.wpx), e10.width = sJ(e10.wch), e10.MDW = sK) : "number" == typeof e10.wch && (e10.width = sJ(e10.wch), e10.wpx = sY(e10.width), e10.MDW = sK), e10.customWidth && delete e10.customWidth;
        }
        function s1(e10) {
          return 96 * e10 / 96;
        }
        function s2(e10) {
          return 96 * e10 / 96;
        }
        var s4 = {
          None: "none",
          Solid: "solid",
          Gray50: "mediumGray",
          Gray75: "darkGray",
          Gray25: "lightGray",
          HorzStripe: "darkHorizontal",
          VertStripe: "darkVertical",
          ReverseDiagStripe: "darkDown",
          DiagStripe: "darkUp",
          DiagCross: "darkGrid",
          ThickDiagCross: "darkTrellis",
          ThinHorzStripe: "lightHorizontal",
          ThinVertStripe: "lightVertical",
          ThinReverseDiagStripe: "lightDown",
          ThinHorzCross: "lightGrid"
        }, s3 = ["numFmtId", "fillId", "fontId", "borderId", "xfId"], s5 = [
          "applyAlignment",
          "applyBorder",
          "applyFill",
          "applyFont",
          "applyNumberFormat",
          "applyProtection",
          "pivotButton",
          "quotePrefix"
        ], s6 = function(e10, t10, r10) {
          var a10, n10, s10, i10, o10, c10, l2, f2, h2, u2, d2, p2, m2, g2 = {};
          return e10 ? ((m2 = tL(e10 = tR(tF(e10, "<!--", "-->")), "numFmts")) && (function(e11, t11, r11) {
            t11.NumberFmt = [];
            for (var a11 = ts(eD), n11 = 0; n11 < a11.length; ++n11) t11.NumberFmt[a11[n11]] = eD[a11[n11]];
            var s11 = e11.match(t0);
            if (s11)
              for (n11 = 0; n11 < s11.length; ++n11) {
                var i11 = t4(s11[n11]);
                switch (t3(i11[0])) {
                  case "<numFmts":
                  case "</numFmts>":
                  case "<numFmts/>":
                  case "<numFmts>":
                  case "</numFmt>":
                    break;
                  case "<numFmt":
                    var o11 = t8(rf(i11.formatCode)), c11 = parseInt(i11.numFmtId, 10);
                    if (t11.NumberFmt[c11] = o11, c11 > 0) {
                      if (c11 > 392) {
                        for (c11 = 392; c11 > 60 && null != t11.NumberFmt[c11]; --c11) ;
                        t11.NumberFmt[c11] = o11;
                      }
                      te(o11, c11);
                    }
                    break;
                  default:
                    if (r11.WTF) throw Error("unrecognized " + i11[0] + " in numFmts");
                }
              }
          })(m2[0], g2, r10), (m2 = tL(e10, "fonts")) && (a10 = m2[0], g2.Fonts = [], n10 = {}, s10 = false, (a10.match(t0) || []).forEach(function(e11) {
            var a11 = t4(e11);
            switch (t3(a11[0])) {
              case "<fonts":
              case "<fonts>":
              case "</fonts>":
              case "<font":
              case "<font>":
              case "<name/>":
              case "</name>":
              case "</b>":
              case "</b":
              case "</i>":
              case "</i":
              case "</u>":
              case "</u":
              case "</strike>":
              case "</strike":
              case "</outline>":
              case "</outline":
              case "</shadow>":
              case "</shadow":
              case "</condense>":
              case "</condense":
              case "</extend>":
              case "</extend":
              case "<sz/>":
              case "</sz>":
              case "</sz":
              case "<vertAlign/>":
              case "</vertAlign>":
              case "</vertAlign":
              case "<family/>":
              case "</family>":
              case "</family":
              case "<scheme/>":
              case "</scheme>":
              case "</scheme":
              case "<charset/>":
              case "</charset>":
              case "</charset":
              case "<color/>":
              case "</color>":
              case "</color":
              case "<extLst":
              case "<extLst>":
              case "</extLst>":
                break;
              case "</font>":
              case "<font/>":
                g2.Fonts.push(n10), n10 = {};
                break;
              case "<name":
                a11.val && (n10.name = rf(a11.val));
                break;
              case "<b":
                n10.bold = a11.val ? rs(a11.val) : 1;
                break;
              case "<b/>":
                n10.bold = 1;
                break;
              case "<i":
                n10.italic = a11.val ? rs(a11.val) : 1;
                break;
              case "<i/>":
                n10.italic = 1;
                break;
              case "<u":
                switch (a11.val) {
                  case "none":
                    n10.underline = 0;
                    break;
                  case "single":
                    n10.underline = 1;
                    break;
                  case "double":
                    n10.underline = 2;
                    break;
                  case "singleAccounting":
                    n10.underline = 33;
                    break;
                  case "doubleAccounting":
                    n10.underline = 34;
                }
                break;
              case "<u/>":
                n10.underline = 1;
                break;
              case "<strike":
                n10.strike = a11.val ? rs(a11.val) : 1;
                break;
              case "<strike/>":
                n10.strike = 1;
                break;
              case "<outline":
                n10.outline = a11.val ? rs(a11.val) : 1;
                break;
              case "<outline/>":
                n10.outline = 1;
                break;
              case "<shadow":
                n10.shadow = a11.val ? rs(a11.val) : 1;
                break;
              case "<shadow/>":
                n10.shadow = 1;
                break;
              case "<condense":
                n10.condense = a11.val ? rs(a11.val) : 1;
                break;
              case "<condense/>":
                n10.condense = 1;
                break;
              case "<extend":
                n10.extend = a11.val ? rs(a11.val) : 1;
                break;
              case "<extend/>":
                n10.extend = 1;
                break;
              case "<sz":
                a11.val && (n10.sz = +a11.val);
                break;
              case "<vertAlign":
                a11.val && (n10.vertAlign = a11.val);
                break;
              case "<family":
                a11.val && (n10.family = parseInt(a11.val, 10));
                break;
              case "<scheme":
                a11.val && (n10.scheme = a11.val);
                break;
              case "<charset":
                if ("1" == a11.val) break;
                a11.codepage = ee[parseInt(a11.val, 10)];
                break;
              case "<color":
                if (n10.color || (n10.color = {}), a11.auto && (n10.color.auto = rs(a11.auto)), a11.rgb)
                  n10.color.rgb = a11.rgb.slice(-6);
                else if (a11.indexed) {
                  n10.color.index = parseInt(a11.indexed, 10);
                  var i11 = aq[n10.color.index];
                  81 == n10.color.index && (i11 = aq[1]), i11 || (i11 = aq[1]), n10.color.rgb = i11[0].toString(16) + i11[1].toString(16) + i11[2].toString(16);
                } else
                  a11.theme && (n10.color.theme = parseInt(a11.theme, 10), a11.tint && (n10.color.tint = parseFloat(a11.tint)), a11.theme && t10.themeElements && t10.themeElements.clrScheme && (n10.color.rgb = sj(t10.themeElements.clrScheme[n10.color.theme].rgb, n10.color.tint || 0)));
                break;
              case "<AlternateContent":
              case "<ext":
                s10 = true;
                break;
              case "</AlternateContent>":
              case "</AlternateContent":
              case "</ext>":
                s10 = false;
                break;
              default:
                if (r10 && r10.WTF && !s10) throw Error("unrecognized " + a11[0] + " in fonts");
            }
          })), (m2 = tL(e10, "fills")) && (i10 = m2[0], g2.Fills = [], o10 = {}, c10 = false, (i10.match(t0) || []).forEach(function(e11) {
            var t11 = t4(e11);
            switch (t3(t11[0])) {
              case "<fills":
              case "<fills>":
              case "</fills>":
              case "</fill>":
              case "<gradientFill>":
              case "<patternFill/>":
              case "</patternFill>":
              case "<bgColor/>":
              case "</bgColor>":
              case "<fgColor/>":
              case "</fgColor>":
              case "<stop":
              case "<stop/>":
              case "</stop>":
              case "<color":
              case "<color/>":
              case "</color>":
              case "<extLst":
              case "<extLst>":
              case "</extLst>":
                break;
              case "<fill>":
              case "<fill":
              case "<fill/>":
                o10 = {}, g2.Fills.push(o10);
                break;
              case "<gradientFill":
              case "</gradientFill>":
                g2.Fills.push(o10), o10 = {};
                break;
              case "<patternFill":
              case "<patternFill>":
                t11.patternType && (o10.patternType = t11.patternType);
                break;
              case "<bgColor":
                o10.bgColor || (o10.bgColor = {}), t11.indexed && (o10.bgColor.indexed = parseInt(t11.indexed, 10)), t11.theme && (o10.bgColor.theme = parseInt(t11.theme, 10)), t11.tint && (o10.bgColor.tint = parseFloat(t11.tint)), t11.rgb && (o10.bgColor.rgb = t11.rgb.slice(-6));
                break;
              case "<fgColor":
                o10.fgColor || (o10.fgColor = {}), t11.theme && (o10.fgColor.theme = parseInt(t11.theme, 10)), t11.tint && (o10.fgColor.tint = parseFloat(t11.tint)), null != t11.rgb && (o10.fgColor.rgb = t11.rgb.slice(-6));
                break;
              case "<ext":
                c10 = true;
                break;
              case "</ext>":
                c10 = false;
                break;
              default:
                if (r10 && r10.WTF && !c10) throw Error("unrecognized " + t11[0] + " in fills");
            }
          })), (m2 = tL(e10, "borders")) && (l2 = m2[0], g2.Borders = [], f2 = {}, h2 = false, (l2.match(t0) || []).forEach(function(e11) {
            var t11 = t4(e11);
            switch (t3(t11[0])) {
              case "<borders":
              case "<borders>":
              case "</borders>":
              case "</border>":
              case "<left/>":
              case "<left":
              case "<left>":
              case "</left>":
              case "<right/>":
              case "<right":
              case "<right>":
              case "</right>":
              case "<top/>":
              case "<top":
              case "<top>":
              case "</top>":
              case "<bottom/>":
              case "<bottom":
              case "<bottom>":
              case "</bottom>":
              case "<diagonal":
              case "<diagonal>":
              case "<diagonal/>":
              case "</diagonal>":
              case "<horizontal":
              case "<horizontal>":
              case "<horizontal/>":
              case "</horizontal>":
              case "<vertical":
              case "<vertical>":
              case "<vertical/>":
              case "</vertical>":
              case "<start":
              case "<start>":
              case "<start/>":
              case "</start>":
              case "<end":
              case "<end>":
              case "<end/>":
              case "</end>":
              case "<color":
              case "<color>":
              case "<color/>":
              case "</color>":
              case "<extLst":
              case "<extLst>":
              case "</extLst>":
                break;
              case "<border":
              case "<border>":
              case "<border/>":
                f2 = {}, t11.diagonalUp && (f2.diagonalUp = rs(t11.diagonalUp)), t11.diagonalDown && (f2.diagonalDown = rs(t11.diagonalDown)), g2.Borders.push(f2);
                break;
              case "<ext":
                h2 = true;
                break;
              case "</ext>":
                h2 = false;
                break;
              default:
                if (r10 && r10.WTF && !h2) throw Error("unrecognized " + t11[0] + " in borders");
            }
          })), (m2 = tL(e10, "cellXfs")) && (u2 = m2[0], g2.CellXf = [], p2 = false, (u2.match(t0) || []).forEach(function(e11) {
            var t11 = t4(e11), a11 = 0;
            switch (t3(t11[0])) {
              case "<cellXfs":
              case "<cellXfs>":
              case "<cellXfs/>":
              case "</cellXfs>":
              case "</xf>":
              case "</alignment>":
              case "<protection":
              case "<protection>":
              case "</protection>":
              case "<protection/>":
              case "<extLst":
              case "<extLst>":
              case "</extLst>":
                break;
              case "<xf":
              case "<xf/>":
              case "<xf>":
                for (d2 = t11, delete d2[0], a11 = 0; a11 < s3.length; ++a11)
                  d2[s3[a11]] && (d2[s3[a11]] = parseInt(d2[s3[a11]], 10));
                for (a11 = 0; a11 < s5.length; ++a11) d2[s5[a11]] && (d2[s5[a11]] = rs(d2[s5[a11]]));
                if (g2.NumberFmt && d2.numFmtId > 392) {
                  for (a11 = 392; a11 > 60; --a11)
                    if (g2.NumberFmt[d2.numFmtId] == g2.NumberFmt[a11]) {
                      d2.numFmtId = a11;
                      break;
                    }
                }
                g2.CellXf.push(d2);
                break;
              case "<alignment":
              case "<alignment/>":
              case "<alignment>":
                var n11 = {};
                t11.vertical && (n11.vertical = t11.vertical), t11.horizontal && (n11.horizontal = t11.horizontal), null != t11.textRotation && (n11.textRotation = t11.textRotation), t11.indent && (n11.indent = t11.indent), t11.wrapText && (n11.wrapText = rs(t11.wrapText)), d2.alignment = n11;
                break;
              case "<AlternateContent":
              case "<AlternateContent>":
              case "<ext":
                p2 = true;
                break;
              case "</AlternateContent>":
              case "</ext>":
                p2 = false;
                break;
              default:
                if (r10 && r10.WTF && !p2) throw Error("unrecognized " + t11[0] + " in cellXfs");
            }
          })), g2) : g2;
        }, s8 = [
          "none",
          "solid",
          "mediumGray",
          "darkGray",
          "lightGray",
          "darkHorizontal",
          "darkVertical",
          "darkDown",
          "darkUp",
          "darkGrid",
          "darkTrellis",
          "lightHorizontal",
          "lightVertical",
          "lightDown",
          "lightUp",
          "lightGrid",
          "lightTrellis",
          "gray125",
          "gray0625"
        ];
        function s7(e10, t10) {
          t10 || (t10 = as(84)), K || (K = to(s8));
          var r10 = K[e10.patternType];
          null == r10 && (r10 = 40), t10.write_shift(4, r10);
          var a10 = 0;
          if (40 != r10) for (aG({ auto: 1 }, t10), aG({ auto: 1 }, t10); a10 < 12; ++a10) t10.write_shift(4, 0);
          else {
            for (; a10 < 4; ++a10) t10.write_shift(4, 0);
            for (; a10 < 12; ++a10) t10.write_shift(4, 0);
          }
          return t10.length > t10.l ? t10.slice(0, t10.l) : t10;
        }
        function s9(e10, t10, r10) {
          return r10 || (r10 = as(16)), r10.write_shift(2, t10 || 0), r10.write_shift(2, e10.numFmtId || 0), r10.write_shift(2, 0), r10.write_shift(2, 0), r10.write_shift(2, 0), r10.write_shift(1, 0), r10.write_shift(1, 0), r10.write_shift(1, 0), r10.write_shift(1, 0), r10.write_shift(1, 0), r10.write_shift(1, 0), r10;
        }
        function ie(e10, t10) {
          return t10 || (t10 = as(10)), t10.write_shift(1, 0), t10.write_shift(1, 0), t10.write_shift(4, 0), t10.write_shift(4, 0), t10;
        }
        var it = [
          "</a:lt1>",
          "</a:dk1>",
          "</a:lt2>",
          "</a:dk2>",
          "</a:accent1>",
          "</a:accent2>",
          "</a:accent3>",
          "</a:accent4>",
          "</a:accent5>",
          "</a:accent6>",
          "</a:hlink>",
          "</a:folHlink>"
        ];
        function ir(e10, t10) {
          e10 && 0 !== e10.length || (e10 = ia());
          var r10, a10 = {};
          if (!(r10 = tP(e10, "a:themeElements"))) throw Error("themeElements not found in theme");
          return !(function(e11, t11, r11) {
            var a11, n10, s10;
            if (t11.themeElements = {}, !(a11 = tP(e11, "a:clrScheme")))
              throw Error("clrScheme not found in themeElements");
            if (n10 = a11, t11.themeElements.clrScheme = [], s10 = {}, (n10[0].match(t0) || []).forEach(function(e12) {
              var a12 = t4(e12);
              switch (a12[0]) {
                case "<a:clrScheme":
                case "</a:clrScheme>":
                case "</a:srgbClr>":
                case "</a:sysClr>":
                  break;
                case "<a:srgbClr":
                  s10.rgb = a12.val;
                  break;
                case "<a:sysClr":
                  s10.rgb = a12.lastClr;
                  break;
                case "</a:dk1>":
                case "</a:lt1>":
                case "<a:dk1>":
                case "<a:lt1>":
                case "<a:dk2>":
                case "</a:dk2>":
                case "<a:lt2>":
                case "</a:lt2>":
                case "<a:accent1>":
                case "</a:accent1>":
                case "<a:accent2>":
                case "</a:accent2>":
                case "<a:accent3>":
                case "</a:accent3>":
                case "<a:accent4>":
                case "</a:accent4>":
                case "<a:accent5>":
                case "</a:accent5>":
                case "<a:accent6>":
                case "</a:accent6>":
                case "<a:hlink>":
                case "</a:hlink>":
                case "<a:folHlink>":
                case "</a:folHlink>":
                  "/" === a12[0].charAt(1) ? (t11.themeElements.clrScheme[it.indexOf(a12[0])] = s10, s10 = {}) : s10.name = a12[0].slice(3, a12[0].length - 1);
                  break;
                default:
                  if (r11 && r11.WTF) throw Error("Unrecognized " + a12[0] + " in clrScheme");
              }
            }), !(a11 = tP(e11, "a:fontScheme")))
              throw Error("fontScheme not found in themeElements");
            if (!(a11 = tP(e11, "a:fmtScheme"))) throw Error("fmtScheme not found in themeElements");
          })(r10[0], a10, t10), a10.raw = e10, a10;
        }
        function ia(e10, t10) {
          if (t10 && t10.themeXLSX) return t10.themeXLSX;
          if (e10 && "string" == typeof e10.raw) return e10.raw;
          var r10 = [tJ];
          return r10[r10.length] = '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme">', r10[r10.length] = "<a:themeElements>", r10[r10.length] = '<a:clrScheme name="Office">', r10[r10.length] = '<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1>', r10[r10.length] = '<a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>', r10[r10.length] = '<a:dk2><a:srgbClr val="1F497D"/></a:dk2>', r10[r10.length] = '<a:lt2><a:srgbClr val="EEECE1"/></a:lt2>', r10[r10.length] = '<a:accent1><a:srgbClr val="4F81BD"/></a:accent1>', r10[r10.length] = '<a:accent2><a:srgbClr val="C0504D"/></a:accent2>', r10[r10.length] = '<a:accent3><a:srgbClr val="9BBB59"/></a:accent3>', r10[r10.length] = '<a:accent4><a:srgbClr val="8064A2"/></a:accent4>', r10[r10.length] = '<a:accent5><a:srgbClr val="4BACC6"/></a:accent5>', r10[r10.length] = '<a:accent6><a:srgbClr val="F79646"/></a:accent6>', r10[r10.length] = '<a:hlink><a:srgbClr val="0000FF"/></a:hlink>', r10[r10.length] = '<a:folHlink><a:srgbClr val="800080"/></a:folHlink>', r10[r10.length] = "</a:clrScheme>", r10[r10.length] = '<a:fontScheme name="Office">', r10[r10.length] = "<a:majorFont>", r10[r10.length] = '<a:latin typeface="Cambria"/>', r10[r10.length] = '<a:ea typeface=""/>', r10[r10.length] = '<a:cs typeface=""/>', r10[r10.length] = '<a:font script="Jpan" typeface="ＭＳ Ｐゴシック"/>', r10[r10.length] = '<a:font script="Hang" typeface="맑은 고딕"/>', r10[r10.length] = '<a:font script="Hans" typeface="宋体"/>', r10[r10.length] = '<a:font script="Hant" typeface="新細明體"/>', r10[r10.length] = '<a:font script="Arab" typeface="Times New Roman"/>', r10[r10.length] = '<a:font script="Hebr" typeface="Times New Roman"/>', r10[r10.length] = '<a:font script="Thai" typeface="Tahoma"/>', r10[r10.length] = '<a:font script="Ethi" typeface="Nyala"/>', r10[r10.length] = '<a:font script="Beng" typeface="Vrinda"/>', r10[r10.length] = '<a:font script="Gujr" typeface="Shruti"/>', r10[r10.length] = '<a:font script="Khmr" typeface="MoolBoran"/>', r10[r10.length] = '<a:font script="Knda" typeface="Tunga"/>', r10[r10.length] = '<a:font script="Guru" typeface="Raavi"/>', r10[r10.length] = '<a:font script="Cans" typeface="Euphemia"/>', r10[r10.length] = '<a:font script="Cher" typeface="Plantagenet Cherokee"/>', r10[r10.length] = '<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>', r10[r10.length] = '<a:font script="Tibt" typeface="Microsoft Himalaya"/>', r10[r10.length] = '<a:font script="Thaa" typeface="MV Boli"/>', r10[r10.length] = '<a:font script="Deva" typeface="Mangal"/>', r10[r10.length] = '<a:font script="Telu" typeface="Gautami"/>', r10[r10.length] = '<a:font script="Taml" typeface="Latha"/>', r10[r10.length] = '<a:font script="Syrc" typeface="Estrangelo Edessa"/>', r10[r10.length] = '<a:font script="Orya" typeface="Kalinga"/>', r10[r10.length] = '<a:font script="Mlym" typeface="Kartika"/>', r10[r10.length] = '<a:font script="Laoo" typeface="DokChampa"/>', r10[r10.length] = '<a:font script="Sinh" typeface="Iskoola Pota"/>', r10[r10.length] = '<a:font script="Mong" typeface="Mongolian Baiti"/>', r10[r10.length] = '<a:font script="Viet" typeface="Times New Roman"/>', r10[r10.length] = '<a:font script="Uigh" typeface="Microsoft Uighur"/>', r10[r10.length] = '<a:font script="Geor" typeface="Sylfaen"/>', r10[r10.length] = "</a:majorFont>", r10[r10.length] = "<a:minorFont>", r10[r10.length] = '<a:latin typeface="Calibri"/>', r10[r10.length] = '<a:ea typeface=""/>', r10[r10.length] = '<a:cs typeface=""/>', r10[r10.length] = '<a:font script="Jpan" typeface="ＭＳ Ｐゴシック"/>', r10[r10.length] = '<a:font script="Hang" typeface="맑은 고딕"/>', r10[r10.length] = '<a:font script="Hans" typeface="宋体"/>', r10[r10.length] = '<a:font script="Hant" typeface="新細明體"/>', r10[r10.length] = '<a:font script="Arab" typeface="Arial"/>', r10[r10.length] = '<a:font script="Hebr" typeface="Arial"/>', r10[r10.length] = '<a:font script="Thai" typeface="Tahoma"/>', r10[r10.length] = '<a:font script="Ethi" typeface="Nyala"/>', r10[r10.length] = '<a:font script="Beng" typeface="Vrinda"/>', r10[r10.length] = '<a:font script="Gujr" typeface="Shruti"/>', r10[r10.length] = '<a:font script="Khmr" typeface="DaunPenh"/>', r10[r10.length] = '<a:font script="Knda" typeface="Tunga"/>', r10[r10.length] = '<a:font script="Guru" typeface="Raavi"/>', r10[r10.length] = '<a:font script="Cans" typeface="Euphemia"/>', r10[r10.length] = '<a:font script="Cher" typeface="Plantagenet Cherokee"/>', r10[r10.length] = '<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>', r10[r10.length] = '<a:font script="Tibt" typeface="Microsoft Himalaya"/>', r10[r10.length] = '<a:font script="Thaa" typeface="MV Boli"/>', r10[r10.length] = '<a:font script="Deva" typeface="Mangal"/>', r10[r10.length] = '<a:font script="Telu" typeface="Gautami"/>', r10[r10.length] = '<a:font script="Taml" typeface="Latha"/>', r10[r10.length] = '<a:font script="Syrc" typeface="Estrangelo Edessa"/>', r10[r10.length] = '<a:font script="Orya" typeface="Kalinga"/>', r10[r10.length] = '<a:font script="Mlym" typeface="Kartika"/>', r10[r10.length] = '<a:font script="Laoo" typeface="DokChampa"/>', r10[r10.length] = '<a:font script="Sinh" typeface="Iskoola Pota"/>', r10[r10.length] = '<a:font script="Mong" typeface="Mongolian Baiti"/>', r10[r10.length] = '<a:font script="Viet" typeface="Arial"/>', r10[r10.length] = '<a:font script="Uigh" typeface="Microsoft Uighur"/>', r10[r10.length] = '<a:font script="Geor" typeface="Sylfaen"/>', r10[r10.length] = "</a:minorFont>", r10[r10.length] = "</a:fontScheme>", r10[r10.length] = '<a:fmtScheme name="Office">', r10[r10.length] = "<a:fillStyleLst>", r10[r10.length] = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', r10[r10.length] = '<a:gradFill rotWithShape="1">', r10[r10.length] = "<a:gsLst>", r10[r10.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="50000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', r10[r10.length] = '<a:gs pos="35000"><a:schemeClr val="phClr"><a:tint val="37000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', r10[r10.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="15000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r10[r10.length] = "</a:gsLst>", r10[r10.length] = '<a:lin ang="16200000" scaled="1"/>', r10[r10.length] = "</a:gradFill>", r10[r10.length] = '<a:gradFill rotWithShape="1">', r10[r10.length] = "<a:gsLst>", r10[r10.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="100000"/><a:shade val="100000"/><a:satMod val="130000"/></a:schemeClr></a:gs>', r10[r10.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="50000"/><a:shade val="100000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r10[r10.length] = "</a:gsLst>", r10[r10.length] = '<a:lin ang="16200000" scaled="0"/>', r10[r10.length] = "</a:gradFill>", r10[r10.length] = "</a:fillStyleLst>", r10[r10.length] = "<a:lnStyleLst>", r10[r10.length] = '<a:ln w="9525" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"><a:shade val="95000"/><a:satMod val="105000"/></a:schemeClr></a:solidFill><a:prstDash val="solid"/></a:ln>', r10[r10.length] = '<a:ln w="25400" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>', r10[r10.length] = '<a:ln w="38100" cap="flat" cmpd="sng" algn="ctr"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>', r10[r10.length] = "</a:lnStyleLst>", r10[r10.length] = "<a:effectStyleLst>", r10[r10.length] = "<a:effectStyle>", r10[r10.length] = "<a:effectLst>", r10[r10.length] = '<a:outerShdw blurRad="40000" dist="20000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="38000"/></a:srgbClr></a:outerShdw>', r10[r10.length] = "</a:effectLst>", r10[r10.length] = "</a:effectStyle>", r10[r10.length] = "<a:effectStyle>", r10[r10.length] = "<a:effectLst>", r10[r10.length] = '<a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw>', r10[r10.length] = "</a:effectLst>", r10[r10.length] = "</a:effectStyle>", r10[r10.length] = "<a:effectStyle>", r10[r10.length] = "<a:effectLst>", r10[r10.length] = '<a:outerShdw blurRad="40000" dist="23000" dir="5400000" rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="35000"/></a:srgbClr></a:outerShdw>', r10[r10.length] = "</a:effectLst>", r10[r10.length] = '<a:scene3d><a:camera prst="orthographicFront"><a:rot lat="0" lon="0" rev="0"/></a:camera><a:lightRig rig="threePt" dir="t"><a:rot lat="0" lon="0" rev="1200000"/></a:lightRig></a:scene3d>', r10[r10.length] = '<a:sp3d><a:bevelT w="63500" h="25400"/></a:sp3d>', r10[r10.length] = "</a:effectStyle>", r10[r10.length] = "</a:effectStyleLst>", r10[r10.length] = "<a:bgFillStyleLst>", r10[r10.length] = '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', r10[r10.length] = '<a:gradFill rotWithShape="1">', r10[r10.length] = "<a:gsLst>", r10[r10.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="40000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r10[r10.length] = '<a:gs pos="40000"><a:schemeClr val="phClr"><a:tint val="45000"/><a:shade val="99000"/><a:satMod val="350000"/></a:schemeClr></a:gs>', r10[r10.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="20000"/><a:satMod val="255000"/></a:schemeClr></a:gs>', r10[r10.length] = "</a:gsLst>", r10[r10.length] = '<a:path path="circle"><a:fillToRect l="50000" t="-80000" r="50000" b="180000"/></a:path>', r10[r10.length] = "</a:gradFill>", r10[r10.length] = '<a:gradFill rotWithShape="1">', r10[r10.length] = "<a:gsLst>", r10[r10.length] = '<a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="80000"/><a:satMod val="300000"/></a:schemeClr></a:gs>', r10[r10.length] = '<a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="30000"/><a:satMod val="200000"/></a:schemeClr></a:gs>', r10[r10.length] = "</a:gsLst>", r10[r10.length] = '<a:path path="circle"><a:fillToRect l="50000" t="50000" r="50000" b="50000"/></a:path>', r10[r10.length] = "</a:gradFill>", r10[r10.length] = "</a:bgFillStyleLst>", r10[r10.length] = "</a:fmtScheme>", r10[r10.length] = "</a:themeElements>", r10[r10.length] = "<a:objectDefaults>", r10[r10.length] = "<a:spDef>", r10[r10.length] = '<a:spPr/><a:bodyPr/><a:lstStyle/><a:style><a:lnRef idx="1"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="3"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="2"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="lt1"/></a:fontRef></a:style>', r10[r10.length] = "</a:spDef>", r10[r10.length] = "<a:lnDef>", r10[r10.length] = '<a:spPr/><a:bodyPr/><a:lstStyle/><a:style><a:lnRef idx="2"><a:schemeClr val="accent1"/></a:lnRef><a:fillRef idx="0"><a:schemeClr val="accent1"/></a:fillRef><a:effectRef idx="1"><a:schemeClr val="accent1"/></a:effectRef><a:fontRef idx="minor"><a:schemeClr val="tx1"/></a:fontRef></a:style>', r10[r10.length] = "</a:lnDef>", r10[r10.length] = "</a:objectDefaults>", r10[r10.length] = "<a:extraClrSchemeLst/>", r10[r10.length] = "</a:theme>", r10.join("");
        }
        function is(e10, t10, r10) {
          var a10 = [21600, 21600], n10 = ["m0,0l0", a10[1], a10[0], a10[1], a10[0], "0xe"].join(","), s10 = [
            rw("xml", null, {
              "xmlns:v": "urn:schemas-microsoft-com:vml",
              "xmlns:o": rI,
              "xmlns:x": rO,
              "xmlns:mv": "http://macVmlSchemaUri"
            }).replace(/\/>/, ">"),
            rw("o:shapelayout", rw("o:idmap", null, { "v:ext": "edit", data: e10 }), { "v:ext": "edit" })
          ], i10 = 65536 * e10, o10 = t10 || [];
          return o10.length > 0 && s10.push(
            rw(
              "v:shapetype",
              [
                rw("v:stroke", null, { joinstyle: "miter" }),
                rw("v:path", null, { gradientshapeok: "t", "o:connecttype": "rect" })
              ].join(""),
              { id: "_x0000_t202", coordsize: a10.join(","), "o:spt": 202, path: n10 }
            )
          ), o10.forEach(function(e11) {
            var t11, r11, a11, n11, o11, c10;
            ++i10, s10.push(
              (t11 = e11, r11 = i10, a11 = av(t11[0]), "gradient" == (n11 = { color2: "#BEFF82", type: "gradient" }).type && (n11.angle = "-180"), o11 = "gradient" == n11.type ? rw("o:fill", null, { type: "gradientUnscaled", "v:ext": "view" }) : null, c10 = rw("v:fill", o11, n11), "<v:shape" + rb({
                id: "_x0000_s" + r11,
                type: "#_x0000_t202",
                style: "position:absolute; margin-left:80pt;margin-top:5pt;width:104pt;height:64pt;z-index:10" + (t11[1].hidden ? ";visibility:hidden" : ""),
                fillcolor: "#ECFAD4",
                strokecolor: "#edeaa1"
              }) + ">" + c10 + rw("v:shadow", null, { on: "t", obscured: "t" }) + rw("v:path", null, { "o:connecttype": "none" }) + '<v:textbox><div style="text-align:left"></div></v:textbox><x:ClientData ObjectType="Note"><x:MoveWithCells/><x:SizeWithCells/>' + rv("x:Anchor", [a11.c + 1, 0, a11.r + 1, 0, a11.c + 3, 20, a11.r + 5, 20].join(",")) + rv("x:AutoFill", "False") + rv("x:Row", String(a11.r)) + rv("x:Column", String(a11.c)) + (t11[1].hidden ? "" : "<x:Visible/>") + "</x:ClientData></v:shape>")
            );
          }), s10.push("</xml>"), s10.join("");
        }
        function ii(e10, t10, r10, a10) {
          var n10, s10 = null != e10["!data"];
          t10.forEach(function(t11) {
            var i10 = av(t11.ref);
            if (!(i10.r < 0) && !(i10.c < 0)) {
              if (s10 ? (e10["!data"][i10.r] || (e10["!data"][i10.r] = []), n10 = e10["!data"][i10.r][i10.c]) : n10 = e10[t11.ref], !n10) {
                n10 = { t: "z" }, s10 ? e10["!data"][i10.r][i10.c] = n10 : e10[t11.ref] = n10;
                var o10 = ak(e10["!ref"] || "BDWGO1000001:A1");
                o10.s.r > i10.r && (o10.s.r = i10.r), o10.e.r < i10.r && (o10.e.r = i10.r), o10.s.c > i10.c && (o10.s.c = i10.c), o10.e.c < i10.c && (o10.e.c = i10.c);
                var c10 = aT(o10);
                e10["!ref"] = c10;
              }
              n10.c || (n10.c = []);
              var l2 = { a: t11.author, t: t11.t, r: t11.r, T: r10 };
              t11.h && (l2.h = t11.h);
              for (var f2 = n10.c.length - 1; f2 >= 0; --f2) {
                if (!r10 && n10.c[f2].T) return;
                r10 && !n10.c[f2].T && n10.c.splice(f2, 1);
              }
              if (r10 && a10) {
                for (f2 = 0; f2 < a10.length; ++f2)
                  if (l2.a == a10[f2].id) {
                    l2.a = a10[f2].name || l2.a;
                    break;
                  }
              }
              n10.c.push(l2);
            }
          });
        }
        function io(e10, t10, r10) {
          var a10 = [tJ, rw("ThreadedComments", null, { xmlns: rx }).replace(/[\/]>/, ">")];
          return e10.forEach(function(e11) {
            var n10 = "";
            (e11[1] || []).forEach(function(s10, i10) {
              if (!s10.T) return void delete s10.ID;
              s10.a && -1 == t10.indexOf(s10.a) && t10.push(s10.a);
              var o10 = { ref: e11[0], id: "{54EE7951-7262-4200-6969-" + ("000000000000" + r10.tcid++).slice(-12) + "}" };
              0 == i10 ? n10 = o10.id : o10.parentId = n10, s10.ID = o10.id, s10.a && (o10.personId = "{54EE7950-7262-4200-6969-" + ("000000000000" + t10.indexOf(s10.a)).slice(-12) + "}"), a10.push(rw("threadedComment", rv("text", s10.t || ""), o10));
            });
          }), a10.push("</ThreadedComments>"), a10.join("");
        }
        function ic(e10) {
          var t10 = [tJ, rw("personList", null, { xmlns: rx, "xmlns:x": rC[0] }).replace(/[\/]>/, ">")];
          return e10.forEach(function(e11, r10) {
            t10.push(
              rw("person", null, {
                displayName: e11,
                id: "{54EE7950-7262-4200-6969-" + ("000000000000" + r10).slice(-12) + "}",
                userId: e11,
                providerId: "None"
              })
            );
          }), t10.push("</personList>"), t10.join("");
        }
        function il(e10) {
          return aR(e10.slice(0, 54));
        }
        var ih = ["xlsb", "xlsm", "xlam", "biff8", "xla"], iu = /* @__PURE__ */ (function() {
          var e10 = /(^|[^A-Za-z_])R(\[?-?\d+\]|[1-9]\d*|)C(\[?-?\d+\]|[1-9]\d*|)(?![A-Za-z0-9_])/g, t10 = { r: 0, c: 0 };
          function r10(e11, r11, a10, n10) {
            var s10 = false, i10 = false;
            0 == a10.length ? i10 = true : "[" == a10.charAt(0) && (i10 = true, a10 = a10.slice(1, -1)), 0 == n10.length ? s10 = true : "[" == n10.charAt(0) && (s10 = true, n10 = n10.slice(1, -1));
            var o10 = a10.length > 0 ? 0 | parseInt(a10, 10) : 0, c10 = n10.length > 0 ? 0 | parseInt(n10, 10) : 0;
            return s10 ? c10 += t10.c : --c10, i10 ? o10 += t10.r : --o10, r11 + (s10 ? "" : "$") + ag(c10) + (i10 ? "" : "$") + ap(o10);
          }
          return function(a10, n10) {
            return t10 = n10, a10.replace(e10, r10);
          };
        })(), id = /(^|[^._A-Z0-9])(\$?)([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])(\$?)(\d{1,7})(?![_.\(A-Za-z0-9])/g;
        try {
          id = /(^|[^._A-Z0-9])([$]?)([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])([$]?)(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})(?![_.\(A-Za-z0-9])/g;
        } catch (e10) {
        }
        var ip = function(e10, t10) {
          return e10.replace(id, function(e11, r10, a10, n10, s10, i10) {
            var o10 = am(n10) - (a10 ? 0 : t10.c), c10 = ad(i10) - (s10 ? 0 : t10.r);
            return r10 + "R" + ("$" == s10 ? c10 + 1 : 0 == c10 ? "" : "[" + c10 + "]") + "C" + ("$" == a10 ? o10 + 1 : 0 == o10 ? "" : "[" + o10 + "]");
          });
        };
        function im(e10, t10) {
          return e10.replace(id, function(e11, r10, a10, n10, s10, i10) {
            return r10 + ("$" == a10 ? a10 + n10 : ag(am(n10) + t10.c)) + ("$" == s10 ? s10 + i10 : ap(ad(i10) + t10.r));
          });
        }
        function ig(e10, t10, r10) {
          var a10 = aw(t10).s, n10 = av(r10);
          return im(e10, { r: n10.r - a10.r, c: n10.c - a10.c });
        }
        function iv(e10) {
          return e10.replace(/_xlfn\./g, "");
        }
        function ib(e10) {
          e10.l += 1;
        }
        function iw(e10, t10) {
          var r10 = e10.read_shift(1 == t10 ? 1 : 2);
          return [16383 & r10, r10 >> 14 & 1, r10 >> 15 & 1];
        }
        function iT(e10, t10, r10) {
          var a10 = 2;
          if (r10)
            if (r10.biff >= 2 && r10.biff <= 5) return iy(e10, t10, r10);
            else 12 == r10.biff && (a10 = 4);
          var n10 = e10.read_shift(a10), s10 = e10.read_shift(a10), i10 = iw(e10, 2), o10 = iw(e10, 2);
          return { s: { r: n10, c: i10[0], cRel: i10[1], rRel: i10[2] }, e: { r: s10, c: o10[0], cRel: o10[1], rRel: o10[2] } };
        }
        function iy(e10) {
          var t10 = iw(e10, 2), r10 = iw(e10, 2), a10 = e10.read_shift(1), n10 = e10.read_shift(1);
          return { s: { r: t10[0], c: a10, cRel: t10[1], rRel: t10[2] }, e: { r: r10[0], c: n10, cRel: r10[1], rRel: r10[2] } };
        }
        function iE(e10, t10, r10) {
          if (r10 && r10.biff >= 2 && r10.biff <= 5) {
            var a10, n10, s10;
            return n10 = iw(a10 = e10, 2), s10 = a10.read_shift(1), { r: n10[0], c: s10, cRel: n10[1], rRel: n10[2] };
          }
          var i10 = e10.read_shift(r10 && 12 == r10.biff ? 4 : 2), o10 = iw(e10, 2);
          return { r: i10, c: o10[0], cRel: o10[1], rRel: o10[2] };
        }
        function ik(e10) {
          var t10 = 1 & e10[e10.l + 1];
          return e10.l += 4, [t10, 1];
        }
        function ix(e10) {
          return [e10.read_shift(1), e10.read_shift(1)];
        }
        function i_(e10, t10, r10) {
          var a10;
          return e10.l += 2, [
            {
              r: e10.read_shift(2),
              c: 255 & (a10 = e10.read_shift(2)),
              fQuoted: !!(16384 & a10),
              cRel: a10 >> 15,
              rRel: a10 >> 15
            }
          ];
        }
        function iS(e10) {
          return e10.l += 6, [];
        }
        function iA(e10) {
          return e10.l += 2, [nX(e10), 1 & e10.read_shift(2)];
        }
        var iC = [
          "Data",
          "All",
          "Headers",
          "??",
          "?Data2",
          "??",
          "?DataHeaders",
          "??",
          "Totals",
          "??",
          "??",
          "??",
          "?DataTotals",
          "??",
          "??",
          "??",
          "?Current"
        ], iI = {
          1: {
            n: "PtgExp",
            f: function(e10, t10, r10) {
              return (e10.l++, r10 && 12 == r10.biff) ? [e10.read_shift(4, "i"), 0] : [e10.read_shift(2), e10.read_shift(r10 && 2 == r10.biff ? 1 : 2)];
            }
          },
          2: { n: "PtgTbl", f: an },
          3: { n: "PtgAdd", f: ib },
          4: { n: "PtgSub", f: ib },
          5: { n: "PtgMul", f: ib },
          6: { n: "PtgDiv", f: ib },
          7: { n: "PtgPower", f: ib },
          8: { n: "PtgConcat", f: ib },
          9: { n: "PtgLt", f: ib },
          10: { n: "PtgLe", f: ib },
          11: { n: "PtgEq", f: ib },
          12: { n: "PtgGe", f: ib },
          13: { n: "PtgGt", f: ib },
          14: { n: "PtgNe", f: ib },
          15: { n: "PtgIsect", f: ib },
          16: { n: "PtgUnion", f: ib },
          17: { n: "PtgRange", f: ib },
          18: { n: "PtgUplus", f: ib },
          19: { n: "PtgUminus", f: ib },
          20: { n: "PtgPercent", f: ib },
          21: { n: "PtgParen", f: ib },
          22: { n: "PtgMissArg", f: ib },
          23: {
            n: "PtgStr",
            f: function(e10, t10, r10) {
              return e10.l++, nJ(e10, t10 - 1, r10);
            }
          },
          26: {
            n: "PtgSheet",
            f: function(e10, t10, r10) {
              return e10.l += 5, e10.l += 2, e10.l += 2 == r10.biff ? 1 : 4, ["PTGSHEET"];
            }
          },
          27: {
            n: "PtgEndSheet",
            f: function(e10, t10, r10) {
              return e10.l += 2 == r10.biff ? 4 : 5, ["PTGENDSHEET"];
            }
          },
          28: {
            n: "PtgErr",
            f: function(e10) {
              return e10.l++, aQ[e10.read_shift(1)];
            }
          },
          29: {
            n: "PtgBool",
            f: function(e10) {
              return e10.l++, 0 !== e10.read_shift(1);
            }
          },
          30: {
            n: "PtgInt",
            f: function(e10) {
              return e10.l++, e10.read_shift(2);
            }
          },
          31: {
            n: "PtgNum",
            f: function(e10) {
              return e10.l++, aV(e10, 8);
            }
          },
          32: {
            n: "PtgArray",
            f: function(e10, t10, r10) {
              var a10 = (96 & e10[e10.l++]) >> 5;
              return e10.l += 2 == r10.biff ? 6 : 12 == r10.biff ? 14 : 7, [a10];
            }
          },
          33: {
            n: "PtgFunc",
            f: function(e10, t10, r10) {
              var a10 = (96 & e10[e10.l]) >> 5;
              e10.l += 1;
              var n10 = e10.read_shift(r10 && r10.biff <= 3 ? 1 : 2);
              return [iG[n10], i$[n10], a10];
            }
          },
          34: {
            n: "PtgFuncVar",
            f: function(e10, t10, r10) {
              var a10, n10 = e10[e10.l++], s10 = e10.read_shift(1), i10 = r10 && r10.biff <= 3 ? [88 == n10 ? -1 : 0, e10.read_shift(1)] : [(a10 = e10)[a10.l + 1] >> 7, 32767 & a10.read_shift(2)];
              return [s10, (0 === i10[0] ? i$ : iV)[i10[1]]];
            }
          },
          35: {
            n: "PtgName",
            f: function(e10, t10, r10) {
              var a10 = e10.read_shift(1) >>> 5 & 3, n10 = !r10 || r10.biff >= 8 ? 4 : 2, s10 = e10.read_shift(n10);
              switch (r10.biff) {
                case 2:
                  e10.l += 5;
                  break;
                case 3:
                case 4:
                  e10.l += 8;
                  break;
                case 5:
                  e10.l += 12;
              }
              return [a10, 0, s10];
            }
          },
          36: {
            n: "PtgRef",
            f: function(e10, t10, r10) {
              var a10 = (96 & e10[e10.l]) >> 5;
              return e10.l += 1, [a10, iE(e10, 0, r10)];
            }
          },
          37: {
            n: "PtgArea",
            f: function(e10, t10, r10) {
              return [(96 & e10[e10.l++]) >> 5, iT(e10, r10.biff >= 2 && r10.biff <= 5 ? 6 : 8, r10)];
            }
          },
          38: {
            n: "PtgMemArea",
            f: function(e10, t10, r10) {
              var a10 = e10.read_shift(1) >>> 5 & 3;
              return e10.l += r10 && 2 == r10.biff ? 3 : 4, [a10, e10.read_shift(r10 && 2 == r10.biff ? 1 : 2)];
            }
          },
          39: { n: "PtgMemErr", f: an },
          40: { n: "PtgMemNoMem", f: an },
          41: {
            n: "PtgMemFunc",
            f: function(e10, t10, r10) {
              return [e10.read_shift(1) >>> 5 & 3, e10.read_shift(r10 && 2 == r10.biff ? 1 : 2)];
            }
          },
          42: {
            n: "PtgRefErr",
            f: function(e10, t10, r10) {
              var a10 = e10.read_shift(1) >>> 5 & 3;
              return e10.l += 4, r10.biff < 8 && e10.l--, 12 == r10.biff && (e10.l += 2), [a10];
            }
          },
          43: {
            n: "PtgAreaErr",
            f: function(e10, t10, r10) {
              var a10 = (96 & e10[e10.l++]) >> 5;
              return e10.l += r10 && r10.biff > 8 ? 12 : r10.biff < 8 ? 6 : 8, [a10];
            }
          },
          44: {
            n: "PtgRefN",
            f: function(e10, t10, r10) {
              var a10 = (96 & e10[e10.l]) >> 5;
              return e10.l += 1, [
                a10,
                (function(e11, t11, r11) {
                  var a11, n10, s10, i10, o10, c10 = r11 && r11.biff ? r11.biff : 8;
                  if (c10 >= 2 && c10 <= 5) {
                    return n10 = (a11 = e11).read_shift(2), s10 = a11.read_shift(1), i10 = (32768 & n10) >> 15, o10 = (16384 & n10) >> 14, n10 &= 16383, 1 == i10 && n10 >= 8192 && (n10 -= 16384), 1 == o10 && s10 >= 128 && (s10 -= 256), { r: n10, c: s10, cRel: o10, rRel: i10 };
                  }
                  var l2 = e11.read_shift(c10 >= 12 ? 4 : 2), f2 = e11.read_shift(2), h2 = (16384 & f2) >> 14, u2 = (32768 & f2) >> 15;
                  if (f2 &= 16383, 1 == u2) for (; l2 > 524287; ) l2 -= 1048576;
                  if (1 == h2) for (; f2 > 8191; ) f2 -= 16384;
                  return { r: l2, c: f2, cRel: h2, rRel: u2 };
                })(e10, 0, r10)
              ];
            }
          },
          45: {
            n: "PtgAreaN",
            f: function(e10, t10, r10) {
              return [
                (96 & e10[e10.l++]) >> 5,
                (function(e11, t11, r11) {
                  if (r11.biff < 8) return iy(e11, t11, r11);
                  var a10 = e11.read_shift(12 == r11.biff ? 4 : 2), n10 = e11.read_shift(12 == r11.biff ? 4 : 2), s10 = iw(e11, 2), i10 = iw(e11, 2);
                  return {
                    s: { r: a10, c: s10[0], cRel: s10[1], rRel: s10[2] },
                    e: { r: n10, c: i10[0], cRel: i10[1], rRel: i10[2] }
                  };
                })(e10, t10 - 1, r10)
              ];
            }
          },
          46: {
            n: "PtgMemAreaN",
            f: function(e10) {
              return [e10.read_shift(1) >>> 5 & 3, e10.read_shift(2)];
            }
          },
          47: {
            n: "PtgMemNoMemN",
            f: function(e10) {
              return [e10.read_shift(1) >>> 5 & 3, e10.read_shift(2)];
            }
          },
          57: {
            n: "PtgNameX",
            f: function(e10, t10, r10) {
              var a10, n10, s10, i10;
              return 5 == r10.biff ? (n10 = (a10 = e10).read_shift(1) >>> 5 & 3, s10 = a10.read_shift(2, "i"), a10.l += 8, i10 = a10.read_shift(2), a10.l += 12, [n10, s10, i10]) : [e10.read_shift(1) >>> 5 & 3, e10.read_shift(2), e10.read_shift(4)];
            }
          },
          58: {
            n: "PtgRef3d",
            f: function(e10, t10, r10) {
              var a10 = (96 & e10[e10.l]) >> 5;
              e10.l += 1;
              var n10 = e10.read_shift(2);
              return r10 && 5 == r10.biff && (e10.l += 12), [a10, n10, iE(e10, 0, r10)];
            }
          },
          59: {
            n: "PtgArea3d",
            f: function(e10, t10, r10) {
              var a10 = (96 & e10[e10.l++]) >> 5, n10 = e10.read_shift(2, "i"), s10 = 8;
              if (r10)
                switch (r10.biff) {
                  case 5:
                    e10.l += 12, s10 = 6;
                    break;
                  case 12:
                    s10 = 12;
                }
              return [a10, n10, iT(e10, s10, r10)];
            }
          },
          60: {
            n: "PtgRefErr3d",
            f: function(e10, t10, r10) {
              var a10 = (96 & e10[e10.l++]) >> 5, n10 = e10.read_shift(2), s10 = 4;
              if (r10)
                switch (r10.biff) {
                  case 5:
                    s10 = 15;
                    break;
                  case 12:
                    s10 = 6;
                }
              return e10.l += s10, [a10, n10];
            }
          },
          61: {
            n: "PtgAreaErr3d",
            f: function(e10, t10, r10) {
              var a10 = (96 & e10[e10.l++]) >> 5, n10 = e10.read_shift(2), s10 = 8;
              if (r10)
                switch (r10.biff) {
                  case 5:
                    e10.l += 12, s10 = 6;
                    break;
                  case 12:
                    s10 = 12;
                }
              return e10.l += s10, [a10, n10];
            }
          },
          255: {}
        }, iO = {
          64: 32,
          96: 32,
          65: 33,
          97: 33,
          66: 34,
          98: 34,
          67: 35,
          99: 35,
          68: 36,
          100: 36,
          69: 37,
          101: 37,
          70: 38,
          102: 38,
          71: 39,
          103: 39,
          72: 40,
          104: 40,
          73: 41,
          105: 41,
          74: 42,
          106: 42,
          75: 43,
          107: 43,
          76: 44,
          108: 44,
          77: 45,
          109: 45,
          78: 46,
          110: 46,
          79: 47,
          111: 47,
          88: 34,
          120: 34,
          89: 57,
          121: 57,
          90: 58,
          122: 58,
          91: 59,
          123: 59,
          92: 60,
          124: 60,
          93: 61,
          125: 61
        }, iR = {
          1: { n: "PtgElfLel", f: iA },
          2: { n: "PtgElfRw", f: i_ },
          3: { n: "PtgElfCol", f: i_ },
          6: { n: "PtgElfRwV", f: i_ },
          7: { n: "PtgElfColV", f: i_ },
          10: { n: "PtgElfRadical", f: i_ },
          11: { n: "PtgElfRadicalS", f: iS },
          13: { n: "PtgElfColS", f: iS },
          15: { n: "PtgElfColSV", f: iS },
          16: { n: "PtgElfRadicalLel", f: iA },
          25: {
            n: "PtgList",
            f: function(e10) {
              e10.l += 2;
              var t10 = e10.read_shift(2), r10 = e10.read_shift(2), a10 = e10.read_shift(4), n10 = e10.read_shift(2), s10 = e10.read_shift(2), i10 = iC[r10 >> 2 & 31];
              return { ixti: t10, coltype: 3 & r10, rt: i10, idx: a10, c: n10, C: s10 };
            }
          },
          29: {
            n: "PtgSxName",
            f: function(e10) {
              return e10.l += 2, [e10.read_shift(4)];
            }
          },
          255: {}
        }, iN = {
          0: {
            n: "PtgAttrNoop",
            f: function(e10) {
              return e10.l += 4, [0, 0];
            }
          },
          1: {
            n: "PtgAttrSemi",
            f: function(e10, t10, r10) {
              var a10 = 255 & e10[e10.l + 1] ? 1 : 0;
              return e10.l += r10 && 2 == r10.biff ? 3 : 4, [a10];
            }
          },
          2: {
            n: "PtgAttrIf",
            f: function(e10, t10, r10) {
              var a10 = 255 & e10[e10.l + 1] ? 1 : 0;
              return e10.l += 2, [a10, e10.read_shift(r10 && 2 == r10.biff ? 1 : 2)];
            }
          },
          4: {
            n: "PtgAttrChoose",
            f: function(e10, t10, r10) {
              e10.l += 2;
              for (var a10 = e10.read_shift(r10 && 2 == r10.biff ? 1 : 2), n10 = [], s10 = 0; s10 <= a10; ++s10)
                n10.push(e10.read_shift(r10 && 2 == r10.biff ? 1 : 2));
              return n10;
            }
          },
          8: {
            n: "PtgAttrGoto",
            f: function(e10, t10, r10) {
              var a10 = 255 & e10[e10.l + 1] ? 1 : 0;
              return e10.l += 2, [a10, e10.read_shift(r10 && 2 == r10.biff ? 1 : 2)];
            }
          },
          16: {
            n: "PtgAttrSum",
            f: function(e10, t10, r10) {
              e10.l += r10 && 2 == r10.biff ? 3 : 4;
            }
          },
          32: { n: "PtgAttrBaxcel", f: ik },
          33: { n: "PtgAttrBaxcel", f: ik },
          64: {
            n: "PtgAttrSpace",
            f: function(e10) {
              return e10.read_shift(2), ix(e10, 2);
            }
          },
          65: {
            n: "PtgAttrSpaceSemi",
            f: function(e10) {
              return e10.read_shift(2), ix(e10, 2);
            }
          },
          128: {
            n: "PtgAttrIfError",
            f: function(e10) {
              var t10 = 255 & e10[e10.l + 1] ? 1 : 0;
              return e10.l += 2, [t10, e10.read_shift(2)];
            }
          },
          255: {}
        };
        function iF(e10, t10, r10, a10) {
          if (a10.biff < 8) return n10 = t10, void (e10.l += n10);
          for (var n10, s10, i10 = e10.l + t10, o10 = [], c10 = 0; c10 !== r10.length; ++c10)
            switch (r10[c10][0]) {
              case "PtgArray":
                r10[c10][1] = (function(e11, t11, r11) {
                  var a11 = 0, n11 = 0;
                  12 == r11.biff ? (a11 = e11.read_shift(4), n11 = e11.read_shift(4)) : (n11 = 1 + e11.read_shift(1), a11 = 1 + e11.read_shift(2)), r11.biff >= 2 && r11.biff < 8 && (--a11, 0 == --n11 && (n11 = 256));
                  for (var s11 = 0, i11 = []; s11 != a11 && (i11[s11] = []); ++s11)
                    for (var o11 = 0; o11 != n11; ++o11)
                      i11[s11][o11] = (function(e12, t12) {
                        var r12 = [e12.read_shift(1)];
                        if (12 == t12)
                          switch (r12[0]) {
                            case 2:
                              r12[0] = 4;
                              break;
                            case 4:
                              r12[0] = 16;
                              break;
                            case 0:
                              r12[0] = 1;
                              break;
                            case 1:
                              r12[0] = 2;
                          }
                        switch (r12[0]) {
                          case 4:
                            r12[1] = n$(e12, 1) ? "TRUE" : "FALSE", 12 != t12 && (e12.l += 7);
                            break;
                          case 37:
                          case 16:
                            r12[1] = aQ[e12[e12.l]], e12.l += 12 == t12 ? 4 : 8;
                            break;
                          case 0:
                            e12.l += 8;
                            break;
                          case 1:
                            r12[1] = aV(e12, 8);
                            break;
                          case 2:
                            r12[1] = n0(e12, 0, { biff: t12 > 0 && t12 < 8 ? 2 : t12 });
                            break;
                          default:
                            throw Error("Bad SerAr: " + r12[0]);
                        }
                        return r12;
                      })(e11, r11.biff);
                  return i11;
                })(e10, 0, a10), o10.push(r10[c10][1]);
                break;
              case "PtgMemArea":
                r10[c10][2] = (function(e11, t11, r11) {
                  for (var a11 = e11.read_shift(12 == r11.biff ? 4 : 2), n11 = [], s11 = 0; s11 != a11; ++s11)
                    n11.push((12 == r11.biff ? az : n9)(e11, 8));
                  return n11;
                })(e10, r10[c10][1], a10), o10.push(r10[c10][2]);
                break;
              case "PtgExp":
                a10 && 12 == a10.biff && (r10[c10][1][1] = e10.read_shift(4), o10.push(r10[c10][1]));
                break;
              case "PtgList":
              case "PtgElfRadicalS":
              case "PtgElfColS":
              case "PtgElfColSV":
                throw "Unsupported " + r10[c10][0];
            }
          return 0 != (t10 = i10 - e10.l) && o10.push((s10 = t10, void (e10.l += s10))), o10;
        }
        function iD(e10, t10, r10) {
          for (var a10, n10, s10, i10 = e10.l + t10, o10 = []; i10 != e10.l; )
            (t10 = i10 - e10.l, n10 = iI[s10 = e10[e10.l]] || iI[iO[s10]], (24 === s10 || 25 === s10) && (n10 = (24 === s10 ? iR : iN)[e10[e10.l + 1]]), n10 && n10.f) ? o10.push([n10.n, n10.f(e10, t10, r10)]) : (a10 = t10, e10.l += a10);
          return o10;
        }
        var iP = {
          PtgAdd: "+",
          PtgConcat: "&",
          PtgDiv: "/",
          PtgEq: "=",
          PtgGe: ">=",
          PtgGt: ">",
          PtgLe: "<=",
          PtgLt: "<",
          PtgMul: "*",
          PtgNe: "<>",
          PtgPower: "^",
          PtgSub: "-"
        };
        function iL(e10, t10, r10) {
          if (!e10) return "SH33TJSERR0";
          if (r10.biff > 8 && (!e10.XTI || !e10.XTI[t10])) return e10.SheetNames[t10];
          if (!e10.XTI) return "SH33TJSERR6";
          var a10 = e10.XTI[t10];
          if (r10.biff < 8) return t10 > 1e4 && (t10 -= 65536), t10 < 0 && (t10 = -t10), 0 == t10 ? "" : e10.XTI[t10 - 1];
          if (!a10) return "SH33TJSERR1";
          var n10 = "";
          if (r10.biff > 8)
            switch (e10[a10[0]][0]) {
              case 357:
                return n10 = -1 == a10[1] ? "#REF" : e10.SheetNames[a10[1]], a10[1] == a10[2] ? n10 : n10 + ":" + e10.SheetNames[a10[2]];
              case 358:
                if (null != r10.SID) return e10.SheetNames[r10.SID];
                return "SH33TJSSAME" + e10[a10[0]][0];
              default:
                return "SH33TJSSRC" + e10[a10[0]][0];
            }
          switch (e10[a10[0]][0][0]) {
            case 1025:
              return n10 = -1 == a10[1] ? "#REF" : e10.SheetNames[a10[1]] || "SH33TJSERR3", a10[1] == a10[2] ? n10 : n10 + ":" + e10.SheetNames[a10[2]];
            case 14849:
              return e10[a10[0]].slice(1).map(function(e11) {
                return e11.Name;
              }).join(";;");
            default:
              if (!e10[a10[0]][0][3]) return "SH33TJSERR2";
              return n10 = -1 == a10[1] ? "#REF" : e10[a10[0]][0][3][a10[1]] || "SH33TJSERR4", a10[1] == a10[2] ? n10 : n10 + ":" + e10[a10[0]][0][3][a10[2]];
          }
        }
        function iM(e10, t10, r10) {
          var a10 = iL(e10, t10, r10);
          return "#REF" == a10 ? a10 : aE(a10, r10);
        }
        function iU(e10, t10, r10, a10, n10) {
          var s10, i10, o10, c10, l2 = n10 && n10.biff || 8, f2 = { s: { c: 0, r: 0 }, e: { c: 0, r: 0 } }, h2 = [], u2 = 0, d2 = 0, p2 = "";
          if (!e10[0] || !e10[0][0]) return "";
          for (var m2 = -1, g2 = "", v2 = 0, b2 = e10[0].length; v2 < b2; ++v2) {
            var w2 = e10[0][v2];
            switch (w2[0]) {
              case "PtgUminus":
                h2.push("-" + h2.pop());
                break;
              case "PtgUplus":
                h2.push("+" + h2.pop());
                break;
              case "PtgPercent":
                h2.push(h2.pop() + "%");
                break;
              case "PtgAdd":
              case "PtgConcat":
              case "PtgDiv":
              case "PtgEq":
              case "PtgGe":
              case "PtgGt":
              case "PtgLe":
              case "PtgLt":
              case "PtgMul":
              case "PtgNe":
              case "PtgPower":
              case "PtgSub":
                if (s10 = h2.pop(), i10 = h2.pop(), m2 >= 0) {
                  switch (e10[0][m2][1][0]) {
                    case 0:
                      g2 = tT(" ", e10[0][m2][1][1]);
                      break;
                    case 1:
                      g2 = tT("\r", e10[0][m2][1][1]);
                      break;
                    default:
                      if (g2 = "", n10.WTF) throw Error("Unexpected PtgAttrSpaceType " + e10[0][m2][1][0]);
                  }
                  i10 += g2, m2 = -1;
                }
                h2.push(i10 + iP[w2[0]] + s10);
                break;
              case "PtgIsect":
                s10 = h2.pop(), i10 = h2.pop(), h2.push(i10 + " " + s10);
                break;
              case "PtgUnion":
                s10 = h2.pop(), i10 = h2.pop(), h2.push(i10 + "," + s10);
                break;
              case "PtgRange":
                s10 = h2.pop(), i10 = h2.pop(), h2.push(
                  (function(e11, t11) {
                    var r11 = e11.lastIndexOf("!"), a11 = t11.lastIndexOf("!");
                    return -1 == r11 && -1 == a11 ? e11 + ":" + t11 : r11 > 0 && a11 > 0 && e11.slice(0, r11).toLowerCase() == t11.slice(0, a11).toLowerCase() ? e11 + ":" + t11.slice(a11 + 1) : (console.error("Cannot hydrate range", e11, t11), e11 + ":" + t11);
                  })(i10, s10)
                );
                break;
              case "PtgAttrChoose":
              case "PtgAttrGoto":
              case "PtgAttrIf":
              case "PtgAttrIfError":
              case "PtgAttrBaxcel":
              case "PtgAttrSemi":
              case "PtgMemArea":
              case "PtgTbl":
              case "PtgMemErr":
              case "PtgMemAreaN":
              case "PtgMemNoMemN":
              case "PtgAttrNoop":
              case "PtgSheet":
              case "PtgEndSheet":
              case "PtgMemFunc":
              case "PtgMemNoMem":
                break;
              case "PtgRef":
                o10 = al(w2[1][1], f2, n10), h2.push(ah(o10, l2));
                break;
              case "PtgRefN":
                o10 = r10 ? al(w2[1][1], r10, n10) : w2[1][1], h2.push(ah(o10, l2));
                break;
              case "PtgRef3d":
                u2 = w2[1][1], o10 = al(w2[1][2], f2, n10), p2 = iM(a10, u2, n10), h2.push(p2 + "!" + ah(o10, l2));
                break;
              case "PtgFunc":
              case "PtgFuncVar":
                var T2 = w2[1][0], y2 = w2[1][1];
                T2 || (T2 = 0);
                var E2 = 0 == (T2 &= 127) ? [] : h2.slice(-T2);
                h2.length -= T2, "User" === y2 && (y2 = E2.shift()), h2.push(y2 + "(" + E2.join(",") + ")");
                break;
              case "PtgBool":
                h2.push(w2[1] ? "TRUE" : "FALSE");
                break;
              case "PtgInt":
              case "PtgErr":
                h2.push(w2[1]);
                break;
              case "PtgNum":
                h2.push(String(w2[1]));
                break;
              case "PtgStr":
                h2.push('"' + w2[1].replace(/"/g, '""') + '"');
                break;
              case "PtgAreaN":
                c10 = af(w2[1][1], r10 ? { s: r10 } : f2, n10), h2.push(au(c10, n10));
                break;
              case "PtgArea":
                c10 = af(w2[1][1], f2, n10), h2.push(au(c10, n10));
                break;
              case "PtgArea3d":
                u2 = w2[1][1], c10 = w2[1][2], p2 = iM(a10, u2, n10), h2.push(p2 + "!" + au(c10, n10));
                break;
              case "PtgAttrSum":
                h2.push("SUM(" + h2.pop() + ")");
                break;
              case "PtgName":
                d2 = w2[1][2];
                var k2 = (a10.names || [])[d2 - 1] || (a10[0] || [])[d2], x2 = k2 ? k2.Name : "SH33TJSNAME" + String(d2);
                x2 && "_xlfn." == x2.slice(0, 6) && !n10.xlfn && (x2 = x2.slice(6)), h2.push(x2);
                break;
              case "PtgNameX":
                var _2, S2 = w2[1][1];
                if (d2 = w2[1][2], n10.biff <= 5) S2 < 0 && (S2 = -S2), a10[S2] && (_2 = a10[S2][d2]);
                else {
                  var A2 = "";
                  if (14849 == ((a10[S2] || [])[0] || [])[0] || (1025 == ((a10[S2] || [])[0] || [])[0] ? a10[S2][d2] && a10[S2][d2].itab > 0 && (A2 = a10.SheetNames[a10[S2][d2].itab - 1] + "!") : A2 = a10.SheetNames[d2 - 1] + "!"), a10[S2] && a10[S2][d2])
                    A2 += a10[S2][d2].Name;
                  else if (a10[0] && a10[0][d2]) A2 += a10[0][d2].Name;
                  else {
                    var C2 = (iL(a10, S2, n10) || "").split(";;");
                    C2[d2 - 1] ? A2 = C2[d2 - 1] : A2 += "SH33TJSERRX";
                  }
                  h2.push(A2);
                  break;
                }
                _2 || (_2 = { Name: "SH33TJSERRY" }), h2.push(_2.Name);
                break;
              case "PtgParen":
                var I2 = "(", O2 = ")";
                if (m2 >= 0) {
                  switch (g2 = "", e10[0][m2][1][0]) {
                    case 2:
                      I2 = tT(" ", e10[0][m2][1][1]) + I2;
                      break;
                    case 3:
                      I2 = tT("\r", e10[0][m2][1][1]) + I2;
                      break;
                    case 4:
                      O2 = tT(" ", e10[0][m2][1][1]) + O2;
                      break;
                    case 5:
                      O2 = tT("\r", e10[0][m2][1][1]) + O2;
                      break;
                    default:
                      if (n10.WTF) throw Error("Unexpected PtgAttrSpaceType " + e10[0][m2][1][0]);
                  }
                  m2 = -1;
                }
                h2.push(I2 + h2.pop() + O2);
                break;
              case "PtgRefErr":
              case "PtgRefErr3d":
              case "PtgAreaErr":
              case "PtgAreaErr3d":
                h2.push("#REF!");
                break;
              case "PtgExp":
                o10 = { c: w2[1][1], r: w2[1][0] };
                var R2 = { c: r10.c, r: r10.r };
                if (a10.sharedf[ab(o10)]) {
                  var N2 = a10.sharedf[ab(o10)];
                  h2.push(iU(N2, f2, R2, a10, n10));
                } else {
                  var F2 = false;
                  for (s10 = 0; s10 != a10.arrayf.length; ++s10)
                    if ((i10 = a10.arrayf[s10], !(o10.c < i10[0].s.c) && !(o10.c > i10[0].e.c)) && !(o10.r < i10[0].s.r) && !(o10.r > i10[0].e.r)) {
                      h2.push(iU(i10[1], f2, R2, a10, n10)), F2 = true;
                      break;
                    }
                  F2 || h2.push(w2[1]);
                }
                break;
              case "PtgArray":
                h2.push(
                  "{" + (function(e11) {
                    for (var t11 = [], r11 = 0; r11 < e11.length; ++r11) {
                      for (var a11 = e11[r11], n11 = [], s11 = 0; s11 < a11.length; ++s11) {
                        var i11 = a11[s11];
                        i11 ? 2 === i11[0] ? n11.push('"' + i11[1].replace(/"/g, '""') + '"') : n11.push(i11[1]) : n11.push("");
                      }
                      t11.push(n11.join(","));
                    }
                    return t11.join(";");
                  })(w2[1]) + "}"
                );
                break;
              case "PtgAttrSpace":
              case "PtgAttrSpaceSemi":
                m2 = v2;
                break;
              case "PtgMissArg":
                h2.push("");
                break;
              case "PtgList":
                h2.push("Table" + w2[1].idx + "[#" + w2[1].rt + "]");
                break;
              case "PtgElfCol":
              case "PtgElfColS":
              case "PtgElfColSV":
              case "PtgElfColV":
              case "PtgElfLel":
              case "PtgElfRadical":
              case "PtgElfRadicalLel":
              case "PtgElfRadicalS":
              case "PtgElfRw":
              case "PtgElfRwV":
                throw Error("Unsupported ELFs");
              default:
                throw Error("Unrecognized Formula Token: " + String(w2));
            }
            var D2 = ["PtgAttrSpace", "PtgAttrSpaceSemi", "PtgAttrGoto"];
            if (3 != n10.biff && m2 >= 0 && -1 == D2.indexOf(e10[0][v2][0])) {
              w2 = e10[0][m2];
              var P2 = true;
              switch (w2[1][0]) {
                case 4:
                  P2 = false;
                case 0:
                  g2 = tT(" ", w2[1][1]);
                  break;
                case 5:
                  P2 = false;
                case 1:
                  g2 = tT("\r", w2[1][1]);
                  break;
                default:
                  if (g2 = "", n10.WTF) throw Error("Unexpected PtgAttrSpaceType " + w2[1][0]);
              }
              h2.push((P2 ? g2 : "") + h2.pop() + (P2 ? "" : g2)), m2 = -1;
            }
          }
          if (h2.length > 1 && n10.WTF) throw Error("bad formula stack");
          return "TRUE" == h2[0] || "FALSE" != h2[0] && h2[0];
        }
        function iB(e10, t10, r10) {
          var a10 = e10.l + t10, n10 = n6(e10, 6, r10), s10 = (function(e11) {
            var t11;
            if (65535 !== r4(e11, e11.l + 6)) return [aV(e11), "n"];
            switch (e11[e11.l]) {
              case 0:
                return e11.l += 8, ["String", "s"];
              case 1:
                return t11 = 1 === e11[e11.l + 2], e11.l += 8, [t11, "b"];
              case 2:
                return t11 = e11[e11.l + 2], e11.l += 8, [t11, "e"];
              case 3:
                return e11.l += 8, ["", "s"];
            }
            return [];
          })(e10, 8), i10 = e10.read_shift(1);
          2 != r10.biff && (e10.read_shift(1), r10.biff >= 5 && e10.read_shift(4));
          var o10 = (function(e11, t11, r11) {
            var a11, n11, s11 = e11.l + t11, i11 = 2 == r11.biff ? 1 : 2, o11 = e11.read_shift(i11);
            if (65535 == o11) return [[], (a11 = t11 - 2, void (e11.l += a11))];
            var c10 = iD(e11, o11, r11);
            return t11 !== o11 + i11 && (n11 = iF(e11, t11 - o11 - i11, c10, r11)), e11.l = s11, [c10, n11];
          })(e10, a10 - e10.l, r10);
          return { cell: n10, val: s10[0], formula: o10, shared: i10 >> 3 & 1, tt: s10[1] };
        }
        function iW(e10, t10, r10) {
          var a10 = e10.read_shift(4), n10 = iD(e10, a10, r10), s10 = e10.read_shift(4), i10 = s10 > 0 ? iF(e10, s10, n10, r10) : null;
          return [n10, i10];
        }
        function iz(e10) {
          if ((0 | e10) == e10 && e10 < 65536 && e10 >= 0) {
            var t10 = as(11);
            return t10.write_shift(4, 3), t10.write_shift(1, 30), t10.write_shift(2, e10), t10.write_shift(4, 0), t10;
          }
          var r10 = as(17);
          return r10.write_shift(4, 11), r10.write_shift(1, 31), r10.write_shift(8, e10), r10.write_shift(4, 0), r10;
        }
        var iH = function(e10, t10) {
          var r10, a10, n10, s10, i10, o10, c10, l2, f2, h2, u2, d2, p2, m2, g2, v2, b2, w2, T2, y2, E2, k2, x2, _2, S2, A2, C2, I2, O2, R2, N2, F2, D2;
          if ("number" == typeof e10) return iz(e10);
          if ("boolean" == typeof e10)
            return (r10 = as(10)).write_shift(4, 2), r10.write_shift(1, 29), r10.write_shift(1, +!!e10), r10.write_shift(4, 0), r10;
          if (/^#(DIV\/0!|GETTING_DATA|N\/A|NAME\?|NULL!|NUM!|REF!|VALUE!)$/.test(e10))
            return a10 = +a0[e10], (n10 = as(10)).write_shift(4, 2), n10.write_shift(1, 28), n10.write_shift(1, a10), n10.write_shift(4, 0), n10;
          if (e10.match(
            /^\$?(?:[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D]|[A-Z]{1,2})\$?(?:10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})$/
          ))
            return s10 = av(e10), (i10 = as(15)).write_shift(4, 7), i10.write_shift(1, 36), i10.write_shift(4, s10.r), i10.write_shift(2, s10.c | ("$" != e10.charAt(0)) << 14 | !e10.match(/\$\d/) << 15), i10.write_shift(4, 0), i10;
          if (e10.match(
            /^\$?(?:[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D]|[A-Z]{1,2})\$?(?:10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5}):\$?(?:[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D]|[A-Z]{1,2})\$?(?:10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})$/
          ))
            return c10 = (o10 = e10.split(":"))[0], (l2 = as(23)).write_shift(4, 15), f2 = av(c10 = o10[0]), l2.write_shift(1, 36), l2.write_shift(4, f2.r), l2.write_shift(2, f2.c | ("$" != c10.charAt(0)) << 14 | !c10.match(/\$\d/) << 15), l2.write_shift(4, 0), f2 = av(c10 = o10[1]), l2.write_shift(1, 36), l2.write_shift(4, f2.r), l2.write_shift(2, f2.c | ("$" != c10.charAt(0)) << 14 | !c10.match(/\$\d/) << 15), l2.write_shift(4, 0), l2.write_shift(1, 17), l2.write_shift(4, 0), l2;
          if (e10.match(
            /^#REF!\$?(?:[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D]|[A-Z]{1,2})\$?(?:10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5}):\$?(?:[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D]|[A-Z]{1,2})\$?(?:10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})$/
          ))
            return u2 = (h2 = e10).lastIndexOf("!"), d2 = h2.slice(0, u2), h2 = h2.slice(u2 + 1), "'" == d2.charAt(0) && (d2 = d2.slice(1, -1).replace(/''/g, "'")), p2 = aw(h2), (m2 = as(23)).write_shift(4, 15), m2.write_shift(1, 59), m2.write_shift(
              2,
              2 + t10.SheetNames.map(function(e11) {
                return e11.toLowerCase();
              }).indexOf(d2.toLowerCase())
            ), m2.write_shift(4, p2.s.r), m2.write_shift(4, p2.e.r), m2.write_shift(2, p2.s.c), m2.write_shift(2, p2.e.c), m2.write_shift(4, 0), m2;
          if (e10.match(
            /^(?:'[^\\\/?*\[\]:]*'|[^'][^\\\/?*\[\]:'`~!@#$%^()\-=+{}|;,<.>]*)!\$?(?:[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D]|[A-Z]{1,2})\$?(?:10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})$/
          ))
            return v2 = (g2 = e10).lastIndexOf("!"), b2 = g2.slice(0, v2), w2 = av(g2 = g2.slice(v2 + 1)), "'" == b2.charAt(0) && (b2 = b2.slice(1, -1).replace(/''/g, "'")), (T2 = as(17)).write_shift(4, 9), T2.write_shift(1, 58), T2.write_shift(
              2,
              2 + t10.SheetNames.map(function(e11) {
                return e11.toLowerCase();
              }).indexOf(b2.toLowerCase())
            ), T2.write_shift(4, w2.r), T2.write_shift(2, w2.c | ("$" != g2.charAt(0)) << 14 | !g2.match(/\$\d/) << 15), T2.write_shift(4, 0), T2;
          if (e10.match(
            /^(?:'[^\\\/?*\[\]:]*'|[^'][^\\\/?*\[\]:'`~!@#$%^()\-=+{}|;,<.>]*)!\$?(?:[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D]|[A-Z]{1,2})\$?(?:10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5}):\$?(?:[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D]|[A-Z]{1,2})\$?(?:10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})$/
          ))
            return E2 = (y2 = e10).lastIndexOf("!"), k2 = y2.slice(0, E2), y2 = y2.slice(E2 + 1), "'" == k2.charAt(0) && (k2 = k2.slice(1, -1).replace(/''/g, "'")), x2 = y2.split(":"), (_2 = as(27)).write_shift(4, 19), A2 = av(S2 = x2[0]), _2.write_shift(1, 58), _2.write_shift(
              2,
              2 + t10.SheetNames.map(function(e11) {
                return e11.toLowerCase();
              }).indexOf(k2.toLowerCase())
            ), _2.write_shift(4, A2.r), _2.write_shift(2, A2.c | ("$" != S2.charAt(0)) << 14 | !S2.match(/\$\d/) << 15), A2 = av(S2 = x2[1]), _2.write_shift(1, 58), _2.write_shift(
              2,
              2 + t10.SheetNames.map(function(e11) {
                return e11.toLowerCase();
              }).indexOf(k2.toLowerCase())
            ), _2.write_shift(4, A2.r), _2.write_shift(2, A2.c | ("$" != S2.charAt(0)) << 14 | !S2.match(/\$\d/) << 15), _2.write_shift(1, 17), _2.write_shift(4, 0), _2;
          if (/^(?:'[^\\\/?*\[\]:]*'|[^'][^\\\/?*\[\]:'`~!@#$%^()\-=+{}|;,<.>]*)!#REF!$/.test(e10))
            return I2 = (C2 = e10).lastIndexOf("!"), O2 = C2.slice(0, I2), C2 = C2.slice(I2 + 1), "'" == O2.charAt(0) && (O2 = O2.slice(1, -1).replace(/''/g, "'")), (R2 = as(17)).write_shift(4, 9), R2.write_shift(1, 60), R2.write_shift(
              2,
              2 + t10.SheetNames.map(function(e11) {
                return e11.toLowerCase();
              }).indexOf(O2.toLowerCase())
            ), R2.write_shift(4, 0), R2.write_shift(2, 0), R2.write_shift(4, 0), R2;
          if (/^".*"$/.test(e10))
            return (N2 = as(7)).write_shift(4, 3 + 2 * e10.length), N2.write_shift(1, 23), N2.write_shift(2, e10.length), (F2 = as(2 * e10.length)).write_shift(2 * e10.length, e10, "utf16le"), (D2 = as(4)).write_shift(4, 0), ek([N2, F2, D2]);
          if (/^[+-]\d+$/.test(e10)) return iz(parseInt(e10, 10));
          throw "Formula |" + e10 + "| not supported for XLSB";
        }, iV = {
          0: "BEEP",
          1: "OPEN",
          2: "OPEN.LINKS",
          3: "CLOSE.ALL",
          4: "SAVE",
          5: "SAVE.AS",
          6: "FILE.DELETE",
          7: "PAGE.SETUP",
          8: "PRINT",
          9: "PRINTER.SETUP",
          10: "QUIT",
          11: "NEW.WINDOW",
          12: "ARRANGE.ALL",
          13: "WINDOW.SIZE",
          14: "WINDOW.MOVE",
          15: "FULL",
          16: "CLOSE",
          17: "RUN",
          22: "SET.PRINT.AREA",
          23: "SET.PRINT.TITLES",
          24: "SET.PAGE.BREAK",
          25: "REMOVE.PAGE.BREAK",
          26: "FONT",
          27: "DISPLAY",
          28: "PROTECT.DOCUMENT",
          29: "PRECISION",
          30: "A1.R1C1",
          31: "CALCULATE.NOW",
          32: "CALCULATION",
          34: "DATA.FIND",
          35: "EXTRACT",
          36: "DATA.DELETE",
          37: "SET.DATABASE",
          38: "SET.CRITERIA",
          39: "SORT",
          40: "DATA.SERIES",
          41: "TABLE",
          42: "FORMAT.NUMBER",
          43: "ALIGNMENT",
          44: "STYLE",
          45: "BORDER",
          46: "CELL.PROTECTION",
          47: "COLUMN.WIDTH",
          48: "UNDO",
          49: "CUT",
          50: "COPY",
          51: "PASTE",
          52: "CLEAR",
          53: "PASTE.SPECIAL",
          54: "EDIT.DELETE",
          55: "INSERT",
          56: "FILL.RIGHT",
          57: "FILL.DOWN",
          61: "DEFINE.NAME",
          62: "CREATE.NAMES",
          63: "FORMULA.GOTO",
          64: "FORMULA.FIND",
          65: "SELECT.LAST.CELL",
          66: "SHOW.ACTIVE.CELL",
          67: "GALLERY.AREA",
          68: "GALLERY.BAR",
          69: "GALLERY.COLUMN",
          70: "GALLERY.LINE",
          71: "GALLERY.PIE",
          72: "GALLERY.SCATTER",
          73: "COMBINATION",
          74: "PREFERRED",
          75: "ADD.OVERLAY",
          76: "GRIDLINES",
          77: "SET.PREFERRED",
          78: "AXES",
          79: "LEGEND",
          80: "ATTACH.TEXT",
          81: "ADD.ARROW",
          82: "SELECT.CHART",
          83: "SELECT.PLOT.AREA",
          84: "PATTERNS",
          85: "MAIN.CHART",
          86: "OVERLAY",
          87: "SCALE",
          88: "FORMAT.LEGEND",
          89: "FORMAT.TEXT",
          90: "EDIT.REPEAT",
          91: "PARSE",
          92: "JUSTIFY",
          93: "HIDE",
          94: "UNHIDE",
          95: "WORKSPACE",
          96: "FORMULA",
          97: "FORMULA.FILL",
          98: "FORMULA.ARRAY",
          99: "DATA.FIND.NEXT",
          100: "DATA.FIND.PREV",
          101: "FORMULA.FIND.NEXT",
          102: "FORMULA.FIND.PREV",
          103: "ACTIVATE",
          104: "ACTIVATE.NEXT",
          105: "ACTIVATE.PREV",
          106: "UNLOCKED.NEXT",
          107: "UNLOCKED.PREV",
          108: "COPY.PICTURE",
          109: "SELECT",
          110: "DELETE.NAME",
          111: "DELETE.FORMAT",
          112: "VLINE",
          113: "HLINE",
          114: "VPAGE",
          115: "HPAGE",
          116: "VSCROLL",
          117: "HSCROLL",
          118: "ALERT",
          119: "NEW",
          120: "CANCEL.COPY",
          121: "SHOW.CLIPBOARD",
          122: "MESSAGE",
          124: "PASTE.LINK",
          125: "APP.ACTIVATE",
          126: "DELETE.ARROW",
          127: "ROW.HEIGHT",
          128: "FORMAT.MOVE",
          129: "FORMAT.SIZE",
          130: "FORMULA.REPLACE",
          131: "SEND.KEYS",
          132: "SELECT.SPECIAL",
          133: "APPLY.NAMES",
          134: "REPLACE.FONT",
          135: "FREEZE.PANES",
          136: "SHOW.INFO",
          137: "SPLIT",
          138: "ON.WINDOW",
          139: "ON.DATA",
          140: "DISABLE.INPUT",
          142: "OUTLINE",
          143: "LIST.NAMES",
          144: "FILE.CLOSE",
          145: "SAVE.WORKBOOK",
          146: "DATA.FORM",
          147: "COPY.CHART",
          148: "ON.TIME",
          149: "WAIT",
          150: "FORMAT.FONT",
          151: "FILL.UP",
          152: "FILL.LEFT",
          153: "DELETE.OVERLAY",
          155: "SHORT.MENUS",
          159: "SET.UPDATE.STATUS",
          161: "COLOR.PALETTE",
          162: "DELETE.STYLE",
          163: "WINDOW.RESTORE",
          164: "WINDOW.MAXIMIZE",
          166: "CHANGE.LINK",
          167: "CALCULATE.DOCUMENT",
          168: "ON.KEY",
          169: "APP.RESTORE",
          170: "APP.MOVE",
          171: "APP.SIZE",
          172: "APP.MINIMIZE",
          173: "APP.MAXIMIZE",
          174: "BRING.TO.FRONT",
          175: "SEND.TO.BACK",
          185: "MAIN.CHART.TYPE",
          186: "OVERLAY.CHART.TYPE",
          187: "SELECT.END",
          188: "OPEN.MAIL",
          189: "SEND.MAIL",
          190: "STANDARD.FONT",
          191: "CONSOLIDATE",
          192: "SORT.SPECIAL",
          193: "GALLERY.3D.AREA",
          194: "GALLERY.3D.COLUMN",
          195: "GALLERY.3D.LINE",
          196: "GALLERY.3D.PIE",
          197: "VIEW.3D",
          198: "GOAL.SEEK",
          199: "WORKGROUP",
          200: "FILL.GROUP",
          201: "UPDATE.LINK",
          202: "PROMOTE",
          203: "DEMOTE",
          204: "SHOW.DETAIL",
          206: "UNGROUP",
          207: "OBJECT.PROPERTIES",
          208: "SAVE.NEW.OBJECT",
          209: "SHARE",
          210: "SHARE.NAME",
          211: "DUPLICATE",
          212: "APPLY.STYLE",
          213: "ASSIGN.TO.OBJECT",
          214: "OBJECT.PROTECTION",
          215: "HIDE.OBJECT",
          216: "SET.EXTRACT",
          217: "CREATE.PUBLISHER",
          218: "SUBSCRIBE.TO",
          219: "ATTRIBUTES",
          220: "SHOW.TOOLBAR",
          222: "PRINT.PREVIEW",
          223: "EDIT.COLOR",
          224: "SHOW.LEVELS",
          225: "FORMAT.MAIN",
          226: "FORMAT.OVERLAY",
          227: "ON.RECALC",
          228: "EDIT.SERIES",
          229: "DEFINE.STYLE",
          240: "LINE.PRINT",
          243: "ENTER.DATA",
          249: "GALLERY.RADAR",
          250: "MERGE.STYLES",
          251: "EDITION.OPTIONS",
          252: "PASTE.PICTURE",
          253: "PASTE.PICTURE.LINK",
          254: "SPELLING",
          256: "ZOOM",
          259: "INSERT.OBJECT",
          260: "WINDOW.MINIMIZE",
          265: "SOUND.NOTE",
          266: "SOUND.PLAY",
          267: "FORMAT.SHAPE",
          268: "EXTEND.POLYGON",
          269: "FORMAT.AUTO",
          272: "GALLERY.3D.BAR",
          273: "GALLERY.3D.SURFACE",
          274: "FILL.AUTO",
          276: "CUSTOMIZE.TOOLBAR",
          277: "ADD.TOOL",
          278: "EDIT.OBJECT",
          279: "ON.DOUBLECLICK",
          280: "ON.ENTRY",
          281: "WORKBOOK.ADD",
          282: "WORKBOOK.MOVE",
          283: "WORKBOOK.COPY",
          284: "WORKBOOK.OPTIONS",
          285: "SAVE.WORKSPACE",
          288: "CHART.WIZARD",
          289: "DELETE.TOOL",
          290: "MOVE.TOOL",
          291: "WORKBOOK.SELECT",
          292: "WORKBOOK.ACTIVATE",
          293: "ASSIGN.TO.TOOL",
          295: "COPY.TOOL",
          296: "RESET.TOOL",
          297: "CONSTRAIN.NUMERIC",
          298: "PASTE.TOOL",
          302: "WORKBOOK.NEW",
          305: "SCENARIO.CELLS",
          306: "SCENARIO.DELETE",
          307: "SCENARIO.ADD",
          308: "SCENARIO.EDIT",
          309: "SCENARIO.SHOW",
          310: "SCENARIO.SHOW.NEXT",
          311: "SCENARIO.SUMMARY",
          312: "PIVOT.TABLE.WIZARD",
          313: "PIVOT.FIELD.PROPERTIES",
          314: "PIVOT.FIELD",
          315: "PIVOT.ITEM",
          316: "PIVOT.ADD.FIELDS",
          318: "OPTIONS.CALCULATION",
          319: "OPTIONS.EDIT",
          320: "OPTIONS.VIEW",
          321: "ADDIN.MANAGER",
          322: "MENU.EDITOR",
          323: "ATTACH.TOOLBARS",
          324: "VBAActivate",
          325: "OPTIONS.CHART",
          328: "VBA.INSERT.FILE",
          330: "VBA.PROCEDURE.DEFINITION",
          336: "ROUTING.SLIP",
          338: "ROUTE.DOCUMENT",
          339: "MAIL.LOGON",
          342: "INSERT.PICTURE",
          343: "EDIT.TOOL",
          344: "GALLERY.DOUGHNUT",
          350: "CHART.TREND",
          352: "PIVOT.ITEM.PROPERTIES",
          354: "WORKBOOK.INSERT",
          355: "OPTIONS.TRANSITION",
          356: "OPTIONS.GENERAL",
          370: "FILTER.ADVANCED",
          373: "MAIL.ADD.MAILER",
          374: "MAIL.DELETE.MAILER",
          375: "MAIL.REPLY",
          376: "MAIL.REPLY.ALL",
          377: "MAIL.FORWARD",
          378: "MAIL.NEXT.LETTER",
          379: "DATA.LABEL",
          380: "INSERT.TITLE",
          381: "FONT.PROPERTIES",
          382: "MACRO.OPTIONS",
          383: "WORKBOOK.HIDE",
          384: "WORKBOOK.UNHIDE",
          385: "WORKBOOK.DELETE",
          386: "WORKBOOK.NAME",
          388: "GALLERY.CUSTOM",
          390: "ADD.CHART.AUTOFORMAT",
          391: "DELETE.CHART.AUTOFORMAT",
          392: "CHART.ADD.DATA",
          393: "AUTO.OUTLINE",
          394: "TAB.ORDER",
          395: "SHOW.DIALOG",
          396: "SELECT.ALL",
          397: "UNGROUP.SHEETS",
          398: "SUBTOTAL.CREATE",
          399: "SUBTOTAL.REMOVE",
          400: "RENAME.OBJECT",
          412: "WORKBOOK.SCROLL",
          413: "WORKBOOK.NEXT",
          414: "WORKBOOK.PREV",
          415: "WORKBOOK.TAB.SPLIT",
          416: "FULL.SCREEN",
          417: "WORKBOOK.PROTECT",
          420: "SCROLLBAR.PROPERTIES",
          421: "PIVOT.SHOW.PAGES",
          422: "TEXT.TO.COLUMNS",
          423: "FORMAT.CHARTTYPE",
          424: "LINK.FORMAT",
          425: "TRACER.DISPLAY",
          430: "TRACER.NAVIGATE",
          431: "TRACER.CLEAR",
          432: "TRACER.ERROR",
          433: "PIVOT.FIELD.GROUP",
          434: "PIVOT.FIELD.UNGROUP",
          435: "CHECKBOX.PROPERTIES",
          436: "LABEL.PROPERTIES",
          437: "LISTBOX.PROPERTIES",
          438: "EDITBOX.PROPERTIES",
          439: "PIVOT.REFRESH",
          440: "LINK.COMBO",
          441: "OPEN.TEXT",
          442: "HIDE.DIALOG",
          443: "SET.DIALOG.FOCUS",
          444: "ENABLE.OBJECT",
          445: "PUSHBUTTON.PROPERTIES",
          446: "SET.DIALOG.DEFAULT",
          447: "FILTER",
          448: "FILTER.SHOW.ALL",
          449: "CLEAR.OUTLINE",
          450: "FUNCTION.WIZARD",
          451: "ADD.LIST.ITEM",
          452: "SET.LIST.ITEM",
          453: "REMOVE.LIST.ITEM",
          454: "SELECT.LIST.ITEM",
          455: "SET.CONTROL.VALUE",
          456: "SAVE.COPY.AS",
          458: "OPTIONS.LISTS.ADD",
          459: "OPTIONS.LISTS.DELETE",
          460: "SERIES.AXES",
          461: "SERIES.X",
          462: "SERIES.Y",
          463: "ERRORBAR.X",
          464: "ERRORBAR.Y",
          465: "FORMAT.CHART",
          466: "SERIES.ORDER",
          467: "MAIL.LOGOFF",
          468: "CLEAR.ROUTING.SLIP",
          469: "APP.ACTIVATE.MICROSOFT",
          470: "MAIL.EDIT.MAILER",
          471: "ON.SHEET",
          472: "STANDARD.WIDTH",
          473: "SCENARIO.MERGE",
          474: "SUMMARY.INFO",
          475: "FIND.FILE",
          476: "ACTIVE.CELL.FONT",
          477: "ENABLE.TIPWIZARD",
          478: "VBA.MAKE.ADDIN",
          480: "INSERTDATATABLE",
          481: "WORKGROUP.OPTIONS",
          482: "MAIL.SEND.MAILER",
          485: "AUTOCORRECT",
          489: "POST.DOCUMENT",
          491: "PICKLIST",
          493: "VIEW.SHOW",
          494: "VIEW.DEFINE",
          495: "VIEW.DELETE",
          509: "SHEET.BACKGROUND",
          510: "INSERT.MAP.OBJECT",
          511: "OPTIONS.MENONO",
          517: "MSOCHECKS",
          518: "NORMAL",
          519: "LAYOUT",
          520: "RM.PRINT.AREA",
          521: "CLEAR.PRINT.AREA",
          522: "ADD.PRINT.AREA",
          523: "MOVE.BRK",
          545: "HIDECURR.NOTE",
          546: "HIDEALL.NOTES",
          547: "DELETE.NOTE",
          548: "TRAVERSE.NOTES",
          549: "ACTIVATE.NOTES",
          620: "PROTECT.REVISIONS",
          621: "UNPROTECT.REVISIONS",
          647: "OPTIONS.ME",
          653: "WEB.PUBLISH",
          667: "NEWWEBQUERY",
          673: "PIVOT.TABLE.CHART",
          753: "OPTIONS.SAVE",
          755: "OPTIONS.SPELL",
          808: "HIDEALL.INKANNOTS"
        }, i$ = {
          0: "COUNT",
          1: "IF",
          2: "ISNA",
          3: "ISERROR",
          4: "SUM",
          5: "AVERAGE",
          6: "MIN",
          7: "MAX",
          8: "ROW",
          9: "COLUMN",
          10: "NA",
          11: "NPV",
          12: "STDEV",
          13: "DOLLAR",
          14: "FIXED",
          15: "SIN",
          16: "COS",
          17: "TAN",
          18: "ATAN",
          19: "PI",
          20: "SQRT",
          21: "EXP",
          22: "LN",
          23: "LOG10",
          24: "ABS",
          25: "INT",
          26: "SIGN",
          27: "ROUND",
          28: "LOOKUP",
          29: "INDEX",
          30: "REPT",
          31: "MID",
          32: "LEN",
          33: "VALUE",
          34: "TRUE",
          35: "FALSE",
          36: "AND",
          37: "OR",
          38: "NOT",
          39: "MOD",
          40: "DCOUNT",
          41: "DSUM",
          42: "DAVERAGE",
          43: "DMIN",
          44: "DMAX",
          45: "DSTDEV",
          46: "VAR",
          47: "DVAR",
          48: "TEXT",
          49: "LINEST",
          50: "TREND",
          51: "LOGEST",
          52: "GROWTH",
          53: "GOTO",
          54: "HALT",
          55: "RETURN",
          56: "PV",
          57: "FV",
          58: "NPER",
          59: "PMT",
          60: "RATE",
          61: "MIRR",
          62: "IRR",
          63: "RAND",
          64: "MATCH",
          65: "DATE",
          66: "TIME",
          67: "DAY",
          68: "MONTH",
          69: "YEAR",
          70: "WEEKDAY",
          71: "HOUR",
          72: "MINUTE",
          73: "SECOND",
          74: "NOW",
          75: "AREAS",
          76: "ROWS",
          77: "COLUMNS",
          78: "OFFSET",
          79: "ABSREF",
          80: "RELREF",
          81: "ARGUMENT",
          82: "SEARCH",
          83: "TRANSPOSE",
          84: "ERROR",
          85: "STEP",
          86: "TYPE",
          87: "ECHO",
          88: "SET.NAME",
          89: "CALLER",
          90: "DEREF",
          91: "WINDOWS",
          92: "SERIES",
          93: "DOCUMENTS",
          94: "ACTIVE.CELL",
          95: "SELECTION",
          96: "RESULT",
          97: "ATAN2",
          98: "ASIN",
          99: "ACOS",
          100: "CHOOSE",
          101: "HLOOKUP",
          102: "VLOOKUP",
          103: "LINKS",
          104: "INPUT",
          105: "ISREF",
          106: "GET.FORMULA",
          107: "GET.NAME",
          108: "SET.VALUE",
          109: "LOG",
          110: "EXEC",
          111: "CHAR",
          112: "LOWER",
          113: "UPPER",
          114: "PROPER",
          115: "LEFT",
          116: "RIGHT",
          117: "EXACT",
          118: "TRIM",
          119: "REPLACE",
          120: "SUBSTITUTE",
          121: "CODE",
          122: "NAMES",
          123: "DIRECTORY",
          124: "FIND",
          125: "CELL",
          126: "ISERR",
          127: "ISTEXT",
          128: "ISNUMBER",
          129: "ISBLANK",
          130: "T",
          131: "N",
          132: "FOPEN",
          133: "FCLOSE",
          134: "FSIZE",
          135: "FREADLN",
          136: "FREAD",
          137: "FWRITELN",
          138: "FWRITE",
          139: "FPOS",
          140: "DATEVALUE",
          141: "TIMEVALUE",
          142: "SLN",
          143: "SYD",
          144: "DDB",
          145: "GET.DEF",
          146: "REFTEXT",
          147: "TEXTREF",
          148: "INDIRECT",
          149: "REGISTER",
          150: "CALL",
          151: "ADD.BAR",
          152: "ADD.MENU",
          153: "ADD.COMMAND",
          154: "ENABLE.COMMAND",
          155: "CHECK.COMMAND",
          156: "RENAME.COMMAND",
          157: "SHOW.BAR",
          158: "DELETE.MENU",
          159: "DELETE.COMMAND",
          160: "GET.CHART.ITEM",
          161: "DIALOG.BOX",
          162: "CLEAN",
          163: "MDETERM",
          164: "MINVERSE",
          165: "MMULT",
          166: "FILES",
          167: "IPMT",
          168: "PPMT",
          169: "COUNTA",
          170: "CANCEL.KEY",
          171: "FOR",
          172: "WHILE",
          173: "BREAK",
          174: "NEXT",
          175: "INITIATE",
          176: "REQUEST",
          177: "POKE",
          178: "EXECUTE",
          179: "TERMINATE",
          180: "RESTART",
          181: "HELP",
          182: "GET.BAR",
          183: "PRODUCT",
          184: "FACT",
          185: "GET.CELL",
          186: "GET.WORKSPACE",
          187: "GET.WINDOW",
          188: "GET.DOCUMENT",
          189: "DPRODUCT",
          190: "ISNONTEXT",
          191: "GET.NOTE",
          192: "NOTE",
          193: "STDEVP",
          194: "VARP",
          195: "DSTDEVP",
          196: "DVARP",
          197: "TRUNC",
          198: "ISLOGICAL",
          199: "DCOUNTA",
          200: "DELETE.BAR",
          201: "UNREGISTER",
          204: "USDOLLAR",
          205: "FINDB",
          206: "SEARCHB",
          207: "REPLACEB",
          208: "LEFTB",
          209: "RIGHTB",
          210: "MIDB",
          211: "LENB",
          212: "ROUNDUP",
          213: "ROUNDDOWN",
          214: "ASC",
          215: "DBCS",
          216: "RANK",
          219: "ADDRESS",
          220: "DAYS360",
          221: "TODAY",
          222: "VDB",
          223: "ELSE",
          224: "ELSE.IF",
          225: "END.IF",
          226: "FOR.CELL",
          227: "MEDIAN",
          228: "SUMPRODUCT",
          229: "SINH",
          230: "COSH",
          231: "TANH",
          232: "ASINH",
          233: "ACOSH",
          234: "ATANH",
          235: "DGET",
          236: "CREATE.OBJECT",
          237: "VOLATILE",
          238: "LAST.ERROR",
          239: "CUSTOM.UNDO",
          240: "CUSTOM.REPEAT",
          241: "FORMULA.CONVERT",
          242: "GET.LINK.INFO",
          243: "TEXT.BOX",
          244: "INFO",
          245: "GROUP",
          246: "GET.OBJECT",
          247: "DB",
          248: "PAUSE",
          251: "RESUME",
          252: "FREQUENCY",
          253: "ADD.TOOLBAR",
          254: "DELETE.TOOLBAR",
          255: "User",
          256: "RESET.TOOLBAR",
          257: "EVALUATE",
          258: "GET.TOOLBAR",
          259: "GET.TOOL",
          260: "SPELLING.CHECK",
          261: "ERROR.TYPE",
          262: "APP.TITLE",
          263: "WINDOW.TITLE",
          264: "SAVE.TOOLBAR",
          265: "ENABLE.TOOL",
          266: "PRESS.TOOL",
          267: "REGISTER.ID",
          268: "GET.WORKBOOK",
          269: "AVEDEV",
          270: "BETADIST",
          271: "GAMMALN",
          272: "BETAINV",
          273: "BINOMDIST",
          274: "CHIDIST",
          275: "CHIINV",
          276: "COMBIN",
          277: "CONFIDENCE",
          278: "CRITBINOM",
          279: "EVEN",
          280: "EXPONDIST",
          281: "FDIST",
          282: "FINV",
          283: "FISHER",
          284: "FISHERINV",
          285: "FLOOR",
          286: "GAMMADIST",
          287: "GAMMAINV",
          288: "CEILING",
          289: "HYPGEOMDIST",
          290: "LOGNORMDIST",
          291: "LOGINV",
          292: "NEGBINOMDIST",
          293: "NORMDIST",
          294: "NORMSDIST",
          295: "NORMINV",
          296: "NORMSINV",
          297: "STANDARDIZE",
          298: "ODD",
          299: "PERMUT",
          300: "POISSON",
          301: "TDIST",
          302: "WEIBULL",
          303: "SUMXMY2",
          304: "SUMX2MY2",
          305: "SUMX2PY2",
          306: "CHITEST",
          307: "CORREL",
          308: "COVAR",
          309: "FORECAST",
          310: "FTEST",
          311: "INTERCEPT",
          312: "PEARSON",
          313: "RSQ",
          314: "STEYX",
          315: "SLOPE",
          316: "TTEST",
          317: "PROB",
          318: "DEVSQ",
          319: "GEOMEAN",
          320: "HARMEAN",
          321: "SUMSQ",
          322: "KURT",
          323: "SKEW",
          324: "ZTEST",
          325: "LARGE",
          326: "SMALL",
          327: "QUARTILE",
          328: "PERCENTILE",
          329: "PERCENTRANK",
          330: "MODE",
          331: "TRIMMEAN",
          332: "TINV",
          334: "MOVIE.COMMAND",
          335: "GET.MOVIE",
          336: "CONCATENATE",
          337: "POWER",
          338: "PIVOT.ADD.DATA",
          339: "GET.PIVOT.TABLE",
          340: "GET.PIVOT.FIELD",
          341: "GET.PIVOT.ITEM",
          342: "RADIANS",
          343: "DEGREES",
          344: "SUBTOTAL",
          345: "SUMIF",
          346: "COUNTIF",
          347: "COUNTBLANK",
          348: "SCENARIO.GET",
          349: "OPTIONS.LISTS.GET",
          350: "ISPMT",
          351: "DATEDIF",
          352: "DATESTRING",
          353: "NUMBERSTRING",
          354: "ROMAN",
          355: "OPEN.DIALOG",
          356: "SAVE.DIALOG",
          357: "VIEW.GET",
          358: "GETPIVOTDATA",
          359: "HYPERLINK",
          360: "PHONETIC",
          361: "AVERAGEA",
          362: "MAXA",
          363: "MINA",
          364: "STDEVPA",
          365: "VARPA",
          366: "STDEVA",
          367: "VARA",
          368: "BAHTTEXT",
          369: "THAIDAYOFWEEK",
          370: "THAIDIGIT",
          371: "THAIMONTHOFYEAR",
          372: "THAINUMSOUND",
          373: "THAINUMSTRING",
          374: "THAISTRINGLENGTH",
          375: "ISTHAIDIGIT",
          376: "ROUNDBAHTDOWN",
          377: "ROUNDBAHTUP",
          378: "THAIYEAR",
          379: "RTD",
          380: "CUBEVALUE",
          381: "CUBEMEMBER",
          382: "CUBEMEMBERPROPERTY",
          383: "CUBERANKEDMEMBER",
          384: "HEX2BIN",
          385: "HEX2DEC",
          386: "HEX2OCT",
          387: "DEC2BIN",
          388: "DEC2HEX",
          389: "DEC2OCT",
          390: "OCT2BIN",
          391: "OCT2HEX",
          392: "OCT2DEC",
          393: "BIN2DEC",
          394: "BIN2OCT",
          395: "BIN2HEX",
          396: "IMSUB",
          397: "IMDIV",
          398: "IMPOWER",
          399: "IMABS",
          400: "IMSQRT",
          401: "IMLN",
          402: "IMLOG2",
          403: "IMLOG10",
          404: "IMSIN",
          405: "IMCOS",
          406: "IMEXP",
          407: "IMARGUMENT",
          408: "IMCONJUGATE",
          409: "IMAGINARY",
          410: "IMREAL",
          411: "COMPLEX",
          412: "IMSUM",
          413: "IMPRODUCT",
          414: "SERIESSUM",
          415: "FACTDOUBLE",
          416: "SQRTPI",
          417: "QUOTIENT",
          418: "DELTA",
          419: "GESTEP",
          420: "ISEVEN",
          421: "ISODD",
          422: "MROUND",
          423: "ERF",
          424: "ERFC",
          425: "BESSELJ",
          426: "BESSELK",
          427: "BESSELY",
          428: "BESSELI",
          429: "XIRR",
          430: "XNPV",
          431: "PRICEMAT",
          432: "YIELDMAT",
          433: "INTRATE",
          434: "RECEIVED",
          435: "DISC",
          436: "PRICEDISC",
          437: "YIELDDISC",
          438: "TBILLEQ",
          439: "TBILLPRICE",
          440: "TBILLYIELD",
          441: "PRICE",
          442: "YIELD",
          443: "DOLLARDE",
          444: "DOLLARFR",
          445: "NOMINAL",
          446: "EFFECT",
          447: "CUMPRINC",
          448: "CUMIPMT",
          449: "EDATE",
          450: "EOMONTH",
          451: "YEARFRAC",
          452: "COUPDAYBS",
          453: "COUPDAYS",
          454: "COUPDAYSNC",
          455: "COUPNCD",
          456: "COUPNUM",
          457: "COUPPCD",
          458: "DURATION",
          459: "MDURATION",
          460: "ODDLPRICE",
          461: "ODDLYIELD",
          462: "ODDFPRICE",
          463: "ODDFYIELD",
          464: "RANDBETWEEN",
          465: "WEEKNUM",
          466: "AMORDEGRC",
          467: "AMORLINC",
          468: "CONVERT",
          724: "SHEETJS",
          469: "ACCRINT",
          470: "ACCRINTM",
          471: "WORKDAY",
          472: "NETWORKDAYS",
          473: "GCD",
          474: "MULTINOMIAL",
          475: "LCM",
          476: "FVSCHEDULE",
          477: "CUBEKPIMEMBER",
          478: "CUBESET",
          479: "CUBESETCOUNT",
          480: "IFERROR",
          481: "COUNTIFS",
          482: "SUMIFS",
          483: "AVERAGEIF",
          484: "AVERAGEIFS"
        }, iG = {
          2: 1,
          3: 1,
          10: 0,
          15: 1,
          16: 1,
          17: 1,
          18: 1,
          19: 0,
          20: 1,
          21: 1,
          22: 1,
          23: 1,
          24: 1,
          25: 1,
          26: 1,
          27: 2,
          30: 2,
          31: 3,
          32: 1,
          33: 1,
          34: 0,
          35: 0,
          38: 1,
          39: 2,
          40: 3,
          41: 3,
          42: 3,
          43: 3,
          44: 3,
          45: 3,
          47: 3,
          48: 2,
          53: 1,
          61: 3,
          63: 0,
          65: 3,
          66: 3,
          67: 1,
          68: 1,
          69: 1,
          70: 1,
          71: 1,
          72: 1,
          73: 1,
          74: 0,
          75: 1,
          76: 1,
          77: 1,
          79: 2,
          80: 2,
          83: 1,
          85: 0,
          86: 1,
          89: 0,
          90: 1,
          94: 0,
          95: 0,
          97: 2,
          98: 1,
          99: 1,
          101: 3,
          102: 3,
          105: 1,
          106: 1,
          108: 2,
          111: 1,
          112: 1,
          113: 1,
          114: 1,
          117: 2,
          118: 1,
          119: 4,
          121: 1,
          126: 1,
          127: 1,
          128: 1,
          129: 1,
          130: 1,
          131: 1,
          133: 1,
          134: 1,
          135: 1,
          136: 2,
          137: 2,
          138: 2,
          140: 1,
          141: 1,
          142: 3,
          143: 4,
          144: 4,
          161: 1,
          162: 1,
          163: 1,
          164: 1,
          165: 2,
          172: 1,
          175: 2,
          176: 2,
          177: 3,
          178: 2,
          179: 1,
          184: 1,
          186: 1,
          189: 3,
          190: 1,
          195: 3,
          196: 3,
          197: 1,
          198: 1,
          199: 3,
          201: 1,
          207: 4,
          210: 3,
          211: 1,
          212: 2,
          213: 2,
          214: 1,
          215: 1,
          225: 0,
          229: 1,
          230: 1,
          231: 1,
          232: 1,
          233: 1,
          234: 1,
          235: 3,
          244: 1,
          247: 4,
          252: 2,
          257: 1,
          261: 1,
          271: 1,
          273: 4,
          274: 2,
          275: 2,
          276: 2,
          277: 3,
          278: 3,
          279: 1,
          280: 3,
          281: 3,
          282: 3,
          283: 1,
          284: 1,
          285: 2,
          286: 4,
          287: 3,
          288: 2,
          289: 4,
          290: 3,
          291: 3,
          292: 3,
          293: 4,
          294: 1,
          295: 3,
          296: 1,
          297: 3,
          298: 1,
          299: 2,
          300: 3,
          301: 3,
          302: 4,
          303: 2,
          304: 2,
          305: 2,
          306: 2,
          307: 2,
          308: 2,
          309: 3,
          310: 2,
          311: 2,
          312: 2,
          313: 2,
          314: 2,
          315: 2,
          316: 4,
          325: 2,
          326: 2,
          327: 2,
          328: 2,
          331: 2,
          332: 2,
          337: 2,
          342: 1,
          343: 1,
          346: 2,
          347: 1,
          350: 4,
          351: 3,
          352: 1,
          353: 2,
          360: 1,
          368: 1,
          369: 1,
          370: 1,
          371: 1,
          372: 1,
          373: 1,
          374: 1,
          375: 1,
          376: 1,
          377: 1,
          378: 1,
          382: 3,
          385: 1,
          392: 1,
          393: 1,
          396: 2,
          397: 2,
          398: 2,
          399: 1,
          400: 1,
          401: 1,
          402: 1,
          403: 1,
          404: 1,
          405: 1,
          406: 1,
          407: 1,
          408: 1,
          409: 1,
          410: 1,
          414: 4,
          415: 1,
          416: 1,
          417: 2,
          420: 1,
          421: 1,
          422: 2,
          424: 1,
          425: 2,
          426: 2,
          427: 2,
          428: 2,
          430: 3,
          438: 3,
          439: 3,
          440: 3,
          443: 2,
          444: 2,
          445: 2,
          446: 2,
          447: 6,
          448: 6,
          449: 2,
          450: 2,
          464: 2,
          468: 3,
          476: 2,
          479: 1,
          480: 2,
          65535: 0
        };
        function iX(e10) {
          return "of:" == e10.slice(0, 3) && (e10 = e10.slice(3)), 61 == e10.charCodeAt(0) && 61 == (e10 = e10.slice(1)).charCodeAt(0) && (e10 = e10.slice(1)), (e10 = (e10 = (e10 = (e10 = (e10 = e10.replace(/COM\.MICROSOFT\./g, "")).replace(
            /\[((?:\.[A-Z]+[0-9]+)(?::\.[A-Z]+[0-9]+)?)\]/g,
            function(e11, t10) {
              return t10.replace(/\./g, "");
            }
          )).replace(/\$'([^']|'')+'/g, function(e11) {
            return e11.slice(1);
          })).replace(/\$([^\]\. #$]+)/g, function(e11, t10) {
            return t10.match(
              /^([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])?(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})?$/
            ) ? e11 : t10;
          })).replace(/\[.(#[A-Z]*[?!])\]/g, "$1")).replace(/[;~]/g, ",").replace(/\|/g, ";");
        }
        function ij(e10) {
          var t10 = (e10 = (e10 = e10.replace(/\$'([^']|'')+'/g, function(e11) {
            return e11.slice(1);
          })).replace(/\$([^\]\. #$]+)/g, function(e11, t11) {
            return t11.match(
              /^([A-Z]{1,2}|[A-W][A-Z]{2}|X[A-E][A-Z]|XF[A-D])?(10[0-3]\d{4}|104[0-7]\d{3}|1048[0-4]\d{2}|10485[0-6]\d|104857[0-6]|[1-9]\d{0,5})?$/
            ) ? e11 : t11;
          })).split(":");
          return [
            t10[0].split(".")[0],
            t10[0].split(".")[1] + (t10.length > 1 ? ":" + (t10[1].split(".")[1] || t10[1].split(".")[0]) : "")
          ];
        }
        function iK(e10) {
          return e10.replace(/!/, ".").replace(/:/, ":.");
        }
        var iY = {}, iZ = {}, iJ = "undefined" != typeof Map;
        function iq(e10, t10, r10) {
          var a10 = 0, n10 = e10.length;
          if (r10) {
            if (iJ ? r10.has(t10) : Object.prototype.hasOwnProperty.call(r10, t10)) {
              for (var s10 = iJ ? r10.get(t10) : r10[t10]; a10 < s10.length; ++a10) if (e10[s10[a10]].t === t10) return e10.Count++, s10[a10];
            }
          } else for (; a10 < n10; ++a10) if (e10[a10].t === t10) return e10.Count++, a10;
          return e10[n10] = { t: t10 }, e10.Count++, e10.Unique++, r10 && (iJ ? (r10.has(t10) || r10.set(t10, []), r10.get(t10).push(n10)) : (Object.prototype.hasOwnProperty.call(r10, t10) || (r10[t10] = []), r10[t10].push(n10))), n10;
        }
        function iQ(e10, t10) {
          var r10 = { min: e10 + 1, max: e10 + 1 }, a10 = -1;
          return t10.MDW && (sK = t10.MDW), null != t10.width ? r10.customWidth = 1 : null != t10.wpx ? a10 = sZ(t10.wpx) : null != t10.wch && (a10 = t10.wch), a10 > -1 ? (r10.width = sJ(a10), r10.customWidth = 1) : null != t10.width && (r10.width = t10.width), t10.hidden && (r10.hidden = true), null != t10.level && (r10.outlineLevel = r10.level = t10.level), r10;
        }
        function i0(e10, t10) {
          if (e10) {
            var r10 = [0.7, 0.7, 0.75, 0.75, 0.3, 0.3];
            "xlml" == t10 && (r10 = [1, 1, 1, 1, 0.5, 0.5]), null == e10.left && (e10.left = r10[0]), null == e10.right && (e10.right = r10[1]), null == e10.top && (e10.top = r10[2]), null == e10.bottom && (e10.bottom = r10[3]), null == e10.header && (e10.header = r10[4]), null == e10.footer && (e10.footer = r10[5]);
          }
        }
        function i1(e10, t10, r10) {
          var a10 = r10.revssf[null != t10.z ? t10.z : "General"], n10 = 60, s10 = e10.length;
          if (null == a10 && r10.ssf) {
            for (; n10 < 392; ++n10)
              if (null == r10.ssf[n10]) {
                te(t10.z, n10), r10.ssf[n10] = t10.z, r10.revssf[t10.z] = a10 = n10;
                break;
              }
          }
          for (n10 = 0; n10 != s10; ++n10) if (e10[n10].numFmtId === a10) return n10;
          return e10[s10] = { numFmtId: a10, fontId: 0, fillId: 0, borderId: 0, xfId: 0, applyNumberFormat: 1 }, s10;
        }
        function i2(e10, t10, r10, a10, n10, s10, i10) {
          try {
            a10.cellNF && (e10.z = eD[t10]);
          } catch (e11) {
            if (a10.WTF) throw e11;
          }
          if ("z" !== e10.t || a10.cellStyles) {
            if ("d" === e10.t && "string" == typeof e10.v && (e10.v = tv(e10.v)), (!a10 || false !== a10.cellText) && "z" !== e10.t)
              try {
                if (null == eD[t10] && te(e8[t10] || "General", t10), "e" === e10.t) e10.w = e10.w || aQ[e10.v];
                else if (0 === t10)
                  if ("n" === e10.t) (0 | e10.v) === e10.v ? e10.w = e10.v.toString(10) : e10.w = eW(e10.v);
                  else if ("d" === e10.t) {
                    var o10 = tu(e10.v, !!i10);
                    (0 | o10) === o10 ? e10.w = o10.toString(10) : e10.w = eW(o10);
                  } else {
                    if (void 0 === e10.v) return "";
                    e10.w = ez(e10.v, iZ);
                  }
                else "d" === e10.t ? e10.w = e22(t10, tu(e10.v, !!i10), iZ) : e10.w = e22(t10, e10.v, iZ);
              } catch (e11) {
                if (a10.WTF) throw e11;
              }
            if (a10.cellStyles && null != r10)
              try {
                e10.s = s10.Fills[r10], e10.s.fgColor && e10.s.fgColor.theme && !e10.s.fgColor.rgb && (e10.s.fgColor.rgb = sj(n10.themeElements.clrScheme[e10.s.fgColor.theme].rgb, e10.s.fgColor.tint || 0), a10.WTF && (e10.s.fgColor.raw_rgb = n10.themeElements.clrScheme[e10.s.fgColor.theme].rgb)), e10.s.bgColor && e10.s.bgColor.theme && (e10.s.bgColor.rgb = sj(n10.themeElements.clrScheme[e10.s.bgColor.theme].rgb, e10.s.bgColor.tint || 0), a10.WTF && (e10.s.bgColor.raw_rgb = n10.themeElements.clrScheme[e10.s.bgColor.theme].rgb));
              } catch (e11) {
                if (a10.WTF && s10.Fills) throw e11;
              }
          }
        }
        var i4 = /<(?:\w+:)?mergeCell ref=["'][A-Z0-9:]+['"]\s*[\/]?>/g, i3 = /<(?:\w+:)?hyperlink [^<>]*>/gm, i5 = /"(\w*:\w*)"/, i6 = /<(?:\w+:)?col\b[^<>]*[\/]?>/g, i8 = /<(?:\w+:)?autoFilter[^>]*/g, i7 = /<(?:\w+:)?pageMargins[^<>]*\/>/g, i9 = /<(?:\w+:)?sheetPr\b[^<>]*?\/>/;
        function oe(e10, t10, r10, a10) {
          var n10 = t4(e10);
          r10.Sheets[a10] || (r10.Sheets[a10] = {}), n10.codeName && (r10.Sheets[a10].CodeName = t8(rf(n10.codeName)));
        }
        var ot = ["objects", "scenarios", "selectLockedCells", "selectUnlockedCells"], or = [
          "formatColumns",
          "formatRows",
          "formatCells",
          "insertColumns",
          "insertRows",
          "insertHyperlinks",
          "deleteColumns",
          "deleteRows",
          "sort",
          "autoFilter",
          "pivotTables"
        ], oa = /<(?:\w:)?sheetView(?:[^<>a-z][^<>]*)?\/?>/g, on = (P = /<(?:\w+:)?c[ \/>]/, L = /<\/(?:\w+:)?row>/, M = /r=["']([^"']*)["']/, U = /ref=["']([^"']*)["']/, function(e10, t10, r10, a10, n10, s10, i10) {
          for (var o10, c10, l2, f2, h2, u2 = 0, d2 = "", p2 = [], m2 = [], g2 = 0, v2 = 0, b2 = 0, w2 = "", T2 = 0, y2 = 0, E2 = 0, k2 = 0, x2 = Array.isArray(s10.CellXf), _2 = [], S2 = [], A2 = null != t10["!data"], C2 = [], I2 = {}, O2 = false, R2 = !!r10.sheetStubs, N2 = !!((i10 || {}).WBProps || {}).date1904, F2 = e10.split(L), D2 = 0, B2 = F2.length; D2 != B2; ++D2) {
            var W2 = (d2 = F2[D2].trim()).length;
            if (0 !== W2) {
              var z2 = 0;
              t: for (u2 = 0; u2 < W2; ++u2)
                switch (d2[u2]) {
                  case ">":
                    if ("/" != d2[u2 - 1]) {
                      ++u2;
                      break t;
                    }
                    if (r10 && r10.cellStyles) {
                      if (T2 = null != (c10 = t4(d2.slice(z2, u2), true)).r ? parseInt(c10.r, 10) : T2 + 1, y2 = -1, r10.sheetRows && r10.sheetRows < T2)
                        continue;
                      I2 = {}, O2 = false, c10.ht && (O2 = true, I2.hpt = parseFloat(c10.ht), I2.hpx = s2(I2.hpt)), c10.hidden && rs(c10.hidden) && (O2 = true, I2.hidden = true), null != c10.outlineLevel && (O2 = true, I2.level = +c10.outlineLevel), O2 && (C2[T2 - 1] = I2);
                    }
                    break;
                  case "<":
                    z2 = u2;
                }
              if (z2 >= u2) break;
              if (T2 = null != (c10 = t4(d2.slice(z2, u2), true)).r ? parseInt(c10.r, 10) : T2 + 1, y2 = -1, !r10.sheetRows || !(r10.sheetRows < T2)) {
                !r10.nodim && (a10.s.r > T2 - 1 && (a10.s.r = T2 - 1), a10.e.r < T2 - 1 && (a10.e.r = T2 - 1)), r10 && r10.cellStyles && (I2 = {}, O2 = false, c10.ht && (O2 = true, I2.hpt = parseFloat(c10.ht), I2.hpx = s2(I2.hpt)), c10.hidden && rs(c10.hidden) && (O2 = true, I2.hidden = true), null != c10.outlineLevel && (O2 = true, I2.level = +c10.outlineLevel), O2 && (C2[T2 - 1] = I2)), p2 = d2.slice(u2).split(P);
                for (var H2 = 0; H2 != p2.length && "<" == p2[H2].trim().charAt(0); ++H2) ;
                for (u2 = 0, p2 = p2.slice(H2); u2 != p2.length; ++u2)
                  if (0 !== (d2 = p2[u2].trim()).length) {
                    if (m2 = d2.match(M), g2 = u2, v2 = 0, b2 = 0, d2 = "<c " + ("<" == d2.slice(0, 1) ? ">" : "") + d2, null != m2 && 2 === m2.length) {
                      for (v2 = 0, g2 = 0, w2 = m2[1]; v2 != w2.length && !((b2 = w2.charCodeAt(v2) - 64) < 1) && !(b2 > 26); ++v2)
                        g2 = 26 * g2 + b2;
                      y2 = --g2;
                    } else ++y2;
                    for (v2 = 0; v2 != d2.length && 62 !== d2.charCodeAt(v2); ++v2) ;
                    if (++v2, (c10 = t4(d2.slice(0, v2), true)).r || (c10.r = ab({ r: T2 - 1, c: y2 })), w2 = d2.slice(v2), o10 = { t: "" }, null != (m2 = tL(w2, "v")) && "" !== m2[1] && (o10.v = t8(m2[1])), r10.cellFormula) {
                      if (null != (m2 = tL(w2, "f"))) {
                        if ("" == m2[1])
                          m2[0].indexOf('t="shared"') > -1 && S2[(f2 = t4(m2[0])).si] && (o10.f = ig(S2[f2.si][1], S2[f2.si][2], c10.r));
                        else if (o10.f = t8(rf(m2[1]), true), r10.xlfn || (o10.f = iv(o10.f)), m2[0].indexOf('t="array"') > -1)
                          o10.F = (w2.match(U) || [])[1], o10.F.indexOf(":") > -1 && _2.push([ak(o10.F), o10.F]);
                        else if (m2[0].indexOf('t="shared"') > -1) {
                          f2 = t4(m2[0]);
                          var V2, G2 = t8(rf(m2[1]));
                          r10.xlfn || (G2 = iv(G2)), S2[parseInt(f2.si, 10)] = [f2, G2, c10.r];
                        }
                      } else
                        (m2 = w2.match(/<f[^<>]*\/>/)) && S2[(f2 = t4(m2[0])).si] && (o10.f = ig(S2[f2.si][1], S2[f2.si][2], c10.r));
                      var X2 = av(c10.r);
                      for (v2 = 0; v2 < _2.length; ++v2)
                        X2.r >= _2[v2][0].s.r && X2.r <= _2[v2][0].e.r && X2.c >= _2[v2][0].s.c && X2.c <= _2[v2][0].e.c && (o10.F = _2[v2][1]);
                    }
                    if (null == c10.t && void 0 === o10.v)
                      if (o10.f || o10.F) o10.v = 0, o10.t = "n";
                      else {
                        if (!R2) continue;
                        o10.t = "z";
                      }
                    else o10.t = c10.t || "n";
                    switch (a10.s.c > y2 && (a10.s.c = y2), a10.e.c < y2 && (a10.e.c = y2), o10.t) {
                      case "n":
                        if ("" == o10.v || null == o10.v) {
                          if (!R2) continue;
                          o10.t = "z";
                        } else o10.v = parseFloat(o10.v);
                        break;
                      case "s":
                        if (void 0 === o10.v) {
                          if (!R2) continue;
                          o10.t = "z";
                        } else l2 = iY[parseInt(o10.v, 10)], o10.v = l2.t, o10.r = l2.r, r10.cellHTML && (o10.h = l2.h);
                        break;
                      case "str":
                        o10.t = "s", o10.v = null != o10.v ? t8(rf(o10.v), true) : "", r10.cellHTML && (o10.h = ra(o10.v));
                        break;
                      case "inlineStr":
                        m2 = tL(w2, "is"), o10.t = "s", null != m2 && (l2 = sN(m2[1])) ? (o10.v = l2.t, r10.cellHTML && (o10.h = l2.h)) : o10.v = "";
                        break;
                      case "b":
                        o10.v = rs(o10.v);
                        break;
                      case "d":
                        r10.cellDates ? o10.v = tv(o10.v, N2) : (o10.v = tu(tv(o10.v, N2), N2), o10.t = "n");
                        break;
                      case "e":
                        r10 && false === r10.cellText || (o10.w = o10.v), o10.v = a0[o10.v];
                    }
                    if (E2 = k2 = 0, h2 = null, x2 && void 0 !== c10.s && null != (h2 = s10.CellXf[c10.s]) && (null != h2.numFmtId && (E2 = h2.numFmtId), r10.cellStyles && null != h2.fillId && (k2 = h2.fillId)), i2(o10, E2, k2, r10, n10, s10, N2), r10.cellDates && x2 && "n" == o10.t && eQ(eD[E2]) && (o10.v = td(o10.v + 1462 * !!N2), o10.t = "number" == typeof o10.v ? "n" : "d"), c10.cm && r10.xlmeta) {
                      var j2 = (r10.xlmeta.Cell || [])[c10.cm - 1];
                      j2 && "XLDAPR" == j2.type && (o10.D = true);
                    }
                    r10.nodim && (V2 = av(c10.r), a10.s.r > V2.r && (a10.s.r = V2.r), a10.e.r < V2.r && (a10.e.r = V2.r)), A2 ? (V2 = av(c10.r), t10["!data"][V2.r] || (t10["!data"][V2.r] = []), t10["!data"][V2.r][V2.c] = o10) : t10[c10.r] = o10;
                  }
              }
            }
          }
          C2.length > 0 && (t10["!rows"] = C2);
        });
        function os(e10, t10, r10) {
          return null == r10 && (r10 = as(9)), aD(t10, r10), r10.write_shift(1, e10.v), r10;
        }
        function oi(e10, t10, r10) {
          return null == r10 && (r10 = as(8)), aL(t10, r10), r10.write_shift(1, e10.v), r10.write_shift(2, 0), r10.write_shift(1, 0), r10;
        }
        function oo(e10) {
          return [aP(e10), aV(e10), "n"];
        }
        var oc = ["left", "right", "top", "bottom", "header", "footer"], ol = [
          ["allowRefreshQuery", false, "bool"],
          ["autoCompressPictures", true, "bool"],
          ["backupFile", false, "bool"],
          ["checkCompatibility", false, "bool"],
          ["CodeName", ""],
          ["date1904", false, "bool"],
          ["defaultThemeVersion", 0, "int"],
          ["filterPrivacy", false, "bool"],
          ["hidePivotFieldList", false, "bool"],
          ["promptedSolutions", false, "bool"],
          ["publishItems", false, "bool"],
          ["refreshAllConnections", false, "bool"],
          ["saveExternalLinkValues", true, "bool"],
          ["showBorderUnselectedTables", true, "bool"],
          ["showInkAnnotation", true, "bool"],
          ["showObjects", "all"],
          ["showPivotChartFilter", false, "bool"],
          ["updateLinks", "userSet"]
        ], of = [
          ["activeTab", 0, "int"],
          ["autoFilterDateGrouping", true, "bool"],
          ["firstSheet", 0, "int"],
          ["minimized", false, "bool"],
          ["showHorizontalScroll", true, "bool"],
          ["showSheetTabs", true, "bool"],
          ["showVerticalScroll", true, "bool"],
          ["tabRatio", 600, "int"],
          ["visibility", "visible"]
        ], oh = [], ou = [
          ["calcCompleted", "true"],
          ["calcMode", "auto"],
          ["calcOnSave", "true"],
          ["concurrentCalc", "true"],
          ["fullCalcOnLoad", "false"],
          ["fullPrecision", "true"],
          ["iterate", "false"],
          ["iterateCount", "100"],
          ["iterateDelta", "0.001"],
          ["refMode", "A1"]
        ];
        function od(e10, t10) {
          for (var r10 = 0; r10 != e10.length; ++r10)
            for (var a10 = e10[r10], n10 = 0; n10 != t10.length; ++n10) {
              var s10 = t10[n10];
              if (null == a10[s10[0]]) a10[s10[0]] = s10[1];
              else
                switch (s10[2]) {
                  case "bool":
                    "string" == typeof a10[s10[0]] && (a10[s10[0]] = rs(a10[s10[0]]));
                    break;
                  case "int":
                    "string" == typeof a10[s10[0]] && (a10[s10[0]] = parseInt(a10[s10[0]], 10));
                }
            }
        }
        function op(e10, t10) {
          for (var r10 = 0; r10 != t10.length; ++r10) {
            var a10 = t10[r10];
            if (null == e10[a10[0]]) e10[a10[0]] = a10[1];
            else
              switch (a10[2]) {
                case "bool":
                  "string" == typeof e10[a10[0]] && (e10[a10[0]] = rs(e10[a10[0]]));
                  break;
                case "int":
                  "string" == typeof e10[a10[0]] && (e10[a10[0]] = parseInt(e10[a10[0]], 10));
              }
          }
        }
        function om(e10) {
          op(e10.WBProps, ol), op(e10.CalcPr, ou), od(e10.WBView, of), od(e10.Sheets, oh), iZ.date1904 = rs(e10.WBProps.date1904);
        }
        var og = ":][*?/\\".split("");
        function ov(e10, t10) {
          try {
            if ("" == e10) throw Error("Sheet name cannot be blank");
            if (e10.length > 31) throw Error("Sheet name cannot exceed 31 chars");
            if (39 == e10.charCodeAt(0) || 39 == e10.charCodeAt(e10.length - 1))
              throw Error("Sheet name cannot start or end with apostrophe (')");
            if ("history" == e10.toLowerCase()) throw Error("Sheet name cannot be 'History'");
            og.forEach(function(t11) {
              if (-1 != e10.indexOf(t11)) throw Error("Sheet name cannot contain : \\ / ? * [ ]");
            });
          } catch (e11) {
            if (t10) return false;
            throw e11;
          }
          return true;
        }
        function ob(e10) {
          if (!e10 || !e10.SheetNames || !e10.Sheets) throw Error("Invalid Workbook");
          if (!e10.SheetNames.length) throw Error("Workbook is empty");
          var t10, r10, a10 = e10.Workbook && e10.Workbook.Sheets || [];
          t10 = e10.SheetNames, r10 = !!e10.vbaraw, t10.forEach(function(e11, n11) {
            ov(e11);
            for (var s10 = 0; s10 < n11; ++s10) if (e11 == t10[s10]) throw Error("Duplicate Sheet Name: " + e11);
            if (r10) {
              var i10 = a10 && a10[n11] && a10[n11].CodeName || e11;
              if (95 == i10.charCodeAt(0) && i10.length > 22) throw Error("Bad Code Name: Worksheet" + i10);
            }
          });
          for (var n10 = 0; n10 < e10.SheetNames.length; ++n10)
            !(function(e11, t11, r11) {
              if (e11 && e11["!ref"]) {
                var a11 = ak(e11["!ref"]);
                if (a11.e.c < a11.s.c || a11.e.r < a11.s.r) throw Error("Bad range (" + r11 + "): " + e11["!ref"]);
              }
            })(e10.Sheets[e10.SheetNames[n10]], e10.SheetNames[n10], n10);
          e10.SheetNames.forEach(function(t11, r11) {
            var a11, n11 = e10.Sheets[t11];
            if (n11 && n11["!autofilter"]) {
              e10.Workbook || (e10.Workbook = {}), e10.Workbook.Names || (e10.Workbook.Names = []), e10.Workbook.Names.forEach(function(e11) {
                "_xlnm._FilterDatabase" == e11.Name && e11.Sheet == r11 && (a11 = e11);
              });
              var s10 = aE(t11) + "!" + ay(n11["!autofilter"].ref);
              a11 ? a11.Ref = s10 : e10.Workbook.Names.push({ Name: "_xlnm._FilterDatabase", Sheet: r11, Ref: s10 });
            }
          });
        }
        var ow = /<\w+:workbook/;
        function oT(e10, t10) {
          var r10 = {};
          return e10.read_shift(4), r10.ArchID = e10.read_shift(4), e10.l += t10 - 8, r10;
        }
        var oy = /\b((?:\w+:)?[\w]+)=((?:")([^"]*)(?:")|(?:')([^']*)(?:'))/g, oE = /\b((?:\w+:)?[\w]+)=((?:")(?:[^"]*)(?:")|(?:')(?:[^']*)(?:'))/;
        function ok(e10, t10) {
          var r10 = e10.split(/\s+/), a10 = [];
          if (t10 || (a10[0] = r10[0]), 1 === r10.length) return a10;
          var n10, s10, i10, o10 = e10.match(oy);
          if (o10)
            for (i10 = 0; i10 != o10.length; ++i10)
              -1 === (s10 = (n10 = o10[i10].match(oE))[1].indexOf(":")) ? a10[n10[1]] = n10[2].slice(1, n10[2].length - 1) : a10["xmlns:" === n10[1].slice(0, 6) ? "xmlns" + n10[1].slice(6) : n10[1].slice(s10 + 1)] = n10[2].slice(
                1,
                n10[2].length - 1
              );
          return a10;
        }
        function ox(e10, t10) {
          var r10, a10, n10, s10 = t10 || {};
          e5();
          var i10 = eo(ry(e10));
          ("binary" == s10.type || "array" == s10.type || "base64" == s10.type) && (i10 = void 0 !== G ? G.utils.decode(65001, en(i10)) : rf(i10));
          var o10 = i10.slice(0, 1024).toLowerCase(), c10 = false;
          if ((1023 & (o10 = o10.replace(/".*?"/g, "")).indexOf(">")) > Math.min(1023 & o10.indexOf(","), 1023 & o10.indexOf(";"))) {
            var l2 = tw(s10);
            return l2.type = "string", sS.to_workbook(i10, l2);
          }
          if (-1 == o10.indexOf("<?xml") && ["html", "table", "head", "meta", "script", "style", "div"].forEach(function(e11) {
            o10.indexOf("<" + e11) >= 0 && (c10 = true);
          }), c10) {
            var f2 = i10, h2 = s10, u2 = tB(f2, "table");
            if (!u2 || 0 == u2.length) throw Error("Invalid HTML: could not find <table>");
            if (1 == u2.length) {
              var d2 = aS(oY(u2[0], h2), h2);
              return d2.bookType = "html", d2;
            }
            var p2 = c9();
            return u2.forEach(function(e11, t11) {
              le(p2, oY(e11, h2), "Sheet" + (t11 + 1));
            }), p2.bookType = "html", p2;
          }
          Y = {
            "General Number": "General",
            "General Date": eD[22],
            "Long Date": "dddd, mmmm dd, yyyy",
            "Medium Date": eD[15],
            "Short Date": eD[14],
            "Long Time": eD[19],
            "Medium Time": eD[18],
            "Short Time": eD[20],
            Currency: '"$"#,##0.00_);[Red]\\("$"#,##0.00\\)',
            Fixed: eD[2],
            Standard: eD[4],
            Percent: eD[10],
            Scientific: eD[11],
            "Yes/No": '"Yes";"Yes";"No";@',
            "True/False": '"True";"True";"False";@',
            "On/Off": '"Yes";"Yes";"No";@'
          };
          var m2, g2, v2 = [], b2 = {}, w2 = [], T2 = {}, y2 = "";
          s10.dense && (T2["!data"] = []);
          var E2, k2 = {}, x2 = {}, _2 = ok('<Data ss:Type="String">'), S2 = 0, A2 = 0, C2 = 0, I2 = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, O2 = {}, R2 = {}, N2 = "", F2 = 0, D2 = [], P2 = {}, L2 = {}, M2 = 0, U2 = [], B2 = [], W2 = {}, z2 = [], H2 = false, V2 = [], X2 = [], K2 = {}, Z2 = 0, J2 = 0, q2 = { Sheets: [], WBProps: { date1904: false } }, Q2 = {};
          rE.lastIndex = 0, i10 = tF(i10, "<!--", "-->");
          for (var ee2 = ""; m2 = rE.exec(i10); )
            switch (m2[3] = (ee2 = m2[3]).toLowerCase()) {
              case "data":
                if ("data" == ee2) {
                  if ("/" === m2[1]) {
                    if ((g2 = v2.pop())[0] !== m2[3]) throw Error("Bad state: " + g2.join("|"));
                  } else "/" !== m2[0].charAt(m2[0].length - 2) && v2.push([m2[3], true]);
                  break;
                }
                if (v2[v2.length - 1][1]) break;
                "/" === m2[1] ? (function(e11, t11, r11, a11, n11, s11, i11, o11, c11, l3, f3) {
                  var h3 = "General", u3 = a11.StyleID, d3 = {};
                  l3 = l3 || {};
                  var p3 = [], m3 = 0;
                  for (void 0 === u3 && o11 && (u3 = o11.StyleID), void 0 === u3 && i11 && (u3 = i11.StyleID); void 0 !== s11[u3]; ) {
                    var g3 = s11[u3];
                    if (g3.nf && (h3 = g3.nf), g3.Interior && p3.push(g3.Interior), !g3.Parent) break;
                    u3 = g3.Parent;
                  }
                  switch (r11.Type) {
                    case "Boolean":
                      a11.t = "b", a11.v = rs(e11);
                      break;
                    case "String":
                      a11.t = "s", a11.r = rn(t8(e11)), a11.v = e11.indexOf("<") > -1 ? t8(t11 || e11).replace(/<[^<>]*>/g, "") : a11.r;
                      break;
                    case "DateTime":
                      "Z" != e11.slice(-1) && (e11 += "Z"), a11.v = tu(tv(e11, f3), f3), a11.v != a11.v && (a11.v = t8(e11)), h3 && "General" != h3 || (h3 = "yyyy-mm-dd");
                    case "Number":
                      void 0 === a11.v && (a11.v = +e11), a11.t || (a11.t = "n");
                      break;
                    case "Error":
                      a11.t = "e", a11.v = a0[e11], false !== l3.cellText && (a11.w = e11);
                      break;
                    default:
                      "" == e11 && "" == t11 ? a11.t = "z" : (a11.t = "s", a11.v = rn(t11 || e11));
                  }
                  if (!(function(e12, t12, r12, a12) {
                    if ("z" !== e12.t) {
                      if (!r12 || false !== r12.cellText)
                        try {
                          if ("e" === e12.t) e12.w = e12.w || aQ[e12.v];
                          else if ("General" === t12)
                            "n" === e12.t ? (0 | e12.v) === e12.v ? e12.w = e12.v.toString(10) : e12.w = eW(e12.v) : e12.w = ez(e12.v);
                          else {
                            var n12, s12, i12;
                            n12 = t12 || "General", s12 = e12.v, i12 = Y[n12] || t8(n12), e12.w = "General" === i12 ? ez(s12) : e22(i12, s12, { date1904: !!a12 });
                          }
                        } catch (e13) {
                          if (r12.WTF) throw e13;
                        }
                      try {
                        var o12 = Y[t12] || t12 || "General";
                        if (r12.cellNF && (e12.z = o12), r12.cellDates && "n" == e12.t && eQ(o12)) {
                          var c12 = eU(e12.v + 1462 * !!a12);
                          c12 && (e12.t = "d", e12.v = new Date(Date.UTC(c12.y, c12.m - 1, c12.d, c12.H, c12.M, c12.S, c12.u)));
                        }
                      } catch (e13) {
                        if (r12.WTF) throw e13;
                      }
                    }
                  })(a11, h3, l3, f3), false !== l3.cellFormula)
                    if (a11.Formula) {
                      var v3 = t8(a11.Formula);
                      61 == v3.charCodeAt(0) && (v3 = v3.slice(1)), a11.f = iu(v3, n11), delete a11.Formula, "RC" == a11.ArrayRange ? a11.F = iu("RC:RC", n11) : a11.ArrayRange && (a11.F = iu(a11.ArrayRange, n11), c11.push([ak(a11.F), a11.F]));
                    } else
                      for (m3 = 0; m3 < c11.length; ++m3)
                        n11.r >= c11[m3][0].s.r && n11.r <= c11[m3][0].e.r && n11.c >= c11[m3][0].s.c && n11.c <= c11[m3][0].e.c && (a11.F = c11[m3][1]);
                  l3.cellStyles && (p3.forEach(function(e12) {
                    !d3.patternType && e12.patternType && (d3.patternType = e12.patternType);
                  }), a11.s = d3), void 0 !== a11.StyleID && (a11.ixfe = a11.StyleID);
                })(
                  i10.slice(S2, m2.index),
                  N2,
                  _2,
                  "comment" == v2[v2.length - 1][0] ? W2 : k2,
                  { c: A2, r: C2 },
                  O2,
                  z2[A2],
                  x2,
                  V2,
                  s10,
                  q2.WBProps.date1904
                ) : (N2 = "", _2 = ok(m2[0]), S2 = m2.index + m2[0].length);
                break;
              case "cell":
                if ("/" === m2[1])
                  if (B2.length > 0 && (k2.c = B2), (!s10.sheetRows || s10.sheetRows > C2) && void 0 !== k2.v && (s10.dense ? (T2["!data"][C2] || (T2["!data"][C2] = []), T2["!data"][C2][A2] = k2) : T2[ag(A2) + ap(C2)] = k2), k2.HRef && (k2.l = { Target: t8(k2.HRef) }, k2.HRefScreenTip && (k2.l.Tooltip = k2.HRefScreenTip), delete k2.HRef, delete k2.HRefScreenTip), (k2.MergeAcross || k2.MergeDown) && (Z2 = A2 + (0 | parseInt(k2.MergeAcross, 10)), J2 = C2 + (0 | parseInt(k2.MergeDown, 10)), (Z2 > A2 || J2 > C2) && D2.push({ s: { c: A2, r: C2 }, e: { c: Z2, r: J2 } })), s10.sheetStubs)
                    if (k2.MergeAcross || k2.MergeDown) {
                      for (var et2 = A2; et2 <= Z2; ++et2)
                        for (var er2 = C2; er2 <= J2; ++er2)
                          (et2 > A2 || er2 > C2) && (s10.dense ? (T2["!data"][er2] || (T2["!data"][er2] = []), T2["!data"][er2][et2] = { t: "z" }) : T2[ag(et2) + ap(er2)] = { t: "z" });
                      A2 = Z2 + 1;
                    } else ++A2;
                  else k2.MergeAcross ? A2 = Z2 + 1 : ++A2;
                else
                  (k2 = (function(e11) {
                    var t11 = e11.split(/\s+/), r11 = {};
                    if (1 === t11.length) return r11;
                    var a11, n11, s11, i11 = e11.match(oy);
                    if (i11)
                      for (s11 = 0; s11 != i11.length; ++s11)
                        -1 === (n11 = (a11 = i11[s11].match(oE))[1].indexOf(":")) ? r11[a11[1]] = a11[2].slice(1, a11[2].length - 1) : r11["xmlns:" === a11[1].slice(0, 6) ? "xmlns" + a11[1].slice(6) : a11[1].slice(n11 + 1)] = a11[2].slice(1, a11[2].length - 1);
                    return r11;
                  })(m2[0])).Index && (A2 = k2.Index - 1), A2 < I2.s.c && (I2.s.c = A2), A2 > I2.e.c && (I2.e.c = A2), "/>" === m2[0].slice(-2) && ++A2, B2 = [];
                break;
              case "row":
                "/" === m2[1] || "/>" === m2[0].slice(-2) ? (C2 < I2.s.r && (I2.s.r = C2), C2 > I2.e.r && (I2.e.r = C2), "/>" === m2[0].slice(-2) && (x2 = ok(m2[0])).Index && (C2 = x2.Index - 1), A2 = 0, ++C2) : ((x2 = ok(m2[0])).Index && (C2 = x2.Index - 1), K2 = {}, ("0" == x2.AutoFitHeight || x2.Height) && (K2.hpx = parseInt(x2.Height, 10), K2.hpt = s1(K2.hpx), X2[C2] = K2), "1" == x2.Hidden && (K2.hidden = true, X2[C2] = K2));
                break;
              case "worksheet":
                if ("/" === m2[1]) {
                  if ((g2 = v2.pop())[0] !== m2[3]) throw Error("Bad state: " + g2.join("|"));
                  w2.push(y2), I2.s.r <= I2.e.r && I2.s.c <= I2.e.c && (T2["!ref"] = aT(I2), s10.sheetRows && s10.sheetRows <= I2.e.r && (T2["!fullref"] = T2["!ref"], I2.e.r = s10.sheetRows - 1, T2["!ref"] = aT(I2))), D2.length && (T2["!merges"] = D2), z2.length > 0 && (T2["!cols"] = z2), X2.length > 0 && (T2["!rows"] = X2), b2[y2] = T2;
                } else
                  I2 = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, C2 = A2 = 0, v2.push([m2[3], false]), y2 = t8((g2 = ok(m2[0])).Name), T2 = {}, s10.dense && (T2["!data"] = []), D2 = [], V2 = [], X2 = [], Q2 = { name: y2, Hidden: 0 }, q2.Sheets.push(Q2);
                break;
              case "table":
                if ("/" === m2[1]) {
                  if ((g2 = v2.pop())[0] !== m2[3]) throw Error("Bad state: " + g2.join("|"));
                } else "/>" == m2[0].slice(-2) || (v2.push([m2[3], false]), z2 = [], H2 = false);
                break;
              case "style":
                "/" === m2[1] ? (function(e11, t11, r11) {
                  if (r11.cellStyles && t11.Interior) {
                    var a11 = t11.Interior;
                    a11.Pattern && (a11.patternType = s4[a11.Pattern] || a11.Pattern);
                  }
                  e11[t11.ID] = t11;
                })(O2, R2, s10) : R2 = ok(m2[0]);
                break;
              case "numberformat":
                R2.nf = t8(ok(m2[0]).Format || "General"), Y[R2.nf] && (R2.nf = Y[R2.nf]);
                for (var ea2 = 0; 392 != ea2 && eD[ea2] != R2.nf; ++ea2) ;
                if (392 == ea2) {
                  for (ea2 = 57; 392 != ea2; ++ea2)
                    if (null == eD[ea2]) {
                      te(R2.nf, ea2);
                      break;
                    }
                }
                break;
              case "column":
                if ("table" !== v2[v2.length - 1][0] || "/" === m2[1]) break;
                if ((E2 = ok(m2[0])).Hidden && (E2.hidden = true, delete E2.Hidden), E2.Width && (E2.wpx = parseInt(E2.Width, 10)), !H2 && E2.wpx > 10) {
                  H2 = true, sK = 6;
                  for (var es2 = 0; es2 < z2.length; ++es2) z2[es2] && s0(z2[es2]);
                }
                H2 && s0(E2), z2[E2.Index - 1 || z2.length] = E2;
                for (var ei2 = 0; ei2 < +E2.Span; ++ei2) z2[z2.length] = tw(E2);
                break;
              case "namedrange":
                if ("/" === m2[1]) break;
                q2.Names || (q2.Names = []);
                var ec2, el2 = t4(m2[0]), ef2 = {
                  Name: (ec2 = el2.Name, a1.indexOf("_xlnm." + ec2) > -1 ? "_xlnm." + ec2 : ec2),
                  Ref: iu(el2.RefersTo.slice(1), { r: 0, c: 0 })
                };
                q2.Sheets.length > 0 && (ef2.Sheet = q2.Sheets.length - 1), q2.Names.push(ef2);
                break;
              case "namedcell":
              case "b":
              case "i":
              case "u":
              case "s":
              case "em":
              case "h2":
              case "h3":
              case "sub":
              case "sup":
              case "span":
              case "alignment":
              case "borders":
              case "border":
              case "protection":
              case "paragraphs":
              case "name":
              case "pixelsperinch":
              case "null":
                break;
              case "font":
                "/>" === m2[0].slice(-2) || ("/" === m2[1] ? N2 += i10.slice(F2, m2.index) : F2 = m2.index + m2[0].length);
                break;
              case "interior":
                if (!s10.cellStyles) break;
                R2.Interior = ok(m2[0]);
                break;
              case "author":
              case "title":
              case "description":
              case "created":
              case "keywords":
              case "subject":
              case "category":
              case "company":
              case "lastauthor":
              case "lastsaved":
              case "lastprinted":
              case "version":
              case "revision":
              case "totaltime":
              case "hyperlinkbase":
              case "manager":
              case "contentstatus":
              case "identifier":
              case "language":
              case "appname":
                "/>" === m2[0].slice(-2) || ("/" === m2[1] ? (r10 = ee2, a10 = i10.slice(M2, m2.index), j || (j = to(nO)), P2[r10 = j[r10] || r10] = a10) : M2 = m2.index + m2[0].length);
                break;
              case "styles":
              case "workbook":
                if ("/" === m2[1]) {
                  if ((g2 = v2.pop())[0] !== m2[3]) throw Error("Bad state: " + g2.join("|"));
                } else v2.push([m2[3], false]);
                break;
              case "comment":
                if ("/" === m2[1]) {
                  if ((g2 = v2.pop())[0] !== m2[3]) throw Error("Bad state: " + g2.join("|"));
                  (n10 = W2).t = n10.v || "", n10.t = n10.t.replace(/\r\n/g, "\n").replace(/\r/g, "\n"), n10.v = n10.w = n10.ixfe = void 0, B2.push(W2);
                } else
                  v2.push([m2[3], false]), rs((g2 = ok(m2[0])).ShowAlways || "0") || (B2.hidden = true), W2 = { a: g2.Author };
                break;
              case "autofilter":
                if ("/" === m2[1]) {
                  if ((g2 = v2.pop())[0] !== m2[3]) throw Error("Bad state: " + g2.join("|"));
                } else if ("/" !== m2[0].charAt(m2[0].length - 2)) {
                  var eh2 = ok(m2[0]);
                  T2["!autofilter"] = { ref: iu(eh2.Range).replace(/\$/g, "") }, v2.push([m2[3], true]);
                }
                break;
              case "datavalidation":
              case "componentoptions":
              case "documentproperties":
              case "customdocumentproperties":
              case "officedocumentsettings":
              case "pivottable":
              case "pivotcache":
              case "names":
              case "mapinfo":
              case "pagebreaks":
              case "querytable":
              case "sorting":
              case "schema":
              case "conditionalformatting":
              case "smarttagtype":
              case "smarttags":
              case "excelworkbook":
              case "workbookoptions":
              case "worksheetoptions":
                if ("/" === m2[1]) {
                  if ((g2 = v2.pop())[0] !== m2[3]) throw Error("Bad state: " + g2.join("|"));
                } else "/" !== m2[0].charAt(m2[0].length - 2) && v2.push([m2[3], true]);
                break;
              default:
                if (0 == v2.length && "document" == m2[3] || 0 == v2.length && "uof" == m2[3])
                  return (function(e11, t11) {
                    var r11 = o5(e11, t11);
                    return r11.bookType = "fods", r11;
                  })(i10, s10);
                var eu2 = true;
                switch (v2[v2.length - 1][0]) {
                  case "officedocumentsettings":
                    switch (m2[3]) {
                      case "allowpng":
                      case "removepersonalinformation":
                      case "downloadcomponents":
                      case "locationofcomponents":
                      case "colors":
                      case "color":
                      case "index":
                      case "rgb":
                      case "targetscreensize":
                      case "readonlyrecommended":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "componentoptions":
                    switch (m2[3]) {
                      case "toolbar":
                      case "hideofficelogo":
                      case "spreadsheetautofit":
                      case "label":
                      case "caption":
                      case "maxheight":
                      case "maxwidth":
                      case "nextsheetnumber":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "excelworkbook":
                    switch (m2[3]) {
                      case "date1904":
                        q2.WBProps.date1904 = true;
                        break;
                      case "hidehorizontalscrollbar":
                      case "hideverticalscrollbar":
                      case "hideworkbooktabs":
                      case "windowheight":
                      case "windowwidth":
                      case "windowtopx":
                      case "windowtopy":
                      case "tabratio":
                      case "protectstructure":
                      case "protectwindow":
                      case "protectwindows":
                      case "activesheet":
                      case "displayinknotes":
                      case "firstvisiblesheet":
                      case "supbook":
                      case "sheetname":
                      case "sheetindex":
                      case "sheetindexfirst":
                      case "sheetindexlast":
                      case "dll":
                      case "acceptlabelsinformulas":
                      case "donotsavelinkvalues":
                      case "iteration":
                      case "maxiterations":
                      case "maxchange":
                      case "path":
                      case "xct":
                      case "count":
                      case "selectedsheets":
                      case "calculation":
                      case "uncalced":
                      case "startupprompt":
                      case "crn":
                      case "externname":
                      case "formula":
                      case "colfirst":
                      case "collast":
                      case "wantadvise":
                      case "boolean":
                      case "error":
                      case "text":
                      case "ole":
                      case "noautorecover":
                      case "publishobjects":
                      case "donotcalculatebeforesave":
                      case "number":
                      case "refmoder1c1":
                      case "embedsavesmarttags":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "workbookoptions":
                    switch (m2[3]) {
                      case "owcversion":
                      case "height":
                      case "width":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "worksheetoptions":
                    switch (m2[3]) {
                      case "visible":
                        if ("/>" === m2[0].slice(-2)) ;
                        else if ("/" === m2[1])
                          switch (i10.slice(M2, m2.index)) {
                            case "SheetHidden":
                              Q2.Hidden = 1;
                              break;
                            case "SheetVeryHidden":
                              Q2.Hidden = 2;
                          }
                        else M2 = m2.index + m2[0].length;
                        break;
                      case "header":
                        T2["!margins"] || i0(T2["!margins"] = {}, "xlml"), isNaN(+t4(m2[0]).Margin) || (T2["!margins"].header = +t4(m2[0]).Margin);
                        break;
                      case "footer":
                        T2["!margins"] || i0(T2["!margins"] = {}, "xlml"), isNaN(+t4(m2[0]).Margin) || (T2["!margins"].footer = +t4(m2[0]).Margin);
                        break;
                      case "pagemargins":
                        var ed2 = t4(m2[0]);
                        T2["!margins"] || i0(T2["!margins"] = {}, "xlml"), isNaN(+ed2.Top) || (T2["!margins"].top = +ed2.Top), isNaN(+ed2.Left) || (T2["!margins"].left = +ed2.Left), isNaN(+ed2.Right) || (T2["!margins"].right = +ed2.Right), isNaN(+ed2.Bottom) || (T2["!margins"].bottom = +ed2.Bottom);
                        break;
                      case "displayrighttoleft":
                        q2.Views || (q2.Views = []), q2.Views[0] || (q2.Views[0] = {}), q2.Views[0].RTL = true;
                        break;
                      case "freezepanes":
                      case "frozennosplit":
                      case "splithorizontal":
                      case "splitvertical":
                      case "donotdisplaygridlines":
                      case "activerow":
                      case "activecol":
                      case "toprowbottompane":
                      case "leftcolumnrightpane":
                      case "unsynced":
                      case "print":
                      case "printerrors":
                      case "panes":
                      case "scale":
                      case "pane":
                      case "number":
                      case "layout":
                      case "pagesetup":
                      case "selected":
                      case "protectobjects":
                      case "enableselection":
                      case "protectscenarios":
                      case "validprinterinfo":
                      case "horizontalresolution":
                      case "verticalresolution":
                      case "numberofcopies":
                      case "activepane":
                      case "toprowvisible":
                      case "leftcolumnvisible":
                      case "fittopage":
                      case "rangeselection":
                      case "papersizeindex":
                      case "pagelayoutzoom":
                      case "pagebreakzoom":
                      case "filteron":
                      case "fitwidth":
                      case "fitheight":
                      case "commentslayout":
                      case "zoom":
                      case "lefttoright":
                      case "gridlines":
                      case "allowsort":
                      case "allowfilter":
                      case "allowinsertrows":
                      case "allowdeleterows":
                      case "allowinsertcols":
                      case "allowdeletecols":
                      case "allowinserthyperlinks":
                      case "allowformatcells":
                      case "allowsizecols":
                      case "allowsizerows":
                      case "tabcolorindex":
                      case "donotdisplayheadings":
                      case "showpagelayoutzoom":
                      case "blackandwhite":
                      case "donotdisplayzeros":
                      case "displaypagebreak":
                      case "rowcolheadings":
                      case "donotdisplayoutline":
                      case "noorientation":
                      case "allowusepivottables":
                      case "zeroheight":
                      case "viewablerange":
                      case "selection":
                      case "protectcontents":
                        break;
                      case "nosummaryrowsbelowdetail":
                        T2["!outline"] || (T2["!outline"] = {}), T2["!outline"].above = true;
                        break;
                      case "nosummarycolumnsrightdetail":
                        T2["!outline"] || (T2["!outline"] = {}), T2["!outline"].left = true;
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "pivottable":
                  case "pivotcache":
                    switch (m2[3]) {
                      case "immediateitemsondrop":
                      case "showpagemultipleitemlabel":
                      case "compactrowindent":
                      case "location":
                      case "pivotfield":
                      case "orientation":
                      case "layoutform":
                      case "layoutsubtotallocation":
                      case "layoutcompactrow":
                      case "position":
                      case "pivotitem":
                      case "datatype":
                      case "datafield":
                      case "sourcename":
                      case "parentfield":
                      case "ptlineitems":
                      case "ptlineitem":
                      case "countofsameitems":
                      case "item":
                      case "itemtype":
                      case "ptsource":
                      case "cacheindex":
                      case "consolidationreference":
                      case "filename":
                      case "reference":
                      case "nocolumngrand":
                      case "norowgrand":
                      case "blanklineafteritems":
                      case "hidden":
                      case "subtotal":
                      case "basefield":
                      case "mapchilditems":
                      case "function":
                      case "refreshonfileopen":
                      case "printsettitles":
                      case "mergelabels":
                      case "defaultversion":
                      case "refreshname":
                      case "refreshdate":
                      case "refreshdatecopy":
                      case "versionlastrefresh":
                      case "versionlastupdate":
                      case "versionupdateablemin":
                      case "versionrefreshablemin":
                      case "calculation":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "pagebreaks":
                    switch (m2[3]) {
                      case "colbreaks":
                      case "colbreak":
                      case "rowbreaks":
                      case "rowbreak":
                      case "colstart":
                      case "colend":
                      case "rowend":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "autofilter":
                    switch (m2[3]) {
                      case "autofiltercolumn":
                      case "autofiltercondition":
                      case "autofilterand":
                      case "autofilteror":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "querytable":
                    switch (m2[3]) {
                      case "id":
                      case "autoformatfont":
                      case "autoformatpattern":
                      case "querysource":
                      case "querytype":
                      case "enableredirections":
                      case "refreshedinxl9":
                      case "urlstring":
                      case "htmltables":
                      case "connection":
                      case "commandtext":
                      case "refreshinfo":
                      case "notitles":
                      case "nextid":
                      case "columninfo":
                      case "overwritecells":
                      case "donotpromptforfile":
                      case "textwizardsettings":
                      case "source":
                      case "number":
                      case "decimal":
                      case "thousandseparator":
                      case "trailingminusnumbers":
                      case "formatsettings":
                      case "fieldtype":
                      case "delimiters":
                      case "tab":
                      case "comma":
                      case "autoformatname":
                      case "versionlastedit":
                      case "versionlastrefresh":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "datavalidation":
                    switch (m2[3]) {
                      case "range":
                      case "type":
                      case "min":
                      case "max":
                      case "sort":
                      case "descending":
                      case "order":
                      case "casesensitive":
                      case "value":
                      case "errorstyle":
                      case "errormessage":
                      case "errortitle":
                      case "inputmessage":
                      case "inputtitle":
                      case "combohide":
                      case "inputhide":
                      case "condition":
                      case "qualifier":
                      case "useblank":
                      case "value1":
                      case "value2":
                      case "format":
                      case "cellrangelist":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "sorting":
                  case "conditionalformatting":
                    switch (m2[3]) {
                      case "range":
                      case "type":
                      case "min":
                      case "max":
                      case "sort":
                      case "descending":
                      case "order":
                      case "casesensitive":
                      case "value":
                      case "errorstyle":
                      case "errormessage":
                      case "errortitle":
                      case "cellrangelist":
                      case "inputmessage":
                      case "inputtitle":
                      case "combohide":
                      case "inputhide":
                      case "condition":
                      case "qualifier":
                      case "useblank":
                      case "value1":
                      case "value2":
                      case "format":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "mapinfo":
                  case "schema":
                  case "data":
                    switch (m2[3]) {
                      case "map":
                      case "entry":
                      case "range":
                      case "xpath":
                      case "field":
                      case "xsdtype":
                      case "filteron":
                      case "aggregate":
                      case "elementtype":
                      case "attributetype":
                      case "schema":
                      case "element":
                      case "complextype":
                      case "datatype":
                      case "all":
                      case "attribute":
                      case "extends":
                      case "row":
                        break;
                      default:
                        eu2 = false;
                    }
                    break;
                  case "smarttags":
                    break;
                  default:
                    eu2 = false;
                }
                if (eu2 || m2[3].match(/!\[CDATA/)) break;
                if (!v2[v2.length - 1][1]) throw "Unrecognized tag: " + m2[3] + "|" + v2.join("|");
                if ("customdocumentproperties" === v2[v2.length - 1][0]) {
                  "/>" === m2[0].slice(-2) || ("/" === m2[1] ? (function(e11, t11, r11, a11) {
                    var n11 = a11;
                    switch ((r11[0].match(/dt:dt="([\w.]+)"/) || ["", ""])[1]) {
                      case "boolean":
                        n11 = rs(a11);
                        break;
                      case "i2":
                      case "int":
                        n11 = parseInt(a11, 10);
                        break;
                      case "r4":
                      case "float":
                        n11 = parseFloat(a11);
                        break;
                      case "date":
                      case "dateTime.tz":
                        n11 = tv(a11);
                        break;
                      case "i8":
                      case "string":
                      case "fixed":
                      case "uuid":
                      case "bin.base64":
                        break;
                      default:
                        throw Error("bad custprop:" + r11[0]);
                    }
                    e11[t8(t11)] = n11;
                  })(L2, ee2, U2, i10.slice(M2, m2.index)) : (U2 = m2, M2 = m2.index + m2[0].length));
                  break;
                }
                if (s10.WTF) throw "Unrecognized tag: " + m2[3] + "|" + v2.join("|");
            }
          var ep2 = {};
          return s10.bookSheets || s10.bookProps || (ep2.Sheets = b2), ep2.SheetNames = w2, ep2.Workbook = q2, ep2.SSF = tw(eD), ep2.Props = P2, ep2.Custprops = L2, ep2.bookType = "xlml", ep2;
        }
        function o_(e10, t10) {
          switch (cM(t10 = t10 || {}), t10.type || "base64") {
            case "base64":
              return ox(ed(e10), t10);
            case "binary":
            case "buffer":
            case "file":
              return ox(e10, t10);
            case "array":
              return ox(ey(e10), t10);
          }
        }
        function oS(e10, t10) {
          var r10, a10, n10, s10, i10, o10, c10, l2 = [];
          return e10.Props && l2.push(
            (r10 = e10.Props, a10 = [], ts(nO).map(function(e11) {
              for (var t11 = 0; t11 < nT.length; ++t11) if (nT[t11][1] == e11) return nT[t11];
              for (t11 = 0; t11 < nx.length; ++t11) if (nx[t11][1] == e11) return nx[t11];
              throw e11;
            }).forEach(function(e11) {
              if (null != r10[e11[1]]) {
                var n11 = t10 && t10.Props && null != t10.Props[e11[1]] ? t10.Props[e11[1]] : r10[e11[1]];
                "date" === e11[2] && (n11 = new Date(n11).toISOString().replace(/\.\d*Z/, "Z")), "number" == typeof n11 ? n11 = String(n11) : true === n11 || false === n11 ? n11 = n11 ? "1" : "0" : n11 instanceof Date && (n11 = new Date(n11).toISOString().replace(/\.\d*Z/, "")), a10.push(rv(nO[e11[1]] || e11[1], n11));
              }
            }), rw("DocumentProperties", a10.join(""), { xmlns: rI }))
          ), e10.Custprops && l2.push(
            (n10 = e10.Props, s10 = e10.Custprops, i10 = ["Worksheets", "SheetNames"], o10 = "CustomDocumentProperties", c10 = [], n10 && ts(n10).forEach(function(e11) {
              if (Object.prototype.hasOwnProperty.call(n10, e11)) {
                for (var t11 = 0; t11 < nT.length; ++t11) if (e11 == nT[t11][1]) return;
                for (t11 = 0; t11 < nx.length; ++t11) if (e11 == nx[t11][1]) return;
                for (t11 = 0; t11 < i10.length; ++t11) if (e11 == i10[t11]) return;
                var r11 = n10[e11], a11 = "string";
                "number" == typeof r11 ? (a11 = "float", r11 = String(r11)) : true === r11 || false === r11 ? (a11 = "boolean", r11 = r11 ? "1" : "0") : r11 = String(r11), c10.push(rw(rt(e11), r11, { "dt:dt": a11 }));
              }
            }), s10 && ts(s10).forEach(function(e11) {
              if (Object.prototype.hasOwnProperty.call(s10, e11) && !(n10 && Object.prototype.hasOwnProperty.call(n10, e11))) {
                var t11 = s10[e11], r11 = "string";
                "number" == typeof t11 ? (r11 = "float", t11 = String(t11)) : true === t11 || false === t11 ? (r11 = "boolean", t11 = t11 ? "1" : "0") : t11 instanceof Date ? (r11 = "dateTime.tz", t11 = t11.toISOString()) : t11 = String(t11), c10.push(rw(rt(e11), t11, { "dt:dt": r11 }));
              }
            }), "<" + o10 + ' xmlns="' + rI + '">' + c10.join("") + "</" + o10 + ">")
          ), l2.join("");
        }
        function oA(e10) {
          return (((e10 || {}).Workbook || {}).WBProps || {}).date1904 ? '<ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel"><Date1904/></ExcelWorkbook>' : "";
        }
        function oC(e10, t10) {
          var r10 = ['<Style ss:ID="Default" ss:Name="Normal"><NumberFormat/></Style>'];
          return t10.cellXfs.forEach(function(e11, t11) {
            var a10 = [];
            a10.push(rw("NumberFormat", null, { "ss:Format": re(eD[e11.numFmtId]) })), r10.push(rw("Style", a10.join(""), { "ss:ID": "s" + (21 + t11) }));
          }), rw("Styles", r10.join(""));
        }
        function oI(e10) {
          return rw("NamedRange", null, {
            "ss:Name": "_xlnm." == e10.Name.slice(0, 6) ? e10.Name.slice(6) : e10.Name,
            "ss:RefersTo": "=" + ip(e10.Ref, { r: 0, c: 0 })
          });
        }
        function oO(e10) {
          if (!((e10 || {}).Workbook || {}).Names) return "";
          for (var t10 = e10.Workbook.Names, r10 = [], a10 = 0; a10 < t10.length; ++a10) {
            var n10 = t10[a10];
            null == n10.Sheet && (n10.Name.match(/^_xlfn\./) || r10.push(oI(n10)));
          }
          return rw("Names", r10.join(""));
        }
        function oR(e10, t10, r10, a10) {
          if (!e10 || !((a10 || {}).Workbook || {}).Names) return "";
          for (var n10 = a10.Workbook.Names, s10 = [], i10 = 0; i10 < n10.length; ++i10) {
            var o10 = n10[i10];
            o10.Sheet == r10 && (o10.Name.match(/^_xlfn\./) || s10.push(oI(o10)));
          }
          return s10.join("");
        }
        function oN(e10, t10, r10, a10) {
          if (!e10) return "";
          var n10 = [];
          if (e10["!margins"] && (n10.push("<PageSetup>"), e10["!margins"].header && n10.push(rw("Header", null, { "x:Margin": e10["!margins"].header })), e10["!margins"].footer && n10.push(rw("Footer", null, { "x:Margin": e10["!margins"].footer })), n10.push(
            rw("PageMargins", null, {
              "x:Bottom": e10["!margins"].bottom || "0.75",
              "x:Left": e10["!margins"].left || "0.7",
              "x:Right": e10["!margins"].right || "0.7",
              "x:Top": e10["!margins"].top || "0.75"
            })
          ), n10.push("</PageSetup>")), a10 && a10.Workbook && a10.Workbook.Sheets && a10.Workbook.Sheets[r10])
            if (a10.Workbook.Sheets[r10].Hidden)
              n10.push(rw("Visible", 1 == a10.Workbook.Sheets[r10].Hidden ? "SheetHidden" : "SheetVeryHidden", {}));
            else {
              for (var s10 = 0; s10 < r10 && (!a10.Workbook.Sheets[s10] || a10.Workbook.Sheets[s10].Hidden); ++s10) ;
              s10 == r10 && n10.push("<Selected/>");
            }
          return (((((a10 || {}).Workbook || {}).Views || [])[0] || {}).RTL && n10.push("<DisplayRightToLeft/>"), e10["!protect"] && (n10.push(rv("ProtectContents", "True")), e10["!protect"].objects && n10.push(rv("ProtectObjects", "True")), e10["!protect"].scenarios && n10.push(rv("ProtectScenarios", "True")), null == e10["!protect"].selectLockedCells || e10["!protect"].selectLockedCells ? null == e10["!protect"].selectUnlockedCells || e10["!protect"].selectUnlockedCells || n10.push(rv("EnableSelection", "UnlockedCells")) : n10.push(rv("EnableSelection", "NoSelection")), [
            ["formatCells", "AllowFormatCells"],
            ["formatColumns", "AllowSizeCols"],
            ["formatRows", "AllowSizeRows"],
            ["insertColumns", "AllowInsertCols"],
            ["insertRows", "AllowInsertRows"],
            ["insertHyperlinks", "AllowInsertHyperlinks"],
            ["deleteColumns", "AllowDeleteCols"],
            ["deleteRows", "AllowDeleteRows"],
            ["sort", "AllowSort"],
            ["autoFilter", "AllowFilter"],
            ["pivotTables", "AllowUsePivotTables"]
          ].forEach(function(t11) {
            e10["!protect"][t11[0]] && n10.push("<" + t11[1] + "/>");
          })), 0 == n10.length) ? "" : rw("WorksheetOptions", n10.join(""), { xmlns: rO });
        }
        function oF(e10, t10, r10, a10, n10, s10, i10) {
          if (!e10 || void 0 == e10.v && void 0 == e10.f) return "";
          var o10, c10 = {};
          if (e10.f && (c10["ss:Formula"] = "=" + re(ip(e10.f, i10))), e10.F && e10.F.slice(0, t10.length) == t10) {
            var l2 = av(e10.F.slice(t10.length + 1));
            c10["ss:ArrayRange"] = "RC:R" + (l2.r == i10.r ? "" : "[" + (l2.r - i10.r) + "]") + "C" + (l2.c == i10.c ? "" : "[" + (l2.c - i10.c) + "]");
          }
          if (e10.l && e10.l.Target && (c10["ss:HRef"] = re(e10.l.Target), e10.l.Tooltip && (c10["x:HRefScreenTip"] = re(e10.l.Tooltip))), r10["!merges"])
            for (var f2 = r10["!merges"], h2 = 0; h2 != f2.length; ++h2)
              f2[h2].s.c == i10.c && f2[h2].s.r == i10.r && (f2[h2].e.c > f2[h2].s.c && (c10["ss:MergeAcross"] = f2[h2].e.c - f2[h2].s.c), f2[h2].e.r > f2[h2].s.r && (c10["ss:MergeDown"] = f2[h2].e.r - f2[h2].s.r));
          var u2 = "", d2 = "";
          switch (e10.t) {
            case "z":
              if (!a10.sheetStubs) return "";
              break;
            case "n":
              isFinite(e10.v) ? (u2 = "Number", d2 = String(e10.v)) : (u2 = "Error", d2 = aQ[isNaN(e10.v) ? 36 : 7]);
              break;
            case "b":
              u2 = "Boolean", d2 = e10.v ? "1" : "0";
              break;
            case "e":
              u2 = "Error", d2 = aQ[e10.v];
              break;
            case "d":
              u2 = "DateTime", d2 = new Date(e10.v).toISOString(), null == e10.z && (e10.z = e10.z || eD[14]);
              break;
            case "s":
              u2 = "String", d2 = ((e10.v || "") + "").replace(t7, function(e11) {
                return t6[e11];
              }).replace(rr, function(e11) {
                return "&#x" + e11.charCodeAt(0).toString(16).toUpperCase() + ";";
              });
          }
          var p2 = i1(a10.cellXfs, e10, a10);
          c10["ss:StyleID"] = "s" + (21 + p2), c10["ss:Index"] = i10.c + 1;
          var m2 = null != e10.v ? d2 : "", g2 = "z" == e10.t ? "" : '<Data ss:Type="' + u2 + '">' + m2 + "</Data>";
          return (e10.c || []).length > 0 && (g2 += (o10 = e10.c).map(function(e11) {
            var t11 = rw("ss:Data", (e11.t || "").replace(/(\r\n|[\r\n])/g, "&#10;"), {
              xmlns: "http://www.w3.org/TR/REC-html40"
            }), r11 = {};
            return e11.a && (r11["ss:Author"] = e11.a), o10.hidden || (r11["ss:ShowAlways"] = "1"), rw("Comment", t11, r11);
          }).join("")), rw("Cell", g2, c10);
        }
        function oD(e10, t10) {
          var r10 = '<Row ss:Index="' + (e10 + 1) + '"';
          return t10 && (t10.hpt && !t10.hpx && (t10.hpx = s2(t10.hpt)), t10.hpx && (r10 += ' ss:AutoFitHeight="0" ss:Height="' + t10.hpx + '"'), t10.hidden && (r10 += ' ss:Hidden="1"')), r10 + ">";
        }
        var oP = [60, 1084, 2066, 2165, 2175];
        function oL(e10, t10, r10) {
          if ("z" !== e10.t && e10.XF) {
            var a10 = 0;
            try {
              a10 = e10.z || e10.XF.numFmtId || 0, t10.cellNF && null == e10.z && (e10.z = eD[a10]);
            } catch (e11) {
              if (t10.WTF) throw e11;
            }
            if (!t10 || false !== t10.cellText)
              try {
                "e" === e10.t ? e10.w = e10.w || aQ[e10.v] : 0 === a10 || "General" == a10 ? "n" === e10.t ? (0 | e10.v) === e10.v ? e10.w = e10.v.toString(10) : e10.w = eW(e10.v) : e10.w = ez(e10.v) : e10.w = e22(a10, e10.v, { date1904: !!r10, dateNF: t10 && t10.dateNF });
              } catch (e11) {
                if (t10.WTF) throw e11;
              }
            if (t10.cellDates && a10 && "n" == e10.t && eQ(eD[a10] || String(a10))) {
              var n10 = eU(e10.v + 1462 * !!r10);
              n10 && (e10.t = "d", e10.v = new Date(Date.UTC(n10.y, n10.m - 1, n10.d, n10.H, n10.M, n10.S, n10.u)));
            }
          }
        }
        function oM(e10, t10, r10) {
          return { v: e10, ixfe: t10, t: r10 };
        }
        var oU = "e0859ff2f94f6810ab9108002b27b3d9", oB = "02d5cdd59c2e1b10939708002b2cf9ae";
        function oW(e10, t10) {
          if (t10 || (t10 = {}), cM(t10), ea(), t10.codepage && et(t10.codepage), e10.FullPaths) {
            if (tr.find(e10, "/encryption")) throw Error("File is password-protected");
            n10 = tr.find(e10, "!CompObj"), s10 = tr.find(e10, "/Workbook") || tr.find(e10, "/Book");
          } else {
            switch (t10.type) {
              case "base64":
                e10 = ew(ed(e10));
                break;
              case "binary":
                e10 = ew(e10);
                break;
              case "buffer":
                break;
              case "array":
                Array.isArray(e10) || (e10 = Array.prototype.slice.call(e10));
            }
            aa(e10, 0), s10 = { content: e10 };
          }
          if (n10 && (function(e11) {
            var t11 = {}, r11 = e11.content;
            if (r11.l = 28, t11.AnsiUserType = r11.read_shift(0, "lpstr-ansi"), t11.AnsiClipboardFormat = aX(r11, 1), r11.length - r11.l <= 4)
              return;
            var a11 = r11.read_shift(4);
            if (0 != a11 && !(a11 > 40) && (r11.l -= 4, t11.Reserved1 = r11.read_shift(0, "lpstr-ansi"), !(r11.length - r11.l <= 4) && 1907505652 === (a11 = r11.read_shift(4))) && (t11.UnicodeClipboardFormat = aX(r11, 2), 0 != (a11 = r11.read_shift(4)) && !(a11 > 40)))
              r11.l -= 4, t11.Reserved2 = r11.read_shift(0, "lpwstr");
          })(n10), t10.bookProps && !t10.bookSheets)
            i10 = {};
          else {
            var r10, a10, n10, s10, i10, o10, c10 = ep ? "buffer" : "array";
            if (s10 && s10.content)
              i10 = (function(e11, t11) {
                var r11, a11, n11, s11, i11 = { opts: {} }, o11 = {}, c11 = {};
                t11.dense && (c11["!data"] = []);
                var l3, f2, h2, u2, d2, p2 = {}, m2 = {}, g2 = null, v2 = [], b2 = "", w2 = {}, T2 = "", y2 = {}, E2 = [], k2 = [], x2 = [], _2 = { Sheets: [], WBProps: { date1904: false }, Views: [{}] }, S2 = {}, A2 = false, C2 = function(e12) {
                  return e12 < 8 ? aq[e12] : e12 < 64 && x2[e12 - 8] || aq[e12];
                }, I2 = function(e12, t12) {
                  var r12, a12 = e12.XF.data;
                  a12 && a12.patternType && t12 && t12.cellStyles && (e12.s = {}, e12.s.patternType = a12.patternType, (r12 = sX(C2(a12.icvFore))) && (e12.s.fgColor = { rgb: r12 }), (r12 = sX(C2(a12.icvBack))) && (e12.s.bgColor = { rgb: r12 }));
                }, O2 = function(e12, t12, r12) {
                  if ((A2 || !(B2 > 1)) && (!r12.sheetRows || !(e12.r >= r12.sheetRows))) {
                    if (r12.cellStyles && t12.XF && t12.XF.data && I2(t12, r12), delete t12.ixfe, delete t12.XF, l3 = e12, T2 = ab(e12), m2 && m2.s && m2.e || (m2 = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }), e12.r < m2.s.r && (m2.s.r = e12.r), e12.c < m2.s.c && (m2.s.c = e12.c), e12.r + 1 > m2.e.r && (m2.e.r = e12.r + 1), e12.c + 1 > m2.e.c && (m2.e.c = e12.c + 1), r12.cellFormula && t12.f) {
                      for (var a12 = 0; a12 < E2.length; ++a12)
                        if (!(E2[a12][0].s.c > e12.c) && !(E2[a12][0].s.r > e12.r) && !(E2[a12][0].e.c < e12.c) && !(E2[a12][0].e.r < e12.r)) {
                          t12.F = aT(E2[a12][0]), (E2[a12][0].s.c != e12.c || E2[a12][0].s.r != e12.r) && delete t12.f, t12.f && (t12.f = "" + iU(E2[a12][1], m2, e12, M2, R2));
                          break;
                        }
                    }
                    r12.dense ? (c11["!data"][e12.r] || (c11["!data"][e12.r] = []), c11["!data"][e12.r][e12.c] = t12) : c11[T2] = t12;
                  }
                }, R2 = {
                  enc: false,
                  sbcch: 0,
                  snames: [],
                  sharedf: y2,
                  arrayf: E2,
                  rrtabid: [],
                  lastuser: "",
                  biff: 8,
                  codepage: 0,
                  winlocked: 0,
                  cellStyles: !!t11 && !!t11.cellStyles,
                  WTF: !!t11 && !!t11.wtf
                };
                t11.password && (R2.password = t11.password);
                var N2 = [], F2 = [], D2 = [], P2 = [], L2 = false, M2 = [];
                M2.SheetNames = R2.snames, M2.sharedf = R2.sharedf, M2.arrayf = R2.arrayf, M2.names = [], M2.XTI = [];
                var U2 = 0, B2 = 0, W2 = 0, z2 = [], H2 = [];
                R2.codepage = 1200, er(1200);
                for (var V2 = false; e11.l < e11.length - 1; ) {
                  var G2 = e11.l, X2 = e11.read_shift(2);
                  if (0 === X2 && 10 === U2) break;
                  var j2 = e11.l === e11.length ? 0 : e11.read_shift(2), K2 = oH[X2];
                  if (0 == B2 && -1 == [9, 521, 1033, 2057].indexOf(X2)) break;
                  if (K2 && K2.f) {
                    if (t11.bookSheets && 133 === U2 && 133 !== X2) break;
                    if (U2 = X2, 2 === K2.r || 12 == K2.r) {
                      var Y2 = e11.read_shift(2);
                      if (j2 -= 2, !R2.enc && Y2 !== X2 && ((255 & Y2) << 8 | Y2 >> 8) !== X2)
                        throw Error("rt mismatch: " + Y2 + "!=" + X2);
                      12 == K2.r && (e11.l += 10, j2 -= 10);
                    }
                    var Z2 = {};
                    if (Z2 = 10 === X2 ? K2.f(e11, j2, R2) : (function(e12, t12, r12, a12, n12) {
                      var s12 = a12, i12 = [], o12 = r12.slice(r12.l, r12.l + s12);
                      if (n12 && n12.enc && n12.enc.insitu && o12.length > 0)
                        switch (e12) {
                          case 9:
                          case 521:
                          case 1033:
                          case 2057:
                          case 47:
                          case 405:
                          case 225:
                          case 406:
                          case 312:
                          case 404:
                          case 10:
                          case 133:
                            break;
                          default:
                            n12.enc.insitu(o12);
                        }
                      i12.push(o12), r12.l += s12;
                      for (var c12 = r4(r12, r12.l), l4 = oH[c12], f3 = 0; null != l4 && oP.indexOf(c12) > -1; )
                        s12 = r4(r12, r12.l + 2), f3 = r12.l + 4, 2066 == c12 ? f3 += 4 : (2165 == c12 || 2175 == c12) && (f3 += 12), o12 = r12.slice(f3, r12.l + 4 + s12), i12.push(o12), r12.l += 4 + s12, l4 = oH[c12 = r4(r12, r12.l)];
                      var h3 = ek(i12);
                      aa(h3, 0);
                      var u3 = 0;
                      h3.lens = [];
                      for (var d3 = 0; d3 < i12.length; ++d3) h3.lens.push(u3), u3 += i12[d3].length;
                      if (h3.length < a12)
                        throw "XLS Record 0x" + e12.toString(16) + " Truncated: " + h3.length + " < " + a12;
                      return t12.f(h3, h3.length, n12);
                    })(X2, K2, e11, j2, R2), 0 == B2 && -1 === [9, 521, 1033, 2057].indexOf(U2))
                      continue;
                    switch (X2) {
                      case 34:
                        i11.opts.Date1904 = _2.WBProps.date1904 = Z2;
                        break;
                      case 134:
                        i11.opts.WriteProtect = true;
                        break;
                      case 47:
                        if (R2.enc || (e11.l = 0), R2.enc = Z2, !t11.password) throw Error("File is password-protected");
                        if (null == Z2.valid) throw Error("Encryption scheme unsupported");
                        if (!Z2.valid) throw Error("Password is incorrect");
                        break;
                      case 92:
                        R2.lastuser = Z2;
                        break;
                      case 66:
                        var J2 = Number(Z2);
                        switch (J2) {
                          case 21010:
                            J2 = 1200;
                            break;
                          case 32768:
                            J2 = 1e4;
                            break;
                          case 32769:
                            J2 = 1252;
                        }
                        er(R2.codepage = J2), V2 = true;
                        break;
                      case 317:
                        R2.rrtabid = Z2;
                        break;
                      case 25:
                        R2.winlocked = Z2;
                        break;
                      case 439:
                        i11.opts.RefreshAll = Z2;
                        break;
                      case 12:
                        i11.opts.CalcCount = Z2;
                        break;
                      case 16:
                        i11.opts.CalcDelta = Z2;
                        break;
                      case 17:
                        i11.opts.CalcIter = Z2;
                        break;
                      case 13:
                        i11.opts.CalcMode = Z2;
                        break;
                      case 14:
                        i11.opts.CalcPrecision = Z2;
                        break;
                      case 95:
                        i11.opts.CalcSaveRecalc = Z2;
                        break;
                      case 15:
                        R2.CalcRefMode = Z2;
                        break;
                      case 2211:
                        i11.opts.FullCalc = Z2;
                        break;
                      case 129:
                        Z2.fDialog && (c11["!type"] = "dialog"), Z2.fBelow || ((c11["!outline"] || (c11["!outline"] = {})).above = true), Z2.fRight || ((c11["!outline"] || (c11["!outline"] = {})).left = true);
                        break;
                      case 67:
                      case 579:
                      case 1091:
                      case 224:
                        k2.push(Z2);
                        break;
                      case 430:
                        M2.push([Z2]), M2[M2.length - 1].XTI = [];
                        break;
                      case 35:
                      case 547:
                        M2[M2.length - 1].push(Z2);
                        break;
                      case 24:
                      case 536:
                        s11 = { Name: Z2.Name, Ref: iU(Z2.rgce, m2, null, M2, R2) }, Z2.itab > 0 && (s11.Sheet = Z2.itab - 1), M2.names.push(s11), M2[0] || (M2[0] = [], M2[0].XTI = []), M2[M2.length - 1].push(Z2), "_xlnm._FilterDatabase" == Z2.Name && Z2.itab > 0 && Z2.rgce && Z2.rgce[0] && Z2.rgce[0][0] && "PtgArea3d" == Z2.rgce[0][0][0] && (H2[Z2.itab - 1] = { ref: aT(Z2.rgce[0][0][1][2]) });
                        break;
                      case 22:
                        R2.ExternCount = Z2;
                        break;
                      case 23:
                        0 == M2.length && (M2[0] = [], M2[0].XTI = []), M2[M2.length - 1].XTI = M2[M2.length - 1].XTI.concat(Z2), M2.XTI = M2.XTI.concat(Z2);
                        break;
                      case 2196:
                        if (R2.biff < 8) break;
                        null != s11 && (s11.Comment = Z2[1]);
                        break;
                      case 18:
                        c11["!protect"] = Z2;
                        break;
                      case 19:
                        0 !== Z2 && R2.WTF && console.error("Password verifier: " + Z2);
                        break;
                      case 133:
                        p2[4 == R2.biff ? R2.snames.length : Z2.pos] = Z2, R2.snames.push(Z2.name);
                        break;
                      case 10:
                        if (--B2 ? !A2 : A2) break;
                        if (m2.e) {
                          if (m2.e.r > 0 && m2.e.c > 0) {
                            if (m2.e.r--, m2.e.c--, c11["!ref"] = aT(m2), t11.sheetRows && t11.sheetRows <= m2.e.r) {
                              var q2 = m2.e.r;
                              m2.e.r = t11.sheetRows - 1, c11["!fullref"] = c11["!ref"], c11["!ref"] = aT(m2), m2.e.r = q2;
                            }
                            m2.e.r++, m2.e.c++;
                          }
                          N2.length > 0 && (c11["!merges"] = N2), F2.length > 0 && (c11["!objects"] = F2), D2.length > 0 && (c11["!cols"] = D2), P2.length > 0 && (c11["!rows"] = P2), _2.Sheets.push(S2);
                        }
                        "" === b2 ? w2 = c11 : o11[b2] = c11, c11 = {}, t11.dense && (c11["!data"] = []);
                        break;
                      case 9:
                      case 521:
                      case 1033:
                      case 2057:
                        if (8 === R2.biff && (R2.biff = { 9: 2, 521: 3, 1033: 4 }[X2] || { 512: 2, 768: 3, 1024: 4, 1280: 5, 1536: 8, 2: 2, 7: 2 }[Z2.BIFFVer] || 8), R2.biffguess = 0 == Z2.BIFFVer, 0 == Z2.BIFFVer && 4096 == Z2.dt && (R2.biff = 5, V2 = true, er(R2.codepage = 28591)), 4 == R2.biff && 256 & Z2.dt && (A2 = true), 8 == R2.biff && 0 == Z2.BIFFVer && 16 == Z2.dt && (R2.biff = 2), B2++ && !A2)
                          break;
                        if (c11 = {}, t11.dense && (c11["!data"] = []), R2.biff < 8 && !V2 && (V2 = true, er(R2.codepage = t11.codepage || 1252)), 4 == R2.biff && A2)
                          b2 = (p2[R2.snames.indexOf(b2) + 1] || { name: "" }).name;
                        else if (R2.biff < 5 || 0 == Z2.BIFFVer && 4096 == Z2.dt) {
                          "" === b2 && (b2 = "Sheet1"), m2 = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
                          var Q2 = { pos: e11.l - j2, name: b2 };
                          p2[Q2.pos] = Q2, R2.snames.push(b2);
                        } else b2 = (p2[G2] || { name: "" }).name;
                        32 == Z2.dt && (c11["!type"] = "chart"), 64 == Z2.dt && (c11["!type"] = "macro"), N2 = [], F2 = [], R2.arrayf = E2 = [], D2 = [], P2 = [], L2 = false, S2 = { Hidden: (p2[G2] || { hs: 0 }).hs, name: b2 };
                        break;
                      case 515:
                      case 3:
                      case 2:
                        "chart" == c11["!type"] && (t11.dense ? (c11["!data"][Z2.r] || [])[Z2.c] : c11[ag(Z2.c) + ap(Z2.r)]) && ++Z2.c, r11 = { ixfe: Z2.ixfe, XF: k2[Z2.ixfe] || {}, v: Z2.val, t: "n" }, W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2({ c: Z2.c, r: Z2.r }, r11, t11);
                        break;
                      case 5:
                      case 517:
                        r11 = { ixfe: Z2.ixfe, XF: k2[Z2.ixfe], v: Z2.val, t: Z2.t }, W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2({ c: Z2.c, r: Z2.r }, r11, t11);
                        break;
                      case 638:
                        r11 = { ixfe: Z2.ixfe, XF: k2[Z2.ixfe], v: Z2.rknum, t: "n" }, W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2({ c: Z2.c, r: Z2.r }, r11, t11);
                        break;
                      case 189:
                        for (var ee2 = Z2.c; ee2 <= Z2.C; ++ee2) {
                          var et2 = Z2.rkrec[ee2 - Z2.c][0];
                          r11 = { ixfe: et2, XF: k2[et2], v: Z2.rkrec[ee2 - Z2.c][1], t: "n" }, W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2({ c: ee2, r: Z2.r }, r11, t11);
                        }
                        break;
                      case 6:
                      case 518:
                      case 1030:
                        if ("String" == Z2.val) {
                          g2 = Z2;
                          break;
                        }
                        if ((r11 = oM(Z2.val, Z2.cell.ixfe, Z2.tt)).XF = k2[r11.ixfe], t11.cellFormula) {
                          var ea2 = Z2.formula;
                          if (ea2 && ea2[0] && ea2[0][0] && "PtgExp" == ea2[0][0][0]) {
                            var en2 = ea2[0][0][1][0], es2 = ea2[0][0][1][1], ei2 = ab({ r: en2, c: es2 });
                            y2[ei2] ? r11.f = "" + iU(Z2.formula, m2, Z2.cell, M2, R2) : r11.F = ((t11.dense ? (c11["!data"][en2] || [])[es2] : c11[ei2]) || {}).F;
                          } else r11.f = "" + iU(Z2.formula, m2, Z2.cell, M2, R2);
                        }
                        W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2(Z2.cell, r11, t11), g2 = Z2;
                        break;
                      case 7:
                      case 519:
                        if (g2)
                          g2.val = Z2, (r11 = oM(Z2, g2.cell.ixfe, "s")).XF = k2[r11.ixfe], t11.cellFormula && (r11.f = "" + iU(g2.formula, m2, g2.cell, M2, R2)), W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2(g2.cell, r11, t11), g2 = null;
                        else throw Error("String record expects Formula");
                        break;
                      case 33:
                      case 545:
                        E2.push(Z2);
                        var eo2 = ab(Z2[0].s);
                        if (f2 = t11.dense ? (c11["!data"][Z2[0].s.r] || [])[Z2[0].s.c] : c11[eo2], t11.cellFormula && f2) {
                          if (!g2 || !eo2 || !f2) break;
                          f2.f = "" + iU(Z2[1], m2, Z2[0], M2, R2), f2.F = aT(Z2[0]);
                        }
                        break;
                      case 1212:
                        if (!t11.cellFormula) break;
                        if (T2) {
                          if (!g2) break;
                          y2[ab(g2.cell)] = Z2[0], ((f2 = t11.dense ? (c11["!data"][g2.cell.r] || [])[g2.cell.c] : c11[ab(g2.cell)]) || {}).f = "" + iU(Z2[0], m2, l3, M2, R2);
                        }
                        break;
                      case 253:
                        r11 = oM(v2[Z2.isst].t, Z2.ixfe, "s"), v2[Z2.isst].h && (r11.h = v2[Z2.isst].h), r11.XF = k2[r11.ixfe], W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2({ c: Z2.c, r: Z2.r }, r11, t11);
                        break;
                      case 513:
                        t11.sheetStubs && (r11 = { ixfe: Z2.ixfe, XF: k2[Z2.ixfe], t: "z" }, W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2({ c: Z2.c, r: Z2.r }, r11, t11));
                        break;
                      case 190:
                        if (t11.sheetStubs)
                          for (var ec2 = Z2.c; ec2 <= Z2.C; ++ec2) {
                            var el2 = Z2.ixfe[ec2 - Z2.c];
                            r11 = { ixfe: el2, XF: k2[el2], t: "z" }, W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2({ c: ec2, r: Z2.r }, r11, t11);
                          }
                        break;
                      case 214:
                      case 516:
                      case 4:
                        (r11 = oM(Z2.val, Z2.ixfe, "s")).XF = k2[r11.ixfe], W2 > 0 && (r11.z = r11.XF && r11.XF.numFmtId && z2[r11.XF.numFmtId] || z2[r11.ixfe >> 8 & 63]), oL(r11, t11, i11.opts.Date1904), O2({ c: Z2.c, r: Z2.r }, r11, t11);
                        break;
                      case 0:
                      case 512:
                        1 === B2 && (m2 = Z2);
                        break;
                      case 252:
                        v2 = Z2;
                        break;
                      case 1054:
                        if (R2.biff >= 3 && R2.biff <= 4) {
                          z2[W2++] = Z2[1];
                          for (var ef2 = 0; ef2 < W2 + 163 && eD[ef2] != Z2[1]; ++ef2) ;
                          ef2 >= 163 && te(Z2[1], W2 + 163);
                        } else te(Z2[1], Z2[0]);
                        break;
                      case 30:
                        z2[W2++] = Z2;
                        for (var eh2 = 0; eh2 < W2 + 163 && eD[eh2] != Z2; ++eh2) ;
                        eh2 >= 163 && te(Z2, W2 + 163);
                        break;
                      case 229:
                        N2 = N2.concat(Z2);
                        break;
                      case 93:
                        F2[Z2.cmo[0]] = R2.lastobj = Z2;
                        break;
                      case 438:
                        R2.lastobj.TxO = Z2;
                        break;
                      case 127:
                        R2.lastobj.ImData = Z2;
                        break;
                      case 440:
                        for (d2 = Z2[0].s.r; d2 <= Z2[0].e.r; ++d2)
                          for (u2 = Z2[0].s.c; u2 <= Z2[0].e.c; ++u2)
                            (f2 = t11.dense ? (c11["!data"][d2] || [])[u2] : c11[ab({ c: u2, r: d2 })]) && (f2.l = Z2[1]);
                        break;
                      case 2048:
                        for (d2 = Z2[0].s.r; d2 <= Z2[0].e.r; ++d2)
                          for (u2 = Z2[0].s.c; u2 <= Z2[0].e.c; ++u2)
                            (f2 = t11.dense ? (c11["!data"][d2] || [])[u2] : c11[ab({ c: u2, r: d2 })]) && f2.l && (f2.l.Tooltip = Z2[1]);
                        break;
                      case 28:
                        if ((f2 = t11.dense ? (c11["!data"][Z2[0].r] || [])[Z2[0].c] : c11[ab(Z2[0])]) || (t11.dense ? (c11["!data"][Z2[0].r] || (c11["!data"][Z2[0].r] = []), f2 = c11["!data"][Z2[0].r][Z2[0].c] = { t: "z" }) : f2 = c11[ab(Z2[0])] = { t: "z" }, m2.e.r = Math.max(m2.e.r, Z2[0].r), m2.s.r = Math.min(m2.s.r, Z2[0].r), m2.e.c = Math.max(m2.e.c, Z2[0].c), m2.s.c = Math.min(m2.s.c, Z2[0].c)), f2.c || (f2.c = []), R2.biff <= 5 && R2.biff >= 2)
                          h2 = { a: "SheetJ5", t: Z2[1] };
                        else {
                          var eu2 = F2[Z2[2]];
                          h2 = { a: Z2[1], t: eu2.TxO.t }, null == Z2[3] || 2 & Z2[3] || (f2.c.hidden = true);
                        }
                        f2.c.push(h2);
                        break;
                      case 2173:
                        k2[Z2.ixfe], Z2.ext.forEach(function(e12) {
                          e12[0];
                        });
                        break;
                      case 125:
                        if (!R2.cellStyles) break;
                        for (; Z2.e >= Z2.s; )
                          D2[Z2.e--] = { width: Z2.w / 256, level: Z2.level || 0, hidden: !!(1 & Z2.flags) }, L2 || (L2 = true, sQ(Z2.w / 256)), s0(D2[Z2.e + 1]);
                        break;
                      case 520:
                        var ed2 = {};
                        null != Z2.level && (P2[Z2.r] = ed2, ed2.level = Z2.level), Z2.hidden && (P2[Z2.r] = ed2, ed2.hidden = true), Z2.hpt && (P2[Z2.r] = ed2, ed2.hpt = Z2.hpt, ed2.hpx = s2(Z2.hpt));
                        break;
                      case 38:
                      case 39:
                      case 40:
                      case 41:
                        c11["!margins"] || i0(c11["!margins"] = {}), c11["!margins"][{ 38: "left", 39: "right", 40: "top", 41: "bottom" }[X2]] = Z2;
                        break;
                      case 161:
                        c11["!margins"] || i0(c11["!margins"] = {}), c11["!margins"].header = Z2.header, c11["!margins"].footer = Z2.footer;
                        break;
                      case 574:
                        Z2.RTL && (_2.Views[0].RTL = true);
                        break;
                      case 146:
                        x2 = Z2;
                        break;
                      case 2198:
                        n11 = Z2;
                        break;
                      case 140:
                        a11 = Z2;
                        break;
                      case 442:
                        b2 ? S2.CodeName = Z2 || S2.name : _2.WBProps.CodeName = Z2 || "ThisWorkbook";
                    }
                  } else K2 || console.error("Missing Info for XLS Record 0x" + X2.toString(16)), e11.l += j2;
                }
                return i11.SheetNames = ts(p2).sort(function(e12, t12) {
                  return Number(e12) - Number(t12);
                }).map(function(e12) {
                  return p2[e12].name;
                }), t11.bookSheets || (i11.Sheets = o11), !i11.SheetNames.length && w2["!ref"] ? (i11.SheetNames.push("Sheet1"), i11.Sheets && (i11.Sheets.Sheet1 = w2)) : i11.Preamble = w2, i11.Sheets && H2.forEach(function(e12, t12) {
                  i11.Sheets[i11.SheetNames[t12]]["!autofilter"] = e12;
                }), i11.Strings = v2, i11.SSF = tw(eD), R2.enc && (i11.Encryption = R2.enc), n11 && (i11.Themes = n11), i11.Metadata = {}, void 0 !== a11 && (i11.Metadata.Country = a11), M2.names.length > 0 && (_2.Names = M2.names), i11.Workbook = _2, i11;
              })(s10.content, t10);
            else if ((o10 = tr.find(e10, "PerfectOffice_MAIN")) && o10.content)
              i10 = sA.to_workbook(o10.content, (t10.type = c10, t10));
            else if ((o10 = tr.find(e10, "NativeContent_MAIN")) && o10.content)
              i10 = sA.to_workbook(o10.content, (t10.type = c10, t10));
            else if ((o10 = tr.find(e10, "MN0")) && o10.content) throw Error("Unsupported Works 4 for Mac file");
            else throw Error("Cannot find Workbook stream");
            t10.bookVBA && e10.FullPaths && tr.find(e10, "/_VBA_PROJECT_CUR/VBA/dir") && (i10.vbaraw = (r10 = e10, a10 = tr.utils.cfb_new({ root: "R" }), r10.FullPaths.forEach(function(e11, t11) {
              if ("/" !== e11.slice(-1) && e11.match(/_VBA_PROJECT_CUR/)) {
                var n11 = e11.replace(/^[^\/]*/, "R").replace(/\/_VBA_PROJECT_CUR\u0000*/, "");
                tr.utils.cfb_add(a10, n11, r10.FileIndex[t11].content);
              }
            }), tr.write(a10)));
          }
          var l2 = {};
          return e10.FullPaths && (function(e11, t11, r11) {
            var a11 = tr.find(e11, "/!DocumentSummaryInformation");
            if (a11 && a11.size > 0)
              try {
                var n11 = nz(a11, aK, oB);
                for (var s11 in n11) t11[s11] = n11[s11];
              } catch (e12) {
                if (r11.WTF) throw e12;
              }
            var i11 = tr.find(e11, "/!SummaryInformation");
            if (i11 && i11.size > 0)
              try {
                var o11 = nz(i11, aY, oU);
                for (var c11 in o11) null == t11[c11] && (t11[c11] = o11[c11]);
              } catch (e12) {
                if (r11.WTF) throw e12;
              }
            t11.HeadingPairs && t11.TitlesOfParts && (nS(t11.HeadingPairs, t11.TitlesOfParts, t11, r11), delete t11.HeadingPairs, delete t11.TitlesOfParts);
          })(e10, l2, t10), i10.Props = i10.Custprops = l2, t10.bookFiles && (i10.cfb = e10), i10;
        }
        var oz = {
          0: {
            f: function(e10, t10) {
              var r10 = {}, a10 = e10.l + t10;
              r10.r = e10.read_shift(4), e10.l += 4;
              var n10 = e10.read_shift(2);
              e10.l += 1;
              var s10 = e10.read_shift(1);
              return e10.l = a10, 7 & s10 && (r10.level = 7 & s10), 16 & s10 && (r10.hidden = true), 32 & s10 && (r10.hpt = n10 / 20), r10;
            }
          },
          1: {
            f: function(e10) {
              return [aF(e10)];
            }
          },
          2: {
            f: function(e10) {
              return [aF(e10), aB(e10), "n"];
            }
          },
          3: {
            f: function(e10) {
              return [aF(e10), e10.read_shift(1), "e"];
            }
          },
          4: {
            f: function(e10) {
              return [aF(e10), e10.read_shift(1), "b"];
            }
          },
          5: {
            f: function(e10) {
              return [aF(e10), aV(e10), "n"];
            }
          },
          6: {
            f: function(e10) {
              return [aF(e10), aO(e10), "str"];
            }
          },
          7: {
            f: function(e10) {
              return [aF(e10), e10.read_shift(4), "s"];
            }
          },
          8: {
            f: function(e10, t10, r10) {
              var a10 = e10.l + t10, n10 = aF(e10);
              n10.r = r10["!row"];
              var s10 = [n10, aO(e10), "str"];
              if (r10.cellFormula) {
                e10.l += 2;
                var i10 = iW(e10, a10 - e10.l, r10);
                s10[3] = iU(i10, null, n10, r10.supbooks, r10);
              } else e10.l = a10;
              return s10;
            }
          },
          9: {
            f: function(e10, t10, r10) {
              var a10 = e10.l + t10, n10 = aF(e10);
              n10.r = r10["!row"];
              var s10 = [n10, aV(e10), "n"];
              if (r10.cellFormula) {
                e10.l += 2;
                var i10 = iW(e10, a10 - e10.l, r10);
                s10[3] = iU(i10, null, n10, r10.supbooks, r10);
              } else e10.l = a10;
              return s10;
            }
          },
          10: {
            f: function(e10, t10, r10) {
              var a10 = e10.l + t10, n10 = aF(e10);
              n10.r = r10["!row"];
              var s10 = [n10, e10.read_shift(1), "b"];
              if (r10.cellFormula) {
                e10.l += 2;
                var i10 = iW(e10, a10 - e10.l, r10);
                s10[3] = iU(i10, null, n10, r10.supbooks, r10);
              } else e10.l = a10;
              return s10;
            }
          },
          11: {
            f: function(e10, t10, r10) {
              var a10 = e10.l + t10, n10 = aF(e10);
              n10.r = r10["!row"];
              var s10 = [n10, e10.read_shift(1), "e"];
              if (r10.cellFormula) {
                e10.l += 2;
                var i10 = iW(e10, a10 - e10.l, r10);
                s10[3] = iU(i10, null, n10, r10.supbooks, r10);
              } else e10.l = a10;
              return s10;
            }
          },
          12: {
            f: function(e10) {
              return [aP(e10)];
            }
          },
          13: {
            f: function(e10) {
              return [aP(e10), aB(e10), "n"];
            }
          },
          14: {
            f: function(e10) {
              return [aP(e10), e10.read_shift(1), "e"];
            }
          },
          15: {
            f: function(e10) {
              return [aP(e10), e10.read_shift(1), "b"];
            }
          },
          16: { f: oo },
          17: {
            f: function(e10) {
              return [aP(e10), aO(e10), "str"];
            }
          },
          18: {
            f: function(e10) {
              return [aP(e10), e10.read_shift(4), "s"];
            }
          },
          19: { f: aN },
          20: {},
          21: {},
          22: {},
          23: {},
          24: {},
          25: {},
          26: {},
          27: {},
          28: {},
          29: {},
          30: {},
          31: {},
          32: {},
          33: {},
          34: {},
          35: { T: 1 },
          36: { T: -1 },
          37: { T: 1 },
          38: { T: -1 },
          39: {
            f: function(e10, t10, r10) {
              var a10, n10 = e10.l + t10, s10 = e10.read_shift(4);
              e10.l += 1;
              var i10 = e10.read_shift(4), o10 = aO(e10), c10 = "";
              try {
                a10 = iW(e10, 0, r10);
                try {
                  c10 = aM(e10);
                } catch (e11) {
                }
              } catch (e11) {
                console.error("Could not parse defined name " + o10);
              }
              32 & s10 && (o10 = "_xlnm." + o10), e10.l = n10;
              var l2 = { Name: o10, Ptg: a10, Flags: s10 };
              return i10 < 268435455 && (l2.Sheet = i10), c10 && (l2.Comment = c10), l2;
            }
          },
          40: {},
          42: {},
          43: {
            f: function(e10, t10, r10) {
              var a10, n10 = {};
              n10.sz = e10.read_shift(2) / 20;
              var s10 = (a10 = e10.read_shift(1), e10.l++, {
                fBold: 1 & a10,
                fItalic: 2 & a10,
                fUnderline: 4 & a10,
                fStrikeout: 8 & a10,
                fOutline: 16 & a10,
                fShadow: 32 & a10,
                fCondense: 64 & a10,
                fExtend: 128 & a10
              });
              switch (s10.fItalic && (n10.italic = 1), s10.fCondense && (n10.condense = 1), s10.fExtend && (n10.extend = 1), s10.fShadow && (n10.shadow = 1), s10.fOutline && (n10.outline = 1), s10.fStrikeout && (n10.strike = 1), 700 === e10.read_shift(2) && (n10.bold = 1), e10.read_shift(2)) {
                case 1:
                  n10.vertAlign = "superscript";
                  break;
                case 2:
                  n10.vertAlign = "subscript";
              }
              var i10 = e10.read_shift(1);
              0 != i10 && (n10.underline = i10);
              var o10 = e10.read_shift(1);
              o10 > 0 && (n10.family = o10);
              var c10 = e10.read_shift(1);
              switch (c10 > 0 && (n10.charset = c10), e10.l++, n10.color = (function(e11) {
                var t11 = {}, r11 = e11.read_shift(1), a11 = e11.read_shift(1), n11 = e11.read_shift(2, "i"), s11 = e11.read_shift(1), i11 = e11.read_shift(1), o11 = e11.read_shift(1);
                switch (e11.l++, r11 >>> 1) {
                  case 0:
                    t11.auto = 1;
                    break;
                  case 1:
                    t11.index = a11;
                    var c11 = aq[a11];
                    c11 && (t11.rgb = sX(c11));
                    break;
                  case 2:
                    t11.rgb = sX([s11, i11, o11]);
                    break;
                  case 3:
                    t11.theme = a11;
                }
                return 0 != n11 && (t11.tint = n11 > 0 ? n11 / 32767 : n11 / 32768), t11;
              })(e10, 8), e10.read_shift(1)) {
                case 1:
                  n10.scheme = "major";
                  break;
                case 2:
                  n10.scheme = "minor";
              }
              return n10.name = aO(e10, t10 - 21), n10;
            }
          },
          44: {
            f: function(e10, t10) {
              return [e10.read_shift(2), aO(e10, t10 - 2)];
            }
          },
          45: { f: an },
          46: { f: an },
          47: {
            f: function(e10, t10) {
              var r10 = e10.l + t10, a10 = e10.read_shift(2), n10 = e10.read_shift(2);
              return e10.l = r10, { ixfe: a10, numFmtId: n10 };
            }
          },
          48: {},
          49: {
            f: function(e10) {
              return e10.read_shift(4, "i");
            }
          },
          50: {},
          51: {
            f: function(e10) {
              for (var t10 = [], r10 = e10.read_shift(4); r10-- > 0; ) t10.push([e10.read_shift(4), e10.read_shift(4)]);
              return t10;
            }
          },
          52: { T: 1 },
          53: { T: -1 },
          54: { T: 1 },
          55: { T: -1 },
          56: { T: 1 },
          57: { T: -1 },
          58: {},
          59: {},
          60: { f: sw },
          62: {
            f: function(e10) {
              return [aF(e10), aN(e10), "is"];
            }
          },
          63: {
            f: function(e10) {
              var t10 = {};
              t10.i = e10.read_shift(4);
              var r10 = {};
              r10.r = e10.read_shift(4), r10.c = e10.read_shift(4), t10.r = ab(r10);
              var a10 = e10.read_shift(1);
              return 2 & a10 && (t10.l = "1"), 8 & a10 && (t10.a = "1"), t10;
            }
          },
          64: { f: function() {
          } },
          65: {},
          66: {},
          67: {},
          68: {},
          69: {},
          70: {},
          128: {},
          129: { T: 1 },
          130: { T: -1 },
          131: { T: 1, f: an, p: 0 },
          132: { T: -1 },
          133: { T: 1 },
          134: { T: -1 },
          135: { T: 1 },
          136: { T: -1 },
          137: {
            T: 1,
            f: function(e10) {
              var t10 = e10.read_shift(2);
              return e10.l += 28, { RTL: 32 & t10 };
            }
          },
          138: { T: -1 },
          139: { T: 1 },
          140: { T: -1 },
          141: { T: 1 },
          142: { T: -1 },
          143: { T: 1 },
          144: { T: -1 },
          145: { T: 1 },
          146: { T: -1 },
          147: {
            f: function(e10, t10) {
              var r10 = {}, a10 = e10[e10.l];
              return ++e10.l, r10.above = !(64 & a10), r10.left = !(128 & a10), e10.l += 18, r10.name = aO(e10, t10 - 19), r10;
            }
          },
          148: { f: az, p: 16 },
          151: { f: function() {
          } },
          152: {},
          153: {
            f: function(e10, t10) {
              var r10 = {}, a10 = e10.read_shift(4);
              r10.defaultThemeVersion = e10.read_shift(4);
              var n10 = t10 > 8 ? aO(e10) : "";
              return n10.length > 0 && (r10.CodeName = n10), r10.autoCompressPictures = !!(65536 & a10), r10.backupFile = !!(64 & a10), r10.checkCompatibility = !!(4096 & a10), r10.date1904 = !!(1 & a10), r10.filterPrivacy = !!(8 & a10), r10.hidePivotFieldList = !!(1024 & a10), r10.promptedSolutions = !!(16 & a10), r10.publishItems = !!(2048 & a10), r10.refreshAllConnections = !!(262144 & a10), r10.saveExternalLinkValues = !!(128 & a10), r10.showBorderUnselectedTables = !!(4 & a10), r10.showInkAnnotation = !!(32 & a10), r10.showObjects = ["all", "placeholders", "none"][a10 >> 13 & 3], r10.showPivotChartFilter = !!(32768 & a10), r10.updateLinks = ["userSet", "never", "always"][a10 >> 8 & 3], r10;
            }
          },
          154: {},
          155: {},
          156: {
            f: function(e10, t10) {
              var r10 = {};
              return r10.Hidden = e10.read_shift(4), r10.iTabID = e10.read_shift(4), r10.strRelID = aM(e10, t10 - 8), r10.name = aO(e10), r10;
            }
          },
          157: {},
          158: {},
          159: {
            T: 1,
            f: function(e10) {
              return [e10.read_shift(4), e10.read_shift(4)];
            }
          },
          160: { T: -1 },
          161: { T: 1, f: az },
          162: { T: -1 },
          163: { T: 1 },
          164: { T: -1 },
          165: { T: 1 },
          166: { T: -1 },
          167: {},
          168: {},
          169: {},
          170: {},
          171: {},
          172: { T: 1 },
          173: { T: -1 },
          174: {},
          175: {},
          176: { f: az },
          177: { T: 1 },
          178: { T: -1 },
          179: { T: 1 },
          180: { T: -1 },
          181: { T: 1 },
          182: { T: -1 },
          183: { T: 1 },
          184: { T: -1 },
          185: { T: 1 },
          186: { T: -1 },
          187: { T: 1 },
          188: { T: -1 },
          189: { T: 1 },
          190: { T: -1 },
          191: { T: 1 },
          192: { T: -1 },
          193: { T: 1 },
          194: { T: -1 },
          195: { T: 1 },
          196: { T: -1 },
          197: { T: 1 },
          198: { T: -1 },
          199: { T: 1 },
          200: { T: -1 },
          201: { T: 1 },
          202: { T: -1 },
          203: { T: 1 },
          204: { T: -1 },
          205: { T: 1 },
          206: { T: -1 },
          207: { T: 1 },
          208: { T: -1 },
          209: { T: 1 },
          210: { T: -1 },
          211: { T: 1 },
          212: { T: -1 },
          213: { T: 1 },
          214: { T: -1 },
          215: { T: 1 },
          216: { T: -1 },
          217: { T: 1 },
          218: { T: -1 },
          219: { T: 1 },
          220: { T: -1 },
          221: { T: 1 },
          222: { T: -1 },
          223: { T: 1 },
          224: { T: -1 },
          225: { T: 1 },
          226: { T: -1 },
          227: { T: 1 },
          228: { T: -1 },
          229: { T: 1 },
          230: { T: -1 },
          231: { T: 1 },
          232: { T: -1 },
          233: { T: 1 },
          234: { T: -1 },
          235: { T: 1 },
          236: { T: -1 },
          237: { T: 1 },
          238: { T: -1 },
          239: { T: 1 },
          240: { T: -1 },
          241: { T: 1 },
          242: { T: -1 },
          243: { T: 1 },
          244: { T: -1 },
          245: { T: 1 },
          246: { T: -1 },
          247: { T: 1 },
          248: { T: -1 },
          249: { T: 1 },
          250: { T: -1 },
          251: { T: 1 },
          252: { T: -1 },
          253: { T: 1 },
          254: { T: -1 },
          255: { T: 1 },
          256: { T: -1 },
          257: { T: 1 },
          258: { T: -1 },
          259: { T: 1 },
          260: { T: -1 },
          261: { T: 1 },
          262: { T: -1 },
          263: { T: 1 },
          264: { T: -1 },
          265: { T: 1 },
          266: { T: -1 },
          267: { T: 1 },
          268: { T: -1 },
          269: { T: 1 },
          270: { T: -1 },
          271: { T: 1 },
          272: { T: -1 },
          273: { T: 1 },
          274: { T: -1 },
          275: { T: 1 },
          276: { T: -1 },
          277: {},
          278: { T: 1 },
          279: { T: -1 },
          280: { T: 1 },
          281: { T: -1 },
          282: { T: 1 },
          283: { T: 1 },
          284: { T: -1 },
          285: { T: 1 },
          286: { T: -1 },
          287: { T: 1 },
          288: { T: -1 },
          289: { T: 1 },
          290: { T: -1 },
          291: { T: 1 },
          292: { T: -1 },
          293: { T: 1 },
          294: { T: -1 },
          295: { T: 1 },
          296: { T: -1 },
          297: { T: 1 },
          298: { T: -1 },
          299: { T: 1 },
          300: { T: -1 },
          301: { T: 1 },
          302: { T: -1 },
          303: { T: 1 },
          304: { T: -1 },
          305: { T: 1 },
          306: { T: -1 },
          307: { T: 1 },
          308: { T: -1 },
          309: { T: 1 },
          310: { T: -1 },
          311: { T: 1 },
          312: { T: -1 },
          313: { T: -1 },
          314: { T: 1 },
          315: { T: -1 },
          316: { T: 1 },
          317: { T: -1 },
          318: { T: 1 },
          319: { T: -1 },
          320: { T: 1 },
          321: { T: -1 },
          322: { T: 1 },
          323: { T: -1 },
          324: { T: 1 },
          325: { T: -1 },
          326: { T: 1 },
          327: { T: -1 },
          328: { T: 1 },
          329: { T: -1 },
          330: { T: 1 },
          331: { T: -1 },
          332: { T: 1 },
          333: { T: -1 },
          334: { T: 1 },
          335: {
            f: function(e10, t10) {
              return { flags: e10.read_shift(4), version: e10.read_shift(4), name: aO(e10, t10 - 8) };
            }
          },
          336: { T: -1 },
          337: {
            f: function(e10) {
              return e10.l += 4, 0 != e10.read_shift(4);
            },
            T: 1
          },
          338: { T: -1 },
          339: { T: 1 },
          340: { T: -1 },
          341: { T: 1 },
          342: { T: -1 },
          343: { T: 1 },
          344: { T: -1 },
          345: { T: 1 },
          346: { T: -1 },
          347: { T: 1 },
          348: { T: -1 },
          349: { T: 1 },
          350: { T: -1 },
          351: {},
          352: {},
          353: { T: 1 },
          354: { T: -1 },
          355: { f: aM },
          357: {},
          358: {},
          359: {},
          360: { T: 1 },
          361: {},
          362: { f: sm },
          363: {},
          364: {},
          366: {},
          367: {},
          368: {},
          369: {},
          370: {},
          371: {},
          372: { T: 1 },
          373: { T: -1 },
          374: { T: 1 },
          375: { T: -1 },
          376: { T: 1 },
          377: { T: -1 },
          378: { T: 1 },
          379: { T: -1 },
          380: { T: 1 },
          381: { T: -1 },
          382: { T: 1 },
          383: { T: -1 },
          384: { T: 1 },
          385: { T: -1 },
          386: { T: 1 },
          387: { T: -1 },
          388: { T: 1 },
          389: { T: -1 },
          390: { T: 1 },
          391: { T: -1 },
          392: { T: 1 },
          393: { T: -1 },
          394: { T: 1 },
          395: { T: -1 },
          396: {},
          397: {},
          398: {},
          399: {},
          400: {},
          401: { T: 1 },
          403: {},
          404: {},
          405: {},
          406: {},
          407: {},
          408: {},
          409: {},
          410: {},
          411: {},
          412: {},
          413: {},
          414: {},
          415: {},
          416: {},
          417: {},
          418: {},
          419: {},
          420: {},
          421: {},
          422: { T: 1 },
          423: { T: 1 },
          424: { T: -1 },
          425: { T: -1 },
          426: {
            f: function(e10, t10, r10) {
              var a10 = e10.l + t10, n10 = az(e10, 16), s10 = e10.read_shift(1), i10 = [n10];
              if (i10[2] = s10, r10.cellFormula) {
                var o10 = iW(e10, a10 - e10.l, r10);
                i10[1] = o10;
              } else e10.l = a10;
              return i10;
            }
          },
          427: {
            f: function(e10, t10, r10) {
              var a10 = e10.l + t10, n10 = [az(e10, 16)];
              if (r10.cellFormula) {
                var s10 = iW(e10, a10 - e10.l, r10);
                n10[1] = s10, e10.l = a10;
              } else e10.l = a10;
              return n10;
            }
          },
          428: {},
          429: { T: 1 },
          430: { T: -1 },
          431: { T: 1 },
          432: { T: -1 },
          433: { T: 1 },
          434: { T: -1 },
          435: { T: 1 },
          436: { T: -1 },
          437: { T: 1 },
          438: { T: -1 },
          439: { T: 1 },
          440: { T: -1 },
          441: { T: 1 },
          442: { T: -1 },
          443: { T: 1 },
          444: { T: -1 },
          445: { T: 1 },
          446: { T: -1 },
          447: { T: 1 },
          448: { T: -1 },
          449: { T: 1 },
          450: { T: -1 },
          451: { T: 1 },
          452: { T: -1 },
          453: { T: 1 },
          454: { T: -1 },
          455: { T: 1 },
          456: { T: -1 },
          457: { T: 1 },
          458: { T: -1 },
          459: { T: 1 },
          460: { T: -1 },
          461: { T: 1 },
          462: { T: -1 },
          463: { T: 1 },
          464: { T: -1 },
          465: { T: 1 },
          466: { T: -1 },
          467: { T: 1 },
          468: { T: -1 },
          469: { T: 1 },
          470: { T: -1 },
          471: {},
          472: {},
          473: { T: 1 },
          474: { T: -1 },
          475: {},
          476: {
            f: function(e10) {
              var t10 = {};
              return oc.forEach(function(r10) {
                t10[r10] = aV(e10, 8);
              }), t10;
            }
          },
          477: {},
          478: {},
          479: { T: 1 },
          480: { T: -1 },
          481: { T: 1 },
          482: { T: -1 },
          483: { T: 1 },
          484: { T: -1 },
          485: { f: function() {
          } },
          486: { T: 1 },
          487: { T: -1 },
          488: { T: 1 },
          489: { T: -1 },
          490: { T: 1 },
          491: { T: -1 },
          492: { T: 1 },
          493: { T: -1 },
          494: {
            f: function(e10, t10) {
              var r10 = e10.l + t10, a10 = az(e10, 16), n10 = aM(e10), s10 = aO(e10), i10 = aO(e10), o10 = aO(e10);
              e10.l = r10;
              var c10 = { rfx: a10, relId: n10, loc: s10, display: o10 };
              return i10 && (c10.Tooltip = i10), c10;
            }
          },
          495: { T: 1 },
          496: { T: -1 },
          497: { T: 1 },
          498: { T: -1 },
          499: {},
          500: { T: 1 },
          501: { T: -1 },
          502: { T: 1 },
          503: { T: -1 },
          504: {},
          505: { T: 1 },
          506: { T: -1 },
          507: {},
          508: { T: 1 },
          509: { T: -1 },
          510: { T: 1 },
          511: { T: -1 },
          512: {},
          513: {},
          514: { T: 1 },
          515: { T: -1 },
          516: { T: 1 },
          517: { T: -1 },
          518: { T: 1 },
          519: { T: -1 },
          520: { T: 1 },
          521: { T: -1 },
          522: {},
          523: {},
          524: {},
          525: {},
          526: {},
          527: {},
          528: { T: 1 },
          529: { T: -1 },
          530: { T: 1 },
          531: { T: -1 },
          532: { T: 1 },
          533: { T: -1 },
          534: {},
          535: {},
          536: {},
          537: {},
          538: { T: 1 },
          539: { T: -1 },
          540: { T: 1 },
          541: { T: -1 },
          542: { T: 1 },
          548: {},
          549: {},
          550: { f: aM },
          551: { f: aM },
          552: {},
          553: {},
          554: { T: 1 },
          555: { T: -1 },
          556: { T: 1 },
          557: { T: -1 },
          558: { T: 1 },
          559: { T: -1 },
          560: { T: 1 },
          561: { T: -1 },
          562: {},
          564: {},
          565: { T: 1 },
          566: { T: -1 },
          569: { T: 1 },
          570: { T: -1 },
          572: {},
          573: { T: 1 },
          574: { T: -1 },
          577: {},
          578: {},
          579: {},
          580: {},
          581: {},
          582: {},
          583: {},
          584: {},
          585: {},
          586: {},
          587: {},
          588: { T: -1 },
          589: {},
          590: { T: 1 },
          591: { T: -1 },
          592: { T: 1 },
          593: { T: -1 },
          594: { T: 1 },
          595: { T: -1 },
          596: {},
          597: { T: 1 },
          598: { T: -1 },
          599: { T: 1 },
          600: { T: -1 },
          601: { T: 1 },
          602: { T: -1 },
          603: { T: 1 },
          604: { T: -1 },
          605: { T: 1 },
          606: { T: -1 },
          607: {},
          608: { T: 1 },
          609: { T: -1 },
          610: {},
          611: { T: 1 },
          612: { T: -1 },
          613: { T: 1 },
          614: { T: -1 },
          615: { T: 1 },
          616: { T: -1 },
          617: { T: 1 },
          618: { T: -1 },
          619: { T: 1 },
          620: { T: -1 },
          625: {},
          626: { T: 1 },
          627: { T: -1 },
          628: { T: 1 },
          629: { T: -1 },
          630: { T: 1 },
          631: { T: -1 },
          632: { f: aO },
          633: { T: 1 },
          634: { T: -1 },
          635: {
            T: 1,
            f: function(e10) {
              var t10 = {};
              t10.iauthor = e10.read_shift(4);
              var r10 = az(e10, 16);
              return t10.rfx = r10.s, t10.ref = ab(r10.s), e10.l += 16, t10;
            }
          },
          636: { T: -1 },
          637: { f: aN },
          638: { T: 1 },
          639: {},
          640: { T: -1 },
          641: { T: 1 },
          642: { T: -1 },
          643: { T: 1 },
          644: {},
          645: { T: -1 },
          646: { T: 1 },
          648: { T: 1 },
          649: {},
          650: { T: -1 },
          651: {
            f: function(e10, t10) {
              return e10.l += 10, { name: aO(e10, t10 - 10) };
            }
          },
          652: {},
          653: { T: 1 },
          654: { T: -1 },
          655: { T: 1 },
          656: { T: -1 },
          657: { T: 1 },
          658: { T: -1 },
          659: {},
          660: { T: 1 },
          661: {},
          662: { T: -1 },
          663: {},
          664: { T: 1 },
          665: {},
          666: { T: -1 },
          667: {},
          668: {},
          669: {},
          671: { T: 1 },
          672: { T: -1 },
          673: { T: 1 },
          674: { T: -1 },
          675: {},
          676: {},
          677: {},
          678: {},
          679: {},
          680: {},
          681: {},
          1024: {},
          1025: {},
          1026: { T: 1 },
          1027: { T: -1 },
          1028: { T: 1 },
          1029: { T: -1 },
          1030: {},
          1031: { T: 1 },
          1032: { T: -1 },
          1033: { T: 1 },
          1034: { T: -1 },
          1035: {},
          1036: {},
          1037: {},
          1038: { T: 1 },
          1039: { T: -1 },
          1040: {},
          1041: { T: 1 },
          1042: { T: -1 },
          1043: {},
          1044: {},
          1045: {},
          1046: { T: 1 },
          1047: { T: -1 },
          1048: { T: 1 },
          1049: { T: -1 },
          1050: {},
          1051: { T: 1 },
          1052: { T: 1 },
          1053: { f: function() {
          } },
          1054: { T: 1 },
          1055: {},
          1056: { T: 1 },
          1057: { T: -1 },
          1058: { T: 1 },
          1059: { T: -1 },
          1061: {},
          1062: { T: 1 },
          1063: { T: -1 },
          1064: { T: 1 },
          1065: { T: -1 },
          1066: { T: 1 },
          1067: { T: -1 },
          1068: { T: 1 },
          1069: { T: -1 },
          1070: { T: 1 },
          1071: { T: -1 },
          1072: { T: 1 },
          1073: { T: -1 },
          1075: { T: 1 },
          1076: { T: -1 },
          1077: { T: 1 },
          1078: { T: -1 },
          1079: { T: 1 },
          1080: { T: -1 },
          1081: { T: 1 },
          1082: { T: -1 },
          1083: { T: 1 },
          1084: { T: -1 },
          1085: {},
          1086: { T: 1 },
          1087: { T: -1 },
          1088: { T: 1 },
          1089: { T: -1 },
          1090: { T: 1 },
          1091: { T: -1 },
          1092: { T: 1 },
          1093: { T: -1 },
          1094: { T: 1 },
          1095: { T: -1 },
          1096: {},
          1097: { T: 1 },
          1098: {},
          1099: { T: -1 },
          1100: { T: 1 },
          1101: { T: -1 },
          1102: {},
          1103: {},
          1104: {},
          1105: {},
          1111: {},
          1112: {},
          1113: { T: 1 },
          1114: { T: -1 },
          1115: { T: 1 },
          1116: { T: -1 },
          1117: {},
          1118: { T: 1 },
          1119: { T: -1 },
          1120: { T: 1 },
          1121: { T: -1 },
          1122: { T: 1 },
          1123: { T: -1 },
          1124: { T: 1 },
          1125: { T: -1 },
          1126: {},
          1128: { T: 1 },
          1129: { T: -1 },
          1130: {},
          1131: { T: 1 },
          1132: { T: -1 },
          1133: { T: 1 },
          1134: { T: -1 },
          1135: { T: 1 },
          1136: { T: -1 },
          1137: { T: 1 },
          1138: { T: -1 },
          1139: { T: 1 },
          1140: { T: -1 },
          1141: {},
          1142: { T: 1 },
          1143: { T: -1 },
          1144: { T: 1 },
          1145: { T: -1 },
          1146: {},
          1147: { T: 1 },
          1148: { T: -1 },
          1149: { T: 1 },
          1150: { T: -1 },
          1152: { T: 1 },
          1153: { T: -1 },
          1154: { T: -1 },
          1155: { T: -1 },
          1156: { T: -1 },
          1157: { T: 1 },
          1158: { T: -1 },
          1159: { T: 1 },
          1160: { T: -1 },
          1161: { T: 1 },
          1162: { T: -1 },
          1163: { T: 1 },
          1164: { T: -1 },
          1165: { T: 1 },
          1166: { T: -1 },
          1167: { T: 1 },
          1168: { T: -1 },
          1169: { T: 1 },
          1170: { T: -1 },
          1171: {},
          1172: { T: 1 },
          1173: { T: -1 },
          1177: {},
          1178: { T: 1 },
          1180: {},
          1181: {},
          1182: {},
          2048: { T: 1 },
          2049: { T: -1 },
          2050: {},
          2051: { T: 1 },
          2052: { T: -1 },
          2053: {},
          2054: {},
          2055: { T: 1 },
          2056: { T: -1 },
          2057: { T: 1 },
          2058: { T: -1 },
          2060: {},
          2067: {},
          2068: { T: 1 },
          2069: { T: -1 },
          2070: {},
          2071: {},
          2072: { T: 1 },
          2073: { T: -1 },
          2075: {},
          2076: {},
          2077: { T: 1 },
          2078: { T: -1 },
          2079: {},
          2080: { T: 1 },
          2081: { T: -1 },
          2082: {},
          2083: { T: 1 },
          2084: { T: -1 },
          2085: { T: 1 },
          2086: { T: -1 },
          2087: { T: 1 },
          2088: { T: -1 },
          2089: { T: 1 },
          2090: { T: -1 },
          2091: {},
          2092: {},
          2093: { T: 1 },
          2094: { T: -1 },
          2095: {},
          2096: { T: 1 },
          2097: { T: -1 },
          2098: { T: 1 },
          2099: { T: -1 },
          2100: { T: 1 },
          2101: { T: -1 },
          2102: {},
          2103: { T: 1 },
          2104: { T: -1 },
          2105: {},
          2106: { T: 1 },
          2107: { T: -1 },
          2108: {},
          2109: { T: 1 },
          2110: { T: -1 },
          2111: { T: 1 },
          2112: { T: -1 },
          2113: { T: 1 },
          2114: { T: -1 },
          2115: {},
          2116: {},
          2117: {},
          2118: { T: 1 },
          2119: { T: -1 },
          2120: {},
          2121: { T: 1 },
          2122: { T: -1 },
          2123: { T: 1 },
          2124: { T: -1 },
          2125: {},
          2126: { T: 1 },
          2127: { T: -1 },
          2128: {},
          2129: { T: 1 },
          2130: { T: -1 },
          2131: { T: 1 },
          2132: { T: -1 },
          2133: { T: 1 },
          2134: {},
          2135: {},
          2136: {},
          2137: { T: 1 },
          2138: { T: -1 },
          2139: { T: 1 },
          2140: { T: -1 },
          2141: {},
          3072: {},
          3073: {},
          4096: { T: 1 },
          4097: { T: -1 },
          5002: { T: 1 },
          5003: { T: -1 },
          5081: { T: 1 },
          5082: { T: -1 },
          5083: {},
          5084: { T: 1 },
          5085: { T: -1 },
          5086: { T: 1 },
          5087: { T: -1 },
          5088: {},
          5089: {},
          5090: {},
          5092: { T: 1 },
          5093: { T: -1 },
          5094: {},
          5095: { T: 1 },
          5096: { T: -1 },
          5097: {},
          5099: {},
          65535: { n: "" }
        }, oH = {
          6: { f: iB },
          10: { f: nV },
          12: { f: nX },
          13: { f: nX },
          14: { f: n$ },
          15: { f: n$ },
          16: { f: aV },
          17: { f: n$ },
          18: { f: n$ },
          19: { f: nX },
          20: { f: su },
          21: { f: su },
          23: { f: sm },
          24: { f: sp },
          25: { f: n$ },
          26: {},
          27: {},
          28: {
            f: function(e10, t10, r10) {
              if (r10 && r10.biff < 8) {
                var a10, n10, s10, i10, o10 = e10.read_shift(2), c10 = e10.read_shift(2);
                if (65535 == o10 || -1 == o10) return;
                var l2 = e10.read_shift(2);
                return [{ r: o10, c: c10 }, e10.read_shift(Math.min(l2, 2048), "cpstr")];
              }
              return a10 = e10.read_shift(2), n10 = e10.read_shift(2), s10 = e10.read_shift(2), i10 = e10.read_shift(2), [{ r: a10, c: n10 }, n0(e10, 0, r10), i10, s10];
            }
          },
          29: {},
          34: { f: n$ },
          35: { f: sd },
          38: { f: aV },
          39: { f: aV },
          40: { f: aV },
          41: { f: aV },
          42: { f: n$ },
          43: { f: n$ },
          47: {
            f: function(e10, t10, r10) {
              var a10, n10, s10, i10 = { Type: r10.biff >= 8 ? e10.read_shift(2) : 0 };
              return i10.Type ? (a10 = t10 - 2, (n10 = i10 || {}).Info = e10.read_shift(2), e10.l -= 2, 1 === n10.Info ? n10.Data = (function(e11) {
                var t11 = {}, r11 = t11.EncryptionVersionInfo = sU(e11, 4);
                if (1 != r11.Major || 1 != r11.Minor)
                  throw "unrecognized version code " + r11.Major + " : " + r11.Minor;
                return t11.Salt = e11.read_shift(16), t11.EncryptedVerifier = e11.read_shift(16), t11.EncryptedVerifierHash = e11.read_shift(16), t11;
              })(e10, a10) : n10.Data = (function(e11, t11) {
                var r11 = {}, a11 = r11.EncryptionVersionInfo = sU(e11, 4);
                if (t11 -= 4, 2 != a11.Minor) throw Error("unrecognized minor version code: " + a11.Minor);
                if (a11.Major > 4 || a11.Major < 2)
                  throw Error("unrecognized major version code: " + a11.Major);
                r11.Flags = e11.read_shift(4), t11 -= 4;
                var n11 = e11.read_shift(4);
                return t11 -= 4, r11.EncryptionHeader = sB(e11, n11), r11.EncryptionVerifier = sW(e11, t11 -= n11), r11;
              })(e10, a10)) : (r10.biff, s10 = { key: nX(e10), verificationBytes: nX(e10) }, r10.password && (s10.verifier = sz(r10.password)), i10.valid = s10.verificationBytes === s10.verifier, i10.valid && (i10.insitu = s$(r10.password))), i10;
            }
          },
          49: {
            f: function(e10, t10, r10) {
              var a10 = { dyHeight: e10.read_shift(2), fl: e10.read_shift(2) };
              switch (r10 && r10.biff || 8) {
                case 2:
                  break;
                case 3:
                case 4:
                  e10.l += 2;
                  break;
                default:
                  e10.l += 10;
              }
              return a10.name = nJ(e10, 0, r10), a10;
            }
          },
          51: { f: nX },
          60: {},
          61: {
            f: function(e10) {
              return {
                Pos: [e10.read_shift(2), e10.read_shift(2)],
                Dim: [e10.read_shift(2), e10.read_shift(2)],
                Flags: e10.read_shift(2),
                CurTab: e10.read_shift(2),
                FirstTab: e10.read_shift(2),
                Selected: e10.read_shift(2),
                TabRatio: e10.read_shift(2)
              };
            }
          },
          64: { f: n$ },
          65: { f: function() {
          } },
          66: { f: nX },
          77: {},
          80: {},
          81: {},
          82: {},
          85: { f: nX },
          89: {},
          90: {},
          91: {},
          92: {
            f: function(e10, t10, r10) {
              if (r10.enc) return e10.l += t10, "";
              var a10 = e10.l, n10 = n0(e10, 0, r10);
              return e10.read_shift(t10 + a10 - e10.l), n10;
            }
          },
          93: {
            f: function(e10, t10, r10) {
              if (r10 && r10.biff < 8) {
                var a10, n10, s10, i10, o10, c10, l2;
                return a10 = e10, n10 = t10, s10 = r10, a10.l += 4, i10 = a10.read_shift(2), o10 = a10.read_shift(2), c10 = a10.read_shift(2), a10.l += 2, a10.l += 2, a10.l += 2, a10.l += 2, a10.l += 2, a10.l += 2, a10.l += 2, a10.l += 2, a10.l += 2, a10.l += 6, n10 -= 36, (l2 = []).push((sb[i10] || an)(a10, n10, s10)), { cmo: [o10, i10, c10], ft: l2 };
              }
              var f2 = sr(e10, 22), h2 = (function(e11, t11) {
                for (var r11 = e11.l + t11, a11 = []; e11.l < r11; ) {
                  var n11 = e11.read_shift(2);
                  e11.l -= 2;
                  try {
                    a11[n11] = sn[n11](e11, r11 - e11.l);
                  } catch (t12) {
                    return e11.l = r11, a11;
                  }
                }
                return e11.l != r11 && (e11.l = r11), a11;
              })(e10, t10 - 22, f2[1]);
              return { cmo: f2, ft: h2 };
            }
          },
          94: {},
          95: { f: n$ },
          96: {},
          97: {},
          99: { f: n$ },
          125: { f: sw },
          128: {
            f: function(e10) {
              e10.l += 4;
              var t10 = [e10.read_shift(2), e10.read_shift(2)];
              if (0 !== t10[0] && t10[0]--, 0 !== t10[1] && t10[1]--, t10[0] > 7 || t10[1] > 7)
                throw Error("Bad Gutters: " + t10.join("|"));
              return t10;
            }
          },
          129: {
            f: function(e10, t10, r10) {
              var a10 = r10 && 8 == r10.biff || 2 == t10 ? e10.read_shift(2) : (e10.l += t10, 0);
              return { fDialog: 16 & a10, fBelow: 64 & a10, fRight: 128 & a10 };
            }
          },
          130: { f: nX },
          131: { f: n$ },
          132: { f: n$ },
          133: {
            f: function(e10, t10, r10) {
              var a10 = "";
              if (4 == r10.biff) return 0 === (a10 = nJ(e10, 0, r10)).length && (a10 = "Sheet1"), { name: a10 };
              var n10 = e10.read_shift(4), s10 = 3 & e10.read_shift(1), i10 = e10.read_shift(1);
              switch (i10) {
                case 0:
                  i10 = "Worksheet";
                  break;
                case 1:
                  i10 = "Macrosheet";
                  break;
                case 2:
                  i10 = "Chartsheet";
                  break;
                case 6:
                  i10 = "VBAModule";
              }
              return 0 === (a10 = nJ(e10, 0, r10)).length && (a10 = "Sheet1"), { pos: n10, hs: s10, dt: i10, name: a10 };
            }
          },
          134: {},
          140: {
            f: function(e10) {
              var t10, r10 = [0, 0];
              return t10 = e10.read_shift(2), r10[0] = aZ[t10] || t10, t10 = e10.read_shift(2), r10[1] = aZ[t10] || t10, r10;
            }
          },
          141: { f: nX },
          144: {},
          146: {
            f: function(e10) {
              for (var t10 = e10.read_shift(2), r10 = []; t10-- > 0; ) r10.push(n5(e10, 8));
              return r10;
            }
          },
          151: {},
          152: {},
          153: {},
          154: {},
          155: {},
          156: { f: nX },
          157: {},
          158: {},
          160: { f: nK },
          161: {
            f: function(e10, t10) {
              var r10 = {};
              return t10 < 32 || (e10.l += 16, r10.header = aV(e10, 8), r10.footer = aV(e10, 8), e10.l += 2), r10;
            }
          },
          174: {},
          175: {},
          176: {},
          177: {},
          178: {},
          180: {},
          181: {},
          182: {},
          184: {},
          185: {},
          189: {
            f: function(e10, t10) {
              for (var r10 = e10.l + t10 - 2, a10 = e10.read_shift(2), n10 = e10.read_shift(2), s10 = []; e10.l < r10; ) s10.push(n7(e10));
              if (e10.l !== r10) throw Error("MulRK read error");
              var i10 = e10.read_shift(2);
              if (s10.length != i10 - n10 + 1) throw Error("MulRK length mismatch");
              return { r: a10, c: n10, C: i10, rkrec: s10 };
            }
          },
          190: {
            f: function(e10, t10) {
              for (var r10 = e10.l + t10 - 2, a10 = e10.read_shift(2), n10 = e10.read_shift(2), s10 = []; e10.l < r10; )
                s10.push(e10.read_shift(2));
              if (e10.l !== r10) throw Error("MulBlank read error");
              var i10 = e10.read_shift(2);
              if (s10.length != i10 - n10 + 1) throw Error("MulBlank length mismatch");
              return { r: a10, c: n10, C: i10, ixfe: s10 };
            }
          },
          193: { f: nV },
          197: {},
          198: {},
          199: {},
          200: {},
          201: {},
          202: { f: n$ },
          203: {},
          204: {},
          205: {},
          206: {},
          207: {},
          208: {},
          209: {},
          210: {},
          211: {},
          213: {},
          215: {},
          216: {},
          217: {},
          218: { f: nX },
          220: {},
          221: { f: n$ },
          222: {},
          224: {
            f: function(e10, t10, r10) {
              var a10, n10, s10, i10, o10, c10 = {};
              return c10.ifnt = e10.read_shift(2), c10.numFmtId = e10.read_shift(2), c10.flags = e10.read_shift(2), c10.fStyle = c10.flags >> 2 & 1, t10 -= 6, c10.fStyle, a10 = {}, n10 = e10.read_shift(4), s10 = e10.read_shift(4), i10 = e10.read_shift(4), o10 = e10.read_shift(2), a10.patternType = aJ[i10 >> 26], r10.cellStyles && (a10.alc = 7 & n10, a10.fWrap = n10 >> 3 & 1, a10.alcV = n10 >> 4 & 7, a10.fJustLast = n10 >> 7 & 1, a10.trot = n10 >> 8 & 255, a10.cIndent = n10 >> 16 & 15, a10.fShrinkToFit = n10 >> 20 & 1, a10.iReadOrder = n10 >> 22 & 2, a10.fAtrNum = n10 >> 26 & 1, a10.fAtrFnt = n10 >> 27 & 1, a10.fAtrAlc = n10 >> 28 & 1, a10.fAtrBdr = n10 >> 29 & 1, a10.fAtrPat = n10 >> 30 & 1, a10.fAtrProt = n10 >> 31 & 1, a10.dgLeft = 15 & s10, a10.dgRight = s10 >> 4 & 15, a10.dgTop = s10 >> 8 & 15, a10.dgBottom = s10 >> 12 & 15, a10.icvLeft = s10 >> 16 & 127, a10.icvRight = s10 >> 23 & 127, a10.grbitDiag = s10 >> 30 & 3, a10.icvTop = 127 & i10, a10.icvBottom = i10 >> 7 & 127, a10.icvDiag = i10 >> 14 & 127, a10.dgDiag = i10 >> 21 & 15, a10.icvFore = 127 & o10, a10.icvBack = o10 >> 7 & 127, a10.fsxButton = o10 >> 14 & 1), c10.data = a10, c10;
            }
          },
          225: {
            f: function(e10, t10) {
              return 0 === t10 || e10.read_shift(2), 1200;
            }
          },
          226: { f: nV },
          227: {},
          229: {
            f: function(e10, t10) {
              for (var r10 = [], a10 = e10.read_shift(2); a10--; ) r10.push(n9(e10, t10));
              return r10;
            }
          },
          233: {},
          235: {},
          236: {},
          237: {},
          239: {},
          240: {},
          241: {},
          242: {},
          244: {},
          245: {},
          246: {},
          247: {},
          248: {},
          249: {},
          251: {},
          252: {
            f: function(e10, t10) {
              for (var r10 = e10.l + t10, a10 = e10.read_shift(4), n10 = e10.read_shift(4), s10 = [], i10 = 0; i10 != n10 && e10.l < r10; ++i10)
                s10.push(
                  (function(e11) {
                    var t11 = J;
                    J = 1200;
                    var r11, a11 = e11.read_shift(2), n11 = e11.read_shift(1), s11 = 4 & n11, i11 = 8 & n11, o10 = 0, c10 = {};
                    i11 && (o10 = e11.read_shift(2)), s11 && (r11 = e11.read_shift(4));
                    var l2 = 0 === a11 ? "" : e11.read_shift(a11, 2 == 1 + (1 & n11) ? "dbcs-cont" : "sbcs-cont");
                    return i11 && (e11.l += 4 * o10), s11 && (e11.l += r11), c10.t = l2, i11 || (c10.raw = "<t>" + c10.t + "</t>", c10.r = c10.t), J = t11, c10;
                  })(e10)
                );
              return s10.Count = a10, s10.Unique = n10, s10;
            }
          },
          253: {
            f: function(e10, t10, r10) {
              var a10 = n6(e10, t10, r10);
              return a10.isst = e10.read_shift(4), a10;
            }
          },
          255: {
            f: function(e10, t10) {
              var r10 = {};
              return r10.dsst = e10.read_shift(2), e10.l += t10 - 2, r10;
            }
          },
          256: {},
          259: {},
          290: {},
          311: {},
          312: {},
          315: {},
          317: { f: nK },
          318: {},
          319: {},
          320: {},
          330: {},
          331: {},
          333: {},
          334: {},
          335: {},
          336: {},
          337: {},
          338: {},
          339: {},
          340: {},
          351: {},
          352: { f: n$ },
          353: { f: nV },
          401: {},
          402: {},
          403: {},
          404: {},
          405: {},
          406: {},
          407: {},
          408: {},
          425: {},
          426: {},
          427: {},
          428: {},
          429: {},
          430: {
            f: function(e10, t10, r10) {
              var a10 = e10.l + t10, n10 = e10.read_shift(2), s10 = e10.read_shift(2);
              if (r10.sbcch = s10, 1025 == s10 || 14849 == s10) return [s10, n10];
              if (s10 < 1 || s10 > 255) throw Error("Unexpected SupBook type: " + s10);
              for (var i10 = nq(e10, s10), o10 = []; a10 > e10.l; ) o10.push(nQ(e10));
              return [s10, n10, i10, o10];
            }
          },
          431: { f: n$ },
          432: {},
          433: {},
          434: {},
          437: {},
          438: {
            f: function(e10, t10, r10) {
              var a10 = e10.l, n10 = "";
              try {
                e10.l += 4;
                var s10 = (r10.lastobj || { cmo: [0, 0] }).cmo[1];
                -1 == [0, 5, 7, 11, 12, 14].indexOf(s10) ? e10.l += 6 : (e10.read_shift(1), e10.l++, e10.read_shift(2), e10.l += 2);
                var i10 = e10.read_shift(2);
                e10.read_shift(2), nX(e10, 2);
                var o10 = e10.read_shift(2);
                e10.l += o10;
                for (var c10 = 1; c10 < e10.lens.length - 1; ++c10) {
                  if (e10.l - a10 != e10.lens[c10]) throw Error("TxO: bad continue record");
                  var l2 = e10[e10.l], f2 = nq(e10, e10.lens[c10 + 1] - e10.lens[c10] - 1);
                  if ((n10 += f2).length >= (l2 ? i10 : 2 * i10)) break;
                }
                if (n10.length !== i10 && n10.length !== 2 * i10) throw Error("cchText: " + i10 + " != " + n10.length);
                return e10.l = a10 + t10, { t: n10 };
              } catch (r11) {
                return e10.l = a10 + t10, { t: n10 };
              }
            }
          },
          439: { f: n$ },
          440: {
            f: function(e10, t10) {
              var r10 = n9(e10, 8);
              return e10.l += 16, [
                r10,
                (function(e11, t11) {
                  var r11 = e11.l + t11, a10 = e11.read_shift(4);
                  if (2 !== a10) throw Error("Unrecognized streamVersion: " + a10);
                  var n10 = e11.read_shift(2);
                  e11.l += 2;
                  var s10, i10, o10, c10, l2, f2, h2 = "";
                  16 & n10 && (s10 = n2(e11, r11 - e11.l)), 128 & n10 && (i10 = n2(e11, r11 - e11.l)), (257 & n10) == 257 && (o10 = n2(e11, r11 - e11.l)), (257 & n10) == 1 && (c10 = (function(e12, t12) {
                    var r12, a11, n11, s11, i11 = e12.read_shift(16);
                    switch (t12 -= 16, i11) {
                      case "e0c9ea79f9bace118c8200aa004ba90b":
                        return r12 = e12.read_shift(4), a11 = e12.l, n11 = false, r12 > 24 && (e12.l += r12 - 24, "795881f43b1d7f48af2c825dc4852763" === e12.read_shift(16) && (n11 = true), e12.l = a11), s11 = e12.read_shift((n11 ? r12 - 24 : r12) >> 1, "utf16le").replace(ex, ""), n11 && (e12.l += 24), s11;
                      case "0303000000000000c000000000000046":
                        for (var o11 = e12.read_shift(2), c11 = ""; o11-- > 0; ) c11 += "../";
                        var l3 = e12.read_shift(0, "lpstr-ansi");
                        if (e12.l += 2, 57005 != e12.read_shift(2)) throw Error("Bad FileMoniker");
                        if (0 === e12.read_shift(4)) return c11 + l3.replace(/\\/g, "/");
                        var f3 = e12.read_shift(4);
                        if (3 != e12.read_shift(2)) throw Error("Bad FileMoniker");
                        return c11 + e12.read_shift(f3 >> 1, "utf16le").replace(ex, "");
                      default:
                        throw Error("Unsupported Moniker " + i11);
                    }
                  })(e11, r11 - e11.l)), 8 & n10 && (h2 = n2(e11, r11 - e11.l)), 32 & n10 && (l2 = e11.read_shift(16)), 64 & n10 && (f2 = nR(e11)), e11.l = r11;
                  var u2 = i10 || o10 || c10 || "";
                  u2 && h2 && (u2 += "#" + h2), u2 || (u2 = "#" + h2), 2 & n10 && "/" == u2.charAt(0) && "/" != u2.charAt(1) && (u2 = "file://" + u2);
                  var d2 = { Target: u2 };
                  return l2 && (d2.guid = l2), f2 && (d2.time = f2), s10 && (d2.Tooltip = s10), d2;
                })(e10, t10 - 24)
              ];
            }
          },
          441: {},
          442: { f: nQ },
          443: {},
          444: { f: nX },
          445: {},
          446: {},
          448: { f: nV },
          449: {
            f: function(e10) {
              return e10.read_shift(2), e10.read_shift(4);
            },
            r: 2
          },
          450: { f: nV },
          512: { f: sc },
          513: { f: n6 },
          515: {
            f: function(e10, t10, r10) {
              r10.biffguess && 2 == r10.biff && (r10.biff = 5);
              var a10 = n6(e10, 6, r10);
              return a10.val = aV(e10, 8), a10;
            }
          },
          516: {
            f: function(e10, t10, r10) {
              r10.biffguess && 2 == r10.biff && (r10.biff = 5);
              var a10 = e10.l + t10, n10 = n6(e10, t10, r10);
              return n10.val = nQ(e10, a10 - e10.l, r10), n10;
            }
          },
          517: {
            f: function(e10, t10, r10) {
              var a10 = n6(e10, 6, r10), n10 = nY(e10, 2);
              return a10.val = n10, a10.t = true === n10 || false === n10 ? "b" : "e", a10;
            }
          },
          519: { f: nQ },
          520: {
            f: function(e10) {
              var t10 = {};
              t10.r = e10.read_shift(2), t10.c = e10.read_shift(2), t10.cnt = e10.read_shift(2) - t10.c;
              var r10 = e10.read_shift(2);
              e10.l += 4;
              var a10 = e10.read_shift(1);
              return e10.l += 3, 7 & a10 && (t10.level = 7 & a10), 32 & a10 && (t10.hidden = true), 64 & a10 && (t10.hpt = r10 / 20), t10;
            }
          },
          523: {},
          545: { f: sg },
          549: { f: so },
          566: {},
          574: {
            f: function(e10, t10, r10) {
              return r10 && r10.biff >= 2 && r10.biff < 5 ? {} : { RTL: 64 & e10.read_shift(2) };
            }
          },
          638: {
            f: function(e10) {
              var t10 = e10.read_shift(2), r10 = e10.read_shift(2), a10 = n7(e10);
              return { r: t10, c: r10, ixfe: a10[0], rknum: a10[1] };
            }
          },
          659: {},
          1048: {},
          1054: {
            f: function(e10, t10, r10) {
              return [e10.read_shift(2), n0(e10, 0, r10)];
            }
          },
          1084: {},
          1212: {
            f: function(e10, t10, r10) {
              var a10 = st(e10, 6);
              e10.l++;
              var n10 = e10.read_shift(1);
              return [
                (function(e11, t11, r11) {
                  var a11, n11, s10 = e11.l + t11, i10 = e11.read_shift(2), o10 = iD(e11, i10, r11);
                  return 65535 == i10 ? [[], (a11 = t11 - 2, void (e11.l += a11))] : (t11 !== i10 + 2 && (n11 = iF(e11, s10 - i10 - 2, o10, r11)), [o10, n11]);
                })(e10, t10 -= 8, r10),
                n10,
                a10
              ];
            }
          },
          2048: {
            f: function(e10, t10) {
              e10.read_shift(2);
              var r10 = n9(e10, 8), a10 = e10.read_shift((t10 - 10) / 2, "dbcs-cont");
              return [r10, a10 = a10.replace(ex, "")];
            }
          },
          2049: {},
          2050: {},
          2051: {},
          2052: {},
          2053: {},
          2054: {},
          2055: {},
          2056: {},
          2057: { f: ss },
          2058: {},
          2059: {},
          2060: {},
          2061: {},
          2062: {},
          2063: {},
          2064: {},
          2066: {},
          2067: {},
          2128: {},
          2129: {},
          2130: {},
          2131: {},
          2132: {},
          2133: {},
          2134: {},
          2135: {},
          2136: {},
          2137: {},
          2138: {},
          2146: {},
          2147: { r: 12 },
          2148: {},
          2149: {},
          2150: {},
          2151: { f: nV },
          2152: {},
          2154: {},
          2155: {},
          2156: {},
          2161: {},
          2162: {},
          2164: {},
          2165: {},
          2166: {},
          2167: {},
          2168: {},
          2169: {},
          2170: {},
          2171: {},
          2172: {
            f: function(e10) {
              e10.l += 2;
              var t10 = { cxfs: 0, crc: 0 };
              return t10.cxfs = e10.read_shift(2), t10.crc = e10.read_shift(4), t10;
            },
            r: 12
          },
          2173: {
            f: function(e10, t10) {
              var r10 = e10.l + t10;
              e10.l += 2;
              var a10 = e10.read_shift(2);
              e10.l += 2;
              for (var n10 = e10.read_shift(2), s10 = []; n10-- > 0; )
                s10.push(
                  (function(e11) {
                    var t11 = e11.read_shift(2), r11 = e11.read_shift(2) - 4, a11 = [t11];
                    switch (t11) {
                      case 4:
                      case 5:
                      case 7:
                      case 8:
                      case 9:
                      case 10:
                      case 11:
                      case 13:
                        a11[1] = (function(e12) {
                          var t12 = {};
                          switch (t12.xclrType = e12.read_shift(2), t12.nTintShade = e12.read_shift(2), t12.xclrType) {
                            case 0:
                            case 4:
                              e12.l += 4;
                              break;
                            case 1:
                              t12.xclrValue = (function(e13, t13) {
                                e13.l += t13;
                              })(e12, 4);
                              break;
                            case 2:
                              t12.xclrValue = n3(e12, 4);
                              break;
                            case 3:
                              t12.xclrValue = e12.read_shift(4);
                          }
                          return e12.l += 8, t12;
                        })(e11, r11);
                        break;
                      case 6:
                        a11[1] = void (e11.l += r11);
                        break;
                      case 14:
                      case 15:
                        a11[1] = e11.read_shift(1 === r11 ? 1 : 2);
                        break;
                      default:
                        throw Error("Unrecognized ExtProp type: " + t11 + " " + r11);
                    }
                    return a11;
                  })(e10, r10 - e10.l)
                );
              return { ixfe: a10, ext: s10 };
            },
            r: 12
          },
          2174: {},
          2175: {},
          2180: {},
          2181: {},
          2182: {},
          2183: {},
          2184: {},
          2185: {},
          2186: {},
          2187: {},
          2188: { f: n$, r: 12 },
          2189: {},
          2190: { r: 12 },
          2191: {},
          2192: {},
          2194: {},
          2195: {},
          2196: {
            f: function(e10, t10, r10) {
              if (r10.biff < 8) {
                e10.l += t10;
                return;
              }
              var a10 = e10.read_shift(2), n10 = e10.read_shift(2);
              return [nq(e10, a10, r10), nq(e10, n10, r10)];
            },
            r: 12
          },
          2197: {},
          2198: {
            f: function(e10, t10, r10) {
              var a10, n10 = e10.l + t10;
              if (124226 !== e10.read_shift(4)) {
                if (!r10.cellStyles) {
                  e10.l = n10;
                  return;
                }
                var s10 = e10.slice(e10.l);
                e10.l = n10;
                try {
                  a10 = tY(s10, { type: "array" });
                } catch (e11) {
                  return;
                }
                var i10 = tG(a10, "theme/theme/theme1.xml", true);
                if (i10) return ir(i10, r10);
              }
            },
            r: 12
          },
          2199: {},
          2200: {},
          2201: {},
          2202: {
            f: function(e10) {
              return [0 !== e10.read_shift(4), 0 !== e10.read_shift(4), e10.read_shift(4)];
            },
            r: 12
          },
          2203: { f: nV },
          2204: {},
          2205: {},
          2206: {},
          2207: {},
          2211: {
            f: function(e10) {
              var t10, r10, a10 = (t10 = e10.read_shift(2), r10 = e10.read_shift(2), e10.l += 8, { type: t10, flags: r10 });
              if (2211 != a10.type) throw Error("Invalid Future Record " + a10.type);
              return 0 !== e10.read_shift(4);
            }
          },
          2212: {},
          2213: {},
          2214: {},
          2215: {},
          4097: {},
          4098: {},
          4099: {},
          4102: {},
          4103: {},
          4105: {},
          4106: {},
          4107: {},
          4108: {},
          4109: {},
          4116: {},
          4117: {},
          4118: {},
          4119: {},
          4120: {},
          4121: {},
          4122: {},
          4123: {},
          4124: {},
          4125: {},
          4126: {},
          4127: {},
          4128: {},
          4129: {},
          4130: {},
          4132: {},
          4133: {},
          4134: { f: nX },
          4135: {},
          4146: {},
          4147: {},
          4148: {},
          4149: {},
          4154: {},
          4156: {},
          4157: {},
          4158: {},
          4159: {},
          4160: {},
          4161: {},
          4163: {},
          4164: {
            f: function(e10, t10, r10) {
              var a10 = { area: false };
              if (5 != r10.biff) return e10.l += t10, a10;
              var n10 = e10.read_shift(1);
              return e10.l += 3, 16 & n10 && (a10.area = true), a10;
            }
          },
          4165: {},
          4166: {},
          4168: {},
          4170: {},
          4171: {},
          4174: {},
          4175: {},
          4176: {},
          4177: {},
          4187: {},
          4188: {
            f: function(e10) {
              for (var t10 = e10.read_shift(2), r10 = []; t10-- > 0; ) r10.push(n5(e10, 8));
              return r10;
            }
          },
          4189: {},
          4191: {},
          4192: {},
          4193: {},
          4194: {},
          4195: {},
          4196: {},
          4197: {},
          4198: {},
          4199: {},
          4200: {},
          0: { f: sc },
          1: {},
          2: {
            f: function(e10, t10, r10) {
              var a10 = n6(e10, 7, r10), n10 = e10.read_shift(2);
              return a10.t = "n", a10.val = n10, a10;
            }
          },
          3: {
            f: function(e10, t10, r10) {
              var a10 = n6(e10, 7, r10), n10 = aV(e10, 8);
              return a10.t = "n", a10.val = n10, a10;
            }
          },
          4: {
            f: function(e10, t10, r10) {
              r10.biffguess && 5 == r10.biff && (r10.biff = 2);
              var a10 = n6(e10, 7, r10), n10 = n0(e10, t10 - 7, r10);
              return a10.t = "str", a10.val = n10, a10;
            }
          },
          5: {
            f: function(e10, t10, r10) {
              var a10 = e10.l + 7, n10 = n6(e10, 6, r10);
              e10.l = a10;
              var s10 = nY(e10, 2);
              return n10.val = s10, n10.t = true === s10 || false === s10 ? "b" : "e", n10;
            }
          },
          7: {
            f: function(e10) {
              var t10 = e10.read_shift(1);
              return 0 === t10 ? (e10.l++, "") : e10.read_shift(t10, "sbcs-cont");
            }
          },
          8: {},
          9: { f: ss },
          11: {},
          22: { f: nX },
          30: { f: n0 },
          31: {},
          32: {},
          33: { f: sg },
          36: {},
          37: { f: so },
          50: {
            f: function(e10, t10) {
              e10.l += 6, e10.l += 2, e10.l += 1, e10.l += 3, e10.l += 1, e10.l += t10 - 13;
            }
          },
          62: {},
          52: {},
          67: {
            f: function(e10) {
              var t10 = {};
              return t10.ifnt = e10.read_shift(1), e10.l++, t10.flags = e10.read_shift(1), t10.numFmtId = 63 & t10.flags, t10.flags >>= 6, t10.fStyle = 0, t10.data = {}, t10;
            }
          },
          68: { f: nX },
          69: {},
          86: {},
          126: {},
          127: {
            f: function(e10) {
              var t10 = e10.read_shift(2), r10 = e10.read_shift(2), a10 = e10.read_shift(4), n10 = { fmt: t10, env: r10, len: a10, data: e10.slice(e10.l, e10.l + a10) };
              return e10.l += a10, n10;
            }
          },
          135: {},
          136: {},
          137: {},
          143: {
            f: function(e10) {
              var t10 = e10.read_shift(4), r10 = e10.read_shift(1), a10 = e10.read_shift(r10, "sbcs");
              return 0 === a10.length && (a10 = "Sheet1"), { flags: t10, name: a10 };
            }
          },
          145: {},
          148: {},
          149: {},
          150: {},
          169: {},
          171: {},
          188: {},
          191: {},
          192: {},
          194: {},
          195: {},
          214: {
            f: function(e10, t10, r10) {
              var a10 = e10.l + t10, n10 = n6(e10, 6, r10), s10 = e10.read_shift(2), i10 = nq(e10, s10, r10);
              return e10.l = a10, n10.t = "str", n10.val = i10, n10;
            }
          },
          223: {},
          234: {},
          354: {},
          421: {},
          518: { f: iB },
          521: { f: ss },
          536: { f: sp },
          547: { f: sd },
          561: {},
          579: {
            f: function(e10) {
              var t10 = {};
              return t10.ifnt = e10.read_shift(1), t10.numFmtId = e10.read_shift(1), t10.flags = e10.read_shift(2), t10.fStyle = t10.flags >> 2 & 1, t10.data = {}, t10;
            }
          },
          1030: { f: iB },
          1033: { f: ss },
          1091: {
            f: function(e10) {
              var t10 = {};
              return t10.ifnt = e10.read_shift(1), t10.numFmtId = e10.read_shift(1), t10.flags = e10.read_shift(2), t10.fStyle = t10.flags >> 2 & 1, t10.data = {}, t10;
            }
          },
          2157: {},
          2163: {},
          2177: {},
          2240: {},
          2241: {},
          2242: {},
          2243: {},
          2244: {},
          2245: {},
          2246: {},
          2247: {},
          2248: {},
          2249: {},
          2250: {},
          2251: {},
          2262: { r: 12 },
          101: {},
          102: {},
          105: {},
          106: {},
          107: {},
          109: {},
          112: {},
          114: {},
          29282: {}
        };
        function oV(e10, t10, r10, a10) {
          if (!isNaN(t10)) {
            var n10 = a10 || (r10 || []).length || 0, s10 = e10.next(4);
            s10.write_shift(2, t10), s10.write_shift(2, n10), n10 > 0 && r0(r10) && e10.push(r10);
          }
        }
        function o$(e10, t10, r10, a10) {
          var n10 = as(9);
          return sT(n10, e10, t10), nZ(r10, a10 || "b", n10), n10;
        }
        function oG(e10, t10) {
          t10.forEach(function(t11) {
            var r10 = t11[0].map(function(e11) {
              return e11.t;
            }).join("");
            if (r10.length <= 2048) return oV(e10, 28, sv(r10, t11[1], t11[2]));
            oV(e10, 28, sv(r10.slice(0, 2048), t11[1], t11[2], r10.length));
            for (var a10 = 2048; a10 < r10.length; a10 += 2048)
              oV(e10, 28, sv(r10.slice(a10, Math.min(a10 + 2048, r10.length)), -1, -1, Math.min(2048, r10.length - a10)));
          });
        }
        var oX = 1, oj = [];
        function oK(e10, t10) {
          for (var r10 = 0; r10 <= e10.SheetNames.length; ++r10) {
            var a10 = e10.Sheets[e10.SheetNames[r10]];
            if (a10 && a10["!ref"]) {
              var n10 = aw(a10["!ref"]);
              n10.e.c > 255 && "undefined" != typeof console && console.error && console.error(
                "Worksheet '" + e10.SheetNames[r10] + "' extends beyond column IV (255).  Data may be lost."
              ), n10.e.r > 65535 && "undefined" != typeof console && console.error && console.error("Worksheet '" + e10.SheetNames[r10] + "' extends beyond row 65536.  Data may be lost.");
            }
          }
          var s10 = t10 || {};
          switch (s10.biff || 2) {
            case 8:
            case 5:
              var i10 = t10 || {}, o10 = [];
              e10 && !e10.SSF && (e10.SSF = tw(eD)), e10 && e10.SSF && (e5(), e3(e10.SSF), i10.revssf = tc(e10.SSF), i10.revssf[e10.SSF[65535]] = 0, i10.ssf = e10.SSF), oX = 1, oj = [], i10.Strings = [], i10.Strings.Count = 0, i10.Strings.Unique = 0, cU(i10), i10.cellXfs = [], i1(i10.cellXfs, {}, { revssf: { General: 0 } }), e10.Props || (e10.Props = {});
              for (var c10 = 0; c10 < e10.SheetNames.length; ++c10)
                o10[o10.length] = (function(e11, t11, r11) {
                  var a11, n11, s11, i11, o11, c11, l2, f2, h2, u2, d2, p2, m2, g2, v2 = ao(), b2 = r11.SheetNames[e11], w2 = r11.Sheets[b2] || {}, T2 = (r11 || {}).Workbook || {}, y2 = (T2.Sheets || [])[e11] || {}, E2 = null != w2["!data"], k2 = 8 == t11.biff, x2 = "", _2 = [], S2 = ak(w2["!ref"] || "A1"), A2 = k2 ? 65536 : 16384;
                  if (S2.e.c > 255 || S2.e.r >= A2) {
                    if (t11.WTF) throw Error("Range " + (w2["!ref"] || "A1") + " exceeds format limit A1:IV" + A2);
                    S2.e.c = Math.min(S2.e.c, 255), S2.e.r = Math.min(S2.e.r, A2 - 1);
                  }
                  oV(v2, 2057, si(r11, 16, t11)), oV(v2, 13, nj(1)), oV(v2, 12, nj(100)), oV(v2, 15, nG(true)), oV(v2, 17, nG(false)), oV(v2, 16, a$(1e-3)), oV(v2, 95, nG(true)), oV(v2, 42, nG(false)), oV(v2, 43, nG(false)), oV(v2, 130, nj(1)), oV(
                    v2,
                    128,
                    (a11 = [0, 0], (n11 = as(8)).write_shift(4, 0), n11.write_shift(2, a11[0] ? a11[0] + 1 : 0), n11.write_shift(2, a11[1] ? a11[1] + 1 : 0), n11)
                  ), oV(v2, 131, nG(false)), oV(v2, 132, nG(false)), k2 && (function(e12, t12) {
                    if (t12) {
                      var r12 = 0;
                      t12.forEach(function(t13, a12) {
                        var n12, s12, i12;
                        ++r12 <= 256 && t13 && oV(
                          e12,
                          125,
                          (n12 = iQ(a12, t13), (s12 = as(12)).write_shift(2, a12), s12.write_shift(2, a12), s12.write_shift(2, 256 * n12.width), s12.write_shift(2, 0), i12 = 0, n12.hidden && (i12 |= 1), s12.write_shift(1, i12), i12 = n12.level || 0, s12.write_shift(1, i12), s12.write_shift(2, 0), s12)
                        );
                      });
                    }
                  })(v2, w2["!cols"]), oV(
                    v2,
                    512,
                    ((i11 = as(2 * (s11 = 8 != t11.biff && t11.biff ? 2 : 4) + 6)).write_shift(s11, S2.s.r), i11.write_shift(s11, S2.e.r + 1), i11.write_shift(2, S2.s.c), i11.write_shift(2, S2.e.c + 1), i11.write_shift(2, 0), i11)
                  );
                  var C2 = (((r11 || {}).Workbook || {}).WBProps || {}).date1904;
                  k2 && (w2["!links"] = []);
                  for (var I2 = S2.s.c; I2 <= S2.e.c; ++I2) _2[I2] = ag(I2);
                  for (var O2 = [], R2 = [], N2 = S2.s.r; N2 <= S2.e.r; ++N2)
                    for (E2 && (R2 = w2["!data"][N2] || []), x2 = ap(N2), I2 = S2.s.c; I2 <= S2.e.c; ++I2) {
                      var F2 = E2 ? R2[I2] : w2[_2[I2] + x2];
                      F2 && (!(function(e12, t12, r12, a12, n12, s12) {
                        var i12 = 16 + i1(n12.cellXfs, t12, n12);
                        if (null == t12.v && !t12.bf) return oV(e12, 513, n8(r12, a12, i12));
                        if (t12.bf)
                          oV(
                            e12,
                            6,
                            (function(e13, t13, r13, a13, n13) {
                              var s13 = n8(t13, r13, n13), i13 = (function(e14) {
                                if (null == e14) {
                                  var t14 = as(8);
                                  return t14.write_shift(1, 3), t14.write_shift(1, 0), t14.write_shift(2, 0), t14.write_shift(2, 0), t14.write_shift(2, 65535), t14;
                                }
                                return "number" == typeof e14 ? a$(e14) : a$(0);
                              })(e13.v), o13 = as(6);
                              o13.write_shift(2, 33), o13.write_shift(4, 0);
                              for (var c13 = as(e13.bf.length), l4 = 0; l4 < e13.bf.length; ++l4) c13[l4] = e13.bf[l4];
                              return ek([s13, i13, o13, c13]);
                            })(t12, r12, a12, 0, i12)
                          );
                        else
                          switch (t12.t) {
                            case "d":
                            case "n":
                              var o12, c12 = "d" == t12.t ? tu(tv(t12.v, s12), s12) : t12.v;
                              isNaN(c12) ? oV(e12, 517, sh(r12, a12, 36, i12, n12, "e")) : isFinite(c12) ? oV(e12, 515, (n8(r12, a12, i12, o12 = as(14)), a$(c12, o12), o12)) : oV(e12, 517, sh(r12, a12, 7, i12, n12, "e"));
                              break;
                            case "b":
                            case "e":
                              oV(e12, 517, sh(r12, a12, t12.v, i12, n12, t12.t));
                              break;
                            case "s":
                            case "str":
                              if (n12.bookSST) {
                                var l3, f3, h3, u3, d3 = iq(n12.Strings, null == t12.v ? "" : String(t12.v), n12.revStrings);
                                oV(e12, 253, (n8(r12, a12, i12, u3 = as(10)), u3.write_shift(4, d3), u3));
                              } else
                                oV(
                                  e12,
                                  516,
                                  (l3 = (null == t12.v ? "" : String(t12.v)).slice(0, 255), n8(r12, a12, i12, h3 = as(8 + +(f3 = !n12 || 8 == n12.biff) + (1 + f3) * l3.length)), h3.write_shift(2, l3.length), f3 && h3.write_shift(1, 1), h3.write_shift((1 + f3) * l3.length, l3, f3 ? "utf16le" : "sbcs"), h3)
                                );
                              break;
                            default:
                              oV(e12, 513, n8(r12, a12, i12));
                          }
                      })(v2, F2, N2, I2, t11, C2), k2 && F2.l && w2["!links"].push([_2[I2] + x2, F2.l]), F2.c && O2.push([F2.c, N2, I2]));
                    }
                  var D2 = y2.CodeName || y2.name || b2;
                  return k2 ? (c11 = [], l2 = 0, f2 = ao(), h2 = oX, O2.forEach(function(e12, t12) {
                    var r12 = "", a12 = e12[0].map(function(e13) {
                      return e13.a && !r12 && (r12 = e13.a), e13.t;
                    }).join("");
                    ++oX;
                    var n12 = as(150);
                    n12.write_shift(2, 15), n12.write_shift(2, 61444), n12.write_shift(4, 150), n12.write_shift(2, 3234), n12.write_shift(2, 61450), n12.write_shift(4, 8), n12.write_shift(4, oX), n12.write_shift(4, 2560), n12.write_shift(2, 227), n12.write_shift(2, 61451), n12.write_shift(4, 84), n12.write_shift(2, 128), n12.write_shift(4, 0), n12.write_shift(2, 139), n12.write_shift(4, 2), n12.write_shift(2, 191), n12.write_shift(4, 524296), n12.write_shift(2, 344), n12.l += 4, n12.write_shift(2, 385), n12.write_shift(4, 134217808), n12.write_shift(2, 387), n12.write_shift(4, 134217808), n12.write_shift(2, 389), n12.write_shift(4, 268435700), n12.write_shift(2, 447), n12.write_shift(4, 1048592), n12.write_shift(2, 448), n12.write_shift(4, 134217809), n12.write_shift(2, 451), n12.write_shift(4, 268435700), n12.write_shift(2, 513), n12.write_shift(4, 134217809), n12.write_shift(2, 515), n12.write_shift(4, 268435700), n12.write_shift(2, 575), n12.write_shift(4, 196609), n12.write_shift(2, 959), n12.write_shift(4, 131072 | 2 * !!e12[0].hidden), n12.l += 2, n12.write_shift(2, 61456), n12.write_shift(4, 18), n12.write_shift(2, 3), n12.write_shift(2, e12[2] + 2), n12.l += 2, n12.write_shift(2, e12[1] + 1), n12.l += 2, n12.write_shift(2, e12[2] + 4), n12.l += 2, n12.write_shift(2, e12[1] + 5), n12.l += 2, n12.l += 2, n12.write_shift(2, 61457), n12.l += 4, n12.l = 150, 0 == t12 ? o11 = n12 : oV(f2, 236, n12), l2 += 150;
                    var s12 = as(52);
                    s12.write_shift(2, 21), s12.write_shift(2, 18), s12.write_shift(2, 25), s12.write_shift(2, oX), s12.write_shift(2, 0), s12.l = 22, s12.write_shift(2, 13), s12.write_shift(2, 22), s12.write_shift(4, 1651663474), s12.write_shift(4, 2503426821), s12.write_shift(4, 2150634280), s12.write_shift(4, 1768515844 + 256 * oX), s12.write_shift(2, 0), s12.write_shift(4, 0), s12.l += 4, oV(f2, 93, s12);
                    var i12 = as(8);
                    i12.l += 2, i12.write_shift(2, 61453), i12.l += 4, oV(f2, 236, i12), l2 += 8;
                    var h3 = as(18);
                    h3.write_shift(2, 18), h3.l += 8, h3.write_shift(2, a12.length), h3.write_shift(2, 16), h3.l += 4, oV(f2, 438, h3);
                    var u3 = as(1 + a12.length);
                    u3.write_shift(1, 0), u3.write_shift(a12.length, a12, "sbcs"), oV(f2, 60, u3);
                    var d3 = as(16);
                    d3.l += 8, d3.write_shift(2, a12.length), d3.l += 6, oV(f2, 60, d3);
                    var p3 = as(12 + r12.length);
                    p3.write_shift(2, e12[1]), p3.write_shift(2, e12[2]), p3.write_shift(2, 0 | 2 * !e12[0].hidden), p3.write_shift(2, oX), p3.write_shift(2, r12.length), p3.write_shift(1, 0), p3.write_shift(r12.length, r12, "sbcs"), p3.l++, c11.push(p3);
                  }), (u2 = as(80)).write_shift(2, 15), u2.write_shift(2, 61442), u2.write_shift(4, l2 + u2.length - 8), u2.write_shift(2, 16), u2.write_shift(2, 61448), u2.write_shift(4, 8), u2.write_shift(4, O2.length + 1), u2.write_shift(4, oX), u2.write_shift(2, 15), u2.write_shift(2, 61443), u2.write_shift(4, l2 + 48), u2.write_shift(2, 15), u2.write_shift(2, 61444), u2.write_shift(4, 40), u2.write_shift(2, 1), u2.write_shift(2, 61449), u2.write_shift(4, 16), u2.l += 16, u2.write_shift(2, 2), u2.write_shift(2, 61450), u2.write_shift(4, 8), u2.write_shift(4, h2), u2.write_shift(4, 5), oV(v2, 236, o11 ? ek([u2, o11]) : u2), v2.push(f2.end()), c11.forEach(function(e12) {
                    oV(v2, 28, e12);
                  }), oj.push([h2, O2.length + 1, oX]), ++oX) : oG(v2, O2), k2 && oV(
                    v2,
                    574,
                    (d2 = (T2.Views || [])[0], p2 = as(18), m2 = 1718, d2 && d2.RTL && (m2 |= 64), p2.write_shift(2, m2), p2.write_shift(4, 0), p2.write_shift(4, 64), p2.write_shift(4, 0), p2.write_shift(4, 0), p2)
                  ), k2 && (w2["!merges"] || []).length && oV(
                    v2,
                    229,
                    (function(e12) {
                      var t12 = as(2 + 8 * e12.length);
                      t12.write_shift(2, e12.length);
                      for (var r12 = 0; r12 < e12.length; ++r12) se(e12[r12], t12);
                      return t12;
                    })(w2["!merges"])
                  ), k2 && (function(e12, t12) {
                    for (var r12 = 0; r12 < t12["!links"].length; ++r12) {
                      var a12 = t12["!links"][r12];
                      oV(
                        e12,
                        440,
                        (function(e13) {
                          var t13 = as(24), r13 = av(e13[0]);
                          t13.write_shift(2, r13.r), t13.write_shift(2, r13.r), t13.write_shift(2, r13.c), t13.write_shift(2, r13.c);
                          for (var a13 = "d0 c9 ea 79 f9 ba ce 11 8c 82 00 aa 00 4b a9 0b".split(" "), n12 = 0; n12 < 16; ++n12)
                            t13.write_shift(1, parseInt(a13[n12], 16));
                          return ek([
                            t13,
                            (function(e14) {
                              var t14 = as(512), r14 = 0, a14 = e14.Target;
                              "file://" == a14.slice(0, 7) && (a14 = a14.slice(7));
                              var n13 = a14.indexOf("#"), s12 = n13 > -1 ? 31 : 23;
                              switch (a14.charAt(0)) {
                                case "#":
                                  s12 = 28;
                                  break;
                                case ".":
                                  s12 &= -3;
                              }
                              t14.write_shift(4, 2), t14.write_shift(4, s12);
                              var i12 = [8, 6815827, 6619237, 4849780, 83];
                              for (r14 = 0; r14 < i12.length; ++r14) t14.write_shift(4, i12[r14]);
                              if (28 == s12) n4(a14 = a14.slice(1), t14);
                              else if (2 & s12) {
                                for (r14 = 0, i12 = "e0 c9 ea 79 f9 ba ce 11 8c 82 00 aa 00 4b a9 0b".split(" "); r14 < i12.length; ++r14)
                                  t14.write_shift(1, parseInt(i12[r14], 16));
                                var o12 = n13 > -1 ? a14.slice(0, n13) : a14;
                                for (t14.write_shift(4, 2 * (o12.length + 1)), r14 = 0; r14 < o12.length; ++r14)
                                  t14.write_shift(2, o12.charCodeAt(r14));
                                t14.write_shift(2, 0), 8 & s12 && n4(n13 > -1 ? a14.slice(n13 + 1) : "", t14);
                              } else {
                                for (r14 = 0, i12 = "03 03 00 00 00 00 00 00 c0 00 00 00 00 00 00 46".split(" "); r14 < i12.length; ++r14)
                                  t14.write_shift(1, parseInt(i12[r14], 16));
                                for (var c12 = 0; "../" == a14.slice(3 * c12, 3 * c12 + 3) || "..\\" == a14.slice(3 * c12, 3 * c12 + 3); )
                                  ++c12;
                                for (t14.write_shift(2, c12), t14.write_shift(4, a14.length - 3 * c12 + 1), r14 = 0; r14 < a14.length - 3 * c12; ++r14)
                                  t14.write_shift(1, 255 & a14.charCodeAt(r14 + 3 * c12));
                                for (t14.write_shift(1, 0), t14.write_shift(2, 65535), t14.write_shift(2, 57005), r14 = 0; r14 < 6; ++r14)
                                  t14.write_shift(4, 0);
                              }
                              return t14.slice(0, t14.l);
                            })(e13[1])
                          ]);
                        })(a12)
                      ), a12[1].Tooltip && oV(
                        e12,
                        2048,
                        (function(e13) {
                          var t13 = e13[1].Tooltip, r13 = as(10 + 2 * (t13.length + 1));
                          r13.write_shift(2, 2048);
                          var a13 = av(e13[0]);
                          r13.write_shift(2, a13.r), r13.write_shift(2, a13.r), r13.write_shift(2, a13.c), r13.write_shift(2, a13.c);
                          for (var n12 = 0; n12 < t13.length; ++n12) r13.write_shift(2, t13.charCodeAt(n12));
                          return r13.write_shift(2, 0), r13;
                        })(a12)
                      );
                    }
                    delete t12["!links"];
                  })(v2, w2), oV(v2, 442, n1(D2, t11)), k2 && ((g2 = as(19)).write_shift(4, 2151), g2.write_shift(4, 0), g2.write_shift(4, 0), g2.write_shift(2, 3), g2.write_shift(1, 1), g2.write_shift(4, 0), oV(v2, 2151, g2), (g2 = as(39)).write_shift(4, 2152), g2.write_shift(4, 0), g2.write_shift(4, 0), g2.write_shift(2, 3), g2.write_shift(1, 0), g2.write_shift(4, 0), g2.write_shift(2, 1), g2.write_shift(4, 4), g2.write_shift(2, 0), se(ak(w2["!ref"] || "A1"), g2), g2.write_shift(4, 4), oV(v2, 2152, g2)), oV(v2, 10), v2.end();
                })(c10, i10, e10);
              return o10.unshift(
                (function(e11, t11, r11) {
                  var a11, n11, s11, i11, o11, c11, l2, f2 = ao(), h2 = (e11 || {}).Workbook || {}, u2 = h2.Sheets || [], d2 = h2.WBProps || {}, p2 = 8 == r11.biff, m2 = 5 == r11.biff;
                  oV(f2, 2057, si(e11, 5, r11)), "xla" == r11.bookType && oV(f2, 135), oV(f2, 225, p2 ? nj(1200) : null), oV(
                    f2,
                    193,
                    (function(e12, t12) {
                      t12 || (t12 = as(2));
                      for (var r12 = 0; r12 < 2; ++r12) t12.write_shift(1, 0);
                      return t12;
                    })(2)
                  ), m2 && oV(f2, 191), m2 && oV(f2, 192), oV(f2, 226), oV(
                    f2,
                    92,
                    (function(e12, t12) {
                      var r12 = !t12 || 8 == t12.biff, a12 = as(r12 ? 112 : 54);
                      for (a12.write_shift(8 == t12.biff ? 2 : 1, 7), r12 && a12.write_shift(1, 0), a12.write_shift(4, 859007059), a12.write_shift(4, 5458548 | 536870912 * !r12); a12.l < a12.length; )
                        a12.write_shift(1, 32 * !r12);
                      return a12;
                    })(0, r11)
                  ), oV(f2, 66, nj(p2 ? 1200 : 1252)), p2 && oV(f2, 353, nj(0)), p2 && oV(f2, 448), oV(
                    f2,
                    317,
                    (function(e12) {
                      for (var t12 = as(2 * e12), r12 = 0; r12 < e12; ++r12) t12.write_shift(2, r12 + 1);
                      return t12;
                    })(e11.SheetNames.length)
                  ), p2 && e11.vbaraw && oV(f2, 211), p2 && e11.vbaraw && oV(f2, 442, n1(d2.CodeName || "ThisWorkbook", r11)), oV(f2, 156, nj(17)), oV(f2, 25, nG(false)), oV(f2, 18, nG(false)), oV(f2, 19, nj(0)), p2 && oV(f2, 431, nG(false)), p2 && oV(f2, 444, nj(0)), oV(
                    f2,
                    61,
                    ((a11 = as(18)).write_shift(2, 0), a11.write_shift(2, 0), a11.write_shift(2, 29280), a11.write_shift(2, 17600), a11.write_shift(2, 56), a11.write_shift(2, 0), a11.write_shift(2, 0), a11.write_shift(2, 1), a11.write_shift(2, 500), a11)
                  ), oV(f2, 64, nG(false)), oV(f2, 141, nj(0)), oV(
                    f2,
                    34,
                    nG(
                      "true" == (e11.Workbook && e11.Workbook.WBProps && rs(e11.Workbook.WBProps.date1904) ? "true" : "false")
                    )
                  ), oV(f2, 14, nG(true)), p2 && oV(f2, 439, nG(false)), oV(f2, 218, nj(0)), oV(
                    f2,
                    49,
                    (s11 = (n11 = { sz: 12, color: { theme: 1 }, name: "Arial", family: 2, scheme: "minor" }).name || "Arial", (o11 = as((i11 = r11 && 5 == r11.biff) ? 15 + s11.length : 16 + 2 * s11.length)).write_shift(
                      2,
                      20 * (n11.sz || 12)
                    ), o11.write_shift(4, 0), o11.write_shift(2, 400), o11.write_shift(4, 0), o11.write_shift(2, 0), o11.write_shift(1, s11.length), i11 || o11.write_shift(1, 1), o11.write_shift((i11 ? 1 : 2) * s11.length, s11, i11 ? "sbcs" : "utf16le"), o11)
                  ), c11 = e11.SSF, c11 && [
                    [5, 8],
                    [23, 26],
                    [41, 44],
                    [50, 392]
                  ].forEach(function(e12) {
                    for (var t12 = e12[0]; t12 <= e12[1]; ++t12)
                      null != c11[t12] && oV(
                        f2,
                        1054,
                        (function(e13, t13, r12, a12) {
                          var n12 = r12 && 5 == r12.biff;
                          a12 || (a12 = as(n12 ? 3 + t13.length : 5 + 2 * t13.length)), a12.write_shift(2, e13), a12.write_shift(n12 ? 1 : 2, t13.length), n12 || a12.write_shift(1, 1), a12.write_shift((n12 ? 1 : 2) * t13.length, t13, n12 ? "sbcs" : "utf16le");
                          var s12 = a12.length > a12.l ? a12.slice(0, a12.l) : a12;
                          return null == s12.l && (s12.l = s12.length), s12;
                        })(t12, c11[t12], r11)
                      );
                  });
                  for (var g2 = 0; g2 < 16; ++g2) oV(f2, 224, sl({ numFmtId: 0, style: true }, 0, r11));
                  r11.cellXfs.forEach(function(e12) {
                    oV(f2, 224, sl(e12, 0, r11));
                  }), p2 && oV(f2, 352, nG(false));
                  var v2 = f2.end(), b2 = ao();
                  p2 && oV(b2, 140, (l2 || (l2 = as(4)), l2.write_shift(2, 1), l2.write_shift(2, 1), l2)), p2 && oj.length && oV(
                    b2,
                    235,
                    (function() {
                      var e12 = as(82 + 8 * oj.length);
                      e12.write_shift(2, 15), e12.write_shift(2, 61440), e12.write_shift(4, 74 + 8 * oj.length), e12.write_shift(2, 0), e12.write_shift(2, 61446), e12.write_shift(4, 16 + 8 * oj.length), e12.write_shift(4, oX), e12.write_shift(4, oj.length + 1);
                      for (var t12 = 0, r12 = 0; r12 < oj.length; ++r12) t12 += oj[r12] && oj[r12][1] || 0;
                      return e12.write_shift(4, t12), e12.write_shift(4, oj.length), oj.forEach(function(t13) {
                        e12.write_shift(4, t13[0]), e12.write_shift(4, t13[2]);
                      }), e12.write_shift(2, 51), e12.write_shift(2, 61451), e12.write_shift(4, 18), e12.write_shift(2, 191), e12.write_shift(4, 524296), e12.write_shift(2, 385), e12.write_shift(4, 134217793), e12.write_shift(2, 448), e12.write_shift(4, 134217792), e12.write_shift(2, 64), e12.write_shift(2, 61726), e12.write_shift(4, 16), e12.write_shift(4, 134217741), e12.write_shift(4, 134217740), e12.write_shift(4, 134217751), e12.write_shift(4, 268435703), e12;
                    })()
                  ), p2 && r11.Strings && (function(e12, t12, r12, a12) {
                    var n12 = (r12 || []).length || 0;
                    if (n12 <= 8224) return oV(e12, 252, r12, n12);
                    if (!isNaN(252)) {
                      for (var s12 = r12.parts || [], i12 = 0, o12 = 0, c12 = 0; c12 + (s12[i12] || 8224) <= 8224; )
                        c12 += s12[i12] || 8224, i12++;
                      var l3 = e12.next(4);
                      for (l3.write_shift(2, t12), l3.write_shift(2, c12), e12.push(r12.slice(o12, o12 + c12)), o12 += c12; o12 < n12; ) {
                        for ((l3 = e12.next(4)).write_shift(2, 60), c12 = 0; c12 + (s12[i12] || 8224) <= 8224; )
                          c12 += s12[i12] || 8224, i12++;
                        l3.write_shift(2, c12), e12.push(r12.slice(o12, o12 + c12)), o12 += c12;
                      }
                    }
                  })(
                    b2,
                    252,
                    (function(e12, t12) {
                      var r12 = as(8);
                      r12.write_shift(4, e12.Count), r12.write_shift(4, e12.Unique);
                      for (var a12 = [], n12 = 0; n12 < e12.length; ++n12)
                        a12[n12] = (function(e13) {
                          var t13 = e13.t || "", r13 = as(3);
                          r13.write_shift(2, t13.length), r13.write_shift(1, 1);
                          var a13 = as(2 * t13.length);
                          return a13.write_shift(2 * t13.length, t13, "utf16le"), ek([r13, a13]);
                        })(e12[n12], t12);
                      var s12 = ek([r12].concat(a12));
                      return s12.parts = [r12.length].concat(
                        a12.map(function(e13) {
                          return e13.length;
                        })
                      ), s12;
                    })(r11.Strings, r11)
                  ), oV(b2, 10);
                  var w2 = b2.end(), T2 = ao(), y2 = 0, E2 = 0;
                  for (E2 = 0; E2 < e11.SheetNames.length; ++E2)
                    y2 += (p2 ? 12 : 11) + (p2 ? 2 : 1) * e11.SheetNames[E2].length;
                  var k2 = v2.length + y2 + w2.length;
                  for (E2 = 0; E2 < e11.SheetNames.length; ++E2)
                    oV(
                      T2,
                      133,
                      (function(e12, t12) {
                        var r12 = !t12 || t12.biff >= 8 ? 2 : 1, a12 = as(8 + r12 * e12.name.length);
                        a12.write_shift(4, e12.pos), a12.write_shift(1, e12.hs || 0), a12.write_shift(1, e12.dt), a12.write_shift(1, e12.name.length), t12.biff >= 8 && a12.write_shift(1, 1), a12.write_shift(r12 * e12.name.length, e12.name, t12.biff < 8 ? "sbcs" : "utf16le");
                        var n12 = a12.slice(0, a12.l);
                        return n12.l = a12.l, n12;
                      })({ pos: k2, hs: (u2[E2] || {}).Hidden || 0, dt: 0, name: e11.SheetNames[E2] }, r11)
                    ), k2 += t11[E2].length;
                  var x2 = T2.end();
                  if (y2 != x2.length) throw Error("BS8 " + y2 + " != " + x2.length);
                  var _2 = [];
                  return v2.length && _2.push(v2), x2.length && _2.push(x2), w2.length && _2.push(w2), ek(_2);
                })(e10, o10, i10)
              ), ek(o10);
            case 4:
            case 3:
            case 2:
              return (function(e11, t11) {
                for (var r11 = t11 || {}, a11 = ao(), n11 = 0, s11 = 0; s11 < e11.SheetNames.length; ++s11)
                  e11.SheetNames[s11] == r11.sheet && (n11 = s11);
                if (0 == n11 && r11.sheet && e11.SheetNames[0] != r11.sheet) throw Error("Sheet not found: " + r11.sheet);
                oV(a11, 4 == r11.biff ? 1033 : 3 == r11.biff ? 521 : 9, si(e11, 16, r11)), ((e11.Workbook || {}).WBProps || {}).date1904 && oV(a11, 34, nG(true)), r11.cellXfs = [{ numFmtId: 0 }], r11._BIFF2FmtTable = ["General"], r11._Fonts = [];
                var i11 = ao();
                return !(function(e12, t12, r12, a12, n12) {
                  var s12 = null != t12["!data"], i12 = ak(t12["!ref"] || "A1"), o11 = "", c11 = [];
                  if (i12.e.c > 255 || i12.e.r > 16383) {
                    if (a12.WTF) throw Error("Range " + (t12["!ref"] || "A1") + " exceeds format limit A1:IV16384");
                    i12.e.c = Math.min(i12.e.c, 255), i12.e.r = Math.min(i12.e.r, 16383);
                  }
                  for (var l2 = (((n12 || {}).Workbook || {}).WBProps || {}).date1904, f2 = [], h2 = [], u2 = i12.s.c; u2 <= i12.e.c; ++u2)
                    c11[u2] = ag(u2);
                  for (var d2 = i12.s.r; d2 <= i12.e.r; ++d2)
                    for (s12 && (f2 = t12["!data"][d2] || []), o11 = ap(d2), u2 = i12.s.c; u2 <= i12.e.c; ++u2) {
                      var p2 = s12 ? f2[u2] : t12[c11[u2] + o11];
                      p2 && (!(function(e13, t13, r13, a13, n13, s13) {
                        var i13, o12, c12 = 0;
                        null != t13.z && -1 == (c12 = n13._BIFF2FmtTable.indexOf(t13.z)) && (n13._BIFF2FmtTable.push(t13.z), c12 = n13._BIFF2FmtTable.length - 1);
                        var l3 = 0;
                        if (null != t13.z) {
                          for (; l3 < n13.cellXfs.length && n13.cellXfs[l3].numFmtId != c12; ++l3) ;
                          l3 == n13.cellXfs.length && n13.cellXfs.push({ numFmtId: c12 });
                        }
                        if (null != t13.v)
                          switch (t13.t) {
                            case "d":
                            case "n":
                              var f3, h3, u3, d3, p3, m2, g2 = "d" == t13.t ? tu(tv(t13.v, s13), s13) : t13.v;
                              2 == n13.biff && g2 == (0 | g2) && g2 >= 0 && g2 < 65536 ? oV(
                                e13,
                                2,
                                (f3 = l3, h3 = c12, sT(u3 = as(9), r13, a13, f3 || 0, h3 || 0), u3.write_shift(2, g2), u3)
                              ) : isNaN(g2) ? oV(e13, 5, o$(r13, a13, 36, "e")) : isFinite(g2) ? oV(
                                e13,
                                3,
                                (d3 = l3, p3 = c12, sT(m2 = as(15), r13, a13, d3 || 0, p3 || 0), m2.write_shift(8, g2, "f"), m2)
                              ) : oV(e13, 5, o$(r13, a13, 7, "e"));
                              return;
                            case "b":
                            case "e":
                              oV(e13, 5, o$(r13, a13, t13.v, t13.t));
                              return;
                            case "s":
                            case "str":
                              oV(
                                e13,
                                4,
                                (sT(
                                  o12 = as(8 + 2 * (i13 = null == t13.v ? "" : String(t13.v).slice(0, 255)).length),
                                  r13,
                                  a13
                                ), o12.write_shift(1, i13.length), o12.write_shift(i13.length, i13, "sbcs"), o12.l < o12.length ? o12.slice(0, o12.l) : o12)
                              );
                              return;
                          }
                        oV(e13, 1, sT(null, r13, a13));
                      })(e12, p2, d2, u2, a12, l2), p2.c && h2.push([p2.c, d2, u2]));
                    }
                  oG(e12, h2);
                })(i11, e11.Sheets[e11.SheetNames[n11]], 0, r11, e11), r11._BIFF2FmtTable.forEach(function(e12) {
                  var t12, n12;
                  r11.biff <= 3 ? oV(
                    a11,
                    30,
                    ((t12 = as(1 + e12.length)).write_shift(1, e12.length), t12.write_shift(e12.length, e12, "sbcs"), t12)
                  ) : oV(
                    a11,
                    1054,
                    (n12 = as(3 + e12.length), n12.l += 2, n12.write_shift(1, e12.length), n12.write_shift(e12.length, e12, "sbcs"), n12)
                  );
                }), r11.cellXfs.forEach(function(e12) {
                  switch (r11.biff) {
                    case 2:
                      var t12;
                      oV(a11, 67, (t12 = as(4), t12.l += 2, t12.write_shift(1, e12.numFmtId), t12.l++, t12));
                      break;
                    case 3:
                      oV(a11, 579, sf(e12));
                      break;
                    case 4:
                      oV(a11, 1091, sf(e12));
                  }
                }), delete r11._BIFF2FmtTable, delete r11.cellXfs, delete r11._Fonts, a11.push(i11.end()), oV(a11, 10), a11.end();
              })(e10, t10);
          }
          throw Error("invalid type " + s10.bookType + " for BIFF");
        }
        function oY(e10, t10) {
          var r10 = t10 || {}, a10 = null != r10.dense ? r10.dense : null, n10 = {};
          a10 && (n10["!data"] = []);
          var s10 = (e10 = tF(e10, "<!--", "-->")).match(/<table/i);
          if (!s10) throw Error("Invalid HTML: could not find <table>");
          var i10 = e10.match(/<\/table/i), o10 = s10.index, c10 = i10 && i10.index || e10.length, l2 = tC(e10.slice(o10, c10), /(:?<tr[^<>]*>)/i, "<tr>"), f2 = -1, h2 = 0, u2 = 0, d2 = 0, p2 = { s: { r: 1e7, c: 1e7 }, e: { r: 0, c: 0 } }, m2 = [];
          for (o10 = 0; o10 < l2.length; ++o10) {
            var g2 = l2[o10].trim(), v2 = g2.slice(0, 3).toLowerCase();
            if ("<tr" == v2) {
              if (++f2, r10.sheetRows && r10.sheetRows <= f2) {
                --f2;
                break;
              }
              h2 = 0;
              continue;
            }
            if ("<td" == v2 || "<th" == v2) {
              var b2 = g2.split(/<\/t[dh]>/i);
              for (c10 = 0; c10 < b2.length; ++c10) {
                var w2 = b2[c10].trim();
                if (w2.match(/<t[dh]/i)) {
                  for (var T2 = w2, y2 = 0; "<" == T2.charAt(0) && (y2 = T2.indexOf(">")) > -1; ) T2 = T2.slice(y2 + 1);
                  for (var E2 = 0; E2 < m2.length; ++E2) {
                    var k2 = m2[E2];
                    k2.s.c == h2 && k2.s.r < f2 && f2 <= k2.e.r && (h2 = k2.e.c + 1, E2 = -1);
                  }
                  var x2 = t4(w2.slice(0, w2.indexOf(">")));
                  d2 = x2.colspan ? +x2.colspan : 1, ((u2 = +x2.rowspan) > 1 || d2 > 1) && m2.push({ s: { r: f2, c: h2 }, e: { r: f2 + (u2 || 1) - 1, c: h2 + d2 - 1 } });
                  var _2 = x2.t || x2["data-t"] || "";
                  if (!T2.length || (T2 = ru(T2), p2.s.r > f2 && (p2.s.r = f2), p2.e.r < f2 && (p2.e.r = f2), p2.s.c > h2 && (p2.s.c = h2), p2.e.c < h2 && (p2.e.c = h2), !T2.length)) {
                    h2 += d2;
                    continue;
                  }
                  var S2 = { t: "s", v: T2 };
                  r10.raw || !T2.trim().length || "s" == _2 || ("TRUE" === T2 ? S2 = { t: "b", v: true } : "FALSE" === T2 ? S2 = { t: "b", v: false } : isNaN(ty(T2)) ? isNaN(tA(T2).getDate()) ? 35 == T2.charCodeAt(0) && null != a0[T2] && (S2.t = "e", S2.w = T2, S2.v = a0[T2]) : (S2 = { t: "d", v: tv(T2) }, false === r10.UTC && (S2.v = tI(S2.v)), r10.cellDates || (S2 = { t: "n", v: tu(S2.v) }), S2.z = r10.dateNF || eD[14]) : S2 = { t: "n", v: ty(T2) }), false !== S2.cellText && (S2.w = T2), a10 ? (n10["!data"][f2] || (n10["!data"][f2] = []), n10["!data"][f2][h2] = S2) : n10[ab({ r: f2, c: h2 })] = S2, h2 += d2;
                }
              }
            }
          }
          return n10["!ref"] = aT(p2), m2.length && (n10["!merges"] = m2), n10;
        }
        function oZ(e10, t10, r10, a10) {
          for (var n10 = e10["!merges"] || [], s10 = [], i10 = {}, o10 = null != e10["!data"], c10 = t10.s.c; c10 <= t10.e.c; ++c10) {
            for (var l2 = 0, f2 = 0, h2 = 0; h2 < n10.length; ++h2)
              if (!(n10[h2].s.r > r10) && !(n10[h2].s.c > c10) && !(n10[h2].e.r < r10) && !(n10[h2].e.c < c10)) {
                if (n10[h2].s.r < r10 || n10[h2].s.c < c10) {
                  l2 = -1;
                  break;
                }
                l2 = n10[h2].e.r - n10[h2].s.r + 1, f2 = n10[h2].e.c - n10[h2].s.c + 1;
                break;
              }
            if (!(l2 < 0)) {
              var u2 = ag(c10) + ap(r10), d2 = o10 ? (e10["!data"][r10] || [])[c10] : e10[u2];
              d2 && "n" == d2.t && null != d2.v && !isFinite(d2.v) && (d2 = isNaN(d2.v) ? { t: "e", v: 36, w: aQ[36] } : { t: "e", v: 7, w: aQ[7] });
              var p2 = d2 && null != d2.v && (d2.h || ra(d2.w || (a_(d2), d2.w) || "")) || "";
              i10 = {}, l2 > 1 && (i10.rowspan = l2), f2 > 1 && (i10.colspan = f2), a10.editable ? p2 = '<span contenteditable="true">' + p2 + "</span>" : d2 && (i10["data-t"] = d2 && d2.t || "z", null != d2.v && (i10["data-v"] = ra(d2.v instanceof Date ? d2.v.toISOString() : d2.v)), null != d2.z && (i10["data-z"] = d2.z), d2.l && "#" != (d2.l.Target || "#").charAt(0) && (p2 = '<a href="' + ra(d2.l.Target) + '">' + p2 + "</a>")), i10.id = (a10.id || "sjs") + "-" + u2, s10.push(rw("td", p2, i10));
            }
          }
          return "<tr>" + s10.join("") + "</tr>";
        }
        var oJ = '<html><head><meta charset="utf-8"/><title>SheetJS Table Export</title></head><body>', oq = "</body></html>";
        function oQ(e10, t10, r10) {
          return "<table" + (r10 && r10.id ? ' id="' + r10.id + '"' : "") + ">";
        }
        function o0(e10, t10) {
          var r10 = t10 || {}, a10 = null != r10.header ? r10.header : oJ, n10 = null != r10.footer ? r10.footer : oq, s10 = [a10], i10 = aw(e10["!ref"] || "A1");
          if (s10.push(oQ(e10, i10, r10)), e10["!ref"]) for (var o10 = i10.s.r; o10 <= i10.e.r; ++o10) s10.push(oZ(e10, i10, o10, r10));
          return s10.push("</table>" + n10), s10.join("");
        }
        function o1(e10, t10, r10) {
          var a10 = t10.rows;
          if (!a10) throw "Unsupported origin when " + t10.tagName + " is not a TABLE";
          var n10 = r10 || {}, s10 = null != e10["!data"], i10 = 0, o10 = 0;
          if (null != n10.origin)
            if ("number" == typeof n10.origin) i10 = n10.origin;
            else {
              var c10 = "string" == typeof n10.origin ? av(n10.origin) : n10.origin;
              i10 = c10.r, o10 = c10.c;
            }
          var l2 = Math.min(n10.sheetRows || 1e7, a10.length), f2 = { s: { r: 0, c: 0 }, e: { r: i10, c: o10 } };
          if (e10["!ref"]) {
            var h2 = aw(e10["!ref"]);
            f2.s.r = Math.min(f2.s.r, h2.s.r), f2.s.c = Math.min(f2.s.c, h2.s.c), f2.e.r = Math.max(f2.e.r, h2.e.r), f2.e.c = Math.max(f2.e.c, h2.e.c), -1 == i10 && (f2.e.r = i10 = h2.e.r + 1);
          }
          var u2 = [], d2 = 0, p2 = e10["!rows"] || (e10["!rows"] = []), m2 = 0, g2 = 0, v2 = 0, b2 = 0, w2 = 0, T2 = 0;
          for (e10["!cols"] || (e10["!cols"] = []); m2 < a10.length && g2 < l2; ++m2) {
            var y2 = a10[m2];
            if (o4(y2)) {
              if (n10.display) continue;
              p2[g2] = { hidden: true };
            }
            var E2 = y2.cells;
            for (v2 = b2 = 0; v2 < E2.length; ++v2) {
              var k2 = E2[v2];
              if (!(n10.display && o4(k2))) {
                var x2 = k2.hasAttribute("data-v") ? k2.getAttribute("data-v") : k2.hasAttribute("v") ? k2.getAttribute("v") : ru(k2.innerHTML), _2 = k2.getAttribute("data-z") || k2.getAttribute("z");
                for (d2 = 0; d2 < u2.length; ++d2) {
                  var S2 = u2[d2];
                  S2.s.c == b2 + o10 && S2.s.r < g2 + i10 && g2 + i10 <= S2.e.r && (b2 = S2.e.c + 1 - o10, d2 = -1);
                }
                T2 = +k2.getAttribute("colspan") || 1, ((w2 = +k2.getAttribute("rowspan") || 1) > 1 || T2 > 1) && u2.push({ s: { r: g2 + i10, c: b2 + o10 }, e: { r: g2 + i10 + (w2 || 1) - 1, c: b2 + o10 + (T2 || 1) - 1 } });
                var A2 = { t: "s", v: x2 }, C2 = k2.getAttribute("data-t") || k2.getAttribute("t") || "";
                null != x2 && (0 == x2.length ? A2.t = C2 || "z" : n10.raw || 0 == x2.trim().length || "s" == C2 || ("e" == C2 && aQ[+x2] ? A2 = { t: "e", v: +x2, w: aQ[+x2] } : "TRUE" === x2 ? A2 = { t: "b", v: true } : "FALSE" === x2 ? A2 = { t: "b", v: false } : isNaN(ty(x2)) ? isNaN(tA(x2).getDate()) ? 35 == x2.charCodeAt(0) && null != a0[x2] && (A2 = { t: "e", v: a0[x2], w: x2 }) : (A2 = { t: "d", v: tv(x2) }, n10.UTC && (A2.v = tO(A2.v)), n10.cellDates || (A2 = { t: "n", v: tu(A2.v) }), A2.z = n10.dateNF || eD[14]) : A2 = { t: "n", v: ty(x2) })), void 0 === A2.z && null != _2 && (A2.z = _2);
                var I2 = "", O2 = k2.getElementsByTagName("A");
                if (O2 && O2.length)
                  for (var R2 = 0; R2 < O2.length && (!O2[R2].hasAttribute("href") || "#" == (I2 = O2[R2].getAttribute("href")).charAt(0)); ++R2) ;
                I2 && "#" != I2.charAt(0) && "javascript:" != I2.slice(0, 11).toLowerCase() && (A2.l = { Target: I2 }), s10 ? (e10["!data"][g2 + i10] || (e10["!data"][g2 + i10] = []), e10["!data"][g2 + i10][b2 + o10] = A2) : e10[ab({ c: b2 + o10, r: g2 + i10 })] = A2, f2.e.c < b2 + o10 && (f2.e.c = b2 + o10), b2 += T2;
              }
            }
            ++g2;
          }
          return u2.length && (e10["!merges"] = (e10["!merges"] || []).concat(u2)), f2.e.r = Math.max(f2.e.r, g2 - 1 + i10), e10["!ref"] = aT(f2), g2 >= l2 && (e10["!fullref"] = aT((f2.e.r = a10.length - m2 + g2 - 1 + i10, f2))), e10;
        }
        function o2(e10, t10) {
          var r10 = {};
          return (t10 || {}).dense && (r10["!data"] = []), o1(r10, e10, t10);
        }
        function o4(e10) {
          var t10, r10 = "", a10 = (t10 = e10).ownerDocument.defaultView && "function" == typeof t10.ownerDocument.defaultView.getComputedStyle ? t10.ownerDocument.defaultView.getComputedStyle : "function" == typeof getComputedStyle ? getComputedStyle : null;
          return a10 && (r10 = a10(e10).getPropertyValue("display")), r10 || (r10 = e10.style && e10.style.display), "none" === r10;
        }
        function o3(e10, t10, r10) {
          var a10 = r10 || {}, n10 = ry(e10);
          rE.lastIndex = 0, n10 = tR(tF(n10, "<!--", "-->"));
          for (var s10, i10, o10, c10 = "", l2 = "", f2 = 0, h2 = -1, u2 = ""; s10 = rE.exec(n10); )
            switch (s10[3] = s10[3].replace(/_[\s\S]*$/, "")) {
              case "number-style":
              case "currency-style":
              case "percentage-style":
              case "date-style":
              case "time-style":
              case "text-style":
                "/" === s10[1] ? ("false" == i10["truncate-on-overflow"] && (c10.match(/h/) ? c10 = c10.replace(/h+/, "[$&]") : c10.match(/m/) ? c10 = c10.replace(/m+/, "[$&]") : c10.match(/s/) && (c10 = c10.replace(/s+/, "[$&]"))), a10[i10.name] = c10, c10 = "") : "/" !== s10[0].charAt(s10[0].length - 2) && (c10 = "", i10 = t4(s10[0], false));
                break;
              case "boolean-style":
                "/" === s10[1] ? (a10[i10.name] = "General", c10 = "") : "/" !== s10[0].charAt(s10[0].length - 2) && (c10 = "", i10 = t4(s10[0], false));
                break;
              case "boolean":
                c10 += "General";
                break;
              case "text":
                "/" === s10[1] ? "%" == (u2 = n10.slice(h2, rE.lastIndex - s10[0].length)) && "<number:percentage-style" == i10[0] ? c10 += "%" : c10 += '"' + u2.replace(/"/g, '""') + '"' : "/" !== s10[0].charAt(s10[0].length - 2) && (h2 = rE.lastIndex);
                break;
              case "day":
                "short" === (o10 = t4(s10[0], false)).style ? c10 += "d" : c10 += "dd";
                break;
              case "day-of-week":
                switch ((o10 = t4(s10[0], false)).style) {
                  case "short":
                  default:
                    c10 += "ddd";
                    break;
                  case "long":
                    c10 += "dddd";
                }
                break;
              case "era":
                "short" === (o10 = t4(s10[0], false)).style ? c10 += "ee" : c10 += "eeee";
                break;
              case "hours":
                "short" === (o10 = t4(s10[0], false)).style ? c10 += "h" : c10 += "hh";
                break;
              case "minutes":
                "short" === (o10 = t4(s10[0], false)).style ? c10 += "m" : c10 += "mm";
                break;
              case "month":
                switch ((o10 = t4(s10[0], false)).textual && (c10 += "mm"), o10.style) {
                  case "short":
                  default:
                    c10 += "m";
                    break;
                  case "long":
                    c10 += "mm";
                }
                break;
              case "seconds":
                "short" === (o10 = t4(s10[0], false)).style ? c10 += "s" : c10 += "ss", o10["decimal-places"] && (c10 += "." + tT("0", +o10["decimal-places"]));
                break;
              case "year":
                switch ((o10 = t4(s10[0], false)).style) {
                  case "short":
                  default:
                    c10 += "yy";
                    break;
                  case "long":
                    c10 += "yyyy";
                }
                break;
              case "am-pm":
                c10 += "AM/PM";
                break;
              case "week-of-year":
              case "quarter":
                console.error("Excel does not support ODS format token " + s10[3]);
                break;
              case "fill-character":
                "/" === s10[1] ? c10 += '"' + (u2 = n10.slice(h2, rE.lastIndex - s10[0].length)).replace(/"/g, '""') + '"*' : "/" !== s10[0].charAt(s10[0].length - 2) && (h2 = rE.lastIndex);
                break;
              case "scientific-number":
                c10 += "0." + tT("0", +(o10 = t4(s10[0], false))["min-decimal-places"] || +o10["decimal-places"] || 2) + tT("?", o10["decimal-places"] - o10["min-decimal-places"] || 0) + "E" + (rs(o10["forced-exponent-sign"]) ? "+" : "") + tT("0", +o10["min-exponent-digits"] || 2);
                break;
              case "fraction":
                +(o10 = t4(s10[0], false))["min-integer-digits"] ? c10 += tT("0", +o10["min-integer-digits"]) : c10 += "#", c10 += " ", c10 += tT("?", +o10["min-numerator-digits"] || 1), c10 += "/", +o10["denominator-value"] ? c10 += o10["denominator-value"] : c10 += tT("?", +o10["min-denominator-digits"] || 1);
                break;
              case "currency-symbol":
                "/" === s10[1] ? c10 += '"' + n10.slice(h2, rE.lastIndex - s10[0].length).replace(/"/g, '""') + '"' : "/" !== s10[0].charAt(s10[0].length - 2) ? h2 = rE.lastIndex : c10 += "$";
                break;
              case "text-properties":
                switch (((o10 = t4(s10[0], false)).color || "").toLowerCase().replace("#", "")) {
                  case "ff0000":
                  case "red":
                    c10 = "[Red]" + c10;
                }
                break;
              case "text-content":
                c10 += "@";
                break;
              case "map":
                "value()>=0" == t8((o10 = t4(s10[0], false)).condition) ? c10 = a10[o10["apply-style-name"]] + ";" + c10 : console.error("ODS number format may be incorrect: " + o10.condition);
                break;
              case "number":
                if ("/" === s10[1]) break;
                l2 = "" + tT("0", +(o10 = t4(s10[0], false))["min-integer-digits"] || 1), rs(o10.grouping) && (l2 = eH(tT("#", Math.max(0, 4 - l2.length)) + l2)), (+o10["min-decimal-places"] || +o10["decimal-places"]) && (l2 += "."), +o10["min-decimal-places"] && (l2 += tT("0", +o10["min-decimal-places"] || 1)), o10["decimal-places"] - (+o10["min-decimal-places"] || 0) && (l2 += tT("0", o10["decimal-places"] - (+o10["min-decimal-places"] || 0))), c10 += l2;
                break;
              case "embedded-text":
                "/" === s10[1] ? 0 == f2 ? c10 += '"' + n10.slice(h2, rE.lastIndex - s10[0].length).replace(/"/g, '""') + '"' : c10 = c10.slice(0, f2) + '"' + n10.slice(h2, rE.lastIndex - s10[0].length).replace(/"/g, '""') + '"' + c10.slice(f2) : "/" !== s10[0].charAt(s10[0].length - 2) && (h2 = rE.lastIndex, f2 = -t4(s10[0], false).position || 0);
            }
          return a10;
        }
        function o5(e10, t10, r10) {
          var a10 = t10 || {}, n10, s10, i10, o10 = ry(e10), c10 = [], l2 = 0, f2 = {}, h2 = [], u2 = {};
          a10.dense && (u2["!data"] = []);
          var d2, p2, m2, g2, v2 = { value: "" }, b2 = {}, w2 = "", T2 = 0, y2 = "", E2 = 0, k2 = [], x2 = [], _2 = -1, S2 = -1, A2 = { s: { r: 1e6, c: 1e7 }, e: { r: 0, c: 0 } }, C2 = 0, I2 = r10 || {}, O2 = {}, R2 = [], N2 = {}, F2 = 0, D2 = 0, P2 = [], L2 = 1, M2 = 1, U2 = [], B2 = { Names: [], WBProps: {} }, W2 = {}, z2 = ["", ""], H2 = [], V2 = {}, G2 = "", X2 = 0, j2 = false, K2 = false, Y2 = 0;
          for (rE.lastIndex = 0, o10 = tR(tF(o10, "<!--", "-->")); m2 = rE.exec(o10); )
            switch (m2[3] = m2[3].replace(/_[\s\S]*$/, "")) {
              case "table":
              case "工作表":
                "/" === m2[1] ? (A2.e.c >= A2.s.c && A2.e.r >= A2.s.r ? u2["!ref"] = aT(A2) : u2["!ref"] = "A1:A1", a10.sheetRows > 0 && a10.sheetRows <= A2.e.r && (u2["!fullref"] = u2["!ref"], A2.e.r = a10.sheetRows - 1, u2["!ref"] = aT(A2)), R2.length && (u2["!merges"] = R2), P2.length && (u2["!rows"] = P2), d2.name = d2["名称"] || d2.name, "undefined" != typeof JSON && JSON.stringify(d2), h2.push(d2.name), f2[d2.name] = u2, K2 = false) : "/" !== m2[0].charAt(m2[0].length - 2) && (d2 = t4(m2[0], false), _2 = S2 = -1, A2.s.r = A2.s.c = 1e7, A2.e.r = A2.e.c = 0, u2 = {}, a10.dense && (u2["!data"] = []), R2 = [], P2 = [], K2 = true);
                break;
              case "table-row-group":
                "/" === m2[1] ? --C2 : ++C2;
                break;
              case "table-row":
              case "行":
                if ("/" === m2[1]) {
                  _2 += L2, L2 = 1;
                  break;
                }
                if ((p2 = t4(m2[0], false))["行号"] ? _2 = p2["行号"] - 1 : -1 == _2 && (_2 = 0), (L2 = +p2["number-rows-repeated"] || 1) < 10)
                  for (Y2 = 0; Y2 < L2; ++Y2) C2 > 0 && (P2[_2 + Y2] = { level: C2 });
                S2 = -1;
                break;
              case "covered-table-cell":
                if ("/" !== m2[1])
                  if (++S2, M2 = parseInt((v2 = t4(m2[0], false))["number-columns-repeated"] || "1", 10) || 1, a10.sheetStubs) {
                    for (; M2-- > 0; )
                      a10.dense ? (u2["!data"][_2] || (u2["!data"][_2] = []), u2["!data"][_2][S2] = { t: "z" }) : u2[ab({ r: _2, c: S2 })] = { t: "z" }, ++S2;
                    --S2;
                  } else S2 += M2 - 1;
                w2 = "", k2 = [];
                break;
              case "table-cell":
              case "数据":
                if ("/" === m2[0].charAt(m2[0].length - 2))
                  ++S2, M2 = parseInt((v2 = t4(m2[0], false))["number-columns-repeated"] || "1", 10) || 1, g2 = { t: "z", v: null }, v2.formula && false != a10.cellFormula && (g2.f = iX(t8(v2.formula))), v2["style-name"] && O2[v2["style-name"]] && (g2.z = O2[v2["style-name"]]), "string" == (v2["数据类型"] || v2["value-type"]) && (g2.t = "s", g2.v = t8(v2["string-value"] || ""), a10.dense ? (u2["!data"][_2] || (u2["!data"][_2] = []), u2["!data"][_2][S2] = g2) : u2[ag(S2) + ap(_2)] = g2), S2 += M2 - 1;
                else if ("/" !== m2[1]) {
                  ++S2, w2 = y2 = "", T2 = E2 = 0, k2 = [], x2 = [], M2 = 1;
                  var Z2 = L2 ? _2 + L2 - 1 : _2;
                  if (S2 > A2.e.c && (A2.e.c = S2), S2 < A2.s.c && (A2.s.c = S2), _2 < A2.s.r && (A2.s.r = _2), Z2 > A2.e.r && (A2.e.r = Z2), v2 = t4(m2[0], false), b2 = (function(e11, t11, r11) {
                    for (var a11 = {}, n11 = 0, s11 = 0; n11 !== e11.length && 32 !== (s11 = e11.charCodeAt(n11)) && 10 !== s11 && 13 !== s11; ++n11) ;
                    if (t11 || (a11[0] = e11.slice(0, n11)), n11 === e11.length) return a11;
                    var i11 = e11.match(tq), o11 = "", c11 = 0, l3 = "", f3 = "", h3 = 1;
                    if (i11)
                      for (c11 = 0; c11 != i11.length; ++c11) {
                        for (s11 = 0, f3 = i11[c11].slice(1); s11 != f3.length && 61 !== f3.charCodeAt(s11); ++s11) ;
                        for (l3 = f3.slice(0, s11).trim(); 32 == f3.charCodeAt(s11 + 1); ) ++s11;
                        h3 = +(34 == (n11 = f3.charCodeAt(s11 + 1)) || 39 == n11), o11 = f3.slice(s11 + 1 + h3, f3.length - h3), l3.indexOf("_") > 0 && (l3 = l3.slice(0, l3.indexOf("_"))), a11[l3] = o11, a11[l3.toLowerCase()] = o11;
                      }
                    return a11;
                  })(m2[0], true), H2 = [], V2 = {}, g2 = { t: v2["数据类型"] || v2["value-type"], v: null }, v2["style-name"] && O2[v2["style-name"]] && (g2.z = O2[v2["style-name"]]), a10.cellFormula)
                    if (v2.formula && (v2.formula = t8(v2.formula)), v2["number-matrix-columns-spanned"] && v2["number-matrix-rows-spanned"] && (N2 = {
                      s: { r: _2, c: S2 },
                      e: {
                        r: _2 + (F2 = parseInt(v2["number-matrix-rows-spanned"], 10) || 0) - 1,
                        c: S2 + (D2 = parseInt(v2["number-matrix-columns-spanned"], 10) || 0) - 1
                      }
                    }, g2.F = aT(N2), U2.push([N2, g2.F])), v2.formula)
                      g2.f = iX(v2.formula);
                    else
                      for (Y2 = 0; Y2 < U2.length; ++Y2)
                        _2 >= U2[Y2][0].s.r && _2 <= U2[Y2][0].e.r && S2 >= U2[Y2][0].s.c && S2 <= U2[Y2][0].e.c && (g2.F = U2[Y2][1]);
                  switch ((v2["number-columns-spanned"] || v2["number-rows-spanned"]) && (F2 = parseInt(v2["number-rows-spanned"] || "1", 10) || 1) * (D2 = parseInt(v2["number-columns-spanned"] || "1", 10) || 1) > 1 && (N2 = { s: { r: _2, c: S2 }, e: { r: _2 + F2 - 1, c: S2 + D2 - 1 } }, R2.push(N2)), v2["number-columns-repeated"] && (M2 = parseInt(v2["number-columns-repeated"], 10)), g2.t) {
                    case "boolean":
                      g2.t = "b", g2.v = rs(v2["boolean-value"]) || +v2["boolean-value"] >= 1;
                      break;
                    case "float":
                      g2.t = "n", g2.v = parseFloat(v2.value), a10.cellDates && g2.z && eQ(g2.z) && (g2.v = td(g2.v + 1462 * !!B2.WBProps.date1904), g2.t = "number" == typeof g2.v ? "n" : "d");
                      break;
                    case "percentage":
                    case "currency":
                      g2.t = "n", g2.v = parseFloat(v2.value);
                      break;
                    case "date":
                      g2.t = "d", g2.v = tv(v2["date-value"], B2.WBProps.date1904), a10.cellDates || (g2.t = "n", g2.v = tu(g2.v, B2.WBProps.date1904)), g2.z || (g2.z = "m/d/yy");
                      break;
                    case "time":
                      g2.t = "n", g2.v = (function(e11) {
                        var t11 = 0, r11 = 0, a11 = false, n11 = e11.match(
                          /P([0-9\.]+Y)?([0-9\.]+M)?([0-9\.]+D)?T([0-9\.]+H)?([0-9\.]+M)?([0-9\.]+S)?/
                        );
                        if (!n11) throw Error("|" + e11 + "| is not an ISO8601 Duration");
                        for (var s11 = 1; s11 != n11.length; ++s11)
                          if (n11[s11]) {
                            switch (r11 = 1, s11 > 3 && (a11 = true), n11[s11].slice(n11[s11].length - 1)) {
                              case "Y":
                                throw Error("Unsupported ISO Duration Field: " + n11[s11].slice(n11[s11].length - 1));
                              case "D":
                                r11 *= 24;
                              case "H":
                                r11 *= 60;
                              case "M":
                                if (a11) r11 *= 60;
                                else throw Error("Unsupported ISO Duration Field: M");
                            }
                            t11 += r11 * parseInt(n11[s11], 10);
                          }
                        return t11;
                      })(v2["time-value"]) / 86400, a10.cellDates && (g2.v = td(g2.v), g2.t = "number" == typeof g2.v ? "n" : "d"), g2.z || (g2.z = "HH:MM:SS");
                      break;
                    case "number":
                      g2.t = "n", g2.v = parseFloat(v2["数据数值"]);
                      break;
                    default:
                      if ("string" !== g2.t && "text" !== g2.t && g2.t) throw Error("Unsupported value type " + g2.t);
                      g2.t = "s", null != v2["string-value"] && (w2 = t8(v2["string-value"]), k2 = []);
                  }
                } else {
                  if (j2 = false, "error" == b2["calcext:value-type"] && null != a0[w2] && (g2.t = "e", g2.w = w2, g2.v = a0[w2]), "s" === g2.t && (g2.v = w2 || "", k2.length && (g2.R = k2), j2 = 0 == T2), W2.Target && (g2.l = W2), H2.length > 0 && (g2.c = H2, H2 = []), w2 && false !== a10.cellText && (g2.w = w2), j2 && (g2.t = "z", delete g2.v), (!j2 || a10.sheetStubs) && !(a10.sheetRows && a10.sheetRows <= _2))
                    for (var J2 = 0; J2 < L2; ++J2) {
                      if (M2 = parseInt(v2["number-columns-repeated"] || "1", 10), a10.dense)
                        for (u2["!data"][_2 + J2] || (u2["!data"][_2 + J2] = []), u2["!data"][_2 + J2][S2] = 0 == J2 ? g2 : tw(g2); --M2 > 0; )
                          u2["!data"][_2 + J2][S2 + M2] = tw(g2);
                      else for (u2[ab({ r: _2 + J2, c: S2 })] = g2; --M2 > 0; ) u2[ab({ r: _2 + J2, c: S2 + M2 })] = tw(g2);
                      A2.e.c <= S2 && (A2.e.c = S2);
                    }
                  S2 += (M2 = parseInt(v2["number-columns-repeated"] || "1", 10)) - 1, M2 = 0, g2 = {}, w2 = "", k2 = [];
                }
                W2 = {};
                break;
              case "document":
              case "document-content":
              case "电子表格文档":
              case "spreadsheet":
              case "主体":
              case "scripts":
              case "styles":
              case "font-face-decls":
              case "master-styles":
                if ("/" === m2[1]) {
                  if ((n10 = c10.pop())[0] !== m2[3]) throw "Bad state: " + n10;
                } else "/" !== m2[0].charAt(m2[0].length - 2) && c10.push([m2[3], true]);
                break;
              case "annotation":
                if ("/" === m2[1]) {
                  if ((n10 = c10.pop())[0] !== m2[3]) throw "Bad state: " + n10;
                  V2.t = w2, k2.length && (V2.R = k2), V2.a = G2, H2.push(V2), w2 = y2, T2 = E2, k2 = x2;
                } else if ("/" !== m2[0].charAt(m2[0].length - 2)) {
                  c10.push([m2[3], false]);
                  var q2 = t4(m2[0], true);
                  q2.display && rs(q2.display) || (H2.hidden = true), y2 = w2, E2 = T2, x2 = k2, w2 = "", T2 = 0, k2 = [];
                }
                G2 = "", X2 = 0;
                break;
              case "creator":
                "/" === m2[1] ? G2 = o10.slice(X2, m2.index) : X2 = m2.index + m2[0].length;
                break;
              case "meta":
              case "元数据":
              case "settings":
              case "config-item-set":
              case "config-item-map-indexed":
              case "config-item-map-entry":
              case "config-item-map-named":
              case "shapes":
              case "frame":
              case "text-box":
              case "image":
              case "data-pilot-tables":
              case "list-style":
              case "form":
              case "dde-links":
              case "event-listeners":
              case "chart":
                if ("/" === m2[1]) {
                  if ((n10 = c10.pop())[0] !== m2[3]) throw "Bad state: " + n10;
                } else "/" !== m2[0].charAt(m2[0].length - 2) && c10.push([m2[3], false]);
                w2 = "", T2 = 0, k2 = [];
                break;
              case "scientific-number":
              case "currency-symbol":
              case "fill-character":
              case "script":
              case "libraries":
              case "automatic-styles":
              case "default-style":
              case "page-layout":
              case "map":
              case "font-face":
              case "paragraph-properties":
              case "table-properties":
              case "table-column-properties":
              case "table-row-properties":
              case "table-cell-properties":
              case "number":
              case "fraction":
              case "day":
              case "month":
              case "year":
              case "era":
              case "day-of-week":
              case "week-of-year":
              case "quarter":
              case "hours":
              case "minutes":
              case "seconds":
              case "am-pm":
              case "boolean":
              case "text-content":
              case "text-properties":
              case "embedded-text":
              case "body":
              case "电子表格":
              case "forms":
              case "table-column":
              case "table-header-rows":
              case "table-rows":
              case "table-column-group":
              case "table-header-columns":
              case "table-columns":
              case "graphic-properties":
              case "calculation-settings":
              case "named-expressions":
              case "label-range":
              case "label-ranges":
              case "named-expression":
              case "sort":
              case "sort-by":
              case "sort-groups":
              case "tab":
              case "line-break":
              case "span":
              case "s":
              case "date":
              case "object":
              case "title":
              case "标题":
              case "desc":
              case "binary-data":
              case "table-source":
              case "scenario":
              case "iteration":
              case "content-validations":
              case "content-validation":
              case "help-message":
              case "error-message":
              case "database-ranges":
              case "filter":
              case "filter-and":
              case "filter-or":
              case "filter-condition":
              case "filter-set-item":
              case "list-level-style-bullet":
              case "list-level-style-number":
              case "list-level-properties":
              case "sender-firstname":
              case "sender-lastname":
              case "sender-initials":
              case "sender-title":
              case "sender-position":
              case "sender-email":
              case "sender-phone-private":
              case "sender-fax":
              case "sender-company":
              case "sender-phone-work":
              case "sender-street":
              case "sender-city":
              case "sender-postal-code":
              case "sender-country":
              case "sender-state-or-province":
              case "author-name":
              case "author-initials":
              case "chapter":
              case "file-name":
              case "template-name":
              case "sheet-name":
              case "event-listener":
              case "initial-creator":
              case "creation-date":
              case "print-date":
              case "generator":
              case "document-statistic":
              case "user-defined":
              case "editing-duration":
              case "editing-cycles":
              case "config-item":
              case "page-number":
              case "page-count":
              case "time":
              case "cell-range-source":
              case "detective":
              case "operation":
              case "highlighted-range":
              case "data-pilot-table":
              case "source-cell-range":
              case "source-service":
              case "data-pilot-field":
              case "data-pilot-level":
              case "data-pilot-subtotals":
              case "data-pilot-subtotal":
              case "data-pilot-members":
              case "data-pilot-member":
              case "data-pilot-display-info":
              case "data-pilot-sort-info":
              case "data-pilot-layout-info":
              case "data-pilot-field-reference":
              case "data-pilot-groups":
              case "data-pilot-group":
              case "data-pilot-group-member":
              case "rect":
              case "dde-connection-decls":
              case "dde-connection-decl":
              case "dde-link":
              case "dde-source":
              case "properties":
              case "property":
              case "table-protection":
              case "data-pilot-grand-total":
              case "office-document-common-attrs":
                break;
              case "text-style":
              case "boolean-style":
              case "number-style":
              case "currency-style":
              case "percentage-style":
              case "date-style":
              case "time-style":
                if ("/" === m2[1]) {
                  var Q2 = rE.lastIndex;
                  o3(o10.slice(i10, rE.lastIndex), t10, I2), rE.lastIndex = Q2;
                } else "/" !== m2[0].charAt(m2[0].length - 2) && (i10 = rE.lastIndex - m2[0].length);
                break;
              case "style":
                var ee2 = t4(m2[0], false);
                "table-cell" == ee2.family && I2[ee2["data-style-name"]] && (O2[ee2.name] = I2[ee2["data-style-name"]]);
                break;
              case "text":
                if ("/>" === m2[0].slice(-2)) ;
                else if ("/" === m2[1])
                  switch (c10[c10.length - 1][0]) {
                    case "number-style":
                    case "date-style":
                    case "time-style":
                      o10.slice(l2, m2.index);
                  }
                else l2 = m2.index + m2[0].length;
                break;
              case "named-range":
                z2 = ij((s10 = t4(m2[0], false))["cell-range-address"]);
                var et2 = { Name: s10.name, Ref: z2[0] + "!" + z2[1] };
                K2 && (et2.Sheet = h2.length), B2.Names.push(et2);
                break;
              case "null-date":
                "1904-01-01" === (s10 = t4(m2[0], false))["date-value"] && (B2.WBProps.date1904 = true);
                break;
              case "p":
              case "文本串":
                if (["master-styles"].indexOf(c10[c10.length - 1][0]) > -1) break;
                if ("/" !== m2[1] || v2 && v2["string-value"])
                  "/>" == m2[0].slice(-2) ? w2 += "\n" : (t4(m2[0], false), T2 = m2.index + m2[0].length);
                else {
                  var er2 = [
                    t8(
                      o10.slice(T2, m2.index).replace(/[\t\r\n]/g, " ").trim().replace(/ +/g, " ").replace(/<text:s\/>/g, " ").replace(/<text:s text:c="(\d+)"\/>/g, function(e11, t11) {
                        return Array(parseInt(t11, 10) + 1).join(" ");
                      }).replace(/<text:tab[^<>]*\/>/g, "	").replace(/<text:line-break\/>/g, "\n").replace(/<[^<>]*>/g, "")
                    )
                  ];
                  w2 = (w2.length > 0 ? w2 + "\n" : "") + er2[0];
                }
                break;
              case "database-range":
                if ("/" === m2[1]) break;
                try {
                  f2[(z2 = ij(t4(m2[0])["target-range-address"]))[0]]["!autofilter"] = { ref: z2[1] };
                } catch (e11) {
                }
                break;
              case "a":
                if ("/" !== m2[1]) {
                  if (!(W2 = t4(m2[0], false)).href) break;
                  W2.Target = t8(W2.href), delete W2.href, "#" == W2.Target.charAt(0) && W2.Target.indexOf(".") > -1 ? (z2 = ij(W2.Target.slice(1)), W2.Target = "#" + z2[0] + "!" + z2[1]) : W2.Target.match(/^\.\.[\\\/]/) && (W2.Target = W2.Target.slice(3));
                }
                break;
              default:
                switch (m2[2]) {
                  case "dc:":
                  case "calcext:":
                  case "loext:":
                  case "ooo:":
                  case "chartooo:":
                  case "draw:":
                  case "style:":
                  case "chart:":
                  case "form:":
                  case "uof:":
                  case "表:":
                  case "字:":
                    break;
                  default:
                    if (a10.WTF) throw Error(m2);
                }
            }
          var ea2 = { Sheets: f2, SheetNames: h2, Workbook: B2 };
          return a10.bookSheets && delete ea2.Sheets, ea2;
        }
        var o6 = (B = "<office:document-styles " + rb({
          "xmlns:office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
          "xmlns:table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
          "xmlns:style": "urn:oasis:names:tc:opendocument:xmlns:style:1.0",
          "xmlns:text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
          "xmlns:draw": "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0",
          "xmlns:fo": "urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0",
          "xmlns:xlink": "http://www.w3.org/1999/xlink",
          "xmlns:dc": "http://purl.org/dc/elements/1.1/",
          "xmlns:number": "urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0",
          "xmlns:svg": "urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0",
          "xmlns:of": "urn:oasis:names:tc:opendocument:xmlns:of:1.2",
          "office:version": "1.2"
        }) + '><office:master-styles><style:master-page style:name="mp1" style:page-layout-name="mp1"><style:header/><style:header-left style:display="false"/><style:footer/><style:footer-left style:display="false"/></style:master-page></office:master-styles></office:document-styles>', function() {
          return tJ + B;
        });
        function o8(e10, t10, r10) {
          for (var a10 = [], n10 = 0; n10 < e10.length; ++n10) {
            var s10 = e10[n10];
            s10 && s10.Sheet == (-1 == r10 ? null : r10) && a10.push(s10);
          }
          return a10.length ? "      <table:named-expressions>\n" + a10.map(function(e11) {
            var t11 = (-1 == r10 ? "$" : "") + iK(e11.Ref);
            return "        " + rw("table:named-range", null, {
              "table:name": e11.Name,
              "table:cell-range-address": t11,
              "table:base-cell-address": t11.replace(/[\.][^\.]*$/, ".$A$1")
            });
          }).join("\n") + "\n      </table:named-expressions>\n" : "";
        }
        var o7 = (W = function(e10, t10) {
          return re(e10).replace(/  +/g, function(e11) {
            return '<text:s text:c="' + e11.length + '"/>';
          }).replace(/\t/g, "<text:tab/>").replace(/\n/g, t10 ? "<text:line-break/>" : "</text:p><text:p>").replace(/^ /, "<text:s/>").replace(/ $/, "<text:s/>");
        }, z = "          <table:table-cell />\n", H = function(e10, t10, r10, a10, n10, s10) {
          var i10 = [];
          i10.push('      <table:table table:name="' + re(t10.SheetNames[r10]) + '" table:style-name="ta1">\n');
          var o10 = 0, c10 = 0, l2 = aw(e10["!ref"] || "A1"), f2 = e10["!merges"] || [], h2 = 0, u2 = null != e10["!data"];
          if (e10["!cols"])
            for (c10 = 0; c10 <= l2.e.c; ++c10)
              i10.push(
                "        <table:table-column" + (e10["!cols"][c10] ? ' table:style-name="co' + e10["!cols"][c10].ods + '"' : "") + "></table:table-column>\n"
              );
          var d2 = "", p2 = e10["!rows"] || [];
          for (o10 = 0; o10 < l2.s.r; ++o10)
            d2 = p2[o10] ? ' table:style-name="ro' + p2[o10].ods + '"' : "", i10.push("        <table:table-row" + d2 + "></table:table-row>\n");
          for (; o10 <= l2.e.r; ++o10) {
            for (d2 = p2[o10] ? ' table:style-name="ro' + p2[o10].ods + '"' : "", i10.push("        <table:table-row" + d2 + ">\n"), c10 = 0; c10 < l2.s.c; ++c10)
              i10.push(z);
            for (; c10 <= l2.e.c; ++c10) {
              var m2 = false, g2 = {}, v2 = "";
              for (h2 = 0; h2 != f2.length; ++h2)
                if (!(f2[h2].s.c > c10) && !(f2[h2].s.r > o10) && !(f2[h2].e.c < c10) && !(f2[h2].e.r < o10)) {
                  (f2[h2].s.c != c10 || f2[h2].s.r != o10) && (m2 = true), g2["table:number-columns-spanned"] = f2[h2].e.c - f2[h2].s.c + 1, g2["table:number-rows-spanned"] = f2[h2].e.r - f2[h2].s.r + 1;
                  break;
                }
              if (m2) {
                i10.push("          <table:covered-table-cell/>\n");
                continue;
              }
              var b2 = ab({ r: o10, c: c10 }), w2 = u2 ? (e10["!data"][o10] || [])[c10] : e10[b2];
              if (w2 && w2.f && (g2["table:formula"] = re(
                ("of:=" + w2.f.replace(id, "$1[.$2$3$4$5]").replace(/\]:\[/g, ":")).replace(/;/g, "|").replace(/,/g, ";")
              ), w2.F && w2.F.slice(0, b2.length) == b2)) {
                var T2 = aw(w2.F);
                g2["table:number-matrix-columns-spanned"] = T2.e.c - T2.s.c + 1, g2["table:number-matrix-rows-spanned"] = T2.e.r - T2.s.r + 1;
              }
              if (!w2) {
                i10.push(z);
                continue;
              }
              switch (w2.t) {
                case "b":
                  v2 = w2.v ? "TRUE" : "FALSE", g2["office:value-type"] = "boolean", g2["office:boolean-value"] = w2.v ? "true" : "false";
                  break;
                case "n":
                  isFinite(w2.v) ? (v2 = w2.w || String(w2.v || 0), g2["office:value-type"] = "float", g2["office:value"] = w2.v || 0) : (isNaN(w2.v) ? (v2 = "#NUM!", g2["table:formula"] = "of:=#NUM!") : (v2 = "#DIV/0!", g2["table:formula"] = "of:=" + (w2.v < 0 ? "-" : "") + "1/0"), g2["office:string-value"] = "", g2["office:value-type"] = "string", g2["calcext:value-type"] = "error");
                  break;
                case "s":
                case "str":
                  v2 = null == w2.v ? "" : w2.v, g2["office:value-type"] = "string";
                  break;
                case "d":
                  v2 = w2.w || tv(w2.v, s10).toISOString(), g2["office:value-type"] = "date", g2["office:date-value"] = tv(w2.v, s10).toISOString(), g2["table:style-name"] = "ce1";
                  break;
                default:
                  i10.push(z);
                  continue;
              }
              var y2 = W(v2);
              if (w2.l && w2.l.Target) {
                var E2 = w2.l.Target;
                "#" == (E2 = "#" == E2.charAt(0) ? "#" + iK(E2.slice(1)) : E2).charAt(0) || E2.match(/^\w+:/) || (E2 = "../" + E2), y2 = rw("text:a", y2, { "xlink:href": E2.replace(/&/g, "&amp;") });
              }
              n10[w2.z] && (g2["table:style-name"] = "ce" + n10[w2.z].slice(1));
              var k2 = rw("text:p", y2, {});
              if (w2.c) {
                for (var x2 = "", _2 = "", S2 = {}, A2 = 0; A2 < w2.c.length; ++A2)
                  !x2 && w2.c[A2].a && (x2 = w2.c[A2].a), _2 += "<text:p>" + W(w2.c[A2].t) + "</text:p>";
                w2.c.hidden || (S2["office:display"] = true), k2 = rw("office:annotation", _2, S2) + k2;
              }
              i10.push("          " + rw("table:table-cell", k2, g2) + "\n");
            }
            i10.push("        </table:table-row>\n");
          }
          return (t10.Workbook || {}).Names && i10.push(o8(t10.Workbook.Names, t10.SheetNames, r10)), i10.push("      </table:table>\n"), i10.join("");
        }, V = function(e10, t10) {
          e10.push(" <office:automatic-styles>\n");
          var r10 = 0;
          t10.SheetNames.map(function(e11) {
            return t10.Sheets[e11];
          }).forEach(function(t11) {
            if (t11 && t11["!cols"]) {
              for (var a11 = 0; a11 < t11["!cols"].length; ++a11)
                if (t11["!cols"][a11]) {
                  var n11 = t11["!cols"][a11];
                  if (null == n11.width && null == n11.wpx && null == n11.wch) continue;
                  s0(n11), n11.ods = r10;
                  var s11 = t11["!cols"][a11].wpx + "px";
                  e10.push('  <style:style style:name="co' + r10 + '" style:family="table-column">\n'), e10.push(
                    '   <style:table-column-properties fo:break-before="auto" style:column-width="' + s11 + '"/>\n'
                  ), e10.push("  </style:style>\n"), ++r10;
                }
            }
          });
          var a10 = 0;
          t10.SheetNames.map(function(e11) {
            return t10.Sheets[e11];
          }).forEach(function(t11) {
            if (t11 && t11["!rows"]) {
              for (var r11 = 0; r11 < t11["!rows"].length; ++r11)
                if (t11["!rows"][r11]) {
                  t11["!rows"][r11].ods = a10;
                  var n11 = t11["!rows"][r11].hpx + "px";
                  e10.push('  <style:style style:name="ro' + a10 + '" style:family="table-row">\n'), e10.push(
                    '   <style:table-row-properties fo:break-before="auto" style:row-height="' + n11 + '"/>\n'
                  ), e10.push("  </style:style>\n"), ++a10;
                }
            }
          }), e10.push('  <style:style style:name="ta1" style:family="table" style:master-page-name="mp1">\n'), e10.push('   <style:table-properties table:display="true" style:writing-mode="lr-tb"/>\n'), e10.push("  </style:style>\n"), e10.push('  <number:date-style style:name="N37" number:automatic-order="true">\n'), e10.push('   <number:month number:style="long"/>\n'), e10.push("   <number:text>/</number:text>\n"), e10.push('   <number:day number:style="long"/>\n'), e10.push("   <number:text>/</number:text>\n"), e10.push("   <number:year/>\n"), e10.push("  </number:date-style>\n");
          var n10 = {}, s10 = 69;
          return t10.SheetNames.map(function(e11) {
            return t10.Sheets[e11];
          }).forEach(function(t11) {
            if (t11) {
              var r11 = null != t11["!data"];
              if (t11["!ref"])
                for (var a11 = aw(t11["!ref"]), i10 = 0; i10 <= a11.e.r; ++i10)
                  for (var o10 = 0; o10 <= a11.e.c; ++o10) {
                    var c10 = r11 ? (t11["!data"][i10] || [])[o10] : t11[ab({ r: i10, c: o10 })];
                    if (c10 && c10.z && "general" != c10.z.toLowerCase() && !n10[c10.z]) {
                      var l2 = (function(e11, t12) {
                        var r12 = "number", a12 = "", n11 = { "style:name": t12 }, s11 = "", i11 = 0;
                        e11 = e11.replace(/"[$]"/g, "$");
                        r: {
                          if (e11.indexOf(";") > -1 && (console.error("Unsupported ODS Style Map exported.  Using first branch of " + e11), e11 = e11.slice(0, e11.indexOf(";"))), "@" == e11) {
                            r12 = "text", a12 = "<number:text-content/>";
                            break r;
                          }
                          if (e11.indexOf(/\$/) > -1 && (r12 = "currency"), '"' == e11[i11]) {
                            for (s11 = ""; '"' != e11[++i11] || '"' == e11[++i11]; ) s11 += e11[i11];
                            "*" == e11[--i11 + 1] ? (i11++, a12 += "<number:fill-character>" + re(s11.replace(/""/g, '"')) + "</number:fill-character>") : a12 += "<number:text>" + re(s11.replace(/""/g, '"')) + "</number:text>", e11 = e11.slice(i11 + 1), i11 = 0;
                          }
                          var o11 = e11.match(/# (\?+)\/(\?+)/);
                          if (o11) {
                            a12 += rw("number:fraction", null, {
                              "number:min-integer-digits": 0,
                              "number:min-numerator-digits": o11[1].length,
                              "number:max-denominator-value": Math.max(
                                +o11[1].replace(/./g, "9"),
                                +o11[2].replace(/./g, "9")
                              )
                            });
                            break r;
                          }
                          if (o11 = e11.match(/# (\?+)\/(\d+)/)) {
                            a12 += rw("number:fraction", null, {
                              "number:min-integer-digits": 0,
                              "number:min-numerator-digits": o11[1].length,
                              "number:denominator-value": +o11[2]
                            });
                            break r;
                          }
                          if (o11 = e11.match(/\b(\d+)(|\.\d+)%/)) {
                            r12 = "percentage", a12 += rw("number:number", null, {
                              "number:decimal-places": o11[2] && o11.length - 1 || 0,
                              "number:min-decimal-places": o11[2] && o11.length - 1 || 0,
                              "number:min-integer-digits": o11[1].length
                            }) + "<number:text>%</number:text>";
                            break r;
                          }
                          var c11 = false;
                          if (["y", "m", "d"].indexOf(e11[0]) > -1) {
                            r12 = "date";
                            a: for (; i11 < e11.length; ++i11)
                              switch (s11 = e11[i11].toLowerCase()) {
                                case "h":
                                case "s":
                                  c11 = true, --i11;
                                  break a;
                                case "m":
                                  n: for (var l3 = i11 + 1; l3 < e11.length; ++l3)
                                    switch (e11[l3]) {
                                      case "y":
                                      case "d":
                                        break n;
                                      case "h":
                                      case "s":
                                        c11 = true, --i11;
                                        break a;
                                    }
                                case "y":
                                case "d":
                                  for (; (e11[++i11] || "").toLowerCase() == s11[0]; ) s11 += s11[0];
                                  switch (--i11, s11) {
                                    case "y":
                                    case "yy":
                                      a12 += "<number:year/>";
                                      break;
                                    case "yyy":
                                    case "yyyy":
                                      a12 += '<number:year number:style="long"/>';
                                      break;
                                    case "mmmmm":
                                      console.error("ODS has no equivalent of format |mmmmm|");
                                    case "m":
                                    case "mm":
                                    case "mmm":
                                    case "mmmm":
                                      a12 += '<number:month number:style="' + (s11.length % 2 ? "short" : "long") + '" number:textual="' + (s11.length >= 3 ? "true" : "false") + '"/>';
                                      break;
                                    case "d":
                                    case "dd":
                                      a12 += '<number:day number:style="' + (s11.length % 2 ? "short" : "long") + '"/>';
                                      break;
                                    case "ddd":
                                    case "dddd":
                                      a12 += '<number:day-of-week number:style="' + (s11.length % 2 ? "short" : "long") + '"/>';
                                  }
                                  break;
                                case '"':
                                  for (; '"' != e11[++i11] || '"' == e11[++i11]; ) s11 += e11[i11];
                                  --i11, a12 += "<number:text>" + re(s11.slice(1).replace(/""/g, '"')) + "</number:text>";
                                  break;
                                case "\\":
                                  a12 += "<number:text>" + re(s11 = e11[++i11]) + "</number:text>";
                                  break;
                                case "/":
                                case ":":
                                  a12 += "<number:text>" + re(s11) + "</number:text>";
                                  break;
                                default:
                                  console.error("unrecognized character " + s11 + " in ODF format " + e11);
                              }
                            if (!c11) break r;
                            e11 = e11.slice(i11 + 1), i11 = 0;
                          }
                          if (e11.match(/^\[?[hms]/)) {
                            for ("number" == r12 && (r12 = "time"), e11.match(/\[/) && (e11 = e11.replace(/[\[\]]/g, ""), n11["number:truncate-on-overflow"] = "false"); i11 < e11.length; ++i11)
                              switch (s11 = e11[i11].toLowerCase()) {
                                case "h":
                                case "m":
                                case "s":
                                  for (; (e11[++i11] || "").toLowerCase() == s11[0]; ) s11 += s11[0];
                                  switch (--i11, s11) {
                                    case "h":
                                    case "hh":
                                      a12 += '<number:hours number:style="' + (s11.length % 2 ? "short" : "long") + '"/>';
                                      break;
                                    case "m":
                                    case "mm":
                                      a12 += '<number:minutes number:style="' + (s11.length % 2 ? "short" : "long") + '"/>';
                                      break;
                                    case "s":
                                    case "ss":
                                      if ("." == e11[i11 + 1])
                                        do
                                          s11 += e11[i11 + 1], ++i11;
                                        while ("0" == e11[i11 + 1]);
                                      a12 += '<number:seconds number:style="' + (s11.match("ss") ? "long" : "short") + '"' + (s11.match(/\./) ? ' number:decimal-places="' + (s11.match(/0+/) || [""])[0].length + '"' : "") + "/>";
                                  }
                                  break;
                                case '"':
                                  for (; '"' != e11[++i11] || '"' == e11[++i11]; ) s11 += e11[i11];
                                  --i11, a12 += "<number:text>" + re(s11.slice(1).replace(/""/g, '"')) + "</number:text>";
                                  break;
                                case "/":
                                case ":":
                                  a12 += "<number:text>" + re(s11) + "</number:text>";
                                  break;
                                case "a":
                                  if ("a/p" == e11.slice(i11, i11 + 3).toLowerCase()) {
                                    a12 += "<number:am-pm/>", i11 += 2;
                                    break;
                                  }
                                  if ("am/pm" == e11.slice(i11, i11 + 5).toLowerCase()) {
                                    a12 += "<number:am-pm/>", i11 += 4;
                                    break;
                                  }
                                default:
                                  console.error("unrecognized character " + s11 + " in ODF format " + e11);
                              }
                            break r;
                          }
                          if (e11.indexOf(/\$/) > -1 && (r12 = "currency"), "$" == e11[0] && (a12 += '<number:currency-symbol number:language="en" number:country="US">$</number:currency-symbol>', e11 = e11.slice(1), i11 = 0), '"' == e11[i11 = 0]) {
                            for (; '"' != e11[++i11] || '"' == e11[++i11]; ) s11 += e11[i11];
                            "*" == e11[--i11 + 1] ? (i11++, a12 += "<number:fill-character>" + re(s11.replace(/""/g, '"')) + "</number:fill-character>") : a12 += "<number:text>" + re(s11.replace(/""/g, '"')) + "</number:text>", e11 = e11.slice(i11 + 1), i11 = 0;
                          }
                          var f2 = e11.match(/([#0][0#,]*)(\.[0#]*|)(E[+]?0*|)/i);
                          if (f2 && f2[0]) {
                            var h2 = f2[1].replace(/,/g, "");
                            a12 += "<number:" + (f2[3] ? "scientific-" : "") + 'number number:min-integer-digits="' + (-1 == h2.indexOf("0") ? "0" : h2.length - h2.indexOf("0")) + '"' + (f2[0].indexOf(",") > -1 ? ' number:grouping="true"' : "") + (f2[2] && ' number:decimal-places="' + (f2[2].length - 1) + '"' || ' number:decimal-places="0"') + (f2[3] && f2[3].indexOf("+") > -1 ? ' number:forced-exponent-sign="true"' : "") + (f2[3] ? ' number:min-exponent-digits="' + f2[3].match(/0+/)[0].length + '"' : "") + "></number:" + (f2[3] ? "scientific-" : "") + "number>", i11 = f2.index + f2[0].length;
                          } else console.error("Could not find numeric part of " + e11);
                          if ('"' == e11[i11]) {
                            for (s11 = ""; '"' != e11[++i11] || '"' == e11[++i11]; ) s11 += e11[i11];
                            --i11, a12 += "<number:text>" + re(s11.replace(/""/g, '"')) + "</number:text>";
                          }
                        }
                        return a12 ? rw("number:" + r12 + "-style", a12, n11) : (console.error("Could not generate ODS number format for |" + e11 + "|"), "");
                      })(c10.z, "N" + s10);
                      l2 && (n10[c10.z] = "N" + s10, ++s10, e10.push(l2 + "\n"));
                    }
                  }
            }
          }), e10.push(
            '  <style:style style:name="ce1" style:family="table-cell" style:parent-style-name="Default" style:data-style-name="N37"/>\n'
          ), ts(n10).forEach(function(t11) {
            e10.push(
              '<style:style style:name="ce' + n10[t11].slice(1) + '" style:family="table-cell" style:parent-style-name="Default" style:data-style-name="' + n10[t11] + '"/>\n'
            );
          }), e10.push(" </office:automatic-styles>\n"), n10;
        }, function(e10, t10) {
          var r10 = [tJ], a10 = rb({
            "xmlns:office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
            "xmlns:table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
            "xmlns:style": "urn:oasis:names:tc:opendocument:xmlns:style:1.0",
            "xmlns:text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
            "xmlns:draw": "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0",
            "xmlns:fo": "urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0",
            "xmlns:xlink": "http://www.w3.org/1999/xlink",
            "xmlns:dc": "http://purl.org/dc/elements/1.1/",
            "xmlns:meta": "urn:oasis:names:tc:opendocument:xmlns:meta:1.0",
            "xmlns:number": "urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0",
            "xmlns:presentation": "urn:oasis:names:tc:opendocument:xmlns:presentation:1.0",
            "xmlns:svg": "urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0",
            "xmlns:chart": "urn:oasis:names:tc:opendocument:xmlns:chart:1.0",
            "xmlns:dr3d": "urn:oasis:names:tc:opendocument:xmlns:dr3d:1.0",
            "xmlns:math": "http://www.w3.org/1998/Math/MathML",
            "xmlns:form": "urn:oasis:names:tc:opendocument:xmlns:form:1.0",
            "xmlns:script": "urn:oasis:names:tc:opendocument:xmlns:script:1.0",
            "xmlns:ooo": "http://openoffice.org/2004/office",
            "xmlns:ooow": "http://openoffice.org/2004/writer",
            "xmlns:oooc": "http://openoffice.org/2004/calc",
            "xmlns:dom": "http://www.w3.org/2001/xml-events",
            "xmlns:xforms": "http://www.w3.org/2002/xforms",
            "xmlns:xsd": "http://www.w3.org/2001/XMLSchema",
            "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            "xmlns:sheet": "urn:oasis:names:tc:opendocument:sh33tjs:1.0",
            "xmlns:rpt": "http://openoffice.org/2005/report",
            "xmlns:of": "urn:oasis:names:tc:opendocument:xmlns:of:1.2",
            "xmlns:xhtml": "http://www.w3.org/1999/xhtml",
            "xmlns:grddl": "http://www.w3.org/2003/g/data-view#",
            "xmlns:tableooo": "http://openoffice.org/2009/table",
            "xmlns:drawooo": "http://openoffice.org/2010/draw",
            "xmlns:calcext": "urn:org:documentfoundation:names:experimental:calc:xmlns:calcext:1.0",
            "xmlns:loext": "urn:org:documentfoundation:names:experimental:office:xmlns:loext:1.0",
            "xmlns:field": "urn:openoffice:names:experimental:ooo-ms-interop:xmlns:field:1.0",
            "xmlns:formx": "urn:openoffice:names:experimental:ooxml-odf-interop:xmlns:form:1.0",
            "xmlns:css3t": "http://www.w3.org/TR/css3-text/",
            "office:version": "1.2"
          }), n10 = rb({
            "xmlns:config": "urn:oasis:names:tc:opendocument:xmlns:config:1.0",
            "office:mimetype": "application/vnd.oasis.opendocument.spreadsheet"
          });
          "fods" == t10.bookType ? (r10.push("<office:document" + a10 + n10 + ">\n"), r10.push(
            nw().replace(/<office:document-meta[^<>]*?>/, "").replace(/<\/office:document-meta>/, "") + "\n"
          )) : r10.push("<office:document-content" + a10 + ">\n");
          var s10 = V(r10, e10);
          r10.push("  <office:body>\n"), r10.push("    <office:spreadsheet>\n"), ((e10.Workbook || {}).WBProps || {}).date1904 && r10.push(
            '      <table:calculation-settings table:case-sensitive="false" table:search-criteria-must-apply-to-whole-cell="true" table:use-wildcards="true" table:use-regular-expressions="false" table:automatic-find-labels="false">\n        <table:null-date table:date-value="1904-01-01"/>\n      </table:calculation-settings>\n'
          );
          for (var i10 = 0; i10 != e10.SheetNames.length; ++i10)
            r10.push(H(e10.Sheets[e10.SheetNames[i10]], e10, i10, t10, s10, ((e10.Workbook || {}).WBProps || {}).date1904));
          return (e10.Workbook || {}).Names && r10.push(o8(e10.Workbook.Names, e10.SheetNames, -1)), r10.push("    </office:spreadsheet>\n"), r10.push("  </office:body>\n"), "fods" == t10.bookType ? r10.push("</office:document>") : r10.push("</office:document-content>"), r10.join("");
        });
        function o9(e10, t10) {
          if ("fods" == t10.bookType) return o7(e10, t10);
          var r10 = tK(), a10 = "", n10 = [], s10 = [];
          return tj(r10, a10 = "mimetype", "application/vnd.oasis.opendocument.spreadsheet"), tj(r10, a10 = "content.xml", o7(e10, t10)), n10.push([a10, "text/xml"]), s10.push([a10, "ContentFile"]), tj(r10, a10 = "styles.xml", o6(e10, t10)), n10.push([a10, "text/xml"]), s10.push([a10, "StylesFile"]), tj(r10, a10 = "meta.xml", tJ + nw()), n10.push([a10, "text/xml"]), s10.push([a10, "MetadataFile"]), tj(
            r10,
            a10 = "manifest.rdf",
            (function(e11) {
              var t11 = [tJ];
              t11.push('<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">\n');
              for (var r11 = 0; r11 != e11.length; ++r11)
                t11.push(nb(e11[r11][0], e11[r11][1])), t11.push(
                  '  <rdf:Description rdf:about="">\n    <ns0:hasPart xmlns:ns0="http://docs.oasis-open.org/ns/office/1.2/meta/pkg#" rdf:resource="' + e11[r11][0] + '"/>\n  </rdf:Description>\n'
                );
              return t11.push(nb("", "Document", "pkg")), t11.push("</rdf:RDF>"), t11.join("");
            })(s10)
          ), n10.push([a10, "application/rdf+xml"]), tj(
            r10,
            a10 = "META-INF/manifest.xml",
            (function(e11) {
              var t11 = [tJ];
              t11.push(
                '<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">\n'
              ), t11.push(
                '  <manifest:file-entry manifest:full-path="/" manifest:version="1.2" manifest:media-type="application/vnd.oasis.opendocument.spreadsheet"/>\n'
              );
              for (var r11 = 0; r11 < e11.length; ++r11)
                t11.push(
                  '  <manifest:file-entry manifest:full-path="' + e11[r11][0] + '" manifest:media-type="' + e11[r11][1] + '"/>\n'
                );
              return t11.push("</manifest:manifest>"), t11.join("");
            })(n10)
          ), r10;
        }
        var ce = (function() {
          try {
            if ("undefined" == typeof Uint8Array || void 0 === Uint8Array.prototype.subarray) return "slice";
            if (void 0 !== a) {
              if (void 0 === a.prototype.subarray) return "slice";
              if (("function" == typeof a.from ? a.from([72, 62]) : new a([72, 62])) instanceof Uint8Array)
                return "subarray";
              return "slice";
            }
            return "subarray";
          } catch (e10) {
            return "slice";
          }
        })();
        function ct(e10) {
          return new DataView(e10.buffer, e10.byteOffset, e10.byteLength);
        }
        function cr(e10) {
          return "undefined" != typeof TextDecoder ? new TextDecoder().decode(e10) : rf(ey(e10));
        }
        function ca(e10) {
          return "undefined" != typeof TextEncoder ? new TextEncoder().encode(e10) : ew(rh(e10));
        }
        function cn(e10) {
          for (var t10 = 0, r10 = 0; r10 < e10.length; ++r10) t10 += e10[r10].length;
          var a10 = new Uint8Array(t10), n10 = 0;
          for (r10 = 0; r10 < e10.length; ++r10) {
            var s10 = e10[r10], i10 = s10.length;
            if (i10 < 250) for (var o10 = 0; o10 < i10; ++o10) a10[n10++] = s10[o10];
            else a10.set(s10, n10), n10 += i10;
          }
          return a10;
        }
        function cs(e10) {
          return e10 -= e10 >> 1 & 1431655765, ((e10 = (858993459 & e10) + (e10 >> 2 & 858993459)) + (e10 >> 4) & 252645135) * 16843009 >>> 24;
        }
        function ci(e10, t10) {
          var r10 = t10.l, a10 = 127 & e10[r10];
          s: if (e10[r10++] >= 128 && (a10 |= (127 & e10[r10]) << 7, e10[r10++] < 128 || (a10 |= (127 & e10[r10]) << 14, e10[r10++] < 128) || (a10 |= (127 & e10[r10]) << 21, e10[r10++] < 128) || (a10 += (127 & e10[r10]) * 268435456, ++r10, e10[r10++] < 128) || (a10 += (127 & e10[r10]) * 34359738368, ++r10, e10[r10++] < 128) || (a10 += (127 & e10[r10]) * 4398046511104, ++r10, e10[r10++] < 128)))
            break s;
          return t10.l = r10, a10;
        }
        function co(e10) {
          var t10 = new Uint8Array(7);
          t10[0] = 127 & e10;
          var r10 = 1;
          i: if (e10 > 127) {
            if (t10[r10 - 1] |= 128, t10[r10] = e10 >> 7 & 127, ++r10, e10 <= 16383 || (t10[r10 - 1] |= 128, t10[r10] = e10 >> 14 & 127, ++r10, e10 <= 2097151) || (t10[r10 - 1] |= 128, t10[r10] = e10 >> 21 & 127, ++r10, e10 <= 268435455) || (t10[r10 - 1] |= 128, t10[r10] = e10 / 256 >>> 21 & 127, ++r10, e10 <= 34359738367) || (t10[r10 - 1] |= 128, t10[r10] = e10 / 65536 >>> 21 & 127, ++r10, e10 <= 4398046511103))
              break i;
            t10[r10 - 1] |= 128, t10[r10] = e10 / 16777216 >>> 21 & 127, ++r10;
          }
          return t10[ce](0, r10);
        }
        function cc(e10) {
          for (var t10 = { l: 0 }, r10 = []; t10.l < e10.length; ) r10.push(ci(e10, t10));
          return r10;
        }
        function cl(e10) {
          return cn(
            e10.map(function(e11) {
              return co(e11);
            })
          );
        }
        function cf(e10) {
          var t10 = 0, r10 = 127 & e10[0];
          return e10[t10++] < 128 || (r10 |= (127 & e10[t10]) << 7, e10[t10++] < 128 || (r10 |= (127 & e10[t10]) << 14, e10[t10++] < 128 || (r10 |= (127 & e10[t10]) << 21, e10[t10++] < 128))) ? r10 : r10 |= (15 & e10[t10]) << 28;
        }
        function ch(e10) {
          for (var t10 = [], r10 = { l: 0 }; r10.l < e10.length; ) {
            var a10, n10 = r10.l, s10 = ci(e10, r10), i10 = 7 & s10;
            s10 = s10 / 8 | 0;
            var o10 = r10.l;
            switch (i10) {
              case 0:
                for (; e10[o10++] >= 128; ) ;
                a10 = e10[ce](r10.l, o10), r10.l = o10;
                break;
              case 1:
                a10 = e10[ce](o10, o10 + 8), r10.l = o10 + 8;
                break;
              case 2:
                var c10 = ci(e10, r10);
                a10 = e10[ce](r10.l, r10.l + c10), r10.l += c10;
                break;
              case 5:
                a10 = e10[ce](o10, o10 + 4), r10.l = o10 + 4;
                break;
              default:
                throw Error("PB Type ".concat(i10, " for Field ").concat(s10, " at offset ").concat(n10));
            }
            var l2 = { data: a10, type: i10 };
            null == t10[s10] && (t10[s10] = []), t10[s10].push(l2);
          }
          return t10;
        }
        function cu(e10) {
          var t10 = [];
          return e10.forEach(function(e11, r10) {
            0 != r10 && e11.forEach(function(e12) {
              e12.data && (t10.push(co(8 * r10 + e12.type)), 2 == e12.type && t10.push(co(e12.data.length)), t10.push(e12.data));
            });
          }), cn(t10);
        }
        function cd(e10, t10) {
          return (null == e10 ? void 0 : e10.map(function(e11) {
            return t10(e11.data);
          })) || [];
        }
        function cp(e10) {
          for (var t10, r10 = [], a10 = { l: 0 }; a10.l < e10.length; ) {
            var n10 = ci(e10, a10), s10 = ch(e10[ce](a10.l, a10.l + n10));
            a10.l += n10;
            var i10 = { id: cf(s10[1][0].data), messages: [] };
            s10[2].forEach(function(t11) {
              var r11 = ch(t11.data), n11 = cf(r11[3][0].data);
              i10.messages.push({ meta: r11, data: e10[ce](a10.l, a10.l + n11) }), a10.l += n11;
            }), (null == (t10 = s10[3]) ? void 0 : t10[0]) && (i10.merge = cf(s10[3][0].data) >>> 0 > 0), r10.push(i10);
          }
          return r10;
        }
        function cm(e10) {
          var t10 = [];
          return e10.forEach(function(e11) {
            var r10 = [[], [{ data: co(e11.id), type: 0 }], []];
            null != e11.merge && (r10[3] = [{ data: co(+!!e11.merge), type: 0 }]);
            var a10 = [];
            e11.messages.forEach(function(e12) {
              a10.push(e12.data), e12.meta[3] = [{ type: 0, data: co(e12.data.length) }], r10[2].push({ data: cu(e12.meta), type: 2 });
            });
            var n10 = cu(r10);
            t10.push(co(n10.length)), t10.push(n10), a10.forEach(function(e12) {
              return t10.push(e12);
            });
          }), cn(t10);
        }
        function cg(e10) {
          Array.isArray(e10) && (e10 = new Uint8Array(e10));
          for (var t10 = [], r10 = 0; r10 < e10.length; ) {
            var a10 = e10[r10++], n10 = e10[r10] | e10[r10 + 1] << 8 | e10[r10 + 2] << 16;
            r10 += 3, t10.push.apply(
              t10,
              (function(e11, t11) {
                if (0 != e11) throw Error("Unexpected Snappy chunk type ".concat(e11));
                for (var r11 = { l: 0 }, a11 = ci(t11, r11), n11 = [], s10 = r11.l; s10 < t11.length; ) {
                  var i10 = 3 & t11[s10];
                  if (0 == i10) {
                    var o10 = t11[s10++] >> 2;
                    if (o10 < 60) ++o10;
                    else {
                      var c10 = o10 - 59;
                      o10 = t11[s10], c10 > 1 && (o10 |= t11[s10 + 1] << 8), c10 > 2 && (o10 |= t11[s10 + 2] << 16), c10 > 3 && (o10 |= t11[s10 + 3] << 24), o10 >>>= 0, o10++, s10 += c10;
                    }
                    n11.push(t11[ce](s10, s10 + o10)), s10 += o10;
                    continue;
                  }
                  var l2 = 0, f2 = 0;
                  if (1 == i10 ? (f2 = (t11[s10] >> 2 & 7) + 4, l2 = (224 & t11[s10++]) << 3 | t11[s10++]) : (f2 = (t11[s10++] >> 2) + 1, 2 == i10 ? (l2 = t11[s10] | t11[s10 + 1] << 8, s10 += 2) : (l2 = (t11[s10] | t11[s10 + 1] << 8 | t11[s10 + 2] << 16 | t11[s10 + 3] << 24) >>> 0, s10 += 4)), 0 == l2)
                    throw Error("Invalid offset 0");
                  for (var h2 = n11.length - 1, u2 = l2; h2 >= 0 && u2 >= n11[h2].length; ) u2 -= n11[h2].length, --h2;
                  if (h2 < 0)
                    if (0 == u2) u2 = n11[h2 = 0].length;
                    else throw Error("Invalid offset beyond length");
                  if (f2 < u2) n11.push(n11[h2][ce](n11[h2].length - u2, n11[h2].length - u2 + f2));
                  else {
                    for (u2 > 0 && (n11.push(n11[h2][ce](n11[h2].length - u2)), f2 -= u2), ++h2; f2 >= n11[h2].length; )
                      n11.push(n11[h2]), f2 -= n11[h2].length, ++h2;
                    f2 && n11.push(n11[h2][ce](0, f2));
                  }
                  n11.length > 25 && (n11 = [cn(n11)]);
                }
                for (var d2 = 0, p2 = 0; p2 < n11.length; ++p2) d2 += n11[p2].length;
                if (d2 != a11) throw Error("Unexpected length: ".concat(d2, " != ").concat(a11));
                return n11;
              })(a10, e10[ce](r10, r10 + n10))
            ), r10 += n10;
          }
          if (r10 !== e10.length) throw Error("data is not a valid framed stream!");
          return 1 == t10.length ? t10[0] : cn(t10);
        }
        function cv(e10) {
          for (var t10 = [], r10 = 0; r10 < e10.length; ) {
            var a10 = Math.min(e10.length - r10, 268435455), n10 = new Uint8Array(4);
            t10.push(n10);
            var s10 = co(a10), i10 = s10.length;
            t10.push(s10), a10 <= 60 ? (i10++, t10.push(new Uint8Array([a10 - 1 << 2]))) : a10 <= 256 ? (i10 += 2, t10.push(new Uint8Array([240, a10 - 1 & 255]))) : a10 <= 65536 ? (i10 += 3, t10.push(new Uint8Array([244, a10 - 1 & 255, a10 - 1 >> 8 & 255]))) : a10 <= 16777216 ? (i10 += 4, t10.push(new Uint8Array([248, a10 - 1 & 255, a10 - 1 >> 8 & 255, a10 - 1 >> 16 & 255]))) : a10 <= 4294967296 && (i10 += 5, t10.push(
              new Uint8Array([
                252,
                a10 - 1 & 255,
                a10 - 1 >> 8 & 255,
                a10 - 1 >> 16 & 255,
                a10 - 1 >>> 24 & 255
              ])
            )), t10.push(e10[ce](r10, r10 + a10)), i10 += a10, n10[0] = 0, n10[1] = 255 & i10, n10[2] = i10 >> 8 & 255, n10[3] = i10 >> 16 & 255, r10 += a10;
          }
          return cn(t10);
        }
        function cb(e10, t10, r10, a10, n10) {
          var s10, i10, o10, c10, l2 = t10 >> 8, f2 = l2 >= 5 ? n10 : a10;
          o: if (r10 & (l2 > 4 ? 8 : 4) && "n" == e10.t && 7 == (255 & t10)) {
            var h2 = (null == (s10 = f2[7]) ? void 0 : s10[0]) ? cf(f2[7][0].data) : -1;
            if (-1 == h2) break o;
            var u2 = (null == (i10 = f2[15]) ? void 0 : i10[0]) ? cf(f2[15][0].data) : -1, d2 = (null == (o10 = f2[16]) ? void 0 : o10[0]) ? cf(f2[16][0].data) : -1, p2 = (null == (c10 = f2[40]) ? void 0 : c10[0]) ? cf(f2[40][0].data) : -1, m2 = e10.v, g2 = m2;
            c: if (p2) {
              if (0 == m2) {
                u2 = d2 = 2;
                break c;
              }
              u2 = m2 >= 604800 ? 1 : m2 >= 86400 ? 2 : m2 >= 3600 ? 4 : m2 >= 60 ? 8 : m2 >= 1 ? 16 : 32, Math.floor(m2) != m2 ? d2 = 32 : m2 % 60 ? d2 = 16 : m2 % 3600 ? d2 = 8 : m2 % 86400 ? d2 = 4 : m2 % 604800 && (d2 = 2), d2 < u2 && (d2 = u2);
            }
            if (-1 == u2 || -1 == d2) break o;
            var v2 = [], b2 = [];
            1 == u2 && (g2 = m2 / 604800, 1 == d2 ? b2.push('d"d"') : (g2 |= 0, m2 -= 604800 * g2), v2.push(g2 + (2 == h2 ? " week" + (1 == g2 ? "" : "s") : 1 == h2 ? "w" : ""))), u2 <= 2 && d2 >= 2 && (g2 = m2 / 86400, d2 > 2 && (g2 |= 0, m2 -= 86400 * g2), b2.push('d"d"'), v2.push(g2 + (2 == h2 ? " day" + (1 == g2 ? "" : "s") : 1 == h2 ? "d" : ""))), u2 <= 4 && d2 >= 4 && (g2 = m2 / 3600, d2 > 4 && (g2 |= 0, m2 -= 3600 * g2), b2.push((u2 >= 4 ? "[h]" : "h") + '"h"'), v2.push(g2 + (2 == h2 ? " hour" + (1 == g2 ? "" : "s") : 1 == h2 ? "h" : ""))), u2 <= 8 && d2 >= 8 && (g2 = m2 / 60, d2 > 8 && (g2 |= 0, m2 -= 60 * g2), b2.push((u2 >= 8 ? "[m]" : "m") + '"m"'), 0 == h2 ? v2.push((8 == u2 && 8 == d2 || g2 >= 10 ? "" : "0") + g2) : v2.push(g2 + (2 == h2 ? " minute" + (1 == g2 ? "" : "s") : 1 == h2 ? "m" : ""))), u2 <= 16 && d2 >= 16 && (g2 = m2, d2 > 16 && (g2 |= 0, m2 -= g2), b2.push((u2 >= 16 ? "[s]" : "s") + '"s"'), 0 == h2 ? v2.push((16 == d2 && 16 == u2 || g2 >= 10 ? "" : "0") + g2) : v2.push(g2 + (2 == h2 ? " second" + (1 == g2 ? "" : "s") : 1 == h2 ? "s" : ""))), d2 >= 32 && (g2 = Math.round(1e3 * m2), u2 < 32 && b2.push('.000"ms"'), 0 == h2 ? v2.push((g2 >= 100 ? "" : g2 >= 10 ? "0" : "00") + g2) : v2.push(g2 + (2 == h2 ? " millisecond" + (1 == g2 ? "" : "s") : 1 == h2 ? "ms" : ""))), e10.w = v2.join(0 == h2 ? ":" : " "), e10.z = b2.join(0 == h2 ? '":"' : " "), 0 == h2 && (e10.w = e10.w.replace(/:(\d\d\d)$/, ".$1"));
          }
        }
        function cw(e10, t10) {
          var r10 = new Uint8Array(32), a10 = ct(r10), n10 = 12, s10 = 0;
          switch (r10[0] = 5, e10.t) {
            case "n":
              e10.z && eQ(e10.z) ? (r10[1] = 5, a10.setFloat64(n10, (td(e10.v + 1462).getTime() - Date.UTC(2001, 0, 1)) / 1e3, true), s10 |= 4, n10 += 8) : (r10[1] = 2, (function(e11, t11, r11) {
                var a11 = Math.floor(0 == r11 ? 0 : Math.LOG10E * Math.log(Math.abs(r11))) + 6176 - 16, n11 = r11 / Math.pow(10, a11 - 6176);
                e11[t11 + 15] |= a11 >> 7, e11[t11 + 14] |= (127 & a11) << 1;
                for (var s11 = 0; n11 >= 1; ++s11, n11 /= 256) e11[t11 + s11] = 255 & n11;
                e11[t11 + 15] |= r11 >= 0 ? 0 : 128;
              })(r10, n10, e10.v), s10 |= 1, n10 += 16);
              break;
            case "b":
              r10[1] = 6, a10.setFloat64(n10, +!!e10.v, true), s10 |= 2, n10 += 8;
              break;
            case "s":
              var i10 = null == e10.v ? "" : String(e10.v);
              if (e10.l) {
                var o10 = t10.rsst.findIndex(function(t11) {
                  var r11;
                  return t11.v == i10 && t11.l == (null == (r11 = e10.l) ? void 0 : r11.Target);
                });
                -1 == o10 && (t10.rsst[o10 = t10.rsst.length] = { v: i10, l: e10.l.Target }), r10[1] = 9, a10.setUint32(n10, o10, true), s10 |= 16, n10 += 4;
              } else {
                var c10 = t10.sst.indexOf(i10);
                -1 == c10 && (t10.sst[c10 = t10.sst.length] = i10), r10[1] = 3, a10.setUint32(n10, c10, true), s10 |= 8, n10 += 4;
              }
              break;
            case "d":
              r10[1] = 5, a10.setFloat64(n10, (e10.v.getTime() - Date.UTC(2001, 0, 1)) / 1e3, true), s10 |= 4, n10 += 8;
              break;
            case "z":
              r10[1] = 0;
              break;
            default:
              throw "unsupported cell type " + e10.t;
          }
          return e10.c && (t10.cmnt.push(
            (function(e11) {
              for (var t11 = { a: "", t: "", replies: [] }, r11 = 0; r11 < e11.length; ++r11)
                0 == r11 ? (t11.a = e11[r11].a, t11.t = e11[r11].t) : t11.replies.push({ a: e11[r11].a, t: e11[r11].t });
              return t11;
            })(e10.c)
          ), a10.setUint32(n10, t10.cmnt.length - 1, true), s10 |= 524288, n10 += 4), a10.setUint32(8, s10, true), r10[ce](0, n10);
        }
        function cT(e10, t10) {
          var r10 = new Uint8Array(32), a10 = ct(r10), n10 = 12, s10 = 0, i10 = "";
          switch (r10[0] = 4, e10.t) {
            case "n":
            case "b":
            case "d":
            case "e":
            case "z":
              break;
            case "s":
              if (i10 = null == e10.v ? "" : String(e10.v), e10.l) {
                var o10 = t10.rsst.findIndex(function(t11) {
                  var r11;
                  return t11.v == i10 && t11.l == (null == (r11 = e10.l) ? void 0 : r11.Target);
                });
                -1 == o10 && (t10.rsst[o10 = t10.rsst.length] = { v: i10, l: e10.l.Target }), r10[1] = 9, a10.setUint32(n10, o10, true), s10 |= 512, n10 += 4;
              }
              break;
            default:
              throw "unsupported cell type " + e10.t;
          }
          switch (e10.c && (a10.setUint32(n10, t10.cmnt.length - 1, true), s10 |= 4096, n10 += 4), e10.t) {
            case "n":
              r10[1] = 2, a10.setFloat64(n10, e10.v, true), s10 |= 32, n10 += 8;
              break;
            case "b":
              r10[1] = 6, a10.setFloat64(n10, +!!e10.v, true), s10 |= 32, n10 += 8;
              break;
            case "s":
              if (i10 = null == e10.v ? "" : String(e10.v), e10.l) ;
              else {
                var c10 = t10.sst.indexOf(i10);
                -1 == c10 && (t10.sst[c10 = t10.sst.length] = i10), r10[1] = 3, a10.setUint32(n10, c10, true), s10 |= 16, n10 += 4;
              }
              break;
            case "d":
              r10[1] = 5, a10.setFloat64(n10, (e10.v.getTime() - Date.UTC(2001, 0, 1)) / 1e3, true), s10 |= 64, n10 += 8;
              break;
            case "z":
              r10[1] = 0;
              break;
            default:
              throw "unsupported cell type " + e10.t;
          }
          return a10.setUint32(8, s10, true), r10[ce](0, n10);
        }
        function cy(e10) {
          return cf(ch(e10)[1][0].data);
        }
        function cE(e10) {
          return cu([[], [{ type: 0, data: co(e10) }]]);
        }
        function ck(e10, t10) {
          var r10, a10 = (null == (r10 = e10.messages[0].meta[5]) ? void 0 : r10[0]) ? cc(e10.messages[0].meta[5][0].data) : [];
          -1 == a10.indexOf(t10) && (a10.push(t10), e10.messages[0].meta[5] = [{ type: 2, data: cl(a10) }]);
        }
        function cx(e10, t10) {
          var r10, a10 = (null == (r10 = e10.messages[0].meta[5]) ? void 0 : r10[0]) ? cc(e10.messages[0].meta[5][0].data) : [];
          e10.messages[0].meta[5] = [
            {
              type: 2,
              data: cl(
                a10.filter(function(e11) {
                  return e11 != t10;
                })
              )
            }
          ];
        }
        function c_(e10, t10) {
          var r10 = ch(t10.data), a10 = cf(r10[1][0].data), n10 = r10[3], s10 = [];
          return (n10 || []).forEach(function(t11) {
            var r11, n11, i10 = ch(t11.data);
            if (i10[1]) {
              var o10 = cf(i10[1][0].data) >>> 0;
              switch (a10) {
                case 1:
                  s10[o10] = cr(i10[3][0].data);
                  break;
                case 8:
                  var c10 = ch(e10[cy(i10[9][0].data)][0].data), l2 = e10[cy(c10[1][0].data)][0], f2 = cf(l2.meta[1][0].data);
                  if (2001 != f2) throw Error("2000 unexpected reference to ".concat(f2));
                  var h2 = ch(l2.data), u2 = {
                    v: h2[3].map(function(e11) {
                      return cr(e11.data);
                    }).join("")
                  };
                  s10[o10] = u2;
                  l: if (null == (r11 = null == h2 ? void 0 : h2[11]) ? void 0 : r11[0]) {
                    var d2 = null == (n11 = ch(h2[11][0].data)) ? void 0 : n11[1];
                    if (!d2) break l;
                    d2.forEach(function(t12) {
                      var r12, a11, n12, s11 = ch(t12.data);
                      if (null == (r12 = s11[2]) ? void 0 : r12[0]) {
                        var i11 = e10[cy(null == (a11 = s11[2]) ? void 0 : a11[0].data)][0], o11 = cf(i11.meta[1][0].data);
                        switch (o11) {
                          case 2032:
                            var c11 = ch(i11.data);
                            (null == (n12 = null == c11 ? void 0 : c11[2]) ? void 0 : n12[0]) && !u2.l && (u2.l = cr(c11[2][0].data));
                            break;
                          case 2039:
                            break;
                          default:
                            console.log("unrecognized ObjectAttribute type ".concat(o11));
                        }
                      }
                    });
                  }
                  break;
                case 2:
                  s10[o10] = ch(i10[6][0].data);
                  break;
                case 3:
                  s10[o10] = ch(i10[5][0].data);
                  break;
                case 10:
                  var p2 = e10[cy(i10[10][0].data)][0];
                  s10[o10] = (function e11(t12, r12) {
                    var a11, n12, s11, i11, o11, c11, l3, f3, h3, u3, d3 = { t: "", a: "" }, p3 = ch(r12);
                    if ((null == (n12 = null == (a11 = null == p3 ? void 0 : p3[1]) ? void 0 : a11[0]) ? void 0 : n12.data) && (d3.t = cr(
                      null == (i11 = null == (s11 = null == p3 ? void 0 : p3[1]) ? void 0 : s11[0]) ? void 0 : i11.data
                    ) || ""), null == (c11 = null == (o11 = null == p3 ? void 0 : p3[3]) ? void 0 : o11[0]) ? void 0 : c11.data) {
                      var m2 = ch(
                        t12[cy(
                          null == (f3 = null == (l3 = null == p3 ? void 0 : p3[3]) ? void 0 : l3[0]) ? void 0 : f3.data
                        )][0].data
                      );
                      (null == (u3 = null == (h3 = m2[1]) ? void 0 : h3[0]) ? void 0 : u3.data) && (d3.a = cr(m2[1][0].data));
                    }
                    return (null == p3 ? void 0 : p3[4]) && (d3.replies = [], p3[4].forEach(function(r13) {
                      var a12 = t12[cy(r13.data)][0];
                      d3.replies.push(e11(t12, a12.data));
                    })), d3;
                  })(e10, p2.data);
                  break;
                default:
                  throw a10;
              }
            }
          }), s10;
        }
        function cS(e10, t10) {
          var r10, a10, n10, s10, i10, o10, c10, l2 = {}, f2 = [];
          if (e10.FullPaths.forEach(function(e11) {
            if (e11.match(/\.iwpv2/)) throw Error("Unsupported password protection");
          }), e10.FileIndex.forEach(function(e11) {
            var t11, r11;
            if (e11.name.match(/\.iwa$/) && 0 == e11.content[0]) {
              try {
                t11 = cg(e11.content);
              } catch (t12) {
                return console.log("?? " + e11.content.length + " " + (t12.message || t12));
              }
              try {
                r11 = cp(t11);
              } catch (e12) {
                return console.log("## " + (e12.message || e12));
              }
              r11.forEach(function(e12) {
                l2[e12.id] = e12.messages, f2.push(e12.id);
              });
            }
          }), !f2.length)
            throw Error("File has no messages");
          if ((null == (n10 = null == (a10 = null == (r10 = null == l2 ? void 0 : l2[1]) ? void 0 : r10[0].meta) ? void 0 : a10[1]) ? void 0 : n10[0].data) && 1e4 == cf(l2[1][0].meta[1][0].data))
            throw Error("Pages documents are not supported");
          var h2 = (null == (c10 = null == (o10 = null == (i10 = null == (s10 = null == l2 ? void 0 : l2[1]) ? void 0 : s10[0]) ? void 0 : i10.meta) ? void 0 : o10[1]) ? void 0 : c10[0].data) && 1 == cf(l2[1][0].meta[1][0].data) && l2[1][0];
          if (h2 || f2.forEach(function(e11) {
            l2[e11].forEach(function(e12) {
              if (1 == cf(e12.meta[1][0].data) >>> 0)
                if (h2) throw Error("Document has multiple roots");
                else h2 = e12;
            });
          }), !h2)
            throw Error("Cannot find Document root");
          var u2, d2 = h2, p2 = c9();
          p2.Workbook = { WBProps: { date1904: true } };
          var m2 = ch(d2.data);
          if (null == (u2 = m2[2]) ? void 0 : u2[0]) throw Error("Keynote presentations are not supported");
          if (cd(m2[1], cy).forEach(function(e11) {
            l2[e11].forEach(function(e12) {
              if (2 == cf(e12.meta[1][0].data)) {
                var r11, a11, n11, s11 = (n11 = {
                  name: (null == (r11 = (a11 = ch(e12.data))[1]) ? void 0 : r11[0]) ? cr(a11[1][0].data) : "",
                  sheets: []
                }, cd(a11[2], cy).forEach(function(e13) {
                  l2[e13].forEach(function(e14) {
                    6e3 == cf(e14.meta[1][0].data) && n11.sheets.push(
                      (function(e15, t11, r12) {
                        var a12 = ch(t11.data), n12 = { "!ref": "A1" };
                        (null == r12 ? void 0 : r12.dense) && (n12["!data"] = []);
                        var s12 = e15[cy(a12[2][0].data)], i11 = cf(s12[0].meta[1][0].data);
                        if (6001 != i11) throw Error("6000 unexpected reference to ".concat(i11));
                        return !(function(e16, t12, r13, a13) {
                          var n13, s13, i12, o11, c11, l3, f3, h3, u3, d3, p3, m3, g2, v2, b2 = ch(t12.data), w2 = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
                          if (w2.e.r = (cf(b2[6][0].data) >>> 0) - 1, w2.e.r < 0)
                            throw Error("Invalid row varint ".concat(b2[6][0].data));
                          if (w2.e.c = (cf(b2[7][0].data) >>> 0) - 1, w2.e.c < 0)
                            throw Error("Invalid col varint ".concat(b2[7][0].data));
                          r13["!ref"] = aT(w2);
                          var T2 = null != r13["!data"], y2 = ch(b2[4][0].data), E2 = { sst: [], rsst: [], ofmt: [], nfmt: [], fmla: [], ferr: [], cmnt: [] };
                          (null == (n13 = y2[4]) ? void 0 : n13[0]) && (E2.sst = c_(e16, e16[cy(y2[4][0].data)][0])), (null == (s13 = y2[6]) ? void 0 : s13[0]) && (E2.fmla = c_(e16, e16[cy(y2[6][0].data)][0])), (null == (i12 = y2[11]) ? void 0 : i12[0]) && (E2.ofmt = c_(e16, e16[cy(y2[11][0].data)][0])), (null == (o11 = y2[12]) ? void 0 : o11[0]) && (E2.ferr = c_(e16, e16[cy(y2[12][0].data)][0])), (null == (c11 = y2[17]) ? void 0 : c11[0]) && (E2.rsst = c_(e16, e16[cy(y2[17][0].data)][0])), (null == (l3 = y2[19]) ? void 0 : l3[0]) && (E2.cmnt = c_(e16, e16[cy(y2[19][0].data)][0])), (null == (f3 = y2[22]) ? void 0 : f3[0]) && (E2.nfmt = c_(e16, e16[cy(y2[22][0].data)][0]));
                          var k2 = ch(y2[3][0].data), x2 = 0;
                          if (!(null == (h3 = y2[9]) ? void 0 : h3[0])) throw "NUMBERS file missing row tree";
                          if (ch(y2[9][0].data)[1].map(function(e17) {
                            return ch(e17.data);
                          }).forEach(function(t13) {
                            x2 = cf(t13[1][0].data);
                            var n14, s14, i13, o12, c12 = cf(t13[2][0].data), l4 = k2[1][c12];
                            if (!l4) throw "NUMBERS missing tile " + c12;
                            var f4 = e16[cy(ch(l4.data)[2][0].data)][0], h4 = cf(f4.meta[1][0].data);
                            if (6002 != h4) throw Error("6001 unexpected reference to ".concat(h4));
                            var u4 = (s14 = ch(f4.data), i13 = -1, (null == (n14 = null == s14 ? void 0 : s14[7]) ? void 0 : n14[0]) && (i13 = cf(s14[7][0].data) >>> 0 ? 1 : 0), o12 = cd(s14[5], function(e17) {
                              return (function(e18, t14) {
                                var r14, a14, n15, s15, i14, o13, c13, l5, f5, h5, u5, d4, p4, m4, g3, v3, b3 = ch(e18), w3 = cf(b3[1][0].data) >>> 0, T3 = cf(b3[2][0].data) >>> 0, y3 = (null == (a14 = null == (r14 = b3[8]) ? void 0 : r14[0]) ? void 0 : a14.data) && cf(b3[8][0].data) > 0 || false;
                                if ((null == (s15 = null == (n15 = b3[7]) ? void 0 : n15[0]) ? void 0 : s15.data) && 0 != t14)
                                  g3 = null == (o13 = null == (i14 = b3[7]) ? void 0 : i14[0]) ? void 0 : o13.data, v3 = null == (l5 = null == (c13 = b3[6]) ? void 0 : c13[0]) ? void 0 : l5.data;
                                else if ((null == (h5 = null == (f5 = b3[4]) ? void 0 : f5[0]) ? void 0 : h5.data) && 1 != t14)
                                  g3 = null == (d4 = null == (u5 = b3[4]) ? void 0 : u5[0]) ? void 0 : d4.data, v3 = null == (m4 = null == (p4 = b3[3]) ? void 0 : p4[0]) ? void 0 : m4.data;
                                else throw "NUMBERS Tile missing ".concat(t14, " cell storage");
                                for (var E3 = y3 ? 4 : 1, k3 = ct(g3), x3 = [], _3 = 0; _3 < g3.length / 2; ++_3) {
                                  var S3 = k3.getUint16(2 * _3, true);
                                  S3 < 65535 && x3.push([_3, S3]);
                                }
                                if (x3.length != T3)
                                  throw "Expected ".concat(T3, " cells, found ").concat(x3.length);
                                var A3 = [];
                                for (_3 = 0; _3 < x3.length - 1; ++_3)
                                  A3[x3[_3][0]] = v3[ce](x3[_3][1] * E3, x3[_3 + 1][1] * E3);
                                return x3.length >= 1 && (A3[x3[x3.length - 1][0]] = v3[ce](x3[x3.length - 1][1] * E3)), { R: w3, cells: A3 };
                              })(e17, i13);
                            }), {
                              nrows: cf(s14[4][0].data) >>> 0,
                              data: o12.reduce(function(e17, t14) {
                                return e17[t14.R] || (e17[t14.R] = []), t14.cells.forEach(function(r14, a14) {
                                  if (e17[t14.R][a14])
                                    throw Error("Duplicate cell r=".concat(t14.R, " c=").concat(a14));
                                  e17[t14.R][a14] = r14;
                                }), e17;
                              }, [])
                            });
                            u4.data.forEach(function(e17, t14) {
                              e17.forEach(function(e18, n15) {
                                var s15 = (function(e19, t15, r14) {
                                  switch (e19[0]) {
                                    case 0:
                                    case 1:
                                    case 2:
                                    case 3:
                                    case 4:
                                      return (function(e20, t16, r15, a14) {
                                        var n16, s16 = ct(e20), i14 = s16.getUint32(4, true), o13 = -1, c13 = -1, l5 = -1, f5 = NaN, h5 = 0, u5 = new Date(Date.UTC(2001, 0, 1)), d4 = r15 > 1 ? 12 : 8;
                                        2 & i14 && (l5 = s16.getUint32(d4, true), d4 += 4), d4 += 4 * cs(i14 & (r15 > 1 ? 3468 : 396)), 512 & i14 && (o13 = s16.getUint32(d4, true), d4 += 4), d4 += 4 * cs(i14 & (r15 > 1 ? 12288 : 4096)), 16 & i14 && (c13 = s16.getUint32(d4, true), d4 += 4), 32 & i14 && (f5 = s16.getFloat64(d4, true), d4 += 8), 64 & i14 && (u5.setTime(u5.getTime() + 1e3 * (h5 = s16.getFloat64(d4, true))), d4 += 8), r15 > 1 && 255 & (i14 = s16.getUint32(8, true) >>> 16) && (-1 == l5 && (l5 = s16.getUint32(d4, true)), d4 += 4);
                                        var p4 = e20[r15 >= 4 ? 1 : 2];
                                        switch (p4) {
                                          case 0:
                                            return;
                                          case 2:
                                          case 7:
                                            n16 = { t: "n", v: f5 };
                                            break;
                                          case 3:
                                            n16 = { t: "s", v: t16.sst[c13] };
                                            break;
                                          case 5:
                                            n16 = (null == a14 ? void 0 : a14.cellDates) ? { t: "d", v: u5 } : { t: "n", v: h5 / 86400 + 35430, z: eD[14] };
                                            break;
                                          case 6:
                                            n16 = { t: "b", v: f5 > 0 };
                                            break;
                                          case 8:
                                            n16 = { t: "e", v: 0 };
                                            break;
                                          case 9:
                                            if (o13 > -1) {
                                              var m4 = t16.rsst[o13];
                                              n16 = { t: "s", v: m4.v }, m4.l && (n16.l = { Target: m4.l });
                                            } else
                                              throw Error("Unsupported cell type ".concat(e20[ce](0, 4)));
                                            break;
                                          default:
                                            throw Error("Unsupported cell type ".concat(e20[ce](0, 4)));
                                        }
                                        return l5 > -1 && cb(n16, p4 | r15 << 8, i14, t16.ofmt[l5], t16.nfmt[l5]), 7 == p4 && (n16.v /= 86400), n16;
                                      })(e19, t15, e19[0], r14);
                                    case 5:
                                      return (function(e20, t16, r15) {
                                        var a14, n16 = ct(e20);
                                        n16.getUint32(4, true);
                                        var s16 = n16.getUint32(8, true), i14 = 12, o13 = -1, c13 = -1, l5 = -1, f5 = NaN, h5 = NaN, u5 = 0, d4 = new Date(Date.UTC(2001, 0, 1));
                                        1 & s16 && (f5 = (function(e21, t17) {
                                          for (var r16 = (127 & e21[t17 + 15]) << 7 | e21[t17 + 14] >> 1, a15 = 1 & e21[t17 + 14], n17 = t17 + 13; n17 >= t17; --n17)
                                            a15 = 256 * a15 + e21[n17];
                                          return (128 & e21[t17 + 15] ? -a15 : a15) * Math.pow(10, r16 - 6176);
                                        })(e20, i14), i14 += 16), 2 & s16 && (h5 = n16.getFloat64(i14, true), i14 += 8), 4 & s16 && (d4.setTime(d4.getTime() + 1e3 * (u5 = n16.getFloat64(i14, true))), i14 += 8), 8 & s16 && (c13 = n16.getUint32(i14, true), i14 += 4), 16 & s16 && (o13 = n16.getUint32(i14, true), i14 += 4), i14 += 4 * cs(480 & s16), 512 & s16 && (n16.getUint32(i14, true), i14 += 4), i14 += 4 * cs(1024 & s16), 2048 & s16 && (n16.getUint32(i14, true), i14 += 4);
                                        var p4 = e20[1];
                                        switch (p4) {
                                          case 0:
                                            a14 = { t: "z" };
                                            break;
                                          case 2:
                                          case 10:
                                            a14 = { t: "n", v: f5 };
                                            break;
                                          case 3:
                                            a14 = { t: "s", v: t16.sst[c13] };
                                            break;
                                          case 5:
                                            a14 = (null == r15 ? void 0 : r15.cellDates) ? { t: "d", v: d4 } : { t: "n", v: u5 / 86400 + 35430, z: eD[14] };
                                            break;
                                          case 6:
                                            a14 = { t: "b", v: h5 > 0 };
                                            break;
                                          case 7:
                                            a14 = { t: "n", v: h5 };
                                            break;
                                          case 8:
                                            a14 = { t: "e", v: 0 };
                                            break;
                                          case 9:
                                            if (o13 > -1) {
                                              var m4 = t16.rsst[o13];
                                              a14 = { t: "s", v: m4.v }, m4.l && (a14.l = { Target: m4.l });
                                            } else
                                              throw Error(
                                                "Unsupported cell type ".concat(e20[1], " : ").concat(31 & s16, " : ").concat(e20[ce](0, 4))
                                              );
                                            break;
                                          default:
                                            throw Error(
                                              "Unsupported cell type ".concat(e20[1], " : ").concat(31 & s16, " : ").concat(e20[ce](0, 4))
                                            );
                                        }
                                        if (i14 += 4 * cs(4096 & s16), 516096 & s16 && (-1 == l5 && (l5 = n16.getUint32(i14, true)), i14 += 4), 524288 & s16) {
                                          var g3, v3, b3 = n16.getUint32(i14, true);
                                          i14 += 4, t16.cmnt[b3] && (a14.c = (g3 = t16.cmnt[b3], (v3 = []).push({
                                            t: g3.t || "",
                                            a: g3.a,
                                            T: g3.replies && g3.replies.length > 0
                                          }), g3.replies && g3.replies.forEach(function(e21) {
                                            v3.push({ t: e21.t || "", a: e21.a, T: true });
                                          }), v3));
                                        }
                                        return l5 > -1 && cb(a14, 1280 | p4, s16 >> 13, t16.ofmt[l5], t16.nfmt[l5]), 7 == p4 && (a14.v /= 86400), a14;
                                      })(e19, t15, r14);
                                    default:
                                      throw Error("Unsupported payload version ".concat(e19[0]));
                                  }
                                })(e18, E2, a13);
                                s15 && (T2 ? (r13["!data"][x2 + t14] || (r13["!data"][x2 + t14] = []), r13["!data"][x2 + t14][n15] = s15) : r13[ag(n15) + ap(x2 + t14)] = s15);
                              });
                            }), x2 += u4.nrows;
                          }), null == (u3 = y2[13]) ? void 0 : u3[0]) {
                            var _2 = e16[cy(y2[13][0].data)][0], S2 = cf(_2.meta[1][0].data);
                            if (6144 != S2) throw Error("Expected merge type 6144, found ".concat(S2));
                            r13["!merges"] = null == (d3 = ch(_2.data)) ? void 0 : d3[1].map(function(e17) {
                              var t13 = ch(e17.data), r14 = ct(ch(t13[1][0].data)[1][0].data), a14 = ct(ch(t13[2][0].data)[1][0].data);
                              return {
                                s: { r: r14.getUint16(0, true), c: r14.getUint16(2, true) },
                                e: {
                                  r: r14.getUint16(0, true) + a14.getUint16(0, true) - 1,
                                  c: r14.getUint16(2, true) + a14.getUint16(2, true) - 1
                                }
                              };
                            });
                          }
                          if (!(null == (p3 = r13["!merges"]) ? void 0 : p3.length) && (null == (m3 = b2[47]) ? void 0 : m3[0])) {
                            var A2 = ch(b2[47][0].data);
                            if (null == (g2 = A2[2]) ? void 0 : g2[0]) {
                              var C2 = ch(A2[2][0].data);
                              (null == (v2 = C2[3]) ? void 0 : v2[0]) && (r13["!merges"] = cd(C2[3], function(e17) {
                                var t13, r14, a14, n14, s14, i13 = ch(e17), o12 = ch(i13[2][0].data), c12 = ch(o12[1][0].data);
                                if (null == (t13 = c12[1]) ? void 0 : t13[0]) {
                                  var l4 = ch(c12[1][0].data);
                                  if (67 == cf(l4[1][0].data)) {
                                    var f4 = ch(l4[40][0].data);
                                    if ((null == (r14 = f4[3]) ? void 0 : r14[0]) && (null == (a14 = f4[4]) ? void 0 : a14[0])) {
                                      var h4 = ch(f4[3][0].data), u4 = ch(f4[4][0].data), d4 = cf(h4[1][0].data), p4 = (null == (n14 = h4[2]) ? void 0 : n14[0]) ? cf(h4[2][0].data) : d4, m4 = cf(u4[1][0].data), g3 = (null == (s14 = u4[2]) ? void 0 : s14[0]) ? cf(u4[2][0].data) : m4;
                                      return { s: { r: m4, c: d4 }, e: { r: g3, c: p4 } };
                                    }
                                  }
                                }
                              }).filter(function(e17) {
                                return null != e17;
                              }));
                            }
                          }
                        })(e15, s12[0], n12, r12), n12;
                      })(l2, e14, t10)
                    );
                  });
                }), n11);
                s11.sheets.forEach(function(e13, t11) {
                  le(p2, e13, 0 == t11 ? s11.name : s11.name + "_" + t11, true);
                });
              }
            });
          }), 0 == p2.SheetNames.length)
            throw Error("Empty NUMBERS file");
          return p2.bookType = "numbers", p2;
        }
        function cA(e10, t10) {
          return { meta: [[], [{ type: 0, data: co(e10) }]], data: t10 };
        }
        function cC(e10, t10) {
          t10.last || (t10.last = 927262);
          for (var r10 = t10.last; r10 < 2e6; ++r10) if (!t10[r10]) return t10[t10.last = r10] = e10, r10;
          throw Error("Too many messages");
        }
        function cI(e10, t10, r10) {
          return cu([
            [],
            [{ type: 0, data: co(1) }],
            [],
            [{ type: 5, data: new Uint8Array(Float32Array.from([e10 / 255]).buffer) }],
            [{ type: 5, data: new Uint8Array(Float32Array.from([t10 / 255]).buffer) }],
            [{ type: 5, data: new Uint8Array(Float32Array.from([r10 / 255]).buffer) }],
            [{ type: 5, data: new Uint8Array(Float32Array.from([1]).buffer) }],
            [],
            [],
            [],
            [],
            [],
            [{ type: 0, data: co(1) }]
          ]);
        }
        function cO(e10) {
          switch (e10) {
            case 0:
              return cI(99, 222, 171);
            case 1:
              return cI(162, 197, 240);
            case 2:
              return cI(255, 189, 189);
          }
          return cI(255 * Math.random(), 255 * Math.random(), 255 * Math.random());
        }
        function cR(e10, t10, r10, a10) {
          var n10 = tr.find(e10, t10[r10].location);
          if (!n10) throw "Could not find ".concat(t10[r10].location, " in Numbers template");
          var s10 = cp(cg(n10.content));
          a10(
            s10.find(function(e11) {
              return e11.id == r10;
            }),
            s10
          ), n10.content = cv(cm(s10)), n10.size = n10.content.length;
        }
        function cN(e10, t10, r10) {
          var a10 = tr.find(e10, t10[r10].location);
          if (!a10) throw "Could not find ".concat(t10[r10].location, " in Numbers template");
          return cp(cg(a10.content)).find(function(e11) {
            return e11.id == r10;
          });
        }
        function cF(e10, t10, r10) {
          e10[3].push({
            type: 2,
            data: cu([
              [],
              [{ type: 0, data: co(t10) }],
              [{ type: 2, data: ca(r10.replace(/-[\s\S]*$/, "")) }],
              [{ type: 2, data: ca(r10) }],
              [{ type: 2, data: new Uint8Array([2, 0, 0]) }],
              [{ type: 2, data: new Uint8Array([2, 0, 0]) }],
              [],
              [],
              [],
              [],
              [{ type: 0, data: co(0) }],
              [],
              [{ type: 0, data: co(0) }]
            ])
          }), e10[1] = [{ type: 0, data: co(Math.max(t10 + 1, cf(e10[1][0].data))) }];
        }
        function cD(e10, t10, r10, a10, n10, s10) {
          s10 || (s10 = cC({ deps: [], location: "", type: t10 }, n10));
          var i10 = "".concat(a10, "-").concat(s10, ".iwa");
          n10[s10].location = "Root Entry" + i10, tr.utils.cfb_add(e10, i10, cv(cm([{ id: s10, messages: [cA(t10, cu(r10))] }])));
          var o10 = i10.replace(/^[\/]/, "").replace(/^Index\//, "").replace(/\.iwa$/, "");
          return cR(e10, n10, 2, function(e11) {
            var t11 = ch(e11.messages[0].data);
            cF(t11, s10 || 0, o10), e11.messages[0].data = cu(t11);
          }), s10;
        }
        function cP(e10, t10, r10, a10) {
          var n10 = t10[r10].location.replace(/^Root Entry\//, "").replace(/^Index\//, "").replace(/\.iwa$/, ""), s10 = e10[3].findIndex(function(e11) {
            var t11, r11, a11 = ch(e11.data);
            return (null == (t11 = a11[3]) ? void 0 : t11[0]) ? cr(a11[3][0].data) == n10 : null != (r11 = a11[2]) && !!r11[0] && cr(a11[2][0].data) == n10;
          }), i10 = ch(e10[3][s10].data);
          i10[6] || (i10[6] = []), (Array.isArray(a10) ? a10 : [a10]).forEach(function(e11) {
            i10[6].push({ type: 2, data: cu([[], [{ type: 0, data: co(e11) }]]) });
          }), e10[3][s10].data = cu(i10);
        }
        function cL(e10) {
          return function(t10) {
            for (var r10 = 0; r10 != e10.length; ++r10) {
              var a10 = e10[r10];
              void 0 === t10[a10[0]] && (t10[a10[0]] = a10[1]), "n" === a10[2] && (t10[a10[0]] = Number(t10[a10[0]]));
            }
          };
        }
        function cM(e10) {
          cL([
            ["cellNF", false],
            ["cellHTML", true],
            ["cellFormula", true],
            ["cellStyles", false],
            ["cellText", true],
            ["cellDates", false],
            ["sheetStubs", false],
            ["sheetRows", 0, "n"],
            ["bookDeps", false],
            ["bookSheets", false],
            ["bookProps", false],
            ["bookFiles", false],
            ["bookVBA", false],
            ["password", ""],
            ["WTF", false]
          ])(e10);
        }
        function cU(e10) {
          cL([
            ["cellDates", false],
            ["bookSST", false],
            ["bookType", "xlsx"],
            ["compression", false],
            ["WTF", false]
          ])(e10);
        }
        function cB(e10) {
          return "/" == e10.charAt(0) ? e10.slice(1) : e10;
        }
        function cW(e10, t10) {
          if (e5(), cM(t10 = t10 || {}), tH(e10, "META-INF/manifest.xml") || tH(e10, "objectdata.xml")) {
            var r10 = e10, n10 = t10;
            n10 = n10 || {}, tH(r10, "META-INF/manifest.xml") && (function(e11, t11) {
              for (var r11, a10, n11 = ry(e11); r11 = rE.exec(n11); )
                switch (r11[3]) {
                  case "manifest":
                    break;
                  case "file-entry":
                    if ("/" == (a10 = t4(r11[0], false)).path && "application/vnd.oasis.opendocument.spreadsheet" !== a10.type)
                      throw Error("This OpenDocument is not a spreadsheet");
                    break;
                  case "encryption-data":
                  case "algorithm":
                  case "start-key-generation":
                  case "key-derivation":
                    throw Error("Unsupported ODS Encryption");
                  default:
                    if (t11 && t11.WTF) throw r11;
                }
            })(t$(r10, "META-INF/manifest.xml"), n10);
            var s10 = tG(r10, "styles.xml"), i10 = s10 && o3(rf(s10), n10), o10 = tG(r10, "content.xml");
            if (!o10) throw Error("Missing content.xml in ODS / UOF file");
            var c10 = o5(rf(o10), n10, i10);
            return tH(r10, "meta.xml") && (c10.Props = ny(t$(r10, "meta.xml"))), c10.bookType = "ods", c10;
          }
          if (tH(e10, "Index/Document.iwa")) {
            if ("undefined" == typeof Uint8Array) throw Error("NUMBERS file parsing requires Uint8Array support");
            if (e10.FileIndex) return cS(e10, t10);
            var l2, f2, h2, u2, d2, p2, m2, g2, v2, b2, w2, T2, y2 = tr.utils.cfb_new();
            return tX(e10).forEach(function(t11) {
              tj(
                y2,
                t11,
                (function e11(t12, r11, a10) {
                  if (!a10) return tz(tV(t12, r11));
                  if (!r11) return null;
                  try {
                    return e11(t12, r11);
                  } catch (e12) {
                    return null;
                  }
                })(e10, t11)
              );
            }), cS(y2, t10);
          }
          if (!tH(e10, "[Content_Types].xml")) {
            if (tH(e10, "index.xml.gz")) throw Error("Unsupported NUMBERS 08 file");
            if (tH(e10, "index.xml")) throw Error("Unsupported NUMBERS 09 file");
            var E2 = tr.find(e10, "Index.zip");
            if (E2)
              return (t10 = tw(t10), delete t10.type, "string" == typeof E2.content && (t10.type = "binary"), "undefined" != typeof Bun && a.isBuffer(E2.content)) ? cG(new Uint8Array(E2.content), t10) : cG(E2.content, t10);
            throw Error("Unsupported ZIP file");
          }
          var k2 = tX(e10), x2 = (function(e11) {
            var t11 = a3();
            if (!e11 || !e11.match) return t11;
            var r11 = {};
            if ((e11.match(t0) || []).forEach(function(e12) {
              var a10 = t4(e12);
              switch (a10[0].replace(t1, "<")) {
                case "<?xml":
                  break;
                case "<Types":
                  t11.xmlns = a10["xmlns" + (a10[0].match(/<(\w+):/) || ["", ""])[1]];
                  break;
                case "<Default":
                  r11[a10.Extension.toLowerCase()] = a10.ContentType;
                  break;
                case "<Override":
                  void 0 !== t11[a2[a10.ContentType]] && t11[a2[a10.ContentType]].push(a10.PartName);
              }
            }), t11.xmlns !== rk)
              throw Error("Unknown Namespace: " + t11.xmlns);
            return t11.calcchain = t11.calcchains.length > 0 ? t11.calcchains[0] : "", t11.sst = t11.strs.length > 0 ? t11.strs[0] : "", t11.style = t11.styles.length > 0 ? t11.styles[0] : "", t11.defaults = r11, delete t11.calcchains, t11;
          })(tG(e10, "[Content_Types].xml")), _2 = false;
          if (0 === x2.workbooks.length && t$(e10, b2 = "xl/workbook.xml", true) && x2.workbooks.push(b2), 0 === x2.workbooks.length) {
            if (!t$(e10, b2 = "xl/workbook.bin", true)) throw Error("Could not find workbook");
            x2.workbooks.push(b2), _2 = true;
          }
          "bin" == x2.workbooks[0].slice(-3) && (_2 = true);
          var S2 = {}, A2 = {};
          if (!t10.bookSheets && !t10.bookProps) {
            if (iY = [], x2.sst)
              try {
                iY = (function(e11, t11, r11) {
                  if (".bin" === t11.slice(-4)) {
                    var a10, n11;
                    return a10 = [], n11 = false, ai(e11, function(e12, t12, s11) {
                      switch (s11) {
                        case 159:
                          a10.Count = e12[0], a10.Unique = e12[1];
                          break;
                        case 19:
                          a10.push(e12);
                          break;
                        case 160:
                          return true;
                        case 35:
                          n11 = true;
                          break;
                        case 36:
                          n11 = false;
                          break;
                        default:
                          if (t12.T, !n11 || r11.WTF) throw Error("Unexpected record 0x" + s11.toString(16));
                      }
                    }), a10;
                  }
                  return (function(e12, t12) {
                    var r12 = [], a11 = "";
                    if (!e12) return r12;
                    var n12 = tL(e12, "sst");
                    if (n12) {
                      a11 = n12[1].replace(sF, "").split(sD);
                      for (var s11 = 0; s11 != a11.length; ++s11) {
                        var i11 = sN(a11[s11].trim(), t12);
                        null != i11 && (r12[r12.length] = i11);
                      }
                      r12.Count = (n12 = t4(n12[0].slice(0, n12[0].indexOf(">")))).count, r12.Unique = n12.uniqueCount;
                    }
                    return r12;
                  })(e11, r11);
                })(t$(e10, cB(x2.sst)), x2.sst, t10);
              } catch (e11) {
                if (t10.WTF) throw e11;
              }
            t10.cellStyles && x2.themes.length && (S2 = ir(tG(e10, x2.themes[0].replace(/^\//, ""), true) || "", t10)), x2.style && (A2 = (function(e11, t11, r11, a10) {
              if (".bin" === t11.slice(-4)) {
                var n11 = {};
                for (var s11 in n11.NumberFmt = [], eD) n11.NumberFmt[s11] = eD[s11];
                n11.CellXf = [], n11.Fonts = [];
                var i11 = [], o11 = false;
                return ai(e11, function(e12, t12, s12) {
                  switch (s12) {
                    case 44:
                      n11.NumberFmt[e12[0]] = e12[1], te(e12[1], e12[0]);
                      break;
                    case 43:
                      n11.Fonts.push(e12), null != e12.color.theme && r11 && r11.themeElements && r11.themeElements.clrScheme && (e12.color.rgb = sj(r11.themeElements.clrScheme[e12.color.theme].rgb, e12.color.tint || 0));
                      break;
                    case 1025:
                    case 45:
                    case 46:
                    case 48:
                    case 507:
                    case 572:
                    case 475:
                    case 1171:
                    case 2102:
                    case 1130:
                    case 512:
                    case 2095:
                    case 3072:
                      break;
                    case 47:
                      617 == i11[i11.length - 1] && n11.CellXf.push(e12);
                      break;
                    case 35:
                      o11 = true;
                      break;
                    case 36:
                      o11 = false;
                      break;
                    case 37:
                      i11.push(s12), o11 = true;
                      break;
                    case 38:
                      i11.pop(), o11 = false;
                      break;
                    default:
                      if (t12.T > 0) i11.push(s12);
                      else if (t12.T < 0) i11.pop();
                      else if (!o11 || a10.WTF && 37 != i11[i11.length - 1])
                        throw Error("Unexpected record 0x" + s12.toString(16));
                  }
                }), n11;
              }
              return s6(e11, r11, a10);
            })(t$(e10, cB(x2.style)), x2.style, S2, t10));
          }
          x2.links.map(function(r11) {
            try {
              nm(tG(e10, np(cB(r11))), r11);
              var a10 = t$(e10, cB(r11)), n11 = r11, s11 = t10;
              if (".bin" === n11.slice(-4)) {
                if (!a10) return a10;
                var i11 = s11 || {}, o11 = false;
                return void ai(
                  a10,
                  function(e11, t11, r12) {
                    switch (r12) {
                      case 359:
                      case 363:
                      case 364:
                      case 366:
                      case 367:
                      case 368:
                      case 369:
                      case 370:
                      case 371:
                      case 472:
                      case 577:
                      case 578:
                      case 579:
                      case 580:
                      case 581:
                      case 582:
                      case 583:
                      case 584:
                      case 585:
                      case 586:
                      case 587:
                        break;
                      case 35:
                        o11 = true;
                        break;
                      case 36:
                        o11 = false;
                        break;
                      default:
                        if (t11.T) ;
                        else if (!o11 || i11.WTF) throw Error("Unexpected record 0x" + r12.toString(16));
                    }
                  },
                  i11
                );
              }
              return;
            } catch (e11) {
            }
          });
          var C2 = (function(e11, t11, r11) {
            if (".bin" === t11.slice(-4)) {
              var a10, n11, s11, i11, o11, c11;
              return n11 = { AppVersion: {}, WBProps: {}, WBView: [], Sheets: [], CalcPr: {}, xmlns: "" }, s11 = [], i11 = false, (a10 = r11) || (a10 = {}), a10.biff = 12, o11 = [], (c11 = [[]]).SheetNames = [], c11.XTI = [], oz[16] = { n: "BrtFRTArchID$", f: oT }, ai(
                e11,
                function(e12, t12, r12) {
                  switch (r12) {
                    case 156:
                      c11.SheetNames.push(e12.name), n11.Sheets.push(e12);
                      break;
                    case 153:
                      n11.WBProps = e12;
                      break;
                    case 39:
                      null != e12.Sheet && (a10.SID = e12.Sheet), e12.Ref = e12.Ptg ? iU(e12.Ptg, null, null, c11, a10) : "#REF!", delete a10.SID, delete e12.Ptg, o11.push(e12);
                      break;
                    case 1036:
                    case 361:
                    case 2071:
                    case 158:
                    case 143:
                    case 664:
                    case 353:
                    case 3072:
                    case 3073:
                    case 534:
                    case 677:
                    case 157:
                    case 610:
                    case 2050:
                    case 155:
                    case 548:
                    case 676:
                    case 128:
                    case 665:
                    case 2128:
                    case 2125:
                    case 549:
                    case 2053:
                    case 596:
                    case 2076:
                    case 2075:
                    case 2082:
                    case 397:
                    case 154:
                    case 1117:
                    case 553:
                    case 2091:
                    case 16:
                      break;
                    case 357:
                    case 358:
                    case 355:
                    case 667:
                      c11[0].length ? c11.push([r12, e12]) : c11[0] = [r12, e12], c11[c11.length - 1].XTI = [];
                      break;
                    case 362:
                      0 === c11.length && (c11[0] = [], c11[0].XTI = []), c11[c11.length - 1].XTI = c11[c11.length - 1].XTI.concat(e12), c11.XTI = c11.XTI.concat(e12);
                      break;
                    case 35:
                    case 37:
                      s11.push(r12), i11 = true;
                      break;
                    case 36:
                    case 38:
                      s11.pop(), i11 = false;
                      break;
                    default:
                      if (t12.T) ;
                      else if (!i11 || a10.WTF && 37 != s11[s11.length - 1] && 35 != s11[s11.length - 1])
                        throw Error("Unexpected record 0x" + r12.toString(16));
                  }
                },
                a10
              ), om(n11), n11.Names = o11, n11.supbooks = c11, n11;
            }
            return (function(e12, t12) {
              if (!e12) throw Error("Could not find file");
              var r12 = { AppVersion: {}, WBProps: {}, WBView: [], Sheets: [], CalcPr: {}, Names: [], xmlns: "" }, a11 = false, n12 = "xmlns", s12 = {}, i12 = 0;
              if (e12.replace(t0, function(o12, c12) {
                var l3 = t4(o12);
                switch (t3(l3[0])) {
                  case "<?xml":
                  case "</workbook>":
                  case "<fileVersion/>":
                  case "</fileVersion>":
                  case "<fileSharing":
                  case "<fileSharing/>":
                  case "</workbookPr>":
                  case "<workbookProtection":
                  case "<workbookProtection/>":
                  case "<bookViews":
                  case "<bookViews>":
                  case "</bookViews>":
                  case "</workbookView>":
                  case "<sheets":
                  case "<sheets>":
                  case "</sheets>":
                  case "</sheet>":
                  case "<functionGroups":
                  case "<functionGroups/>":
                  case "<functionGroup":
                  case "<externalReferences":
                  case "</externalReferences>":
                  case "<externalReferences>":
                  case "<externalReference":
                  case "<definedNames/>":
                  case "<definedName/>":
                  case "</calcPr>":
                  case "<oleSize":
                  case "<customWorkbookViews>":
                  case "</customWorkbookViews>":
                  case "<customWorkbookViews":
                  case "<customWorkbookView":
                  case "</customWorkbookView>":
                  case "<pivotCaches>":
                  case "</pivotCaches>":
                  case "<pivotCaches":
                  case "<pivotCache":
                  case "<smartTagPr":
                  case "<smartTagPr/>":
                  case "<smartTagTypes":
                  case "<smartTagTypes>":
                  case "</smartTagTypes>":
                  case "<smartTagType":
                  case "<webPublishing":
                  case "<webPublishing/>":
                  case "<fileRecoveryPr":
                  case "<fileRecoveryPr/>":
                  case "<webPublishObjects>":
                  case "<webPublishObjects":
                  case "</webPublishObjects>":
                  case "<webPublishObject":
                  case "<extLst":
                  case "<extLst>":
                  case "</extLst>":
                  case "<extLst/>":
                  case "<ArchID":
                  case "<revisionPtr":
                    break;
                  case "<workbook":
                    o12.match(ow) && (n12 = "xmlns" + o12.match(/<(\w+):/)[1]), r12.xmlns = l3[n12];
                    break;
                  case "<fileVersion":
                    delete l3[0], r12.AppVersion = l3;
                    break;
                  case "<workbookPr":
                  case "<workbookPr/>":
                    ol.forEach(function(e13) {
                      if (null != l3[e13[0]])
                        switch (e13[2]) {
                          case "bool":
                            r12.WBProps[e13[0]] = rs(l3[e13[0]]);
                            break;
                          case "int":
                            r12.WBProps[e13[0]] = parseInt(l3[e13[0]], 10);
                            break;
                          default:
                            r12.WBProps[e13[0]] = l3[e13[0]];
                        }
                    }), l3.codeName && (r12.WBProps.CodeName = rf(l3.codeName));
                    break;
                  case "<workbookView":
                  case "<workbookView/>":
                    delete l3[0], r12.WBView.push(l3);
                    break;
                  case "<sheet":
                    switch (l3.state) {
                      case "hidden":
                        l3.Hidden = 1;
                        break;
                      case "veryHidden":
                        l3.Hidden = 2;
                        break;
                      default:
                        l3.Hidden = 0;
                    }
                    delete l3.state, l3.name = t8(rf(l3.name)), delete l3[0], r12.Sheets.push(l3);
                    break;
                  case "<definedNames>":
                  case "<definedNames":
                  case "<ext":
                  case "<AlternateContent":
                  case "<AlternateContent>":
                    a11 = true;
                    break;
                  case "</definedNames>":
                  case "</ext>":
                  case "</AlternateContent>":
                    a11 = false;
                    break;
                  case "<definedName":
                    (s12 = {}).Name = rf(l3.name), l3.comment && (s12.Comment = l3.comment), l3.localSheetId && (s12.Sheet = +l3.localSheetId), rs(l3.hidden || "0") && (s12.Hidden = true), i12 = c12 + o12.length;
                    break;
                  case "</definedName>":
                    s12.Ref = t8(rf(e12.slice(i12, c12))), r12.Names.push(s12);
                    break;
                  case "<calcPr":
                  case "<calcPr/>":
                    delete l3[0], r12.CalcPr = l3;
                    break;
                  default:
                    if (!a11 && t12.WTF) throw Error("unrecognized " + l3[0] + " in workbook");
                }
                return o12;
              }), -1 === rC.indexOf(r12.xmlns))
                throw Error("Unknown Namespace: " + r12.xmlns);
              return om(r12), r12;
            })(e11, r11);
          })(t$(e10, cB(x2.workbooks[0])), x2.workbooks[0], t10), I2 = {}, O2 = "";
          x2.coreprops.length && ((O2 = t$(e10, cB(x2.coreprops[0]), true)) && (I2 = ny(O2)), 0 !== x2.extprops.length) && (O2 = t$(e10, cB(x2.extprops[0]), true)) && (l2 = O2, f2 = I2, h2 = t10, u2 = {}, f2 || (f2 = {}), l2 = rf(l2), nx.forEach(function(e11) {
            var t11 = (tL(l2, e11[0]) || [])[1];
            switch (e11[2]) {
              case "string":
                t11 && (f2[e11[1]] = t8(t11));
                break;
              case "bool":
                f2[e11[1]] = "true" === t11;
                break;
              case "raw":
                var r11 = tP(l2, e11[0]);
                r11 && r11.length > 0 && (u2[e11[1]] = r11[1]);
            }
          }), u2.HeadingPairs && u2.TitlesOfParts && nS(u2.HeadingPairs, u2.TitlesOfParts, f2, h2));
          var R2 = {};
          (!t10.bookSheets || t10.bookProps) && 0 !== x2.custprops.length && (O2 = tG(e10, cB(x2.custprops[0]), true)) && (R2 = (function(e11, t11) {
            var r11 = {}, a10 = "", n11 = e11.match(nC);
            if (n11)
              for (var s11 = 0; s11 != n11.length; ++s11) {
                var i11 = n11[s11], o11 = t4(i11);
                switch (t3(o11[0])) {
                  case "<?xml":
                  case "<Properties":
                    break;
                  case "<property":
                    a10 = t8(o11.name);
                    break;
                  case "</property>":
                    a10 = null;
                    break;
                  default:
                    if (0 === i11.indexOf("<vt:")) {
                      var c11 = i11.split(">"), l3 = c11[0].slice(4), f3 = c11[1];
                      switch (l3) {
                        case "lpstr":
                        case "bstr":
                        case "lpwstr":
                        case "cy":
                        case "error":
                          r11[a10] = t8(f3);
                          break;
                        case "bool":
                          r11[a10] = rs(f3);
                          break;
                        case "i1":
                        case "i2":
                        case "i4":
                        case "i8":
                        case "int":
                        case "uint":
                          r11[a10] = parseInt(f3, 10);
                          break;
                        case "r4":
                        case "r8":
                        case "decimal":
                          r11[a10] = parseFloat(f3);
                          break;
                        case "filetime":
                        case "date":
                          r11[a10] = tv(f3);
                          break;
                        default:
                          if ("/" == l3.slice(-1)) break;
                          t11.WTF && "undefined" != typeof console && console.warn("Unexpected", i11, l3, c11);
                      }
                    } else if ("</" === i11.slice(0, 2)) ;
                    else if (t11.WTF) throw Error(i11);
                }
              }
            return r11;
          })(O2, t10));
          var N2 = {};
          if ((t10.bookSheets || t10.bookProps) && (C2.Sheets ? v2 = C2.Sheets.map(function(e11) {
            return e11.name;
          }) : I2.Worksheets && I2.SheetNames.length > 0 && (v2 = I2.SheetNames), t10.bookProps && (N2.Props = I2, N2.Custprops = R2), t10.bookSheets && void 0 !== v2 && (N2.SheetNames = v2), t10.bookSheets ? N2.SheetNames : t10.bookProps))
            return N2;
          v2 = {};
          var F2 = {};
          t10.bookDeps && x2.calcchain && (F2 = (function(e11, t11, r11) {
            if (".bin" === t11.slice(-4)) {
              var a10;
              return a10 = [], ai(e11, function(e12, t12, r12) {
                if (63 === r12) a10.push(e12);
                else if (t12.T) ;
                else if (1) throw Error("Unexpected record 0x" + r12.toString(16));
              }), a10;
            }
            var n11 = [];
            if (!e11) return n11;
            var s11 = 1;
            return (e11.match(t0) || []).forEach(function(e12) {
              var t12 = t4(e12);
              switch (t12[0]) {
                case "<?xml":
                case "<calcChain":
                case "<calcChain>":
                case "</calcChain>":
                  break;
                case "<c":
                  delete t12[0], t12.i ? s11 = t12.i : t12.i = s11, n11.push(t12);
              }
            }), n11;
          })(t$(e10, cB(x2.calcchain)), x2.calcchain, t10));
          var D2 = 0, P2 = {}, L2 = C2.Sheets;
          I2.Worksheets = L2.length, I2.SheetNames = [];
          for (var M2 = 0; M2 != L2.length; ++M2) I2.SheetNames[M2] = L2[M2].name;
          var U2 = _2 ? "bin" : "xml", B2 = x2.workbooks[0].lastIndexOf("/"), W2 = (x2.workbooks[0].slice(0, B2 + 1) + "_rels/" + x2.workbooks[0].slice(B2 + 1) + ".rels").replace(
            /^\//,
            ""
          );
          tH(e10, W2) || (W2 = "xl/_rels/workbook." + U2 + ".rels");
          var z2 = nm(tG(e10, W2, true), W2.replace(/_rels.*/, "s5s"));
          (x2.metadata || []).length >= 1 && (t10.xlmeta = (function(e11, t11, r11) {
            if (".bin" === t11.slice(-4)) {
              var a10, n11, s11, i11, o11;
              return a10 = { Types: [], Cell: [], Value: [] }, n11 = r11 || {}, s11 = [], i11 = false, o11 = 2, ai(e11, function(e12, t12, r12) {
                switch (r12) {
                  case 335:
                    a10.Types.push({ name: e12.name });
                    break;
                  case 51:
                    e12.forEach(function(e13) {
                      1 == o11 ? a10.Cell.push({ type: a10.Types[e13[0] - 1].name, index: e13[1] }) : 0 == o11 && a10.Value.push({ type: a10.Types[e13[0] - 1].name, index: e13[1] });
                    });
                    break;
                  case 337:
                    o11 = +!!e12;
                    break;
                  case 338:
                    o11 = 2;
                    break;
                  case 35:
                    s11.push(r12), i11 = true;
                    break;
                  case 36:
                    s11.pop(), i11 = false;
                    break;
                  default:
                    if (t12.T) ;
                    else if (!i11 || n11.WTF && 35 != s11[s11.length - 1])
                      throw Error("Unexpected record 0x" + r12.toString(16));
                }
              }), a10;
            }
            var c11, l3 = { Types: [], Cell: [], Value: [] };
            if (!e11) return l3;
            var f3 = false, h3 = 2;
            return e11.replace(t0, function(e12) {
              var t12 = t4(e12);
              switch (t3(t12[0])) {
                case "<?xml":
                case "<metadata":
                case "</metadata>":
                case "<metadataTypes":
                case "</metadataTypes>":
                case "</metadataType>":
                case "</futureMetadata>":
                case "<bk>":
                case "</bk>":
                case "</rc>":
                case "<extLst":
                case "<extLst>":
                case "</extLst>":
                case "<extLst/>":
                  break;
                case "<metadataType":
                  l3.Types.push({ name: t12.name });
                  break;
                case "<futureMetadata":
                  for (var a11 = 0; a11 < l3.Types.length; ++a11) l3.Types[a11].name == t12.name && (c11 = l3.Types[a11]);
                  break;
                case "<rc":
                  1 == h3 ? l3.Cell.push({ type: l3.Types[t12.t - 1].name, index: +t12.v }) : 0 == h3 && l3.Value.push({ type: l3.Types[t12.t - 1].name, index: +t12.v });
                  break;
                case "<cellMetadata":
                  h3 = 1;
                  break;
                case "</cellMetadata>":
                case "</valueMetadata>":
                  h3 = 2;
                  break;
                case "<valueMetadata":
                  h3 = 0;
                  break;
                case "<ext":
                  f3 = true;
                  break;
                case "</ext>":
                  f3 = false;
                  break;
                case "<rvb":
                  if (!c11) break;
                  c11.offsets || (c11.offsets = []), c11.offsets.push(+t12.i);
                  break;
                default:
                  if (!f3 && (null == r11 ? void 0 : r11.WTF)) throw Error("unrecognized " + t12[0] + " in metadata");
              }
              return e12;
            }), l3;
          })(t$(e10, cB(x2.metadata[0])), x2.metadata[0], t10)), (x2.people || []).length >= 1 && (t10.people = (d2 = t$(e10, cB(x2.people[0])), p2 = t10, m2 = [], g2 = false, d2.replace(t0, function(e11) {
            var t11 = t4(e11);
            switch (t3(t11[0])) {
              case "<?xml":
              case "<personList":
              case "</personList>":
              case "</person>":
              case "<extLst":
              case "<extLst>":
              case "</extLst>":
              case "<extLst/>":
                break;
              case "<person":
                m2.push({ name: t11.displayname, id: t11.id });
                break;
              case "<ext":
                g2 = true;
                break;
              case "</ext>":
                g2 = false;
                break;
              default:
                if (!g2 && p2.WTF) throw Error("unrecognized " + t11[0] + " in threaded comments");
            }
            return e11;
          }), m2)), z2 && (z2 = (function(e11, t11) {
            if (!e11) return 0;
            try {
              e11 = t11.map(function(t12) {
                var r11;
                return t12.id || (t12.id = t12.strRelID), [
                  t12.name,
                  e11["!id"][t12.id].Target,
                  (r11 = e11["!id"][t12.id].Type, no.indexOf(r11) > -1 ? "sheet" : ni && r11 == ni ? "chart" : nc && r11 == nc ? "dialog" : nl && r11 == nl ? "macro" : r11 && r11.length ? r11 : "sheet")
                ];
              });
            } catch (e12) {
              return null;
            }
            return e11 && 0 !== e11.length ? e11 : null;
          })(z2, C2.Sheets));
          var H2 = +!!t$(e10, "xl/worksheets/sheet.xml", true);
          for (D2 = 0; D2 != I2.Worksheets; ++D2) {
            var V2 = "sheet";
            if (z2 && z2[D2] ? (tH(e10, w2 = "xl/" + z2[D2][1].replace(/[\/]?xl\//, "")) || (w2 = z2[D2][1]), tH(e10, w2) || (w2 = W2.replace(/_rels\/[\S\s]*$/, "") + z2[D2][1]), V2 = z2[D2][2]) : w2 = (w2 = "xl/worksheets/sheet" + (D2 + 1 - H2) + "." + U2).replace(/sheet0\./, "sheet."), T2 = w2.replace(/^(.*)(\/)([^\/]*)$/, "$1/_rels/$3.rels"), t10 && null != t10.sheets)
              switch (typeof t10.sheets) {
                case "number":
                  if (D2 != t10.sheets) continue;
                  break;
                case "string":
                  if (I2.SheetNames[D2].toLowerCase() != t10.sheets.toLowerCase()) continue;
                  break;
                default:
                  if (Array.isArray && Array.isArray(t10.sheets)) {
                    for (var G2 = false, X2 = 0; X2 != t10.sheets.length; ++X2)
                      "number" == typeof t10.sheets[X2] && t10.sheets[X2] == D2 && (G2 = 1), "string" == typeof t10.sheets[X2] && t10.sheets[X2].toLowerCase() == I2.SheetNames[D2].toLowerCase() && (G2 = 1);
                    if (!G2) continue;
                  }
              }
            !(function(e11, t11, r11, a10, n11, s11, i11, o11, c11, l3, f3, h3) {
              try {
                s11[a10] = nm(tG(e11, r11, true), t11);
                var u3, d3, p3 = t$(e11, t11);
                switch (o11) {
                  case "sheet":
                    u3 = s11[a10], d3 = ".bin" === t11.slice(-4) ? (function(e12, t12, r12, a11, n12, s12, i12) {
                      if (!e12) return e12;
                      var o12, c12, l4, f4, h4, u4, d4, p4, m4, g4, v4, b4, w4 = t12 || {};
                      a11 || (a11 = { "!id": {} });
                      var T4 = {};
                      w4.dense && (T4["!data"] = []);
                      var y4 = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, E3 = [], k3 = false, x3 = false, _3 = [];
                      w4.biff = 12, w4["!row"] = 0;
                      var S3 = 0, A3 = false, C3 = [], I3 = {}, O3 = w4.supbooks || n12.supbooks || [[]];
                      if (O3.sharedf = I3, O3.arrayf = C3, O3.SheetNames = n12.SheetNames || n12.Sheets.map(function(e13) {
                        return e13.name;
                      }), !w4.supbooks && (w4.supbooks = O3, n12.Names))
                        for (var R3 = 0; R3 < n12.Names.length; ++R3) O3[0][R3 + 1] = n12.Names[R3];
                      var N3 = [], F3 = [], D3 = false;
                      oz[16] = { n: "BrtShortReal", f: oo };
                      var P3 = 1462 * !!((n12 || {}).WBProps || {}).date1904;
                      if (ai(
                        e12,
                        function(e13, t13, R4) {
                          if (!x3)
                            switch (R4) {
                              case 148:
                                o12 = e13;
                                break;
                              case 0:
                                c12 = e13, w4.sheetRows && w4.sheetRows <= c12.r && (x3 = true), m4 = ap(h4 = c12.r), w4["!row"] = c12.r, (e13.hidden || e13.hpt || null != e13.level) && (e13.hpt && (e13.hpx = s2(e13.hpt)), F3[e13.r] = e13);
                                break;
                              case 2:
                              case 3:
                              case 4:
                              case 5:
                              case 6:
                              case 7:
                              case 8:
                              case 9:
                              case 10:
                              case 11:
                              case 13:
                              case 14:
                              case 15:
                              case 16:
                              case 17:
                              case 18:
                              case 62:
                                switch (l4 = { t: e13[2] }, e13[2]) {
                                  case "n":
                                    l4.v = e13[1];
                                    break;
                                  case "s":
                                    p4 = iY[e13[1]], l4.v = p4.t, l4.r = p4.r;
                                    break;
                                  case "b":
                                    l4.v = !!e13[1];
                                    break;
                                  case "e":
                                    l4.v = e13[1], false !== w4.cellText && (l4.w = aQ[l4.v]);
                                    break;
                                  case "str":
                                    l4.t = "s", l4.v = e13[1];
                                    break;
                                  case "is":
                                    l4.t = "s", l4.v = e13[1].t;
                                }
                                if ((f4 = i12.CellXf[e13[0].iStyleRef]) && i2(l4, f4.numFmtId, null, w4, s12, i12, P3 > 0), u4 = -1 == e13[0].c ? u4 + 1 : e13[0].c, w4.dense ? (T4["!data"][h4] || (T4["!data"][h4] = []), T4["!data"][h4][u4] = l4) : T4[ag(u4) + m4] = l4, w4.cellFormula) {
                                  for (S3 = 0, A3 = false; S3 < C3.length; ++S3) {
                                    var L4 = C3[S3];
                                    c12.r >= L4[0].s.r && c12.r <= L4[0].e.r && u4 >= L4[0].s.c && u4 <= L4[0].e.c && (l4.F = aT(L4[0]), A3 = true);
                                  }
                                  !A3 && e13.length > 3 && (l4.f = e13[3]);
                                }
                                if (y4.s.r > c12.r && (y4.s.r = c12.r), y4.s.c > u4 && (y4.s.c = u4), y4.e.r < c12.r && (y4.e.r = c12.r), y4.e.c < u4 && (y4.e.c = u4), w4.cellDates && f4 && "n" == l4.t && eQ(eD[f4.numFmtId])) {
                                  var M3 = eU(l4.v + P3);
                                  M3 && (l4.t = "d", l4.v = new Date(Date.UTC(M3.y, M3.m - 1, M3.d, M3.H, M3.M, M3.S, M3.u)));
                                }
                                v4 && ("XLDAPR" == v4.type && (l4.D = true), v4 = void 0), b4 && (b4 = void 0);
                                break;
                              case 1:
                              case 12:
                                if (!w4.sheetStubs || k3) break;
                                l4 = { t: "z", v: void 0 }, u4 = -1 == e13[0].c ? u4 + 1 : e13[0].c, w4.dense ? (T4["!data"][h4] || (T4["!data"][h4] = []), T4["!data"][h4][u4] = l4) : T4[ag(u4) + m4] = l4, y4.s.r > c12.r && (y4.s.r = c12.r), y4.s.c > u4 && (y4.s.c = u4), y4.e.r < c12.r && (y4.e.r = c12.r), y4.e.c < u4 && (y4.e.c = u4), v4 && ("XLDAPR" == v4.type && (l4.D = true), v4 = void 0), b4 && (b4 = void 0);
                                break;
                              case 176:
                                _3.push(e13);
                                break;
                              case 49:
                                v4 = ((w4.xlmeta || {}).Cell || [])[e13 - 1];
                                break;
                              case 494:
                                var U3 = a11["!id"][e13.relId];
                                for (U3 ? (e13.Target = U3.Target, e13.loc && (e13.Target += "#" + e13.loc), e13.Rel = U3) : "" == e13.relId && (e13.Target = "#" + e13.loc), h4 = e13.rfx.s.r; h4 <= e13.rfx.e.r; ++h4)
                                  for (u4 = e13.rfx.s.c; u4 <= e13.rfx.e.c; ++u4)
                                    w4.dense ? (T4["!data"][h4] || (T4["!data"][h4] = []), T4["!data"][h4][u4] || (T4["!data"][h4][u4] = { t: "z", v: void 0 }), T4["!data"][h4][u4].l = e13) : (T4[d4 = ag(u4) + ap(h4)] || (T4[d4] = { t: "z", v: void 0 }), T4[d4].l = e13);
                                break;
                              case 426:
                                if (!w4.cellFormula) break;
                                C3.push(e13), (g4 = w4.dense ? T4["!data"][h4][u4] : T4[ag(u4) + m4]).f = iU(
                                  e13[1],
                                  y4,
                                  { r: c12.r, c: u4 },
                                  O3,
                                  w4
                                ), g4.F = aT(e13[0]);
                                break;
                              case 427:
                                if (!w4.cellFormula) break;
                                I3[ab(e13[0].s)] = e13[1], (g4 = w4.dense ? T4["!data"][h4][u4] : T4[ag(u4) + m4]).f = iU(
                                  e13[1],
                                  y4,
                                  { r: c12.r, c: u4 },
                                  O3,
                                  w4
                                );
                                break;
                              case 60:
                                if (!w4.cellStyles) break;
                                for (; e13.e >= e13.s; )
                                  N3[e13.e--] = {
                                    width: e13.w / 256,
                                    hidden: !!(1 & e13.flags),
                                    level: e13.level
                                  }, D3 || (D3 = true, sQ(e13.w / 256)), s0(N3[e13.e + 1]);
                                break;
                              case 551:
                                e13 && (T4["!legrel"] = e13);
                                break;
                              case 161:
                                T4["!autofilter"] = { ref: aT(e13) };
                                break;
                              case 476:
                                T4["!margins"] = e13;
                                break;
                              case 147:
                                n12.Sheets[r12] || (n12.Sheets[r12] = {}), e13.name && (n12.Sheets[r12].CodeName = e13.name), (e13.above || e13.left) && (T4["!outline"] = { above: e13.above, left: e13.left });
                                break;
                              case 137:
                                n12.Views || (n12.Views = [{}]), n12.Views[0] || (n12.Views[0] = {}), e13.RTL && (n12.Views[0].RTL = true);
                                break;
                              case 485:
                              case 64:
                              case 1053:
                              case 151:
                              case 152:
                              case 175:
                              case 644:
                              case 625:
                              case 562:
                              case 396:
                              case 1112:
                              case 1146:
                              case 471:
                              case 1050:
                              case 649:
                              case 1105:
                              case 589:
                              case 607:
                              case 564:
                              case 1055:
                              case 168:
                              case 174:
                              case 1180:
                              case 499:
                              case 507:
                              case 550:
                              case 171:
                              case 167:
                              case 1177:
                              case 169:
                              case 1181:
                              case 552:
                              case 661:
                              case 639:
                              case 478:
                              case 537:
                              case 477:
                              case 536:
                              case 1103:
                              case 680:
                              case 1104:
                              case 1024:
                              case 663:
                              case 535:
                              case 678:
                              case 504:
                              case 1043:
                              case 428:
                              case 170:
                              case 3072:
                              case 50:
                              case 2070:
                              case 1045:
                                break;
                              case 35:
                                k3 = true;
                                break;
                              case 36:
                                k3 = false;
                                break;
                              case 37:
                                E3.push(R4), k3 = true;
                                break;
                              case 38:
                                E3.pop(), k3 = false;
                                break;
                              default:
                                if (t13.T) ;
                                else if (!k3 || w4.WTF) throw Error("Unexpected record 0x" + R4.toString(16));
                            }
                        },
                        w4
                      ), delete w4.supbooks, delete w4["!row"], !T4["!ref"] && (y4.s.r < 2e6 || o12 && (o12.e.r > 0 || o12.e.c > 0 || o12.s.r > 0 || o12.s.c > 0)) && (T4["!ref"] = aT(o12 || y4)), w4.sheetRows && T4["!ref"]) {
                        var L3 = ak(T4["!ref"]);
                        w4.sheetRows <= +L3.e.r && (L3.e.r = w4.sheetRows - 1, L3.e.r > y4.e.r && (L3.e.r = y4.e.r), L3.e.r < L3.s.r && (L3.s.r = L3.e.r), L3.e.c > y4.e.c && (L3.e.c = y4.e.c), L3.e.c < L3.s.c && (L3.s.c = L3.e.c), T4["!fullref"] = T4["!ref"], T4["!ref"] = aT(L3));
                      }
                      return _3.length > 0 && (T4["!merges"] = _3), N3.length > 0 && (T4["!cols"] = N3), F3.length > 0 && (T4["!rows"] = F3), a11["!id"][T4["!legrel"]] && (T4["!legdrawel"] = a11["!id"][T4["!legrel"]]), T4;
                    })(p3, c11, n11, u3, l3, f3, h3) : (function(e12, t12, r12, a11, n12, s12, i12) {
                      if (!e12) return e12;
                      a11 || (a11 = { "!id": {} });
                      var o12, c12 = {};
                      t12.dense && (c12["!data"] = []);
                      var l4 = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } }, f4 = "", h4 = "", u4 = tL(e12, "sheetData");
                      u4 ? (f4 = e12.slice(0, u4.index), h4 = e12.slice(u4.index + u4[0].length)) : f4 = h4 = e12;
                      var d4 = f4.match(i9);
                      d4 ? oe(d4[0], c12, n12, r12) : (d4 = tL(f4, "sheetPr")) && (m4 = d4[0], g4 = d4[1], v4 = c12, b4 = n12, w4 = r12, oe(m4.slice(0, m4.indexOf(">")), v4, b4, w4));
                      var p4 = (f4.match(/<(?:\w*:)?dimension/) || { index: -1 }).index;
                      if (p4 > 0) {
                        var m4, g4, v4, b4, w4, T4, y4 = f4.slice(p4, p4 + 50).match(i5);
                        y4 && !(t12 && t12.nodim) && (T4 = ak(y4[1])).s.r <= T4.e.r && T4.s.c <= T4.e.c && T4.s.r >= 0 && T4.s.c >= 0 && (c12["!ref"] = aT(T4));
                      }
                      var E3 = tL(f4, "sheetViews");
                      E3 && E3[1] && (function(e13, t13) {
                        t13.Views || (t13.Views = [{}]), (e13.match(oa) || []).forEach(function(e14, r13) {
                          var a12 = t4(e14);
                          t13.Views[r13] || (t13.Views[r13] = {}), +a12.zoomScale && (t13.Views[r13].zoom = +a12.zoomScale), a12.rightToLeft && rs(a12.rightToLeft) && (t13.Views[r13].RTL = true);
                        });
                      })(E3[1], n12);
                      var k3 = [];
                      if (t12.cellStyles) {
                        var x3 = f4.match(i6);
                        x3 && (function(e13, t13) {
                          for (var r13 = false, a12 = 0; a12 != t13.length; ++a12) {
                            var n13 = t4(t13[a12], true);
                            n13.hidden && (n13.hidden = rs(n13.hidden));
                            var s13 = parseInt(n13.min, 10) - 1, i13 = parseInt(n13.max, 10) - 1;
                            for (n13.outlineLevel && (n13.level = +n13.outlineLevel || 0), delete n13.min, delete n13.max, n13.width = +n13.width, !r13 && n13.width && (r13 = true, sQ(n13.width)), s0(n13); s13 <= i13; )
                              e13[s13++] = tw(n13);
                          }
                        })(k3, x3);
                      }
                      u4 && on(u4[1], c12, t12, l4, s12, i12, n12);
                      var _3 = h4.match(i8);
                      _3 && (c12["!autofilter"] = { ref: (_3[0].match(/ref="([^"]*)"/) || [])[1] });
                      var S3 = [], A3 = h4.match(i4);
                      if (A3) for (p4 = 0; p4 != A3.length; ++p4) S3[p4] = ak(A3[p4].slice(A3[p4].indexOf("=") + 2));
                      var C3 = h4.match(i3);
                      C3 && (function(e13, t13, r13) {
                        for (var a12 = null != e13["!data"], n13 = 0; n13 != t13.length; ++n13) {
                          var s13 = t4(rf(t13[n13]), true);
                          if (!s13.ref) return;
                          var i13 = ((r13 || {})["!id"] || [])[s13.id];
                          i13 ? (s13.Target = i13.Target, s13.location && (s13.Target += "#" + t8(s13.location))) : (s13.Target = "#" + t8(s13.location), i13 = { Target: s13.Target, TargetMode: "Internal" }), s13.Rel = i13, s13.tooltip && (s13.Tooltip = s13.tooltip, delete s13.tooltip);
                          for (var o13 = ak(s13.ref), c13 = o13.s.r; c13 <= o13.e.r; ++c13)
                            for (var l5 = o13.s.c; l5 <= o13.e.c; ++l5) {
                              var f5 = ag(l5) + ap(c13);
                              a12 ? (e13["!data"][c13] || (e13["!data"][c13] = []), e13["!data"][c13][l5] || (e13["!data"][c13][l5] = { t: "z", v: void 0 }), e13["!data"][c13][l5].l = s13) : (e13[f5] || (e13[f5] = { t: "z", v: void 0 }), e13[f5].l = s13);
                            }
                        }
                      })(c12, C3, a11);
                      var I3 = h4.match(i7);
                      if (I3 && (c12["!margins"] = (function(e13) {
                        var t13 = {};
                        return ["left", "right", "top", "bottom", "header", "footer"].forEach(function(r13) {
                          e13[r13] && (t13[r13] = parseFloat(e13[r13]));
                        }), t13;
                      })(t4(I3[0]))), (o12 = h4.match(/legacyDrawing r:id="(.*?)"/)) && (c12["!legrel"] = o12[1]), t12 && t12.nodim && (l4.s.c = l4.s.r = 0), !c12["!ref"] && l4.e.c >= l4.s.c && l4.e.r >= l4.s.r && (c12["!ref"] = aT(l4)), t12.sheetRows > 0 && c12["!ref"]) {
                        var O3 = ak(c12["!ref"]);
                        t12.sheetRows <= +O3.e.r && (O3.e.r = t12.sheetRows - 1, O3.e.r > l4.e.r && (O3.e.r = l4.e.r), O3.e.r < O3.s.r && (O3.s.r = O3.e.r), O3.e.c > l4.e.c && (O3.e.c = l4.e.c), O3.e.c < O3.s.c && (O3.s.c = O3.e.c), c12["!fullref"] = c12["!ref"], c12["!ref"] = aT(O3));
                      }
                      return k3.length > 0 && (c12["!cols"] = k3), S3.length > 0 && (c12["!merges"] = S3), a11["!id"][c12["!legrel"]] && (c12["!legdrawel"] = a11["!id"][c12["!legrel"]]), c12;
                    })(p3, c11, n11, u3, l3, f3, h3);
                    break;
                  case "chart":
                    if (!(d3 = (function(e12, t12, r12, a11, n12, s12, i12, o12) {
                      if (".bin" === t12.slice(-4)) {
                        var c12 = n12;
                        if (!e12) return e12;
                        c12 || (c12 = { "!id": {} });
                        var l4 = { "!type": "chart", "!drawel": null, "!rel": "" }, f4 = [], h4 = false;
                        return ai(
                          e12,
                          function(e13, t13, n13) {
                            switch (n13) {
                              case 550:
                                l4["!rel"] = e13;
                                break;
                              case 651:
                                s12.Sheets[r12] || (s12.Sheets[r12] = {}), e13.name && (s12.Sheets[r12].CodeName = e13.name);
                                break;
                              case 562:
                              case 652:
                              case 669:
                              case 679:
                              case 551:
                              case 552:
                              case 476:
                              case 3072:
                                break;
                              case 35:
                                h4 = true;
                                break;
                              case 36:
                                h4 = false;
                                break;
                              case 37:
                                f4.push(n13);
                                break;
                              case 38:
                                f4.pop();
                                break;
                              default:
                                if (t13.T > 0) f4.push(n13);
                                else if (t13.T < 0) f4.pop();
                                else if (!h4 || a11.WTF) throw Error("Unexpected record 0x" + n13.toString(16));
                            }
                          },
                          a11
                        ), c12["!id"][l4["!rel"]] && (l4["!drawel"] = c12["!id"][l4["!rel"]]), l4;
                      }
                      var u4 = n12;
                      if (!e12) return e12;
                      u4 || (u4 = { "!id": {} });
                      var d4, p4 = { "!type": "chart", "!drawel": null, "!rel": "" }, m4 = e12.match(i9);
                      return m4 && oe(m4[0], p4, s12, r12), (d4 = e12.match(/drawing r:id="(.*?)"/)) && (p4["!rel"] = d4[1]), u4["!id"][p4["!rel"]] && (p4["!drawel"] = u4["!id"][p4["!rel"]]), p4;
                    })(p3, t11, n11, c11, s11[a10], l3, 0, 0)) || !d3["!drawel"])
                      break;
                    var m3 = tZ(d3["!drawel"].Target, t11), g3 = np(m3), v3 = (function(e12, t12) {
                      if (!e12) return "??";
                      var r12 = (e12.match(/<c:chart [^<>]*r:id="([^<>"]*)"/) || ["", ""])[1];
                      return t12["!id"][r12].Target;
                    })(tG(e11, m3, true), nm(tG(e11, g3, true), m3)), b3 = tZ(v3, m3), w3 = np(b3);
                    d3 = (function(e12, t12, r12, a11, n12, s12) {
                      var i12 = s12 || { "!type": "chart" };
                      if (!e12) return s12;
                      var o12 = 0, c12 = 0, l4 = "A", f4 = { s: { r: 2e6, c: 2e6 }, e: { r: 0, c: 0 } };
                      return (tN(e12, "<c:numCache>", "</c:numCache>") || []).forEach(function(e13) {
                        var t13, r13, a12, n13, s13 = (r13 = [], a12 = e13.match(/^<c:numCache>/), (e13.match(/<c:pt idx="(\d*)"[^<>\/]*><c:v>([^<])<\/c:v><\/c:pt>/gm) || []).forEach(
                          function(e14) {
                            var t14 = e14.match(/<c:pt idx="(\d*)"[^<>\/]*><c:v>([^<]*)<\/c:v><\/c:pt>/);
                            t14 && (r13[+t14[1]] = a12 ? +t14[2] : t14[2]);
                          }
                        ), n13 = t8((tP(e13, "c:formatCode") || ["", "General"])[1]), (tN(e13, "<c:f>", "</c:f>") || []).forEach(function(e14) {
                          t13 = e14.replace(/<[^<>]*>/g, "");
                        }), [r13, n13, t13]);
                        f4.s.r = f4.s.c = 0, f4.e.c = o12, l4 = ag(o12), s13[0].forEach(function(e14, t14) {
                          i12["!data"] ? (i12["!data"][t14] || (i12["!data"][t14] = []), i12["!data"][t14][o12] = { t: "n", v: e14, z: s13[1] }) : i12[l4 + ap(t14)] = { t: "n", v: e14, z: s13[1] }, c12 = t14;
                        }), f4.e.r < c12 && (f4.e.r = c12), ++o12;
                      }), o12 > 0 && (i12["!ref"] = aT(f4)), i12;
                    })(tG(e11, b3, true), 0, 0, nm(tG(e11, w3, true), b3), 0, d3);
                    break;
                  case "macro":
                    s11[a10], t11.slice(-4), d3 = { "!type": "macro" };
                    break;
                  case "dialog":
                    s11[a10], t11.slice(-4), d3 = { "!type": "dialog" };
                    break;
                  default:
                    throw Error("Unrecognized sheet type " + o11);
                }
                i11[a10] = d3;
                var T3 = [], y3 = [];
                s11 && s11[a10] && ts(s11[a10]).forEach(function(r12) {
                  var n12, i12, o12, l4, f4, h4 = "";
                  if (s11[a10][r12].Type == a9) {
                    if (h4 = tZ(s11[a10][r12].Target, t11), !(T3 = (function(e12, t12, r13) {
                      if (".bin" === t12.slice(-4)) {
                        var a11, n13, s12, i13;
                        return a11 = [], n13 = [], s12 = {}, i13 = false, ai(e12, function(e13, t13, o14) {
                          switch (o14) {
                            case 632:
                              n13.push(e13);
                              break;
                            case 635:
                              s12 = e13;
                              break;
                            case 637:
                              s12.t = e13.t, s12.h = e13.h, s12.r = e13.r;
                              break;
                            case 636:
                              if (s12.author = n13[s12.iauthor], delete s12.iauthor, r13.sheetRows && s12.rfx && r13.sheetRows <= s12.rfx.r)
                                break;
                              s12.t || (s12.t = ""), delete s12.rfx, a11.push(s12);
                              break;
                            case 3072:
                            case 37:
                            case 38:
                              break;
                            case 35:
                              i13 = true;
                              break;
                            case 36:
                              i13 = false;
                              break;
                            default:
                              if (t13.T) ;
                              else if (!i13 || r13.WTF) throw Error("Unexpected record 0x" + o14.toString(16));
                          }
                        }), a11;
                      }
                      if (e12.match(/<(?:\w+:)?comments *\/>/)) return [];
                      var o13 = [], c12 = [], l5 = tL(e12, "authors");
                      l5 && l5[1] && l5[1].split(/<\/\w*:?author>/).forEach(function(e13) {
                        if ("" !== e13 && "" !== e13.trim()) {
                          var t13 = e13.match(/<(?:\w+:)?author[^<>]*>(.*)/);
                          t13 && o13.push(t13[1]);
                        }
                      });
                      var f5 = tL(e12, "commentList");
                      return f5 && f5[1] && f5[1].split(/<\/\w*:?comment>/).forEach(function(e13) {
                        if ("" !== e13 && "" !== e13.trim()) {
                          var t13 = e13.match(/<(?:\w+:)?comment[^<>]*>/);
                          if (t13) {
                            var a12 = t4(t13[0]), n14 = {
                              author: a12.authorId && o13[a12.authorId] || "sheetjsghost",
                              ref: a12.ref,
                              guid: a12.guid
                            }, s13 = av(a12.ref);
                            if (!r13.sheetRows || !(r13.sheetRows <= s13.r)) {
                              var i14 = tL(e13, "text"), l6 = !!i14 && !!i14[1] && sN(i14[1]) || { r: "", t: "", h: "" };
                              n14.r = l6.r, "<t></t>" == l6.r && (l6.t = l6.h = ""), n14.t = (l6.t || "").replace(/\r\n/g, "\n").replace(/\r/g, "\n"), r13.cellHTML && (n14.h = l6.h), c12.push(n14);
                            }
                          }
                        }
                      }), c12;
                    })(t$(e11, h4, true), h4, c11)) || !T3.length)
                      return;
                    ii(d3, T3, false);
                  }
                  s11[a10][r12].Type == nh && (h4 = tZ(s11[a10][r12].Target, t11), y3 = y3.concat(
                    (n12 = t$(e11, h4, true), i12 = [], o12 = false, l4 = {}, f4 = 0, n12.replace(t0, function(e12, t12) {
                      var r13 = t4(e12);
                      switch (t3(r13[0])) {
                        case "<?xml":
                        case "<ThreadedComments":
                        case "</ThreadedComments>":
                        case "<extLst":
                        case "<extLst>":
                        case "</extLst>":
                        case "<extLst/>":
                          break;
                        case "<threadedComment":
                          l4 = { author: r13.personId, guid: r13.id, ref: r13.ref, T: 1 };
                          break;
                        case "</threadedComment>":
                          null != l4.t && i12.push(l4);
                          break;
                        case "<text>":
                        case "<text":
                          f4 = t12 + e12.length;
                          break;
                        case "</text>":
                          l4.t = n12.slice(f4, t12).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
                          break;
                        case "<mentions":
                        case "<mentions>":
                        case "<ext":
                          o12 = true;
                          break;
                        case "</mentions>":
                        case "</ext>":
                          o12 = false;
                          break;
                        default:
                          if (!o12 && c11.WTF) throw Error("unrecognized " + r13[0] + " in threaded comments");
                      }
                      return e12;
                    }), i12)
                  ));
                }), y3 && y3.length && ii(d3, y3, true, c11.people || []), (function(e12, t12, r12, a11, n12, s12, i12, o12) {
                  if (e12 && e12["!legdrawel"]) {
                    var c12, l4, f4, h4 = tG(r12, tZ(e12["!legdrawel"].Target, a11), true);
                    h4 && (c12 = rf(h4), l4 = o12 || [], f4 = 0, (tM(c12, "shape") || []).forEach(function(t13) {
                      var r13 = "", a12 = true, n13 = -1, s13 = -1, i13 = -1;
                      if (t13.replace(t0, function(e13, o14) {
                        var c13 = t4(e13);
                        switch (t3(c13[0])) {
                          case "<ClientData":
                            c13.ObjectType && (r13 = c13.ObjectType);
                            break;
                          case "<Visible":
                          case "<Visible/>":
                            a12 = false;
                            break;
                          case "<Row":
                          case "<Row>":
                          case "<Column":
                          case "<Column>":
                            n13 = o14 + e13.length;
                            break;
                          case "</Row>":
                            s13 = +t13.slice(n13, o14).trim();
                            break;
                          case "</Column>":
                            i13 = +t13.slice(n13, o14).trim();
                        }
                        return "";
                      }), "Note" === r13) {
                        var o13 = c7(e12, s13 >= 0 && i13 >= 0 ? ab({ r: s13, c: i13 }) : l4[f4].ref);
                        o13.c && (o13.c.hidden = a12), ++f4;
                      }
                    }));
                  }
                })(d3, 0, e11, t11, 0, 0, 0, T3);
              } catch (e12) {
                if (c11.WTF) throw e12;
              }
            })(e10, w2, T2, I2.SheetNames[D2], D2, P2, v2, V2, t10, C2, S2, A2);
          }
          return N2 = {
            Directory: x2,
            Workbook: C2,
            Props: I2,
            Custprops: R2,
            Deps: F2,
            Sheets: v2,
            SheetNames: I2.SheetNames,
            Strings: iY,
            Styles: A2,
            Themes: S2,
            SSF: tw(eD)
          }, t10 && t10.bookFiles && (e10.files ? (N2.keys = k2, N2.files = e10.files) : (N2.keys = [], N2.files = {}, e10.FullPaths.forEach(function(t11, r11) {
            t11 = t11.replace(/^Root Entry[\/]/, ""), N2.keys.push(t11), N2.files[t11] = e10.FileIndex[r11];
          }))), t10 && t10.bookVBA && (x2.vba.length > 0 ? N2.vbaraw = t$(e10, cB(x2.vba[0]), true) : x2.defaults && "application/vnd.ms-office.vbaProject" === x2.defaults.bin && (N2.vbaraw = t$(e10, "xl/vbaProject.bin", true))), N2.bookType = _2 ? "xlsb" : "xlsx", N2;
        }
        function cz(e10, t10) {
          e10 && !e10.SSF && (e10.SSF = tw(eD)), e10 && e10.SSF && (e5(), e3(e10.SSF), t10.revssf = tc(e10.SSF), t10.revssf[e10.SSF[65535]] = 0, t10.ssf = e10.SSF), t10.rels = {}, t10.wbrels = {}, t10.Strings = [], t10.Strings.Count = 0, t10.Strings.Unique = 0, iJ ? t10.revStrings = /* @__PURE__ */ new Map() : (t10.revStrings = {}, t10.revStrings.foo = [], delete t10.revStrings.foo);
          var r10, a10, n10, s10, i10, o10, c10, l2, f2 = ih.indexOf(t10.bookType) > -1, h2 = a3();
          cU(t10 = t10 || {});
          var u2 = tK(), d2 = "", p2 = 0;
          if (t10.cellXfs = [], i1(t10.cellXfs, {}, { revssf: { General: 0 } }), e10.Props || (e10.Props = {}), tj(u2, d2 = "docProps/core.xml", nk(e10.Props, t10)), h2.coreprops.push(d2), nv(t10.rels, 2, d2, ne), d2 = "docProps/app.xml", e10.Props && e10.Props.SheetNames) ;
          else if (e10.Workbook && e10.Workbook.Sheets) {
            for (var m2 = [], g2 = 0; g2 < e10.SheetNames.length; ++g2)
              2 != (e10.Workbook.Sheets[g2] || {}).Hidden && m2.push(e10.SheetNames[g2]);
            e10.Props.SheetNames = m2;
          } else e10.Props.SheetNames = e10.SheetNames;
          e10.Props.Worksheets = e10.Props.SheetNames.length, tj(u2, d2, nA(e10.Props, t10)), h2.extprops.push(d2), nv(t10.rels, 3, d2, nt), e10.Custprops !== e10.Props && ts(e10.Custprops || {}).length > 0 && (tj(u2, d2 = "docProps/custom.xml", nI(e10.Custprops, t10)), h2.custprops.push(d2), nv(t10.rels, 4, d2, nr));
          var v2 = ["SheetJ5"];
          for (p2 = 1, t10.tcid = 0; p2 <= e10.SheetNames.length; ++p2) {
            var b2 = { "!id": {} }, w2 = e10.Sheets[e10.SheetNames[p2 - 1]];
            if ((w2 || {})["!type"], tj(
              u2,
              d2 = "xl/worksheets/sheet" + p2 + ".xml",
              (function(e11, t11, r11, a11) {
                var n11, s11 = [tJ, rw("worksheet", null, { xmlns: rC[0], "xmlns:r": r_ })], i11 = r11.SheetNames[e11], o11 = 0, c11 = "", l3 = r11.Sheets[i11];
                null == l3 && (l3 = {});
                var f3 = l3["!ref"] || "A1", h3 = ak(f3);
                if (h3.e.c > 16383 || h3.e.r > 1048575) {
                  if (t11.WTF) throw Error("Range " + f3 + " exceeds format limit A1:XFD1048576");
                  h3.e.c = Math.min(h3.e.c, 16383), h3.e.r = Math.min(h3.e.c, 1048575), f3 = aT(h3);
                }
                a11 || (a11 = {}), l3["!comments"] = [];
                var u3 = [];
                !(function(e12, t12, r12, a12, n12) {
                  var s12 = false, i12 = {}, o12 = null;
                  if ("xlsx" !== a12.bookType && t12.vbaraw) {
                    var c12 = t12.SheetNames[r12];
                    try {
                      t12.Workbook && (c12 = t12.Workbook.Sheets[r12].CodeName || c12);
                    } catch (e13) {
                    }
                    s12 = true, i12.codeName = rh(re(c12));
                  }
                  if (e12 && e12["!outline"]) {
                    var l4 = { summaryBelow: 1, summaryRight: 1 };
                    e12["!outline"].above && (l4.summaryBelow = 0), e12["!outline"].left && (l4.summaryRight = 0), o12 = (o12 || "") + rw("outlinePr", null, l4);
                  }
                  (s12 || o12) && (n12[n12.length] = rw("sheetPr", o12, i12));
                })(l3, r11, e11, t11, s11), s11[s11.length] = rw("dimension", null, { ref: f3 }), s11[s11.length] = (d3 = { workbookViewId: "0" }, (((r11 || {}).Workbook || {}).Views || [])[0] && (d3.rightToLeft = r11.Workbook.Views[0].RTL ? "1" : "0"), rw("sheetViews", rw("sheetView", null, d3), {})), t11.sheetFormat && (s11[s11.length] = rw("sheetFormatPr", null, {
                  defaultRowHeight: t11.sheetFormat.defaultRowHeight || "16",
                  baseColWidth: t11.sheetFormat.baseColWidth || "10",
                  outlineLevelRow: t11.sheetFormat.outlineLevelRow || "7"
                })), null != l3["!cols"] && l3["!cols"].length > 0 && (s11[s11.length] = (function(e12, t12) {
                  for (var r12, a12 = ["<cols>"], n12 = 0; n12 != t12.length; ++n12)
                    (r12 = t12[n12]) && (a12[a12.length] = rw("col", null, iQ(n12, r12)));
                  return a12[a12.length] = "</cols>", a12.join("");
                })(0, l3["!cols"])), s11[o11 = s11.length] = "<sheetData/>", l3["!links"] = [], null != l3["!ref"] && (c11 = (function(e12, t12, r12, a12) {
                  var n12, s12, i12 = [], o12 = [], c12 = ak(e12["!ref"]), l4 = "", f4 = "", h4 = [], u4 = 0, d4 = 0, p4 = e12["!rows"], m4 = null != e12["!data"], g4 = m4 ? e12["!data"] : [], v4 = { r: f4 }, b4 = -1, w3 = (((a12 || {}).Workbook || {}).WBProps || {}).date1904;
                  for (d4 = c12.s.c; d4 <= c12.e.c; ++d4) h4[d4] = ag(d4);
                  for (u4 = c12.s.r; u4 <= c12.e.r; ++u4) {
                    o12 = [], f4 = ap(u4);
                    var T3 = m4 ? g4[u4] : [];
                    for (d4 = c12.s.c; d4 <= c12.e.c; ++d4) {
                      n12 = h4[d4] + f4;
                      var y3 = m4 ? T3[d4] : e12[n12];
                      void 0 !== y3 && null != (l4 = (function(e13, t13, r13, a13, n13, s13, i13) {
                        if (e13.c && r13["!comments"].push([t13, e13.c]), (void 0 === e13.v || "z" === e13.t && !(a13 || {}).sheetStubs) && "string" != typeof e13.f && void 0 === e13.z)
                          return "";
                        var o13 = "", c13 = e13.t, l5 = e13.v;
                        if ("z" !== e13.t)
                          switch (e13.t) {
                            case "b":
                              o13 = e13.v ? "1" : "0";
                              break;
                            case "n":
                              isNaN(e13.v) ? (e13.t = "e", o13 = aQ[e13.v = 36]) : isFinite(e13.v) ? o13 = "" + e13.v : (e13.t = "e", o13 = aQ[e13.v = 7]);
                              break;
                            case "e":
                              o13 = aQ[e13.v];
                              break;
                            case "d":
                              if (a13 && a13.cellDates) {
                                var f5 = tv(e13.v, i13);
                                o13 = f5.toISOString(), 1900 > f5.getUTCFullYear() && (o13 = o13.slice(o13.indexOf("T") + 1).replace("Z", ""));
                              } else (e13 = tw(e13)).t = "n", o13 = "" + (e13.v = tu(tv(e13.v, i13), i13));
                              void 0 === e13.z && (e13.z = eD[14]);
                              break;
                            default:
                              o13 = e13.v;
                          }
                        var h5 = "z" == e13.t || null == e13.v ? "" : rv("v", re(o13)), u5 = { r: t13 }, d5 = i1(a13.cellXfs, e13, a13);
                        switch (0 !== d5 && (u5.s = d5), e13.t) {
                          case "n":
                          case "z":
                            break;
                          case "d":
                            u5.t = "d";
                            break;
                          case "b":
                            u5.t = "b";
                            break;
                          case "e":
                            u5.t = "e";
                            break;
                          default:
                            if (null == e13.v) {
                              delete e13.t;
                              break;
                            }
                            if (e13.v.length > 32767)
                              throw Error("Text length must not exceed 32767 characters");
                            a13 && a13.bookSST ? (h5 = rv("v", "" + iq(a13.Strings, e13.v, a13.revStrings)), u5.t = "s") : u5.t = "str";
                        }
                        if (e13.t != c13 && (e13.t = c13, e13.v = l5), "string" == typeof e13.f && e13.f) {
                          var p5 = e13.F && e13.F.slice(0, t13.length) == t13 ? { t: "array", ref: e13.F } : null;
                          h5 = rw("f", re(e13.f), p5) + (null != e13.v ? h5 : "");
                        }
                        return e13.l && (e13.l.display = re(o13), r13["!links"].push([t13, e13.l])), e13.D && (u5.cm = 1), rw("c", h5, u5);
                      })(y3, n12, e12, t12, 0, 0, w3)) && o12.push(l4);
                    }
                    (o12.length > 0 || p4 && p4[u4]) && (v4 = { r: f4 }, p4 && p4[u4] && ((s12 = p4[u4]).hidden && (v4.hidden = 1), b4 = -1, s12.hpx ? b4 = s1(s12.hpx) : s12.hpt && (b4 = s12.hpt), b4 > -1 && (v4.ht = b4, v4.customHeight = 1), s12.level && (v4.outlineLevel = s12.level)), i12[i12.length] = rw("row", o12.join(""), v4));
                  }
                  if (p4)
                    for (; u4 < p4.length; ++u4)
                      p4 && p4[u4] && (v4 = { r: u4 + 1 }, (s12 = p4[u4]).hidden && (v4.hidden = 1), b4 = -1, s12.hpx ? b4 = s1(s12.hpx) : s12.hpt && (b4 = s12.hpt), b4 > -1 && (v4.ht = b4, v4.customHeight = 1), s12.level && (v4.outlineLevel = s12.level), i12[i12.length] = rw("row", "", v4));
                  return i12.join("");
                })(l3, t11, 0, r11, a11)).length > 0 && (s11[s11.length] = c11), s11.length > o11 + 1 && (s11[s11.length] = "</sheetData>", s11[o11] = s11[o11].replace("/>", ">")), l3["!protect"] && (s11[s11.length] = (p3 = l3["!protect"], m3 = { sheet: 1 }, ot.forEach(function(e12) {
                  null != p3[e12] && p3[e12] && (m3[e12] = "1");
                }), or.forEach(function(e12) {
                  null == p3[e12] || p3[e12] || (m3[e12] = "0");
                }), p3.password && (m3.password = sz(p3.password).toString(16).toUpperCase()), rw("sheetProtection", null, m3))), null != l3["!autofilter"] && (s11[s11.length] = (function(e12, t12, r12, a12) {
                  var n12 = "string" == typeof e12.ref ? e12.ref : aT(e12.ref);
                  r12.Workbook || (r12.Workbook = { Sheets: [] }), r12.Workbook.Names || (r12.Workbook.Names = []);
                  var s12 = r12.Workbook.Names, i12 = aw(n12);
                  i12.s.r == i12.e.r && (i12.e.r = aw(t12["!ref"]).e.r, n12 = aT(i12));
                  for (var o12 = 0; o12 < s12.length; ++o12) {
                    var c12 = s12[o12];
                    if ("_xlnm._FilterDatabase" == c12.Name && c12.Sheet == a12) {
                      c12.Ref = aE(r12.SheetNames[a12]) + "!" + ay(n12);
                      break;
                    }
                  }
                  return o12 == s12.length && s12.push({
                    Name: "_xlnm._FilterDatabase",
                    Sheet: a12,
                    Ref: "'" + r12.SheetNames[a12] + "'!" + n12
                  }), rw("autoFilter", null, { ref: n12 });
                })(l3["!autofilter"], l3, r11, e11)), null != l3["!merges"] && l3["!merges"].length > 0 && (s11[s11.length] = (function(e12) {
                  if (0 === e12.length) return "";
                  for (var t12 = '<mergeCells count="' + e12.length + '">', r12 = 0; r12 != e12.length; ++r12)
                    t12 += '<mergeCell ref="' + aT(e12[r12]) + '"/>';
                  return t12 + "</mergeCells>";
                })(l3["!merges"]));
                var d3, p3, m3, g3, v3 = -1, b3 = -1;
                return l3["!links"].length > 0 && (s11[s11.length] = "<hyperlinks>", l3["!links"].forEach(function(e12) {
                  e12[1].Target && (g3 = { ref: e12[0] }, "#" != e12[1].Target.charAt(0) && (b3 = nv(a11, -1, re(e12[1].Target).replace(/#[\s\S]*$/, ""), a8), g3["r:id"] = "rId" + b3), (v3 = e12[1].Target.indexOf("#")) > -1 && (g3.location = re(e12[1].Target.slice(v3 + 1))), e12[1].Tooltip && (g3.tooltip = re(e12[1].Tooltip)), g3.display = e12[1].display, s11[s11.length] = rw("hyperlink", null, g3));
                }), s11[s11.length] = "</hyperlinks>"), delete l3["!links"], null != l3["!margins"] && (s11[s11.length] = (i0(n11 = l3["!margins"]), rw("pageMargins", null, n11))), (!t11 || t11.ignoreEC || void 0 == t11.ignoreEC) && (s11[s11.length] = rv(
                  "ignoredErrors",
                  rw("ignoredError", null, { numberStoredAsText: 1, sqref: f3 })
                )), u3.length > 0 && (b3 = nv(
                  a11,
                  -1,
                  "../drawings/drawing" + (e11 + 1) + ".xml",
                  "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing"
                ), s11[s11.length] = rw("drawing", null, { "r:id": "rId" + b3 }), l3["!drawing"] = u3), l3["!comments"].length > 0 && (b3 = nv(a11, -1, "../drawings/vmlDrawing" + (e11 + 1) + ".vml", a7), s11[s11.length] = rw("legacyDrawing", null, { "r:id": "rId" + b3 }), l3["!legacy"] = b3), s11.length > 1 && (s11[s11.length] = "</worksheet>", s11[1] = s11[1].replace("/>", ">")), s11.join("");
              })(p2 - 1, t10, e10, b2)
            ), h2.sheets.push(d2), nv(t10.wbrels, -1, "worksheets/sheet" + p2 + ".xml", no[0]), w2) {
              var T2 = w2["!comments"], y2 = false, E2 = "";
              if (T2 && T2.length > 0) {
                var k2 = false;
                T2.forEach(function(e11) {
                  e11[1].forEach(function(e12) {
                    true == e12.T && (k2 = true);
                  });
                }), k2 && (tj(u2, E2 = "xl/threadedComments/threadedComment" + p2 + ".xml", io(T2, v2, t10)), h2.threadedcomments.push(E2), nv(b2, -1, "../threadedComments/threadedComment" + p2 + ".xml", nh)), tj(
                  u2,
                  E2 = "xl/comments" + p2 + ".xml",
                  (function(e11) {
                    var t11 = [tJ, rw("comments", null, { xmlns: rC[0] })], r11 = [];
                    return t11.push("<authors>"), e11.forEach(function(e12) {
                      e12[1].forEach(function(e13) {
                        var a11 = re(e13.a);
                        -1 == r11.indexOf(a11) && (r11.push(a11), t11.push("<author>" + a11 + "</author>")), e13.T && e13.ID && -1 == r11.indexOf("tc=" + e13.ID) && (r11.push("tc=" + e13.ID), t11.push("<author>tc=" + e13.ID + "</author>"));
                      });
                    }), 0 == r11.length && (r11.push("SheetJ5"), t11.push("<author>SheetJ5</author>")), t11.push("</authors>"), t11.push("<commentList>"), e11.forEach(function(e12) {
                      var a11 = 0, n11 = [], s11 = 0;
                      if (e12[1][0] && e12[1][0].T && e12[1][0].ID && (a11 = r11.indexOf("tc=" + e12[1][0].ID)), e12[1].forEach(function(e13) {
                        e13.a && (a11 = r11.indexOf(re(e13.a))), e13.T && ++s11, n11.push(null == e13.t ? "" : re(e13.t));
                      }), 0 === s11)
                        e12[1].forEach(function(a12) {
                          t11.push('<comment ref="' + e12[0] + '" authorId="' + r11.indexOf(re(a12.a)) + '"><text>'), t11.push(rv("t", null == a12.t ? "" : re(a12.t))), t11.push("</text></comment>");
                        });
                      else {
                        e12[1][0] && e12[1][0].T && e12[1][0].ID && (a11 = r11.indexOf("tc=" + e12[1][0].ID)), t11.push('<comment ref="' + e12[0] + '" authorId="' + a11 + '"><text>');
                        for (var i11 = "Comment:\n    " + n11[0] + "\n", o11 = 1; o11 < n11.length; ++o11)
                          i11 += "Reply:\n    " + n11[o11] + "\n";
                        t11.push(rv("t", re(i11))), t11.push("</text></comment>");
                      }
                    }), t11.push("</commentList>"), t11.length > 2 && (t11[t11.length] = "</comments>", t11[1] = t11[1].replace("/>", ">")), t11.join("");
                  })(T2, t10)
                ), h2.comments.push(E2), nv(b2, -1, "../comments" + p2 + ".xml", a9), y2 = true;
              }
              w2["!legacy"] && y2 && tj(u2, "xl/drawings/vmlDrawing" + p2 + ".vml", is(p2, w2["!comments"])), delete w2["!comments"], delete w2["!legacy"];
            }
            b2["!id"].rId1 && tj(u2, np(d2), ng(b2));
          }
          return null != t10.Strings && t10.Strings.length > 0 && (tj(
            u2,
            d2 = "xl/sharedStrings.xml",
            (function(e11, t11) {
              if (!t11.bookSST) return "";
              var r11 = [tJ];
              r11[r11.length] = rw("sst", null, { xmlns: rC[0], count: e11.Count, uniqueCount: e11.Unique });
              for (var a11 = 0; a11 != e11.length; ++a11)
                if (null != e11[a11]) {
                  var n11 = e11[a11], s11 = "<si>";
                  n11.r ? s11 += n11.r : (s11 += "<t", n11.t || (n11.t = ""), "string" != typeof n11.t && (n11.t = String(n11.t)), n11.t.match(sP) && (s11 += ' xml:space="preserve"'), s11 += ">" + re(n11.t) + "</t>"), s11 += "</si>", r11[r11.length] = s11;
                }
              return r11.length > 2 && (r11[r11.length] = "</sst>", r11[1] = r11[1].replace("/>", ">")), r11.join("");
            })(t10.Strings, t10)
          ), h2.strs.push(d2), nv(t10.wbrels, -1, "sharedStrings.xml", na)), tj(
            u2,
            d2 = "xl/workbook.xml",
            (function(e11) {
              var t11 = [tJ];
              t11[t11.length] = rw("workbook", null, { xmlns: rC[0], "xmlns:r": r_ });
              var r11 = e11.Workbook && (e11.Workbook.Names || []).length > 0, a11 = { codeName: "ThisWorkbook" };
              e11.Workbook && e11.Workbook.WBProps && (ol.forEach(function(t12) {
                null != e11.Workbook.WBProps[t12[0]] && e11.Workbook.WBProps[t12[0]] != t12[1] && (a11[t12[0]] = e11.Workbook.WBProps[t12[0]]);
              }), e11.Workbook.WBProps.CodeName && (a11.codeName = e11.Workbook.WBProps.CodeName, delete a11.CodeName)), t11[t11.length] = rw("workbookPr", null, a11);
              var n11 = e11.Workbook && e11.Workbook.Sheets || [], s11 = 0;
              if (n11 && n11[0] && n11[0].Hidden) {
                for (s11 = 0, t11[t11.length] = "<bookViews>"; s11 != e11.SheetNames.length && n11[s11] && n11[s11].Hidden; ++s11) ;
                s11 == e11.SheetNames.length && (s11 = 0), t11[t11.length] = '<workbookView firstSheet="' + s11 + '" activeTab="' + s11 + '"/>', t11[t11.length] = "</bookViews>";
              }
              for (s11 = 0, t11[t11.length] = "<sheets>"; s11 != e11.SheetNames.length; ++s11) {
                var i11 = { name: re(e11.SheetNames[s11].slice(0, 31)) };
                if (i11.sheetId = "" + (s11 + 1), i11["r:id"] = "rId" + (s11 + 1), n11[s11])
                  switch (n11[s11].Hidden) {
                    case 1:
                      i11.state = "hidden";
                      break;
                    case 2:
                      i11.state = "veryHidden";
                  }
                t11[t11.length] = rw("sheet", null, i11);
              }
              return t11[t11.length] = "</sheets>", r11 && (t11[t11.length] = "<definedNames>", e11.Workbook && e11.Workbook.Names && e11.Workbook.Names.forEach(function(e12) {
                var r12 = { name: e12.Name };
                e12.Comment && (r12.comment = e12.Comment), null != e12.Sheet && (r12.localSheetId = "" + e12.Sheet), e12.Hidden && (r12.hidden = "1"), e12.Ref && (t11[t11.length] = rw("definedName", re(e12.Ref), r12));
              }), t11[t11.length] = "</definedNames>"), t11.length > 2 && (t11[t11.length] = "</workbook>", t11[1] = t11[1].replace("/>", ">")), t11.join("");
            })(e10, t10)
          ), h2.workbooks.push(d2), nv(t10.rels, 1, d2, a6), tj(u2, d2 = "xl/theme/theme1.xml", ia(e10.Themes, t10)), h2.themes.push(d2), nv(t10.wbrels, -1, "theme/theme1.xml", ns), tj(
            u2,
            d2 = "xl/styles.xml",
            (r10 = t10, n10 = [tJ, rw("styleSheet", null, { xmlns: rC[0], "xmlns:vt": rS })], e10.SSF && null != (s10 = e10.SSF, i10 = ["<numFmts>"], [
              [5, 8],
              [23, 26],
              [41, 44],
              [50, 392]
            ].forEach(function(e11) {
              for (var t11 = e11[0]; t11 <= e11[1]; ++t11)
                null != s10[t11] && (i10[i10.length] = rw("numFmt", null, { numFmtId: t11, formatCode: re(s10[t11]) }));
            }), a10 = 1 === i10.length ? "" : (i10[i10.length] = "</numFmts>", i10[0] = rw("numFmts", null, { count: i10.length - 2 }).replace("/>", ">"), i10.join(""))) && (n10[n10.length] = a10), n10[n10.length] = '<fonts count="1"><font><sz val="12"/><color theme="1"/><name val="Calibri"/><family val="2"/><scheme val="minor"/></font></fonts>', n10[n10.length] = '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>', n10[n10.length] = '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>', n10[n10.length] = '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>', o10 = r10.cellXfs, (c10 = [])[c10.length] = rw("cellXfs", null), o10.forEach(function(e11) {
              c10[c10.length] = rw("xf", null, e11);
            }), c10[c10.length] = "</cellXfs>", (a10 = 2 === c10.length ? "" : (c10[0] = rw("cellXfs", null, { count: c10.length - 2 }).replace("/>", ">"), c10.join(""))) && (n10[n10.length] = a10), n10[n10.length] = '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>', n10[n10.length] = '<dxfs count="0"/>', n10[n10.length] = '<tableStyles count="0" defaultTableStyle="TableStyleMedium9" defaultPivotStyle="PivotStyleMedium4"/>', n10.length > 2 && (n10[n10.length] = "</styleSheet>", n10[1] = n10[1].replace("/>", ">")), n10.join(""))
          ), h2.styles.push(d2), nv(t10.wbrels, -1, "styles.xml", nn), e10.vbaraw && f2 && (tj(u2, d2 = "xl/vbaProject.bin", e10.vbaraw), h2.vba.push(d2), nv(t10.wbrels, -1, "vbaProject.bin", nd)), tj(
            u2,
            d2 = "xl/metadata.xml",
            ((l2 = [tJ]).push(
              '<metadata xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:xlrd="http://schemas.microsoft.com/office/spreadsheetml/2017/richdata" xmlns:xda="http://schemas.microsoft.com/office/spreadsheetml/2017/dynamicarray">\n  <metadataTypes count="1">\n    <metadataType name="XLDAPR" minSupportedVersion="120000" copy="1" pasteAll="1" pasteValues="1" merge="1" splitFirst="1" rowColShift="1" clearFormats="1" clearComments="1" assign="1" coerce="1" cellMeta="1"/>\n  </metadataTypes>\n  <futureMetadata name="XLDAPR" count="1">\n    <bk>\n      <extLst>\n        <ext uri="{bdbb8cdc-fa1e-496e-a857-3c3f30c029c3}">\n          <xda:dynamicArrayProperties fDynamic="1" fCollapsed="0"/>\n        </ext>\n      </extLst>\n    </bk>\n  </futureMetadata>\n  <cellMetadata count="1">\n    <bk>\n      <rc t="1" v="0"/>\n    </bk>\n  </cellMetadata>\n</metadata>'
            ), l2.join(""))
          ), h2.metadata.push(d2), nv(t10.wbrels, -1, "metadata.xml", nf), v2.length > 1 && (tj(u2, d2 = "xl/persons/person.xml", ic(v2, t10)), h2.people.push(d2), nv(t10.wbrels, -1, "persons/person.xml", nu)), tj(u2, "[Content_Types].xml", a5(h2, t10)), tj(u2, "_rels/.rels", ng(t10.rels)), tj(u2, "xl/_rels/workbook.xml.rels", ng(t10.wbrels)), delete t10.revssf, delete t10.ssf, u2;
        }
        function cH(e10, t10) {
          var r10 = "";
          switch ((t10 || {}).type || "base64") {
            case "buffer":
            case "array":
              return [e10[0], e10[1], e10[2], e10[3], e10[4], e10[5], e10[6], e10[7]];
            case "base64":
              r10 = ed(e10.slice(0, 12));
              break;
            case "binary":
              r10 = e10;
              break;
            default:
              throw Error("Unrecognized type " + (t10 && t10.type || "undefined"));
          }
          return [
            r10.charCodeAt(0),
            r10.charCodeAt(1),
            r10.charCodeAt(2),
            r10.charCodeAt(3),
            r10.charCodeAt(4),
            r10.charCodeAt(5),
            r10.charCodeAt(6),
            r10.charCodeAt(7)
          ];
        }
        function cV(e10, t10) {
          var r10 = 0;
          f: for (; r10 < e10.length; )
            switch (e10.charCodeAt(r10)) {
              case 10:
              case 13:
              case 32:
                ++r10;
                break;
              case 60:
                return o_(e10.slice(r10), t10);
              default:
                break f;
            }
          return sS.to_workbook(e10, t10);
        }
        function c$(e10, t10, r10, a10) {
          return a10 ? (r10.type = "string", sS.to_workbook(e10, r10)) : sS.to_workbook(t10, r10);
        }
        function cG(e10, t10) {
          ea();
          var r10, n10, s10, i10, o10, c10, l2, f2, h2, u2 = t10 || {};
          if (u2.codepage && void 0 === G && console.error("Codepage tables are not loaded.  Non-ASCII characters may not give expected results"), "undefined" != typeof ArrayBuffer && e10 instanceof ArrayBuffer)
            return cG(new Uint8Array(e10), ((u2 = tw(u2)).type = "array", u2));
          if ("undefined" != typeof Int8Array && e10 instanceof Int8Array)
            return cG(new Uint8Array(e10.buffer, e10.byteOffset, e10.length), u2);
          "undefined" != typeof Uint8Array && e10 instanceof Uint8Array && !u2.type && (u2.type = "undefined" != typeof Deno ? "buffer" : "array");
          var d2 = e10, p2 = [0, 0, 0, 0], m2 = false;
          if (u2.cellStyles && (u2.cellNF = true, u2.sheetStubs = true), iZ = {}, u2.dateNF && (iZ.dateNF = u2.dateNF), u2.type || (u2.type = ep && a.isBuffer(e10) ? "buffer" : "base64"), "file" == u2.type && (u2.type = ep ? "buffer" : "binary", d2 = (function(e11) {
            if (void 0 !== X) return X.readFileSync(e11);
            if ("undefined" != typeof Deno) return Deno.readFileSync(e11);
            if ("undefined" != typeof $ && "undefined" != typeof File && "undefined" != typeof Folder)
              try {
                var t11 = File(e11);
                t11.open("r"), t11.encoding = "binary";
                var r11 = t11.read();
                return t11.close(), r11;
              } catch (e12) {
                if (!e12.message || -1 == e12.message.indexOf("onstruct")) throw e12;
              }
            throw Error("Cannot access file " + e11);
          })(e10), "undefined" == typeof Uint8Array || ep || (u2.type = "array")), "string" == u2.type && (m2 = true, u2.type = "binary", u2.codepage = 65001, d2 = e10.match(/[^\x00-\x7F]/) ? rh(e10) : e10), "array" == u2.type && "undefined" != typeof Uint8Array && e10 instanceof Uint8Array && "undefined" != typeof ArrayBuffer) {
            var g2 = new Uint8Array(new ArrayBuffer(3));
            if (g2.foo = "bar", !g2.foo) return (u2 = tw(u2)).type = "array", cG(eE(d2), u2);
          }
          switch ((p2 = cH(d2, u2))[0]) {
            case 208:
              if (207 === p2[1] && 17 === p2[2] && 224 === p2[3] && 161 === p2[4] && 177 === p2[5] && 26 === p2[6] && 225 === p2[7])
                return s10 = tr.read(d2, u2), i10 = u2, tr.find(s10, "EncryptedPackage") ? (function(e11, t11) {
                  var r11 = t11 || {}, a10 = "Workbook", n11 = tr.find(e11, a10);
                  try {
                    if (a10 = "/!DataSpaces/Version", !(n11 = tr.find(e11, a10)) || !n11.content || (s11 = n11.content, (i11 = {}).id = s11.read_shift(0, "lpp4"), i11.R = sU(s11, 4), i11.U = sU(s11, 4), i11.W = sU(s11, 4), a10 = "/!DataSpaces/DataSpaceMap", !(n11 = tr.find(e11, a10)) || !n11.content))
                      throw Error("ECMA-376 Encrypted file missing " + a10);
                    var s11, i11, o11 = (function(e12) {
                      var t12 = [];
                      e12.l += 4;
                      for (var r12 = e12.read_shift(4); r12-- > 0; )
                        t12.push(
                          (function(e13) {
                            for (var t13 = e13.read_shift(4), r13 = e13.l + t13 - 4, a11 = {}, n12 = e13.read_shift(4), s12 = []; n12-- > 0; )
                              s12.push({ t: e13.read_shift(4), v: e13.read_shift(0, "lpp4") });
                            if (a11.name = e13.read_shift(0, "lpp4"), a11.comps = s12, e13.l != r13)
                              throw Error("Bad DataSpaceMapEntry: " + e13.l + " != " + r13);
                            return a11;
                          })(e12)
                        );
                      return t12;
                    })(n11.content);
                    if (1 !== o11.length || 1 !== o11[0].comps.length || 0 !== o11[0].comps[0].t || "StrongEncryptionDataSpace" !== o11[0].name || "EncryptedPackage" !== o11[0].comps[0].v)
                      throw Error("ECMA-376 Encrypted file bad " + a10);
                    if (a10 = "/!DataSpaces/DataSpaceInfo/StrongEncryptionDataSpace", !(n11 = tr.find(e11, a10)) || !n11.content)
                      throw Error("ECMA-376 Encrypted file missing " + a10);
                    var c11 = (function(e12) {
                      var t12 = [];
                      e12.l += 4;
                      for (var r12 = e12.read_shift(4); r12-- > 0; ) t12.push(e12.read_shift(0, "lpp4"));
                      return t12;
                    })(n11.content);
                    if (1 != c11.length || "StrongEncryptionTransform" != c11[0])
                      throw Error("ECMA-376 Encrypted file bad " + a10);
                    if (a10 = "/!DataSpaces/TransformInfo/StrongEncryptionTransform/!Primary", !(n11 = tr.find(e11, a10)) || !n11.content)
                      throw Error("ECMA-376 Encrypted file missing " + a10);
                    !(function(e12) {
                      var t12, r12 = (t12 = {}, e12.read_shift(4), e12.l += 4, t12.id = e12.read_shift(0, "lpp4"), t12.name = e12.read_shift(0, "lpp4"), t12.R = sU(e12, 4), t12.U = sU(e12, 4), t12.W = sU(e12, 4), t12);
                      if (r12.ename = e12.read_shift(0, "8lpp4"), r12.blksz = e12.read_shift(4), r12.cmode = e12.read_shift(4), 4 != e12.read_shift(4))
                        throw Error("Bad !Primary record");
                    })(n11.content);
                  } catch (e12) {
                  }
                  if (a10 = "/EncryptionInfo", !(n11 = tr.find(e11, a10)) || !n11.content)
                    throw Error("ECMA-376 Encrypted file missing " + a10);
                  var l3 = (function(e12) {
                    var t12, r12, a11, n12, s12 = sU(e12);
                    switch (s12.Minor) {
                      case 2:
                        return [
                          s12.Minor,
                          (function(e13) {
                            if ((63 & e13.read_shift(4)) != 36) throw Error("EncryptionInfo mismatch");
                            var t13 = e13.read_shift(4);
                            return { t: "Std", h: sB(e13, t13), v: sW(e13, e13.length - e13.l) };
                          })(e12, s12)
                        ];
                      case 3:
                        return [
                          s12.Minor,
                          (function() {
                            throw Error("File is password-protected: ECMA-376 Extensible");
                          })(e12, s12)
                        ];
                      case 4:
                        return [
                          s12.Minor,
                          (t12 = e12, r12 = [
                            "saltSize",
                            "blockSize",
                            "keyBits",
                            "hashSize",
                            "cipherAlgorithm",
                            "cipherChaining",
                            "hashAlgorithm",
                            "saltValue"
                          ], t12.l += 4, a11 = t12.read_shift(t12.length - t12.l, "utf8"), n12 = {}, a11.replace(t0, function(e13) {
                            var t13 = t4(e13);
                            switch (t3(t13[0])) {
                              case "<?xml":
                              case "<encryption":
                              case "</encryption>":
                              case "</keyEncryptors>":
                              case "</keyEncryptor>":
                                break;
                              case "<keyData":
                                r12.forEach(function(e14) {
                                  n12[e14] = t13[e14];
                                });
                                break;
                              case "<dataIntegrity":
                                n12.encryptedHmacKey = t13.encryptedHmacKey, n12.encryptedHmacValue = t13.encryptedHmacValue;
                                break;
                              case "<keyEncryptors>":
                              case "<keyEncryptors":
                                n12.encs = [];
                                break;
                              case "<keyEncryptor":
                                n12.uri = t13.uri;
                                break;
                              case "<encryptedKey":
                                n12.encs.push(t13);
                                break;
                              default:
                                throw t13[0];
                            }
                          }), n12)
                        ];
                    }
                    throw Error("ECMA-376 Encrypted file unrecognized Version: " + s12.Minor);
                  })(n11.content);
                  if (a10 = "/EncryptedPackage", !(n11 = tr.find(e11, a10)) || !n11.content)
                    throw Error("ECMA-376 Encrypted file missing " + a10);
                  if (4 == l3[0] && "undefined" != typeof decrypt_agile)
                    return decrypt_agile(l3[1], n11.content, r11.password || "", r11);
                  if (2 == l3[0] && "undefined" != typeof decrypt_std76)
                    return decrypt_std76(l3[1], n11.content, r11.password || "", r11);
                  throw Error("File is password-protected");
                })(s10, i10) : oW(s10, i10);
              break;
            case 9:
              if (p2[1] <= 8) return oW(d2, u2);
              break;
            case 60:
              return o_(d2, u2);
            case 73:
              if (73 === p2[1] && 42 === p2[2] && 0 === p2[3]) throw Error("TIFF Image File is not a spreadsheet");
              if (68 === p2[1]) {
                var v2 = d2, b2 = u2, w2 = b2 || {}, T2 = !!w2.WTF;
                w2.WTF = true;
                try {
                  var y2 = sk.to_workbook(v2, w2);
                  return w2.WTF = T2, y2;
                } catch (e11) {
                  if (w2.WTF = T2, -1 == e11.message.indexOf("SYLK bad record ID") && T2) throw e11;
                  return sS.to_workbook(v2, b2);
                }
              }
              break;
            case 84:
              if (65 === p2[1] && 66 === p2[2] && 76 === p2[3]) return sx.to_workbook(d2, u2);
              break;
            case 80:
              return 75 === p2[1] && p2[2] < 9 && p2[3] < 9 ? (r10 = d2, (n10 = u2 || {}).type || (n10.type = ep && a.isBuffer(r10) ? "buffer" : "base64"), cW(tY(r10, n10), n10)) : c$(e10, d2, u2, m2);
            case 239:
              return 60 === p2[3] ? o_(d2, u2) : c$(e10, d2, u2, m2);
            case 255:
              if (254 === p2[1])
                return o10 = d2, c10 = u2, l2 = o10, "base64" == c10.type && (l2 = ed(l2)), "undefined" != typeof ArrayBuffer && o10 instanceof ArrayBuffer && (l2 = new Uint8Array(o10)), l2 = void 0 !== G ? G.utils.decode(1200, l2.slice(2), "str") : ep && a.isBuffer(o10) ? o10.slice(2).toString("utf16le") : "undefined" != typeof Uint8Array && l2 instanceof Uint8Array ? "undefined" != typeof TextDecoder ? new TextDecoder("utf-16le").decode(l2.slice(2)) : (function(e11) {
                  for (var t11 = [], r11 = 0; r11 < e11.length >> 1; ++r11)
                    t11[r11] = String.fromCharCode(e11[2 * r11] + (e11[2 * r11 + 1] << 8));
                  return t11.join("");
                })(l2.slice(2)) : es(l2.slice(2)), c10.type = "binary", cV(l2, c10);
              if (0 === p2[1] && 2 === p2[2] && 0 === p2[3]) return sA.to_workbook(d2, u2);
              break;
            case 0:
              if (0 === p2[1] && (p2[2] >= 2 && 0 === p2[3] || 0 === p2[2] && (8 === p2[3] || 9 === p2[3])))
                return sA.to_workbook(d2, u2);
              break;
            case 3:
            case 131:
            case 139:
            case 140:
              return sE.to_workbook(d2, u2);
            case 123:
              if (92 === p2[1] && 114 === p2[2] && 116 === p2[3])
                return (h2 = aS(
                  (function(e11, t11) {
                    switch (t11.type) {
                      case "base64":
                        return sG(ed(e11), t11);
                      case "binary":
                        return sG(e11, t11);
                      case "buffer":
                        return sG(ep && a.isBuffer(e11) ? e11.toString("binary") : ey(e11), t11);
                      case "array":
                        return sG(tb(e11), t11);
                    }
                    throw Error("Unrecognized type " + t11.type);
                  })(d2, f2 = u2),
                  f2
                )).bookType = "rtf", h2;
              break;
            case 10:
            case 13:
            case 32:
              var E2 = d2, k2 = u2, x2 = "", _2 = cH(E2, k2);
              switch (k2.type) {
                case "base64":
                  x2 = ed(E2);
                  break;
                case "binary":
                  x2 = E2;
                  break;
                case "buffer":
                  x2 = E2.toString("binary");
                  break;
                case "array":
                  x2 = tb(E2);
                  break;
                default:
                  throw Error("Unrecognized type " + k2.type);
              }
              return 239 == _2[0] && 187 == _2[1] && 191 == _2[2] && (x2 = rf(x2)), k2.type = "binary", cV(x2, k2);
            case 137:
              if (80 === p2[1] && 78 === p2[2] && 71 === p2[3]) throw Error("PNG Image File is not a spreadsheet");
              break;
            case 8:
              if (231 === p2[1]) throw Error("Unsupported Multiplan 1.x file!");
              break;
            case 12:
              if (236 === p2[1]) throw Error("Unsupported Multiplan 2.x file!");
              if (237 === p2[1]) throw Error("Unsupported Multiplan 3.x file!");
          }
          return sy.indexOf(p2[0]) > -1 && p2[2] <= 12 && p2[3] <= 31 ? sE.to_workbook(d2, u2) : c$(e10, d2, u2, m2);
        }
        function cX(e10, t10) {
          var r10 = t10 || {};
          return r10.type = "file", cG(e10, r10);
        }
        function cj(e10, t10) {
          switch (t10.type) {
            case "base64":
            case "binary":
              break;
            case "buffer":
            case "array":
              t10.type = "";
              break;
            case "file":
              return tn(t10.file, tr.write(e10, { type: ep ? "buffer" : "" }));
            case "string":
              throw Error("'string' output type invalid for '" + t10.bookType + "' files");
            default:
              throw Error("Unrecognized type " + t10.type);
          }
          return tr.write(e10, t10);
        }
        function cK(e10, t10) {
          var r10 = {}, a10 = ep ? "nodebuffer" : "undefined" != typeof Uint8Array ? "array" : "string";
          if (t10.compression && (r10.compression = "DEFLATE"), t10.password) r10.type = a10;
          else
            switch (t10.type) {
              case "base64":
                r10.type = "base64";
                break;
              case "binary":
                r10.type = "string";
                break;
              case "string":
                throw Error("'string' output type invalid for '" + t10.bookType + "' files");
              case "buffer":
              case "file":
                r10.type = a10;
                break;
              default:
                throw Error("Unrecognized type " + t10.type);
            }
          var n10 = e10.FullPaths ? tr.write(e10, {
            fileType: "zip",
            type: { nodebuffer: "buffer", string: "binary" }[r10.type] || r10.type,
            compression: !!t10.compression
          }) : e10.generate(r10);
          if ("undefined" != typeof Deno && "string" == typeof n10) {
            if ("binary" == t10.type || "base64" == t10.type) return n10;
            n10 = new Uint8Array(eT(n10));
          }
          return t10.password && "undefined" != typeof encrypt_agile ? cj(encrypt_agile(n10, t10.password), t10) : "file" === t10.type ? tn(t10.file, n10) : "string" == t10.type ? rf(n10) : n10;
        }
        function cY(e10, t10, r10) {
          r10 || (r10 = "");
          var a10 = r10 + e10;
          switch (t10.type) {
            case "base64":
              return eu(rh(a10));
            case "binary":
              return rh(a10);
            case "string":
              return e10;
            case "file":
              return tn(t10.file, a10, "utf8");
            case "buffer":
              if (ep) return em(a10, "utf8");
              if ("undefined" != typeof TextEncoder) return new TextEncoder().encode(a10);
              return cY(a10, { type: "binary" }).split("").map(function(e11) {
                return e11.charCodeAt(0);
              });
          }
          throw Error("Unrecognized type " + t10.type);
        }
        function cZ(e10, t10) {
          switch (t10.type) {
            case "string":
            case "base64":
            case "binary":
              for (var r10 = "", a10 = 0; a10 < e10.length; ++a10) r10 += String.fromCharCode(e10[a10]);
              return "base64" == t10.type ? eu(r10) : "string" == t10.type ? rf(r10) : r10;
            case "file":
              return tn(t10.file, e10);
            case "buffer":
              return e10;
            default:
              throw Error("Unrecognized type " + t10.type);
          }
        }
        function cJ(e10, t10) {
          ea(), ob(e10);
          var r10, a10 = tw(t10 || {});
          if (a10.cellStyles && (a10.cellNF = true, a10.sheetStubs = true), "array" == a10.type) {
            a10.type = "binary";
            var n10 = cJ(e10, a10);
            return a10.type = "array", eT(n10);
          }
          return cK(cz(e10, r10 = tw(a10 || {})), r10);
        }
        function cq(t10, r10) {
          ea(), ob(t10);
          var a10, n10, s10 = tw(r10 || {});
          if (s10.cellStyles && (s10.cellNF = true, s10.sheetStubs = true), "array" == s10.type) {
            s10.type = "binary";
            var i10 = cq(t10, s10);
            return s10.type = "array", eT(i10);
          }
          var o10 = 0;
          if (s10.sheet && (o10 = "number" == typeof s10.sheet ? s10.sheet : t10.SheetNames.indexOf(s10.sheet), !t10.SheetNames[o10]))
            throw Error("Sheet not found: " + s10.sheet + " : " + typeof s10.sheet);
          switch (s10.bookType || "xlsb") {
            case "xml":
            case "xlml":
              return cY(
                (function(e10, t11) {
                  t11 || (t11 = {}), e10.SSF || (e10.SSF = tw(eD)), e10.SSF && (e5(), e3(e10.SSF), t11.revssf = tc(e10.SSF), t11.revssf[e10.SSF[65535]] = 0, t11.ssf = e10.SSF, t11.cellXfs = [], i1(t11.cellXfs, {}, { revssf: { General: 0 } }));
                  var r11 = [];
                  r11.push(oS(e10, t11)), r11.push(oA(e10, t11)), r11.push(""), r11.push(oO(e10, t11));
                  for (var a11 = 0; a11 < e10.SheetNames.length; ++a11)
                    r11.push(
                      rw(
                        "Worksheet",
                        (function(e11, t12, r12) {
                          var a12 = [], n11 = r12.SheetNames[e11], s11 = r12.Sheets[n11], i11 = s11 ? oR(s11, t12, e11, r12) : "";
                          return i11.length > 0 && a12.push("<Names>" + i11 + "</Names>"), (i11 = s11 ? (function(e12, t13, r13, a13) {
                            if (!e12["!ref"]) return "";
                            var n12 = ak(e12["!ref"]), s12 = e12["!merges"] || [], i12 = 0, o11 = [];
                            e12["!cols"] && e12["!cols"].forEach(function(e13, t14) {
                              s0(e13);
                              var r14 = !!e13.width, a14 = iQ(t14, e13), n13 = { "ss:Index": t14 + 1 };
                              r14 && (n13["ss:Width"] = sY(a14.width)), e13.hidden && (n13["ss:Hidden"] = "1"), o11.push(rw("Column", null, n13));
                            });
                            for (var c11 = null != e12["!data"], l2 = { r: 0, c: 0 }, f2 = n12.s.r; f2 <= n12.e.r; ++f2) {
                              var h2 = [oD(f2, (e12["!rows"] || [])[f2])];
                              l2.r = f2;
                              for (var u2 = n12.s.c; u2 <= n12.e.c; ++u2) {
                                l2.c = u2;
                                var d2 = false;
                                for (i12 = 0; i12 != s12.length; ++i12)
                                  if (!(s12[i12].s.c > u2) && !(s12[i12].s.r > f2) && !(s12[i12].e.c < u2) && !(s12[i12].e.r < f2)) {
                                    (s12[i12].s.c != u2 || s12[i12].s.r != f2) && (d2 = true);
                                    break;
                                  }
                                if (!d2) {
                                  var p2 = ag(u2) + ap(f2), m2 = c11 ? (e12["!data"][f2] || [])[u2] : e12[p2];
                                  h2.push(oF(m2, p2, e12, t13, r13, a13, l2));
                                }
                              }
                              h2.push("</Row>"), h2.length > 2 && o11.push(h2.join(""));
                            }
                            return o11.join("");
                          })(s11, t12, e11, r12) : "").length > 0 && a12.push("<Table>" + i11 + "</Table>"), a12.push(oN(s11, t12, e11, r12)), s11 && s11["!autofilter"] && a12.push(
                            '<AutoFilter x:Range="' + ip(ay(s11["!autofilter"].ref), { r: 0, c: 0 }) + '" xmlns="urn:schemas-microsoft-com:office:excel"></AutoFilter>'
                          ), a12.join("");
                        })(a11, t11, e10),
                        { "ss:Name": re(e10.SheetNames[a11]) }
                      )
                    );
                  return r11[2] = oC(e10, t11), tJ + rw("Workbook", r11.join(""), {
                    xmlns: rR,
                    "xmlns:o": rI,
                    "xmlns:x": rO,
                    "xmlns:ss": rR,
                    "xmlns:dt": rN,
                    "xmlns:html": rF
                  });
                })(t10, s10),
                s10
              );
            case "slk":
            case "sylk":
              return cY(sk.from_sheet(t10.Sheets[t10.SheetNames[o10]], s10, t10), s10);
            case "htm":
            case "html":
              return cY(o0(t10.Sheets[t10.SheetNames[o10]], s10), s10);
            case "txt":
              var c10 = c6(t10.Sheets[t10.SheetNames[o10]], s10);
              switch (s10.type) {
                case "base64":
                  return (function(e10) {
                    for (var t11 = "", r11 = 0, a11 = 0, n11 = 0, s11 = 0, i11 = 0, o11 = 0, c11 = 0, l2 = 0; l2 < e10.length; )
                      (r11 = e10.charCodeAt(l2++)) > 255 && (r11 = 95), s11 = r11 >> 2, (a11 = e10.charCodeAt(l2++)) > 255 && (a11 = 95), i11 = (3 & r11) << 4 | a11 >> 4, (n11 = e10.charCodeAt(l2++)) > 255 && (n11 = 95), o11 = (15 & a11) << 2 | n11 >> 6, c11 = 63 & n11, isNaN(a11) ? o11 = c11 = 64 : isNaN(n11) && (c11 = 64), t11 += eh.charAt(s11) + eh.charAt(i11) + eh.charAt(o11) + eh.charAt(c11);
                    return t11;
                  })(c10);
                case "binary":
                case "string":
                  return c10;
                case "file":
                  return tn(s10.file, c10, "binary");
                case "buffer":
                  if (ep) return em(c10, "binary");
                  return c10.split("").map(function(e10) {
                    return e10.charCodeAt(0);
                  });
              }
              throw Error("Unrecognized type " + s10.type);
            case "csv":
              return cY(c5(t10.Sheets[t10.SheetNames[o10]], s10), s10, "\uFEFF");
            case "dif":
              return cY(sx.from_sheet(t10.Sheets[t10.SheetNames[o10]], s10), s10);
            case "dbf":
              return cZ(sE.from_sheet(t10.Sheets[t10.SheetNames[o10]], s10), s10);
            case "prn":
              return cY(sS.from_sheet(t10.Sheets[t10.SheetNames[o10]], s10), s10);
            case "rtf":
              return cY(
                (function(e10, t11) {
                  var r11 = ["{\\rtf1\\ansi"];
                  if (!e10["!ref"]) return r11[0] + "}";
                  for (var a11, n11 = ak(e10["!ref"]), s11 = null != e10["!data"], i11 = [], o11 = n11.s.r; o11 <= n11.e.r; ++o11) {
                    r11.push("\\trowd\\trautofit1");
                    for (var c11 = n11.s.c; c11 <= n11.e.c; ++c11) r11.push("\\cellx" + (c11 + 1));
                    for (r11.push("\\pard\\intbl"), s11 && (i11 = e10["!data"][o11] || []), c11 = n11.s.c; c11 <= n11.e.c; ++c11) {
                      var l2 = ab({ r: o11, c: c11 });
                      if (!(a11 = s11 ? i11[c11] : e10[l2]) || null == a11.v && (!a11.f || a11.F)) {
                        r11.push(" \\cell");
                        continue;
                      }
                      r11.push(" " + (a11.w || (a_(a11), a11.w) || "").replace(/[\r\n]/g, "\\par ")), r11.push("\\cell");
                    }
                    r11.push("\\pard\\intbl\\row");
                  }
                  return r11.join("") + "}";
                })(t10.Sheets[t10.SheetNames[o10]], 0),
                s10
              );
            case "eth":
              return cY(s_.from_sheet(t10.Sheets[t10.SheetNames[o10]], s10), s10);
            case "fods":
              return cY(o9(t10, s10), s10);
            case "wk1":
              return cZ(sA.sheet_to_wk1(t10.Sheets[t10.SheetNames[o10]], s10), s10);
            case "wk3":
              return cZ(sA.book_to_wk3(t10, s10), s10);
            case "biff2":
              s10.biff || (s10.biff = 2);
            case "biff3":
              s10.biff || (s10.biff = 3);
            case "biff4":
              return s10.biff || (s10.biff = 4), cZ(oK(t10, s10), s10);
            case "biff5":
              s10.biff || (s10.biff = 5);
            case "biff8":
            case "xla":
            case "xls":
              return s10.biff || (s10.biff = 8), cj(
                (function(e10, t11) {
                  var r11, a11 = t11 || {}, n11 = tr.utils.cfb_new({ root: "R" }), s11 = "/Workbook";
                  switch (a11.bookType || "xls") {
                    case "xls":
                      a11.bookType = "biff8";
                    case "xla":
                      a11.bookType || (a11.bookType = "xla");
                    case "biff8":
                      s11 = "/Workbook", a11.biff = 8;
                      break;
                    case "biff5":
                      s11 = "/Book", a11.biff = 5;
                      break;
                    default:
                      throw Error("invalid type " + a11.bookType + " for XLS CFB");
                  }
                  return tr.utils.cfb_add(n11, s11, oK(e10, a11)), 8 == a11.biff && (e10.Props || e10.Custprops) && (function(e11, t12) {
                    var r12, a12 = [], n12 = [], s12 = [], i11 = 0, o11 = ti(aK, "n"), c11 = ti(aY, "n");
                    if (e11.Props)
                      for (i11 = 0, r12 = ts(e11.Props); i11 < r12.length; ++i11)
                        (Object.prototype.hasOwnProperty.call(o11, r12[i11]) ? a12 : Object.prototype.hasOwnProperty.call(c11, r12[i11]) ? n12 : s12).push([r12[i11], e11.Props[r12[i11]]]);
                    if (e11.Custprops)
                      for (i11 = 0, r12 = ts(e11.Custprops); i11 < r12.length; ++i11)
                        Object.prototype.hasOwnProperty.call(e11.Props || {}, r12[i11]) || (Object.prototype.hasOwnProperty.call(o11, r12[i11]) ? a12 : Object.prototype.hasOwnProperty.call(c11, r12[i11]) ? n12 : s12).push([r12[i11], e11.Custprops[r12[i11]]]);
                    var l2 = [];
                    for (i11 = 0; i11 < s12.length; ++i11)
                      nB.indexOf(s12[i11][0]) > -1 || n_.indexOf(s12[i11][0]) > -1 || null != s12[i11][1] && l2.push(s12[i11]);
                    n12.length && tr.utils.cfb_add(t12, "/SummaryInformation", nH(n12, oU, c11, aY)), (a12.length || l2.length) && tr.utils.cfb_add(
                      t12,
                      "/DocumentSummaryInformation",
                      nH(a12, oB, o11, aK, l2.length ? l2 : null, "05d5cdd59c2e1b10939708002b2cf9ae")
                    );
                  })(e10, n11), 8 == a11.biff && e10.vbaraw && (r11 = tr.read(e10.vbaraw, {
                    type: "string" == typeof e10.vbaraw ? "binary" : "buffer"
                  })).FullPaths.forEach(function(e11, t12) {
                    if (0 != t12) {
                      var a12 = e11.replace(/^[\/]*[^\/]*[\/]/, "/_VBA_PROJECT_CUR/");
                      "/" !== a12.slice(-1) && tr.utils.cfb_add(n11, a12, r11.FileIndex[t12].content);
                    }
                  }), n11;
                })(t10, a10 = s10 || {}),
                a10
              );
            case "xlsx":
            case "xlsm":
            case "xlam":
            case "xlsb":
            case "numbers":
            case "ods":
              return cK(
                (function(t11, r11) {
                  switch (r11.bookType) {
                    case "ods":
                      return o9(t11, r11);
                    case "numbers":
                      return (function(e10, t12) {
                        if (!t12 || !t12.numbers) throw Error("Must pass a `numbers` option -- check the README");
                        var r12, a11, n11 = tr.read(t12.numbers, { type: "base64" }), s11 = (r12 = {}, a11 = [], n11.FileIndex.map(function(e11, t13) {
                          return [e11, n11.FullPaths[t13]];
                        }).forEach(function(e11) {
                          var t13 = e11[0], n12 = e11[1];
                          2 == t13.type && t13.name.match(/\.iwa/) && 0 == t13.content[0] && cp(cg(t13.content)).forEach(function(e12) {
                            a11.push(e12.id), r12[e12.id] = { deps: [], location: n12, type: cf(e12.messages[0].meta[1][0].data) };
                          });
                        }), n11.FileIndex.forEach(function(e11) {
                          e11.name.match(/\.iwa/) && 0 == e11.content[0] && cp(cg(e11.content)).forEach(function(e12) {
                            e12.messages.forEach(function(t13) {
                              [5, 6].forEach(function(a12) {
                                t13.meta[a12] && t13.meta[a12].forEach(function(t14) {
                                  r12[e12.id].deps.push(cf(t14.data));
                                });
                              });
                            });
                          });
                        }), r12), i11 = cN(n11, s11, 1);
                        if (null == i11) throw "Could not find message ".concat(1, " in Numbers template");
                        var o11 = cd(ch(i11.messages[0].data)[1], cy);
                        if (o11.length > 1) throw Error("Template NUMBERS file must have exactly one sheet");
                        return e10.SheetNames.forEach(function(t13, r13) {
                          var a12, c11, l2, f2, h2, u2, d2, p2, m2, g2, v2, b2, w2, T2, y2;
                          r13 >= 1 && (a12 = n11, c11 = s11, l2 = r13 + 1, f2 = -1, h2 = -1, u2 = {}, cR(a12, c11, 1, function(e11, t14) {
                            var r14 = ch(e11.messages[0].data);
                            h2 = cC(
                              {
                                deps: [1],
                                location: c11[f2 = cy(ch(e11.messages[0].data)[1][0].data)].location,
                                type: 2
                              },
                              c11
                            ), u2[f2] = h2, ck(e11, h2), r14[1].push({ type: 2, data: cE(h2) });
                            var n12 = cN(a12, c11, f2);
                            n12.id = h2, c11[1].location == c11[h2].location ? t14.push(n12) : cR(a12, c11, h2, function(e12, t15) {
                              return t15.push(n12);
                            }), e11.messages[0].data = cu(r14);
                          }), d2 = -1, cR(a12, c11, h2, function(e11, t14) {
                            for (var r14 = ch(e11.messages[0].data), n12 = 3; n12 <= 69; ++n12) delete r14[n12];
                            var s12 = cd(r14[2], cy);
                            s12.forEach(function(t15) {
                              return cx(e11, t15);
                            }), ck(e11, d2 = cC({ deps: [h2], location: c11[s12[0]].location, type: c11[s12[0]].type }, c11)), u2[s12[0]] = d2, r14[2] = [{ type: 2, data: cE(d2) }];
                            var i12 = cN(a12, c11, s12[0]);
                            i12.id = d2, c11[s12[0]].location == c11[h2].location ? t14.push(i12) : (cR(a12, c11, 2, function(e12) {
                              var t15 = ch(e12.messages[0].data);
                              cP(t15, c11, h2, d2), e12.messages[0].data = cu(t15);
                            }), cR(a12, c11, d2, function(e12, t15) {
                              return t15.push(i12);
                            })), e11.messages[0].data = cu(r14);
                          }), p2 = -1, cR(a12, c11, d2, function(e11, t14) {
                            for (var r14 = ch(e11.messages[0].data), n12 = ch(r14[1][0].data), s12 = 3; s12 <= 69; ++s12)
                              delete n12[s12];
                            var i12 = cy(n12[2][0].data);
                            n12[2][0].data = cE(u2[i12]), r14[1][0].data = cu(n12);
                            var o12 = cy(r14[2][0].data);
                            cx(e11, o12), ck(e11, p2 = cC({ deps: [d2], location: c11[o12].location, type: c11[o12].type }, c11)), u2[o12] = p2, r14[2][0].data = cE(p2);
                            var l3 = cN(a12, c11, o12);
                            l3.id = p2, c11[d2].location == c11[p2].location ? t14.push(l3) : cR(a12, c11, p2, function(e12, t15) {
                              return t15.push(l3);
                            }), e11.messages[0].data = cu(r14);
                          }), cR(a12, c11, p2, function(e11, t14) {
                            var r14, n12, s12 = ch(e11.messages[0].data), i12 = cr(s12[1][0].data).replace(
                              /-[A-Z0-9]*/,
                              "-".concat(("0000" + l2.toString(16)).slice(-4))
                            );
                            s12[1][0].data = ca(i12), [12, 13, 29, 31, 32, 33, 39, 44, 47, 81, 82, 84].forEach(function(e12) {
                              return delete s12[e12];
                            }), s12[45] && (cx(e11, cy(ch(s12[45][0].data)[1][0].data)), delete s12[45]), s12[70] && (null == (r14 = ch(s12[70][0].data)[2]) || r14.forEach(function(t15) {
                              var r15 = ch(t15.data);
                              [2, 3].map(function(e12) {
                                return r15[e12][0];
                              }).forEach(function(t16) {
                                var r16 = ch(t16.data);
                                r16[8] && cx(e11, cy(r16[8][0].data));
                              });
                            }), delete s12[70]), [
                              46,
                              30,
                              34,
                              35,
                              36,
                              38,
                              48,
                              49,
                              60,
                              61,
                              62,
                              63,
                              64,
                              71,
                              72,
                              73,
                              74,
                              75,
                              85,
                              86,
                              87,
                              88,
                              89
                            ].forEach(function(t15) {
                              if (s12[t15]) {
                                var r15 = cy(s12[t15][0].data);
                                delete s12[t15], cx(e11, r15);
                              }
                            });
                            var o12 = ch(s12[4][0].data);
                            [2, 4, 5, 6, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 22].forEach(function(r15) {
                              if (null == (n13 = o12[r15]) ? void 0 : n13[0]) {
                                var n13, s13 = cy(o12[r15][0].data), i13 = cC({ deps: [p2], location: c11[s13].location, type: c11[s13].type }, c11);
                                cx(e11, s13), ck(e11, i13), u2[s13] = i13;
                                var l3 = cN(a12, c11, s13);
                                if (l3.id = i13, c11[s13].location == c11[p2].location) t14.push(l3);
                                else {
                                  c11[i13].location = c11[s13].location.replace(s13.toString(), i13.toString()), c11[i13].location == c11[s13].location && (c11[i13].location = c11[i13].location.replace(/\.iwa/, "-".concat(i13, ".iwa"))), tr.utils.cfb_add(a12, c11[i13].location, cv(cm([l3])));
                                  var f4 = c11[i13].location.replace(/^Root Entry\//, "").replace(/^Index\//, "").replace(/\.iwa$/, "");
                                  cR(a12, c11, 2, function(e12) {
                                    var t15 = ch(e12.messages[0].data);
                                    cF(t15, i13, f4), cP(t15, c11, p2, i13), e12.messages[0].data = cu(t15);
                                  });
                                }
                                o12[r15][0].data = cE(i13);
                              }
                            });
                            var f3 = ch(o12[1][0].data);
                            null == (n12 = f3[2]) || n12.forEach(function(r15) {
                              var n13 = cy(r15.data), s13 = cC({ deps: [p2], location: c11[n13].location, type: c11[n13].type }, c11);
                              cx(e11, n13), ck(e11, s13), u2[n13] = s13;
                              var i13 = cN(a12, c11, n13);
                              if (i13.id = s13, c11[n13].location == c11[p2].location) t14.push(i13);
                              else {
                                c11[s13].location = c11[n13].location.replace(n13.toString(), s13.toString()), c11[s13].location == c11[n13].location && (c11[s13].location = c11[s13].location.replace(/\.iwa/, "-".concat(s13, ".iwa"))), tr.utils.cfb_add(a12, c11[s13].location, cv(cm([i13])));
                                var o13 = c11[s13].location.replace(/^Root Entry\//, "").replace(/^Index\//, "").replace(/\.iwa$/, "");
                                cR(a12, c11, 2, function(e12) {
                                  var t15 = ch(e12.messages[0].data);
                                  cF(t15, s13, o13), cP(t15, c11, p2, s13), e12.messages[0].data = cu(t15);
                                });
                              }
                              r15.data = cE(s13);
                            }), o12[1][0].data = cu(f3);
                            var h3 = ch(o12[3][0].data);
                            h3[1].forEach(function(t15) {
                              var r15 = ch(t15.data), n13 = cy(r15[2][0].data), s13 = u2[n13];
                              if (!u2[n13]) {
                                s13 = cC({ deps: [p2], location: "", type: c11[n13].type }, c11), c11[s13].location = "Root Entry/Index/Tables/Tile-".concat(s13, ".iwa"), u2[n13] = s13;
                                var i13 = cN(a12, c11, n13);
                                i13.id = s13, cx(e11, n13), ck(e11, s13), tr.utils.cfb_add(a12, "/Index/Tables/Tile-".concat(s13, ".iwa"), cv(cm([i13]))), cR(a12, c11, 2, function(e12) {
                                  var t16 = ch(e12.messages[0].data);
                                  t16[3].push({
                                    type: 2,
                                    data: cu([
                                      [],
                                      [{ type: 0, data: co(s13) }],
                                      [{ type: 2, data: ca("Tables/Tile") }],
                                      [{ type: 2, data: ca("Tables/Tile-".concat(s13)) }],
                                      [{ type: 2, data: new Uint8Array([2, 0, 0]) }],
                                      [{ type: 2, data: new Uint8Array([2, 0, 0]) }],
                                      [],
                                      [],
                                      [],
                                      [],
                                      [{ type: 0, data: co(0) }],
                                      [],
                                      [{ type: 0, data: co(0) }]
                                    ])
                                  }), t16[1] = [{ type: 0, data: co(Math.max(s13 + 1, cf(t16[1][0].data))) }], cP(t16, c11, p2, s13), e12.messages[0].data = cu(t16);
                                });
                              }
                              r15[2][0].data = cE(s13), t15.data = cu(r15);
                            }), o12[3][0].data = cu(h3), s12[4][0].data = cu(o12), e11.messages[0].data = cu(s12);
                          }), o11 = cd(ch((i11 = cN(n11, s11, 1)).messages[0].data)[1], cy)), m2 = n11, g2 = s11, v2 = e10.Sheets[t13], b2 = t13, w2 = o11[r13], T2 = [], cR(m2, g2, w2, function(e11) {
                            var t14 = ch(e11.messages[0].data);
                            t14[1] = [{ type: 2, data: ca(b2) }], T2 = cd(t14[2], cy), e11.messages[0].data = cu(t14);
                          }), y2 = cy(ch(cN(m2, g2, T2[0]).messages[0].data)[2][0].data), cR(m2, g2, y2, function(e11, t14) {
                            return (function(e12, t15, r14, a13, n12, s12) {
                              if (!r14["!ref"]) throw Error("Cannot export empty sheet to NUMBERS");
                              var i12, o12 = aw(r14["!ref"]);
                              o12.s.r = o12.s.c = 0;
                              var c12 = false;
                              o12.e.c > 999 && (c12 = true, o12.e.c = 999), o12.e.r > 999999 && (c12 = true, o12.e.r = 999999), c12 && console.error("Truncating to ".concat(aT(o12)));
                              var l3 = [];
                              if (r14["!data"]) l3 = r14["!data"];
                              else {
                                for (var f3 = [], h3 = 0; h3 <= o12.e.c; ++h3) f3[h3] = ag(h3);
                                for (var u3 = 0; u3 <= o12.e.r; ++u3) {
                                  l3[u3] = [];
                                  var d3 = "" + (u3 + 1);
                                  for (h3 = 0; h3 <= o12.e.c; ++h3) {
                                    var p3 = r14[f3[h3] + d3];
                                    p3 && (l3[u3][h3] = p3);
                                  }
                                }
                              }
                              var m3 = {
                                cmnt: [
                                  {
                                    a: "~54ee77S~",
                                    t: "... the people who are crazy enough to think they can change the world, are the ones who do."
                                  }
                                ],
                                ferr: [],
                                fmla: [],
                                nfmt: [],
                                ofmt: [],
                                rsst: [{ v: "~54ee77S~", l: "https://sheetjs.com/" }],
                                sst: ["~Sh33tJ5~"]
                              }, g3 = ch(a13.messages[0].data);
                              g3[6][0].data = co(o12.e.r + 1), g3[7][0].data = co(o12.e.c + 1), delete g3[46];
                              var v3 = ch(g3[4][0].data);
                              cR(e12, t15, cy(ch(v3[1][0].data)[2][0].data), function(e13, t16) {
                                var r15, a14 = ch(e13.messages[0].data);
                                if (null == (r15 = null == a14 ? void 0 : a14[2]) ? void 0 : r15[0])
                                  for (var n13 = 0; n13 < l3.length; ++n13) {
                                    var s13 = ch(a14[2][0].data);
                                    s13[1][0].data = co(n13), s13[4][0].data = co(l3[n13].length), a14[2][n13] = { type: a14[2][0].type, data: cu(s13) };
                                  }
                                e13.messages[0].data = cu(a14);
                              }), cR(e12, t15, cy(v3[2][0].data), function(e13, t16) {
                                for (var r15 = ch(e13.messages[0].data), a14 = 0; a14 <= o12.e.c; ++a14) {
                                  var n13 = ch(r15[2][0].data);
                                  n13[1][0].data = co(a14), n13[4][0].data = co(o12.e.r + 1), r15[2][a14] = { type: r15[2][0].type, data: cu(n13) };
                                }
                                e13.messages[0].data = cu(r15);
                              });
                              var b3 = ch(v3[9][0].data);
                              b3[1] = [];
                              var w3 = ch(v3[3][0].data);
                              w3[2] = [{ type: 0, data: co(256) }];
                              var T3 = cy(ch(w3[1][0].data)[2][0].data), y3 = (null == (i12 = ch(cN(e12, t15, 2).messages[0].data)[3].filter(function(e13) {
                                return cf(ch(e13.data)[1][0].data) == T3;
                              })) ? void 0 : i12.length) ? cf(ch(i12[0].data)[12][0].data) : 0;
                              tr.utils.cfb_del(e12, t15[T3].location), cR(e12, t15, 2, function(e13) {
                                var r15, a14, n13, i13 = ch(e13.messages[0].data);
                                i13[3] = i13[3].filter(function(e14) {
                                  return cf(ch(e14.data)[1][0].data) != T3;
                                }), r15 = t15[s12].location.replace(/^Root Entry\//, "").replace(/^Index\//, "").replace(/\.iwa$/, ""), a14 = i13[3].findIndex(function(e14) {
                                  var t16, a15, n14 = ch(e14.data);
                                  return (null == (t16 = n14[3]) ? void 0 : t16[0]) ? cr(n14[3][0].data) == r15 : null != (a15 = n14[2]) && !!a15[0] && cr(n14[2][0].data) == r15;
                                }), (n13 = ch(i13[3][a14].data))[6] || (n13[6] = []), n13[6] = n13[6].filter(function(e14) {
                                  return cf(ch(e14.data)[1][0].data) != T3;
                                }), i13[3][a14].data = cu(n13), e13.messages[0].data = cu(i13);
                              }), cx(a13, T3), w3[1] = [];
                              for (var E2 = Math.ceil((o12.e.r + 1) / 256), k2 = 0; k2 < E2; ++k2) {
                                var x2 = cC({ deps: [], location: "", type: 6002 }, t15);
                                t15[x2].location = "Root Entry/Index/Tables/Tile-".concat(x2, ".iwa");
                                for (var _2 = [
                                  [],
                                  [{ type: 0, data: co(0) }],
                                  [{ type: 0, data: co(Math.min(o12.e.r + 1, (k2 + 1) * 256)) }],
                                  [{ type: 0, data: co(0) }],
                                  [{ type: 0, data: co(Math.min((k2 + 1) * 256, o12.e.r + 1) - 256 * k2) }],
                                  [],
                                  [{ type: 0, data: co(5) }],
                                  [{ type: 0, data: co(1) }],
                                  [{ type: 0, data: co(1) }]
                                ], S2 = 256 * k2; S2 <= Math.min(o12.e.r, (k2 + 1) * 256 - 1); ++S2) {
                                  var A2 = (function(e13, t16, r15) {
                                    var a14, n13, s13, i13, o13, c13 = [
                                      [],
                                      [{ type: 0, data: co(0) }],
                                      [{ type: 0, data: co(0) }],
                                      [{ type: 2, data: new Uint8Array([]) }],
                                      [
                                        {
                                          type: 2,
                                          data: new Uint8Array(
                                            Array.from({ length: 510 }, function() {
                                              return 255;
                                            })
                                          )
                                        }
                                      ],
                                      [{ type: 0, data: co(5) }],
                                      [{ type: 2, data: new Uint8Array([]) }],
                                      [
                                        {
                                          type: 2,
                                          data: new Uint8Array(
                                            Array.from({ length: 510 }, function() {
                                              return 255;
                                            })
                                          )
                                        }
                                      ],
                                      [{ type: 0, data: co(1) }]
                                    ];
                                    if (!(null == (a14 = c13[6]) ? void 0 : a14[0]) || !(null == (n13 = c13[7]) ? void 0 : n13[0]))
                                      throw "Mutation only works on post-BNC storages!";
                                    var l4 = 0;
                                    if (c13[7][0].data.length < 2 * e13.length) {
                                      var f4 = new Uint8Array(2 * e13.length);
                                      f4.set(c13[7][0].data), c13[7][0].data = f4;
                                    }
                                    if (c13[4][0].data.length < 2 * e13.length) {
                                      var h4 = new Uint8Array(2 * e13.length);
                                      h4.set(c13[4][0].data), c13[4][0].data = h4;
                                    }
                                    for (var u4 = ct(c13[7][0].data), d4 = 0, p4 = [], m4 = ct(c13[4][0].data), g4 = 0, v4 = [], b4 = r15 ? 4 : 1, w4 = 0; w4 < e13.length; ++w4) {
                                      if (null == e13[w4] || "z" == e13[w4].t && !(null == (s13 = e13[w4].c) ? void 0 : s13.length) || "e" == e13[w4].t) {
                                        u4.setUint16(2 * w4, 65535, true), m4.setUint16(2 * w4, 65535);
                                        continue;
                                      }
                                      switch (u4.setUint16(2 * w4, d4 / b4, true), m4.setUint16(2 * w4, g4 / b4, true), e13[w4].t) {
                                        case "d":
                                          if (e13[w4].v instanceof Date) {
                                            i13 = cw(e13[w4], t16), o13 = cT(e13[w4], t16);
                                            break;
                                          }
                                          i13 = cw(e13[w4], t16), o13 = cT(e13[w4], t16);
                                          break;
                                        case "s":
                                        case "n":
                                        case "b":
                                        case "z":
                                          i13 = cw(e13[w4], t16), o13 = cT(e13[w4], t16);
                                          break;
                                        default:
                                          throw Error("Unsupported value " + e13[w4]);
                                      }
                                      p4.push(i13), d4 += i13.length, v4.push(o13), g4 += o13.length, ++l4;
                                    }
                                    for (c13[2][0].data = co(l4), c13[5][0].data = co(5); w4 < c13[7][0].data.length / 2; ++w4)
                                      u4.setUint16(2 * w4, 65535, true), m4.setUint16(2 * w4, 65535, true);
                                    return c13[6][0].data = cn(p4), c13[3][0].data = cn(v4), c13[8] = [{ type: 0, data: co(+!!r15) }], c13;
                                  })(l3[S2], m3, true);
                                  A2[1][0].data = co(S2 - 256 * k2), _2[5].push({ data: cu(A2), type: 2 });
                                }
                                w3[1].push({
                                  type: 2,
                                  data: cu([[], [{ type: 0, data: co(k2) }], [{ type: 2, data: cE(x2) }]])
                                });
                                var C2 = cv(cm([{ id: x2, messages: [cA(6002, cu(_2))] }]));
                                tr.utils.cfb_add(e12, "/Index/Tables/Tile-".concat(x2, ".iwa"), C2), cR(e12, t15, 2, function(e13) {
                                  var r15 = ch(e13.messages[0].data);
                                  r15[3].push({
                                    type: 2,
                                    data: cu([
                                      [],
                                      [{ type: 0, data: co(x2) }],
                                      [{ type: 2, data: ca("Tables/Tile") }],
                                      [{ type: 2, data: ca("Tables/Tile-".concat(x2)) }],
                                      [{ type: 2, data: new Uint8Array([2, 0, 0]) }],
                                      [{ type: 2, data: new Uint8Array([2, 0, 0]) }],
                                      [],
                                      [],
                                      [],
                                      [],
                                      [{ type: 0, data: co(0) }],
                                      [],
                                      [{ type: 0, data: co(y3) }]
                                    ])
                                  }), r15[1] = [{ type: 0, data: co(Math.max(x2 + 1, cf(r15[1][0].data))) }], cP(r15, t15, s12, x2), e13.messages[0].data = cu(r15);
                                }), ck(a13, x2), b3[1].push({
                                  type: 2,
                                  data: cu([[], [{ type: 0, data: co(256 * k2) }], [{ type: 0, data: co(k2) }]])
                                });
                              }
                              if (v3[3][0].data = cu(w3), v3[9][0].data = cu(b3), v3[10] = [{ type: 2, data: new Uint8Array([]) }], r14["!merges"]) {
                                var I2 = cC({ type: 6144, deps: [s12], location: t15[s12].location }, t15);
                                n12.push({
                                  id: I2,
                                  messages: [
                                    cA(
                                      6144,
                                      cu([
                                        [],
                                        r14["!merges"].map(function(e13) {
                                          return {
                                            type: 2,
                                            data: cu([
                                              [],
                                              [
                                                {
                                                  type: 2,
                                                  data: cu([
                                                    [],
                                                    [
                                                      {
                                                        type: 5,
                                                        data: new Uint8Array(
                                                          new Uint16Array([e13.s.r, e13.s.c]).buffer
                                                        )
                                                      }
                                                    ]
                                                  ])
                                                }
                                              ],
                                              [
                                                {
                                                  type: 2,
                                                  data: cu([
                                                    [],
                                                    [
                                                      {
                                                        type: 5,
                                                        data: new Uint8Array(
                                                          new Uint16Array([e13.e.r - e13.s.r + 1, e13.e.c - e13.s.c + 1]).buffer
                                                        )
                                                      }
                                                    ]
                                                  ])
                                                }
                                              ]
                                            ])
                                          };
                                        })
                                      ])
                                    )
                                  ]
                                }), v3[13] = [{ type: 2, data: cE(I2) }], cR(e12, t15, 2, function(e13) {
                                  var r15 = ch(e13.messages[0].data);
                                  cP(r15, t15, s12, I2), e13.messages[0].data = cu(r15);
                                }), ck(a13, I2);
                              } else delete v3[13];
                              cR(e12, t15, cy(v3[4][0].data), function(e13) {
                                var t16 = ch(e13.messages[0].data);
                                t16[3] = [], m3.sst.forEach(function(e14, r15) {
                                  0 != r15 && t16[3].push({
                                    type: 2,
                                    data: cu([
                                      [],
                                      [{ type: 0, data: co(r15) }],
                                      [{ type: 0, data: co(1) }],
                                      [{ type: 2, data: ca(e14) }]
                                    ])
                                  });
                                }), e13.messages[0].data = cu(t16);
                              });
                              var O2 = cy(v3[17][0].data);
                              if (cR(e12, t15, O2, function(r15) {
                                var a14 = ch(r15.messages[0].data);
                                a14[3] = [];
                                var n13 = [904980, 903835, 903815, 903845];
                                m3.rsst.forEach(function(s13, i13) {
                                  if (0 != i13) {
                                    var o13 = [
                                      [],
                                      [{ type: 0, data: new Uint8Array([5]) }],
                                      [],
                                      [{ type: 2, data: ca(s13.v) }]
                                    ];
                                    o13[10] = [{ type: 0, data: new Uint8Array([1]) }], o13[19] = [
                                      { type: 2, data: new Uint8Array([10, 6, 8, 0, 18, 2, 101, 110]) }
                                    ], o13[5] = [
                                      {
                                        type: 2,
                                        data: new Uint8Array([10, 8, 8, 0, 18, 4, 8, 155, 149, 55])
                                      }
                                    ], o13[2] = [{ type: 2, data: new Uint8Array([8, 148, 158, 55]) }], o13[6] = [{ type: 2, data: new Uint8Array([10, 6, 8, 0, 16, 0, 24, 0]) }], o13[7] = [
                                      {
                                        type: 2,
                                        data: new Uint8Array([10, 8, 8, 0, 18, 4, 8, 135, 149, 55])
                                      }
                                    ], o13[8] = [
                                      {
                                        type: 2,
                                        data: new Uint8Array([10, 8, 8, 0, 18, 4, 8, 165, 149, 55])
                                      }
                                    ], o13[14] = [
                                      { type: 2, data: new Uint8Array([10, 6, 8, 0, 16, 0, 24, 0]) }
                                    ], o13[24] = [
                                      { type: 2, data: new Uint8Array([10, 6, 8, 0, 16, 0, 24, 0]) }
                                    ];
                                    var c13 = cC({ deps: [], location: "", type: 2001 }, t15), l4 = [];
                                    if (s13.l) {
                                      var f4 = cD(
                                        e12,
                                        2032,
                                        [[], [], [{ type: 2, data: ca(s13.l) }]],
                                        "/Index/Tables/DataList",
                                        t15
                                      );
                                      o13[11] = [];
                                      var h4 = [[], []];
                                      h4[1] || (h4[1] = []), h4[1].push({
                                        type: 2,
                                        data: cu([
                                          [],
                                          [{ type: 0, data: co(0) }],
                                          [{ type: 2, data: cE(f4) }]
                                        ])
                                      }), o13[11][0] = { type: 2, data: cu(h4) }, l4.push(f4);
                                    }
                                    cD(e12, 2001, o13, "/Index/Tables/DataList", t15, c13), cR(e12, t15, c13, function(e13) {
                                      n13.forEach(function(t16) {
                                        return ck(e13, t16);
                                      }), l4.forEach(function(t16) {
                                        return ck(e13, t16);
                                      });
                                    });
                                    var u4 = cD(
                                      e12,
                                      6218,
                                      [
                                        [],
                                        [{ type: 2, data: cE(c13) }],
                                        [],
                                        [
                                          {
                                            type: 2,
                                            data: new Uint8Array([
                                              13,
                                              255,
                                              255,
                                              255,
                                              0,
                                              18,
                                              10,
                                              16,
                                              255,
                                              255,
                                              1,
                                              24,
                                              255,
                                              255,
                                              255,
                                              255,
                                              7
                                            ])
                                          }
                                        ]
                                      ],
                                      "/Index/Tables/DataList",
                                      t15
                                    );
                                    cR(e12, t15, u4, function(e13) {
                                      return ck(e13, c13);
                                    }), a14[3].push({
                                      type: 2,
                                      data: cu([
                                        [],
                                        [{ type: 0, data: co(i13) }],
                                        [{ type: 0, data: co(1) }],
                                        [],
                                        [],
                                        [],
                                        [],
                                        [],
                                        [],
                                        [{ type: 2, data: cE(u4) }]
                                      ])
                                    }), ck(r15, u4), cR(e12, t15, 2, function(e13) {
                                      var r16 = ch(e13.messages[0].data);
                                      cP(r16, t15, O2, u4), cP(r16, t15, u4, c13), cP(r16, t15, c13, l4), cP(r16, t15, c13, n13), e13.messages[0].data = cu(r16);
                                    });
                                  }
                                }), r15.messages[0].data = cu(a14);
                              }), m3.cmnt.length > 1) {
                                var R2 = cy(v3[19][0].data), N2 = {}, F2 = 0;
                                cR(e12, t15, R2, function(r15) {
                                  var a14 = ch(r15.messages[0].data);
                                  a14[3] = [], m3.cmnt.forEach(function(n13, s13) {
                                    if (0 != s13) {
                                      var i13 = [];
                                      n13.replies && n13.replies.forEach(function(r16) {
                                        N2[r16.a || ""] || (N2[r16.a || ""] = cD(
                                          e12,
                                          212,
                                          [
                                            [],
                                            [{ type: 2, data: ca(r16.a || "") }],
                                            [{ type: 2, data: cO(++F2) }],
                                            [],
                                            [{ type: 0, data: co(0) }]
                                          ],
                                          "/Index/Tables/DataList",
                                          t15
                                        ));
                                        var a15 = N2[r16.a || ""], n14 = cD(
                                          e12,
                                          3056,
                                          [
                                            [],
                                            [{ type: 2, data: ca(r16.t || "") }],
                                            [
                                              {
                                                type: 2,
                                                data: cu([
                                                  [],
                                                  [
                                                    {
                                                      type: 1,
                                                      data: new Uint8Array([
                                                        0,
                                                        0,
                                                        0,
                                                        128,
                                                        116,
                                                        109,
                                                        182,
                                                        65
                                                      ])
                                                    }
                                                  ]
                                                ])
                                              }
                                            ],
                                            [{ type: 2, data: cE(a15) }]
                                          ],
                                          "/Index/Tables/DataList",
                                          t15
                                        );
                                        cR(e12, t15, n14, function(e13) {
                                          return ck(e13, a15);
                                        }), i13.push(n14), cR(e12, t15, 2, function(e13) {
                                          var r17 = ch(e13.messages[0].data);
                                          cP(r17, t15, n14, a15), e13.messages[0].data = cu(r17);
                                        });
                                      }), N2[n13.a || ""] || (N2[n13.a || ""] = cD(
                                        e12,
                                        212,
                                        [
                                          [],
                                          [{ type: 2, data: ca(n13.a || "") }],
                                          [{ type: 2, data: cO(++F2) }],
                                          [],
                                          [{ type: 0, data: co(0) }]
                                        ],
                                        "/Index/Tables/DataList",
                                        t15
                                      ));
                                      var o13 = N2[n13.a || ""], c13 = cD(
                                        e12,
                                        3056,
                                        [
                                          [],
                                          [{ type: 2, data: ca(n13.t || "") }],
                                          [
                                            {
                                              type: 2,
                                              data: cu([
                                                [],
                                                [
                                                  {
                                                    type: 1,
                                                    data: new Uint8Array([0, 0, 0, 128, 116, 109, 182, 65])
                                                  }
                                                ]
                                              ])
                                            }
                                          ],
                                          [{ type: 2, data: cE(o13) }],
                                          i13.map(function(e13) {
                                            return { type: 2, data: cE(e13) };
                                          }),
                                          [
                                            {
                                              type: 2,
                                              data: cu([
                                                [],
                                                [{ type: 0, data: co(s13) }],
                                                [{ type: 0, data: co(0) }]
                                              ])
                                            }
                                          ]
                                        ],
                                        "/Index/Tables/DataList",
                                        t15
                                      );
                                      cR(e12, t15, c13, function(e13) {
                                        ck(e13, o13), i13.forEach(function(t16) {
                                          return ck(e13, t16);
                                        });
                                      }), a14[3].push({
                                        type: 2,
                                        data: cu([
                                          [],
                                          [{ type: 0, data: co(s13) }],
                                          [{ type: 0, data: co(1) }],
                                          [],
                                          [],
                                          [],
                                          [],
                                          [],
                                          [],
                                          [],
                                          [{ type: 2, data: cE(c13) }]
                                        ])
                                      }), ck(r15, c13), cR(e12, t15, 2, function(e13) {
                                        var r16 = ch(e13.messages[0].data);
                                        cP(r16, t15, R2, c13), cP(r16, t15, c13, o13), i13.length && cP(r16, t15, c13, i13), e13.messages[0].data = cu(r16);
                                      });
                                    }
                                  }), a14[2][0].data = co(m3.cmnt.length + 1), r15.messages[0].data = cu(a14);
                                });
                              }
                              g3[4][0].data = cu(v3), a13.messages[0].data = cu(g3);
                            })(m2, g2, v2, e11, t14, y2);
                          });
                        }), n11;
                      })(t11, r11);
                    case "xlsb":
                      return (function(t12, r12) {
                        t12 && !t12.SSF && (t12.SSF = tw(eD)), t12 && t12.SSF && (e5(), e3(t12.SSF), r12.revssf = tc(t12.SSF), r12.revssf[t12.SSF[65535]] = 0, r12.ssf = t12.SSF), r12.rels = {}, r12.wbrels = {}, r12.Strings = [], r12.Strings.Count = 0, r12.Strings.Unique = 0, iJ ? r12.revStrings = /* @__PURE__ */ new Map() : (r12.revStrings = {}, r12.revStrings.foo = [], delete r12.revStrings.foo);
                        var a11, n11, s11, i11, o11, c11 = a3();
                        cU(r12 = r12 || {});
                        var l2 = tK(), f2 = "", h2 = 0;
                        if (r12.cellXfs = [], i1(r12.cellXfs, {}, { revssf: { General: 0 } }), t12.Props || (t12.Props = {}), tj(l2, f2 = "docProps/core.xml", nk(t12.Props, r12)), c11.coreprops.push(f2), nv(r12.rels, 2, f2, ne), f2 = "docProps/app.xml", t12.Props && t12.Props.SheetNames) ;
                        else if (t12.Workbook && t12.Workbook.Sheets) {
                          for (var u2 = [], d2 = 0; d2 < t12.SheetNames.length; ++d2)
                            2 != (t12.Workbook.Sheets[d2] || {}).Hidden && u2.push(t12.SheetNames[d2]);
                          t12.Props.SheetNames = u2;
                        } else t12.Props.SheetNames = t12.SheetNames;
                        t12.Props.Worksheets = t12.Props.SheetNames.length, tj(l2, f2, nA(t12.Props, r12)), c11.extprops.push(f2), nv(r12.rels, 3, f2, nt), t12.Custprops !== t12.Props && ts(t12.Custprops || {}).length > 0 && (tj(l2, f2 = "docProps/custom.xml", nI(t12.Custprops, r12)), c11.custprops.push(f2), nv(r12.rels, 4, f2, nr));
                        var p2 = ["SheetJ5"];
                        for (h2 = 1, r12.tcid = 0; h2 <= t12.SheetNames.length; ++h2) {
                          var m2 = { "!id": {} }, g2 = t12.Sheets[t12.SheetNames[h2 - 1]];
                          if ((g2 || {})["!type"], tj(
                            l2,
                            f2 = "xl/worksheets/sheet" + h2 + ".bin",
                            (function(e10, t13, r13, a12) {
                              var n12, s12, i12, o12, c12, l3, f3, h3, u3, d3 = ao(), p3 = r13.SheetNames[e10], m3 = r13.Sheets[p3] || {}, g3 = p3;
                              try {
                                r13 && r13.Workbook && (g3 = r13.Workbook.Sheets[e10].CodeName || g3);
                              } catch (e11) {
                              }
                              var v3 = ak(m3["!ref"] || "A1");
                              if (v3.e.c > 16383 || v3.e.r > 1048575) {
                                if (t13.WTF)
                                  throw Error(
                                    "Range " + (m3["!ref"] || "A1") + " exceeds format limit A1:XFD1048576"
                                  );
                                v3.e.c = Math.min(v3.e.c, 16383), v3.e.r = Math.min(v3.e.c, 1048575);
                              }
                              m3["!links"] = [], m3["!comments"] = [], ac(d3, 129), (r13.vbaraw || m3["!outline"]) && ac(
                                d3,
                                147,
                                (function(e11, t14, r14) {
                                  null == r14 && (r14 = as(84 + 4 * e11.length));
                                  var a13 = 192;
                                  t14 && (t14.above && (a13 &= -65), t14.left && (a13 &= -129)), r14.write_shift(1, a13);
                                  for (var n13 = 1; n13 < 3; ++n13) r14.write_shift(1, 0);
                                  return aG({ auto: 1 }, r14), r14.write_shift(-4, -1), r14.write_shift(-4, -1), aR(e11, r14), r14.slice(0, r14.l);
                                })(g3, m3["!outline"])
                              ), ac(d3, 148, aH(v3)), n12 = r13.Workbook, ac(d3, 133), ac(
                                d3,
                                137,
                                (null == s12 && (s12 = as(30)), i12 = 924, (((n12 || {}).Views || [])[0] || {}).RTL && (i12 |= 32), s12.write_shift(2, i12), s12.write_shift(4, 0), s12.write_shift(4, 0), s12.write_shift(4, 0), s12.write_shift(1, 0), s12.write_shift(1, 0), s12.write_shift(2, 0), s12.write_shift(2, 100), s12.write_shift(2, 0), s12.write_shift(2, 0), s12.write_shift(2, 0), s12.write_shift(4, 0), s12)
                              ), ac(d3, 138), ac(d3, 134), m3 && m3["!cols"] && (ac(d3, 390), m3["!cols"].forEach(function(e11, t14) {
                                var r14, a13, n13;
                                e11 && ac(
                                  d3,
                                  60,
                                  (null == r14 && (r14 = as(18)), a13 = iQ(t14, e11), r14.write_shift(-4, t14), r14.write_shift(-4, t14), r14.write_shift(4, 256 * (a13.width || 10)), r14.write_shift(4, 0), n13 = 0, e11.hidden && (n13 |= 1), "number" == typeof a13.width && (n13 |= 2), e11.level && (n13 |= e11.level << 8), r14.write_shift(2, n13), r14)
                                );
                              }), ac(d3, 391)), (function(e11, t14, r14, a13, n13) {
                                var s13 = ak(t14["!ref"] || "A1"), i13 = "", o13 = [], c13 = (((n13 || {}).Workbook || {}).WBProps || {}).date1904;
                                ac(e11, 145);
                                var l4 = null != t14["!data"], f4 = l4 ? t14["!data"][s13.s.r] : [], h4 = s13.e.r;
                                t14["!rows"] && (h4 = Math.max(s13.e.r, t14["!rows"].length - 1));
                                for (var u4 = s13.s.r; u4 <= h4; ++u4)
                                  if (i13 = ap(u4), l4 && (f4 = t14["!data"][u4]), !(function(e12, t15, r15, a14) {
                                    var n14 = (function(e13, t16, r16) {
                                      var a15 = as(145), n15 = (r16["!rows"] || [])[e13] || {};
                                      a15.write_shift(4, e13), a15.write_shift(4, 0);
                                      var s14 = 320;
                                      n15.hpx ? s14 = 20 * s1(n15.hpx) : n15.hpt && (s14 = 20 * n15.hpt), a15.write_shift(2, s14), a15.write_shift(1, 0);
                                      var i14 = 0;
                                      n15.level && (i14 |= n15.level), n15.hidden && (i14 |= 16), (n15.hpx || n15.hpt) && (i14 |= 32), a15.write_shift(1, i14), a15.write_shift(1, 0);
                                      var o14 = 0, c14 = a15.l;
                                      a15.l += 4;
                                      for (var l5 = { r: e13, c: 0 }, f5 = null != r16["!data"], h5 = 0; h5 < 16; ++h5)
                                        if (!(t16.s.c > h5 + 1 << 10) && !(t16.e.c < h5 << 10)) {
                                          for (var u5 = -1, d5 = -1, p5 = h5 << 10; p5 < h5 + 1 << 10; ++p5)
                                            l5.c = p5, (f5 ? (r16["!data"][l5.r] || [])[l5.c] : r16[ab(l5)]) && (u5 < 0 && (u5 = p5), d5 = p5);
                                          u5 < 0 || (++o14, a15.write_shift(4, u5), a15.write_shift(4, d5));
                                        }
                                      var m5 = a15.l;
                                      return a15.l = c14, a15.write_shift(4, o14), a15.l = m5, a15.length > a15.l ? a15.slice(0, a15.l) : a15;
                                    })(a14, r15, t15);
                                    (n14.length > 17 || (t15["!rows"] || [])[a14]) && ac(e12, 0, n14);
                                  })(e11, t14, s13, u4), !l4 || f4) {
                                    var d4 = false;
                                    if (u4 <= s13.e.r)
                                      for (var p4 = s13.s.c; p4 <= s13.e.c; ++p4) {
                                        u4 === s13.s.r && (o13[p4] = ag(p4));
                                        var m4 = l4 ? f4[p4] : t14[o13[p4] + i13];
                                        if (!m4) {
                                          d4 = false;
                                          continue;
                                        }
                                        d4 = (function(e12, t15, r15, a14, n14, s14, i14, o14) {
                                          var c14, l5, f5, h5, u5, d5, p5, m5, g4, v4, b4, w3, T3, y2, E2, k2, x2, _2, S2, A2, C2, I2, O2 = { r: r15, c: a14 };
                                          if (t15.c && s14["!comments"].push([ab(O2), t15.c]), void 0 === t15.v)
                                            return false;
                                          var R2 = "";
                                          switch (t15.t) {
                                            case "b":
                                              R2 = t15.v ? "1" : "0";
                                              break;
                                            case "d":
                                              (t15 = tw(t15)).z = t15.z || eD[14], t15.v = tu(tv(t15.v, o14), o14), t15.t = "n";
                                              break;
                                            case "n":
                                            case "e":
                                              R2 = "" + t15.v;
                                              break;
                                            default:
                                              R2 = t15.v;
                                          }
                                          switch (O2.s = i1(n14.cellXfs, t15, n14), t15.l && s14["!links"].push([ab(O2), t15.l]), t15.t) {
                                            case "s":
                                            case "str":
                                              return n14.bookSST ? (R2 = iq(
                                                n14.Strings,
                                                null == t15.v ? "" : String(t15.v),
                                                n14.revStrings
                                              ), O2.t = "s", O2.v = R2, i14) ? ac(
                                                e12,
                                                18,
                                                (null == c14 && (c14 = as(8)), aL(O2, c14), c14.write_shift(4, O2.v), c14)
                                              ) : ac(
                                                e12,
                                                7,
                                                (null == l5 && (l5 = as(12)), aD(O2, l5), l5.write_shift(4, O2.v), l5)
                                              ) : (O2.t = "str", i14) ? ac(
                                                e12,
                                                17,
                                                (u5 = null == (f5 = t15).v ? "" : String(f5.v), null == h5 && (h5 = as(8 + 4 * u5.length)), aL(O2, h5), aR(u5, h5), h5.length > h5.l ? h5.slice(0, h5.l) : h5)
                                              ) : ac(
                                                e12,
                                                6,
                                                (m5 = null == (d5 = t15).v ? "" : String(d5.v), null == p5 && (p5 = as(12 + 4 * d5.v.length)), aD(O2, p5), aR(m5, p5), p5.length > p5.l ? p5.slice(0, p5.l) : p5)
                                              ), true;
                                            case "n":
                                              return t15.v == (0 | t15.v) && t15.v > -1e3 && t15.v < 1e3 ? i14 ? ac(
                                                e12,
                                                13,
                                                (g4 = t15, null == v4 && (v4 = as(8)), aL(O2, v4), aW(g4.v, v4), v4)
                                              ) : ac(
                                                e12,
                                                2,
                                                (b4 = t15, null == w3 && (w3 = as(12)), aD(O2, w3), aW(b4.v, w3), w3)
                                              ) : isFinite(t15.v) ? i14 ? ac(
                                                e12,
                                                16,
                                                (T3 = t15, null == y2 && (y2 = as(12)), aL(O2, y2), a$(T3.v, y2), y2)
                                              ) : ac(
                                                e12,
                                                5,
                                                (E2 = t15, null == k2 && (k2 = as(16)), aD(O2, k2), a$(E2.v, k2), k2)
                                              ) : (O2.t = "e", isNaN(t15.v) ? i14 ? ac(e12, 14, oi({ t: "e", v: 36 }, O2)) : ac(e12, 3, os({ t: "e", v: 36 }, O2)) : i14 ? ac(e12, 14, oi({ t: "e", v: 7 }, O2)) : ac(e12, 3, os({ t: "e", v: 7 }, O2))), true;
                                            case "b":
                                              return (O2.t = "b", i14) ? ac(
                                                e12,
                                                15,
                                                (x2 = t15, null == _2 && (_2 = as(5)), aL(O2, _2), _2.write_shift(1, +!!x2.v), _2)
                                              ) : ac(
                                                e12,
                                                4,
                                                (S2 = t15, null == A2 && (A2 = as(9)), aD(O2, A2), A2.write_shift(1, +!!S2.v), A2)
                                              ), true;
                                            case "e":
                                              return O2.t = "e", i14 ? ac(e12, 14, oi(t15, O2)) : ac(e12, 3, os(t15, O2)), true;
                                          }
                                          return i14 ? ac(e12, 12, (null == C2 && (C2 = as(4)), aL(O2, C2))) : ac(e12, 1, (null == I2 && (I2 = as(8)), aD(O2, I2))), true;
                                        })(e11, m4, u4, p4, a13, t14, d4, c13);
                                      }
                                  }
                                ac(e11, 146);
                              })(d3, m3, 0, t13, r13);
                              m3["!protect"] && ac(
                                d3,
                                535,
                                (o12 = m3["!protect"], null == c12 && (c12 = as(66)), c12.write_shift(2, o12.password ? sz(o12.password) : 0), c12.write_shift(4, 1), [
                                  ["objects", false],
                                  ["scenarios", false],
                                  ["formatCells", true],
                                  ["formatColumns", true],
                                  ["formatRows", true],
                                  ["insertColumns", true],
                                  ["insertRows", true],
                                  ["insertHyperlinks", true],
                                  ["deleteColumns", true],
                                  ["deleteRows", true],
                                  ["selectLockedCells", false],
                                  ["sort", true],
                                  ["autoFilter", true],
                                  ["pivotTables", true],
                                  ["selectUnlockedCells", false]
                                ].forEach(function(e11) {
                                  e11[1] ? c12.write_shift(4, +(null != o12[e11[0]] && !o12[e11[0]])) : c12.write_shift(4, null != o12[e11[0]] && o12[e11[0]] ? 0 : 1);
                                }), c12)
                              ), !(function(e11, t14, r14, a13) {
                                if (t14["!autofilter"]) {
                                  var n13 = t14["!autofilter"], s13 = "string" == typeof n13.ref ? n13.ref : aT(n13.ref);
                                  r14.Workbook || (r14.Workbook = { Sheets: [] }), r14.Workbook.Names || (r14.Workbook.Names = []);
                                  var i13 = r14.Workbook.Names, o13 = aw(s13);
                                  o13.s.r == o13.e.r && (o13.e.r = aw(t14["!ref"]).e.r, s13 = aT(o13));
                                  for (var c13 = 0; c13 < i13.length; ++c13) {
                                    var l4 = i13[c13];
                                    if ("_xlnm._FilterDatabase" == l4.Name && l4.Sheet == a13) {
                                      l4.Ref = aE(r14.SheetNames[a13]) + "!" + ay(s13);
                                      break;
                                    }
                                  }
                                  c13 == i13.length && i13.push({
                                    Name: "_xlnm._FilterDatabase",
                                    Sheet: a13,
                                    Ref: aE(r14.SheetNames[a13]) + "!" + ay(s13)
                                  }), ac(e11, 161, aH(ak(s13))), ac(e11, 162);
                                }
                              })(d3, m3, r13, e10);
                              m3 && m3["!merges"] && (ac(
                                d3,
                                177,
                                (l3 = m3["!merges"].length, null == f3 && (f3 = as(4)), f3.write_shift(4, l3), f3)
                              ), m3["!merges"].forEach(function(e11) {
                                ac(d3, 176, aH(e11));
                              }), ac(d3, 178)), m3["!links"].forEach(function(e11) {
                                if (e11[1].Target) {
                                  var t14, r14, n13 = nv(a12, -1, e11[1].Target.replace(/#[\s\S]*$/, ""), a8);
                                  ac(
                                    d3,
                                    494,
                                    (t14 = as(50 + 4 * (e11[1].Target.length + (e11[1].Tooltip || "").length)), aH({ s: av(e11[0]), e: av(e11[0]) }, t14), aU("rId" + n13, t14), aR(
                                      (-1 == (r14 = e11[1].Target.indexOf("#")) ? "" : e11[1].Target.slice(r14 + 1)) || "",
                                      t14
                                    ), aR(e11[1].Tooltip || "", t14), aR("", t14), t14.slice(0, t14.l))
                                  );
                                }
                              }), delete m3["!links"], m3["!margins"] && ac(
                                d3,
                                476,
                                (h3 = m3["!margins"], null == u3 && (u3 = as(48)), i0(h3), oc.forEach(function(e11) {
                                  a$(h3[e11], u3);
                                }), u3)
                              ), (!t13 || t13.ignoreEC || void 0 == t13.ignoreEC) && (function(e11, t14) {
                                if (t14 && t14["!ref"]) {
                                  var r14, a13;
                                  ac(e11, 648), ac(
                                    e11,
                                    649,
                                    (r14 = ak(t14["!ref"]), (a13 = as(24)).write_shift(4, 4), a13.write_shift(4, 1), aH(r14, a13), a13)
                                  ), ac(e11, 650);
                                }
                              })(d3, m3);
                              if (m3["!comments"].length > 0) {
                                var b3 = nv(a12, -1, "../drawings/vmlDrawing" + (e10 + 1) + ".vml", a7);
                                ac(d3, 551, aU("rId" + b3)), m3["!legacy"] = b3;
                              }
                              return ac(d3, 130), d3.end();
                            })(h2 - 1, r12, t12, m2)
                          ), c11.sheets.push(f2), nv(r12.wbrels, -1, "worksheets/sheet" + h2 + ".bin", no[0]), g2) {
                            var v2 = g2["!comments"], b2 = false, w2 = "";
                            if (v2 && v2.length > 0) {
                              var T2 = false;
                              v2.forEach(function(e10) {
                                e10[1].forEach(function(e11) {
                                  true == e11.T && (T2 = true);
                                });
                              }), T2 && (tj(l2, w2 = "xl/threadedComments/threadedComment" + h2 + ".xml", io(v2, p2, r12)), c11.threadedcomments.push(w2), nv(m2, -1, "../threadedComments/threadedComment" + h2 + ".xml", nh)), tj(
                                l2,
                                w2 = "xl/comments" + h2 + ".bin",
                                (function(e10) {
                                  var t13 = ao(), r13 = [];
                                  return ac(t13, 628), ac(t13, 630), e10.forEach(function(e11) {
                                    e11[1].forEach(function(e12) {
                                      !(r13.indexOf(e12.a) > -1) && (r13.push(e12.a.slice(0, 54)), ac(t13, 632, il(e12.a)), e12.T && e12.ID && -1 == r13.indexOf("tc=" + e12.ID) && (r13.push("tc=" + e12.ID), ac(t13, 632, il("tc=" + e12.ID))));
                                    });
                                  }), ac(t13, 631), ac(t13, 633), e10.forEach(function(e11) {
                                    e11[1].forEach(function(a12) {
                                      var n12, s12, i12, o12, c12, l3, f3 = -1;
                                      a12.ID && (f3 = r13.indexOf("tc=" + a12.ID)), -1 == f3 && e11[1][0].T && e11[1][0].ID && (f3 = r13.indexOf("tc=" + e11[1][0].ID)), -1 == f3 && (f3 = r13.indexOf(a12.a)), a12.iauthor = f3, ac(
                                        t13,
                                        635,
                                        (n12 = [{ s: av(e11[0]), e: av(e11[0]) }, a12], null == s12 && (s12 = as(36)), s12.write_shift(4, n12[1].iauthor), aH(n12[0], s12), s12.write_shift(4, 0), s12.write_shift(4, 0), s12.write_shift(4, 0), s12.write_shift(4, 0), s12)
                                      ), a12.t && a12.t.length > 0 && ac(
                                        t13,
                                        637,
                                        (o12 = false, null == i12 && (o12 = true, i12 = as(23 + 4 * a12.t.length)), i12.write_shift(1, 1), aR(a12.t, i12), i12.write_shift(4, 1), c12 = { ich: 0, ifnt: 0 }, (l3 = i12) || (l3 = as(4)), l3.write_shift(2, c12.ich || 0), l3.write_shift(2, c12.ifnt || 0), o12 ? i12.slice(0, i12.l) : i12)
                                      ), ac(t13, 636), delete a12.iauthor;
                                    });
                                  }), ac(t13, 634), ac(t13, 629), t13.end();
                                })(v2, r12)
                              ), c11.comments.push(w2), nv(m2, -1, "../comments" + h2 + ".bin", a9), b2 = true;
                            }
                            g2["!legacy"] && b2 && tj(l2, "xl/drawings/vmlDrawing" + h2 + ".vml", is(h2, g2["!comments"])), delete g2["!comments"], delete g2["!legacy"];
                          }
                          m2["!id"].rId1 && tj(l2, np(f2), ng(m2));
                        }
                        return null != r12.Strings && r12.Strings.length > 0 && (tj(
                          l2,
                          f2 = "xl/sharedStrings.bin",
                          (function(e10) {
                            var t13, r13 = ao();
                            ac(
                              r13,
                              159,
                              (t13 || (t13 = as(8)), t13.write_shift(4, e10.Count), t13.write_shift(4, e10.Unique), t13)
                            );
                            for (var a12 = 0; a12 < e10.length; ++a12) ac(r13, 19, sL(e10[a12]));
                            return ac(r13, 160), r13.end();
                          })(r12.Strings, r12)
                        ), c11.strs.push(f2), nv(r12.wbrels, -1, "sharedStrings.bin", na)), tj(
                          l2,
                          f2 = "xl/workbook.bin",
                          (function(t13, r13) {
                            var a12 = ao();
                            ac(a12, 131), ac(
                              a12,
                              128,
                              (function(t14, r14) {
                                r14 || (r14 = as(127));
                                for (var a13 = 0; 4 != a13; ++a13) r14.write_shift(4, 0);
                                return aR("SheetJS", r14), aR(e2.version, r14), aR(e2.version, r14), aR("7262", r14), r14.length > r14.l ? r14.slice(0, r14.l) : r14;
                              })()
                            ), ac(
                              a12,
                              153,
                              (s12 = t13.Workbook && t13.Workbook.WBProps || null, i12 || (i12 = as(72)), o12 = 0, s12 && (s12.date1904 && (o12 |= 1), s12.filterPrivacy && (o12 |= 8)), i12.write_shift(4, o12), i12.write_shift(4, 0), aR(s12 && s12.CodeName || "ThisWorkbook", i12), i12.slice(0, i12.l))
                            ), (function(e10, t14) {
                              if (t14.Workbook && t14.Workbook.Sheets) {
                                for (var r14, a13, n13 = t14.Workbook.Sheets, s13 = 0, i13 = -1, o13 = -1; s13 < n13.length; ++s13)
                                  n13[s13] && (n13[s13].Hidden || -1 != i13) ? 1 == n13[s13].Hidden && -1 == o13 && (o13 = s13) : i13 = s13;
                                o13 > i13 || (ac(e10, 135), ac(
                                  e10,
                                  158,
                                  (r14 = i13, a13 || (a13 = as(29)), a13.write_shift(-4, 0), a13.write_shift(-4, 460), a13.write_shift(4, 28800), a13.write_shift(4, 17600), a13.write_shift(4, 500), a13.write_shift(4, r14), a13.write_shift(4, r14), a13.write_shift(1, 120), a13.length > a13.l ? a13.slice(0, a13.l) : a13)
                                ), ac(e10, 136));
                              }
                            })(a12, t13, r13);
                            ac(a12, 143);
                            for (var n12 = 0; n12 != t13.SheetNames.length; ++n12) {
                              var s12, i12, o12, c12 = {
                                Hidden: t13.Workbook && t13.Workbook.Sheets && t13.Workbook.Sheets[n12] && t13.Workbook.Sheets[n12].Hidden || 0,
                                iTabID: n12 + 1,
                                strRelID: "rId" + (n12 + 1),
                                name: t13.SheetNames[n12]
                              }, l3 = void 0;
                              ac(
                                a12,
                                156,
                                (l3 || (l3 = as(127)), l3.write_shift(4, c12.Hidden), l3.write_shift(4, c12.iTabID), aU(c12.strRelID, l3), aR(c12.name.slice(0, 31), l3), l3.length > l3.l ? l3.slice(0, l3.l) : l3)
                              );
                            }
                            return ac(a12, 144), ac(a12, 353), ac(a12, 357), ac(
                              a12,
                              362,
                              (function(e10) {
                                var t14 = e10.SheetNames.length, r14 = as(12 * t14 + 28);
                                r14.write_shift(4, t14 + 2), r14.write_shift(4, 0), r14.write_shift(4, -2), r14.write_shift(4, -2), r14.write_shift(4, 0), r14.write_shift(4, -1), r14.write_shift(4, -1);
                                for (var a13 = 0; a13 < t14; ++a13)
                                  r14.write_shift(4, 0), r14.write_shift(4, a13), r14.write_shift(4, a13);
                                return r14;
                              })(t13, 0)
                            ), ac(a12, 354), (t13.Workbook || {}).Names && t13.Workbook && t13.Workbook.Names && t13.Workbook.Names.forEach(function(e10) {
                              try {
                                if (14 & e10.Flags) return;
                                ac(
                                  a12,
                                  39,
                                  (function(e11, t14) {
                                    var r14 = as(9), a13 = 0, n13 = e11.Name;
                                    a1.indexOf(n13) > -1 && (a13 |= 32, n13 = n13.slice(6)), r14.write_shift(4, a13), r14.write_shift(1, 0), r14.write_shift(4, null == e11.Sheet ? 4294967295 : e11.Sheet);
                                    var s13 = [r14, aR(n13), iH(e11.Ref, t14)];
                                    if (e11.Comment) s13.push(aU(e11.Comment));
                                    else {
                                      var i13 = as(4);
                                      i13.write_shift(4, 4294967295), s13.push(i13);
                                    }
                                    return ek(s13);
                                  })(e10, t13)
                                );
                              } catch (t14) {
                                console.error("Could not serialize defined name " + JSON.stringify(e10));
                              }
                            }), ac(a12, 132), a12.end();
                          })(t12, r12)
                        ), c11.workbooks.push(f2), nv(r12.rels, 1, f2, a6), tj(l2, f2 = "xl/theme/theme1.xml", ia(t12.Themes, r12)), c11.themes.push(f2), nv(r12.wbrels, -1, "theme/theme1.xml", ns), tj(
                          l2,
                          f2 = "xl/styles.bin",
                          (function(e10, t13) {
                            var r13, a12, n12, s12, i12, o12 = ao();
                            return ac(o12, 278), (function(e11, t14) {
                              if (t14) {
                                var r14 = 0;
                                [
                                  [5, 8],
                                  [23, 26],
                                  [41, 44],
                                  [50, 392]
                                ].forEach(function(e12) {
                                  for (var a13 = e12[0]; a13 <= e12[1]; ++a13) null != t14[a13] && ++r14;
                                }), 0 != r14 && (ac(e11, 615, aI(r14)), [
                                  [5, 8],
                                  [23, 26],
                                  [41, 44],
                                  [50, 392]
                                ].forEach(function(r15) {
                                  for (var a13 = r15[0]; a13 <= r15[1]; ++a13)
                                    null != t14[a13] && ac(
                                      e11,
                                      44,
                                      (function(e12, t15, r16) {
                                        r16 || (r16 = as(6 + 4 * t15.length)), r16.write_shift(2, e12), aR(t15, r16);
                                        var a14 = r16.length > r16.l ? r16.slice(0, r16.l) : r16;
                                        return null == r16.l && (r16.l = r16.length), a14;
                                      })(a13, t14[a13])
                                    );
                                }), ac(e11, 616));
                              }
                            })(o12, e10.SSF), (function(e11) {
                              var t14, r14, a13, n13, s13, i13;
                              ac(e11, 611, aI(1)), ac(
                                e11,
                                43,
                                (t14 = {
                                  sz: 12,
                                  color: { theme: 1 },
                                  name: "Calibri",
                                  family: 2,
                                  scheme: "minor"
                                }, r14 || (r14 = as(153)), r14.write_shift(2, 20 * t14.sz), (a13 = r14) || (a13 = as(2)), n13 = 2 * !!t14.italic | 8 * !!t14.strike | 16 * !!t14.outline | 32 * !!t14.shadow | 64 * !!t14.condense | 128 * !!t14.extend, a13.write_shift(1, n13), a13.write_shift(1, 0), r14.write_shift(2, t14.bold ? 700 : 400), s13 = 0, "superscript" == t14.vertAlign ? s13 = 1 : "subscript" == t14.vertAlign && (s13 = 2), r14.write_shift(2, s13), r14.write_shift(1, t14.underline || 0), r14.write_shift(1, t14.family || 0), r14.write_shift(1, t14.charset || 0), r14.write_shift(1, 0), aG(t14.color, r14), i13 = 0, "major" == t14.scheme && (i13 = 1), "minor" == t14.scheme && (i13 = 2), r14.write_shift(1, i13), aR(t14.name, r14), r14.length > r14.l ? r14.slice(0, r14.l) : r14)
                              ), ac(e11, 612);
                            })(o12, e10), ac(o12, 603, aI(2)), ac(o12, 45, s7({ patternType: "none" })), ac(o12, 45, s7({ patternType: "gray125" })), ac(o12, 604), ac(o12, 613, aI(1)), ac(
                              o12,
                              46,
                              (r13 || (r13 = as(51)), r13.write_shift(1, 0), ie(null, r13), ie(null, r13), ie(null, r13), ie(null, r13), ie(null, r13), r13.length > r13.l ? r13.slice(0, r13.l) : r13)
                            ), ac(o12, 614), ac(o12, 626, aI(1)), ac(o12, 47, s9({ numFmtId: 0, fontId: 0, fillId: 0, borderId: 0 }, 65535)), ac(o12, 627), ac(o12, 617, aI((a12 = t13.cellXfs).length)), a12.forEach(function(e11) {
                              ac(o12, 47, s9(e11, 0));
                            }), ac(o12, 618), ac(o12, 619, aI(1)), ac(
                              o12,
                              48,
                              (n12 = { xfId: 0, builtinId: 0, name: "Normal" }, s12 || (s12 = as(52)), s12.write_shift(4, n12.xfId), s12.write_shift(2, 1), s12.write_shift(1, +n12.builtinId), s12.write_shift(1, 0), aU(n12.name || "", s12), s12.length > s12.l ? s12.slice(0, s12.l) : s12)
                            ), ac(o12, 620), ac(o12, 505, aI(0)), ac(o12, 506), ac(
                              o12,
                              508,
                              ((i12 = as(2052)).write_shift(4, 0), aU("TableStyleMedium9", i12), aU("PivotStyleMedium4", i12), i12.length > i12.l ? i12.slice(0, i12.l) : i12)
                            ), ac(o12, 509), ac(o12, 279), o12.end();
                          })(t12, r12)
                        ), c11.styles.push(f2), nv(r12.wbrels, -1, "styles.bin", nn), t12.vbaraw && (tj(l2, f2 = "xl/vbaProject.bin", t12.vbaraw), c11.vba.push(f2), nv(r12.wbrels, -1, "vbaProject.bin", nd)), tj(
                          l2,
                          f2 = "xl/metadata.bin",
                          (ac(a11 = ao(), 332), ac(a11, 334, aI(1)), ac(
                            a11,
                            335,
                            ((s11 = as(
                              12 + 2 * (n11 = { name: "XLDAPR", version: 12e4, flags: 3496657072 }).name.length
                            )).write_shift(4, n11.flags), s11.write_shift(4, n11.version), aR(n11.name, s11), s11.slice(0, s11.l))
                          ), ac(a11, 336), ac(a11, 339, ((i11 = as(20)).write_shift(4, 1), aR("XLDAPR", i11), i11.slice(0, i11.l))), ac(a11, 52), ac(a11, 35, aI(514)), ac(a11, 4096, aI(0)), ac(a11, 4097, nj(1)), ac(a11, 36), ac(a11, 53), ac(a11, 340), ac(a11, 337, ((o11 = as(8)).write_shift(4, 1), o11.write_shift(4, 1), o11)), ac(
                            a11,
                            51,
                            (function(e10) {
                              var t13 = as(4 + 8 * e10.length);
                              t13.write_shift(4, e10.length);
                              for (var r13 = 0; r13 < e10.length; ++r13)
                                t13.write_shift(4, e10[r13][0]), t13.write_shift(4, e10[r13][1]);
                              return t13;
                            })([[1, 0]])
                          ), ac(a11, 338), ac(a11, 333), a11.end())
                        ), c11.metadata.push(f2), nv(r12.wbrels, -1, "metadata.bin", nf), p2.length > 1 && (tj(l2, f2 = "xl/persons/person.xml", ic(p2, r12)), c11.people.push(f2), nv(r12.wbrels, -1, "persons/person.xml", nu)), tj(l2, "[Content_Types].xml", a5(c11, r12)), tj(l2, "_rels/.rels", ng(r12.rels)), tj(l2, "xl/_rels/workbook.bin.rels", ng(r12.wbrels)), delete r12.revssf, delete r12.ssf, l2;
                      })(t11, r11);
                    default:
                      return cz(t11, r11);
                  }
                })(t10, n10 = tw(s10 || {})),
                n10
              );
            default:
              throw Error("Unrecognized bookType |" + s10.bookType + "|");
          }
        }
        function cQ(e10) {
          if (!e10.bookType) {
            var t10 = e10.file.slice(e10.file.lastIndexOf(".")).toLowerCase();
            t10.match(/^\.[a-z]+$/) && (e10.bookType = t10.slice(1)), e10.bookType = { xls: "biff8", htm: "html", slk: "sylk", socialcalc: "eth", Sh33tJS: "WTF" }[e10.bookType] || e10.bookType;
          }
        }
        function c0(e10, t10, r10) {
          var a10 = r10 || {};
          return a10.type = "file", a10.file = t10, cQ(a10), cq(e10, a10);
        }
        function c1(e10, t10, r10, a10, n10, s10, i10) {
          var o10 = ap(r10), c10 = i10.defval, l2 = i10.raw || !Object.prototype.hasOwnProperty.call(i10, "raw"), f2 = true, h2 = null != e10["!data"], u2 = 1 === n10 ? [] : {};
          if (1 !== n10)
            if (Object.defineProperty)
              try {
                Object.defineProperty(u2, "__rowNum__", { value: r10, enumerable: false });
              } catch (e11) {
                u2.__rowNum__ = r10;
              }
            else u2.__rowNum__ = r10;
          if (!h2 || e10["!data"][r10])
            for (var d2 = t10.s.c; d2 <= t10.e.c; ++d2) {
              var p2 = h2 ? (e10["!data"][r10] || [])[d2] : e10[a10[d2] + o10];
              if (null == p2 || void 0 === p2.t) {
                if (void 0 === c10) continue;
                null != s10[d2] && (u2[s10[d2]] = c10);
                continue;
              }
              var m2 = p2.v;
              switch (p2.t) {
                case "z":
                  if (null == m2) break;
                  continue;
                case "e":
                  m2 = 0 == m2 ? null : void 0;
                  break;
                case "s":
                case "b":
                case "n":
                  if (!p2.z || !eQ(p2.z) || "number" == typeof (m2 = td(m2))) break;
                case "d":
                  i10 && (i10.UTC || false === i10.raw) || (m2 = tI(new Date(m2)));
                  break;
                default:
                  throw Error("unrecognized type " + p2.t);
              }
              if (null != s10[d2]) {
                if (null == m2)
                  if ("e" == p2.t && null === m2) u2[s10[d2]] = null;
                  else if (void 0 !== c10) u2[s10[d2]] = c10;
                  else {
                    if (!l2 || null !== m2) continue;
                    u2[s10[d2]] = null;
                  }
                else u2[s10[d2]] = ("n" === p2.t && "boolean" == typeof i10.rawNumbers ? i10.rawNumbers : l2) ? m2 : a_(p2, m2, i10);
                null != m2 && (f2 = false);
              }
            }
          return { row: u2, isempty: f2 };
        }
        function c2(e10, t10) {
          if (null == e10 || null == e10["!ref"]) return [];
          var r10 = { t: "n", v: 0 }, a10 = 0, n10 = 1, s10 = [], i10 = 0, o10 = "", c10 = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, l2 = t10 || {}, f2 = null != l2.range ? l2.range : e10["!ref"];
          switch (1 === l2.header ? a10 = 1 : "A" === l2.header ? a10 = 2 : Array.isArray(l2.header) ? a10 = 3 : null == l2.header && (a10 = 0), typeof f2) {
            case "string":
              c10 = ak(f2);
              break;
            case "number":
              (c10 = ak(e10["!ref"])).s.r = f2;
              break;
            default:
              c10 = f2;
          }
          a10 > 0 && (n10 = 0);
          var h2 = ap(c10.s.r), u2 = [], d2 = [], p2 = 0, m2 = 0, g2 = null != e10["!data"], v2 = c10.s.r, b2 = 0, w2 = {};
          g2 && !e10["!data"][v2] && (e10["!data"][v2] = []);
          var T2 = l2.skipHidden && e10["!cols"] || [], y2 = l2.skipHidden && e10["!rows"] || [];
          for (b2 = c10.s.c; b2 <= c10.e.c; ++b2)
            if (!(T2[b2] || {}).hidden)
              switch (u2[b2] = ag(b2), r10 = g2 ? e10["!data"][v2][b2] : e10[u2[b2] + h2], a10) {
                case 1:
                  s10[b2] = b2 - c10.s.c;
                  break;
                case 2:
                  s10[b2] = u2[b2];
                  break;
                case 3:
                  s10[b2] = l2.header[b2 - c10.s.c];
                  break;
                default:
                  if (null == r10 && (r10 = { w: "__EMPTY", t: "s" }), o10 = i10 = a_(r10, null, l2), m2 = w2[i10] || 0) {
                    do
                      o10 = i10 + "_" + m2++;
                    while (w2[o10]);
                    w2[i10] = m2, w2[o10] = 1;
                  } else w2[i10] = 1;
                  s10[b2] = o10;
              }
          for (v2 = c10.s.r + n10; v2 <= c10.e.r; ++v2)
            if (!(y2[v2] || {}).hidden) {
              var E2 = c1(e10, c10, v2, u2, a10, s10, l2);
              (false === E2.isempty || (1 === a10 ? false !== l2.blankrows : l2.blankrows)) && (d2[p2++] = E2.row);
            }
          return d2.length = p2, d2;
        }
        var c4 = /"/g;
        function c3(e10, t10, r10, a10, n10, s10, i10, o10, c10) {
          for (var l2 = true, f2 = [], h2 = "", u2 = ap(r10), d2 = null != e10["!data"], p2 = d2 && e10["!data"][r10] || [], m2 = t10.s.c; m2 <= t10.e.c; ++m2)
            if (a10[m2]) {
              var g2 = d2 ? p2[m2] : e10[a10[m2] + u2];
              if (null == g2) h2 = "";
              else if (null != g2.v) {
                l2 = false, h2 = "" + (c10.rawNumbers && "n" == g2.t ? g2.v : a_(g2, null, c10));
                for (var v2 = 0, b2 = 0; v2 !== h2.length; ++v2)
                  if ((b2 = h2.charCodeAt(v2)) === n10 || b2 === s10 || 34 === b2 || c10.forceQuotes) {
                    h2 = '"' + h2.replace(c4, '""') + '"';
                    break;
                  }
                "ID" == h2 && 0 == o10 && 0 == f2.length && (h2 = '"ID"');
              } else
                null == g2.f || g2.F ? h2 = "" : (l2 = false, (h2 = "=" + g2.f).indexOf(",") >= 0 && (h2 = '"' + h2.replace(c4, '""') + '"'));
              f2.push(h2);
            }
          if (c10.strip) for (; "" === f2[f2.length - 1]; ) --f2.length;
          return false === c10.blankrows && l2 ? null : f2.join(i10);
        }
        function c5(e10, t10) {
          var r10 = [], a10 = null == t10 ? {} : t10;
          if (null == e10 || null == e10["!ref"]) return "";
          for (var n10 = ak(e10["!ref"]), s10 = void 0 !== a10.FS ? a10.FS : ",", i10 = s10.charCodeAt(0), o10 = void 0 !== a10.RS ? a10.RS : "\n", c10 = o10.charCodeAt(0), l2 = "", f2 = [], h2 = a10.skipHidden && e10["!cols"] || [], u2 = a10.skipHidden && e10["!rows"] || [], d2 = n10.s.c; d2 <= n10.e.c; ++d2)
            (h2[d2] || {}).hidden || (f2[d2] = ag(d2));
          for (var p2 = 0, m2 = n10.s.r; m2 <= n10.e.r; ++m2)
            !(u2[m2] || {}).hidden && null != (l2 = c3(e10, n10, m2, f2, i10, c10, s10, p2, a10)) && (l2 || false !== a10.blankrows) && r10.push((p2++ ? o10 : "") + l2);
          return r10.join("");
        }
        function c6(e10, t10) {
          t10 || (t10 = {}), t10.FS = "	", t10.RS = "\n";
          var r10 = c5(e10, t10);
          if (void 0 === G || "string" == t10.type) return r10;
          var a10 = G.utils.encode(1200, r10, "str");
          return String.fromCharCode(255) + String.fromCharCode(254) + a10;
        }
        function c8(e10, t10, r10) {
          var a10 = r10 || {}, n10 = e10 ? null != e10["!data"] : a10.dense, s10 = +!a10.skipHeader, i10 = e10 || {};
          !e10 && n10 && (i10["!data"] = []);
          var o10 = 0, c10 = 0;
          if (i10 && null != a10.origin)
            if ("number" == typeof a10.origin) o10 = a10.origin;
            else {
              var l2 = "string" == typeof a10.origin ? av(a10.origin) : a10.origin;
              o10 = l2.r, c10 = l2.c;
            }
          var f2 = { s: { c: 0, r: 0 }, e: { c: c10, r: o10 + t10.length - 1 + s10 } };
          if (i10["!ref"]) {
            var h2 = ak(i10["!ref"]);
            f2.e.c = Math.max(f2.e.c, h2.e.c), f2.e.r = Math.max(f2.e.r, h2.e.r), -1 == o10 && (o10 = h2.e.r + 1, f2.e.r = o10 + t10.length - 1 + s10);
          } else -1 == o10 && (o10 = 0, f2.e.r = t10.length - 1 + s10);
          var u2 = a10.header || [], d2 = 0, p2 = [];
          t10.forEach(function(e11, t11) {
            n10 && !i10["!data"][o10 + t11 + s10] && (i10["!data"][o10 + t11 + s10] = []), n10 && (p2 = i10["!data"][o10 + t11 + s10]), ts(e11).forEach(function(r11) {
              -1 == (d2 = u2.indexOf(r11)) && (u2[d2 = u2.length] = r11);
              var l3 = e11[r11], f3 = "z", h3 = "", m3 = n10 ? "" : ag(c10 + d2) + ap(o10 + t11 + s10), g2 = n10 ? p2[c10 + d2] : i10[m3];
              !l3 || "object" != typeof l3 || l3 instanceof Date ? ("number" == typeof l3 ? f3 = "n" : "boolean" == typeof l3 ? f3 = "b" : "string" == typeof l3 ? f3 = "s" : l3 instanceof Date ? (f3 = "d", a10.UTC || (l3 = tO(l3)), a10.cellDates || (f3 = "n", l3 = tu(l3)), h3 = null != g2 && g2.z && eQ(g2.z) ? g2.z : a10.dateNF || eD[14]) : null === l3 && a10.nullError && (f3 = "e", l3 = 0), g2 ? (g2.t = f3, g2.v = l3, delete g2.w, delete g2.R, h3 && (g2.z = h3)) : n10 ? p2[c10 + d2] = g2 = { t: f3, v: l3 } : i10[m3] = g2 = { t: f3, v: l3 }, h3 && (g2.z = h3)) : n10 ? p2[c10 + d2] = l3 : i10[m3] = l3;
            });
          }), f2.e.c = Math.max(f2.e.c, c10 + u2.length - 1);
          var m2 = ap(o10);
          if (n10 && !i10["!data"][o10] && (i10["!data"][o10] = []), s10)
            for (d2 = 0; d2 < u2.length; ++d2)
              n10 ? i10["!data"][o10][d2 + c10] = { t: "s", v: u2[d2] } : i10[ag(d2 + c10) + m2] = { t: "s", v: u2[d2] };
          return i10["!ref"] = aT(f2), i10;
        }
        function c7(e10, t10, r10) {
          if ("string" == typeof t10) {
            if (null != e10["!data"]) {
              var a10 = av(t10);
              return e10["!data"][a10.r] || (e10["!data"][a10.r] = []), e10["!data"][a10.r][a10.c] || (e10["!data"][a10.r][a10.c] = { t: "z" });
            }
            return e10[t10] || (e10[t10] = { t: "z" });
          }
          return "number" != typeof t10 ? c7(e10, ab(t10)) : c7(e10, ag(r10 || 0) + ap(t10));
        }
        function c9(e10, t10) {
          var r10 = { SheetNames: [], Sheets: {} };
          return e10 && le(r10, e10, t10 || "Sheet1"), r10;
        }
        function le(e10, t10, r10, a10) {
          var n10 = 1;
          if (!r10) for (; n10 <= 65535 && -1 != e10.SheetNames.indexOf(r10 = "Sheet" + n10); ++n10, r10 = void 0) ;
          if (!r10 || e10.SheetNames.length >= 65535) throw Error("Too many worksheets");
          if (a10 && e10.SheetNames.indexOf(r10) >= 0 && r10.length < 32) {
            var s10 = r10.match(/\d+$/);
            n10 = s10 && +s10[0] || 0;
            var i10 = s10 && r10.slice(0, s10.index) || r10;
            for (++n10; n10 <= 65535 && -1 != e10.SheetNames.indexOf(r10 = i10 + n10); ++n10) ;
          }
          if (ov(r10), e10.SheetNames.indexOf(r10) >= 0) throw Error("Worksheet with name |" + r10 + "| already exists!");
          return e10.SheetNames.push(r10), e10.Sheets[r10] = t10, r10;
        }
        function lt(e10, t10, r10) {
          return t10 ? (e10.l = { Target: t10 }, r10 && (e10.l.Tooltip = r10)) : delete e10.l, e10;
        }
        e2.parse_xlscfb = oW, e2.parse_zip = cW, e2.read = cG, e2.readFile = cX, e2.readFileSync = cX, e2.write = cq, e2.writeFile = c0, e2.writeFileSync = c0, e2.writeFileAsync = function(e10, t10, r10, a10) {
          var n10 = r10 || {};
          n10.type = "file", n10.file = e10, cQ(n10), n10.type = "buffer";
          var s10 = a10;
          return s10 instanceof Function || (s10 = r10), X.writeFile(e10, cq(t10, n10), s10);
        }, e2.utils = {
          encode_col: ag,
          encode_row: ap,
          encode_cell: ab,
          encode_range: aT,
          decode_col: am,
          decode_row: ad,
          split_cell: function(e10) {
            return e10.replace(/(\$?[A-Z]*)(\$?\d*)/, "$1,$2").split(",");
          },
          decode_cell: av,
          decode_range: aw,
          format_cell: a_,
          sheet_new: function(e10) {
            var t10 = {};
            return (e10 || {}).dense && (t10["!data"] = []), t10;
          },
          sheet_add_aoa: aA,
          sheet_add_json: c8,
          sheet_add_dom: o1,
          aoa_to_sheet: aC,
          json_to_sheet: function(e10, t10) {
            return c8(null, e10, t10);
          },
          table_to_sheet: o2,
          table_to_book: function(e10, t10) {
            return aS(o2(e10, t10), t10);
          },
          sheet_to_csv: c5,
          sheet_to_txt: c6,
          sheet_to_json: c2,
          sheet_to_html: o0,
          sheet_to_formulae: function(e10, t10) {
            var r10, a10 = "", n10 = "";
            if (null == e10 || null == e10["!ref"]) return [];
            var s10, i10 = ak(e10["!ref"]), o10 = "", c10 = [], l2 = [], f2 = null != e10["!data"];
            for (s10 = i10.s.c; s10 <= i10.e.c; ++s10) c10[s10] = ag(s10);
            for (var h2 = i10.s.r; h2 <= i10.e.r; ++h2)
              for (o10 = ap(h2), s10 = i10.s.c; s10 <= i10.e.c; ++s10)
                if (a10 = c10[s10] + o10, r10 = f2 ? (e10["!data"][h2] || [])[s10] : e10[a10], n10 = "", void 0 !== r10) {
                  if (null != r10.F) {
                    if (a10 = r10.F, !r10.f) continue;
                    n10 = r10.f, -1 == a10.indexOf(":") && (a10 = a10 + ":" + a10);
                  }
                  if (null != r10.f) n10 = r10.f;
                  else if (t10 && false === t10.values) continue;
                  else if ("z" == r10.t) continue;
                  else if ("n" == r10.t && null != r10.v) n10 = "" + r10.v;
                  else if ("b" == r10.t) n10 = r10.v ? "TRUE" : "FALSE";
                  else if (void 0 !== r10.w) n10 = "'" + r10.w;
                  else {
                    if (void 0 === r10.v) continue;
                    n10 = "s" == r10.t ? "'" + r10.v : "" + r10.v;
                  }
                  l2[l2.length] = a10 + "=" + n10;
                }
            return l2;
          },
          sheet_to_row_object_array: c2,
          sheet_get_cell: c7,
          book_new: c9,
          book_append_sheet: le,
          book_set_sheet_visibility: function(e10, t10, r10) {
            e10.Workbook || (e10.Workbook = {}), e10.Workbook.Sheets || (e10.Workbook.Sheets = []);
            var a10 = (function(e11, t11) {
              if ("number" == typeof t11) {
                if (t11 >= 0 && e11.SheetNames.length > t11) return t11;
                throw Error("Cannot find sheet # " + t11);
              }
              if ("string" == typeof t11) {
                var r11 = e11.SheetNames.indexOf(t11);
                if (r11 > -1) return r11;
                throw Error("Cannot find sheet name |" + t11 + "|");
              }
              throw Error("Cannot find sheet |" + t11 + "|");
            })(e10, t10);
            switch (!e10.Workbook.Sheets[a10] && (e10.Workbook.Sheets[a10] = {}), r10) {
              case 0:
              case 1:
              case 2:
                break;
              default:
                throw Error("Bad sheet visibility setting " + r10);
            }
            e10.Workbook.Sheets[a10].Hidden = r10;
          },
          cell_set_number_format: function(e10, t10) {
            return e10.z = t10, e10;
          },
          cell_set_hyperlink: lt,
          cell_set_internal_link: function(e10, t10, r10) {
            return lt(e10, "#" + t10, r10);
          },
          cell_add_comment: function(e10, t10, r10) {
            e10.c || (e10.c = []), e10.c.push({ t: t10, a: r10 || "SheetJS" });
          },
          sheet_set_array_formula: function(e10, t10, r10, a10) {
            for (var n10 = "string" != typeof t10 ? t10 : ak(t10), s10 = "string" == typeof t10 ? t10 : aT(t10), i10 = n10.s.r; i10 <= n10.e.r; ++i10)
              for (var o10 = n10.s.c; o10 <= n10.e.c; ++o10) {
                var c10 = c7(e10, i10, o10);
                c10.t = "n", c10.F = s10, delete c10.v, i10 == n10.s.r && o10 == n10.s.c && (c10.f = r10, a10 && (c10.D = true));
              }
            var l2 = aw(e10["!ref"]);
            return l2.s.r > n10.s.r && (l2.s.r = n10.s.r), l2.s.c > n10.s.c && (l2.s.c = n10.s.c), l2.e.r < n10.e.r && (l2.e.r = n10.e.r), l2.e.c < n10.e.c && (l2.e.c = n10.e.c), e10["!ref"] = aT(l2), e10;
          },
          consts: { SHEET_VISIBLE: 0, SHEET_HIDDEN: 1, SHEET_VERY_HIDDEN: 2 }
        }, e2.writeXLSX = cJ, e2.writeFileXLSX = function(e10, t10, r10) {
          var a10 = r10 || {};
          return a10.type = "file", a10.file = t10, cQ(a10), cJ(e10, a10);
        }, e2.set_fs = function(e10) {
          X = e10;
        }, e2.set_cptable = ef, e2.SSF = e6, e2.stream = {
          to_json: function(e10, t10) {
            var r10 = Z({ objectMode: true });
            if (null == e10 || null == e10["!ref"]) return r10.push(null), r10;
            var a10 = { t: "n", v: 0 }, n10 = 0, s10 = 1, i10 = [], o10 = 0, c10 = "", l2 = { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } }, f2 = t10 || {}, h2 = null != f2.range ? f2.range : e10["!ref"];
            switch (1 === f2.header ? n10 = 1 : "A" === f2.header ? n10 = 2 : Array.isArray(f2.header) && (n10 = 3), typeof h2) {
              case "string":
                l2 = ak(h2);
                break;
              case "number":
                (l2 = ak(e10["!ref"])).s.r = h2;
                break;
              default:
                l2 = h2;
            }
            n10 > 0 && (s10 = 0);
            var u2 = ap(l2.s.r), d2 = [], p2 = 0, m2 = null != e10["!data"], g2 = l2.s.r, v2 = 0, b2 = {};
            m2 && !e10["!data"][g2] && (e10["!data"][g2] = []);
            var w2 = f2.skipHidden && e10["!cols"] || [], T2 = f2.skipHidden && e10["!rows"] || [];
            for (v2 = l2.s.c; v2 <= l2.e.c; ++v2)
              if (!(w2[v2] || {}).hidden)
                switch (d2[v2] = ag(v2), a10 = m2 ? e10["!data"][g2][v2] : e10[d2[v2] + u2], n10) {
                  case 1:
                    i10[v2] = v2 - l2.s.c;
                    break;
                  case 2:
                    i10[v2] = d2[v2];
                    break;
                  case 3:
                    i10[v2] = f2.header[v2 - l2.s.c];
                    break;
                  default:
                    if (null == a10 && (a10 = { w: "__EMPTY", t: "s" }), c10 = o10 = a_(a10, null, f2), p2 = b2[o10] || 0) {
                      do
                        c10 = o10 + "_" + p2++;
                      while (b2[c10]);
                      b2[o10] = p2, b2[c10] = 1;
                    } else b2[o10] = 1;
                    i10[v2] = c10;
                }
            return g2 = l2.s.r + s10, r10._read = function() {
              for (; g2 <= l2.e.r; )
                if (!(T2[g2 - 1] || {}).hidden) {
                  var t11 = c1(e10, l2, g2, d2, n10, i10, f2);
                  if (++g2, false === t11.isempty || (1 === n10 ? false !== f2.blankrows : !!f2.blankrows))
                    return void r10.push(t11.row);
                }
              return r10.push(null);
            }, r10;
          },
          to_html: function(e10, t10) {
            var r10 = Z(), a10 = t10 || {}, n10 = null != a10.header ? a10.header : oJ, s10 = null != a10.footer ? a10.footer : oq;
            r10.push(n10);
            var i10 = aw(e10["!ref"]);
            r10.push(oQ(e10, i10, a10));
            var o10 = i10.s.r, c10 = false;
            return r10._read = function() {
              if (o10 > i10.e.r) return c10 || (c10 = true, r10.push("</table>" + s10)), r10.push(null);
              for (; o10 <= i10.e.r; ) {
                r10.push(oZ(e10, i10, o10, a10)), ++o10;
                break;
              }
            }, r10;
          },
          to_csv: function(e10, t10) {
            var r10 = Z(), a10 = null == t10 ? {} : t10;
            if (null == e10 || null == e10["!ref"]) return r10.push(null), r10;
            for (var n10 = ak(e10["!ref"]), s10 = void 0 !== a10.FS ? a10.FS : ",", i10 = s10.charCodeAt(0), o10 = void 0 !== a10.RS ? a10.RS : "\n", c10 = o10.charCodeAt(0), l2 = "", f2 = [], h2 = a10.skipHidden && e10["!cols"] || [], u2 = a10.skipHidden && e10["!rows"] || [], d2 = n10.s.c; d2 <= n10.e.c; ++d2)
              (h2[d2] || {}).hidden || (f2[d2] = ag(d2));
            var p2 = n10.s.r, m2 = false, g2 = 0;
            return r10._read = function() {
              if (!m2) return m2 = true, r10.push("\uFEFF");
              for (; p2 <= n10.e.r; )
                if (!(u2[++p2 - 1] || {}).hidden && null != (l2 = c3(e10, n10, p2 - 1, f2, i10, c10, s10, g2, a10)) && (l2 || false !== a10.blankrows))
                  return r10.push((g2++ ? o10 : "") + l2);
              return r10.push(null);
            }, r10;
          },
          to_xlml: function(e10, t10) {
            var r10 = Z(), a10 = null == t10 ? {} : t10, n10 = +a10.stride || 10;
            e10.SSF || (e10.SSF = tw(eD)), e10.SSF && (e5(), e3(e10.SSF), a10.revssf = tc(e10.SSF), a10.revssf[e10.SSF[65535]] = 0, a10.ssf = e10.SSF, a10.cellXfs = [], i1(a10.cellXfs, {}, { revssf: { General: 0 } })), e10.SheetNames.forEach(function(t11) {
              var r11 = e10.Sheets[t11];
              if (r11 && r11["!ref"]) {
                for (var n11 = aw(r11["!ref"]), s11 = null != r11["!data"], i11 = s11 ? r11["!data"] : [], o11 = { r: 0, c: 0 }, c11 = n11.s.r; c11 <= n11.e.r; ++c11)
                  if (o11.r = c11, !s11 || i11[c11])
                    for (var l3 = n11.s.c; l3 <= n11.e.c; ++l3) {
                      o11.c = l3;
                      var f3 = s11 ? i11[c11][l3] : r11[ag(l3) + ap(c11)];
                      f3 && ("d" == f3.t && null == f3.z && ((f3 = tw(f3)).z = eD[14]), i1(a10.cellXfs, f3, a10));
                    }
              }
            });
            var s10 = oC(e10, a10), i10 = 0, o10 = 0, c10 = e10.Sheets[e10.SheetNames[o10]], l2 = ak(c10), f2 = -1, h2 = false, u2 = [], d2 = 0, p2 = false, m2 = [], g2 = { r: 0, c: 0 };
            return r10._read = function() {
              switch (i10) {
                case 0:
                  i10 = 1, r10.push(tJ), r10.push(
                    "<Workbook" + rb({
                      xmlns: rR,
                      "xmlns:o": rI,
                      "xmlns:x": rO,
                      "xmlns:ss": rR,
                      "xmlns:dt": rN,
                      "xmlns:html": rF
                    }) + ">"
                  );
                  break;
                case 1:
                  i10 = 2, r10.push(oS(e10, a10)), r10.push(oA(e10, a10));
                  break;
                case 2:
                  i10 = 3, r10.push(s10), r10.push(oO(e10, a10));
                  break;
                case 3:
                  if (h2 = false, o10 >= e10.SheetNames.length) {
                    i10 = -1, r10.push("");
                    break;
                  }
                  if (r10.push("<Worksheet" + rb({ "ss:Name": re(e10.SheetNames[o10]) }) + ">"), !(c10 = e10.Sheets[e10.SheetNames[o10]]))
                    return r10.push("</Worksheet>"), void ++o10;
                  var t11 = oR(c10, a10, o10, e10);
                  if (t11.length && r10.push("<Names>" + t11 + "</Names>"), !c10["!ref"]) return i10 = 5;
                  f2 = (l2 = ak(c10["!ref"])).s.r, i10 = 4;
                  break;
                case 4:
                  if (f2 < 0 || f2 > l2.e.r) return h2 && r10.push("</Table>"), void (i10 = 5);
                  f2 <= l2.s.r && (c10["!cols"] && c10["!cols"].forEach(function(e11, t12) {
                    s0(e11);
                    var a11 = !!e11.width, n11 = iQ(t12, e11), s11 = { "ss:Index": t12 + 1 };
                    a11 && (s11["ss:Width"] = sY(n11.width)), e11.hidden && (s11["ss:Hidden"] = "1"), h2 || (h2 = true, r10.push("<Table>")), r10.push(rw("Column", null, s11));
                  }), (p2 = null != c10["!data"]) && (m2 = c10["!data"]), g2.r = g2.c = 0);
                  for (var v2 = 0; f2 <= l2.e.r && v2 < n10; ++f2, ++v2) {
                    var b2 = [oD(f2, (c10["!rows"] || [])[f2])];
                    if (g2.r = f2, !(p2 && !m2[f2]))
                      for (var w2 = l2.s.c; w2 <= l2.e.c; ++w2) {
                        g2.c = w2;
                        var T2 = false;
                        for (d2 = 0; d2 != u2.length; ++d2)
                          if (!(u2[d2].s.c > w2) && !(u2[d2].s.r > f2) && !(u2[d2].e.c < w2) && !(u2[d2].e.r < f2)) {
                            (u2[d2].s.c != w2 || u2[d2].s.r != f2) && (T2 = true);
                            break;
                          }
                        if (!T2) {
                          var y2 = ag(w2) + ap(f2), E2 = p2 ? m2[f2][w2] : c10[y2];
                          b2.push(oF(E2, y2, c10, a10, o10, e10, g2));
                        }
                      }
                    b2.push("</Row>"), h2 || (h2 = true, r10.push("<Table>")), r10.push(b2.join(""));
                  }
                  break;
                case 5:
                  return r10.push(oN(c10, a10, o10, e10)), c10 && c10["!autofilter"] && r10.push(
                    '<AutoFilter x:Range="' + ip(ay(c10["!autofilter"].ref), { r: 0, c: 0 }) + '" xmlns="urn:schemas-microsoft-com:office:excel"></AutoFilter>'
                  ), r10.push("</Worksheet>"), o10++, f2 = -1, void (i10 = 3);
                case -1:
                  i10 = -2, r10.push("</Workbook>");
                  break;
                case -2:
                  r10.push(null);
              }
            }, r10;
          },
          set_readable: function(e10) {
            Z = e10;
          }
        }, void 0 !== tr && (e2.CFB = tr);
        var lr = r(91540);
        (lr || {}).Readable && (Z = lr.Readable);
        try {
          X = r(43677);
        } catch (e10) {
        }
      })(t), "undefined" != typeof window && !window.XLSX)
        try {
          window.XLSX = {};
        } catch (e2) {
        }
    }
  }
]);
