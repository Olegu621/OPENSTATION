(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4640],
  {
    558: (t, e, s) => {
      "use strict";
      s.d(e, { Y: () => a });
      var i = s(96559);
      class a {
        getStore() {
          return this.store;
        }
        constructor(t2) {
          (0, i._)(this, "store", void 0), this.store = t2;
        }
      }
    },
    2936: (t, e, s) => {
      "use strict";
      s.d(e, { w: () => r });
      var i = s(96559), a = s(53676), n = s(77220);
      class r extends n.X {
        async getData(t2, e2) {
          return (await this.httpClient.get(
            "labels/".concat(t2.labelId),
            this.createHttpOptions({ timeoutKey: "getData", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getAlbums(t2, e2) {
          return (await this.httpClient.get(
            "labels/".concat(t2.labelId, "/albums"),
            this.createHttpOptions({
              timeoutKey: "getAlbums",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                page: t2.page,
                pageSize: t2.pageSize,
                sortBy: t2.sortBy,
                sortOrder: t2.sortOrder
              })
            })
          )).json();
        }
        async getArtists(t2, e2) {
          return (await this.httpClient.get(
            "labels/".concat(t2.labelId, "/artists"),
            this.createHttpOptions({
              timeoutKey: "getArtists",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ page: t2.page, pageSize: t2.pageSize })
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    3327: (t, e, s) => {
      "use strict";
      s.d(e, { u: () => r });
      var i = s(96559), a = s(53676), n = s(77220);
      class r extends n.X {
        async getCollectionKidsTracksLiked(t2, e2) {
          return (await this.httpClient.get(
            "landing-blocks/collection/kids/tracks-liked",
            this.createHttpOptions({
              timeoutKey: "getCollectionKidsTracksLiked",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ page: t2.page, pageSize: t2.pageSize })
            })
          )).json();
        }
        async getCollectionKidsPlaylistsLiked(t2, e2) {
          return (await this.httpClient.get(
            "landing-blocks/collection/kids/playlists-liked",
            this.createHttpOptions({
              timeoutKey: "getCollectionKidsPlaylistsLiked",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ page: t2.page, pageSize: t2.pageSize })
            })
          )).json();
        }
        async getCollectionKidsAlbumsLiked(t2, e2) {
          return (await this.httpClient.get(
            "landing-blocks/collection/kids/albums-liked",
            this.createHttpOptions({
              timeoutKey: "getCollectionKidsAlbumsLiked",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ page: t2.page, pageSize: t2.pageSize })
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    3463: (t, e, s) => {
      "use strict";
      s.d(e, { s: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getTriggers(t2, e2) {
          return (await this.httpClient.post(
            "dynamic-pages/trigger/polling",
            this.createHttpOptions({
              timeoutKey: "getTriggers",
              params: t2,
              json: { anchorIds: t2.anchorIds },
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getTrigger(t2, e2) {
          return (await this.httpClient.get(
            "dynamic-pages/trigger/polling/".concat(t2.anchorId),
            this.createHttpOptions({ timeoutKey: "getTrigger", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async shown(t2, e2) {
          await this.httpClient.post(
            "dynamic-pages/trigger/shown",
            this.createHttpOptions({
              timeoutKey: "shown",
              params: t2,
              json: { anchorIds: t2.anchorIds, screenId: t2.screenId },
              signal: null == e2 ? void 0 : e2.signal
            })
          );
        }
        async action(t2, e2) {
          await this.httpClient.post(
            "dynamic-pages/trigger/action",
            this.createHttpOptions({
              timeoutKey: "action",
              params: t2,
              json: { anchorIds: t2.anchorIds, screenId: t2.screenId, actionId: t2.actionId },
              signal: null == e2 ? void 0 : e2.signal
            })
          );
        }
        async getTriggersV2(t2, e2) {
          return (await this.httpClient.post(
            "dynamic-pages/v2/trigger/polling",
            this.createHttpOptions({
              timeoutKey: "getTriggers",
              params: t2,
              json: { anchorIds: t2.anchorIds },
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async shownV2(t2, e2) {
          await this.httpClient.post(
            "dynamic-pages/v2/trigger/shown",
            this.createHttpOptions({
              timeoutKey: "shown",
              params: t2,
              json: { anchorIds: t2.anchorIds, feedbackToken: t2.feedbackToken },
              signal: null == e2 ? void 0 : e2.signal
            })
          );
        }
        async actionV2(t2, e2) {
          await this.httpClient.post(
            "dynamic-pages/v2/trigger/action",
            this.createHttpOptions({
              timeoutKey: "action",
              params: t2,
              json: { anchorIds: t2.anchorIds, actionId: t2.actionId, feedbackToken: t2.feedbackToken },
              signal: null == e2 ? void 0 : e2.signal
            })
          );
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    6556: (t, e, s) => {
      "use strict";
      s.d(e, { J: () => a });
      var i = s(8171);
      let a = (t2) => {
        let e2 = t2.resources.musicExternalApi.timeouts;
        return t2.resources.musicExternalApi.defaultTimeout = i.nJ, t2.resources.musicExternalApi.timeouts = (0, i.ne)(e2, [
          { type: "override", value: i.nJ, conditionFn: (t3) => t3 < i.nJ }
        ]), t2;
      };
    },
    8171: (t, e, s) => {
      "use strict";
      s.d(e, { nJ: () => a, Aj: () => i, LE: () => c, ne: () => l });
      let i = 2e3, a = 1e4;
      var n = s(98388), r = s(59955), o = s(21863);
      let l = (t2, e2) => {
        let s2 = (0, n.A)(t2);
        return Object.values(s2).forEach((t3) => {
          t3 && Object.keys(t3).forEach((s3) => {
            let i2 = e2.reduce(
              (t4, e3) => {
                let { type: s4, value: i3, conditionFn: a2 = () => true } = e3;
                if (!a2(t4)) return t4;
                switch (s4) {
                  case "sum":
                    return t4 + i3;
                  case "multiply":
                    return t4 * i3;
                  case "devide":
                    return t4 / i3;
                  case "override":
                    return i3;
                  default:
                    return t4;
                }
              },
              (0, r.A)(t3, [s3])
            );
            (0, o.A)(t3, [s3], i2);
          });
        }), s2;
      }, c = l(
        {
          redAlertResource: { getRedAlerts: i },
          rotorResource: {
            getStationInfo: 180,
            sessionNew: i,
            sessionTracks: i,
            sessionFeedback: 450,
            waveLast: 170,
            waveSettings: 180,
            waveLastReset: 30
          },
          adsResource: { saveAds: 200 },
          accountResource: { experiments: 130, experimentsDetails: 600, settings: 190, about: 600 },
          albumsResource: {
            getAlbumWithTracksIds: 5e3,
            getAlbumWithRichTracks: 5e3,
            getDisclaimer: 150,
            getTrailer: i,
            getRelatedContent: 1e3,
            getAlbums: 1e3,
            getSimilarEntities: i,
            getExternalStreamingLinks: i
          },
          artistsResource: {
            getArtistTracks: 650,
            getArtistTrackIds: 310,
            getSafeDirectAlbums: 210,
            getBriefInfo: 600,
            getSimilarArtists: 90,
            getConcerts: 100,
            getFamiliarYouInfo: i,
            getFamiliarYou: 500,
            getDisclaimer: 150,
            getTrailer: i,
            getInfo: i,
            getSkeleton: i,
            getAboutArtist: i,
            getClips: i,
            getDonation: i,
            getArtistLinks: i
          },
          availabilityResource: { getAvailabilityTracks: 500 },
          clipsResource: { getClip: 2e3, getCredits: 200, getDisclaimer: i, getClipsWillLike: i },
          chartResource: { getChartPodcasts: 2e3, getChartPodcastsCategory: 800 },
          dynamicPagesResource: { getTriggers: 3e3, getTrigger: 3e3, shown: 3e3, action: 3e3 },
          filtersResource: { getTracksFilters: i, getFilterName: i },
          libraryResource: { getAllIds: 260 },
          searchResource: { getInstantMixedSearch: 1e3, sendFeedback: 170 },
          searchPlaylistResource: { getTrackIds: 2e3 },
          siteMapResource: { link: i },
          slidesResource: {
            getUserSlides: 500,
            getArtistSlides: 500,
            getPodcastSlides: 500,
            getSpecialSlides: 500,
            getKidsSlides: 500
          },
          topResource: { getTopByGenre: 1e3 },
          tracksResource: {
            getStorageData: 140,
            getTracksMeta: 2700,
            getDisclaimer: 150,
            getFullInfoTrack: 600,
            getFullDescriptionTrack: 300,
            getCredits: 400,
            getLyrics: 80,
            getTrailer: i
          },
          usersResource: {
            getLikedAlbums: 250,
            getLikedArtists: 250,
            getDislikedArtists: 200,
            getLikedPlaylists: 480,
            getPlaylistsKinds: 800,
            createPlaylist: 500,
            getPlaylistsByKinds: 800,
            getCreatedPlaylists: 670,
            changePlaylistTitle: i,
            changePlaylistDescription: i,
            uploadPlaylistCover: i,
            deletePlaylist: i,
            getPlaylistTrailer: i,
            getPlaylistWithTracksIds: 1e3,
            getPlaylistWithRichTracks: 1500,
            getSearchHistory: 220,
            clearSearchHistory: 60,
            getDislikedTracks: 1e3,
            likeTrack: 300,
            unlikeTrack: 60,
            likeArtist: 230,
            unlikeArtist: 120,
            likeAlbum: 120,
            unlikeAlbum: 70,
            likePlaylist: 120,
            unlikePlaylist: 90,
            getLikedClips: i,
            likeClip: 2e3,
            unlikeClip: 2e3,
            dislikeArtist: 40,
            undislikeArtist: 400,
            dislikeTrack: 140,
            undislikeTrack: 300,
            getPresaves: 300,
            presaveAlbum: 200,
            removePresaveAlbum: 300
          },
          personalResource: { getTopArtists: i },
          playlistResource: { getPlaylist: 1e3, getSimilarEntities: i },
          playlistsResource: { getPlaylists: i, getPlaylistPersonal: 1e3 },
          landingResource: { getSkeleton: 5e3, getBlock: i, getSpecialHeader: 500 },
          landingBlocksResource: {
            getCollectionKidsTracksLiked: i,
            getCollectionKidsPlaylistsLiked: i,
            getCollectionKidsAlbumsLiked: i
          },
          landing3Resource: { getMetatags: i, getChart: i },
          loaderResource: { getUploadUrl: i },
          metatagsResource: { getMetatagById: i },
          pinResource: {
            pinAlbum: i,
            unpinAlbum: i,
            pinPlaylist: i,
            unpinPlaylist: i,
            pinArtist: i,
            unpinArtist: i,
            pinWave: i,
            unpinWave: i
          },
          pinsResource: { getPins: i },
          getFileInfoResource: { getFileInfo: i, getByteRange: i },
          tagResource: { getPlaylistIds: i },
          feedResource: {
            getPromotionsById: i,
            getWizardGenres: 1e3,
            getWizardArtistsByGenre: 1e3,
            finishWizard: 1e3
          },
          musicHistoryResource: { getMusicHistory: i, getMusicHistoryItems: i },
          streamsResource: {
            progressSync: 150,
            markAlbumFinished: 150,
            markAlbumUnfinished: 150,
            markFinished: 350,
            markUnfinished: 150
          },
          lyricViewsResource: { sendViews: 140 },
          nonMusicResource: {
            getShelfRecentlyPlayed: 500,
            getShelfLiked: 1e3,
            getPlaylists: 200,
            getNewEpisodes: 1e3,
            getEditorialAlbums: 200,
            getCategory: 2e3,
            getCategoryAlbums: 200
          },
          donationResource: { getAlbumDonations: i },
          prefixlessResource: { uploadFile: 4e5, reportForAlbumPromo: i, getLyricsText: i },
          offersResource: { getCompositeOffers: i },
          afterTrackResource: { getAfterTrack: i },
          ugcResource: { changeTrack: 200 },
          collectionResource: { sync: 1e3 },
          disclaimersResource: { getDisclaimers: i },
          familyResource: { getInviteInfo: i, acceptInvite: i },
          childrenLandingResource: { getSkeleton: 1e3, getEditorialPlaylist: 200, getEditorialAlbum: 200 },
          promoResource: { getPromoAlbumInfo: i, getAlbumCpaId: i, sendFeedback: i },
          telemetryResouce: { log: i, perfLog: i },
          labelsResource: { getData: i, getAlbums: i, getArtists: i },
          concertsResource: { getTabConfig: i, getFeed: i, getInfo: i, getSkeleton: i },
          radioStreamResource: { getAvailableList: i, getByRadioId: i },
          radioStationsResource: {
            getAll: i,
            getStationBySlug: i,
            getStreamBySlug: i,
            getStreamsBySlugs: i,
            getStreamUrlBySlug: i,
            getStreamWidgetsBySlug: i,
            getRegions: i,
            getRegionBySlug: i,
            getStreamsByRegion: i,
            getGenres: i,
            getStationsByGenre: i,
            getBlocksForYou: i,
            getCollectionStations: i,
            addCollectionStations: i,
            getCollectionTracks: i,
            addCollectionTracks: i,
            getCollectionTracksIds: i,
            bulkDeleteCollectionTracks: i,
            bulkDeleteCollectionStations: i,
            getCollectionStationsSlugs: i,
            getStreamReactions: i,
            sendStreamReactions: i,
            search: i,
            getStationsListenersCount: i,
            sendRecommendationsRecordEvent: i
          },
          complaintResource: { sendComplaint: i, getComplaintsReasons: i },
          importResource: {
            getStatus: i,
            getActiveImportsList: i,
            spotifyAuth: i,
            spotifyCallback: i,
            appleMusicCreate: i,
            youtubeMusicAuth: i,
            youtubeMusicCallback: i,
            vkImport: i,
            anghamiImport: i
          },
          partnersResource: { getAccountInfo: i, getMajors: i, scheduleReport: i }
        },
        [
          { type: "override", value: 200, conditionFn: (t2) => t2 < 200 },
          { type: "multiply", value: 1.5, conditionFn: (t2) => t2 >= 1e3 },
          { type: "multiply", value: 2, conditionFn: (t2) => t2 < 1e3 },
          { type: "sum", value: 200 }
        ]
      );
    },
    10560: (t, e, s) => {
      "use strict";
      s.d(e, { z: () => r });
      var i = s(96559), a = s(53676), n = s(77220);
      class r extends n.X {
        async saveAds(t2, e2) {
          return (await this.httpClient.post(
            "ads/save-ads",
            this.createHttpOptions({
              timeoutKey: "saveAds",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ from: t2.from, trackId: t2.trackId, type: t2.type })
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    10582: (t, e, s) => {
      "use strict";
      s.d(e, { $: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getMetatagById(t2, e2) {
          return (await this.httpClient.get(
            "metatags/".concat(t2.id),
            this.createHttpOptions({
              timeoutKey: "getMetatagById",
              params: t2,
              searchParams: (0, n.P)({
                tracksCount: t2.tracksCount,
                artistsCount: t2.artistsCount,
                composersCount: t2.composersCount,
                albumsCount: t2.albumsCount,
                promotionsCount: t2.promotionsCount,
                featuresCount: t2.featuresCount,
                playlistsCount: t2.playlistsCount,
                concertsCount: t2.concertsCount,
                tracksSortBy: t2.tracksSortBy,
                albumsSortBy: t2.albumsSortBy,
                withLikesCount: t2.withLikesCount
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getMetatagAlbums(t2, e2) {
          return (await this.httpClient.get(
            "metatags/".concat(t2.id, "/albums"),
            this.createHttpOptions({
              timeoutKey: "getMetatagAlbums",
              params: t2,
              searchParams: (0, n.P)({ period: t2.period, sortBy: t2.sortBy, offset: t2.offset, limit: t2.limit }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getMetatagArtists(t2, e2) {
          return (await this.httpClient.get(
            "metatags/".concat(t2.id, "/artists"),
            this.createHttpOptions({
              timeoutKey: "getMetatagArtists",
              params: t2,
              searchParams: (0, n.P)({
                period: t2.period,
                sortBy: t2.sortBy,
                offset: t2.offset,
                limit: t2.limit,
                tracksPerArtist: t2.tracksPerArtist
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getMetatagPlaylists(t2, e2) {
          return (await this.httpClient.get(
            "metatags/".concat(t2.id, "/playlists"),
            this.createHttpOptions({
              timeoutKey: "getMetatagPlaylists",
              params: t2,
              searchParams: (0, n.P)({
                sortBy: t2.sortBy,
                offset: t2.offset,
                limit: t2.limit,
                withLikesCount: t2.withLikesCount
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    12774: (t, e, s) => {
      "use strict";
      s.d(e, { T: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getPlaylist(t2, e2) {
          return (await this.httpClient.get(
            "playlist/".concat(t2.playlistUuid),
            this.createHttpOptions({
              timeoutKey: "getPlaylist",
              params: t2,
              searchParams: (0, n.P)({
                resumeStream: t2.resumeStream,
                richTracks: t2.richTracks,
                trackPlayCounts: t2.trackPlayCounts,
                withSimilarsLikesCount: t2.withSimilarsLikesCount,
                page: t2.page,
                pageSize: t2.pageSize
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getSimilarEntities(t2, e2) {
          return (await this.httpClient.get(
            "playlist/".concat(t2.playlistUuid, "/similar-entities"),
            this.createHttpOptions({
              timeoutKey: "getSimilarEntities",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    12979: (t, e, s) => {
      "use strict";
      async function i(t2) {
        let { config: e2 } = await s(94753)("./".concat(t2, ".ts"));
        return e2();
      }
      s.d(e, { z: () => i });
    },
    13696: (t, e, s) => {
      "use strict";
      s.d(e, { p: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getPlaylistIds(t2, e2) {
          return (await this.httpClient.get(
            "tags/".concat(t2.id, "/playlist-ids"),
            this.createHttpOptions({
              timeoutKey: "getPlaylistIds",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    13871: (t, e, s) => {
      "use strict";
      s.d(e, { i: () => n });
      var i = s(9348), a = s(70755);
      let n = (t2, e2) => {
        let { cause: s2 } = t2;
        if (((t3) => "object" == typeof t3 && null !== t3 && "response" in t3 && "request" in t3)(s2) || (0, a.N)(s2)) {
          var n2;
          let t3 = (null == (n2 = s2.request.options) ? void 0 : n2.headers) || s2.request.originalRequestHeaders;
          if (t3 instanceof Headers) {
            t3.set("x-retry-count", String(e2));
            let [s3] = (t3.get("x-request-id") || (0, i.A)()).split(".");
            t3.set("x-request-id", "".concat(s3, ".").concat(e2));
          }
        }
      };
    },
    14032: (t, e, s) => {
      "use strict";
      s.d(e, { V: () => a, d: () => i });
      let i = (t2) => String(t2).split(":"), a = (t2, e2) => e2 ? [t2, e2].join(":") : t2;
    },
    16068: (t, e, s) => {
      "use strict";
      s.d(e, { H: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getDisclaimers(t2, e2) {
          return (await this.httpClient.get(
            "disclaimers",
            this.createHttpOptions({
              timeoutKey: "getDisclaimers",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    18258: (t, e, s) => {
      "use strict";
      s.d(e, { r: () => r });
      var i = s(96559), a = s(86622), n = s(91927);
      class r extends n.q {
        info(t2, e2) {
          this.maxLogLevel >= a.c.INFO && this.logToConsole(a.c.INFO, t2, e2);
        }
        debug(t2, e2) {
          this.maxLogLevel >= a.c.DEBUG && this.logToConsole(a.c.DEBUG, t2, e2);
        }
        trace(t2, e2) {
          this.maxLogLevel >= a.c.TRACE && this.logToConsole(a.c.TRACE, t2, e2);
        }
        warn(t2, e2) {
          this.maxLogLevel >= a.c.WARNING && this.logToConsole(a.c.WARNING, t2, e2), this.sendToErrorBooster(a.c.WARNING, t2, e2);
        }
        error(t2, e2) {
          this.maxLogLevel >= a.c.ERROR && this.logToConsole(a.c.ERROR, t2, e2), this.sendToErrorBooster(a.c.ERROR, t2, e2);
        }
        log(t2, e2) {
          this.logToConsole(a.c.INFO, t2, e2);
        }
        logToConsole(t2, e2, s2) {
          if (this.disableLogToConsole) return;
          let i2 = a.Q[t2];
          console[i2](...this.formatMessage(t2, e2, s2));
        }
        sendToErrorBooster(t2, e2, s2) {
          window.Ya.Rum.logError({
            message: e2,
            level: t2,
            additional: { data: s2 ? this.obfuscateData({ ...this.additionalData, ...s2 }) : {} }
          });
        }
        constructor(t2) {
          super(t2), (0, i._)(this, "disableLogToConsole", void 0), this.disableLogToConsole = t2.disableLogToConsole;
        }
      }
    },
    21220: (t, e, s) => {
      "use strict";
      s.d(e, { q: () => a });
      var i = s(96559);
      class a {
        get(t2) {
          return this.config.get(t2);
        }
        set(t2, e2) {
          this.config.set(t2, e2);
        }
        constructor(t2) {
          (0, i._)(this, "config", void 0), this.config = t2;
        }
      }
    },
    24120: (t, e, s) => {
      "use strict";
      s.d(e, { B: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getChartPodcasts(t2, e2) {
          return (await this.httpClient.get(
            "chart/podcasts",
            this.createHttpOptions({
              timeoutKey: "getChartPodcasts",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getChartPodcastsCategory(t2, e2) {
          return (await this.httpClient.get(
            "chart/podcasts/category/".concat(t2.categoryId),
            this.createHttpOptions({
              timeoutKey: "getChartPodcastsCategory",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    24252: (t, e, s) => {
      "use strict";
      s.d(e, { e: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getPlaylists(t2, e2) {
          return (await this.httpClient.get(
            "playlists",
            this.createHttpOptions({
              timeoutKey: "getPlaylists",
              params: t2,
              searchParams: (0, n.P)({
                resumeStream: t2.resumeStream,
                page: t2.page,
                pageSize: t2.pageSize,
                playlistIds: t2.playlistIds
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getPlaylistPersonal(t2, e2) {
          return (await this.httpClient.get(
            "playlists/personal/".concat(t2.playlistId),
            this.createHttpOptions({
              timeoutKey: "getPlaylistPersonal",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    25289: (t, e, s) => {
      "use strict";
      s.d(e, { a: () => i.a });
      var i = s(80506);
      s(42520);
    },
    27493: (t, e, s) => {
      "use strict";
      async function i(t2) {
        let { config: e2 } = await s(55256)("./".concat(t2, ".ts"));
        return e2();
      }
      s.d(e, { B: () => i });
    },
    29372: (t, e, s) => {
      "use strict";
      s.d(e, { o: () => r });
      var i = s(96559), a = s(77220), n = s(76898);
      class r extends a.X {
        async pinAlbum(t2, e2) {
          let s2 = (0, n.F)({ id: t2.id });
          return (await this.httpClient.put(
            "pin/album",
            this.createHttpOptions({
              timeoutKey: "pinAlbum",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async unpinAlbum(t2, e2) {
          let s2 = (0, n.F)({ id: t2.id });
          return (await this.httpClient.delete(
            "pin/album",
            this.createHttpOptions({
              timeoutKey: "unpinAlbum",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async pinPlaylist(t2, e2) {
          let s2 = (0, n.F)({ uid: t2.uid, kind: t2.kind });
          return (await this.httpClient.put(
            "pin/playlist",
            this.createHttpOptions({
              timeoutKey: "pinPlaylist",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async unpinPlaylist(t2, e2) {
          let s2 = (0, n.F)({ uid: t2.uid, kind: t2.kind });
          return (await this.httpClient.delete(
            "pin/playlist",
            this.createHttpOptions({
              timeoutKey: "unpinPlaylist",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async pinArtist(t2, e2) {
          let s2 = (0, n.F)({ id: t2.id });
          return (await this.httpClient.put(
            "pin/artist",
            this.createHttpOptions({
              timeoutKey: "pinArtist",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async unpinArtist(t2, e2) {
          let s2 = (0, n.F)({ id: t2.id });
          return (await this.httpClient.delete(
            "pin/artist",
            this.createHttpOptions({
              timeoutKey: "unpinArtist",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async pinWave(t2, e2) {
          let s2 = (0, n.F)({ seeds: t2.seeds });
          return (await this.httpClient.put(
            "pin/wave",
            this.createHttpOptions({
              timeoutKey: "pinWave",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async unpinWave(t2, e2) {
          let s2 = (0, n.F)({ seeds: t2.seeds });
          return (await this.httpClient.delete(
            "pin/wave",
            this.createHttpOptions({
              timeoutKey: "unpinWave",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    29449: (t, e, s) => {
      "use strict";
      s.d(e, { L: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getSkeleton(t2, e2) {
          return (await this.httpClient.get(
            "children-landing/category/".concat(t2.categoryId),
            this.createHttpOptions({ timeoutKey: "getSkeleton", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getEditorialPlaylist(t2, e2) {
          return (await this.httpClient.get(
            "children-landing/editorial/playlist/".concat(t2.id),
            this.createHttpOptions({
              timeoutKey: "getEditorialPlaylist",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getEditorialAlbum(t2, e2) {
          return (await this.httpClient.get(
            "children-landing/editorial/album/".concat(t2.id),
            this.createHttpOptions({
              timeoutKey: "getEditorialAlbum",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    30508: (t, e, s) => {
      "use strict";
      s.d(e, { E: () => r });
      var i = s(96559), a = s(77220), n = s(76898);
      class r extends a.X {
        async changeTrack(t2, e2) {
          return (await this.httpClient.post(
            "ugc/tracks/".concat(t2.trackId, "/change"),
            this.createHttpOptions({
              timeoutKey: "changeTrack",
              params: t2,
              json: (0, n.F)({ artist: t2.artist, title: t2.title }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    33716: (t, e, s) => {
      "use strict";
      s.d(e, { K: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getCompositeOffers(t2, e2) {
          var s2;
          let i2 = (null == (s2 = t2.common) ? void 0 : s2.language) || this.config.params.common.language;
          return (await this.httpClient.get(
            "proxy/plus-cg-api/offers/composite",
            this.createHttpOptions({
              timeoutKey: "getCompositeOffers",
              params: t2,
              searchParams: (0, n.P)({ uid: t2.uid, target: t2.target, features: t2.features, language: i2 }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    34965: (t, e, s) => {
      "use strict";
      s.d(e, { cm: () => i.c });
      var i = s(86622);
      s(91927);
    },
    35566: (t, e, s) => {
      "use strict";
      s.d(e, { V: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getUserSlides(t2, e2) {
          return (await this.httpClient.get(
            "recap-slides/user",
            this.createHttpOptions({ timeoutKey: "getUserSlides", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getArtistSlides(t2, e2) {
          return (await this.httpClient.get(
            "recap-slides/artist/".concat(t2.artistId),
            this.createHttpOptions({
              timeoutKey: "getArtistSlides",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getPodcastSlides(t2, e2) {
          return (await this.httpClient.get(
            "recap-slides/podcast/".concat(t2.podcastId),
            this.createHttpOptions({
              timeoutKey: "getPodcastSlides",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getSpecialSlides(t2, e2) {
          return (await this.httpClient.get(
            "recap-slides/special/".concat(t2.campaignId),
            this.createHttpOptions({
              timeoutKey: "getSpecialSlides",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getKidsSlides(t2, e2) {
          return (await this.httpClient.get(
            "recap-slides/kids",
            this.createHttpOptions({ timeoutKey: "getKidsSlides", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    36211: (t, e, s) => {
      "use strict";
      s.d(e, { G: () => n, B: () => r });
      var i = s(96559), a = s(56258);
      class n {
        async send(t2, e2) {
          var s2, i2, n2, r2, o, l, c;
          let { name: u, data: d } = t2, p = this.rum._errorSettings, h = this.rum._buildAdditional(p.additional, d), g = this.rum._buildExperiments(null != (c = p.experiments) ? c : []), y = {
            ...this.rum._vars,
            "-project": "music.frontend",
            "-service": e2.project,
            "-experiments": g,
            "-yandexuid": p.yandexuid,
            "-loggedin": p.loggedin,
            "-referrer": this.rum._getReferrer(p),
            "-additional": h,
            "-ts": Date.now(),
            "-type": "string",
            "-name": u,
            "-value": this.clientType
          }, m = this.rum._createVarsString(y), v = (null == (s2 = (i2 = this.rum).getSetting) ? void 0 : s2.call(i2, "reqid")) || "", f = null == (n2 = (r2 = this.rum).getSetting) ? void 0 : n2.call(r2, "slots"), C = null == (o = (l = this.rum).getSetting) ? void 0 : o.call(l, "experiments");
          try {
            await this.rumResource.sendMetrics({
              varsString: m,
              reqid: v,
              table: "rum_events",
              slots: f,
              experimentsSetting: C,
              name: u,
              clientType: this.clientType
            });
          } catch (t3) {
            throw new a.t("Failed to send metrics to RUM", { code: "E_RUM_METRICS_SEND", cause: t3 });
          }
        }
        constructor(t2, e2, s2) {
          (0, i._)(this, "clientType", void 0), (0, i._)(this, "rumResource", void 0), (0, i._)(this, "rum", void 0), this.clientType = t2, this.rumResource = e2, this.rum = s2;
        }
      }
      class r {
        async send(t2, e2) {
          return new Promise((s2) => {
            let i2 = { [t2.name]: { ...t2.data } };
            this.yaMetrika.count(i2, e2.topLevelParameter), s2();
          });
        }
        constructor(t2) {
          (0, i._)(this, "yaMetrika", void 0), this.yaMetrika = t2;
        }
      }
    },
    36788: (t, e, s) => {
      "use strict";
      s.d(e, { b: () => r });
      var i = s(96559), a = s(53676), n = s(77220);
      class r extends n.X {
        async getArtistTracks(t2, e2) {
          var s2, i2;
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/tracks"),
            this.createHttpOptions({
              timeoutKey: "getArtistTracks",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                "sort-by": null == (s2 = t2.sort) ? void 0 : s2.sortBy,
                "sort-order": null == (i2 = t2.sort) ? void 0 : i2.sortOrder,
                page: t2.page,
                pageSize: t2.pageSize
              })
            })
          )).json();
        }
        async getArtistTrackIds(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/track-ids"),
            this.createHttpOptions({
              timeoutKey: "getArtistTrackIds",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ page: t2.page, pageSize: t2.pageSize })
            })
          )).json();
        }
        async getSafeDirectAlbums(t2, e2) {
          var s2, i2;
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/safe-direct-albums"),
            this.createHttpOptions({
              timeoutKey: "getSafeDirectAlbums",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                "sort-by": null == (s2 = t2.sort) ? void 0 : s2.sortBy,
                "sort-order": null == (i2 = t2.sort) ? void 0 : i2.sortOrder,
                limit: t2.limit
              })
            })
          )).json();
        }
        async getBriefInfo(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/brief-info"),
            this.createHttpOptions({
              timeoutKey: "getBriefInfo",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                popularTracksCount: t2.popularTracksCount,
                useClipDataFormat: t2.useClipDataFormat,
                discographyBlockEnabled: t2.discographyBlockEnabled,
                fetchPlaylistLikesCounts: t2.fetchPlaylistLikesCounts
              })
            })
          )).json();
        }
        async getAboutArtist(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/about-artist"),
            this.createHttpOptions({
              timeoutKey: "getAboutArtist",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getSimilarArtists(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/similar"),
            this.createHttpOptions({
              timeoutKey: "getSimilarArtists",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getDiscographyAlbums(t2, e2) {
          var s2, i2;
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/discography-albums"),
            this.createHttpOptions({
              timeoutKey: "getDiscographyAlbums",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                page: t2.page,
                pageSize: t2.pageSize,
                "sort-by": null == (s2 = t2.sort) ? void 0 : s2.sortBy,
                "sort-order": null == (i2 = t2.sort) ? void 0 : i2.sortOrder
              })
            })
          )).json();
        }
        async getDirectAlbums(t2, e2) {
          var s2, i2;
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/direct-albums"),
            this.createHttpOptions({
              timeoutKey: "getDirectAlbums",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                page: t2.page,
                pageSize: t2.pageSize,
                "sort-by": null == (s2 = t2.sort) ? void 0 : s2.sortBy,
                "sort-order": null == (i2 = t2.sort) ? void 0 : i2.sortOrder
              })
            })
          )).json();
        }
        async getAlsoAlbums(t2, e2) {
          var s2, i2;
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/also-albums"),
            this.createHttpOptions({
              timeoutKey: "getAlsoAlbums",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                page: t2.page,
                pageSize: t2.pageSize,
                "sort-by": null == (s2 = t2.sort) ? void 0 : s2.sortBy,
                "sort-order": null == (i2 = t2.sort) ? void 0 : i2.sortOrder
              })
            })
          )).json();
        }
        async getConcerts(t2, e2) {
          let s2 = await this.httpClient.get(
            "artists/".concat(t2.artistId, "/concerts"),
            this.createHttpOptions({
              timeoutKey: "getConcerts",
              params: { ...t2, common: { ...t2, withoutInvocationInfo: false } },
              signal: null == e2 ? void 0 : e2.signal
            })
          );
          return (await s2.json()).result;
        }
        async getFamiliarYouInfo(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/familiar-you/info"),
            this.createHttpOptions({
              timeoutKey: "getFamiliarYouInfo",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ withWaveInfo: t2.withWaveInfo, withCollectionInfo: t2.withCollectionInfo })
            })
          )).json();
        }
        async getFamiliarYou(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/familiar-you"),
            this.createHttpOptions({
              timeoutKey: "getFamiliarYou",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                waveTracksLimit: t2.waveTracksLimit,
                collectionTracksLimit: t2.collectionTracksLimit,
                collectionAlbumsLimit: t2.collectionAlbumsLimit,
                withIds: t2.withIds
              })
            })
          )).json();
        }
        async getDisclaimer(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/disclaimer"),
            this.createHttpOptions({ timeoutKey: "getDisclaimer", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getTrailer(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/trailer"),
            this.createHttpOptions({ timeoutKey: "getTrailer", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getInfo(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/info"),
            this.createHttpOptions({ timeoutKey: "getInfo", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getSkeleton(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/skeletons/").concat(t2.skeletonId),
            this.createHttpOptions({ timeoutKey: "getSkeleton", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getClips(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/blocks/artist-clips"),
            this.createHttpOptions({
              timeoutKey: "getClips",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ page: t2.page, pageSize: t2.pageSize })
            })
          )).json();
        }
        async getDonation(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/blocks/artist-donation"),
            this.createHttpOptions({ timeoutKey: "getDonation", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getArtistLinks(t2, e2) {
          return (await this.httpClient.get(
            "artists/".concat(t2.artistId, "/artist-links"),
            this.createHttpOptions({
              timeoutKey: "getArtistLinks",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    37934: (t, e, s) => {
      "use strict";
      s.d(e, { p: () => o });
      var i = s(96559), a = s(77220), n = s(76898), r = s(53676);
      class o extends a.X {
        async getInstantMixedSearch(t2, e2) {
          return (await this.httpClient.get(
            "search/instant/mixed",
            this.createHttpOptions({
              timeoutKey: "getInstantMixedSearch",
              params: t2,
              searchParams: (0, r.P)({
                text: t2.text,
                type: t2.type,
                page: t2.page,
                filter: t2.filter,
                pageSize: t2.pageSize,
                nocorrect: t2.nocorrent,
                onlyCounters: t2.onlyCounters,
                withLikesCount: t2.withLikesCount,
                from: t2.from,
                inputType: t2.inputType,
                vocalTypes: t2.vocalTypes,
                releaseYears: t2.releaseYears,
                epochs: t2.epochs,
                moods: t2.moods,
                activities: t2.activities,
                genres: t2.genres,
                lyricsLanguages: t2.lyricsLanguages,
                moodScoresFrom: t2.moodScoresFrom,
                moodScoresTo: t2.moodScoresTo,
                activityScoresFrom: t2.activityScoresFrom,
                activityScoresTo: t2.activityScoresTo,
                withBestResults: t2.withBestResults
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async sendFeedback(t2, e2) {
          let s2 = (0, n.F)({
            blockType: t2.blockType,
            entityId: t2.entityId,
            timestamp: t2.timestamp,
            blockPosition: t2.blockPosition,
            position: t2.position,
            searchRequestId: t2.searchRequestId,
            query: t2.query,
            page: t2.page,
            clickType: t2.clickType,
            clientNow: t2.clientNow,
            absolutePosition: t2.absoluteBlockPosition,
            clientSearchContext: t2.clientSearchContext,
            searchType: t2.searchType
          });
          return (await this.httpClient.post(
            "search/feedback",
            this.createHttpOptions({
              timeoutKey: "sendFeedback",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    38689: (t, e, s) => {
      "use strict";
      s.d(e, { D: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getShelfRecentlyPlayed(t2, e2) {
          return (await this.httpClient.get(
            "non-music/bookshelf/recently-played",
            this.createHttpOptions({
              timeoutKey: "getShelfRecentlyPlayed",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, n.P)({
                page: null == t2 ? void 0 : t2.page,
                pageSize: null == t2 ? void 0 : t2.pageSize
              })
            })
          )).json();
        }
        async getShelfLiked(t2, e2) {
          return (await this.httpClient.get(
            "non-music/bookshelf/liked",
            this.createHttpOptions({
              timeoutKey: "getShelfLiked",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, n.P)({
                page: null == t2 ? void 0 : t2.page,
                pageSize: null == t2 ? void 0 : t2.pageSize
              })
            })
          )).json();
        }
        async getPlaylists(t2, e2) {
          return (await this.httpClient.get(
            "non-music/editorial/playlist/".concat(t2.categoryId, "/"),
            this.createHttpOptions({ timeoutKey: "getPlaylists", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getNewEpisodes(t2, e2) {
          return (await this.httpClient.get(
            "non-music/new-episodes",
            this.createHttpOptions({
              timeoutKey: "getNewEpisodes",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getEditorialAlbums(t2, e2) {
          return (await this.httpClient.get(
            "non-music/editorial/album/".concat(t2.id),
            this.createHttpOptions({
              timeoutKey: "getEditorialAlbums",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getCategory(t2, e2) {
          return (await this.httpClient.get(
            "non-music/category/".concat(t2.categoryId),
            this.createHttpOptions({ timeoutKey: "getCategory", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getCategoryAlbums(t2, e2) {
          return (await this.httpClient.get(
            "non-music/category/".concat(t2.id, "/albums"),
            this.createHttpOptions({
              timeoutKey: "getCategoryAlbums",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    40080: (t, e, s) => {
      "use strict";
      s.d(e, { d: () => l });
      var i = s(96559), a = s(77534), n = s(71020), r = s(53676), o = s(77220);
      class l extends o.X {
        async getLikedAlbums(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/likes/albums/page"),
            this.createHttpOptions({
              timeoutKey: "getLikedAlbums",
              params: t2,
              searchParams: (0, r.P)({
                rich: true,
                page: t2.page,
                pageSize: t2.pageSize,
                "sort-by": t2.sortBy,
                "sort-order": t2.sortOrder,
                metaType: t2.metaType
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getLikedArtists(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/likes/artists/page"),
            this.createHttpOptions({
              timeoutKey: "getLikedArtists",
              params: t2,
              searchParams: (0, r.P)({
                page: t2.page,
                pageSize: t2.pageSize,
                "sort-by": t2.sortBy,
                "sort-order": t2.sortOrder,
                withTimestamps: t2.withTimestamps
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getDislikedArtists(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/dislikes/artists"),
            this.createHttpOptions({
              timeoutKey: "getDislikedArtists",
              params: t2,
              searchParams: (0, r.P)({ "sort-by": t2.sortBy, "sort-order": t2.sortOrder }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getLikedPlaylists(t2, e2) {
          let s2 = await this.httpClient.get(
            "users/".concat(t2.userId, "/likes/playlists"),
            this.createHttpOptions({
              timeoutKey: "getLikedPlaylists",
              params: { ...t2, common: { ...t2.common, withoutInvocationInfo: false } },
              searchParams: (0, r.P)({
                page: t2.page,
                pageSize: t2.pageSize,
                "sort-by": t2.sortBy,
                "sort-order": t2.sortOrder,
                playlistMetaType: t2.playlistMetaType,
                withTracks: t2.withTracks
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          ), i2 = await s2.json();
          return { likedPlaylists: i2.result, pager: i2.pager };
        }
        async getPlaylistsKinds(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/playlists/list/kinds"),
            this.createHttpOptions({
              timeoutKey: "getPlaylistsKinds",
              params: t2,
              searchParams: (0, r.P)({ addPlaylistWithLikes: t2.addPlaylistWithLikes }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async createPlaylist(t2, e2) {
          return (await this.httpClient.post(
            "users/".concat(t2.userId, "/playlists/create"),
            this.createHttpOptions({
              timeoutKey: "createPlaylist",
              params: t2,
              searchParams: (0, r.P)({ visibility: t2.visibility, title: t2.title, description: t2.description }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getPlaylistsByKinds(t2, e2) {
          return (await this.httpClient.post(
            "users/".concat(t2.userId, "/playlists"),
            this.createHttpOptions({
              timeoutKey: "getPlaylistsByKinds",
              params: t2,
              searchParams: (0, r.P)({ kinds: t2.kinds, withLikesCount: t2.withLikesCount, withTracks: t2.withTracks }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getCreatedPlaylists(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/playlists/list"),
            this.createHttpOptions({
              timeoutKey: "getCreatedPlaylists",
              params: t2,
              searchParams: (0, r.P)({
                page: t2.page,
                pageSize: t2.pageSize,
                "sort-by": t2.sortBy,
                "sort-order": t2.sortOrder,
                withLikesCount: t2.withLikesCount
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getPlaylistWithRichTracks(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/playlists/").concat(t2.playlistKind),
            this.createHttpOptions({
              timeoutKey: "getPlaylistWithRichTracks",
              params: t2,
              searchParams: (0, r.P)({
                resumeStream: t2.resumeStream,
                trackMetaType: t2.trackMetaType,
                page: t2.page,
                pageSize: t2.pageSize,
                trackPlayCounts: t2.trackPlayCounts,
                withSimilarsLikesCount: t2.withSimilarsLikesCount,
                richTracks: true
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async changePlaylistTitle(t2, e2) {
          return (await this.httpClient.post(
            "users/".concat(t2.userId, "/playlists/").concat(t2.playlistKind, "/name"),
            this.createHttpOptions({
              timeoutKey: "changePlaylistTitle",
              params: t2,
              searchParams: (0, r.P)({ value: t2.title }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async deletePlaylist(t2, e2) {
          return (await this.httpClient.post(
            "users/".concat(t2.userId, "/playlists/").concat(t2.playlistKind, "/delete"),
            this.createHttpOptions({
              timeoutKey: "deletePlaylist",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async changePlaylistDescription(t2, e2) {
          return (await this.httpClient.post(
            "users/".concat(t2.userId, "/playlists/").concat(t2.playlistKind, "/description"),
            this.createHttpOptions({
              timeoutKey: "changePlaylistDescription",
              params: t2,
              searchParams: (0, r.P)({ value: t2.description }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getPlaylistWithTracksIds(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/playlists/").concat(t2.playlistKind),
            this.createHttpOptions({
              timeoutKey: "getPlaylistWithTracksIds",
              params: t2,
              searchParams: (0, r.P)({
                resumeStream: t2.resumeStream,
                trackMetaType: t2.trackMetaType,
                page: t2.page,
                pageSize: t2.pageSize,
                trackPlayCounts: t2.trackPlayCounts,
                withSimilarsLikesCount: t2.withSimilarsLikesCount,
                richTracks: false
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async likeTrack(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/tracks/add"),
            this.createHttpOptions({
              timeoutKey: "likeTrack",
              params: t2,
              searchParams: (0, r.P)({ "track-id": t2.entityId }),
              signal: null == e2 ? void 0 : e2.signal
            })
          ), i2 = await s2.json();
          return (null == i2 ? void 0 : i2.revision) ? a.f.OK : a.f.ERROR;
        }
        async unlikeTrack(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/tracks/").concat(t2.entityId, "/remove"),
            this.createHttpOptions({ timeoutKey: "unlikeTrack", params: t2, signal: null == e2 ? void 0 : e2.signal })
          ), i2 = await s2.json();
          return (null == i2 ? void 0 : i2.revision) ? a.f.OK : a.f.ERROR;
        }
        async getDislikedTracks(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/dislikes/tracks"),
            this.createHttpOptions({
              timeoutKey: "getDislikedTracks",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async dislikeTrack(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/dislikes/tracks/add"),
            this.createHttpOptions({
              timeoutKey: "dislikeTrack",
              params: t2,
              searchParams: (0, r.P)({ "track-id": t2.entityId }),
              signal: null == e2 ? void 0 : e2.signal
            })
          ), i2 = await s2.json();
          return (null == i2 ? void 0 : i2.revision) ? a.f.OK : a.f.ERROR;
        }
        async undislikeTrack(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/dislikes/tracks/").concat(t2.entityId, "/remove"),
            this.createHttpOptions({
              timeoutKey: "undislikeTrack",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          ), i2 = await s2.json();
          return (null == i2 ? void 0 : i2.revision) ? a.f.OK : a.f.ERROR;
        }
        async likeArtist(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/artists/add"),
            this.createHttpOptions({
              timeoutKey: "likeArtist",
              params: t2,
              searchParams: (0, r.P)({ "artist-id": t2.entityId }),
              signal: null == e2 ? void 0 : e2.signal
            })
          );
          return await s2.json() === a.f.OK ? a.f.OK : a.f.ERROR;
        }
        async unlikeArtist(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/artists/").concat(t2.entityId, "/remove"),
            this.createHttpOptions({ timeoutKey: "unlikeArtist", params: t2, signal: null == e2 ? void 0 : e2.signal })
          );
          return await s2.json() === a.f.OK ? a.f.OK : a.f.ERROR;
        }
        async dislikeArtist(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/dislikes/artists/add"),
            this.createHttpOptions({
              timeoutKey: "dislikeArtist",
              params: t2,
              searchParams: (0, r.P)({ "artist-id": t2.entityId }),
              signal: null == e2 ? void 0 : e2.signal
            })
          );
          return await s2.json() === a.f.OK ? a.f.OK : a.f.ERROR;
        }
        async undislikeArtist(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/dislikes/artists/").concat(t2.entityId, "/remove"),
            this.createHttpOptions({ timeoutKey: "undislikeArtist", params: t2, signal: null == e2 ? void 0 : e2.signal })
          );
          return await s2.json() === a.f.OK ? a.f.OK : a.f.ERROR;
        }
        async likeAlbum(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/albums/add"),
            this.createHttpOptions({
              timeoutKey: "likeAlbum",
              params: t2,
              searchParams: (0, r.P)({ "album-id": t2.entityId }),
              signal: null == e2 ? void 0 : e2.signal
            })
          );
          return await s2.json() === a.f.OK ? a.f.OK : a.f.ERROR;
        }
        async unlikeAlbum(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/albums/").concat(t2.entityId, "/remove"),
            this.createHttpOptions({ timeoutKey: "unlikeAlbum", params: t2, signal: null == e2 ? void 0 : e2.signal })
          );
          return await s2.json() === a.f.OK ? a.f.OK : a.f.ERROR;
        }
        async likePlaylist(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/playlists/add"),
            this.createHttpOptions({
              timeoutKey: "likePlaylist",
              params: t2,
              searchParams: (0, r.P)({ "owner-uid": t2.ownerId, kind: t2.kindId }),
              signal: null == e2 ? void 0 : e2.signal
            })
          );
          return await s2.json() === a.f.OK ? a.f.OK : a.f.ERROR;
        }
        async unlikePlaylist(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/playlists/").concat(t2.ownerId, "-").concat(t2.kindId, "/remove"),
            this.createHttpOptions({ timeoutKey: "unlikePlaylist", params: t2, signal: null == e2 ? void 0 : e2.signal })
          );
          return await s2.json() === a.f.OK ? a.f.OK : a.f.ERROR;
        }
        async getLikedClips(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/likes/clips"),
            this.createHttpOptions({
              timeoutKey: "getLikedClips",
              params: t2,
              searchParams: (0, r.P)({ page: t2.page, pageSize: t2.pageSize }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async likeClip(t2, e2) {
          await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/clips/add"),
            this.createHttpOptions({
              timeoutKey: "likeClip",
              params: t2,
              searchParams: (0, r.P)({ "clip-id": t2.entityId }),
              signal: null == e2 ? void 0 : e2.signal
            })
          );
        }
        async unlikeClip(t2, e2) {
          await this.httpClient.post(
            "users/".concat(t2.userId, "/likes/clips/").concat(t2.entityId, "/remove"),
            this.createHttpOptions({ timeoutKey: "unlikeClip", params: t2, signal: null == e2 ? void 0 : e2.signal })
          );
        }
        async presaveAlbum(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/presaves/add"),
            this.createHttpOptions({
              timeoutKey: "presaveAlbum",
              params: t2,
              searchParams: (0, r.P)({ albumId: t2.albumId, likeAfterRelease: t2.likeAfterRelease }),
              signal: null == e2 ? void 0 : e2.signal
            })
          );
          return await s2.json() === n.J.OK ? n.J.OK : n.J.ERROR;
        }
        async removePresaveAlbum(t2, e2) {
          let s2 = await this.httpClient.post(
            "users/".concat(t2.userId, "/presaves/remove"),
            this.createHttpOptions({
              timeoutKey: "removePresaveAlbum",
              params: t2,
              searchParams: (0, r.P)({ albumId: t2.albumId }),
              signal: null == e2 ? void 0 : e2.signal
            })
          );
          return await s2.json() === n.J.OK ? n.J.OK : n.J.ERROR;
        }
        async getPresaves(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/presaves"),
            this.createHttpOptions({
              timeoutKey: "getPresaves",
              params: t2,
              searchParams: (0, r.P)({ includeReleased: t2.includeReleased, includeUpcoming: t2.includeUpcoming }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getSearchHistory(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/search-history"),
            this.createHttpOptions({
              timeoutKey: "getSearchHistory",
              params: t2,
              searchParams: (0, r.P)({
                clientSearchContext: t2.clientSearchContext,
                contentType: t2.contentType,
                supportedTypes: t2.supportedTypes
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async clearSearchHistory(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/search-history/clear"),
            this.createHttpOptions({
              timeoutKey: "clearSearchHistory",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async changePlaylistRelative(t2, e2) {
          return (await this.httpClient.post(
            "users/".concat(t2.userId, "/playlists/").concat(t2.playlistKind, "/change-relative"),
            this.createHttpOptions({
              timeoutKey: "changePlaylistRelative",
              params: t2,
              searchParams: (0, r.P)({ diff: t2.diff, revision: t2.revision }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async uploadPlaylistCover(t2, e2) {
          return (await this.httpClient.post(
            "users/".concat(t2.userId, "/playlists/").concat(t2.playlistKind, "/cover/upload"),
            this.createHttpOptions({
              timeoutKey: "uploadPlaylistCover",
              params: t2,
              body: t2.formData,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getPlaylistTrailer(t2, e2) {
          return (await this.httpClient.get(
            "users/".concat(t2.userId, "/playlists/").concat(t2.playlistKind, "/trailer"),
            this.createHttpOptions({
              timeoutKey: "getPlaylistTrailer",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async togglePlaylistVisibility(t2, e2) {
          return (await this.httpClient.post(
            "users/".concat(t2.userId, "/playlists/").concat(t2.playlistKind, "/visibility"),
            this.createHttpOptions({
              timeoutKey: "createPlaylist",
              params: t2,
              searchParams: (0, r.P)({ value: t2.visibility }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    40168: (t, e, s) => {
      "use strict";
      s.d(e, { O: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getTabConfig(t2, e2) {
          let s2 = await this.httpClient.get(
            "concerts/tab-config",
            this.createHttpOptions({ timeoutKey: "getTabConfig", params: t2, signal: null == e2 ? void 0 : e2.signal })
          );
          return await s2.json();
        }
        async getFeed(t2, e2) {
          let s2 = await this.httpClient.get(
            "concerts/feed",
            this.createHttpOptions({ timeoutKey: "getFeed", params: t2, signal: null == e2 ? void 0 : e2.signal })
          );
          return await s2.json();
        }
        async getInfo(t2, e2) {
          let s2 = await this.httpClient.get(
            "concerts/".concat(t2.concertId, "/info"),
            this.createHttpOptions({ timeoutKey: "getInfo", params: t2, signal: null == e2 ? void 0 : e2.signal })
          );
          return await s2.json();
        }
        async getSkeleton(t2, e2) {
          return (await this.httpClient.get(
            "concerts/".concat(t2.concertId, "/skeletons/").concat(t2.skeletonId),
            this.createHttpOptions({ timeoutKey: "getSkeleton", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getConcertsDetails(t2, e2) {
          return (await this.httpClient.get(
            "concerts/details/".concat(t2.type, "/").concat(t2.id),
            this.createHttpOptions({
              timeoutKey: "getConcertsDetails",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    41778: (t, e, s) => {
      "use strict";
      s.d(e, { J: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getInviteInfo(t2) {
          return (await this.httpClient.get(
            "account/family/invite-info/".concat(t2.inviteId, "/"),
            this.createHttpOptions({ timeoutKey: "getInviteInfo", params: t2 })
          )).json();
        }
        async acceptInvite(t2) {
          await this.httpClient.post(
            "account/family/accept-invite/".concat(t2.inviteId),
            this.createHttpOptions({ timeoutKey: "acceptInvite", params: t2 })
          );
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    42132: (t, e, s) => {
      "use strict";
      s.d(e, { g: () => o });
      var i = s(96559), a = s(77220), n = s(76898), r = s(53676);
      class o extends a.X {
        async log(t2) {
          await this.httpClient.post(
            "log",
            this.createHttpOptions(
              {
                timeoutKey: "log",
                params: t2,
                json: (0, n.F)(t2.payload),
                excludeHeaders: ["x-request-id", "x-retry-count", "x-retpath-y"],
                searchParams: (0, r.P)(t2.urlParams)
              },
              { withoutHeaders: true }
            )
          );
        }
        async perfLog(t2) {
          await this.httpClient.post(
            "perf",
            this.createHttpOptions(
              {
                timeoutKey: "perfLog",
                params: t2,
                json: t2.payload,
                excludeHeaders: ["x-request-id", "x-retry-count", "x-retpath-y"],
                searchParams: (0, r.P)(t2.urlParams)
              },
              { withoutHeaders: true }
            )
          );
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    42520: (t, e, s) => {
      "use strict";
      let i;
      s.d(e, { useMetrika: () => r });
      var a = s(61910), n = s(80506);
      let r = () => {
        let t2 = (i || (i = (0, n.a)()), i), e2 = (0, a.useSyncExternalStore)(t2.isLoaded.onChange, () => t2.isLoaded.value);
        return (0, a.useMemo)(() => ({ ...t2, isLoaded: e2 }), [e2]);
      };
    },
    45628: (t, e, s) => {
      "use strict";
      s.d(e, { V: () => a });
      var i = s(96559);
      class a {
        setPassportUid(t2) {
          let e2 = this.executionContext.getStore();
          void 0 !== e2 && (e2.puid = t2), this.passportUid = t2;
        }
        getPassportUid() {
          return this.passportUid;
        }
        constructor(t2) {
          (0, i._)(this, "executionContext", void 0), (0, i._)(this, "passportUid", void 0), this.executionContext = t2;
        }
      }
    },
    49775: (t, e, s) => {
      "use strict";
      s.d(e, { t: () => i });
      let i = {
        statusCodes: {
          408: { retryPolicy: "constant-backoff", attempts: [2e3, 5e3] },
          429: { retryPolicy: "constant-backoff", attempts: [2e3, 5e3] },
          500: { retryPolicy: "constant-backoff", attempts: [1e3, 3e3] },
          502: { retryPolicy: "constant-backoff", attempts: [1e3, 3e3] },
          503: { retryPolicy: "constant-backoff", attempts: [1e3, 3e3] },
          504: { retryPolicy: "constant-backoff", attempts: [2e3, 5e3] },
          NON_HTTP_ERROR: { retryPolicy: "constant-backoff", attempts: [1e3, 1e3] },
          TIMEOUT: { retryPolicy: "constant-backoff", attempts: [500] }
        },
        totalRequestsLimit: 3
      };
    },
    50218: (t, e, s) => {
      "use strict";
      s.d(e, { N: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getAlbumDonations(t2, e2) {
          let s2 = await this.httpClient.get(
            "donation/albums/".concat(t2.albumId),
            this.createHttpOptions({
              timeoutKey: "getAlbumDonations",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          );
          return await s2.json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    52962: (t, e, s) => {
      "use strict";
      s.d(e, { L: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getStorageData(t2, e2) {
          let {
            formatFlags: s2,
            direct: i2,
            preview: a2,
            canUseStreaming: r2,
            tsInSeconds: o,
            sign: l,
            debug: c,
            isAliceRequester: u,
            requireMp3Link: d
          } = t2;
          return (await this.httpClient.get(
            "tracks/".concat(t2.trackId, "/download-info"),
            this.createHttpOptions({
              timeoutKey: "getStorageData",
              params: t2,
              searchParams: (0, n.P)({
                formatFlags: s2,
                debug: c,
                preview: a2,
                direct: i2,
                isAliceRequester: u,
                requireMp3Link: d,
                canUseStreaming: r2,
                ts: o,
                sign: l
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getTracksMeta(t2, e2) {
          return (await this.httpClient.post(
            "tracks",
            this.createHttpOptions({
              timeoutKey: "getTracksMeta",
              params: t2,
              body: (function(t3) {
                let e3 = new FormData();
                return Object.getOwnPropertyNames(t3).forEach((s2) => {
                  let i2 = t3[s2];
                  ("number" == typeof i2 || "string" == typeof i2 || "boolean" == typeof i2) && e3.append(s2, String(i2)), Array.isArray(i2) && i2.forEach((t4) => {
                    ("number" == typeof t4 || "string" == typeof t4) && e3.append(s2, String(t4));
                  });
                }), e3;
              })({
                trackIds: t2.trackIds,
                removeDuplicates: t2.removeDuplicates || false,
                withProgress: t2.withProgress,
                withMixData: t2.withMixData
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getFullInfoTrack(t2, e2) {
          let s2 = t2.albumId ? "".concat(t2.trackId, ":").concat(t2.albumId) : t2.trackId;
          return (await this.httpClient.get(
            "tracks/".concat(s2, "/full-info"),
            this.createHttpOptions({
              timeoutKey: "getFullInfoTrack",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getFullDescriptionTrack(t2, e2) {
          return (await this.httpClient.get(
            "tracks/".concat(t2.trackId, "/supplement"),
            this.createHttpOptions({
              timeoutKey: "getFullDescriptionTrack",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getCredits(t2, e2) {
          return (await this.httpClient.get(
            "tracks/".concat(t2.trackId, "/credits"),
            this.createHttpOptions({ timeoutKey: "getCredits", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getDisclaimer(t2, e2) {
          return (await this.httpClient.get(
            "tracks/".concat(t2.trackId, "/disclaimer"),
            this.createHttpOptions({ timeoutKey: "getDisclaimer", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getTrailer(t2, e2) {
          return (await this.httpClient.get(
            "tracks/".concat(t2.trackId, "/trailer"),
            this.createHttpOptions({ timeoutKey: "getTrailer", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getLyrics(t2, e2) {
          return (await this.httpClient.get(
            "tracks/".concat(t2.trackId, "/lyrics"),
            this.createHttpOptions({
              timeoutKey: "getLyrics",
              params: t2,
              searchParams: (0, n.P)({ sign: t2.sign, timeStamp: t2.timeStamp, format: t2.format }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    54280: (t, e, s) => {
      "use strict";
      s.d(e, { S: () => r });
      var i = s(96559), a = s(53676), n = s(77220);
      class r extends n.X {
        async getUploadUrl(t2, e2) {
          return (await this.httpClient.post(
            "loader/upload-url",
            this.createHttpOptions({
              timeoutKey: "getUploadUrl",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                uid: t2.uid,
                "playlist-id": t2.playlistId,
                visibility: t2.visibility,
                path: t2.path
              })
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    54924: (t, e, s) => {
      "use strict";
      s.d(e, { _: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getAfterTrack(t2, e2) {
          return (await this.httpClient.get(
            "after-track",
            this.createHttpOptions({
              timeoutKey: "getAfterTrack",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, n.P)({
                from: t2.from,
                types: t2.types,
                nextTrackId: t2.nextTrackId,
                prevTrackId: t2.prevTrackId
              })
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    55256: (t, e, s) => {
      var i = {
        "./default.ts": [83491, 3491],
        "./development.ts": [6071, 6071],
        "./production.ts": [82965, 2965],
        "./qa.ts": [45396, 3015],
        "./stress.ts": [65989, 8370],
        "./tokens/DevToolsTokens.ts": [62901]
      };
      function a(t2) {
        if (!s.o(i, t2))
          return Promise.resolve().then(() => {
            var e3 = Error("Cannot find module '" + t2 + "'");
            throw e3.code = "MODULE_NOT_FOUND", e3;
          });
        var e2 = i[t2], a2 = e2[0];
        return Promise.all(e2.slice(1).map(s.e)).then(() => s(a2));
      }
      a.keys = () => Object.keys(i), a.id = 55256, t.exports = a;
    },
    55948: (t, e, s) => {
      "use strict";
      s.d(e, { _: () => r });
      var i = s(96559), a = s(53676), n = s(77220);
      class r extends n.X {
        async getClip(t2, e2) {
          return (await this.httpClient.get(
            "clips",
            this.createHttpOptions({
              timeoutKey: "getClip",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ clipIds: t2.clipIds.join(",") })
            })
          )).json();
        }
        async getCredits(t2, e2) {
          return (await this.httpClient.get(
            "clips/".concat(t2.clipId, "/credits"),
            this.createHttpOptions({ timeoutKey: "getCredits", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getDisclaimer(t2, e2) {
          return (await this.httpClient.get(
            "clips/".concat(t2.clipId, "/disclaimer"),
            this.createHttpOptions({ timeoutKey: "getDisclaimer", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getClipsWillLike(t2, e2) {
          return (await this.httpClient.get(
            "clips/will/like",
            this.createHttpOptions({
              timeoutKey: "getClipsWillLike",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ page: t2.page, pageSize: t2.pageSize })
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    63988: (t, e, s) => {
      "use strict";
      s.d(e, { Z: () => o });
      var i = s(96559), a = s(53676), n = s(76898), r = s(77220);
      class o extends r.X {
        async getStationInfo(t2, e2) {
          return (await this.httpClient.get(
            "rotor/station/".concat(t2.stationId, "/info"),
            this.createHttpOptions({
              timeoutKey: "getStationInfo",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async sessionNew(t2, e2) {
          let s2 = (0, n.F)({
            seeds: t2.seeds,
            queue: t2.queue,
            includeTracksInResponse: t2.includeTracksInResponse,
            trackToStartFrom: t2.trackToStartFrom,
            clientRemoteType: t2.clientRemoteType,
            incognito: t2.incognito,
            child: t2.child,
            allowExplicit: t2.allowExplicit,
            aliceExperiments: t2.aliceExperiments,
            djData: t2.djData,
            useIchwill: t2.useIchwill,
            includeWaveModel: t2.includeWaveModel,
            interactive: t2.interactive
          });
          return (await this.httpClient.post(
            "rotor/session/new",
            this.createHttpOptions({
              timeoutKey: "sessionNew",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async sessionClone(t2, e2) {
          let s2 = (0, n.F)({
            seeds: t2.seeds,
            queue: t2.queue,
            includeTracksInResponse: t2.includeTracksInResponse,
            trackToStartFrom: t2.trackToStartFrom,
            clientRemoteType: t2.clientRemoteType,
            incognito: t2.incognito,
            child: t2.child,
            allowExplicit: t2.allowExplicit,
            aliceExperiments: t2.aliceExperiments,
            djData: t2.djData,
            useIchwill: t2.useIchwill,
            includeWaveModel: t2.includeWaveModel,
            interactive: t2.interactive
          });
          return (await this.httpClient.post(
            "rotor/session/".concat(t2.radioSessionId, "/clone"),
            this.createHttpOptions({
              timeoutKey: "sessionClone",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async sessionTracks(t2, e2) {
          let s2 = (0, n.F)({
            queue: t2.queue,
            aliceExperiments: t2.aliceExperiments,
            djData: t2.djData,
            useIchwill: t2.useIchwill,
            feedbacks: t2.feedbacks
          });
          return (await this.httpClient.post(
            "rotor/session/".concat(t2.radioSessionId, "/tracks"),
            this.createHttpOptions({
              timeoutKey: "sessionTracks",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async sessionFeedback(t2, e2) {
          let s2 = (0, n.F)({ event: t2.feedback.event, batchId: t2.feedback.batchId, from: t2.feedback.from });
          return (await this.httpClient.post(
            "rotor/session/".concat(t2.radioSessionId, "/feedback/"),
            this.createHttpOptions({
              timeoutKey: "sessionFeedback",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async waveLast(t2, e2) {
          return (await this.httpClient.get(
            "rotor/wave/last",
            this.createHttpOptions({ timeoutKey: "waveLast", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async waveSettings(t2, e2) {
          return (await this.httpClient.get(
            "rotor/wave/settings",
            this.createHttpOptions({
              timeoutKey: "waveSettings",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ seeds: null == t2 ? void 0 : t2.seeds })
            })
          )).json();
        }
        async waveLastReset(t2, e2) {
          return (await this.httpClient.post(
            "rotor/wave/last/reset",
            this.createHttpOptions({ timeoutKey: "waveLastReset", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getGenerativeInfo(t2, e2) {
          return (await this.httpClient.get(
            "rotor/station/".concat(t2.stationId, "/stream"),
            this.createHttpOptions({
              timeoutKey: "getGenerativeInfo",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async stationFeedback(t2, e2) {
          return (await this.httpClient.post(
            "rotor/station/".concat(t2.stationId, "/feedback"),
            this.createHttpOptions({
              timeoutKey: "stationFeedback",
              params: t2,
              json: (0, n.F)({ type: t2.type, timestamp: t2.timestamp }),
              searchParams: (0, a.P)({ streamId: t2.streamId }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async combinedLanding(t2, e2) {
          return (await this.httpClient.post(
            "rotor/combined/session/landing",
            this.createHttpOptions({
              timeoutKey: "combinedLanding",
              params: t2,
              json: (0, n.F)({ supportedTypes: t2.supportedTypes, child: t2.child, allowExplicit: t2.allowExplicit }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async combinedSessionNew(t2, e2) {
          return (await this.httpClient.post(
            "rotor/combined/session/new",
            this.createHttpOptions({
              timeoutKey: "combinedSessionNew",
              params: t2,
              json: (0, n.F)({
                supportedTypes: t2.supportedTypes,
                child: t2.child,
                allowExplicit: t2.allowExplicit,
                queue: t2.queue
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async combinedSessionNext(t2, e2) {
          return (await this.httpClient.post(
            "rotor/combined/session/".concat(t2.sessionid, "/next"),
            this.createHttpOptions({
              timeoutKey: "combinedSessionNext",
              params: t2,
              json: (0, n.F)({ queue: t2.queue }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async stationsDashboard(t2, e2) {
          return (await this.httpClient.get(
            "rotor/stations/dashboard",
            this.createHttpOptions({
              timeoutKey: "stationsDashboard",
              params: t2,
              searchParams: (0, a.P)({ limit: t2.limit }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    64659: (t, e, s) => {
      "use strict";
      s.d(e, { c: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getRedAlerts(t2, e2) {
          var s2;
          let i2 = (null == (s2 = t2.common) ? void 0 : s2.language) || this.config.params.common.language;
          return (await this.httpClient.get(
            "proxy/plus-red-alert/v1/alerts",
            this.createHttpOptions({
              timeoutKey: "getRedAlerts",
              params: t2,
              searchParams: (0, n.P)({
                service: t2.service,
                client: t2.client,
                platform: t2.platform,
                countryId: t2.countryId,
                language: i2
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    65098: (t, e, s) => {
      "use strict";
      s.d(e, { n: () => a });
      var i = s(49775);
      let a = (t2) => async (e2) => {
        let s2 = await t2.post(e2.url, {
          body: e2.body,
          headers: e2.headers,
          signal: e2.signal,
          credentials: e2.credentials,
          retry: { config: i.t }
        });
        return await s2.json();
      };
    },
    71020: (t, e, s) => {
      "use strict";
      var i;
      s.d(e, { J: () => i }), (function(t2) {
        t2.OK = "ok", t2.ERROR = "error";
      })(i || (i = {}));
    },
    74875: (t, e, s) => {
      "use strict";
      s.d(e, { o: () => r });
      var i = s(14287), a = s(70755);
      let n = (t2) => 401 === ((t3) => {
        var e2, s2, i2, n2;
        if ((0, a.N)(t3.cause))
          return (null == (s2 = t3.cause) || null == (e2 = s2.response) ? void 0 : e2.statusCode) || (null == (n2 = t3.cause) || null == (i2 = n2.response) ? void 0 : i2.status);
      })(t2), r = (t2, e2) => async (s2) => {
        let r2 = s2.cause;
        if ((0, a.N)(r2) && n(s2))
          try {
            await e2.about();
          } catch (e3) {
            e3 instanceof i.m5 && n(e3) && t2.redirectToLogoutUrl();
          }
        return s2;
      };
    },
    74922: (t, e, s) => {
      "use strict";
      s.d(e, { l: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getTopArtists(t2, e2) {
          return (await this.httpClient.get(
            "personal/top/artists/month",
            this.createHttpOptions({ timeoutKey: "getTopArtists", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    76898: (t, e, s) => {
      "use strict";
      function i(t2) {
        let e2 = {};
        return Object.getOwnPropertyNames(t2).filter((e3) => void 0 !== t2[e3] && null !== t2[e3]).map((s2) => {
          e2[s2] = t2[s2];
        }), e2;
      }
      s.d(e, { F: () => i });
    },
    77534: (t, e, s) => {
      "use strict";
      var i;
      s.d(e, { f: () => i }), (function(t2) {
        t2.OK = "ok", t2.ERROR = "error";
      })(i || (i = {}));
    },
    78226: (t, e, s) => {
      "use strict";
      s.d(e, { D: () => o });
      var i = s(96559), a = s(77220), n = s(53676), r = s(76898);
      class o extends a.X {
        async getPromotionsById(t2, e2) {
          return (await this.httpClient.get(
            "feed/promotions/".concat(t2.promoId),
            this.createHttpOptions({
              timeoutKey: "getPromotionsById",
              params: t2,
              searchParams: (0, n.P)({ checkContent: t2.checkContent }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getWizardGenres(t2, e2) {
          return (await this.httpClient.get(
            "feed/wizard2-new/get-genres",
            this.createHttpOptions({
              timeoutKey: "getWizardGenres",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getWizardArtistsByGenre(t2, e2) {
          let s2 = (0, r.F)({
            genre: t2.genre,
            showedArtists: t2.showedArtists,
            likedArtists: t2.likedArtists,
            unlikedArtists: t2.unlikedArtists,
            countOfNewArtists: t2.countOfNewArtists
          });
          return (await this.httpClient.post(
            "feed/wizard2-new/get-artists-by-genre",
            this.createHttpOptions({
              timeoutKey: "getWizardArtistsByGenre",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async finishWizard(t2, e2) {
          let s2 = (0, r.F)({ genre: t2.genre, likedArtists: t2.likedArtists, unlikedArtists: t2.unlikedArtists });
          await this.httpClient.post(
            "feed/wizard2-new/finish",
            this.createHttpOptions({
              timeoutKey: "finishWizard",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          );
        }
        async infiniteFeed(t2, e2) {
          return (await this.httpClient.get(
            "infinite-feed",
            this.createHttpOptions({
              timeoutKey: "infiniteFeed",
              params: t2,
              searchParams: (0, n.P)({
                batchNumber: t2.batchNumber,
                landingType: t2.landingType,
                supportedBlocks: "generic"
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    79329: (t, e, s) => {
      "use strict";
      s.d(e, { v: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getTrackIds(t2, e2) {
          return (await this.httpClient.get(
            "search-playlist/".concat(t2.uid, "/").concat(t2.kind),
            this.createHttpOptions({
              timeoutKey: "getTrackIds",
              params: t2,
              searchParams: (0, n.P)({ part: t2.part }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    79817: (t, e, s) => {
      "use strict";
      s.d(e, { B: () => r });
      var i = s(96559), a = s(53676), n = s(77220);
      class r extends n.X {
        async getAlbumWithRichTracks(t2, e2) {
          return (await this.httpClient.get(
            "albums/".concat(t2.albumId, "/with-tracks"),
            this.createHttpOptions({
              timeoutKey: "getAlbumWithRichTracks",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                resumeStream: t2.resumeStream,
                page: t2.page,
                pageSize: t2.pageSize,
                "sort-order": t2.sortOrder,
                richTracks: true,
                withListeningFinished: true
              })
            })
          )).json();
        }
        async getAlbumWithTracksIds(t2, e2) {
          return (await this.httpClient.get(
            "albums/".concat(t2.albumId, "/with-tracks"),
            this.createHttpOptions({
              timeoutKey: "getAlbumWithTracksIds",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({
                resumeStream: t2.resumeStream,
                page: t2.page,
                pageSize: t2.pageSize,
                "sort-order": t2.sortOrder,
                richTracks: false,
                withListeningFinished: true
              })
            })
          )).json();
        }
        async getDisclaimer(t2, e2) {
          return (await this.httpClient.get(
            "albums/".concat(t2.albumId, "/disclaimer"),
            this.createHttpOptions({ timeoutKey: "getDisclaimer", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getTrailer(t2, e2) {
          return (await this.httpClient.get(
            "albums/".concat(t2.albumId, "/trailer"),
            this.createHttpOptions({ timeoutKey: "getTrailer", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getRelatedContent(t2, e2) {
          return (await this.httpClient.get(
            "albums/".concat(t2.albumId, "/related-content"),
            this.createHttpOptions({
              timeoutKey: "getRelatedContent",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getAlbums(t2, e2) {
          return (await this.httpClient.get(
            "albums",
            this.createHttpOptions({
              timeoutKey: "getAlbums",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, a.P)({ albumIds: t2.albumIds.join(",") })
            })
          )).json();
        }
        async getSimilarEntities(t2, e2) {
          return (await this.httpClient.get(
            "albums/".concat(t2.albumId, "/similar-entities"),
            this.createHttpOptions({
              timeoutKey: "getSimilarEntities",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getExternalStreamingLinks(t2, e2) {
          return (await this.httpClient.get(
            "albums/".concat(t2.albumId, "/external-streaming-links"),
            this.createHttpOptions({
              timeoutKey: "getExternalStreamingLinks",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    79850: (t, e, s) => {
      "use strict";
      s.d(e, { S: () => o });
      var i = s(96559), a = s(97992), n = s(78793), r = s(95998);
      class o {
        async get(t2) {
          let e2 = new n.m(
            "GET method is not supported by BeaconHttpClient. navigator.sendBeacon() only supports POST requests.",
            { code: a.Z.METHOD_NOT_SUPPORTED, cause: { method: "GET", supportedMethods: ["POST"] } }
          );
          return await this.executeBeforeErrorHooks(e2), this.executeRequestDoneHooks(t2, { method: "GET" }, void 0, e2), Promise.reject(e2);
        }
        async put(t2) {
          let e2 = new n.m(
            "PUT method is not supported by BeaconHttpClient. navigator.sendBeacon() only supports POST requests.",
            { code: a.Z.METHOD_NOT_SUPPORTED, cause: { method: "PUT", supportedMethods: ["POST"] } }
          );
          return await this.executeBeforeErrorHooks(e2), this.executeRequestDoneHooks(t2, { method: "PUT" }, void 0, e2), Promise.reject(e2);
        }
        async patch(t2) {
          let e2 = new n.m(
            "PATCH method is not supported by BeaconHttpClient. navigator.sendBeacon() only supports POST requests.",
            { code: a.Z.METHOD_NOT_SUPPORTED, cause: { method: "PATCH", supportedMethods: ["POST"] } }
          );
          return await this.executeBeforeErrorHooks(e2), this.executeRequestDoneHooks(t2, { method: "PATCH" }, void 0, e2), Promise.reject(e2);
        }
        async delete(t2) {
          let e2 = new n.m(
            "DELETE method is not supported by BeaconHttpClient. navigator.sendBeacon() only supports POST requests.",
            { code: a.Z.METHOD_NOT_SUPPORTED, cause: { method: "DELETE", supportedMethods: ["POST"] } }
          );
          return await this.executeBeforeErrorHooks(e2), this.executeRequestDoneHooks(t2, { method: "DELETE" }, void 0, e2), Promise.reject(e2);
        }
        async head(t2) {
          let e2 = new n.m(
            "HEAD method is not supported by BeaconHttpClient. navigator.sendBeacon() only supports POST requests.",
            { code: a.Z.METHOD_NOT_SUPPORTED, cause: { method: "HEAD", supportedMethods: ["POST"] } }
          );
          return await this.executeBeforeErrorHooks(e2), this.executeRequestDoneHooks(t2, { method: "HEAD" }, void 0, e2), Promise.reject(e2);
        }
        async post(t2) {
          let e2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return this.request(t2, { ...e2, method: "POST" });
        }
        async request(t2, e2) {
          let s2, i2, r2 = e2.method || "GET";
          if ("POST" !== r2)
            throw new n.m(
              "".concat(
                r2,
                " method is not supported by BeaconHttpClient. navigator.sendBeacon() only supports POST requests."
              ),
              { code: a.Z.METHOD_NOT_SUPPORTED, cause: { method: r2, supportedMethods: ["POST"] } }
            );
          if ("undefined" == typeof navigator || "function" != typeof navigator.sendBeacon)
            throw new n.m("navigator.sendBeacon is not available in this environment", { code: a.Z.NOT_AVAILABLE });
          try {
            let i3 = this.mergeOptions(e2), a2 = this.buildUrl(t2, i3);
            await this.executeBeforeRequestHooks(a2, i3);
            let n2 = this.prepareBeaconData(i3);
            return s2 = await this.executeWithRetries(a2, n2, i3);
          } catch (t3) {
            throw i2 = t3, await this.executeBeforeErrorHooks(t3, e2), t3;
          } finally {
            this.executeRequestDoneHooks(t2, e2, s2, i2);
          }
        }
        mergeOptions(t2) {
          return { ...this.defaultOptions, ...t2, headers: { ...this.defaultOptions.headers, ...t2.headers } };
        }
        buildUrl(t2, e2) {
          let s2 = t2;
          if (e2.prefixUrl) {
            let i2 = e2.prefixUrl.toString().replace(/\/$/, ""), a2 = t2.replace(/^\//, "");
            s2 = "".concat(i2, "/").concat(a2);
          }
          if (e2.searchParams) {
            let t3 = new URL(s2);
            ("string" == typeof e2.searchParams ? new URLSearchParams(e2.searchParams) : e2.searchParams).forEach(
              (e3, s3) => {
                t3.searchParams.set(s3, e3);
              }
            ), s2 = t3.toString();
          }
          return s2;
        }
        async executeBeforeRequestHooks(t2, e2) {
          var s2, i2;
          for (let a2 of [
            ...this.beforeRequestHooks,
            ...null != (i2 = null == (s2 = e2.hooks) ? void 0 : s2.beforeRequest) ? i2 : []
          ]) {
            let s3 = {
              url: t2,
              method: e2.method,
              headers: new Headers(e2.headers || {}),
              searchParams: e2.searchParams ? "string" == typeof e2.searchParams ? new URLSearchParams(e2.searchParams) : e2.searchParams : new URLSearchParams(),
              json: e2.json,
              timeout: e2.timeout
            };
            await a2(s3);
          }
        }
        async executeBeforeErrorHooks(t2, e2) {
          var s2, i2;
          let a2 = [
            ...this.beforeErrorHooks,
            ...null != (i2 = null == e2 || null == (s2 = e2.hooks) ? void 0 : s2.beforeError) ? i2 : []
          ], r2 = t2 instanceof n.m ? t2 : new n.m(t2 instanceof Error ? t2.message : "Unknown error", { cause: t2 });
          for (let t3 of a2) {
            let e3 = await t3(r2);
            e3 instanceof n.m && Object.assign(r2, e3);
          }
        }
        executeRequestDoneHooks(t2, e2, s2, i2) {
          this.requestDoneHooks.forEach((a2) => {
            a2({ url: t2, options: e2, response: s2, error: i2 });
          });
        }
        prepareBeaconData(t2) {
          return void 0 !== t2.body ? t2.body instanceof Blob || t2.body instanceof ArrayBuffer || t2.body instanceof FormData || t2.body instanceof URLSearchParams || "string" == typeof t2.body ? t2.body : String(t2.body) : void 0 !== t2.json ? JSON.stringify(t2.json) : null;
        }
        createMockResponse(t2, e2) {
          let s2 = {};
          return void 0 !== e2.json ? s2["content-type"] = "application/json" : e2.body instanceof FormData ? s2["content-type"] = "multipart/form-data" : e2.body instanceof URLSearchParams && (s2["content-type"] = "application/x-www-form-urlencoded"), {
            headers: s2,
            statusCode: 204,
            statusMessage: "No Content",
            url: t2,
            json: async () => Promise.reject(
              new n.m(
                "BeaconHttpClient does not receive response data. navigator.sendBeacon() is a fire-and-forget API.",
                { code: a.Z.NO_RESPONSE_DATA }
              )
            ),
            text: async () => Promise.reject(
              new n.m(
                "BeaconHttpClient does not receive response data. navigator.sendBeacon() is a fire-and-forget API.",
                { code: a.Z.NO_RESPONSE_DATA }
              )
            ),
            arrayBuffer: async () => Promise.reject(
              new n.m(
                "BeaconHttpClient does not receive response data. navigator.sendBeacon() is a fire-and-forget API.",
                { code: a.Z.NO_RESPONSE_DATA }
              )
            ),
            clone: () => this.createMockResponse(t2, e2),
            request: { prefixUrl: e2.prefixUrl, headers: e2.headers, searchParams: e2.searchParams, method: e2.method }
          };
        }
        async executeWithRetries(t2, e2, s2) {
          var i2, r2;
          let o2 = null == (i2 = s2.retry) ? void 0 : i2.config, l = null != (r2 = null == o2 ? void 0 : o2.totalRequestsLimit) ? r2 : 1, c = new n.m("All retry attempts failed", { code: a.Z.RETRY_EXHAUSTED });
          for (let i3 = 1; i3 <= l; i3++)
            try {
              if (!navigator.sendBeacon(t2, e2)) {
                let t3 = new n.m("Failed to queue beacon request.", { code: a.Z.QUEUE_FAILED });
                if (await this.handleRetryableError(t3, i3, l, o2)) continue;
                throw t3;
              }
              return this.createMockResponse(t2, s2);
            } catch (e3) {
              let t3 = e3 instanceof n.m ? e3 : new n.m(e3 instanceof Error ? e3.message : "Unknown error", { cause: e3, code: a.Z.RETRY_EXHAUSTED });
              if (await this.handleRetryableError(t3, i3, l, o2, s2)) continue;
              throw t3;
            }
          throw c;
        }
        async handleRetryableError(t2, e2, s2, i2, a2) {
          if (e2 < s2 && this.shouldRetryForError(t2, i2)) {
            await this.executeBeforeRetryHooks(t2, e2, a2);
            let s3 = this.getRetryDelay(t2, e2 - 1, i2);
            return s3 > 0 && await (0, r.c)(s3), true;
          }
          return false;
        }
        async executeBeforeRetryHooks(t2, e2, s2) {
          var i2, a2;
          for (let n2 of [
            ...this.beforeRetryHooks,
            ...null != (a2 = null == s2 || null == (i2 = s2.hooks) ? void 0 : i2.beforeRetry) ? a2 : []
          ])
            await n2(t2, e2);
        }
        shouldRetryForError(t2, e2) {
          return !!e2 && !!e2.statusCodes.NON_HTTP_ERROR && t2.code === a.Z.QUEUE_FAILED;
        }
        getRetryDelay(t2, e2, s2) {
          var i2;
          if (!s2) return 0;
          let a2 = s2.statusCodes.NON_HTTP_ERROR, n2 = null == a2 ? void 0 : a2.attempts;
          return !n2 || e2 >= n2.length ? 0 : null != (i2 = n2[e2]) ? i2 : 0;
        }
        constructor(t2 = {}) {
          var e2, s2, a2, n2, r2, o2, l, c;
          (0, i._)(this, "requestDoneHooks", []), (0, i._)(this, "beforeRequestHooks", []), (0, i._)(this, "beforeErrorHooks", []), (0, i._)(this, "beforeRetryHooks", []), (0, i._)(this, "defaultOptions", void 0), this.defaultOptions = t2, this.beforeRequestHooks = null != (r2 = null == (e2 = t2.hooks) ? void 0 : e2.beforeRequest) ? r2 : [], this.beforeErrorHooks = null != (o2 = null == (s2 = t2.hooks) ? void 0 : s2.beforeError) ? o2 : [], this.beforeRetryHooks = null != (l = null == (a2 = t2.hooks) ? void 0 : a2.beforeRetry) ? l : [], this.requestDoneHooks = null != (c = null == (n2 = t2.hooks) ? void 0 : n2.onRequestDone) ? c : [];
        }
      }
    },
    80506: (t, e, s) => {
      "use strict";
      s.d(e, { a: () => a });
      var i = s(87965);
      let a = () => {
        let t2 = null, e2 = new i.cJ(false), s2 = [];
        return {
          isLoaded: e2,
          init: (i2) => {
            var a2, n;
            if (void 0 !== (null == (a2 = window.Ya) ? void 0 : a2.Metrika2) && !e2.value)
              try {
                t2 = new window.Ya.Metrika2({ ...i2 }), e2.value = true, n = t2, s2.forEach((t3) => {
                  t3(n);
                }), s2.length = 0;
              } catch (t3) {
                ("string" == typeof t3 || t3 instanceof Error) && i2.logger.error(t3);
              }
          },
          count: function(e3) {
            let i2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "counter";
            t2 ? t2.params({ [i2]: e3 }) : s2.push((t3) => {
              t3.params({ [i2]: e3 });
            });
          },
          hit: (e3) => {
            t2 ? t2.hit(e3) : s2.push((t3) => {
              t3.hit(e3);
            });
          },
          reachGoal: (e3, i2) => {
            if (!t2) return void s2.push((t3) => t3.reachGoal(e3, i2));
            t2.reachGoal(e3, i2);
          }
        };
      };
    },
    80535: (t, e, s) => {
      "use strict";
      s.d(e, { c: () => r });
      var i = s(96559), a = s(77220), n = s(76898);
      class r extends a.X {
        async sendViews(t2, e2) {
          let s2 = (0, n.F)({ lyricViews: t2.lyricViews });
          await this.httpClient.post(
            "lyric-views",
            this.createHttpOptions({
              timeoutKey: "sendViews",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              json: s2
            })
          );
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    81658: (t, e, s) => {
      "use strict";
      s.d(e, { H: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getMetatags(t2, e2) {
          return (await this.httpClient.get(
            "landing3/metatags",
            this.createHttpOptions({ timeoutKey: "getMetatags", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async getChart(t2, e2) {
          return (await this.httpClient.get(
            "landing3/chart",
            this.createHttpOptions({ timeoutKey: "getChart", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    81760: (t, e, s) => {
      "use strict";
      s.d(e, { N: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async sendMetrics(t2) {
          let { varsString: e2, reqid: s2, table: i2, path: a2, slots: n2, experimentsSetting: r } = t2, o = [
            "/reqid=".concat(s2),
            "/table=".concat(i2),
            a2 ? "/path=".concat(a2) : "",
            n2 ? "/slots=".concat(Array.isArray(n2) ? n2.join(";") : n2) : "",
            r ? "/experiments=".concat(Array.isArray(r) ? r.join(";") : r) : "",
            "/vars=".concat(e2),
            "/cts=".concat(Date.now()),
            "/*"
          ].filter(Boolean).join("");
          return this.httpClient.post("", {
            prefixUrl: this.config.prefixUrl,
            body: o,
            retry: this.config.retryPolicyConfig ? { config: this.config.retryPolicyConfig } : void 0
          });
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    84690: (t, e, s) => {
      "use strict";
      s.d(e, { Q: () => g });
      var i = s(96559), a = s(51736), n = s(38697), r = s(67195), o = s(31643), l = s(78793), c = s(41999);
      let u = { retryLimit: 0, retryDelay: 0 };
      var d = s(95998);
      let p = async (t2) => {
        var e2, s2;
        let { options: i2, error: a2, retryAttempt: n2, clientRetryConfig: r2 } = t2;
        if (null == a2 || null == (s2 = a2.response) || null == (e2 = s2.headers) ? void 0 : e2.get("Retry-After")) return;
        let o2 = ((t3) => {
          let { retryAttempt: e3, error: s3, retryAfter: i3, retryPolicyConfig: a3 } = t3;
          if (!a3) return u;
          if (i3) return a3.totalRequestsLimit > e3 ? { retryLimit: a3.totalRequestsLimit, retryDelay: i3 } : u;
          if (a3.statusCodes[s3]) {
            var n3;
            let t4 = a3.statusCodes[s3];
            if ((null == t4 || null == (n3 = t4.attempts) ? void 0 : n3.length) && t4.attempts.length >= e3)
              return { retryLimit: t4.attempts.length + 1, retryDelay: t4.attempts[e3 - 1] || 1 };
          }
          return u;
        })({
          error: ((t3) => (null == t3 ? void 0 : t3.code) === "ETIMEDOUT" ? "TIMEOUT" : t3.response && (t3.response.status || t3.response.statusCode) || "NON_HTTP_ERROR")(a2),
          retryAttempt: n2,
          retryPolicyConfig: null == r2 ? void 0 : r2.config
        });
        i2.retry.limit = o2.retryLimit, await (0, d.c)(o2.retryDelay);
      }, h = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "get", "post", "put", "patch", "delete", "head"];
      class g {
        async get(t2) {
          let e2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return this.request(t2, { ...e2, method: "GET" });
        }
        async post(t2) {
          let e2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return this.request(t2, { ...e2, method: "POST" });
        }
        async put(t2) {
          let e2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return this.request(t2, { ...e2, method: "PUT" });
        }
        async patch(t2) {
          let e2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return this.request(t2, { ...e2, method: "PATCH" });
        }
        async delete(t2) {
          let e2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return this.request(t2, { ...e2, method: "DELETE" });
        }
        async head(t2) {
          let e2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
          return this.request(t2, { ...e2, method: "HEAD" });
        }
        async request(t2, e2) {
          let s2, i2;
          try {
            let i3 = Date.now(), a2 = await this.client(t2, this.optionsConverter(e2)), n2 = Date.now() - i3;
            return s2 = this.responseConverter(a2, e2, { start: i3, response: n2 });
          } catch (t3) {
            if (t3 instanceof a.H) throw this.errorConverter(t3);
            if (i2 = t3, t3 instanceof n.M)
              throw this.afterTimeoutHooks.forEach((e3) => {
                e3(this.errorConverter(t3));
              }), this.errorConverter(t3);
            throw t3;
          } finally {
            this.requestDoneHooks.forEach((a2) => {
              a2({ url: t2, options: e2, response: s2, error: i2 });
            });
          }
        }
        optionsConverter(t2) {
          let {
            prefixUrl: e2,
            method: s2,
            searchParams: i2,
            headers: a2,
            json: n2,
            hooks: r2,
            retry: o2,
            timeout: l2,
            body: c2,
            credentials: u2,
            signal: d2,
            excludeHeaders: g2
          } = t2, y = {};
          if (void 0 !== u2 && (y.credentials = u2), void 0 !== e2 && (y.prefixUrl = e2), void 0 !== s2 && (y.method = s2), void 0 !== a2) {
            var m;
            y.headers = { ...a2, "user-agent": null != (m = a2["user-agent"]) ? m : a2["User-Agent"] };
          }
          if (void 0 !== i2 && (y.searchParams = i2), void 0 !== n2 && (y.json = n2), "number" == typeof l2 && (y.timeout = l2), void 0 !== c2 && (y.body = c2), void 0 !== d2 && (y.signal = d2), (null == o2 ? void 0 : o2.config) && (y.retry = {
            limit: o2.config.totalRequestsLimit,
            backoffLimit: 1,
            statusCodes: Object.keys(o2.config.statusCodes).filter((t3) => !isNaN(Number(t3))).map((t3) => parseInt(t3, 10)),
            methods: h
          }, y.hooks = y.hooks || {}, y.hooks.beforeRetry = y.hooks.beforeRetry || [], y.hooks.beforeRetry.push(async (t3) => {
            await p({
              request: t3.request,
              options: t3.options,
              error: t3.error,
              retryAttempt: t3.retryCount,
              clientRetryConfig: o2
            });
          })), r2) {
            let t3, { beforeRequest: e3, beforeRetry: s3, beforeError: i3, afterResponse: a3 } = r2;
            void 0 === y.hooks && (y.hooks = {}), Array.isArray(e3) && (y.hooks.beforeRequest = e3.map((e4) => async (s4, i4) => {
              t3 = Date.now();
              let a4 = { ...this.normalizeOptions(s4, i4), headers: s4.headers };
              await e4(a4);
            })), Array.isArray(s3) && (y.hooks.beforeRetry = y.hooks.beforeRetry || [], y.hooks.beforeRetry = y.hooks.beforeRetry.concat(
              s3.map((t4) => async (e4) => {
                let { request: s4, options: i4, error: a4, retryCount: n3 } = e4;
                await t4(this.errorConverter(a4, s4, i4), n3);
              })
            )), Array.isArray(i3) && (y.hooks.beforeError = i3.map((t4) => async (e4) => (await t4(this.errorConverter(e4)), e4))), Array.isArray(a3) && (y.hooks.afterResponse = a3.map((e4) => async (s4, i4, a4) => {
              let n3 = this.normalizeOptions(s4, i4), r3 = Date.now();
              return await e4(this.responseConverter(a4, n3, { start: t3, response: r3 })), a4;
            }));
          }
          return void 0 !== g2 && (void 0 === y.hooks && (y.hooks = {}), void 0 === y.hooks.beforeRequest && (y.hooks.beforeRequest = []), y.hooks.beforeRequest.push((t3) => {
            if (g2) for (let e3 of g2) t3.headers.has(e3) && t3.headers.delete(e3);
          })), y;
        }
        responseConverter(t2, e2, s2) {
          return {
            headers: Object.fromEntries(t2.headers.entries()),
            statusCode: t2.status,
            statusMessage: t2.statusText,
            url: t2.url,
            json: t2.json.bind(t2),
            text: t2.text.bind(t2),
            arrayBuffer: t2.arrayBuffer.bind(t2),
            timings: s2,
            clone: () => this.responseConverter(t2.clone(), e2, s2),
            request: { prefixUrl: e2.prefixUrl, headers: e2.headers, searchParams: e2.searchParams, method: e2.method }
          };
        }
        normalizeOptions(t2, e2) {
          let s2 = new URL(t2.url);
          return {
            headers: this.normalizeHeaders(e2.headers),
            searchParams: new URLSearchParams(s2.search),
            json: t2.json,
            url: t2.url,
            method: this.convertMethod(e2.method),
            timeout: void 0
          };
        }
        normalizeHeaders(t2) {
          return void 0 === t2 ? {} : t2 instanceof Headers ? Object.fromEntries(t2.entries()) : Array.isArray(t2) ? Object.fromEntries(t2) : t2;
        }
        errorConverter(t2, e2, s2) {
          if (t2 instanceof a.H || t2 instanceof n.M)
            return new c.G(t2.message, {
              statusCode: t2 instanceof n.M ? o.X.REQUEST_TIMEOUT : t2.response.status,
              cause: t2
            });
          let i2 = null;
          return e2 && s2 && (i2 = {
            headers: null == s2 ? void 0 : s2.headers,
            originalRequestHeaders: e2.headers,
            url: null == e2 ? void 0 : e2.url,
            method: null == e2 ? void 0 : e2.method
          }), new l.m(t2.message, { cause: { error: t2, request: i2 } });
        }
        convertMethod(t2) {
          return void 0 !== t2 && h.includes(t2) ? t2.toUpperCase() : "GET";
        }
        convertMethods(t2) {
          let e2 = /* @__PURE__ */ new Set();
          return t2.forEach((t3) => {
            h.includes(t3) && e2.add(t3.toUpperCase());
          }), [...e2];
        }
        constructor(t2 = {}) {
          var e2, s2, a2, n2;
          (0, i._)(this, "client", void 0), (0, i._)(this, "afterTimeoutHooks", []), (0, i._)(this, "requestDoneHooks", []), this.client = r.Ay.create(this.optionsConverter(t2)), this.afterTimeoutHooks = null != (a2 = null == (e2 = t2.hooks) ? void 0 : e2.afterTimeout) ? a2 : [], this.requestDoneHooks = null != (n2 = null == (s2 = t2.hooks) ? void 0 : s2.onRequestDone) ? n2 : [];
        }
      }
    },
    86420: (t, e, s) => {
      "use strict";
      s.d(e, { g: () => r });
      var i = s(96559), a = s(76898), n = s(77220);
      class r extends n.X {
        async getTracksFilters(t2, e2) {
          let s2 = (0, a.F)({ trackIds: t2.trackIds });
          return (await this.httpClient.post(
            "filters/tracks",
            this.createHttpOptions({
              timeoutKey: "getTracksFilters",
              params: t2,
              json: s2,
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        async getFilterName(t2, e2) {
          return (await this.httpClient.get(
            "filters/".concat(t2.filterId),
            this.createHttpOptions({ timeoutKey: "getFilterName", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    86622: (t, e, s) => {
      "use strict";
      var i;
      s.d(e, { Q: () => a, c: () => i }), (function(t2) {
        t2[t2.ERROR = 10] = "ERROR", t2[t2.WARNING = 20] = "WARNING", t2[t2.INFO = 30] = "INFO", t2[t2.DEBUG = 40] = "DEBUG", t2[t2.TRACE = 50] = "TRACE";
      })(i || (i = {}));
      let a = { [i.ERROR]: "error", [i.WARNING]: "warn", [i.INFO]: "info", [i.DEBUG]: "debug", [i.TRACE]: "trace" };
    },
    87716: (t, e, s) => {
      "use strict";
      s.d(e, { q: () => o });
      var i = s(96559), a = s(77220), n = s(76898), r = s(53676);
      class o extends a.X {
        async getPromoAlbumInfo(t2, e2) {
          return (await this.httpClient.get(
            "promo/albums/".concat(t2.albumId),
            this.createHttpOptions({
              timeoutKey: "getPromoAlbumInfo",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, r.P)({ campaignId: t2.campaignId })
            })
          )).json();
        }
        async getAlbumCpaId(t2, e2) {
          return (await this.httpClient.get(
            "promo/albums/".concat(t2.albumId, "/cpa-id"),
            this.createHttpOptions({ timeoutKey: "getAlbumCpaId", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        async sendFeedback(t2, e2) {
          await this.httpClient.post(
            "promo/feedback",
            this.createHttpOptions({
              timeoutKey: "sendFeedback",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              json: (0, n.F)({ reaction: t2.reaction, yclid: t2.yclid, campaignId: t2.campaignId, trackId: t2.trackId })
            })
          );
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    88246: (t, e, s) => {
      "use strict";
      s.d(e, { x: () => a });
      var i = s(9348);
      let a = (t2) => {
        t2.headers.has("x-request-id") || t2.headers.set("x-request-id", (0, i.A)());
      };
    },
    88660: (t, e, s) => {
      "use strict";
      s.d(e, { w: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getAllIds(t2, e2) {
          return (await this.httpClient.get(
            "library/all-ids",
            this.createHttpOptions({ timeoutKey: "getAllIds", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    90579: (t, e, s) => {
      "use strict";
      s.d(e, { b: () => a });
      var i = s(14287);
      let a = (t2) => class extends t2 {
        error(t3, e2) {
          !(t3 instanceof i.m5) && (t3 instanceof Error || "string" == typeof t3) && super.error(t3, e2);
        }
        constructor(t3) {
          super(t3);
        }
      };
    },
    91927: (t, e, s) => {
      "use strict";
      s.d(e, { q: () => c });
      var i = s(96559), a = s(46175), n = s(59955), r = s(21863), o = s(98388);
      let l = () => "SECRET";
      class c {
        formatMessage(t2, e2) {
          let s2, i2 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, n2 = arguments.length > 3 ? arguments[3] : void 0, r2 = String(e2 instanceof Error && e2.stack ? e2.stack : e2), l2 = (0, o.A)({ ...this.additionalData, ...i2 });
          return (Object.keys(l2).length && (s2 = this.obfuscateData(l2)), n2) ? "".concat(r2, " ").concat(a(s2)) : [r2, s2];
        }
        obfuscateData(t2) {
          var e2;
          if (null == (e2 = this.secureFields) ? void 0 : e2.length)
            for (let e3 of this.secureFields) void 0 !== (0, n.A)(t2, e3) && (0, r.A)(t2, e3, l());
          return t2;
        }
        constructor({ additionalData: t2, maxLogLevel: e2, secureFields: s2 }) {
          (0, i._)(this, "maxLogLevel", void 0), (0, i._)(this, "secureFields", void 0), (0, i._)(this, "additionalData", void 0), this.maxLogLevel = e2, this.secureFields = s2, this.additionalData = t2;
        }
      }
    },
    92103: (t, e, s) => {
      "use strict";
      s.d(e, { I: () => o });
      var i = s(96559), a = s(77220), n = s(53676), r = s(76898);
      class o extends a.X {
        async getMusicHistory(t2, e2) {
          return (await this.httpClient.get(
            "music-history",
            this.createHttpOptions({
              timeoutKey: "getMusicHistory",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, n.P)({ fullModelsCount: t2.fullModelsCount })
            })
          )).json();
        }
        async getMusicHistoryItems(t2, e2) {
          return (await this.httpClient.post(
            "music-history/items",
            this.createHttpOptions({
              timeoutKey: "getMusicHistoryItems",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              json: (0, r.F)({ items: t2.items })
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    93076: (t, e, s) => {
      "use strict";
      s.d(e, { a: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getTopByGenre(t2, e2) {
          return (await this.httpClient.get(
            "top/".concat(t2.category),
            this.createHttpOptions({
              timeoutKey: "getTopByGenre",
              params: t2,
              searchParams: (0, n.P)({
                genre: t2.genre,
                period: t2.period,
                page: t2.page,
                pageSize: t2.pageSize,
                popularTracksPerArtist: t2.popularTracksPerArtist,
                chartRegion: t2.chartRegion
              }),
              signal: null == e2 ? void 0 : e2.signal
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    94150: (t, e, s) => {
      "use strict";
      s.d(e, { l: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async getPins(t2, e2) {
          return (await this.httpClient.get(
            "pins",
            this.createHttpOptions({ timeoutKey: "getPins", params: t2, signal: null == e2 ? void 0 : e2.signal })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    94753: (t, e, s) => {
      var i = {
        "./clientSafeConfig/default.ts": [83491, 3491],
        "./clientSafeConfig/development.ts": [6071, 6071],
        "./clientSafeConfig/production.ts": [82965, 2965],
        "./clientSafeConfig/qa.ts": [45396, 3015],
        "./clientSafeConfig/stress.ts": [65989, 8370],
        "./clientSafeConfig/tokens/DevToolsTokens.ts": [62901],
        "./default.ts": [80738, 8357],
        "./development.ts": [58814, 8814],
        "./production.ts": [10622, 622],
        "./qa.ts": [9259, 9259],
        "./retryPolicyConfigs/musicExternalApiRetryPolicyConfig.ts": [49775],
        "./retryPolicyConfigs/musicExternalApiRetryPolicyServerConfig.ts": [52580, 2580],
        "./stress.ts": [83273, 3273],
        "./types/ConfigVariables.ts": [62638, 2638],
        "./types/ConfigVariablesMainPlayback.ts": [28170, 8170],
        "./types/ConfigVariablesPayment.ts": [10588, 588],
        "./types/ConfigVariablesPlayer.ts": [68631, 8631],
        "./types/ConfigVariablesResource.ts": [43654, 3654],
        "./types/ConfigVariablesTelemetry.ts": [78213, 8213],
        "./types/ConfigVariablesTrailerPlayback.ts": [46276, 6276],
        "./types/ConfigVariablesVHMediaProvider.ts": [58713, 8713],
        "./utils/getAfishaClientId.ts": [39399, 9399],
        "./utils/getClientSafeConfig.ts": [27493],
        "./utils/getConfig.ts": [12979]
      };
      function a(t2) {
        if (!s.o(i, t2))
          return Promise.resolve().then(() => {
            var e3 = Error("Cannot find module '" + t2 + "'");
            throw e3.code = "MODULE_NOT_FOUND", e3;
          });
        var e2 = i[t2], a2 = e2[0];
        return Promise.all(e2.slice(1).map(s.e)).then(() => s(a2));
      }
      a.keys = () => Object.keys(i), a.id = 94753, t.exports = a;
    },
    95198: (t, e, s) => {
      "use strict";
      s.d(e, { L: () => r });
      var i = s(96559), a = s(77220), n = s(76898);
      class r extends a.X {
        async sync(t2, e2) {
          return (await this.httpClient.post(
            "collection/sync",
            this.createHttpOptions({
              timeoutKey: "sync",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              json: (0, n.F)({
                likedAlbums: t2.likedAlbums,
                likedArtists: t2.likedArtists,
                likedClips: t2.likedClips,
                likedTracks: t2.likedTracks,
                presavedAlbums: t2.presavedAlbums,
                ownPlaylists: t2.ownPlaylists,
                likedPlaylists: t2.likedPlaylists
              })
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    95998: (t, e, s) => {
      "use strict";
      s.d(e, { c: () => i });
      let i = async (t2) => new Promise((e2) => setTimeout(e2, t2));
    },
    96992: (t, e, s) => {
      "use strict";
      s.d(e, { _: () => r });
      var i = s(96559), a = s(77220), n = s(53676);
      class r extends a.X {
        async getAvailabilityTracks(t2, e2) {
          return (await this.httpClient.post(
            "availability/tracks",
            this.createHttpOptions({
              timeoutKey: "getAvailabilityTracks",
              params: t2,
              signal: null == e2 ? void 0 : e2.signal,
              searchParams: (0, n.P)({ trackIds: t2.trackIds })
            })
          )).json();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    },
    99676: (t, e, s) => {
      "use strict";
      s.d(e, { s: () => n });
      var i = s(96559), a = s(77220);
      class n extends a.X {
        async uploadFile(t2, e2) {
          return (await this.httpClient.post(
            t2.url,
            this.createHttpOptions(
              {
                timeoutKey: "uploadFile",
                params: t2,
                body: t2.formData,
                excludeHeaders: ["x-request-id", "x-retry-count"],
                signal: null == e2 ? void 0 : e2.signal
              },
              { withoutHeaders: true }
            )
          )).json();
        }
        async reportForAlbumPromo(t2, e2) {
          await this.httpClient.get(
            t2,
            this.createHttpOptions(
              {
                timeoutKey: "reportForAlbumPromo",
                excludeHeaders: ["x-request-id", "x-retry-count"],
                signal: null == e2 ? void 0 : e2.signal
              },
              { withoutHeaders: true }
            )
          );
        }
        async getLyricsText(t2, e2) {
          return (await this.httpClient.get(
            t2,
            this.createHttpOptions(
              {
                timeoutKey: "getLyricsText",
                excludeHeaders: ["x-request-id", "x-retry-count"],
                signal: null == e2 ? void 0 : e2.signal
              },
              { withoutHeaders: true }
            )
          )).text();
        }
        constructor(t2, e2) {
          super(t2, e2), (0, i._)(this, "httpClient", void 0), (0, i._)(this, "config", void 0), this.httpClient = t2, this.config = e2;
        }
      }
    }
  }
]);
