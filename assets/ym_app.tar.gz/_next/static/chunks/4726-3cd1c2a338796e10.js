(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4726],
  {
    4499: (e, t, a) => {
      "use strict";
      a.d(t, { M: () => s });
      var l = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let i = await (0, l.WGy)(t2.locale), o = i({ id: "metadata.label-artists-title" }, { labelName: e2.name, labelType: e2.type }), n = i({ id: "metadata.label-artists-description" }, { labelName: e2.name, labelType: e2.type });
        return {
          title: o,
          description: n,
          openGraph: (0, l.i$E)({
            ogTitle: o,
            ogDescription: n,
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            siteName: i({ id: "metadata.yandex-music" }),
            ogType: "music.playlist"
          }),
          twitter: (0, l.HRN)({
            cardType: l.WfF.APP,
            title: o,
            url: t2.url,
            appName: i({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, l.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: i({ id: "metadata.yandex-music" })
          }),
          alternates: (0, l.SEs)("/label/:labelId/artists", t2.tld, { params: { labelId: e2.id } })
        };
      }
    },
    6094: (e, t, a) => {
      "use strict";
      a.d(t, { LabelAlbumsPage: () => S });
      var l = a(54486), s = a(50420), r = a(28303), i = a(97396), o = a(61910), n = a(43426), u = a(31500), d = a(8817), m = a(97800), c = a(82644), g = a(94376), b = a(33276), p = a(40502), L = a(74125), N = a(80585), h = a(18569), y = a(52456), _ = a.n(y);
      let S = (0, r.PA)((e2) => {
        let { labelId: t2, preloadedLabel: a2, preloadedAlbums: r2, sortBy: y2 } = e2, {
          label: {
            id: S2,
            type: A,
            name: x,
            albumsSubpage: f,
            reset: v,
            isNeededToLoad: C,
            getData: P,
            isPublisher: T
          },
          settings: { isMobile: E },
          experiments: j
        } = (0, L.Pjs)(), { formatMessage: R } = (0, n.A)(), { contentScrollRef: I, setContentScrollRef: w } = (0, L.gKY)(), X = (0, L.W6M)(), B = T ? R({ id: "page.label-podcast-header" }, { labelName: x }) : R({ id: "page.label-albums-header" }, { labelName: x }), O = (0, d.c)((e3) => {
          var a3;
          f.getData({ labelId: Number(t2), page: e3, pageSize: 20, sortBy: null != (a3 = f.sort.sortBy) ? a3 : y2 });
        }), U = (0, d.c)(() => {
          f.reset(), O(0);
        });
        (0, p.y8)({ sortModel: f.sort }), (0, L.XcE)(f.pagesLoader, O), (0, o.useEffect)(
          () => () => {
            v(), f.reset();
          },
          [v, f]
        ), (f.isNotFound || !j.checkExperiment(L.zal.WebNextLabelPage, "on")) && (0, i.notFound)(), (0, h.Q)({ id: Number(S2), name: null != x ? x : "", type: null != A ? A : "" }, h.T.ALBUMS), (0, L.Jzs)(f.isResolved);
        let k = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(N.A, { children: (0, l.jsx)(N.wi, { className: _().footer }) }) }),
          []
        ), F = R({ id: "entity-names.label-albums-list" }), D = [];
        if (f.isNeededToLoad) {
          var G;
          let e3 = f.sort.sortBy === y2 || void 0 === f.sort.sortBy;
          D.push(
            f.getData({
              labelId: Number(t2),
              page: 0,
              pageSize: 20,
              preloadedAlbums: e3 ? r2 : void 0,
              sortBy: null != (G = f.sort.sortBy) ? G : y2
            })
          );
        }
        if (C && D.push(P({ labelId: Number(t2), preloadedLabel: a2, withLabelEntities: false })), D.length && (0, o.use)(Promise.allSettled(D)), f.isRejected && !f.isNotFound)
          return (0, l.jsx)(c.w, {});
        let K = f.isShimmerVisible ? 20 : f.items.length;
        return (0, l.jsx)(L.nVz, {
          pageId: L._Q$.LABEL_ALBUMS,
          children: (0, l.jsx)(b.hO, {
            scrollElement: I,
            outerTitle: B,
            children: (0, l.jsxs)("div", {
              className: _().root,
              ...(0, u.Am)(u.Xk.label.LABEL_ALBUMS_PAGE),
              children: [
                (0, l.jsxs)(N.Y9, {
                  variant: N.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: X.canBack,
                  children: [
                    (0, l.jsx)(m.Heading, { variant: "h1", weight: "bold", size: "xl", lineClamp: 1, children: B }),
                    (0, l.jsx)(p.mi, { sortModel: f.sort, onSort: U })
                  ]
                }),
                (0, l.jsx)(N.$$, {
                  className: (0, s.$)(_().scrollContainer, _().important),
                  listClassName: _().content,
                  itemClassName: _().item,
                  customComponents: k,
                  itemContentCallback: (e3) => {
                    let t3 = f.items[e3], a3 = R(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: R({ id: "entity-names.album" }) }
                    );
                    return t3 ? (0, l.jsx)(
                      g.aX,
                      { album: t3, contentLinesCount: 4, withAddition: !t3.isNonMusic, withLikesCount: t3.isNonMusic },
                      t3.id
                    ) : (0, l.jsx)(N.Vt, { "aria-label": a3, linesCount: 4 });
                  },
                  totalCount: K,
                  onGetDataByPage: O,
                  pageSize: 20,
                  totalRequests: f.requestsCount,
                  handleRef: w,
                  context: { listAriaLabel: F },
                  isMobileLayout: E,
                  useWindowScroll: E
                })
              ]
            })
          })
        });
      });
    },
    14726: (e, t, a) => {
      "use strict";
      a.d(t, { oM: () => L.LabelAlbumsPage, ac: () => N.LabelArtistsPage, wg: () => h.LabelPage, X: () => p });
      var l, s = a(97396), r = a(61910), i = a(74125);
      (0, r.cache)(async function(e2, t2) {
        var a2;
        let l2, r2 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : { labelId: Number(e2), page: 0, pageSize: 20, sortBy: t2 };
        (0, i.LLJ)(e2) || (0, s.notFound)();
        try {
          let {
            container: t3,
            backendHostTld: a3,
            locale: s2,
            host: o2,
            fullUrl: n2,
            isRSC: u2,
            requestUrl: d2
          } = await (0, i.IhE)();
          if (u2)
            return { label: void 0, albums: void 0, backendHostTld: a3, locale: s2, host: o2, fullUrl: n2, requestUrl: d2 };
          let m2 = Number(e2), c2 = t3.get(i.PLX), g2 = await c2.getData({ labelId: m2 }), b2 = await c2.getAlbums(r2 || { labelId: m2, page: 0, pageSize: 20 });
          l2 = { label: g2, albums: b2, backendHostTld: a3, locale: s2, host: o2, fullUrl: n2, requestUrl: d2 };
        } catch (e3) {
          return (0, i.tfF)(e3, () => ({ label: void 0, albums: void 0, ...(0, i.Bj3)() }));
        }
        return (null == (a2 = l2.label) ? void 0 : a2.error) === "not-found" && (0, s.notFound)(), l2;
      }), (0, r.cache)(async (e2, t2) => {
        var a2;
        let l2;
        (0, i.LLJ)(e2) || (0, s.notFound)();
        try {
          let {
            container: a3,
            backendHostTld: s2,
            locale: r2,
            host: o2,
            fullUrl: n2,
            isRSC: u2,
            requestUrl: d2
          } = await (0, i.IhE)();
          if (u2)
            return {
              label: void 0,
              artists: void 0,
              backendHostTld: s2,
              locale: r2,
              host: o2,
              fullUrl: n2,
              requestUrl: d2
            };
          let m2 = Number(e2), c2 = a3.get(i.PLX), g2 = await c2.getData({ labelId: m2 }), b2 = await c2.getArtists(t2 || { labelId: m2, page: 0, pageSize: 20 });
          l2 = { label: g2, artists: b2, backendHostTld: s2, locale: r2, host: o2, fullUrl: n2, requestUrl: d2 };
        } catch (e3) {
          return (0, i.tfF)(e3, () => ({ label: void 0, artists: void 0, ...(0, i.Bj3)() }));
        }
        return (null == (a2 = l2.label) ? void 0 : a2.error) === "not-found" && (0, s.notFound)(), l2;
      }), (0, r.cache)(async (e2) => {
        var t2;
        let a2;
        (0, i.LLJ)(e2) || (0, s.notFound)();
        try {
          let {
            container: t3,
            backendHostTld: l2,
            locale: s2,
            host: r2,
            fullUrl: o2,
            isRSC: n2,
            requestUrl: u2
          } = await (0, i.IhE)();
          if (n2) return { label: void 0, backendHostTld: l2, locale: s2, host: r2, fullUrl: o2, requestUrl: u2 };
          let d2 = t3.get(i.PLX);
          a2 = {
            label: await d2.getData({ labelId: Number(e2) }),
            backendHostTld: l2,
            locale: s2,
            host: r2,
            fullUrl: o2,
            requestUrl: u2
          };
        } catch (e3) {
          return (0, i.tfF)(e3, () => ({ label: void 0, ...(0, i.Bj3)() }));
        }
        return (null == (t2 = a2.label) ? void 0 : t2.error) === "not-found" && (0, s.notFound)(), a2;
      }), a(94687), a(4499), a(84227);
      var o = a(93064), n = a(14287);
      !(function(e2) {
        e2.MUSICAL = "musical", e2.PUBLISHER = "publisher";
      })(l || (l = {}));
      var u = a(94376), d = a(63695), m = a(26433), c = a(40502);
      let g = o.gK.model("LabelAlbumsPage", {
        pagesLoader: (0, m.Ij)(u.JC),
        errorStatusCode: o.gK.maybeNull(o.gK.number),
        sort: c.wY
      }).views((e2) => ({
        get isShimmerVisible() {
          return !e2.pagesLoader.isSomePageResolved;
        },
        get isNeededToLoad() {
          return e2.pagesLoader.isNeedToMakeInitialRequest;
        },
        get isRejected() {
          return e2.pagesLoader.isInitialRequestRejected;
        },
        get isEmpty() {
          return e2.pagesLoader.isEmpty;
        },
        get isResolved() {
          return e2.pagesLoader.isSomePageResolved;
        },
        get requestsCount() {
          return e2.pagesLoader.requestsCount;
        },
        get items() {
          var t2;
          return null != (t2 = e2.pagesLoader.items) ? t2 : [];
        },
        get isNotFound() {
          return e2.pagesLoader.isInitialRequestRejected && e2.errorStatusCode === n.X1.NOT_FOUND;
        }
      })).actions((e2) => ({
        getData: (0, o.L3)(function* (t2) {
          let { labelId: a2, page: l2 = 0, pageSize: s2 = 20, preloadedAlbums: r2, sortBy: d2 } = t2, { labelsResource: m2, modelActionsLogger: c2 } = (0, o._$)(e2);
          if (e2.pagesLoader.isPageNeedToLoad(l2))
            try {
              e2.pagesLoader.setPageState(l2, i.GuX.PENDING);
              let t3 = r2;
              t3 || (t3 = yield m2.getAlbums({ labelId: a2, page: l2, pageSize: s2, sortBy: d2 }));
              let o2 = t3.albums.map(u.pp);
              e2.pagesLoader.setItems(o2, { page: l2, pager: t3.pager });
            } catch (t3) {
              c2.error(t3), t3 instanceof n.GX && t3.statusCode === n.X1.NOT_FOUND && (e2.errorStatusCode = n.X1.NOT_FOUND), e2.pagesLoader.setItems(null, { responseStatus: i.FlZ.ERROR, page: l2 });
            }
        }),
        reset() {
          e2.pagesLoader.reset(), e2.errorStatusCode = null;
        }
      })), b = o.gK.model("LabelArtistsPage", { pagesLoader: (0, m.Ij)(d.PK), errorStatusCode: o.gK.maybeNull(o.gK.number) }).views((e2) => ({
        get isShimmerVisible() {
          return !e2.pagesLoader.isSomePageResolved;
        },
        get isNeededToLoad() {
          return e2.pagesLoader.isNeedToMakeInitialRequest;
        },
        get isRejected() {
          return e2.pagesLoader.isInitialRequestRejected;
        },
        get isEmpty() {
          return e2.pagesLoader.isEmpty;
        },
        get isResolved() {
          return e2.pagesLoader.isSomePageResolved;
        },
        get requestsCount() {
          return e2.pagesLoader.requestsCount;
        },
        get items() {
          var t2;
          return null != (t2 = e2.pagesLoader.items) ? t2 : [];
        },
        get isNotFound() {
          return e2.pagesLoader.isInitialRequestRejected && e2.errorStatusCode === n.X1.NOT_FOUND;
        }
      })).actions((e2) => ({
        getData: (0, o.L3)(function* (t2) {
          let { labelId: a2, page: l2 = 0, pageSize: s2 = 20, preloadedArtists: r2 } = t2, { labelsResource: u2, modelActionsLogger: m2 } = (0, o._$)(e2);
          if (e2.pagesLoader.isPageNeedToLoad(l2))
            try {
              e2.pagesLoader.setPageState(l2, i.GuX.PENDING);
              let t3 = r2;
              t3 || (t3 = yield u2.getArtists({ labelId: a2, page: l2, pageSize: s2 }));
              let o2 = t3.artists.map(d.dM);
              e2.pagesLoader.setItems(o2, { page: l2, pager: t3.pager });
            } catch (t3) {
              m2.error(t3), t3 instanceof n.GX && t3.statusCode === n.X1.NOT_FOUND && (e2.errorStatusCode = n.X1.NOT_FOUND), e2.pagesLoader.setItems(null, { responseStatus: i.FlZ.ERROR, page: l2 });
            }
        }),
        reset() {
          e2.pagesLoader.reset(), e2.errorStatusCode = null;
        }
      })), p = o.gK.compose(
        o.gK.model("LabelPage", {
          id: o.gK.maybeNull(o.gK.string),
          name: o.gK.maybeNull(o.gK.string),
          type: o.gK.maybeNull(o.gK.string),
          albums: o.gK.maybeNull(o.gK.array(u.JC)),
          albumsSubpage: g,
          artistsSubpage: b,
          artists: o.gK.maybeNull(o.gK.array(d.PK)),
          errorStatusCode: o.gK.maybeNull(o.gK.number)
        }),
        m.pl,
        m.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === i.GuX.PENDING;
          },
          get hasAlbums() {
            return !!(t2.isLoading || e2.albums && e2.albums.length > 0);
          },
          get hasArtists() {
            if (t2.isPublisher) return false;
            return !!(t2.isLoading || e2.artists && e2.artists.length > 0);
          },
          get isNotFound() {
            let a2 = e2.isResolved && !e2.name && !t2.hasAlbums && !t2.hasArtists, l2 = e2.errorStatusCode && [n.X1.NOT_FOUND, n.X1.BAD_REQUEST].includes(e2.errorStatusCode);
            return e2.isRejected && l2 || a2;
          },
          get albumsUrl() {
            if (!e2.id) return "";
            let { href: t3 } = (0, i.uvd)("/label/:labelId/albums", { params: { labelId: e2.id } });
            return t3;
          },
          get artistsUrl() {
            if (!e2.id) return "";
            let { href: t3 } = (0, i.uvd)("/label/:labelId/artists", { params: { labelId: e2.id } });
            return t3;
          },
          get isPublisher() {
            return e2.type === l.PUBLISHER;
          },
          get isMusical() {
            return e2.type === l.MUSICAL;
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          getAlbums: (0, o.L3)(function* (t3) {
            let { labelsResource: a2, modelActionsLogger: l2 } = (0, o._$)(e2);
            try {
              let l3 = yield a2.getAlbums(t3);
              e2.albums = (0, o.wg)(l3.albums.map(u.pp));
            } catch (t4) {
              l2.error(t4), t4 instanceof n.GX && [n.X1.BAD_REQUEST, n.X1.NOT_FOUND].includes(t4.statusCode) && (e2.errorStatusCode = n.X1.NOT_FOUND);
            }
          }),
          getArtists: (0, o.L3)(function* (t3) {
            let { labelsResource: a2, modelActionsLogger: l2 } = (0, o._$)(e2);
            try {
              let l3 = yield a2.getArtists(t3);
              e2.artists = (0, o.wg)(l3.artists.map(d.dM));
            } catch (t4) {
              l2.error(t4), t4 instanceof n.GX && [n.X1.BAD_REQUEST, n.X1.NOT_FOUND].includes(t4.statusCode) && (e2.errorStatusCode = n.X1.NOT_FOUND);
            }
          }),
          getData: (0, o.L3)(function* (a2) {
            let { labelId: l2, preloadedLabel: s2, withLabelEntities: r2 = true } = a2, { labelsResource: u2, modelActionsLogger: d2 } = (0, o._$)(e2);
            if (e2.loadingState !== i.GuX.PENDING)
              try {
                e2.loadingState = i.GuX.PENDING;
                let a3 = s2;
                a3 || (a3 = yield u2.getData({ labelId: l2 })), e2.id = String(a3.id), e2.name = a3.name, e2.type = a3.type, r2 && (yield t2.getAlbums({ labelId: l2, pageSize: 8 }), yield t2.getArtists({ labelId: l2, pageSize: 8 })), e2.loadingState = i.GuX.RESOLVE;
              } catch (t3) {
                d2.error(t3), t3 instanceof n.GX && [n.X1.BAD_REQUEST, n.X1.NOT_FOUND].includes(t3.statusCode) && (e2.errorStatusCode = t3.statusCode), e2.loadingState !== i.GuX.IDLE && (e2.loadingState = i.GuX.REJECT);
              }
          }),
          reset() {
            e2.loadingState = i.GuX.IDLE, e2.id = null, e2.name = null, e2.type = null, e2.errorStatusCode = null, e2.destroyItems([e2.albums, e2.artists]);
          }
        };
        return t2;
      });
      var L = a(6094), N = a(73910);
      a(33265);
      var h = a(77120);
    },
    18569: (e, t, a) => {
      "use strict";
      a.d(t, { Q: () => u, T: () => n });
      var l = a(61910), s = a(74125), r = a(94687), i = a(4499), o = a(84227), n = (function(e2) {
        return e2.ROOT = "root", e2.ALBUMS = "albums", e2.ARTISTS = "artists", e2;
      })({});
      let u = (e2, t2) => {
        (0, l.useEffect)(() => {
          switch (t2) {
            case "root":
              (0, o.I)(e2, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e3) => {
                (0, s.jxB)(e3);
              });
              break;
            case "albums":
              (0, r._)(e2, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e3) => {
                (0, s.jxB)(e3);
              });
              break;
            case "artists":
              (0, i.M)(e2, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e3) => {
                (0, s.jxB)(e3);
              });
          }
        }, [null == e2 ? void 0 : e2.id, null == e2 ? void 0 : e2.type, null == e2 ? void 0 : e2.name, t2, e2]);
      };
    },
    33265: (e, t, a) => {
      "use strict";
      a.d(t, { LabelNotFoundPage: () => r });
      var l = a(54486), s = a(42421);
      let r = () => (0, l.jsx)(s.M, {});
    },
    39656: (e) => {
      e.exports = {
        root: "LabelArtistsPage_root__smTJJ",
        scrollContainer: "LabelArtistsPage_scrollContainer__alDjs",
        important: "LabelArtistsPage_important__pOZpi",
        footer: "LabelArtistsPage_footer__JU2P3",
        item: "LabelArtistsPage_item__kol2m",
        content: "LabelArtistsPage_content__4hjcX"
      };
    },
    40502: (e, t, a) => {
      "use strict";
      a.d(t, { mi: () => d.SortDropdown, wY: () => u, WG: () => l.W, hl: () => r, y8: () => i.useSort });
      var l = a(90229), s = a(61288);
      let r = (e2) => !!e2 && (e2 === s.x.ASC || e2 === s.x.DESC);
      var i = a(40188), o = a(93064), n = a(11405);
      let u = o.gK.model("Sort", {
        sortBy: o.gK.maybe(o.gK.enumeration(Object.values(n.g))),
        sortOrder: o.gK.maybe(o.gK.enumeration(Object.values(s.x)))
      }).actions((e2) => ({
        setSortBy(t2) {
          e2.sortBy = t2;
        },
        setSortOrder(t2) {
          e2.sortOrder = t2;
        }
      }));
      var d = a(2405);
    },
    40846: (e) => {
      e.exports = {
        root: "LabelPage_root__jquyP",
        content: "LabelPage_content__9st_X",
        header: "LabelPage_header__G2xY_",
        title: "LabelPage_title__BNxeX",
        button: "LabelPage_button__JXw3C",
        carouselBlock: "LabelPage_carouselBlock__zPJmW",
        carouselBlockHeader: "LabelPage_carouselBlockHeader__dvYqJ",
        carouselContainer: "LabelPage_carouselContainer__bRVMp",
        footer: "LabelPage_footer__lvKmF"
      };
    },
    52456: (e) => {
      e.exports = {
        root: "LabelAlbumsPage_root__xyWi4",
        scrollContainer: "LabelAlbumsPage_scrollContainer__zRUlM",
        important: "LabelAlbumsPage_important__s18oL",
        footer: "LabelAlbumsPage_footer__dcXFk",
        item: "LabelAlbumsPage_item__Qjz9F",
        content: "LabelAlbumsPage_content__jOWKZ"
      };
    },
    73910: (e, t, a) => {
      "use strict";
      a.d(t, { LabelArtistsPage: () => _ });
      var l = a(54486), s = a(50420), r = a(28303), i = a(97396), o = a(61910), n = a(43426), u = a(31500), d = a(8817), m = a(97800), c = a(82644), g = a(55616), b = a(33276), p = a(74125), L = a(80585), N = a(18569), h = a(39656), y = a.n(h);
      let _ = (0, r.PA)((e2) => {
        let { labelId: t2, preloadedLabel: a2, preloadedArtists: r2 } = e2, {
          label: { id: h2, name: _2, type: S, artistsSubpage: A, reset: x, isNeededToLoad: f, getData: v },
          settings: { isMobile: C },
          experiments: P
        } = (0, p.Pjs)(), { formatMessage: T } = (0, n.A)(), { contentScrollRef: E, setContentScrollRef: j } = (0, p.gKY)(), R = (0, p.W6M)(), I = T({ id: "page.label-artists-header" }, { labelName: _2 }), w = (0, d.c)((e3) => {
          A.getData({ labelId: Number(t2), page: e3, pageSize: 20 });
        });
        (0, p.XcE)(A.pagesLoader, w), (0, o.useEffect)(
          () => () => {
            x(), A.reset();
          },
          [x, A]
        ), (A.isNotFound || !P.checkExperiment(p.zal.WebNextLabelPage, "on")) && (0, i.notFound)(), (0, N.Q)({ id: Number(h2), name: null != _2 ? _2 : "", type: null != S ? S : "" }, N.T.ARTISTS), (0, p.Jzs)(A.isResolved);
        let X = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(L.A, { children: (0, l.jsx)(L.wi, { className: y().footer }) }) }),
          []
        ), B = T({ id: "entity-names.label-artists-list" }), O = [];
        if (A.isNeededToLoad && O.push(A.getData({ labelId: Number(t2), page: 0, pageSize: 20, preloadedArtists: r2 })), f && O.push(v({ labelId: Number(t2), preloadedLabel: a2, withLabelEntities: false })), O.length && (0, o.use)(Promise.allSettled(O)), A.isRejected && !A.isNotFound)
          return (0, l.jsx)(c.w, {});
        let U = A.isShimmerVisible ? 20 : A.items.length;
        return (0, l.jsx)(p.nVz, {
          pageId: p._Q$.LABEL_ARTISTS,
          children: (0, l.jsx)(b.hO, {
            scrollElement: E,
            outerTitle: I,
            children: (0, l.jsxs)("div", {
              className: y().root,
              ...(0, u.Am)(u.Xk.label.LABEL_ARTISTS_PAGE),
              children: [
                (0, l.jsx)(L.Y9, {
                  variant: L.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: R.canBack,
                  className: y().header,
                  children: (0, l.jsx)(m.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: I
                  })
                }),
                (0, l.jsx)(L.$$, {
                  className: (0, s.$)(y().scrollContainer, y().important),
                  listClassName: y().content,
                  itemClassName: y().item,
                  customComponents: X,
                  itemContentCallback: (e3) => {
                    let t3 = A.items[e3], a3 = T(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: T({ id: "entity-names.artist" }) }
                    );
                    return t3 ? (0, l.jsx)(g.ao, { artist: t3, contentLinesCount: 4 }, t3.id) : (0, l.jsx)(L.Vt, { "aria-label": a3, round: true, centered: true, linesCount: 4 });
                  },
                  totalCount: U,
                  onGetDataByPage: w,
                  pageSize: 20,
                  totalRequests: A.requestsCount,
                  handleRef: j,
                  context: { listAriaLabel: B },
                  isMobileLayout: C,
                  useWindowScroll: C
                })
              ]
            })
          })
        });
      });
    },
    77120: (e, t, a) => {
      "use strict";
      a.d(t, { LabelPage: () => C });
      var l = a(54486), s = a(50420), r = a(28303), i = a(97396), o = a(61910), n = a(43426), u = a(47713), d = a(31500), m = a(8817), c = a(77881), g = a(5956), b = a(56231), p = a(97800), L = a(32353), N = a(82644), h = a(94376), y = a(55616), _ = a(33276), S = a(74125), A = a(80585), x = a(18569), f = a(40846), v = a.n(f);
      let C = (0, r.PA)((e2) => {
        var t2, a2, r2, f2;
        let { labelId: C2, preloadedLabel: P } = e2, {
          label: T,
          settings: { isMobile: E },
          experiments: j
        } = (0, S.Pjs)(), { formatMessage: R } = (0, n.A)(), { contentScrollRef: I, setContentScrollRef: w } = (0, S.gKY)(), { notify: X } = (0, S.lkh)(), { shareLink: B } = (0, S.bNS)("/label/:labelId", { params: { labelId: null != (a2 = T.id) ? a2 : "" } }), O = (0, o.useRef)(null), U = (0, o.useRef)(0);
        (0, x.Q)(
          { id: Number(T.id), name: null != (r2 = T.name) ? r2 : "", type: null != (f2 = T.type) ? f2 : "" },
          x.T.ROOT
        );
        let k = (0, m.c)(async () => {
          await window.navigator.clipboard.writeText(B), X((0, l.jsx)(A.Do, { entityVariant: S.Yxq.LABEL, entityTitle: T.name || "" }), {
            containerId: S.uQT.INFO
          });
        }), F = (0, o.useMemo)(
          () => E ? (0, l.jsx)(c.$, {
            className: v().button,
            onClick: k,
            icon: (0, l.jsx)(g.Icon, { variant: "share", size: "xxs" }),
            size: "l",
            radius: "xxxl",
            ...(0, d.Am)(d.Xk.label.SHARE_COPY_LINK_BUTTON)
          }) : (0, l.jsx)(c.$, {
            className: v().button,
            onClick: k,
            icon: (0, l.jsx)(g.Icon, { variant: "share", size: "xxs" }),
            size: "l",
            radius: "xxxl",
            ...(0, d.Am)(d.Xk.label.SHARE_COPY_LINK_BUTTON),
            children: (0, l.jsx)(u.A, { id: "interface-actions.share" })
          }),
          [E, k]
        ), D = T.isPublisher ? R({ id: "entity-names.publisher" }) : R({ id: "entity-names.label" }), G = T.isPublisher ? R({ id: "entity-names.non-music-releases" }) : R({ id: "entity-names.releases" });
        return ((0, o.useEffect)(
          () => () => {
            T.reset();
          },
          [T]
        ), (T.isNotFound || !j.checkExperiment(S.zal.WebNextLabelPage, "on")) && (0, i.notFound)(), (0, o.useEffect)(
          () => () => {
            U.current = 0;
          },
          [T]
        ), (0, o.useEffect)(() => {
          T.isRejected && U && !(U.current > 0) && (X((0, l.jsx)(A.hT, { error: R({ id: "error-messages.error-load-part-page" }) }), {
            containerId: S.uQT.ERROR
          }), U.current++);
        }, [T.isRejected, X, R]), (0, S.Jzs)(T.isResolved), T.isNeededToLoad && (0, o.use)(T.getData({ labelId: Number(C2), preloadedLabel: P })), T.isRejected && !T.isNotFound) ? (0, l.jsx)(N.w, {}) : (0, l.jsx)(S.nVz, {
          pageId: S._Q$.LABEL,
          children: (0, l.jsxs)(_.hO, {
            scrollElement: I,
            children: [
              (0, l.jsx)(A.Y9, { innerHeaderRef: O }),
              (0, l.jsxs)(b.N, {
                className: v().root,
                containerClassName: v().content,
                ref: w,
                ...(0, d.Am)(d.Xk.label.LABEL_PAGE),
                children: [
                  (0, l.jsxs)("div", {
                    className: v().header,
                    children: [
                      (0, l.jsx)(p.Caption, {
                        variant: "div",
                        type: "text",
                        size: "m",
                        weight: "medium",
                        children: D
                      }),
                      (0, l.jsx)(L.RR, { className: v().title, title: T.name || "", headingVariant: "h1" }),
                      F
                    ]
                  }),
                  T.hasAlbums && T.albums && (0, l.jsx)(h.pZ, {
                    isShimmerVisible: T.isLoading,
                    isShimmerActive: true,
                    className: v().carouselContainer,
                    headerClassName: (0, s.$)(v().carouselBlock, v().carouselBlockHeader),
                    containerClassName: v().carouselBlock,
                    title: G,
                    viewAllActionLink: T.albumsUrl,
                    albums: T.albums,
                    headingVariant: "h2",
                    ...(0, d.Am)(d.Xk.label.RELEASES_CAROUSEL)
                  }),
                  T.hasArtists && (0, l.jsx)(A.OY, {
                    isShimmerVisible: T.isLoading,
                    isShimmerActive: true,
                    headerClassName: (0, s.$)(v().carouselBlockHeader, v().carouselBlock),
                    containerClassName: v().carouselBlock,
                    viewAllActionLink: T.artistsUrl,
                    title: R({ id: "entity-names.artists" }),
                    headingVariant: "h2",
                    ...(0, d.Am)(d.Xk.label.ARTISTS_CAROUSEL),
                    children: null == (t2 = T.artists) ? void 0 : t2.map((e3) => (0, l.jsx)(y.ao, { artist: e3, contentLinesCount: 3 }, e3.id))
                  }),
                  (0, l.jsx)(A.A, { children: (0, l.jsx)(A.wi, { className: v().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    84227: (e, t, a) => {
      "use strict";
      a.d(t, { I: () => s });
      var l = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let i = await (0, l.WGy)(t2.locale), o = i({ id: "metadata.label-title" }, { labelTitle: e2.name, labelType: e2.type }), n = i({ id: "metadata.label-description" }, { labelTitle: e2.name, labelType: e2.type });
        return {
          title: o,
          description: n,
          openGraph: (0, l.i$E)({
            ogTitle: o,
            ogDescription: n,
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            siteName: i({ id: "metadata.yandex-music" }),
            ogType: "music.playlist"
          }),
          twitter: (0, l.HRN)({
            cardType: l.WfF.APP,
            title: o,
            url: t2.url,
            appName: i({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, l.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: i({ id: "metadata.yandex-music" })
          }),
          alternates: (0, l.SEs)("/label/:labelId", t2.tld, { params: { labelId: e2.id } })
        };
      }
    },
    94687: (e, t, a) => {
      "use strict";
      a.d(t, { _: () => s });
      var l = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let i = await (0, l.WGy)(t2.locale), o = i({ id: "metadata.label-albums-title" }, { labelName: e2.name, labelType: e2.type }), n = i({ id: "metadata.label-albums-description" }, { labelName: e2.name, labelType: e2.type });
        return {
          title: o,
          description: n,
          openGraph: (0, l.i$E)({
            ogTitle: o,
            ogDescription: n,
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            siteName: i({ id: "metadata.yandex-music" }),
            ogType: "music.playlist"
          }),
          twitter: (0, l.HRN)({
            cardType: l.WfF.APP,
            title: o,
            url: t2.url,
            appName: i({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, l.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: i({ id: "metadata.yandex-music" })
          }),
          alternates: (0, l.SEs)("/label/:labelId/albums", t2.tld, { params: { labelId: e2.id } })
        };
      }
    }
  }
]);
