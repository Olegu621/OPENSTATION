(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4790],
  {
    246: (e, t, a) => {
      "use strict";
      a.d(t, { r: () => y, q: () => i });
      var i = (function(e2) {
        return e2.VERTICAL = "vertical", e2.HORIZONTAL = "horizontal", e2;
      })({}), n = a(54486), r = a(50420), l = a(28303), o = a(61910), s = a(43426), c = a(31500), d = a(8817), u = a(27510), m = a(62443), _ = a(77881), p = a(5956), v = a(28584), h = a(74125), g = a(30980), x = a.n(g);
      let y = (0, l.PA)((e2) => {
        let {
          className: t2,
          horizontalSliderClassName: a2,
          verticalSliderClassName: l2,
          variant: g2 = i.HORIZONTAL,
          playbackId: y2,
          onVolumeClick: b,
          onVolumeSet: A,
          sonataVolume: C
        } = e2, { formatMessage: N } = (0, s.A)(), f = (0, h.NFA)(), I = (0, h.eGp)(), { advert: S } = (0, h.Pjs)(), T = (0, h.rs2)(), { state: P, toggleTrue: k, toggleFalse: E } = (0, m.e)(false), j = f.get(h.ooW), L = Math.round((null != C ? C : 1) * 100) / 100, w = (0, d.c)((e3) => {
          var t3, a3;
          null == T || null == (a3 = T.audioAdvertPlayback) || null == (t3 = a3.setExponentVolume) || t3.call(a3, e3);
        }), M = (0, d.c)((e3) => {
          null == I || I.setExponentVolume(e3, y2);
        });
        (0, o.useEffect)(() => {
          S.isAdvertShown && w(L);
        }, [S.isAdvertShown, L, null == T ? void 0 : T.audioAdvertPlayback, w]), (0, o.useEffect)(() => {
          S.isAdvertShown || M(L);
        }, [S.isAdvertShown, L, I, y2, M]);
        let B = (0, d.c)((e3) => {
          M(e3), j.set(h.cYZ.YmPlayerVolume, e3, { expires: 365 }), S.isAdvertShown && (w(e3), A(e3));
        }), O = (0, d.c)(async () => {
          await b(L);
        }), R = 0 === L ? "volumeOff" : "volume", D = 0 === L ? N({ id: "player-actions.volume-on" }) : N({ id: "player-actions.volume-off" }), K = (0, d.c)((e3) => {
          B(Math.max(0, Math.min(1, Math.round(100 * (L + (e3.deltaY > 0 ? -1 : 1) * 0.01)) / 100)));
        }), U = (0, u.L)(() => {
          if (g2 === i.HORIZONTAL)
            return (0, n.jsx)(v.A, {
              onWheel: K,
              className: a2,
              thumbSize: "s",
              trackSize: "s",
              value: L,
              maxValue: 1,
              step: 0.01,
              onChange: B,
              "aria-label": N({ id: "player-actions.volume-control" }),
              ...(0, c.Am)(c.Kq.changeVolume.CHANGE_VOLUME_SLIDER)
            });
        }), F = (0, u.L)(() => {
          if (g2 === i.VERTICAL)
            return (0, n.jsx)("div", {
              onWheel: K,
              className: (0, r.$)(x().sliderContainer, { [x().sliderContainer_focusVisible]: P }),
              children: (0, n.jsx)("div", {
                className: x().wrapperSlider,
                children: (0, n.jsx)(v.A, {
                  onMouseLeave: E,
                  className: (0, r.$)(x().slider, x().important, l2),
                  thumbSize: "s",
                  onFocus: k,
                  onBlur: E,
                  trackSize: "s",
                  value: L,
                  maxValue: 1,
                  step: 0.01,
                  onChange: B,
                  "aria-label": N({ id: "player-actions.volume-control" }),
                  ...(0, c.Am)(c.Kq.changeVolume.CHANGE_VOLUME_SLIDER)
                })
              })
            });
        });
        return (0, n.jsxs)("div", {
          className: (0, r.$)(x().root, t2),
          children: [
            F,
            (0, n.jsx)(_.$, {
              onWheel: K,
              radius: "round",
              size: "xxxs",
              variant: "text",
              withRipple: false,
              onClick: O,
              "aria-label": D,
              icon: (0, n.jsx)(p.Icon, { size: "xs", className: x().icon, variant: R }),
              className: x().button,
              ...(0, c.Am)(c.Kq.changeVolume.CHANGE_VOLUME_BUTTON)
            }),
            U
          ]
        });
      });
    },
    882: (e) => {
      e.exports = {
        root: "PlayQueueTitle_root__E2XOW",
        root_withDnD: "PlayQueueTitle_root_withDnD__8kctq",
        linkContainer: "PlayQueueTitle_linkContainer__xqLIj",
        titleIcon: "PlayQueueTitle_titleIcon__z1B_p",
        title: "PlayQueueTitle_title__q3ppG",
        linkText: "PlayQueueTitle_linkText__9mgvM",
        heading: "PlayQueueTitle_heading__JrzQq",
        heading_withOffset: "PlayQueueTitle_heading_withOffset__ZRyEr",
        subTitle: "PlayQueueTitle_subTitle__RzrJA",
        modeTitle: "PlayQueueTitle_modeTitle__KixWV"
      };
    },
    1172: (e) => {
      e.exports = {
        root: "TrackModalLyrics_root__JABJp",
        title: "TrackModalLyrics_title__zjWl_",
        button: "TrackModalLyrics_button__YqxIm",
        lyrics: "TrackModalLyrics_lyrics__naoEF"
      };
    },
    1762: (e, t, a) => {
      "use strict";
      a.d(t, { N1: () => y, i_: () => r, h9: () => i });
      let i = (e2) => null === e2 || !!("object" == typeof e2 && "imageUri" in e2 && "string" == typeof e2.imageUri && "content" in e2 && "string" == typeof e2.content && "primaryHref" in e2 && "string" == typeof e2.primaryHref && "shouldShowSecondaryButton" in e2 && "boolean" == typeof e2.shouldShowSecondaryButton && "secondaryText" in e2 && "string" == typeof e2.secondaryText);
      var n = a(93064);
      let r = n.gK.model("BrandedPlayerModal", {
        imageUri: n.gK.maybeNull(n.gK.string),
        content: n.gK.string,
        primaryHref: n.gK.string,
        shouldShowSecondaryButton: n.gK.boolean,
        secondaryText: n.gK.maybeNull(n.gK.string)
      });
      var l = a(54486), o = a(28303), s = a(43426), c = a(47713), d = a(8817), u = a(77881), m = a(5956), _ = a(58360), p = a(32692), v = a(97800), h = a(74125), g = a(87078), x = a.n(g);
      let y = (0, o.PA)((e2) => {
        var t2;
        let { modal: a2 } = e2, {
          paywall: i2,
          advertBanners: {
            banners: { brandedPlayerBanner: n2 }
          }
        } = (0, h.Pjs)(), { contentRootRef: r2 } = (0, h.gKY)(), { formatMessage: o2 } = (0, s.A)(), g2 = (0, h.ZpR)(a2.primaryHref), y2 = (0, d.c)((e3) => {
          var t3, a3;
          null == (t3 = (a3 = n2.modal).onOpenChange) || t3.call(a3, e3);
        }), b = { "--modal-bottom-offset": "".concat(null == (t2 = n2.payload) ? void 0 : t2.thumb.height, "px") };
        return (0, l.jsxs)(p.a, {
          size: "fitContent",
          placement: "default",
          open: n2.modal.isOpened,
          onOpenChange: y2,
          className: x().root,
          contentClassName: x().modalContent,
          portalNode: r2,
          showHeader: false,
          closeOnOutsidePress: false,
          lockScroll: false,
          withOverlay: false,
          enableSwipe: true,
          style: b,
          onClose: n2.modal.close,
          shouldCloseOnNavigate: true,
          children: [
            (0, l.jsxs)("header", {
              children: [
                a2.imageUri && (0, l.jsx)(_.Image, { src: a2.imageUri, className: x().image }),
                (0, l.jsx)(u.$, {
                  className: x().closeButton,
                  color: "primary",
                  variant: "text",
                  radius: "round",
                  size: "xxs",
                  onClick: n2.modal.close,
                  icon: (0, l.jsx)(m.Icon, { variant: "close", size: "xs" }),
                  "aria-label": o2({ id: "interface-actions.close" })
                })
              ]
            }),
            (0, l.jsx)(v.Caption, { variant: "span", className: x().content, lineClamp: 2, children: a2.content }),
            (0, l.jsxs)("div", {
              className: x().actions,
              children: [
                (0, l.jsx)(u.$, {
                  size: "s",
                  color: "primary",
                  variant: "default",
                  radius: "xxxl",
                  onClick: g2,
                  className: x().button,
                  children: (0, l.jsx)(v.Caption, {
                    variant: "span",
                    size: "m",
                    lineClamp: 1,
                    children: (0, l.jsx)(c.A, { id: "branded-player.to-website" })
                  })
                }),
                a2.shouldShowSecondaryButton && (0, l.jsx)(u.$, {
                  size: "s",
                  color: "secondary",
                  variant: "default",
                  radius: "xxxl",
                  onClick: i2.openModal,
                  className: x().button,
                  children: (0, l.jsx)(v.Caption, {
                    variant: "span",
                    size: "m",
                    lineClamp: 1,
                    children: a2.secondaryText || (0, l.jsx)(c.A, { id: "branded-player.hide" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    2782: (e) => {
      e.exports = {
        content: "WizardModal_content__mLcxg",
        modalHeader: "WizardModal_modalHeader__BbNjx",
        root: "WizardModal_root__mrF2y",
        root_withCustomControls: "WizardModal_root_withCustomControls__t7Kjv",
        modalContent: "WizardModal_modalContent__OifZs",
        wrapper: "WizardModal_wrapper__2_8ft",
        title: "WizardModal_title__fPGJr",
        text: "WizardModal_text__ntEON",
        button: "WizardModal_button__e8bCS",
        mainContainer: "WizardModal_mainContainer__fbjpt",
        carousel: "WizardModal_carousel__uVcYS",
        scrollContainer: "WizardModal_scrollContainer__tDrP6",
        important: "WizardModal_important__7uymQ",
        tabCarousel: "WizardModal_tabCarousel__AclIV",
        tabShimmer: "WizardModal_tabShimmer__36Qc7",
        tabTitle: "WizardModal_tabTitle__7ZAaF",
        filter: "WizardModal_filter__o2wpn",
        filter_selected: "WizardModal_filter_selected__qdlMf",
        item: "WizardModal_item__wUHVg"
      };
    },
    4073: (e) => {
      e.exports = {
        root: "FamilyInviteInviter_root__2XR_p",
        icon: "FamilyInviteInviter_icon__e5pZe",
        important: "FamilyInviteInviter_important__wl_l1",
        iconShimmer: "FamilyInviteInviter_iconShimmer__Dbxw_",
        root_mobile: "FamilyInviteInviter_root_mobile__LRDAo",
        name: "FamilyInviteInviter_name__0E0QC",
        nameShimmer: "FamilyInviteInviter_nameShimmer__Zzoa1"
      };
    },
    5128: (e) => {
      e.exports = { root: "SyncLyrics_root__6KZg4", content: "SyncLyrics_content__lbkWP" };
    },
    6437: (e) => {
      e.exports = {
        root: "NavbarDesktopPlusBar_root__QgKqJ",
        logos: "NavbarDesktopPlusBar_logos__kKKEl",
        addition: "NavbarDesktopPlusBar_addition__vluXf",
        title: "NavbarDesktopPlusBar_title__mMdem",
        buttons: "NavbarDesktopPlusBar_buttons__40_1A"
      };
    },
    7186: (e, t, a) => {
      "use strict";
      a.d(t, { P: () => Y, D: () => N });
      var i = a(93064), n = a(15209), r = a(26433), l = a(56258), o = a(74125);
      let s = { width: "614", height: "556" }, c = { width: "100%", height: "240" }, d = (e2) => ({ width: e2 ? c.width : s.width, height: e2 ? c.height : s.height }), u = { width: "614", height: "244" }, m = { width: "100%", height: "240" }, _ = "{lang}", p = RegExp("(px|%)$"), v = (e2) => e2.replace("px", ""), h = (e2) => p.test(e2) ? e2 : "".concat(e2).concat("px"), g = (e2) => {
        let { width: t2, height: a2, iframeUri: i2, listenMessage: n2 } = e2, r2 = v(t2), l2 = v(a2), o2 = h(t2), s2 = h(a2);
        return '<iframe frameborder="0" allow="clipboard-write" style="border:none;width:'.concat(o2, ";height:").concat(s2, ';" width="').concat(r2, '" height="').concat(l2, '" src="').concat(i2, '">').concat(n2, "</iframe>");
      }, x = i.gK.model({ width: i.gK.string, height: i.gK.string }), y = x.props({
        id: i.gK.number,
        type: i.gK.literal(o.Yxq.ALBUM),
        title: i.gK.string,
        path: i.gK.string,
        artistName: i.gK.maybeNull(i.gK.string),
        artistId: i.gK.maybeNull(i.gK.string),
        listenMessage: i.gK.maybeNull(i.gK.string)
      }).views((e2) => {
        let t2 = {
          get iframeUri() {
            let { location: t3 } = (0, i.Zn)(e2);
            return (0, o.yK3)({ tld: t3.tld, id: e2.id });
          },
          get entityUri() {
            let { location: t3 } = (0, i.Zn)(e2), { config: a2 } = (0, i._$)(e2);
            return "".concat((0, n.getTldHost)(a2.iframe.entityBaseUrl, t3.tld, o.BEZ)).concat(e2.path);
          },
          get artistUri() {
            if (null === e2.artistId) return null;
            let { location: t3 } = (0, i.Zn)(e2), { config: a2 } = (0, i._$)(e2);
            return "".concat((0, n.getTldHost)(a2.iframe.entityBaseUrl, t3.tld, o.BEZ), "/artist/").concat(e2.artistId);
          },
          get iframeCode() {
            var a2;
            return g({
              width: e2.width,
              height: e2.height,
              iframeUri: t2.iframeUri,
              listenMessage: null != (a2 = e2.listenMessage) ? a2 : ""
            });
          }
        };
        return t2;
      }).actions((e2) => ({
        setWidth(t2) {
          e2.width = t2;
        },
        setHeight(t2) {
          e2.height = t2;
        },
        setListenMessage(t2) {
          var a2, i2, n2, r2;
          e2.listenMessage = t2(
            (a2 = e2.entityUri, i2 = e2.title, n2 = e2.artistUri, null === (r2 = e2.artistName) ? '<a href="'.concat(a2, '">').concat(i2, "</a>") : null === n2 ? '<a href="'.concat(a2, '">').concat(i2, "</a> — ").concat(r2) : '<a href="'.concat(a2, '">').concat(i2, '</a> — <a href="').concat(n2, '">').concat(r2, "</a>"))
          );
        }
      })), b = x.props({
        id: i.gK.string,
        type: i.gK.literal(o.Yxq.PLAYLIST),
        title: i.gK.maybeNull(i.gK.string),
        path: i.gK.string,
        ownerLogin: i.gK.maybeNull(i.gK.string),
        ownerName: i.gK.maybeNull(i.gK.string),
        listenMessage: i.gK.maybeNull(i.gK.string)
      }).views((e2) => {
        let t2 = {
          get iframeUri() {
            var a2;
            let { location: t3 } = (0, i.Zn)(e2);
            return (0, o.J6z)({ tld: t3.tld, ownerLogin: null != (a2 = e2.ownerLogin) ? a2 : "", id: e2.id });
          },
          get entityUri() {
            let { location: t3 } = (0, i.Zn)(e2), { config: a2 } = (0, i._$)(e2);
            return "".concat((0, n.getTldHost)(a2.iframe.entityBaseUrl, t3.tld, o.BEZ)).concat(e2.path);
          },
          get iframeCode() {
            var r2;
            return g({
              width: e2.width,
              height: e2.height,
              iframeUri: t2.iframeUri,
              listenMessage: null != (r2 = e2.listenMessage) ? r2 : ""
            });
          }
        };
        return t2;
      }).actions((e2) => ({
        setWidth(t2) {
          e2.width = t2;
        },
        setHeight(t2) {
          e2.height = t2;
        },
        setListenMessage(t2) {
          let a2, n2, r2, l2;
          if (null === e2.title || null === e2.ownerName || null === e2.ownerLogin) {
            e2.listenMessage = t2("");
            return;
          }
          let { location: s2 } = (0, i.Zn)(e2);
          e2.listenMessage = t2(
            (a2 = e2.entityUri, n2 = e2.title, r2 = e2.ownerName, l2 = (0, o.QoD)(s2.tld, e2.ownerLogin), '<a href="'.concat(a2, '">').concat(n2, '</a> — <a href="').concat(l2, '">').concat(r2, "</a>"))
          );
        }
      })), A = x.props({
        id: i.gK.string,
        albumId: i.gK.maybeNull(i.gK.number),
        type: i.gK.literal(o.Yxq.TRACK),
        title: i.gK.string,
        path: i.gK.string,
        artistName: i.gK.maybeNull(i.gK.string),
        artistId: i.gK.maybeNull(i.gK.string),
        listenMessage: i.gK.maybeNull(i.gK.string)
      }).views((e2) => {
        let t2 = {
          get iframeUri() {
            var a2;
            let { location: t3 } = (0, i.Zn)(e2);
            return (0, o.iq5)({ tld: t3.tld, id: e2.id, albumId: null != (a2 = e2.albumId) ? a2 : void 0 });
          },
          get entityUri() {
            let { location: t3 } = (0, i.Zn)(e2), { config: a2 } = (0, i._$)(e2);
            return "".concat((0, n.getTldHost)(a2.iframe.entityBaseUrl, t3.tld, o.BEZ)).concat(e2.path);
          },
          get artistUri() {
            if (null === e2.artistId) return null;
            let { location: t3 } = (0, i.Zn)(e2), { config: a2 } = (0, i._$)(e2);
            return "".concat((0, n.getTldHost)(a2.iframe.entityBaseUrl, t3.tld, o.BEZ), "/artist/").concat(e2.artistId);
          },
          get iframeCode() {
            var r2;
            return g({
              width: e2.width,
              height: e2.height,
              iframeUri: t2.iframeUri,
              listenMessage: null != (r2 = e2.listenMessage) ? r2 : ""
            });
          }
        };
        return t2;
      }).actions((e2) => ({
        setWidth(t2) {
          e2.width = t2;
        },
        setHeight(t2) {
          e2.height = t2;
        },
        setListenMessage(t2) {
          var a2, i2, n2, r2;
          e2.listenMessage = t2(
            (a2 = e2.entityUri, i2 = e2.title, n2 = e2.artistUri, null === (r2 = e2.artistName) ? '<a href="'.concat(a2, '">').concat(i2, "</a>") : null === n2 ? '<a href="'.concat(a2, '">').concat(i2, "</a> — ").concat(r2) : '<a href="'.concat(a2, '">').concat(i2, '</a> — <a href="').concat(n2, '">').concat(r2, "</a>"))
          );
        }
      })), C = i.gK.union(A, y, b), N = i.gK.model({ entity: i.gK.maybeNull(C), modal: r.qt }).actions((e2) => ({
        openModal(t2) {
          let { settings: a2 } = (0, i.Zn)(e2);
          e2.entity = ((e3, t3) => {
            if (e3.variant === o.Yxq.TRACK)
              return ((e4) => {
                let t4, {
                  variant: a3,
                  id: n2,
                  title: r2,
                  path: l2,
                  trackArtistName: o2,
                  trackArtistId: s2,
                  trackAlbumId: c2,
                  isMobile: d2
                } = e4;
                return (0, i.wg)({
                  id: n2,
                  type: a3,
                  albumId: c2,
                  title: r2,
                  path: l2,
                  artistName: null != o2 ? o2 : null,
                  artistId: null != s2 ? s2 : null,
                  ...{ width: (t4 = d2) ? m.width : u.width, height: t4 ? m.height : u.height }
                });
              })({ ...e3, isMobile: t3 });
            if (e3.variant === o.Yxq.ALBUM) {
              let a3 = e3.id;
              if (void 0 === a3) throw new l.t("Missing album ID");
              return ((e4) => {
                let { variant: t4, id: a4, title: n2, path: r2, albumArtistName: l2, albumArtistId: o2, isMobile: s2 } = e4;
                return (0, i.wg)({
                  id: a4,
                  type: t4,
                  title: n2,
                  path: r2,
                  artistName: null != l2 ? l2 : null,
                  artistId: null != o2 ? o2 : null,
                  ...d(s2)
                });
              })({ ...e3, id: a3, isMobile: t3 });
            }
            if (e3.variant === o.Yxq.PLAYLIST)
              return ((e4) => {
                let {
                  variant: t4,
                  id: a3,
                  title: n2,
                  path: r2,
                  playlistOwnerName: l2,
                  playlistOwnerLogin: o2,
                  isMobile: s2
                } = e4;
                return (0, i.wg)({
                  id: String(a3),
                  type: t4,
                  title: null != n2 ? n2 : null,
                  path: null != r2 ? r2 : null,
                  ownerName: l2,
                  ownerLogin: o2,
                  ...d(s2)
                });
              })({ ...e3, isMobile: t3 });
            throw new l.t("Unknown variant");
          })({ ...t2, title: (0, n.sanitizeDOM)(t2.title || "", { whiteList: {} }) }, a2.isMobile), e2.modal.open();
        },
        closeModal() {
          e2.modal.close(), e2.entity = null;
        }
      }));
      var f = a(54486), I = a(28303), S = a(43426), T = a(31500), P = a(32692), k = a(61910), E = a(47713), j = a(8817), L = a(77881), w = a(5956), M = a(19009), B = a(97800);
      let O = (e2, t2) => p.test(e2) ? e2 : 0 === e2.trim().length ? "".concat(t2, "px") : "".concat(Math.max(Number(e2), t2), "px");
      var R = a(80585), D = a(61931), K = a.n(D);
      let U = (e2) => {
        let { closeToast: t2 } = e2;
        return (0, f.jsx)(R.$W, {
          closeToast: t2,
          cover: (0, f.jsx)(w.Icon, { className: K().icon, size: "xs", variant: "chain" }),
          message: (0, f.jsx)(B.Caption, {
            className: K().message,
            variant: "div",
            type: "controls",
            size: "m",
            children: (0, f.jsx)(E.A, { id: "notifications-info.html-code-copied" })
          }),
          coverRadius: "s"
        });
      };
      var F = a(33175), z = a.n(F);
      let V = (0, I.PA)((e2) => {
        let { entity: t2 } = e2, { formatMessage: a2 } = (0, S.A)(), { language: i2 } = (0, o.h6b)(), { notify: n2 } = (0, o.lkh)();
        (0, k.useEffect)(() => {
          t2.setListenMessage((e3) => a2({ id: "share.iframe-listen" }, { html: e3 }));
        }, [t2, a2]);
        let r2 = (0, j.c)((e3) => {
          let {
            target: { value: a3 }
          } = e3;
          t2.setWidth(a3);
        }), l2 = (0, j.c)((e3) => {
          let {
            target: { value: a3 }
          } = e3;
          !p.test(a3) && (0 === a3.length || Number.isNaN(Number(a3)) || 220 > Number(a3)) && t2.setWidth(String(220));
        }), s2 = (0, j.c)((e3) => {
          let {
            target: { value: a3 }
          } = e3;
          t2.setHeight(a3);
        }), c2 = (0, j.c)((e3) => {
          let {
            target: { value: a3 }
          } = e3;
          !p.test(a3) && (0 === a3.length || Number.isNaN(Number(a3)) || 88 > Number(a3)) && t2.setHeight(String(88));
        }), d2 = { width: O(t2.width, 220), height: O(t2.height, 88) }, u2 = t2.iframeUri.replace(_, i2), m2 = t2.iframeCode.replace(_, i2), v2 = (0, j.c)(async () => {
          await window.navigator.clipboard.writeText(m2), n2((0, f.jsx)(U, {}), { containerId: o.uQT.INFO });
        });
        return (0, f.jsxs)("div", {
          className: z().root,
          ...(0, T.Am)(T.Kq.shareIframe.SHARE_IFRAME_EDITOR),
          children: [
            (0, f.jsxs)("form", {
              className: z().controls,
              children: [
                (0, f.jsxs)("div", {
                  className: z().settings,
                  children: [
                    (0, f.jsx)(M.p, {
                      containerClassName: z().sizeInputContainer,
                      size: "xxxs",
                      value: t2.width,
                      variant: "secondary",
                      pattern: "^\\d+(px|%)?$",
                      min: 220,
                      required: true,
                      onChange: r2,
                      onBlur: l2,
                      "aria-label": a2({ id: "share.iframe-editor-width" }),
                      ...(0, T.Am)(T.Kq.shareIframe.SHARE_IFRAME_EDITOR_WIDTH_INPUT)
                    }),
                    (0, f.jsx)(w.Icon, { size: "xs", variant: "close" }),
                    (0, f.jsx)(M.p, {
                      containerClassName: z().sizeInputContainer,
                      size: "xxxs",
                      value: t2.height,
                      pattern: "^\\d+(px|%)?$",
                      variant: "secondary",
                      min: 88,
                      required: true,
                      onChange: s2,
                      onBlur: c2,
                      "aria-label": a2({ id: "share.iframe-editor-height" }),
                      ...(0, T.Am)(T.Kq.shareIframe.SHARE_IFRAME_EDITOR_HEIGHT_INPUT)
                    })
                  ]
                }),
                (0, f.jsx)(M.p, {
                  inputClassName: z().iframeCodeInput,
                  containerClassName: z().iframeCodeInputContainer,
                  type: "text",
                  size: "xxxs",
                  variant: "secondary",
                  value: m2,
                  required: true,
                  readOnly: true,
                  "aria-label": a2({ id: "share.iframe-editor-code" }),
                  ...(0, T.Am)(T.Kq.shareIframe.SHARE_IFRAME_EDITOR_CODE_INPUT)
                }),
                (0, f.jsx)(L.$, {
                  color: "primary",
                  className: z().copyButton,
                  size: "l",
                  radius: "xxxl",
                  onClick: v2,
                  ...(0, T.Am)(T.Kq.shareIframe.SHARE_IFRAME_EDITOR_COPY_BUTTON),
                  children: (0, f.jsx)(B.Caption, {
                    type: "text",
                    variant: "div",
                    size: "m",
                    weight: "medium",
                    lineClamp: 1,
                    children: (0, f.jsx)(E.A, { id: "share.iframe-copy" })
                  })
                })
              ]
            }),
            (0, f.jsx)("div", {
              className: z().iframeContainer,
              style: d2,
              ...(0, T.Am)(T.Kq.shareIframe.SHARE_IFRAME_EDITOR_PREVIEW),
              children: (0, f.jsx)("iframe", {
                className: z().iframe,
                src: u2,
                title: a2({ id: "share.iframe-editor-preview" })
              })
            })
          ]
        });
      });
      var W = a(11180), G = a.n(W);
      let Y = (0, I.PA)(() => {
        let {
          shareIframe: e2,
          settings: { isMobile: t2 }
        } = (0, o.Pjs)(), { formatMessage: a2 } = (0, S.A)();
        return e2.entity ? (0, f.jsx)(P.a, {
          className: G().root,
          contentClassName: G().content,
          open: e2.modal.isOpened,
          onOpenChange: e2.modal.onOpenChange,
          placement: t2 ? "default" : "center",
          size: "fitContent",
          title: a2({ id: "share.iframe-modal-title" }),
          labelClose: a2({ id: "interface-actions.close" }),
          onClose: e2.closeModal,
          overlayColor: "full",
          containerProps: (0, T.Am)(T.Kq.shareIframe.SHARE_IFRAME_MODAL),
          children: (0, f.jsx)(V, { entity: e2.entity })
        }) : null;
      });
    },
    7495: (e) => {
      e.exports = {
        root: "Timecode_root__TLT75",
        root_start: "Timecode_root_start__pHG5N",
        root_end: "Timecode_root_end__LLQsh"
      };
    },
    7917: (e) => {
      e.exports = {
        userProfileContainer: "NavbarDesktopUserWidget_userProfileContainer__ha3Tm",
        userProfile: "NavbarDesktopUserWidget_userProfile__vqeMC",
        userId: "NavbarDesktopUserWidget_userId__ihL7U",
        userMeta_withAnimation: "NavbarDesktopUserWidget_userMeta_withAnimation__rrz0Y",
        animation_show: "NavbarDesktopUserWidget_animation_show__fadL3",
        userMeta_collapsed: "NavbarDesktopUserWidget_userMeta_collapsed__cSARy",
        animation_hide: "NavbarDesktopUserWidget_animation_hide__tO81o",
        unauthorizedBar: "NavbarDesktopUserWidget_unauthorizedBar__HE5Yu"
      };
    },
    11180: (e) => {
      e.exports = { root: "ShareIframeModal_root__t_NbK", content: "ShareIframeModal_content__jcq_o" };
    },
    11284: (e) => {
      e.exports = {
        contextMenu: "PinItem_contextMenu__VwiFp",
        contextMenu_visible: "PinItem_contextMenu_visible__Zgwkh",
        root: "PinItem_root__WSoCn",
        image: "PinItem_image__Ow56U",
        cover: "PinItem_cover__9TcjE",
        tooltip: "PinItem_tooltip__BGwBw"
      };
    },
    13403: (e, t, a) => {
      "use strict";
      a.d(t, { A2: () => ee, bg: () => h });
      var i = a(74125);
      async function n(e2) {
        var t2, a2, n2, r2, l2, o2, s2;
        let c2, d2, { clipMeta: u2, additional: m2 } = e2, _2 = await (0, i.WGy)(m2.locale);
        return u2 ? (c2 = _2(
          { id: "metadata.clips-title" },
          {
            clipTitle: u2.title,
            clipArtists: null == (a2 = u2.artists) || null == (t2 = a2.map((e3) => e3.name)) ? void 0 : t2.join(", ")
          }
        ), d2 = _2(
          { id: "metadata.clips-description" },
          {
            clipTitle: u2.title,
            clipArtists: null == (r2 = u2.artists) || null == (n2 = r2.map((e3) => e3.name)) ? void 0 : n2.join(", ")
          }
        )) : (c2 = _2({ id: "metadata.clips-title-default" }), d2 = _2({ id: "metadata.clips-description-default" })), {
          title: c2,
          description: d2,
          openGraph: (0, i.i$E)({
            ogTitle: c2,
            ogDescription: d2,
            ogType: "website",
            fullUrl: null != (l2 = m2.fullUrl) ? l2 : "",
            locale: m2.locale,
            customImage: (0, i.vWM)({ tld: m2.tld }),
            siteName: _2({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({ cardType: i.WfF.SUMMARY_LARGE_IMAGE, title: c2, description: d2 }),
          facebook: (0, i.kRl)(),
          appLinks: (0, i.X5i)({
            additional: {
              ...m2,
              url: null != (o2 = m2.url) ? o2 : "",
              fullUrl: null != (s2 = m2.fullUrl) ? s2 : "",
              host: m2.host
            },
            appName: _2({ id: "metadata.yandex-music" })
          })
        };
      }
      var r = a(61910), l = a(65779), o = a(93064), s = a(14287), c = a(5693), d = a(89461), u = a(54830), m = a(26433), _ = a(63585), p = a(97719);
      let v = o.gK.model("VideoPlayerState", {
        contextType: o.gK.maybeNull(o.gK.enumeration(Object.values(_.K))),
        contextId: o.gK.maybeNull(o.gK.string),
        entityMeta: o.gK.maybeNull(p.Op),
        status: o.gK.enumeration(Object.values(d.MT)),
        canMoveForward: o.gK.boolean,
        canMoveBackward: o.gK.boolean
      }).actions((e2) => ({
        setContextId: (t2) => {
          e2.contextId = String(t2);
        },
        setContextType: (t2) => {
          e2.contextType = t2;
        },
        setEntityMeta: (t2) => {
          (null == t2 ? void 0 : t2.data.meta) && (e2.entityMeta = (0, p.EX)(t2));
        },
        setStatus: (t2) => {
          e2.status = t2;
        },
        setCanMoveForward: (t2) => {
          e2.canMoveForward = t2;
        },
        setCanMoveBackward: (t2) => {
          e2.canMoveBackward = t2;
        }
      })), h = o.gK.compose(
        o.gK.model("FullscreenVideoPlayer", {
          modal: m.qt,
          ids: o.gK.array(o.gK.number),
          activeIndex: o.gK.maybeNull(o.gK.number),
          clips: o.gK.array(l.kv),
          errorStatusCode: o.gK.maybeNull(o.gK.number),
          state: v,
          sonataStatusBeforeClipStart: o.gK.enumeration(Object.values(d.MT)),
          isOpenedFromMain: o.gK.maybeNull(o.gK.boolean),
          withAnimation: o.gK.boolean
        }),
        m.XT,
        m.pl
      ).views((e2) => {
        let t2 = {
          get clipActiveIndex() {
            return e2.activeIndex || 0;
          },
          get clipActive() {
            return e2.clips[t2.clipActiveIndex];
          },
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === i.GuX.PENDING;
          },
          get isNotFound() {
            let t3 = e2.isResolved && 0 === e2.clips.length;
            return e2.errorStatusCode === s.X1.NOT_FOUND || t3;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          },
          get entitiesData() {
            return e2.ids.map((e3) => ({ type: c.R.Clip, meta: { id: e3 }, loadEntityMeta: true }));
          },
          get isPlayingSonataStatusBeforeClipStart() {
            return e2.sonataStatusBeforeClipStart === d.MT.PLAYING;
          }
        };
        return t2;
      }).actions((e2) => ({
        setIds(t2) {
          e2.ids = (0, o.wg)(t2);
        },
        setClipIndex() {
          let t2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
          e2.activeIndex = t2;
        },
        setOpenedFromMain() {
          e2.isOpenedFromMain = true, e2.withAnimation = false;
        },
        setAnimationState(t2) {
          e2.withAnimation = t2;
        },
        setSonataStatusBeforeClipStart() {
          let { sonataState: t2 } = (0, o.Zn)(e2);
          e2.sonataStatusBeforeClipStart = t2.status;
        },
        getClips: (0, o.L3)(function* () {
          let { clipsResource: t2, modelActionsLogger: a2 } = (0, o._$)(e2);
          if (e2.loadingState !== i.GuX.PENDING)
            try {
              e2.loadingState = i.GuX.PENDING;
              let a3 = yield t2.getClip({ clipIds: e2.ids });
              e2.ids = (0, o.wg)(a3.map((e3) => e3.clipId)), e2.clips = (0, o.wg)(a3.map(l.i$)), e2.activeIndex = (0, u.z4)(e2.ids, e2.activeIndex), e2.loadingState !== i.GuX.IDLE && (e2.loadingState = i.GuX.RESOLVE);
            } catch (t3) {
              a2.error(t3), t3 instanceof s.GX && (e2.errorStatusCode = t3.statusCode), e2.loadingState !== i.GuX.IDLE && (e2.loadingState = i.GuX.REJECT);
            }
        }),
        reset() {
          e2.loadingState = i.GuX.IDLE, e2.activeIndex = null, e2.errorStatusCode = null, e2.isOpenedFromMain = null, e2.withAnimation = true, e2.sonataStatusBeforeClipStart = d.MT.IDLE, e2.destroyItems([e2.ids, e2.clips]);
        }
      }));
      var g = a(54486), x = a(28303), y = a(50420), b = a(43426), A = a(31500), C = a(8817), N = a(77881), f = a(5956), I = a(32692), S = a(62662), T = a(80585), P = a(12186), k = a(62443), E = a(25818), j = a(246), L = a(93666), w = a(97800), M = a(21365), B = a(63695), O = a(39298), R = a.n(O);
      let D = (0, x.PA)((e2) => {
        let {
          className: t2,
          clip: a2,
          withExplicitMark: n2 = true,
          withSecondaryColor: l2,
          captionSize: o2 = "m",
          explicitSize: s2 = "xxxs",
          withAllArtistsTitle: c2,
          withCustomTooltip: d2 = true,
          hasLineClamp: u2 = true,
          withArtistLink: m2 = true
        } = e2, _2 = (0, M.$N)({ withCustomTooltip: d2 }), p2 = (0, r.useCallback)(
          (e3) => {
            let t3 = String(a2.title);
            return (0, g.jsx)(L.m_, {
              enabled: _2,
              offsetOptions: 4,
              placement: "top",
              text: t3,
              hoverSettings: i.VP$,
              children: (0, g.jsx)(w.Caption, {
                className: (0, y.$)(R().text, R().title),
                type: "entity",
                size: o2,
                weight: "medium",
                variant: "span",
                ...e3,
                children: a2.title
              })
            });
          },
          [_2, o2, a2.title]
        ), v2 = (0, r.useMemo)(() => p2((0, A.Am)(A.Kq.clip.CLIP_META_TITLE)), [p2]), h2 = (0, M.su)(a2.artists);
        return (0, g.jsx)("div", {
          className: (0, y.$)(R().root, { [R().root_withSecondaryColor]: l2 }, t2),
          children: (0, g.jsxs)("div", {
            className: R().metaContainer,
            children: [
              (0, g.jsxs)("div", {
                className: R().titleContainer,
                children: [
                  (0, g.jsx)(w.Caption, {
                    type: "entity",
                    size: o2,
                    weight: "medium",
                    variant: "div",
                    lineClamp: 1,
                    children: v2
                  }),
                  a2.explicitDisclaimer && n2 && (0, g.jsx)(T.Nq, {
                    getDescriptionTexts: a2.getDescriptionTexts,
                    size: s2,
                    variant: a2.explicitDisclaimer,
                    className: R().explicitMark,
                    trackId: String(a2.clipId)
                  })
                ]
              }),
              h2.length > 0 && (0, g.jsx)(B.iQ, {
                linkClassName: R().link,
                captionClassName: R().artistCaption,
                artists: h2,
                withLink: m2,
                lineClamp: +!!u2,
                captionSize: o2,
                withAllArtistsTitle: c2,
                withCustomTooltip: _2
              })
            ]
          })
        });
      });
      var K = a(53226), U = a.n(K);
      let F = (0, x.PA)((e2) => {
        let { entityMeta: t2, onLikeClick: a2, onContextMenuOpenChange: n2, isContextMenuOpened: o2 } = e2, { user: s2, sonataState: c2, fullscreenVideoPlayer: d2 } = (0, i.Pjs)(), { isPassToProduct: u2 } = (0, i.XCI)(), m2 = (0, p.d0)(), _2 = (0, C.c)(async (e3) => {
          await m2(c2, e3);
        }), v2 = (0, C.c)((e3) => {
          c2.setVolume(e3);
        }), h2 = (0, r.useMemo)(
          () => t2 ? (0, g.jsx)("div", {
            className: U().description,
            children: (0, g.jsx)(D, { captionSize: "l", clip: t2, withSecondaryColor: true })
          }) : null,
          [t2]
        );
        return (0, g.jsxs)("section", {
          className: U().root,
          children: [
            (0, g.jsxs)("div", {
              className: U().info,
              children: [
                (0, g.jsx)("div", { className: U().infoCard, children: h2 }),
                (0, g.jsxs)("div", {
                  className: U().infoButtons,
                  children: [
                    d2.clipActive && (0, g.jsx)(l.zb, {
                      placement: "top-start",
                      icon: (0, g.jsx)(f.Icon, { variant: "more", size: "m" }),
                      size: "l",
                      clip: d2.clipActive,
                      onOpenChange: n2,
                      open: o2,
                      ...(0, A.Am)(A.Kq.clip.CLIP_CONTEXT_MENU_BUTTON)
                    }),
                    t2 && (0, g.jsx)(T.cy, {
                      className: U().likeButton,
                      isLiked: t2.isLiked,
                      iconSize: "xs",
                      onClick: a2,
                      disabled: !s2.isAuthorized
                    })
                  ]
                })
              ]
            }),
            (0, g.jsxs)("div", {
              className: U().sonata,
              children: [
                (0, g.jsx)(p.qF, {}),
                (0, g.jsx)(E.v, {
                  sliderClassName: (0, y.$)(U().slider, U().important),
                  disabled: !t2,
                  isMobile: false,
                  isFullscreen: false,
                  canMoveForward: d2.state.canMoveForward,
                  customDuration: (null == s2 ? void 0 : s2.isAuthorized) && !u2 ? void 0 : 29,
                  sonataPlaybackId: i.V_r.CLIP
                })
              ]
            }),
            (0, g.jsx)("div", {
              className: U().meta,
              children: (0, g.jsx)(j.r, {
                sonataVolume: c2.volume,
                onVolumeSet: v2,
                onVolumeClick: _2,
                horizontalSliderClassName: (0, y.$)(U().slider, U().important)
              })
            })
          ]
        });
      }), z = (0, x.PA)((e2) => {
        let {
          className: t2,
          isSettingsMenuOpened: a2,
          onSettingsMenuOpenChange: n2,
          isContextMenuOpened: r2,
          onContextMenuOpenChange: l2
        } = e2, { fullscreenVideoPlayer: o2 } = (0, i.Pjs)(), s2 = (0, u.KX)(o2.state.entityMeta), {
          settings: { isMobile: c2 }
        } = (0, i.Pjs)();
        return c2 ? null : (0, g.jsx)(F, {
          className: t2,
          onLikeClick: s2,
          entityMeta: o2.state.entityMeta,
          isSettingsMenuOpened: a2,
          onSettingsMenuOpenChange: n2,
          isContextMenuOpened: r2,
          onContextMenuOpenChange: l2
        });
      });
      var V = a(35311), W = a.n(V);
      let G = (0, x.PA)(() => {
        let { fullscreenVideoPlayer: e2 } = (0, i.Pjs)(), { state: t2, toggleTrue: a2, toggleFalse: n2 } = (0, k.e)(false), { state: o2, toggleTrue: s2, toggleFalse: c2 } = (0, k.e)(false), { state: u2, toggleTrue: m2, toggleFalse: _2 } = (0, k.e)(false), p2 = (0, r.useRef)(null), [v2, h2] = (0, r.useState)(false), [x2, b2] = (0, r.useState)(false), A2 = x2 || v2, N2 = (0, r.useMemo)(
          () => (0, P.A)(() => {
            n2(), c2();
          }, 1500),
          [c2, n2]
        ), f2 = (0, r.useMemo)(
          () => (0, P.A)(() => {
            c2();
          }, 1500),
          [c2]
        ), I2 = (0, C.c)(() => {
          f2.cancel(), s2(), m2();
        }), S2 = (0, C.c)(() => {
          f2(), _2();
        }), E2 = (0, C.c)(() => {
          v2 || x2 || N2();
        }), j2 = (0, C.c)((e3) => {
          e3.stopPropagation(), N2.cancel(), f2.cancel(), a2(), s2(), N2();
        }), L2 = (0, C.c)((e3) => {
          e3.stopPropagation(), N2.cancel(), f2.cancel(), a2(), N2();
        }), w2 = (0, C.c)(() => {
          t2 ? N2.cancel() : a2(), N2();
        });
        (0, r.useEffect)(
          () => (window.addEventListener("mousemove", w2), () => {
            window.removeEventListener("mousemove", w2);
          }),
          [w2]
        ), (0, r.useEffect)(() => {
          t2 || c2();
        }, [c2, t2]);
        let M2 = e2.state.status !== d.MT.PLAYING, B2 = (0, r.useMemo)(
          () => (0, g.jsx)(l.tD, {
            className: W().carousel,
            containerClassName: W().carouselBlock,
            clipCardTitleClassName: (0, y.$)(W().clipCardTitle, W().important),
            clipCardArtistLinkClassName: (0, y.$)(W().clipCardArtist, W().important),
            isShimmerVisible: e2.isLoading,
            isShimmerActive: true,
            clips: e2.clips,
            shouldOpenModalOnCardClick: false,
            itemCounter: 5,
            ref: p2
          }),
          [e2.clips, e2.isLoading, p2]
        );
        return (0, r.useEffect)(() => {
          (o2 || u2) && (a2(), s2());
        }, [u2, o2, s2, a2]), (0, g.jsxs)("div", {
          className: (0, y.$)(W().root, {
            [W().root_visible]: t2 || M2 || u2 || A2,
            [W().root_withHoveredCarousel]: o2
          }),
          onMouseEnter: a2,
          onMouseLeave: E2,
          onFocus: L2,
          children: [
            (0, g.jsx)(z, {
              isSettingsMenuOpened: v2,
              onSettingsMenuOpenChange: h2,
              isContextMenuOpened: x2,
              onContextMenuOpenChange: b2
            }),
            (0, g.jsx)(i.FoH, {
              blockId: i.hf$.CLIPS_CAROUSEL,
              blockType: i.hf$.CLIPS_CAROUSEL,
              blockPosX: 1,
              blockPosY: 1,
              objectsCount: e2.clips.length,
              children: (0, g.jsx)("div", {
                className: W().carouselContainer,
                onMouseEnter: I2,
                onMouseLeave: S2,
                onFocus: j2,
                children: (0, g.jsx)(T.FY, {
                  className: W().carouselWrapper,
                  carouselElement: B2,
                  ref: p2,
                  isCarouselBetweenArrows: true,
                  controlsWrapperClassName: W().carouselControls,
                  buttonSize: "xs",
                  buttonVariant: "default",
                  withSecondaryColor: true
                })
              })
            })
          ]
        });
      }), Y = (0, x.PA)(() => {
        let {
          settings: { isMobile: e2 }
        } = (0, i.Pjs)();
        return e2 ? null : (0, g.jsx)(G, {});
      });
      var Q = a(3728), $ = a(93622), q = a.n($);
      let H = (0, x.PA)((e2) => {
        let { closeModal: t2 } = e2, a2 = (0, r.useRef)(null), n2 = (0, i.eGp)(), {
          sonataState: { isVHCoreRegistered: o2 },
          fullscreenVideoPlayer: s2,
          advert: c2
        } = (0, i.Pjs)(), { from: m2 } = (0, i.fyy)({
          pageId: i._Q$.VIDEO_PLAYER,
          contextId: s2.state.contextId,
          contextType: _.K.Various
        }), p2 = (0, i.XJ9)(), { state: v2, toggleFalse: h2 } = (0, k.e)(true), { togglePlay: x2 } = (0, i.Dx4)({
          playContextParams: {
            contextData: { type: _.K.Various, meta: { id: i.H7u.VARIOUS_CLIP_CONTEXT }, from: m2 },
            loadContextMeta: true
          },
          sonataState: s2.state,
          playbackId: i.V_r.CLIP
        }), b2 = (0, l.XP)({ clip: s2.clips[s2.clipActiveIndex], callback: x2, disclaimerRejectHandler: t2 });
        return (0, r.useEffect)(() => {
          let e3, t3, r2;
          if (a2.current && n2 && o2) {
            let l2, o3;
            s2.setSonataStatusBeforeClipStart(), n2.setVideoCoreContainer({ container: a2.current, playbackId: i.V_r.CLIP }), n2.setContext(
              {
                contextData: { type: _.K.Various, meta: { id: i.H7u.VARIOUS_CLIP_CONTEXT }, from: m2 },
                entitiesData: s2.entitiesData,
                queueParams: { index: s2.clipActiveIndex },
                loadContextMeta: false
              },
              i.V_r.CLIP
            ).then(() => {
              c2.isAdvertShown || b2();
            });
            let d2 = n2.getState(i.V_r.CLIP);
            e3 = d2.queueState.currentEntity.onChange((e4) => {
              var t4;
              let a3 = null == e4 ? void 0 : e4.context.data.type, i2 = null == e4 ? void 0 : e4.context.data.meta.id, n3 = null == e4 ? void 0 : e4.entity.data.meta.id;
              if (n3) {
                let e5 = (0, u.z4)(s2.ids, s2.ids.indexOf(Number(n3)));
                s2.setClipIndex(e5), p2((0, u.JL)(s2.ids, e5));
              }
              s2.state.setEntityMeta(null != (t4 = null == e4 ? void 0 : e4.entity) ? t4 : null), a3 && s2.state.setContextType(a3), i2 && s2.state.setContextId(i2);
            }), t3 = d2.playerState.status.onChange((e4) => {
              e4 && s2.state.setStatus(e4);
            }), r2 = d2.currentContext.onChange((e4) => {
              null == l2 || l2(), null == o3 || o3(), l2 = null == e4 ? void 0 : e4.availableActions.moveBackward.onChange((e5) => {
                s2.state.setCanMoveBackward(!!e5);
              }), o3 = null == e4 ? void 0 : e4.availableActions.moveForward.onChange((e5) => {
                s2.state.setCanMoveForward(!!e5);
              });
            });
          }
          return () => {
            null == n2 || n2.destroyVideoCore(i.V_r.CLIP), s2.isPlayingSonataStatusBeforeClipStart && (null == n2 || n2.resume()), null == e3 || e3(), null == t3 || t3(), null == r2 || r2();
          };
        }, [n2, o2, s2, m2, p2, x2, b2, c2.isAdvertShown]), (0, r.useEffect)(() => {
          s2.state.status === d.MT.PLAYING && h2();
        }, [s2.state.status, h2]), (0, g.jsxs)("div", {
          className: q().root,
          children: [
            (0, g.jsx)("div", { onClick: x2, ref: a2, className: q().container }),
            (0, g.jsx)("div", {
              className: (0, y.$)(q().loadingIndicator, { [q().loadingIndicator_showed]: v2 }),
              children: (0, g.jsx)(Q.y, { size: "m" })
            })
          ]
        });
      });
      var X = a(90812), Z = a.n(X);
      let J = (0, x.PA)(() => {
        let { formatMessage: e2 } = (0, b.A)(), {
          advertBanners: {
            banners: { topAdvertBanner: t2 }
          },
          fullscreenVideoPlayer: a2,
          modals: { disclaimerModal: o2 }
        } = (0, i.Pjs)(), { defaultLayoutRef: s2 } = (0, i.gKY)(), c2 = (0, i.v8p)(), d2 = (0, i.pqZ)(), { notify: m2 } = (0, i.lkh)(), _2 = (0, i.eGp)(), p2 = (0, i.jjz)(), v2 = (0, u.QV)(), h2 = (0, u.Hx)(), [x2] = a2.ids, P2 = (0, C.c)(() => {
          let e3 = (0, i.qne)(i.K3F.IDS), t3 = (0, i.qne)(i.K3F.ACTIVE_INDEX), { clipIds: n2, activeClipIndex: r2 } = (0, l.V1)(e3, t3);
          n2.length ? (a2.setIds(n2), a2.setClipIndex(r2), a2.setAnimationState(false), null == _2 || _2.setEntityByIndex(a2.clipActiveIndex, i.V_r.CLIP), a2.modal.open()) : (a2.modal.close(), a2.reset());
        }), k2 = (0, C.c)(() => {
          if (a2.modal.isOpened && !o2.isOpened) {
            if (a2.setAnimationState(true), x2 && h2(String(x2)), a2.isOpenedFromMain) {
              d2(i.Zyd.main.href), (0, i.Zgt)({ fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e3) => {
                (0, i.jxB)(e3);
              }), a2.modal.close(), a2.reset();
              return;
            }
            c2();
          }
        });
        ((e3) => {
          let { fullscreenVideoPlayer: t3, advert: a3 } = (0, i.Pjs)(), n2 = (0, i.eGp)(), l2 = (0, i.zwV)(), o3 = (0, u.KX)(t3.state.entityMeta);
          (0, r.useEffect)(() => {
            if (a3.isAdvertShown) {
              null == l2 || l2.disable(i.Mo.VIDEO_PLAYER);
              return;
            }
            t3.modal.isOpened ? (null == l2 || l2.disable(i.Mo.MAIN), null == l2 || l2.enable(i.Mo.MAIN, i.lbr.TOGGLE_MUTE), null == l2 || l2.enable(i.Mo.MAIN, i.lbr.INCREASE_VOLUME), null == l2 || l2.enable(i.Mo.MAIN, i.lbr.DECREASE_VOLUME), null == l2 || l2.enable(i.Mo.VIDEO_PLAYER)) : (null == l2 || l2.disable(i.Mo.VIDEO_PLAYER), null == l2 || l2.enable(i.Mo.MAIN));
          }, [l2, t3.modal.isOpened, a3.isAdvertShown]);
          let s3 = null == n2 ? void 0 : n2.getState(i.V_r.CLIP);
          (0, r.useEffect)(
            () => (null == l2 || l2.addShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.CLOSE, e3), null == l2 || l2.addShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.TOGGLE_PLAY, () => {
              null == n2 || n2.togglePause(i.V_r.CLIP);
            }), null == l2 || l2.addShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.LIKE, o3), null == l2 || l2.addShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.MOVE_FORWARD, async () => {
              var e4;
              (null == s3 || null == (e4 = s3.currentContext.value) ? void 0 : e4.availableActions.moveForward.value) && await (null == n2 ? void 0 : n2.moveForward(i.V_r.CLIP));
            }), null == l2 || l2.addShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.MOVE_BACKWARD, async () => {
              var e4;
              (null == s3 || null == (e4 = s3.currentContext.value) ? void 0 : e4.availableActions.moveBackward.value) && await (null == n2 ? void 0 : n2.moveBackward(i.V_r.CLIP));
            }), null == l2 || l2.addShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.SLIDE_FORWARD, async () => {
              (null == s3 ? void 0 : s3.playerState.progress.value.duration) && await (null == n2 ? void 0 : n2.slideForward(1, i.V_r.CLIP));
            }), null == l2 || l2.addShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.SLIDE_BACKWARD, async () => {
              (null == s3 ? void 0 : s3.playerState.progress.value.duration) && await (null == n2 ? void 0 : n2.slideBackward(1, i.V_r.CLIP));
            }), () => {
              null == l2 || l2.removeShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.CLOSE), null == l2 || l2.removeShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.TOGGLE_PLAY), null == l2 || l2.removeShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.LIKE), null == l2 || l2.removeShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.MOVE_FORWARD), null == l2 || l2.removeShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.MOVE_BACKWARD), null == l2 || l2.removeShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.SLIDE_FORWARD), null == l2 || l2.removeShortcutsListener(i.Mo.VIDEO_PLAYER, i.lbr.SLIDE_BACKWARD);
            }),
            [l2, t3.ids, e3, o3, n2, s3, a3.isAdvertShown]
          );
        })(k2), 0 === a2.ids.length && k2(), (0, r.useEffect)(
          () => () => {
            a2.reset(), t2.setIsShowBanner(true);
          },
          [a2, t2, t2.setIsShowBanner]
        ), (0, r.useEffect)(() => {
          a2.modal.isOpened ? t2.setIsShowBanner(false) : t2.setIsShowBanner(true);
        }, [a2.modal.isOpened, t2, t2.setIsShowBanner]);
        let E2 = (0, C.c)(() => {
          a2.setAnimationState(true), x2 && h2(String(x2)), d2(i.Zyd.main.href), a2.modal.close(), a2.reset();
        });
        return (0, r.useEffect)(() => {
          if (a2.isNotFound || a2.isSomethingWrong) {
            k2();
            let t3 = a2.modal.isOpened ? i.uQT.FULLSCREEN_ERROR : i.uQT.ERROR;
            m2((0, g.jsx)(T.hT, { error: e2({ id: "error-messages.something-went-wrong" }) }), { containerId: t3 });
          }
        }, [a2.isNotFound, a2.isSomethingWrong, a2.modal.isOpened, k2, e2, m2]), (0, r.useEffect)(() => {
          a2.modal.isOpened && x2 && v2(String(x2));
        }, [a2.modal.isOpened, v2, x2]), (0, r.useEffect)(
          () => (window.addEventListener("popstate", P2), () => {
            window.removeEventListener("popstate", P2);
          }),
          [P2]
        ), ((e3) => {
          (0, r.useEffect)(() => {
            (null == e3 ? void 0 : e3.clips) && 0 !== e3.clips.length && !e3.isLoading && n({
              clipMeta: (0, l.wS)(e3.clips[0]),
              additional: { fullUrl: null, locale: null, url: null, tld: "", host: "" }
            }).then((e4) => {
              (0, i.jxB)(e4);
            });
          }, [null == e3 ? void 0 : e3.clips, null == e3 ? void 0 : e3.isLoading]);
        })(a2), (0, r.useEffect)(() => {
          a2.isNeededToLoad && a2.modal.isOpened && x2 && a2.getClips();
        }, [a2, a2.isNeededToLoad, a2.modal.isOpened, x2]), (0, g.jsxs)(I.a, {
          className: (0, y.$)(Z().root, Z().important),
          open: a2.modal.isOpened,
          onOpenChange: a2.modal.onOpenChange,
          onClose: k2,
          portalNode: s2,
          size: "fullscreen",
          placement: "center",
          showHeader: false,
          contentClassName: Z().modalContent,
          closeOnOutsidePress: false,
          escapeKey: false,
          transitionDuration: 300 * !!a2.withAnimation,
          ...(0, A.Am)(A.e8.videoPlayer.FULLSCREEN_VIDEO_PLAYER_MODAL),
          children: [
            (0, g.jsxs)("header", {
              className: Z().header,
              children: [
                (0, g.jsx)(N.$, {
                  className: Z().closeButton,
                  radius: "round",
                  color: "secondary",
                  size: "m",
                  icon: (0, g.jsx)(f.Icon, { variant: "arrowDown", size: "xs" }),
                  onClick: k2,
                  "aria-label": e2({ id: "interface-actions.close" }),
                  ...(0, A.Am)(A.e8.videoPlayer.FULLSCREEN_VIDEO_PLAYER_CLOSE_BUTTON)
                }),
                (0, g.jsx)(T.N_, {
                  className: Z().logoLink,
                  href: "/",
                  onClick: E2,
                  "aria-label": e2({ id: "navigation.page-main" }),
                  ...(0, A.Am)(A.e8.videoPlayer.FULLSCREEN_VIDEO_PLAYER_LABEL_BUTTON),
                  children: (0, g.jsx)(f.Icon, {
                    variant: "musicLogoCenter".concat(p2),
                    className: Z()["logo_".concat(p2.toLocaleLowerCase())]
                  })
                })
              ]
            }),
            (0, g.jsx)(H, { closeModal: k2 }),
            (0, g.jsx)(Y, {}),
            (0, g.jsx)(S.Notification, {
              className: Z().notification,
              enableMultiContainer: true,
              containerId: i.uQT.FULLSCREEN_INFO,
              position: "bottom-center"
            }),
            (0, g.jsx)(S.Notification, {
              className: Z().notification,
              enableMultiContainer: true,
              containerId: i.uQT.FULLSCREEN_ERROR,
              position: "bottom-center"
            })
          ]
        });
      }), ee = (0, x.PA)(() => {
        let {
          settings: { isMobile: e2 }
        } = (0, i.Pjs)();
        return e2 ? null : (0, g.jsx)(J, {});
      });
    },
    13528: (e) => {
      e.exports = {
        root: "PlayQueue_root__ponhw",
        content: "PlayQueue_content__zIUvd",
        scrollContent: "PlayQueue_scrollContent__2dI0v"
      };
    },
    14140: (e) => {
      e.exports = { root: "TicketImage_root__vTgWd" };
    },
    16213: (e, t, a) => {
      "use strict";
      a.d(t, { tL: () => C, __: () => s, cZ: () => l });
      var i, n, r = a(93064);
      let l = (e2) => {
        let { text: t2, textColor: a2, color: i2, action: n2 } = e2;
        return (0, r.wg)({
          text: t2 || null,
          textColor: a2 || null,
          color: i2 || null,
          action: n2 && ((e3) => {
            let { id: t3, type: a3, value: i3, communicationId: n3 } = e3;
            return (0, r.wg)({ id: t3 || null, type: a3 || null, value: i3 || null, communicationId: n3 || null });
          })(n2)
        });
      };
      !(function(e2) {
        e2.CLOSE = "close", e2.LINK = "link", e2.PAYWALL = "paywall";
      })(i || (i = {}));
      let o = r.gK.model("CommunicationButtonAction", {
        id: r.gK.maybeNull(r.gK.string),
        type: r.gK.maybeNull(r.gK.enumeration(Object.values(i))),
        value: r.gK.maybeNull(r.gK.string),
        communicationId: r.gK.maybeNull(r.gK.string)
      });
      !(function(e2) {
        e2.PRIMARY = "primary", e2.SECONDARY = "secondary", e2.PLUS = "plus";
      })(n || (n = {}));
      let s = r.gK.model("CommunicationButton", {
        text: r.gK.maybeNull(r.gK.string),
        color: r.gK.maybeNull(r.gK.enumeration(Object.values(n))),
        action: r.gK.maybeNull(o),
        textColor: r.gK.maybeNull(r.gK.string)
      });
      var c = a(54486), d = a(50420), u = a(28303), m = a(61910), _ = a(31500), p = a(8817), v = a(67648), h = a(27510), g = a(77881), x = a(97800), y = a(74125), b = a(82502), A = a.n(b);
      let C = (0, u.PA)((e2) => {
        var t2, a2, n2, r2;
        let {
          anchorId: l2,
          screenId: o2,
          button: s2,
          buttonSize: u2,
          buttonClassName: b2,
          textClassName: C2,
          feedbackToken: N,
          hide: f
        } = e2, { communication: I } = (0, y.Pjs)(), [S] = (0, v.d)(), { openPaymentWidgetModal: T } = (0, y.DpZ)({
          storeName: "music",
          communicationId: null != (r2 = null == (t2 = s2.action) ? void 0 : t2.communicationId) ? r2 : "",
          offerElement: { element: S, intersectionPropertyId: "barbellow" },
          isEnabled: !!(null == (a2 = s2.action) ? void 0 : a2.communicationId)
        }), P = (null == (n2 = s2.action) ? void 0 : n2.type) === i.LINK && s2.action.value || "", k = (0, y.ZpR)(P), E = (0, p.c)((e3) => {
          if (s2.action)
            switch (l2 && o2 && s2.action.id && I.action(l2, o2, s2.action.id, N), s2.action.type) {
              case i.PAYWALL:
                T(), null == f || f();
                return;
              case i.LINK:
                s2.action.value && (k(e3), null == f || f());
                return;
              case i.CLOSE:
                null == f || f();
                return;
            }
        }), j = (0, m.useMemo)(() => {
          if (s2.textColor) return { color: s2.textColor };
        }, [s2.textColor]), L = (0, h.L)(() => {
          var e3;
          switch (null == (e3 = s2.action) ? void 0 : e3.type) {
            case i.LINK:
              return _.OA.communicationButton.COMMUNICATION_BUTTON_LINK;
            case i.CLOSE:
              return _.OA.communicationButton.COMMUNICATION_BUTTON_CLOSE;
            default:
              return _.OA.communicationButton.COMMUNICATION_BUTTON_PAYWALL;
          }
        });
        return (0, c.jsx)(g.$, {
          className: (0, d.$)(A().root, A()["root_".concat(s2.color)], b2),
          role: P ? "link" : "button",
          color: s2.color ? s2.color : void 0,
          radius: "xxxl",
          onClick: E,
          size: u2,
          ...(0, _.Am)(L),
          children: (0, c.jsx)(x.Caption, {
            className: (0, d.$)(A().text, C2),
            variant: "div",
            type: "text",
            size: "m",
            style: j,
            children: s2.text
          })
        });
      });
    },
    16825: (e) => {
      e.exports = { buttonWithPlayerBar: "WithBuySubscriptionModal_buttonWithPlayerBar__p7or7" };
    },
    18180: (e) => {
      e.exports = {
        root: "TrackModalAlbumShimmer_root__iGoUU",
        title: "TrackModalAlbumShimmer_title__2jt8z",
        coverBlock: "TrackModalAlbumShimmer_coverBlock__PQFDQ",
        cover: "TrackModalAlbumShimmer_cover__AI0zt",
        linkBlock: "TrackModalAlbumShimmer_linkBlock__yBLL4",
        link: "TrackModalAlbumShimmer_link__7_gHs",
        description: "TrackModalAlbumShimmer_description__63Pnt"
      };
    },
    18726: (e) => {
      e.exports = {
        root: "PlayingNow_root__0lQa8",
        textBlock: "PlayingNow_textBlock___CfRh",
        title: "PlayingNow_title__82csz",
        subTitle: "PlayingNow_subTitle__JNJfh",
        link: "PlayingNow_link__4gLK9"
      };
    },
    19020: (e, t, a) => {
      "use strict";
      a.d(t, { M: () => g, v: () => s });
      var i = a(93064), n = a(59672), r = a(1762), l = a(74125), o = a(26433);
      let s = i.gK.compose(
        i.gK.model("BrandedPlayerBanner", {
          payload: i.gK.maybeNull(i.gK.model({ thumb: n.KB, modal: i.gK.maybeNull(r.i_) })),
          modal: o.qt
        }),
        o.JE
      ).views((e2) => ({
        get isVisible() {
          let { experiments: t2, settings: a2, user: n2 } = (0, i.Zn)(e2);
          if (e2.noAds || e2.hasError || t2.checkExperiment(l.zal.WebNextDisableAds, "on") || !t2.checkExperiment(l.zal.WebNextPlayerBranding, "on"))
            return false;
          return !n2.hasPlus && !a2.isMobile;
        }
      })).actions((e2) => ({
        setPayload: (t2) => {
          let { settings: a2 } = (0, i.Zn)(e2);
          a2.setCustomPlayerThumb(l.TZj.BRANDED), e2.payload = (0, i.wg)(t2);
        }
      }));
      var c = a(54486), d = a(28303), u = a(61910), m = a(8817), _ = a(80585);
      let p = { pp: "g", ps: "clni", p2: "joqc", puid1: "", puid2: "", puid3: "" };
      var v = a(16560), h = (function(e2) {
        return e2.PLAYER = "branded_player", e2;
      })({});
      let g = (0, d.PA)(() => {
        let {
          advertBanners: {
            banners: { brandedPlayerBanner: e2 }
          }
        } = (0, l.Pjs)(), t2 = (0, m.c)(() => {
          e2.setType(l.h8o.BRANDING);
        }), a2 = (0, m.c)((t3) => {
          ((e3) => (0, v.m)(e3) && e3.type === h.PLAYER && "object" == typeof e3.payload && null !== e3.payload && !Array.isArray(e3.payload) && "thumb" in e3.payload && (0, n.ls)(e3.payload.thumb) && "modal" in e3.payload && (0, r.h9)(e3.payload.modal))(t3.data) && e2.setPayload(t3.data.payload);
        });
        return ((0, u.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), (0, u.useEffect)(
          () => (window.addEventListener("message", a2), () => {
            window.removeEventListener("message", a2);
          }),
          [a2]
        ), e2.isVisible) ? (0, c.jsx)(_.NX, {
          ownerId: l.PVv,
          containerId: "adfox_175861261312993498",
          params: p,
          onLoad: t2,
          onError: e2.toggleHasErrorTrue,
          onNoAds: e2.toggleNoAdsTrue
        }) : null;
      });
    },
    20125: (e) => {
      e.exports = {
        root: "BuySubscriptionModal_root__5LvlX",
        content: "BuySubscriptionModal_content__v06Ju",
        heading: "BuySubscriptionModal_heading__07nBE",
        buttons: "BuySubscriptionModal_buttons__wSCRP",
        button: "BuySubscriptionModal_button__8m6Dx",
        buttonMainText: "BuySubscriptionModal_buttonMainText__pyjEc",
        buttonAdditionText: "BuySubscriptionModal_buttonAdditionText__rdKJn",
        header: "BuySubscriptionModal_header__ho5hr"
      };
    },
    21514: (e, t, a) => {
      "use strict";
      a.d(t, { w: () => f, J: () => l });
      var i = a(63930), n = a(93064), r = a(26433);
      let l = n.gK.model("ImageSliderModal", {
        modal: r.qt,
        images: n.gK.maybeNull(n.gK.array(n.gK.string)),
        initialSlideIndex: n.gK.optional(n.gK.number, 0),
        loadedImages: n.gK.maybeNull(n.gK.array(n.gK.string)),
        sizeImage: n.gK.optional(n.gK.number, 1e3),
        withAspectRatio: n.gK.optional(n.gK.boolean, true)
      }).views((e2) => ({ isImageLoaded: (t2) => !!t2 && !!e2.loadedImages && e2.loadedImages.includes(t2) })).actions((e2) => ({
        openImages(t2) {
          let { images: a2, initialSlideIndex: r2, sizeImage: l2, withAspectRatio: o2 } = t2;
          e2.images = (0, n.wg)((0, i.HO)(a2)), e2.sizeImage = null != l2 ? l2 : 1e3, e2.withAspectRatio = null == o2 || o2, r2 && (e2.initialSlideIndex = r2), e2.modal.open();
        },
        setImageIsLoaded(t2) {
          var a2, i2;
          e2.loadedImages || (e2.loadedImages = (0, n.wg)([])), !t2 || (null == (a2 = e2.loadedImages) ? void 0 : a2.includes(t2)) || null == (i2 = e2.loadedImages) || i2.push(t2);
        },
        close() {
          e2.images = null, e2.initialSlideIndex = 0, e2.loadedImages = null, e2.modal.close();
        }
      }));
      var o = a(54486), s = a(50420), c = a(28303), d = a(61910), u = a(43426), m = a(91657), _ = a(36553), p = a(31500), v = a(8817), h = a(77881), g = a(5956), x = a(58360), y = a(32692), b = a(3728), A = a(74125), C = a(88684), N = a.n(C);
      let f = (0, c.PA)(() => {
        var e2, t2, a2, i2;
        let {
          settings: { isMobile: n2 },
          modals: { imageSliderModal: r2 }
        } = (0, A.Pjs)(), { formatMessage: l2 } = (0, u.A)(), { contentRef: c2 } = (0, A.gKY)(), C2 = (0, A.zwV)(), f2 = (0, d.useRef)(null), [I, S] = (0, d.useState)(true), [T, P] = (0, d.useState)(false), [k, E] = (0, d.useState)(0), j = (null != (i2 = null == (e2 = r2.images) ? void 0 : e2.length) ? i2 : 0) > 1, L = (0, v.c)(() => {
          var e3;
          null == (e3 = f2.current) || e3.swiper.slideNext();
        }), w = (0, v.c)(() => {
          var e3;
          null == (e3 = f2.current) || e3.swiper.slidePrev();
        }), M = (0, v.c)((e3) => {
          S(e3.isBeginning), P(e3.isEnd), E(e3.activeIndex);
        });
        return (0, d.useEffect)(() => {
          setTimeout(() => {
            var e3, t3, a3;
            (null == (e3 = f2.current) ? void 0 : e3.swiper) && (S(0 === f2.current.swiper.activeIndex), P(
              f2.current.swiper.activeIndex === (null != (a3 = null == (t3 = r2.images) ? void 0 : t3.length) ? a3 : 0) - 1
            ), E(f2.current.swiper.activeIndex));
          });
        }, [null == (t2 = r2.images) ? void 0 : t2.length, n2]), (0, d.useEffect)(() => {
          r2.modal.isOpened ? (null == C2 || C2.disable(A.Mo.MAIN, A.lbr.CLOSE), null == C2 || C2.disable(A.Mo.MAIN, A.lbr.SLIDE_BACKWARD), null == C2 || C2.disable(A.Mo.MAIN, A.lbr.SLIDE_FORWARD), null == C2 || C2.enable(A.Mo.IMAGE_SLIDER, A.lbr.CLOSE)) : (null == C2 || C2.disable(A.Mo.IMAGE_SLIDER, A.lbr.CLOSE), null == C2 || C2.enable(A.Mo.MAIN, A.lbr.CLOSE), null == C2 || C2.enable(A.Mo.MAIN, A.lbr.SLIDE_BACKWARD), null == C2 || C2.enable(A.Mo.MAIN, A.lbr.SLIDE_FORWARD));
        }, [C2, r2.modal.isOpened]), (0, d.useEffect)(
          () => (null == C2 || C2.addShortcutsListener(A.Mo.IMAGE_SLIDER, A.lbr.CLOSE, () => {
            r2.modal.isOpened && r2.close();
          }), () => {
            null == C2 || C2.removeShortcutsListener(A.Mo.IMAGE_SLIDER, A.lbr.CLOSE), null == C2 || C2.disable(A.Mo.IMAGE_SLIDER, A.lbr.CLOSE), null == C2 || C2.enable(A.Mo.MAIN, A.lbr.CLOSE), null == C2 || C2.enable(A.Mo.MAIN, A.lbr.SLIDE_BACKWARD), null == C2 || C2.enable(A.Mo.MAIN, A.lbr.SLIDE_FORWARD), r2.close();
          }),
          [C2, r2]
        ), (0, o.jsxs)(y.a, {
          className: (0, s.$)(N().root, { [N().root_mobile]: n2 }),
          contentClassName: N().modalContent,
          open: r2.modal.isOpened,
          size: n2 ? "fullscreen" : "fitContent",
          placement: "center",
          showHeader: false,
          isMobile: n2,
          onClose: r2.close,
          escapeKey: false,
          onOpenChange: r2.modal.onOpenChange,
          portalNode: n2 ? null : c2,
          withAnimation: !r2.modal.isOpened,
          ...(0, p.Am)(p.e8.imageSlider.IMAGE_SLIDER_MODAL),
          children: [
            (0, o.jsx)("div", {
              className: N().leftArrowWrapper,
              children: j && (0, o.jsx)(h.$, {
                radius: "round",
                color: "secondary",
                size: "xxs",
                icon: (0, o.jsx)(g.Icon, { variant: "arrowLeft", size: "xxs" }),
                onClick: w,
                disabled: I,
                "aria-label": l2({ id: "slider.prev-image" }),
                ...(0, p.Am)(p.e8.imageSlider.IMAGE_SLIDER_MODAL_PREV_SLIDE_BUTTON)
              })
            }),
            (0, o.jsx)("div", {
              className: N().rightArrowWrapper,
              children: j && (0, o.jsx)(h.$, {
                radius: "round",
                color: "secondary",
                size: "xxs",
                icon: (0, o.jsx)(g.Icon, { variant: "arrowRight", size: "xxs" }),
                onClick: L,
                disabled: T,
                "aria-label": l2({ id: "slider.next-image" }),
                ...(0, p.Am)(p.e8.imageSlider.IMAGE_SLIDER_MODAL_NEXT_SLIDE_BUTTON)
              })
            }),
            (0, o.jsx)(h.$, {
              radius: "round",
              color: "secondary",
              size: "xxs",
              icon: (0, o.jsx)(g.Icon, { variant: "close", size: "xxs" }),
              className: N().closeButton,
              onClick: r2.close,
              "aria-label": l2({ id: "slider.close-image-modal" }),
              ...(0, p.Am)(p.e8.imageSlider.IMAGE_SLIDER_MODAL_CLOSE_BUTTON)
            }),
            (0, o.jsx)("div", {
              className: N().content,
              children: (0, o.jsx)(_.RC, {
                initialSlide: r2.initialSlideIndex,
                className: N().slider,
                wrapperClass: N().wrapper,
                ref: f2,
                onActiveIndexChange: M,
                a11y: { enabled: true, containerMessage: l2({ id: "slider.image-slider-modal" }) },
                pagination: { dynamicBullets: true, dynamicMainBullets: 4 },
                modules: [m.dK, m.s3],
                keyboard: true,
                children: null == (a2 = r2.images) ? void 0 : a2.map((e3, t3) => {
                  var a3, i3;
                  let n3 = ((e4, t4) => e4 >= t4 - 5 && e4 <= t4 + 5)(t3, k) ? e3 : void 0;
                  return (0, o.jsxs)(
                    _.qr,
                    {
                      className: N().slide,
                      ...(0, p.Am)(p.e8.imageSlider.IMAGE_SLIDER_MODAL_SLIDE),
                      children: [
                        (0, o.jsx)(x.Image, {
                          fit: "contain",
                          className: (0, s.$)(N().image, { [N().image_loading]: !r2.isImageLoaded(n3) }),
                          src: n3,
                          size: r2.sizeImage,
                          tabIndex: t3 === k ? 0 : -1,
                          "aria-roledescription": l2({ id: "slider.slide" }),
                          "aria-label": l2(
                            { id: "slider.image-counter" },
                            {
                              index: t3 + 1,
                              count: null != (i3 = null == (a3 = r2.images) ? void 0 : a3.length) ? i3 : 0
                            }
                          ),
                          onLoadBySrc: r2.setImageIsLoaded,
                          withLoadingIndicator: false,
                          withSrcSet: false,
                          withAvatarReplace: true,
                          withAspectRatio: r2.withAspectRatio
                        }),
                        t3 === k && (0, o.jsx)("div", {
                          className: (0, s.$)(N().loadingIndicator, {
                            [N().loadingIndicator_showed]: !r2.isImageLoaded(n3)
                          }),
                          children: (0, o.jsx)(b.y, { size: "m" })
                        })
                      ]
                    },
                    t3
                  );
                })
              })
            })
          ]
        });
      });
    },
    21891: (e) => {
      e.exports = {
        root: "FullscreenPlayerMobile_root__Sqyh0",
        important: "FullscreenPlayerMobile_important__1lAN3",
        header: "FullscreenPlayerMobile_header__8KH28",
        headerCenter: "FullscreenPlayerMobile_headerCenter___EqSP",
        modalContent: "FullscreenPlayerMobile_modalContent__m2cbB",
        castButton: "FullscreenPlayerMobile_castButton__3ZgER",
        footer: "FullscreenPlayerMobile_footer__LRvhK",
        footerContainer: "FullscreenPlayerMobile_footerContainer__aupK1",
        playQueueButton_active: "FullscreenPlayerMobile_playQueueButton_active__CG2s8",
        syncLyricsButton_active: "FullscreenPlayerMobile_syncLyricsButton_active__6L4YF",
        notification: "FullscreenPlayerMobile_notification__V1cxP"
      };
    },
    23258: (e) => {
      e.exports = {
        root: "NavbarDesktopAnimatedDownloadBarMinimized_root__nEPqZ",
        icon: "NavbarDesktopAnimatedDownloadBarMinimized_icon__Y2hec",
        button: "NavbarDesktopAnimatedDownloadBarMinimized_button__hesBw"
      };
    },
    23605: (e) => {
      e.exports = {
        growContainer: "FamilyInviteStepInfo_growContainer__y0xmo",
        important: "FamilyInviteStepInfo_important__YvkpI"
      };
    },
    25358: (e) => {
      e.exports = {
        root: "PlayQueueBeforePlayingBlock_root__QIIfB",
        prevTrack: "PlayQueueBeforePlayingBlock_prevTrack__5b6o4",
        animatedContent: "PlayQueueBeforePlayingBlock_animatedContent__C04_K",
        animatedContent_moveToBottom: "PlayQueueBeforePlayingBlock_animatedContent_moveToBottom__2gKF7",
        "move-to-bottom": "PlayQueueBeforePlayingBlock_move-to-bottom__7EZIY",
        animatedContent_moveFromBottom: "PlayQueueBeforePlayingBlock_animatedContent_moveFromBottom__0kTuW",
        "move-from-bottom": "PlayQueueBeforePlayingBlock_move-from-bottom__8mDwi",
        "move-prev-track-from-bottom": "PlayQueueBeforePlayingBlock_move-prev-track-from-bottom__mFqMq",
        animatedContent_moveFromBottomSingleTrack: "PlayQueueBeforePlayingBlock_animatedContent_moveFromBottomSingleTrack__MIEIc",
        "move-from-bottom-single-track": "PlayQueueBeforePlayingBlock_move-from-bottom-single-track__YhsMT",
        "move-prev-track-from-bottom-single-track": "PlayQueueBeforePlayingBlock_move-prev-track-from-bottom-single-track__NGI9j"
      };
    },
    25615: (e) => {
      e.exports = {
        root: "NavbarDesktopAnimatedPlusBar_root___wH9W",
        button: "NavbarDesktopAnimatedPlusBar_button__IX7L4",
        important: "NavbarDesktopAnimatedPlusBar_important__7R916",
        icon: "NavbarDesktopAnimatedPlusBar_icon__9lTgJ"
      };
    },
    25818: (e, t, a) => {
      "use strict";
      a.d(t, { v: () => y, J: () => E });
      var i = a(54486), n = a(50420), r = a(61910), l = a(43426), o = a(31500), s = a(8817), c = a(27510), d = a(28584), u = a(74125), m = a(37262), _ = a.n(m), p = a(97800), v = a(7495), h = a.n(v);
      let g = (e2) => {
        let { value: t2, variant: a2, className: r2, forwardRef: l2, ...s2 } = e2, c2 = "start" === a2 ? o.Kq.changeTimecode.TIMECODE_TIME_START : o.Kq.changeTimecode.TIMECODE_TIME_END;
        return (0, i.jsx)(p.Caption, {
          ref: l2,
          tabIndex: 0,
          className: (0, n.$)(h().root, h()["root_".concat(a2)], r2),
          variant: "span",
          size: "s",
          type: "entity",
          weight: "medium",
          ...(0, o.Am)(c2),
          ...s2,
          children: (0, i.jsx)("span", { "aria-hidden": "true", children: t2 })
        });
      }, x = (0, r.forwardRef)((e2, t2) => (0, i.jsx)(g, { forwardRef: t2, ...e2 })), y = (e2) => {
        var t2, a2, m2, p2;
        let {
          className: v2,
          sliderClassName: h2,
          disabled: g2,
          isFullscreen: y2,
          isMobile: b2,
          showThumbVariant: A2,
          withTimecode: C2 = true,
          sonataPlaybackId: N2,
          customDuration: f2,
          canMoveForward: I2
        } = e2, S2 = (0, u.eGp)(), T2 = (y2 || !b2) && C2, P2 = (0, r.useRef)(false), { sonataState: k2 } = (0, u.Pjs)(), [E2, j] = (0, r.useState)(null != (m2 = k2.position) ? m2 : 0), [L, w] = (0, r.useState)(null != (p2 = k2.duration) ? p2 : 0), [M, B] = (0, r.useState)(0), { formatMessage: O } = (0, l.A)(), { advert: R } = (0, u.Pjs)(), D = (0, u.rs2)(), K = E2 && L ? 100 * Math.min(E2, L) / L : 0, U = null == S2 ? void 0 : S2.getState(N2), F = (0, u.PMf)(E2), z = (0, u.E4p)(Math.round(E2), Math.round(L)), V = (0, u.PMf)(L), W = f2 && E2 > f2, G = (0, s.c)((e3, t3) => {
          R.isAdvertShown || (P2.current = !t3, t3 ? null == S2 || S2.setProgress(e3, N2) : j(e3));
        });
        (0, r.useEffect)(() => {
          W && (I2 ? null == S2 || S2.moveForward(N2) : (null == S2 || S2.moveBackward(N2), null == S2 || S2.pause(N2)));
        }, [I2, W, S2, N2]);
        let Y = (0, r.useCallback)(
          (e3) => {
            e3 && (e3.duration === 1 / 0 ? (w(0), j(0), B(0)) : (w(f2 && !R.isAdvertShown ? f2 : e3.duration), j((t3) => P2.current ? t3 : e3.position), B(e3.loaded)));
          },
          [f2, R.isAdvertShown]
        );
        (0, r.useEffect)(() => {
          var e3, t3;
          let a3 = null == D || null == (e3 = D.audioAdvertPlayback) ? void 0 : e3.state.playerState.progress.onChange(Y), i2 = null == U || null == (t3 = U.playerState) ? void 0 : t3.progress.onChange(Y);
          return () => {
            null == i2 || i2(), null == a3 || a3();
          };
        }, [
          null == D || null == (t2 = D.audioAdvertPlayback) ? void 0 : t2.state.playerState.progress,
          Y,
          null == U || null == (a2 = U.playerState) ? void 0 : a2.progress
        ]);
        let Q = (0, c.L)(() => {
          if (0 !== L) return f2 && f2 <= L ? Math.round(f2) : Math.round(L);
        });
        return (0, i.jsxs)("div", {
          className: (0, n.$)(
            _().root,
            { [_().root_fullscreen]: y2, [_().root_mobile]: b2, [_().root_withTimecode]: C2 },
            v2
          ),
          style: { "--track-progress": "".concat(K, "%") },
          ...(0, o.Am)(o.Kq.changeTimecode.TIMECODE_WRAPPER),
          children: [
            T2 && (0, i.jsx)(x, { role: "text", "aria-label": F, value: z, variant: "start", className: _().timecode }),
            (0, i.jsx)(d.A, {
              "aria-valuetext": F,
              className: (0, n.$)(_().slider, { [_()["slider_thumbSize_".concat(b2 ? "xs" : "m")]]: true }, h2),
              disabled: g2,
              thumbSize: b2 ? "xs" : "s",
              trackSize: b2 ? "xs" : "s",
              value: Math.round(E2),
              mode: "deferred",
              secondaryValue: Math.round(M),
              maxValue: Q,
              onChange: G,
              "aria-label": O({ id: "player-actions.timecode-control" }),
              showThumbVariant: A2,
              ...(0, o.Am)(o.Kq.changeTimecode.TIMECODE_SLIDER)
            }),
            T2 && (0, i.jsx)(x, {
              role: "text",
              "aria-label": V,
              value: (0, u.E4p)(Math.round(L), Math.round(L)),
              variant: "end",
              className: _().timecode
            })
          ]
        });
      };
      var b = a(28303), A = a(62443), C = a(89461), N = a(59672), f = a(1762), I = a(38234), S = a.n(I), T = a(85465), P = a.n(T);
      let k = (e2) => {
        let {
          progress: t2,
          position: a2,
          duration: l2,
          timecodeClassName: o2,
          currentTimecodeClassName: s2,
          progressElementWidth: d2,
          shouldHoldTimecode: m2
        } = e2, _2 = (0, u.PMf)(a2), p2 = (0, u.PMf)(l2), v2 = (0, r.useRef)(null), [h2, g2] = (0, r.useState)(0), y2 = (0, u.E4p)(Math.round(l2), Math.round(l2));
        (0, r.useEffect)(() => {
          v2.current && g2(Math.round(v2.current.getBoundingClientRect().width));
        }, [y2.length, d2]);
        let b2 = Math.round(t2 / 100 * d2), A2 = 0 !== d2 ? d2 - h2 : 0, C2 = Math.min(Math.max(b2 - h2 / 2, 0), A2), N2 = (0, c.L)(() => {
          if (!m2) return { "--timecode-position": "".concat(C2, "px") };
        });
        return (0, i.jsxs)(i.Fragment, {
          children: [
            (0, i.jsx)(x, {
              role: "text",
              "aria-label": p2,
              value: y2,
              variant: "end",
              className: (0, n.$)(P().timecode, o2, P().timecode_end, { [P().timecode_end_hidden]: !(b2 < A2 - h2 / 2) })
            }),
            (0, i.jsx)(x, {
              role: "text",
              "aria-label": _2,
              style: N2,
              ref: v2,
              value: (0, u.E4p)(Math.round(a2), Math.round(l2)),
              variant: "start",
              className: (0, n.$)(P().timecode, P().timecode_current, o2, s2, {
                [P().timecode_current_animation]: h2 > 0,
                [P().timecode_current_hidden]: m2 && !(b2 > 2 * h2)
              })
            })
          ]
        });
      }, E = (0, b.PA)((e2) => {
        var t2, a2;
        let {
          sliderClassName: m2,
          disabled: _2,
          isMobile: p2,
          progressbarClassName: v2,
          showThumbVariant: h2,
          withTimecode: g2 = true
        } = e2, x2 = (0, u.eGp)(), y2 = (0, r.useRef)(false), {
          advert: b2,
          sonataState: I2,
          settings: T2,
          advertBanners: {
            banners: { brandedPlayerBanner: P2 }
          }
        } = (0, u.Pjs)(), { formatMessage: E2 } = (0, l.A)(), j = (0, u.rs2)(), [L, w] = (0, r.useState)(I2.position), [M, B] = (0, r.useState)(I2.duration), O = (0, u.PMf)(Math.round(null != L ? L : 0)), R = L && M ? 100 * Math.min(L, M) / M : 0, D = (0, r.useRef)(null), [K, U] = (0, r.useState)(0), F = K > 0, { state: z, toggleTrue: V, toggleFalse: W } = (0, A.e)(false), { state: G, toggleTrue: Y, toggleFalse: Q } = (0, A.e)(false), $ = (0, c.L)(() => {
          var e3, t3;
          return P2.isVisible && (null == (e3 = P2.payload) ? void 0 : e3.thumb) ? { thumb: P2.payload.thumb, onThumbAction: P2.modal.open } : T2.selectedThumbId && T2.selectedThumbId !== u.TZj.DEFAULT ? { thumb: null == (t3 = (0, N.rI)(E2).get(T2.selectedThumbId)) ? void 0 : t3.thumb } : void 0;
        });
        (0, r.useEffect)(() => {
          (null == x2 ? void 0 : x2.state.playerState.status.value) === C.MT.PLAYING && Q();
        }, [Q, null == x2 ? void 0 : x2.state.playerState.status.value]), (0, r.useEffect)(() => {
          let e3 = null == x2 ? void 0 : x2.state.queueState.currentEntity.onChange(Y);
          return Q(), () => {
            null == e3 || e3();
          };
        }, [Y, Q, null == x2 ? void 0 : x2.state.queueState.currentEntity]);
        let q = (0, s.c)((e3, t3) => {
          b2.isAdvertShown || (y2.current = !t3, t3 ? null == x2 || x2.setProgress(e3) : w(e3));
        }), H = (0, s.c)((e3, t3) => {
          null !== e3 && null !== t3 && (e3 === 1 / 0 ? (B(0), w(0)) : (B(e3), y2.current || w(t3)));
        });
        (0, r.useEffect)(() => {
          H(I2.duration, I2.position);
        }, [I2.duration, I2.position, H]), (0, r.useEffect)(() => {
          var e3;
          let t3 = null == j || null == (e3 = j.audioAdvertPlayback) ? void 0 : e3.state.playerState.progress.onChange((e4) => {
            e4 && b2.isAdvertShown && H(e4.duration, e4.position);
          });
          return () => {
            null == t3 || t3();
          };
        }, [
          null == j || null == (t2 = j.audioAdvertPlayback) ? void 0 : t2.state.playerState.progress,
          H,
          b2.isAdvertShown
        ]);
        let X = R / 100 * K - 6;
        (0, r.useEffect)(() => {
          let e3 = new ResizeObserver(() => {
            var e4, t3;
            U(Math.round(null != (t3 = null == (e4 = D.current) ? void 0 : e4.clientWidth) ? t3 : 0));
          });
          return D.current && e3.observe(D.current), () => {
            e3.disconnect();
          };
        }, []);
        let Z = {
          "--size-thumb": "".concat(12, "px"),
          "--track-progress": "".concat(R, "%"),
          "--thumb-position": "".concat(X, "px"),
          ...G && { "--transition-disabled": "none" }
        };
        return (0, i.jsxs)("div", {
          className: (0, n.$)(S().root, { [S().root_focusVisible]: z, [S().root_isPlayingTrack]: !b2.isAdvertShown }),
          style: Z,
          ...(0, o.Am)(o.Kq.changeTimecode.TIMECODE_WRAPPER),
          children: [
            !p2 && g2 && F && (0, i.jsx)(k, {
              currentTimecodeClassName: $ ? void 0 : (0, n.$)(S().timecodeGroupCurrent, S().important),
              timecodeClassName: S().timecodeGroup,
              progress: R,
              position: null != L ? L : 0,
              duration: null != M ? M : 0,
              progressElementWidth: K,
              shouldHoldTimecode: !!$
            }),
            (0, i.jsx)("div", { ref: D, className: (0, n.$)(S().progressbar, v2) }),
            F && !$ && (0, i.jsx)("div", { className: S().thumb }),
            $ && (0, i.jsx)(N.Th, {
              className: S().brandedThumb,
              thumbData: null == $ ? void 0 : $.thumb,
              onThumbAction: null == $ ? void 0 : $.onThumbAction
            }),
            (null == (a2 = P2.payload) ? void 0 : a2.modal) && (0, i.jsx)(f.N1, { modal: P2.payload.modal }),
            (0, i.jsx)(d.A, {
              "aria-valuetext": O,
              onClick: W,
              onBlur: W,
              onFocus: V,
              className: (0, n.$)(S().slider, S().important, m2),
              disabled: _2 || b2.isAdvertShown,
              "aria-label": E2({ id: "player-actions.timecode-control" }),
              showThumbVariant: h2,
              onChange: q,
              maxValue: M ? Math.round(M) : 0,
              mode: "deferred",
              value: Math.round(null != L ? L : 0),
              trackSize: "s",
              thumbSize: "s",
              ...(0, o.Am)(o.Kq.changeTimecode.TIMECODE_SLIDER)
            }),
            (0, i.jsx)("div", { className: S().backgroundProgressbar })
          ]
        });
      });
    },
    25886: (e) => {
      e.exports = {
        root: "SyncLyricsFooter_root__STCKQ",
        major: "SyncLyricsFooter_major__QMZmT",
        writers: "SyncLyricsFooter_writers__c7zhj"
      };
    },
    27176: (e) => {
      e.exports = {
        imageContainer: "AudioAd_imageContainer__ZmZsg",
        image: "AudioAd_image__f6DJR",
        image_fallback: "AudioAd_image_fallback__7ufC3",
        backgroundImage: "AudioAd_backgroundImage__aqvQd",
        contextMenuButton: "AudioAd_contextMenuButton__fbb47",
        contextMenuIcon: "AudioAd_contextMenuIcon__KTxE1",
        contextMenuHeader: "AudioAd_contextMenuHeader__97XqU"
      };
    },
    27319: (e) => {
      e.exports = {
        root: "PlayQueueVibeBlock_root__cVjcM",
        ripple: "PlayQueueVibeBlock_ripple__Ig_pb",
        vibeCover: "PlayQueueVibeBlock_vibeCover__THxKz",
        title: "PlayQueueVibeBlock_title__G3kir",
        vibeTitle: "PlayQueueVibeBlock_vibeTitle__C5fWp"
      };
    },
    30980: (e) => {
      e.exports = {
        icon: "ChangeVolume_icon__5Zv2a",
        button: "ChangeVolume_button__4HLEr",
        sliderContainer: "ChangeVolume_sliderContainer__pvOZa",
        sliderContainer_focusVisible: "ChangeVolume_sliderContainer_focusVisible__1JxI9",
        wrapperSlider: "ChangeVolume_wrapperSlider__9S1Vi",
        root: "ChangeVolume_root__HDxtA",
        slider: "ChangeVolume_slider__fCKGZ",
        important: "ChangeVolume_important__ZIYpu"
      };
    },
    31182: (e) => {
      e.exports = {
        root: "TrailerModal_root__T4ZJ8",
        modalContent: "TrailerModal_modalContent__ZSNFe",
        header: "TrailerModal_header__0h1zj"
      };
    },
    31865: (e) => {
      e.exports = {
        root: "NavbarDesktopUnauthorizedBar_root__uQZ9L",
        title: "NavbarDesktopUnauthorizedBar_title__vf0W7",
        subtitle: "NavbarDesktopUnauthorizedBar_subtitle__anNNQ",
        userProfile: "NavbarDesktopUnauthorizedBar_userProfile__hAABb",
        userId: "NavbarDesktopUnauthorizedBar_userId__m0jC6",
        buttons: "NavbarDesktopUnauthorizedBar_buttons__94Y3N"
      };
    },
    32061: (e, t, a) => {
      "use strict";
      a.d(t, {
        kn: () => b,
        vR: () => tq,
        uZ: () => M,
        LN: () => am,
        Hq: () => ag,
        OK: () => B,
        BG: () => ab,
        so: () => i
      });
      var i = (function(e10) {
        return e10.VIDEO = "video-ad-player", e10.SLOT = "video-ad-container", e10;
      })({}), n = a(74125);
      let r = (e10) => {
        let t10 = (0, n.eGp)(), {
          fullscreenPlayer: {
            playQueue: { trackMap: a2 }
          }
        } = (0, n.Pjs)(), i2 = null == t10 ? void 0 : t10.state.queueState.entityList.value, r2 = null == i2 ? void 0 : i2[e10];
        if (!r2) return null;
        let {
          context: { data: l2 }
        } = r2, o2 = a2.get(String(r2.entity.data.meta.id));
        return o2 ? { track: o2, playContextParams: { contextData: l2, queueParams: { index: e10 } } } : null;
      };
      var l = a(93064);
      let o = l.gK.model("AdContainer", {
        adTitle: l.gK.maybe(l.gK.string),
        iconSrc: l.gK.maybe(l.gK.string),
        clickThroughUrl: l.gK.maybe(l.gK.string),
        src: l.gK.maybe(l.gK.string),
        clientLegalInfo: l.gK.maybe(l.gK.string),
        advertiserInfoUrl: l.gK.maybe(l.gK.string)
      });
      var s = a(54486), c = a(50420), d = a(28303), u = a(61910), m = a(47713), _ = a(77881), p = a(58360), v = a(97800), h = a(80585), g = a(99835), x = a.n(g);
      let y = (0, d.PA)((e10) => {
        let { className: t10, data: a2, mediaContent: i2, linkClassName: r2 } = e10, {
          settings: { isMobile: l2 }
        } = (0, n.Pjs)(), o2 = (0, n.rs2)(), d2 = (0, u.useMemo)(
          () => (null == o2 ? void 0 : o2.state.clickThrough) ? (0, s.jsx)(_.$, {
            className: (0, c.$)(x().button, r2),
            variant: "default",
            radius: "xxxl",
            onClick: o2.state.clickThrough,
            children: (0, s.jsx)(m.A, { id: "ads.learn-more" })
          }) : (null == a2 ? void 0 : a2.clickThroughUrl) ? (0, s.jsx)(h.N_, {
            target: "_blank",
            href: a2.clickThroughUrl,
            className: (0, c.$)(x().button, x().linkButton, r2),
            children: (0, s.jsx)(m.A, { id: "ads.learn-more" })
          }) : (0, s.jsx)(_.$, {
            className: (0, c.$)(x().button, r2),
            variant: "default",
            radius: "xxxl",
            disabled: true,
            children: (0, s.jsx)(m.A, { id: "ads.learn-more" })
          }),
          [null == a2 ? void 0 : a2.clickThroughUrl, null == o2 ? void 0 : o2.state.clickThrough, r2]
        );
        return (0, s.jsxs)("div", {
          className: (0, c.$)(x().root, t10),
          children: [
            i2,
            (0, s.jsxs)("div", {
              className: x().container,
              children: [
                (0, s.jsxs)("div", {
                  className: x().info,
                  children: [
                    (0, s.jsx)(p.Image, {
                      className: x().favicon,
                      withAspectRatio: true,
                      "aria-hidden": true,
                      fit: "cover",
                      src: (null == a2 ? void 0 : a2.iconSrc) || "",
                      alt: "",
                      fallbackIconVariant: "picture"
                    }),
                    (0, s.jsxs)("div", {
                      className: x().text,
                      children: [
                        (0, s.jsx)(v.Caption, {
                          variant: "div",
                          type: "text",
                          size: "l",
                          weight: "medium",
                          className: x().title,
                          lineClamp: l2 ? 5 : void 0,
                          children: null == a2 ? void 0 : a2.adTitle
                        }),
                        (0, s.jsx)(v.Caption, {
                          variant: "div",
                          type: "text",
                          size: "m",
                          weight: "medium",
                          className: x().subtitle,
                          children: (0, s.jsx)(m.A, { id: "ads.ad" })
                        })
                      ]
                    })
                  ]
                }),
                (0, s.jsx)("div", { className: x().buttonContainer, children: d2 })
              ]
            })
          ]
        });
      }), b = l.gK.model("Advert", {
        data: l.gK.maybeNull(o),
        isAdvertShown: l.gK.maybe(l.gK.boolean),
        isAdvertPlaying: l.gK.maybe(l.gK.boolean),
        isAdvertPlaybackCreated: l.gK.boolean,
        type: l.gK.maybeNull(l.gK.enumeration(Object.values(n.I1A)))
      }).views((e10) => ({
        get isAudioAdvert() {
          return e10.type === n.I1A.AUDIO;
        },
        get isVideoAdvert() {
          return e10.type === n.I1A.VIDEO;
        }
      })).actions((e10) => ({
        setData: (t10) => {
          e10.data = (0, l.wg)({
            adTitle: null == t10 ? void 0 : t10.adTitle,
            iconSrc: null == t10 ? void 0 : t10.iconSrc,
            clickThroughUrl: null == t10 ? void 0 : t10.clickThroughUrl,
            clientLegalInfo: null == t10 ? void 0 : t10.clientLegalInfo,
            advertiserInfoUrl: null == t10 ? void 0 : t10.advertiserInfoUrl
          });
        },
        setType(t10) {
          e10.type = t10;
        },
        setAdvertShown: (t10) => {
          e10.isAdvertShown = t10;
        },
        setAdvertPlaying: (t10) => {
          e10.isAdvertPlaying = t10;
        },
        setIsAdvertPlaybackCreated(t10) {
          e10.isAdvertPlaybackCreated = t10;
        },
        reset: () => {
          e10.data = null, e10.isAdvertPlaying = true, e10.isAdvertShown = false, e10.type = null;
        }
      }));
      var A = a(26433), C = (function(e10) {
        return e10.SYNC_LYRICS = "syncLyrics", e10.PLAY_QUEUE = "playQueue", e10;
      })({}), N = a(63585), f = a(89461), I = a(97719);
      let S = l.gK.compose(
        l.gK.model("PlayQueue", {
          isVisible: l.gK.optional(l.gK.boolean, false),
          beforeTracksIds: l.gK.maybeNull(l.gK.array(l.gK.number)),
          afterTracksIds: l.gK.optional(l.gK.frozen(), []),
          hiddenTrackIds: l.gK.array(l.gK.number),
          currentIndex: l.gK.optional(l.gK.number, 0),
          trackMap: l.gK.optional(l.gK.map(I.x5), {})
        }),
        A.pl
      ).views((e10) => ({
        get isVibeBlockShowed() {
          let {
            sonataState: { isVibeContext: t10 }
          } = (0, l.Zn)(e10);
          return !t10 && 0 === e10.afterTracksIds.length;
        },
        get itemsKeys() {
          var t10, a2;
          return null != (a2 = null == (t10 = e10.beforeTracksIds) ? void 0 : t10.concat(e10.afterTracksIds).map(String)) ? a2 : [];
        },
        get isDragAndDropEnabled() {
          let {
            experiments: t10,
            sonataState: { isVibeContext: a2 }
          } = (0, l.Zn)(e10);
          return t10.checkExperiment(n.zal.WebNextPlayQueueDnD, "on") && !a2;
        }
      })).actions((e10) => {
        let t10 = (t11, a3) => {
          let i2 = t11[a3];
          if (!i2 || (0, f.Re)(i2)) return null;
          let { entity: n2 } = i2, r2 = (0, I.pE)(n2);
          return !r2 || r2.isHiddenFromSonataQueue ? null : (e10.trackMap.has(r2.id) || e10.trackMap.set(r2.id, (0, l.wg)(r2)), a3);
        }, a2 = {
          setVisible() {
            e10.isVisible = true;
          },
          setInvisible() {
            e10.isVisible = false;
          },
          updateTracks(e11, t11, i2, n2) {
            a2.setCurrentTrackId(e11, t11), a2.setBeforeTracksIds(e11, i2), a2.setAfterTracksIds(e11, i2, n2), a2.setHiddenTrackIds(e11);
          },
          setCurrentTrackId(a3, i2) {
            e10.currentIndex = i2, t10(a3, i2);
          },
          setBeforeTracksIds(a3, i2) {
            let n2 = Math.max(0, e10.currentIndex - 125) - 1, r2 = [];
            for (let l2 = e10.currentIndex - 1; l2 > n2; l2--) {
              let e11 = i2[l2];
              if ("number" != typeof e11) break;
              let n3 = t10(a3, e11);
              null !== n3 && r2.unshift(n3);
            }
            e10.beforeTracksIds = (0, l.wg)(r2);
          },
          setAfterTracksIds(a3, i2, n2) {
            let r2 = n2 === N.K.Vibe ? 1 : 125, l2 = [];
            for (let n3 = e10.currentIndex + 1; n3 < i2.length && l2.length < r2; n3++) {
              let e11 = i2[n3];
              if ("number" != typeof e11) break;
              let r3 = t10(a3, e11);
              null !== r3 && l2.push(r3);
            }
            e10.afterTracksIds = l2;
          },
          setHiddenTrackIds(t11) {
            let a3 = [];
            for (let e11 = 0; e11 < t11.length; e11++) {
              let i2 = t11[e11];
              i2 && i2.entity.hidden && a3.push(e11);
            }
            e10.hiddenTrackIds = (0, l.wg)(a3);
          },
          reset() {
            e10.destroyItems([e10.beforeTracksIds, e10.hiddenTrackIds]), e10.afterTracksIds = [], e10.trackMap.clear();
          }
        };
        return a2;
      });
      var T = a(9348), P = a(68907), k = a(21365), E = a(54460);
      let j = (e10) => {
        if (!e10) return;
        let t10 = e10.split(":"), a2 = parseInt(t10[0] || "0", 10), i2 = parseFloat(t10[1] || "0");
        return a2 > 0 ? parseFloat((60 * a2 + i2).toFixed(2)) : i2;
      }, L = l.gK.model("SyncLyricsLine", { text: l.gK.string, fromSec: l.gK.number, toSec: l.gK.maybe(l.gK.number) }).views((e10) => ({
        get key() {
          return "".concat(e10.fromSec, ":").concat(e10.toSec);
        }
      })), w = l.gK.compose(
        l.gK.model("SyncLyrics", {
          isVisible: l.gK.optional(l.gK.boolean, false),
          lines: l.gK.maybeNull(l.gK.array(L)),
          major: l.gK.maybeNull(E.t$),
          writers: l.gK.maybeNull(l.gK.array(l.gK.string)),
          lyricId: l.gK.maybeNull(l.gK.number),
          externalLyricId: l.gK.maybeNull(l.gK.string),
          currentTrackId: l.gK.maybeNull(l.gK.union(l.gK.string, l.gK.number)),
          hasLyricsViewed: l.gK.optional(l.gK.boolean, false)
        }),
        A.XT
      ).views((e10) => ({
        get startSec() {
          var t10;
          let a2 = null == (t10 = e10.lines) ? void 0 : t10.at(0);
          return null == a2 ? void 0 : a2.fromSec;
        },
        get endSec() {
          var a2;
          let t10 = null == (a2 = e10.lines) ? void 0 : a2.at(-1);
          return null == t10 ? void 0 : t10.toSec;
        },
        get hasWriters() {
          var i2;
          return !!(e10.writers && (null == (i2 = e10.writers) ? void 0 : i2.length) > 0);
        },
        get hasInvalidLyrics() {
          var n2;
          return !!(e10.isResolved && (null == (n2 = e10.lines) ? void 0 : n2.length) === 0);
        }
      })).actions((e10) => {
        let t10 = {
          setVisible() {
            e10.isVisible = true;
          },
          setInvisible() {
            e10.isVisible = false;
          },
          getActiveLineIndex: (t11) => {
            if (e10.startSec && t11 < e10.startSec || e10.endSec && t11 > e10.endSec) return null;
            let a2 = (e10.lines || []).findIndex(
              (e11) => void 0 === e11.toSec ? t11 >= e11.fromSec : !!(t11 >= e11.fromSec) && !!(e11.toSec >= t11)
            );
            return a2 >= 0 ? a2 : null;
          },
          getData: (0, l.L3)(function* (a2) {
            let { tracksResource: i2, modelActionsLogger: r2 } = (0, l._$)(e10);
            if (a2)
              try {
                e10.loadingState = n.GuX.PENDING;
                let {
                  downloadUrl: r3,
                  major: o2,
                  externalLyricId: s2,
                  lyricId: c2,
                  writers: d2
                } = yield i2.getLyrics((0, k.h3)(a2, P.o.LRC));
                e10.major = (0, E.LT)(o2), e10.externalLyricId = s2, e10.lyricId = c2, e10.writers = (0, l.wg)(d2), e10.currentTrackId = a2, e10.hasLyricsViewed = false, yield t10.downloadSyncLyrics(r3), e10.loadingState = n.GuX.RESOLVE;
              } catch (t11) {
                e10.loadingState = n.GuX.REJECT, r2.error(t11);
              }
          }),
          downloadSyncLyrics: (0, l.L3)(function* (t11) {
            let { prefixlessResource: a2 } = (0, l._$)(e10), i2 = yield a2.getLyricsText(t11);
            e10.lines = (0, l.wg)(
              ((e11) => {
                try {
                  return (((e12) => {
                    if ("string" != typeof e12) throw TypeError("expect first argument to be a string");
                    let t12 = e12.split("\n"), a3 = /\[(\d*:\d*\.?\d*)\]/, i3 = new RegExp(a3.source + /(.+)/.source), n2 = [], r2 = [], l2 = { scripts: [] };
                    for (let e13 = 0; e13 < t12.length; e13++) {
                      let a4 = t12[e13];
                      if (a4 && false === i3.test(a4)) n2.push(a4);
                      else break;
                    }
                    n2.reduce((e13, t13) => {
                      let a4 = t13.trim().slice(1, -1).split(": "), i4 = a4[0], n3 = a4[1];
                      return void 0 !== i4 && (e13[i4] = n3), e13;
                    }, l2), t12.splice(0, n2.length);
                    let o2 = new RegExp("".concat(i3.source, "|").concat(a3.source));
                    t12 = t12.filter((e13) => e13 && o2.test(e13));
                    for (let e13 = 0, n3 = t12.length; e13 < n3; e13++) {
                      let l3 = t12[e13], o3 = e13 + 1 < n3 ? t12[e13 + 1] : null;
                      if (l3) {
                        let e14 = i3.exec(l3), t13 = o3 ? a3.exec(o3) : null;
                        if (e14) {
                          let [, a4, i4] = e14, n4 = null == t13 ? void 0 : t13[1];
                          a4 && r2.push({ start: j(a4), text: i4 || "", end: j(n4) });
                        }
                      }
                    }
                    return l2.scripts = r2, l2;
                  })(e11).scripts || []).map((e12) => {
                    let { start: t12, end: a3, text: i3 } = e12;
                    return (0, l.wg)({ text: i3.trim(), fromSec: t12, toSec: a3 });
                  });
                } catch (e12) {
                  return [];
                }
              })(i2)
            );
          }),
          sendViews: (0, l.L3)(function* (t11) {
            let { contextId: a2, contextType: i2 } = t11, { lyricViewsResource: r2, modelActionsLogger: o2 } = (0, l._$)(e10);
            if (e10.loadingState === n.GuX.RESOLVE)
              try {
                if (!e10.major || !e10.lyricId || !e10.externalLyricId || !e10.currentTrackId) return;
                yield r2.sendViews({
                  lyricViews: [
                    {
                      id: (0, T.A)(),
                      trackId: e10.currentTrackId,
                      majorId: e10.major.id,
                      lyricId: e10.lyricId,
                      externalLyricId: e10.externalLyricId,
                      lyricFormat: P.o.LRC,
                      albumId: i2 === N.K.Album && a2 ? a2 : void 0,
                      playlistId: i2 === N.K.Playlist && a2 ? a2 : void 0
                    }
                  ]
                }), e10.hasLyricsViewed = true;
              } catch (e11) {
                o2.error(e11);
              }
          })
        };
        return t10;
      }), M = l.gK.model("FullscreenPlayer", {
        mode: l.gK.maybeNull(l.gK.enumeration(Object.values(C))),
        syncLyrics: w,
        playQueue: S,
        modal: A.qt
      }).views((e10) => ({
        get isSplitMode() {
          return this.isPlayQueueMode || this.isSyncLyricsMode;
        },
        get isSyncLyricsMode() {
          var t10;
          let { sonataState: a2 } = (0, l.Zn)(e10);
          return e10.mode === C.SYNC_LYRICS && !!(null == a2 || null == (t10 = a2.entityMeta) ? void 0 : t10.isSyncLyricsAvailable);
        },
        get isPlayQueueMode() {
          return e10.mode === C.PLAY_QUEUE;
        }
      })).actions((e10) => ({
        setMode(t10) {
          e10.mode = t10;
        },
        showFullscreenPlayerModal() {
          e10.syncLyrics.setInvisible(), e10.modal.open();
        },
        showSyncLyrics() {
          e10.mode = C.SYNC_LYRICS, e10.syncLyrics.setVisible(), e10.modal.isOpened || e10.modal.open();
        },
        hideSyncLyrics() {
          e10.mode = null, e10.syncLyrics.setInvisible();
        },
        showPlayQueue() {
          e10.mode = C.PLAY_QUEUE, e10.playQueue.setVisible(), e10.modal.isOpened || e10.modal.open();
        },
        hidePlayQueue() {
          e10.mode = null, e10.playQueue.setInvisible();
        },
        isModeActive: (t10) => e10.mode === t10,
        reset() {
          e10.mode = null;
        }
      })), B = l.gK.model("QualitySettings", { modal: A.qt });
      var O = a(43426), R = a(31500), D = a(5956), K = a(32692), U = a(62662), F = a(38117), z = a.n(F), V = a(95424), W = a(62443), G = a(25818), Y = a(8817);
      let Q = (0, u.createContext)({ difference: 0, isSingleTrackSwitch: false }), $ = () => (0, u.useContext)(Q);
      var q = a(13528), H = a.n(q), X = a(37706);
      let Z = (0, d.PA)((e10) => {
        let { children: t10 } = e10, {
          fullscreenPlayer: {
            playQueue: { itemsKeys: a2, isDragAndDropEnabled: i2 }
          }
        } = (0, n.Pjs)();
        return i2 ? (0, s.jsx)(X.gB, { items: a2, strategy: X._G, children: t10 }) : t10;
      });
      var J = a(27510), ee = a(78028), et = a.n(ee);
      let ea = (0, d.PA)(
        (0, u.forwardRef)((e10, t10) => {
          let { children: a2, "data-index": i2, className: n2, ...r2 } = e10, {
            isDragging: l2,
            listeners: o2,
            setNodeRef: d2,
            transform: m2,
            transition: _2,
            attributes: p2
          } = (0, X.gl)({ id: String(i2) }), v2 = (0, u.useCallback)(
            (e11) => {
              d2(e11), "function" == typeof t10 && t10(e11);
            },
            [t10, d2]
          ), h2 = { transition: _2, "--translate-y": m2 ? "".concat(Math.round(m2.y), "px") : void 0 };
          return (0, s.jsx)("div", {
            ref: v2,
            "data-index": i2,
            style: h2,
            ...r2,
            className: (0, c.$)(et().root, n2),
            children: (0, s.jsx)("div", {
              ref: t10,
              className: (0, c.$)(et().inner, { [et().dragging]: l2 }),
              ...o2,
              ...p2,
              role: "listitem",
              children: a2
            })
          });
        })
      ), ei = (e10) => {
        let { index: t10, isDragAndDropEnabled: a2, blockRef: i2, className: l2, isRemoveAvailable: o2 } = e10, c2 = (0, n.eGp)(), d2 = (0, u.useMemo)(() => {
          let e11 = null == c2 ? void 0 : c2.state.queueState.order.value.indexOf(t10);
          return "number" == typeof e11 ? [e11] : [];
        }, [t10, null == c2 ? void 0 : c2.state.queueState.order.value]), m2 = r(t10), _2 = null == m2 ? void 0 : m2.track, p2 = null == m2 ? void 0 : m2.playContextParams, v2 = (0, E.iQ)(null != _2 ? _2 : null, E.NM.HIDE, d2), h2 = (0, Y.c)(() => {
          v2(), (null == i2 ? void 0 : i2.current) && i2.current.focus();
        }), g2 = (0, J.L)(
          () => _2 && p2 ? (0, s.jsx)(k.Kt, {
            track: _2,
            playContextParams: p2,
            className: l2,
            withDNDBlock: a2,
            handleRemove: o2 ? h2 : void 0,
            withSecondaryColor: true
          }) : null
        );
        return g2 ? a2 ? (0, s.jsx)(ea, { "data-index": t10, children: g2 }) : g2 : null;
      };
      var en = a(89488), er = a.n(en), el = a(73633), eo = a(76866), es = a(70140), ec = a(63006), ed = a(15099), eu = a(14148), em = a(29064), e_ = a(66570), ep = a(41730), ev = a(64336);
      let eh = (e10) => !!(e10 && "object" == typeof e10 && ("playlistUuid" in e10 || "playlistTitle" in e10));
      var eg = (function(e10) {
        return e10.Artist = "artist", e10.Playlist = "playlist", e10.Album = "album", e10.Track = "track", e10;
      })({});
      let ex = () => {
        let { formatMessage: e10 } = (0, O.A)(), {
          experiments: t10,
          sonataState: { entityMeta: a2 },
          vibe: i2
        } = (0, n.Pjs)(), r2 = (0, n.eGp)(), l2 = null == r2 ? void 0 : r2.state.currentContext.value, o2 = null == l2 ? void 0 : l2.data.meta, c2 = null == r2 ? void 0 : r2.state.queueState.currentEntity.value, d2 = null == a2 ? void 0 : a2.mainArtist, _2 = null == a2 ? void 0 : a2.mainAlbum, p2 = null == a2 ? void 0 : a2.isPodcast, v2 = t10.checkExperiment(n.zal.WebNextUseWaveQueue, "on"), h2 = (function(e11) {
          let { isWaveQueueEnabled: t11 } = e11, a3 = (0, n.eGp)(), i3 = null == a3 ? void 0 : a3.state.queueState.currentEntity.value;
          return (0, u.useMemo)(
            () => t11 ? (function(e12) {
              if (!e12) return { title: void 0, type: void 0, sourceContextType: void 0 };
              let t12 = e12.data.sourceContextType;
              if ((0, e_.F)(e12)) {
                let a5 = e12.data.meta.title;
                if (a5) return { title: a5, type: N.K.Album, sourceContextType: t12 };
              }
              if ((0, ev.K)(e12)) {
                let a5 = e12.data.meta.title;
                if (a5) return { title: a5, type: N.K.Playlist, sourceContextType: t12 };
              }
              if ((0, ep.T)(e12)) {
                var a4;
                let i4 = null == (a4 = e12.data.meta.artist) ? void 0 : a4.name;
                if (i4) return { title: i4, type: N.K.Artist, sourceContextType: t12 };
              }
              return { title: void 0, type: void 0, sourceContextType: t12 };
            })(null == i3 ? void 0 : i3.sourceContext) : { title: void 0, type: void 0, sourceContextType: void 0 },
            [null == i3 ? void 0 : i3.sourceContext, t11]
          );
        })({ isWaveQueueEnabled: v2 }), g2 = (0, J.L)(() => {
          if (v2 && h2.type)
            return (function(e12) {
              let { sourceType: t11, sourceContext: a3 } = e12;
              if (a3)
                switch (t11) {
                  case N.K.Album: {
                    if (!(0, e_.F)(a3)) return;
                    let e13 = a3.data.meta.id;
                    if (!e13) return;
                    let { href: t12 } = (0, n.uvd)("/album/:albumId", { params: { albumId: String(e13) } });
                    return t12;
                  }
                  case N.K.Artist: {
                    if (!(0, ep.T)(a3)) return;
                    let e13 = a3.data.meta.id;
                    if (!e13) return;
                    let { href: t12 } = (0, n.uvd)("/artist/:artistId", { params: { artistId: String(e13) } });
                    return t12;
                  }
                  case N.K.Playlist: {
                    if (!(0, ev.K)(a3)) return;
                    let e13 = a3.data.meta.playlistUuid;
                    if (!e13) return;
                    let { href: t12 } = (0, n.uvd)("/playlists/:playlistUuid", { params: { playlistUuid: e13 } });
                    return t12;
                  }
                  default:
                    return;
                }
            })({ sourceType: h2.type, sourceContext: null == c2 ? void 0 : c2.sourceContext });
          switch (null == l2 ? void 0 : l2.data.type) {
            case N.K.Vibe:
              var e11;
              return ((e12, t11) => {
                var a3, i3;
                let r3 = (0, es.i)(t11) ? null == t11 ? void 0 : t11.data.parentContext : null, l3 = (0, es.i)(t11) ? null == t11 ? void 0 : t11.data.parentContextId : null;
                if (r3 || l3)
                  switch (e12) {
                    case eg.Artist: {
                      let { href: e13 } = (0, n.uvd)("/artist/:artistId", {
                        params: { artistId: (null != (a3 = null == r3 ? void 0 : r3.data.meta.id) ? a3 : l3) || "" }
                      });
                      return e13;
                    }
                    case eg.Playlist: {
                      let e13 = null == r3 ? void 0 : r3.data.meta, t12 = eh(e13) ? e13.playlistUuid : l3;
                      if (!t12) return;
                      let { href: a4 } = (0, n.uvd)("/playlists/:playlistUuid", {
                        params: { playlistUuid: String(t12) }
                      });
                      return a4;
                    }
                    case eg.Album: {
                      if (!(null == r3 ? void 0 : r3.data.meta.id) && !l3) return;
                      let { href: e13 } = (0, n.uvd)("/album/:albumId", {
                        params: { albumId: (null != (i3 = null == r3 ? void 0 : r3.data.meta.id) ? i3 : l3) || "" }
                      });
                      return e13;
                    }
                    case eg.Track: {
                      if (!l3) return;
                      if (String(l3).includes(":")) {
                        let [e14, t12] = String(l3).split(":"), { href: a4 } = (0, n.uvd)("/album/:albumId/track/:trackId", {
                          params: { albumId: e14 || "", trackId: t12 || "" }
                        });
                        return a4;
                      }
                      let { href: e13 } = (0, n.uvd)("/track/:trackId", { params: { trackId: l3 } });
                      return e13;
                    }
                    default:
                      return;
                  }
              })(null == i2 || null == (e11 = i2.meta) ? void 0 : e11.stationType, l2);
            case N.K.Artist: {
              if (!(null == d2 ? void 0 : d2.id)) return;
              let { href: e12 } = (0, n.uvd)("/artist/:artistId", { params: { artistId: d2.id } });
              return e12;
            }
            case N.K.Playlist: {
              if (!eh(o2)) return;
              let { href: e12 } = (0, n.uvd)("/playlists/:playlistUuid", {
                params: { playlistUuid: null == o2 ? void 0 : o2.playlistUuid }
              });
              return e12;
            }
            case N.K.Album: {
              if (!(null == _2 ? void 0 : _2.id)) return;
              let { href: e12 } = (0, n.uvd)("/album/:albumId", { params: { albumId: _2.id } });
              return e12;
            }
            default:
              return;
          }
        }), x2 = (0, J.L)(() => {
          var e11, t11, a3;
          if (v2 && h2.title) return h2.title;
          switch (null == l2 ? void 0 : l2.data.type) {
            case N.K.Vibe:
              return ((e12, t12) => t12 && e12 ? t12 : (0, s.jsx)(m.A, { id: "entity-names.my-vibe" }))(
                null == i2 || null == (e11 = i2.meta) ? void 0 : e11.stationType,
                null == i2 || null == (t11 = i2.meta) ? void 0 : t11.title
              );
            case N.K.Artist:
              return (null == (a3 = l2.data.meta.artist) ? void 0 : a3.name) || (null == d2 ? void 0 : d2.name);
            case N.K.Playlist:
              if (!eh(o2)) return;
              return null == o2 ? void 0 : o2.title;
            case N.K.Album:
              return null == _2 ? void 0 : _2.title;
            case N.K.Various:
              return (0, s.jsx)(m.A, { id: "play-queue.now-playing" });
            default:
              return (0, s.jsx)(m.A, { id: "entity-names.my-vibe" });
          }
        }), y2 = (0, J.L)(() => {
          if (v2 && h2.type) {
            let e11 = (function(e12) {
              let { sourceType: t11, sourceContext: a4, sourceContextType: i3 } = e12, n2 = (function(e13) {
                switch (e13) {
                  case em.h.SEARCH:
                    return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-search" });
                  case em.h.DOWNLOADED_TRACKS:
                    return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-downloads" });
                  case em.h.MUSIC_HISTORY:
                    return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-history" });
                  case em.h.MUSIC_HISTORY_SEARCH:
                    return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-history-search" });
                  case em.h.ARTIST_MY_COLLECTION:
                    return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-artist-collection" });
                  case em.h.ARTIST_FAMILIAR_FROM_WAVE:
                    return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-artist-wave" });
                  default:
                    return;
                }
              })(i3);
              if (n2) return n2;
              if (i3 === em.h.BASED_ON_ENTITY_BY_DEFAULT || void 0 === i3)
                switch (t11) {
                  case N.K.Album:
                    if ((0, e_.F)(a4) && a4.data.meta.type === ed._.PODCAST)
                      return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-podcast" });
                    return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-album" });
                  case N.K.Artist:
                    return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-artist-popular-tracks" });
                  case N.K.Playlist:
                    return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-playlist" });
                }
            })({
              sourceType: h2.type,
              sourceContext: null == c2 ? void 0 : c2.sourceContext,
              sourceContextType: h2.sourceContextType
            });
            if (e11) return e11;
          }
          switch (null == l2 ? void 0 : l2.data.type) {
            case N.K.Vibe:
              var a3, r3;
              if (!t10.checkExperiment(n.zal.WebNextVibeDescription, "on") || void 0 === (null == i2 || null == (a3 = i2.meta) ? void 0 : a3.description))
                return ((e11, t11) => {
                  let a4 = (0, es.i)(t11) ? null == t11 ? void 0 : t11.data.parentContext : null;
                  switch (e11) {
                    case eg.Artist:
                      return (0, s.jsx)(m.A, { id: "play-queue.now-playing-my-wave-by-artist" });
                    case eg.Playlist:
                      return (0, s.jsx)(m.A, { id: "play-queue.now-playing-my-wave-by-playlist" });
                    case eg.Album:
                      if ((null == a4 ? void 0 : a4.data.type) === ed._.PODCAST)
                        return (0, s.jsx)(m.A, { id: "play-queue.now-playing-my-wave-by-podcast" });
                      return (0, s.jsx)(m.A, { id: "play-queue.now-playing-my-wave-by-album" });
                    case eg.Track:
                      return (0, s.jsx)(m.A, { id: "play-queue.now-playing-my-wave-by-track" });
                    default:
                      return (0, s.jsx)(m.A, { id: "play-queue.now-playing" });
                  }
                })(null == i2 || null == (r3 = i2.meta) ? void 0 : r3.stationType, l2);
              if (null == i2 ? void 0 : i2.isMyVibe) return e10({ id: "play-queue.now-playing" });
              return e10(
                { id: "play-queue.now-playing-by-entity" },
                { entity: null == i2 ? void 0 : i2.meta.getDescription() }
              );
            case N.K.Artist:
              return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-artist-popular-tracks" });
            case N.K.Playlist:
              return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-playlist" });
            case N.K.Album:
              if (p2) return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-podcast" });
              return (0, s.jsx)(m.A, { id: "play-queue.now-playing-from-album" });
            default:
              return;
          }
        }), b2 = (0, J.L)(() => (0, ec.p)(l2) ? (0, s.jsx)(m.A, { id: "entity-names.my-vibe" }) : x2);
        return {
          url: g2,
          title: x2,
          subTitle: y2,
          vibeBlockTitle: b2,
          vibeBlockSubTitle: (0, J.L)(() => {
            switch (null == l2 ? void 0 : l2.data.type) {
              case N.K.Artist:
                return (0, s.jsx)(m.A, { id: "play-queue.my-wave-by-artist" });
              case N.K.Playlist:
                return (0, s.jsx)(m.A, { id: "play-queue.my-wave-by-playlist" });
              case N.K.Album:
                return (0, s.jsx)(m.A, { id: "play-queue.my-wave-by-album" });
              default:
                return;
            }
          }),
          vibeBlockAgent: (0, J.L)(() => {
            var e11, t11, a3;
            switch (null == l2 ? void 0 : l2.data.type) {
              case N.K.Album:
                return (0, eo.KU)({
                  animationUri: "",
                  cover: { uri: l2.data.meta.coverUri },
                  entity: { type: eu.h.ALBUM }
                });
              case N.K.Artist:
                return (0, eo.KU)({
                  animationUri: "",
                  cover: { uri: null == (t11 = l2.data.meta.artist) || null == (e11 = t11.cover) ? void 0 : e11.uri },
                  entity: { type: eu.h.ARTIST }
                });
              case N.K.Playlist:
                return (0, eo.KU)({
                  animationUri: "",
                  cover: { uri: null == (a3 = l2.data.meta.cover) ? void 0 : a3.uri },
                  entity: { type: eu.h.PLAYLIST }
                });
              case N.K.Various:
                return (0, eo.KU)({
                  animationUri: "",
                  cover: { uri: "avatars.mds.yandex.net/get-music-misc/2419084/img.686688add03ee35062c02822/%%" },
                  entity: { type: eu.h.TRACK }
                });
            }
          })
        };
      }, ey = { src: "/_next/static/media/vibeCover.c55d574d.png" };
      var eb = a(27319), eA = a.n(eb);
      let eC = (0, d.PA)(() => {
        let { experiments: e10 } = (0, n.Pjs)(), t10 = (0, n.eGp)(), { vibeBlockTitle: a2, vibeBlockSubTitle: i2, vibeBlockAgent: r2 } = ex(), l2 = (0, u.useCallback)(
          (e11) => {
            (0, el.P)(e11, eA().ripple), null == t10 || t10.moveForward();
          },
          [t10]
        ), o2 = (0, J.L)(
          () => e10.checkExperiment(n.zal.WebNextWaveAgentExperiment, "on") && r2 ? (0, s.jsx)(eo.nr, { agent: r2, shouldShowControl: false }) : (0, s.jsx)(p.Image, {
            src: ey.src,
            className: eA().vibeCover,
            fit: "cover",
            "aria-hidden": true,
            ...(0, R.Am)(R.e8.player.PLAY_QUEUE_VIBE_BLOCK_IMAGE)
          })
        );
        return (0, s.jsxs)("div", {
          className: eA().root,
          onClick: l2,
          ...(0, R.Am)(R.e8.player.PLAY_QUEUE_VIBE_BLOCK),
          children: [
            o2,
            (0, s.jsxs)("div", {
              children: [
                (0, s.jsx)(v.Caption, {
                  variant: "div",
                  size: "m",
                  className: eA().title,
                  ...(0, R.Am)(R.e8.player.PLAY_QUEUE_VIBE_BLOCK_TITLE),
                  children: a2
                }),
                (0, s.jsx)(v.Caption, {
                  variant: "div",
                  size: "m",
                  className: eA().vibeTitle,
                  ...(0, R.Am)(R.e8.player.PLAY_QUEUE_VIBE_BLOCK_VIBE_TITLE),
                  children: i2
                })
              ]
            })
          ]
        });
      }), eN = (0, d.PA)(() => {
        let {
          fullscreenPlayer: {
            playQueue: { afterTracksIds: e10, isVibeBlockShowed: t10, isDragAndDropEnabled: a2, currentIndex: i2 }
          },
          sonataState: { isContextRepeatMode: r2, isVibeContext: l2 },
          experiments: o2
        } = (0, n.Pjs)(), d2 = (0, n.eGp)(), _2 = null == d2 ? void 0 : d2.state.queueState.order.value, p2 = o2.checkExperiment(n.zal.WebNextUseWaveQueue, "on"), h2 = !l2 || p2, { isMovingForward: g2, isMovingBackward: x2, difference: y2, isSingleTrackSwitch: b2 } = $(), A2 = i2 - y2, C2 = (0, u.useId)(), N2 = (0, u.useRef)(null);
        return r2 && 0 === e10.length ? (0, s.jsx)("div", { className: er().root, ...(0, R.Am)(R.e8.player.PLAY_QUEUE_AFTER_PLAYING_BLOCK) }) : (0, s.jsxs)("div", {
          className: er().root,
          ...(0, R.Am)(R.e8.player.PLAY_QUEUE_AFTER_PLAYING_BLOCK),
          children: [
            (0, s.jsx)(v.Caption, {
              variant: "div",
              size: "m",
              className: (0, c.$)(er().title, { [er().title_withDnD]: a2 }),
              ...(0, R.Am)(R.e8.player.PLAY_QUEUE_AFTER_PLAYING_BLOCK_TITLE),
              children: (0, s.jsx)(m.A, { id: "play-queue.next-in" })
            }),
            (0, s.jsx)(Z, {
              children: (0, s.jsxs)("div", {
                tabIndex: 0,
                ref: N2,
                className: (0, c.$)(er().animatedContent, {
                  [er().animatedContent_moveToTop]: g2,
                  [er().animatedContent_moveFromTop]: x2 && !b2,
                  [er().animatedContent_moveFromTopSingleTrack]: x2 && b2
                }),
                children: [
                  e10.map(
                    (e11) => (null == _2 ? void 0 : _2[A2]) === e11 ? (0, s.jsx)(
                      "div",
                      {
                        className: er().prevTrack,
                        children: (0, s.jsx)(
                          ei,
                          { index: e11, isDragAndDropEnabled: a2, isRemoveAvailable: h2 },
                          e11
                        )
                      },
                      C2
                    ) : (0, s.jsx)(
                      ei,
                      { index: e11, isDragAndDropEnabled: a2, blockRef: N2, isRemoveAvailable: h2 },
                      e11
                    )
                  ),
                  t10 && (0, s.jsx)(eC, {})
                ]
              })
            })
          ]
        });
      });
      var ef = a(25358), eI = a.n(ef);
      let eS = (0, d.PA)((e10) => {
        let { forwardRef: t10, scrollToNowPlayingBlock: a2 } = e10, {
          fullscreenPlayer: {
            playQueue: { beforeTracksIds: i2, isDragAndDropEnabled: r2, currentIndex: l2 }
          },
          sonataState: { isVibeContext: o2 },
          experiments: d2
        } = (0, n.Pjs)(), m2 = (0, n.eGp)(), _2 = null == m2 ? void 0 : m2.state.queueState.order.value, p2 = d2.checkExperiment(n.zal.WebNextUseWaveQueue, "on"), v2 = !o2 || p2;
        (0, u.useEffect)(() => {
          a2();
          let e11 = new ResizeObserver(() => a2());
          return "function" != typeof t10 && (null == t10 ? void 0 : t10.current) && e11.observe(t10.current), () => {
            e11.disconnect();
          };
        }, [t10, a2]);
        let { isMovingForward: h2, isMovingBackward: g2, difference: x2, isSingleTrackSwitch: y2 } = $(), b2 = l2 - x2, A2 = (0, u.useId)();
        return (0, s.jsx)("div", {
          className: eI().root,
          ref: t10,
          children: (0, s.jsx)(Z, {
            children: (0, s.jsx)("div", {
              className: (0, c.$)(eI().animatedContent, {
                [eI().animatedContent_moveToBottom]: g2,
                [eI().animatedContent_moveFromBottom]: h2 && !y2,
                [eI().animatedContent_moveFromBottomSingleTrack]: h2 && y2
              }),
              ...(0, R.Am)(R.e8.player.PLAY_QUEUE_BEFORE_PLAYING_BLOCK),
              children: null == i2 ? void 0 : i2.map(
                (e11) => (null == _2 ? void 0 : _2[b2]) === e11 ? (0, s.jsx)(
                  "div",
                  {
                    className: eI().prevTrack,
                    children: (0, s.jsx)(
                      ei,
                      { index: e11, isDragAndDropEnabled: r2, isRemoveAvailable: v2 },
                      e11
                    )
                  },
                  A2
                ) : (0, s.jsx)(ei, { index: e11, isDragAndDropEnabled: r2, isRemoveAvailable: v2 }, e11)
              )
            })
          })
        });
      }), eT = (0, u.forwardRef)((e10, t10) => (0, s.jsx)(eS, { forwardRef: t10, ...e10 }));
      var eP = a(95296), ek = a(19713), eE = a(92803), ej = a(91724), eL = a.n(ej);
      let ew = (e10) => {
        let { index: t10 } = e10, a2 = r(t10), i2 = null == a2 ? void 0 : a2.track, n2 = null == a2 ? void 0 : a2.playContextParams;
        return i2 && n2 ? (0, s.jsx)("div", {
          className: eL().root,
          children: (0, s.jsx)(k.Kt, {
            track: i2,
            playContextParams: n2,
            draggingClassName: eL().dots,
            className: eL().noHoverItem,
            withDNDBlock: true,
            isDragging: true,
            withSecondaryColor: true
          })
        }) : null;
      }, eM = (0, d.PA)((e10) => {
        let { children: t10 } = e10, {
          fullscreenPlayer: {
            playQueue: { isDragAndDropEnabled: a2 }
          }
        } = (0, n.Pjs)(), { activeId: i2, handleDragStart: r2, handleDragCancel: l2, sensors: o2 } = (0, n.YcA)(), c2 = (0, u.useCallback)((e11) => {
          let { active: t11, over: a3 } = e11;
          if (!t11.id || !(null == a3 ? void 0 : a3.id)) return;
        }, []), d2 = (0, u.useMemo)(() => {
          if (i2)
            return (0, eE.createPortal)(
              (0, s.jsx)(eP.Hd, { dropAnimation: { duration: 0 }, children: (0, s.jsx)(ew, { index: Number(i2) }) }),
              window.document.body
            );
        }, [i2]);
        return a2 ? (0, s.jsxs)(eP.Mp, {
          sensors: o2,
          collisionDetection: eP.fp,
          onDragStart: r2,
          onDragEnd: c2,
          onDragCancel: l2,
          modifiers: [ek.FN],
          children: [t10, d2]
        }) : t10;
      });
      var eB = a(882), eO = a.n(eB);
      let eR = (0, d.PA)(() => {
        let {
          fullscreenPlayer: {
            modal: e10,
            playQueue: { isDragAndDropEnabled: t10 }
          },
          sonataState: { isContextRepeatMode: a2, isOneRepeatMode: i2, shuffle: r2 }
        } = (0, n.Pjs)(), { formatMessage: l2 } = (0, O.A)(), { url: o2, title: d2, subTitle: m2 } = ex(), _2 = (0, n.Cz$)({ onClick: e10.close }), p2 = (0, u.useMemo)(() => {
          let e11 = o2 ? {} : (0, R.Am)(R.e8.player.PLAY_QUEUE_NOW_PLAYING_BLOCK_TITLE), t11 = (0, s.jsx)(v.Heading, {
            variant: "h2",
            size: "m",
            weight: "bold",
            lineClamp: 1,
            className: (0, c.$)(eO().heading, { [eO().heading_withOffset]: !m2 }),
            ...e11,
            children: d2
          });
          return o2 ? (0, s.jsx)(h.N_, {
            className: eO().title,
            containerClassName: eO().linkContainer,
            textClassName: eO().linkText,
            icon: (0, s.jsx)(D.Icon, { className: eO().titleIcon, size: "xs", variant: "arrowRight" }),
            iconPosition: "right",
            href: o2,
            onClick: _2,
            ...(0, R.Am)(R.e8.player.PLAY_QUEUE_NOW_PLAYING_BLOCK_TITLE),
            children: t11
          }) : t11;
        }, [_2, m2, d2, o2]), g2 = (0, J.L)(
          () => a2 ? l2({ id: "play-queue.repeat-context" }) : i2 ? l2({ id: "play-queue.repeat-one" }) : r2 ? l2({ id: "play-queue.shuffle" }) : null
        );
        return (0, s.jsxs)("div", {
          className: (0, c.$)(eO().root, { [eO().root_withDnD]: t10 }),
          children: [
            (0, s.jsx)(v.Caption, {
              variant: "div",
              size: "m",
              className: eO().subTitle,
              ...(0, R.Am)(R.e8.player.PLAY_QUEUE_NOW_PLAYING_BLOCK_SUBTITLE),
              children: m2
            }),
            p2,
            (0, s.jsx)(v.Caption, {
              variant: "div",
              size: "m",
              className: eO().modeTitle,
              ...(0, R.Am)(R.e8.player.PLAY_QUEUE_NOW_PLAYING_BLOCK_MODE_TITLE),
              children: g2
            })
          ]
        });
      });
      var eD = a(71176), eK = a.n(eD);
      let eU = (0, d.PA)(() => {
        var e10, t10;
        let { from: a2 } = (0, n.fyy)(), {
          fullscreenPlayer: {
            playQueue: { currentIndex: i2, isDragAndDropEnabled: r2 }
          },
          sonataState: { entityMeta: l2 }
        } = (0, n.Pjs)(), { isMovingForward: o2, isMovingBackward: d2 } = $(), u2 = (0, n.eGp)(), m2 = null == u2 || null == (t10 = u2.state.currentContext) || null == (e10 = t10.value) ? void 0 : e10.data;
        if (!m2 || !l2) return null;
        let _2 = { contextData: { ...m2, from: a2 }, queueParams: { index: i2, entityId: l2.id } };
        return (0, s.jsxs)("div", {
          className: eK().root,
          ...(0, R.Am)(R.e8.player.PLAY_QUEUE_NOW_PLAYING_BLOCK),
          children: [
            (0, s.jsx)(eR, {}),
            (0, s.jsx)(k.Kt, {
              track: l2,
              playContextParams: _2,
              className: (0, c.$)(eK().track, eK().important, {
                [eK().track_withDnD]: r2,
                [eK().track_moveFromTop]: d2,
                [eK().track_moveFromBottom]: o2
              }),
              withSecondaryColor: true
            })
          ]
        });
      }), eF = () => {
        let { style: e10, contextValue: t10 } = (() => {
          var e11;
          let {
            fullscreenPlayer: {
              playQueue: { updateTracks: t11, hiddenTrackIds: a3 }
            }
          } = (0, n.Pjs)(), i3 = (0, n.eGp)(), [r3, l3] = (0, u.useState)(), o3 = (0, u.useRef)(void 0), s2 = (0, u.useRef)(void 0), c3 = (0, u.useRef)(void 0), { state: d2, handleDebouncedToggle: m2 } = (0, V.F)({ delay: 600, throttleTimeout: 600 }), { state: _2, handleDebouncedToggle: p2 } = (0, V.F)({ delay: 600, throttleTimeout: 600 }), v2 = (0, Y.c)(() => {
            var e12;
            let a4 = null == i3 ? void 0 : i3.state.queueState.entityList.value, n2 = null == i3 ? void 0 : i3.state.queueState.index.value, r4 = null == i3 ? void 0 : i3.state.queueState.order.value, l4 = null == i3 || null == (e12 = i3.state.currentContext.value) ? void 0 : e12.data.type;
            a4 && "number" == typeof n2 && r4 && l4 && t11(a4, n2, r4, l4);
          }), h2 = (0, Y.c)(() => {
            var e12;
            let t12 = null == i3 ? void 0 : i3.state.queueState.index.value, n2 = null == i3 || null == (e12 = i3.state.currentContext.value) ? void 0 : e12.data.type, r4 = o3.current;
            if ("number" == typeof t12 && "number" == typeof r4) {
              let e13 = a3.reduce((e14, t13) => t13 < r4 ? e14 + 1 : e14 - 1, 0), i4 = t12 - r4;
              c3.current = i4;
              let o4 = n2 !== s2.current, d3 = 1 === Math.abs(i4) ? i4 : i4 + e13;
              i4 > 0 || o4 ? (m2(), l3(o4 ? 1 : d3)) : i4 < 0 && (p2(), l3(d3));
            }
            o3.current = t12, s2.current = n2;
          });
          (0, u.useEffect)(() => {
            let e12 = null == i3 ? void 0 : i3.state.queueState.index.onChange(() => {
              v2(), h2();
            });
            return () => {
              null == e12 || e12();
            };
          }, [h2, v2, null == i3 ? void 0 : i3.state.queueState.index]), (0, u.useEffect)(() => {
            let e12 = null == i3 ? void 0 : i3.state.queueState.shuffle.onChange(v2), t12 = null == i3 ? void 0 : i3.state.queueState.entityList.onChange(v2), a4 = null == i3 ? void 0 : i3.state.queueState.order.onChange(v2);
            return () => {
              null == e12 || e12(), null == t12 || t12(), null == a4 || a4();
            };
          }, [
            v2,
            null == i3 ? void 0 : i3.state.queueState.entityList,
            null == i3 ? void 0 : i3.state.queueState.index,
            null == i3 ? void 0 : i3.state.queueState.order,
            null == i3 ? void 0 : i3.state.queueState.shuffle
          ]);
          let g2 = (0, u.useMemo)(() => {
            let e12 = 56 * (r3 || 1);
            return {
              "--play-queue-transition-duration-s": "".concat(0.6, "s"),
              "--now-playing-title-height-px": "".concat(90, "px"),
              "--next-in-title-height-px": "".concat(52, "px"),
              "--track-height-px": "".concat(56, "px"),
              "--move-to-top-start-position": "".concat(e12, "px"),
              "--move-from-top-start-position": "".concat(e12 - 142, "px"),
              "--move-to-bottom-start-position": "".concat(e12, "px"),
              "--move-from-bottom-start-position": "".concat(e12 + 52 + 90, "px"),
              "--move-from-top-now-playing-block-start-position": "".concat(e12 - 90, "px"),
              "--move-from-bottom-now-playing-block-start-position": "".concat(e12 + 52, "px")
            };
          }, [r3]), x2 = 1 === Math.abs(null != r3 ? r3 : 0);
          return {
            style: g2,
            contextValue: {
              isMovingForward: d2,
              isMovingBackward: _2,
              difference: null != (e11 = c3.current) ? e11 : 0,
              isSingleTrackSwitch: x2
            }
          };
        })(), a2 = (0, u.useRef)(null), i2 = (0, u.useRef)(null), { state: r2, handleDebouncedToggle: l2, reset: o2 } = (0, V.F)({ delay: 1e4, throttleTimeout: 2e3 }), c2 = (0, u.useCallback)(function() {
          let e11 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "instant";
          if (i2.current && a2.current) {
            let t11 = i2.current.clientHeight;
            a2.current.scrollTo({ top: t11, behavior: e11 });
          }
        }, []);
        return (0, u.useEffect)(() => {
          r2 || (c2("smooth"), o2());
        }, [r2, o2, c2]), (0, u.useEffect)(() => {
          let e11 = a2.current;
          return null == e11 || e11.addEventListener("scroll", l2), () => {
            null == e11 || e11.removeEventListener("scroll", l2);
          };
        }, [l2]), (0, s.jsx)(eM, {
          children: (0, s.jsx)(Q.Provider, {
            value: t10,
            children: (0, s.jsx)("div", {
              className: H().root,
              style: e10,
              ...(0, R.Am)(R.e8.player.PLAY_QUEUE),
              children: (0, s.jsx)("div", {
                className: H().content,
                ref: a2,
                children: (0, s.jsxs)("div", {
                  className: H().scrollContent,
                  children: [
                    (0, s.jsx)(eT, { ref: i2, scrollToNowPlayingBlock: c2 }),
                    (0, s.jsx)(eU, {}),
                    (0, s.jsx)(eN, {})
                  ]
                })
              })
            })
          })
        });
      }, ez = (0, u.createContext)({});
      var eV = a(5128), eW = a.n(eV), eG = a(68326), eY = a.n(eG);
      let eQ = (0, d.PA)((e10) => {
        let { className: t10, icon: a2 } = e10, { sonataState: i2 } = (0, n.Pjs)(), r2 = (0, u.useCallback)(
          (e11) => {
            let t11 = {
              animationDelay: "".concat((e11 + 1) * 0.275, "s"),
              animationDuration: "".concat(1.1, "s, ").concat(1.1, "s")
            };
            return a2 ? (0, u.cloneElement)(a2, {
              className: (0, c.$)(eY().element, eY().element_withIcon, { [eY().element_paused]: i2.isPaused }),
              key: e11,
              style: t11
            }) : (0, s.jsx)(
              "div",
              {
                className: (0, c.$)(eY().element, eY().element_withDefaultElement, {
                  [eY().element_paused]: i2.isPaused
                }),
                style: t11
              },
              e11
            );
          },
          [a2, i2]
        );
        return (0, s.jsx)("div", {
          className: (0, c.$)(eY().root, t10),
          children: Array.from({ length: 4 }, (e11, t11) => r2(t11))
        });
      });
      var e$ = a(91657), eq = a(36553), eH = (function(e10) {
        return e10.INTRO = "intro", e10.PREPARE = "prepare", e10.PLAYING = "playing", e10.OUTRO = "outro", e10;
      })({}), eX = a(25886), eZ = a.n(eX);
      let eJ = (0, d.PA)(() => {
        var e10, t10, a2;
        let { formatMessage: i2 } = (0, O.A)(), {
          fullscreenPlayer: { syncLyrics: r2 }
        } = (0, n.Pjs)();
        return (0, s.jsxs)("footer", {
          className: eZ().root,
          children: [
            r2.hasWriters && (0, s.jsx)(v.Caption, {
              className: eZ().writers,
              variant: "div",
              size: "l",
              weight: "medium",
              children: i2(
                { id: "entity-names.authors" },
                { authors: null == (e10 = r2.writers) ? void 0 : e10.join(", ") }
              )
            }),
            (null == (t10 = r2.major) ? void 0 : t10.prettyName) && (0, s.jsx)(v.Caption, {
              className: eZ().major,
              variant: "div",
              size: "l",
              weight: "medium",
              children: i2({ id: "entity-names.source" }, { source: null == (a2 = r2.major) ? void 0 : a2.prettyName })
            })
          ]
        });
      });
      var e0 = a(95744), e1 = a.n(e0);
      let e2 = (e10) => {
        let { className: t10, text: a2 } = e10;
        return (0, s.jsx)("span", { className: (0, c.$)(e1().root, t10), children: a2 });
      };
      var e8 = a(47840), e3 = a.n(e8);
      let e4 = (0, d.PA)((e10) => {
        var t10, a2;
        let { state: i2, progressPosition: r2, shouldShowScrolledLyrics: l2, setProgressPosition: o2 } = e10, d2 = (0, n.eGp)(), m2 = (0, eq.Mn)(), {
          fullscreenPlayer: { syncLyrics: _2 }
        } = (0, n.Pjs)(), p2 = (0, u.useCallback)(
          (e11) => (t11) => {
            l2 && (t11.stopPropagation(), o2(e11 + 0.01), null == d2 || d2.setProgress(e11 + 0.01).catch(() => {
              o2(r2);
            }));
          },
          [r2, o2, l2, d2]
        ), v2 = _2.getActiveLineIndex(r2);
        return ((e11) => {
          let t11 = (0, u.useRef)(0), {
            fullscreenPlayer: { syncLyrics: a3 },
            sonataState: { contextId: i3, contextType: r3 }
          } = (0, n.Pjs)();
          (0, u.useEffect)(() => {
            !a3.hasLyricsViewed && null !== e11 && "visible" === document.visibilityState && (t11.current++, t11.current >= 2 && a3.sendViews({ contextId: i3, contextType: r3 }));
          }, [e11, i3, r3, a3]);
        })(v2), (0, u.useEffect)(() => {
          if (!l2) {
            if ((i2 === eH.INTRO || i2 === eH.PREPARE) && m2.slideTo(0), i2 === eH.OUTRO) {
              var e11;
              m2.slideTo(Number(null == (e11 = _2.lines) ? void 0 : e11.length));
            }
            null !== v2 && m2.slideTo(v2 + 1);
          }
        }, [v2, l2, i2, m2, null == (t10 = _2.lines) ? void 0 : t10.length]), null == (a2 = _2.lines) ? void 0 : a2.map((e11, t11) => {
          var a3;
          return (0, s.jsx)(
            eq.qr,
            {
              onClickCapture: p2(e11.fromSec),
              className: (0, c.$)(e3().line, {
                [e3().line_last]: t11 === Number(null == (a3 = _2.lines) ? void 0 : a3.length) - 1 && !l2,
                [e3().line_active]: t11 === v2 && !l2
              }),
              ...(0, R.Am)(R.e8.player.SYNC_LYRICS_LINE),
              children: (0, s.jsx)(e2, { text: e11.text })
            },
            e11.key
          );
        });
      });
      e4.displayName = "SwiperSlide";
      let e5 = { forceToAxis: true }, e6 = (0, d.PA)(() => {
        let {
          fullscreenPlayer: { syncLyrics: e10 },
          settings: { isMobile: t10 }
        } = (0, n.Pjs)(), { progressPosition: a2, setProgressPosition: i2 } = (() => {
          var e11;
          let t11 = (0, n.eGp)(), [a3, i3] = (0, u.useState)(
            null != (e11 = null == t11 ? void 0 : t11.state.playerState.progress.value.position) ? e11 : 0
          ), r3 = (0, u.useCallback)((e12) => {
            i3(e12);
          }, []);
          return (0, u.useEffect)(() => {
            let e12 = null == t11 ? void 0 : t11.state.playerState.progress.onChange(() => {
              i3(t11.state.playerState.progress.value.position);
            });
            return () => {
              null == e12 || e12();
            };
          }, [t11]), { progressPosition: a3, setProgressPosition: r3 };
        })(), { state: r2 } = ((e11) => {
          let { position: t11 } = e11, {
            fullscreenPlayer: { syncLyrics: a3 }
          } = (0, n.Pjs)();
          return {
            state: (0, u.useMemo)(() => {
              let { startSec: e12, endSec: i3 } = a3;
              return e12 && e12 >= 3 && e12 - t11 > 0 && e12 - t11 <= 3 ? eH.PREPARE : e12 && e12 > t11 ? eH.INTRO : i3 && t11 > i3 ? eH.OUTRO : eH.PLAYING;
            }, [t11, a3])
          };
        })({ position: a2 }), { scrollerClassName: l2, footerClassName: o2, counterClassName: d2 } = (0, u.useContext)(ez), { state: m2, handleDebouncedToggle: _2, reset: p2 } = (0, V.F)({ delay: 3e3, throttleTimeout: 300 }), { state: v2, handleDebouncedToggle: h2, reset: g2 } = (0, V.F)({ delay: 3e3, throttleTimeout: 300 }), x2 = (0, u.useCallback)(() => {
          v2 || _2();
        }, [_2, v2]), y2 = (0, u.useCallback)(() => {
          m2 && p2(), h2();
        }, [h2, p2, m2]), b2 = (0, u.useCallback)(
          (e11) => {
            switch (e11.code) {
              case n.Y_O.KEY_L:
              case n.Y_O.KEY_J:
              case n.Y_O.ARROW_LEFT:
              case n.Y_O.ARROW_RIGHT:
                _2();
            }
          },
          [_2]
        ), A2 = (0, u.useMemo)(() => r2 === eH.PREPARE ? Math.ceil(Number(e10.startSec) - a2) : null, [a2, r2, e10.startSec]), C2 = (0, u.useMemo)(
          () => r2 === eH.PREPARE ? (0, s.jsx)(e2, { className: e3().counterLine, text: A2 }) : r2 === eH.INTRO ? (0, s.jsx)(eQ, {}) : null,
          [A2, r2]
        );
        return ((e11) => {
          let { onSetProgressEventChange: t11 } = e11, a3 = (0, n.eGp)();
          (0, u.useEffect)(() => {
            let e12 = null == a3 ? void 0 : a3.state.playerState.event.onChange((e13) => {
              e13 === f.Iu.SET_PROGRESS && t11();
            });
            return () => {
              null == e12 || e12();
            };
          }, [t11, a3]);
        })({ onSetProgressEventChange: g2 }), (0, u.useEffect)(
          () => (window.addEventListener("keydown", b2), () => {
            window.removeEventListener("keydown", b2);
          }),
          [b2]
        ), (0, u.useEffect)(
          () => (window.addEventListener("mousemove", x2), () => {
            window.removeEventListener("mousemove", x2);
          }),
          [x2]
        ), (0, s.jsxs)(eq.RC, {
          className: (0, c.$)(
            e3().root,
            {
              [e3()["root_".concat(r2)]]: !v2,
              [e3().root_withVisibleUpperLyrics]: m2,
              [e3().root_withVisibleScrolledLyrics]: v2
            },
            l2
          ),
          modules: [e$.FJ, e$.U1],
          slidesPerView: "auto",
          spaceBetween: 32,
          direction: "vertical",
          mousewheel: e5,
          freeMode: true,
          onScroll: y2,
          onTouchMove: t10 ? y2 : void 0,
          allowTouchMove: t10,
          children: [
            (0, s.jsx)(eq.qr, { className: (0, c.$)(e3().counter, d2), children: C2 }),
            (0, s.jsx)(e4, { setProgressPosition: i2, shouldShowScrolledLyrics: v2, state: r2, progressPosition: a2 }),
            (0, s.jsx)(eq.qr, { className: o2, children: (0, s.jsx)(eJ, {}) })
          ]
        });
      }), e7 = (0, d.PA)((e10) => {
        let {
          className: t10,
          counterClassName: a2,
          footerClassName: i2,
          scrollerClassName: r2,
          contentClassName: l2,
          loaderClassName: o2
        } = e10, d2 = (0, u.useRef)(null), {
          sonataState: { entityMeta: m2 },
          fullscreenPlayer: { syncLyrics: _2, hideSyncLyrics: p2 }
        } = (0, n.Pjs)();
        (0, u.useEffect)(() => {
          _2.currentTrackId !== (null == m2 ? void 0 : m2.id) && (null == m2 ? void 0 : m2.isSyncLyricsAvailable) && _2.getData(null == m2 ? void 0 : m2.id);
        }, [null == m2 ? void 0 : m2.isSyncLyricsAvailable, null == m2 ? void 0 : m2.id, _2]);
        let v2 = (0, u.useMemo)(
          () => _2.isResolved ? (0, s.jsx)(e6, {}) : ((_2.isRejected || _2.hasInvalidLyrics) && p2(), (0, s.jsx)(eQ, { className: o2 })),
          [_2.isResolved, _2.isRejected, _2.hasInvalidLyrics, _2.setInvisible, o2]
        ), h2 = (0, u.useMemo)(() => ({ counterClassName: a2, scrollerClassName: r2, footerClassName: i2 }), [a2, i2, r2]);
        return (0, s.jsx)(ez.Provider, {
          value: h2,
          children: (0, s.jsx)("div", {
            ref: d2,
            className: (0, c.$)(eW().root, t10),
            children: (0, s.jsx)("div", {
              className: (0, c.$)(eW().content, l2),
              ...(0, R.Am)(R.e8.player.SYNC_LYRICS_CONTENT),
              children: v2
            })
          })
        });
      });
      var e9 = a(45427), te = a(39122), tt = a.n(te);
      let ta = (0, d.PA)((e10) => {
        let {
          className: t10,
          variant: a2 = "text",
          iconSize: i2,
          iconClassName: r2,
          withRipple: l2 = false,
          size: o2 = "s",
          forwardRef: d2,
          children: m2,
          color: p2,
          disabled: v2 = false
        } = e10, { formatMessage: h2 } = (0, O.A)(), {
          fullscreenPlayer: { isPlayQueueMode: g2, hidePlayQueue: x2, showPlayQueue: y2 }
        } = (0, n.Pjs)(), b2 = (0, u.useCallback)(() => g2 ? x2() : y2(), [x2, g2, y2]), {
          scaleAnimation: A2,
          unscaleAnimation: C2,
          handleAnimationEnd: N2,
          handleClick: f2
        } = (0, e9.C)({ shouldStartFromUnscale: g2, onClick: b2 });
        return (0, s.jsx)(_.$, {
          className: (0, c.$)(tt().root, { [tt().animation_scaled]: A2, [tt().animation_unscaled]: C2 }, t10),
          color: p2,
          onAnimationEnd: N2,
          withRipple: l2,
          variant: a2,
          size: o2,
          radius: "xxxl",
          "aria-label": h2({ id: "play-queue.title" }),
          "aria-pressed": g2,
          onClick: f2,
          icon: (0, s.jsx)(D.Icon, {
            size: i2,
            className: (0, c.$)(tt().icon, r2, { [tt().icon_active]: g2 }),
            variant: "playQueue"
          }),
          ref: d2,
          disabled: v2,
          ...(0, R.Am)(R.e8.player.FULLSCREEN_PLAYER_QUEUE_BUTTON),
          children: m2
        });
      }), ti = (0, u.forwardRef)((e10, t10) => (0, s.jsx)(ta, { forwardRef: t10, ...e10 }));
      var tn = a(50328), tr = a.n(tn);
      let tl = (0, d.PA)((e10) => {
        let {
          className: t10,
          variant: a2 = "text",
          iconSize: i2,
          iconClassName: r2,
          withRipple: l2 = false,
          size: o2 = "s",
          forwardRef: d2,
          children: m2,
          color: p2,
          disabled: v2 = false
        } = e10, { formatMessage: h2 } = (0, O.A)(), {
          fullscreenPlayer: { isSyncLyricsMode: g2, hideSyncLyrics: x2, showSyncLyrics: y2 }
        } = (0, n.Pjs)(), b2 = (0, u.useCallback)(() => g2 ? x2() : y2(), [x2, g2, y2]), {
          scaleAnimation: A2,
          unscaleAnimation: C2,
          handleAnimationEnd: N2,
          handleClick: f2
        } = (0, e9.C)({ shouldStartFromUnscale: g2, onClick: b2 }), I2 = "".concat(h2({ id: "interface-actions.open-sync-lyrics" }), " ").concat(h2({ id: "warning-messages.can-break-accessibility" }));
        return (0, s.jsx)(_.$, {
          className: (0, c.$)(tr().root, { [tr().animation_scaled]: A2, [tr().animation_unscaled]: C2 }, t10),
          color: p2,
          onAnimationEnd: N2,
          withRipple: l2,
          variant: a2,
          size: o2,
          radius: "xxxl",
          "aria-label": I2,
          "aria-pressed": g2,
          onClick: f2,
          icon: (0, s.jsx)(D.Icon, {
            size: i2,
            className: (0, c.$)(tr().icon, r2, { [tr().icon_active]: g2 }),
            variant: "syncLyrics"
          }),
          ref: d2,
          disabled: v2,
          ...(0, R.Am)(R.e8.player.PLAYERBAR_DESKTOP_SYNC_LYRICS_BUTTON),
          children: m2
        });
      }), to = (0, u.forwardRef)((e10, t10) => (0, s.jsx)(tl, { forwardRef: t10, ...e10 }));
      var ts = a(71372), tc = a.n(ts);
      let td = (0, d.PA)(() => {
        var e10;
        let [t10, a2] = (0, u.useState)(false), { sonataState: i2, user: r2 } = (0, n.Pjs)(), { entityMeta: l2 } = i2, { handleDebouncedToggle: o2 } = (0, V.F)({ delay: 1500, throttleTimeout: 300 }), d2 = i2.canSpeed && ((null == l2 ? void 0 : l2.isNonMusic) || (null == l2 || null == (e10 = l2.mainAlbum) ? void 0 : e10.isNonMusic)), m2 = (0, E.KX)(l2), _2 = (0, u.useCallback)((e11) => {
          e11.stopPropagation();
        }, []), p2 = (0, J.L)(() => {
          if ((null == l2 || !l2.isRemoved) && (null == l2 ? void 0 : l2.isAvailable))
            return (0, s.jsx)(k._Y, {
              dismissSettings: { bubbles: { escapeKey: false } },
              track: l2,
              open: t10,
              onOpenChange: a2,
              placement: "left",
              icon: (0, s.jsx)(D.Icon, { variant: "more", size: "m" }),
              className: (0, c.$)(tc().menuButton, { [tc().menuButton_active]: t10 }),
              wrapperClassName: tc().menuWrapper,
              onClick: _2,
              size: "l",
              ...(0, R.Am)(R.e8.player.FULLSCREEN_PLAYER_CONTEXT_MENU_BUTTON)
            });
        }), v2 = (0, u.useMemo)(() => {
          if (null == l2 ? void 0 : l2.isSyncLyricsAvailable)
            return (0, s.jsx)(to, {
              className: tc().syncLyricsButton,
              iconSize: "m",
              size: "l",
              variant: "default",
              color: "secondary",
              disabled: !r2.isAuthorized
            });
        }, [null == l2 ? void 0 : l2.isSyncLyricsAvailable, r2.isAuthorized]);
        return (0, u.useEffect)(
          () => (window.addEventListener("mousemove", o2), () => {
            window.removeEventListener("mousemove", o2);
          }),
          [o2]
        ), (0, s.jsxs)("div", {
          className: (0, c.$)(tc().root, { [tc().root_visible]: t10 }),
          children: [
            (0, s.jsx)(ti, {
              className: tc().playQueueButton,
              iconSize: "m",
              size: "l",
              variant: "default",
              color: "secondary",
              disabled: !r2.isAuthorized
            }),
            (0, s.jsx)(I.$u, { className: tc().sonataControls, isMobile: false, entityMeta: l2, isFullscreen: true }),
            p2,
            v2,
            (0, s.jsxs)("div", {
              className: tc().bottomRightButtonsWrapper,
              children: [
                d2 && (0, s.jsx)(h.ig, { className: tc().speedButton, size: "l", iconSize: "m", isIconCentered: true }),
                (0, s.jsx)(h.aQ, {
                  fallback: (0, s.jsx)(h.cy, {
                    className: tc().likeButton,
                    isLiked: null == l2 ? void 0 : l2.isLiked,
                    onClick: m2,
                    iconSize: "m",
                    size: "l",
                    variant: "default",
                    color: "secondary",
                    disabled: !r2.isAuthorized
                  })
                })
              ]
            })
          ]
        });
      });
      var tu = a(6971), tm = a(71416), t_ = a.n(tm);
      let tp = (e10) => {
        let { className: t10, children: a2, coverUri: i2 } = e10;
        return (0, s.jsxs)(tu.Paper, {
          radius: "m",
          className: (0, c.$)(t_().root, t10),
          ...(0, R.Am)(R.e8.player.FULLSCREEN_PLAYER_POSTER_CONTENT),
          children: [
            (0, s.jsx)(h.BW, { className: t_().cover, src: i2, size: 400, fit: "cover", withAvatarReplace: true }),
            a2
          ]
        });
      };
      var tv = a(86024), th = a.n(tv), tg = a(63664);
      let tx = {
        enter: th().additionalContent_enter,
        enterActive: th().additionalContent_enter_active,
        exit: th().additionalContent_exit,
        exitActive: th().additionalContent_exit_active,
        appear: th().additionalContent_enter,
        appearActive: th().additionalContent_enter_active
      }, ty = (e10) => {
        let { isModeActive: t10, shouldDisableInsetTransition: a2, children: i2 } = e10, n2 = (0, u.useRef)(null);
        return (0, s.jsx)(tg.A, {
          in: t10,
          nodeRef: n2,
          timeout: 800,
          unmountOnExit: true,
          appear: true,
          classNames: tx,
          children: (0, s.jsx)("div", {
            ref: n2,
            className: (0, c.$)(th().additionalContent, { [th().additionalContent_withDisabledInsetTransition]: a2 }),
            children: i2
          })
        });
      }, tb = (0, d.PA)(() => {
        var e10;
        let { state: t10, handleDebouncedToggle: a2 } = (0, V.F)({ delay: 150, throttleTimeout: 100 }), {
          sonataState: { entityMeta: i2 },
          fullscreenPlayer: r2
        } = (0, n.Pjs)(), { state: l2, toggleTrue: o2 } = (0, W.e)(false), d2 = (null == i2 ? void 0 : i2.isTrackPodcast) || (null == i2 || null == (e10 = i2.mainAlbum) ? void 0 : e10.isPodcast), m2 = null == i2 ? void 0 : i2.isTrackAudiobook, _2 = {
          [C.PLAY_QUEUE]: { component: (0, s.jsx)(eF, {}), isActive: r2.isPlayQueueMode },
          [C.SYNC_LYRICS]: {
            component: (0, s.jsx)(e7, {
              className: th().syncLyrics,
              loaderClassName: th().syncLyricsLoader,
              contentClassName: th().syncLyricsContent,
              scrollerClassName: th().syncLyricsScroller,
              counterClassName: th().syncLyricsCounter,
              footerClassName: th().syncLyricsFooter
            }),
            isActive: r2.isSyncLyricsMode
          }
        }, p2 = (0, u.useMemo)(
          () => i2 ? m2 ? (0, s.jsx)(k.ZS, {
            hasLineClamp: false,
            className: (0, c.$)(th().meta, { [th().meta_isSplitMode]: r2.isSplitMode }),
            titleContainerClassName: th().title,
            track: i2,
            withSecondaryColor: true,
            captionSize: "l",
            explicitSize: "xs",
            withAuthor: true,
            textClassName: (0, c.$)(th().nonMusicAuthors, th().ellipsis),
            withContextMenuArtists: true
          }) : d2 ? (0, s.jsx)(k.wo, {
            className: (0, c.$)(th().meta, { [th().meta_isSplitMode]: r2.isSplitMode }),
            titleContainerClassName: th().title,
            track: i2,
            withSecondaryColor: true,
            withDate: false,
            captionSize: "l",
            explicitSize: "xs",
            withPodcastName: true,
            textClassName: th().nonMusicAuthors
          }) : (0, s.jsx)(k.j7, {
            hasLineClamp: false,
            className: (0, c.$)(th().meta, { [th().meta_isSplitMode]: r2.isSplitMode }),
            titleContainerClassName: th().title,
            track: i2,
            withSecondaryColor: true,
            withAlbumLink: false,
            captionSize: "l",
            explicitSize: "xs",
            withAllArtistsTitle: true,
            artistsClassName: th().artists,
            textClassName: th().ellipsis,
            withContextMenuArtists: true
          }) : null,
          [i2, null == i2 ? void 0 : i2.id, d2, m2, r2.isSplitMode]
        );
        return (0, u.useEffect)(
          () => (window.addEventListener("resize", a2), () => {
            window.removeEventListener("resize", a2);
          }),
          [a2]
        ), (0, u.useEffect)(() => {
          r2.isSplitMode && o2();
        }, [r2.isSplitMode, r2.mode, o2]), (0, u.useEffect)(
          () => () => {
            r2.reset(), r2.playQueue.reset();
          },
          [r2]
        ), (0, s.jsxs)("div", {
          className: th().root,
          children: [
            (0, s.jsxs)("div", {
              className: (0, c.$)(th().fullscreenContent, {
                [th().fullscreenContent_withDisabledInsetTransition]: t10,
                [th().fullscreenContent_enter]: r2.isSplitMode,
                [th().fullscreenContent_leave]: !r2.isSplitMode && l2
              }),
              ...(0, R.Am)(R.e8.player.FULLSCREEN_PLAYER_FULLSCREEN_CONTENT),
              children: [
                (0, s.jsx)(tp, {
                  className: (0, c.$)(th().poster, th().important),
                  coverUri: null == i2 ? void 0 : i2.coverUri,
                  children: (0, s.jsx)(td, {})
                }),
                (0, s.jsxs)("div", {
                  className: th().info,
                  children: [
                    p2,
                    (0, s.jsx)(G.v, {
                      className: th().sliderContainer,
                      sliderClassName: th().slider,
                      disabled: !i2,
                      isMobile: false,
                      isFullscreen: r2.isSplitMode
                    })
                  ]
                })
              ]
            }),
            Object.entries(_2).map((e11) => {
              let [a3, { component: i3, isActive: n2 }] = e11;
              return (0, s.jsx)(ty, { isModeActive: n2, shouldDisableInsetTransition: t10, children: i3 }, a3);
            })
          ]
        });
      }), tA = (0, d.PA)(() => {
        let { formatMessage: e10 } = (0, O.A)(), { theme: t10 } = (0, n.DPo)(), {
          currentTrackInfo: { modal: a2 },
          sonataState: { entityMeta: i2 },
          fullscreenPlayer: r2,
          fullscreenVideoPlayer: l2,
          advert: o2
        } = (0, n.Pjs)(), d2 = (0, u.useMemo)(
          () => ({ "--player-average-color-background": (0, k.ye)(t10, null == i2 ? void 0 : i2.averageColor) }),
          [null == i2 ? void 0 : i2.averageColor, t10]
        );
        (0, u.useEffect)(() => {
          o2.isAdvertShown && r2.modal.close();
        }, [o2.isAdvertShown, r2.modal]);
        let m2 = !a2.isOpened && !l2.modal.isOpened;
        return (0, s.jsxs)(K.a, {
          className: (0, c.$)(z().root, z().important),
          open: r2.modal.isOpened,
          onOpenChange: m2 ? r2.modal.onOpenChange : void 0,
          onClose: r2.modal.close,
          size: "fullscreen",
          placement: "center",
          showHeader: false,
          style: d2,
          contentClassName: z().modalContent,
          closeOnOutsidePress: false,
          ...(0, R.Am)(R.e8.player.FULLSCREEN_PLAYER_MODAL),
          children: [
            (0, s.jsx)("header", {
              className: z().header,
              children: (0, s.jsx)(_.$, {
                className: z().closeButton,
                radius: "round",
                color: "secondary",
                size: "m",
                icon: (0, s.jsx)(D.Icon, { variant: "arrowDown", size: "xs" }),
                onClick: r2.modal.close,
                "aria-label": e10({ id: "interface-actions.close" }),
                ...(0, R.Am)(R.e8.player.FULLSCREEN_PLAYER_CLOSE_BUTTON)
              })
            }),
            (0, s.jsx)(tb, {}),
            (0, s.jsx)(U.Notification, {
              className: z().notification,
              enableMultiContainer: true,
              containerId: n.uQT.FULLSCREEN_INFO,
              position: "bottom-center"
            }),
            (0, s.jsx)(U.Notification, {
              className: z().notification,
              enableMultiContainer: true,
              containerId: n.uQT.FULLSCREEN_ERROR,
              position: "bottom-center"
            })
          ]
        });
      });
      var tC = a(21891), tN = a.n(tC), tf = a(30630), tI = a(61958), tS = a(39610), tT = a(40320), tP = a(43350), tk = a(62395);
      let tE = () => {
        let e10 = (0, tk.st)(), t10 = (0, n.UlF)(), { hash: a2 } = (0, tk.gf)(), { pageId: i2 } = (0, n.$au)();
        return (0, u.useCallback)(
          (r2, l2) => {
            if (!e10 || !i2 || !n.Wft[i2] || !a2) return;
            let o2 = {
              hash: a2,
              pageId: n.Wft[i2],
              propertyKey: "sound_quality",
              propertyValueNew: r2,
              propertyValueOld: l2
            }, s2 = (0, tP.Fx)({ params: o2, logger: t10, context: "useSendEventOnQualitySettingsChanged" });
            s2 && (0, tP.Bl)(e10.evgenInstance, s2);
          },
          [e10, a2, t10, i2]
        );
      };
      var tj = a(81904), tL = a.n(tj);
      let tw = (e10) => {
        let { closeToast: t10, onOpenQualitySettingsMenu: a2, message: i2, ariaLabel: n2, isMobile: r2 } = e10, { formatMessage: l2 } = (0, O.A)(), o2 = (0, u.useCallback)(() => {
          a2(), null == t10 || t10();
        }, [t10, a2]), c2 = (0, u.useMemo)(
          () => (0, s.jsxs)("div", {
            className: tL().message,
            children: [
              (0, s.jsx)(tS.q, { children: (0, s.jsx)("p", { role: "alert", "aria-label": n2 }) }),
              (0, s.jsx)(v.Caption, {
                variant: "div",
                size: "m",
                "aria-hidden": true,
                ...(0, R.Am)(R.e8.player.NOTIFICATION_CHANGE_QUALITY_TEXT),
                children: i2
              }),
              !r2 && (0, s.jsx)(_.$, {
                className: tL().changeButton,
                onClick: o2,
                variant: "text",
                withRipple: false,
                "aria-label": l2({ id: "interface-actions.change" }),
                children: (0, s.jsx)(v.Caption, {
                  variant: "div",
                  size: "m",
                  children: (0, s.jsx)(m.A, { id: "interface-actions.change" })
                })
              })
            ]
          }),
          [n2, l2, o2, i2, r2]
        );
        return (0, s.jsx)(h.$W, {
          closeToast: t10,
          cover: (0, s.jsx)(D.Icon, { className: tL().icon, size: "xs", variant: "settings" }),
          message: c2,
          coverRadius: "s"
        });
      };
      var tM = a(45944), tB = a.n(tM);
      let tO = [
        {
          type: tf.e.HIGH_QUALITY,
          text: (0, s.jsx)(m.A, { id: "player-actions.audio-quality-maximum" }),
          qualityMessageId: "player-actions.audio-quality-maximum"
        },
        {
          type: tf.e.BALANCED,
          text: (0, s.jsx)(m.A, { id: "player-actions.audio-quality-optimal" }),
          qualityMessageId: "player-actions.audio-quality-optimal"
        },
        {
          type: tf.e.EFFICIENT,
          text: (0, s.jsx)(m.A, { id: "player-actions.audio-quality-economical" }),
          qualityMessageId: "player-actions.audio-quality-economical"
        }
      ], tR = {
        [tf.e.HIGH_QUALITY]: (0, s.jsx)(m.A, { id: "player-actions.audio-quality-maximum-description" }),
        [tf.e.BALANCED]: (0, s.jsx)(m.A, { id: "player-actions.audio-quality-optimal-description" }),
        [tf.e.EFFICIENT]: (0, s.jsx)(m.A, { id: "player-actions.audio-quality-economical-description" })
      }, tD = (0, d.PA)((e10) => {
        let {
          onOpenChange: t10,
          open: a2,
          placement: i2,
          size: r2,
          referenceClassName: l2,
          icon: o2,
          referenceLabel: d2,
          disabled: p2
        } = e10;
        (0, n.NBO)(a2);
        let v2 = (0, u.useId)(), { formatMessage: g2 } = (0, O.A)(), { notify: x2 } = (0, n.lkh)(), y2 = (0, n.NFA)().get(n.ooW), {
          sonataState: b2,
          user: A2,
          settings: { isMobile: C2 },
          quality: N2
        } = (0, n.Pjs)(), f2 = (0, tT.Sq)(), I2 = (0, n.gQL)(), S2 = tE(), { state: T2, setState: P2 } = (0, W.e)(false), k2 = (0, u.useCallback)(() => {
          null == t10 || t10(true);
        }, [t10]), E2 = (0, u.useCallback)(
          (e11) => {
            S2(e11, b2.quality), b2.setQuality(e11), null == I2 || I2.setQuality(e11), y2.set(n.cYZ.YmPlayerQuality, e11, { expires: 365 });
          },
          [I2, b2, y2, S2]
        ), j2 = (0, u.useCallback)(
          (e11) => {
            let t11 = g2({ id: e11 }).toLowerCase();
            return {
              message: (0, s.jsx)(m.A, { id: "notifications-info.quality-changed", values: { quality: t11 } }),
              ariaLabel: g2({ id: "notifications-info.quality-changed" }, { quality: t11 })
            };
          },
          [g2]
        ), L2 = (0, u.useCallback)(
          (e11, t11) => () => {
            if (b2.quality === e11) return;
            E2(e11);
            let { message: a3, ariaLabel: i3 } = j2(t11);
            x2((0, s.jsx)(tw, { onOpenQualitySettingsMenu: k2, message: a3, ariaLabel: i3, isMobile: C2 }), {
              containerId: n.uQT.INFO
            });
          },
          [j2, k2, x2, b2.quality, E2, C2]
        ), w2 = (0, u.useCallback)(
          (e11) => {
            let { selectedItemIcon: t11, type: a3, qualityMessageId: i3, ariaSelected: n2, text: r3 } = e11;
            return (e12) => {
              let { isPopoverEnabled: l3, popoverText: o3 } = e12;
              return (0, s.jsx)(tI.Dr, {
                isBlock: true,
                disabled: l3,
                className: (0, c.$)(tB().item, tB().expandedItem),
                iconPosition: "right",
                icon: t11,
                onClick: L2(a3, i3),
                role: "option",
                "aria-selected": n2,
                children: (0, s.jsxs)("span", {
                  className: tB().itemWrapper,
                  children: [
                    (0, s.jsxs)("span", {
                      className: tB().item_option,
                      children: [r3, " ", (0, s.jsx)(tS.q, { children: o3 })]
                    }),
                    (0, s.jsx)("span", {
                      className: (0, c.$)(tB().item_option, tB().itemSubTitle),
                      children: tR[a3]
                    })
                  ]
                })
              });
            };
          },
          [L2]
        ), M2 = !A2.hasPlus, B2 = (0, u.useMemo)(
          () => tO.map((e11) => {
            let { type: t11, text: a3, qualityMessageId: i3 } = e11, n2 = t11 === b2.quality ? (0, s.jsx)(D.Icon, { variant: "check", size: "xxs" }) : null, r3 = t11 === b2.quality;
            return (0, s.jsx)(
              h.SU,
              {
                isNested: true,
                isEnabled: M2 && !C2,
                placement: "left",
                textVariant: "highQuality",
                renderChildren: w2({
                  selectedItemIcon: n2,
                  type: t11,
                  qualityMessageId: i3,
                  ariaSelected: r3,
                  text: a3
                })
              },
              t11
            );
          }),
          [b2.quality, M2, C2, w2]
        ), K2 = (0, u.useMemo)(
          () => ({
            listClassName: (0, c.$)(tB().root, tB().root_withNewQuality, {
              [tB().root_withEqualizer]: f2.isAvailable
            }),
            menuClassName: (0, c.$)({ [tB().menuContent]: !C2 })
          }),
          [f2.isAvailable, C2]
        ), U2 = (0, u.useMemo)(() => {
          if (f2.isAvailable && !C2)
            return (0, s.jsx)(
              tT.rk,
              {
                isExpanded: f2.isEnabled,
                isDisabled: false,
                className: tB().equalizer,
                title: g2({ id: "equalizer.title" })
              },
              v2
            );
        }, [f2.isEnabled, v2, g2, f2.isAvailable, C2]), F2 = (0, u.useCallback)(
          (e11) => {
            let { isPopoverEnabled: n2 } = e11;
            if (!C2)
              return (0, s.jsx)(_.$, {
                className: (0, c.$)({ [tB().button_active]: N2.modal.isOpened }),
                radius: "round",
                color: "secondary",
                size: r2,
                icon: o2,
                variant: "text",
                onClick: N2.modal.open,
                "aria-label": g2({ id: "player-actions.audio-quality" }),
                withRipple: false,
                ...(0, R.Am)(R.e8.player.SOUND_QUALITY_BUTTON)
              });
            let u2 = n2 ? P2 : t10;
            return (0, s.jsx)(tI.W1, {
              wrapperClassName: l2,
              size: r2,
              icon: o2,
              placement: i2,
              open: a2,
              onOpenChange: u2,
              ariaLabel: g2({ id: "player-actions.audio-quality" }),
              footer: U2,
              label: d2,
              variant: "text",
              ...K2,
              containerProps: (0, R.Am)(R.e8.player.QUALITY_SETTINGS_CONTEXT_MENU),
              isMobile: C2,
              lockScroll: !C2,
              disabled: p2,
              ...(0, R.Am)(R.e8.player.SOUND_QUALITY_BUTTON),
              children: B2
            });
          },
          [C2, P2, t10, l2, r2, o2, i2, a2, g2, U2, d2, K2, B2, N2.modal.open, N2.modal.isOpened, p2]
        );
        return (0, s.jsx)(h.Zr, {
          isEnabled: !A2.isAuthorized,
          isOpened: T2,
          onOpenChange: P2,
          placement: "top",
          textVariant: "changeQuality",
          renderChildren: F2
        });
      }), tK = (0, d.PA)((e10) => {
        var t10, a2, i2, r2;
        let { className: l2, onSyncLyricsButtonClick: o2 } = e10, {
          sonataState: d2,
          settings: { isLandscape: m2 },
          fullscreenPlayer: { isSyncLyricsMode: p2 },
          user: { hasPlus: v2 }
        } = (0, n.Pjs)(), { formatMessage: g2 } = (0, O.A)(), [x2, y2] = (0, u.useState)(false), b2 = (0, I.AA)(), A2 = (0, I.e9)(), C2 = null === d2.entityMeta, N2 = (null == (t10 = d2.entityMeta) ? void 0 : t10.isNonMusic) || (null == (i2 = d2.entityMeta) || null == (a2 = i2.mainAlbum) ? void 0 : a2.isNonMusic), f2 = d2.canSpeed && N2, S2 = (0, Y.c)(() => {
          A2(d2);
        }), T2 = (0, Y.c)(() => {
          b2(d2);
        }), P2 = (0, u.useMemo)(() => {
          var e11;
          if (N2) return;
          let t11 = "".concat(g2({ id: "interface-actions.open-sync-lyrics" }), " ").concat(g2({ id: "warning-messages.can-break-accessibility" }));
          return (0, s.jsx)(_.$, {
            className: (0, c.$)(tN().syncLyricsButton, { [tN().syncLyricsButton_active]: p2 }),
            radius: "round",
            size: "xxxs",
            variant: "text",
            disabled: !(null == (e11 = d2.entityMeta) ? void 0 : e11.isSyncLyricsAvailable) || m2,
            withRipple: false,
            withHover: false,
            "aria-label": t11,
            icon: (0, s.jsx)(D.Icon, { variant: "syncLyrics", size: "xs" }),
            onClick: o2
          });
        }, [g2, N2, p2, o2, m2, null == (r2 = d2.entityMeta) ? void 0 : r2.isSyncLyricsAvailable]);
        return (0, s.jsx)("div", {
          className: (0, c.$)(tN().footer, l2),
          children: (0, s.jsxs)("div", {
            className: tN().footerContainer,
            children: [
              (C2 || d2.canChangeRepeatMode) && (0, s.jsx)(I.s_, { onClick: T2, isDisabled: C2, repeatMode: d2.repeatMode, variant: "text" }),
              f2 && (0, s.jsx)(h.ig, { size: "xxxs", iconSize: "l" }),
              (0, s.jsx)(tD, {
                open: x2,
                onOpenChange: y2,
                icon: (0, s.jsx)(D.Icon, { variant: "settings", size: "xs" }),
                size: "xxxs",
                disabled: !v2
              }),
              P2,
              (C2 || d2.canShuffle) && (0, s.jsx)(I.uP, { onClick: S2, isDisabled: C2, shuffle: d2.shuffle, variant: "text" })
            ]
          })
        });
      });
      var tU = a(78444), tF = a.n(tU);
      let tz = {
        enter: tF().coverWrapper_enter,
        enterActive: tF().coverWrapper_enter_active,
        exit: tF().coverWrapper_exit,
        exitActive: tF().coverWrapper_exit_active
      }, tV = (0, d.PA)((e10) => {
        var t10;
        let { className: a2 } = e10, i2 = (0, u.useRef)(null), [r2, l2] = (0, u.useState)(false), { state: o2, handleDebouncedToggle: d2, reset: m2 } = (0, V.F)({ delay: 7e3, throttleTimeout: 0 }), {
          fullscreenPlayer: {
            isSplitMode: _2,
            isSyncLyricsMode: p2,
            showSyncLyrics: v2,
            hideSyncLyrics: g2,
            isPlayQueueMode: x2,
            syncLyrics: y2
          },
          sonataState: { entityMeta: b2 },
          settings: { isLandscape: A2 }
        } = (0, n.Pjs)(), C2 = (null == b2 ? void 0 : b2.isTrackPodcast) || (null == b2 || null == (t10 = b2.mainAlbum) ? void 0 : t10.isPodcast), N2 = null == b2 ? void 0 : b2.isTrackAudiobook, f2 = (o2 || !_2 || A2) && !x2, S2 = (0, u.useCallback)(() => {
          p2 && !A2 && (o2 ? m2() : d2());
        }, [p2, o2, m2, d2, A2]), T2 = (0, u.useCallback)(() => {
          p2 && !A2 && o2 && d2();
        }, [d2, p2, o2, A2]), P2 = (0, u.useCallback)(() => {
          if (null == b2 ? void 0 : b2.isSyncLyricsAvailable) return p2 ? g2() : v2();
        }, [null == b2 ? void 0 : b2.isSyncLyricsAvailable, g2, p2, v2]), E2 = (0, u.useMemo)(() => {
          if (b2)
            return N2 ? (0, s.jsx)(k.ZS, {
              textClassName: tF().metaText,
              track: b2,
              withSecondaryColor: true,
              captionSize: "l",
              explicitSize: "xs",
              withAuthor: true,
              withContextMenuArtists: true
            }) : C2 ? (0, s.jsx)(k.wo, {
              textClassName: tF().metaText,
              track: b2,
              withSecondaryColor: true,
              withDate: false,
              captionSize: "l",
              explicitSize: "xs",
              withPodcastName: true
            }) : (0, s.jsx)(k.j7, {
              textClassName: tF().metaText,
              track: b2,
              withSecondaryColor: true,
              withAlbumLink: false,
              captionSize: "l",
              explicitSize: "xs",
              withAllArtistsTitle: true,
              withContextMenuArtists: true
            });
        }, [b2, N2, C2]);
        return (0, u.useEffect)(() => {
          p2 && A2 && y2.setInvisible();
        }, [A2, p2, y2]), (0, u.useLayoutEffect)(() => {
          p2 && !A2 && d2();
        }, [d2, p2, A2]), (0, s.jsxs)("div", {
          onTouchEnd: T2,
          className: (0, c.$)(tF().root, a2),
          children: [
            (0, s.jsx)("div", {
              className: tF().content,
              children: (0, s.jsxs)("div", {
                className: tF().wrapper,
                children: [
                  (0, s.jsxs)("div", {
                    className: (0, c.$)(tF().infoBlock, { [tF().infoBlock_withExpandedSyncLyrics]: !o2 && p2 && !A2 }),
                    children: [
                      (0, s.jsxs)("div", {
                        onClick: S2,
                        className: (0, c.$)(tF().contentContainer, { [tF().contentContainer_withSplitMode]: _2 }),
                        children: [
                          p2 && !A2 && (0, s.jsx)(e7, {
                            className: tF().syncLyrics,
                            scrollerClassName: tF().syncLyricsScroller,
                            contentClassName: tF().syncLyricsContent,
                            loaderClassName: tF().syncLyricsLoader,
                            footerClassName: tF().syncLyricsFooter,
                            counterClassName: tF().syncLyricsCounter
                          }),
                          x2 && (0, s.jsx)(eF, {}),
                          (0, s.jsx)(tg.A, {
                            in: !_2 || A2 && p2,
                            nodeRef: i2,
                            timeout: 200,
                            unmountOnExit: true,
                            classNames: tz,
                            children: (0, s.jsx)(tu.Paper, {
                              ref: i2,
                              radius: "m",
                              className: tF().coverWrapper,
                              children: (0, s.jsx)(h.BW, {
                                className: tF().cover,
                                src: null == b2 ? void 0 : b2.coverUri,
                                size: 400,
                                fit: "cover",
                                withAvatarReplace: true
                              })
                            })
                          })
                        ]
                      }),
                      !x2 && (0, s.jsxs)("div", {
                        className: tF().trackInfo,
                        children: [
                          !o2 && p2 && !A2 && (0, s.jsx)(tu.Paper, {
                            className: tF().trackInfoCoverContainer,
                            radius: "xs",
                            children: (0, s.jsx)(h.BW, {
                              className: tF().trackInfoCover,
                              src: null == b2 ? void 0 : b2.coverUri,
                              size: 200,
                              fit: "cover",
                              withAvatarReplace: true
                            })
                          }),
                          (0, s.jsxs)("div", {
                            className: tF().metaContainer,
                            children: [
                              E2,
                              !(null == b2 ? void 0 : b2.isRemoved) && (null == b2 ? void 0 : b2.isAvailable) && (0, s.jsx)(k._Y, {
                                className: (0, c.$)(tF().contextMenu, { [tF().contextMenu_visible]: r2 }),
                                track: b2,
                                open: r2,
                                onOpenChange: l2,
                                placement: "bottom",
                                isFullscreenMobile: true,
                                size: "xs",
                                icon: (0, s.jsx)(D.Icon, { variant: "more", size: "xxs" }),
                                ...(0, R.Am)(R.e8.player.MOBILE_FULLSCREEN_PLAYER_CONTEXT_MENU_BUTTON)
                              })
                            ]
                          })
                        ]
                      })
                    ]
                  }),
                  f2 && (0, s.jsx)(G.v, {
                    className: tF().timeline,
                    disabled: !b2,
                    isMobile: true,
                    isFullscreen: true,
                    showThumbVariant: "always"
                  }),
                  f2 && (0, s.jsx)(I.$u, {
                    className: tF().buttonsBlock,
                    isMobile: true,
                    entityMeta: b2,
                    isFullscreen: true
                  })
                ]
              })
            }),
            f2 && (0, s.jsx)(tK, { onSyncLyricsButtonClick: P2 })
          ]
        });
      });
      var tW = a(18726), tG = a.n(tW);
      let tY = (0, d.PA)((e10) => {
        let { children: t10, className: a2 } = e10, { url: i2, title: r2, subTitle: l2 } = ex(), { fullscreenPlayer: o2 } = (0, n.Pjs)(), d2 = (0, Y.c)((e11) => {
          e11.stopPropagation(), o2.modal.isOpened && o2.modal.close();
        }), m2 = (0, u.useMemo)(() => {
          let e11 = (0, s.jsx)(v.Caption, {
            variant: "span",
            size: "m",
            className: tG().title,
            lineClamp: 1,
            ...(0, R.Am)(R.e8.player.MOBILE_PLAY_QUEUE_NOW_PLAYING_BLOCK_TITLE),
            children: r2
          });
          return i2 ? (0, s.jsx)(h.N_, { href: i2, target: "_self", onClick: d2, className: tG().link, children: e11 }) : e11;
        }, [d2, r2, i2]);
        return (0, s.jsxs)("div", {
          className: (0, c.$)(tG().root, a2),
          ...(0, R.Am)(R.e8.player.MOBILE_PLAY_QUEUE_NOW_PLAYING_BLOCK),
          children: [
            (0, s.jsxs)("div", {
              className: tG().textBlock,
              children: [
                (0, s.jsx)(v.Caption, {
                  variant: "span",
                  size: "s",
                  weight: "normal",
                  className: tG().subTitle,
                  ...(0, R.Am)(R.e8.player.MOBILE_PLAY_QUEUE_NOW_PLAYING_BLOCK_SUBTITLE),
                  children: l2
                }),
                m2
              ]
            }),
            t10
          ]
        });
      }), tQ = (0, d.PA)(() => {
        let { formatMessage: e10 } = (0, O.A)(), {
          fullscreenPlayer: { modal: t10, showPlayQueue: a2, isPlayQueueMode: i2, hidePlayQueue: r2 },
          user: l2
        } = (0, n.Pjs)(), o2 = (0, u.useCallback)(() => i2 ? r2() : a2(), [r2, i2, a2]);
        return (0, s.jsxs)("header", {
          className: tN().header,
          children: [
            (0, s.jsx)(_.$, {
              radius: "round",
              color: "secondary",
              size: "s",
              variant: "text",
              icon: (0, s.jsx)(D.Icon, { variant: "arrowDown", size: "xs" }),
              onClick: t10.close,
              "aria-label": e10({ id: "interface-actions.close" }),
              ...(0, R.Am)(R.e8.player.MOBILE_FULLSCREEN_PLAYER_CLOSE_BUTTON)
            }),
            (0, s.jsx)(tY, {
              className: tN().headerCenter,
              children: (0, s.jsx)(h.hj, {
                title: e10({ id: "player-actions.cast" }),
                description: e10({ id: "future-feature.message" }),
                children: (0, s.jsx)(_.$, {
                  className: tN().castButton,
                  radius: "round",
                  size: "s",
                  variant: "text",
                  disabled: true,
                  withRipple: false,
                  "aria-label": e10({ id: "player-actions.cast" }),
                  icon: (0, s.jsx)(D.Icon, { variant: "cast", size: "xs" })
                })
              })
            }),
            (0, s.jsx)(_.$, {
              className: (0, c.$)(tN().playQueueButton, { [tN().playQueueButton_active]: i2 }),
              radius: "round",
              size: "s",
              variant: "text",
              withRipple: false,
              withHover: false,
              "aria-label": e10({ id: "play-queue.title" }),
              onClick: o2,
              icon: (0, s.jsx)(D.Icon, { variant: "playQueue", size: "xs" }),
              disabled: !l2.isAuthorized,
              ...(0, R.Am)(R.e8.player.MOBILE_FULLSCREEN_PLAYER_QUEUE_BUTTON)
            })
          ]
        });
      }), t$ = (0, d.PA)(() => {
        let {
          sonataState: { entityMeta: e10 },
          fullscreenPlayer: t10,
          advert: a2,
          settings: { isMobile: i2 }
        } = (0, n.Pjs)(), { theme: r2 } = (0, n.DPo)(), l2 = (0, u.useMemo)(
          () => ({ "--player-average-color-background": (0, k.ye)(r2, null == e10 ? void 0 : e10.averageColor) }),
          [null == e10 ? void 0 : e10.averageColor, r2]
        );
        return (0, u.useEffect)(() => {
          a2.isAdvertShown && t10.modal.close();
        }, [a2.isAdvertShown, t10.modal]), (0, s.jsxs)(K.a, {
          className: (0, c.$)(tN().root, tN().important),
          open: t10.modal.isOpened,
          onOpenChange: t10.modal.onOpenChange,
          size: "fullscreen",
          placement: "center",
          showHeader: false,
          style: l2,
          contentClassName: tN().modalContent,
          lockScroll: i2,
          ...(0, R.Am)(R.e8.player.MOBILE_FULLSCREEN_PLAYER_MODAL),
          children: [
            (0, s.jsx)(tQ, {}),
            (0, s.jsx)(tV, {}),
            (0, s.jsx)(U.Notification, {
              className: tN().notification,
              enableMultiContainer: true,
              containerId: n.uQT.FULLSCREEN_INFO,
              position: "bottom-center"
            }),
            (0, s.jsx)(U.Notification, {
              className: tN().notification,
              enableMultiContainer: true,
              containerId: n.uQT.FULLSCREEN_ERROR,
              position: "bottom-center"
            })
          ]
        });
      }), tq = (0, d.PA)(() => {
        let {
          settings: { isMobileLandscapeHeight: e10, layout: t10 }
        } = (0, n.Pjs)(), a2 = t10 === n.u40.Mobile;
        return !a2 && e10 || a2 ? (0, s.jsx)(t$, {}) : (0, s.jsx)(tA, {});
      });
      var tH = a(19020), tX = a(34960), tZ = a(27176), tJ = a.n(tZ);
      let t0 = (0, d.PA)((e10) => {
        let { advertData: t10 } = e10, {
          settings: { isMobile: a2 }
        } = (0, n.Pjs)(), { formatMessage: i2 } = (0, O.A)(), r2 = !!t10.advertiserInfoUrl || !!t10.clientLegalInfo, l2 = (0, u.useCallback)(() => {
          window.open(t10.advertiserInfoUrl, "_blank", "noreferrer noopener");
        }, [t10.advertiserInfoUrl]);
        return r2 ? (0, s.jsxs)(tI.W1, {
          className: tJ().contextMenuButton,
          size: "xxs",
          icon: (0, s.jsx)(D.Icon, { size: "xxs", variant: "more", className: tJ().contextMenuIcon }),
          isMobile: a2,
          ariaLabel: i2({ id: "interface-actions.context-menu" }),
          children: [
            t10.clientLegalInfo && (0, s.jsx)(v.Caption, {
              variant: "div",
              size: "s",
              className: tJ().contextMenuHeader,
              children: t10.clientLegalInfo
            }),
            t10.advertiserInfoUrl && (0, s.jsx)(tI.Dr, {
              onClick: l2,
              icon: (0, s.jsx)(D.Icon, { variant: "info", size: "xxs" }),
              children: (0, s.jsx)(m.A, { id: "ads.about-advertiser" })
            })
          ]
        }) : null;
      }), t1 = (0, d.PA)((e10) => {
        var t10, a2, i2;
        let { className: r2 } = e10, { advert: l2 } = (0, n.Pjs)();
        return l2.data && l2.isAudioAdvert ? (0, s.jsx)("div", {
          className: r2,
          children: (0, s.jsx)(y, {
            data: l2.data,
            mediaContent: (0, s.jsxs)("div", {
              className: tJ().imageContainer,
              children: [
                (0, s.jsx)(p.Image, {
                  className: (0, c.$)(tJ().image, {
                    [tJ().image_fallback]: !(null == (t10 = l2.data) ? void 0 : t10.iconSrc)
                  }),
                  "aria-hidden": true,
                  fit: "cover",
                  src: null == (a2 = l2.data) ? void 0 : a2.iconSrc,
                  fallbackIconVariant: "picture",
                  alt: ""
                }),
                (0, s.jsx)(p.Image, {
                  className: tJ().backgroundImage,
                  "aria-hidden": true,
                  fit: "cover",
                  src: null == (i2 = l2.data) ? void 0 : i2.iconSrc,
                  fallbackIconVariant: "picture",
                  alt: ""
                }),
                (0, s.jsx)(t0, { advertData: l2.data })
              ]
            }),
            linkClassName: tJ().linkButton
          })
        }) : null;
      });
      var t2 = a(42653), t8 = a.n(t2);
      let t3 = (0, d.PA)(() => {
        let {
          settings: { isMobile: e10 },
          sonataState: t10,
          user: a2,
          quality: i2
        } = (0, n.Pjs)(), r2 = (0, tT.Sq)(), { contentRootRef: l2 } = (0, n.gKY)(), { formatMessage: o2 } = (0, O.A)(), d2 = (0, n.NFA)(), { notify: p2 } = (0, n.lkh)(), g2 = (0, u.useId)(), x2 = (0, n.gQL)(), y2 = d2.get(n.ooW), b2 = tE(), A2 = (0, u.useCallback)(
          (e11) => {
            b2(e11, t10.quality), t10.setQuality(e11), null == x2 || x2.setQuality(e11), y2.set(n.cYZ.YmPlayerQuality, e11, { expires: 365 });
          },
          [x2, t10, y2, b2]
        ), C2 = (0, u.useCallback)(
          (e11) => {
            let t11 = o2({ id: e11 }).toLowerCase();
            return {
              message: (0, s.jsx)(m.A, { id: "notifications-info.quality-changed", values: { quality: t11 } }),
              ariaLabel: o2({ id: "notifications-info.quality-changed" }, { quality: t11 })
            };
          },
          [o2]
        ), N2 = (0, u.useCallback)(
          (e11, a3) => () => {
            if (t10.quality === e11) return;
            i2.modal.close(), A2(e11);
            let { message: r3, ariaLabel: l3 } = C2(a3);
            p2((0, s.jsx)(tw, { onOpenQualitySettingsMenu: i2.modal.open, message: r3, ariaLabel: l3 }), {
              containerId: n.uQT.INFO
            });
          },
          [C2, p2, t10.quality, A2, i2.modal]
        ), f2 = (0, Y.c)((e11) => {
          switch (e11) {
            case tf.e.HIGH_QUALITY:
              return R.e8.player.QUALITY_SETTINGS_CONTEXT_MENU_ITEM_HIGH_QUALITY;
            case tf.e.BALANCED:
              return R.e8.player.QUALITY_SETTINGS_CONTEXT_MENU_ITEM_BALANCED;
            default:
              return R.e8.player.QUALITY_SETTINGS_CONTEXT_MENU_ITEM_EFFICIENT;
          }
        }), I2 = (0, u.useCallback)(
          (e11) => {
            let { selectedItemIcon: t11, type: a3, qualityMessageId: i3, ariaSelected: n2, text: r3 } = e11;
            return (e12) => {
              let { isPopoverEnabled: l3, popoverText: o3 } = e12;
              return (0, s.jsx)(
                _.$,
                {
                  isBlock: true,
                  disabled: l3,
                  className: (0, c.$)(tB().item, t8().button, tB().expandedItem),
                  iconPosition: "right",
                  icon: t11,
                  onClick: N2(a3, i3),
                  role: "option",
                  "aria-selected": n2,
                  variant: "text",
                  ...(0, R.Am)(f2(a3)),
                  children: (0, s.jsxs)("span", {
                    className: tB().itemWrapper,
                    children: [
                      (0, s.jsxs)("span", {
                        className: tB().item_option,
                        children: [r3, " ", (0, s.jsx)(tS.q, { children: o3 })]
                      }),
                      (0, s.jsx)("span", {
                        className: (0, c.$)(tB().item_option, tB().itemSubTitle),
                        children: tR[a3]
                      })
                    ]
                  })
                },
                a3
              );
            };
          },
          [N2, f2]
        );
        (0, u.useEffect)(
          () => () => {
            i2.modal.close();
          },
          [i2.modal]
        );
        let S2 = !a2.hasPlus, T2 = (0, u.useMemo)(
          () => tO.map((a3) => {
            let { type: i3, text: n2, qualityMessageId: r3 } = a3, l3 = i3 === t10.quality ? (0, s.jsx)(D.Icon, { variant: "check", size: "xxs" }) : null, o3 = i3 === t10.quality;
            return (0, s.jsx)(
              h.SU,
              {
                isNested: true,
                isEnabled: S2 && !e10,
                placement: "left",
                textVariant: "highQuality",
                renderChildren: I2({ selectedItemIcon: l3, type: i3, qualityMessageId: r3, ariaSelected: o3, text: n2 })
              },
              i3
            );
          }),
          [t10.quality, S2, e10, I2]
        ), P2 = (0, u.useMemo)(() => {
          if (r2.isAvailable && !e10)
            return (0, s.jsx)(
              tT.rk,
              {
                isExpanded: r2.isEnabled,
                isDisabled: false,
                className: (0, c.$)(tB().equalizer, tB().equalizer_withNewQuality),
                title: o2({ id: "equalizer.title" })
              },
              g2
            );
        }, [g2, o2, e10, r2.isEnabled, r2.isAvailable]);
        return (0, s.jsxs)(K.a, {
          size: "fitContent",
          placement: e10 ? "default" : "right",
          open: i2.modal.isOpened,
          onOpenChange: i2.modal.onOpenChange,
          onClose: i2.modal.close,
          className: t8().root,
          contentClassName: t8().modalContent,
          portalNode: e10 ? null : l2,
          showHeader: false,
          overlayClassName: t8().overlay,
          containerProps: (0, R.Am)(R.e8.player.QUALITY_SETTINGS_CONTEXT_MENU),
          children: [
            !e10 && (0, s.jsxs)(v.Heading, {
              className: (0, c.$)(tB().header, tB().headerWithCloseButton),
              variant: "h4",
              size: "xs",
              weight: "bold",
              children: [
                (0, s.jsx)(m.A, { id: "player-actions.audio-quality" }),
                (0, s.jsx)(_.$, {
                  radius: "round",
                  color: "secondary",
                  size: "xxs",
                  icon: (0, s.jsx)(D.Icon, { variant: "close", size: "xxs" }),
                  onClick: i2.modal.close,
                  "aria-label": o2({ id: "interface-actions.close-quality-settings" })
                })
              ]
            }),
            T2,
            P2
          ]
        });
      });
      var t4 = a(77760), t5 = a.n(t4), t6 = a(93666), t7 = a(246);
      let t9 = "player-region", ae = (e10) => {
        let { theme: t10 } = (0, n.DPo)();
        return { "--player-average-color-background": (0, k.ye)(t10, null == e10 ? void 0 : e10.averageColor) };
      };
      var at = a(85188), aa = a.n(at);
      let ai = (e10) => {
        let { className: t10, ariaLabel: a2, onClick: i2, forwardRef: n2 } = e10;
        return (0, s.jsx)("div", {
          ref: n2,
          className: (0, c.$)(aa().root, t10),
          children: (0, s.jsx)(_.$, {
            className: aa().button,
            radius: "round",
            size: "s",
            color: "secondary",
            withRipple: false,
            "aria-label": a2,
            icon: (0, s.jsx)(D.Icon, { variant: "fullscreen", size: "xs" }),
            onClick: i2,
            ...(0, R.Am)(R.e8.player.FULLSCREEN_PLAYER_BUTTON)
          })
        });
      }, an = (0, u.forwardRef)((e10, t10) => (0, s.jsx)(ai, { forwardRef: t10, ...e10 }));
      var ar = a(44123), al = a.n(ar);
      let ao = (0, d.PA)((e10) => {
        var t10;
        let { className: a2, entityMeta: i2, isLiked: r2, isDisliked: l2, onLikeClick: o2, onDislikeClick: d2 } = e10, {
          user: p2,
          sonataState: g2,
          fullscreenPlayer: x2,
          settings: { isMobileLandscapeHeight: y2 },
          advert: b2,
          track: A2
        } = (0, n.Pjs)(), [C2, N2] = (0, u.useState)(false), [f2, S2] = (0, u.useState)(false), { formatMessage: T2 } = (0, O.A)(), P2 = !g2.isGenerativeContext, E2 = g2.canSpeed && (null == i2 ? void 0 : i2.isNonMusic), j2 = (null == i2 ? void 0 : i2.isTrackPodcast) || (null == i2 || null == (t10 = i2.mainAlbum) ? void 0 : t10.isPodcast), L2 = null == i2 ? void 0 : i2.isTrackAudiobook, w2 = (0, I.d0)(), M2 = ae(i2), B2 = (0, Y.c)(() => {
          A2.open({ trackId: null == i2 ? void 0 : i2.id, albumId: null == i2 ? void 0 : i2.albumId });
        }), K2 = (0, Y.c)((e11) => {
          e11.stopPropagation();
        }), U2 = (0, Y.c)(async (e11) => {
          await w2(g2, e11);
        }), F2 = (0, Y.c)((e11) => {
          g2.setVolume(e11);
        }), z2 = (0, Y.c)((e11) => {
          let t11 = e11.target, a3 = t11 instanceof Element && ["DIV", "SECTION", "SPAN"].includes(t11.tagName);
          i2 && P2 && a3 && !b2.isAdvertShown && x2.showFullscreenPlayerModal();
        }), V2 = (0, Y.c)((e11) => {
          if (!g2.isGenerativeContext && i2) {
            if ((0, el.P)(e11, al().ripple), 2 === e11.detail) {
              A2.close(), z2(e11);
              return;
            }
            1 === e11.detail && (null == i2 ? void 0 : i2.hasTrackLink) && !x2.modal.isOpened && B2();
          }
        }), W2 = (0, u.useCallback)(
          (e11) => {
            let { isPopoverEnabled: t11 } = e11, a3 = "".concat(T2({ id: "interface-actions.open-sync-lyrics" }), " ").concat(T2({ id: "warning-messages.can-break-accessibility" })), n2 = t11 ? void 0 : x2.showSyncLyrics;
            return (0, s.jsx)(_.$, {
              radius: "round",
              size: "xxxs",
              variant: "text",
              disabled: !(null == i2 ? void 0 : i2.isSyncLyricsAvailableWithOfflineFeature) || y2,
              "aria-hidden": !(null == i2 ? void 0 : i2.isSyncLyricsAvailableWithOfflineFeature),
              withRipple: false,
              "aria-label": a3,
              icon: (0, s.jsx)(D.Icon, { variant: "syncLyrics", size: "xs" }),
              onClick: n2,
              ...(0, R.Am)(R.e8.player.PLAYERBAR_DESKTOP_SYNC_LYRICS_BUTTON)
            });
          },
          [T2, x2.showSyncLyrics, null == i2 ? void 0 : i2.isSyncLyricsAvailableWithOfflineFeature, y2]
        ), Q2 = (0, u.useMemo)(
          () => (null == i2 ? void 0 : i2.isNonMusic) || b2.isAdvertShown ? null : p2.isAuthorized && !p2.hasPlus ? (0, s.jsx)(h.SU, { placement: "top", textVariant: "sync-lyrics", renderChildren: W2 }) : (0, s.jsx)(h.Zr, {
            isEnabled: !p2.isAuthorized,
            placement: "top",
            textVariant: "sync-lyrics",
            renderChildren: W2
          }),
          [null == i2 ? void 0 : i2.isNonMusic, b2.isAdvertShown, p2.isAuthorized, W2, p2.hasPlus]
        ), $2 = (0, u.useCallback)(
          (e11) => {
            let { isPopoverEnabled: t11 } = e11, a3 = t11 ? void 0 : x2.showPlayQueue;
            return (0, s.jsx)(_.$, {
              radius: "round",
              size: "xxxs",
              variant: "text",
              disabled: !i2,
              withRipple: false,
              "aria-label": T2({ id: "play-queue.title" }),
              icon: (0, s.jsx)(D.Icon, { variant: "playQueue", size: "xs" }),
              onClick: a3,
              ...(0, R.Am)(R.e8.player.PLAYERBAR_DESKTOP_PLAY_QUEUE_BUTTON)
            });
          },
          [i2, x2.showPlayQueue, T2]
        ), q2 = (0, u.useMemo)(
          () => b2.isAdvertShown ? null : (0, s.jsx)(h.Zr, {
            isEnabled: !p2.isAuthorized,
            placement: "top",
            textVariant: "openQueue",
            renderChildren: $2
          }),
          [b2.isAdvertShown, p2.isAuthorized, $2]
        ), H2 = (0, u.useMemo)(() => {
          if (i2 && !g2.isGenerativeContext && !b2.isAdvertShown)
            return (0, s.jsx)("div", {
              onDoubleClick: K2,
              children: (0, s.jsx)(k._Y, {
                track: i2,
                placement: "top",
                className: al().trackContextMenuIcon,
                open: C2,
                onOpenChange: N2,
                icon: (0, s.jsx)(D.Icon, { size: "xxs", variant: "more" }),
                size: "xs",
                ...(0, R.Am)(R.e8.player.PLAYERBAR_DESKTOP_CONTEXT_MENU_BUTTON)
              })
            });
        }, [b2.isAdvertShown, i2, K2, C2, g2.isGenerativeContext]), X2 = (0, u.useMemo)(
          () => i2 ? L2 ? (0, s.jsx)(k.ZS, {
            afterTitle: H2,
            explicitSize: "xxxs",
            track: i2,
            withAuthor: true,
            withSecondaryColor: true,
            withContextMenuArtists: true
          }) : j2 ? (0, s.jsx)(k.wo, {
            afterTitle: H2,
            explicitSize: "xxxs",
            track: i2,
            withDate: false,
            withSecondaryColor: true,
            withPodcastName: true
          }) : (0, s.jsx)(k.j7, {
            afterTitle: H2,
            track: i2,
            withSecondaryColor: true,
            withAlbumLink: false,
            withTrackLink: !g2.isGenerativeContext,
            withContextMenuArtists: true
          }) : null,
          [H2, i2, L2, j2, g2.isGenerativeContext]
        );
        return (0, s.jsx)("section", {
          style: b2.isAdvertShown ? void 0 : M2,
          className: (0, c.$)(al().root, al().important, a2),
          ...(0, R.Am)(R.e8.player.PLAYERBAR_DESKTOP),
          "aria-labelledby": t9,
          children: (0, s.jsxs)("div", {
            className: al().playerBar,
            children: [
              !g2.isGenerativeContext && (0, s.jsx)(G.J, {
                sliderClassName: al().slider,
                progressbarClassName: al().progressBar,
                disabled: !i2,
                isMobile: false
              }),
              (0, s.jsxs)("div", {
                className: (0, c.$)(al().player, { [al().player_disabled]: !i2 }),
                children: [
                  (0, s.jsx)("div", { onClick: V2, className: al().triggerModal }),
                  (0, s.jsx)(tS.q, {
                    children: (0, s.jsx)(v.Heading, {
                      variant: "h3",
                      id: t9,
                      children: (0, s.jsx)(m.A, { id: "a11y-regions.player" })
                    })
                  }),
                  (0, s.jsx)("div", {
                    className: al().info,
                    children: (0, s.jsx)("div", {
                      className: al().infoCard,
                      children: i2 && !b2.isAdvertShown && (0, s.jsxs)(s.Fragment, {
                        children: [
                          (0, s.jsxs)(tu.Paper, {
                            radius: "s",
                            className: al().coverContainer,
                            ...(0, R.Am)(R.e8.player.PLAYERBAR_DESKTOP_COVER_CONTAINER),
                            children: [
                              (0, s.jsx)(h.BW, {
                                className: al().cover,
                                src: i2.coverUri,
                                size: 100,
                                fit: "cover",
                                withAvatarReplace: true
                              }),
                              P2 && (0, s.jsxs)(t6.m_, {
                                placement: "top",
                                offsetOptions: 4,
                                children: [
                                  (0, s.jsx)(an, {
                                    ariaLabel: T2({ id: "player-actions.fullscreen-button" }),
                                    onClick: x2.showFullscreenPlayerModal
                                  }),
                                  (0, s.jsx)(t6.ZI, {
                                    children: (0, s.jsx)(m.A, { id: "player-actions.fullscreen" })
                                  })
                                ]
                              })
                            ]
                          }),
                          (0, s.jsx)("div", { className: al().description, children: X2 })
                        ]
                      })
                    })
                  }),
                  (0, s.jsxs)("div", {
                    className: al().sonata,
                    children: [
                      (0, s.jsx)(h.aQ, {
                        fallback: (0, s.jsx)(h.cy, {
                          disabled: !i2 || b2.isAdvertShown,
                          isLiked: r2,
                          onClick: o2,
                          iconSize: "xs"
                        })
                      }),
                      (0, s.jsx)(I.$u, {
                        className: (0, c.$)(al().sonataControls, al().important),
                        withRepeat: true,
                        withShuffle: true,
                        isMobile: false,
                        entityMeta: i2
                      }),
                      (0, s.jsx)(h.aQ, {
                        fallback: (0, s.jsx)(h._I, {
                          disabled: !i2 || b2.isAdvertShown,
                          isDisliked: l2,
                          onClick: d2,
                          iconSize: "xs"
                        })
                      })
                    ]
                  }),
                  (0, s.jsxs)("div", {
                    className: al().meta,
                    children: [
                      !g2.isGenerativeContext && !b2.isAdvertShown && (0, s.jsxs)(s.Fragment, {
                        children: [
                          E2 && (0, s.jsx)(h.ig, { iconSize: "l" }),
                          Q2,
                          q2,
                          (0, s.jsx)(tD, {
                            placement: "bottom",
                            open: f2,
                            onOpenChange: S2,
                            icon: (0, s.jsx)(D.Icon, { variant: "settings", size: "xs" }),
                            size: "xxxs",
                            referenceClassName: al().settingsButton
                          })
                        ]
                      }),
                      (0, s.jsx)(t7.r, {
                        variant: t7.q.VERTICAL,
                        sonataVolume: g2.volume,
                        onVolumeSet: F2,
                        onVolumeClick: U2
                      })
                    ]
                  })
                ]
              })
            ]
          })
        });
      });
      var as = a(22674), ac = a(51935), ad = a.n(ac);
      let au = (0, d.PA)((e10) => {
        var t10;
        let { className: a2, entityMeta: i2, isLiked: r2, onLikeClick: l2 } = e10, { user: o2, sonataState: d2, fullscreenPlayer: _2, advert: p2 } = (0, n.Pjs)(), g2 = o2.isAuthorized && i2 && !p2.isAdvertShown, x2 = (null == i2 ? void 0 : i2.isTrackPodcast) || (null == i2 || null == (t10 = i2.mainAlbum) ? void 0 : t10.isPodcast), y2 = null == i2 ? void 0 : i2.isTrackAudiobook, b2 = ae(i2), A2 = (0, u.useCallback)(
          (e11) => {
            if (p2.isAdvertShown) return;
            let t11 = e11.target, a3 = t11 instanceof Element && ["DIV", "SECTION", "IMG", "SPAN"].includes(t11.tagName);
            i2 && a3 && !d2.isGenerativeContext && _2.showFullscreenPlayerModal();
          },
          [i2, _2, d2.isGenerativeContext, p2.isAdvertShown]
        ), C2 = (0, u.useMemo)(
          () => p2.isAdvertShown ? null : i2 ? y2 ? (0, s.jsx)(k.ZS, {
            explicitSize: "xxxs",
            track: i2,
            withAuthor: true,
            withSecondaryColor: true,
            withArtistLink: false
          }) : x2 ? (0, s.jsx)(k.wo, {
            explicitSize: "xxxs",
            track: i2,
            withDate: false,
            withSecondaryColor: true,
            withPodcastName: true,
            withAlbumTitleLink: false
          }) : (0, s.jsx)(k.j7, { withArtistLink: false, track: i2, withSecondaryColor: true, withAlbumLink: false }) : (0, s.jsxs)("div", {
            className: ad().shimmerMeta,
            children: [
              (0, s.jsx)(as.Shimmer, { className: ad().shimmerMetaTitle }),
              (0, s.jsx)(as.Shimmer, { className: ad().shimmerMetaDescription })
            ]
          }),
          [p2.isAdvertShown, i2, y2, x2]
        ), N2 = (0, J.L)(
          () => p2.isAdvertShown ? (0, s.jsx)("div", { className: ad().infoCard }) : i2 ? (0, s.jsxs)("div", {
            className: ad().infoCard,
            children: [
              (0, s.jsx)(tu.Paper, {
                radius: "s",
                className: ad().coverContainer,
                children: (0, s.jsx)(h.BW, {
                  className: ad().cover,
                  src: i2.coverUri,
                  size: 50,
                  fit: "cover",
                  withAvatarReplace: true
                })
              }),
              (0, s.jsx)("div", { className: ad().description, children: C2 })
            ]
          }) : (0, s.jsxs)("div", {
            className: ad().infoCard,
            children: [
              (0, s.jsx)(tu.Paper, {
                radius: "s",
                className: ad().coverContainer,
                children: (0, s.jsx)(as.Shimmer, { className: ad().shimmerCover })
              }),
              (0, s.jsx)("div", { className: ad().description, children: C2 })
            ]
          })
        );
        return (0, s.jsxs)("section", {
          style: p2.isAdvertShown ? void 0 : b2,
          className: (0, c.$)(ad().root, a2),
          onClick: A2,
          ...(0, R.Am)(R.e8.player.MOBILE_PLAYERBAR),
          children: [
            (0, s.jsx)(tS.q, {
              children: (0, s.jsx)(v.Heading, {
                variant: "h3",
                id: t9,
                children: (0, s.jsx)(m.A, { id: "a11y-regions.player" })
              })
            }),
            !d2.isGenerativeContext && (0, s.jsx)(G.v, {
              className: ad().backgroundProgress,
              sliderClassName: ad().sliderChangeTimeCode,
              isMobile: true,
              isFullscreen: false,
              disabled: !i2
            }),
            (0, s.jsxs)("div", {
              className: ad().info,
              children: [
                N2,
                (0, s.jsxs)("div", {
                  className: ad().infoButtons,
                  children: [
                    i2 && g2 && !p2.isAdvertShown && (0, s.jsx)(h.aQ, {
                      fallback: (0, s.jsx)(h.cy, {
                        isLiked: r2,
                        iconSize: "xs",
                        onClick: l2,
                        disabled: !o2.isAuthorized
                      })
                    }),
                    (0, s.jsx)(I.$u, { isMobile: true, entityMeta: i2 })
                  ]
                })
              ]
            })
          ]
        });
      }), am = (0, d.PA)((e10) => {
        let { className: t10 } = e10, {
          settings: { isMobile: a2 },
          sonataState: i2,
          fullscreenPlayer: r2
        } = (0, n.Pjs)(), {
          isLiked: l2,
          handleLike: o2,
          isDisliked: d2,
          handleDislike: m2
        } = (() => {
          var e11, t11;
          let { sonataState: a3 } = (0, n.Pjs)(), i3 = (0, E.KX)(a3.entityMeta), r3 = (0, E.mW)(a3.entityMeta), {
            isGenerativeLiked: l3,
            isGenerativeDisliked: o3,
            onGenerativeLikeClick: s2,
            onGenerativeDislikeClick: c2
          } = (0, tX.nD)();
          return a3.isGenerativeContext ? { isLiked: l3, isDisliked: o3, handleLike: s2, handleDislike: c2 } : {
            isLiked: null == (e11 = a3.entityMeta) ? void 0 : e11.isLiked,
            isDisliked: null == (t11 = a3.entityMeta) ? void 0 : t11.isDisliked,
            handleLike: i3,
            handleDislike: r3
          };
        })(), _2 = (0, n.zwV)(), p2 = (0, Y.c)(() => {
          if (i2.entityMeta) {
            if (r2.modal.isOpened) return void r2.modal.close();
            r2.modal.open();
          }
        });
        return (0, u.useEffect)(() => {
          if (!i2.isGenerativeContext)
            return null == _2 || _2.addShortcutsListener(n.Mo.MAIN, n.lbr.TOGGLE_FULLSCREEN_PLAYER, p2), null == _2 || _2.addShortcutsListener(n.Mo.MAIN, n.lbr.LIKE, o2), null == _2 || _2.addShortcutsListener(n.Mo.MAIN, n.lbr.DISLIKE, m2), () => {
              null == _2 || _2.removeShortcutsListener(n.Mo.MAIN, n.lbr.TOGGLE_FULLSCREEN_PLAYER), null == _2 || _2.removeShortcutsListener(n.Mo.MAIN, n.lbr.LIKE), null == _2 || _2.removeShortcutsListener(n.Mo.MAIN, n.lbr.DISLIKE);
            };
        }, [m2, o2, _2, i2.isGenerativeContext, i2.entityMeta, p2]), (0, s.jsxs)(s.Fragment, {
          children: [
            (0, s.jsx)(a2 ? au : ao, {
              className: (0, c.$)(t10, t5().root),
              entityMeta: i2.entityMeta,
              isLiked: l2,
              isDisliked: d2,
              onDislikeClick: m2,
              onLikeClick: o2
            }),
            (0, s.jsx)(t1, { className: t5().adPopup }),
            (0, s.jsx)(tH.M, {}),
            (0, s.jsx)(t3, {})
          ]
        });
      });
      var a_ = a(62937), ap = a.n(a_);
      let av = (0, d.PA)((e10) => {
        let { entityMeta: t10, onLikeClick: a2, className: i2 } = e10, {
          promolanding: { state: r2 }
        } = (0, n.Pjs)(), l2 = ae(t10), o2 = (0, I.d0)(), d2 = (0, Y.c)(async (e11) => {
          await o2(r2, e11, n.V_r.PROMO_LANDING);
        }), u2 = (0, Y.c)((e11) => {
          r2.setVolume(e11);
        }), _2 = (0, J.L)(
          () => t10 ? (0, s.jsx)(k.j7, {
            track: t10,
            withSecondaryColor: true,
            withAlbumLink: false,
            withTrackLink: false,
            withArtistLink: false
          }) : null
        );
        return (0, s.jsxs)("section", {
          style: l2,
          className: (0, c.$)(ap().root, i2),
          "aria-labelledby": t9,
          ...(0, R.Am)(R.e8.player.PROMOLANDING_PLAYERBAR_DESKTOP),
          children: [
            (0, s.jsx)(tS.q, {
              children: (0, s.jsx)(v.Heading, {
                variant: "h3",
                id: t9,
                children: (0, s.jsx)(m.A, { id: "a11y-regions.player" })
              })
            }),
            t10 && (0, s.jsxs)("div", {
              className: ap().info,
              children: [
                (0, s.jsxs)("div", {
                  className: ap().infoCard,
                  children: [
                    (0, s.jsx)(tu.Paper, {
                      radius: "s",
                      className: ap().coverContainer,
                      children: (0, s.jsx)(h.BW, {
                        className: ap().cover,
                        src: t10.coverUri,
                        size: 100,
                        fit: "cover",
                        withAvatarReplace: true
                      })
                    }),
                    (0, s.jsx)("div", { className: ap().description, children: _2 })
                  ]
                }),
                (0, s.jsx)("div", {
                  className: ap().infoButtons,
                  children: (0, s.jsx)(h.cy, {
                    className: ap().likeButton,
                    isLiked: t10.isLiked,
                    onClick: a2,
                    iconSize: "xs"
                  })
                })
              ]
            }),
            (0, s.jsxs)("div", {
              className: ap().sonata,
              children: [
                (0, s.jsx)(I.jh, { isMobile: false, entityMeta: t10 }),
                (0, s.jsx)(G.v, {
                  disabled: !t10,
                  isMobile: false,
                  isFullscreen: false,
                  sonataPlaybackId: n.V_r.PROMO_LANDING
                })
              ]
            }),
            (0, s.jsx)("div", {
              className: ap().meta,
              children: (0, s.jsx)(t7.r, {
                sonataVolume: r2.volume,
                onVolumeSet: u2,
                onVolumeClick: d2,
                playbackId: n.V_r.PROMO_LANDING
              })
            })
          ]
        });
      }), ah = (0, d.PA)((e10) => {
        let { onLikeClick: t10, entityMeta: a2, className: i2 } = e10, r2 = ae(a2), l2 = (0, J.L)(
          () => a2 ? (0, s.jsx)(k.j7, {
            track: a2,
            withSecondaryColor: true,
            withAlbumLink: false,
            withTrackLink: false,
            withArtistLink: false
          }) : null
        );
        return (0, s.jsxs)("section", {
          style: r2,
          className: (0, c.$)(ad().root, i2),
          children: [
            (0, s.jsx)(tS.q, {
              children: (0, s.jsx)(v.Heading, {
                variant: "h3",
                id: t9,
                children: (0, s.jsx)(m.A, { id: "a11y-regions.player" })
              })
            }),
            (0, s.jsx)(G.v, {
              className: ad().progressBar,
              sliderClassName: ad().progressBar,
              isMobile: true,
              isFullscreen: false,
              disabled: !a2,
              sonataPlaybackId: n.V_r.PROMO_LANDING
            }),
            (0, s.jsxs)("div", {
              className: ad().info,
              children: [
                a2 && (0, s.jsxs)("div", {
                  className: ad().infoCard,
                  children: [
                    (0, s.jsx)(tu.Paper, {
                      radius: "s",
                      className: ad().coverContainer,
                      children: (0, s.jsx)(h.BW, {
                        className: ad().cover,
                        src: a2.coverUri,
                        size: 50,
                        fit: "cover",
                        withAvatarReplace: true
                      })
                    }),
                    (0, s.jsx)("div", { className: ad().description, children: l2 })
                  ]
                }),
                (0, s.jsxs)("div", {
                  className: ad().infoButtons,
                  children: [
                    a2 && (0, s.jsx)(h.cy, { isLiked: a2.isLiked, iconSize: "xs", onClick: t10 }),
                    (0, s.jsx)(I.jh, { isMobile: true, entityMeta: a2 })
                  ]
                })
              ]
            })
          ]
        });
      }), ag = (0, d.PA)((e10) => {
        let { className: t10 } = e10, {
          settings: { isMobile: a2 },
          promolanding: { state: i2 }
        } = (0, n.Pjs)(), r2 = (0, n.zwV)(), l2 = (0, E.c5)(i2.entityMeta);
        (0, u.useEffect)(
          () => (null == r2 || r2.addShortcutsListener(n.Mo.PROMO_LANDING, n.lbr.LIKE, l2), () => {
            null == r2 || r2.removeShortcutsListener(n.Mo.PROMO_LANDING, n.lbr.LIKE);
          }),
          [l2, r2]
        );
        let o2 = (0, J.L)(() => a2 ? ah : av);
        return (0, s.jsx)(o2, { onLikeClick: l2, entityMeta: i2.entityMeta, className: (0, c.$)(t5().root, t10) });
      });
      var ax = a(96020), ay = a.n(ax);
      let ab = (0, d.PA)((e10) => {
        let { className: t10 } = e10, {
          advert: a2,
          user: r2,
          paywall: { modal: l2 }
        } = (0, n.Pjs)(), { notify: o2, dismiss: d2 } = (0, n.lkh)(), { formatMessage: p2 } = (0, O.A)(), g2 = (0, n.zwV)(), x2 = (0, n.rs2)(), [b2, A2] = (0, u.useState)(false), C2 = (0, u.useRef)(null), N2 = (0, u.useCallback)(
          (e11) => {
            e11.stopPropagation(), e11.preventDefault(), l2.open(), A2(true), null == x2 || x2.pauseVideoAdvert(), d2();
          },
          [x2, d2, l2]
        );
        (0, u.useEffect)(() => {
          b2 && !l2.isOpened && (A2(false), null == x2 || x2.resumeVideoAdvert());
        }, [x2, b2, l2.isOpened]);
        let f2 = (0, u.useCallback)(() => {
          o2(
            (0, s.jsx)(h.$W, {
              className: ay().notify,
              message: (0, s.jsx)(v.Caption, {
                className: ay().text,
                variant: "div",
                type: "controls",
                size: "m",
                children: (0, s.jsx)(m.A, { id: "ads.notification" })
              }),
              cover: (0, s.jsx)(D.Icon, { className: ay().icon, variant: "plusColor" }),
              coverRadius: "round",
              withDefaultCloseButton: false,
              coverClassName: (0, c.$)(ay().cover, ay().important),
              closeButton: (0, s.jsx)(_.$, {
                className: ay().notifyClose,
                variant: "text",
                color: "primary",
                size: "xxs",
                onClick: N2,
                withRipple: false,
                ref: C2,
                "data-intersection-property-id": "video-ad-button",
                children: (0, s.jsx)(m.A, { id: "ads.disable-ads" })
              })
            }),
            { containerId: n.uQT.AD_INFO }
          );
        }, [N2, o2]);
        if ((0, u.useEffect)(() => {
          if (!r2.hasPlus)
            return null == g2 || g2.addShortcutsListener(n.Mo.MAIN, n.lbr.CLOSE, () => {
              a2.isAdvertShown && a2.isVideoAdvert && f2();
            }), () => {
              null == g2 || g2.removeShortcutsListener(n.Mo.MAIN, n.lbr.CLOSE);
            };
        }, [f2, g2, a2.isAdvertShown, a2.isVideoAdvert, r2.hasPlus]), r2.hasPlus)
          return;
        let I2 = a2.isAdvertShown && a2.isVideoAdvert;
        return (0, s.jsxs)(s.Fragment, {
          children: [
            (0, s.jsx)(K.a, {
              className: (0, c.$)(ay().root, { [ay().root_hidden]: !I2 }, t10),
              contentClassName: ay().content,
              placement: "center",
              showHeader: false,
              closeOnOutsidePress: false,
              escapeKey: false,
              withOverlay: I2,
              open: true,
              lockScroll: I2,
              overlayColor: "full",
              disableGuards: !I2,
              disableFocusTrap: !I2,
              ...(0, R.Am)(R.e8.ad.VIDEO_AD),
              children: (0, s.jsxs)(s.Fragment, {
                children: [
                  (0, s.jsx)(_.$, {
                    className: ay().close,
                    radius: "round",
                    color: "secondary",
                    size: "xxs",
                    icon: (0, s.jsx)(D.Icon, { variant: "close", size: "xxs" }),
                    onClick: f2,
                    "aria-label": p2({ id: "interface-actions.close-ad" }),
                    withRipple: false
                  }),
                  (0, s.jsx)(y, {
                    data: a2.data,
                    mediaContent: (0, s.jsx)("div", {
                      className: ay().videoBlock,
                      id: i.SLOT,
                      children: (0, s.jsx)("video", { id: i.VIDEO, className: ay().video })
                    })
                  })
                ]
              })
            }),
            (0, s.jsx)(U.Notification, {
              enableMultiContainer: true,
              containerId: n.uQT.AD_INFO,
              position: "bottom-center"
            })
          ]
        });
      });
      ab.displayName = "VideoAd";
    },
    32578: (e) => {
      e.exports = {
        collapseButton: "NavbarDesktop_collapseButton__XQh9d",
        root: "NavbarDesktop_root__scYzp",
        logoWrapper: "NavbarDesktop_logoWrapper__89ce6",
        navigation: "NavbarDesktop_navigation__dLUGW",
        navigation_new: "NavbarDesktop_navigation_new__0j8W5",
        navigation_gapFill: "NavbarDesktop_navigation_gapFill__SsWxA",
        navigationGroup: "NavbarDesktop_navigationGroup__eexLF",
        logoLink: "NavbarDesktop_logoLink__KR0Dk",
        logo: "NavbarDesktop_logo__Z4jGx",
        collapseButtonTooltip_hidden: "NavbarDesktop_collapseButtonTooltip_hidden__tFoZZ",
        subTitle: "NavbarDesktop_subTitle__Fqvr4",
        subTitle_withCursorPointer: "NavbarDesktop_subTitle_withCursorPointer__VYJOh",
        title: "NavbarDesktop_title__OrnHN",
        title_animate: "NavbarDesktop_title_animate__XLxaQ",
        animation_show: "NavbarDesktop_animation_show__pRFj9",
        title_collapsed: "NavbarDesktop_title_collapsed__IH9Bc",
        animation_hide: "NavbarDesktop_animation_hide__8VxPs",
        pinsList: "NavbarDesktop_pinsList___jXIM",
        scrollableContainer: "NavbarDesktop_scrollableContainer__HLc9D",
        scrollableContent: "NavbarDesktop_scrollableContent__OyU4P",
        disabledNavigationItem: "NavbarDesktop_disabledNavigationItem__Qp_hs",
        bestRecommendationsModal: "NavbarDesktop_bestRecommendationsModal__l7GD2",
        bestRecommendationsModalHeader: "NavbarDesktop_bestRecommendationsModalHeader__VSi5Y",
        bestRecommendationsModalContent: "NavbarDesktop_bestRecommendationsModalContent__WhwfK",
        bestRecommendationsModalLogo: "NavbarDesktop_bestRecommendationsModalLogo__QnXgm",
        bestRecommendationsModalText: "NavbarDesktop_bestRecommendationsModalText__05Z3M"
      };
    },
    33175: (e) => {
      e.exports = {
        root: "ShareIframeEditor_root__LALvp",
        controls: "ShareIframeEditor_controls__k8vT_",
        iframeCodeInputContainer: "ShareIframeEditor_iframeCodeInputContainer__b4Klq",
        settings: "ShareIframeEditor_settings__UWt51",
        copyButton: "ShareIframeEditor_copyButton___jOz_",
        sizeInputContainer: "ShareIframeEditor_sizeInputContainer__s6PMW",
        iframeCodeInput: "ShareIframeEditor_iframeCodeInput__M9w6E",
        iframeContainer: "ShareIframeEditor_iframeContainer__pgdr5",
        iframe: "ShareIframeEditor_iframe__ky5_o"
      };
    },
    33320: (e) => {
      e.exports = {
        root: "TrailerHeader_root__n8XkZ",
        coverContainer: "TrailerHeader_coverContainer__4R_jG",
        cover: "TrailerHeader_cover__G6BRb",
        iconContainer: "TrailerHeader_iconContainer__QXR64",
        icon: "TrailerHeader_icon__5T0JT",
        textContainer: "TrailerHeader_textContainer__LR03v",
        text: "TrailerHeader_text__BWMLw",
        link: "TrailerHeader_link__kObd5",
        title: "TrailerHeader_title__GuIe0",
        playButton: "TrailerHeader_playButton__MGmhZ",
        playButtonIcon: "TrailerHeader_playButtonIcon__JFbl_",
        shimmerContainer: "TrailerHeader_shimmerContainer__cOsas",
        titleShimmer: "TrailerHeader_titleShimmer__KKn7b",
        descriptionShimmer: "TrailerHeader_descriptionShimmer__WOlY5",
        share: "TrailerHeader_share__5lxh7"
      };
    },
    34528: (e) => {
      e.exports = {
        root: "Trailer_root__c8eG3",
        header: "Trailer_header__FBFMi",
        trackShimmer: "Trailer_trackShimmer__qmCN3",
        albumShimmer: "Trailer_albumShimmer__8RxuC",
        footer: "Trailer_footer__POMTS"
      };
    },
    34942: (e, t, a) => {
      "use strict";
      a.d(t, { mt: () => b, bo: () => l, cF: () => r });
      var i = a(93064), n = a(26433), r = (function(e2) {
        return e2.IDLE = "idle", e2.SUCCESS = "success", e2.ERROR = "error", e2;
      })({});
      let l = i.gK.model({
        modal: n.qt,
        target: i.gK.string,
        isSilent: i.gK.boolean,
        tariffOfferName: i.gK.string,
        offersBatchId: i.gK.string,
        offersPositionIds: i.gK.string,
        serviceSessionId: i.gK.string,
        status: i.gK.enumeration(Object.values(r))
      }).views((e2) => ({
        get isSuccess() {
          return e2.status === r.SUCCESS;
        },
        get isError() {
          return e2.status === r.ERROR;
        }
      })).actions((e2) => ({
        setTarget(t2) {
          e2.target = t2;
        },
        setIsSilent(t2) {
          e2.isSilent = t2;
        },
        setTariffOfferName(t2) {
          e2.tariffOfferName = t2;
        },
        setOffersBatchId(t2) {
          e2.offersBatchId = t2;
        },
        setOffersPositionIds(t2) {
          e2.offersPositionIds = t2;
        },
        setServiceSessionId(t2) {
          e2.serviceSessionId = t2;
        },
        setStatus(t2) {
          e2.status = t2;
        },
        reset() {
          e2.target = "", e2.tariffOfferName = "", e2.offersBatchId = "", e2.offersPositionIds = "", e2.serviceSessionId = "", e2.status = r.IDLE;
        },
        onModalOpenChange(t2) {
          e2.modal.onOpenChange(t2), e2.status === r.SUCCESS && window.location.reload();
        }
      }));
      var o = a(54486), s = a(50420), c = a(28303), d = a(61910), u = a(31500), m = a(62443), _ = a(32692), p = a(74125), v = a(8817);
      let h = null, g = (0, c.PA)((e2) => {
        let {
          className: t2,
          target: a2,
          silent: i2,
          serviceSessionId: n2,
          tariffOfferName: r2,
          offersBatchId: l2,
          offersPositionIds: s2,
          onLoad: c2,
          onSuccess: u2,
          onError: m2,
          onClose: _2
        } = e2, g2 = (0, d.useRef)(null), { theme: x2 } = (0, p.DPo)(), { pwTools: y2 } = (0, p.q4i)(), b2 = (0, p.bBU)(), A = (0, v.c)((e3) => {
          "purchase_data" === e3.type && (null == u2 || u2());
        }), C = (0, v.c)(() => {
          null == m2 || m2();
        }), N = (0, v.c)(() => {
          null == _2 || _2();
        }), f = (0, v.c)((e3) => {
          "loaded" === e3.data.status && (null == c2 || c2());
        }), I = (0, d.useCallback)(async () => {
          if (!y2 || !g2.current) return;
          let { lang: e3, mode: t3, platform: o2, widgetServiceName: c3, authMethod: d2 } = y2.options;
          if (!h)
            try {
              h = await y2.loadManager();
            } catch (e4) {
              N();
              return;
            }
          h.send({
            type: "init",
            options: {
              lang: e3,
              mode: t3,
              platform: o2,
              widgetServiceName: c3,
              authMethod: d2,
              silent: i2,
              usePlusHost: true,
              theme: x2,
              onSuccess: A,
              onError: C,
              onReport: f,
              onClose: N
            }
          });
          let u3 = {
            target: a2,
            eventSessionId: n2,
            tariffOfferName: r2,
            offersBatchId: l2,
            offersPositionIds: s2,
            targetNode: g2.current,
            isTarifficator: true
          }, m3 = await b2();
          null !== m3 && (u3.clid = m3), h.send({ type: "open", options: u3 });
        }, [x2, y2, a2, i2, r2, n2, l2, s2, A, C, f, N, b2]);
        return (0, d.useEffect)(
          () => (I(), () => {
            null == h || h.send({ type: "close" });
          }),
          [I]
        ), (0, o.jsx)("div", { className: t2, ref: g2 });
      });
      var x = a(41584), y = a.n(x);
      let b = (0, c.PA)(() => {
        let { paymentWidgetModal: e2, advert: t2 } = (0, p.Pjs)(), { state: a2, toggleTrue: i2 } = (0, m.e)(false), n2 = (0, p.vUB)();
        (0, d.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        );
        let l2 = (0, d.useCallback)(() => {
          e2.setStatus(r.SUCCESS), n2.track({ label: "WCvtCKnr84oYEPnRuvUo" });
        }, [e2, n2]), c2 = (0, d.useCallback)(() => {
          e2.modal.close(), e2.isSuccess && window.location.reload(), e2.reset();
        }, [e2]), v2 = (0, d.useCallback)(() => {
          e2.setStatus(r.ERROR);
        }, [e2]);
        return (0, o.jsx)(_.a, {
          open: e2.modal.isOpened,
          size: "fitContent",
          placement: "center",
          showHeader: false,
          withAnimation: false,
          className: (0, s.$)(y().root, { [y().root_loaded]: a2, [y().root_level_up]: t2.isAdvertShown }),
          ...(0, u.Am)(u.OA.paymentWidget.PAYMENT_WIDGET),
          contentClassName: y().content,
          overlayColor: "full",
          onOpenChange: e2.onModalOpenChange,
          children: (0, o.jsx)(g, {
            className: y().widget,
            target: e2.target,
            silent: e2.isSilent,
            serviceSessionId: e2.serviceSessionId,
            tariffOfferName: e2.tariffOfferName,
            offersBatchId: e2.offersBatchId,
            offersPositionIds: e2.offersPositionIds,
            onLoad: i2,
            onSuccess: l2,
            onError: v2,
            onClose: c2
          })
        });
      });
    },
    35311: (e) => {
      e.exports = {
        root: "VideoPlayerBarContainerDesktop_root__Aw4GO",
        root_visible: "VideoPlayerBarContainerDesktop_root_visible__F_7vs",
        root_withHoveredCarousel: "VideoPlayerBarContainerDesktop_root_withHoveredCarousel__2gzlW",
        carouselWrapper: "VideoPlayerBarContainerDesktop_carouselWrapper__HN1rc",
        carousel: "VideoPlayerBarContainerDesktop_carousel__15RwT",
        carouselBlock: "VideoPlayerBarContainerDesktop_carouselBlock__8prtL",
        carouselControls: "VideoPlayerBarContainerDesktop_carouselControls__OwWar",
        clipCardTitle: "VideoPlayerBarContainerDesktop_clipCardTitle__4wJ1A",
        important: "VideoPlayerBarContainerDesktop_important__PBP47",
        clipCardArtist: "VideoPlayerBarContainerDesktop_clipCardArtist__XegP0"
      };
    },
    36017: (e) => {
      e.exports = {
        root: "PlusNavbarButton_root__kdY04",
        plusButtonShimmer: "PlusNavbarButton_plusButtonShimmer__6t1go"
      };
    },
    37262: (e) => {
      e.exports = {
        timecode: "ChangeTimecode_timecode__UScFt",
        root: "ChangeTimecode_root__QxEw_",
        root_withTimecode: "ChangeTimecode_root_withTimecode__eJhYI",
        root_mobile: "ChangeTimecode_root_mobile__SzOdx",
        root_fullscreen: "ChangeTimecode_root_fullscreen__FA6r0",
        slider: "ChangeTimecode_slider__P4qmT"
      };
    },
    38117: (e) => {
      e.exports = {
        root: "FullscreenPlayerDesktop_root___8vo1",
        important: "FullscreenPlayerDesktop_important__dGfiL",
        header: "FullscreenPlayerDesktop_header__OBhzq",
        modalContent: "FullscreenPlayerDesktop_modalContent__Zs_LC",
        notification: "FullscreenPlayerDesktop_notification__luD_J",
        closeButton: "FullscreenPlayerDesktop_closeButton__MQ64s"
      };
    },
    38234: (e) => {
      e.exports = {
        backgroundProgressbar: "ChangeTimecodeBackground_backgroundProgressbar__hT_QP",
        progressbar: "ChangeTimecodeBackground_progressbar__M93Ie",
        timecodeGroup: "ChangeTimecodeBackground_timecodeGroup__2VQ1N",
        thumb: "ChangeTimecodeBackground_thumb__vx6J0",
        timecodeGroupCurrent: "ChangeTimecodeBackground_timecodeGroupCurrent__aGlrB",
        important: "ChangeTimecodeBackground_important__OSzLR",
        root_focusVisible: "ChangeTimecodeBackground_root_focusVisible__RLp5i",
        root: "ChangeTimecodeBackground_root__B89FS",
        root_isPlayingTrack: "ChangeTimecodeBackground_root_isPlayingTrack__2naHL",
        brandedThumb: "ChangeTimecodeBackground_brandedThumb__igXsO",
        slider: "ChangeTimecodeBackground_slider__Jdu3l"
      };
    },
    39122: (e) => {
      e.exports = {
        icon: "PlayQueueButton_icon__7fc0G",
        icon_active: "PlayQueueButton_icon_active__4A8H2",
        animation_scaled: "PlayQueueButton_animation_scaled__w_Wir",
        scale: "PlayQueueButton_scale__dXShR",
        animation_unscaled: "PlayQueueButton_animation_unscaled__Lt_j9",
        unscale: "PlayQueueButton_unscale__BlmKQ"
      };
    },
    39298: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        artistCaption: "ClipMeta_artistCaption__8RrCD",
        link: "ClipMeta_link__6QadT",
        root: "ClipMeta_root__pqZ6s",
        root_withSecondaryColor: "ClipMeta_root_withSecondaryColor__va_JM",
        explicitMark: "ClipMeta_explicitMark__TmCzw",
        metaContainer: "ClipMeta_metaContainer__023Bj",
        titleContainer: "ClipMeta_titleContainer__dtIm1",
        title: "ClipMeta_title__L6Nwk"
      };
    },
    40139: (e) => {
      e.exports = {
        root: "Pin_root__UyplT",
        ripple: "Pin_ripple__Vzpzs",
        link: "Pin_link__nz6I7",
        root_withoutLink: "Pin_root_withoutLink__fr1XH",
        info: "Pin_info__x_7Zx",
        info_withContextMenu: "Pin_info_withContextMenu__7HX5A",
        info_collapsed: "Pin_info_collapsed__bF9ac",
        info_animated: "Pin_info_animated__AQQZk",
        show: "Pin_show__xSkOa",
        hide: "Pin_hide__RCc9X",
        meta: "Pin_meta__MzX_7",
        contextMenu: "Pin_contextMenu__WGmhp",
        contextMenu_hidden: "Pin_contextMenu_hidden__xksGY",
        title: "Pin_title__Jw5WW",
        subtitle: "Pin_subtitle__rb8Gq",
        cover: "Pin_cover__7ofYY",
        cover_withAnimation: "Pin_cover_withAnimation__2Z2n6",
        show_and_scale: "Pin_show_and_scale__VdNfj"
      };
    },
    41584: (e) => {
      e.exports = {
        root: "PaymentWidgetModal_root__I6Hrp",
        root_loaded: "PaymentWidgetModal_root_loaded__Rzltj",
        root_level_up: "PaymentWidgetModal_root_level_up__pj52G",
        content: "PaymentWidgetModal_content__ifRry",
        widget: "PaymentWidgetModal_widget__cu_gr"
      };
    },
    41730: (e, t, a) => {
      "use strict";
      a.d(t, { T: () => n });
      var i = a(63585);
      function n(e2) {
        return (null == e2 ? void 0 : e2.data.type) === i.K.Artist;
      }
    },
    42653: (e) => {
      e.exports = {
        root: "QualitySettingsModal_root__f3gE2",
        modalContent: "QualitySettingsModal_modalContent__R_JNT",
        overlay: "QualitySettingsModal_overlay__8pjOO",
        button: "QualitySettingsModal_button__BCHBi"
      };
    },
    42701: (e) => {
      e.exports = {
        root: "PinsList_root__LN_2Z",
        root_withScroll: "PinsList_root_withScroll__g8x3V",
        root_hasPins: "PinsList_root_hasPins__3LXlo",
        content: "PinsList_content__9RG7s",
        pin_enter: "PinsList_pin_enter__2p2_6",
        pin_enter_active: "PinsList_pin_enter_active__eNGlc",
        "enter-fade": "PinsList_enter-fade__G_QY8",
        "enter-move": "PinsList_enter-move__DSAXH",
        pin_exit: "PinsList_pin_exit__y_gcM",
        pin_exit_active: "PinsList_pin_exit_active__rF5Je",
        "exit-fade": "PinsList_exit-fade__M6fYX",
        "exit-move": "PinsList_exit-move__Jtgi0"
      };
    },
    44123: (e) => {
      e.exports = {
        root: "PlayerBarDesktopWithBackgroundProgressBar_root__bpmwN",
        important: "PlayerBarDesktopWithBackgroundProgressBar_important__HzXrK",
        ripple: "PlayerBarDesktopWithBackgroundProgressBar_ripple__FcmrF",
        progressBar: "PlayerBarDesktopWithBackgroundProgressBar_progressBar___Q6eK",
        slider: "PlayerBarDesktopWithBackgroundProgressBar_slider__SezFn",
        player: "PlayerBarDesktopWithBackgroundProgressBar_player__ASKKs",
        playerBar: "PlayerBarDesktopWithBackgroundProgressBar_playerBar__mp0p9",
        info: "PlayerBarDesktopWithBackgroundProgressBar_info__YnvZ_",
        infoCard: "PlayerBarDesktopWithBackgroundProgressBar_infoCard__i0cbW",
        coverContainer: "PlayerBarDesktopWithBackgroundProgressBar_coverContainer__dkNCG",
        cover: "PlayerBarDesktopWithBackgroundProgressBar_cover__MKmEt",
        description: "PlayerBarDesktopWithBackgroundProgressBar_description__5jHke",
        artists: "PlayerBarDesktopWithBackgroundProgressBar_artists__wKsF6",
        artistLink: "PlayerBarDesktopWithBackgroundProgressBar_artistLink__l9Bk_",
        infoButtons: "PlayerBarDesktopWithBackgroundProgressBar_infoButtons__OxPBy",
        sonata: "PlayerBarDesktopWithBackgroundProgressBar_sonata__mGFb_",
        meta: "PlayerBarDesktopWithBackgroundProgressBar_meta__FhKTC",
        sonataControls: "PlayerBarDesktopWithBackgroundProgressBar_sonataControls__rSmXQ",
        settingsButton: "PlayerBarDesktopWithBackgroundProgressBar_settingsButton__HnCgK",
        trackContextMenuIcon: "PlayerBarDesktopWithBackgroundProgressBar_trackContextMenuIcon__xBJxI",
        triggerModal: "PlayerBarDesktopWithBackgroundProgressBar_triggerModal__EVv5d"
      };
    },
    44342: (e) => {
      e.exports = { root: "TrailerTrack_root__0UIP4", root_active: "TrailerTrack_root_active__F_8Iw" };
    },
    45944: (e) => {
      e.exports = {
        root: "QualitySettings_root__bsEFH",
        root_withEqualizer: "QualitySettings_root_withEqualizer__KF0Ng",
        root_withNewQuality: "QualitySettings_root_withNewQuality__wP_x5",
        header: "QualitySettings_header__azQ0H",
        list: "QualitySettings_list__ggzI6",
        equalizer: "QualitySettings_equalizer__bt11k",
        headerWithCloseButton: "QualitySettings_headerWithCloseButton__VHskw",
        itemWrapper: "QualitySettings_itemWrapper__3KKwt",
        item: "QualitySettings_item__2SGU_",
        item_option: "QualitySettings_item_option__KuE4e",
        item_type: "QualitySettings_item_type___96WF",
        expandedItem: "QualitySettings_expandedItem__kCxQb",
        itemSubTitle: "QualitySettings_itemSubTitle__rNJL_",
        menuContent: "QualitySettings_menuContent__SzqoC",
        button_active: "QualitySettings_button_active__Nivv_"
      };
    },
    47840: (e) => {
      e.exports = {
        line: "SyncLyricsScroller_line__Vh6WN",
        counter: "SyncLyricsScroller_counter__B2E7K",
        counterLine: "SyncLyricsScroller_counterLine__NpBT4",
        root: "SyncLyricsScroller_root__amiLm",
        root_withVisibleUpperLyrics: "SyncLyricsScroller_root_withVisibleUpperLyrics__d7noO",
        root_withVisibleScrolledLyrics: "SyncLyricsScroller_root_withVisibleScrolledLyrics__lowGE",
        root_intro: "SyncLyricsScroller_root_intro__13gls",
        root_outro: "SyncLyricsScroller_root_outro__XlDH5",
        line_last: "SyncLyricsScroller_line_last__liS_1",
        root_prepare: "SyncLyricsScroller_root_prepare__h0Gf1",
        line_active: "SyncLyricsScroller_line_active__6lLvH"
      };
    },
    48167: (e) => {
      e.exports = {
        modalHeader: "CommunicationModal_modalHeader__TnzU6",
        modalContent: "CommunicationModal_modalContent__d8REH",
        container: "CommunicationModal_container__BIgb7",
        wrapper: "CommunicationModal_wrapper__SRy17",
        imageWrapper: "CommunicationModal_imageWrapper__LOr5C",
        imageWrapper_content: "CommunicationModal_imageWrapper_content__PfjQl",
        imageWrapper_header: "CommunicationModal_imageWrapper_header__8wsRZ",
        image: "CommunicationModal_image__qzXK8",
        title: "CommunicationModal_title__yvFAn",
        text: "CommunicationModal_text__gGaLU",
        buttons: "CommunicationModal_buttons__MDmp2",
        disclaimerWrapper: "CommunicationModal_disclaimerWrapper__pMRYf",
        disclaimer: "CommunicationModal_disclaimer__NJJSA",
        disclaimerLink: "CommunicationModal_disclaimerLink__8yuBO",
        root: "CommunicationModal_root__1dOYE",
        root_modal: "CommunicationModal_root_modal__u_igG",
        button: "CommunicationModal_button__qysqU",
        root_fullscreen: "CommunicationModal_root_fullscreen__41Y5Y",
        gradientOverlay: "CommunicationModal_gradientOverlay__MOg5g",
        buttonText: "CommunicationModal_buttonText__2XS8u",
        closeButton: "CommunicationModal_closeButton__EP7ay",
        closeButtonIcon: "CommunicationModal_closeButtonIcon__ujXug"
      };
    },
    48910: (e) => {
      e.exports = { root: "DownloadMobileAppModal_root__nD7fo", content: "DownloadMobileAppModal_content__4ZW2F" };
    },
    49230: (e) => {
      e.exports = { root: "TrackModalAlbum_root__ux7J4", title: "TrackModalAlbum_title__CtM2_" };
    },
    49324: (e, t, a) => {
      "use strict";
      a.d(t, { Fp: () => tw, _1: () => B, Yp: () => y });
      var i, n, r, l, o, s, c, d, u, m, _ = a(1365), p = a(61910), v = a.t(p, 2), h = a(69306), g = a(74125);
      let x = (e10) => window.innerWidth < (e10 ? 1920 : 1024), y = () => {
        let { sideBannerRef: e10 } = (0, g.gKY)(), {
          advertBanners: {
            banners: { sideAdvertBanner: t2 }
          }
        } = (0, g.Pjs)(), a2 = (0, h.y)(), i2 = e10 ? !!(t2.isVisible && e10.clientWidth) : a2, [n2, r2] = (0, p.useState)(x(i2)), l2 = (0, p.useMemo)(
          () => (0, _.A)(
            () => {
              r2(x(i2));
            },
            100,
            { trailing: false }
          ),
          [r2, i2]
        );
        return (0, p.useEffect)(
          () => (window.addEventListener("resize", l2), l2(), () => {
            window.removeEventListener("resize", l2);
          }),
          [l2]
        ), n2;
      };
      var b = a(93064), A = a(60049), C = a(46423), N = a(63695), f = a(13611), I = a(76866);
      let S = b.gK.model("PinAlbumItemModel", { type: b.gK.literal(A._.ALBUM_ITEM), data: C.GI }), T = b.gK.model("PinArtistItemModel", { type: b.gK.literal(A._.ARTIST_ITEM), data: N.PK }), P = b.gK.model("PinPlaylistItemModel", { type: b.gK.literal(A._.PLAYLIST_ITEM), data: f.$o }), k = b.gK.model("PinVibeItemModel", { type: b.gK.literal(A._.WAVE_ITEM), data: I.Gh }), E = b.gK.union(S, T, P, k), j = (e10) => "object" == typeof e10 && e10 && "type" in e10;
      var L = a(94376), w = a(83909);
      let M = (e10) => {
        switch (e10.type) {
          case A._.WAVE_ITEM:
            return (0, b.wg)({ type: A._.WAVE_ITEM, data: (0, I.er)(e10.data) });
          case A._.PLAYLIST_ITEM:
            return (0, b.wg)({ type: A._.PLAYLIST_ITEM, data: (0, w.bk)({ playlist: e10.data }) });
          case A._.ARTIST_ITEM:
            return (0, b.wg)({ type: A._.ARTIST_ITEM, data: (0, N.as)({ artist: e10.data }) });
          case A._.ALBUM_ITEM:
            return (0, b.wg)({ type: A._.ALBUM_ITEM, data: (0, L.sK)({ album: e10.data }) });
        }
      }, B = b.gK.model("Pins", {
        loadingState: b.gK.enumeration(Object.values(g.GuX)),
        items: b.gK.maybeNull(b.gK.array(E)),
        index: b.gK.map(b.gK.boolean)
      }).views((e10) => ({
        isPinned: (t2) => !!e10.index.get(t2),
        get(t2) {
          var a2;
          return null == (a2 = e10.items) ? void 0 : a2.find((e11) => e11.data.pinId === t2);
        }
      })).actions((e10) => {
        let t2 = {
          deletePin(t3) {
            var a2;
            e10.items = (0, b.wg)(null == (a2 = e10.items) ? void 0 : a2.filter((e11) => e11.data.pinId !== t3)), e10.index.delete(t3);
          },
          addPin(t3) {
            var a2, i2, n2, r2;
            if ((null == (a2 = e10.items) ? void 0 : a2.length) === 30) {
              let t4 = null == (r2 = e10.items) ? void 0 : r2.pop();
              void 0 !== t4 && e10.index.delete(t4.data.pinId);
            }
            null == (i2 = e10.items) || i2.unshift(M(t3));
            let l2 = null == (n2 = e10.items) ? void 0 : n2.at(0);
            l2 && e10.index.set(l2.data.pinId, true);
          },
          getData: (0, b.L3)(function* () {
            let { pinsResource: t3, modelActionsLogger: a2 } = (0, b._$)(e10);
            if (e10.loadingState !== g.GuX.PENDING)
              try {
                var i2;
                e10.loadingState = g.GuX.PENDING;
                let a3 = yield t3.getPins();
                e10.items = (0, b.wg)(a3.pins.map(M)), null == (i2 = e10.items) || i2.forEach((t4) => {
                  e10.index.set(t4.data.pinId, true);
                }), e10.loadingState = g.GuX.RESOLVE;
              } catch (t4) {
                e10.loadingState = g.GuX.REJECT, a2.error(t4);
              }
          }),
          toggleAlbumPin: (0, b.L3)(function* (a2, i2) {
            let { pinResource: n2, modelActionsLogger: r2 } = (0, b._$)(e10);
            if (e10.loadingState !== g.GuX.PENDING)
              try {
                let r3;
                if (e10.isPinned(i2)) return r3 = yield n2.unpinAlbum(a2), t2.deletePin(i2), r3;
                return r3 = yield n2.pinAlbum(a2), j(r3) && t2.addPin(r3), r3;
              } catch (e11) {
                r2.error(e11);
                return;
              }
          }),
          toggleArtistPin: (0, b.L3)(function* (a2, i2) {
            let { pinResource: n2, modelActionsLogger: r2 } = (0, b._$)(e10);
            if (e10.loadingState !== g.GuX.PENDING)
              try {
                let r3;
                if (e10.isPinned(i2)) return r3 = yield n2.unpinArtist(a2), t2.deletePin(i2), r3;
                return r3 = yield n2.pinArtist(a2), j(r3) && t2.addPin(r3), r3;
              } catch (e11) {
                r2.error(e11);
                return;
              }
          }),
          togglePlaylistPin: (0, b.L3)(function* (a2, i2) {
            let { pinResource: n2, modelActionsLogger: r2 } = (0, b._$)(e10);
            if (e10.loadingState !== g.GuX.PENDING)
              try {
                let r3;
                if (e10.isPinned(i2)) return r3 = yield n2.unpinPlaylist(a2), t2.deletePin(i2), r3;
                return r3 = yield n2.pinPlaylist(a2), j(r3) && t2.addPin(r3), r3;
              } catch (e11) {
                r2.error(e11);
                return;
              }
          }),
          toggleVibePin: (0, b.L3)(function* (a2, i2) {
            let { pinResource: n2, modelActionsLogger: r2 } = (0, b._$)(e10);
            if (e10.loadingState !== g.GuX.PENDING)
              try {
                let r3;
                if (e10.isPinned(i2)) return r3 = yield n2.unpinWave(a2), t2.deletePin(i2), r3;
                return r3 = yield n2.pinWave(a2), j(r3) && t2.addPin(r3), r3;
              } catch (e11) {
                r2.error(e11);
                return;
              }
          })
        };
        return t2;
      });
      var O = a(54486), R = a(50420), D = a(28303), K = a(31500), U = a(8817), F = a(43350), z = a(62395), V = a(68529), W = a.n(V), G = a(43426), Y = a(47713), Q = a(77881), $ = a(5956), q = a(14342), H = a(32692), X = {
        5881: (e10, t2, a2) => {
          function i2() {
            for (var e11, t3, a3 = 0, i3 = ""; a3 < arguments.length; )
              (e11 = arguments[a3++]) && (t3 = (function e12(t4) {
                var a4, i4, n3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) n3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (a4 = 0; a4 < t4.length; a4++) t4[a4] && (i4 = e12(t4[a4])) && (n3 && (n3 += " "), n3 += i4);
                  else for (a4 in t4) t4[a4] && (n3 && (n3 += " "), n3 += a4);
                return n3;
              })(e11)) && (i3 && (i3 += " "), i3 += t3);
            return i3;
          }
          a2.r(t2), a2.d(t2, { clsx: () => i2, default: () => n2 });
          let n2 = i2;
        },
        2408: (e10, t2, a2) => {
          a2.r(t2), a2.d(t2, { default: () => i2 });
          let i2 = {
            root: "NGdj0oZ2Bt8qdZhP2Tzt",
            root_collapsed: "rece5errcONnjJeX0YW8",
            root_direction_vertical: "QilmoKKJwk6f0BdkYgrA",
            root_direction_horizontal: "AO4rWY4RLVh48fwQw5Qs"
          };
        },
        1308: (e10, t2, a2) => {
          a2.r(t2), a2.d(t2, { default: () => i2 });
          let i2 = {
            root: "yuyI2hMAT7qyL1N14MAQ",
            root_direction_vertical: "xfFtKQpgAYvC2jI1tBtS",
            root_direction_horizontal: "OGlYJO0lZgpSOhfU2Iru"
          };
        },
        2056: (e10, t2, a2) => {
          a2.r(t2), a2.d(t2, { default: () => i2 });
          let i2 = {
            root: "Bp1d3U6W8Nrbqi3MRQS_",
            root_direction_vertical: "hYfgO_Y8c4rrQsZJWTDZ",
            ripple: "UiZ4QyGEVzfvZ3QfQqqA",
            root_direction_horizontal: "X_Lr5kqrhzMO6kX8v92s",
            root_collapsed: "Q3gGGaIXiJ_oQTiVZBfl",
            root_variant_main: "H4trq_Zx2d9qOnQgxmxr",
            root_animate: "Kr9rXeXGlqHee2euqH0u",
            animation_width: "k8zKIZRDy6LmoaIcEpo8",
            item: "A4bDkbQHkwWNGqxO9qhW",
            item_selected: "mAd9pgMkWVX5ktCgYINQ",
            item_direction_vertical: "Xx9Tg5ugzg1pkf8Zh421",
            item_direction_horizontal: "fQVXazc9HwT3NQ8dywCh",
            iconContainer: "zpkgiiHgDpbBThy6gavq",
            textContainer: "ZrkG6gNYcr4h3hfkhyT1",
            textContainer_selected: "xENlRAFvRskKnt8LUObC",
            textContainer_direction_horizontal: "xE5fIMRnjd8oSm5BOhpI"
          };
        },
        5408: (e10, t2, a2) => {
          a2.r(t2), a2.d(t2, { default: () => i2 });
          let i2 = {
            root: "HcfYy4VfnRHqgXzIdL7w",
            root_direction_vertical: "kRmUIkcHKD5AgtpPo8wT",
            ripple: "aHtf5XL4YejhYEJNUkYi",
            root_direction_horizontal: "ZxlCWb78gIBQ8izioAXa",
            root_collapsed: "e1KYSvMXXv0FD4s_yCuw",
            item: "ZfF8mQ3Iftpwu0aZgDtG",
            item_selected: "Eg3pt5lTL33sOlxorSbN",
            item_direction_vertical: "yWJHrpNsBvchs9Jjyokk",
            item_direction_horizontal: "bJ7YpssStK5UnpbuTtf2",
            item_collapsed_vertical: "uw57VJ37U4rAAHDs0zJR",
            iconContainer: "_YzsXZGNK8KeaUFC4Ja1",
            textContainer: "nxMXCBiVfgH4oxds3f2y",
            textContainer_selected: "jhnLSZpmG69Hlxi8n6IO",
            textContainer_direction_horizontal: "FH36Kh9OP4VHc2Yv3bIc"
          };
        },
        9097: (e10, t2) => {
          var a2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function i2(e11, t3, i3) {
            var n2 = null;
            if (void 0 !== i3 && (n2 = "" + i3), void 0 !== t3.key && (n2 = "" + t3.key), "key" in t3)
              for (var r2 in i3 = {}, t3) "key" !== r2 && (i3[r2] = t3[r2]);
            else i3 = t3;
            return { $$typeof: a2, type: e11, key: n2, ref: void 0 !== (t3 = i3.ref) ? t3 : null, props: i3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = i2, t2.jsxs = i2;
        },
        4377: (e10, t2, a2) => {
          e10.exports = a2(9097);
        },
        8796: (e10, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.createRipple = void 0, t2.createRipple = function(e11, t3, a2) {
            let i2 = null != a2 ? a2 : e11.currentTarget, n2 = document.createElement("span"), r2 = Math.max(i2.clientWidth, i2.clientHeight), l2 = r2 / 2, o2 = i2.getBoundingClientRect(), s2 = 0 === e11.clientX ? Math.round(o2.width / 2) : e11.clientX - o2.left, c2 = 0 === e11.clientY ? Math.round(o2.height / 2) : e11.clientY - o2.top;
            n2.style.width = "".concat(r2, "px"), n2.style.height = "".concat(r2, "px"), n2.style.left = 0 === e11.clientX ? "0px" : "".concat(s2 - l2, "px"), n2.style.top = "".concat(c2 - l2, "px"), n2.classList.add(t3);
            let d2 = i2.getElementsByClassName(t3)[0];
            d2 && d2.remove(), i2.insertBefore(n2, i2.firstChild);
          };
        },
        361: (e10, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e11) => {
            if (void 0 !== e11) {
              if (null === e11 || e11 instanceof HTMLElement) return e11;
              if (null === e11.current || e11.current instanceof HTMLElement) return e11.current;
            }
          };
        },
        8216: (e10, t2, a2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = t2.createRipple = void 0;
          var i2 = a2(8796);
          Object.defineProperty(t2, "createRipple", {
            enumerable: true,
            get: function() {
              return i2.createRipple;
            }
          });
          var n2 = a2(361);
          Object.defineProperty(t2, "getElementFromRefOrElement", {
            enumerable: true,
            get: function() {
              return n2.getElementFromRefOrElement;
            }
          });
        },
        19: function(e10, t2, a2) {
          var i2 = this && this.__importDefault || function(e11) {
            return e11 && e11.__esModule ? e11 : { default: e11 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Navigation = void 0;
          let n2 = a2(4377), r2 = a2(5881), l2 = a2(7786), o2 = i2(a2(2408));
          t2.Navigation = function(e11) {
            let { className: t3, children: a3, collapsed: i3 = false, direction: s2 = "vertical", ...c2 } = e11;
            return (0, n2.jsx)(l2.NavigationProvider, {
              collapsed: i3,
              direction: s2,
              children: (0, n2.jsx)("nav", {
                className: (0, r2.clsx)(
                  o2.default.root,
                  o2.default["root_direction_".concat(s2)],
                  { [o2.default.root_collapsed]: i3 },
                  t3
                ),
                "aria-label": c2["aria-label"],
                ...c2,
                children: a3
              })
            });
          };
        },
        7786: (e10, t2, a2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.NavigationProvider = t2.NavigationContext = void 0;
          let i2 = a2(4377), n2 = a2(810);
          t2.NavigationContext = (0, n2.createContext)({ collapsed: false, direction: "vertical" }), t2.NavigationProvider = (e11) => {
            let { collapsed: a3, direction: r2, children: l2 } = e11, o2 = (0, n2.useMemo)(() => ({ collapsed: a3, direction: r2 }), [a3, r2]);
            return (0, i2.jsx)(t2.NavigationContext.Provider, { value: o2, children: l2 });
          };
        },
        8106: function(e10, t2, a2) {
          var i2 = this && this.__importDefault || function(e11) {
            return e11 && e11.__esModule ? e11 : { default: e11 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.NavigationGroup = void 0;
          let n2 = a2(4377), r2 = a2(810), l2 = a2(5881), o2 = a2(7786), s2 = i2(a2(1308));
          t2.NavigationGroup = function(e11) {
            let { className: t3, children: a3, ...i3 } = e11, c2 = (0, r2.createRef)(), { direction: d2 } = (0, r2.useContext)(o2.NavigationContext);
            return (0, n2.jsx)("ol", {
              ref: c2,
              className: (0, l2.clsx)(s2.default.root, s2.default["root_direction_".concat(d2)], t3),
              ...i3,
              children: a3
            });
          };
        },
        3506: function(e10, t2, a2) {
          var i2 = this && this.__importDefault || function(e11) {
            return e11 && e11.__esModule ? e11 : { default: e11 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.NavigationItem = t2.NavigationItemComponent = void 0;
          let n2 = a2(4377), r2 = a2(810), l2 = a2(5881), o2 = a2(7786), s2 = a2(8216), c2 = i2(a2(2056)), d2 = i2(a2(5408));
          function u2(e11) {
            let {
              className: t3 = "",
              forwardRef: a3,
              children: i3,
              selected: u3 = false,
              shownAnimation: m2,
              withRipple: _2 = false,
              variant: p2 = "default",
              isNewVisualVersion: v2,
              ...h2
            } = e11, { collapsed: g2, direction: x2 } = (0, r2.useContext)(o2.NavigationContext), y2 = v2 ? d2.default : c2.default, b2 = (0, r2.useCallback)(
              (e12) => {
                _2 && (0, s2.createRipple)(e12, y2.ripple);
              },
              [y2.ripple, _2]
            ), [A2, C2] = r2.Children.toArray(i3.props.children), N2 = (0, r2.useMemo)(
              () => (0, n2.jsxs)(n2.Fragment, {
                children: [
                  (0, n2.jsx)("div", { className: y2.iconContainer, children: A2 }),
                  (0, n2.jsx)("div", {
                    className: (0, l2.clsx)(y2.textContainer, y2["textContainer_direction_".concat(x2)], {
                      [y2.textContainer_selected]: u3
                    }),
                    children: C2
                  })
                ]
              }),
              [y2, A2, x2, u3, C2]
            ), f2 = (0, r2.cloneElement)(i3, {
              className: (0, l2.clsx)(
                y2.item,
                y2["item_direction_".concat(x2)],
                { [y2.item_selected]: u3, [y2["item_collapsed_".concat(x2)]]: g2 },
                i3.props.className
              ),
              children: N2
            });
            return (0, n2.jsx)("li", {
              ref: a3,
              className: (0, l2.clsx)(
                y2.root,
                y2["root_direction_".concat(x2)],
                y2["root_variant_".concat(p2)],
                { [y2.root_animate]: m2, [y2.root_collapsed]: g2 },
                t3
              ),
              "aria-current": !!u3 && "page",
              onClick: b2,
              ...h2,
              children: f2
            });
          }
          t2.NavigationItemComponent = u2, t2.NavigationItem = (0, r2.forwardRef)((e11, t3) => (0, n2.jsx)(u2, { forwardRef: t3, ...e11 }));
        },
        810: (e10) => {
          e10.exports = v;
        }
      }, Z = {};
      function J(e10) {
        var t2 = Z[e10];
        if (void 0 !== t2) return t2.exports;
        var a2 = Z[e10] = { exports: {} };
        return X[e10].call(a2.exports, a2, a2.exports, J), a2.exports;
      }
      J.d = (e10, t2) => {
        for (var a2 in t2) J.o(t2, a2) && !J.o(e10, a2) && Object.defineProperty(e10, a2, { enumerable: true, get: t2[a2] });
      }, J.o = (e10, t2) => Object.prototype.hasOwnProperty.call(e10, t2), J.r = (e10) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e10, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e10, "__esModule", { value: true });
      };
      var ee = {};
      (() => {
        Object.defineProperty(ee, "X$", { value: true }), ee.Dx = ee.KB = ee.W_ = void 0;
        var e10 = J(19);
        Object.defineProperty(ee, "W_", {
          enumerable: true,
          get: function() {
            return e10.Navigation;
          }
        });
        var t2 = J(8106);
        Object.defineProperty(ee, "KB", {
          enumerable: true,
          get: function() {
            return t2.NavigationGroup;
          }
        });
        var a2 = J(3506);
        Object.defineProperty(ee, "Dx", {
          enumerable: true,
          get: function() {
            return a2.NavigationItem;
          }
        });
      })();
      var et = ee.W_, ea = ee.KB, ei = ee.Dx;
      ee.X$;
      var en = a(93666), er = a(97800), el = a(51376), eo = a(80585);
      let es = () => {
        let e10 = (0, z.st)(), { hash: t2 } = (0, z.gf)(), a2 = (0, g.UlF)(), { location: i2 } = (0, g.Pjs)();
        return (0, p.useCallback)(
          (n2, r2) => {
            if (!e10 || !t2) return;
            let l2 = (0, F.Fx)({
              params: ((e11) => {
                let { isNotFound: t3, entityType: a3, to: i3, hash: n3 } = e11;
                return t3 ? {
                  entityType: F.LA.Error,
                  entityId: F.LA.Error,
                  hash: n3,
                  pageId: F.QT.PageNotFoundScreen,
                  pageStyle: F.QL.Fullscreen,
                  pagePlacement: F.c4.Fullscreen,
                  mainObjectType: F.ky.NonApplicable,
                  mainObjectId: F.ky.NonApplicable,
                  from: F.QT.PageNotFoundScreen,
                  to: i3
                } : {
                  entityType: a3,
                  entityId: a3,
                  hash: n3,
                  pageId: F.QT.Sidebar,
                  pageStyle: F.QL.Bar,
                  pagePlacement: F.c4.Left,
                  from: F.QT.Sidebar,
                  to: i3
                };
              })({ isNotFound: i2.isNotFound, entityType: n2, to: r2, hash: t2 }),
              logger: a2,
              context: "useSendEventOnNavbarNavigated"
            });
            l2 && (0, F.ID)(e10.evgenInstance, l2);
          },
          [e10, t2, a2, i2.isNotFound]
        );
      }, ec = {
        [g.RnV.SEARCH]: K.e8.navbar.NAVBAR_NAVIGATION_ITEM_SEARCH,
        [g.RnV.HOME]: K.e8.navbar.NAVBAR_NAVIGATION_ITEM_HOME,
        [g.RnV.FOR_YOU_AND_TRENDS]: K.e8.navbar.NAVBAR_NAVIGATION_ITEM_FOR_YOU_AND_TRENDS,
        [g.RnV.CONCERTS]: K.e8.navbar.NAVBAR_NAVIGATION_ITEM_CONCERTS,
        [g.RnV.NON_MUSIC]: K.e8.navbar.NAVBAR_NAVIGATION_ITEM_NON_MUSIC,
        [g.RnV.KIDS]: K.e8.navbar.NAVBAR_NAVIGATION_ITEM_KIDS,
        [g.RnV.COLLECTION]: K.e8.navbar.NAVBAR_NAVIGATION_ITEM_COLLECTION,
        [g.RnV.PLUS]: K.e8.navbar.NAVBAR_NAVIGATION_ITEM_PLUS
      }, ed = (e10) => {
        let { padding: t2, placement: a2 } = e10;
        return {
          shiftOptions: { padding: t2 },
          offsetOptions: t2,
          flipOptions: { fallbackAxisSideDirection: "start", padding: t2 },
          placement: a2
        };
      }, eu = ed({ placement: "right", padding: 8 });
      var em = a(67648), e_ = a(74631), ep = a.n(e_);
      let ev = { width: 20, height: 8, tipRadius: 2, fill: "var(--ym-background-color-primary-enabled-tooltip)" }, eh = (0, D.PA)((e10) => {
        let { config: t2, children: a2 } = e10, { formatMessage: i2 } = (0, G.A)(), {
          settings: { isMobile: n2 }
        } = (0, g.Pjs)(), { compositePlayerBarRef: r2 } = (0, g.gKY)(), { setIsOnboardingOpened: l2 } = (0, g.wD7)(), [o2, s2] = (0, em.d)(), c2 = (0, g.zzi)({ id: t2.id, ref: o2 }), [d2, u2] = (0, p.useState)(c2 && t2.isEnabled), m2 = (0, U.c)((e11) => {
          null == e11 || e11.stopPropagation(), u2(false), l2(false);
        }), _2 = (0, U.c)((e11) => {
          e11 || m2();
        });
        return (0, O.jsxs)(en.m_, {
          placement: n2 ? "top" : "right",
          arrowProps: ev,
          offsetOptions: n2 ? 15 : -10,
          isHoverEnabled: false,
          open: d2,
          onOpenChange: _2,
          enableAriaDescribedby: true,
          referenceRef: s2,
          children: [
            a2,
            (0, O.jsxs)(en.ZI, {
              className: ep().tooltip,
              rootNode: n2 ? r2 : void 0,
              children: [
                (0, O.jsx)(Q.$, {
                  icon: (0, O.jsx)($.Icon, { variant: "close", size: "xxs" }),
                  onClick: m2,
                  variant: "text",
                  withRipple: false,
                  className: ep().button,
                  "aria-label": i2({ id: "interface-actions.close" })
                }),
                (0, O.jsx)(er.Caption, { className: ep().text, variant: "span", children: t2.text })
              ]
            })
          ]
        });
      }), eg = (e10) => {
        let { config: t2, children: a2 } = e10;
        return t2 ? (0, O.jsx)(eh, { config: t2, children: a2 }) : a2;
      };
      var ex = a(53497), ey = a(63664), eb = a(58360), eA = a(6971);
      let eC = () => {
        let e10 = (0, z.st)(), { hash: t2 } = (0, z.gf)(), a2 = (0, g.UlF)(), {
          settings: { isMobile: i2 }
        } = (0, g.Pjs)();
        return (0, p.useCallback)(
          (n2, r2) => {
            if (!e10) return;
            let l2 = (0, F.Fx)({
              params: {
                hash: t2,
                pageId: F.QT.Sidebar,
                sidebarSize: n2 || i2 ? F.JQ.Small : F.JQ.Medium,
                from: F.QT.Sidebar,
                to: r2
              },
              logger: a2,
              context: "useSendEventOnSidebarNavigated"
            });
            l2 && (0, F.qi)(e10.evgenInstance, l2);
          },
          [e10, t2, i2, a2]
        );
      };
      var eN = a(73633), ef = a(40139), eI = a.n(ef);
      let eS = (e10) => {
        let { children: t2, entityUrl: a2, ariaLabel: i2, ...n2 } = e10;
        return a2 ? (0, O.jsx)(eo.N_, { href: a2, "aria-label": i2, className: eI().link, ...n2, children: t2 }) : t2;
      }, eT = (e10) => {
        let {
          className: t2,
          cover: a2,
          title: i2,
          subtitle: n2,
          contextMenu: r2,
          isCollapsed: l2,
          withCollapseAnimation: o2,
          entityUrl: s2,
          onDoubleClick: c2,
          onClick: d2,
          forwardRef: u2,
          ariaLabel: m2
        } = e10, _2 = (0, p.useCallback)(
          (e11) => {
            2 === e11.detail ? null == c2 || c2() : (e11.target instanceof HTMLElement && "IMG" !== e11.target.tagName && (0, eN.P)(e11, eI().ripple), null == d2 || d2(e11));
          },
          [d2, c2]
        );
        return (0, O.jsxs)(eo.Cj, {
          ref: u2,
          className: (0, R.$)(eI().root, { [eI().root_withoutLink]: !s2 }, t2),
          role: "listitem",
          ...(0, K.Am)(K.e8.navbar.PIN_ITEM),
          children: [
            (0, O.jsxs)(eS, {
              entityUrl: s2,
              ariaLabel: m2,
              onClick: _2,
              children: [
                (0, O.jsx)("div", { className: eI().cover, ...(0, K.Am)(K.e8.navbar.PIN_COVER), children: a2 }),
                (0, O.jsx)("div", {
                  className: eI().meta,
                  children: (0, O.jsxs)("div", {
                    className: (0, R.$)(eI().info, {
                      [eI().info_collapsed]: l2,
                      [eI().info_animated]: o2,
                      [eI().info_withContextMenu]: (0, p.isValidElement)(r2)
                    }),
                    children: [
                      (0, O.jsx)(er.Caption, {
                        "aria-hidden": true,
                        className: eI().title,
                        variant: "span",
                        type: "controls",
                        size: "s",
                        lineClamp: 1,
                        ...(0, K.Am)(K.e8.navbar.PIN_TITLE),
                        children: i2
                      }),
                      (0, O.jsx)(er.Caption, {
                        "aria-hidden": true,
                        className: eI().subtitle,
                        variant: "span",
                        type: "controls",
                        size: "s",
                        lineClamp: 1,
                        ...(0, K.Am)(K.e8.navbar.PIN_SUBTITLE),
                        children: n2
                      })
                    ]
                  })
                })
              ]
            }),
            (0, p.isValidElement)(r2) && (0, O.jsx)("div", {
              className: (0, R.$)(eI().contextMenu, { [eI().contextMenu_hidden]: l2 }),
              ...(0, K.Am)(K.e8.navbar.PIN_CONTEXT_MENU_BUTTON),
              children: r2
            })
          ]
        });
      }, eP = (0, p.forwardRef)((e10, t2) => (0, O.jsx)(eT, { forwardRef: t2, ...e10 })), ek = (0, p.createContext)(null);
      var eE = a(11284), ej = a.n(eE), eL = a(61958);
      let ew = () => {
        let e10 = (0, z.st)(), { hash: t2 } = (0, z.gf)(), a2 = (0, g.UlF)(), {
          settings: { isMobile: i2 }
        } = (0, g.Pjs)();
        return (0, p.useCallback)(
          (n2) => {
            let { actionType: r2, isCollapsed: l2, mainObjectType: o2, mainObjectId: s2 } = n2;
            if (!e10) return;
            let c2 = {
              hash: t2,
              actionType: r2,
              user_interaction_type: F.gi.Tap,
              pageId: F.QT.Sidebar,
              sidebarSize: l2 || i2 ? F.JQ.Small : F.JQ.Medium
            };
            o2 && (c2.mainObjectType = o2), s2 && (c2.mainObjectId = s2);
            let d2 = (0, F.Fx)({ params: c2, logger: a2, context: "useSendEventOnSidebarActionPerformed" });
            d2 && (0, F.dL)(e10.evgenInstance, d2);
          },
          [e10, t2, i2, a2]
        );
      }, eM = (e10) => {
        let { onPinClick: t2, isPinned: a2 } = e10, { formatMessage: i2 } = (0, G.A)(), { isCollapsed: n2 } = (0, p.useContext)(ek) || {}, [r2, l2] = (0, p.useState)(false), o2 = ew(), s2 = (0, p.useCallback)((e11) => {
          e11.preventDefault(), e11.stopPropagation();
        }, []), c2 = (0, p.useCallback)(() => {
          t2(), o2({ actionType: F.X2.Unpin, isCollapsed: null != n2 && n2 });
        }, [n2, t2, o2]);
        return (0, g.NBO)(r2), (0, O.jsx)(eL.W1, {
          className: (0, R.$)(ej().contextMenu, { [ej().contextMenu_visible]: r2 }),
          onClick: s2,
          icon: (0, O.jsx)($.Icon, { size: "xxs", variant: "more" }),
          tabIndex: n2 ? -1 : 0,
          "aria-hidden": n2,
          variant: "text",
          offsetOptions: 3,
          open: r2,
          onOpenChange: l2,
          ariaLabel: i2({ id: "interface-actions.context-menu" }),
          containerProps: (0, K.Am)(K.e8.navbar.PIN_CONTEXT_MENU),
          children: (0, O.jsx)(eo.L1, { onClick: c2, isPinned: a2 })
        });
      }, eB = (0, D.PA)((e10) => {
        var t2;
        let { className: a2, album: i2, forwardRef: n2, tooltipOptions: r2 } = e10, { formatMessage: l2 } = (0, G.A)(), { isCollapsed: o2, withCollapseAnimation: s2 } = null != (t2 = (0, p.useContext)(ek)) ? t2 : {}, c2 = (0, C.A7)(i2), d2 = (0, C.r_)(i2.type, C.cr.PIN), u2 = eC(), m2 = (0, C.Rl)(i2.type), _2 = (0, g.ZpR)(i2.url), v2 = (0, C.$1)({ albumId: i2.id, albumUrl: i2.url, callback: _2 }), h2 = (0, C.cp)({ album: i2, callback: v2 }), x2 = (0, U.c)((e11) => {
          u2(null != o2 && o2, m2), h2(e11);
        }), y2 = (0, p.useMemo)(
          () => (0, O.jsx)(eA.Paper, {
            className: ej().cover,
            radius: "xs",
            children: (0, O.jsxs)(en.m_, {
              ...r2,
              enabled: o2,
              children: [
                (0, O.jsx)(eb.Image, {
                  className: ej().image,
                  "aria-hidden": true,
                  src: i2.coverUri,
                  size: 100,
                  fit: "cover",
                  withAvatarReplace: true
                }),
                (0, O.jsx)(en.ZI, {
                  className: ej().tooltip,
                  children: (0, O.jsx)(er.Caption, {
                    variant: "span",
                    type: "text",
                    size: "s",
                    weight: "medium",
                    lineClamp: 1,
                    children: i2.title
                  })
                })
              ]
            })
          }),
          [i2.coverUri, i2.title, o2, r2]
        );
        return (0, O.jsx)(eP, {
          ref: n2,
          ariaLabel: l2({ id: "entity-names.album-name" }, { albumName: i2.title }),
          className: (0, R.$)(ej().root, a2),
          title: i2.title,
          entityUrl: i2.url,
          subtitle: d2,
          cover: y2,
          isCollapsed: !!o2,
          withCollapseAnimation: !!s2,
          contextMenu: (0, O.jsx)(eM, { onPinClick: c2, isPinned: i2.isPinned }),
          onClick: x2
        });
      }), eO = (0, p.forwardRef)((e10, t2) => (0, O.jsx)(eB, { forwardRef: t2, ...e10 })), eR = (0, D.PA)((e10) => {
        var t2;
        let { className: a2, artist: i2, forwardRef: n2, tooltipOptions: r2 } = e10, { formatMessage: l2 } = (0, G.A)(), { isCollapsed: o2, withCollapseAnimation: s2 } = null != (t2 = (0, p.useContext)(ek)) ? t2 : {}, c2 = (0, N.A7)(i2), d2 = eC(), u2 = (0, g.ZpR)(i2.url), m2 = (0, N.SA)({ artist: i2, callback: u2 }), _2 = (0, U.c)((e11) => {
          d2(null != o2 && o2, F.QT.ArtistScreen), m2(e11);
        }), v2 = (0, p.useMemo)(
          () => (0, O.jsx)(eA.Paper, {
            className: ej().cover,
            radius: "round",
            children: (0, O.jsxs)(en.m_, {
              ...r2,
              enabled: o2,
              children: [
                (0, O.jsx)(eb.Image, {
                  className: ej().image,
                  "aria-hidden": true,
                  src: i2.coverUri,
                  size: 100,
                  fit: "cover",
                  withAvatarReplace: true
                }),
                (0, O.jsx)(en.ZI, {
                  className: ej().tooltip,
                  children: (0, O.jsx)(er.Caption, {
                    variant: "span",
                    type: "text",
                    size: "s",
                    weight: "medium",
                    lineClamp: 1,
                    children: i2.name
                  })
                })
              ]
            })
          }),
          [i2.coverUri, i2.name, o2, r2]
        );
        return (0, O.jsx)(eP, {
          ref: n2,
          ariaLabel: l2({ id: "entity-names.artist-name" }, { artistName: i2.name }),
          className: (0, R.$)(ej().root, a2),
          title: i2.name,
          entityUrl: i2.url,
          subtitle: (0, O.jsx)(Y.A, { id: "entity-names.artist" }),
          cover: v2,
          isCollapsed: !!o2,
          withCollapseAnimation: !!s2,
          contextMenu: (0, O.jsx)(eM, { onPinClick: c2, isPinned: i2.isPinned }),
          onClick: _2
        });
      }), eD = (0, p.forwardRef)((e10, t2) => (0, O.jsx)(eR, { forwardRef: t2, ...e10 })), eK = (e10) => {
        var t2;
        let { className: a2, playlist: i2, forwardRef: n2, tooltipOptions: r2 } = e10, { formatMessage: l2 } = (0, G.A)(), { isCollapsed: o2, withCollapseAnimation: s2 } = null != (t2 = (0, p.useContext)(ek)) ? t2 : {}, c2 = (0, f.A7)(i2), d2 = eC(), u2 = (0, U.c)(() => {
          d2(null != o2 && o2, F.QT.PlaylistScreen);
        }), m2 = (0, p.useMemo)(
          () => (0, O.jsx)(eA.Paper, {
            className: ej().cover,
            radius: "xs",
            children: (0, O.jsxs)(en.m_, {
              ...r2,
              enabled: o2,
              children: [
                (0, O.jsx)(eb.Image, {
                  "aria-hidden": true,
                  className: ej().image,
                  src: i2.coverUri,
                  size: 100,
                  fit: "cover",
                  withAvatarReplace: true
                }),
                (0, O.jsx)(en.ZI, {
                  className: ej().tooltip,
                  children: (0, O.jsx)(er.Caption, {
                    variant: "span",
                    type: "text",
                    size: "s",
                    weight: "medium",
                    lineClamp: 1,
                    children: i2.title
                  })
                })
              ]
            })
          }),
          [o2, i2.coverUri, i2.title, r2]
        );
        return (0, O.jsx)(eP, {
          ref: n2,
          ariaLabel: l2({ id: "entity-names.playlist-name" }, { playlistName: i2.title }),
          className: (0, R.$)(ej().root, a2),
          title: i2.title,
          entityUrl: i2.url,
          subtitle: (0, O.jsx)(Y.A, { id: "entity-names.playlist" }),
          cover: m2,
          isCollapsed: !!o2,
          withCollapseAnimation: !!s2,
          contextMenu: (0, O.jsx)(eM, { onPinClick: c2, isPinned: i2.isPinned }),
          onClick: u2
        });
      }, eU = (0, p.forwardRef)((e10, t2) => (0, O.jsx)(eK, { forwardRef: t2, ...e10 }));
      var eF = a(27510), ez = a(62443);
      let eV = (0, D.PA)((e10) => {
        var t2;
        let { className: a2, vibe: i2, forwardRef: n2, tooltipOptions: r2 } = e10, l2 = (0, p.useId)(), { formatMessage: o2 } = (0, G.A)(), { isCollapsed: s2, withCollapseAnimation: c2 } = null != (t2 = (0, p.useContext)(ek)) ? t2 : {}, [d2, u2] = (0, p.useState)(false), m2 = (0, I.A7)(i2), { isFreemium: _2 } = (0, g.XCI)(), { state: v2, setState: h2 } = (0, ez.e)(false), x2 = (() => {
          let e11 = (0, z.st)(), { hash: t3 } = (0, z.gf)(), a3 = (0, g.UlF)(), {
            settings: { isMobile: i3 }
          } = (0, g.Pjs)();
          return (0, p.useCallback)(
            (n3) => {
              let { isCollapsed: r3, mainObjectId: l3 } = n3;
              if (!e11) return;
              let o3 = (0, F.Fx)({
                params: {
                  hash: t3,
                  pageId: F.QT.Sidebar,
                  sidebarSize: r3 || i3 ? F.JQ.Small : F.JQ.Medium,
                  mainObjectType: F.ky.Wave,
                  mainObjectId: l3
                },
                logger: a3,
                context: "useSendEventOnSidebarStarted"
              });
              o3 && (0, F.cV)(e11.evgenInstance, o3);
            },
            [e11, t3, i3, a3]
          );
        })(), y2 = ew(), b2 = (0, g.brA)(), A2 = (0, g.PT7)(), {
          isPlaying: C2,
          togglePlay: N2,
          isCurrent: f2
        } = (0, g.B0S)({ seeds: i2.seeds, pageIdForFrom: g._Q$.SIDEBAR, blockIdForFrom: g.UfI.RADIO }), S2 = (0, U.c)(async () => {
          var e11, t3;
          return _2 ? void h2(true) : (C2 ? y2({
            actionType: F.X2.Pause,
            isCollapsed: null != s2 && s2,
            mainObjectType: F.ky.Wave,
            mainObjectId: null != (e11 = i2.seeds[0]) ? e11 : ""
          }) : x2({ isCollapsed: null != s2 && s2, mainObjectId: null != (t3 = i2.seeds[0]) ? t3 : "" }), N2());
        }), T2 = (0, U.c)(() => {
          A2() || (u2(true), S2().finally(() => {
            u2(false);
          }), b2(!C2));
        }), P2 = (0, p.useMemo)(
          () => (0, O.jsx)(er.Caption, {
            id: l2,
            variant: "span",
            "aria-label": o2({ id: "entity-names.vibe-name" }, { vibeName: i2.title }),
            type: "controls",
            size: "s",
            lineClamp: 1,
            children: i2.title
          }),
          [o2, l2, i2.title]
        ), k2 = (0, eF.L)(() => {
          var e11;
          return i2.shouldShowAgent && i2.agent ? (0, O.jsx)(I.nr, { agent: i2.agent, isCurrent: f2, isPlaying: C2, onPlayButtonClick: T2 }) : (0, O.jsx)(eo.q1, {
            isCurrent: f2,
            isPlaying: C2,
            isAvailable: true,
            isPlayButtonLoading: d2,
            onPlayButtonClick: T2,
            title: i2.title,
            entityCoverStyle: { backgroundColor: null == (e11 = i2.colors) ? void 0 : e11.average },
            ariaDescribedBy: l2,
            coverUri: i2.backgroundImageUrl,
            radius: "round",
            withLoadingIndicator: false
          });
        }), E2 = (0, eF.L)(
          () => (0, O.jsxs)(en.m_, {
            ...r2,
            enabled: s2,
            children: [
              k2,
              (0, O.jsx)(en.ZI, {
                className: ej().tooltip,
                children: (0, O.jsx)(er.Caption, {
                  variant: "span",
                  type: "text",
                  size: "s",
                  weight: "medium",
                  lineClamp: 1,
                  children: i2.title
                })
              })
            ]
          })
        ), j2 = (0, p.useCallback)(
          () => (0, O.jsx)(eP, {
            ref: n2,
            onDoubleClick: S2,
            className: (0, R.$)(ej().root, a2),
            isCollapsed: !!s2,
            contextMenu: (0, O.jsx)(eM, { onPinClick: m2, isPinned: i2.isPinned }),
            withCollapseAnimation: !!c2,
            title: P2,
            subtitle: i2.getDescription(o2({ id: "entity-names.my-vibe" })),
            cover: E2
          }),
          [n2, S2, a2, s2, m2, i2, c2, P2, o2, E2]
        );
        return (0, O.jsx)(eo.SU, {
          isEnabled: _2,
          isOpened: v2,
          onOpenChange: h2,
          placement: "right",
          textVariant: "vibe",
          vibeTextVariant: i2.stationType,
          renderChildren: j2
        });
      }), eW = (0, p.forwardRef)((e10, t2) => (0, O.jsx)(eV, { forwardRef: t2, ...e10 }));
      var eG = a(42701), eY = a.n(eG);
      let eQ = ed({ placement: "right", padding: 20 }), e$ = {
        enter: eY().pin_enter,
        enterActive: eY().pin_enter_active,
        exit: eY().pin_exit,
        exitActive: eY().pin_exit_active
      }, eq = (0, D.PA)((e10) => {
        var t2, a2;
        let { className: i2, withCollapseAnimation: n2, isCollapsed: r2, style: l2 } = e10, { formatMessage: o2 } = (0, G.A)(), { pinsCollection: s2 } = (0, g.Pjs)(), c2 = null == (t2 = s2.items) ? void 0 : t2.map(() => (0, p.createRef)()), d2 = (0, p.useMemo)(() => ({ withCollapseAnimation: n2, isCollapsed: r2 }), [r2, n2]), u2 = s2.items && s2.items.length > 0, m2 = s2.items && s2.items.length >= 3;
        return (0, O.jsx)(ek.Provider, {
          value: d2,
          children: (0, O.jsx)("div", {
            className: (0, R.$)(eY().root, { [eY().root_withScroll]: m2, [eY().root_hasPins]: u2 }, i2),
            style: l2,
            ...(0, K.Am)(K.e8.navbar.PIN_LIST),
            children: (0, O.jsx)("div", {
              role: "list",
              "aria-label": o2({ id: "navigation.pins-list" }),
              className: eY().content,
              children: (0, O.jsx)(ex.A, {
                component: null,
                children: null == (a2 = s2.items) ? void 0 : a2.map((e11, t3) => {
                  switch (e11.type) {
                    case A._.ALBUM_ITEM:
                      return (0, O.jsx)(
                        ey.A,
                        {
                          classNames: e$,
                          nodeRef: null == c2 ? void 0 : c2[t3],
                          timeout: 270,
                          children: (0, O.jsx)(eO, {
                            className: eY().pin,
                            tooltipOptions: eQ,
                            ref: null == c2 ? void 0 : c2[t3],
                            album: e11.data
                          })
                        },
                        e11.data.pinId
                      );
                    case A._.ARTIST_ITEM:
                      return (0, O.jsx)(
                        ey.A,
                        {
                          classNames: e$,
                          nodeRef: null == c2 ? void 0 : c2[t3],
                          timeout: 270,
                          children: (0, O.jsx)(eD, {
                            className: eY().pin,
                            tooltipOptions: eQ,
                            ref: null == c2 ? void 0 : c2[t3],
                            artist: e11.data
                          })
                        },
                        e11.data.pinId
                      );
                    case A._.PLAYLIST_ITEM:
                      return (0, O.jsx)(
                        ey.A,
                        {
                          classNames: e$,
                          nodeRef: null == c2 ? void 0 : c2[t3],
                          timeout: 270,
                          children: (0, O.jsx)(eU, {
                            className: eY().pin,
                            tooltipOptions: eQ,
                            ref: null == c2 ? void 0 : c2[t3],
                            playlist: e11.data
                          })
                        },
                        e11.data.pinId
                      );
                    case A._.WAVE_ITEM:
                      return (0, O.jsx)(
                        ey.A,
                        {
                          classNames: e$,
                          nodeRef: null == c2 ? void 0 : c2[t3],
                          timeout: 270,
                          children: (0, O.jsx)(eW, {
                            className: eY().pin,
                            tooltipOptions: eQ,
                            ref: null == c2 ? void 0 : c2[t3],
                            vibe: e11.data
                          })
                        },
                        e11.data.pinId
                      );
                  }
                })
              })
            })
          })
        });
      }), eH = { src: "/_next/static/media/ticket_dark.4e1b9044.png" }, eX = { src: "/_next/static/media/ticket_dark_selected.2b929060.png" }, eZ = { src: "/_next/static/media/ticket_light.6b4bb4f7.png" }, eJ = { src: "/_next/static/media/ticket_light_selected.648fa420.png" };
      var e0 = a(14140), e1 = a.n(e0);
      let e2 = (e10) => {
        let { isSelected: t2, forwardRef: a2 } = e10, { theme: i2 } = (0, g.DPo)(), n2 = (0, eF.L)(() => {
          switch (i2) {
            case g.Sxu.Dark:
              if (t2) return eX.src;
              return eH.src;
            case g.Sxu.Light:
              if (t2) return eJ.src;
              return eZ.src;
          }
        });
        return (0, O.jsx)(eb.Image, {
          ref: a2,
          className: e1().root,
          fit: "contain",
          withLoadingIndicator: false,
          src: n2
        });
      }, e8 = (0, p.forwardRef)((e10, t2) => (0, O.jsx)(e2, { forwardRef: t2, ...e10 }));
      var e3 = a(32578), e4 = a.n(e3), e5 = (function(e10) {
        return e10.WINDOWS = "WINDOWS", e10.MACOS = "MACOS", e10.UNKNOWN = "UNKNOWN", e10;
      })({}), e6 = a(60927), e7 = a.n(e6);
      let e9 = {
        exit: e7().bar_exit,
        exitActive: e7().bar_exit_active,
        enter: e7().bar_enter,
        enterActive: e7().bar_enter_active
      }, te = {
        exit: e7().button_exit,
        exitActive: e7().button_exit_active,
        enter: e7().button_enter,
        enterActive: e7().button_enter_active
      }, tt = (e10) => {
        let { className: t2, children: a2, button: i2, isCollapsed: n2, barClassName: r2 } = e10, l2 = (0, p.useRef)(null), o2 = (0, p.useRef)(null);
        return (0, O.jsxs)("div", {
          className: (0, R.$)(e7().root, t2),
          children: [
            (0, O.jsx)(ey.A, {
              nodeRef: o2,
              in: n2,
              timeout: 150,
              classNames: te,
              unmountOnExit: true,
              children: (0, O.jsx)("div", { className: (0, R.$)(e7().button), ref: o2, children: i2 })
            }),
            (0, O.jsx)(ey.A, {
              nodeRef: l2,
              in: !n2,
              timeout: 150,
              classNames: e9,
              unmountOnExit: true,
              children: (0, O.jsx)("div", { className: (0, R.$)(e7().bar, r2), ref: l2, children: a2 })
            })
          ]
        });
      }, ta = (e10) => {
        switch (e10) {
          case e5.MACOS:
            return "macos";
          case e5.WINDOWS:
            return "windows";
          default:
            return "musicLogo";
        }
      }, ti = (e10) => {
        let { formatMessage: t2 } = (0, G.A)();
        switch (e10) {
          case e5.MACOS:
            return t2({ id: "sidebar.download-macos" });
          case e5.WINDOWS:
            return t2({ id: "sidebar.download-windows" });
          default:
            return t2({ id: "sidebar.download-app" });
        }
      };
      var tn = a(60640), tr = a.n(tn);
      let tl = (e10) => {
        let { variant: t2, forwardRef: a2, onDownloadClick: i2, onCloseClick: n2 } = e10, { formatMessage: r2 } = (0, G.A)(), l2 = ti(t2), o2 = (0, p.useMemo)(() => {
          let e11 = { span: (e12) => (0, O.jsx)("span", { className: tr().textBright, children: e12 }) };
          switch (t2) {
            case e5.MACOS:
              return r2({ id: "sidebar.download-macos-formatted" }, e11);
            case e5.WINDOWS:
              return r2({ id: "sidebar.download-windows-formatted" }, e11);
            default:
              return r2({ id: "sidebar.download-app-formatted" }, e11);
          }
        }, [r2, t2]);
        return (0, O.jsx)("section", {
          ref: a2,
          "aria-label": l2,
          children: (0, O.jsxs)(eA.Paper, {
            radius: "m",
            className: tr().root,
            children: [
              (0, O.jsx)(Q.$, {
                color: "secondary",
                radius: "round",
                variant: "text",
                size: "xxxs",
                className: tr().closeButton,
                icon: (0, O.jsx)($.Icon, { variant: "close", size: "xxs", className: tr().closeButtonIcon }),
                withRipple: false,
                onClick: n2,
                "aria-label": r2({ id: "interface-actions.close" })
              }),
              (0, O.jsx)(er.Caption, { variant: "div", className: tr().text, size: "m", children: o2 }),
              (0, O.jsx)(Q.$, {
                color: "secondary",
                radius: "xxxl",
                size: "xs",
                variant: "default",
                role: "link",
                withRipple: true,
                flexIcon: true,
                "aria-label": l2,
                onClick: i2,
                icon: (0, O.jsx)($.Icon, { variant: ta(t2), size: "xxs", className: tr().downloadButtonIcon }),
                ...(0, K.Am)(K.e8.navbar.DOWNLOAD_APP_BUTTON_ENLARGED),
                children: (0, O.jsx)(er.Caption, {
                  variant: "span",
                  className: tr().downloadButtonText,
                  size: "m",
                  children: (0, O.jsx)(Y.A, { id: "offline.download" })
                })
              })
            ]
          })
        });
      }, to = (0, p.forwardRef)((e10, t2) => (0, O.jsx)(tl, { forwardRef: t2, ...e10 }));
      var ts = a(23258), tc = a.n(ts);
      let td = (e10) => {
        let { variant: t2, onDownloadClick: a2 } = e10, i2 = ti(t2), n2 = (0, p.useMemo)(() => ta(t2), [t2]);
        return (0, O.jsxs)(eA.Paper, {
          radius: "m",
          className: tc().root,
          children: [
            (0, O.jsx)($.Icon, { variant: n2, className: tc().icon }),
            (0, O.jsxs)(en.m_, {
              placement: "left",
              offsetOptions: 4,
              children: [
                (0, O.jsx)(Q.$, {
                  className: tc().button,
                  color: "secondary",
                  radius: "round",
                  size: "xs",
                  variant: "default",
                  role: "link",
                  withRipple: true,
                  flexIcon: true,
                  onClick: a2,
                  icon: (0, O.jsx)($.Icon, { variant: "download", size: "xxs", className: tc().buttonIcon }),
                  "aria-label": i2,
                  ...(0, K.Am)(K.e8.navbar.DOWNLOAD_APP_BUTTON_MINIMIZED)
                }),
                (0, O.jsx)(en.ZI, {
                  children: (0, O.jsx)(er.Caption, {
                    variant: "span",
                    type: "text",
                    size: "s",
                    weight: "medium",
                    lineClamp: 1,
                    children: i2
                  })
                })
              ]
            })
          ]
        });
      }, tu = (0, D.PA)((e10) => {
        var t2;
        let { isCollapsed: a2 } = e10, { settings: i2 } = (0, g.Pjs)(), n2 = (0, g.NFA)(), r2 = n2.get(g.ooW), l2 = n2.get(g.twC), [o2, s2] = (0, p.useState)(false), c2 = (() => {
          let e11 = (0, z.st)(), { hash: t3 } = (0, z.gf)(), a3 = (0, g.UlF)();
          return (0, p.useCallback)(() => {
            if (!e11 || !t3) return;
            let i3 = (0, F.Fx)({
              params: {
                entityType: F.LA.Error,
                entityId: F.LA.Error,
                hash: t3,
                pageId: F.QT.PageNotFoundScreen,
                pageStyle: F.QL.Fullscreen,
                pagePlacement: F.c4.Fullscreen,
                mainObjectType: F.ky.NonApplicable,
                mainObjectId: F.ky.NonApplicable,
                from: F.QT.PageNotFoundScreen,
                to: F.QT.DownloadAppScreen
              },
              logger: a3,
              context: "useSendEventOnDownloadScreenNavigated"
            });
            i3 && (0, F.ID)(e11.evgenInstance, i3);
          }, [e11, t3, a3]);
        })(), d2 = (0, p.useMemo)(() => {
          var e11;
          switch (null == (e11 = i2.browserInfo) ? void 0 : e11.OSFamily) {
            case "MacOS":
              return e5.MACOS;
            case "Windows":
              return e5.WINDOWS;
            default:
              return e5.UNKNOWN;
          }
        }, [null == (t2 = i2.browserInfo) ? void 0 : t2.OSFamily]), u2 = (0, g._lF)(l2.downloadDesktop.url), m2 = (0, p.useCallback)(() => {
          c2(), window.open(u2, "_blank", "noreferrer noopener");
        }, [c2, u2]), _2 = (0, p.useCallback)(() => {
          r2.set(g.cYZ.NavbarDownloadBarIsHidden, true, { expires: 30 }), s2(true);
        }, [r2]);
        return o2 ? null : (0, O.jsx)(tt, {
          isCollapsed: a2,
          button: (0, O.jsx)(td, { variant: d2, onDownloadClick: m2 }),
          children: (0, O.jsx)(to, { variant: d2, onDownloadClick: m2, onCloseClick: _2 })
        });
      });
      var tm = a(69610);
      function t_() {
        return (t_ = Object.assign ? Object.assign.bind() : function(e10) {
          for (var t2 = 1; t2 < arguments.length; t2++) {
            var a2 = arguments[t2];
            for (var i2 in a2) ({}).hasOwnProperty.call(a2, i2) && (e10[i2] = a2[i2]);
          }
          return e10;
        }).apply(null, arguments);
      }
      let tp = function(e10) {
        return p.createElement(
          "svg",
          t_({ viewBox: "0 0 58 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" }, e10),
          p.createElement(
            "g",
            { clipPath: "url(#clip0_2521_25547)" },
            p.createElement(
              "g",
              { clipPath: "url(#clip1_2521_25547)" },
              i || (i = p.createElement("rect", { x: 33.5005, width: 24, height: 24, rx: 12, fill: "white" })),
              n || (n = p.createElement("path", {
                d: "M40.4184 5.14279C41.6821 4.20644 43.1756 3.6404 44.7322 3.49976V6.07553C43.726 6.20598 42.765 6.59121 41.943 7.20031C40.9138 7.96298 40.1569 9.03624 39.7839 10.2618C39.411 11.4873 39.4419 12.8003 39.8719 14.007C40.3019 15.2137 41.1084 16.2502 42.1723 16.9637C43.2362 17.6773 44.5013 18.03 45.7809 17.9698C47.0605 17.9097 48.2869 17.4399 49.2792 16.6298C50.2716 15.8197 50.9773 14.712 51.2922 13.4703C51.5119 12.6042 51.5334 11.7049 51.3613 10.8378L53.5243 9.09892L53.5229 9.0849C54.1067 10.691 54.1959 12.4383 53.7744 14.1C53.3245 15.8738 52.3163 17.4561 50.8987 18.6135C49.4811 19.7708 47.7291 20.4419 45.9011 20.5278C44.0731 20.6137 42.2658 20.1099 40.7459 19.0906C39.2261 18.0713 38.074 16.5905 37.4597 14.8666C36.8453 13.1428 36.8013 11.2671 37.334 9.51633C37.8668 7.76555 38.948 6.23231 40.4184 5.14279Z",
                fill: "#FCCA00"
              })),
              r || (r = p.createElement("path", {
                d: "M51.8934 6.34507L51.9025 6.36777L50.457 8.66347C49.9314 7.88453 49.227 7.23618 48.4027 6.77726V12.0016C48.4027 13.6044 47.1033 14.9038 45.5004 14.9038C43.8975 14.9038 42.5981 13.6044 42.5981 12.0016C42.5981 10.3987 43.8975 9.09931 45.5004 9.09931C46.1011 9.09931 46.6592 9.28181 47.1223 9.59441V3.61938C49.0065 3.98181 50.6703 4.96381 51.8934 6.34507Z",
                fill: "#FC3F1D"
              })),
              p.createElement(
                "mask",
                {
                  id: "mask0_2521_25547",
                  style: { maskType: "alpha" },
                  maskUnits: "userSpaceOnUse",
                  x: 33,
                  y: 0,
                  width: 25,
                  height: 24
                },
                l || (l = p.createElement("circle", { cx: 45.5005, cy: 12, r: 12, fill: "white" }))
              ),
              o || (o = p.createElement("g", { mask: "url(#mask0_2521_25547)" })),
              s || (s = p.createElement(
                "g",
                { clipPath: "url(#clip2_2521_25547)" },
                p.createElement("rect", { width: 24, height: 24, transform: "translate(33.5005)", fill: "black" }),
                p.createElement("path", {
                  d: "M57.5002 3.59937L45.121 10.2255L51.5722 3.59937L47.9962 3.59937L43.6042 9.6956V3.59937L40.7002 3.59937V20.3994H43.6042V14.313L47.9962 20.3994H51.5722L45.2885 13.9815L57.5002 20.3994V17.2794L46.3623 12.811L57.5002 13.5594V10.4394L46.4328 11.1589L57.5002 6.71936V3.59937Z",
                  fill: "url(#paint0_radial_2521_25547)"
                })
              ))
            )
          ),
          c || (c = p.createElement(
            "g",
            { clipPath: "url(#clip3_2521_25547)" },
            p.createElement("rect", { x: 17.0005, width: 24, height: 24, rx: 12, fill: "white" }),
            p.createElement("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M41.0005 12C41.0005 18.6274 35.6279 24 29.0005 24C22.3731 24 17.0005 18.6274 17.0005 12C17.0005 5.37258 22.3731 0 29.0005 0C30.2956 0 31.5427 0.205154 32.7112 0.584736L29.9763 9H21.9892L21.0132 12H29.0013L26.6613 19.2H29.9613L32.3013 12L41.0005 12ZM40.6224 9H33.2763L35.5662 1.95391C38.0324 3.56896 39.8677 6.06758 40.6224 9Z",
              fill: "url(#paint1_linear_2521_25547)"
            })
          )),
          d || (d = p.createElement("path", {
            d: "M12.5 24C19.1274 24 24.5 18.6274 24.5 12C24.5 5.37258 19.1274 0 12.5 0C5.87258 0 0.5 5.37258 0.5 12C0.5 18.6274 5.87258 24 12.5 24Z",
            fill: "black"
          })),
          u || (u = p.createElement("path", {
            d: "M18.2943 10.6431C18.2943 10.6431 21.283 14.8271 21.2703 14.8639C21.2143 15.024 21.154 15.1821 21.0895 15.338C21.0747 15.3735 17.35 12.1585 17.35 12.1585C17.35 12.1585 18.3728 19.0145 18.3525 19.0314C18.2041 19.1531 18.0528 19.2706 17.8972 19.383C17.8757 19.3986 15.6594 12.6669 15.6594 12.6669C15.6594 12.6669 12.5603 21.1641 12.5342 21.1646C12.4861 21.1654 12.4376 21.1658 12.3896 21.1658C12.2277 21.1658 12.0671 21.1616 11.9069 21.1536C11.8828 21.1523 13.7581 12.101 13.7581 12.101C13.7581 12.101 4.94181 17.5004 4.92916 17.4839C4.80269 17.3199 4.68169 17.1517 4.56617 16.9789C4.55395 16.9607 12.2686 10.4711 12.2686 10.4711C12.269 10.4716 3.15343 9.90658 3.15723 9.88756C3.19601 9.69233 3.2407 9.49879 3.29129 9.30821C3.29593 9.29003 12.0532 8.60038 12.0532 8.60038C12.0532 8.60038 5.65977 5.13649 5.67495 5.12085C5.80606 4.98689 5.94139 4.85674 6.08052 4.73039C6.09738 4.71517 13.1383 7.06726 13.1383 7.06726C13.1383 7.06726 10.9718 2.40366 11.011 2.39774C11.1691 2.3745 11.328 2.35506 11.4886 2.33985C11.5224 2.33689 15.1704 6.63623 15.1704 6.63623C15.1704 6.63623 16.3365 3.16388 16.3711 3.18036C16.5363 3.25811 16.6991 3.34009 16.8588 3.42672C16.8888 3.44278 16.9891 7.20502 16.9891 7.20502C16.9891 7.20502 19.8066 5.92333 19.8133 5.93178C19.9116 6.05814 20.0068 6.18702 20.0987 6.31887C20.1046 6.32732 18.0401 8.74829 18.0401 8.74829C18.0401 8.74829 21.6506 10.0397 21.6565 10.0735C21.6835 10.2261 21.7071 10.3794 21.7265 10.5341C21.7303 10.5658 18.2943 10.6431 18.2943 10.6431Z",
            fill: "#FED42B"
          })),
          m || (m = p.createElement(
            "defs",
            null,
            p.createElement(
              "radialGradient",
              {
                id: "paint0_radial_2521_25547",
                cx: 0,
                cy: 0,
                r: 1,
                gradientUnits: "userSpaceOnUse",
                gradientTransform: "translate(40.7002 3.59937) rotate(45) scale(23.7588)"
              },
              p.createElement("stop", { offset: 0.5, stopColor: "#FF5500" }),
              p.createElement("stop", { offset: 1, stopColor: "#BBFF00" })
            ),
            p.createElement(
              "linearGradient",
              {
                id: "paint1_linear_2521_25547",
                x1: 17.0005,
                y1: 10.4,
                x2: 41.0005,
                y2: 10.4,
                gradientUnits: "userSpaceOnUse"
              },
              p.createElement("stop", { stopColor: "#FF5C4D" }),
              p.createElement("stop", { offset: 0.4, stopColor: "#EB469F" }),
              p.createElement("stop", { offset: 1, stopColor: "#8341EF" })
            ),
            p.createElement(
              "clipPath",
              { id: "clip0_2521_25547" },
              p.createElement("rect", { x: 33.5005, width: 24, height: 24, rx: 12, fill: "white" })
            ),
            p.createElement(
              "clipPath",
              { id: "clip1_2521_25547" },
              p.createElement("rect", { x: 33.5005, width: 24, height: 24, rx: 12, fill: "white" })
            ),
            p.createElement(
              "clipPath",
              { id: "clip2_2521_25547" },
              p.createElement("rect", { width: 24, height: 24, fill: "white", transform: "translate(33.5005)" })
            ),
            p.createElement(
              "clipPath",
              { id: "clip3_2521_25547" },
              p.createElement("rect", { x: 17.0005, width: 24, height: 24, rx: 12, fill: "white" })
            )
          ))
        );
      };
      var tv = a(6437), th = a.n(tv);
      let tg = (e10) => {
        let { className: t2, forwardRef: a2, shouldFetchOffers: i2 } = e10, {
          paywall: { modal: n2 }
        } = (0, g.Pjs)(), { formatMessage: r2 } = (0, G.A)();
        return (0, O.jsxs)("section", {
          className: (0, R.$)(th().root, t2),
          ref: a2,
          "aria-label": r2({ id: "plusbar.subscription-activation" }),
          ...(0, K.Am)(K.e8.plusBar.PLUS_BAR),
          children: [
            (0, O.jsx)(tp, { className: th().logos, "aria-hidden": "true" }),
            (0, O.jsx)(er.Caption, {
              className: th().title,
              variant: "div",
              size: "m",
              weight: "medium",
              ...(0, K.Am)(K.e8.plusBar.PLUS_BAR_TITLE),
              children: (0, O.jsx)(Y.A, { id: "plusbar.title", values: { br: "\n", nbsp: " " } })
            }),
            (0, O.jsx)(er.Caption, {
              className: th().addition,
              variant: "div",
              size: "xs",
              weight: "normal",
              ...(0, K.Am)(K.e8.plusBar.PLUS_BAR_ADDITION),
              children: (0, O.jsx)(Y.A, { id: "plusbar.text", values: { br: "\n", nbsp: " " } })
            }),
            (0, O.jsxs)("div", {
              className: th().buttons,
              children: [
                (0, O.jsx)(tm.FB, { shouldFetchOffers: i2, ...(0, K.Am)(K.e8.plusBar.PLUS_BAR_OFFER_BUTTON) }),
                (0, O.jsx)(Q.$, {
                  className: th().button,
                  isBlock: true,
                  radius: "xxxl",
                  size: "m",
                  variant: "text",
                  color: "primary",
                  withRipple: false,
                  onClick: n2.open,
                  ...(0, K.Am)(K.e8.plusBar.PLUS_BAR_PAYWALL_BUTTON),
                  children: (0, O.jsx)(Y.A, { id: "interface-actions.more-details" })
                })
              ]
            })
          ]
        });
      }, tx = (0, p.forwardRef)(
        (e10, t2) => (0, O.jsx)(g.rtM, {
          page: g.l7W.SIDEBAR,
          places: [g.RBW.SIDEBAR_BANNER],
          children: (0, O.jsx)(tg, { forwardRef: t2, ...e10 })
        })
      );
      var ty = a(25615), tb = a.n(ty);
      let tA = (0, D.PA)((e10) => {
        let { isCollapsed: t2, shouldFetchOffers: a2 } = e10, { formatMessage: i2 } = (0, G.A)(), {
          paywall: { modal: n2 }
        } = (0, g.Pjs)();
        return (0, O.jsx)(tt, {
          className: tb().root,
          isCollapsed: t2,
          button: (0, O.jsxs)(en.m_, {
            ...eu,
            enabled: t2,
            children: [
              (0, O.jsx)(Q.$, {
                variant: "text",
                withRipple: false,
                size: "xxs",
                icon: (0, O.jsx)($.Icon, { className: tb().icon, variant: "plusOutlined" }),
                className: (0, R.$)(tb().button, tb().important),
                "aria-label": i2({ id: "plusbar.subscription-activation" }),
                onClick: n2.open,
                ...(0, K.Am)(K.e8.navbar.PAYWALL_BUTTON_MINIMIZED)
              }),
              (0, O.jsx)(en.ZI, {
                children: (0, O.jsx)(er.Caption, {
                  variant: "span",
                  type: "text",
                  size: "s",
                  weight: "medium",
                  children: (0, O.jsx)(Y.A, { id: "plusbar.subscription-activation" })
                })
              })
            ]
          }),
          children: (0, O.jsx)(tx, { shouldFetchOffers: a2 })
        });
      });
      tA.displayName = "NavbarDesktopAnimatedPlusBar";
      var tC = a(49320), tN = a(31865), tf = a.n(tN);
      let tI = () => {
        let {
          experiments: e10,
          paywall: { modal: t2 }
        } = (0, g.Pjs)(), { formatMessage: a2 } = (0, G.A)(), i2 = e10.checkExperiment(g.zal.WebNextUnauthorizedSubscriptionButton, "on"), n2 = i2 ? a2({ id: "plusbar.title" }, { br: "\n", nbsp: " " }) : a2({ id: "authorization.enter-title" }), r2 = i2 ? a2({ id: "plusbar.text" }, { br: "\n", nbsp: " " }) : a2({ id: "authorization.enter-subtitle" }), l2 = (0, p.useMemo)(
          () => i2 ? (0, O.jsxs)("div", {
            className: tf().buttons,
            children: [
              (0, O.jsx)(tm.FB, {}),
              (0, O.jsx)(Q.$, {
                className: tf().button,
                isBlock: true,
                radius: "xxxl",
                size: "m",
                variant: "default",
                color: "secondary",
                withRipple: false,
                onClick: t2.open,
                children: (0, O.jsx)(Y.A, { id: "interface-actions.more-details" })
              }),
              (0, O.jsx)(eo.Hi, {
                size: "s",
                variant: "text",
                withRipple: false,
                buttonText: (0, O.jsx)(Y.A, { id: "authorization.has-subscription" }),
                isBlock: true
              })
            ]
          }) : (0, O.jsx)(eo.Hi, { size: "s", isBlock: true }),
          [t2.open, i2]
        );
        return (0, O.jsxs)("div", {
          className: tf().root,
          children: [
            (0, O.jsx)(p.Suspense, {
              children: (0, O.jsx)(tC.YS, {
                className: tf().userProfile,
                userIdClassName: tf().userId,
                variant: "desktop"
              })
            }),
            (0, O.jsx)(er.Caption, { className: tf().title, size: "m", variant: "div", weight: "bold", children: n2 }),
            (0, O.jsx)(er.Caption, {
              className: tf().subtitle,
              size: "xs",
              variant: "div",
              weight: "medium",
              children: r2
            }),
            l2
          ]
        });
      };
      var tS = a(7917), tT = a.n(tS);
      let tP = (0, D.PA)((e10) => {
        let { isCollapsed: t2, withUserProfileAnimation: a2 } = e10, { user: i2, experiments: n2 } = (0, g.Pjs)();
        if (!i2.isAuthorized) {
          let e11 = n2.checkExperiment(g.zal.WebNextUnauthorizedSubscriptionButton, "on"), a3 = !t2 && e11, i3 = e11 || t2;
          return (0, O.jsx)(tt, {
            barClassName: tT().unauthorizedBar,
            isCollapsed: i3,
            button: (0, O.jsxs)(en.m_, {
              ...eu,
              enabled: t2,
              children: [
                (0, O.jsxs)("div", {
                  className: tT().userProfileContainer,
                  children: [
                    (0, O.jsx)(tC.YS, { className: tT().userProfile }),
                    a3 && (0, O.jsx)(er.Caption, {
                      variant: "span",
                      type: "text",
                      size: "s",
                      weight: "medium",
                      children: (0, O.jsx)(Y.A, { id: "authorization.enter-button" })
                    })
                  ]
                }),
                (0, O.jsx)(en.ZI, {
                  children: (0, O.jsx)(er.Caption, {
                    variant: "span",
                    type: "text",
                    size: "s",
                    weight: "medium",
                    children: (0, O.jsx)(Y.A, { id: "authorization.enter-tooltip" })
                  })
                })
              ]
            }),
            children: (0, O.jsx)(tI, {})
          });
        }
        return (0, O.jsx)("div", {
          className: tT().userProfileContainer,
          children: (0, O.jsx)(tC.YS, {
            className: tT().userProfile,
            userIdClassName: tT().userId,
            metaClassName: (0, R.$)(tT().userMeta, {
              [tT().userMeta_withAnimation]: a2,
              [tT().userMeta_collapsed]: t2
            }),
            withMeta: true
          })
        });
      }), tk = (0, D.PA)((e10) => {
        var t2, a2;
        let { className: i2, isCollapsed: n2, shownAnimation: r2, handleClick: l2 } = e10, o2 = y(), s2 = (0, g.EE7)(), { formatMessage: c2 } = (0, G.A)(), d2 = (0, g.jjz)(), {
          user: u2,
          experiments: m2,
          settings: _2,
          modals: { bestRecommedationModal: v2 },
          advertBanners: {
            banners: { brandedEntityAxeBanner: h2 }
          }
        } = (0, g.Pjs)(), x2 = (0, g.Yej)(), b2 = (0, g.NFA)().get(g.ooW), A2 = es(), C2 = ((e11) => {
          let t3 = (0, g.NFA)().get(g.ooW), a3 = y(), [i3, n3] = (0, p.useState)(false);
          return (0, p.useEffect)(() => {
            true !== t3.get(g.cYZ.NavbarCollapsed) && ((e11 || a3) && false !== t3.get(g.cYZ.NavbarCollapsed) || n3(true));
          }, [e11, a3, t3]), i3;
        })(n2), N2 = ((e11, t3, a3) => e11.checkExperiment(g.zal.WebNextUnauthorizedSubscriptionButton, "on") ? !a3 : t3 && !a3)(
          m2,
          u2.isAuthorized,
          u2.hasPlus
        ), f2 = (0, el.Qj)(), I2 = h2.isVisible && f2.isEnabled ? null == (t2 = f2.data) ? void 0 : t2.style : void 0, S2 = m2.checkExperiment(g.zal.WebNextPromoVeryBestRecommendations, "on"), T2 = m2.checkExperiment(g.zal.WebNextNavbarExplicit, "on"), P2 = !n2 && T2, k2 = (null == (a2 = _2.browserInfo) || a2.isTouch, !b2.get(g.cYZ.NavbarDownloadBarIsHidden) && false), E2 = m2.checkExperiment(g.zal.WebNextNewWaveTab, "on"), j2 = (0, p.useMemo)(() => {
          if (u2.collectionHue && !E2) return { "--logo-color": (0, g.eWZ)(u2.collectionHue) };
        }, [E2, u2.collectionHue]), L2 = (0, p.useMemo)(() => n2 ? c2({ id: "sidebar.uncollapse" }) : c2({ id: "sidebar.collapse" }), [n2, c2]), w2 = (0, p.useCallback)(
          (e11, t3) => e11.id === g.RnV.CONCERTS && m2.checkExperiment(g.zal.WebNextConcertsTicketIcon, "on") ? (0, O.jsx)(e8, { isSelected: t3 }) : E2 ? (0, O.jsx)($.Icon, { variant: e11.iconNewVersion, size: "xs" }) : (0, O.jsx)($.Icon, { variant: t3 ? e11.iconSelected : e11.icon, size: "m" }),
          [m2, E2]
        ), M2 = (0, U.c)(() => {
          P2 && v2.open();
        }), B2 = (0, p.useMemo)(
          () => ({
            [g.RnV.SEARCH]: c2({ id: "navigation.search" }),
            [g.RnV.HOME]: E2 ? c2({ id: "navigation.page-my-vibe" }) : c2({ id: "navigation.page-main" }),
            [g.RnV.FOR_YOU_AND_TRENDS]: c2({ id: "navigation.page-for-you-and-trends" }),
            [g.RnV.COLLECTION]: c2({ id: "navigation.page-collection" }),
            [g.RnV.NON_MUSIC]: c2({ id: "entity-names.podcasts-and-books" }),
            [g.RnV.KIDS]: c2({ id: "kids.for-kids" }),
            [g.RnV.CONCERTS]: c2({ id: "entity-names.concerts" }),
            [g.RnV.PLUS]: c2({ id: "navigation.page-plus" })
          }),
          [c2, E2]
        ), D2 = (0, U.c)((e11, t3) => () => {
          A2(e11, t3);
        }), F2 = (0, p.useMemo)(
          () => (0, O.jsx)(
            ea,
            {
              className: (0, R.$)({ [e4().navigationGroup]: E2 }),
              children: x2.map((e11) => {
                let t3 = s2(e11.availablePaths);
                return (0, O.jsx)(
                  eg,
                  {
                    config: e11.onboardingConfig,
                    children: (0, O.jsx)(ei, {
                      "data-intersection-property-id": g.NZ,
                      selected: t3,
                      shownAnimation: r2,
                      variant: "main",
                      isNewVisualVersion: E2,
                      withRipple: E2 && e11.isEnabled,
                      children: (0, O.jsxs)(eo.N_, {
                        href: e11.isEnabled ? e11.path : void 0,
                        role: "link",
                        "aria-disabled": !e11.isEnabled,
                        tabIndex: e11.isEnabled ? 0 : -1,
                        className: (0, R.$)({ [e4().disabledNavigationItem]: !e11.isEnabled }),
                        onClick: D2(e11.analyticsParams.entityType, e11.analyticsParams.to),
                        ...(0, K.Am)(ec[e11.id]),
                        children: [
                          (0, O.jsxs)(en.m_, {
                            ...eu,
                            enabled: n2,
                            children: [
                              w2(e11, t3),
                              (0, O.jsx)(en.ZI, {
                                children: (0, O.jsx)(er.Caption, {
                                  variant: "span",
                                  type: "text",
                                  size: "s",
                                  weight: "medium",
                                  children: B2[e11.id]
                                })
                              })
                            ]
                          }),
                          (0, O.jsx)(er.Caption, {
                            variant: "span",
                            type: "controls",
                            size: "m",
                            weight: "medium",
                            lineClamp: 1,
                            className: (0, R.$)({ [e4().title_animate]: r2, [e4().title_collapsed]: n2 }),
                            children: B2[e11.id]
                          })
                        ]
                      })
                    })
                  },
                  e11.id
                );
              })
            },
            "main"
          ),
          [s2, n2, m2, m2.loadingState, r2, B2, x2, D2, w2]
        ), z2 = (0, p.useMemo)(
          () => o2 ? null : (0, p.createElement)(en.m_, {
            ...eu,
            key: "collapseTooltip",
            enabled: n2,
            isFocusEnabled: false,
            children: [
              (0, O.jsx)(Q.$, {
                className: e4().collapseButton,
                "aria-label": L2,
                radius: "round",
                color: "secondary",
                size: "xs",
                icon: (0, O.jsx)($.Icon, { variant: n2 ? "arrowRight" : "arrowLeft", size: "xxs" }),
                onClick: l2
              }),
              (0, O.jsx)(en.ZI, {
                className: (0, R.$)({ [e4().collapseButtonTooltip_hidden]: !n2 }),
                children: L2
              })
            ]
          }),
          [n2, L2, l2, o2]
        );
        return (0, O.jsxs)("div", {
          className: (0, R.$)(e4().root, i2),
          style: I2,
          children: [
            (0, O.jsxs)("div", {
              className: e4().logoWrapper,
              children: [
                (0, O.jsx)(eo.N_, {
                  href: "/",
                  className: e4().logoLink,
                  "aria-label": c2({ id: "navigation.page-main" }),
                  children: (0, O.jsx)(q.gu, {
                    style: j2,
                    className: e4().logo,
                    collapsed: n2,
                    shownAnimation: r2,
                    lang: d2
                  })
                }),
                z2
              ]
            }),
            S2 && (0, O.jsx)(er.Caption, {
              style: j2,
              variant: "div",
              type: "text",
              size: "xs",
              weight: "medium",
              className: (0, R.$)(e4().subTitle, {
                [e4().title_animate]: r2,
                [e4().title_collapsed]: n2,
                [e4().subTitle_withCursorPointer]: P2
              }),
              onClick: M2,
              children: (0, O.jsx)(Y.A, { id: "navigation.best-recommendations" })
            }),
            (0, O.jsx)("div", {
              className: e4().scrollableContainer,
              children: (0, O.jsxs)("div", {
                className: e4().scrollableContent,
                children: [
                  (0, O.jsx)(et, {
                    className: (0, R.$)(e4().navigation, { [e4().navigation_new]: E2, [e4().navigation_gapFill]: false }),
                    collapsed: n2,
                    "aria-label": c2({ id: "navigation.main-menu" }),
                    children: F2
                  }),
                  (0, O.jsx)(eo.aQ, {
                    fallback: (0, O.jsx)(eq, {
                      style: I2,
                      isCollapsed: n2,
                      withCollapseAnimation: !!r2,
                      className: e4().pinsList
                    })
                  }),
                  N2 && (0, O.jsx)(tA, { shouldFetchOffers: C2, isCollapsed: n2 }),
                  k2 && (0, O.jsx)(tu, { isCollapsed: n2 })
                ]
              })
            }),
            (0, O.jsx)(tP, { withUserProfileAnimation: r2, isCollapsed: n2 }),
            T2 && (0, O.jsxs)(H.a, {
              className: e4().bestRecommendationsModal,
              headerClassName: e4().bestRecommendationsModalHeader,
              contentClassName: e4().bestRecommendationsModalContent,
              open: v2.isOpened,
              onOpenChange: v2.onOpenChange,
              onClose: v2.close,
              size: "fitContent",
              placement: "center",
              overlayColor: "full",
              labelClose: c2({ id: "interface-actions.close" }),
              children: [
                (0, O.jsx)($.Icon, { variant: "musicLogo", className: e4().bestRecommendationsModalLogo }),
                (0, O.jsx)(er.Caption, {
                  className: e4().bestRecommendationsModalText,
                  variant: "div",
                  size: "m",
                  weight: "normal",
                  dangerouslySetInnerHTML: { __html: c2({ id: "about-app.explicit-content" }) }
                })
              ]
            })
          ]
        });
      });
      var tE = a(59408), tj = a.n(tE);
      let tL = (0, D.PA)((e10) => {
        let { className: t2 } = e10, { experiments: a2 } = (0, g.Pjs)(), i2 = (0, g.EE7)(), { formatMessage: n2 } = (0, G.A)(), r2 = (0, g.Yej)(), l2 = n2({ id: "navigation.main-menu" }), o2 = es(), s2 = a2.checkExperiment(g.zal.WebNextNewWaveTab, "on"), c2 = (0, p.useMemo)(
          () => ({
            [g.RnV.SEARCH]: n2({ id: "navigation.search" }),
            [g.RnV.HOME]: s2 ? n2({ id: "navigation.page-my-vibe" }) : n2({ id: "navigation.page-main" }),
            [g.RnV.FOR_YOU_AND_TRENDS]: n2({ id: "navigation.page-for-you-and-trends" }),
            [g.RnV.COLLECTION]: n2({ id: "navigation.page-collection" }),
            [g.RnV.NON_MUSIC]: n2({ id: "entity-names.podcasts-and-books" }),
            [g.RnV.KIDS]: n2({ id: "kids.for-kids" }),
            [g.RnV.CONCERTS]: n2({ id: "entity-names.concerts" })
          }),
          [n2, s2]
        ), d2 = (0, p.useCallback)(
          (e11, t3) => e11.id === g.RnV.CONCERTS && a2.checkExperiment(g.zal.WebNextConcertsTicketIcon, "on") ? (0, O.jsx)(e8, { isSelected: t3 || s2 }) : s2 ? (0, O.jsx)($.Icon, { variant: e11.iconNewVersion, size: "xs" }) : (0, O.jsx)($.Icon, { variant: t3 ? e11.iconSelected : e11.icon, size: "m" }),
          [a2, s2]
        ), u2 = (0, U.c)((e11, t3) => () => {
          o2(e11, t3);
        });
        return (0, O.jsx)("div", {
          className: (0, R.$)(tj().root, t2),
          children: (0, O.jsx)(et, {
            collapsed: true,
            direction: "horizontal",
            "aria-label": l2,
            children: (0, O.jsx)(ea, {
              children: (0, O.jsxs)(O.Fragment, {
                children: [
                  r2.map((e11) => {
                    let t3 = i2(e11.availablePaths);
                    return (0, O.jsx)(
                      eg,
                      {
                        config: e11.onboardingConfig,
                        children: (0, O.jsx)(ei, {
                          "data-intersection-property-id": g.NZ,
                          selected: t3,
                          isNewVisualVersion: s2,
                          children: (0, O.jsxs)(eo.N_, {
                            href: e11.isEnabled ? e11.path : void 0,
                            role: "link",
                            "aria-disabled": !e11.isEnabled,
                            tabIndex: e11.isEnabled ? 0 : -1,
                            className: (0, R.$)({ [tj().disabledNavigationItem]: !e11.isEnabled }),
                            onClick: u2(e11.analyticsParams.entityType, e11.analyticsParams.to),
                            ...(0, K.Am)(ec[e11.id]),
                            children: [
                              d2(e11, t3),
                              (0, O.jsx)(er.Caption, {
                                variant: "span",
                                type: "controls",
                                size: "m",
                                weight: "medium",
                                lineClamp: 1,
                                children: c2[e11.id]
                              })
                            ]
                          })
                        })
                      },
                      e11.id
                    );
                  }),
                  !s2 && (0, O.jsx)(ei, { children: (0, O.jsx)(tC.YS, { className: tj().user, variant: "mobile" }) })
                ]
              })
            })
          })
        });
      }), tw = (0, D.PA)((e10) => {
        var t2;
        let { className: a2, externalIsCollapsed: i2, externalSetIsCollapsed: n2 } = e10, r2 = (0, g.NFA)().get(g.ooW), l2 = y(), {
          settings: { isMobile: o2 }
        } = (0, g.Pjs)(), [s2, c2] = (0, p.useState)(null != (t2 = r2.get(g.cYZ.NavbarCollapsed)) ? t2 : l2), [d2, u2] = (0, p.useState)(false), m2 = (() => {
          let e11 = (0, z.st)(), { hash: t3 } = (0, z.gf)(), a3 = (0, g.UlF)(), {
            settings: { isMobile: i3 }
          } = (0, g.Pjs)();
          return (0, p.useCallback)(
            (n3) => {
              if (!e11) return;
              let r3 = (0, F.Fx)({
                params: {
                  hash: t3,
                  pageId: F.QT.Sidebar,
                  sidebarSize: n3 || i3 ? F.JQ.Small : F.JQ.Medium,
                  sidebarPosition: i3 ? F.Vw.Bottom : F.Vw.Left
                },
                logger: a3,
                context: "useSendEventOnSidebarOpened"
              });
              r3 && (0, F.U0)(e11.evgenInstance, r3);
            },
            [e11, t3, i3, a3]
          );
        })(), _2 = null != i2 ? i2 : s2, v2 = null != n2 ? n2 : c2, h2 = (0, p.useMemo)(() => o2 ? tL : tk, [o2]), x2 = (0, U.c)((e11) => {
          e11.stopPropagation(), e11.preventDefault();
          let t3 = !_2;
          r2.set(g.cYZ.NavbarCollapsed, t3, { expires: 180 }), v2(t3), u2(true);
        });
        return (0, p.useEffect)(() => {
          m2(_2 || l2);
        }, [l2, _2, m2]), (0, O.jsx)("aside", {
          className: (0, R.$)(W().root, { [W().root_collapsed]: _2 || l2 }, a2),
          ...(0, K.Am)(K.e8.navbar.NAVBAR),
          children: (0, O.jsx)(h2, { handleClick: x2, isCollapsed: _2 || l2, shownAnimation: d2 })
        });
      });
    },
    50328: (e) => {
      e.exports = {
        icon: "SyncLyricsButton_icon__m0Gdk",
        icon_active: "SyncLyricsButton_icon_active__6WcWG",
        animation_scaled: "SyncLyricsButton_animation_scaled__vwsc_",
        scale: "SyncLyricsButton_scale__FGAYV",
        animation_unscaled: "SyncLyricsButton_animation_unscaled__eM1Wb",
        unscale: "SyncLyricsButton_unscale__ceLQu"
      };
    },
    51935: (e) => {
      e.exports = {
        root: "PlayerBarMobile_root__cdKy_",
        progressBar: "PlayerBarMobile_progressBar___DmH8",
        info: "PlayerBarMobile_info__WmdhZ",
        infoCard: "PlayerBarMobile_infoCard__DCATu",
        coverContainer: "PlayerBarMobile_coverContainer__a3JDF",
        cover: "PlayerBarMobile_cover__pnJd1",
        description: "PlayerBarMobile_description__IxQ9L",
        artists: "PlayerBarMobile_artists__XVSBV",
        artistLink: "PlayerBarMobile_artistLink__pieMq",
        infoButtons: "PlayerBarMobile_infoButtons__JXxfv",
        sliderChangeTimeCode: "PlayerBarMobile_sliderChangeTimeCode___2Vpu",
        backgroundProgress: "PlayerBarMobile_backgroundProgress__jevhK",
        shimmerCover: "PlayerBarMobile_shimmerCover__q1eXc",
        shimmerMeta: "PlayerBarMobile_shimmerMeta__4vDEK",
        shimmerMetaTitle: "PlayerBarMobile_shimmerMetaTitle__TsIb2",
        shimmerMetaDescription: "PlayerBarMobile_shimmerMetaDescription__pIeAr"
      };
    },
    53226: (e) => {
      e.exports = {
        root: "VideoPlayerBarDesktop_root__OxypO",
        info: "VideoPlayerBarDesktop_info__ulYvU",
        infoCard: "VideoPlayerBarDesktop_infoCard__mE___",
        coverContainer: "VideoPlayerBarDesktop_coverContainer__xV_VP",
        cover: "VideoPlayerBarDesktop_cover__Nf4WW",
        description: "VideoPlayerBarDesktop_description__sAiwG",
        artists: "VideoPlayerBarDesktop_artists__PNY62",
        artistLink: "VideoPlayerBarDesktop_artistLink__FgFZ8",
        infoButtons: "VideoPlayerBarDesktop_infoButtons__9xWZ3",
        sonata: "VideoPlayerBarDesktop_sonata__VrtGS",
        meta: "VideoPlayerBarDesktop_meta__KlPBv",
        slider: "VideoPlayerBarDesktop_slider__xULTh",
        important: "VideoPlayerBarDesktop_important__HR9Xf"
      };
    },
    54278: (e, t, a) => {
      "use strict";
      a.d(t, { h: () => C, A: () => l });
      var i = a(93064), n = a(74125), r = a(26433);
      let l = i.gK.model({ modal: r.qt }).views((e2) => ({
        shouldShow() {
          var t2;
          let { user: a2, settings: r2 } = (0, i.Zn)(e2), { sessionStorage: l2 } = (0, i._$)(e2);
          if (!a2.hasPlus || !(null == (t2 = r2.browserInfo) ? void 0 : t2.isMobile)) return false;
          let o2 = l2.get(n.cYZ.DownloadMobileApp);
          return null == o2 || !o2.shown;
        }
      })).actions((e2) => ({
        openModal() {
          var t2;
          let { localStorage: a2, sessionStorage: r2 } = (0, i._$)(e2);
          if (!(null == (t2 = a2.get(n.cYZ.DownloadMobileApp)) ? void 0 : t2.shown)) {
            e2.modal.open(), a2.set(n.cYZ.DownloadMobileApp, { shown: true }), r2.set(n.cYZ.DownloadMobileApp, { shown: true });
            return;
          }
          setTimeout(() => {
            e2.modal.open();
          }, 5e3), r2.set(n.cYZ.DownloadMobileApp, { shown: true });
        }
      }));
      var o = a(54486), s = a(28303), c = a(32692), d = a(50420), u = a(43426), m = a(47713), _ = a(77881), p = a(5956), v = a(65749), h = a(97800), g = a(66e3), x = a.n(g);
      let y = (0, s.PA)(() => {
        let { downloadMobileApp: e2, user: t2, settings: a2 } = (0, n.Pjs)(), { formatMessage: i2 } = (0, u.A)(), r2 = (0, n.qQp)({ browserInfo: a2.browserInfo, login: t2.account.data.login });
        return (0, o.jsxs)("div", {
          className: (0, d.$)(x().root, (0, n.JH_)(n.Sxu.Dark)),
          children: [
            (0, o.jsx)(_.$, {
              className: x().closeButton,
              radius: "round",
              size: "xxs",
              icon: (0, o.jsx)(p.Icon, { variant: "close", size: "xxs" }),
              "aria-label": i2({ id: "interface-actions.close" }),
              onClick: e2.modal.close
            }),
            (0, o.jsxs)("div", {
              className: x().text,
              children: [
                (0, o.jsx)(h.Heading, {
                  variant: "h1",
                  size: "xl",
                  weight: "bold",
                  children: (0, o.jsx)(m.A, { id: "download-mobile-app.title", values: { nbsp: " " } })
                }),
                (0, o.jsx)(h.Caption, {
                  className: x().subtitle,
                  variant: "p",
                  size: "l",
                  weight: "bold",
                  children: (0, o.jsx)(m.A, { id: "download-mobile-app.subtitle", values: { nbsp: " " } })
                })
              ]
            }),
            (0, o.jsxs)("div", {
              className: x().buttons,
              children: [
                (0, o.jsx)(v.N, {
                  className: x().listenInAppLink,
                  href: r2(),
                  children: (0, o.jsx)(_.$, {
                    className: x().button,
                    color: "primary",
                    size: "m",
                    radius: "xxxl",
                    children: (0, o.jsx)(h.Caption, {
                      variant: "span",
                      size: "m",
                      weight: "medium",
                      children: (0, o.jsx)(m.A, { id: "download-mobile-app.listen-in-app" })
                    })
                  })
                }),
                (0, o.jsx)(_.$, {
                  className: (0, d.$)(x().button, x().stayButton),
                  variant: "text",
                  size: "m",
                  color: "secondary",
                  radius: "xxxl",
                  onClick: e2.modal.close,
                  children: (0, o.jsx)(h.Caption, {
                    variant: "span",
                    size: "m",
                    weight: "medium",
                    children: (0, o.jsx)(m.A, { id: "download-mobile-app.stay" })
                  })
                })
              ]
            })
          ]
        });
      });
      var b = a(48910), A = a.n(b);
      let C = (0, s.PA)(() => {
        let { downloadMobileApp: e2 } = (0, n.Pjs)();
        return (0, o.jsx)(c.a, {
          className: A().root,
          contentClassName: A().content,
          open: e2.modal.isOpened,
          size: "fullscreen",
          placement: "center",
          showHeader: false,
          closeOnOutsidePress: false,
          overlayColor: "full",
          onOpenChange: e2.modal.onOpenChange,
          onClose: e2.modal.close,
          children: (0, o.jsx)(y, {})
        });
      });
    },
    56985: (e) => {
      e.exports = {
        image: "FamilyInviteErrorView_image__OyVA_",
        image_small: "FamilyInviteErrorView_image_small__uczsu"
      };
    },
    57477: (e) => {
      e.exports = {
        image: "FamilyInviteStepSuccess_image__kDBnc",
        image_mobile: "FamilyInviteStepSuccess_image_mobile__PyiXK"
      };
    },
    59408: (e) => {
      e.exports = {
        root: "NavbarMobile_root__NhKBQ",
        user: "NavbarMobile_user__vTEb2",
        disabledNavigationItem: "NavbarMobile_disabledNavigationItem__PA3EE"
      };
    },
    60640: (e) => {
      e.exports = {
        root: "NavbarDesktopAnimatedDownloadBarEnlarged_root__5lnM0",
        closeButton: "NavbarDesktopAnimatedDownloadBarEnlarged_closeButton__MSz9j",
        text: "NavbarDesktopAnimatedDownloadBarEnlarged_text__fT36E",
        downloadButtonText: "NavbarDesktopAnimatedDownloadBarEnlarged_downloadButtonText__3GqKa",
        textBright: "NavbarDesktopAnimatedDownloadBarEnlarged_textBright__JA1nf",
        closeButtonIcon: "NavbarDesktopAnimatedDownloadBarEnlarged_closeButtonIcon___xaoS",
        downloadButtonIcon: "NavbarDesktopAnimatedDownloadBarEnlarged_downloadButtonIcon__oE_rc"
      };
    },
    60927: (e) => {
      e.exports = {
        root: "NavbarDesktopAnimatedBar_root__tTyvO",
        bar: "NavbarDesktopAnimatedBar_bar__Wge_o",
        bar_enter: "NavbarDesktopAnimatedBar_bar_enter__pUWOV",
        bar_enter_active: "NavbarDesktopAnimatedBar_bar_enter_active__cYAzl",
        animation_show: "NavbarDesktopAnimatedBar_animation_show__oAMq1",
        animation_scale: "NavbarDesktopAnimatedBar_animation_scale__iOhup",
        bar_exit: "NavbarDesktopAnimatedBar_bar_exit__Wq1AL",
        bar_exit_active: "NavbarDesktopAnimatedBar_bar_exit_active__EZFDU",
        animation_hide: "NavbarDesktopAnimatedBar_animation_hide__Eiu1e",
        animation_unscale: "NavbarDesktopAnimatedBar_animation_unscale__gyZb6",
        button: "NavbarDesktopAnimatedBar_button__T7n21",
        button_enter: "NavbarDesktopAnimatedBar_button_enter__6v5a5",
        button_enter_active: "NavbarDesktopAnimatedBar_button_enter_active__jZmtw",
        button_exit: "NavbarDesktopAnimatedBar_button_exit__j8qXO",
        button_exit_active: "NavbarDesktopAnimatedBar_button_exit_active__D5JJp"
      };
    },
    61528: (e) => {
      e.exports = {
        root: "TrackModalControls_root__alpd3",
        controlsContainer: "TrackModalControls_controlsContainer__UeQb4",
        menuWrapper: "TrackModalControls_menuWrapper__tDLID",
        menuButton: "TrackModalControls_menuButton__V6L4c",
        disabledButtonByDisclaimer: "TrackModalControls_disabledButtonByDisclaimer__qfCvg"
      };
    },
    61931: (e) => {
      e.exports = {
        icon: "NotificationHtmlCodeCopied_icon__qJMbi",
        message: "NotificationHtmlCodeCopied_message__ivRvX"
      };
    },
    62937: (e) => {
      e.exports = {
        root: "PlayerBarDesktop_root__d2Hwi",
        info: "PlayerBarDesktop_info__56v53",
        infoCard: "PlayerBarDesktop_infoCard__tnLS6",
        coverContainer: "PlayerBarDesktop_coverContainer__2Z5nQ",
        cover: "PlayerBarDesktop_cover__IYLwR",
        description: "PlayerBarDesktop_description__eQ_tA",
        artists: "PlayerBarDesktop_artists__N5vpf",
        artistLink: "PlayerBarDesktop_artistLink__Btgdq",
        infoButtons: "PlayerBarDesktop_infoButtons__iSpa_",
        sonata: "PlayerBarDesktop_sonata__sJHY_",
        meta: "PlayerBarDesktop_meta__6sm58",
        settingsButton: "PlayerBarDesktop_settingsButton__jLkVn"
      };
    },
    63006: (e, t, a) => {
      "use strict";
      a.d(t, { p: () => n });
      var i = a(63585);
      function n(e2) {
        return (null == e2 ? void 0 : e2.data.type) === i.K.Various;
      }
    },
    64052: (e) => {
      e.exports = {
        root: "BarBelow_root__KFexT",
        root_hidden: "BarBelow_root_hidden__eTKvU",
        root_show: "BarBelow_root_show__yIQBX",
        show: "BarBelow_show__5GQBP",
        root_hide: "BarBelow_root_hide__d1a_5",
        hide: "BarBelow_hide__a0dwD",
        image: "BarBelow_image__GfExj",
        content: "BarBelow_content__GWWbR",
        title: "BarBelow_title__hBNPY",
        text: "BarBelow_text__tU_Rm",
        buttons: "BarBelow_buttons__XGwDQ"
      };
    },
    64336: (e, t, a) => {
      "use strict";
      a.d(t, { K: () => n });
      var i = a(63585);
      function n(e2) {
        return (null == e2 ? void 0 : e2.data.type) === i.K.Playlist;
      }
    },
    65857: (e) => {
      e.exports = {
        root: "TrackModalTitleShimmer_root__woixY",
        entityName: "TrackModalTitleShimmer_entityName__9NMYB",
        title: "TrackModalTitleShimmer_title__PXJfS",
        artists: "TrackModalTitleShimmer_artists__mz6q9",
        important: "TrackModalTitleShimmer_important__uBJ8_",
        artist: "TrackModalTitleShimmer_artist__fre6F",
        controls: "TrackModalTitleShimmer_controls__0kNh8",
        playButton: "TrackModalTitleShimmer_playButton__PYklv",
        button: "TrackModalTitleShimmer_button__j5_GI"
      };
    },
    66e3: (e) => {
      e.exports = {
        root: "DownloadMobileApp_root__RU7VS",
        closeButton: "DownloadMobileApp_closeButton__t38Rw",
        text: "DownloadMobileApp_text__bCbs3",
        subtitle: "DownloadMobileApp_subtitle__vPtiS",
        buttons: "DownloadMobileApp_buttons__mL4w1",
        listenInAppLink: "DownloadMobileApp_listenInAppLink__flOyk",
        button: "DownloadMobileApp_button__r0E7Z",
        stayButton: "DownloadMobileApp_stayButton__k3Ot8"
      };
    },
    66498: (e, t, a) => {
      "use strict";
      a.d(t, { x8: () => Y, J4: () => _, _n: () => i, hj: () => o });
      var i = (function(e2) {
        return e2.INFO = "INFO", e2.SUCCESS = "SUCCESS", e2;
      })({}), n = a(61910), r = a(74125);
      let l = { INVITE_ID: "invite_id", UTM_MEDIUM: "utm_medium" }, o = () => {
        let { user: e2 } = (0, r.Pjs)(), t2 = (0, r.XJ9)(), { inviteIdSearchParam: a2, hasNecessarySearchParams: i2 } = (0, n.useMemo)(() => {
          let e3 = (0, r.qne)(l.INVITE_ID), t3 = !!(e3 && "copy_link" === (0, r.qne)(l.UTM_MEDIUM));
          return { inviteIdSearchParam: e3, hasNecessarySearchParams: t3 };
        }, []), o2 = (0, n.useCallback)(() => {
          let e3 = (0, r.jrm)();
          if (null === e3) return;
          e3.delete(l.INVITE_ID), e3.delete(l.UTM_MEDIUM);
          let a3 = new URL(window.location.href);
          a3.search = e3.toString(), t2(a3.toString());
        }, [t2]);
        return { inviteId: a2, shouldShowFamilyInvite: !!(!e2.hasPlus && i2), clear: o2 };
      };
      var s = a(93064), c = a(14287), d = a(26433), u = (function(e2) {
        return e2.SUBSCRIPTION_IS_NOT_AVAILABLE = "SUBSCRIPTION_IS_NOT_AVAILABLE", e2.INVITATION_IS_INVALID = "INVITATION_IS_INVALID", e2.UNKNOWN = "UNKNOWN", e2;
      })({});
      let m = s.gK.model("FamilyInviteInfoModel", { name: s.gK.string, avatarUrl: s.gK.string }), _ = s.gK.model("FamilyInviteModel", {
        info: s.gK.model({ loadingState: s.gK.enumeration(Object.values(r.GuX)), data: s.gK.maybeNull(m) }),
        acceptanceLoadingState: s.gK.enumeration(Object.values(r.GuX)),
        isSuccess: s.gK.maybe(s.gK.boolean),
        modal: d.qt,
        step: s.gK.enumeration("Step", Object.values(i)),
        inviteId: s.gK.maybeNull(s.gK.string),
        error: s.gK.maybeNull(s.gK.enumeration(Object.values(u)))
      }).views((e2) => ({
        get hasError() {
          return !!e2.error;
        },
        get isInfoShimmerVisible() {
          return e2.info.loadingState === r.GuX.IDLE || e2.info.loadingState === r.GuX.PENDING;
        },
        get isInfoShimmerActive() {
          return e2.info.loadingState === r.GuX.PENDING;
        },
        get isAcceptanceActive() {
          return e2.acceptanceLoadingState === r.GuX.PENDING;
        }
      })).actions((e2) => {
        let t2 = {
          start(a2) {
            t2.setInviteId(a2), e2.modal.open(), t2.getInviteInfo();
          },
          retry: (0, s.L3)(function* () {
            t2.setError(null), t2.toggleStepInfo(), e2.info.loadingState !== r.GuX.RESOLVE && (yield t2.getInviteInfo());
          }),
          getInviteInfo: (0, s.L3)(function* () {
            let { familyResource: a2, modelActionsLogger: i2 } = (0, s._$)(e2);
            if (e2.inviteId && e2.info.loadingState !== r.GuX.PENDING)
              try {
                e2.info.loadingState = r.GuX.PENDING;
                let i3 = { inviteId: e2.inviteId }, n2 = yield a2.getInviteInfo(i3);
                if (!n2.hasPlus) {
                  t2.setError(u.SUBSCRIPTION_IS_NOT_AVAILABLE), e2.info.loadingState = r.GuX.RESOLVE;
                  return;
                }
                e2.info.data = ((e3) => {
                  let { name: t3, avatarUrl: a3 } = e3;
                  return (0, s.wg)({ name: t3, avatarUrl: a3 });
                })(n2), e2.info.loadingState = r.GuX.RESOLVE;
              } catch (a3) {
                if (e2.info.loadingState = r.GuX.REJECT, i2.error(a3), a3 instanceof c.GX && a3.statusCode === c.X1.BAD_REQUEST)
                  return void t2.setError(u.INVITATION_IS_INVALID);
                t2.setError(u.UNKNOWN);
              }
          }),
          acceptInvite: (0, s.L3)(function* () {
            let { familyResource: a2, modelActionsLogger: i2 } = (0, s._$)(e2);
            if (e2.inviteId && e2.acceptanceLoadingState !== r.GuX.PENDING)
              try {
                e2.acceptanceLoadingState = r.GuX.PENDING;
                let i3 = { inviteId: e2.inviteId };
                yield a2.acceptInvite(i3), e2.acceptanceLoadingState = r.GuX.RESOLVE, t2.toggleStateSuccessTrue();
              } catch (a3) {
                if (e2.acceptanceLoadingState = r.GuX.REJECT, i2.error(a3), a3 instanceof c.GX && a3.statusCode === c.X1.BAD_REQUEST)
                  return void t2.setError(u.INVITATION_IS_INVALID);
                t2.setError(u.UNKNOWN);
              }
          }),
          toggleStepInfo() {
            e2.step = i.INFO;
          },
          toggleStepSuccess() {
            e2.step = i.SUCCESS;
          },
          setError(t3) {
            e2.error = t3;
          },
          setInviteId(t3) {
            e2.inviteId = t3;
          },
          toggleStateSuccessTrue() {
            t2.toggleStepSuccess(), e2.isSuccess = true;
          },
          reset() {
            e2.acceptanceLoadingState = r.GuX.IDLE, e2.error = null, e2.info.loadingState = r.GuX.IDLE, e2.info.data = null, e2.inviteId = null, e2.step = i.INFO, e2.isSuccess = false;
          }
        };
        return t2;
      });
      var p = a(54486), v = a(28303), h = a(31500), g = a(80585);
      let x = () => {
        let {
          familyInvite: { modal: e2, isSuccess: t2, reset: a2 }
        } = (0, r.Pjs)();
        return (0, n.useCallback)(() => {
          if (e2.close(), t2) return void window.location.reload();
          a2();
        }, [e2, t2, a2]);
      };
      var y = a(50420), b = a(58360), A = a(56985), C = a.n(A), N = a(43426), f = a(47713), I = a(97800);
      let S = (0, v.PA)(() => {
        let { formatMessage: e2 } = (0, N.A)(), {
          settings: { isMobile: t2 }
        } = (0, r.Pjs)(), a2 = x();
        return (0, p.jsxs)(p.Fragment, {
          children: [
            (0, p.jsxs)("div", {
              className: g.SE.text,
              children: [
                (0, p.jsx)(I.Heading, {
                  variant: "h1",
                  size: "xl",
                  className: g.SE.title,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_TITLE),
                  children: (0, p.jsx)(f.A, { id: "family.invitation-error-title" })
                }),
                (0, p.jsx)(I.Caption, {
                  variant: "span",
                  size: "m",
                  className: g.SE.description,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_DESCRIPTION),
                  children: (0, p.jsx)(f.A, { id: "family.invitation-error-description" })
                })
              ]
            }),
            (0, p.jsx)("div", {
              className: g.SE.buttons,
              children: (0, p.jsx)(g.mv, {
                color: "primary",
                isMobile: t2,
                text: e2({ id: "interface-actions.confirm" }),
                onClick: a2,
                ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_INVITATION_ERROR_BUTTON_CONFIRM)
              })
            })
          ]
        });
      }), T = (0, v.PA)(() => {
        let { formatMessage: e2 } = (0, N.A)(), {
          settings: { isMobile: t2 },
          paywall: { modal: a2 }
        } = (0, r.Pjs)(), i2 = x(), l2 = (0, n.useCallback)(() => {
          i2(), a2.open();
        }, [i2, a2]);
        return (0, p.jsxs)(p.Fragment, {
          children: [
            (0, p.jsxs)("div", {
              className: g.SE.text,
              children: [
                (0, p.jsx)(I.Heading, {
                  variant: "h1",
                  size: "xl",
                  className: g.SE.title,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_TITLE),
                  children: (0, p.jsx)(f.A, { id: "family.subscription-error-title" })
                }),
                (0, p.jsx)(I.Caption, {
                  variant: "span",
                  size: "m",
                  className: g.SE.description,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_DESCRIPTION),
                  children: (0, p.jsx)(f.A, { id: "family.subscription-error-description" })
                })
              ]
            }),
            (0, p.jsxs)("div", {
              className: g.SE.buttons,
              children: [
                (0, p.jsx)(g.mv, {
                  color: "primary",
                  isMobile: t2,
                  text: e2({ id: "family.about1" }),
                  onClick: l2,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_SUBSCRIPTION_ERROR_BUTTON_ABOUT)
                }),
                (0, p.jsx)(g.mv, {
                  color: "secondary",
                  isMobile: t2,
                  text: (0, p.jsx)(f.A, { id: "family.later" }),
                  onClick: i2,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_SUBSCRIPTION_ERROR_BUTTON_LATER)
                })
              ]
            })
          ]
        });
      }), P = (0, v.PA)(() => {
        let { formatMessage: e2 } = (0, N.A)(), {
          familyInvite: { retry: t2 }
        } = (0, r.Pjs)();
        return (0, p.jsxs)(p.Fragment, {
          children: [
            (0, p.jsxs)("div", {
              className: g.SE.text,
              children: [
                (0, p.jsx)(I.Heading, {
                  variant: "h1",
                  size: "xl",
                  className: g.SE.title,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_TITLE),
                  children: (0, p.jsx)(f.A, { id: "family.unknown-error-title" })
                }),
                (0, p.jsx)(I.Caption, {
                  variant: "span",
                  size: "m",
                  className: g.SE.description,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_DESCRIPTION),
                  children: (0, p.jsx)(f.A, { id: "family.unknown-error-description" })
                })
              ]
            }),
            (0, p.jsx)("div", {
              className: g.SE.buttons,
              children: (0, p.jsx)(g.mv, {
                color: "primary",
                text: e2({ id: "family.retry" }),
                onClick: t2,
                ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_ERROR_UNKNOWN_ERROR_BUTTON_RETRY)
              })
            })
          ]
        });
      }), k = {
        [u.INVITATION_IS_INVALID]: (0, p.jsx)(S, {}),
        [u.SUBSCRIPTION_IS_NOT_AVAILABLE]: (0, p.jsx)(T, {}),
        [u.UNKNOWN]: (0, p.jsx)(P, {})
      }, E = (0, v.PA)(() => {
        let {
          familyInvite: { error: e2 },
          settings: { isMobile: t2 }
        } = (0, r.Pjs)(), a2 = t2 || e2 === u.SUBSCRIPTION_IS_NOT_AVAILABLE;
        return (0, p.jsxs)(p.Fragment, {
          children: [
            (0, p.jsx)("div", {
              className: (0, y.$)(g.SE.growContainer, g.SE.growContainer_withoutPaddings),
              children: (0, p.jsx)(b.Image, {
                className: (0, y.$)(C().image, { [C().image_small]: a2 }),
                src: "https://avatars.mds.yandex.net/get-music-misc/49997/img.6724b88e3c0f01402213116b/orig",
                srcSet: "https://avatars.mds.yandex.net/get-music-misc/70850/img.6724b88c3c0f01402213116a/orig 2x",
                fit: "contain",
                "aria-hidden": true
              })
            }),
            k[null != e2 ? e2 : u.UNKNOWN]
          ]
        });
      });
      var j = a(97396), L = a(5956), w = a(49320), M = a(4073), B = a.n(M);
      let O = (e2) => {
        let { avatarSrc: t2, name: a2, isMobile: i2 } = e2;
        return (0, p.jsxs)("div", {
          className: (0, y.$)(B().root, { [B().root_mobile]: i2 }),
          children: [
            (0, p.jsx)(w.ny, {
              className: (0, y.$)(B().icon, B().important),
              avatarSrc: t2,
              hasPlus: true,
              ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_INFO_INVITER_AVATAR)
            }),
            (0, p.jsx)(I.Caption, {
              className: B().name,
              variant: "div",
              size: "m",
              ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_INFO_INVITER_NAME),
              children: a2
            })
          ]
        });
      };
      var R = a(22674);
      let D = (e2) => {
        let { isActive: t2, isMobile: a2 } = e2;
        return (0, p.jsxs)("div", {
          className: (0, y.$)(B().root, { [B().root_mobile]: a2 }),
          children: [
            (0, p.jsx)(R.Shimmer, { className: B().iconShimmer, isActive: t2, radius: "round" }),
            (0, p.jsx)(R.Shimmer, { className: B().nameShimmer, isActive: t2, radius: "xs" })
          ]
        });
      };
      var K = a(23605), U = a.n(K);
      let F = (0, v.PA)(() => {
        let {
          user: e2,
          location: t2,
          settings: { isMobile: a2 },
          familyInvite: {
            isInfoShimmerVisible: i2,
            isInfoShimmerActive: l2,
            isAcceptanceActive: o2,
            info: { data: s2 },
            acceptInvite: c2
          }
        } = (0, r.Pjs)(), { name: d2 = "", avatarUrl: u2 = "" } = s2 || {}, m2 = (0, r.NFA)(), _2 = (0, j.useRouter)(), v2 = m2.get(r.QGx), b2 = x(), A2 = (0, n.useCallback)(() => {
          if (!e2.isAuthorized) {
            v2.authorizationUrl && _2.push(v2.authorizationUrl);
            return;
          }
          c2();
        }, [v2.authorizationUrl, _2, e2.isAuthorized, c2]), C2 = (0, n.useMemo)(
          () => i2 ? (0, p.jsx)(D, { isActive: l2, isMobile: a2 }) : (0, p.jsx)(O, { avatarSrc: u2, name: d2, isMobile: a2 }),
          [i2, l2, a2, u2, d2]
        ), N2 = (0, n.useMemo)(
          () => i2 ? (0, p.jsx)(g.bb, { isActive: l2, isMobile: a2 }) : (0, p.jsx)(g.mv, {
            color: "plus",
            isMobile: a2,
            text: (0, p.jsx)(f.A, { id: "family.accept" }),
            onClick: A2,
            showSpinner: o2,
            ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_INFO_BUTTON_ACCEPT)
          }),
          [i2, l2, o2, a2, A2]
        );
        return (0, p.jsxs)(p.Fragment, {
          children: [
            (0, p.jsx)("div", {
              className: (0, y.$)(g.SE.growContainer, U().growContainer, U().important),
              children: C2
            }),
            (0, p.jsxs)("div", {
              className: g.SE.text,
              children: [
                (0, p.jsx)(I.Heading, {
                  variant: "h1",
                  size: "xl",
                  className: g.SE.title,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_INFO_TITLE),
                  children: (0, p.jsx)(f.A, { id: "family.info-title", values: { br: "\n" } })
                }),
                (0, p.jsx)(I.Caption, {
                  variant: "span",
                  size: "m",
                  className: g.SE.description,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_INFO_DESCRIPTION),
                  children: (0, p.jsx)(f.A, { id: "family.info-description", values: { br: "\n" } })
                }),
                (0, p.jsx)(g.N_, {
                  target: "_blank",
                  href: "https://yandex.".concat(t2.tld, "/legal/yandex_plus_conditions/"),
                  icon: (0, p.jsx)(L.Icon, { variant: "arrowRight", size: "xxxs", className: g.SE.linkArrow }),
                  iconPosition: "right",
                  className: g.SE.link,
                  containerClassName: g.SE.linkContainer,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_INFO_TERMS),
                  children: (0, p.jsx)(I.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, p.jsx)(f.A, { id: "family.terms" })
                  })
                })
              ]
            }),
            (0, p.jsxs)("div", {
              className: g.SE.buttons,
              children: [
                N2,
                (0, p.jsx)(g.mv, {
                  color: "secondary",
                  isMobile: a2,
                  text: (0, p.jsx)(f.A, { id: "family.reject" }),
                  onClick: b2,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_INFO_BUTTON_REJECT)
                })
              ]
            })
          ]
        });
      });
      var z = a(57477), V = a.n(z);
      let W = (0, v.PA)(() => {
        let {
          location: e2,
          settings: { isMobile: t2 }
        } = (0, r.Pjs)(), a2 = x();
        return (0, p.jsxs)(p.Fragment, {
          children: [
            (0, p.jsx)("div", {
              className: g.SE.growContainer,
              children: (0, p.jsx)(b.Image, {
                className: (0, y.$)(V().image, { [V().image_mobile]: t2 }),
                src: "https://avatars.mds.yandex.net/get-music-misc/2406661/img.6724a5445724776f278ec59d/orig",
                srcSet: "https://avatars.mds.yandex.net/get-music-misc/2406661/img.6724a5445724776f278ec59d/orig 2x",
                fit: "contain",
                "aria-hidden": true
              })
            }),
            (0, p.jsxs)("div", {
              className: g.SE.text,
              children: [
                (0, p.jsx)(I.Heading, {
                  variant: "h1",
                  size: "xl",
                  className: g.SE.title,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_SUCCESS_TITLE),
                  children: (0, p.jsx)(f.A, { id: "family.success-title" })
                }),
                (0, p.jsx)(I.Caption, {
                  variant: "span",
                  size: "m",
                  className: g.SE.description,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_SUCCESS_DESCRIPTION),
                  children: (0, p.jsx)(f.A, { id: "family.success-description", values: { br: "\n" } })
                }),
                (0, p.jsx)(g.N_, {
                  target: "_blank",
                  href: "https://plus.yandex.".concat(e2.tld, "/"),
                  icon: (0, p.jsx)(L.Icon, { variant: "arrowRight", size: "xxxs", className: g.SE.linkArrow }),
                  iconPosition: "right",
                  className: g.SE.link,
                  containerClassName: g.SE.linkContainer,
                  ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_SUCCESS_ABOUT),
                  children: (0, p.jsx)(I.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, p.jsx)(f.A, { id: "family.about" })
                  })
                })
              ]
            }),
            (0, p.jsx)("div", {
              className: g.SE.buttons,
              children: (0, p.jsx)(g.mv, {
                color: "plus",
                isMobile: t2,
                text: (0, p.jsx)(f.A, { id: "family.go-to-music" }),
                onClick: a2,
                ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL_STEP_SUCCESS_BUTTON_FINISH)
              })
            })
          ]
        });
      }), G = { [i.INFO]: (0, p.jsx)(F, {}), [i.SUCCESS]: (0, p.jsx)(W, {}) }, Y = (0, v.PA)(() => {
        let {
          familyInvite: { modal: e2, step: t2, hasError: a2 }
        } = (0, r.Pjs)(), i2 = x(), l2 = (0, n.useCallback)(
          (t3) => {
            t3 || i2(), e2.onOpenChange(t3);
          },
          [i2, e2]
        ), o2 = (0, n.useMemo)(() => a2 ? (0, p.jsx)(E, {}) : G[t2], [a2, t2]);
        return (0, p.jsx)(g.cu, {
          open: e2.isOpened,
          hasError: a2,
          onOpenChange: l2,
          onClose: i2,
          ...(0, h.Am)(h.e8.familyInvite.FAMILY_INVITE_MODAL),
          children: o2
        });
      });
    },
    66570: (e, t, a) => {
      "use strict";
      a.d(t, { F: () => n });
      var i = a(63585);
      function n(e2) {
        return (null == e2 ? void 0 : e2.data.type) === i.K.Album;
      }
    },
    67250: (e, t, a) => {
      "use strict";
      var i;
      a.d(t, { v: () => i }), (function(e2) {
        e2.ON_START_BAR_BELOW = "music-web-on-start-bar-bellow", e2.ON_START_FULLSCREEN = "music-web-on-start-fullscreen";
      })(i || (i = {}));
    },
    67418: (e) => {
      e.exports = {
        title: "TrackModalTitle_title__3zfNn",
        important: "TrackModalTitle_important__qNVlq",
        content: "TrackModalTitle_content__mtQKw",
        explicitMark: "TrackModalTitle_explicitMark__aRT_I",
        text: "TrackModalTitle_text__3iWX4",
        artistCaption: "TrackModalTitle_artistCaption__Sj1CR",
        link: "TrackModalTitle_link__kzVsl",
        meta: "TrackModalTitle_meta__xlEgt",
        entityName: "TrackModalTitle_entityName__BRnTV"
      };
    },
    68023: (e) => {
      e.exports = {
        root: "BuySubscriptionButton_root__BdquR",
        root_hidden: "BuySubscriptionButton_root_hidden__oMe3p",
        info: "BuySubscriptionButton_info__qBinu",
        subtitle: "BuySubscriptionButton_subtitle__Ni4VS",
        title: "BuySubscriptionButton_title__RG_OU",
        buttonText: "BuySubscriptionButton_buttonText__cmJMC",
        titleContainer: "BuySubscriptionButton_titleContainer__h7Lmt",
        titleShimmer: "BuySubscriptionButton_titleShimmer___hnah",
        titleShimmerContainer: "BuySubscriptionButton_titleShimmerContainer__Wv82r",
        icon: "BuySubscriptionButton_icon__0oNi_"
      };
    },
    68326: (e) => {
      e.exports = {
        root: "SyncLyricsLoader_root__I2hTe",
        element: "SyncLyricsLoader_element___Luwv",
        pulse: "SyncLyricsLoader_pulse__5AqRf",
        "change-opacity": "SyncLyricsLoader_change-opacity__vscya",
        element_withIcon: "SyncLyricsLoader_element_withIcon__iiSBo",
        element_withDefaultElement: "SyncLyricsLoader_element_withDefaultElement__WmP80",
        element_paused: "SyncLyricsLoader_element_paused__LFpD0"
      };
    },
    68529: (e) => {
      e.exports = { root: "Navbar_root__chF4R", root_collapsed: "Navbar_root_collapsed__pozJX" };
    },
    69306: (e, t, a) => {
      "use strict";
      a.d(t, { u: () => x, y: () => n });
      var i = a(74125);
      let n = () => {
        let { isFreemium: e2 } = (0, i.XCI)(), {
          user: t2,
          advertBanners: {
            banners: { sideAdvertBanner: a2 }
          }
        } = (0, i.Pjs)();
        return !!a2.isVisible && (!t2.isAuthorized || e2);
      };
      var r = a(54486), l = a(50420), o = a(28303), s = a(61910), c = a(43426), d = a(47713), u = a(77881), m = a(97800), _ = a(80585);
      let p = { p1: "bwvvu", p2: "foom", puid1: "", puid2: "" };
      var v = a(99092), h = a.n(v);
      let g = (0, o.PA)((e2) => {
        let { className: t2, forwardRef: a2 } = e2, {
          advertBanners: {
            banners: { sideAdvertBanner: n2 }
          },
          experiments: o2,
          paywall: { modal: s2 }
        } = (0, i.Pjs)(), { formatMessage: v2 } = (0, c.A)(), g2 = n2.type !== i.h8o.EMPTY && o2.checkExperiment(i.zal.WebNextCloseAdsSideBanner, "on");
        return (0, r.jsxs)("section", {
          className: (0, l.$)(h().root, t2, { [h().root_hidden]: !n2.isVisible }),
          "aria-label": v2({ id: "advert.banner" }),
          role: "banner",
          ref: a2,
          children: [
            (0, r.jsx)("div", {
              className: h().contentWrapper,
              children: (0, r.jsx)(_.NX, {
                className: h().content,
                ownerId: i.PVv,
                containerId: "adfox_173831489302952769",
                params: p,
                onLoad: n2.setType,
                onError: n2.toggleHasErrorTrue,
                onNoAds: n2.toggleNoAdsTrue
              })
            }),
            g2 && (0, r.jsx)(u.$, {
              className: h().disableAdsButton,
              onClick: s2.open,
              size: "default",
              radius: "xxxl",
              children: (0, r.jsx)(m.Caption, {
                className: h().adsCloseText,
                variant: "span",
                size: "m",
                children: (0, r.jsx)(d.A, { id: "ads.disable-ads" })
              })
            })
          ]
        });
      }), x = (0, s.forwardRef)((e2, t2) => (0, r.jsx)(g, { forwardRef: t2, ...e2 }));
    },
    69610: (e, t, a) => {
      "use strict";
      a.d(t, { BZ: () => S, FB: () => j });
      var i = a(54486), n = a(50420), r = a(28303), l = a(43426), o = a(47713), s = a(8817), c = a(67648), d = a(77881), u = a(58360), m = a(22674), _ = a(97800), p = a(74125);
      let v = { src: "/_next/static/media/logos.fdba38dc.png" };
      var h = a(70539), g = a.n(h);
      let x = "BUY_SUBSCRIPTION_BANNER_BUTTON_INTERSECTION_PROPERTY_ID";
      (0, r.PA)((e2) => {
        let { className: t2 } = e2, {
          user: a2,
          paywall: { modal: r2 }
        } = (0, p.Pjs)(), [h2, y2] = (0, c.d)(), { formatMessage: b2 } = (0, l.A)(), {
          mainText: A2,
          isShimmerVisible: C2,
          isShimmerActive: N2,
          openPaymentWidgetModal: f2,
          saveOfferAndAuthorize: I2
        } = (0, p.DpZ)({
          storeName: "music",
          offerElement: { element: h2, intersectionPropertyId: x },
          place: p.RBW.BANNER_BUTTON
        }), S2 = (0, s.c)(() => {
          if (!a2.isAuthorized) return void I2();
          f2();
        });
        return (0, i.jsxs)("section", {
          className: (0, n.$)(g().root, t2),
          "aria-label": b2({ id: "plusbar.subscription-activation" }),
          "data-intersection-property-id": "BUY_SUBSCRIPTION_BANNER_INTERSECTION_PROPERTY_ID",
          children: [
            (0, i.jsx)(u.Image, { fit: "contain", src: v.src, className: g().logos }),
            (0, i.jsx)(_.Heading, {
              variant: "div",
              size: "m",
              weight: "bold",
              className: g().title,
              children: (0, i.jsx)(o.A, { id: "buy-subscription.get-more-discoveries", values: { nbsp: " " } })
            }),
            C2 && (0, i.jsx)(m.Shimmer, { className: g().plusButtonShimmer, isActive: N2, radius: "xxxl" }),
            !C2 && (0, i.jsx)(d.$, {
              className: g().plusButton,
              isBlock: true,
              radius: "xxxl",
              size: "m",
              color: "plus",
              onClick: S2,
              ref: y2,
              "data-intersection-property-id": x,
              children: (0, i.jsx)(_.Caption, { variant: "div", size: "s", lineClamp: 2, children: A2 })
            }),
            (0, i.jsx)(d.$, {
              className: g().button,
              isBlock: true,
              radius: "xxxl",
              size: "m",
              variant: "text",
              color: "primary",
              withRipple: false,
              onClick: r2.open,
              children: (0, i.jsx)(o.A, { id: "interface-actions.more-details" })
            })
          ]
        });
      });
      var y = a(97396), b = a(31500), A = a(32692), C = a(80585), N = a(20125), f = a.n(N);
      let I = "buy-subscription-modal", S = (0, r.PA)((e2) => {
        let { modal: t2 } = e2, a2 = (0, y.useRouter)(), n2 = (0, p.NFA)().get(p.QGx), [r2, l2] = (0, c.d)(), {
          openPaymentWidgetModal: u2,
          isShimmerActive: m2,
          isShimmerVisible: v2,
          mainText: h2,
          mainTextA11y: g2,
          additionText: x2,
          saveOfferAndAuthorize: N2
        } = (0, p.DpZ)({ storeName: "music", offerElement: { element: r2, intersectionPropertyId: I } }), { user: S2 } = (0, p.Pjs)(), T2 = (0, s.c)(() => {
          if (t2.close(), !S2.isAuthorized) return void N2();
          u2();
        }), P2 = (0, s.c)(() => {
          t2.close(), n2.authorizationUrl && a2.push(n2.authorizationUrl);
        });
        return (0, i.jsxs)(A.a, {
          className: f().root,
          headerClassName: f().header,
          contentClassName: f().content,
          size: "fitContent",
          placement: "default",
          open: t2.isOpened,
          onOpenChange: t2.onOpenChange,
          onClose: t2.close,
          lockScroll: true,
          closeButtonProps: (0, b.Am)(b.Kq.buySubscriptionModal.BUY_SUBSCRIPTION_BOTTOMSHEET_CLOSE_BUTTON),
          ...(0, b.Am)(b.Kq.buySubscriptionModal.BUY_SUBSCRIPTION_BOTTOMSHEET),
          children: [
            (0, i.jsx)(_.Caption, {
              className: f().heading,
              variant: "div",
              weight: "bold",
              ...(0, b.Am)(b.Kq.buySubscriptionModal.BUY_SUBSCRIPTION_BOTTOMSHEET_TITLE),
              children: (0, i.jsx)(o.A, {
                id: "buy-subscription.listen-without-restrictions",
                values: { nbsp: " " }
              })
            }),
            (0, i.jsxs)("div", {
              className: f().buttons,
              children: [
                (0, i.jsx)(C.b4, {
                  ref: l2,
                  "data-intersection-property-id": I,
                  mainText: h2,
                  ariaLabel: g2,
                  additionText: x2,
                  isShimmerActive: m2,
                  isShimmerVisible: v2,
                  onClick: T2,
                  className: f().button,
                  mainTextClassName: f().buttonMainText,
                  additionTextClassName: f().buttonAdditionText,
                  ...(0, b.Am)(b.Kq.buySubscriptionModal.BUY_SUBSCRIPTION_BOTTOMSHEET_SUBSCRIPTION_BUTTON)
                }),
                (0, i.jsx)(d.$, {
                  onClick: P2,
                  className: f().button,
                  isBlock: true,
                  color: "secondary",
                  variant: "default",
                  size: "l",
                  radius: "xxxl",
                  ...(0, b.Am)(b.Kq.buySubscriptionModal.BUY_SUBSCRIPTION_BOTTOMSHEET_ALREADY_IN_PLUS_BUTTON),
                  children: (0, i.jsx)(_.Caption, {
                    className: f().buttonMainText,
                    variant: "span",
                    weight: "bold",
                    children: (0, i.jsx)(o.A, { id: "buy-subscription.already-in-plus", values: { nbsp: " " } })
                  })
                })
              ]
            })
          ]
        });
      });
      S.displayName = "BuySubscriptionModal";
      var T = a(27510), P = a(36017), k = a.n(P);
      let E = "PLUSBAR_BUTTON_INTERSECTION_PROPERTY_ID", j = (0, r.PA)((e2) => {
        let { shouldFetchOffers: t2, ...a2 } = e2, { user: n2, experiments: r2 } = (0, p.Pjs)(), [o2, u2] = (0, c.d)(), { formatMessage: v2 } = (0, l.A)(), {
          mainText: h2,
          isShimmerVisible: g2,
          isShimmerActive: x2,
          openPaymentWidgetModal: y2,
          saveOfferAndAuthorize: b2
        } = (0, p.DpZ)({
          storeName: "music",
          isEnabled: t2,
          offerElement: { element: o2, intersectionPropertyId: E }
        }), A2 = (0, T.L)(
          () => !h2 && r2.checkExperiment(p.zal.WebNextUnauthorizedSubscriptionButton, "on") ? v2({ id: "authorization.start-button" }) : h2
        ), C2 = (0, s.c)(() => {
          if (!n2.isAuthorized) return void b2();
          y2();
        });
        return g2 ? (0, i.jsx)(m.Shimmer, { className: k().plusButtonShimmer, isActive: x2, radius: "xxxl" }) : (0, i.jsx)(d.$, {
          className: k().root,
          isBlock: true,
          radius: "xxxl",
          size: "m",
          color: "plus",
          onClick: C2,
          ref: u2,
          "data-intersection-property-id": E,
          ...a2,
          children: (0, i.jsx)(_.Caption, { variant: "div", size: "s", lineClamp: 2, children: A2 })
        });
      });
      j.displayName = "PlusNavbarButton";
      var L = a(61910), w = a(5956), M = a(68023), B = a.n(M);
      let O = "buy-subscription-button", R = (0, r.PA)((e2) => {
        let { className: t2 } = e2, a2 = (0, L.useRef)(null), { showBuySubscriptionModal: r2 } = (0, p.qBP)(), {
          mainText: l2,
          mainTextA11y: s2,
          isShimmerVisible: c2,
          isShimmerActive: u2
        } = (0, p.DpZ)({
          storeName: "music",
          isEnabled: false,
          offerElement: { element: a2.current, intersectionPropertyId: O }
        }), m2 = (0, T.L)(
          () => c2 ? (0, i.jsx)(C.nN, {
            className: B().titleShimmerContainer,
            isActive: u2,
            textClassName: B().titleShimmer
          }) : (0, i.jsx)(_.Caption, {
            className: B().title,
            variant: "span",
            size: "m",
            weight: "bold",
            "aria-label": s2,
            children: l2
          })
        );
        return (0, i.jsxs)("div", {
          ref: a2,
          className: (0, n.$)(B().root, t2),
          "data-intersection-property-id": O,
          children: [
            (0, i.jsxs)("div", {
              className: B().info,
              children: [
                (0, i.jsxs)("div", {
                  className: B().titleContainer,
                  children: [(0, i.jsx)(w.Icon, { className: B().icon, "aria-hidden": true, variant: "plusColor" }), m2]
                }),
                (0, i.jsx)(_.Caption, {
                  className: B().subtitle,
                  variant: "span",
                  size: "xs",
                  weight: "normal",
                  children: (0, i.jsx)(o.A, { id: "buy-subscription.music-and-films-and-other" })
                })
              ]
            }),
            (0, i.jsx)(d.$, {
              color: "plus",
              variant: "default",
              size: "m",
              radius: "xxxl",
              onClick: r2,
              children: (0, i.jsx)(_.Caption, {
                className: B().buttonText,
                variant: "span",
                size: "m",
                weight: "normal",
                children: (0, i.jsx)(o.A, { id: "buy-subscription.activate" })
              })
            })
          ]
        });
      });
      var D = a(16825), K = a.n(D);
      (0, r.PA)((e2) => {
        var t2;
        let { children: a2 } = e2, {
          paymentWidgetModal: r2,
          modals: { buySubscriptionModal: l2 },
          album: o2,
          albumCPA: { isPlusCPAPlayerBarEnabled: s2 },
          settings: { isMobile: c2, browserInfo: d2 }
        } = (0, p.Pjs)(), {
          shouldShowBuySubscriptionModal: u2,
          showBuySubscriptionModal: m2,
          hideBuySubscriptionModal: _2
        } = (0, p.qBP)(), v2 = s2(o2.id, null == (t2 = o2.meta) ? void 0 : t2.isNonMusic), h2 = null == d2 ? void 0 : d2.isTouch, g2 = c2 || h2 && !v2;
        return ((0, L.useEffect)(() => {
          if (u2 && !v2) {
            if (r2.modal.isOpened) return void _2();
            m2();
          }
        }, [_2, r2.modal.isOpened, u2, m2, v2]), u2 && g2) ? (0, i.jsxs)(i.Fragment, {
          children: [
            a2,
            (0, i.jsxs)(p.rtM, {
              page: p.l7W.MOBILE_POPUP,
              places: [p.RBW.TOP_BUTTON],
              shouldFetchOffers: u2,
              children: [
                (0, i.jsx)(R, { className: (0, n.$)({ [K().buttonWithPlayerBar]: v2 }) }),
                (0, i.jsx)(S, { modal: l2 })
              ]
            })
          ]
        }) : a2;
      });
    },
    70103: (e) => {
      e.exports = {
        root: "TrackModal_root__QrFg6",
        header: "TrackModal_header__hjfRd",
        closeButton: "TrackModal_closeButton__VLm_R",
        modalContent: "TrackModal_modalContent__AzQPF",
        content: "TrackModal_content__9qH7W",
        container: "TrackModal_container__JaG86"
      };
    },
    70392: (e, t, a) => {
      "use strict";
      a.d(t, { I: () => i });
      let i = (e2) => {
        let [t2, a2] = e2.split(":");
        return { uid: String(t2), kind: Number(a2) };
      };
    },
    70539: (e) => {
      e.exports = {
        root: "BuySubscriptionBanner_root__y2M_5",
        logos: "BuySubscriptionBanner_logos__LHOzM",
        title: "BuySubscriptionBanner_title___sWo0",
        plusButton: "BuySubscriptionBanner_plusButton__UwULz",
        plusButtonShimmer: "BuySubscriptionBanner_plusButtonShimmer__nS7im"
      };
    },
    71176: (e) => {
      e.exports = {
        root: "PlayQueueNowPlayingBlock_root__aJSb8",
        important: "PlayQueueNowPlayingBlock_important__sxxvA",
        track: "PlayQueueNowPlayingBlock_track__ClZLs",
        track_withDnD: "PlayQueueNowPlayingBlock_track_withDnD__D8h0r",
        track_moveFromTop: "PlayQueueNowPlayingBlock_track_moveFromTop__pBBJt",
        "move-from-top": "PlayQueueNowPlayingBlock_move-from-top__O5e0S",
        track_moveFromBottom: "PlayQueueNowPlayingBlock_track_moveFromBottom__Jj2UO",
        "move-from-bottom": "PlayQueueNowPlayingBlock_move-from-bottom__Cz7lV"
      };
    },
    71372: (e) => {
      e.exports = {
        bottomRightButtonsWrapper: "FullscreenPlayerDesktopControls_bottomRightButtonsWrapper__EvGiZ",
        root: "FullscreenPlayerDesktopControls_root__tviu4",
        root_visible: "FullscreenPlayerDesktopControls_root_visible__1b9xD",
        sonataControls: "FullscreenPlayerDesktopControls_sonataControls__9AIki",
        menuWrapper: "FullscreenPlayerDesktopControls_menuWrapper__ifxNx",
        syncLyricsButton: "FullscreenPlayerDesktopControls_syncLyricsButton__g6E6g",
        playQueueButton: "FullscreenPlayerDesktopControls_playQueueButton__reNOW",
        speedButton: "FullscreenPlayerDesktopControls_speedButton__uTbyy",
        likeButton: "FullscreenPlayerDesktopControls_likeButton__vpJ7S",
        menuButton: "FullscreenPlayerDesktopControls_menuButton__R4cXl",
        likeButton_active: "FullscreenPlayerDesktopControls_likeButton_active__XltBK",
        menuButton_active: "FullscreenPlayerDesktopControls_menuButton_active__YZ8M8",
        playQueueButton_active: "FullscreenPlayerDesktopControls_playQueueButton_active___SA85",
        speedButton_active: "FullscreenPlayerDesktopControls_speedButton_active__H_EXl",
        syncLyricsButton_active: "FullscreenPlayerDesktopControls_syncLyricsButton_active__VMvEH",
        fullscreenPlayerButton: "FullscreenPlayerDesktopControls_fullscreenPlayerButton__0UjpS",
        fullscreenPlayerButton_visible: "FullscreenPlayerDesktopControls_fullscreenPlayerButton_visible__qjQ0X"
      };
    },
    71416: (e) => {
      e.exports = {
        root: "FullscreenPlayerDesktopPoster_root__d__YD",
        cover: "FullscreenPlayerDesktopPoster_cover__CDmhM"
      };
    },
    74504: (e) => {
      e.exports = {
        root: "TrailerError_root__GwuKR",
        textContainer: "TrailerError_textContainer__lF7RZ",
        title: "TrailerError_title__Q52Pa",
        description: "TrailerError_description__60UJ6"
      };
    },
    74631: (e) => {
      e.exports = {
        tooltip: "NavigationOnboarding_tooltip___xZni",
        text: "NavigationOnboarding_text__YW93F",
        button: "NavigationOnboarding_button__Vc_Ka"
      };
    },
    77760: (e) => {
      e.exports = { root: "PlayerBar_root__cXUnU", adPopup: "PlayerBar_adPopup__BrBC6" };
    },
    77846: (e) => {
      e.exports = {
        coverBlock: "ArtistCard_coverBlock__YCSus",
        like: "ArtistCard_like__jmlKc",
        root: "ArtistCard_root__F4RfA",
        root_selected: "ArtistCard_root_selected__9Djbq",
        cover: "ArtistCard_cover__RSTvK",
        image: "ArtistCard_image__Uab5w",
        name: "ArtistCard_name__IF9yZ",
        icon: "ArtistCard_icon__PjbJI"
      };
    },
    78028: (e) => {
      e.exports = {
        root: "PlayQueueDnDTrackWrapper_root__CithE",
        inner: "PlayQueueDnDTrackWrapper_inner__xq3xM",
        dragging: "PlayQueueDnDTrackWrapper_dragging__Tk9uP",
        dragOverlay: "PlayQueueDnDTrackWrapper_dragOverlay__ulF2W"
      };
    },
    78444: (e) => {
      e.exports = {
        root: "FullscreenPlayerMobileContent_root__RITqv",
        wrapper: "FullscreenPlayerMobileContent_wrapper__JPmBe",
        syncLyrics: "FullscreenPlayerMobileContent_syncLyrics__HKUm0",
        trackInfoCoverContainer: "FullscreenPlayerMobileContent_trackInfoCoverContainer__Y2hly",
        trackInfoCover: "FullscreenPlayerMobileContent_trackInfoCover__zsEEq",
        contentContainer: "FullscreenPlayerMobileContent_contentContainer__ILyg5",
        contentContainer_withSplitMode: "FullscreenPlayerMobileContent_contentContainer_withSplitMode__Rdv5T",
        trackInfo: "FullscreenPlayerMobileContent_trackInfo__IPGjo",
        metaContainer: "FullscreenPlayerMobileContent_metaContainer__B2vTr",
        infoBlock: "FullscreenPlayerMobileContent_infoBlock__ZcRdn",
        infoBlock_withExpandedSyncLyrics: "FullscreenPlayerMobileContent_infoBlock_withExpandedSyncLyrics__qlbKX",
        coverWrapper: "FullscreenPlayerMobileContent_coverWrapper___Y6ll",
        coverWrapper_enter: "FullscreenPlayerMobileContent_coverWrapper_enter__oFtHh",
        coverWrapper_enter_active: "FullscreenPlayerMobileContent_coverWrapper_enter_active__GM_of",
        "enter-fade": "FullscreenPlayerMobileContent_enter-fade__Q0KNn",
        coverWrapper_exit: "FullscreenPlayerMobileContent_coverWrapper_exit__QDk1i",
        coverWrapper_exit_active: "FullscreenPlayerMobileContent_coverWrapper_exit_active__9S_wE",
        "exit-fade": "FullscreenPlayerMobileContent_exit-fade__uS0jT",
        cover: "FullscreenPlayerMobileContent_cover__W6pz2",
        metaText: "FullscreenPlayerMobileContent_metaText__Fr74D",
        timeline: "FullscreenPlayerMobileContent_timeline__Pta9W",
        content: "FullscreenPlayerMobileContent_content__EAteH",
        syncLyricsContent: "FullscreenPlayerMobileContent_syncLyricsContent__qhWG_",
        syncLyricsLoader: "FullscreenPlayerMobileContent_syncLyricsLoader__0_W2j",
        syncLyricsScroller: "FullscreenPlayerMobileContent_syncLyricsScroller__EqiCL",
        syncLyricsFooter: "FullscreenPlayerMobileContent_syncLyricsFooter__bi9vY",
        syncLyricsCounter: "FullscreenPlayerMobileContent_syncLyricsCounter___wm5g"
      };
    },
    79952: (e, t, a) => {
      "use strict";
      a.d(t, { hq: () => el, qQ: () => c });
      var i = a(74125);
      async function n(e2, t2, a2) {
        var n2, r2, l2, o2, s2, c2;
        if (!e2 || !t2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let d2 = await (0, i.WGy)(a2.locale), u2 = (0, i.NsT)(null != (n2 = e2.title) ? n2 : "");
        return a2.isNotFound ? { robots: { index: false } } : {
          title: (function(e3) {
            var t3;
            let { trackMeta: a3, messageFormatter: n3 } = e3, r3 = (0, i.j4K)(null != (t3 = a3.artists) ? t3 : []);
            return n3({ id: "metadata.track-title" }, { trackTitle: a3.title, artistsNames: r3 });
          })({ trackMeta: e2, messageFormatter: d2 }),
          description: (function(e3) {
            var t3, a3;
            let { trackMeta: n3, albumMeta: r3, messageFormatter: l3 } = e3, o3 = (0, i.j4K)(null != (a3 = n3.artists) ? a3 : []), s3 = Math.round((n3.durationMs || 0) / i.k7R);
            return l3(
              { id: "metadata.track-description" },
              {
                type: (null == (t3 = n3.type) ? void 0 : t3.replace("-", "_")) || null,
                artistsNames: o3 || null,
                trackTitle: n3.title,
                albumTitle: (null == r3 ? void 0 : r3.title) || null,
                duration: (0, i.E4p)(s3),
                year: (null == r3 ? void 0 : r3.year) || null
              }
            );
          })({ trackMeta: e2, albumMeta: t2, messageFormatter: d2 }),
          openGraph: (0, i.i$E)({
            ogTitle: u2,
            ogDescription: (function(e3) {
              var t3, a3;
              let { trackMeta: n3, albumMeta: r3, messageFormatter: l3 } = e3, o3 = (0, i.YFq)((0, i.j4K)(null != (a3 = n3.artists) ? a3 : []), 96, false);
              return l3(
                { id: "metadata.track-og-description" },
                {
                  type: (null == (t3 = n3.type) ? void 0 : t3.replace("-", "_")) || null,
                  artistsNames: o3 || null,
                  year: (null == r3 ? void 0 : r3.year) || null
                }
              );
            })({ trackMeta: e2, albumMeta: t2, messageFormatter: d2 }),
            fullUrl: null != (r2 = a2.fullUrl) ? r2 : "",
            locale: a2.locale,
            ogImage: null != (l2 = e2.ogImage) ? l2 : "",
            siteName: d2({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: u2,
            url: a2.url,
            appName: d2({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: {
              ...a2,
              url: null != (o2 = a2.url) ? o2 : "",
              fullUrl: null != (s2 = a2.fullUrl) ? s2 : "",
              host: a2.host
            },
            appName: d2({ id: "metadata.yandex-music" })
          }),
          other: { "music:musician": (0, i.xdV)(null != (c2 = null == e2 ? void 0 : e2.artists) ? c2 : [], a2.host) },
          alternates: (0, i.SEs)("/album/:albumId/track/:trackId", a2.tld, {
            params: { albumId: t2.id, trackId: e2.id }
          })
        };
      }
      var r = a(93064), l = a(14032), o = a(21365), s = a(26433);
      let c = r.gK.compose(
        r.gK.model({
          meta: r.gK.maybeNull(o.vj),
          similarTracks: r.gK.maybeNull(r.gK.array(o.vj)),
          prevEntityId: r.gK.maybeNull(r.gK.union(r.gK.string, r.gK.number)),
          trackId: r.gK.maybeNull(r.gK.union(r.gK.string, r.gK.number)),
          albumId: r.gK.maybeNull(r.gK.number),
          isTrackPage: r.gK.optional(r.gK.boolean, false),
          withAnimation: r.gK.boolean,
          shouldSendEventOnPlusButtonShowed: r.gK.boolean
        }),
        s.qt,
        s.XT
      ).views((e2) => ({
        get shouldReloadMeta() {
          var t2;
          let a2 = e2.trackId && e2.albumId && (0, l.V)(e2.trackId, e2.albumId);
          return a2 === (null == (t2 = e2.meta) ? void 0 : t2.entityId) || a2 === e2.prevEntityId;
        },
        get isShimmerVisible() {
          return e2.isLoading || e2.isRejected;
        },
        get seeds() {
          var a2;
          return ["track:".concat(null == (a2 = e2.meta) ? void 0 : a2.id)];
        }
      })).actions((e2) => {
        let t2 = {
          setShouldSendEventOnPlusButtonShowed(t3) {
            e2.shouldSendEventOnPlusButtonShowed = t3;
          },
          setTrackInfo(t3) {
            var a2;
            (0, r._n)(e2) && (e2.meta = (0, o.vU)(t3.track), e2.similarTracks = (0, r.wg)(null == (a2 = t3.similarTracks) ? void 0 : a2.map((e3) => (0, o.vU)(e3))), e2.loadingState = i.GuX.RESOLVE);
          },
          setIsTrackPage(t3) {
            e2.isTrackPage = !!t3;
          },
          setAnimationState(t3) {
            e2.withAnimation = t3;
          },
          getData: (0, r.L3)(function* () {
            let { tracksResource: a2, modelActionsLogger: n2 } = (0, r._$)(e2);
            if (!e2.trackId || e2.loadingState === i.GuX.PENDING || e2.shouldReloadMeta) return null;
            try {
              var l2;
              e2.loadingState = i.GuX.PENDING, e2.meta = null;
              let n3 = yield a2.getFullInfoTrack({ trackId: e2.trackId, albumId: e2.albumId });
              if (!n3) return e2.loadingState = i.GuX.REJECT, null;
              e2.meta = (0, o.vU)(n3.track), e2.similarTracks = (0, r.wg)(n3.similarTracks.map((e3) => (0, o.vU)(e3))), e2.prevEntityId = n3.track.id, t2.setShouldSendEventOnPlusButtonShowed(true), (null == (l2 = e2.meta) ? void 0 : l2.resolveAllDisclaimers) && (yield e2.meta.resolveAllDisclaimers()), e2.loadingState = i.GuX.RESOLVE;
            } catch (t3) {
              n2.error(t3), e2.loadingState = i.GuX.REJECT;
            }
            return null;
          }),
          open(t3) {
            let { trackId: a2, albumId: i2 } = t3;
            a2 && i2 && (e2.trackId = a2, e2.albumId = i2, e2.isOpened = true);
          },
          reset() {
            e2.loadingState = i.GuX.IDLE, e2.shouldSendEventOnPlusButtonShowed = true;
          }
        };
        return t2;
      }).named("TrackPage");
      var d = a(54486), u = a(28303), m = a(61910), _ = a(32692), p = a(94376), v = a(70103), h = a.n(v), g = a(43426), x = a(31500), y = a(8817), b = a(77881), A = a(5956), C = a(80585), N = a(97800), f = a(49230), I = a.n(f), S = a(22674), T = a(18180), P = a.n(T);
      let k = (e2) => {
        let { isShimmerActive: t2 } = e2;
        return (0, d.jsxs)("div", {
          className: P().root,
          children: [
            (0, d.jsx)(S.Shimmer, { className: P().title, isActive: t2 }),
            (0, d.jsxs)("div", {
              className: P().coverBlock,
              children: [
                (0, d.jsx)(S.Shimmer, { className: P().cover, isActive: t2 }),
                (0, d.jsxs)("div", {
                  className: P().linkBlock,
                  children: [
                    (0, d.jsx)(S.Shimmer, { className: P().link, isActive: t2 }),
                    (0, d.jsx)(S.Shimmer, { className: P().description, isActive: t2 })
                  ]
                })
              ]
            })
          ]
        });
      }, E = (0, u.PA)((e2) => {
        var t2;
        let { onModalClose: a2 } = e2, { formatMessage: n2 } = (0, g.A)(), {
          settings: { isMobile: r2 },
          track: l2,
          fullscreenPlayer: o2
        } = (0, i.Pjs)(), s2 = (0, y.c)(() => {
          o2.modal.isOpened && o2.modal.close(), r2 && a2();
        }), c2 = null == (t2 = l2.meta) ? void 0 : t2.mainAlbum, u2 = (0, m.useMemo)(() => {
          if (!c2) return;
          let e3 = c2.trackCount;
          return c2.isAudiobook || c2.isFairyTale ? n2({ id: "entity-names.number-of-chapters" }, { counter: e3 }) : c2.isPodcast ? n2({ id: "entity-names.number-of-episodes" }, { counter: e3 }) : n2({ id: "entity-names.number-of-tracks" }, { counter: e3 });
        }, [c2, n2]);
        return l2.isShimmerVisible ? (0, d.jsx)(k, { isShimmerActive: l2.isLoading }) : c2 ? (0, d.jsxs)("div", {
          className: I().root,
          ...(0, x.Am)(x.Xk.track.TRACK_PAGE_ALBUM),
          children: [
            (0, d.jsx)(N.Heading, {
              variant: "h2",
              size: "m",
              lineClamp: 1,
              className: I().title,
              ...(0, x.Am)(x.Xk.track.TRACK_PAGE_ALBUM_TITLE),
              children: n2({ id: "track-modal.album-heading" }, { type: (0, i.yDn)(c2.type) })
            }),
            (0, d.jsx)(C.Tw, {
              title: null == c2 ? void 0 : c2.title,
              coverUrl: null == c2 ? void 0 : c2.coverUri,
              description: u2,
              viewAllActionLink: null == c2 ? void 0 : c2.url,
              onViewAllAction: s2,
              titleLineClamp: 1,
              available: c2.isAvailable,
              titleSize: "xs",
              withDescription: !!u2
            })
          ]
        }) : null;
      });
      var j = a(62443), L = a(39694), w = a(1172), M = a.n(w), B = a(50420), O = a(87923), R = a.n(O);
      let D = (e2) => {
        let { isShimmerActive: t2 } = e2;
        return (0, d.jsxs)("div", {
          className: R().root,
          children: [
            (0, d.jsx)(S.Shimmer, { className: R().title, isActive: t2 }),
            (0, d.jsx)(C.q$, { className: (0, B.$)(R().lyrics, R().important), count: 4, isActive: t2 }),
            (0, d.jsx)(S.Shimmer, { className: R().button, isActive: t2 })
          ]
        });
      }, K = (0, u.PA)((e2) => {
        var t2, a2, n2, r2;
        let { track: l2 } = e2, { formatMessage: s2 } = (0, g.A)(), { notify: c2 } = (0, i.lkh)(), { track: u2, trackLyrics: _2 } = (0, i.Pjs)(), { state: p2, setState: v2 } = (0, j.e)(false), h2 = _2.currentTrackId !== (null == (t2 = u2.meta) ? void 0 : t2.id), b2 = u2.isResolved && (null == (a2 = u2.meta) ? void 0 : a2.isLyricsAvailable);
        (0, m.useEffect)(() => {
          var e3;
          (null == (e3 = u2.meta) ? void 0 : e3.id) && b2 && h2 && _2.getLyrics(u2.meta.id);
        }, [h2, b2, _2, null == (n2 = u2.meta) ? void 0 : n2.id]), _2.shouldShowErrorNotification && (c2((0, d.jsx)(C.hT, { error: s2({ id: "error-messages.error-during-action" }) }), {
          containerId: i.uQT.ERROR
        }), _2.resetShouldShowError());
        let A2 = (0, y.c)((e3) => {
          v2(e3), e3 && l2 && _2.sendViews({ trackId: l2.id, albumId: l2.albumId });
        });
        return _2.isShimmerVisible || !_2.lyrics || u2.isShimmerVisible ? (0, d.jsx)(D, { isShimmerActive: _2.isLoading || u2.isLoading }) : (0, d.jsxs)("div", {
          className: M().root,
          ...(0, x.Am)(x.Xk.track.TRACK_PAGE_LYRICS),
          children: [
            (0, d.jsx)(N.Heading, {
              variant: "h2",
              size: "m",
              lineClamp: 1,
              className: M().title,
              ...(0, x.Am)(x.e8.content.TRACK_LYRICS_TITLE),
              children: s2({ id: "entity-names.text" })
            }),
            (0, d.jsx)(L.K, {
              moreText: s2({ id: "track-modal.read-more" }),
              buttonClassName: M().button,
              open: p2,
              onOpenChange: A2,
              lineClamp: 4,
              withFade: true,
              children: (0, d.jsx)(N.Caption, {
                variant: "div",
                className: M().lyrics,
                size: "l",
                weight: "medium",
                ...(0, x.Am)(x.e8.content.TRACK_LYRICS_TEXT),
                children: (0, d.jsx)(o.xe, {
                  lyrics: _2.lyrics,
                  authors: _2.writersNames,
                  source: null == (r2 = _2.major) ? void 0 : r2.prettyName,
                  isShimmerVisible: _2.isShimmerVisible,
                  isShimmerActive: _2.isLoading
                })
              })
            })
          ]
        });
      });
      var U = a(63585), F = a(91126), z = a.n(F);
      let V = (0, u.PA)((e2) => {
        let {
          tracks: t2,
          contextId: a2,
          isShimmerVisible: n2,
          isShimmerActive: r2,
          autoflowSeeds: l2,
          shouldResetCarouselScroll: s2
        } = e2, { formatMessage: c2 } = (0, g.A)(), { from: u2 } = (0, i.fyy)({ contextId: a2, contextType: U.K.Various }), m2 = (0, y.c)((e3, a3) => ({
          contextData: { type: U.K.Various, meta: { id: e3.entityId }, from: u2, overrideAutoflowSeeds: l2 },
          queueParams: { index: a3 },
          loadContextMeta: false,
          entitiesData: t2.map(o.$b)
        }));
        return (0, d.jsx)(C.$2, {
          className: z().root,
          shimmer: (0, d.jsx)(C.DS, { variant: i.Xjt.PLAYLIST, isActive: r2 }),
          maxColumnsCount: C.DI.TWO,
          itemsCountPerColumn: 4,
          blockHeaderTitle: c2({ id: "track-modal.similar-tracks" }),
          blockHeaderHeadingVariant: "h2",
          isShimmerVisible: n2,
          isShimmerActive: r2,
          carouselItemClassName: (0, B.$)(z().item, z().important),
          blockHeaderClassName: z().title,
          carouselClassName: z().tracksContainer,
          shouldResetCarouselScroll: s2,
          ...(0, x.Am)(x.Xk.track.TRACK_PAGE_SIMILAR_TRACKS),
          children: t2.map(
            (e3, t3) => (0, d.jsx)(o.Kt, { track: e3, playContextParams: m2(e3, t3), withDislike: false, withTrailer: false }, e3.id)
          )
        });
      });
      var W = a(32353), G = a(63695), Y = a(47713), Q = a(54460), $ = a(43350), q = a(62395), H = a(61528), X = a.n(H);
      let Z = (0, u.PA)((e2) => {
        var t2, a2, n2;
        let { track: r2 } = e2, { shouldShowBuySubscriptionModal: l2, showBuySubscriptionModal: s2 } = (0, i.qBP)(), { from: c2, utmLink: u2 } = (0, i.fyy)({ contextId: r2.id, contextType: U.K.Various }), {
          user: _2,
          settings: { isMobile: p2 },
          track: { shouldSendEventOnPlusButtonShowed: v2, setShouldSendEventOnPlusButtonShowed: h2, isOpened: g2 },
          albumCPA: { isPlusCPAPlayerBarEnabled: b2 }
        } = (0, i.Pjs)(), N2 = (0, i.brA)(), f2 = ((e3) => {
          let t3 = (0, q.st)(), a3 = (0, i.UlF)(), { hash: n3 } = (0, q.gf)();
          return (0, y.c)(() => {
            if (!t3) return;
            let r3 = {
              hash: n3,
              pageId: i.Wft[i._Q$.TRACK_SCREEN],
              mainObjectType: $.ky.Track,
              mainObjectId: e3.objectId,
              entityId: "buy_subscription_button",
              pageStyle: $.QL.Sheet,
              pagePlacement: $.c4.Right,
              from: i.Wft[i._Q$.TRACK_SCREEN],
              to: i.Wft[i._Q$.PAYWALL],
              tabId: "",
              tabPos: 0
            }, l3 = (0, $.Fx)({ params: r3, logger: a3, context: "useSendEventOnTrackModalPlusButtonNavigated" });
            l3 && (0, $.QS)(t3.evgenInstance, l3);
          });
        })({ objectId: r2.id }), I2 = ((e3) => {
          let t3 = (0, q.st)(), a3 = (0, i.UlF)(), { hash: n3 } = (0, q.gf)();
          return (0, y.c)(() => {
            if (!t3) return;
            let r3 = {
              hash: n3,
              pageId: i.Wft[i._Q$.TRACK_SCREEN],
              mainObjectType: $.ky.Track,
              mainObjectId: e3.objectId,
              entityId: "buy_subscription_button",
              pageStyle: $.QL.Sheet,
              pagePlacement: $.c4.Right,
              tabId: "",
              tabPos: 0
            }, l3 = (0, $.Fx)({ params: r3, logger: a3, context: "useSendEventOnTrackModalPlusButtonShowed" });
            l3 && (0, $.Pf)(t3.evgenInstance, l3);
          });
        })({ objectId: r2.id }), S2 = (0, i.PT7)(), T2 = !_2.hasPlus && r2.isTrackMusic && (r2.isAvailable && !r2.hasModalAccess || (null == (t2 = r2.mainAlbum) ? void 0 : t2.isAvailableOnlyForPlus)), P2 = b2(null == (a2 = r2.mainAlbum) ? void 0 : a2.id, null == (n2 = r2.mainAlbum) ? void 0 : n2.isNonMusic), { iconSize: k2, controlSize: E2 } = (0, W.q)(p2), [j2, L2] = (0, m.useState)(false), { isPlaying: w2, togglePlay: M2 } = (0, i.Dx4)({
          playContextParams: {
            contextData: { type: U.K.Various, meta: { id: r2.entityId }, from: c2, utmLink: u2 },
            loadContextMeta: true
          },
          entityId: r2.entityId
        }), O2 = (0, o.wf)({ track: r2, callback: M2 }), R2 = (0, y.c)(() => {
          if (!S2()) {
            if (l2 && !P2) return void s2();
            O2(), N2(!w2);
          }
        }), D2 = (0, Q.KX)(r2), K2 = (0, y.c)((e3) => {
          e3.stopPropagation();
        });
        (0, m.useEffect)(() => {
          v2 && T2 && g2 && (I2(), h2(false));
        }, [I2, T2, v2, h2, g2]);
        let F2 = (0, m.useMemo)(() => {
          if (T2)
            return (0, d.jsx)(C.hS, {
              text: (0, d.jsx)(Y.A, { id: "payment.high-quality-offer-button-title" }),
              analyticsNavigatedCallback: f2
            });
        }, [T2, f2]), z2 = T2 ? "secondary" : "primary";
        return (0, d.jsxs)("div", {
          className: X().root,
          children: [
            F2,
            (0, d.jsxs)("div", {
              className: X().controlsContainer,
              children: [
                (0, d.jsx)(C.DM, {
                  className: (0, B.$)({ [X().disabledButtonByDisclaimer]: !r2.isAvailable && r2.hasModalAccess }),
                  withRipple: r2.isAvailable,
                  buttonVariant: "default",
                  radius: "xxxl",
                  size: E2,
                  color: z2,
                  iconSize: k2,
                  isPlaying: w2,
                  onClick: R2,
                  disabled: !r2.isAvailable && !r2.hasModalAccess,
                  children: !p2 && (0, d.jsx)(Y.A, { id: "player-actions.listen" })
                }),
                (0, d.jsx)(C.cy, {
                  isLiked: r2.isLiked,
                  onClick: D2,
                  variant: "default",
                  size: E2,
                  iconSize: k2,
                  withRipple: !p2,
                  disabled: !r2.isAvailable || !_2.isAuthorized
                }),
                r2.isAvailable && (0, d.jsx)(o._Y, {
                  track: r2,
                  open: j2,
                  onOpenChange: L2,
                  size: E2,
                  icon: (0, d.jsx)(A.Icon, { variant: "more", size: k2 }),
                  className: (0, B.$)(X().menuButton, { [X().menuButton_active]: j2 }),
                  wrapperClassName: X().menuWrapper,
                  onClick: K2,
                  withTrailer: false,
                  ...(0, x.Am)(x.e8.pageHeader.TRACK_HEADER_CONTEXT_MENU_BUTTON)
                })
              ]
            })
          ]
        });
      });
      var J = a(67418), ee = a.n(J), et = a(65857), ea = a.n(et);
      let ei = (e2) => {
        let { isShimmerActive: t2 } = e2;
        return (0, d.jsxs)("div", {
          className: ea().root,
          children: [
            (0, d.jsx)(S.Shimmer, { className: ea().entityName, isActive: t2 }),
            (0, d.jsx)(S.Shimmer, { className: ea().title, isActive: t2 }),
            (0, d.jsx)(C.q$, {
              className: (0, B.$)(ea().artists, ea().important),
              shimmerClassName: ea().artist,
              count: 3,
              minWidth: 10,
              maxWidth: 30,
              isActive: t2
            }),
            (0, d.jsxs)("div", {
              className: ea().controls,
              children: [
                (0, d.jsx)(S.Shimmer, { className: ea().playButton, isActive: t2 }),
                (0, d.jsx)(S.Shimmer, { className: ea().button, isActive: t2 }),
                (0, d.jsx)(S.Shimmer, { className: ea().button, isActive: t2 }),
                (0, d.jsx)(S.Shimmer, { className: ea().button, isActive: t2 })
              ]
            })
          ]
        });
      }, en = (0, u.PA)((e2) => {
        let { track: t2, isShimmerVisible: a2, isShimmerActive: n2, isTrackPage: r2 } = e2, { formatMessage: l2 } = (0, g.A)(), {
          settings: { isMobile: o2 }
        } = (0, i.Pjs)(), s2 = null == t2 ? void 0 : t2.explicitDisclaimer, c2 = (0, m.useMemo)(() => {
          if (s2)
            return (0, d.jsx)(C.Nq, {
              className: (0, B.$)(ee().explicitMark, ee().important),
              getDescriptionTexts: t2.getDescriptionTexts,
              size: "xxs",
              variant: s2
            });
        }, [s2, null == t2 ? void 0 : t2.getDescriptionTexts]);
        return a2 ? (0, d.jsx)(ei, { isShimmerActive: n2 }) : t2 ? (0, d.jsx)(W.kE, {
          entityName: l2({ id: "entity-names.track-type" }, { type: (0, i.yDn)(t2.type) }),
          entityNameIcon: c2,
          controls: (0, d.jsx)(Z, { track: t2 }),
          meta: (0, d.jsx)(G.iQ, {
            className: (0, B.$)(ee().text, ee().important),
            linkClassName: ee().link,
            captionClassName: ee().artistCaption,
            artists: t2.artists,
            variant: "breakWord",
            separator: o2 ? "" : void 0
          }),
          title: t2.title,
          version: t2.version,
          headingVariant: r2 ? "h1" : "div",
          titleClassName: (0, B.$)(ee().title, ee().important),
          metaClassName: (0, B.$)(ee().meta, ee().important),
          contentClassName: (0, B.$)(ee().content, ee().important),
          withHeadingClamp: false,
          entityNameClassName: ee().entityName
        }) : null;
      }), er = (0, u.PA)(() => {
        var e2, t2, a2, n2, r2, l2, s2;
        let { formatMessage: c2 } = (0, g.A)(), { notify: u2 } = (0, i.lkh)(), {
          track: _2,
          albumCPA: { isPlusCPAPlayerBarEnabled: p2 }
        } = (0, i.Pjs)(), v2 = p2(
          null == (t2 = _2.meta) || null == (e2 = t2.mainAlbum) ? void 0 : e2.id,
          null == (n2 = _2.meta) || null == (a2 = n2.mainAlbum) ? void 0 : a2.isNonMusic
        ), N2 = _2.similarTracks && _2.similarTracks.length > 0 && (null == (r2 = _2.meta) ? void 0 : r2.isTrackMusic) && !v2, f2 = (0, y.c)(() => {
          _2.setAnimationState(true), _2.close(), _2.reset();
        }), I2 = (0, o.wf)({ track: _2.meta, disclaimerRejectHandler: f2 });
        return (0, m.useEffect)(() => {
          I2();
        }, [I2]), _2.isRejected && u2((0, d.jsx)(C.hT, { error: c2({ id: "error-messages.error-during-action" }) }), {
          containerId: i.uQT.ERROR
        }), (0, d.jsxs)("div", {
          ...(0, x.Am)(x.Xk.track.TRACK_PAGE),
          children: [
            (0, d.jsxs)("header", {
              className: h().header,
              children: [
                (0, d.jsx)(b.$, {
                  radius: "round",
                  color: "secondary",
                  size: "xxs",
                  icon: (0, d.jsx)(A.Icon, { variant: "close", size: "xxs" }),
                  className: h().closeButton,
                  onClick: f2,
                  "aria-label": c2({ id: "interface-actions.close" }),
                  ...(0, x.Am)(x.Xk.track.TRACK_PAGE_CLOSE_BUTTON)
                }),
                (0, d.jsx)(en, {
                  track: _2.meta,
                  isShimmerVisible: _2.isShimmerVisible,
                  isShimmerActive: _2.isLoading,
                  isTrackPage: _2.isTrackPage
                })
              ]
            }),
            (0, d.jsxs)("div", {
              className: h().content,
              ...(0, x.Am)(x.Xk.track.TRACK_PAGE_CONTENT),
              children: [
                (0, d.jsx)(E, { onModalClose: f2 }),
                (null == (l2 = _2.meta) ? void 0 : l2.isLyricsAvailable) && (0, d.jsx)(K, { track: _2.meta }, _2.meta.id),
                N2 && _2.similarTracks && (0, d.jsx)(V, {
                  tracks: _2.similarTracks,
                  contextId: null == (s2 = _2.meta) ? void 0 : s2.entityId,
                  isShimmerVisible: _2.isShimmerVisible,
                  isShimmerActive: _2.isLoading,
                  autoflowSeeds: _2.seeds,
                  shouldResetCarouselScroll: _2.shouldReloadMeta
                })
              ]
            }),
            _2.meta && (0, d.jsx)(o.v4, { track: _2.meta })
          ]
        });
      }), el = (0, u.PA)(() => {
        let { contentRef: e2 } = (0, i.gKY)(), {
          album: t2,
          track: a2,
          settings: { isMobile: r2 }
        } = (0, i.Pjs)();
        a2.trackId && a2.albumId && a2.isOpened && a2.getData(), (0, m.useEffect)(
          () => () => {
            a2.reset();
          },
          [a2]
        ), (0, m.useEffect)(() => {
          a2.isOpened && a2.setAnimationState(false);
        }, [a2]), ((e3, t3) => {
          (0, m.useEffect)(() => {
            if (!e3 || !t3) return;
            let a3 = (0, p.fO)(e3);
            n((0, o.zc)(t3), a3, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, i.jxB)(e4);
            });
          }, [e3, null == e3 ? void 0 : e3.title, t3, null == t3 ? void 0 : t3.title]);
        })(t2.meta, a2.meta);
        let l2 = (0, m.useCallback)(
          (e3) => {
            var t3;
            null == (t3 = a2.onOpenChange) || t3.call(a2, e3);
          },
          [a2]
        );
        return (0, d.jsx)(_.a, {
          size: "fitContent",
          placement: r2 ? "default" : "right",
          open: a2.isOpened,
          onOpenChange: l2,
          className: h().root,
          contentClassName: h().modalContent,
          portalNode: r2 ? null : e2,
          showHeader: false,
          withOverlay: r2,
          closeOnOutsidePress: false,
          withAnimation: a2.withAnimation,
          isMobile: r2,
          lockScroll: r2,
          children: (0, d.jsx)(er, {})
        });
      });
      (0, u.PA)((e2) => {
        let { albumId: t2, trackId: a2, preloadedTrack: n2, preloadedSimilarTracks: r2 } = e2, { track: l2 } = (0, i.Pjs)();
        return n2 && l2.setTrackInfo({ track: n2, similarTracks: r2 }), l2.setIsTrackPage(true), l2.open({ trackId: a2, albumId: Number(t2) }), null;
      });
    },
    81904: (e) => {
      e.exports = {
        message: "NotificationChangeQuality_message__coCvn",
        changeButton: "NotificationChangeQuality_changeButton__Hzc3y",
        icon: "NotificationChangeQuality_icon__bOfQO"
      };
    },
    82502: (e) => {
      e.exports = {
        root_primary: "CommunicationButton_root_primary__rrmax",
        root_plus: "CommunicationButton_root_plus__d48MV",
        root_secondary: "CommunicationButton_root_secondary__YQujH",
        text: "CommunicationButton_text__kObnq"
      };
    },
    83564: (e) => {
      e.exports = {
        root: "TrailerFooter_root__LKXby",
        playButtonShimmer: "TrailerFooter_playButtonShimmer__5QwPi",
        linkButtonShimmer: "TrailerFooter_linkButtonShimmer__ZV1s1"
      };
    },
    85188: (e) => {
      e.exports = {
        root: "FullscreenPlayerDesktopButton_root__qGgoC",
        button: "FullscreenPlayerDesktopButton_button__7NEl6"
      };
    },
    85465: (e) => {
      e.exports = {
        timecode: "TimecodeGroup_timecode__IJXpy",
        timecode_current: "TimecodeGroup_timecode_current__wv9pb",
        timecode_current_animation: "TimecodeGroup_timecode_current_animation__kZUW_",
        timecode_current_hidden: "TimecodeGroup_timecode_current_hidden__D88_K",
        timecode_end: "TimecodeGroup_timecode_end__kzP5g",
        timecode_end_hidden: "TimecodeGroup_timecode_end_hidden__BxQ5h"
      };
    },
    86024: (e) => {
      e.exports = {
        root: "FullscreenPlayerDesktopContent_root__tKNGK",
        fullscreenContent: "FullscreenPlayerDesktopContent_fullscreenContent__Nvety",
        fullscreenContent_enter: "FullscreenPlayerDesktopContent_fullscreenContent_enter__xMN2Y",
        "enter-fade-fullscreen-content": "FullscreenPlayerDesktopContent_enter-fade-fullscreen-content__eOCyM",
        fullscreenContent_leave: "FullscreenPlayerDesktopContent_fullscreenContent_leave__6HeZ_",
        "leave-fade-fullscreen-content": "FullscreenPlayerDesktopContent_leave-fade-fullscreen-content__kswW5",
        fullscreenContent_withDisabledInsetTransition: "FullscreenPlayerDesktopContent_fullscreenContent_withDisabledInsetTransition___gd__",
        additionalContent: "FullscreenPlayerDesktopContent_additionalContent__tuuy7",
        additionalContent_enter: "FullscreenPlayerDesktopContent_additionalContent_enter__WQmXC",
        additionalContent_enter_active: "FullscreenPlayerDesktopContent_additionalContent_enter_active__a3nOf",
        "enter-fade-additional-content": "FullscreenPlayerDesktopContent_enter-fade-additional-content__awk7_",
        additionalContent_exit: "FullscreenPlayerDesktopContent_additionalContent_exit__aM4Or",
        additionalContent_exit_active: "FullscreenPlayerDesktopContent_additionalContent_exit_active__vokVE",
        "leave-fade-additional-content": "FullscreenPlayerDesktopContent_leave-fade-additional-content__dlFhp",
        additionalContent_withDisabledInsetTransition: "FullscreenPlayerDesktopContent_additionalContent_withDisabledInsetTransition__kvSmh",
        info: "FullscreenPlayerDesktopContent_info__Dq69p",
        artists: "FullscreenPlayerDesktopContent_artists__a_2G3",
        nonMusicAuthors: "FullscreenPlayerDesktopContent_nonMusicAuthors__JhhPY",
        meta: "FullscreenPlayerDesktopContent_meta__3jDTy",
        title: "FullscreenPlayerDesktopContent_title__I2JrP",
        meta_isSplitMode: "FullscreenPlayerDesktopContent_meta_isSplitMode__zPC2S",
        ellipsis: "FullscreenPlayerDesktopContent_ellipsis__2Qk2b",
        sliderContainer: "FullscreenPlayerDesktopContent_sliderContainer__FtBZ7",
        slider: "FullscreenPlayerDesktopContent_slider__FJscl",
        syncLyrics: "FullscreenPlayerDesktopContent_syncLyrics__6dTfH",
        syncLyricsContent: "FullscreenPlayerDesktopContent_syncLyricsContent__H_enX",
        syncLyricsLoader: "FullscreenPlayerDesktopContent_syncLyricsLoader__EQ8o9",
        syncLyricsScroller: "FullscreenPlayerDesktopContent_syncLyricsScroller__JslVK",
        syncLyricsFooter: "FullscreenPlayerDesktopContent_syncLyricsFooter__HS8JZ",
        syncLyricsCounter: "FullscreenPlayerDesktopContent_syncLyricsCounter__CnB_k"
      };
    },
    87078: (e) => {
      e.exports = {
        root: "BrandedPlayerModal_root__hejJx",
        modalContent: "BrandedPlayerModal_modalContent__xcXKK",
        image: "BrandedPlayerModal_image__paBEA",
        closeButton: "BrandedPlayerModal_closeButton__W3QRx",
        content: "BrandedPlayerModal_content__b9e2P",
        actions: "BrandedPlayerModal_actions__6aeD7",
        button: "BrandedPlayerModal_button__WZTH7"
      };
    },
    87923: (e) => {
      e.exports = {
        root: "TrackModalLyricsShimmer_root__t88sX",
        title: "TrackModalLyricsShimmer_title__lIyk4",
        lyrics: "TrackModalLyricsShimmer_lyrics__BSM_Q",
        important: "TrackModalLyricsShimmer_important__U1BbD",
        button: "TrackModalLyricsShimmer_button__uAG_w"
      };
    },
    88294: (e, t, a) => {
      "use strict";
      a.d(t, { Bx: () => C, t5: () => d, S3: () => o });
      var i = a(93064), n = a(67250), r = a(16213);
      let l = (e2) => {
        let { bgUrl: t2, bgColor: a2, title: n2, text: l2, titleColor: o2, textColor: s2, imageUrl: c2, buttons: d2 } = e2;
        return (0, i.wg)({
          bgUrl: t2 || null,
          bgColor: a2 || null,
          title: n2 || null,
          text: l2 || null,
          titleColor: o2 || null,
          textColor: s2 || null,
          imageUrl: c2 || null,
          buttons: d2.filter((e3) => e3.text).map(r.cZ)
        });
      }, o = (e2) => {
        let t2 = "data" in e2 ? l(e2.data) : l(e2.div), a2 = "feedbackToken" in e2 ? e2.feedbackToken : null, r2 = "anchorId" in e2 ? e2.anchorId : n.v.ON_START_BAR_BELOW;
        return (0, i.wg)({ anchorId: r2, screenId: e2.screenId, content: t2, feedbackToken: a2 });
      }, s = i.gK.model("BarBelowContent", {
        bgUrl: i.gK.maybeNull(i.gK.string),
        bgColor: i.gK.maybeNull(i.gK.string),
        imageUrl: i.gK.maybeNull(i.gK.string),
        title: i.gK.maybeNull(i.gK.string),
        titleColor: i.gK.maybeNull(i.gK.string),
        text: i.gK.maybeNull(i.gK.string),
        textColor: i.gK.maybeNull(i.gK.string),
        buttons: i.gK.array(r.__)
      }), c = i.gK.model("BarBelow", {
        anchorId: i.gK.enumeration(Object.values(n.v)),
        screenId: i.gK.string,
        content: s,
        feedbackToken: i.gK.maybeNull(i.gK.string)
      }), d = i.gK.model("BarBelowMain", {
        anchorId: i.gK.maybe(i.gK.string),
        isVisible: i.gK.maybe(i.gK.boolean),
        hasAnimationAlreadyBeenShown: i.gK.maybe(i.gK.boolean),
        hasAnimationAlreadyBeenHidden: i.gK.maybe(i.gK.boolean),
        hasAnimationAlreadyBeenStarted: i.gK.maybe(i.gK.boolean),
        list: i.gK.array(c)
      }).views((e2) => ({
        get barBelowItem() {
          return e2.list.find((t2) => t2.anchorId === e2.anchorId);
        },
        get showWithAnimation() {
          return !e2.hasAnimationAlreadyBeenShown && e2.isVisible;
        },
        get hideWithAnimation() {
          return e2.hasAnimationAlreadyBeenShown && !e2.hasAnimationAlreadyBeenHidden && !e2.isVisible;
        }
      })).actions((e2) => ({
        setAnchorId(t2) {
          e2.anchorId = t2;
        },
        show() {
          e2.isVisible = true;
        },
        hide() {
          e2.isVisible = false;
        },
        setAnimationAlreadyBeenShown() {
          e2.hasAnimationAlreadyBeenShown = true;
        },
        setAnimationAlreadyBeenHidden() {
          e2.hasAnimationAlreadyBeenHidden = true;
        },
        setAnimationAlreadyBeenStarted() {
          e2.hasAnimationAlreadyBeenStarted = true;
        }
      }));
      var u = a(54486), m = a(50420), _ = a(28303), p = a(61910), v = a(43426), h = a(31500), g = a(58360), x = a(97800), y = a(74125), b = a(64052), A = a.n(b);
      let C = (0, _.PA)((e2) => {
        var t2, a2, i2, n2;
        let { className: l2, barBelow: o2 } = e2, { formatMessage: s2 } = (0, v.A)(), c2 = (0, p.useMemo)(() => {
          let e3 = { title: {}, text: {}, bg: {} };
          if (!o2.barBelowItem) return e3;
          let { titleColor: t3, textColor: a3, bgColor: i3, bgUrl: n3 } = o2.barBelowItem.content;
          return t3 && (e3.title.color = t3), a3 && (e3.text.color = a3), i3 && (e3.bg.backgroundColor = i3), n3 && (e3.bg.backgroundImage = 'url("'.concat(o2.barBelowItem.content.bgUrl, '")')), e3;
        }, [o2]), d2 = (0, p.useMemo)(() => {
          var e3;
          return null == (e3 = o2.barBelowItem) ? void 0 : e3.content.buttons.map((e4) => {
            var t3, a3;
            return (0, u.jsx)(
              r.tL,
              {
                anchorId: null == (t3 = o2.barBelowItem) ? void 0 : t3.anchorId,
                screenId: null == (a3 = o2.barBelowItem) ? void 0 : a3.screenId,
                button: e4,
                buttonSize: "l",
                hide: o2.hide,
                feedbackToken: o2.barBelowItem ? o2.barBelowItem.feedbackToken : null
              },
              e4.text
            );
          });
        }, [o2]), _2 = (0, p.useCallback)(
          (e3) => {
            e3.animationName.includes("show") ? o2.setAnimationAlreadyBeenShown() : e3.animationName.includes("hide") && o2.setAnimationAlreadyBeenHidden();
          },
          [o2]
        ), b2 = (0, p.useCallback)(
          (e3) => {
            e3.animationName.includes("show") && o2.setAnimationAlreadyBeenStarted();
          },
          [o2]
        );
        return (0, u.jsx)(y.rtM, {
          page: y.l7W.MUSIC_DEEPLINK_SCREEN,
          places: [y.RBW.TOP_BUTTON],
          children: (0, u.jsxs)("section", {
            className: (0, m.$)(
              A().root,
              {
                [A().root_hidden]: !o2.isVisible && !o2.hideWithAnimation,
                [A().root_show]: o2.showWithAnimation,
                [A().root_hide]: o2.hideWithAnimation
              },
              l2
            ),
            style: c2.bg,
            onAnimationStart: b2,
            onAnimationEnd: _2,
            "aria-label": s2({ id: "bar-below.section-name" }),
            ...(0, h.Am)(h.Kq.barBelow.BAR_BELOW),
            children: [
              (null == (t2 = o2.barBelowItem) ? void 0 : t2.content.imageUrl) && (0, u.jsx)(g.Image, {
                className: A().image,
                "aria-hidden": true,
                src: null == (a2 = o2.barBelowItem) ? void 0 : a2.content.imageUrl,
                fit: "contain",
                withAvatarReplace: true,
                withAspectRatio: true,
                ...(0, h.Am)(h.Kq.barBelow.BAR_BELOW_IMAGE)
              }),
              (0, u.jsxs)("div", {
                className: A().content,
                children: [
                  (null == (i2 = o2.barBelowItem) ? void 0 : i2.content.title) && (0, u.jsx)(x.Heading, {
                    className: A().title,
                    variant: "h3",
                    style: c2.title,
                    lineClamp: 2,
                    ...(0, h.Am)(h.Kq.barBelow.BAR_BELOW_TITLE_TEXT),
                    children: o2.barBelowItem.content.title
                  }),
                  (null == (n2 = o2.barBelowItem) ? void 0 : n2.content.text) && (0, u.jsx)(x.Heading, {
                    className: A().text,
                    variant: "h4",
                    size: "xs",
                    style: c2.text,
                    lineClamp: 2,
                    ...(0, h.Am)(h.Kq.barBelow.BAR_BELOW_SECONDARY_TEXT),
                    children: o2.barBelowItem.content.text
                  })
                ]
              }),
              (0, u.jsx)("div", { className: A().buttons, children: d2 })
            ]
          })
        });
      });
    },
    88684: (e) => {
      e.exports = {
        root: "ImageSliderModal_root__AZO_D",
        root_mobile: "ImageSliderModal_root_mobile__lBg8o",
        modalContent: "ImageSliderModal_modalContent__R7c_w",
        closeButton: "ImageSliderModal_closeButton__mabus",
        content: "ImageSliderModal_content__Gjm6N",
        image: "ImageSliderModal_image__ZUYEL",
        image_loading: "ImageSliderModal_image_loading__1Fyyn",
        leftArrowWrapper: "ImageSliderModal_leftArrowWrapper__2d5RO",
        rightArrowWrapper: "ImageSliderModal_rightArrowWrapper__vSPiO",
        slider: "ImageSliderModal_slider__gDVWR",
        "swiper-pagination-disabled": "ImageSliderModal_swiper-pagination-disabled__l_U2N",
        "swiper-pagination-clickable": "ImageSliderModal_swiper-pagination-clickable__URGM_",
        "swiper-rtl": "ImageSliderModal_swiper-rtl__6n6TQ",
        "swiper-horizontal": "ImageSliderModal_swiper-horizontal__qVsPY",
        "swiper-vertical": "ImageSliderModal_swiper-vertical__fVuXc",
        wrapper: "ImageSliderModal_wrapper__s31SU",
        slide: "ImageSliderModal_slide__4VnYF",
        loadingIndicator: "ImageSliderModal_loadingIndicator__3yfbk",
        loadingIndicator_showed: "ImageSliderModal_loadingIndicator_showed__Ec0yW"
      };
    },
    89488: (e) => {
      e.exports = {
        root: "PlayQueueAfterPlayingBlock_root__A7_wI",
        title: "PlayQueueAfterPlayingBlock_title__nS_nG",
        title_withDnD: "PlayQueueAfterPlayingBlock_title_withDnD__jsVTk",
        prevTrack: "PlayQueueAfterPlayingBlock_prevTrack__wDAPP",
        animatedContent: "PlayQueueAfterPlayingBlock_animatedContent__6rvOT",
        animatedContent_moveToTop: "PlayQueueAfterPlayingBlock_animatedContent_moveToTop__bW549",
        "move-to-top": "PlayQueueAfterPlayingBlock_move-to-top__c_AzJ",
        animatedContent_moveFromTop: "PlayQueueAfterPlayingBlock_animatedContent_moveFromTop__ZLgMV",
        "move-from-top": "PlayQueueAfterPlayingBlock_move-from-top___8bwu",
        "move-prev-track-from-top": "PlayQueueAfterPlayingBlock_move-prev-track-from-top__XY1VA",
        animatedContent_moveFromTopSingleTrack: "PlayQueueAfterPlayingBlock_animatedContent_moveFromTopSingleTrack__rrewW",
        "move-from-top-single-track": "PlayQueueAfterPlayingBlock_move-from-top-single-track__8po97",
        "move-prev-track-from-top-single-track": "PlayQueueAfterPlayingBlock_move-prev-track-from-top-single-track__ySSca"
      };
    },
    90812: (e) => {
      e.exports = {
        root: "FullscreenVideoPlayerDesktop_root__a69Pd",
        important: "FullscreenVideoPlayerDesktop_important__NvXzL",
        header: "FullscreenVideoPlayerDesktop_header__oiftJ",
        modalContent: "FullscreenVideoPlayerDesktop_modalContent__YeGCV",
        closeButton: "FullscreenVideoPlayerDesktop_closeButton__OqSFs",
        logoLink: "FullscreenVideoPlayerDesktop_logoLink__o92zi",
        logo_ru: "FullscreenVideoPlayerDesktop_logo_ru__uRbpz",
        logo_en: "FullscreenVideoPlayerDesktop_logo_en__mBcdF"
      };
    },
    91126: (e) => {
      e.exports = {
        root: "TrackModalSimilarTracks_root__EAOmg",
        title: "TrackModalSimilarTracks_title__0WPaJ",
        item: "TrackModalSimilarTracks_item__BGQWd",
        important: "TrackModalSimilarTracks_important__mGqEv",
        tracksContainer: "TrackModalSimilarTracks_tracksContainer__E55ep"
      };
    },
    91724: (e) => {
      e.exports = {
        root: "PlayQueueDnDDraggableTrack_root__ysTVY",
        dots: "PlayQueueDnDDraggableTrack_dots__enjOX",
        noHoverItem: "PlayQueueDnDDraggableTrack_noHoverItem__uHRh1"
      };
    },
    91803: (e, t, a) => {
      "use strict";
      a.d(t, { ov: () => P, k8: () => m, fZ: () => s });
      var i = a(93064), n = a(67250), r = a(15209), l = a(16213);
      let o = (e2) => {
        let {
          isModal: t2,
          withShadow: a2,
          closeActionId: n2,
          bgUrl: o2,
          bgUrlLarge: s2,
          bgColor: c2,
          logoUrl: d2,
          title: u2,
          text: m2,
          titleColor: _2,
          textColor: p2,
          buttons: v2,
          disclaimer: h2,
          disclaimerColor: g2
        } = e2;
        return (0, i.wg)({
          isModal: (0, r.toBoolean)(t2),
          withShadow: (0, r.toBoolean)(a2),
          closeActionId: n2 || null,
          bgUrl: o2 || null,
          bgUrlLarge: s2 || null,
          bgColor: c2 || null,
          logoUrl: d2 || null,
          title: u2 || null,
          text: m2 || null,
          titleColor: _2 || null,
          textColor: p2 || null,
          buttons: v2.filter((e3) => e3.text).map(l.cZ),
          disclaimer: h2 || null,
          disclaimerColor: g2 || null
        });
      }, s = (e2) => {
        let t2 = "data" in e2 ? o(e2.data) : o(e2.div), a2 = "feedbackToken" in e2 ? e2.feedbackToken : null, r2 = "anchorId" in e2 ? e2.anchorId : n.v.ON_START_FULLSCREEN;
        return (0, i.wg)({ anchorId: r2, screenId: e2.screenId, content: t2, feedbackToken: a2 });
      };
      var c = a(26433);
      let d = i.gK.model("CommunicationModalContentModel", {
        isModal: i.gK.boolean,
        withShadow: i.gK.boolean,
        closeActionId: i.gK.maybeNull(i.gK.string),
        bgUrl: i.gK.maybeNull(i.gK.string),
        bgUrlLarge: i.gK.maybeNull(i.gK.string),
        bgColor: i.gK.maybeNull(i.gK.string),
        logoUrl: i.gK.maybeNull(i.gK.string),
        title: i.gK.maybeNull(i.gK.string),
        titleColor: i.gK.maybeNull(i.gK.string),
        text: i.gK.maybeNull(i.gK.string),
        textColor: i.gK.maybeNull(i.gK.string),
        buttons: i.gK.array(l.__),
        disclaimer: i.gK.maybeNull(i.gK.string),
        disclaimerColor: i.gK.maybeNull(i.gK.string)
      }), u = i.gK.model("CommunicationModal", {
        anchorId: i.gK.enumeration(Object.values(n.v)),
        screenId: i.gK.string,
        content: d,
        feedbackToken: i.gK.maybeNull(i.gK.string)
      }), m = c.qt.props({ anchorId: i.gK.maybe(i.gK.enumeration(Object.values(n.v))), list: i.gK.array(u) }).views((e2) => ({
        get modalItem() {
          return e2.list.find((t2) => t2.anchorId === e2.anchorId);
        }
      })).actions((e2) => ({
        setAnchorId(t2) {
          e2.anchorId = t2;
        }
      }));
      var _ = a(54486), p = a(50420), v = a(28303), h = a(61910), g = a(43426), x = a(31500), y = a(77881), b = a(5956), A = a(58360), C = a(32692), N = a(97800), f = a(74125), I = a(80585), S = a(48167), T = a.n(S);
      let P = (0, v.PA)((e2) => {
        var t2, a2, i2, n2, r2, o2;
        let { modal: s2 } = e2, { formatMessage: c2 } = (0, g.A)(), { communication: d2 } = (0, f.Pjs)(), u2 = null == (t2 = s2.modalItem) ? void 0 : t2.content.isModal, m2 = (0, h.useMemo)(() => {
          var e3;
          return null == (e3 = s2.modalItem) ? void 0 : e3.content.buttons.map((e4) => {
            var t3;
            return (0, _.jsx)(
              l.tL,
              {
                screenId: null == (t3 = s2.modalItem) ? void 0 : t3.screenId,
                anchorId: s2.anchorId,
                button: e4,
                buttonSize: "default",
                buttonClassName: T().button,
                textClassName: T().buttonText,
                hide: s2.close,
                feedbackToken: s2.modalItem ? s2.modalItem.feedbackToken : null
              },
              e4.text
            );
          });
        }, [s2]), v2 = (0, h.useMemo)(() => {
          let e3 = { bg: {}, title: {}, text: {}, disclaimer: {} };
          if (!s2.modalItem) return e3;
          let {
            bgUrl: t3,
            bgUrlLarge: a3,
            bgColor: i3,
            titleColor: n3,
            textColor: r3,
            disclaimerColor: l2
          } = s2.modalItem.content;
          return t3 && (e3.bg["--bg-url"] = 'url("'.concat(t3, '")')), a3 && (e3.bg["--bg-url-large"] = 'url("'.concat(a3, '")')), i3 && (e3.bg.backgroundColor = i3), n3 && (e3.title.color = n3), r3 && (e3.text.color = r3), l2 && (e3.disclaimer.color = l2), e3;
        }, [s2]), S2 = (0, h.useCallback)(() => {
          s2.modalItem && s2.modalItem.content.closeActionId && d2.action(
            s2.modalItem.anchorId,
            s2.modalItem.screenId,
            s2.modalItem.content.closeActionId,
            s2.modalItem.feedbackToken
          ), s2.close();
        }, [s2, d2]), P2 = (0, h.useMemo)(() => {
          var e3;
          if (null == (e3 = s2.modalItem) ? void 0 : e3.content.logoUrl)
            return (0, _.jsx)(A.Image, {
              className: T().image,
              withAvatarReplace: true,
              withFallback: false,
              src: s2.modalItem.content.logoUrl,
              withAspectRatio: true,
              size: 400,
              fit: "cover"
            });
        }, [s2]), k = (0, h.useMemo)(() => {
          var e3;
          return (null == (e3 = s2.modalItem) ? void 0 : e3.content.disclaimer) && (0, f.rVI)(s2.modalItem.content.disclaimer, I.N_, {
            className: T().disclaimerLink,
            style: v2.disclaimer,
            target: "_blank"
          });
        }, [s2, v2]);
        return (0, _.jsxs)(C.a, {
          style: v2.bg,
          className: (0, p.$)(T().root, u2 ? T().root_modal : T().root_fullscreen),
          headerClassName: T().modalHeader,
          contentClassName: T().modalContent,
          header: P2 && (0, _.jsx)("div", {
            className: (0, p.$)(T().imageWrapper, T().imageWrapper_header),
            ...(0, x.Am)(x.Kq.communicationModal.COMMUNICATION_MODAL_HEADER_LOGO),
            children: P2
          }),
          open: s2.isOpened,
          onOpenChange: s2.onOpenChange,
          onClose: S2,
          closeOnOutsidePress: false,
          size: u2 ? "fitContent" : "fullscreen",
          placement: "center",
          labelClose: c2({ id: "interface-actions.close" }),
          customCloseButton: (0, _.jsx)(
            y.$,
            {
              radius: "round",
              size: "xxs",
              icon: (0, _.jsx)(b.Icon, { className: T().closeButtonIcon, variant: "close", size: "xxs" }),
              onClick: S2,
              "aria-label": c2({ id: "interface-actions.close" }),
              className: T().closeButton,
              withHover: false,
              ...(0, x.Am)(x.Kq.communicationModal.COMMUNICATION_MODAL_CLOSE_CROSS_BUTTON)
            },
            "".concat(null == (a2 = s2.modalItem) ? void 0 : a2.anchorId, "-").concat(null == (i2 = s2.modalItem) ? void 0 : i2.content.closeActionId)
          ),
          ...(0, x.Am)(x.Kq.communicationModal.COMMUNICATION_MODAL),
          children: [
            (0, _.jsxs)("div", {
              className: T().container,
              children: [
                (0, _.jsxs)("div", {
                  className: T().wrapper,
                  children: [
                    P2 && (0, _.jsx)("div", {
                      className: (0, p.$)(T().imageWrapper, T().imageWrapper_content),
                      ...(0, x.Am)(x.Kq.communicationModal.COMMUNICATION_MODAL_CONTENT_LOGO),
                      children: P2
                    }),
                    (null == (n2 = s2.modalItem) ? void 0 : n2.content.title) && (0, _.jsx)(N.Heading, {
                      className: T().title,
                      style: v2.title,
                      size: "xl",
                      weight: "black",
                      variant: "h1",
                      lineClamp: 3,
                      ...(0, x.Am)(x.Kq.communicationModal.COMMUNICATION_MODAL_TITLE_TEXT),
                      children: s2.modalItem.content.title
                    }),
                    (null == (r2 = s2.modalItem) ? void 0 : r2.content.text) && (0, _.jsx)(N.Heading, {
                      className: T().text,
                      style: v2.text,
                      size: "xs",
                      variant: "h2",
                      lineClamp: 4,
                      ...(0, x.Am)(x.Kq.communicationModal.COMMUNICATION_MODAL_CONTENT_TEXT),
                      children: s2.modalItem.content.text
                    }),
                    (0, _.jsx)(f.rtM, {
                      page: f.l7W.MUSIC_DEEPLINK_SCREEN,
                      places: [f.RBW.TOP_BUTTON],
                      children: (0, _.jsx)("div", { className: T().buttons, children: m2 })
                    })
                  ]
                }),
                (0, _.jsx)("div", {
                  className: T().disclaimerWrapper,
                  children: (0, _.jsx)(N.Caption, {
                    className: T().disclaimer,
                    style: v2.disclaimer,
                    type: "text",
                    variant: "div",
                    size: "xs",
                    weight: "medium",
                    ...(0, x.Am)(x.Kq.communicationModal.COMMUNICATION_MODAL_DISCLAIMER),
                    children: k
                  })
                })
              ]
            }),
            !u2 && (null == (o2 = s2.modalItem) ? void 0 : o2.content.withShadow) && (0, _.jsx)("div", { className: T().gradientOverlay })
          ]
        });
      });
    },
    93622: (e) => {
      e.exports = {
        container: "VideoPlayerContainer_container__pZe41",
        loadingIndicator: "VideoPlayerContainer_loadingIndicator__qDxPV",
        root: "VideoPlayerContainer_root__GHDoi",
        loadingIndicator_showed: "VideoPlayerContainer_loadingIndicator_showed__KQCNf"
      };
    },
    95373: (e, t, a) => {
      "use strict";
      a.d(t, { f: () => eu, v: () => b });
      var i = a(63930), n = a(93064), r = a(14287), l = a(70392), o = a(89461), s = a(74125), c = a(26433), d = a(63695), u = a(54460), m = a(21365);
      let _ = (e2, t2) => {
        let a2 = (0, m.vU)(e2, t2);
        if (null == t2 ? void 0 : t2.albumId) {
          var i2, r2;
          let e3 = a2.albums.find((e4) => String(e4.id) === String(t2.albumId));
          return {
            ...a2,
            isBest: null == e3 || null == (i2 = e3.bestAlbumTracks) ? void 0 : i2.includes(Number(a2.id)),
            positionInAlbum: null == e3 || null == (r2 = e3.trackPosition) ? void 0 : r2.index
          };
        }
        return (0, n.wg)({ ...a2 });
      };
      var p = (function(e2) {
        return e2.ALBUM = "album", e2.ARTIST = "artist", e2.PLAYLIST = "playlist", e2.TRACK = "track", e2;
      })({});
      let v = n.gK.model("TrailerMeta", {
        id: n.gK.string,
        url: n.gK.string,
        title: n.gK.maybe(n.gK.string),
        uuid: n.gK.maybe(n.gK.string),
        coverUri: n.gK.maybe(n.gK.string),
        averageColor: n.gK.maybe(n.gK.string),
        albumArtists: n.gK.maybe(n.gK.array(d.PK)),
        albumType: n.gK.maybe(n.gK.string)
      }).views((e2) => ({
        getSharingProps(t2) {
          switch (t2) {
            case p.ALBUM:
              return { pattern: "/album/:albumId", params: { albumId: e2.id } };
            case p.ARTIST:
              return { pattern: "/artist/:artistId", params: { artistId: e2.id } };
            case p.PLAYLIST:
              return { pattern: "/playlists/:playlistUuid", params: { playlistUuid: e2.uuid } };
            case p.TRACK:
              return { pattern: "/track/:trackId", params: { trackId: e2.id } };
            default:
              return { pattern: s.Zyd.main.href, params: {} };
          }
        }
      }));
      var h = a(63585), g = a(97719);
      let x = n.gK.model("TrailerState", {
        contextType: n.gK.maybeNull(n.gK.enumeration(Object.values(h.K))),
        contextId: n.gK.maybeNull(n.gK.string),
        entityMeta: n.gK.maybeNull(g.x5),
        status: n.gK.enumeration(Object.values(o.MT))
      }).actions((e2) => ({
        setContextId: (t2) => {
          e2.contextId = String(t2);
        },
        setContextType: (t2) => {
          e2.contextType = t2;
        },
        setEntityMeta: (t2) => {
          t2 && t2.data.meta && (e2.entityMeta = (0, g.pE)(t2));
        },
        setStatus: (t2) => {
          e2.status = t2;
        }
      })), y = m.vj.props({ isBest: n.gK.maybe(n.gK.boolean), positionInAlbum: n.gK.maybe(n.gK.number) }).named("TrailerTrack"), b = n.gK.compose(
        n.gK.model("Trailer", {
          id: n.gK.maybeNull(n.gK.string),
          errorStatusCode: n.gK.maybeNull(n.gK.number),
          modal: c.qt,
          variant: n.gK.maybeNull(n.gK.enumeration(Object.values(p))),
          tracks: n.gK.maybeNull(n.gK.array(y)),
          meta: n.gK.maybeNull(v),
          state: x,
          withAnimation: n.gK.boolean,
          shouldAutoStartPlaying: n.gK.boolean,
          shouldSendEventOnTracksShowed: n.gK.boolean,
          sonataStatusBeforeTrailerStart: n.gK.enumeration(Object.values(o.MT)),
          isManuallyPaused: n.gK.boolean,
          utmLinkModel: n.gK.maybe(s._eP),
          title: n.gK.maybeNull(n.gK.string),
          shareable: n.gK.maybeNull(n.gK.boolean),
          personalColor: n.gK.maybeNull(n.gK.number)
        }),
        c.XT
      ).views((e2) => ({
        get isLoading() {
          return e2.isNeededToLoad || e2.loadingState === s.GuX.PENDING;
        },
        get isNotFound() {
          var t2;
          let a2 = e2.loadingState === s.GuX.RESOLVE && (null == (t2 = e2.tracks) ? void 0 : t2.length) === 0, i2 = e2.errorStatusCode === r.X1.NOT_FOUND;
          return a2 || i2;
        },
        get objectId() {
          return "".concat(e2.variant, ":").concat(e2.id);
        },
        get utmLink() {
          return e2.utmLinkModel && (0, i.HO)(e2.utmLinkModel);
        }
      })).actions((e2) => {
        let t2 = {
          setUtmLink(t3) {
            t3 && (e2.utmLinkModel = (0, n.wg)(t3));
          },
          resetUtmLink() {
            e2.utmLinkModel = void 0;
          },
          setAnimationState(t3) {
            e2.withAnimation = t3;
          },
          setShouldAutoStartPlaying(t3) {
            e2.shouldAutoStartPlaying = t3;
          },
          setShouldSendEventOnTracksShowed(t3) {
            e2.shouldSendEventOnTracksShowed = t3;
          },
          setIsManuallyPaused(t3) {
            e2.isManuallyPaused = t3;
          },
          isTrailerActive: (t3, a2) => !!e2.modal.isOpened && e2.variant === t3 && e2.id === a2,
          openArtistTrailer(a2) {
            let { sonataState: i2 } = (0, n.Zn)(e2);
            t2.isTrailerActive(p.ARTIST, a2) || (t2.reset(), e2.variant = p.ARTIST, e2.id = a2, e2.sonataStatusBeforeTrailerStart = i2.status, e2.modal.open(), t2.getArtistTrailer(a2));
          },
          openAlbumTrailer(a2) {
            let { sonataState: i2 } = (0, n.Zn)(e2);
            t2.isTrailerActive(p.ALBUM, String(a2)) || (t2.reset(), e2.variant = p.ALBUM, e2.id = String(a2), e2.sonataStatusBeforeTrailerStart = i2.status, e2.modal.open(), t2.getAlbumTrailer(a2));
          },
          openPlaylistTrailer(a2) {
            let { sonataState: i2 } = (0, n.Zn)(e2);
            t2.isTrailerActive(p.PLAYLIST, a2) || (t2.reset(), e2.variant = p.PLAYLIST, e2.id = a2, e2.sonataStatusBeforeTrailerStart = i2.status, e2.modal.open(), t2.getPlaylistTrailer(a2));
          },
          openTrackTrailer(a2) {
            let { sonataState: i2 } = (0, n.Zn)(e2);
            t2.isTrailerActive(p.TRACK, a2) || (t2.reset(), e2.variant = p.TRACK, e2.id = a2, e2.sonataStatusBeforeTrailerStart = i2.status, e2.modal.open(), t2.getTrackTrailer(a2));
          },
          getArtistTrailer: (0, n.L3)(function* (a2) {
            let { artistsResource: i2 } = (0, n._$)(e2);
            if (e2.loadingState !== s.GuX.PENDING)
              try {
                e2.loadingState = s.GuX.PENDING;
                let { artist: t3, trailer: r2 } = yield i2.getTrailer({ artistId: a2 });
                r2.tracks && (e2.tracks = (0, n.wg)(r2.tracks.map((e3) => _(e3, { isSmartPreview: true })))), r2.title && (e2.title = r2.title), t3 && (e2.meta = ((e3) => {
                  var t4, a3;
                  let { href: i3 } = (0, s.uvd)("/artist/:artistId", { params: { artistId: e3.id } });
                  return (0, n.wg)({
                    id: String(e3.id),
                    url: i3,
                    title: e3.name,
                    coverUri: null == (t4 = e3.cover) ? void 0 : t4.uri,
                    averageColor: null == (a3 = e3.cover) ? void 0 : a3.color
                  });
                })(t3)), e2.loadingState = s.GuX.RESOLVE;
              } catch (e3) {
                t2.handleError(e3);
              }
          }),
          getAlbumTrailer: (0, n.L3)(function* (a2) {
            let { albumResource: i2 } = (0, n._$)(e2);
            if (e2.loadingState !== s.GuX.PENDING)
              try {
                e2.loadingState = s.GuX.PENDING;
                let { album: t3, artists: r2, trailer: l2 } = yield i2.getTrailer({ albumId: a2 });
                l2.tracks && (e2.tracks = (0, n.wg)(l2.tracks.map((e3) => _(e3, { isSmartPreview: true, albumId: t3.id })))), l2.title && (e2.title = l2.title), t3 && (e2.meta = ((e3, t4) => {
                  var a3, i3;
                  let r3 = null == t4 ? void 0 : t4.map((e4) => (0, d.as)({ artist: e4 })), { href: l3 } = (0, s.uvd)("/album/:albumId", { params: { albumId: e3.id } });
                  return (0, n.wg)({
                    id: String(e3.id),
                    url: l3,
                    title: e3.title,
                    coverUri: null == (a3 = e3.cover) ? void 0 : a3.uri,
                    averageColor: null == (i3 = e3.cover) ? void 0 : i3.color,
                    albumArtists: r3,
                    albumType: e3.albumType
                  });
                })(t3, r2)), e2.loadingState = s.GuX.RESOLVE;
              } catch (e3) {
                t2.handleError(e3);
              }
          }),
          getPlaylistTrailer: (0, n.L3)(function* (a2) {
            let { usersResource: i2 } = (0, n._$)(e2);
            if (e2.loadingState !== s.GuX.PENDING)
              try {
                e2.loadingState = s.GuX.PENDING;
                let { uid: t3, kind: r2 } = (0, l.I)(a2);
                if (!t3 || !r2) {
                  e2.loadingState = s.GuX.REJECT;
                  return;
                }
                let {
                  playlist: o2,
                  trailer: c2,
                  shareable: d2,
                  personalColor: u2
                } = yield i2.getPlaylistTrailer({ userId: t3, playlistKind: Number(r2) });
                c2.tracks && (e2.tracks = (0, n.wg)(c2.tracks.map((e3) => _(e3, { isSmartPreview: true })))), c2.title && (e2.title = c2.title), d2 && (e2.shareable = d2), u2 && (e2.personalColor = u2), o2 && (e2.meta = ((e3) => {
                  var t4, a3;
                  let { href: i3 } = (0, s.uvd)("/playlists/:playlistUuid", {
                    params: { playlistUuid: e3.playlistUuid }
                  });
                  return (0, n.wg)({
                    id: "".concat(e3.uid, ":").concat(e3.kind),
                    url: i3,
                    uuid: e3.playlistUuid,
                    title: e3.title,
                    coverUri: null == (t4 = e3.cover) ? void 0 : t4.uri,
                    averageColor: null == (a3 = e3.cover) ? void 0 : a3.color
                  });
                })(o2)), e2.loadingState = s.GuX.RESOLVE;
              } catch (e3) {
                t2.handleError(e3);
              }
          }),
          getTrackTrailer: (0, n.L3)(function* (a2) {
            let { tracksResource: i2 } = (0, n._$)(e2);
            if (e2.loadingState !== s.GuX.PENDING)
              try {
                e2.loadingState = s.GuX.PENDING;
                let { track: t3, title: c2 } = yield i2.getTrailer({ trackId: a2 });
                if (c2 && (e2.title = c2), t3) {
                  var r2, l2, o2;
                  e2.tracks = (0, n.wg)([_(t3, { isSmartPreview: true })]), e2.meta = (0, n.wg)({
                    id: String(t3.id),
                    url: (0, u.$O)(t3.id, null == (l2 = t3.albums) || null == (r2 = l2[0]) ? void 0 : r2.id),
                    title: t3.title,
                    coverUri: t3.coverUri,
                    averageColor: null == (o2 = t3.derivedColors) ? void 0 : o2.average
                  });
                }
                e2.loadingState = s.GuX.RESOLVE;
              } catch (e3) {
                t2.handleError(e3);
              }
          }),
          handleError(t3) {
            let { modelActionsLogger: a2 } = (0, n._$)(e2);
            a2.error(t3), t3 instanceof r.GX && (t3.statusCode === r.X1.NOT_FOUND || t3.statusCode === r.X1.BAD_REQUEST) && (e2.errorStatusCode = r.X1.NOT_FOUND), e2.loadingState !== s.GuX.IDLE && (e2.loadingState = s.GuX.REJECT);
          },
          reset() {
            e2.loadingState = s.GuX.IDLE, e2.errorStatusCode = null, e2.variant = null, e2.id = null, e2.tracks = null, e2.meta = null, e2.withAnimation = true, e2.shouldAutoStartPlaying = true, e2.shouldSendEventOnTracksShowed = true, e2.sonataStatusBeforeTrailerStart = o.MT.IDLE, e2.isManuallyPaused = true, e2.title = null, e2.shareable = null, e2.personalColor = null;
          }
        };
        return t2;
      });
      var A = a(54486), C = a(28303), N = a(61910), f = a(43426), I = a(31500), S = a(77881), T = a(5956), P = a(32692), k = a(43350), E = a(62395);
      let j = () => {
        let e2 = (0, E.st)(), t2 = (0, s.UlF)(), { hash: a2 } = (0, E.gf)(), { pageId: i2 } = (0, s.$au)();
        return (0, N.useCallback)(
          (n2) => {
            if (!e2 || !i2) return;
            let r2 = { hash: a2, pageId: s.Wft[i2], mainObjectType: k.ky.Trailer, mainObjectId: n2 }, l2 = (0, k.Fx)({ params: r2, logger: t2, context: "useSendEventOnTrailerClosed" });
            l2 && (0, k.XB)(e2.evgenInstance, l2);
          },
          [e2, a2, t2, i2]
        );
      };
      var L = a(50420), w = a(9348), M = a(80585);
      let B = () => {
        let e2 = (0, E.st)(), t2 = (0, s.UlF)(), { hash: a2 } = (0, E.gf)(), { pageId: i2 } = (0, s.$au)();
        return (0, N.useCallback)(
          (n2, r2) => {
            if (!e2 || !i2) return;
            let l2 = { hash: a2, pageId: s.Wft[i2], mainObjectType: k.ky.Trailer, mainObjectId: n2 };
            r2 && (l2.actionType = k.X2.Pause, l2.userInteractionType = k.gi.Tap);
            let o2 = (0, k.Fx)({ params: l2, logger: t2, context: "useSendEventOnTrailerStarted" });
            o2 && (r2 && ((e3) => "object" == typeof e3 && null !== e3 && "actionType" in e3 && "mainObjectId" in e3)(o2) ? (0, k.bv)(e2.evgenInstance, o2) : (0, k.e7)(e2.evgenInstance, o2));
          },
          [e2, a2, t2, i2]
        );
      }, O = (e2) => {
        let { variant: t2, blockId: a2, meta: i2 } = e2, n2 = ((e3) => {
          switch (e3) {
            case p.ALBUM:
              return s._Q$.ALBUM;
            case p.ARTIST:
              return s._Q$.ARTIST;
            case p.PLAYLIST:
              return s._Q$.PLAYLIST;
            case p.TRACK:
              return s._Q$.TRACK;
          }
        })(t2), r2 = ((e3) => {
          switch (e3) {
            case p.ALBUM:
              return h.K.Album;
            case p.ARTIST:
              return h.K.Artist;
            case p.PLAYLIST:
              return h.K.Playlist;
            case p.TRACK:
            default:
              return h.K.Various;
          }
        })(t2), l2 = (null == i2 ? void 0 : i2.uuid) || (null == i2 ? void 0 : i2.id);
        return (0, s.fyy)({ pageId: n2, blockId: a2, contextId: l2, contextType: r2, pageEntityId: l2 });
      }, R = (e2) => {
        let { variant: t2, id: a2, from: i2, uuid: n2, utmLink: r2 } = e2;
        switch (t2) {
          case p.ALBUM:
            return { type: h.K.Album, trailer: true, meta: { id: Number(a2) }, from: i2, utmLink: r2 };
          case p.ARTIST:
            return { type: h.K.Artist, trailer: true, meta: { id: String(a2) }, from: i2, utmLink: r2 };
          case p.PLAYLIST:
            return { type: h.K.Playlist, trailer: true, meta: { id: String(a2), uuid: n2 }, from: i2, utmLink: r2 };
          case p.TRACK:
            return { type: h.K.Various, trailer: true, meta: { id: String(a2) }, from: i2, utmLink: r2 };
        }
      };
      var D = a(47713), K = a(97800), U = a(74504), F = a.n(U);
      let z = (0, C.PA)(() => {
        let { trailer: e2 } = (0, s.Pjs)(), { variant: t2, id: a2 } = e2, i2 = (0, N.useCallback)(() => {
          if (t2 && a2)
            switch (t2) {
              case p.ALBUM:
                e2.getAlbumTrailer(Number(a2));
                break;
              case p.ARTIST:
                e2.getArtistTrailer(a2);
                break;
              case p.PLAYLIST:
                e2.getPlaylistTrailer(a2);
                break;
              case p.TRACK:
                e2.getTrackTrailer(a2);
            }
        }, [a2, e2, t2]);
        return (0, A.jsxs)("div", {
          className: F().root,
          children: [
            (0, A.jsxs)("div", {
              className: F().textContainer,
              children: [
                (0, A.jsx)(K.Heading, {
                  variant: "h2",
                  className: F().title,
                  size: "xs",
                  weight: "bold",
                  children: (0, A.jsx)(D.A, { id: "error-messages.something-went-wrong" })
                }),
                (0, A.jsx)(K.Caption, {
                  className: F().description,
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: (0, A.jsx)(D.A, { id: "trailer.something-went-wrong-description" })
                })
              ]
            }),
            (0, A.jsx)(S.$, {
              onClick: i2,
              color: "secondary",
              size: "default",
              radius: "xxxl",
              children: (0, A.jsx)(K.Caption, {
                type: "controls",
                variant: "span",
                size: "m",
                children: (0, A.jsx)(D.A, { id: "page-error.reload" })
              })
            })
          ]
        });
      }), V = () => (0, A.jsx)("div", {
        className: F().root,
        children: (0, A.jsxs)("div", {
          className: F().textContainer,
          children: [
            (0, A.jsx)(K.Heading, {
              variant: "h2",
              className: F().title,
              size: "xs",
              weight: "bold",
              children: (0, A.jsx)(D.A, { id: "trailer.not-found-title" })
            }),
            (0, A.jsx)(K.Caption, {
              className: F().description,
              variant: "span",
              type: "text",
              size: "l",
              weight: "normal",
              children: (0, A.jsx)(D.A, { id: "trailer.not-found-description" })
            })
          ]
        })
      });
      var W = a(22674);
      let G = () => {
        let e2 = (0, E.st)(), t2 = (0, s.UlF)(), { hash: a2 } = (0, E.gf)(), { pageId: i2 } = (0, s.$au)();
        return (0, N.useCallback)(
          (n2, r2) => {
            if (!e2 || !i2) return;
            let l2 = {
              hash: a2,
              pageId: s.Wft[i2],
              mainObjectType: k.ky.Trailer,
              mainObjectId: n2,
              from: k.QT.TrailerScreen,
              to: s.Wft[r2]
            }, o2 = (0, k.Fx)({ params: l2, logger: t2, context: "useSendEventOnTrailerNavigated" });
            o2 && (0, k.Mu)(e2.evgenInstance, o2);
          },
          [e2, a2, t2, i2]
        );
      }, Y = { [p.ALBUM]: k.ky.Album, [p.ARTIST]: k.ky.Artist, [p.PLAYLIST]: k.ky.Playlist, [p.TRACK]: k.ky.Track }, Q = { [p.ALBUM]: s._Q$.ALBUM, [p.ARTIST]: s._Q$.ARTIST, [p.PLAYLIST]: s._Q$.PLAYLIST };
      var $ = a(83564), q = a.n($);
      let H = (0, C.PA)((e2) => {
        var t2, a2;
        let { variant: i2, isShimmerVisible: n2, isShimmerActive: r2, className: l2 } = e2, {
          trailer: { state: c2, meta: d2, modal: u2, objectId: m2, resetUtmLink: _2 }
        } = (0, s.Pjs)(), v2 = (0, s.eGp)(), { from: g2 } = O({ variant: i2, blockId: s.UfI.TRAILER }), x2 = G(), y2 = j(), b2 = (() => {
          let e3 = (0, E.st)(), t3 = (0, s.UlF)(), { hash: a3 } = (0, E.gf)(), { pageId: i3 } = (0, s.$au)();
          return (0, N.useCallback)(
            (n3, r3) => {
              if (!e3 || !i3) return;
              let l3 = { hash: a3, pageId: s.Wft[i3], mainObjectType: n3, mainObjectId: r3 }, o2 = (0, k.Fx)({ params: l3, logger: t3, context: "useSendEventOnTrailerEntityStarted" });
              o2 && (0, k.e7)(e3.evgenInstance, o2);
            },
            [e3, a3, t3, i3]
          );
        })(), C2 = (0, s.ZpR)(null != (a2 = null == d2 ? void 0 : d2.url) ? a2 : ""), f2 = (0, N.useCallback)(() => {
          C2();
          let e3 = Q[i2];
          e3 && x2(m2, e3);
        }, [C2, m2, x2, i2]), P2 = ((e3) => {
          let {
            trailer: { meta: t3 },
            artist: a3,
            album: i3,
            playlist: n3
          } = (0, s.Pjs)();
          switch (e3) {
            case p.ALBUM:
              return i3.id === Number(null == t3 ? void 0 : t3.id);
            case p.ARTIST:
              return a3.id === (null == t3 ? void 0 : t3.id);
            case p.PLAYLIST:
              return n3.uuid === (null == t3 ? void 0 : t3.uuid);
            case p.TRACK:
              return false;
          }
        })(i2), w2 = !P2 && i2 !== p.TRACK, M2 = (0, N.useCallback)(() => {
          var e3, t3, a3, n3;
          let r3 = null == v2 || null == (a3 = v2.playbackController.activePlayback.value) || null == (t3 = a3.state) || null == (e3 = t3.currentContext.value) ? void 0 : e3.utmLink;
          null == v2 || v2.stop(s.V_r.TRAILER), _2(), u2.close(), y2(m2), w2 && f2();
          let l3 = c2.status !== o.MT.PLAYING || i2 === p.ALBUM ? { index: 0 } : { entityId: null == (n3 = c2.entityMeta) ? void 0 : n3.id }, x3 = ((e4) => {
            let { variant: t4, id: a4, from: i3, uuid: n4, utmLink: r4 } = e4;
            switch (t4) {
              case p.ALBUM:
                return { type: h.K.Album, meta: { id: Number(a4) }, from: i3, utmLink: r4 };
              case p.ARTIST:
                return { type: h.K.Artist, meta: { id: String(a4) }, from: i3, utmLink: r4 };
              case p.PLAYLIST:
                return { type: h.K.Playlist, meta: { id: String(a4), uuid: n4 }, from: i3, utmLink: r4 };
              case p.TRACK:
                return { type: h.K.Various, meta: { id: String(a4) }, from: i3, utmLink: r4 };
            }
          })({ variant: i2, id: null == d2 ? void 0 : d2.id, uuid: null == d2 ? void 0 : d2.uuid, from: g2, utmLink: r3 });
          null == v2 || v2.playContext({ contextData: x3, queueParams: l3 }).then(() => {
            (null == d2 ? void 0 : d2.id) && b2(Y[i2], d2.id);
          });
        }, [
          v2,
          _2,
          u2,
          y2,
          m2,
          w2,
          c2.status,
          null == (t2 = c2.entityMeta) ? void 0 : t2.id,
          i2,
          null == d2 ? void 0 : d2.id,
          null == d2 ? void 0 : d2.uuid,
          g2,
          f2,
          b2
        ]), B2 = (0, N.useMemo)(
          () => (0, A.jsxs)("div", {
            className: (0, L.$)(q().root, l2),
            children: [
              (0, A.jsx)(S.$, {
                radius: "xxxl",
                size: "default",
                color: "secondary",
                icon: (0, A.jsx)(T.Icon, { variant: "play", size: "xxxs" }),
                className: q().button,
                onClick: M2,
                ...(0, I.Am)(I.e8.trailer.TRAILER_LISTEN_FULL_VERSION_BUTTON),
                children: (0, A.jsx)(D.A, { id: "trailer.listen-full-version" })
              }),
              w2 && (0, A.jsx)(S.$, {
                radius: "xxxl",
                size: "default",
                color: "secondary",
                onClick: f2,
                className: q().button,
                ...(0, I.Am)(I.e8.trailer.TRAILER_NAVIGATE_TO_ENTITY_BUTTON),
                children: (0, A.jsx)(D.A, { id: "trailer.navigate" })
              })
            ]
          }),
          [l2, M2, f2, w2]
        );
        return n2 ? ((e3) => {
          let { isActive: t3, className: a3, isCurrentEntityPage: i3 } = e3;
          return (0, A.jsxs)("div", {
            className: (0, L.$)(q().root, a3),
            children: [
              (0, A.jsx)(W.Shimmer, { isActive: t3, radius: "xxxl", className: q().playButtonShimmer }),
              i3 && (0, A.jsx)(W.Shimmer, { isActive: t3, radius: "xxxl", className: q().linkButtonShimmer })
            ]
          });
        })({ isActive: r2, isCurrentEntityPage: P2, className: l2 }) : B2;
      });
      var X = a(8817), Z = a(58360), J = a(6971), ee = a(33320), et = a.n(ee);
      let ea = (0, C.PA)((e2) => {
        var t2;
        let { variant: a2, isShimmerVisible: i2, isShimmerActive: n2, className: r2 } = e2, {
          trailer: { meta: l2, objectId: o2, utmLink: c2, personalColor: d2, shareable: u2, title: m2, state: _2 },
          playlist: { shouldShowTrailerOnboarding: v2, isRewind2024Playlist: h2 }
        } = (0, s.Pjs)(), { from: g2 } = O({ variant: a2, blockId: s.UfI.TRAILER, meta: l2 }), x2 = G(), y2 = B(), b2 = (0, s.brA)(), C2 = a2 === p.ARTIST ? "round" : "s", { notify: f2 } = (0, s.lkh)(), P2 = (0, s.PT7)(), k2 = (0, A.jsx)(D.A, { id: "onboarding.rewind-trailer", values: { br: (0, A.jsx)("br", {}) } }), { togglePlay: E2, isPlaying: j2 } = (0, s.Dx4)({
          playContextParams: {
            contextData: R({
              variant: a2,
              id: null == l2 ? void 0 : l2.id,
              uuid: null == l2 ? void 0 : l2.uuid,
              from: g2,
              utmLink: c2
            }),
            loadContextMeta: true
          },
          sonataState: _2,
          playbackId: s.V_r.TRAILER
        }), w2 = (0, X.c)(() => {
          P2() || (y2(o2, j2), E2(), b2(!j2));
        }), U2 = (0, N.useCallback)(() => {
          let e3 = Q[a2];
          e3 && x2(o2, e3);
        }, [o2, x2, a2]), F2 = (0, s.R4Z)(d2 || 0), z2 = (0, s.mBl)(d2 || 0), V2 = (0, N.useMemo)(() => {
          let e3, t3;
          return "number" == typeof d2 ? (e3 = F2, t3 = z2) : e3 = { "--trailer-color": null == l2 ? void 0 : l2.averageColor }, (0, A.jsxs)("div", {
            className: et().coverContainer,
            ...(0, I.Am)(I.e8.trailer.TRAILER_COVER),
            children: [
              (0, A.jsx)(J.Paper, {
                radius: C2,
                className: et().cover,
                style: t3,
                withShadow: true,
                children: (0, A.jsx)(Z.Image, {
                  "aria-hidden": true,
                  src: null == l2 ? void 0 : l2.coverUri,
                  size: 100,
                  fit: "cover",
                  withAvatarReplace: true
                })
              }),
              (0, A.jsx)("div", {
                className: et().iconContainer,
                style: e3,
                children: (0, A.jsx)(T.Icon, { variant: "trailer", size: "xs", className: et().icon })
              })
            ]
          });
        }, [C2, null == l2 ? void 0 : l2.coverUri, z2, null == l2 ? void 0 : l2.averageColor, d2, F2]), Y2 = (0, N.useMemo)(() => {
          let e3 = null == l2 ? void 0 : l2.url;
          return e3 ? (0, A.jsx)(M.N_, {
            href: e3,
            className: et().link,
            onClick: U2,
            ...(0, I.Am)(I.e8.trailer.TRAILER_ENTITY_TITLE),
            children: (0, A.jsx)(K.Caption, {
              variant: "span",
              type: "controls",
              lineClamp: 1,
              className: et().text,
              children: null == l2 ? void 0 : l2.title
            })
          }) : (0, A.jsx)(K.Caption, {
            variant: "span",
            type: "controls",
            lineClamp: 1,
            className: et().text,
            ...(0, I.Am)(I.e8.trailer.TRAILER_ENTITY_TITLE),
            children: null == l2 ? void 0 : l2.title
          });
        }, [U2, l2]), $2 = (0, N.useMemo)(
          () => (0, A.jsxs)("div", {
            className: et().textContainer,
            children: [
              (0, A.jsx)(K.Heading, {
                variant: "h1",
                className: (0, L.$)(et().text, et().title),
                lineClamp: 1,
                ...(0, I.Am)(I.e8.trailer.TRAILER_MODAL_TITLE),
                children: m2
              }),
              Y2
            ]
          }),
          [Y2, m2]
        ), { pattern: q2, params: H2 } = null != (t2 = null == l2 ? void 0 : l2.getSharingProps(a2)) ? t2 : { pattern: s.Zyd.main.href, params: {} }, { shareLink: ee2 } = (0, s.bNS)(q2, { params: H2, query: { [s.K3F.OPEN_TRAILER]: "true" } }), ea2 = (0, N.useCallback)(async () => {
          await window.navigator.clipboard.writeText(ee2), f2(
            (0, A.jsx)(M.Do, {
              entityTitle: null == l2 ? void 0 : l2.title,
              entityVariant: ((e3) => {
                switch (e3) {
                  case p.ALBUM:
                    return s.Yxq.ALBUM;
                  case p.ARTIST:
                    return s.Yxq.ARTIST;
                  case p.PLAYLIST:
                    return s.Yxq.PLAYLIST;
                  case p.TRACK:
                    return s.Yxq.TRACK;
                }
              })(a2)
            }),
            { containerId: s.uQT.INFO }
          );
        }, [ee2, f2, null == l2 ? void 0 : l2.title, a2]);
        return (0, A.jsxs)("div", {
          className: (0, L.$)(et().root, r2),
          ...(0, I.Am)(I.e8.trailer.TRAILER_HEADER),
          children: [
            i2 ? (0, A.jsx)("div", {
              className: et().coverContainer,
              children: (0, A.jsx)(W.Shimmer, { isActive: n2, radius: C2, className: et().cover })
            }) : V2,
            i2 ? ((e3) => (0, A.jsxs)("div", {
              className: et().textContainer,
              children: [
                (0, A.jsx)("div", {
                  className: et().shimmerContainer,
                  children: (0, A.jsx)(W.Shimmer, { isActive: e3, radius: "xl", className: et().titleShimmer })
                }),
                (0, A.jsx)("div", {
                  className: et().shimmerContainer,
                  children: (0, A.jsx)(W.Shimmer, {
                    isActive: e3,
                    radius: "xl",
                    className: et().descriptionShimmer
                  })
                })
              ]
            }))(n2) : $2,
            !i2 && u2 && (0, A.jsx)(S.$, {
              className: et().share,
              icon: (0, A.jsx)(T.Icon, { variant: "share", size: "xxs" }),
              onClick: ea2,
              variant: "text",
              withRipple: false,
              withHover: false
            }),
            !i2 && (0, A.jsx)(M.cv, {
              customMessage: h2 ? k2 : void 0,
              shouldForceOpenTooltip: !!v2,
              children: (0, A.jsx)(M.DM, {
                className: et().playButton,
                iconSize: "m",
                variant: "filled",
                isPlaying: j2,
                iconClassName: et().playButtonIcon,
                onClick: w2
              })
            })
          ]
        });
      });
      var ei = a(44342), en = a.n(ei);
      let er = (0, C.PA)((e2) => {
        let { variant: t2, track: a2, playContextParams: i2, viewUuid: n2 } = e2, {
          trailer: { meta: r2, objectId: l2, shouldSendEventOnTracksShowed: c2, setShouldSendEventOnTracksShowed: d2 }
        } = (0, s.Pjs)(), u2 = t2 === p.ALBUM ? m.g2 : m.nP, { isActive: _2, progress: v2 } = ((e3, t3) => {
          var a3;
          let i3 = (0, s.eGp)(), {
            trailer: { state: n3 }
          } = (0, s.Pjs)(), [r3, l3] = (0, N.useState)(0), c3 = (null == (a3 = n3.entityMeta) ? void 0 : a3.id) === e3;
          return (0, N.useEffect)(() => {
            let e4 = null == i3 ? void 0 : i3.getState(s.V_r.TRAILER).playerState.progress.onChange(() => {
              let e5, a4 = i3.getState(s.V_r.TRAILER).playerState, n4 = a4.progress.value;
              e5 = t3 ? t3 / 1e3 : n4.duration, c3 || l3(0), a4.status.value === o.MT.PLAYING && c3 && l3(n4.position / e5 * 100);
            });
            return () => {
              null == e4 || e4();
            };
          }, [t3, c3, i3]), { isActive: c3, progress: r3 };
        })(a2.id, a2.durationMs), h2 = ((e3, t3) => {
          let a3 = (0, s.UlF)(), i3 = (0, E.st)(), { hash: n3 } = (0, E.gf)(), { pageId: r3 } = (0, s.$au)(), { blockType: l3, blockId: o2, blockPosX: c3, blockPosY: d3 } = (0, s.N8n)(), { objectType: u3, objectsCount: m2, objectId: _3, objectPosX: p2, objectPosY: v3 } = (0, s.Jfv)();
          return (0, N.useCallback)(() => {
            if (!i3 || !r3) return;
            let h3 = s.Wft[r3];
            if (!h3) return;
            let g3 = {
              hash: n3,
              pageId: h3,
              mainObjectType: k.ky.Trailer,
              mainObjectId: e3,
              entityType: l3,
              entityId: o2,
              entityPosX: c3,
              entityPosY: d3,
              objectsCount: m2,
              viewUuid: t3,
              objectType: u3,
              objectId: _3,
              objectPosX: p2,
              objectPosY: v3
            }, x3 = (0, k.Fx)({ params: g3, logger: a3, context: "useSendEventOnSmartPreviewShowed" });
            x3 && (0, k.Pf)(i3.evgenInstance, x3);
          }, [i3, o2, c3, d3, l3, n3, a3, e3, _3, p2, v3, u3, m2, r3, t3]);
        })(l2, n2), g2 = ((e3) => {
          let t3 = (0, s.UlF)(), a3 = (0, E.st)(), { hash: i3 } = (0, E.gf)(), { pageId: n3 } = (0, s.$au)(), { blockType: r3, blockId: l3, blockPosX: o2, blockPosY: c3 } = (0, s.N8n)(), { objectType: d3, objectsCount: u3, objectId: m2, objectPosX: _3, objectPosY: p2 } = (0, s.Jfv)();
          return (0, N.useCallback)(
            (v3) => {
              if (!a3 || !n3) return;
              let h3 = s.Wft[n3];
              if (!h3) return;
              let g3 = {
                hash: i3,
                pageId: h3,
                mainObjectType: k.ky.Trailer,
                mainObjectId: e3,
                entityType: r3,
                entityId: l3,
                entityPosX: o2,
                entityPosY: c3,
                objectsCount: u3,
                objectType: d3,
                objectId: m2,
                objectPosX: _3,
                objectPosY: p2
              };
              v3 || (g3.actionType = k.X2.Pause, g3.userInteractionType = k.gi.Tap);
              let x3 = (0, k.Fx)({ params: g3, logger: t3, context: "useSendEventOnSmartPreviewStarted" });
              x3 && (!v3 && ((e4) => "object" == typeof e4 && null !== e4 && "actionType" in e4 && "mainObjectId" in e4)(x3) ? (0, k.h_)(a3.evgenInstance, x3) : (0, k.er)(a3.evgenInstance, x3));
            },
            [a3, l3, o2, c3, r3, i3, t3, e3, m2, _3, p2, d3, u3, n3]
          );
        })(l2), x2 = ((e3) => {
          let t3 = (0, s.UlF)(), a3 = (0, E.st)(), { hash: i3 } = (0, E.gf)(), { pageId: n3 } = (0, s.$au)(), { blockType: r3, blockId: l3, blockPosX: o2, blockPosY: c3 } = (0, s.N8n)(), { objectType: d3, objectsCount: u3, objectId: m2, objectPosX: _3, objectPosY: p2 } = (0, s.Jfv)();
          return (0, N.useCallback)(
            (v3) => {
              if (!a3 || !n3) return;
              let h3 = s.Wft[n3];
              if (!h3) return;
              let g3 = {
                hash: i3,
                pageId: h3,
                mainObjectType: k.ky.Trailer,
                mainObjectId: e3,
                entityType: r3,
                entityId: l3,
                entityPosX: o2,
                entityPosY: c3,
                objectsCount: u3,
                objectType: d3,
                objectId: m2,
                objectPosX: _3,
                objectPosY: p2,
                userInteractionType: k.gi.Tap
              };
              v3 ? g3.actionType = k.X2.Like : g3.actionType = k.X2.Unlike;
              let x3 = (0, k.Fx)({ params: g3, logger: t3, context: "useSendEventOnSmartPreviewLike" });
              x3 && (0, k.h_)(a3.evgenInstance, x3);
            },
            [a3, l3, o2, c3, r3, i3, t3, e3, m2, _3, p2, d3, u3, n3]
          );
        })(l2), y2 = ((e3) => {
          let t3 = (0, s.UlF)(), a3 = (0, E.st)(), { hash: i3 } = (0, E.gf)(), { pageId: n3 } = (0, s.$au)(), { blockType: r3, blockId: l3, blockPosX: o2, blockPosY: c3 } = (0, s.N8n)(), { objectType: d3, objectsCount: u3, objectId: m2, objectPosX: _3, objectPosY: p2 } = (0, s.Jfv)();
          return (0, N.useCallback)(
            (v3) => {
              if (!a3 || !n3) return;
              let h3 = s.Wft[n3];
              if (!h3) return;
              let g3 = {
                hash: i3,
                pageId: h3,
                mainObjectType: k.ky.Trailer,
                mainObjectId: e3,
                entityType: r3,
                entityId: l3,
                entityPosX: o2,
                entityPosY: c3,
                objectsCount: u3,
                objectType: d3,
                objectId: m2,
                objectPosX: _3,
                objectPosY: p2,
                userInteractionType: k.gi.Tap
              };
              v3 ? g3.actionType = k.X2.Dislike : g3.actionType = k.X2.Undislike;
              let x3 = (0, k.Fx)({ params: g3, logger: t3, context: "useSendEventOnSmartPreviewDislike" });
              x3 && (0, k.h_)(a3.evgenInstance, x3);
            },
            [a3, l3, o2, c3, r3, i3, t3, e3, m2, _3, p2, d3, u3, n3]
          );
        })(l2);
        (0, N.useEffect)(() => {
          c2 && (h2(), d2(false));
        }, [h2, d2, c2]);
        let b2 = (0, N.useMemo)(() => ({ "--track-progress": "".concat(v2 || 0, "%") }), [v2]);
        return (0, A.jsx)("div", {
          className: (0, L.$)(en().root, { [en().root_active]: _2 }),
          style: b2,
          children: (0, A.jsx)(u2, {
            position: a2.positionInAlbum,
            withLightning: !!(null == a2 ? void 0 : a2.isBest),
            track: a2,
            playContextParams: i2,
            albumArtists: null == r2 ? void 0 : r2.albumArtists,
            onPlayClick: g2,
            onLikeClick: x2,
            onDislikeClick: y2
          })
        });
      });
      var el = a(34528), eo = a.n(el);
      let es = (0, C.PA)((e2) => {
        let { variant: t2 } = e2, {
          trailer: a2,
          playlist: { setShouldShowTrailerOnboarding: i2 }
        } = (0, s.Pjs)(), {
          isLoading: n2,
          isRejected: r2,
          tracks: l2,
          meta: o2,
          state: c2,
          shouldAutoStartPlaying: d2,
          setShouldAutoStartPlaying: u2,
          isNotFound: m2,
          modal: _2,
          utmLink: v2
        } = a2, h2 = (0, s.eGp)(), { from: g2 } = O({ variant: t2, blockId: s.UfI.TRAILER, meta: o2 }), x2 = (() => {
          let e3 = (0, E.st)(), t3 = (0, s.UlF)(), { hash: a3 } = (0, E.gf)(), { pageId: i3 } = (0, s.$au)();
          return (0, N.useCallback)(
            (n3) => {
              if (!e3 || !i3) return;
              let r3 = { hash: a3, pageId: s.Wft[i3], mainObjectType: k.ky.Trailer, mainObjectId: n3 }, l3 = (0, k.Fx)({ params: r3, logger: t3, context: "useSendEventOnTrailerOpened" });
              l3 && (0, k.w5)(e3.evgenInstance, l3);
            },
            [e3, a3, t3, i3]
          );
        })(), y2 = B(), [b2, C2] = (0, N.useState)(false), f2 = (0, N.useRef)((0, w.A)()), I2 = n2 || r2, { isPlaying: S2 } = (0, s.Dx4)({
          playContextParams: {
            contextData: R({
              variant: t2,
              id: null == o2 ? void 0 : o2.id,
              uuid: null == o2 ? void 0 : o2.uuid,
              from: g2,
              utmLink: v2
            }),
            loadContextMeta: true
          },
          sonataState: a2.state,
          playbackId: s.V_r.TRAILER
        });
        (0, N.useEffect)(() => {
          _2.isOpened && (null == o2 ? void 0 : o2.id) && d2 && (x2(a2.objectId), null == h2 || h2.playContext(
            {
              contextData: R({
                variant: t2,
                id: null == o2 ? void 0 : o2.id,
                uuid: null == o2 ? void 0 : o2.uuid,
                from: g2,
                utmLink: v2
              }),
              queueParams: { index: 0 },
              loadContextMeta: true
            },
            s.V_r.TRAILER
          ).then(() => {
            C2(true);
          }), u2(false));
        }, [
          g2,
          null == o2 ? void 0 : o2.id,
          null == o2 ? void 0 : o2.uuid,
          _2.isOpened,
          x2,
          y2,
          u2,
          d2,
          h2,
          c2.status,
          a2.objectId,
          t2,
          v2,
          S2
        ]), (0, N.useEffect)(() => {
          b2 && (S2 ? (y2(a2.objectId), C2(false)) : i2(true));
        }, [b2, S2, y2, a2.objectId, i2]);
        let T2 = (0, N.useCallback)(
          (e3) => ({
            contextData: R({
              variant: t2,
              id: null == o2 ? void 0 : o2.id,
              uuid: null == o2 ? void 0 : o2.uuid,
              from: g2,
              utmLink: v2
            }),
            queueParams: { index: e3 },
            loadContextMeta: true
          }),
          [g2, null == o2 ? void 0 : o2.id, null == o2 ? void 0 : o2.uuid, t2, v2]
        ), P2 = (0, N.useMemo)(
          () => I2 ? ((e3, t3) => {
            let a3 = t3 === p.ALBUM ? s.Xjt.ALBUM : s.Xjt.PLAYLIST;
            return Array.from(
              { length: t3 === p.TRACK ? 1 : 5 },
              (t4, i3) => (0, A.jsx)(
                "div",
                {
                  className: eo().trackContainer,
                  children: (0, A.jsx)(M.DS, {
                    isActive: e3,
                    className: (0, L.$)(eo().trackShimmer, { [eo().albumShimmer]: a3 === s.Xjt.ALBUM }),
                    variant: a3
                  })
                },
                i3
              )
            );
          })(n2, t2) : null == l2 ? void 0 : l2.map(
            (e3, a3) => (0, A.jsx)(
              s.FoH,
              {
                blockType: k.ky.SmartPreview,
                blockId: e3.id,
                blockPosX: 1,
                blockPosY: 1,
                children: (0, A.jsx)(s.Bki, {
                  objectType: k.ky.SmartPreview,
                  objectId: e3.id,
                  objectPosX: 1,
                  objectPosY: a3 + 1,
                  objectsCount: l2.length,
                  children: (0, A.jsx)(er, {
                    variant: t2,
                    track: e3,
                    playContextParams: T2(a3),
                    viewUuid: f2.current
                  })
                })
              },
              e3.id
            )
          ),
          [T2, n2, I2, l2, t2]
        );
        return r2 ? m2 ? (0, A.jsx)(V, {}) : (0, A.jsx)(z, {}) : (0, A.jsxs)("div", {
          className: eo().root,
          children: [
            (0, A.jsx)(ea, { isShimmerVisible: I2, isShimmerActive: n2, variant: t2, className: eo().header }),
            P2,
            (0, A.jsx)(H, { isShimmerVisible: I2, isShimmerActive: n2, variant: t2, className: eo().footer })
          ]
        });
      });
      var ec = a(31182), ed = a.n(ec);
      let eu = (0, C.PA)(() => {
        let {
          settings: { isMobile: e2 },
          trailer: t2,
          sonataState: a2,
          fullscreenPlayer: i2
        } = (0, s.Pjs)(), n2 = (0, s.eGp)(), { contentRef: r2 } = (0, s.gKY)(), { formatMessage: l2 } = (0, f.A)(), c2 = j();
        (() => {
          let { trailer: e3 } = (0, s.Pjs)(), t3 = (0, s.eGp)(), a3 = (0, s.zwV)(), i3 = (0, u.KX)(e3.state.entityMeta), n3 = (0, u.mW)(e3.state.entityMeta);
          (0, N.useEffect)(() => {
            e3.modal.isOpened ? (null == a3 || a3.disable(s.Mo.MAIN), null == a3 || a3.enable(s.Mo.MAIN, s.lbr.TOGGLE_MUTE), null == a3 || a3.enable(s.Mo.MAIN, s.lbr.INCREASE_VOLUME), null == a3 || a3.enable(s.Mo.MAIN, s.lbr.DECREASE_VOLUME), null == a3 || a3.enable(s.Mo.MAIN, s.lbr.TOGGLE_FULLSCREEN_PLAYER), null == a3 || a3.enable(s.Mo.TRAILER)) : (null == a3 || a3.disable(s.Mo.TRAILER), null == a3 || a3.enable(s.Mo.MAIN));
          }, [a3, e3.modal.isOpened]), (0, N.useEffect)(
            () => (null == a3 || a3.addShortcutsListener(s.Mo.TRAILER, s.lbr.TOGGLE_PLAY, () => {
              null == t3 || t3.togglePause(s.V_r.TRAILER);
            }), null == a3 || a3.addShortcutsListener(s.Mo.TRAILER, s.lbr.LIKE, i3), null == a3 || a3.addShortcutsListener(s.Mo.TRAILER, s.lbr.DISLIKE, n3), null == a3 || a3.addShortcutsListener(s.Mo.TRAILER, s.lbr.MOVE_FORWARD, async () => {
              var e4;
              (null == t3 || null == (e4 = t3.getState(s.V_r.TRAILER).currentContext.value) ? void 0 : e4.availableActions.moveForward.value) && await (null == t3 ? void 0 : t3.moveForward(s.V_r.TRAILER));
            }), null == a3 || a3.addShortcutsListener(s.Mo.TRAILER, s.lbr.MOVE_BACKWARD, async () => {
              var e4;
              (null == t3 || null == (e4 = t3.getState(s.V_r.TRAILER).currentContext.value) ? void 0 : e4.availableActions.moveBackward.value) && await (null == t3 ? void 0 : t3.moveBackward(s.V_r.TRAILER));
            }), null == a3 || a3.addShortcutsListener(s.Mo.TRAILER, s.lbr.SLIDE_FORWARD, async () => {
              (null == t3 ? void 0 : t3.getState(s.V_r.TRAILER).playerState.progress.value.duration) && await (null == t3 ? void 0 : t3.slideForward(1, s.V_r.TRAILER));
            }), null == a3 || a3.addShortcutsListener(s.Mo.TRAILER, s.lbr.SLIDE_BACKWARD, async () => {
              (null == t3 ? void 0 : t3.getState(s.V_r.TRAILER).playerState.progress.value.duration) && await (null == t3 ? void 0 : t3.slideBackward(1, s.V_r.TRAILER));
            }), () => {
              null == a3 || a3.removeShortcutsListener(s.Mo.TRAILER, s.lbr.TOGGLE_PLAY), null == a3 || a3.removeShortcutsListener(s.Mo.TRAILER, s.lbr.LIKE), null == a3 || a3.removeShortcutsListener(s.Mo.TRAILER, s.lbr.DISLIKE), null == a3 || a3.removeShortcutsListener(s.Mo.TRAILER, s.lbr.MOVE_FORWARD), null == a3 || a3.removeShortcutsListener(s.Mo.TRAILER, s.lbr.MOVE_BACKWARD), null == a3 || a3.removeShortcutsListener(s.Mo.TRAILER, s.lbr.SLIDE_FORWARD), null == a3 || a3.removeShortcutsListener(s.Mo.TRAILER, s.lbr.SLIDE_BACKWARD);
            }),
            [n3, i3, a3, t3]
          );
        })(), (0, N.useEffect)(() => {
          let e3 = null == n2 ? void 0 : n2.getState(s.V_r.TRAILER).queueState.currentEntity.onChange((e4) => {
            var a4;
            let i3 = null == e4 ? void 0 : e4.context.data.type, n3 = null == e4 ? void 0 : e4.context.data.meta.id;
            t2.state.setEntityMeta(null != (a4 = null == e4 ? void 0 : e4.entity) ? a4 : null), i3 && t2.state.setContextType(i3), n3 && t2.state.setContextId(n3);
          }), a3 = null == n2 ? void 0 : n2.getState(s.V_r.TRAILER).playerState.status.onChange((e4) => {
            e4 && t2.state.setStatus(e4);
          });
          return () => {
            null == e3 || e3(), null == a3 || a3();
          };
        }, [n2, t2.state]);
        let d2 = (0, N.useCallback)(() => {
          null == n2 || n2.stop(s.V_r.TRAILER).finally(() => {
            t2.sonataStatusBeforeTrailerStart !== o.MT.PLAYING || t2.isManuallyPaused || null == n2 || n2.resume(), t2.setAnimationState(true), t2.resetUtmLink(), t2.modal.close(), c2(t2.objectId);
          });
        }, [c2, n2, t2]), m2 = (0, N.useCallback)(
          (e3) => {
            t2.modal.onOpenChange(e3), e3 || d2();
          },
          [d2, t2.modal]
        );
        return (0, N.useEffect)(() => {
          t2.modal.isOpened && t2.isResolved && a2.status === o.MT.PLAYING && d2();
        }, [d2, a2.status, t2, t2.modal.isOpened]), (0, N.useEffect)(() => {
          t2.modal.isOpened && t2.isResolved && t2.setAnimationState(false);
        }, [t2]), (0, N.useEffect)(() => {
          i2.modal.isOpened && t2.modal.isOpened && d2();
        }, [i2.modal.isOpened, d2, t2.modal.isOpened]), (0, A.jsxs)(P.a, {
          size: "fitContent",
          placement: e2 ? "default" : "right",
          open: t2.modal.isOpened,
          onOpenChange: m2,
          onClose: d2,
          className: ed().root,
          contentClassName: ed().modalContent,
          portalNode: e2 ? null : r2,
          showHeader: false,
          withOverlay: e2,
          closeOnOutsidePress: e2,
          containerProps: (0, I.Am)(I.e8.trailer.TRAILER_MODAL),
          withAnimation: t2.withAnimation,
          isMobile: e2,
          lockScroll: e2,
          overlayColor: "full",
          enableSwipe: true,
          children: [
            !e2 && (0, A.jsx)("div", {
              className: ed().header,
              children: (0, A.jsx)(S.$, {
                radius: "round",
                color: "secondary",
                size: "xxs",
                icon: (0, A.jsx)(T.Icon, { variant: "close", size: "xxs" }),
                onClick: d2,
                "aria-label": l2({ id: "trailer.close" }),
                ...(0, I.Am)(I.e8.trailer.TRAILER_CLOSE_BUTTON)
              })
            }),
            t2.variant && (0, A.jsx)(es, { variant: t2.variant })
          ]
        });
      });
    },
    95744: (e) => {
      e.exports = { root: "SyncLyricsLine_root__r62BN" };
    },
    96020: (e) => {
      e.exports = {
        root: "VideoAd_root__e7gla",
        root_hidden: "VideoAd_root_hidden__78CPl",
        videoBlock: "VideoAd_videoBlock__bqNRq",
        video: "VideoAd_video__j1f_y",
        content: "VideoAd_content__QroDp",
        close: "VideoAd_close__sMGlV",
        notifyClose: "VideoAd_notifyClose__w82mE",
        cover: "VideoAd_cover__kQwxh",
        important: "VideoAd_important__VZkA_",
        icon: "VideoAd_icon__o_Hzn",
        text: "VideoAd_text__rjKqZ"
      };
    },
    98845: (e, t, a) => {
      "use strict";
      a.d(t, { p: () => w, H: () => c });
      var i = a(93064), n = a(63695), r = a(74125), l = a(26433), o = a(63930);
      let s = i.gK.model("WizardGenre", { id: i.gK.string, title: i.gK.string }), c = i.gK.model("Wizard", {
        loadingState: i.gK.enumeration(Object.values(r.GuX)),
        modal: l.qt,
        genres: i.gK.array(s),
        artistsByGenres: i.gK.maybe(i.gK.frozen()),
        savedLikedArtists: i.gK.array(i.gK.string),
        likedArtists: i.gK.array(i.gK.string),
        unlikedArtists: i.gK.array(i.gK.string),
        filter: i.gK.maybe(i.gK.string)
      }).views((e2) => ({
        get genreItem() {
          var t2;
          return null == (t2 = e2.artistsByGenres) ? void 0 : t2.get(e2.filter);
        },
        get artistsByGenre() {
          var a2;
          return (null == (a2 = this.genreItem) ? void 0 : a2.artists) || [];
        },
        get selectedArtistsCounter() {
          return e2.likedArtists.length + e2.savedLikedArtists.length - e2.unlikedArtists.length;
        },
        isArtistLiked: (t2) => !e2.unlikedArtists.includes(t2) && (e2.likedArtists.includes(t2) || e2.savedLikedArtists.includes(t2))
      })).actions((e2) => ({
        likeArtist: (t2) => {
          let { likedArtists: a2, unlikedArtists: n2, savedLikedArtists: r2 } = e2, l2 = ((e3) => {
            let { id: t3, likedArtists: a3, unlikedArtists: i2, savedLikedArtists: n3 } = e3, r3 = {};
            if (a3.includes(t3)) return r3.likedArtists = a3.filter((e4) => e4 !== t3), r3;
            let l3 = n3.includes(t3), o2 = i2.includes(t3);
            return (r3.unlikedArtists = i2.filter((e4) => e4 !== t3), l3 && !o2) ? r3.unlikedArtists.push(t3) : r3.likedArtists = [...a3, t3], r3;
          })({ id: t2, likedArtists: a2, unlikedArtists: n2, savedLikedArtists: r2 });
          l2.likedArtists && (e2.likedArtists = (0, i.wg)(l2.likedArtists)), l2.unlikedArtists && (e2.unlikedArtists = (0, i.wg)(l2.unlikedArtists));
        },
        setFilter: (t2) => {
          e2.filter = t2;
        },
        getGenres: (0, i.L3)(function* () {
          let { feedResource: t2, modelActionsLogger: a2 } = (0, i._$)(e2);
          if (e2.loadingState !== r.GuX.PENDING && e2.loadingState !== r.GuX.RESOLVE)
            try {
              var n2;
              e2.loadingState = r.GuX.PENDING;
              let { genres: a3 } = yield t2.getWizardGenres();
              if (e2.genres = (0, i.wg)(a3.map((e3) => ({ id: e3.id, title: e3.title }))), !a3.length)
                throw Error("The wizard's genre array is empty");
              e2.filter = null == (n2 = a3[0]) ? void 0 : n2.id, e2.artistsByGenres = (0, i.wg)(
                ((e3) => {
                  let t3 = /* @__PURE__ */ new Map();
                  return e3.map((e4) => {
                    t3.set(e4.id, { loadingState: r.GuX.IDLE, artists: [], showedArtists: [] });
                  }), o.sH.map(t3);
                })(a3)
              ), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.RESOLVE);
            } catch (t3) {
              a2.error(t3), e2.loadingState !== r.GuX.IDLE && (e2.loadingState = r.GuX.REJECT);
            }
        }),
        getArtists: (0, i.L3)(function* (t2) {
          let { feedResource: a2, modelActionsLogger: l2 } = (0, i._$)(e2);
          if (e2.loadingState !== r.GuX.RESOLVE || !e2.filter) return;
          let o2 = e2.artistsByGenres.get(e2.filter);
          if (o2.loadingState !== r.GuX.PENDING)
            try {
              o2.loadingState = r.GuX.PENDING;
              let { artists: l3 = [], likedArtists: s2 = [] } = yield a2.getWizardArtistsByGenre({
                genre: e2.filter,
                showedArtists: o2.showedArtists,
                likedArtists: e2.likedArtists,
                unlikedArtists: e2.unlikedArtists,
                countOfNewArtists: t2
              }), c2 = l3.map((e3) => (0, n.as)({ artist: e3 })), d2 = l3.map((e3) => e3.id);
              e2.artistsByGenres.set(e2.filter, {
                artists: [...o2.artists, ...c2],
                showedArtists: [...o2.showedArtists, ...d2],
                loadingState: r.GuX.RESOLVE
              }), e2.savedLikedArtists = (0, i.wg)(s2.map((e3) => String(e3))), e2.likedArtists = (0, i.wg)([]), e2.unlikedArtists = (0, i.wg)([]);
            } catch (e3) {
              l2.error(e3), o2.loadingState = r.GuX.REJECT;
            }
        }),
        finish: (0, i.L3)(function* () {
          let { feedResource: t2, modelActionsLogger: a2 } = (0, i._$)(e2);
          if (!e2.filter) return r.FlZ.ERROR;
          try {
            return yield t2.finishWizard({
              genre: e2.filter,
              likedArtists: e2.likedArtists,
              unlikedArtists: e2.unlikedArtists
            }), r.FlZ.OK;
          } catch (e3) {
            return a2.error(e3), r.FlZ.ERROR;
          }
        })
      }));
      var d = a(54486), u = a(50420), m = a(28303), _ = a(61910), p = a(43426), v = a(47713), h = a(31500), g = a(67648), x = a(77881), y = a(32692), b = a(51321), A = a(97800), C = a(80585), N = a(71712), f = a(5956), I = a(6971);
      let S = { src: "/_next/static/media/artist.c49b2bfa.png" };
      var T = a(77846), P = a.n(T);
      let k = (0, m.PA)((e2) => {
        let { className: t2, artist: a2 } = e2, { ref: i2, intersectionPropertyId: n2 } = (0, r.nMI)(), {
          wizard: { likeArtist: l2, isArtistLiked: o2 }
        } = (0, r.Pjs)(), { id: s2, name: c2, coverUri: m2 } = a2, p2 = (0, _.useCallback)(() => {
          l2(s2);
        }, [l2, s2]), v2 = o2(s2), g2 = (0, _.useMemo)(
          () => (0, d.jsx)(I.Paper, {
            className: P().cover,
            radius: "round",
            ...(0, h.Am)(h.e8.wizard.ARTIST_CARD),
            children: (0, d.jsxs)(x.$, {
              radius: "round",
              className: P().coverBlock,
              variant: "default",
              onClick: p2,
              withRipple: false,
              withHover: false,
              "aria-pressed": v2,
              "aria-label": c2,
              ...(0, h.Am)(h.e8.wizard.ARTIST_CARD_BUTTON),
              children: [
                (0, d.jsx)(C.BW, {
                  className: P().image,
                  src: m2 || S.src,
                  fit: "cover",
                  alt: c2,
                  withAvatarReplace: !!m2,
                  "aria-hidden": true
                }),
                (0, d.jsx)("div", {
                  className: (0, u.$)(P().like),
                  children: (0, d.jsx)(f.Icon, { variant: "likedVariant", size: "s", className: P().icon })
                })
              ]
            })
          }),
          [v2, m2, c2, p2]
        );
        return (0, d.jsx)(N.MN, {
          ref: i2,
          className: (0, u.$)(P().root, { [P().root_selected]: v2 }, t2),
          textPosition: "center",
          title: (0, d.jsx)(A.Caption, {
            "aria-hidden": true,
            className: P().name,
            variant: "div",
            type: "entity",
            size: "l",
            weight: "medium",
            lineClamp: 2,
            ...(0, h.Am)(h.e8.wizard.ARTIST_CARD_NAME),
            children: c2
          }),
          "data-intersection-property-id": n2,
          view: g2,
          ...(0, h.Am)(h.Kq.artist.ARTIST_ITEM)
        });
      });
      var E = a(2782), j = a.n(E);
      let L = { [r.u40.Desktop]: { start: 40, end: 40 }, [r.u40.Mobile]: { start: 40, end: 40 } }, w = (0, m.PA)(() => {
        let { formatMessage: e2 } = (0, p.A)(), {
          wizard: t2,
          settings: { isMobile: a2, isWindowsApplication: i2, isLinuxApplication: n2 },
          user: l2
        } = (0, r.Pjs)(), { notify: o2 } = (0, r.lkh)(), s2 = (0, r.zwV)(), [c2, m2] = (0, g.d)(), N2 = (0, r.RpR)(), f2 = (0, b.useTabsState)(0), I2 = (0, _.useMemo)(
          () => (e3) => {
            var a3;
            if (!f2.onTabChange || e3 === f2.value) return;
            f2.onTabChange(e3);
            let i3 = null == (a3 = t2.genres[e3]) ? void 0 : a3.id;
            t2.setFilter(i3), null == c2 || c2.scrollTo({ top: 0 });
          },
          [t2, f2, c2]
        ), S2 = (0, _.useMemo)(() => {
          switch (t2.selectedArtistsCounter) {
            case 0:
              return e2({ id: "wizard.button-tune" });
            case 1:
              return e2({ id: "wizard.button-little-more" });
            case 2:
              return e2({ id: "wizard.button-one-more" });
            default:
              return e2({ id: "wizard.button-done" });
          }
        }, [t2.selectedArtistsCounter, e2]), T2 = (0, _.useMemo)(
          () => (0, d.jsx)(C.wI, {
            className: j().tabCarousel,
            ...f2,
            onTabChange: I2,
            isShimmerVisible: t2.loadingState === r.GuX.PENDING,
            shimmer: (0, d.jsx)(C.zr, {
              isActive: true,
              className: j().tabCarousel,
              shimmerClassName: j().tabShimmer,
              count: a2 ? 2 : 3
            }),
            children: t2.genres.map(
              (e3, t3) => (0, d.jsx)(
                C.oz,
                {
                  className: (0, u.$)(j().filter, { [j().filter_selected]: t3 === f2.value }),
                  titleClassName: j().tabTitle,
                  title: e3.title,
                  value: t3
                },
                t3
              )
            )
          }),
          [t2.genres, f2, I2, t2.loadingState, a2]
        ), P2 = (0, _.useCallback)(() => {
          t2.getArtists(60);
        }, [t2]);
        (0, _.useEffect)(() => {
          t2.filter && P2();
        }, [t2.filter, P2]);
        let E2 = (0, _.useCallback)(async () => {
          await t2.getGenres(), P2();
        }, [t2, P2]);
        (0, _.useEffect)(() => {
          t2.modal.isOpened && E2();
        }, [t2, t2.modal.isOpened, E2]), (0, _.useEffect)(() => {
          t2.loadingState === r.GuX.REJECT && (t2.modal.close(), o2((0, d.jsx)(C.hT, { error: e2({ id: "error-messages.error-load-wizard" }) }), {
            containerId: r.uQT.ERROR
          }));
        }, [t2, t2.getGenres, t2.loadingState, e2, o2]);
        let w2 = (0, _.useMemo)(
          () => (0, d.jsx)(A.Heading, {
            className: j().title,
            weight: "bold",
            variant: "h1",
            size: "l",
            ...(0, h.Am)(h.e8.wizard.WIZARD_MODAL_TITLE),
            children: (0, d.jsx)(v.A, { id: "wizard.modal-title" })
          }),
          []
        ), M = (0, _.useCallback)(async () => {
          t2.selectedArtistsCounter < 3 ? t2.getArtists() : await t2.finish() === r.FlZ.OK && (await l2.getSettings(), N2()), t2.modal.close();
        }, [N2, l2, t2]);
        return (0, _.useEffect)(
          () => (null == s2 || s2.addShortcutsListener(r.Mo.MAIN, r.lbr.CLOSE, () => {
            t2.modal.isOpened && M();
          }), () => {
            null == s2 || s2.removeShortcutsListener(r.Mo.MAIN, r.lbr.CLOSE);
          }),
          [M, t2.modal.isOpened, s2]
        ), (0, d.jsxs)(y.a, {
          className: (0, u.$)(j().root, { [j().root_withCustomControls]: i2 || n2 }),
          headerClassName: j().modalHeader,
          contentClassName: j().modalContent,
          open: t2.modal.isOpened,
          onOpenChange: t2.modal.onOpenChange,
          onClose: M,
          size: "fullscreen",
          placement: "center",
          labelClose: e2({ id: "interface-actions.close" }),
          closeButtonProps: (0, h.Am)(h.e8.wizard.WIZARD_MODAL_CLOSE_BUTTON),
          ...(0, h.Am)(h.e8.wizard.WIZARD_MODAL),
          header: a2 && w2,
          escapeKey: false,
          children: [
            (0, d.jsxs)("div", {
              className: j().wrapper,
              children: [
                !a2 && w2,
                (0, d.jsx)(A.Caption, {
                  className: j().text,
                  variant: "div",
                  size: "l",
                  weight: "normal",
                  ...(0, h.Am)(h.e8.wizard.WIZARD_MODAL_TEXT),
                  children: (0, d.jsx)(v.A, { id: "wizard.modal-text" })
                }),
                (0, d.jsx)(x.$, {
                  className: j().button,
                  size: a2 ? "m" : "l",
                  iconPosition: "right",
                  radius: "xxxl",
                  color: "primary",
                  onClick: M,
                  disabled: t2.selectedArtistsCounter < 3,
                  ...(0, h.Am)(h.e8.wizard.WIZARD_MODAL_BUTTON),
                  children: (0, d.jsx)(A.Caption, { variant: "div", size: "m", weight: "medium", children: S2 })
                })
              ]
            }),
            (0, d.jsxs)("div", {
              className: j().mainContainer,
              children: [
                (0, d.jsx)(C.FY, { className: j().carousel, carouselElement: T2, scrollPadding: L }),
                (0, d.jsx)(C.$$, {
                  withFooter: false,
                  className: (0, u.$)(j().scrollContainer, j().important),
                  itemContentCallback: (a3) => {
                    let i3 = t2.artistsByGenre[a3];
                    if (!i3) {
                      let t3 = e2(
                        { id: "loading-messages.entity-is-loading" },
                        { entityName: e2({ id: "entity-names.artist" }) }
                      );
                      return (0, d.jsx)(C.Vt, { "aria-label": t3, round: true, centered: true });
                    }
                    return (0, d.jsx)(k, { artist: i3 }, i3.id);
                  },
                  data: t2.artistsByGenre,
                  endReached: P2,
                  listClassName: j().content,
                  itemClassName: j().item,
                  pageSize: 60,
                  handleRef: m2,
                  ...(0, h.Am)(h.e8.wizard.WIZARD_MODAL_ARTISTS_GRID)
                })
              ]
            })
          ]
        });
      });
    },
    99092: (e) => {
      e.exports = {
        root: "SideAdvertBanner_root__hT1jJ",
        root_hidden: "SideAdvertBanner_root_hidden__Yg__R",
        contentWrapper: "SideAdvertBanner_contentWrapper__5255E",
        content: "SideAdvertBanner_content__nDGWG",
        disableAdsButton: "SideAdvertBanner_disableAdsButton__is8g1"
      };
    },
    99835: (e) => {
      e.exports = {
        root: "AdContainer_root__ti4rk",
        container: "AdContainer_container__DLRij",
        title: "AdContainer_title__AsPky",
        subtitle: "AdContainer_subtitle__LIOif",
        info: "AdContainer_info__EKKWS",
        favicon: "AdContainer_favicon__ry_3I",
        buttonContainer: "AdContainer_buttonContainer__SvDt3",
        button: "AdContainer_button__nQcMg",
        linkButton: "AdContainer_linkButton__rabLN"
      };
    }
  }
]);
