(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4826],
  {
    11405: (t, e, r) => {
      "use strict";
      var o;
      r.d(e, { g: () => o }), (function(t2) {
        t2.RATING = "rating", t2.YEAR = "year";
      })(o || (o = {}));
    },
    19633: (t, e, r) => {
      "use strict";
      r.d(e, { HorizontalArtistCard: () => b });
      var o = r(54486), i = r(50420), a = r(28303), l = r(61910), n = r(43426), s = r(43350), c = r(31500), u = r(63585), d = r(8817), _ = r(73633), m = r(97800), p = r(63695), v = r(74125), f = r(80585), A = r(5956), g = r(96266), x = r.n(g);
      let h = (0, a.PA)((t2) => {
        var e2;
        let { className: r2, artist: a2, likeIconSize: n2 = "xxs" } = t2, { user: c2, trailer: u2 } = (0, v.Pjs)(), _2 = (0, v.PT7)(), { sendLikeSearchFeedback: m2 } = (0, v.zEv)(), g2 = (0, p.KX)(a2), [h2, b2] = (0, l.useState)(false), C = (0, d.c)(async () => {
          h2 || a2.isLiked || (b2(true), null == m2 || m2()), await g2();
        }), T = (0, v.Ftl)(), y = (0, d.c)((t3) => {
          if (t3.stopPropagation(), _2()) return void t3.preventDefault();
          u2.openArtistTrailer(a2.id), T(s.ky.Artist, a2.id);
        });
        return (0, o.jsxs)("div", {
          className: (0, i.$)(x().root, x().controls, r2, { [x().controls_disabled]: !a2.isAvailable }),
          children: [
            a2.isAvailable && (0, o.jsxs)(o.Fragment, {
              children: [
                (0, o.jsx)(f.aQ, {
                  fallback: (0, o.jsx)(f.cy, {
                    size: "xs",
                    iconSize: n2,
                    className: (0, i.$)(x().item, x().likeIcon),
                    isLiked: a2.isLiked,
                    onClick: C,
                    disabled: !c2.isAuthorized
                  })
                }),
                (null == (e2 = a2.trailer) ? void 0 : e2.isAvailable) && (0, o.jsx)(f.aQ, {
                  fallback: (0, o.jsx)(f.kJ, {
                    className: (0, i.$)(x().item, x().trailerIcon),
                    iconSize: "xs",
                    variant: "text",
                    onClick: y,
                    withRipple: false
                  })
                })
              ]
            }),
            (0, o.jsx)("div", {
              className: (0, i.$)(x().item, x().item_buttonArrow),
              children: (0, o.jsx)(A.Icon, { className: f.$f.buttonArrow, variant: "arrowRight", size: "xs" })
            })
          ]
        });
      }), b = (0, a.PA)((t2) => {
        let {
          className: e2,
          artist: r2,
          pageId: a2,
          description: A2,
          coverClassName: g2,
          playButtonIconSize: x2,
          likeIconSize: b2
        } = t2, { formatMessage: C } = (0, n.A)(), { ref: T, intersectionPropertyId: y } = (0, v.nMI)(), { from: k } = (0, v.fyy)({ pageId: a2 }), [j, M] = (0, l.useState)(false), N = (0, v.ZpR)(r2.url), I = (0, v.brA)(), S = (0, v.PT7)(), { sendNavigateSearchFeedback: w, sendPlaySearchFeedback: E } = (0, v.zEv)(), L = (0, v.NKK)(), {
          isPlaying: B,
          isCurrent: R,
          togglePlay: O
        } = (0, v.Dx4)({
          playContextParams: {
            contextData: { type: u.K.Artist, meta: { id: Number(r2.id) }, from: k },
            loadContextMeta: true
          }
        }), P = (0, p.SA)({ artist: r2, callback: N }), K = (0, p.SA)({ artist: r2, callback: O }), D = (0, d.c)((t3) => {
          null == w || w(), L({ to: s.QT.ArtistScreen }), P(t3);
        }), F = (0, d.c)(() => {
          S() || (j || B || (M(true), null == E || E()), K(), I(!B));
        }), z = (0, d.c)((t3) => {
          (0, _.P)(t3, f.$f.ripple), D(t3);
        }), U = (0, d.c)((t3) => {
          t3.stopPropagation(), D(t3);
        }), H = (0, l.useCallback)(
          (t3) => (0, o.jsx)(f.q1, {
            isAvailable: r2.isAvailable,
            isDisliked: false,
            coverUri: r2.coverUri,
            title: r2.name,
            className: (0, i.$)(f.$f.playButtonCell, g2),
            radius: "round",
            alt: C({ id: "entity-names.artist-name" }, { artistName: r2.name }),
            ...t3
          }),
          [r2, g2, C]
        ), W = null == H ? void 0 : H({ onPlayButtonClick: F, isPlaying: B, isCurrent: R, playButtonIconSize: x2 }), q = (0, l.useMemo)(
          () => r2.url && r2.isAvailable ? (0, o.jsx)(f.N_, {
            className: (0, i.$)(f.$f.text, f.$f.titleLink),
            href: r2.url,
            onClick: U,
            ...(0, c.Am)(c.Kq.artist.SEARCH_ARTIST_CARD_TITLE_LINK),
            children: r2.name
          }) : (0, o.jsx)(m.Caption, {
            className: (0, i.$)(f.$f.text, f.$f.titleText),
            size: "m",
            variant: "div",
            type: "text",
            children: r2.name
          }),
          [r2.isAvailable, r2.name, r2.url, U]
        );
        return (0, o.jsxs)(f.Cj, {
          ref: T,
          "data-intersection-property-id": y,
          className: (0, i.$)(f.$f.root, { [f.$f.root_disabled]: !r2.isAvailable }, e2),
          "aria-label": r2.name,
          onClick: z,
          ...(0, c.Am)(c.Kq.artist.HORIZONTAL_ARTIST_CARD),
          children: [
            W,
            (0, o.jsx)(f.ro, {
              isDisabled: !r2.isAvailable,
              isDisliked: false,
              likesCount: r2.actualLikesCount,
              isLiked: r2.isLiked,
              title: q,
              description: A2
            }),
            (0, o.jsx)(h, { className: f.$f.controlsBar, artist: r2, likeIconSize: b2 })
          ]
        });
      });
    },
    21390: (t, e, r) => {
      "use strict";
      r.d(e, { L: () => u });
      var o, i = r(94377), a = r(61910), l = {
        6699: (t2, e2, r2) => {
          Object.defineProperty(e2, "__esModule", { value: true }), e2.useDebouncedToggle = void 0;
          let o2 = r2(352), i2 = r2(810);
          e2.useDebouncedToggle = (t3) => {
            let { delay: e3, initialState: r3, throttleTimeout: a2 } = t3, l2 = (0, i2.useRef)(null), [n2, s2] = (0, i2.useState)(!!r3), c2 = (0, i2.useMemo)(
              () => (0, o2.throttle)(() => {
                s2(!r3), l2.current && window.clearTimeout(l2.current), l2.current = window.setTimeout(() => {
                  s2(!!r3);
                }, e3);
              }, a2),
              [e3, r3, a2]
            ), u2 = (0, i2.useCallback)(() => {
              s2(!!r3), l2.current && window.clearTimeout(l2.current);
            }, [r3]);
            return (0, i2.useEffect)(
              () => () => {
                l2.current && window.clearTimeout(l2.current);
              },
              []
            ), { state: n2, handleDebouncedToggle: c2, reset: u2 };
          };
        },
        361: (t2, e2) => {
          Object.defineProperty(e2, "__esModule", { value: true }), e2.getElementFromRefOrElement = void 0, e2.getElementFromRefOrElement = (t3) => {
            if (void 0 !== t3) {
              if (null === t3 || t3 instanceof HTMLElement) return t3;
              if (null === t3.current || t3.current instanceof HTMLElement) return t3.current;
            }
          };
        },
        352: (t2) => {
          t2.exports = i;
        },
        810: (t2) => {
          t2.exports = o || (o = r.t(a, 2));
        }
      }, n = {};
      function s(t2) {
        var e2 = n[t2];
        if (void 0 !== e2) return e2.exports;
        var r2 = n[t2] = { exports: {} };
        return l[t2](r2, r2.exports, s), r2.exports;
      }
      var c = {};
      (() => {
        Object.defineProperty(c, "__esModule", { value: true }), c.useScroll = void 0;
        let t2 = s(810), e2 = s(361), r2 = s(6699);
        c.useScroll = (o2) => {
          let { onScroll: i2, listenIsScrolling: a2, elementRef: l2 } = o2, { state: n2, handleDebouncedToggle: s2 } = (0, r2.useDebouncedToggle)({ delay: 1e3, throttleTimeout: 100 }), c2 = (0, t2.useCallback)(() => {
            a2 && s2(), null == i2 || i2();
          }, [a2, s2, i2]);
          return (0, t2.useEffect)(() => {
            let t3 = (0, e2.getElementFromRefOrElement)(l2);
            if (null === t3) return;
            let r3 = null != t3 ? t3 : window, o3 = { capture: true, passive: true };
            return r3.addEventListener("scroll", c2, o3), () => r3.removeEventListener("scroll", c2, o3);
          }, [l2, c2]), n2;
        };
      })(), c.__esModule;
      var u = c.useScroll;
    },
    23504: (t, e, r) => {
      "use strict";
      r.d(e, { ArtistCard: () => T });
      var o = r(54486), i = r(50420), a = r(28303), l = r(61910), n = r(43426), s = r(43350), c = r(31500), u = r(63585), d = r(8817), _ = r(27510), m = r(71712), p = r(5956), v = r(6971), f = r(97800), A = r(63695), g = r(74125), x = r(80585), h = r(99182), b = r(34846), C = r.n(b);
      let T = (0, a.PA)((t2) => {
        let {
          artist: e2,
          className: r2,
          children: a2,
          contentLinesCount: b2,
          topTitleElement: T2,
          bottomTitleElement: y
        } = t2, { ref: k, intersectionPropertyId: j } = (0, g.nMI)(), { trailer: M, user: N } = (0, g.Pjs)(), { from: I, utmLink: S } = (0, g.fyy)({ contextId: e2.id, contextType: u.K.Artist }), { formatMessage: w } = (0, n.A)(), [E, L] = (0, l.useState)(false), [B, R] = (0, l.useState)(false), [O, P] = (0, l.useState)(false), { sendLikeSearchFeedback: K, sendNavigateSearchFeedback: D, sendPlaySearchFeedback: F } = (0, g.zEv)(), z = (0, g.NKK)(), U = (0, g.brA)(), H = (0, A.KX)(e2), W = (0, A.A7)(e2), { id: q, name: X, coverUri: G, isLiked: Y } = e2, $ = (0, g.ZpR)(e2.url), [J, Q] = (0, l.useState)(false), Z = (0, g.Ftl)(), V = (0, g.PT7)(), tt = (0, d.c)((t3) => {
          if (t3.stopPropagation(), V()) return void t3.preventDefault();
          M.openArtistTrailer(e2.id), Z(s.ky.Artist, e2.id);
        }), te = (0, l.useMemo)(() => {
          let t3 = w({ id: "entity-names.artist-name" }, { artistName: X }), e3 = Y ? w({ id: "entity-names.has-your-like" }) : "";
          return "".concat(t3, " ").concat(e3);
        }, [X, Y, w]), { isPlaying: tr, togglePlay: to } = (0, g.Dx4)({
          playContextParams: {
            contextData: { type: u.K.Artist, meta: { id: Number(q) }, from: I, utmLink: S },
            loadContextMeta: true
          }
        }), ti = (0, A.SA)({ artist: e2, callback: $ }), ta = (0, A.SA)({ artist: e2, callback: to }), tl = (0, d.c)((t3) => {
          null == D || D(), z({ to: s.QT.ArtistScreen }), ti(t3);
        }), tn = (0, d.c)(() => {
          V() || (E || tr || (L(true), null == F || F()), ta(), U(!tr));
        }), ts = (0, d.c)(() => {
          B || Y || (R(true), null == K || K()), H();
        }), tc = (0, d.c)((t3) => {
          t3.preventDefault(), t3.stopPropagation();
        }), tu = (0, d.c)((t3) => {
          P(t3), Q(t3);
        }), td = (0, l.useMemo)(
          () => (0, o.jsx)(
            h.ArtistContextMenu,
            {
              artist: e2,
              onOpenChange: tu,
              open: O,
              onClick: tc,
              className: (0, i.$)(C().menuButton, C().control),
              size: "s",
              icon: (0, o.jsx)(p.Icon, { size: "xxs", variant: "more" }),
              ...(0, c.Am)(c.Kq.artist.ARTIST_CONTEXT_MENU_BUTTON)
            },
            e2.getKey("ArtistContextMenu")
          ),
          [e2, tc, tu, O]
        ), t_ = (0, l.useMemo)(() => {
          var t3;
          if (null == e2 || null == (t3 = e2.trailer) ? void 0 : t3.isAvailable)
            return (0, o.jsx)(
              x.nE,
              {
                children: (0, o.jsx)(x.kJ, {
                  className: (0, i.$)(C().trailerButton, C().control),
                  radius: "round",
                  size: "s",
                  iconSize: "xxs",
                  onClick: tt
                })
              },
              e2.getKey("ArtistCardTrailerTooltip")
            );
        }, [e2, tt]), tm = (0, l.useMemo)(
          () => (0, o.jsx)(
            x.O0,
            { onClick: W, isPinned: e2.isPinned, className: (0, i.$)(C().pinButton, C().control), withRipple: false },
            e2.getKey("PinButton")
          ),
          [e2, W]
        ), tp = (0, _.L)(() => {
          if (e2.isAvailable)
            return (0, o.jsx)(
              m.hg,
              {
                isVisible: O || J,
                className: C().controls,
                radius: "round",
                playControl: (0, o.jsx)(
                  x.DM,
                  {
                    buttonVariant: "default",
                    withHover: false,
                    className: (0, i.$)(C().playButton, C().control),
                    iconSize: "xl",
                    variant: "filled",
                    onClick: tn,
                    isPlaying: tr,
                    disabled: !e2.isAvailableForPlaying
                  },
                  e2.getKey("PlayButton")
                ),
                likeControl: (0, o.jsx)(
                  x.cy,
                  {
                    className: (0, i.$)(C().likeButton, C().control),
                    isLiked: Y,
                    onClick: ts,
                    variant: "default",
                    size: "s",
                    iconSize: "xxs",
                    disabled: !N.isAuthorized
                  },
                  e2.getKey("LikeButton")
                ),
                menuControl: td,
                pinControl: tm,
                trailerControl: t_
              },
              e2.getKey("ArtistCardControls")
            );
        }), tv = (0, l.useMemo)(
          () => (0, o.jsx)(v.Paper, {
            className: C().cover,
            radius: "round",
            withShadow: true,
            ...(0, c.Am)(c.Kq.artist.ARTIST_CARD),
            children: (0, o.jsxs)("div", {
              className: C().coverBlock,
              onClick: tl,
              children: [
                (0, o.jsx)(x.BW, {
                  className: C().image,
                  src: G,
                  size: 200,
                  fit: "cover",
                  alt: te,
                  withAvatarReplace: true,
                  isAvailable: e2.isAvailable,
                  "aria-hidden": true
                }),
                tp
              ]
            })
          }),
          [tl, G, te, e2.isAvailable, tp]
        );
        return (0, o.jsx)(m.MN, {
          ref: k,
          className: (0, i.$)(C().root, r2),
          textPosition: "center",
          "aria-label": te,
          title: (0, o.jsxs)(o.Fragment, {
            children: [
              T2,
              (0, o.jsx)(f.Caption, {
                variant: "div",
                type: "entity",
                size: "s",
                weight: "medium",
                lineClamp: 2,
                children: (0, o.jsx)(x.N_, {
                  className: C().titleLink,
                  href: e2.url,
                  "aria-label": te,
                  onClick: tl,
                  ...(0, c.Am)(c.Kq.artist.ARTIST_TITLE),
                  children: X
                })
              }),
              y
            ]
          }),
          srTitle: (0, o.jsx)(x.N_, { href: e2.url, onClick: tl, children: te }),
          "data-intersection-property-id": j,
          contentLinesCount: b2,
          view: tv,
          ...(0, c.Am)(c.Kq.artist.ARTIST_ITEM),
          children: a2
        });
      });
    },
    26923: (t, e, r) => {
      "use strict";
      r.d(e, { ArtistAboutModal: () => L });
      var o = r(54486), i = r(28303), a = r(61910), l = r(43426), n = r(31500), s = r(27510), c = r(77881), u = r(5956), d = r(32692), _ = r(74125), m = r(80585), p = r(69258), v = r.n(p), f = r(62443), A = r(39694), g = r(97800), x = r(63695), h = r(47713), b = r(8817), C = r(58360), T = r(54736), y = r.n(T);
      let k = (0, i.PA)((t2) => {
        let { covers: e2 } = t2, { formatMessage: r2 } = (0, l.A)(), {
          modals: { imageSliderModal: i2, artistAboutModal: a2 }
        } = (0, _.Pjs)(), s2 = e2.slice(0, 1), u2 = e2.length - 2 + 1, d2 = (0, b.c)((t3) => () => {
          a2.close(), i2.openImages({ images: e2, initialSlideIndex: t3 });
        });
        return (0, o.jsxs)("div", {
          className: y().root,
          ...(0, n.Am)(n.e8.content.ARTIST_ABOUT_IMAGE_SLIDER),
          children: [
            s2.map(
              (t3, e3) => (0, o.jsx)(
                c.$,
                {
                  className: y().button,
                  onClick: d2(e3),
                  "aria-label": r2({ id: "slider.view-artist-covers" }),
                  ...(0, n.Am)(n.e8.content.ARTIST_ABOUT_IMAGE_SLIDER_BUTTON),
                  children: (0, o.jsx)(C.Image, {
                    fit: "contain",
                    className: y().image,
                    src: t3,
                    size: 400,
                    withAvatarReplace: true
                  })
                },
                e3
              )
            ),
            e2[1] && (0, o.jsxs)(c.$, {
              className: y().button,
              onClick: d2(1),
              "aria-label": r2({ id: "slider.view-artist-covers" }),
              ...(0, n.Am)(n.e8.content.ARTIST_ABOUT_IMAGE_SLIDER_BUTTON),
              children: [
                (0, o.jsx)(C.Image, {
                  fit: "contain",
                  className: y().image,
                  src: e2[1],
                  size: 400,
                  withAvatarReplace: true
                }),
                (0, o.jsx)("div", {
                  className: y().moreCovers,
                  children: (0, o.jsx)(g.Caption, {
                    variant: "span",
                    className: y().moreCoversText,
                    size: "m",
                    weight: "medium",
                    children: (0, o.jsx)(h.A, { id: "slider.images-left-count", values: { imagesLeft: u2 } })
                  })
                })
              ]
            })
          ]
        });
      });
      var j = r(44844), M = r.n(j);
      let N = (0, i.PA)(() => {
        var t2, e2, r2, i2, a2, s2, c2;
        let { formatMessage: u2 } = (0, l.A)(), {
          modals: { artistAboutModal: d2 }
        } = (0, _.Pjs)(), { state: m2, setState: p2 } = (0, f.e)(false), v2 = (0, x.eI)(d2.artistType);
        return (0, o.jsxs)("div", {
          className: M().root,
          children: [
            d2.isResolved && (0, o.jsxs)("header", {
              className: M().header,
              ...(0, n.Am)(n.e8.content.ARTIST_ABOUT_HEADER),
              children: [
                (0, o.jsx)(g.Caption, {
                  variant: "div",
                  type: "text",
                  size: "m",
                  weight: "medium",
                  className: M().subtitle,
                  ...(0, n.Am)(n.e8.content.ARTIST_ABOUT_HEADER_SUBTITLE),
                  children: v2
                }),
                (0, o.jsx)(g.Heading, {
                  size: "xxl",
                  variant: "div",
                  className: M().title,
                  ...(0, n.Am)(n.e8.content.ARTIST_ABOUT_HEADER_TITLE),
                  children: null == (t2 = d2.artist) ? void 0 : t2.name
                })
              ]
            }),
            d2.description && (0, o.jsx)(A.K, {
              moreText: u2({ id: "track-modal.read-more" }),
              className: M().descriptionWrapper,
              buttonClassName: M().readMoreButton,
              buttonProps: (0, n.Am)(n.e8.content.ARTIST_ABOUT_DESCRIPTION_READ_MORE_BUTTON),
              open: m2,
              onOpenChange: p2,
              lineClamp: 7,
              withFade: true,
              ...(0, n.Am)(n.e8.content.ARTIST_ABOUT_DESCRIPTION),
              children: (0, o.jsx)(g.Caption, {
                variant: "div",
                className: M().description,
                size: "l",
                weight: "medium",
                ...(0, n.Am)(n.e8.content.ARTIST_ABOUT_DESCRIPTION_TEXT),
                children: d2.description
              })
            }),
            d2.isArtistStatsAvailable && (0, o.jsx)(x.FO, {
              lastMonthListeners: null != (s2 = d2.lastMonthListeners) ? s2 : 0,
              lastMonthListenersDelta: d2.lastMonthListenersDelta
            }),
            d2.isResolved && (0, o.jsx)(x.lW, {
              className: M().bandlinkScanner,
              artistId: null == (e2 = d2.artist) ? void 0 : e2.id,
              artistName: null == (r2 = d2.artist) ? void 0 : r2.name
            }),
            d2.links && (null == (i2 = d2.links) ? void 0 : i2.length) > 0 && (0, o.jsx)(x.KH, {
              links: d2.links,
              artistName: null != (c2 = null == (a2 = d2.artist) ? void 0 : a2.name) ? c2 : ""
            }),
            d2.covers && d2.covers.length > 0 && (0, o.jsx)(k, { covers: d2.covers })
          ]
        });
      });
      var I = r(22674), S = r(72588), w = r.n(S);
      let E = () => (0, o.jsxs)("div", {
        className: w().root,
        children: [
          (0, o.jsx)(I.Shimmer, { className: w().entityName }),
          (0, o.jsx)(I.Shimmer, { className: w().title }),
          (0, o.jsx)(m.q$, { count: 4 })
        ]
      }), L = (0, i.PA)(() => {
        let { formatMessage: t2 } = (0, l.A)(), { notify: e2 } = (0, _.lkh)(), { contentRef: r2 } = (0, _.gKY)(), {
          modals: { artistAboutModal: i2 },
          settings: { isMobile: p2 }
        } = (0, _.Pjs)();
        (0, a.useEffect)(() => {
          i2.isRejected && (e2((0, o.jsx)(m.hT, { error: t2({ id: "artist-errors.error-during-loading-artist-info" }) }), {
            containerId: _.uQT.ERROR
          }), i2.close());
        }, [i2, i2.isRejected, t2, e2]);
        let f2 = (0, s.L)(() => i2.isLoading ? (0, o.jsx)(E, {}) : (0, o.jsx)(N, {}));
        return (0, o.jsxs)(d.a, {
          placement: p2 ? "default" : "right",
          size: p2 ? "fullscreen" : "fitContent",
          open: i2.modal.isOpened,
          onClose: i2.close,
          contentClassName: v().modalContent,
          headerClassName: v().header,
          className: v().root,
          overlayClassName: v().overlay,
          onOpenChange: i2.onOpenChange,
          labelClose: t2({ id: "interface-actions.close" }),
          portalNode: p2 ? null : r2,
          showHeader: false,
          containerProps: (0, n.Am)(n.Xk.artist.ARTIST_ABOUT_MODAL),
          children: [
            (0, o.jsx)(c.$, {
              radius: "round",
              color: "secondary",
              size: "xxs",
              icon: (0, o.jsx)(u.Icon, { variant: "close", size: "xxs" }),
              className: v().closeButton,
              onClick: i2.close,
              "aria-label": t2({ id: "interface-actions.close" }),
              ...(0, n.Am)(n.Xk.artist.ARTIST_ABOUT_MODAL_CLOSE_BUTTON)
            }),
            f2
          ]
        });
      });
    },
    33276: (t, e, r) => {
      "use strict";
      r.d(e, { hO: () => _, jr: () => m, jp: () => p, QZ: () => i }), r(77607);
      var o = r(61910);
      let i = (t2, e2, r2) => {
        let i2 = null != r2 && r2;
        return {
          topColorStyle: (0, o.useMemo)(() => {
            if (void 0 === e2) return;
            let r3 = i2 ? 93 : 17, o2 = e2 - r3;
            return {
              "--average-color-background": t2,
              transform: "translateY(".concat(e2 >= r3 ? 0 : o2, "px)"),
              opacity: 1
            };
          }, [e2, i2, t2]),
          headerStyle: (0, o.useMemo)(() => ({ "--average-color-background": t2 }), [t2])
        };
      };
      var a = r(54486), l = r(1365), n = r(28303), s = r(21390), c = r(74125), u = r(80585);
      let d = (t2) => {
        let { element: e2, scrollTop: r2, isMobile: o2 } = t2, i2 = 0.6 * e2.clientHeight;
        return r2 + (o2 ? 60 : 76) >= e2.offsetTop + i2;
      }, _ = (0, n.PA)((t2) => {
        let {
          children: e2,
          scrollElement: r2,
          outerTitle: i2 = "",
          headerElement: n2,
          headerThreshold: _2,
          shouldHideHeader: m2
        } = t2, [p2, v] = (0, o.useState)(i2), [f, A] = (0, o.useState)(null), [g, x] = (0, o.useState)(null), [h, b] = (0, o.useState)(null), [C, T] = (0, o.useState)(false), [y, k] = (0, o.useState)(false), [j, M] = (0, o.useState)(false), [N, I] = (0, o.useState)(false), {
          settings: { isMobile: S }
        } = (0, c.Pjs)();
        (0, o.useLayoutEffect)(() => {
          v(i2);
        }, [i2]);
        let w = (0, o.useCallback)(() => {
          let t3 = null != _2 ? _2 : 10, e3 = n2 ? Number(n2.offsetTop) - t3 : t3;
          e3 < 0 && (e3 = 0);
          let o2 = (t4) => {
            M(t4 > e3), m2 && I(t4 > 30), (null == f ? void 0 : f.current) && T(d({ element: null == f ? void 0 : f.current, scrollTop: t4, isMobile: S })), (null == g ? void 0 : g.current) && k(d({ element: null == g ? void 0 : g.current, scrollTop: t4, isMobile: S }));
          };
          S ? o2(window.scrollY) : r2 && o2(r2.scrollTop);
        }, [_2, n2, S, m2, f, g, r2]);
        (0, o.useEffect)(() => {
          S ? 0 === window.scrollY && M(false) : r2 && 0 !== r2.scrollTop || M(false);
        }, [r2, null == r2 ? void 0 : r2.scrollTop, S]);
        let E = (0, o.useMemo)(
          () => S ? { onScroll: (0, l.A)(w, 200) } : { onScroll: (0, l.A)(w, 200), elementRef: r2 },
          [w, r2, S]
        );
        (0, s.L)(E);
        let L = (0, o.useMemo)(
          () => ({
            title: p2,
            setTitle: v,
            titleElement: f,
            scrollElement: S ? null : r2,
            setTitleElement: A,
            childElement: g,
            setChildElement: x,
            child: h,
            setChild: b,
            isScrolledChild: y,
            isScrolledTitle: C,
            isScrolling: j,
            isHeaderHidden: N
          }),
          [p2, C, f, r2, j, S, h, g, y, N]
        );
        return (0, a.jsx)(u.B9.Provider, { value: L, children: e2 });
      }), m = (t2) => {
        let { children: e2, child: r2, className: i2 } = t2, { setChildElement: l2, setChild: n2 } = (0, o.useContext)(u.B9), s2 = (0, o.useRef)(null);
        return (0, o.useEffect)(() => {
          (null == s2 ? void 0 : s2.current) && l2(s2), r2 && n2(r2);
        }, [s2, r2, l2, n2]), (0, o.useEffect)(
          () => () => {
            n2(null);
          },
          [n2]
        ), (0, a.jsx)("div", { ref: s2, className: i2, children: e2 });
      }, p = (t2) => {
        let { children: e2, title: r2, className: i2 } = t2, { setTitleElement: l2, setTitle: n2 } = (0, o.useContext)(u.B9), s2 = (0, o.useRef)(null);
        return (0, o.useEffect)(() => {
          (null == s2 ? void 0 : s2.current) && l2(s2), r2 && n2(r2);
        }, [s2, r2, l2, n2]), (0, o.useEffect)(
          () => () => {
            n2("");
          },
          [n2]
        ), (0, a.jsx)("div", { ref: s2, className: i2, children: e2 });
      };
    },
    34846: (t) => {
      t.exports = {
        root: "ArtistCard_root__x67BK",
        controls: "ArtistCard_controls__jsqqI",
        cover: "ArtistCard_cover__29ShU",
        coverBlock: "ArtistCard_coverBlock__dBL4x",
        image: "ArtistCard_image__pONJx",
        titleLink: "ArtistCard_titleLink__G8Puz",
        playButton: "ArtistCard_playButton__XZoTr",
        likeButton: "ArtistCard_likeButton__LU9TL",
        menuButton: "ArtistCard_menuButton__EynXG",
        pinButton: "ArtistCard_pinButton__G_VOi",
        trailerButton: "ArtistCard_trailerButton__a2NHm",
        control: "ArtistCard_control___qv5j"
      };
    },
    39694: (t, e, r) => {
      "use strict";
      r.d(e, { K: () => u });
      var o, i = r(94377), a = r(61910), l = {
        5881: (t2, e2, r2) => {
          function o2() {
            for (var t3, e3, r3 = 0, o3 = ""; r3 < arguments.length; )
              (t3 = arguments[r3++]) && (e3 = (function t4(e4) {
                var r4, o4, i3 = "";
                if ("string" == typeof e4 || "number" == typeof e4) i3 += e4;
                else if ("object" == typeof e4)
                  if (Array.isArray(e4))
                    for (r4 = 0; r4 < e4.length; r4++) e4[r4] && (o4 = t4(e4[r4])) && (i3 && (i3 += " "), i3 += o4);
                  else for (r4 in e4) e4[r4] && (i3 && (i3 += " "), i3 += r4);
                return i3;
              })(t3)) && (o3 && (o3 += " "), o3 += e3);
            return o3;
          }
          r2.r(e2), r2.d(e2, { clsx: () => o2, default: () => i2 });
          let i2 = o2;
        },
        1920: (t2, e2, r2) => {
          r2.r(e2), r2.d(e2, { default: () => o2 });
          let o2 = {
            contentContainer: "JjlbHZ4FaP9EAcR_1DxF",
            contentContainer_block: "iOlzvyUREgDkthkrx7Sf",
            flexIcon: "WsKeF73pWotx9W1tWdYY",
            root: "cpeagBA1_PblpJn8Xgtv",
            root_withoutBorder: "qU2apWBO1yyEK0lZ3lPO",
            root_radius_xs: "MmZbSs387gu2qrJ1lDWd",
            root_radius_s: "mlcrraysn7mW6xrBXSBF",
            root_radius_m: "dgV08FKVLZKFsucuiryn",
            root_radius_l: "S97_5dtzhpxo_amtfYRg",
            root_radius_xl: "nNBJnDHRlyLTniWosJhk",
            root_radius_xxxl: "zIMibMuH7wcqUoW7KH1B",
            root_radius_round: "uwk3hfWzB2VT7kE13SQk",
            root_size: "IlG7b1K0AD7E7AMx6F5p",
            root_size_default: "C_QGmfTz6UFX93vfPt6Z",
            root_size_xxxs: "eQt33MLDiQ6DRSuLaYEp",
            root_size_xxs: "oR11LfCBVqMbUJiAgknd",
            root_size_xs: "j1jXIVckFgZECecFzZMe",
            root_size_s: "WtFdWDF44egSVM_YiMUX",
            root_size_m: "Y2uqxoU7xa_AZ8FUCVOW",
            root_size_l: "SGYcNjvjmMsXeEVGUV2Z",
            root_icon_left: "kc5CjvU5hT9KEj0iTt3C",
            root_icon_right: "et24Jf7pT_X9Fvc7TznR",
            root_primary: "fXlFz1qMkliFUWOkHo8T",
            root_primary_default: "_eTRQi5ADZCUvUKMZqJU",
            ripple: "spMT3NcRD9Yb0ntNaNct",
            root_primary_outline: "fCUSh2B0Ye9kEvceE8zc",
            root_primary_text: "qlPp6CSQQEMVZPqtqLiQ",
            root_primary_withHover: "KZF6_4K1p_Y_GMIAxaAn",
            root_primary_withHover_default: "rWukOKAJh5Ga7JuIp62L",
            root_primary_withHover_outline: "fdwWCJKgUqml5wNqrRcN",
            root_primary_withHover_text: "IgYbZLnYjW0nMahgpkus",
            root_secondary: "_T4p_w41oaq6L4sztSdw",
            root_secondary_default: "iJVAJMgccD4vj4E4o068",
            root_secondary_outline: "pnM3iSP9keZOELI2oohr",
            root_secondary_text: "UDMYhpDjiAFT3xUx268O",
            root_secondary_withHover: "qUbrkhZIOVrvM0roV1QF",
            root_secondary_withHover_default: "nHWc2sto1C6Gm0Dpw_l0",
            root_secondary_withHover_outline: "i5WuBm5mfG0mflk_1jH_",
            root_secondary_withHover_text: "HbaqudSqu7Q3mv3zMPGr",
            root_plus: "ixLRsIJ2FvXO2k04n_QY",
            root_plus_default: "yRHwHzEGfDgRXGzYJqw2",
            root_plus_outline: "e777irPFmyQFFrURLF_U",
            root_plus_text: "vRqDhvmt3gt8TFp45_Zw",
            root_plus_withHover: "TZif6q3I2RwBEYXwK_iA",
            root_plus_withHover_default: "k3DhvmzpnM_Fb9oFdE4q",
            root_plus_withHover_outline: "RiDWYwGIxqbrUPR699DM",
            root_plus_withHover_text: "hC_mMCzWjkTn2j9xZzGc",
            root_accent: "jqD2jMT6n7F0WKyqwMsn",
            root_accent_default: "bDp0r9MtoYECZ8ObMoCh",
            root_accent_outline: "rXNyGp8NBAw2MUjACZNj",
            root_accent_text: "hmV4ERaXWAJc4uPLZL30",
            root_accent_withHover: "uKuxXu1N4TP5cWaEK5Ke",
            root_accent_withHover_default: "t_hequUaUgAMhFuxizLb",
            root_accent_withHover_outline: "Oy9sPFTxNTo1_E29U4aF",
            root_accent_withHover_text: "LcKRSd3DLoh7k60Oqox8",
            root_withActiveSpinner: "nAGvO87rLs15SJgft6Hh",
            block: "BbCxxIjBGupN28bq2lSP",
            icon: "J9wTKytjOWG73QMoN5WP",
            icon_position_left: "elJfazUBui03YWZgHCbW",
            icon_position_right: "RBoEbyJKP5rEtLsXM1ji",
            icon_withButtonSize: "cE17_kCWJgx8kzQEkeVr",
            spinnerContainer: "STbBDGqYjUEcLuNvhu9w"
          };
        },
        8903: (t2, e2, r2) => {
          r2.r(e2), r2.d(e2, { default: () => o2 });
          let o2 = {
            root: "BnN6sQIg6NahNBun6fkP",
            fade: "MM8MKXCw0gMkVvq7C1YS",
            fade_active: "MsLY_qiKofQrwKAr98EC",
            button: "Dp6n_Y0cfUyPQT1Z6uIm",
            text: "bfmUuyonXAK7HKYtDzUK"
          };
        },
        9097: (t2, e2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function o2(t3, e3, o3) {
            var i2 = null;
            if (void 0 !== o3 && (i2 = "" + o3), void 0 !== e3.key && (i2 = "" + e3.key), "key" in e3)
              for (var a2 in o3 = {}, e3) "key" !== a2 && (o3[a2] = e3[a2]);
            else o3 = e3;
            return { $$typeof: r2, type: t3, key: i2, ref: void 0 !== (e3 = o3.ref) ? e3 : null, props: o3 };
          }
          e2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), e2.jsx = o2, e2.jsxs = o2;
        },
        4377: (t2, e2, r2) => {
          t2.exports = r2(9097);
        },
        4601: (t2, e2, r2) => {
          Object.defineProperty(e2, "__esModule", { value: true }), e2.useToggle = void 0;
          let o2 = r2(810);
          e2.useToggle = (t3) => {
            let [e3, r3] = (0, o2.useState)(t3);
            (0, o2.useEffect)(() => {
              r3(t3);
            }, [t3]);
            let i2 = (0, o2.useCallback)(() => {
              r3((t4) => !t4);
            }, []), a2 = (0, o2.useCallback)(() => {
              r3(true);
            }, []), l2 = (0, o2.useCallback)(() => {
              r3(false);
            }, []);
            return { state: e3, toggle: i2, setState: r3, toggleTrue: a2, toggleFalse: l2 };
          };
        },
        666: (t2, e2, r2) => {
          Object.defineProperty(e2, "__esModule", { value: true }), e2.useTruncate = void 0;
          let o2 = r2(352), i2 = r2(810), a2 = r2(4601);
          e2.useTruncate = (t3) => {
            let [e3, r3] = (0, i2.useState)(0), { state: l2, toggleTrue: n2, toggleFalse: s2 } = (0, a2.useToggle)(false), c2 = (0, i2.useMemo)(
              () => (0, o2.throttle)(() => {
                let { offsetHeight: r4, scrollHeight: o3 } = (null == t3 ? void 0 : t3.current) || {};
                r4 && o3 && e3 < o3 ? n2() : s2();
              }, 100),
              [e3, t3, s2, n2]
            );
            return (0, i2.useEffect)(() => {
              var o3, i3;
              !e3 && (null == (o3 = t3.current) ? void 0 : o3.offsetHeight) && r3(null == (i3 = t3.current) ? void 0 : i3.offsetHeight);
            }, [e3, t3]), (0, i2.useEffect)(
              () => (c2(), window.addEventListener("resize", c2), () => {
                window.removeEventListener("resize", c2);
              }),
              [c2]
            ), { isTruncated: l2 };
          };
        },
        8796: (t2, e2) => {
          Object.defineProperty(e2, "__esModule", { value: true }), e2.createRipple = void 0, e2.createRipple = function(t3, e3, r2) {
            let o2 = null != r2 ? r2 : t3.currentTarget, i2 = document.createElement("span"), a2 = Math.max(o2.clientWidth, o2.clientHeight), l2 = a2 / 2, n2 = o2.getBoundingClientRect(), s2 = 0 === t3.clientX ? Math.round(n2.width / 2) : t3.clientX - n2.left, c2 = 0 === t3.clientY ? Math.round(n2.height / 2) : t3.clientY - n2.top;
            i2.style.width = "".concat(a2, "px"), i2.style.height = "".concat(a2, "px"), i2.style.left = 0 === t3.clientX ? "0px" : "".concat(s2 - l2, "px"), i2.style.top = "".concat(c2 - l2, "px"), i2.classList.add(e3);
            let u2 = o2.getElementsByClassName(e3)[0];
            u2 && u2.remove(), o2.insertBefore(i2, o2.firstChild);
          };
        },
        361: (t2, e2) => {
          Object.defineProperty(e2, "__esModule", { value: true }), e2.getElementFromRefOrElement = void 0, e2.getElementFromRefOrElement = (t3) => {
            if (void 0 !== t3) {
              if (null === t3 || t3 instanceof HTMLElement) return t3;
              if (null === t3.current || t3.current instanceof HTMLElement) return t3.current;
            }
          };
        },
        8216: (t2, e2, r2) => {
          Object.defineProperty(e2, "__esModule", { value: true }), e2.getElementFromRefOrElement = e2.createRipple = void 0;
          var o2 = r2(8796);
          Object.defineProperty(e2, "createRipple", {
            enumerable: true,
            get: function() {
              return o2.createRipple;
            }
          });
          var i2 = r2(361);
          Object.defineProperty(e2, "getElementFromRefOrElement", {
            enumerable: true,
            get: function() {
              return i2.getElementFromRefOrElement;
            }
          });
        },
        8119: function(t2, e2, r2) {
          var o2 = this && this.__importDefault || function(t3) {
            return t3 && t3.__esModule ? t3 : { default: t3 };
          };
          Object.defineProperty(e2, "__esModule", { value: true }), e2.Button = void 0;
          let i2 = r2(4377), a2 = r2(810), l2 = r2(5881), n2 = r2(8216), s2 = o2(r2(1920)), c2 = (t3) => {
            let {
              forwardRef: e3,
              isBlock: r3,
              iconPosition: o3 = "left",
              children: c3,
              className: u2,
              color: d = "secondary",
              flexIcon: _,
              icon: m,
              spinner: p,
              role: v,
              onClick: f,
              radius: A = "m",
              size: g,
              type: x = "button",
              variant: h = "default",
              withRipple: b = true,
              withHover: C = true,
              withBorder: T = false,
              disabled: y,
              iconClassName: k,
              contentContainerClassName: j,
              ...M
            } = t3, N = (0, a2.useId)(), I = !a2.Children.toArray(c3).filter(Boolean).length, S = "left" === o3, w = null, E = (0, a2.isValidElement)(p);
            if (m) {
              var L, B;
              w = (0, a2.cloneElement)(m, {
                className: (0, l2.clsx)(
                  s2.default.icon,
                  {
                    [s2.default["icon_position_".concat(o3)]]: o3 && !I,
                    [s2.default.icon_withButtonSize]: !(null == (L = m.props) ? void 0 : L.size)
                  },
                  null == (B = m.props) ? void 0 : B.className,
                  k
                ),
                key: N
              });
            }
            let R = (0, a2.useMemo)(
              () => E ? (0, i2.jsx)("div", { className: s2.default.spinnerContainer, children: p }) : null,
              [E, p]
            ), O = (0, a2.useCallback)(
              (t4) => {
                E || (b && (0, n2.createRipple)(t4, s2.default.ripple), null == f || f(t4));
              },
              [E, f, b]
            );
            return (0, i2.jsx)("button", {
              ref: e3,
              className: (0, l2.clsx)(
                s2.default.root,
                s2.default["root_".concat(d, "_").concat(h)],
                s2.default["root_radius_".concat(A)],
                s2.default.root_size,
                {
                  [s2.default["root_".concat(d, "_withHover_").concat(h)]]: C && !y && !E,
                  [s2.default["root_size_".concat(g)]]: g,
                  [s2.default.root_withoutBorder]: !T,
                  [s2.default.root_withActiveSpinner]: E,
                  [s2.default.block]: r3,
                  [s2.default.flexIcon]: _,
                  [s2.default.iconOnly]: I,
                  [s2.default.root_icon_left]: m && !I && S,
                  [s2.default.root_icon_right]: m && !I && !S
                },
                u2
              ),
              type: x,
              role: v,
              onClick: O,
              ...M,
              disabled: y,
              "aria-live": E ? "polite" : "off",
              "aria-busy": E,
              children: m || E ? (0, i2.jsxs)("span", {
                className: (0, l2.clsx)(
                  s2.default.contentContainer,
                  { [s2.default.contentContainer_block]: r3 },
                  j
                ),
                children: [m && S && w, !I && c3, m && !S && w, R]
              }) : c3
            });
          };
          e2.Button = (0, a2.forwardRef)((t3, e3) => (0, i2.jsx)(c2, { forwardRef: e3, ...t3 }));
        },
        217: function(t2, e2, r2) {
          var o2 = this && this.__importDefault || function(t3) {
            return t3 && t3.__esModule ? t3 : { default: t3 };
          };
          Object.defineProperty(e2, "__esModule", { value: true }), e2.CollapsableText = void 0;
          let i2 = r2(4377), a2 = r2(5881), l2 = r2(810), n2 = r2(666), s2 = r2(8119), c2 = o2(r2(8903));
          e2.CollapsableText = (t3) => {
            var e3;
            let {
              className: r3,
              children: o3,
              lineClamp: u2,
              moreText: d,
              lessText: _,
              buttonClassName: m,
              buttonProps: p,
              withFade: v,
              initialOpen: f = false,
              open: A,
              onOpenChange: g,
              ...x
            } = t3, [h, b] = (0, l2.useState)(f), C = (0, l2.useRef)(null), { isTruncated: T } = (0, n2.useTruncate)(C), y = null != A ? A : h, k = null != g ? g : b, j = (0, l2.cloneElement)(o3, {
              ref: C,
              lineClamp: !y && u2 || void 0,
              className: (0, a2.clsx)(null == (e3 = o3.props) ? void 0 : e3.className, c2.default.text)
            }), M = (0, l2.useMemo)(
              () => v && T ? (0, i2.jsx)("div", {
                className: (0, a2.clsx)(c2.default.fade, { [c2.default.fade_active]: !y }),
                children: j
              }) : j,
              [T, y, j, v]
            ), N = (0, l2.useCallback)(() => {
              k(!y);
            }, [y, k]), I = y ? _ : d;
            return (0, i2.jsxs)("div", {
              className: (0, a2.clsx)(c2.default.root, r3),
              ...x,
              children: [
                M,
                T && I && (0, i2.jsx)(s2.Button, {
                  ...p,
                  variant: "text",
                  withRipple: false,
                  onClick: N,
                  className: (0, a2.clsx)(c2.default.button, m),
                  color: "primary",
                  children: I
                })
              ]
            });
          };
        },
        352: (t2) => {
          t2.exports = i;
        },
        810: (t2) => {
          t2.exports = o || (o = r.t(a, 2));
        }
      }, n = {};
      function s(t2) {
        var e2 = n[t2];
        if (void 0 !== e2) return e2.exports;
        var r2 = n[t2] = { exports: {} };
        return l[t2].call(r2.exports, r2, r2.exports, s), r2.exports;
      }
      s.d = (t2, e2) => {
        for (var r2 in e2) s.o(e2, r2) && !s.o(t2, r2) && Object.defineProperty(t2, r2, { enumerable: true, get: e2[r2] });
      }, s.o = (t2, e2) => Object.prototype.hasOwnProperty.call(t2, e2), s.r = (t2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(t2, "__esModule", { value: true });
      };
      var c = {};
      (() => {
        Object.defineProperty(c, "X", { value: true }), c.f = void 0;
        var t2 = s(217);
        Object.defineProperty(c, "f", {
          enumerable: true,
          get: function() {
            return t2.CollapsableText;
          }
        });
      })();
      var u = c.f;
      c.X;
    },
    44844: (t) => {
      t.exports = {
        root: "ArtistAboutModalContent_root__XGW1F",
        header: "ArtistAboutModalContent_header__ws7Ap",
        title: "ArtistAboutModalContent_title__hMO2k",
        subtitle: "ArtistAboutModalContent_subtitle__OpssN",
        descriptionWrapper: "ArtistAboutModalContent_descriptionWrapper__jNL4G",
        description: "ArtistAboutModalContent_description__KlWvL",
        readMoreButton: "ArtistAboutModalContent_readMoreButton__1ageU",
        bandlinkScanner: "ArtistAboutModalContent_bandlinkScanner__Fwv2x"
      };
    },
    54736: (t) => {
      t.exports = {
        root: "ArtistAboutModalImageSlider_root__L18Xb",
        button: "ArtistAboutModalImageSlider_button__GPXyc",
        image: "ArtistAboutModalImageSlider_image__3CTLr",
        moreCovers: "ArtistAboutModalImageSlider_moreCovers__7oDPM",
        moreCoversText: "ArtistAboutModalImageSlider_moreCoversText__W_P8L"
      };
    },
    55616: (t, e, r) => {
      "use strict";
      r.d(e, {
        vx: () => u,
        r3: () => m,
        EV: () => p,
        y8: () => k.ArtistAboutModal,
        Xj: () => b,
        ao: () => j.ArtistCard,
        gg: () => M.ArtistContextMenu,
        G4: () => T,
        NN: () => N.ArtistTopCard,
        GV: () => y,
        eS: () => _,
        cz: () => I.HorizontalArtistCard,
        M$: () => d,
        xx: () => s,
        dg: () => c,
        LH: () => i,
        MX: () => n
      });
      var o = r(93064);
      let i = (t2) => (0, o.wg)({ title: t2.title, url: t2.action.weblink });
      var a = r(63695), l = r(42140);
      let n = (t2) => {
        let e2 = (0, a.as)({ artist: t2.artist }), r2 = (0, l.ws)(t2.top);
        return (0, o.wg)({ artist: e2, listenTimeSeconds: t2.listenTimeSeconds, top: r2 });
      }, s = 5, c = 9, u = 9, d = 3, _ = 5, m = 20, p = 20;
      var v = r(97396), f = r(61910), A = r(11405), g = r(74125);
      (0, f.cache)(async function(t2, e2) {
        let r2, o2 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : { artistId: t2, page: 0, pageSize: m, sort: { sortBy: A.g.YEAR } };
        (0, g.LLJ)(t2) || (0, v.notFound)();
        try {
          let i3, {
            container: a2,
            backendHostTld: l2,
            locale: n2,
            host: c2,
            fullUrl: u2,
            isRSC: d2,
            requestUrl: _2
          } = await (0, g.IhE)();
          if (d2)
            return { artist: void 0, albums: void 0, backendHostTld: l2, locale: n2, host: c2, fullUrl: u2, requestUrl: _2 };
          let m2 = a2.get(g.O9U), p2 = await m2.getBriefInfo({
            artistId: t2,
            popularTracksCount: s,
            fetchPlaylistLikesCounts: true,
            discographyBlockEnabled: true,
            useClipDataFormat: true
          });
          switch (e2) {
            case g.hVl.COMPILATIONS:
              i3 = await m2.getAlsoAlbums(o2);
              break;
            case g.hVl.DISCOGRAPHY:
              i3 = await m2.getDiscographyAlbums(o2);
              break;
            default:
              i3 = await m2.getDirectAlbums(o2);
          }
          r2 = { artist: p2, albums: i3, backendHostTld: l2, locale: n2, host: c2, fullUrl: u2, requestUrl: _2 };
        } catch (t3) {
          return (0, g.tfF)(t3, () => ({ artist: void 0, albums: void 0, ...(0, g.Bj3)() }));
        }
        let { artist: i2 } = r2;
        return ((null == i2 ? void 0 : i2.error) === "not-found" || (null == i2 ? void 0 : i2.artist.error) === "not-found") && (0, v.notFound)(), r2;
      }), (0, f.cache)(async function(t2) {
        let e2, r2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : { artistId: t2, page: 0, pageSize: p };
        try {
          let {
            container: o3,
            backendHostTld: i2,
            locale: a2,
            host: l2,
            fullUrl: n2,
            isRSC: c2,
            requestUrl: u2
          } = await (0, g.IhE)();
          if (c2)
            return {
              artist: void 0,
              clips: void 0,
              backendHostTld: i2,
              locale: a2,
              host: l2,
              fullUrl: n2,
              requestUrl: u2
            };
          let d2 = o3.get(g.O9U), _2 = await d2.getBriefInfo({
            artistId: t2,
            popularTracksCount: s,
            fetchPlaylistLikesCounts: true,
            discographyBlockEnabled: true,
            useClipDataFormat: true
          }), m2 = await d2.getClips(r2);
          e2 = { artist: _2, clips: m2, backendHostTld: i2, locale: a2, host: l2, fullUrl: n2, requestUrl: u2 };
        } catch (t3) {
          return (0, g.tfF)(t3, () => ({ artist: void 0, clips: void 0, ...(0, g.Bj3)() }));
        }
        let { artist: o2 } = e2;
        return ((null == o2 ? void 0 : o2.error) === "not-found" || (null == o2 ? void 0 : o2.artist.error) === "not-found") && (0, v.notFound)(), e2;
      }), (0, f.cache)(async (t2) => {
        let e2;
        (0, g.LLJ)(t2) || (0, v.notFound)();
        try {
          let {
            container: r3,
            backendHostTld: o2,
            locale: i2,
            host: a2,
            fullUrl: l2,
            isRSC: n2,
            requestUrl: c2
          } = await (0, g.IhE)();
          if (n2) return { artist: void 0, backendHostTld: o2, locale: i2, host: a2, fullUrl: l2, requestUrl: c2 };
          let u2 = r3.get(g.O9U), d2 = await u2.getBriefInfo({
            artistId: t2,
            popularTracksCount: s,
            fetchPlaylistLikesCounts: true,
            discographyBlockEnabled: true,
            useClipDataFormat: true
          }), _2 = await u2.getConcerts({ artistId: Number(t2) });
          e2 = { artist: d2, concerts: _2, backendHostTld: o2, locale: i2, host: a2, fullUrl: l2, requestUrl: c2 };
        } catch (t3) {
          return (0, g.tfF)(t3, () => ({ artist: void 0, concerts: void 0, ...(0, g.Bj3)() }));
        }
        let { artist: r2 } = e2;
        return ((null == r2 ? void 0 : r2.error) === "not-found" || (null == r2 ? void 0 : r2.artist.error) === "not-found") && (0, v.notFound)(), e2;
      }), (0, f.cache)(async (t2) => {
        let e2;
        (0, g.LLJ)(t2) || (0, v.notFound)();
        try {
          let {
            container: r3,
            backendHostTld: o2,
            locale: i2,
            host: a2,
            fullUrl: l2,
            isRSC: n2,
            requestUrl: c2
          } = await (0, g.IhE)();
          if (n2)
            return {
              artist: void 0,
              familiar: void 0,
              backendHostTld: o2,
              locale: i2,
              host: a2,
              fullUrl: l2,
              requestUrl: c2
            };
          let u2 = r3.get(g.O9U), d2 = await u2.getBriefInfo({
            artistId: t2,
            popularTracksCount: s,
            fetchPlaylistLikesCounts: true,
            discographyBlockEnabled: true,
            useClipDataFormat: true
          }), _2 = await u2.getFamiliarYou({
            artistId: t2,
            waveTracksLimit: 100,
            collectionTracksLimit: 100,
            collectionAlbumsLimit: 20
          });
          e2 = { artist: d2, familiar: _2, backendHostTld: o2, locale: i2, host: a2, fullUrl: l2, requestUrl: c2 };
        } catch (t3) {
          return (0, g.tfF)(t3, () => ({ artist: void 0, familiar: void 0, ...(0, g.Bj3)() }));
        }
        let { artist: r2 } = e2;
        return ((null == r2 ? void 0 : r2.error) === "not-found" || (null == r2 ? void 0 : r2.artist.error) === "not-found") && (0, v.notFound)(), e2;
      }), (0, f.cache)(async (t2) => {
        let e2;
        (0, g.LLJ)(t2) || (0, v.notFound)();
        try {
          let {
            container: r3,
            backendHostTld: o2,
            locale: i2,
            host: a2,
            fullUrl: l2,
            isRSC: n2,
            requestUrl: c2
          } = await (0, g.IhE)();
          if (n2) return { artist: void 0, backendHostTld: o2, locale: i2, host: a2, fullUrl: l2, requestUrl: c2 };
          let u2 = r3.get(g.O9U);
          e2 = {
            artist: await u2.getBriefInfo({
              artistId: t2,
              popularTracksCount: s,
              fetchPlaylistLikesCounts: true,
              discographyBlockEnabled: true,
              useClipDataFormat: true
            }),
            backendHostTld: o2,
            locale: i2,
            host: a2,
            fullUrl: l2,
            requestUrl: c2
          };
        } catch (t3) {
          return (0, g.tfF)(t3, () => ({ artist: void 0, ...(0, g.Bj3)() }));
        }
        let { artist: r2 } = e2;
        return ((null == r2 ? void 0 : r2.error) === "not-found" || (null == r2 ? void 0 : r2.artist.error) === "not-found") && (0, v.notFound)(), e2;
      }), (0, f.cache)(async (t2) => {
        let e2;
        (0, g.LLJ)(t2) || (0, v.notFound)();
        try {
          let {
            container: r3,
            backendHostTld: o2,
            locale: i2,
            host: a2,
            fullUrl: l2,
            isRSC: n2,
            requestUrl: c2
          } = await (0, g.IhE)();
          if (n2)
            return {
              artist: void 0,
              similarArtists: void 0,
              backendHostTld: o2,
              locale: i2,
              host: a2,
              fullUrl: l2,
              requestUrl: c2
            };
          let u2 = r3.get(g.O9U), d2 = await u2.getBriefInfo({
            artistId: t2,
            popularTracksCount: s,
            fetchPlaylistLikesCounts: true,
            discographyBlockEnabled: true,
            useClipDataFormat: true
          }), _2 = await u2.getSimilarArtists({ artistId: t2 });
          e2 = { artist: d2, similarArtists: _2, backendHostTld: o2, locale: i2, host: a2, fullUrl: l2, requestUrl: c2 };
        } catch (t3) {
          return (0, g.tfF)(t3, () => ({ artist: void 0, similarArtists: void 0, ...(0, g.Bj3)() }));
        }
        let { artist: r2 } = e2;
        return ((null == r2 ? void 0 : r2.error) === "not-found" || (null == r2 ? void 0 : r2.artist.error) === "not-found") && (0, v.notFound)(), e2;
      });
      var x = r(46163), h = r(26433);
      let b = o.gK.compose(
        o.gK.model("ArtistAboutModal", {
          modal: h.qt,
          artist: o.gK.maybeNull(a.PK),
          artistType: o.gK.maybeNull(o.gK.enumeration(Object.values(x.o))),
          description: o.gK.maybeNull(o.gK.string),
          lastMonthListeners: o.gK.maybeNull(o.gK.number),
          lastMonthListenersDelta: o.gK.optional(o.gK.number, 0),
          covers: o.gK.maybeNull(o.gK.array(o.gK.string)),
          links: o.gK.maybeNull(o.gK.array(a.dP))
        }),
        h.XT,
        h.pl
      ).views((t2) => ({
        get isArtistStatsAvailable() {
          return Number.isFinite(t2.lastMonthListeners);
        }
      })).actions((t2) => {
        let e2 = {
          open(r2) {
            r2 && (e2.getData(r2), t2.modal.open());
          },
          getData: (0, o.L3)(function* (e3) {
            let { artistsResource: r2, modelActionsLogger: i2 } = (0, o._$)(t2);
            if (!t2.isLoading)
              try {
                var l2, n2, s2, c2, u2;
                t2.loadingState = g.GuX.PENDING;
                let i3 = yield r2.getAboutArtist({ artistId: e3 });
                t2.artist = (0, a.as)({ artist: i3.artist }), t2.description = null != (u2 = i3.description) ? u2 : null, t2.artistType = i3.artistType === x.o.COMPOSER ? x.o.COMPOSER : x.o.ARTIST, i3.stats && Number.isFinite(null == (l2 = i3.stats) ? void 0 : l2.lastMonthListeners) && (t2.lastMonthListeners = i3.stats.lastMonthListeners), i3.stats && Number.isFinite(null == (n2 = i3.stats) ? void 0 : n2.lastMonthListenersDelta) && (t2.lastMonthListenersDelta = i3.stats.lastMonthListenersDelta);
                let d2 = null == (s2 = i3.covers) ? void 0 : s2.map((t3) => t3.uri).filter((t3) => !!t3);
                d2 && (t2.covers = (0, o.wg)(d2)), t2.links = (0, o.wg)(null == (c2 = i3.links) ? void 0 : c2.map(a.DZ)), t2.loadingState !== g.GuX.IDLE && (t2.loadingState = g.GuX.RESOLVE);
              } catch (e4) {
                i2.error(e4), t2.loadingState !== g.GuX.IDLE && (t2.loadingState = g.GuX.REJECT);
              }
          }),
          close() {
            t2.modal.close(), e2.reset();
          },
          onOpenChange(r2) {
            t2.modal.onOpenChange(r2), r2 || e2.reset();
          },
          reset() {
            t2.loadingState = g.GuX.IDLE, t2.description = null, t2.lastMonthListeners = null, t2.lastMonthListenersDelta = 0, t2.artistType = null, t2.destroyItems([t2.artist, t2.covers, t2.links]);
          }
        };
        return e2;
      }), C = o.gK.model("ArtistBrandedButton", { title: o.gK.maybeNull(o.gK.string), url: o.gK.maybeNull(o.gK.string) }), T = o.gK.model("ArtistMeta", {
        artist: a.PK,
        donationUrl: o.gK.maybe(o.gK.string),
        lastMonthListeners: o.gK.maybe(o.gK.number),
        brandedButton: o.gK.maybe(C),
        covers: o.gK.maybeNull(o.gK.array(o.gK.string))
      }).views((t2) => ({
        get hasCovers() {
          var e2;
          return !!(null == (e2 = t2.covers) ? void 0 : e2.length);
        }
      })), y = o.gK.model("ArtistTop", { artist: a.PK, listenTimeSeconds: o.gK.number, top: o.gK.maybe(l.Iz) }).views((t2) => ({
        get isAvailableForPlaying() {
          if (void 0 === t2.artist.counts) return true;
          return t2.artist.counts.tracks > 0;
        }
      })).actions((t2) => ({ getKey: (e2) => "".concat(e2, "_").concat(t2.artist.id) }));
      var k = r(26923), j = r(23504), M = r(99182), N = r(83580), I = r(19633);
    },
    66534: (t, e, r) => {
      "use strict";
      var o;
      r.d(e, { U: () => o }), (function(t2) {
        t2.UNKNOWN = "unknown", t2.MALE = "male", t2.FEMALE = "female";
      })(o || (o = {}));
    },
    69258: (t) => {
      t.exports = {
        root: "ArtistAboutModal_root__bmUo9",
        modalContent: "ArtistAboutModal_modalContent__RGkJk",
        header: "ArtistAboutModal_header__yLnAj",
        overlay: "ArtistAboutModal_overlay__6hToT",
        closeButton: "ArtistAboutModal_closeButton__Gnz25"
      };
    },
    72588: (t) => {
      t.exports = {
        root: "ArtistAboutModalShimmer_root__RWCDi",
        entityName: "ArtistAboutModalShimmer_entityName__eBJym",
        title: "ArtistAboutModalShimmer_title__0uj5d"
      };
    },
    76886: (t) => {
      t.exports = {
        positionIndicator: "ArtistTopCard_positionIndicator__Bs_Ga",
        crownIcon: "ArtistTopCard_crownIcon__yxAH3",
        progressIcon: "ArtistTopCard_progressIcon__gHcbF",
        progressIcon_up: "ArtistTopCard_progressIcon_up__PeHBx",
        progressIcon_down: "ArtistTopCard_progressIcon_down__0PKeO",
        progressIcon_same: "ArtistTopCard_progressIcon_same___SujQ",
        progressIcon_new: "ArtistTopCard_progressIcon_new__w3wA6",
        listenTime: "ArtistTopCard_listenTime__P1_jw"
      };
    },
    83580: (t, e, r) => {
      "use strict";
      r.d(e, { ArtistTopCard: () => f });
      var o = r(54486), i = r(50420), a = r(28303), l = r(43426), n = r(60423), s = r(27510), c = r(5956), u = r(97800), d = r(63695), _ = r(23504), m = r(76886), p = r.n(m);
      let v = { [n._.UP]: "chartUp", [n._.DOWN]: "chartDown", [n._.SAME]: "chartSame", [n._.NEW]: "chartNew" }, f = (0, a.PA)((t2) => {
        let { artist: e2, position: r2, progress: a2, listenTimeSeconds: n2, className: m2 } = t2, { formatMessage: f2 } = (0, l.A)(), A = (0, d.Uw)(n2, f2), g = a2 ? v[a2] : null, x = g ? (0, o.jsx)(c.Icon, {
          variant: g,
          size: "xxs",
          className: (0, i.$)(p().progressIcon, p()["progressIcon_".concat(a2)]),
          "aria-hidden": true
        }) : null, h = (0, s.L)(
          () => void 0 !== r2 ? (0, o.jsxs)("div", {
            className: p().positionIndicator,
            children: [
              (0, o.jsx)(u.Caption, {
                variant: "span",
                type: "entity",
                size: "m",
                weight: "bold",
                children: r2
              }),
              1 === r2 && (0, o.jsx)(c.Icon, {
                variant: "crown",
                size: "xxs",
                className: p().crownIcon,
                "aria-hidden": "true"
              }),
              1 !== r2 && x
            ]
          }) : void 0
        ), b = (0, s.L)(
          () => (0, o.jsx)(u.Caption, {
            variant: "div",
            type: "controls",
            size: "s",
            weight: "medium",
            className: p().listenTime,
            children: A
          })
        );
        return (0, o.jsx)(_.ArtistCard, {
          artist: e2,
          className: m2,
          topTitleElement: h,
          bottomTitleElement: b,
          contentLinesCount: 3
        });
      });
    },
    96266: (t) => {
      t.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "ControlsBar_root__Cb_I5",
        item: "ControlsBar_item__Bgdoc",
        item_buttonArrow: "ControlsBar_item_buttonArrow__Hpg2f",
        controls: "ControlsBar_controls__JCmC_",
        likeIcon: "ControlsBar_likeIcon__LBoka",
        trailerIcon: "ControlsBar_trailerIcon__W0fPg",
        controls_disabled: "ControlsBar_controls_disabled__gLZiS"
      };
    },
    99182: (t, e, r) => {
      "use strict";
      r.d(e, { ArtistContextMenu: () => f });
      var o = r(54486), i = r(28303), a = r(43426), l = r(43350), n = r(31500), s = r(63585), c = r(8817), u = r(5956), d = r(61958), _ = r(63695), m = r(83504), p = r(74125), v = r(80585);
      let f = (0, i.PA)((t2) => {
        var e2, r2, i2;
        let { artist: f2, onOpenChange: A, open: g, ...x } = t2, { shouldShowBuySubscriptionModal: h, showBuySubscriptionModal: b } = (0, p.qBP)(), {
          settings: { isMobile: C },
          modals: { artistAboutModal: T },
          trailer: y,
          user: k,
          experiments: j
        } = (0, p.Pjs)(), M = (0, _.A7)(f2), N = (0, _.KX)(f2), I = (0, _.mW)(f2), S = (0, p.Ftl)(), w = "".concat(p.UfI.ARTIST, "-").concat(null == f2 ? void 0 : f2.id), { formatMessage: E } = (0, a.A)(), { utmLink: L } = (0, p.fyy)({
          blockId: p.UfI.ARTIST,
          contextType: s.K.Artist,
          contextId: null == f2 ? void 0 : f2.id
        }), { shareLink: B, pathname: R } = (0, p.bNS)("/artist/:artistId", {
          params: { artistId: null != (r2 = null == f2 ? void 0 : f2.id) ? r2 : "" }
        }), O = (0, m.A_)({ entityVariant: p.DwC.ARTIST, urlParams: { id: null == f2 ? void 0 : f2.id } }), { isPlaying: P, togglePlay: K } = (0, p.B0S)({
          seeds: null != (i2 = null == f2 ? void 0 : f2.seeds) ? i2 : [],
          pageIdForFrom: p._Q$.RADIO,
          blockIdForFrom: w,
          parentContextId: null == f2 ? void 0 : f2.id
        }), D = (0, p.PT7)(), F = E((null == f2 ? void 0 : f2.isComposer) ? { id: "artist.about-composer" } : { id: "artist.about-artist" }), z = (0, c.c)(() => {
          if (h && k.isAuthorized) return void b();
          P || K();
        }), U = (0, c.c)(() => {
          if (!D()) {
            if (h) return void b();
            (null == f2 ? void 0 : f2.id) && (y.setUtmLink(L), y.openArtistTrailer(f2.id), S(l.ky.Artist, f2.id));
          }
        }), H = (0, c.c)(() => {
          T.open(null == f2 ? void 0 : f2.id);
        });
        (0, p.NBO)(g);
        let W = { variant: p.Yxq.ARTIST, id: null == f2 ? void 0 : f2.id, title: null == f2 ? void 0 : f2.name, path: R }, q = j.checkExperiment(p.zal.WebEditorsFeatures, "on"), X = null == f2 || null == (e2 = f2.trailer) ? void 0 : e2.isAvailable, G = j.checkExperiment(p.zal.WebNextArtistInfo, "on");
        return (0, o.jsxs)(d.W1, {
          isMobile: C,
          offsetOptions: 10,
          open: g,
          onOpenChange: A,
          ariaLabel: E({ id: "interface-actions.context-menu" }),
          containerProps: (0, n.Am)(n.Kq.artist.ARTIST_CONTEXT_MENU),
          ...x,
          children: [
            q && (0, o.jsx)(v.aQ, { fallback: (0, o.jsx)(m.dx, { entityVariant: p.DwC.ARTIST, adminUrl: O }) }),
            !C && (0, o.jsx)(v.aQ, {
              fallback: (0, o.jsx)(v.L1, { onClick: M, isPinned: null == f2 ? void 0 : f2.isPinned })
            }),
            (0, o.jsx)(v.aQ, {
              fallback: (0, o.jsx)(v.TW, {
                onClick: N,
                isLiked: null == f2 ? void 0 : f2.isLiked,
                disabled: !k.isAuthorized || !(null == f2 ? void 0 : f2.isAvailable)
              })
            }),
            X && (0, o.jsx)(v.aQ, { fallback: (0, o.jsx)(v.No, { onClick: U }) }),
            (0, o.jsx)(v.aQ, {
              fallback: (0, o.jsx)(v.C6, {
                onClick: z,
                disabled: !(null == f2 ? void 0 : f2.isAvailable),
                variant: p.IGO.ARTIST,
                onOpenMenuChange: A
              })
            }),
            (0, o.jsx)(v.Ht, { disabled: !f2, shareLink: B, entityMeta: W }),
            G && (0, o.jsx)(v.aQ, {
              fallback: (0, o.jsx)(d.Dr, {
                onClick: H,
                icon: (0, o.jsx)(u.Icon, { variant: "info", size: "xxs" }),
                ...(0, n.Am)(n.Kq.artist.ARTIST_CONTEXT_MENU_ABOUT_ARTIST_BUTTON),
                children: F
              })
            }),
            (0, o.jsx)(v.aQ, {
              fallback: (0, o.jsx)(v.DZ, {
                onClick: I,
                isDisliked: null == f2 ? void 0 : f2.isDisliked,
                disabled: !(null == f2 ? void 0 : f2.isAvailable)
              })
            })
          ]
        });
      });
    }
  }
]);
