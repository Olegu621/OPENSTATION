"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4885],
  {
    4885: (e, t, s) => {
      s.d(t, { Te: () => y, XW: () => M });
      var i = s(61910), n = s(92803);
      function l(e2, t2, s2) {
        var _a;
        let i2, n2 = (_a = s2.initialDeps) != null ? _a : [];
        function l2() {
          var l3, o2, r2, h2;
          let a2, d2;
          s2.key && (null == (l3 = s2.debug) ? void 0 : l3.call(s2)) && (a2 = Date.now());
          let u2 = e2();
          if (!(u2.length !== n2.length || u2.some((e3, t3) => n2[t3] !== e3))) return i2;
          if (n2 = u2, s2.key && (null == (o2 = s2.debug) ? void 0 : o2.call(s2)) && (d2 = Date.now()), i2 = t2(...u2), s2.key && (null == (r2 = s2.debug) ? void 0 : r2.call(s2))) {
            let e3 = Math.round((Date.now() - a2) * 100) / 100, t3 = Math.round((Date.now() - d2) * 100) / 100, i3 = t3 / 16, n3 = (e4, t4) => {
              for (e4 = String(e4); e4.length < t4; ) e4 = " " + e4;
              return e4;
            };
            console.info(
              `%c⏱ ${n3(t3, 5)} /${n3(e3, 5)} ms`,
              `
            font-size: .6rem;
            font-weight: bold;
            color: hsl(${Math.max(0, Math.min(120 - 120 * i3, 120))}deg 100% 31%);`,
              null == s2 ? void 0 : s2.key
            );
          }
          return null == (h2 = null == s2 ? void 0 : s2.onChange) || h2.call(s2, i2), i2;
        }
        return l2.updateDeps = (e3) => {
          n2 = e3;
        }, l2;
      }
      function o(e2, t2) {
        if (void 0 !== e2) return e2;
        throw Error(`Unexpected undefined${t2 ? `: ${t2}` : ""}`);
      }
      let r = (e2, t2, s2) => {
        let i2;
        return function(...n2) {
          e2.clearTimeout(i2), i2 = e2.setTimeout(() => t2.apply(this, n2), s2);
        };
      }, h = (e2) => e2, a = (e2) => {
        let t2 = Math.max(e2.startIndex - e2.overscan, 0), s2 = Math.min(e2.endIndex + e2.overscan, e2.count - 1), i2 = [];
        for (let e3 = t2; e3 <= s2; e3++) i2.push(e3);
        return i2;
      }, d = (e2, t2) => {
        let s2 = e2.scrollElement;
        if (!s2) return;
        let i2 = e2.targetWindow;
        if (!i2) return;
        let n2 = (e3) => {
          let { width: s3, height: i3 } = e3;
          t2({ width: Math.round(s3), height: Math.round(i3) });
        };
        if (n2(s2.getBoundingClientRect()), !i2.ResizeObserver) return () => {
        };
        let l2 = new i2.ResizeObserver((t3) => {
          let i3 = () => {
            let e3 = t3[0];
            if (null == e3 ? void 0 : e3.borderBoxSize) {
              let t4 = e3.borderBoxSize[0];
              if (t4) return void n2({ width: t4.inlineSize, height: t4.blockSize });
            }
            n2(s2.getBoundingClientRect());
          };
          e2.options.useAnimationFrameWithResizeObserver ? requestAnimationFrame(i3) : i3();
        });
        return l2.observe(s2, { box: "border-box" }), () => {
          l2.unobserve(s2);
        };
      }, u = { passive: true }, c = (e2, t2) => {
        let s2 = e2.scrollElement;
        if (!s2) return;
        let i2 = () => {
          t2({ width: s2.innerWidth, height: s2.innerHeight });
        };
        return i2(), s2.addEventListener("resize", i2, u), () => {
          s2.removeEventListener("resize", i2);
        };
      }, m = "undefined" == typeof window || "onscrollend" in window, f = (e2, t2) => {
        let s2 = e2.scrollElement;
        if (!s2) return;
        let i2 = e2.targetWindow;
        if (!i2) return;
        let n2 = 0, l2 = e2.options.useScrollendEvent && m ? () => void 0 : r(
          i2,
          () => {
            t2(n2, false);
          },
          e2.options.isScrollingResetDelay
        ), o2 = (i3) => () => {
          let { horizontal: o3, isRtl: r2 } = e2.options;
          n2 = o3 ? s2.scrollLeft * (r2 && -1 || 1) : s2.scrollTop, l2(), t2(n2, i3);
        }, h2 = o2(true), a2 = o2(false);
        a2(), s2.addEventListener("scroll", h2, u);
        let d2 = e2.options.useScrollendEvent && m;
        return d2 && s2.addEventListener("scrollend", a2, u), () => {
          s2.removeEventListener("scroll", h2), d2 && s2.removeEventListener("scrollend", a2);
        };
      }, g = (e2, t2) => {
        let s2 = e2.scrollElement;
        if (!s2) return;
        let i2 = e2.targetWindow;
        if (!i2) return;
        let n2 = 0, l2 = e2.options.useScrollendEvent && m ? () => void 0 : r(
          i2,
          () => {
            t2(n2, false);
          },
          e2.options.isScrollingResetDelay
        ), o2 = (i3) => () => {
          n2 = s2[e2.options.horizontal ? "scrollX" : "scrollY"], l2(), t2(n2, i3);
        }, h2 = o2(true), a2 = o2(false);
        a2(), s2.addEventListener("scroll", h2, u);
        let d2 = e2.options.useScrollendEvent && m;
        return d2 && s2.addEventListener("scrollend", a2, u), () => {
          s2.removeEventListener("scroll", h2), d2 && s2.removeEventListener("scrollend", a2);
        };
      }, p = (e2, t2, s2) => {
        if (null == t2 ? void 0 : t2.borderBoxSize) {
          let e3 = t2.borderBoxSize[0];
          if (e3) return Math.round(e3[s2.options.horizontal ? "inlineSize" : "blockSize"]);
        }
        return Math.round(e2.getBoundingClientRect()[s2.options.horizontal ? "width" : "height"]);
      }, v = (e2, { adjustments: t2 = 0, behavior: s2 }, i2) => {
        var n2, l2;
        null == (l2 = null == (n2 = i2.scrollElement) ? void 0 : n2.scrollTo) || l2.call(n2, { [i2.options.horizontal ? "left" : "top"]: e2 + t2, behavior: s2 });
      }, b = (e2, { adjustments: t2 = 0, behavior: s2 }, i2) => {
        var n2, l2;
        null == (l2 = null == (n2 = i2.scrollElement) ? void 0 : n2.scrollTo) || l2.call(n2, { [i2.options.horizontal ? "left" : "top"]: e2 + t2, behavior: s2 });
      };
      class E {
        constructor(e2) {
          this.unsubs = [], this.scrollElement = null, this.targetWindow = null, this.isScrolling = false, this.scrollToIndexTimeoutId = null, this.measurementsCache = [], this.itemSizeCache = /* @__PURE__ */ new Map(), this.pendingMeasuredCacheIndexes = [], this.scrollRect = null, this.scrollOffset = null, this.scrollDirection = null, this.scrollAdjustments = 0, this.elementsCache = /* @__PURE__ */ new Map(), this.observer = /* @__PURE__ */ (() => {
            let e3 = null, t2 = () => e3 || (this.targetWindow && this.targetWindow.ResizeObserver ? e3 = new this.targetWindow.ResizeObserver((e4) => {
              e4.forEach((e5) => {
                let t3 = () => {
                  this._measureElement(e5.target, e5);
                };
                this.options.useAnimationFrameWithResizeObserver ? requestAnimationFrame(t3) : t3();
              });
            }) : null);
            return {
              disconnect: () => {
                var s2;
                null == (s2 = t2()) || s2.disconnect(), e3 = null;
              },
              observe: (e4) => {
                var s2;
                return null == (s2 = t2()) ? void 0 : s2.observe(e4, { box: "border-box" });
              },
              unobserve: (e4) => {
                var s2;
                return null == (s2 = t2()) ? void 0 : s2.unobserve(e4);
              }
            };
          })(), this.range = null, this.setOptions = (e3) => {
            Object.entries(e3).forEach(([t2, s2]) => {
              void 0 === s2 && delete e3[t2];
            }), this.options = {
              debug: false,
              initialOffset: 0,
              overscan: 1,
              paddingStart: 0,
              paddingEnd: 0,
              scrollPaddingStart: 0,
              scrollPaddingEnd: 0,
              horizontal: false,
              getItemKey: h,
              rangeExtractor: a,
              onChange: () => {
              },
              measureElement: p,
              initialRect: { width: 0, height: 0 },
              scrollMargin: 0,
              gap: 0,
              indexAttribute: "data-index",
              initialMeasurementsCache: [],
              lanes: 1,
              isScrollingResetDelay: 150,
              enabled: true,
              isRtl: false,
              useScrollendEvent: false,
              useAnimationFrameWithResizeObserver: false,
              ...e3
            };
          }, this.notify = (e3) => {
            var t2, s2;
            null == (s2 = (t2 = this.options).onChange) || s2.call(t2, this, e3);
          }, this.maybeNotify = l(
            () => (this.calculateRange(), [this.isScrolling, this.range ? this.range.startIndex : null, this.range ? this.range.endIndex : null]),
            (e3) => {
              this.notify(e3);
            },
            {
              key: false,
              debug: () => this.options.debug,
              initialDeps: [
                this.isScrolling,
                this.range ? this.range.startIndex : null,
                this.range ? this.range.endIndex : null
              ]
            }
          ), this.cleanup = () => {
            this.unsubs.filter(Boolean).forEach((e3) => e3()), this.unsubs = [], this.observer.disconnect(), this.scrollElement = null, this.targetWindow = null;
          }, this._didMount = () => () => {
            this.cleanup();
          }, this._willUpdate = () => {
            var _a;
            var e3;
            let t2 = this.options.enabled ? this.options.getScrollElement() : null;
            if (this.scrollElement !== t2) {
              if (this.cleanup(), !t2) return void this.maybeNotify();
              this.scrollElement = t2, this.scrollElement && "ownerDocument" in this.scrollElement ? this.targetWindow = this.scrollElement.ownerDocument.defaultView : this.targetWindow = (_a = null == (e3 = this.scrollElement) ? void 0 : e3.window) != null ? _a : null, this.elementsCache.forEach((e4) => {
                this.observer.observe(e4);
              }), this._scrollToOffset(this.getScrollOffset(), { adjustments: void 0, behavior: void 0 }), this.unsubs.push(
                this.options.observeElementRect(this, (e4) => {
                  this.scrollRect = e4, this.maybeNotify();
                })
              ), this.unsubs.push(
                this.options.observeElementOffset(this, (e4, t3) => {
                  this.scrollAdjustments = 0, this.scrollDirection = t3 ? this.getScrollOffset() < e4 ? "forward" : "backward" : null, this.scrollOffset = e4, this.isScrolling = t3, this.maybeNotify();
                })
              );
            }
          }, this.getSize = () => {
            var _a;
            return this.options.enabled ? (this.scrollRect = (_a = this.scrollRect) != null ? _a : this.options.initialRect, this.scrollRect[this.options.horizontal ? "width" : "height"]) : (this.scrollRect = null, 0);
          }, this.getScrollOffset = () => {
            var _a;
            return this.options.enabled ? (this.scrollOffset = (_a = this.scrollOffset) != null ? _a : "function" == typeof this.options.initialOffset ? this.options.initialOffset() : this.options.initialOffset, this.scrollOffset) : (this.scrollOffset = null, 0);
          }, this.getFurthestMeasurement = (e3, t2) => {
            let s2 = /* @__PURE__ */ new Map(), i2 = /* @__PURE__ */ new Map();
            for (let n2 = t2 - 1; n2 >= 0; n2--) {
              let t3 = e3[n2];
              if (s2.has(t3.lane)) continue;
              let l2 = i2.get(t3.lane);
              if (null == l2 || t3.end > l2.end ? i2.set(t3.lane, t3) : t3.end < l2.end && s2.set(t3.lane, true), s2.size === this.options.lanes)
                break;
            }
            return i2.size === this.options.lanes ? Array.from(i2.values()).sort((e4, t3) => e4.end === t3.end ? e4.index - t3.index : e4.end - t3.end)[0] : void 0;
          }, this.getMeasurementOptions = l(
            () => [
              this.options.count,
              this.options.paddingStart,
              this.options.scrollMargin,
              this.options.getItemKey,
              this.options.enabled
            ],
            (e3, t2, s2, i2, n2) => (this.pendingMeasuredCacheIndexes = [], { count: e3, paddingStart: t2, scrollMargin: s2, getItemKey: i2, enabled: n2 }),
            { key: false }
          ), this.getMeasurements = l(
            () => [this.getMeasurementOptions(), this.itemSizeCache],
            ({ count: e3, paddingStart: t2, scrollMargin: s2, getItemKey: i2, enabled: n2 }, l2) => {
              if (!n2) return this.measurementsCache = [], this.itemSizeCache.clear(), [];
              0 === this.measurementsCache.length && (this.measurementsCache = this.options.initialMeasurementsCache, this.measurementsCache.forEach((e4) => {
                this.itemSizeCache.set(e4.key, e4.size);
              }));
              let o2 = this.pendingMeasuredCacheIndexes.length > 0 ? Math.min(...this.pendingMeasuredCacheIndexes) : 0;
              this.pendingMeasuredCacheIndexes = [];
              let r2 = this.measurementsCache.slice(0, o2);
              for (let n3 = o2; n3 < e3; n3++) {
                let e4 = i2(n3), o3 = 1 === this.options.lanes ? r2[n3 - 1] : this.getFurthestMeasurement(r2, n3), h2 = o3 ? o3.end + this.options.gap : t2 + s2, a2 = l2.get(e4), d2 = "number" == typeof a2 ? a2 : this.options.estimateSize(n3), u2 = h2 + d2, c2 = o3 ? o3.lane : n3 % this.options.lanes;
                r2[n3] = { index: n3, start: h2, size: d2, end: u2, key: e4, lane: c2 };
              }
              return this.measurementsCache = r2, r2;
            },
            { key: false, debug: () => this.options.debug }
          ), this.calculateRange = l(
            () => [this.getMeasurements(), this.getSize(), this.getScrollOffset(), this.options.lanes],
            (e3, t2, s2, i2) => this.range = e3.length > 0 && t2 > 0 ? (function({ measurements: e4, outerSize: t3, scrollOffset: s3, lanes: i3 }) {
              let n2 = e4.length - 1, l2 = S(0, n2, (t4) => e4[t4].start, s3), o2 = l2;
              if (1 === i3) for (; o2 < n2 && e4[o2].end < s3 + t3; ) o2++;
              else if (i3 > 1) {
                let r2 = Array(i3).fill(0);
                for (; o2 < n2 && r2.some((e5) => e5 < s3 + t3); ) {
                  let t4 = e4[o2];
                  r2[t4.lane] = t4.end, o2++;
                }
                let h2 = Array(i3).fill(s3 + t3);
                for (; l2 > 0 && h2.some((e5) => e5 >= s3); ) {
                  let t4 = e4[l2];
                  h2[t4.lane] = t4.start, l2--;
                }
                l2 = Math.max(0, l2 - l2 % i3), o2 = Math.min(n2, o2 + (i3 - 1 - o2 % i3));
              }
              return { startIndex: l2, endIndex: o2 };
            })({ measurements: e3, outerSize: t2, scrollOffset: s2, lanes: i2 }) : null,
            { key: false, debug: () => this.options.debug }
          ), this.getVirtualIndexes = l(
            () => {
              let e3 = null, t2 = null, s2 = this.calculateRange();
              return s2 && (e3 = s2.startIndex, t2 = s2.endIndex), this.maybeNotify.updateDeps([this.isScrolling, e3, t2]), [this.options.rangeExtractor, this.options.overscan, this.options.count, e3, t2];
            },
            (e3, t2, s2, i2, n2) => null === i2 || null === n2 ? [] : e3({ startIndex: i2, endIndex: n2, overscan: t2, count: s2 }),
            { key: false, debug: () => this.options.debug }
          ), this.indexFromElement = (e3) => {
            let t2 = this.options.indexAttribute, s2 = e3.getAttribute(t2);
            return s2 ? parseInt(s2, 10) : (console.warn(`Missing attribute name '${t2}={index}' on measured element.`), -1);
          }, this._measureElement = (e3, t2) => {
            let s2 = this.indexFromElement(e3), i2 = this.measurementsCache[s2];
            if (!i2) return;
            let n2 = i2.key, l2 = this.elementsCache.get(n2);
            l2 !== e3 && (l2 && this.observer.unobserve(l2), this.observer.observe(e3), this.elementsCache.set(n2, e3)), e3.isConnected && this.resizeItem(s2, this.options.measureElement(e3, t2, this));
          }, this.resizeItem = (e3, t2) => {
            var _a;
            let s2 = this.measurementsCache[e3];
            if (!s2) return;
            let i2 = t2 - ((_a = this.itemSizeCache.get(s2.key)) != null ? _a : s2.size);
            0 !== i2 && ((void 0 !== this.shouldAdjustScrollPositionOnItemSizeChange ? this.shouldAdjustScrollPositionOnItemSizeChange(s2, i2, this) : s2.start < this.getScrollOffset() + this.scrollAdjustments) && this._scrollToOffset(this.getScrollOffset(), {
              adjustments: this.scrollAdjustments += i2,
              behavior: void 0
            }), this.pendingMeasuredCacheIndexes.push(s2.index), this.itemSizeCache = new Map(this.itemSizeCache.set(s2.key, t2)), this.notify(false));
          }, this.measureElement = (e3) => {
            if (!e3)
              return void this.elementsCache.forEach((e4, t2) => {
                e4.isConnected || (this.observer.unobserve(e4), this.elementsCache.delete(t2));
              });
            this._measureElement(e3, void 0);
          }, this.getVirtualItems = l(
            () => [this.getVirtualIndexes(), this.getMeasurements()],
            (e3, t2) => {
              let s2 = [];
              for (let i2 = 0, n2 = e3.length; i2 < n2; i2++) {
                let n3 = t2[e3[i2]];
                s2.push(n3);
              }
              return s2;
            },
            { key: false, debug: () => this.options.debug }
          ), this.getVirtualItemForOffset = (e3) => {
            let t2 = this.getMeasurements();
            if (0 !== t2.length) return o(t2[S(0, t2.length - 1, (e4) => o(t2[e4]).start, e3)]);
          }, this.getOffsetForAlignment = (e3, t2, s2 = 0) => {
            let i2 = this.getSize(), n2 = this.getScrollOffset();
            "auto" === t2 && (t2 = e3 >= n2 + i2 ? "end" : "start"), "center" === t2 ? e3 += (s2 - i2) / 2 : "end" === t2 && (e3 -= i2);
            let l2 = this.options.horizontal ? "scrollWidth" : "scrollHeight";
            return Math.max(
              Math.min(
                (this.scrollElement ? "document" in this.scrollElement ? this.scrollElement.document.documentElement[l2] : this.scrollElement[l2] : 0) - i2,
                e3
              ),
              0
            );
          }, this.getOffsetForIndex = (e3, t2 = "auto") => {
            e3 = Math.max(0, Math.min(e3, this.options.count - 1));
            let s2 = this.measurementsCache[e3];
            if (!s2) return;
            let i2 = this.getSize(), n2 = this.getScrollOffset();
            if ("auto" === t2)
              if (s2.end >= n2 + i2 - this.options.scrollPaddingEnd) t2 = "end";
              else {
                if (!(s2.start <= n2 + this.options.scrollPaddingStart)) return [n2, t2];
                t2 = "start";
              }
            let l2 = "end" === t2 ? s2.end + this.options.scrollPaddingEnd : s2.start - this.options.scrollPaddingStart;
            return [this.getOffsetForAlignment(l2, t2, s2.size), t2];
          }, this.isDynamicMode = () => this.elementsCache.size > 0, this.cancelScrollToIndex = () => {
            null !== this.scrollToIndexTimeoutId && this.targetWindow && (this.targetWindow.clearTimeout(this.scrollToIndexTimeoutId), this.scrollToIndexTimeoutId = null);
          }, this.scrollToOffset = (e3, { align: t2 = "start", behavior: s2 } = {}) => {
            this.cancelScrollToIndex(), "smooth" === s2 && this.isDynamicMode() && console.warn("The `smooth` scroll behavior is not fully supported with dynamic size."), this._scrollToOffset(this.getOffsetForAlignment(e3, t2), { adjustments: void 0, behavior: s2 });
          }, this.scrollToIndex = (e3, { align: t2 = "auto", behavior: s2 } = {}) => {
            e3 = Math.max(0, Math.min(e3, this.options.count - 1)), this.cancelScrollToIndex(), "smooth" === s2 && this.isDynamicMode() && console.warn("The `smooth` scroll behavior is not fully supported with dynamic size.");
            let i2 = this.getOffsetForIndex(e3, t2);
            if (!i2) return;
            let [n2, l2] = i2;
            this._scrollToOffset(n2, { adjustments: void 0, behavior: s2 }), "smooth" !== s2 && this.isDynamicMode() && this.targetWindow && (this.scrollToIndexTimeoutId = this.targetWindow.setTimeout(() => {
              if (this.scrollToIndexTimeoutId = null, this.elementsCache.has(this.options.getItemKey(e3))) {
                let [t3] = o(this.getOffsetForIndex(e3, l2));
                1 > Math.abs(t3 - this.getScrollOffset()) || this.scrollToIndex(e3, { align: l2, behavior: s2 });
              } else this.scrollToIndex(e3, { align: l2, behavior: s2 });
            }));
          }, this.scrollBy = (e3, { behavior: t2 } = {}) => {
            this.cancelScrollToIndex(), "smooth" === t2 && this.isDynamicMode() && console.warn("The `smooth` scroll behavior is not fully supported with dynamic size."), this._scrollToOffset(this.getScrollOffset() + e3, { adjustments: void 0, behavior: t2 });
          }, this.getTotalSize = () => {
            var _a;
            var e3;
            let t2, s2 = this.getMeasurements();
            if (0 === s2.length) t2 = this.options.paddingStart;
            else if (1 === this.options.lanes) t2 = (_a = null == (e3 = s2[s2.length - 1]) ? void 0 : e3.end) != null ? _a : 0;
            else {
              let e4 = Array(this.options.lanes).fill(null), i2 = s2.length - 1;
              for (; i2 > 0 && e4.some((e5) => null === e5); ) {
                let t3 = s2[i2];
                null === e4[t3.lane] && (e4[t3.lane] = t3.end), i2--;
              }
              t2 = Math.max(...e4.filter((e5) => null !== e5));
            }
            return Math.max(t2 - this.options.scrollMargin + this.options.paddingEnd, 0);
          }, this._scrollToOffset = (e3, { adjustments: t2, behavior: s2 }) => {
            this.options.scrollToFn(e3, { behavior: s2, adjustments: t2 }, this);
          }, this.measure = () => {
            this.itemSizeCache = /* @__PURE__ */ new Map(), this.notify(false);
          }, this.setOptions(e2);
        }
      }
      let S = (e2, t2, s2, i2) => {
        for (; e2 <= t2; ) {
          let n2 = (e2 + t2) / 2 | 0, l2 = s2(n2);
          if (l2 < i2) e2 = n2 + 1;
          else {
            if (!(l2 > i2)) return n2;
            t2 = n2 - 1;
          }
        }
        return e2 > 0 ? e2 - 1 : 0;
      }, w = "undefined" != typeof document ? i.useLayoutEffect : i.useEffect;
      function x(e2) {
        let t2 = i.useReducer(() => ({}), {})[1], s2 = {
          ...e2,
          onChange: (s3, i2) => {
            var l3;
            i2 ? (0, n.flushSync)(t2) : t2(), null == (l3 = e2.onChange) || l3.call(e2, s3, i2);
          }
        }, [l2] = i.useState(() => new E(s2));
        return l2.setOptions(s2), w(() => l2._didMount(), []), w(() => l2._willUpdate()), l2;
      }
      function y(e2) {
        return x({ observeElementRect: d, observeElementOffset: f, scrollToFn: b, ...e2 });
      }
      function M(e2) {
        return x({
          getScrollElement: () => "undefined" != typeof document ? window : null,
          observeElementRect: c,
          observeElementOffset: g,
          scrollToFn: v,
          initialOffset: () => "undefined" != typeof document ? window.scrollY : 0,
          ...e2
        });
      }
    }
  }
]);
