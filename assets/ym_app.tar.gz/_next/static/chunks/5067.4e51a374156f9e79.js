(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [5067, 7533],
  {
    7533: (e, t, n) => {
      "use strict";
      n.r(t), n.d(t, { VibeFallbackAnimation: () => m, VibeFallbackAnimationComponent: () => v });
      var i = n(54486), r = n(50420), l = n(28303), a = n(61910), o = n(31500), s = n(74125), u = n(49124);
      let c = (e2, t2) => {
        let n2 = u.env.ASSET_PREFIX || "";
        return "".concat(n2, "/media/vibe_animation_fallback/vibe_animation_fallback_").concat(e2, ".").concat(t2);
      };
      var d = n(68290), f = n.n(d);
      let v = (0, l.PA)((e2) => {
        var t2, n2;
        let { forwardRef: l2, className: u2 } = e2, d2 = (0, a.useRef)(null), { theme: v2 } = (0, s.DPo)(), { sonataState: m2 } = (0, s.Pjs)(), _ = m2.isPlaying && m2.isVibeContext;
        (0, a.useEffect)(() => {
          var e3, t3, n3;
          let i2 = null != (n3 = null == (t3 = m2.entityMeta) || null == (e3 = t3.trackParameters) ? void 0 : e3.energy) ? n3 : 1;
          d2.current && (d2.current.playbackRate = _ ? Math.max(1.5 * i2, 1) : 0.8);
        }, [_, null == (n2 = m2.entityMeta) || null == (t2 = n2.trackParameters) ? void 0 : t2.energy]);
        let p = (0, a.useMemo)(
          () => ((e3) => {
            if (e3) return { posterSrc: c(e3, "jpeg"), videoSrc: c(e3, "mp4") };
          })(v2),
          [v2]
        );
        return (0, i.jsxs)("div", {
          ref: l2,
          className: (0, r.$)(f().root, f().root_visible, u2),
          ...(0, o.Am)(o.Kq.vibeAnimation.VIBE_ANIMATION),
          children: [
            (0, i.jsx)("video", {
              ref: d2,
              preload: "metadata",
              loop: true,
              autoPlay: true,
              muted: true,
              playsInline: true,
              disablePictureInPicture: true,
              width: 1e3,
              height: 1e3,
              src: null == p ? void 0 : p.videoSrc,
              poster: null == p ? void 0 : p.posterSrc
            }),
            (0, i.jsx)("div", {})
          ]
        });
      }), m = (0, a.forwardRef)((e2, t2) => (0, i.jsx)(v, { forwardRef: t2, ...e2 }));
    },
    45067: (e, t, n) => {
      "use strict";
      n.r(t), n.d(t, { VibeAnimation: () => q });
      var i, r, l = n(54486), a = n(28303), o = n(61910), s = n(8197), u = n(68173), c = n(35948), d = { out: "out-in", in: "in-out" }, f = function(e2, t2, n2) {
        return function() {
          var i2;
          e2.props[t2] && (i2 = e2.props)[t2].apply(i2, arguments), n2();
        };
      }, v = ((i = {})[d.out] = function(e2) {
        var t2 = e2.current, n2 = e2.changeState;
        return o.cloneElement(t2, {
          in: false,
          onExited: f(t2, "onExited", function() {
            n2(u.ns, null);
          })
        });
      }, i[d.in] = function(e2) {
        var t2 = e2.current, n2 = e2.changeState, i2 = e2.children;
        return [
          t2,
          o.cloneElement(i2, {
            in: true,
            onEntered: f(i2, "onEntered", function() {
              n2(u.ns);
            })
          })
        ];
      }, i), m = ((r = {})[d.out] = function(e2) {
        var t2 = e2.children, n2 = e2.changeState;
        return o.cloneElement(t2, {
          in: true,
          onEntered: f(t2, "onEntered", function() {
            n2(u._K, o.cloneElement(t2, { in: true }));
          })
        });
      }, r[d.in] = function(e2) {
        var t2 = e2.current, n2 = e2.children, i2 = e2.changeState;
        return [
          o.cloneElement(t2, {
            in: false,
            onExited: f(t2, "onExited", function() {
              i2(u._K, o.cloneElement(n2, { in: true }));
            })
          }),
          o.cloneElement(n2, { in: true })
        ];
      }, r), _ = (function(e2) {
        function t2() {
          for (var t3, n3 = arguments.length, i2 = Array(n3), r2 = 0; r2 < n3; r2++) i2[r2] = arguments[r2];
          return (t3 = e2.call.apply(e2, [this].concat(i2)) || this).state = { status: u._K, current: null }, t3.appeared = false, t3.changeState = function(e3, n4) {
            void 0 === n4 && (n4 = t3.state.current), t3.setState({ status: e3, current: n4 });
          }, t3;
        }
        (0, s.A)(t2, e2);
        var n2 = t2.prototype;
        return n2.componentDidMount = function() {
          this.appeared = true;
        }, t2.getDerivedStateFromProps = function(e3, t3) {
          var n3, i2;
          return null == e3.children ? { current: null } : t3.status === u.ns && e3.mode === d.in ? { status: u.ns } : t3.current && !((n3 = t3.current) === (i2 = e3.children) || o.isValidElement(n3) && o.isValidElement(i2) && null != n3.key && n3.key === i2.key) && 1 ? { status: u.ze } : { current: o.cloneElement(e3.children, { in: true }) };
        }, n2.render = function() {
          var e3, t3 = this.props, n3 = t3.children, i2 = t3.mode, r2 = this.state, l2 = r2.status, a2 = r2.current, s2 = { children: n3, current: a2, changeState: this.changeState, status: l2 };
          switch (l2) {
            case u.ns:
              e3 = m[i2](s2);
              break;
            case u.ze:
              e3 = v[i2](s2);
              break;
            case u._K:
              e3 = a2;
          }
          return o.createElement(c.A.Provider, { value: { isMounting: !this.appeared } }, e3);
        }, t2;
      })(o.Component);
      _.propTypes = {}, _.defaultProps = { mode: d.out };
      var p = n(63664), b = n(8817), h = n(27510), g = n(74125), E = n(29444), x = n(47713), y = n(5956), k = n(97800), A = n(80585), M = n(63050), P = n.n(M);
      let V = (0, a.PA)((e2) => {
        let { closeToast: t2 } = e2, { fullscreenPlayer: n2 } = (0, g.Pjs)(), i2 = (0, o.useCallback)(() => {
          n2.modal.isOpened && n2.modal.close();
        }, [n2]), r2 = (0, o.useMemo)(
          () => (0, l.jsxs)("div", {
            className: P().message,
            children: [
              (0, l.jsx)(k.Caption, {
                className: P().title,
                variant: "div",
                type: "controls",
                size: "m",
                children: (0, l.jsx)(x.A, { id: "lite-version.notification-title" })
              }),
              (0, l.jsx)(A.N_, {
                className: P().link,
                href: g.Zyd.settings.href,
                onClick: i2,
                children: (0, l.jsx)(k.Caption, {
                  className: P().linkText,
                  variant: "div",
                  type: "controls",
                  size: "m",
                  children: (0, l.jsx)(x.A, { id: "lite-version.go-to-settings" })
                })
              })
            ]
          }),
          [i2]
        );
        return (0, l.jsx)(A.$W, {
          cover: (0, l.jsx)(y.Icon, { className: P().icon, size: "xs", variant: "liteVersion" }),
          message: r2,
          closeToast: t2,
          coverRadius: "s"
        });
      }), j = "vibeAnimationDegradationLevel", L = null;
      var N = n(68290), S = n.n(N), R = n(7533), T = n(50420), w = n(31500), I = n(67648), C = n(63585), F = n(77881), D = n(19009), U = n(80246), K = n.n(U);
      let O = (0, a.PA)((e2) => {
        var t2, n2, i2, r2, a2, s2, u2, c2;
        let { vibeAnimationState: d2, isIntersecting: f2, forwardRef: v2, className: m2 } = e2, [_2, p2] = (0, I.d)(), [h2, x2] = (0, I.d)(), [y2, k2] = (0, I.d)(), [A2, M2] = (0, o.useState)(false), { user: P2, sonataState: V2, settings: j2 } = (0, g.Pjs)(), L2 = (0, g.UlF)(), { theme: N2 } = (0, g.DPo)(), F2 = (0, g.iIU)(), D2 = (0, b.c)((e3) => {
          e3.data.type === E.iR.ERROR && (M2(true), L2.error(e3.data.payload));
        }), U2 = (0, b.c)(() => {
          M2(true);
        }), K2 = V2.isPlaying && V2.isVibeContext;
        ((e3) => {
          var t3, n3;
          let [i3, r3] = (0, o.useState)({}), { sonataState: l2 } = (0, g.Pjs)();
          (0, o.useEffect)(() => {
            if (l2.contextType === C.K.Vibe) {
              var t4, n4, a3, o2;
              i3.id === (null == (t4 = l2.entityMeta) ? void 0 : t4.id) && !i3.isLiked && (null == (o2 = l2.entityMeta) ? void 0 : o2.isLiked) && e3(), r3({
                id: null == (n4 = l2.entityMeta) ? void 0 : n4.id,
                isLiked: null == (a3 = l2.entityMeta) ? void 0 : a3.isLiked
              });
            }
          }, [
            l2.contextType,
            null == (t3 = l2.entityMeta) ? void 0 : t3.id,
            null == (n3 = l2.entityMeta) ? void 0 : n3.isLiked,
            i3.id,
            i3.isLiked,
            e3
          ]);
        })(
          (0, b.c)(() => {
            null == _2 || _2.likeAnimation();
          })
        );
        let O2 = (0, b.c)(() => {
          if (!(null == F2 ? void 0 : F2.analyser)) return;
          let [e3, t3, n3] = F2.analyser.getAverageFrequencies([
            { low: 0, high: 250 },
            { low: 500, high: 2e3 },
            { low: 2e3, high: 4e3 }
          ]);
          null == _2 || _2.updateAudioFrequencies({ low: null != e3 ? e3 : 0, middle: null != t3 ? t3 : 0, high: null != n3 ? n3 : 0 });
        });
        (0, o.useEffect)(() => {
          var e3, t3;
          if (!h2 || _2) return;
          if (!h2.transferControlToOffscreen) return void U2();
          let n3 = h2.transferControlToOffscreen(), i3 = new E.a6({
            offscreenCanvas: n3,
            state: d2,
            collectionHue: P2.collectionHue,
            shaderOptions: void 0,
            onMessage: D2,
            onError: U2
          });
          p2(i3), k2(new E.Rv(E.p4, O2));
          let r3 = null == (t3 = V2.entityMeta) || null == (e3 = t3.trackParameters) ? void 0 : e3.hue, l2 = P2.collectionHue;
          i3.applySettings({ hue: r3, collectionHue: l2 });
        }, [
          y2,
          h2,
          U2,
          D2,
          k2,
          p2,
          null == (n2 = V2.entityMeta) || null == (t2 = n2.trackParameters) ? void 0 : t2.hue,
          O2,
          P2.collectionHue,
          d2,
          _2
        ]);
        let H2 = (0, b.c)(() => {
          null == _2 || _2.destroy(), p2(null), null == y2 || y2.stop(), k2(null);
        });
        return ((0, o.useEffect)(
          () => () => {
            H2();
          },
          [H2]
        ), (0, o.useEffect)(() => {
          f2 && K2 ? null == y2 || y2.start() : null == y2 || y2.stop();
        }, [y2, f2, K2, _2]), (0, o.useEffect)(() => {
          if (_2) {
            let e3 = N2 === g.Sxu.Dark ? 0.0705 : 0.9607;
            null == _2 || _2.applySettings({ backgroundColor: e3 });
          }
        }, [N2, _2]), (0, o.useEffect)(() => {
          var e3, t3, n3, i3, r3, l2;
          let a3 = null == (t3 = V2.entityMeta) || null == (e3 = t3.trackParameters) ? void 0 : e3.hue, o2 = null == (i3 = V2.entityMeta) || null == (n3 = i3.trackParameters) ? void 0 : n3.energy, s3 = null == (l2 = V2.entityMeta) || null == (r3 = l2.trackParameters) ? void 0 : r3.userCollectionHue;
          s3 && P2.setUserCollectionHue(s3), K2 ? null == _2 || _2.playAnimation({ hue: a3, energy: o2, collectionHue: s3 }) : null == _2 || _2.idleAnimation();
        }, [
          K2,
          null == (r2 = V2.entityMeta) || null == (i2 = r2.trackParameters) ? void 0 : i2.energy,
          null == (s2 = V2.entityMeta) || null == (a2 = s2.trackParameters) ? void 0 : a2.hue,
          null == (c2 = V2.entityMeta) || null == (u2 = c2.trackParameters) ? void 0 : u2.userCollectionHue,
          P2,
          _2
        ]), (0, o.useEffect)(() => {
          f2 ? null == _2 || _2.enable() : null == _2 || _2.disable();
        }, [f2, _2]), (0, o.useEffect)(() => {
          null == _2 || _2.updateLayout(j2.isMobile);
        }, [j2.isMobile, _2]), (0, o.useEffect)(() => {
          d2 === E.IU.LITE && (null == _2 || _2.enableLiteAnimation());
        }, [d2, _2]), A2) ? (0, l.jsx)(R.VibeFallbackAnimation, { ref: v2, className: m2 }) : (0, l.jsxs)(l.Fragment, {
          children: [
            (0, l.jsx)("div", {
              ref: v2,
              className: (0, T.$)(S().root, m2),
              ...(0, w.Am)(w.Kq.vibeAnimation.VIBE_ANIMATION),
              children: (0, l.jsx)("canvas", { ref: x2 })
            }),
            false
          ]
        });
      }), H = (0, o.forwardRef)((e2, t2) => (0, l.jsx)(O, { forwardRef: t2, ...e2 })), z = {
        enter: S().enter,
        enterActive: S().enter_active,
        enterDone: S().enter_done,
        exit: S().exit,
        exitActive: S().exit_active,
        exitDone: S().exit_done
      }, q = (0, a.PA)((e2) => {
        let { isIntersecting: t2 = true, className: n2 } = e2, i2 = (0, o.useRef)(null), r2 = (0, o.useRef)(null), [a2, s2] = (0, o.useState)(false), { experiments: u2, settings: c2 } = (0, g.Pjs)();
        (() => {
          let e3 = (0, g.NFA)().get(g.vgk), t3 = (0, o.useRef)(true);
          (0, o.useEffect)(() => {
            if (!t3.current) return;
            let n3 = document.createElement("canvas");
            try {
              let i3 = n3.getContext("webgl2") || n3.getContext("webgl");
              if (!i3) return;
              let r3 = i3.getExtension("WEBGL_debug_renderer_info");
              if (!r3) return;
              let l2 = i3.getParameter(r3.UNMASKED_RENDERER_WEBGL);
              l2 && (e3.count(l2, "gpuRenderer"), t3.current = false);
            } catch (e4) {
            }
            n3.remove();
          }, [e3]);
        })();
        let d2 = (0, b.c)(() => {
          s2("visible" === document.visibilityState);
        });
        (0, o.useEffect)(
          () => (d2(), document.addEventListener("visibilitychange", d2), () => {
            document.removeEventListener("visibilitychange", d2);
          }),
          [d2]
        );
        let f2 = u2.checkExperiment(g.zal.WebNextLiteVersion, "on"), v2 = c2.isLiteVersionModeEnabled, { isFallback: m2, vibeAnimationState: x2 } = ((e3) => {
          let { isEnabled: t3 } = e3, n3 = (0, o.useRef)(0), i3 = (0, g.NFA)(), { notify: r3 } = (0, g.lkh)(), { settings: a3 } = (0, g.Pjs)(), [s3, u3] = (0, o.useState)(false), [c3, d3] = (0, o.useState)(E.IU.DEFAULT), f3 = i3.get(g.vgk), v3 = (0, o.useMemo)(() => (L || (L = new E.Qq()), L), []), m3 = (0, b.c)((e4) => {
            var t4, i4;
            if (null == (i4 = window.Ya) || null == (t4 = i4.Rum) || t4.sendTimeMark("my-vibe-animation-fps", e4.toFixed(1)), e4 >= 20) {
              n3.current = 0;
              return;
            }
            if (n3.current++, !(n3.current < 3)) {
              if (n3.current = 0, c3 !== E.IU.LITE) {
                d3(E.IU.LITE), f3.count("liteAnimation", j);
                return;
              }
              s3 || (u3(true), f3.count("fallback", j), a3.setLiteVersionMode(g.wv5.ENABLED, true), r3((0, l.jsx)(V, {}), { containerId: g.uQT.INFO, autoClose: false }));
            }
          });
          return (0, o.useEffect)(
            () => (a3.isLiteVersionModeAvailableForToggle || !t3 || s3 ? (v3.stopMeasuring(), n3.current = 0) : v3.startMeasuring(m3), () => {
              v3.stopMeasuring();
            }),
            [v3, m3, t3, s3, a3.isLiteVersionModeAvailableForToggle]
          ), { isFallback: s3, vibeAnimationState: c3 };
        })({ isEnabled: f2 && a2 && t2 }), y2 = m2 || f2 && v2 || "undefined" == typeof Worker, k2 = (0, h.L)(
          () => y2 ? (0, l.jsx)(R.VibeFallbackAnimation, { ref: r2, className: n2 }) : (0, l.jsx)(H, { ref: i2, vibeAnimationState: x2, isIntersecting: a2 && t2, className: n2 })
        );
        return (0, l.jsx)(_, {
          mode: "out-in",
          children: (0, l.jsx)(
            p.A,
            { nodeRef: y2 ? r2 : i2, timeout: 1e3, appear: true, classNames: z, children: k2 },
            y2 ? "fallback" : "shader"
          )
        });
      });
    },
    63050: (e) => {
      e.exports = {
        message: "NotificationLiteVersion_message__IT6FA",
        icon: "NotificationLiteVersion_icon__T4E8d",
        title: "NotificationLiteVersion_title__UPCcu",
        linkText: "NotificationLiteVersion_linkText__L6r3P",
        link: "NotificationLiteVersion_link__cQUUY"
      };
    },
    68290: (e) => {
      e.exports = {
        root: "VibeAnimation_root__UKMJy",
        root_visible: "VibeAnimation_root_visible__S7kXl",
        enter: "VibeAnimation_enter__c6tvj",
        enter_active: "VibeAnimation_enter_active__j0jOl",
        enter_done: "VibeAnimation_enter_done__Oi2Kz",
        exit: "VibeAnimation_exit__ioGXk",
        exit_active: "VibeAnimation_exit_active__D94vP",
        exit_done: "VibeAnimation_exit_done__LDXSJ"
      };
    },
    80246: (e) => {
      e.exports = { root: "VibeDebugPanel_root__97HZQ", forceTop: "VibeDebugPanel_forceTop__VY0oQ" };
    }
  }
]);
