(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [5164],
  {
    7021: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "ClipCard_root__kzWjg",
        view: "ClipCard_view__MYSwA",
        playButton: "ClipCard_playButton__0Wyss",
        duration: "ClipCard_duration__89ZCx",
        image: "ClipCard_image__hSUud",
        media: "ClipCard_media__dU4RM",
        cover: "ClipCard_cover__ztEok",
        unavailableCover: "ClipCard_unavailableCover__Zd9jl",
        cover_withoutOffset: "ClipCard_cover_withoutOffset__aasE2",
        title: "ClipCard_title__I1s7Q",
        artistLink: "ClipCard_artistLink__t6oPP",
        titleLink: "ClipCard_titleLink__g3HDM",
        version: "ClipCard_version__w9PM7"
      };
    },
    15091: (e, t, a) => {
      "use strict";
      a.d(t, { useGenerativeActions: () => p });
      var i = a(54486), n = a(61910), s = a(43426), l = a(11036), o = a(59553), r = a(8817), c = a(95424), d = a(74125), u = a(80585);
      let p = () => {
        let {
          sonataState: { entityMeta: e2 },
          user: t2,
          fullscreenPlayer: a2
        } = (0, d.Pjs)(), p2 = (0, d.eGp)(), { notify: m } = (0, d.lkh)(), { formatMessage: C } = (0, s.A)(), [_, v] = (0, n.useState)(false), { state: x, handleDebouncedToggle: h, reset: f } = (0, c.F)({ delay: 1e4, throttleTimeout: 0 }), { state: g, handleDebouncedToggle: N, reset: b } = (0, c.F)({ delay: 1e4, throttleTimeout: 0 }), I = (0, r.c)(() => {
          f(), b();
        });
        (0, n.useEffect)(() => {
          (null == e2 ? void 0 : e2.id) && I();
        }, [null == e2 ? void 0 : e2.id, I]);
        let y = (0, r.c)(async (n2) => {
          if (_ || !e2 || !p2) return;
          if (!t2.isAuthorized) {
            let e3 = a2.modal.isOpened ? d.uQT.FULLSCREEN_ERROR : d.uQT.ERROR;
            m((0, i.jsx)(u.hT, { error: C({ id: "authorization-messages.need-to-authorizate" }) }), { containerId: e3 });
            return;
          }
          let s2 = p2.getState(), r2 = p2.playbackController.getPlayback();
          if (s2 && r2 && (0, l.S)(s2.currentContext.value)) {
            v(true);
            try {
              switch (n2) {
                case o.Q.TimestampLike:
                  b(), h();
                  break;
                case o.Q.TimestampDislike:
                  f(), N();
              }
              let t3 = s2.currentContext.value.restartsCount;
              s2.queueState.entityList.value.find((t4) => {
                var a3, i2;
                let { entity: n3 } = t4;
                return (null == (i2 = n3.data) || null == (a3 = i2.meta) ? void 0 : a3.id) === e2.id;
              }) && await s2.currentContext.value.sendFeedback(n2, r2), s2.currentContext.value.restartsCount > t3 && I();
            } catch (t3) {
              I();
              let e3 = a2.modal.isOpened ? d.uQT.FULLSCREEN_ERROR : d.uQT.ERROR;
              m((0, i.jsx)(u.hT, { error: C({ id: "error-messages.error-during-action" }) }), { containerId: e3 });
            } finally {
              v(false);
            }
          }
        });
        return {
          isGenerativeLiked: x,
          isGenerativeDisliked: g,
          onGenerativeLikeClick: (0, r.c)(() => y(o.Q.TimestampLike)),
          onGenerativeDislikeClick: (0, r.c)(() => y(o.Q.TimestampDislike))
        };
      };
    },
    15647: (e) => {
      e.exports = {
        icon: "NotificationRepeat_icon__WCf4_",
        message: "NotificationRepeat_message__jCngy",
        icon_unset: "NotificationRepeat_icon_unset__z2fmU"
      };
    },
    16045: (e, t, a) => {
      "use strict";
      a.d(t, { RepeatButton: () => m });
      var i = a(54486), n = a(50420), s = a(43426), l = a(31500), o = a(3269), r = a(8817), c = a(77881), d = a(5956), u = a(74890), p = a.n(u);
      let m = (e2) => {
        let {
          isDisabled: t2,
          repeatMode: a2,
          className: u2,
          iconClassName: m2,
          size: C = "xxxs",
          iconSize: _ = "xs",
          color: v,
          variant: x = "default",
          onClick: h
        } = e2, { formatMessage: f } = (0, s.A)(), g = t2 || a2 !== o.pM.ONE ? "repeat" : "repeat_one", N = ((e3, t3, a3) => t3(
          e3 === o.pM.NONE || a3 ? { id: "player-actions.repeat" } : e3 === o.pM.ONE ? { id: "player-actions.repeat-one" } : { id: "player-actions.repeat-context" }
        ))(a2, f, t2), b = (0, r.c)((e3) => {
          null == h || h(), e3.stopPropagation();
        });
        return (0, i.jsx)(c.$, {
          className: u2,
          radius: "round",
          size: C,
          variant: x,
          color: v,
          disabled: t2,
          withRipple: false,
          "aria-hidden": t2,
          "aria-label": N,
          "aria-pressed": !t2 && a2 !== o.pM.NONE,
          onClick: b,
          icon: (0, i.jsx)(d.Icon, {
            size: _,
            variant: g,
            className: (0, n.$)(p().repeatIcon, p()["repeatIcon_".concat(a2)], { [p().repeatIcon_disabled]: t2 }, m2)
          }),
          ...(0, l.Am)(
            ((e3, t3) => e3 === o.pM.NONE || t3 ? l.Kq.sonata.REPEAT_BUTTON_NO_REPEAT : e3 === o.pM.ONE ? l.Kq.sonata.REPEAT_BUTTON_REPEAT_ONE : l.Kq.sonata.REPEAT_BUTTON_REPEAT_CONTEXT)(a2, t2)
          )
        });
      };
    },
    20765: (e) => {
      e.exports = {
        root: "SonataFullscreenControlsDesktop_root__ZCIGk",
        sonataButtons: "SonataFullscreenControlsDesktop_sonataButtons__9y89g",
        sonataButton: "SonataFullscreenControlsDesktop_sonataButton__69FFc",
        sonataPlayButton: "SonataFullscreenControlsDesktop_sonataPlayButton__QXEEp",
        playPauseButtonIcon: "SonataFullscreenControlsDesktop_playPauseButtonIcon__IkUNX",
        playPauseButtonIcon_withYellowPlayButton: "SonataFullscreenControlsDesktop_playPauseButtonIcon_withYellowPlayButton__osz8_",
        buttonContainer: "SonataFullscreenControlsDesktop_buttonContainer__SpXWc"
      };
    },
    21050: (e, t, a) => {
      "use strict";
      a.d(t, { w: () => n });
      var i = a(89461);
      let n = [i.MT.PLAYING, i.MT.LOADING_MEDIA_SOURCE, i.MT.BUFFERING];
    },
    22017: (e, t, a) => {
      "use strict";
      a.d(t, { ClipContextMenu: () => C });
      var i = a(54486), n = a(28303), s = a(43426), l = a(47713), o = a(31500), r = a(8817), c = a(5956), d = a(61958), u = a(54830), p = a(74125), m = a(80585);
      let C = (0, n.PA)((e2) => {
        let { onOpenChange: t2, open: a2, placement: n2, isFullscreenMobile: C2 = false, icon: _, size: v, clip: x, ...h } = e2, { currentClipInfo: f, settings: g, user: N } = (0, p.Pjs)(), { formatMessage: b } = (0, s.A)(), { shareLink: I, pathname: y } = (0, p.bNS)(p.Zyd.video.href, { query: { ids: String(x.clipId) } }), S = C2 || g.isMobile;
        (0, p.NBO)(a2);
        let M = (0, u.KX)(x), A = (0, r.c)(() => {
          f.setClipId(x.clipId), f.modal.open();
        }), k = { variant: p.Yxq.CLIP, id: x.clipId, title: x.title, path: y };
        return (0, i.jsxs)(d.W1, {
          isMobile: S,
          placement: n2,
          offsetOptions: -10,
          open: a2,
          onOpenChange: t2,
          icon: _,
          size: v,
          containerProps: (0, o.Am)(o.Kq.clip.CLIP_CONTEXT_MENU),
          ariaLabel: b({ id: "interface-actions.context-menu" }),
          variant: "text",
          ...h,
          children: [
            (0, i.jsx)(m.TW, { onClick: M, isLiked: x.isLiked, disabled: !N.isAuthorized }),
            (0, i.jsx)(m.Ht, { shareLink: I, entityMeta: k }),
            (0, i.jsx)(d.Dr, {
              onClick: A,
              icon: (0, i.jsx)(c.Icon, { variant: "info", size: "xxs" }),
              ...(0, o.Am)(o.Kq.clip.CLIP_CONTEXT_MENU_ABOUT_TRACK_BUTTON),
              children: (0, i.jsx)(l.A, { id: "track-modal.clip-title" })
            })
          ]
        });
      });
    },
    23897: (e, t, a) => {
      "use strict";
      a.d(t, { useToggleMute: () => l });
      var i = a(61910), n = a(8817), s = a(74125);
      let l = () => {
        let e2 = (0, s.NFA)().get(s.ooW), t2 = (0, s.eGp)(), { advert: a2 } = (0, s.Pjs)(), l2 = (0, s.rs2)(), o = (0, n.c)(async (i2) => {
          let { sonataState: n2, volume: o2, playbackId: r } = i2;
          await (null == t2 ? void 0 : t2.setExponentVolume(o2, r)), e2.set(s.cYZ.YmPlayerVolume, o2, { expires: 365 }), a2.isAdvertShown && (null == l2 || l2.audioAdvertPlayback.setExponentVolume(o2), n2.setVolume(o2));
        });
        return (0, i.useCallback)(
          async (t3, a3, i2) => {
            if (0 !== a3)
              e2.set(s.cYZ.YmPlayerPrevVolume, a3, { expires: 365 }), await o({ sonataState: t3, volume: 0, playbackId: i2 });
            else {
              var n2;
              let a4 = null != (n2 = e2.get(s.cYZ.YmPlayerPrevVolume)) ? n2 : 1;
              e2.remove(s.cYZ.YmPlayerPrevVolume), await o({ sonataState: t3, volume: a4, playbackId: i2 });
            }
          },
          [e2, o]
        );
      };
    },
    26245: (e) => {
      e.exports = {
        root: "HorizontalClipCard_root__B_6yA",
        cover: "HorizontalClipCard_cover__vpEvl",
        unavailable: "HorizontalClipCard_unavailable__SILaB",
        duration: "HorizontalClipCard_duration__r1UFp"
      };
    },
    29476: (e, t, a) => {
      "use strict";
      a.d(t, { useOnShuffleClick: () => o });
      var i = a(54486), n = a(8817), s = a(74125), l = a(62915);
      let o = () => {
        let { notify: e2 } = (0, s.lkh)(), { fullscreenPlayer: t2 } = (0, s.Pjs)(), a2 = (0, s.eGp)();
        return (0, n.c)((n2, o2) => {
          null !== n2.entityMeta && n2.canShuffle && (null == a2 || a2.toggleShuffle(o2), e2(
            (0, i.jsx)(l.NotificationShuffle, {
              shuffle: !!(null == a2 ? void 0 : a2.getState(o2).queueState.shuffle.value)
            }),
            { containerId: t2.modal.isOpened ? s.uQT.FULLSCREEN_INFO : s.uQT.INFO }
          ));
        });
      };
    },
    32159: (e, t, a) => {
      "use strict";
      a.d(t, { ClipsCarouselContent: () => v });
      var i = a(54486), n = a(50420), s = a(28303), l = a(61910), o = a(9348), r = a(43350), c = a(81203), d = a(74125), u = a(57923), p = a(69597), m = a(73717), C = a.n(m);
      let _ = (0, s.PA)((e2) => {
        let {
          forwardRef: t2,
          clipCardTitleClassName: a2,
          clipCardArtistLinkClassName: s2,
          carouselItemClassName: m2,
          isShimmerVisible: _2,
          isShimmerActive: v2,
          containerClassName: x,
          artistIdWithoutLink: h,
          withVideo: f = true,
          clips: g,
          shouldOpenModalOnCardClick: N = true,
          itemCounter: b
        } = e2, I = (0, l.useId)(), y = (0, l.useRef)(String((0, o.A)())), S = (0, l.useMemo)(() => {
          if (_2) return Array.from({ length: 5 }, (e3, t3) => (0, i.jsx)(p.k, { isActive: v2 }, t3));
          return null == g ? void 0 : g.map(
            (e3, t3) => (0, i.jsx)(
              d.Bki,
              {
                objectType: r.ky.Video,
                objectPosX: t3 + 1,
                objectPosY: 1,
                objectsCount: null == g ? void 0 : g.length,
                objectId: String(e3.clipId),
                children: (0, i.jsx)(u.ClipCard, {
                  titleClassName: a2,
                  artistLinkClassName: s2,
                  clip: e3,
                  withVideo: f,
                  artistIdWithoutLink: h,
                  viewUuid: y.current,
                  shouldOpenModalOnCardClick: N
                })
              },
              e3.clipId
            )
          );
        }, [a2, s2, _2, v2, h, f, g, N]);
        return (0, i.jsx)(c.Carousel, {
          className: (0, n.$)(C().itemCounter, { [C()["itemCounter_".concat(b)]]: b }, x),
          ref: t2,
          itemClassName: (0, n.$)(C().item, C().important, m2),
          "aria-labelledby": I,
          children: S
        });
      }), v = (0, l.forwardRef)((e2, t2) => (0, i.jsx)(_, { forwardRef: t2, ...e2 }));
    },
    33506: (e, t, a) => {
      "use strict";
      a.d(t, { Z: () => v });
      var i = a(54486), n = a(28303), s = a(61910), l = a(8817), o = a(27510), r = a(74125), c = a(80585), d = a(63585), u = a(89461), p = a(83675), m = a(91129), C = a.n(m);
      let _ = { mainAxis: 44 }, v = (0, n.PA)((e2) => {
        let {
          disabled: t2,
          isPlaying: a2,
          repeatMode: n2,
          canMoveForward: m2,
          canMoveBackward: v2,
          canShuffle: x,
          shuffle: h,
          onClickNext: f,
          onClickPrev: g,
          onClickPlayPause: N,
          canChangeRepeatMode: b,
          className: I,
          withShuffle: y,
          withRepeat: S,
          onRepeatClick: M,
          onShuffleClick: A
        } = e2, {
          advert: k,
          modals: { popoverOverPlayer: E },
          paymentWidgetModal: P,
          user: w
        } = (0, r.Pjs)(), { isFreemium: T, hasFreeUserAccess: O } = (0, r.XCI)();
        (() => {
          let {
            sonataState: e3,
            modals: { popoverOverPlayer: t3 },
            user: a3
          } = (0, r.Pjs)(), { isPassToProduct: i2 } = (0, r.XCI)(), n3 = (0, r.eGp)(), l2 = e3.contextType === d.K.Generative;
          (0, s.useEffect)(() => {
            if (a3.isAuthorized && !i2 || l2) return;
            let e4 = null == n3 ? void 0 : n3.state.playerState.event.onChange((e5) => {
              e5 === u.Iu.PLAYING && t3.open();
            });
            return () => {
              null == e4 || e4();
            };
          }, [n3, t3, l2, i2, a3.isAuthorized]);
        })();
        let R = (0, s.useCallback)(
          () => (0, i.jsx)(c.DM, {
            className: C().sonataButton,
            iconSize: "l",
            variant: "filled",
            isPlaying: a2,
            iconClassName: C().playButtonIcon,
            onClick: N
          }),
          [a2, N]
        ), j = (0, l.c)((e3) => {
          e3 || E.close();
        }), L = (0, o.L)(() => {
          let e3 = T && w.isAuthorized ? "vibe" : "fullTracks";
          return w.isAuthorized ? P.modal.isOpened ? R() : (0, i.jsx)(c.SU, {
            isEnabled: O,
            isOpened: E.isOpened,
            placement: "top",
            onOpenChange: j,
            offsetOptions: _,
            textVariant: e3,
            renderChildren: R
          }) : (0, i.jsx)(c.Zr, {
            isEnabled: true,
            isOpened: E.isOpened,
            placement: "top",
            onOpenChange: j,
            offsetOptions: _,
            textVariant: e3,
            renderChildren: R
          });
        });
        return (0, i.jsx)(p.a, {
          isDisabledRepeat: !b || t2,
          isDisabledShuffle: !x || t2,
          withShuffle: (t2 || x) && !(null == k ? void 0 : k.isAdvertShown) || !!y,
          shuffle: h,
          canMoveBackward: v2,
          canMoveForward: m2,
          onClickNext: f,
          onClickPrev: g,
          withRepeat: (t2 || b) && !(null == k ? void 0 : k.isAdvertShown) || !!S,
          repeatMode: n2,
          className: I,
          playButton: L,
          onRepeatClick: M,
          onShuffleClick: A
        });
      });
    },
    34960: (e, t, a) => {
      "use strict";
      a.d(t, { R6: () => l, xf: () => n, nD: () => s.useGenerativeActions });
      var i = a(93064);
      let n = (e2) => {
        var t2, a2;
        return (0, i.wg)({
          title: e2.title,
          stationId: e2.stationId,
          imageUrl: e2.imageUrl,
          style: {
            backgroundColor: null == (t2 = e2.style) ? void 0 : t2.backgroundColor,
            titleColor: null == (a2 = e2.style) ? void 0 : a2.titleColor
          }
        });
      };
      var s = a(15091);
      let l = i.gK.model("NeuromusicItem", {
        title: i.gK.string,
        stationId: i.gK.string,
        imageUrl: i.gK.maybe(i.gK.string),
        style: i.gK.maybe(
          i.gK.model({ backgroundColor: i.gK.maybe(i.gK.string), titleColor: i.gK.maybe(i.gK.string) })
        )
      });
    },
    37863: (e) => {
      e.exports = {
        root: "ClipCardShimmer_root__sIvNr",
        cover: "ClipCardShimmer_cover__yA4jz",
        title: "ClipCardShimmer_title__MCApK",
        text: "ClipCardShimmer_text__ajZGv"
      };
    },
    40632: (e) => {
      e.exports = { root: "SonataControls_root__w8uqu" };
    },
    46521: (e) => {
      e.exports = {
        root: "SonataFullscreenControlsMobile_root__H6MQ7",
        sonataButtons: "SonataFullscreenControlsMobile_sonataButtons__hLf19",
        sonataButton: "SonataFullscreenControlsMobile_sonataButton__UGQ_U",
        playPauseButtonIcon: "SonataFullscreenControlsMobile_playPauseButtonIcon__e5ygU",
        buttonContainer: "SonataFullscreenControlsMobile_buttonContainer__5ITqM"
      };
    },
    46695: (e, t, a) => {
      "use strict";
      a.d(t, { SonataVideoControls: () => m });
      var i = a(54486), n = a(50420), s = a(28303), l = a(63585), o = a(3269), r = a(8817), c = a(74125), d = a(33506), u = a(72309), p = a.n(u);
      let m = (0, s.PA)((e2) => {
        let { className: t2 } = e2, { fullscreenVideoPlayer: a2, experiments: s2 } = (0, c.Pjs)(), u2 = s2.checkExperiment(c.zal.WebNextPlayerBarYellowButton, "on"), m2 = (0, c.eGp)(), { from: C } = (0, c.fyy)({
          pageId: c._Q$.VIDEO_PLAYER,
          contextId: a2.state.contextId,
          contextType: l.K.Various
        }), _ = (0, r.c)(() => {
          null == m2 || m2.moveForward(c.V_r.CLIP);
        }), v = (0, r.c)(() => {
          null == m2 || m2.moveBackward(c.V_r.CLIP);
        }), { isPlaying: x, togglePlay: h } = (0, c.Dx4)({
          playContextParams: {
            contextData: { type: l.K.Various, meta: { id: c.H7u.VARIOUS_CLIP_CONTEXT }, from: C },
            loadContextMeta: true
          },
          sonataState: a2.state,
          playbackId: c.V_r.CLIP
        });
        return (0, i.jsx)(d.Z, {
          className: (0, n.$)(t2, { [p().root]: u2 }),
          isPlaying: x,
          canMoveBackward: a2.state.canMoveBackward,
          canMoveForward: a2.state.canMoveForward,
          canShuffle: false,
          onClickPlayPause: h,
          onClickNext: _,
          onClickPrev: v,
          canChangeRepeatMode: false,
          shuffle: false,
          repeatMode: o.pM.NONE
        });
      });
    },
    50795: (e, t, a) => {
      "use strict";
      a.d(t, { ClipsCarousel: () => m });
      var i = a(54486), n = a(50420), s = a(28303), l = a(61910), o = a(15209), r = a(80585), c = a(63325), d = a.n(c), u = a(32159);
      let p = (0, s.PA)((e2) => {
        let {
          clipCardTitleClassName: t2,
          clipCardArtistLinkClassName: a2,
          carouselItemClassName: s2,
          forwardRef: c2,
          isShimmerVisible: p2,
          isShimmerActive: m2,
          title: C,
          description: _,
          containerClassName: v,
          headerClassName: x,
          viewAllActionLink: h,
          artistIdWithoutLink: f,
          withVideo: g = true,
          clips: N,
          headingVariant: b,
          className: I,
          shouldOpenModalOnCardClick: y = true,
          itemCounter: S,
          ...M
        } = e2, A = (0, l.useId)(), k = (0, l.useRef)(null);
        return (0, i.jsxs)("section", {
          className: (0, n.$)(d().root, I),
          ref: c2,
          ...(0, o.getDataAttrFromProps)(M),
          children: [
            (0, i.jsx)(r.Tw, {
              className: x,
              labeledForId: A,
              title: C,
              description: _,
              viewAllActionLink: h,
              controls: (0, i.jsx)(r.X9, { className: d().controls, carouselRef: k }),
              headingVariant: b,
              withDescription: !!_
            }),
            (0, i.jsx)(u.ClipsCarouselContent, {
              clipCardTitleClassName: t2,
              clipCardArtistLinkClassName: a2,
              carouselItemClassName: s2,
              isShimmerVisible: p2,
              isShimmerActive: m2,
              containerClassName: v,
              artistIdWithoutLink: f,
              withVideo: g,
              clips: N,
              shouldOpenModalOnCardClick: y,
              itemCounter: S,
              ref: k,
              "aria-labelledby": A
            })
          ]
        });
      }), m = (0, l.forwardRef)((e2, t2) => (0, i.jsx)(p, { forwardRef: t2, ...e2 }));
    },
    57923: (e, t, a) => {
      "use strict";
      a.d(t, { ClipCard: () => y });
      var i = a(54486), n = a(50420), s = a(12186), l = a(28303), o = a(61910), r = a(43426), c = a(15209), d = a(31500), u = a(63585), p = a(8817), m = a(71712), C = a(58360), _ = a(6971), v = a(97800), x = a(63695), h = a(54830), f = a(74125), g = a(80585), N = a(84883), b = a(7021), I = a.n(b);
      let y = (0, l.PA)((e2) => {
        var t2;
        let {
          titleClassName: a2,
          artistLinkClassName: l2,
          clip: b2,
          withVideo: y2 = true,
          artistIdWithoutLink: S,
          viewUuid: M,
          shouldOpenModalOnCardClick: A = true
        } = e2, { fullscreenVideoPlayer: k } = (0, f.Pjs)(), { formatMessage: E } = (0, r.A)(), P = (0, h.Cc)(), { from: w } = (0, f.fyy)({
          pageId: f._Q$.VIDEO_PLAYER,
          contextId: k.state.contextId,
          contextType: u.K.Various,
          blockId: f.UfI.CLIPS
        }), T = (0, f.PMf)(null != (t2 = b2.duration) ? t2 : 0), O = (0, h.Mn)(M), R = (0, h._7)(M), { ref: j, intersectionPropertyId: L } = (0, f.nMI)({ callback: O }), B = (0, o.useRef)(null), K = y2 && b2.previewUrl, D = (0, p.c)(() => {
          B.current && (B.current.currentTime = 0, B.current.play());
        }), F = (0, o.useMemo)(() => (0, s.A)(D, 500), [D]), z = (0, p.c)(() => {
          var e3;
          null == (e3 = B.current) || e3.pause();
        }), U = (0, o.useMemo)(() => k.ids.indexOf(b2.clipId), [k, b2.clipId]), { isPlaying: G, togglePlay: V } = (0, f.Dx4)({
          playContextParams: {
            contextData: { type: u.K.Various, meta: { id: f.H7u.VARIOUS_CLIP_CONTEXT }, from: w },
            queueParams: { index: U },
            entitiesData: k.entitiesData,
            loadContextMeta: false
          },
          entityId: String(b2.clipId),
          sonataState: k.state,
          playbackId: f.V_r.CLIP
        }), $ = A ? b2.url : (0, h.JL)(k.ids, U), X = (0, p.c)(() => {
          A ? (P([b2.clipId]), R()) : G || V();
        }), q = (0, N.useClipDisclaimer)({ clip: b2, callback: X }), Q = E({ id: "entity-names.clip-name" }, { clipName: b2.title }), Y = (0, o.useMemo)(
          () => b2.isAvailable ? (0, i.jsxs)(_.Paper, {
            radius: "m",
            className: (0, n.$)(I().view, I().cover),
            onMouseEnter: F,
            onMouseLeave: z,
            onClick: q,
            children: [
              K && (0, i.jsx)("video", {
                className: I().media,
                ref: B,
                poster: b2.thumbnail && (0, c.createAvatarVideoUrl)(b2.thumbnail, 1280),
                playsInline: true,
                muted: true,
                loop: true,
                "aria-hidden": true,
                children: (0, i.jsx)("source", { src: b2.previewUrl, type: "video/mp4" })
              }),
              b2.thumbnail && (0, i.jsx)(C.Image, {
                className: I().image,
                "aria-hidden": true,
                src: b2.thumbnail,
                fit: "cover",
                withAvatarReplace: true,
                size: 1280,
                createUrlReplacer: c.createAvatarVideoUrl
              }),
              void 0 !== b2.duration && (0, i.jsx)(v.Caption, {
                role: "text",
                "aria-label": T,
                variant: "span",
                className: I().duration,
                type: "entity",
                size: "xs",
                weight: "medium",
                children: (0, i.jsx)("span", {
                  "aria-hidden": "true",
                  children: (0, f.E4p)(b2.duration, b2.duration)
                })
              }),
              (0, i.jsx)(g.DM, { variant: "filled", className: I().playButton, onClick: q, iconSize: "xl" })
            ]
          }) : (0, i.jsx)(_.Paper, {
            radius: "m",
            className: I().unavailableCover,
            children: (0, i.jsx)(C.FallbackImage, {
              className: I().image,
              iconVariant: "unavailable",
              ...(0, d.Am)(d.S7.ENTITY_COVER_FALLBACK_IMAGE)
            })
          }),
          [T, b2.isAvailable, b2.thumbnail, b2.previewUrl, b2.duration, F, z, q, K]
        ), H = (0, o.useMemo)(
          () => b2.hasArtists ? (0, i.jsx)(
            x.iQ,
            {
              linkClassName: (0, n.$)(I().artistLink, l2),
              artists: b2.artists,
              lineClamp: 1,
              withAllArtistsTitle: true,
              artistIdWithoutLink: S
            },
            b2.getKey("SeparatedArtists")
          ) : null,
          [S, b2, l2]
        );
        return (0, i.jsx)(m.MN, {
          ref: j,
          className: I().root,
          explicitMarkComponent: b2.explicitDisclaimer && (0, i.jsx)(
            g.Nq,
            { getDescriptionTexts: b2.getDescriptionTexts, variant: b2.explicitDisclaimer, size: "xxs" },
            b2.getKey("ExplicitMarkIcon")
          ),
          "aria-label": Q,
          srTitle: (0, i.jsx)(g.N_, { href: $, onClick: q, children: Q }),
          title: (0, i.jsxs)(
            v.Caption,
            {
              className: (0, n.$)(I().title, a2),
              variant: "div",
              type: "entity",
              size: "m",
              weight: "medium",
              lineClamp: 1,
              children: [
                (0, i.jsx)(g.N_, {
                  className: I().titleLink,
                  href: $,
                  "aria-label": Q,
                  onClick: q,
                  ...(0, d.Am)(d.Kq.clip.CLIP_META_TITLE),
                  children: b2.title
                }),
                b2.version && (0, i.jsx)(v.Caption, { className: I().version, variant: "span", children: " ".concat(b2.version) })
              ]
            },
            b2.getKey("Title")
          ),
          "data-intersection-property-id": L,
          view: Y,
          description: H,
          ...(0, d.Am)(d.Kq.clip.CLIP_CARD)
        });
      });
    },
    59553: (e, t, a) => {
      "use strict";
      var i;
      a.d(t, { Q: () => i }), (function(e2) {
        e2.StreamPause = "streamPause", e2.StreamPlay = "streamPlay", e2.TimestampLike = "timestampLike", e2.TimestampDislike = "timestampDislike";
      })(i || (i = {}));
    },
    59767: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "ControlsBar_root__l6Fg6",
        item: "ControlsBar_item__tEQvM",
        item_buttonArrow: "ControlsBar_item_buttonArrow__3aZyp",
        contextMenu: "ControlsBar_contextMenu__1Sj5f",
        contextMenu_visible: "ControlsBar_contextMenu_visible__FMTw4",
        controls_disabled: "ControlsBar_controls_disabled__xR0_N",
        controls: "ControlsBar_controls__PEMXx",
        likeIcon: "ControlsBar_likeIcon__UBXQm"
      };
    },
    61569: (e, t, a) => {
      "use strict";
      a.d(t, { PromoLandingSonataControls: () => f });
      var i = a(54486), n = a(28303), s = a(61910), l = a(8817), o = a(27510), r = a(74125), c = a(21050), d = a(84096), u = a(29476), p = a(73401), m = a(50420), C = a(80585), _ = a(83675), v = a(91129), x = a.n(v);
      let h = (0, n.PA)((e2) => {
        let {
          className: t2,
          disabled: a2,
          isPlaying: n2,
          canChangeRepeatMode: s2,
          canMoveBackward: l2,
          canMoveForward: o2,
          canShuffle: c2,
          shuffle: d2,
          onClickNext: u2,
          onClickPlayPause: p2,
          onClickPrev: v2,
          repeatMode: h2,
          onRepeatClick: f2,
          onShuffleClick: g
        } = e2, { experiments: N } = (0, r.Pjs)(), b = N.checkExperiment(r.zal.WebNextPlayerBarYellowButton, "on");
        return (0, i.jsx)(_.a, {
          onShuffleClick: g,
          onRepeatClick: f2,
          isDisabledRepeat: !s2 || a2,
          isDisabledShuffle: !c2 || a2,
          withShuffle: a2 || c2,
          shuffle: d2,
          canMoveBackward: l2,
          canMoveForward: o2,
          onClickNext: u2,
          onClickPrev: v2,
          withRepeat: a2 || s2,
          repeatMode: h2,
          className: t2,
          playButton: (0, i.jsx)(C.DM, {
            className: x().sonataButton,
            iconSize: "l",
            variant: "filled",
            isPlaying: n2,
            iconClassName: (0, m.$)(x().playButtonIcon, { [x().playButtonIcon_withYellowPlayButton]: b }),
            onClick: p2
          })
        });
      }), f = (0, n.PA)((e2) => {
        let { className: t2, isMobile: a2, entityMeta: n2 } = e2, {
          promolanding: { state: m2 }
        } = (0, r.Pjs)(), C2 = (0, r.eGp)(), _2 = (0, r.brA)(), v2 = (0, d.useOnRepeatClick)(), x2 = (0, u.useOnShuffleClick)(), f2 = (0, r.zwV)(), g = c.w.includes(m2.status), N = (0, l.c)(() => {
          n2 && (null == C2 || C2.togglePause(r.V_r.PROMO_LANDING), _2(!g));
        }), b = (0, l.c)(() => {
          null == C2 || C2.moveForward(r.V_r.PROMO_LANDING);
        }), I = (0, l.c)(() => {
          null == C2 || C2.moveBackward(r.V_r.PROMO_LANDING);
        }), y = (0, l.c)(() => {
          v2(m2, r.V_r.PROMO_LANDING);
        }), S = (0, l.c)(() => {
          x2(m2, r.V_r.PROMO_LANDING);
        });
        (0, s.useEffect)(
          () => (null == f2 || f2.addShortcutsListener(r.Mo.PROMO_LANDING, r.lbr.TOGGLE_PLAY, N), null == f2 || f2.addShortcutsListener(r.Mo.PROMO_LANDING, r.lbr.TOGGLE_REPEAT, y), null == f2 || f2.addShortcutsListener(r.Mo.PROMO_LANDING, r.lbr.TOGGLE_SHUFFLE, S), () => {
            null == f2 || f2.removeShortcutsListener(r.Mo.PROMO_LANDING, r.lbr.TOGGLE_PLAY), null == f2 || f2.removeShortcutsListener(r.Mo.PROMO_LANDING, r.lbr.TOGGLE_SHUFFLE), null == f2 || f2.removeShortcutsListener(r.Mo.PROMO_LANDING, r.lbr.TOGGLE_REPEAT);
          }),
          [N, y, S, f2]
        );
        let M = (0, o.L)(() => a2 ? p.K : h);
        return (0, i.jsx)(M, {
          onRepeatClick: y,
          onShuffleClick: S,
          className: t2,
          disabled: !n2,
          isPlaying: !!g,
          canMoveBackward: m2.canMoveBackward,
          canMoveForward: m2.canMoveForward,
          canShuffle: m2.canShuffle,
          shuffle: m2.shuffle,
          onClickPlayPause: N,
          onClickNext: b,
          onClickPrev: I,
          canChangeRepeatMode: m2.canChangeRepeatMode,
          repeatMode: m2.repeatMode
        });
      });
    },
    62915: (e, t, a) => {
      "use strict";
      a.d(t, { NotificationShuffle: () => m });
      var i = a(54486), n = a(50420), s = a(61910), l = a(43426), o = a(5956), r = a(39610), c = a(97800), d = a(80585), u = a(87537), p = a.n(u);
      let m = (e2) => {
        let { shuffle: t2, closeToast: a2 } = e2, { formatMessage: u2 } = (0, l.A)(), m2 = (0, s.useMemo)(
          () => t2 ? u2({ id: "notifications-info.shuffle-enabled" }) : u2({ id: "notifications-info.shuffle-disabled" }),
          [u2, t2]
        ), C = (0, s.useMemo)(
          () => (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)(r.q, { children: (0, i.jsx)("p", { role: "alert", children: m2 }) }),
              (0, i.jsx)(c.Caption, {
                className: p().message,
                variant: "div",
                type: "controls",
                size: "m",
                "aria-hidden": true,
                children: m2
              })
            ]
          }),
          [m2]
        );
        return (0, i.jsx)(d.$W, {
          cover: (0, i.jsx)(o.Icon, {
            className: (0, n.$)(p().icon, { [p().icon_unset]: !t2 }),
            size: "xs",
            variant: "shuffle"
          }),
          message: C,
          closeToast: a2,
          coverRadius: "s"
        });
      };
    },
    63325: (e) => {
      e.exports = { root: "ClipsCarousel_root__r1mGp", controls: "ClipsCarousel_controls__nZB6r" };
    },
    65779: (e, t, a) => {
      "use strict";
      a.d(t, {
        FC: () => x.ClipCard,
        kV: () => h.k,
        zb: () => f.ClipContextMenu,
        kv: () => m,
        KR: () => g.ClipsCarousel,
        tD: () => N.ClipsCarouselContent,
        $d: () => v,
        Nk: () => b.HorizontalClipCard,
        wS: () => s,
        i$: () => r,
        SZ: () => d,
        V1: () => u,
        XP: () => p.useClipDisclaimer
      });
      var i = a(73975), n = a(63695);
      let s = (e2) => {
        var t2;
        if (!e2)
          return {
            clipId: 0,
            title: "",
            artists: [],
            thumbnail: "",
            previewUrl: "",
            duration: 0,
            disclaimers: [],
            trackIds: []
          };
        let a2 = [];
        return (null == (t2 = e2.disclaimers) ? void 0 : t2.every((e3) => Object.values(i.M).includes(e3))) && (a2 = e2.disclaimers), {
          clipId: e2.clipId,
          title: e2.title,
          thumbnail: e2.thumbnail,
          previewUrl: e2.previewUrl,
          duration: e2.duration,
          disclaimers: a2,
          version: e2.version,
          artists: e2.artists.map((e3) => {
            let t3 = (0, n.NE)(e3), a3 = Number(t3.id);
            return { ...t3, id: isNaN(a3) ? 0 : a3 };
          }),
          trackIds: []
        };
      };
      var l = a(93064), o = a(54830);
      let r = (e2) => {
        var t2;
        let a2 = null == (t2 = e2.artists) ? void 0 : t2.map((e3) => (0, n.as)({ artist: e3 }));
        return (0, l.wg)({ ...(0, o.l6)(e2), artists: a2 });
      };
      var c = a(74125);
      let d = (e2) => {
        var t2, a2;
        let { clip: i2, artists: s2 } = e2, { available: o2, disclaimers: r2 } = (0, c.fyr)(i2);
        return (0, l.wg)({
          clipId: i2.id,
          title: i2.title,
          thumbnail: null == (t2 = i2.cover) ? void 0 : t2.uri,
          previewUrl: null == (a2 = i2.cover) ? void 0 : a2.videoUrl,
          duration: i2.duration,
          artists: null == s2 ? void 0 : s2.map((e3) => (0, n.as)({ artist: e3 })),
          isAvailable: o2,
          disclaimers: r2
        });
      }, u = (e2, t2) => {
        if (!e2) return { clipIds: [], activeClipIndex: 0 };
        let a2 = e2.split(",").map(Number).filter((e3) => e3 >= 0), i2 = (0, o.z4)(a2, t2);
        return { clipIds: a2, activeClipIndex: i2 };
      };
      (0, a(61910).cache)(async (e2) => {
        try {
          let {
            container: t2,
            backendHostTld: a2,
            locale: i2,
            host: n2,
            fullUrl: s2,
            isRSC: l2,
            requestUrl: o2
          } = await (0, c.IhE)();
          if (l2 || !e2) return { clips: void 0, backendHostTld: a2, locale: i2, host: n2, fullUrl: s2, requestUrl: o2 };
          let r2 = t2.get(c.jQD), d2 = await r2.getClip({ clipIds: [e2] }), u2 = s2 ? new URL(s2) : void 0;
          u2 && (u2.search = "", u2.searchParams.set(c.K3F.IDS, String(null != e2 ? e2 : "")));
          let p2 = null == u2 ? void 0 : u2.toString();
          return {
            clip: null == d2 ? void 0 : d2[0],
            backendHostTld: a2,
            locale: i2,
            host: n2,
            fullUrl: s2,
            requestUrl: o2,
            canonical: p2
          };
        } catch (e3) {
          return { clips: void 0, backendHostTld: "", locale: null, host: "", fullUrl: null, requestUrl: null };
        }
      });
      var p = a(84883);
      let m = o.z8.props({ artists: l.gK.array(n.PK) }).views((e2) => ({
        get hasArtists() {
          return e2.artists.length > 0;
        }
      }));
      var C = a(26433);
      let _ = l.gK.model("Credit", { title: l.gK.string, value: l.gK.string }), v = l.gK.model("CurrentClipInfo", {
        id: l.gK.maybeNull(l.gK.number),
        clip: l.gK.maybeNull(m),
        clipLoadingState: l.gK.enumeration(Object.values(c.GuX)),
        creditsLoadingState: l.gK.enumeration(Object.values(c.GuX)),
        credits: l.gK.maybeNull(l.gK.array(_)),
        modal: C.qt
      }).views((e2) => ({
        get isClipIdle() {
          return e2.clipLoadingState === c.GuX.IDLE;
        },
        get isClipLoading() {
          return e2.clipLoadingState === c.GuX.PENDING;
        },
        get isClipRejected() {
          return e2.clipLoadingState === c.GuX.REJECT;
        },
        get isCreditsIdle() {
          return e2.creditsLoadingState === c.GuX.IDLE;
        },
        get isCreditsLoading() {
          return e2.creditsLoadingState === c.GuX.PENDING;
        },
        get isCreditsRejected() {
          return e2.creditsLoadingState === c.GuX.REJECT;
        },
        get isRejected() {
          return e2.creditsLoadingState === c.GuX.REJECT && e2.clipLoadingState === c.GuX.REJECT;
        }
      })).actions((e2) => ({
        setClipId(t2) {
          e2.id = t2;
        },
        getClip: (0, l.L3)(function* () {
          let { clipsResource: t2, modelActionsLogger: a2 } = (0, l._$)(e2);
          if (e2.id && e2.clipLoadingState !== c.GuX.PENDING)
            try {
              e2.clipLoadingState = c.GuX.PENDING;
              let [a3] = yield t2.getClip({ clipIds: [e2.id] });
              if (!a3) return;
              e2.clip = r(a3), e2.clipLoadingState = c.GuX.RESOLVE;
            } catch (t3) {
              a2.error(t3), e2.clipLoadingState = c.GuX.REJECT;
            }
        }),
        getCreditsInfo: (0, l.L3)(function* () {
          let { clipsResource: t2, modelActionsLogger: a2 } = (0, l._$)(e2);
          if (!e2.id || e2.creditsLoadingState === c.GuX.PENDING) return null;
          try {
            e2.creditsLoadingState = c.GuX.PENDING;
            let a3 = yield t2.getCredits({ clipId: e2.id });
            e2.credits = (0, l.wg)(null == a3 ? void 0 : a3.credits), e2.creditsLoadingState = c.GuX.RESOLVE;
          } catch (t3) {
            a2.error(t3), e2.creditsLoadingState = c.GuX.REJECT;
          }
          return null;
        }),
        reset() {
          e2.id = null, e2.clip = null, e2.clipLoadingState = c.GuX.IDLE, e2.creditsLoadingState = c.GuX.IDLE, e2.credits = null;
        }
      }));
      var x = a(57923), h = a(69597), f = a(22017), g = a(50795), N = a(32159), b = a(70901);
    },
    69597: (e, t, a) => {
      "use strict";
      a.d(t, { k: () => r });
      var i = a(54486), n = a(22674), s = a(80585), l = a(37863), o = a.n(l);
      let r = (e2) => {
        let { isActive: t2 } = e2;
        return (0, i.jsxs)("div", {
          className: o().root,
          "aria-live": t2 ? "polite" : "off",
          "aria-busy": t2,
          children: [
            (0, i.jsx)(n.Shimmer, { isActive: t2, className: o().cover, radius: "l" }),
            (0, i.jsx)(s.nN, { isActive: t2, className: o().title }),
            (0, i.jsx)(s.nN, { isActive: t2, className: o().text })
          ]
        });
      };
    },
    70901: (e, t, a) => {
      "use strict";
      a.d(t, { HorizontalClipCard: () => T });
      var i = a(54486), n = a(50420), s = a(12186), l = a(28303), o = a(61910), r = a(43426), c = a(15209), d = a(31500), u = a(63585), p = a(8817), m = a(27510), C = a(73633), _ = a(58360), v = a(6971), x = a(97800), h = a(63695), f = a(54830), g = a(74125), N = a(80585), b = a(84883), I = a(7021), y = a.n(I), S = a(5956), M = a(22017), A = a(59767), k = a.n(A);
      let E = (0, l.PA)((e2) => {
        let { className: t2, clip: a2, likeIconSize: s2 = "xxs" } = e2, { user: l2 } = (0, g.Pjs)(), { sendLikeSearchFeedback: r2 } = (0, g.zEv)(), c2 = (0, f.KX)(a2), [u2, m2] = (0, o.useState)(false), [C2, _2] = (0, o.useState)(false), v2 = (0, p.c)(() => {
          u2 || a2.isLiked || (m2(true), null == r2 || r2()), c2();
        });
        return (0, i.jsx)("div", {
          className: (0, n.$)(k().root, k().controls, t2, { [k().controls_disabled]: !a2.isAvailable }),
          children: a2.isAvailable && (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)(N.aQ, {
                fallback: (0, i.jsx)(N.cy, {
                  size: "xs",
                  iconSize: s2,
                  className: (0, n.$)(k().item, k().likeIcon),
                  isLiked: a2.isLiked,
                  onClick: v2,
                  disabled: !l2.isAuthorized
                })
              }),
              (0, i.jsx)(M.ClipContextMenu, {
                placement: "top-start",
                icon: (0, i.jsx)(S.Icon, { variant: "more", size: "xs" }),
                size: "xs",
                clip: a2,
                className: (0, n.$)(k().contextMenu, { [k().contextMenu_visible]: C2 }),
                onOpenChange: _2,
                open: C2,
                ...(0, d.Am)(d.Kq.clip.CLIP_CONTEXT_MENU_BUTTON)
              })
            ]
          })
        });
      });
      var P = a(26245), w = a.n(P);
      let T = (0, l.PA)((e2) => {
        var t2;
        let {
          clip: a2,
          className: l2,
          coverClassName: I2,
          playButtonIconSize: S2 = "xs",
          likeIconSize: M2,
          viewUuid: A2,
          shouldShowTimecode: k2 = false
        } = e2, { fullscreenVideoPlayer: P2 } = (0, g.Pjs)(), { formatMessage: T2 } = (0, r.A)(), O = (0, g.PMf)(null != (t2 = a2.duration) ? t2 : 0), R = (0, f._7)(A2), j = (0, f.Mn)(A2), { ref: L, intersectionPropertyId: B } = (0, g.nMI)({ callback: j }), { from: K } = (0, g.fyy)({
          pageId: g._Q$.VIDEO_PLAYER,
          contextId: P2.state.contextId,
          contextType: u.K.Various,
          blockId: g.UfI.CLIPS
        }), [D, F] = (0, o.useState)(false), { sendNavigateSearchFeedback: z, sendPlaySearchFeedback: U } = (0, g.zEv)(), G = (0, f.Cc)(), V = (0, o.useRef)(null), $ = (0, p.c)(() => {
          V.current && (V.current.currentTime = 0, V.current.play());
        }), X = (0, o.useMemo)(() => (0, s.A)($, 500), [$]), q = (0, p.c)(() => {
          var e3;
          null == (e3 = V.current) || e3.pause();
        }), Q = (0, o.useMemo)(() => P2.ids.indexOf(a2.clipId), [P2, a2.clipId]), { isPlaying: Y } = (0, g.Dx4)({
          playContextParams: {
            contextData: { type: u.K.Various, meta: { id: g.H7u.VARIOUS_CLIP_CONTEXT }, from: K },
            queueParams: { index: Q },
            entitiesData: P2.entitiesData,
            loadContextMeta: false
          },
          entityId: String(a2.clipId),
          sonataState: P2.state,
          playbackId: g.V_r.CLIP
        }), H = (0, p.c)(() => {
          G([a2.clipId]), D || Y || (F(true), null == U || U()), null == z || z(), R();
        }), W = (0, b.useClipDisclaimer)({ clip: a2, callback: H }), Z = (0, p.c)((e3) => {
          (0, C.P)(e3, N.$f.ripple), W(e3);
        }), J = (0, m.L)(
          () => (0, i.jsx)(x.Caption, {
            className: (0, n.$)(N.$f.text, N.$f.titleText),
            "aria-hidden": true,
            variant: "div",
            type: "entity",
            size: "m",
            weight: "medium",
            lineClamp: 1,
            children: a2.title
          })
        ), ee = (0, o.useCallback)(
          (e3, t3) => {
            var n2;
            return (null == (n2 = a2.artists) ? void 0 : n2.length) ? (0, i.jsx)(h.iQ, { linkClassName: e3, captionClassName: t3, artists: a2.artists, lineClamp: 1 }) : null;
          },
          [a2.artists]
        ), et = T2({ id: "entity-names.clip-name" }, { clipName: a2.title }), ea = (0, m.L)(
          () => a2.isAvailable ? (0, i.jsxs)(v.Paper, {
            className: (0, n.$)(w().cover, y().cover, y().cover_withoutOffset, I2),
            radius: "xs",
            onMouseEnter: X,
            onMouseLeave: q,
            children: [
              a2.previewUrl && (0, i.jsx)("video", {
                className: y().media,
                ref: V,
                poster: a2.thumbnail && (0, c.createAvatarVideoUrl)(a2.thumbnail, 80),
                playsInline: true,
                muted: true,
                loop: true,
                "aria-hidden": true,
                children: (0, i.jsx)("source", { src: a2.previewUrl, type: "video/mp4" })
              }),
              a2.thumbnail && (0, i.jsx)(_.Image, {
                className: y().image,
                src: a2.thumbnail,
                fit: "cover",
                withAvatarReplace: true,
                size: 80,
                createUrlReplacer: c.createAvatarVideoUrl,
                alt: et
              }),
              void 0 !== a2.duration && k2 && (0, i.jsx)(x.Caption, {
                variant: "span",
                className: (0, n.$)(y().duration, w().duration),
                type: "entity",
                size: "xs",
                weight: "medium",
                role: "text",
                "aria-label": O,
                children: (0, i.jsx)("span", {
                  "aria-hidden": "true",
                  children: (0, g.E4p)(a2.duration, a2.duration)
                })
              }),
              (0, i.jsx)(N.DM, { variant: "filled", className: y().playButton, onClick: W, iconSize: S2 })
            ]
          }) : (0, i.jsxs)(v.Paper, {
            className: (0, n.$)(w().cover, w().unavailable, I2),
            radius: "xs",
            children: [
              (0, i.jsx)(_.FallbackImage, {
                className: y().image,
                iconVariant: "unavailable",
                iconSize: "xs",
                ...(0, d.Am)(d.S7.ENTITY_COVER_FALLBACK_IMAGE)
              }),
              (0, i.jsx)(N.DM, { variant: "filled", className: y().playButton, iconSize: S2, disabled: true })
            ]
          })
        );
        return (0, i.jsxs)(N.Cj, {
          ref: L,
          "data-intersection-property-id": B,
          className: (0, n.$)(N.$f.root, { [N.$f.root_disabled]: !a2.isAvailable }, w().root, l2),
          onClick: Z,
          ...(0, d.Am)(d.Kq.clip.HORIZONTAL_CLIP_CARD),
          children: [
            ea,
            (0, i.jsx)(N.ro, {
              isDisabled: !a2.isAvailable,
              title: J,
              artistsComponent: ee,
              getDescriptionTexts: a2.getDescriptionTexts,
              explicitMarkVariant: a2.explicitDisclaimer,
              isLiked: a2.isLiked
            }),
            (0, i.jsx)(E, { className: N.$f.controlsBar, clip: a2, likeIconSize: M2 })
          ]
        });
      });
    },
    72113: (e) => {
      e.exports = {
        shuffleIcon_off: "ShuffleButton_shuffleIcon_off___oqrr",
        shuffleIcon_on: "ShuffleButton_shuffleIcon_on__qFJqV",
        shuffleIcon_disabled: "ShuffleButton_shuffleIcon_disabled__fQsOo"
      };
    },
    72309: (e) => {
      e.exports = { root: "SonataVideoControls_root__mHglL" };
    },
    73401: (e, t, a) => {
      "use strict";
      a.d(t, { K: () => s });
      var i = a(54486), n = a(80585);
      let s = (e2) => {
        let { disabled: t2, isPlaying: a2, onClickPlayPause: s2, className: l } = e2;
        return (0, i.jsx)(n.DM, { className: l, size: "s", iconSize: "xs", disabled: t2, isPlaying: a2, onClick: s2 });
      };
    },
    73717: (e) => {
      e.exports = {
        itemCounter_3: "ClipsCarouselContent_itemCounter_3__c_H3V",
        item: "ClipsCarouselContent_item__Yy7_P",
        important: "ClipsCarouselContent_important__nZYA0",
        itemCounter_5: "ClipsCarouselContent_itemCounter_5__QeQd_"
      };
    },
    74890: (e) => {
      e.exports = {
        repeatIcon_none: "RepeatButton_repeatIcon_none__2nb1J",
        repeatIcon_context: "RepeatButton_repeatIcon_context__QwVY9",
        repeatIcon_one: "RepeatButton_repeatIcon_one___mSkU",
        repeatIcon_disabled: "RepeatButton_repeatIcon_disabled__LwHV_"
      };
    },
    77091: (e, t, a) => {
      "use strict";
      a.d(t, { SonataControls: () => w });
      var i = a(54486), n = a(50420), s = a(28303), l = a(61910), o = a(8817), r = a(74125), c = a(21050), d = a(84096), u = a(29476), p = a(73401), m = a(40632), C = a.n(m), _ = a(33506), v = a(43426), x = a(31500), h = a(77881), f = a(5956), g = a(80585), N = a(16045), b = a(93011), I = a(20765), y = a.n(I);
      let S = (0, s.PA)((e2) => {
        let {
          disabled: t2,
          isPlaying: a2,
          repeatMode: s2,
          canMoveForward: l2,
          canMoveBackward: o2,
          canRewind: c2,
          canShuffle: d2,
          onClickNext: u2,
          onClickPrev: p2,
          onRewindBackwardsClick: m2,
          onRewindForwardClick: C2,
          onClickPlayPause: _2,
          canChangeRepeatMode: I2,
          shuffle: S2,
          className: M2,
          onRepeatClick: A2,
          onShuffleClick: k2
        } = e2, { formatMessage: E2 } = (0, v.A)(), { experiments: P2 } = (0, r.Pjs)(), w2 = P2.checkExperiment(r.zal.WebNextPlayerBarYellowButton, "on");
        return (0, i.jsxs)("div", {
          className: (0, n.$)(y().root, M2),
          children: [
            (0, i.jsxs)("div", {
              className: y().buttonContainer,
              children: [
                (t2 || d2) && (0, i.jsx)(b.ShuffleButton, {
                  className: y().sonataButton,
                  size: "s",
                  iconSize: "xxs",
                  color: "secondary",
                  isDisabled: t2,
                  shuffle: S2,
                  onClick: k2,
                  ...(0, x.Am)(x.Kq.sonata.SHUFFLE_BUTTON)
                }),
                !t2 && c2 && (0, i.jsx)(h.$, {
                  className: (0, n.$)(y().sonataButton, y().rewind),
                  color: "secondary",
                  size: "m",
                  radius: "round",
                  withRipple: false,
                  "aria-label": E2({ id: "player-actions.rewind-backwards" }),
                  icon: (0, i.jsx)(f.Icon, { variant: "rewindBackwards", size: "xxs" }),
                  onClick: m2,
                  ...(0, x.Am)(x.Kq.sonata.REWIND_BACKWARDS_BUTTON)
                })
              ]
            }),
            (0, i.jsxs)("div", {
              className: y().sonataButtons,
              children: [
                (0, i.jsx)(h.$, {
                  className: y().sonataButton,
                  color: "secondary",
                  size: "m",
                  radius: "round",
                  disabled: !o2,
                  withRipple: false,
                  "aria-label": E2({ id: "player-actions.previous-track" }),
                  icon: (0, i.jsx)(f.Icon, { variant: "previous", size: "xxs" }),
                  onClick: p2,
                  ...(0, x.Am)(x.Kq.sonata.PREVIOUS_TRACK_BUTTON)
                }),
                (0, i.jsx)(g.DM, {
                  className: (0, n.$)(y().sonataButton, y().sonataPlayButton),
                  iconSize: "m",
                  size: "l",
                  radius: "round",
                  color: "secondary",
                  buttonVariant: "default",
                  isPlaying: a2,
                  iconClassName: (0, n.$)(y().playPauseButtonIcon, {
                    [y().playPauseButtonIcon_withYellowPlayButton]: w2
                  }),
                  onClick: _2
                }),
                (0, i.jsx)(h.$, {
                  className: y().sonataButton,
                  radius: "round",
                  size: "m",
                  color: "secondary",
                  disabled: !l2,
                  withRipple: false,
                  "aria-label": E2({ id: "player-actions.next-track" }),
                  icon: (0, i.jsx)(f.Icon, { variant: "next", size: "xxs" }),
                  onClick: u2,
                  ...(0, x.Am)(x.Kq.sonata.NEXT_TRACK_BUTTON)
                })
              ]
            }),
            (0, i.jsxs)("div", {
              className: y().buttonContainer,
              children: [
                !t2 && c2 && (0, i.jsx)(h.$, {
                  className: (0, n.$)(y().sonataButton, y().rewind),
                  color: "secondary",
                  size: "m",
                  radius: "round",
                  withRipple: false,
                  "aria-label": E2({ id: "player-actions.rewind-forward" }),
                  icon: (0, i.jsx)(f.Icon, { variant: "rewindForward", size: "xxs" }),
                  onClick: C2,
                  ...(0, x.Am)(x.Kq.sonata.REWIND_FORWARD_BUTTON)
                }),
                (t2 || I2) && (0, i.jsx)(N.RepeatButton, {
                  className: y().sonataButton,
                  size: "s",
                  color: "secondary",
                  isDisabled: t2,
                  iconSize: "xxs",
                  repeatMode: s2,
                  onClick: A2
                })
              ]
            })
          ]
        });
      });
      var M = a(63585), A = a(54460), k = a(46521), E = a.n(k);
      let P = (0, s.PA)((e2) => {
        let {
          isPlaying: t2,
          canMoveForward: a2,
          canMoveBackward: s2,
          canRewind: o2,
          onClickNext: c2,
          onClickPrev: d2,
          onRewindBackwardsClick: u2,
          onRewindForwardClick: p2,
          onClickPlayPause: m2,
          className: C2
        } = e2, { formatMessage: _2 } = (0, v.A)(), { user: N2, sonataState: b2 } = (0, r.Pjs)(), I2 = (0, r.zwV)(), y2 = b2.entityMeta, S2 = b2.contextType === M.K.Generative, k2 = N2.isAuthorized && !S2, P2 = (0, A.KX)(b2.entityMeta), w2 = (0, A.mW)(b2.entityMeta);
        (0, l.useEffect)(() => {
          if (!b2.isGenerativeContext)
            return null == I2 || I2.addShortcutsListener(r.Mo.MAIN, r.lbr.LIKE, P2), null == I2 || I2.addShortcutsListener(r.Mo.MAIN, r.lbr.DISLIKE, w2), () => {
              null == I2 || I2.removeShortcutsListener(r.Mo.MAIN, r.lbr.LIKE), null == I2 || I2.removeShortcutsListener(r.Mo.MAIN, r.lbr.DISLIKE);
            };
        }, [w2, P2, I2, b2.isGenerativeContext]);
        let T = (0, l.useMemo)(
          () => o2 ? (0, i.jsx)(h.$, {
            className: E().sonataButton,
            variant: "text",
            color: "secondary",
            size: "m",
            radius: "round",
            withRipple: false,
            "aria-label": _2({ id: "player-actions.rewind-backwards" }),
            icon: (0, i.jsx)(f.Icon, { variant: "rewindBackwards", size: "xs" }),
            onClick: u2,
            ...(0, x.Am)(x.Kq.sonata.MOBILE_REWIND_BACKWARDS_BUTTON)
          }) : (0, i.jsx)(h.$, {
            className: E().sonataButton,
            variant: "text",
            color: "secondary",
            size: "m",
            radius: "round",
            disabled: !s2,
            withRipple: false,
            "aria-label": _2({ id: "player-actions.previous-track" }),
            icon: (0, i.jsx)(f.Icon, { variant: "previous", size: "xs" }),
            onClick: d2,
            ...(0, x.Am)(x.Kq.sonata.MOBILE_PREVIOUS_TRACK_BUTTON)
          }),
          [o2, s2, _2, d2, u2]
        ), O = (0, l.useMemo)(
          () => o2 ? (0, i.jsx)(h.$, {
            className: E().sonataButton,
            variant: "text",
            radius: "round",
            size: "m",
            color: "secondary",
            disabled: !a2,
            withRipple: false,
            "aria-label": _2({ id: "player-actions.rewind-forward" }),
            icon: (0, i.jsx)(f.Icon, { variant: "rewindForward", size: "xs" }),
            onClick: p2,
            ...(0, x.Am)(x.Kq.sonata.MOBILE_REWIND_FORWARD_BUTTON)
          }) : (0, i.jsx)(h.$, {
            className: E().sonataButton,
            variant: "text",
            radius: "round",
            size: "m",
            color: "secondary",
            disabled: !a2,
            withRipple: false,
            "aria-label": _2({ id: "player-actions.next-track" }),
            icon: (0, i.jsx)(f.Icon, { variant: "next", size: "xs" }),
            onClick: c2,
            ...(0, x.Am)(x.Kq.sonata.MOBILE_NEXT_TRACK_BUTTON)
          }),
          [o2, a2, _2, c2, p2]
        );
        return (0, i.jsxs)("div", {
          className: (0, n.$)(E().root, C2),
          children: [
            (0, i.jsx)("div", {
              className: E().buttonContainer,
              children: y2 && k2 && (0, i.jsx)(g.aQ, {
                fallback: (0, i.jsx)(g._I, { isDisliked: y2.isDisliked, iconSize: "xs", onClick: w2 })
              })
            }),
            (0, i.jsxs)("div", {
              className: E().sonataButtons,
              children: [
                T,
                (0, i.jsx)(g.DM, {
                  className: E().sonataButton,
                  iconSize: "xxl",
                  variant: "filled",
                  color: "secondary",
                  isPlaying: t2,
                  iconClassName: E().playPauseButtonIcon,
                  onClick: m2
                }),
                O
              ]
            }),
            (0, i.jsx)("div", {
              className: E().buttonContainer,
              children: y2 && k2 && (0, i.jsx)(g.aQ, {
                fallback: (0, i.jsx)(g.cy, {
                  isLiked: y2.isLiked,
                  iconSize: "xs",
                  onClick: P2,
                  disabled: !N2.isAuthorized
                })
              })
            })
          ]
        });
      }), w = (0, s.PA)((e2) => {
        var t2, a2;
        let { isMobile: s2, entityMeta: m2, isFullscreen: v2, className: x2, withShuffle: h2, withRepeat: f2 } = e2, {
          sonataState: g2,
          vibe: N2,
          advert: b2,
          modals: { popoverOverPlayer: I2 },
          experiments: y2
        } = (0, r.Pjs)(), M2 = y2.checkExperiment(r.zal.WebNextPlayerBarYellowButton, "on"), A2 = (0, r.zwV)(), k2 = (0, r.eGp)(), { rewindBackwards: E2, rewindForward: w2 } = (() => {
          let {
            sonataState: { entityMeta: e3 }
          } = (0, r.Pjs)(), t3 = (0, r.eGp)();
          return {
            rewindBackwards: (0, l.useCallback)(() => {
              if (!t3 || !e3 || !e3.durationMs) return;
              let a3 = t3.state.playerState.progress.value.position - 15;
              t3.setProgress(a3 < 0 ? 0 : a3);
            }, [e3, t3]),
            rewindForward: (0, l.useCallback)(() => {
              if (!t3 || !e3 || !e3.durationMs) return;
              let a3 = e3.durationMs / 1e3, i2 = t3.state.playerState.progress.value.position + 30;
              t3.setProgress(i2 < a3 ? i2 : a3);
            }, [e3, t3])
          };
        })(), T = (0, r.rs2)(), O = (0, r.brA)(), R = (null == m2 ? void 0 : m2.isNonMusic) && !b2.isAdvertShown, j = (0, r.PT7)(), { togglePlay: L } = (0, r.B0S)({
          seeds: null != (a2 = null == (t2 = N2.meta) ? void 0 : t2.seeds) ? a2 : [],
          pageIdForFrom: r._Q$.HOME,
          blockIdForFrom: r.hf$.RUP_MAIN_RADIO,
          onPlayInterrupted: I2.open
        }), B = (0, l.useMemo)(
          () => b2.isAdvertShown ? b2.isAdvertPlaying : c.w.includes(g2.status),
          [g2.status, b2.isAdvertShown, b2.isAdvertPlaying]
        ), K = (0, o.c)(() => {
          if (b2.isAdvertShown) {
            var e3;
            null == T || null == (e3 = T.audioAdvertPlayback) || e3.togglePause();
            return;
          }
          m2 ? null == k2 || k2.togglePause() : L();
        }), D = (0, o.c)(() => {
          v2 && j() || (K(), O(!B));
        }), F = (0, o.c)(() => {
          null == k2 || k2.moveForward();
        }), z = (0, o.c)(() => {
          null == k2 || k2.moveBackward();
        }), U = (0, u.useOnShuffleClick)(), G = (0, d.useOnRepeatClick)(), V = (0, o.c)(() => {
          G(g2);
        }), $ = (0, o.c)(() => {
          U(g2);
        });
        (0, l.useEffect)(() => {
          if (!v2 && (null == A2 || A2.addShortcutsListener(r.Mo.MAIN, r.lbr.TOGGLE_PLAY, K), !b2.isAdvertShown))
            return null == A2 || A2.addShortcutsListener(r.Mo.MAIN, r.lbr.TOGGLE_REPEAT, V), null == A2 || A2.addShortcutsListener(r.Mo.MAIN, r.lbr.TOGGLE_SHUFFLE, $), () => {
              null == A2 || A2.removeShortcutsListener(r.Mo.MAIN, r.lbr.TOGGLE_PLAY), b2.isAdvertShown || (null == A2 || A2.removeShortcutsListener(r.Mo.MAIN, r.lbr.TOGGLE_SHUFFLE), null == A2 || A2.removeShortcutsListener(r.Mo.MAIN, r.lbr.TOGGLE_REPEAT));
            };
        }, [v2, K, V, $, A2, b2.isAdvertShown]);
        let X = (0, l.useMemo)(() => v2 ? s2 ? P : S : s2 ? p.K : _.Z, [s2, v2]);
        return (0, i.jsx)(X, {
          className: (0, n.$)(x2, { [C().root]: M2 }),
          disabled: null === g2.entityMeta || b2.isAdvertShown && !s2,
          isPlaying: B || false,
          canMoveBackward: g2.canMoveBackward && !b2.isAdvertShown,
          canMoveForward: g2.canMoveForward && !b2.isAdvertShown,
          withShuffle: h2,
          withRepeat: f2,
          canShuffle: g2.canShuffle,
          shuffle: g2.shuffle,
          onClickPlayPause: D,
          onClickNext: F,
          onClickPrev: z,
          canRewind: R,
          onRewindBackwardsClick: E2,
          onRewindForwardClick: w2,
          canChangeRepeatMode: g2.canChangeRepeatMode,
          repeatMode: g2.repeatMode,
          onRepeatClick: V,
          onShuffleClick: $
        });
      });
    },
    83675: (e, t, a) => {
      "use strict";
      a.d(t, { a: () => _ });
      var i = a(54486), n = a(50420), s = a(28303), l = a(43426), o = a(31500), r = a(8817), c = a(77881), d = a(5956), u = a(16045), p = a(93011), m = a(91129), C = a.n(m);
      let _ = (0, s.PA)((e2) => {
        let {
          className: t2,
          withShuffle: a2,
          shuffle: s2,
          canMoveBackward: m2,
          canMoveForward: _2,
          onClickNext: v,
          onClickPrev: x,
          withRepeat: h,
          repeatMode: f,
          playButton: g,
          isDisabledShuffle: N,
          isDisabledRepeat: b,
          onRepeatClick: I,
          onShuffleClick: y
        } = e2, { formatMessage: S } = (0, l.A)(), M = (0, r.c)(() => {
          v();
        }), A = (0, r.c)(() => {
          x();
        });
        return (0, i.jsxs)("div", {
          className: (0, n.$)(C().root, t2),
          children: [
            a2 && (0, i.jsx)("div", {
              className: C().buttonContainer,
              children: (0, i.jsx)(p.ShuffleButton, {
                className: C().sonataButton,
                size: "xxxs",
                variant: "text",
                iconSize: "xs",
                isDisabled: N,
                shuffle: s2,
                onClick: y,
                ...(0, o.Am)(o.Kq.sonata.SHUFFLE_BUTTON)
              })
            }),
            (0, i.jsxs)("div", {
              className: C().sonataButtons,
              children: [
                (0, i.jsx)(c.$, {
                  className: C().sonataButton,
                  variant: "text",
                  size: "m",
                  radius: "round",
                  "aria-hidden": !m2,
                  disabled: !m2,
                  withRipple: false,
                  "aria-label": S({ id: "player-actions.previous-track" }),
                  icon: (0, i.jsx)(d.Icon, { variant: "previous", size: "xxs" }),
                  onClick: A,
                  ...(0, o.Am)(o.Kq.sonata.PREVIOUS_TRACK_BUTTON)
                }),
                g,
                (0, i.jsx)(c.$, {
                  className: C().sonataButton,
                  radius: "round",
                  size: "m",
                  variant: "text",
                  disabled: !_2,
                  "aria-hidden": !_2,
                  withRipple: false,
                  "aria-label": S({ id: "player-actions.next-track" }),
                  icon: (0, i.jsx)(d.Icon, { variant: "next", size: "xxs" }),
                  onClick: M,
                  ...(0, o.Am)(o.Kq.sonata.NEXT_TRACK_BUTTON)
                })
              ]
            }),
            h && (0, i.jsx)("div", {
              className: C().buttonContainer,
              children: (0, i.jsx)(u.RepeatButton, {
                className: C().sonataButton,
                size: "xxxs",
                variant: "text",
                isDisabled: b,
                iconSize: "xs",
                repeatMode: f,
                onClick: I
              })
            })
          ]
        });
      });
    },
    84096: (e, t, a) => {
      "use strict";
      a.d(t, { useOnRepeatClick: () => r });
      var i = a(54486), n = a(3269), s = a(8817), l = a(74125), o = a(94953);
      let r = () => {
        let { notify: e2 } = (0, l.lkh)(), { fullscreenPlayer: t2 } = (0, l.Pjs)(), a2 = (0, l.eGp)();
        return (0, s.c)((s2, r2) => {
          if (null === s2.entityMeta || !s2.canChangeRepeatMode) return;
          let c = ((e3, t3) => t3 ? e3 === n.pM.NONE ? n.pM.ONE : n.pM.NONE : e3 === n.pM.NONE ? n.pM.CONTEXT : e3 === n.pM.CONTEXT ? n.pM.ONE : n.pM.NONE)(s2.repeatMode, s2.isVibeContext);
          null == a2 || a2.setRepeatMode(c, r2), e2((0, i.jsx)(o.NotificationRepeat, { repeatMode: c }), {
            containerId: t2.modal.isOpened ? l.uQT.FULLSCREEN_INFO : l.uQT.INFO
          });
        });
      };
    },
    84883: (e, t, a) => {
      "use strict";
      a.d(t, { useClipDisclaimer: () => n });
      var i = a(74125);
      let n = (e2) => {
        let { clip: t2, callback: a2, disclaimerRejectHandler: n2 } = e2;
        return (0, i.lVe)({
          entity: t2,
          callback: a2,
          onReject: n2,
          modalBehavior: { closeOnOutside: false, closeOnEscape: false },
          preventDefaultWhenSafe: true
        });
      };
    },
    87537: (e) => {
      e.exports = {
        icon: "NotificationShuffle_icon__U_ape",
        message: "NotificationShuffle_message__BNxJm",
        icon_unset: "NotificationShuffle_icon_unset__y1jg_"
      };
    },
    91129: (e) => {
      e.exports = {
        root: "BaseSonataControlsDesktop_root__E6wjA",
        sonataButtons: "BaseSonataControlsDesktop_sonataButtons__7vLtw",
        sonataButton: "BaseSonataControlsDesktop_sonataButton__GbwFt",
        playButtonIcon: "BaseSonataControlsDesktop_playButtonIcon__TlFqv",
        buttonContainer: "BaseSonataControlsDesktop_buttonContainer__EB404"
      };
    },
    93011: (e, t, a) => {
      "use strict";
      a.d(t, { ShuffleButton: () => p });
      var i = a(54486), n = a(50420), s = a(43426), l = a(31500), o = a(8817), r = a(77881), c = a(5956), d = a(72113), u = a.n(d);
      let p = (e2) => {
        let {
          isDisabled: t2,
          shuffle: a2,
          className: d2,
          size: p2 = "xxxs",
          variant: m = "default",
          iconSize: C = "xs",
          color: _,
          onClick: v
        } = e2, { formatMessage: x } = (0, s.A)(), h = (0, o.c)((e3) => {
          null == v || v(), e3.stopPropagation();
        });
        return (0, i.jsx)(r.$, {
          className: d2,
          radius: "round",
          size: p2,
          variant: m,
          color: _,
          withRipple: false,
          disabled: t2,
          "aria-label": x({ id: "player-actions.shuffle" }),
          "aria-pressed": !t2 && a2,
          "aria-hidden": t2,
          icon: (0, i.jsx)(c.Icon, {
            variant: "shuffle",
            size: C,
            className: (0, n.$)(u().shuffleIcon, {
              [u().shuffleIcon_disabled]: t2,
              [u().shuffleIcon_on]: !t2 && a2,
              [u().shuffleIcon_off]: !t2 && !a2
            })
          }),
          onClick: h,
          ...(0, l.Am)(!a2 || t2 ? l.Kq.sonata.SHUFFLE_BUTTON : l.Kq.sonata.SHUFFLE_BUTTON_ON)
        });
      };
    },
    94953: (e, t, a) => {
      "use strict";
      a.d(t, { NotificationRepeat: () => m });
      var i = a(54486), n = a(50420), s = a(43426), l = a(3269), o = a(5956), r = a(39610), c = a(97800), d = a(80585), u = a(15647), p = a.n(u);
      let m = (e2) => {
        let t2, { repeatMode: a2, closeToast: u2 } = e2, { formatMessage: m2 } = (0, s.A)(), C = a2 === l.pM.ONE ? "repeat_one" : "repeat";
        switch (a2) {
          case l.pM.CONTEXT:
            t2 = m2({ id: "notifications-info.change-repeat-context" });
            break;
          case l.pM.ONE:
            t2 = m2({ id: "notifications-info.change-repeat-track" });
            break;
          case l.pM.NONE:
          default:
            t2 = m2({ id: "notifications-info.change-repeat-none" });
        }
        return (0, i.jsx)(d.$W, {
          cover: (0, i.jsx)(o.Icon, {
            className: (0, n.$)(p().icon, { [p().icon_unset]: a2 === l.pM.NONE }),
            size: "xs",
            variant: C
          }),
          message: (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)(r.q, { children: (0, i.jsx)("p", { role: "alert", "aria-label": t2 }) }),
              (0, i.jsx)(c.Caption, {
                className: p().message,
                variant: "div",
                type: "controls",
                size: "m",
                "aria-hidden": true,
                children: t2
              })
            ]
          }),
          closeToast: u2,
          coverRadius: "s"
        });
      };
    },
    95424: (e, t, a) => {
      "use strict";
      a.d(t, { F: () => d });
      var i, n = a(94377), s = a(61910), l = {
        352: (e2) => {
          e2.exports = n;
        },
        810: (e2) => {
          e2.exports = i || (i = a.t(s, 2));
        }
      }, o = {};
      function r(e2) {
        var t2 = o[e2];
        if (void 0 !== t2) return t2.exports;
        var a2 = o[e2] = { exports: {} };
        return l[e2](a2, a2.exports, r), a2.exports;
      }
      var c = {};
      (() => {
        Object.defineProperty(c, "__esModule", { value: true }), c.useDebouncedToggle = void 0;
        let e2 = r(352), t2 = r(810);
        c.useDebouncedToggle = (a2) => {
          let { delay: i2, initialState: n2, throttleTimeout: s2 } = a2, l2 = (0, t2.useRef)(null), [o2, r2] = (0, t2.useState)(!!n2), c2 = (0, t2.useMemo)(
            () => (0, e2.throttle)(() => {
              r2(!n2), l2.current && window.clearTimeout(l2.current), l2.current = window.setTimeout(() => {
                r2(!!n2);
              }, i2);
            }, s2),
            [i2, n2, s2]
          ), d2 = (0, t2.useCallback)(() => {
            r2(!!n2), l2.current && window.clearTimeout(l2.current);
          }, [n2]);
          return (0, t2.useEffect)(
            () => () => {
              l2.current && window.clearTimeout(l2.current);
            },
            []
          ), { state: o2, handleDebouncedToggle: c2, reset: d2 };
        };
      })(), c.__esModule;
      var d = c.useDebouncedToggle;
    },
    97719: (e, t, a) => {
      "use strict";
      a.d(t, {
        QQ: () => M,
        Op: () => A,
        x5: () => S,
        jh: () => E.PromoLandingSonataControls,
        s_: () => P.RepeatButton,
        uP: () => w.ShuffleButton,
        $u: () => T.SonataControls,
        bG: () => k,
        qF: () => O.SonataVideoControls,
        EX: () => o,
        li: () => c,
        pE: () => p,
        AA: () => m.useOnRepeatClick,
        e9: () => C.useOnShuffleClick,
        d0: () => _.useToggleMute
      });
      var i = a(93064), n = a(5693), s = a(63695), l = a(74125);
      let o = (e2) => {
        if (e2.data.type !== n.R.Clip) return null;
        {
          var t2;
          let a2 = e2.data.meta;
          if (!a2.clipId) return null;
          let n2 = null == (t2 = a2.artists) ? void 0 : t2.map((e3) => (0, s.as)({ artist: e3 })), { available: o2, disclaimers: r2 } = (0, l.fyr)(a2);
          return (0, i.wg)({
            clipId: a2.clipId,
            title: a2.title,
            thumbnail: a2.thumbnail,
            duration: a2.duration,
            previewUrl: a2.previewUrl,
            isAvailable: o2,
            disclaimers: r2,
            artists: n2,
            isHiddenFromSonataQueue: e2.hidden
          });
        }
      };
      var r = a(89461);
      let c = (e2, t2) => ({ type: r.z4.Unloaded, meta: { id: e2, albumId: t2 } });
      var d = a(46423), u = a(54460);
      let p = (e2) => {
        var t2, a2, o2;
        switch (e2.data.type) {
          case n.R.Generative: {
            let a3 = e2.data.meta, n2 = (0, l.QBb)(null == a3 ? void 0 : a3.derivedColors);
            return (0, i.wg)({
              id: String(a3.id),
              coverUri: a3.imageUrl,
              title: null != (t2 = a3.title) ? t2 : "",
              isAvailable: true,
              isRemoved: false,
              averageColor: n2
            });
          }
          case n.R.Clip:
          case r.z4.Unloaded:
          case n.R.Radio:
            return null;
          default: {
            let t3 = e2.data.meta, n2 = null == (a2 = t3.artists) ? void 0 : a2.map(s.dM), l2 = null == (o2 = t3.albums) ? void 0 : o2.map(d.e7);
            return (0, i.wg)({ ...(0, u.gK)(t3), artists: n2, albums: l2, isHiddenFromSonataQueue: e2.hidden });
          }
        }
      };
      var m = a(84096), C = a(29476), _ = a(23897), v = a(98388), x = a(63930), h = a(63585), f = a(30630), g = a(3269);
      let N = i.gK.model("UnloadedEntityMeta", {
        id: i.gK.union(i.gK.number, i.gK.string),
        albumId: i.gK.maybe(i.gK.union(i.gK.number, i.gK.string))
      }), b = i.gK.model("UnloadedEntityData", { meta: N, type: i.gK.literal(r.z4.Unloaded) });
      var I = a(8075), y = a(42140);
      let S = u.OQ.props({
        artists: i.gK.array(s.PK),
        albums: i.gK.array(d.GI),
        chart: i.gK.maybe(y.Iz),
        isHiddenFromSonataQueue: i.gK.maybe(i.gK.boolean)
      }).views((e2) => ({
        get idWithContext() {
          return e2.albumId ? "".concat(e2.id, ":").concat(e2.albumId) : e2.id;
        },
        get artistsNames() {
          var t2;
          return null == (t2 = e2.artists) ? void 0 : t2.map((e3) => e3.name).join(", ");
        },
        get mainArtist() {
          var a2, i2;
          return null != (i2 = null == (a2 = e2.artists) ? void 0 : a2[0]) ? i2 : null;
        },
        get mainAlbum() {
          var n2, s2;
          return null != (s2 = null == (n2 = e2.albums) ? void 0 : n2[0]) ? s2 : null;
        },
        get index() {
          var l2, o2, r2;
          return null != (r2 = null == (o2 = e2.albums[0]) || null == (l2 = o2.trackPosition) ? void 0 : l2.index) ? r2 : null;
        },
        get isPodcast() {
          var c2;
          return e2.isTrackPodcast || (null == (c2 = this.mainAlbum) ? void 0 : c2.isPodcast);
        },
        get isAudiobook() {
          return e2.type === I.S.AUDIOBOOK;
        },
        get isFairyTale() {
          return e2.type === I.S.FAIRY_TALE;
        },
        get isNonMusic() {
          return this.isPodcast || this.isAudiobook || this.isFairyTale;
        },
        get isAvailableOnlyForPlus() {
          var d2;
          return !!(null == (d2 = this.mainAlbum) ? void 0 : d2.isAvailableOnlyForPlus);
        }
      })).actions((e2) => ({
        changeTrackInfo: (0, i.L3)(function* (t2, a2) {
          let { ugcResource: n2, modelActionsLogger: o2 } = (0, i._$)(e2);
          if (e2.artists.map((e3) => e3.name).join(", ") === a2 && t2 === e2.title) return l.FlZ.OK;
          try {
            var r2;
            yield n2.changeTrack({ trackId: e2.id, title: t2, artist: a2 }), e2.title = t2;
            let o3 = (null == (r2 = e2.artists[0]) ? void 0 : r2.id) || "0";
            if (e2.artists = (0, i.wg)([]), a2) {
              let t3 = s.PK.create({ id: o3, name: a2, isAvailable: true });
              e2.artists = (0, i.wg)([t3]);
            }
            return l.FlZ.OK;
          } catch (e3) {
            return o2.error(e3), l.FlZ.ERROR;
          }
        })
      })), M = i.gK.model("BaseSonataState", {
        contextType: i.gK.maybeNull(i.gK.enumeration(Object.values(h.K))),
        contextId: i.gK.maybeNull(i.gK.string),
        entityMeta: i.gK.maybeNull(S),
        status: i.gK.enumeration(Object.values(r.MT)),
        canMoveForward: i.gK.boolean,
        canMoveBackward: i.gK.boolean,
        canSpeed: i.gK.boolean,
        repeatMode: i.gK.enumeration(Object.values(g.pM)),
        canChangeRepeatMode: i.gK.boolean,
        volume: i.gK.maybe(i.gK.number),
        speed: i.gK.maybe(i.gK.number),
        position: i.gK.maybeNull(i.gK.number),
        duration: i.gK.maybeNull(i.gK.number),
        canShuffle: i.gK.boolean,
        shuffle: i.gK.boolean,
        quality: i.gK.enumeration(Object.values(f.e)),
        unloadedEntitiesData: i.gK.maybe(i.gK.array(b))
      }).volatile(() => ({ volatileUnloadedEntitiesData: void 0 })).views((e2) => ({
        get unloadedEntitiesDataFromModels() {
          var t2;
          return null != (t2 = e2.volatileUnloadedEntitiesData) ? t2 : (0, x.HO)(e2.unloadedEntitiesData);
        },
        get isVibeContext() {
          return e2.contextType === h.K.Vibe;
        },
        get isGenerativeContext() {
          return e2.contextType === h.K.Generative;
        },
        get isPaused() {
          return e2.status === r.MT.PAUSED;
        },
        get isPlaying() {
          return e2.status === r.MT.PLAYING;
        },
        get isContextRepeatMode() {
          return e2.repeatMode === g.pM.CONTEXT;
        },
        get isOneRepeatMode() {
          return e2.repeatMode === g.pM.ONE;
        }
      })).actions((e2) => ({
        setContextId: (t2) => {
          e2.contextId = String(t2);
        },
        setContextType: (t2) => {
          e2.contextType = t2;
        },
        setEntityMeta: (t2) => {
          t2 && t2.data.meta && (e2.entityMeta = p(t2));
        },
        setUnloadedEntitiesData: (t2) => {
          t2 && (e2.volatileUnloadedEntitiesData = (0, v.A)(t2), e2.unloadedEntitiesData = (0, i.wg)(t2));
        },
        resetUnloadedEntitiesData: () => {
          e2.volatileUnloadedEntitiesData = void 0, e2.unloadedEntitiesData = void 0;
        },
        setStatus: (t2) => {
          e2.status = t2;
        },
        setCanMoveForward: (t2) => {
          e2.canMoveForward = t2;
        },
        setCanMoveBackward: (t2) => {
          e2.canMoveBackward = t2;
        },
        setVolume: (t2) => {
          e2.volume = t2;
        },
        setCanSpeed: (t2) => {
          e2.canSpeed = t2;
        },
        setSpeed: (t2) => {
          e2.speed = t2;
        },
        setRepeatMode: (t2) => {
          e2.repeatMode = t2;
        },
        setCanChangeRepeatMode: (t2) => {
          e2.canChangeRepeatMode = t2;
        },
        setCanShuffle: (t2) => {
          e2.canShuffle = t2;
        },
        setShuffle: (t2) => {
          e2.shuffle = t2;
        },
        setQuality: (t2) => {
          e2.quality = t2;
        },
        setPosition: (t2) => {
          e2.position = t2;
        },
        setDuration: (t2) => {
          e2.duration = t2;
        }
      })), A = a(54830).z8.props({ artists: i.gK.array(s.PK), isHiddenFromSonataQueue: i.gK.maybe(i.gK.boolean) }).views((e2) => ({
        get idWithContext() {
          return String(e2.clipId);
        }
      })), k = M.props({
        playlistFilter: i.gK.maybe(i.gK.string),
        areCoresRegistered: i.gK.boolean,
        isVHCoreRegistered: i.gK.boolean,
        shouldApplyYnisonState: i.gK.optional(i.gK.boolean, true),
        isCrossFadeEnabled: i.gK.boolean
      }).actions((e2) => ({
        setIsVHCoreRegistered(t2) {
          e2.isVHCoreRegistered = t2;
        },
        setPlaylistFilter: (t2) => {
          e2.playlistFilter = t2;
        },
        setCoresAsRegistered: (t2) => {
          e2.areCoresRegistered = t2;
        },
        setShouldApplyYnisonState: (t2) => {
          e2.shouldApplyYnisonState = t2;
        },
        setCrossFadeMode: (t2) => {
          let { containerStorage: a2 } = (0, i._$)(e2);
          a2.set(l.cYZ.CrossFadeMode, t2, { expires: 365 }), e2.isCrossFadeEnabled = t2;
        }
      })).named("SonataState");
      a(94953), a(62915);
      var E = a(61569), P = a(16045), w = a(93011), T = a(77091), O = a(46695);
    }
  }
]);
