(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [5288],
  {
    1690: (e, t, s) => {
      "use strict";
      s.d(t, { T: () => a });
      var l, i = s(63585);
      !(function(e2) {
        e2.ALBUM = "album", e2.PLAYLIST = "playlist";
      })(l || (l = {}));
      let a = (e2, t2) => {
        var s2, a2;
        return e2.type === l.ALBUM ? { type: i.K.Album, meta: { id: (null == (a2 = e2.album) ? void 0 : a2.id) || 0 }, from: t2 || "" } : { type: i.K.Playlist, meta: { id: (null == (s2 = e2.playlist) ? void 0 : s2.id) || "" }, from: t2 || "" };
      };
    },
    2192: (e) => {
      e.exports = {
        root: "CollectionKidsPage_root__nfE01",
        content: "CollectionKidsPage_content__hVB40",
        carouselBlocks: "CollectionKidsPage_carouselBlocks__q7f0T",
        tracksCarouselItem: "CollectionKidsPage_tracksCarouselItem__8WvD0",
        important: "CollectionKidsPage_important__GkZJX",
        carouselBlock: "CollectionKidsPage_carouselBlock___6XRJ",
        carouselBlockHeader: "CollectionKidsPage_carouselBlockHeader__fqs_v",
        emptyBlock: "CollectionKidsPage_emptyBlock__dc50I",
        emptyBlockIcon: "CollectionKidsPage_emptyBlockIcon__eVAMs",
        emptyBlockTitle: "CollectionKidsPage_emptyBlockTitle__TYUpU",
        footer: "CollectionKidsPage_footer__wEREs"
      };
    },
    2313: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionArtistsPage: () => N });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(43350), d = s(31500), m = s(97800), u = s(55616), _ = s(33276), C = s(74125), h = s(80585), g = s(14426), p = s.n(g), x = s(5956), P = s(43448), j = s.n(P);
      let y = (e2) => {
        let { className: t2 } = e2;
        return (0, l.jsxs)("div", {
          className: j().root,
          children: [
            (0, l.jsxs)("div", {
              className: (0, i.$)(j().emptyContent, t2),
              children: [
                (0, l.jsx)(x.Icon, { className: j().emptyContentIcon, size: "l", variant: "album" }),
                (0, l.jsx)(m.Heading, {
                  className: j().emptyContentTitle,
                  variant: "h3",
                  size: "xs",
                  children: (0, l.jsx)(r.A, { id: "error-messages.empty-collection-artists-title" })
                })
              ]
            }),
            (0, l.jsx)(h.A, { children: (0, l.jsx)(h.wi, { className: j().footer }) })
          ]
        });
      };
      var b = s(63695), A = s(42140), k = s(82206), S = s.n(k);
      let v = (0, a.PA)(() => {
        let { collection: e2 } = (0, C.Pjs)(), { formatMessage: t2 } = (0, n.A)(), s2 = t2({ id: "loading-messages.entity-is-loading" }, { entityName: t2({ id: "entity-names.artist" }) }), i2 = (0, o.useMemo)(
          () => e2.artists.topArtists.isResolved ? e2.artists.topArtists.items.map((s3, i3) => {
            var a2;
            let o2 = s3.listenTimeSeconds ? (0, b.Uw)(s3.listenTimeSeconds, t2) : null;
            return (0, l.jsx)(
              C.Bki,
              {
                objectType: c.ky.Artist,
                objectId: s3.artist.id,
                objectPosX: i3 + 1,
                objectPosY: 1,
                objectsCount: e2.artists.topArtists.items.length,
                children: (0, l.jsx)(
                  u.ao,
                  {
                    topTitleElement: s3.top && (0, l.jsx)(
                      A.t1,
                      {
                        className: S().chart,
                        position: s3.top.position,
                        progress: s3.top.progress,
                        weight: "bold",
                        positionClassName: S().position,
                        withIcon: 0 === i3,
                        withCrownIcon: 0 === i3
                      },
                      s3.getKey("ArtistTop")
                    ),
                    bottomTitleElement: o2 ? (0, l.jsx)(m.Caption, {
                      className: S().listenTime,
                      variant: "div",
                      type: "entity",
                      size: "s",
                      weight: "medium",
                      lineClamp: 1,
                      ...(0, d.Am)(d.Xk.collection.COLLECTION_TOP_ARTISTS_LISTEN_TIME),
                      children: o2
                    }) : void 0,
                    artist: s3.artist,
                    contentLinesCount: 4
                  },
                  null == (a2 = s3.artist) ? void 0 : a2.id
                )
              },
              s3.artist.id
            );
          }) : (0, l.jsx)(h.eI, {
            linesCount: 4,
            count: 3,
            isActive: true,
            "aria-label": s2,
            round: true,
            centered: true
          }),
          [t2, s2, e2.artists.topArtists.isResolved, e2.artists.topArtists.items]
        );
        return (0, l.jsxs)(C.FoH, {
          blockId: "collection_artists_top",
          blockType: "ARTISTS_TOP",
          blockPosX: 1,
          blockPosY: 1,
          blockIdForFrom: "collection_artists_top",
          objectsCount: e2.artists.topArtists.items.length,
          children: [
            (0, l.jsx)(m.Heading, {
              size: "s",
              weight: "bold",
              variant: "h2",
              className: S().subTitle,
              ...(0, d.Am)(d.Xk.collection.COLLECTION_TOP_ARTISTS_HEADING),
              children: (0, l.jsx)(r.A, { id: "entity-names.top-artists" })
            }),
            (0, l.jsx)("div", {
              className: S().gridLayout,
              ...(0, d.Am)(d.Xk.collection.COLLECTION_TOP_ARTISTS_GRID),
              children: i2
            })
          ]
        });
      }), N = (0, a.PA)(() => {
        let {
          user: e2,
          collection: t2,
          settings: { isMobile: s2 },
          library: a2
        } = (0, C.Pjs)(), { formatMessage: g2 } = (0, n.A)(), { contentScrollRef: x2, setContentScrollRef: P2 } = (0, C.gKY)(), j2 = (0, C.W6M)();
        (0, C.Jzs)(t2.artists.isResolved), (0, o.useEffect)(
          () => () => {
            t2.artists.reset();
          },
          [t2.artists]
        );
        let b2 = (0, o.useCallback)(
          (s3) => {
            e2.account.data.uid && t2.artists.getData({ userId: e2.account.data.uid, page: s3, pageSize: 20 });
          },
          [t2.artists, e2.account.data.uid]
        );
        (0, C.XcE)(t2.artists.pagesLoader, b2);
        let A2 = g2({ id: "loading-messages.entity-is-loading" }, { entityName: g2({ id: "entity-names.artist" }) }), k2 = (0, o.useCallback)(
          (e3) => {
            var s3;
            let i2 = null == (s3 = t2.artists.items) ? void 0 : s3[e3];
            return i2 ? (0, l.jsx)(C.FoH, {
              blockId: "collection_artist",
              blockType: "ARTIST",
              blockPosX: e3 + 1,
              blockPosY: 1,
              blockIdForFrom: i2.id,
              objectsCount: t2.artists.items.length,
              children: (0, l.jsx)(C.Bki, {
                objectType: c.ky.Artist,
                objectId: i2.id,
                objectPosX: 1,
                objectPosY: 1,
                objectsCount: t2.artists.items.length,
                children: (0, l.jsx)(u.ao, { artist: i2, contentLinesCount: 3 }, i2.id)
              })
            }) : (0, l.jsx)(h.Vt, { isActive: true, "aria-label": A2, round: true, centered: true });
          },
          [t2.artists.items, A2]
        ), S2 = t2.artists.topArtists.items.length || !t2.artists.topArtists.isResolved, N2 = (0, o.useMemo)(
          () => S2 ? () => (0, l.jsxs)("div", {
            className: (0, i.$)(p().contentBlock, p().contentBlock_withMarginTop),
            children: [
              (0, l.jsx)(v, {}),
              (t2.artists.items.length > 0 || !t2.artists.isResolved) && (0, l.jsx)(m.Heading, {
                size: "s",
                weight: "bold",
                variant: "h2",
                className: p().subTitle,
                children: (0, l.jsx)(r.A, { id: "entity-names.liked-artist" })
              })
            ]
          }) : null,
          [S2, t2.artists.items.length, t2.artists.isResolved]
        ), L = (0, o.useMemo)(
          () => ({
            Header: N2,
            Footer: () => (0, l.jsx)(h.A, { children: (0, l.jsx)(h.wi, { className: p().footer }) })
          }),
          [N2]
        ), E = t2.artists.isShimmerVisible ? 10 : t2.artists.items.length, I = (0, o.useMemo)(
          () => 0 === t2.artists.items.length && 0 === t2.artists.topArtists.items.length && t2.artists.isResolved ? (0, l.jsx)(y, {}) : (0, l.jsx)(h.$$, {
            className: (0, i.$)(p().scrollContainer, p().important),
            customComponents: L,
            itemContentCallback: k2,
            initialItemCount: E,
            totalCount: E,
            onGetDataByPage: b2,
            pageSize: 20,
            totalRequests: t2.artists.requestsCount,
            listClassName: (0, i.$)(p().contentBlock, p().gridLayout, {
              [p().contentBlock_withMarginTop]: !S2
            }),
            itemClassName: p().item,
            handleRef: P2,
            context: { listAriaLabel: g2({ id: "collection.liked-artists-list" }) },
            isMobileLayout: s2,
            useWindowScroll: s2
          }),
          [
            t2.artists.items.length,
            t2.artists.topArtists.items.length,
            t2.artists.isResolved,
            t2.artists.requestsCount,
            L,
            g2,
            b2,
            s2,
            k2,
            E,
            P2,
            S2
          ]
        );
        if (e2.account.data.uid && t2.artists.isNeededToLoad) {
          let s3 = [t2.artists.getData({ userId: e2.account.data.uid }), t2.artists.getDataTopArtists(), a2.getData()];
          (0, o.use)(Promise.allSettled(s3));
        }
        return (0, l.jsx)(C.nVz, {
          pageId: C._Q$.OWN_ARTISTS,
          children: (0, l.jsx)(C.jPc, {
            children: (0, l.jsx)(_.hO, {
              scrollElement: x2,
              outerTitle: g2({ id: "entity-names.artists" }),
              children: (0, l.jsxs)("div", {
                className: p().root,
                ...(0, d.Am)(d.Xk.collection.COLLECTION_ARTISTS_PAGE),
                children: [
                  (0, l.jsx)(h.Y9, {
                    variant: h.Vw.TEXT,
                    withForwardControl: false,
                    withBackwardControl: j2.canBack,
                    children: (0, l.jsx)(m.Heading, {
                      id: "collection-artists-header",
                      variant: "h1",
                      weight: "bold",
                      size: "xl",
                      lineClamp: 1,
                      children: (0, l.jsx)(r.A, { id: "entity-names.artists" })
                    })
                  }),
                  I
                ]
              })
            })
          })
        });
      });
    },
    2405: (e, t, s) => {
      "use strict";
      s.d(t, { SortDropdown: () => P });
      var l = s(54486), i = s(28303), a = s(61910), o = s(47713), n = s(31500), r = s(11405), c = s(8817), d = s(77881), m = s(71656), u = s(5956), _ = s(97800), C = s(74125), h = s(90229), g = s(46353), p = s.n(g);
      let x = {
        [r.g.RATING]: (0, l.jsx)(o.A, { id: "sort.sort-by-rating" }),
        [r.g.YEAR]: (0, l.jsx)(o.A, { id: "sort.sort-by-year" })
      }, P = (0, i.PA)((e2) => {
        var t2;
        let { sortModel: s2, onSort: i2 } = e2, {
          settings: { isMobile: g2 }
        } = (0, C.Pjs)(), P2 = (0, c.c)((e3) => {
          (0, h.W)(e3.id) && s2.sortBy !== e3.id && (s2.setSortBy(e3.id), i2());
        }), j = (0, a.useMemo)(
          () => g2 ? (0, l.jsx)(d.$, {
            radius: "xxxl",
            className: p().button,
            icon: (0, l.jsx)(u.Icon, { variant: "filter", size: "xs" })
          }) : (0, l.jsxs)(d.$, {
            radius: "xxxl",
            className: p().button,
            ...(0, n.Am)(n.Kq.sort.SORT_DROPDOWN_BUTTON),
            children: [
              (0, l.jsx)(_.Caption, {
                variant: "span",
                size: "m",
                weight: "medium",
                ...(0, n.Am)(n.Kq.sort.SORT_DROPDOWN_BUTTON_CAPTION),
                children: s2.sortBy ? x[s2.sortBy] : (0, l.jsx)(o.A, { id: "sort.select-filter" })
              }),
              (0, l.jsx)(u.Icon, {
                size: "xxs",
                variant: "arrowDown",
                ...(0, n.Am)(n.Kq.sort.SORT_DROPDOWN_BUTTON_ICON)
              })
            ]
          }),
          [g2, s2.sortBy]
        );
        return (0, l.jsx)(m.ms, {
          placement: g2 ? "bottom" : "top",
          isMobile: g2,
          strategy: "fixed",
          className: p().root,
          onSelect: P2,
          reference: j,
          offsetOptions: { mainAxis: 10, crossAxis: -50 },
          defaultValue: null != (t2 = s2.sortBy) ? t2 : r.g.YEAR,
          containerClassName: p().container,
          header: g2 ? (0, l.jsx)("div", { className: p().header }) : void 0,
          ...(0, n.Am)(n.Kq.sort.SORT_DROPDOWN),
          children: Object.values(r.g).map(
            (e3) => (0, l.jsx)(m.c$, { id: e3, label: x[e3], ...(0, n.Am)(n.Kq.sort.SORT_DROPDOWN_ITEM) }, e3)
          )
        });
      });
    },
    4696: (e, t, s) => {
      "use strict";
      s.d(t, { c: () => l });
      let l = 20;
    },
    8162: (e) => {
      e.exports = {
        root: "CollectionKidsPlaylistsPage_root__RXH06",
        scrollContainer: "CollectionKidsPlaylistsPage_scrollContainer__F_oj2",
        important: "CollectionKidsPlaylistsPage_important__5V_zc",
        footer: "CollectionKidsPlaylistsPage_footer__R41Ol",
        item: "CollectionKidsPlaylistsPage_item__ht83l",
        content: "CollectionKidsPlaylistsPage_content__6Oo1m"
      };
    },
    11900: (e, t, s) => {
      "use strict";
      s.d(t, { h: () => l });
      var l = (function(e2) {
        return e2.TRACKS = "tracks", e2.ARTISTS = "artists", e2;
      })({});
    },
    12652: (e, t, s) => {
      "use strict";
      s.d(t, { F: () => u });
      var l = s(54486), i = s(28303), a = s(47713), o = s(77881), n = s(5956), r = s(97800), c = s(74125), d = s(82552), m = s.n(d);
      let u = (0, i.PA)((e2) => {
        let { title: t2 } = e2, s2 = (0, c.ZpR)(c.Zyd.nonMusic.href);
        return (0, l.jsxs)("div", {
          className: m().root,
          children: [
            (0, l.jsx)("div", {
              className: m().iconBackground,
              children: (0, l.jsx)(n.Icon, { variant: "like", size: "l" })
            }),
            (0, l.jsx)(r.Heading, { className: m().title, variant: "h3", size: "xs", children: t2 }),
            (0, l.jsx)(o.$, {
              onClick: s2,
              className: m().button,
              role: "link",
              color: "secondary",
              size: "s",
              radius: "xxxl",
              children: (0, l.jsx)(r.Caption, {
                type: "controls",
                variant: "span",
                size: "m",
                children: (0, l.jsx)(a.A, { id: "error-messages.empty-shelf-liked-page-link" })
              })
            })
          ]
        });
      });
    },
    12778: (e) => {
      e.exports = {
        root: "CollectionPlaylistsPage_root__1QnBw",
        content: "CollectionPlaylistsPage_content__P3Br2",
        content_withGridLayout: "CollectionPlaylistsPage_content_withGridLayout__ytZKv",
        footer: "CollectionPlaylistsPage_footer__8nXuA",
        item: "CollectionPlaylistsPage_item__SvtpO",
        scrollContainer: "CollectionPlaylistsPage_scrollContainer__ECphU",
        important: "CollectionPlaylistsPage_important__YtxxZ"
      };
    },
    13144: (e) => {
      e.exports = {
        root: "CollectionDislikesPageHeader_root__lZ6LT",
        container: "CollectionDislikesPageHeader_container__ACUbW",
        title: "CollectionDislikesPageHeader_title__6h9Km",
        tabs: "CollectionDislikesPageHeader_tabs__gt5AJ",
        tab: "CollectionDislikesPageHeader_tab__bxN5I",
        tabsShimmer: "CollectionDislikesPageHeader_tabsShimmer__akKoq",
        tabShimmer: "CollectionDislikesPageHeader_tabShimmer__0QLuH",
        staticHeader: "CollectionDislikesPageHeader_staticHeader__75rsF",
        important: "CollectionDislikesPageHeader_important__5ZM6D",
        stickyHeader: "CollectionDislikesPageHeader_stickyHeader__cAkxR"
      };
    },
    14426: (e) => {
      e.exports = {
        root: "CollectionArtistsPage_root__EH25F",
        scrollContainer: "CollectionArtistsPage_scrollContainer__tT6NQ",
        important: "CollectionArtistsPage_important__MG_XV",
        footer: "CollectionArtistsPage_footer__aZrx3",
        item: "CollectionArtistsPage_item___cy_9",
        contentBlock: "CollectionArtistsPage_contentBlock__5QDcr",
        contentBlock_withMarginTop: "CollectionArtistsPage_contentBlock_withMarginTop__e4_VX",
        gridLayout: "CollectionArtistsPage_gridLayout__00brJ",
        subTitle: "CollectionArtistsPage_subTitle__My70z"
      };
    },
    16314: (e) => {
      e.exports = {
        root: "CollectionPage_root__CZAxL",
        root_withCollectionColor: "CollectionPage_root_withCollectionColor__4kV02",
        content: "CollectionPage_content__c3f8z",
        header: "CollectionPage_header__z193s",
        description: "CollectionPage_description__A3dny",
        collectionColor: "CollectionPage_collectionColor__M5l1f",
        landing: "CollectionPage_landing__B4jW_",
        landing_onlyWizard: "CollectionPage_landing_onlyWizard__umeEK",
        footer: "CollectionPage_footer__9kzD0",
        footer_onlyWizard: "CollectionPage_footer_onlyWizard__FxCwa",
        error: "CollectionPage_error__xs4ZH"
      };
    },
    17714: (e) => {
      e.exports = {
        root: "CollectionNonMusicPage_root__U6DRX",
        scrollableContainer: "CollectionNonMusicPage_scrollableContainer__iIZvl",
        important: "CollectionNonMusicPage_important__Y9D5x",
        content: "CollectionNonMusicPage_content__d8E7R",
        likedBlocks: "CollectionNonMusicPage_likedBlocks__cNqyq",
        carousel: "CollectionNonMusicPage_carousel__zDCY0",
        blockHeader: "CollectionNonMusicPage_blockHeader__PoAFY",
        footer: "CollectionNonMusicPage_footer__9feIA",
        shelfBlockCarousel: "CollectionNonMusicPage_shelfBlockCarousel__Kd6DB",
        shelfBlockHeader: "CollectionNonMusicPage_shelfBlockHeader__yfFcf"
      };
    },
    17928: (e) => {
      e.exports = {
        root: "CollectionShelfLikedPage_root__KRXgN",
        footer: "CollectionShelfLikedPage_footer__NgcOJ",
        scrollContainer: "CollectionShelfLikedPage_scrollContainer__IBlT7",
        important: "CollectionShelfLikedPage_important__R4MBr",
        content: "CollectionShelfLikedPage_content__KHWpo",
        item: "CollectionShelfLikedPage_item__x5cqv"
      };
    },
    19434: (e) => {
      e.exports = {
        root: "CollectionShelfRecentlyPlayedPage_root__1eSLj",
        footer: "CollectionShelfRecentlyPlayedPage_footer__5pPcU",
        scrollContainer: "CollectionShelfRecentlyPlayedPage_scrollContainer__2ErJI",
        important: "CollectionShelfRecentlyPlayedPage_important___ajYP",
        content: "CollectionShelfRecentlyPlayedPage_content__p4qEp",
        item: "CollectionShelfRecentlyPlayedPage_item__gQR_c"
      };
    },
    19706: (e) => {
      e.exports = {
        root: "CollectionShelfPage_root__S0__c",
        scrollableContainer: "CollectionShelfPage_scrollableContainer__9f317",
        content: "CollectionShelfPage_content__AG3r8",
        block: "CollectionShelfPage_block__34jyy",
        blockHeader: "CollectionShelfPage_blockHeader__Qjoln",
        footer: "CollectionShelfPage_footer__pgWKV"
      };
    },
    19796: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionPlaylistsCreatedPage: () => p });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(97800), m = s(33276), u = s(83909), _ = s(74125), C = s(80585), h = s(68696), g = s.n(h);
      let p = (0, a.PA)(() => {
        let {
          user: e2,
          collection: {
            playlists: { playlistsCreated: t2 }
          },
          settings: { isMobile: s2 }
        } = (0, _.Pjs)(), { formatMessage: a2 } = (0, n.A)(), { contentScrollRef: h2, setContentScrollRef: p2 } = (0, _.gKY)(), x = (0, _.W6M)(), P = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(C.A, { children: (0, l.jsx)(C.wi, { className: g().footer }) }) }),
          []
        );
        (0, _.Jzs)(t2.isResolved);
        let j = (0, o.useCallback)(
          (s3) => {
            e2.account.data.uid && t2.getData({ userId: e2.account.data.uid, page: s3, pageSize: 20 });
          },
          [t2, e2.account.data.uid]
        );
        (0, _.XcE)(t2.pagesLoader, j), (0, o.useEffect)(
          () => () => {
            t2.reset();
          },
          [t2]
        ), e2.account.data.uid && t2.isNeededToLoad && (0, o.use)(t2.getData({ userId: e2.account.data.uid, page: 0, pageSize: 20 }));
        let y = t2.isShimmerVisible ? 20 : t2.items.length;
        return (0, l.jsx)(_.nVz, {
          pageId: _._Q$.OWN_PLAYLISTS,
          children: (0, l.jsx)(m.hO, {
            scrollElement: h2,
            outerTitle: a2({ id: "entity-names.my-playlists" }),
            children: (0, l.jsxs)("div", {
              className: g().root,
              ...(0, c.Am)(c.Xk.collection.COLLECTION_PLAYLISTS_CREATED_PAGE),
              children: [
                (0, l.jsx)(C.Y9, {
                  variant: C.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: x.canBack,
                  children: (0, l.jsx)(d.Heading, {
                    id: "collection-playlistsCreated-header",
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: (0, l.jsx)(r.A, { id: "entity-names.my-playlists" })
                  })
                }),
                (0, l.jsx)(C.$$, {
                  className: (0, i.$)(g().scrollContainer, g().important),
                  customComponents: P,
                  itemContentCallback: (e3) => {
                    let s3 = t2.items[e3], i2 = a2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: a2({ id: "entity-names.playlist" }) }
                    );
                    return s3 ? (0, l.jsx)(u.B6, { playlist: s3, contentLinesCount: 3 }, s3.key) : (0, l.jsx)(C.Vt, { "aria-label": i2 });
                  },
                  totalCount: y,
                  onGetDataByPage: j,
                  pageSize: 20,
                  totalRequests: t2.requestsCount,
                  listClassName: g().content,
                  itemClassName: g().item,
                  handleRef: p2,
                  context: { listAriaLabel: a2({ id: "collection.created-playlists-list" }) },
                  isMobileLayout: s2,
                  useWindowScroll: s2
                })
              ]
            })
          })
        });
      });
    },
    19816: (e) => {
      e.exports = {
        root: "CollectionAlbumsPageHeader_root__87L_c",
        container: "CollectionAlbumsPageHeader_container__96cIo",
        title: "CollectionAlbumsPageHeader_title__1Ps8d",
        tabs: "CollectionAlbumsPageHeader_tabs__P4GTY",
        tab: "CollectionAlbumsPageHeader_tab__JSFBc",
        tabsShimmer: "CollectionAlbumsPageHeader_tabsShimmer__fGlR0",
        tabShimmer: "CollectionAlbumsPageHeader_tabShimmer__9hCc6",
        staticHeader: "CollectionAlbumsPageHeader_staticHeader__YNfX4",
        important: "CollectionAlbumsPageHeader_important__0dgC2",
        stickyHeader: "CollectionAlbumsPageHeader_stickyHeader__L_1IS"
      };
    },
    20139: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionPage: () => j });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(6024), m = s(56231), u = s(97800), _ = s(4542), C = s(82644), h = s(33276), g = s(74125), p = s(80585), x = s(16314), P = s.n(x);
      let j = (0, a.PA)(() => {
        let { collection: e2, user: t2, library: s2, experiments: a2 } = (0, g.Pjs)(), { contentScrollRef: x2, setContentScrollRef: j2 } = (0, g.gKY)(), { formatMessage: y } = (0, n.A)(), b = !e2.landing.isRejected && !!t2.collectionHue && !a2.checkExperiment(g.zal.WebNextWaveAgentExperiment, "on");
        (0, o.useEffect)(() => () => e2.landing.reset(), [e2.landing]), (0, g.Jzs)(e2.landing.isResolved);
        let A = (0, _._9)(e2.landing), k = (0, o.useMemo)(() => {
          if (b && t2.collectionHue) return { "--collection-color": (0, g.eWZ)(t2.collectionHue) };
        }, [b, t2.collectionHue]), S = (0, o.useMemo)(
          () => ({
            color: (e3) => (0, l.jsx)(p.hj, {
              title: y({ id: "collection.collection-color-title" }),
              description: y({ id: "collection.collection-color-description" }),
              placement: "right",
              children: (0, l.jsx)("span", { className: P().collectionColor, style: k, children: e3 })
            })
          }),
          [k, y]
        );
        if (e2.landing.isNeededToLoad) {
          let l2 = [
            e2.landing.getSkeleton(
              { id: d.p.WEB_COLLECTION, showWizard: t2.settings.showWizard },
              { preloadBlocksCount: 2 }
            ),
            s2.getData()
          ];
          (0, o.use)(Promise.allSettled(l2));
        }
        return (0, l.jsx)(g.nVz, {
          pageId: g._Q$.OWN_COLLECTION,
          children: (0, l.jsxs)(h.hO, {
            scrollElement: x2,
            outerTitle: y({ id: "entity-names.collection" }),
            children: [
              (0, l.jsx)(p.Y9, {
                variant: p.Vw.TEXT,
                showControls: false,
                children: (0, l.jsxs)("div", {
                  className: P().header,
                  children: [
                    (0, l.jsx)(u.Heading, {
                      variant: "h1",
                      weight: "bold",
                      size: "xl",
                      children: (0, l.jsx)(r.A, { id: "entity-names.collection" })
                    }),
                    b && (0, l.jsx)(u.Caption, {
                      className: P().description,
                      variant: "div",
                      size: "m",
                      children: (0, l.jsx)(r.A, { id: "collection.collection-color", values: S })
                    })
                  ]
                })
              }),
              (0, l.jsxs)(m.N, {
                className: (0, i.$)(P().root, { [P().root_withCollectionColor]: b }),
                containerClassName: P().content,
                ref: j2,
                children: [
                  (0, l.jsx)("div", {
                    className: (0, i.$)(P().landing, { [P().landing_onlyWizard]: A }),
                    ...(0, c.Am)(c.Xk.collection.COLLECTION_PAGE),
                    children: (0, l.jsx)(_.EA, {
                      landing: e2.landing,
                      errorComponent: (0, l.jsx)(C.w, { className: P().error, withBackwardControl: false })
                    })
                  }),
                  (0, l.jsx)(p.A, { children: (0, l.jsx)(p.wi, { className: P().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    23430: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionShelfPage: () => v });
      var l = s(54486), i = s(28303), a = s(61910), o = s(43426), n = s(47713), r = s(31500), c = s(56231), d = s(97800), m = s(82644), u = s(33276), _ = s(74125), C = s(80585), h = s(99227), g = s(50420), p = s(27510), x = s(21365), P = s(1690), j = s(59255), y = s(62567), b = s.n(y);
      let A = (0, i.PA)((e2) => {
        var t2;
        let { className: s2, itemsCount: i2, headerClassName: o2 } = e2, {
          sonataState: n2,
          collection: {
            shelf: { recentlyPlayed: c2 }
          }
        } = (0, _.Pjs)(), d2 = (0, p.L)(() => {
          var e3;
          return null == (e3 = c2.entities) ? void 0 : e3.map((e4, t3) => {
            let s3 = (0, P.T)(e4, c2.typeForFrom);
            return (0, l.jsx)(
              x.Kd,
              {
                track: e4.track,
                playContextParams: {
                  contextData: s3,
                  queueParams: { index: t3, entityId: e4.track.id },
                  loadContextMeta: false,
                  entitiesData: n2.unloadedEntitiesDataFromModels
                },
                withPodcastName: true
              },
              e4.track.id
            );
          });
        });
        return (c2.isNeededToLoad && (0, a.use)(c2.getData()), !c2.isLoading && (null == (t2 = c2.entities) ? void 0 : t2.length)) ? (0, l.jsx)(C.$2, {
          blockHeaderClassName: (0, g.$)(b().header, o2),
          className: s2,
          carouselItemClassName: (0, g.$)(b().shelfColumn, b().important),
          shimmer: (0, l.jsx)(C.DS, { variant: _.Xjt.PLAYLIST, isActive: true }),
          isShimmerVisible: c2.isLoading,
          isShimmerActive: true,
          maxColumnsCount: C.DI.ONE,
          blockHeaderTitle: c2.title,
          itemsCountPerColumn: null != i2 ? i2 : 0,
          viewAllActionLink: _.Zyd.collectionShelfRecentlyPlayed.href,
          ...(0, r.Am)(r.Xk.collection.COLLECTION_SHELF_PAGE_RECENTLY_PLAYED_BLOCK),
          children: d2
        }) : (0, l.jsx)(j.E, { className: s2 });
      });
      var k = s(19706), S = s.n(k);
      let v = (0, i.PA)(() => {
        let {
          collection: { shelf: e2 }
        } = (0, _.Pjs)(), { contentScrollRef: t2, setContentScrollRef: s2 } = (0, _.gKY)(), { formatMessage: i2 } = (0, o.A)(), g2 = (0, _.W6M)();
        return ((0, a.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), (0, _.Jzs)(e2.isResolved), e2.isRejected) ? (0, l.jsx)(m.w, {}) : (0, l.jsxs)(u.hO, {
          scrollElement: t2,
          outerTitle: i2({ id: "page.shelf" }),
          children: [
            (0, l.jsx)(C.Y9, {
              variant: C.Vw.TEXT,
              withForwardControl: false,
              withBackwardControl: g2.canBack,
              children: (0, l.jsx)(d.Heading, {
                variant: "h2",
                weight: "bold",
                size: "xl",
                lineClamp: 1,
                children: (0, l.jsx)(n.A, { id: "page.shelf" })
              })
            }),
            (0, l.jsx)(c.N, {
              ref: s2,
              containerClassName: S().scrollableContainer,
              className: S().root,
              ...(0, r.Am)(r.Xk.collection.COLLECTION_SHELF_PAGE),
              children: (0, l.jsxs)("div", {
                className: S().content,
                children: [
                  e2.hasRecentlyPlayed && (0, l.jsx)(A, { className: S().block, headerClassName: S().blockHeader, itemsCount: 5 }),
                  e2.hasLiked && (0, l.jsx)(h.m, { className: S().block, headerClassName: S().blockHeader, itemsCount: 5 }),
                  (0, l.jsx)(C.A, { children: (0, l.jsx)(C.wi, { className: S().footer }) })
                ]
              })
            })
          ]
        });
      });
    },
    24159: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionPlaylistsPage: () => R });
      var l = s(54486), i = s(50420), a = s(28303), o = s(97396), n = s(61910), r = s(43426), c = s(31500), d = s(61288), m = s(47168), u = s(8817), _ = s(27510), C = s(33276), h = s(83909), g = s(13611), p = s(74125), x = s(80585), P = s(41663), j = s(51321);
      let y = (0, a.PA)((e2) => {
        let { style: t2, forwardRef: s2, context: i2, ...a2 } = e2, {
          collection: {
            playlists: { activeTabIndex: o2, tabIndexElement: n2 }
          }
        } = (0, p.Pjs)(), r2 = (0, j.useTabsState)(o2), c2 = null == i2 ? void 0 : i2.listAriaLabel;
        return (0, l.jsx)(j.TabPanel, {
          value: r2.value,
          name: r2.value,
          elementId: n2,
          "aria-label": c2,
          style: t2,
          ref: s2,
          ...a2
        });
      }), b = (0, n.forwardRef)((e2, t2) => (0, l.jsx)(y, { forwardRef: t2, ...e2 }));
      var A = s(12778), k = s.n(A), S = s(47713), v = s(5956), N = s(97800), L = s(32487), E = s.n(L);
      let I = (0, a.PA)((e2) => {
        let { activeTabIndex: t2, tabElementId: s2 } = e2;
        return (0, l.jsxs)(j.TabPanel, {
          value: t2,
          name: t2,
          elementId: s2,
          className: E().root,
          children: [
            (0, l.jsx)(v.Icon, { className: E().icon, size: "l", variant: "album" }),
            (0, l.jsx)(N.Heading, {
              className: E().title,
              variant: "h3",
              size: "xs",
              children: (0, l.jsx)(S.A, { id: "error-messages.empty-collection-liked-playlists" })
            })
          ]
        });
      }), T = () => {
        let e2 = (0, p.XJ9)(), {
          collection: { playlists: t2 }
        } = (0, p.Pjs)();
        return (0, n.useCallback)(
          (s2) => {
            switch (t2.setActiveTabIndex(s2), s2) {
              case P.a.CREATED: {
                let { href: t3 } = (0, p.uvd)(p.Zyd.collectionPlaylists.href, { query: { tab: p.W4C.CREATED } });
                e2(t3);
                break;
              }
              case P.a.LIKED: {
                let { href: t3 } = (0, p.uvd)(p.Zyd.collectionPlaylists.href, { query: { tab: p.W4C.LIKED } });
                e2(t3);
              }
            }
          },
          [e2, t2]
        );
      };
      var f = s(83155), w = s.n(f), D = s(22674);
      let M = () => (0, l.jsxs)("div", {
        className: w().tabsShimmer,
        children: [
          (0, l.jsx)(D.Shimmer, { className: w().tabShimmer }),
          (0, l.jsx)(D.Shimmer, { className: w().tabShimmer })
        ]
      }), B = (0, a.PA)(() => {
        let {
          collection: {
            playlists: { playlistsCreated: e2, playlistsLiked: t2, tabIndexElement: s2, activeTabIndex: i2 }
          }
        } = (0, p.Pjs)(), { formatMessage: a2 } = (0, r.A)(), o2 = (0, p.W6M)(), { isScrolling: d2 } = (0, n.useContext)(x.B9), m2 = T(), u2 = (0, n.useMemo)(
          () => e2.items.length ? "".concat(a2({ id: "collection.your-created-playlists" }), " • ").concat(e2.items.length) : a2({ id: "collection.your-created-playlists" }),
          [a2, e2.items.length]
        ), _2 = (0, n.useMemo)(
          () => t2.items.length ? "".concat(a2({ id: "collection.your-liked-playlists" }), " • ").concat(t2.items.length) : a2({ id: "collection.your-liked-playlists" }),
          [a2, t2.items.length]
        );
        return (0, l.jsxs)(l.Fragment, {
          children: [
            (0, l.jsx)("header", {
              className: w().root,
              "aria-hidden": d2,
              ...(0, c.Am)(c.Xk.collection.COLLECTION_PLAYLISTS_PAGE_STATIC_HEADER),
              children: (0, l.jsxs)("div", {
                className: w().container,
                children: [
                  o2.canBack && (0, l.jsx)(x.Lh, {
                    withForwardControl: false,
                    withBackwardControl: o2.canBack,
                    shouldFocusOnMount: !d2
                  }),
                  (0, l.jsx)(N.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    className: w().title,
                    ...(0, c.Am)(c.Xk.collection.COLLECTION_PLAYLISTS_PAGE_STATIC_HEADER_TITLE),
                    children: (0, l.jsx)(S.A, { id: "entity-names.artist-playlist" })
                  })
                ]
              })
            }),
            (0, l.jsxs)(x.wI, {
              isShimmerVisible: e2.isShimmerVisible,
              shimmer: (0, l.jsx)(M, {}),
              className: w().staticTabs,
              elementId: s2,
              value: i2,
              onTabChange: m2,
              children: [
                (0, l.jsx)(x.oz, {
                  className: w().tab,
                  value: P.a.CREATED,
                  title: u2,
                  "aria-label": a2({ id: "entity-names.created-playlists-count" }, { value: e2.items.length }),
                  "aria-hidden": d2,
                  tabIndex: d2 ? -1 : 0
                }),
                (0, l.jsx)(x.oz, {
                  className: w().tab,
                  value: P.a.LIKED,
                  title: _2,
                  "aria-label": a2({ id: "entity-names.liked-playlists-count" }, { value: t2.items.length }),
                  "aria-hidden": d2,
                  tabIndex: d2 ? -1 : 0
                })
              ]
            })
          ]
        });
      }), O = (0, a.PA)((e2) => {
        let { tabElementId: t2 } = e2, {
          collection: {
            playlists: { playlistsCreated: s2, playlistsLiked: a2, activeTabIndex: o2 }
          }
        } = (0, p.Pjs)(), { formatMessage: d2 } = (0, r.A)(), { isScrolling: m2 } = (0, n.useContext)(x.B9), u2 = (0, p.W6M)(), _2 = T(), C2 = (0, n.useMemo)(
          () => s2.items.length ? "".concat(d2({ id: "collection.your-created-playlists" }), " • ").concat(s2.items.length) : d2({ id: "collection.your-created-playlists" }),
          [d2, s2.items.length]
        ), h2 = (0, n.useMemo)(
          () => a2.items.length ? "".concat(d2({ id: "collection.your-liked-playlists" }), " • ").concat(a2.items.length) : d2({ id: "collection.your-liked-playlists" }),
          [d2, a2.items.length]
        );
        return (0, l.jsx)(x.Y9, {
          variant: x.Vw.COMPOSITE,
          staticClassName: (0, i.$)(w().staticHeader, w().important),
          "aria-hidden": !m2,
          stickyClassName: (0, i.$)(w().stickyHeader, w().important),
          containerProps: (0, c.Am)(c.Xk.collection.COLLECTION_PLAYLISTS_PAGE_STICKY_HEADER),
          stickyChild: (0, l.jsxs)("div", {
            className: w().container,
            children: [
              u2.canBack && (0, l.jsx)(x.Lh, {
                withForwardControl: false,
                withBackwardControl: u2.canBack,
                shouldFocusOnMount: false,
                buttonSize: "xs"
              }),
              (0, l.jsxs)(x.wI, {
                isShimmerVisible: s2.isShimmerVisible,
                shimmer: (0, l.jsx)(M, {}),
                className: w().stickyTabs,
                elementId: t2,
                value: o2,
                onTabChange: _2,
                children: [
                  (0, l.jsx)(x.oz, {
                    className: w().tab,
                    value: P.a.CREATED,
                    title: C2,
                    "aria-label": d2({ id: "entity-names.created-playlists-count" }, { value: s2.items.length }),
                    "aria-hidden": !m2,
                    tabIndex: m2 ? 0 : -1
                  }),
                  (0, l.jsx)(x.oz, {
                    className: w().tab,
                    value: P.a.LIKED,
                    title: h2,
                    "aria-label": d2({ id: "entity-names.liked-playlists-count" }, { value: a2.items.length }),
                    "aria-hidden": !m2,
                    tabIndex: m2 ? 0 : -1
                  })
                ]
              })
            ]
          })
        });
      }), R = (0, a.PA)(() => {
        let e2 = (0, o.useSearchParams)(), {
          user: t2,
          collection: {
            playlists: {
              playlistsCreated: s2,
              playlistsLiked: a2,
              setTabIndexElement: j2,
              reset: y2,
              setActiveTabIndex: A2,
              isCreatedTabActive: S2,
              isLikedTabActive: v2,
              activeTabIndex: N2,
              activePlaylistsModel: L2,
              isEmptyLikedTab: E2
            }
          },
          library: T2,
          settings: { isMobile: f2 }
        } = (0, p.Pjs)(), { contentScrollRef: w2, setContentScrollRef: D2 } = (0, p.gKY)(), M2 = (0, n.useId)();
        (0, n.useEffect)(() => {
          j2(M2);
        }, [M2, j2]);
        let { formatMessage: R2 } = (0, r.A)();
        if ((0, n.useLayoutEffect)(() => {
          switch (e2.get(p.K3F.TAB)) {
            case p.W4C.CREATED:
              A2(P.a.CREATED);
              break;
            case p.W4C.LIKED:
              A2(P.a.LIKED);
              break;
            default:
              A2(P.a.CREATED);
          }
        }, [e2, A2]), (0, p.Jzs)(s2.isResolved), (0, n.useEffect)(
          () => () => {
            y2();
          },
          [y2]
        ), t2.account.data.uid && s2.isNeededToLoad) {
          let e3 = [
            s2.getData({ userId: t2.account.data.uid, page: 0, pageSize: 20 }),
            a2.getData({
              userId: t2.account.data.uid,
              sortOrder: d.x.DESC,
              playlistMetaType: m.S.MUSIC,
              page: 0,
              pageSize: 20
            }),
            T2.getData()
          ];
          (0, n.use)(Promise.allSettled(e3));
        }
        let K = (0, n.useMemo)(
          () => ({
            Header: () => (0, l.jsx)(B, {}),
            Footer: () => (0, l.jsx)(x.A, { children: (0, l.jsx)(x.wi, { className: k().footer }) }),
            List: b
          }),
          []
        ), z = (0, u.c)((e3) => {
          if (!t2.account.data.uid) return;
          let l2 = { userId: t2.account.data.uid, page: e3, pageSize: 20 };
          switch (N2) {
            case P.a.CREATED:
              s2.getData({ ...l2 });
              break;
            case P.a.LIKED:
              a2.getData({ sortOrder: d.x.DESC, playlistMetaType: m.S.MUSIC, ...l2 });
          }
        }), H = (0, _.L)(() => {
          switch (N2) {
            case P.a.CREATED:
              return s2.items.length + 1;
            case P.a.LIKED:
              var e3;
              return E2 ? 1 : null != (e3 = a2.items.length) ? e3 : 1;
            default:
              return 1;
          }
        });
        return (0, l.jsx)(p.nVz, {
          pageId: p._Q$.OWN_PLAYLISTS,
          children: (0, l.jsx)(C.hO, {
            scrollElement: w2,
            headerThreshold: 148,
            children: (0, l.jsxs)("div", {
              className: k().root,
              ...(0, c.Am)(c.Xk.collection.COLLECTION_PLAYLISTS_PAGE),
              children: [
                (0, l.jsx)(O, { tabElementId: M2 }),
                (0, l.jsx)(x.$$, {
                  className: (0, i.$)(k().scrollContainer, k().important),
                  customComponents: K,
                  itemContentCallback: (e3) => {
                    var t3;
                    if (S2 && 0 === e3) return (0, l.jsx)(g.Bw, {});
                    if (v2 && E2) return (0, l.jsx)(I, { activeTabIndex: N2, tabElementId: M2 });
                    let s3 = S2 ? e3 - 1 : e3, i2 = null == L2 || null == (t3 = L2.items) ? void 0 : t3[s3], a3 = R2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: R2({ id: "entity-names.playlist" }) }
                    );
                    return i2 ? (0, l.jsx)(h.B6, { playlist: i2, contentLinesCount: 3 }, i2.key) : (0, l.jsx)(x.Vt, { "aria-label": a3 });
                  },
                  totalCount: H,
                  onGetDataByPage: z,
                  pageSize: 20,
                  totalRequests: L2.pagesLoader.requestsCount,
                  listClassName: (0, i.$)(k().content, { [k().content_withGridLayout]: S2 || !E2 }, k().important),
                  itemClassName: k().item,
                  handleRef: D2,
                  context: { listAriaLabel: R2({ id: "collection.liked-playlists-list" }) },
                  isMobileLayout: f2,
                  useWindowScroll: f2
                })
              ]
            })
          })
        });
      });
    },
    25605: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionShelfNewEpisodesPage: () => v });
      var l = s(54486), i = s(28303), a = s(97396), o = s(61910), n = s(31500), r = s(8817), c = s(56231), d = s(97800), m = s(82644), u = s(33276), _ = s(74125), C = s(80585), h = s(50420), g = s(47713), p = s(63585), x = s(77881), P = s(5956), j = s(21365), y = s(65681), b = s.n(y);
      let A = (0, i.PA)(() => {
        let {
          sonataState: e2,
          collection: {
            shelf: { newEpisodes: t2 }
          }
        } = (0, _.Pjs)(), s2 = (0, _.ZpR)(_.Zyd.nonMusic.href), i2 = (0, o.useMemo)(() => {
          var s3;
          return null == (s3 = t2.tracks) ? void 0 : s3.map(
            (s4, i3) => (0, l.jsx)(
              j.Kd,
              {
                track: s4,
                playContextParams: {
                  contextData: { type: p.K.Album, meta: { id: s4.entityId }, from: t2.typeForFrom || "" },
                  queueParams: { index: i3, entityId: s4.id },
                  loadContextMeta: true,
                  entitiesData: e2.unloadedEntitiesDataFromModels
                },
                withPodcastName: true
              },
              s4.entityId
            )
          );
        }, [t2.tracks, t2.typeForFrom, e2.unloadedEntitiesDataFromModels]), a2 = (0, o.useMemo)(
          () => t2.isEmpty ? (0, l.jsx)(g.A, { id: "error-messages.empty-shelf-new-episodes-title-no-tracks" }) : (0, l.jsx)(g.A, { id: "error-messages.empty-shelf-new-episodes-title" }),
          [t2.isEmpty]
        );
        return (t2.isNeededToLoad && (0, o.use)(t2.getData()), t2.isLoading) ? (0, l.jsx)(C.DS, { variant: _.Xjt.PLAYLIST, isActive: true }) : (0, l.jsxs)("div", {
          className: (0, h.$)(b().root, { [b().root_emptyList]: t2.isEmpty }),
          children: [
            i2,
            (0, l.jsxs)("div", {
              className: b().wrapper,
              children: [
                (0, l.jsx)("div", {
                  className: b().iconBackground,
                  children: (0, l.jsx)(P.Icon, { variant: "like", size: "l" })
                }),
                (0, l.jsx)(d.Heading, { className: b().title, variant: "h3", size: "xs", children: a2 }),
                !t2.isEmpty && (0, l.jsx)(d.Caption, {
                  type: "controls",
                  variant: "span",
                  size: "l",
                  weight: "normal",
                  children: (0, l.jsx)(g.A, { id: "error-messages.empty-shelf-new-episodes-text" })
                }),
                (0, l.jsx)(x.$, {
                  onClick: s2,
                  className: b().button,
                  role: "link",
                  color: "secondary",
                  size: "s",
                  radius: "xxxl",
                  children: (0, l.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, l.jsx)(g.A, { id: "error-messages.empty-shelf-liked-page-link" })
                  })
                })
              ]
            })
          ]
        });
      });
      var k = s(71898), S = s.n(k);
      let v = (0, i.PA)(() => {
        let {
          collection: {
            shelf: { newEpisodes: e2 }
          }
        } = (0, _.Pjs)(), { contentScrollRef: t2, setContentScrollRef: s2 } = (0, _.gKY)(), i2 = (0, _.W6M)(), h2 = (0, a.useRouter)(), g2 = (0, r.c)(() => {
          var t3;
          (null == (t3 = e2.playlist) ? void 0 : t3.uuid) && h2.replace(e2.playlist.url);
        });
        return ((0, o.useEffect)(() => {
          e2.isResolved && e2.withPlaylist && g2();
        }, [e2.isResolved, e2.withPlaylist, g2]), (0, o.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), (0, _.Jzs)(e2.isResolved), e2.isRejected) ? (0, l.jsx)(m.w, {}) : (0, l.jsxs)(u.hO, {
          scrollElement: t2,
          outerTitle: e2.title,
          children: [
            (0, l.jsx)(C.Y9, {
              variant: C.Vw.TEXT,
              withForwardControl: false,
              withBackwardControl: i2.canBack,
              children: (0, l.jsx)(d.Heading, {
                variant: "h2",
                weight: "bold",
                size: "xl",
                lineClamp: 1,
                children: e2.title
              })
            }),
            (0, l.jsxs)(c.N, {
              ref: s2,
              containerClassName: S().scrollableContainer,
              className: S().root,
              ...(0, n.Am)(n.Xk.collection.COLLECTION_SHELF_NEW_EPISODES_PAGE),
              children: [
                (0, l.jsx)(A, {}),
                (0, l.jsx)(C.A, { children: (0, l.jsx)(C.wi, { className: S().footer }) })
              ]
            })
          ]
        });
      });
    },
    26722: (e) => {
      e.exports = {
        root: "CollectionDislikesPageEmpty_root__F9g35",
        icon: "CollectionDislikesPageEmpty_icon__hbz5L",
        title: "CollectionDislikesPageEmpty_title__AqUTM"
      };
    },
    27584: (e, t, s) => {
      "use strict";
      s.d(t, { j: () => l });
      var l = (function(e2) {
        return e2[e2.TRACKS = 0] = "TRACKS", e2[e2.ARTISTS = 1] = "ARTISTS", e2;
      })({});
    },
    30919: (e) => {
      e.exports = { title: "CollectionShelfShimmer_title__X3d9J" };
    },
    31818: (e) => {
      e.exports = {
        root: "CollectionClipsPage_root__Z1yh9",
        content: "CollectionClipsPage_content__68gZ1",
        scrollContent: "CollectionClipsPage_scrollContent__6F_37",
        header: "CollectionClipsPage_header__L_hq2",
        footer: "CollectionClipsPage_footer__0IfmB"
      };
    },
    32290: (e, t, s) => {
      "use strict";
      s.d(t, { M: () => d });
      var l = s(54486), i = s(50420), a = s(47713), o = s(5956), n = s(97800), r = s(72736), c = s.n(r);
      let d = (e2) => {
        let { className: t2 } = e2;
        return (0, l.jsxs)("div", {
          className: (0, i.$)(c().emptyContent, t2),
          children: [
            (0, l.jsx)(o.Icon, { className: c().emptyContentIcon, size: "l", variant: "album" }),
            (0, l.jsx)(n.Heading, {
              className: c().emptyContentTitle,
              variant: "h3",
              size: "xs",
              children: (0, l.jsx)(a.A, { id: "error-messages.empty-collection-podcasts-and-books" })
            })
          ]
        });
      };
    },
    32487: (e) => {
      e.exports = {
        root: "CollectionPlaylistsPageEmpty_root__mKZt2",
        icon: "CollectionPlaylistsPageEmpty_icon__x9v_P",
        title: "CollectionPlaylistsPageEmpty_title__8RfSi"
      };
    },
    36845: (e) => {
      e.exports = {
        root: "CollectionPlaylistsLikedPage_root__ZyIwA",
        scrollContainer: "CollectionPlaylistsLikedPage_scrollContainer__H_vPA",
        important: "CollectionPlaylistsLikedPage_important__GjYTU",
        content: "CollectionPlaylistsLikedPage_content__WIxhp",
        footer: "CollectionPlaylistsLikedPage_footer__A60Ui",
        item: "CollectionPlaylistsLikedPage_item__PpCht"
      };
    },
    38155: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionAlbumsPage: () => B });
      var l = s(54486), i = s(28303), a = s(97396), o = s(61910), n = s(31500), r = s(51321), c = s(33276), d = s(74125), m = (function(e2) {
        return e2[e2.LIKED_ALBUMS = 0] = "LIKED_ALBUMS", e2[e2.UPCOMING_ALBUMS = 1] = "UPCOMING_ALBUMS", e2;
      })({}), u = s(92066), _ = s.n(u), C = s(50420), h = s(43426), g = s(94376), p = s(80585), x = s(47713), P = s(97800);
      let j = (e2) => {
        let t2 = (0, d.XJ9)();
        return (0, o.useCallback)(
          (s2) => {
            var l2;
            switch (null == (l2 = e2.onTabChange) || l2.call(e2, s2), s2) {
              case m.LIKED_ALBUMS: {
                let { href: e3 } = (0, d.uvd)(d.Zyd.collectionAlbums.href, { query: { tab: d.Hl3.LIKED_ALBUMS } });
                t2(e3);
                break;
              }
              case m.UPCOMING_ALBUMS: {
                let { href: e3 } = (0, d.uvd)(d.Zyd.collectionAlbums.href, { query: { tab: d.Hl3.UPCOMING_ALBUMS } });
                t2(e3);
              }
            }
          },
          [t2, e2]
        );
      };
      var y = s(19816), b = s.n(y), A = s(22674);
      let k = () => (0, l.jsxs)("div", {
        className: b().tabsShimmer,
        children: [
          (0, l.jsx)(A.Shimmer, { className: b().tabShimmer }),
          (0, l.jsx)(A.Shimmer, { className: b().tabShimmer })
        ]
      }), S = (0, i.PA)((e2) => {
        var t2, s2, i2;
        let { tabsState: a2, tabElementId: r2 } = e2, { collection: c2 } = (0, d.Pjs)(), { formatMessage: u2 } = (0, h.A)(), _2 = (0, d.W6M)(), { isScrolling: C2 } = (0, o.useContext)(p.B9), g2 = j(a2), y2 = (0, o.useMemo)(
          () => c2.albums.items.length ? "".concat(u2({ id: "entity-names.albums" }), " • ").concat(c2.albums.items.length) : u2({ id: "entity-names.albums" }),
          [c2.albums.items.length, u2]
        ), A2 = (0, o.useMemo)(() => {
          var e3;
          return (null == (e3 = c2.albums.upcomingAlbums.items) ? void 0 : e3.length) ? "".concat(u2({ id: "entity-names.upcoming-albums" }), " • ").concat(c2.albums.upcomingAlbums.items.length) : u2({ id: "entity-names.upcoming-albums" });
        }, [null == (t2 = c2.albums.upcomingAlbums.items) ? void 0 : t2.length, u2]);
        return (0, l.jsxs)("header", {
          className: b().root,
          "aria-hidden": C2,
          ...(0, n.Am)(n.Xk.collection.COLLECTION_ALBUMS_PAGE_STATIC_HEADER),
          children: [
            (0, l.jsxs)("div", {
              className: b().container,
              children: [
                _2.canBack && (0, l.jsx)(p.Lh, {
                  withForwardControl: false,
                  withBackwardControl: _2.canBack,
                  shouldFocusOnMount: !C2
                }),
                (0, l.jsx)(P.Heading, {
                  variant: "h2",
                  weight: "bold",
                  size: "xl",
                  lineClamp: 1,
                  className: b().title,
                  ...(0, n.Am)(n.Xk.collection.COLLECTION_ALBUMS_PAGE_STATIC_HEADER_TITLE),
                  children: (0, l.jsx)(x.A, { id: "entity-names.favourite-albums" })
                })
              ]
            }),
            (0, l.jsxs)(p.wI, {
              isShimmerVisible: c2.albums.isLoading,
              shimmer: (0, l.jsx)(k, {}),
              className: b().tabs,
              elementId: r2,
              ...a2,
              onTabChange: g2,
              children: [
                (0, l.jsx)(p.oz, {
                  className: b().tab,
                  value: m.LIKED_ALBUMS,
                  title: y2,
                  "aria-label": u2({ id: "entity-names.albums-count" }, { value: c2.albums.items.length }),
                  "aria-hidden": C2,
                  tabIndex: C2 ? -1 : 0
                }),
                (0, l.jsx)(p.oz, {
                  className: b().tab,
                  value: m.UPCOMING_ALBUMS,
                  title: A2,
                  "aria-label": u2(
                    { id: "entity-names.upcoming-albums-count" },
                    { value: null != (i2 = null == (s2 = c2.albums.upcomingAlbums.items) ? void 0 : s2.length) ? i2 : 0 }
                  ),
                  "aria-hidden": C2,
                  tabIndex: C2 ? -1 : 0
                })
              ]
            })
          ]
        });
      });
      var v = s(59790), N = s.n(v);
      let L = (0, i.PA)((e2) => {
        var t2;
        let { forwardRef: s2, tabsState: i2, tabElementId: a2 } = e2, {
          user: n2,
          collection: c2,
          settings: { isMobile: u2 }
        } = (0, d.Pjs)(), { formatMessage: _2 } = (0, h.A)(), x2 = (0, o.useCallback)(
          (e3) => {
            n2.account.data.uid && c2.albums.getData({ userId: n2.account.data.uid, metaType: "music", page: e3, pageSize: 20 });
          },
          [c2.albums, n2.account.data.uid]
        ), P2 = (0, o.useMemo)(
          () => ({
            Header: () => (0, l.jsx)(S, { tabsState: i2, tabElementId: a2 }),
            Footer: () => (0, l.jsx)(p.A, { children: (0, l.jsx)(p.wi, { className: N().footer }) })
          }),
          [a2, i2]
        ), j2 = c2.albums.isAlbumsLoading ? 20 : c2.albums.items.length;
        return (0, l.jsx)("div", {
          className: N().root,
          children: (0, l.jsx)(r.TabPanel, {
            value: i2.value,
            name: m.LIKED_ALBUMS,
            elementId: a2,
            className: N().tabPanel,
            children: (0, l.jsx)(p.$$, {
              className: (0, C.$)(N().scrollContainer, N().important),
              customComponents: P2,
              itemContentCallback: (e3) => {
                var t3;
                let s3 = null == (t3 = c2.albums.pagesLoader.items) ? void 0 : t3[e3], i3 = _2({ id: "loading-messages.entity-is-loading" }, { entityName: _2({ id: "entity-names.album" }) });
                return s3 ? (0, l.jsx)(g.aX, { album: s3, contentLinesCount: 4 }, s3.id) : (0, l.jsx)(p.Vt, { "aria-label": i3, linesCount: 4 });
              },
              totalCount: j2,
              onGetDataByPage: x2,
              pageSize: 20,
              totalRequests: null != (t2 = c2.albums.pagesLoader.requestsCount) ? t2 : 0,
              listClassName: N().content,
              itemClassName: N().item,
              handleRef: s2,
              context: { listAriaLabel: _2({ id: "collection.liked-albums-list" }) },
              isMobileLayout: u2,
              useWindowScroll: u2
            })
          })
        });
      });
      var E = s(56231);
      let I = (0, i.PA)((e2) => {
        let { forwardRef: t2, tabsState: s2, tabElementId: i2 } = e2, { collection: a2 } = (0, d.Pjs)(), { formatMessage: n2 } = (0, h.A)(), c2 = (0, o.useMemo)(() => {
          var e3;
          let t3 = n2({ id: "loading-messages.entity-is-loading" }, { entityName: n2({ id: "entity-names.album" }) });
          return a2.albums.isUpcomingAlbumsLoading ? (0, l.jsx)(p.eI, { isActive: true, "aria-label": t3 }) : null == (e3 = a2.albums.upcomingAlbums.items) ? void 0 : e3.map((e4) => (0, l.jsx)(g.M3, { upcomingAlbum: e4 }, e4.id));
        }, [a2.albums.isUpcomingAlbumsLoading, a2.albums.upcomingAlbums, n2]);
        return (0, l.jsxs)(E.N, {
          className: N().root,
          containerClassName: (0, C.$)(N().scrollContainer, N().important),
          ref: t2,
          children: [
            (0, l.jsx)(S, { tabsState: s2, tabElementId: i2 }),
            (0, l.jsx)(r.TabPanel, {
              value: s2.value,
              name: m.UPCOMING_ALBUMS,
              elementId: i2,
              className: N().content,
              children: c2
            }),
            (0, l.jsx)(p.A, { children: (0, l.jsx)(p.wi, { className: N().footer }) })
          ]
        });
      });
      var T = s(5956), f = s(88798), w = s.n(f);
      let D = (0, i.PA)((e2) => {
        let { tabsState: t2, tabElementId: s2 } = e2, i2 = (0, o.useMemo)(() => {
          switch (t2.value) {
            case m.LIKED_ALBUMS:
              return (0, l.jsx)(x.A, { id: "error-messages.empty-collection-albums-title" });
            case m.UPCOMING_ALBUMS:
              return (0, l.jsx)(x.A, { id: "error-messages.empty-collection-upcoming-albums-title" });
          }
        }, [t2.value]), a2 = t2.value === m.LIKED_ALBUMS;
        return (0, l.jsxs)(l.Fragment, {
          children: [
            (0, l.jsx)(S, { tabsState: t2, tabElementId: s2 }),
            (0, l.jsxs)(r.TabPanel, {
              value: t2.value,
              name: t2.value,
              elementId: s2,
              className: w().root,
              children: [
                (0, l.jsx)(T.Icon, { className: w().icon, size: "l", variant: "album" }),
                (0, l.jsx)(P.Heading, {
                  className: w().title,
                  variant: "h3",
                  size: "xs",
                  ...(0, n.Am)(n.Xk.collection.COLLECTION_ALBUMS_PAGE_EMPTY_TITLE),
                  children: i2
                }),
                a2 && (0, l.jsx)(P.Caption, {
                  className: w().text,
                  variant: "span",
                  type: "controls",
                  size: "l",
                  weight: "normal",
                  children: (0, l.jsx)(x.A, { id: "error-messages.empty-collection-albums-description" })
                })
              ]
            })
          ]
        });
      }), M = (0, i.PA)((e2) => {
        var t2, s2, i2;
        let { tabsState: a2, tabElementId: r2 } = e2, { collection: c2 } = (0, d.Pjs)(), { formatMessage: u2 } = (0, h.A)(), { isScrolling: _2 } = (0, o.useContext)(p.B9), g2 = (0, d.W6M)(), x2 = j(a2), P2 = (0, o.useMemo)(
          () => c2.albums.items.length ? "".concat(u2({ id: "entity-names.albums" }), " • ").concat(c2.albums.items.length) : u2({ id: "entity-names.albums" }),
          [c2.albums.items.length, u2]
        ), y2 = (0, o.useMemo)(() => {
          var e3, t3;
          return (null == (e3 = c2.albums.upcomingAlbums.items) ? void 0 : e3.length) ? "".concat(u2({ id: "entity-names.upcoming-albums" }), " • ").concat(null == (t3 = c2.albums.upcomingAlbums.items) ? void 0 : t3.length) : u2({ id: "entity-names.upcoming-albums" });
        }, [null == (t2 = c2.albums.upcomingAlbums.items) ? void 0 : t2.length, u2]);
        return (0, l.jsx)(p.Y9, {
          variant: p.Vw.COMPOSITE,
          staticClassName: (0, C.$)(b().staticHeader, b().important),
          "aria-hidden": !_2,
          stickyClassName: (0, C.$)(b().stickyHeader, b().important),
          containerProps: (0, n.Am)(n.Xk.collection.COLLECTION_ALBUMS_PAGE_STICKY_HEADER),
          stickyChild: (0, l.jsxs)("div", {
            className: b().container,
            children: [
              g2.canBack && (0, l.jsx)(p.Lh, {
                withForwardControl: false,
                withBackwardControl: g2.canBack,
                shouldFocusOnMount: false,
                buttonSize: "xs"
              }),
              (0, l.jsxs)(p.wI, {
                isShimmerVisible: c2.albums.isLoading,
                shimmer: (0, l.jsx)(k, {}),
                className: b().tabs,
                elementId: r2,
                ...a2,
                onTabChange: x2,
                children: [
                  (0, l.jsx)(p.oz, {
                    className: b().tab,
                    value: m.LIKED_ALBUMS,
                    title: P2,
                    "aria-label": u2({ id: "entity-names.albums-count" }, { value: c2.albums.items.length }),
                    "aria-hidden": !_2,
                    tabIndex: _2 ? 0 : -1
                  }),
                  (0, l.jsx)(p.oz, {
                    className: b().tab,
                    value: m.UPCOMING_ALBUMS,
                    title: y2,
                    "aria-label": u2(
                      { id: "entity-names.upcoming-albums-count" },
                      {
                        value: null != (i2 = null == (s2 = c2.albums.upcomingAlbums.items) ? void 0 : s2.length) ? i2 : 0
                      }
                    ),
                    "aria-hidden": !_2,
                    tabIndex: _2 ? 0 : -1
                  })
                ]
              })
            ]
          })
        });
      }), B = (0, i.PA)(() => {
        let e2 = (0, a.useSearchParams)(), { user: t2, collection: s2, library: i2 } = (0, d.Pjs)(), { contentScrollRef: u2, setContentScrollRef: C2 } = (0, d.gKY)(), h2 = (0, o.useId)(), g2 = (0, o.useMemo)(() => {
          switch (e2.get(d.K3F.TAB)) {
            case d.Hl3.LIKED_ALBUMS:
              break;
            case d.Hl3.UPCOMING_ALBUMS:
              return m.UPCOMING_ALBUMS;
          }
          return m.LIKED_ALBUMS;
        }, [e2]), p2 = (0, r.useTabsState)(g2);
        (0, d.Jzs)(s2.albums.isResolved), (0, o.useEffect)(
          () => () => {
            s2.albums.reset();
          },
          [s2.albums]
        );
        let x2 = (0, o.useMemo)(() => {
          switch (p2.value) {
            case m.LIKED_ALBUMS:
              if (s2.albums.isAlbumsEmpty) return (0, l.jsx)(D, { tabsState: p2, tabElementId: h2 });
              return (0, l.jsx)(L, { forwardRef: C2, tabsState: p2, tabElementId: h2 });
            case m.UPCOMING_ALBUMS:
              if (s2.albums.isUpcomingAlbumsEmpty) return (0, l.jsx)(D, { tabsState: p2, tabElementId: h2 });
              return (0, l.jsx)(I, { forwardRef: C2, tabsState: p2, tabElementId: h2 });
          }
        }, [s2.albums.isAlbumsEmpty, s2.albums.isUpcomingAlbumsEmpty, C2, h2, p2]);
        if (t2.account.data.uid && s2.albums.isNeededToLoad) {
          let e3 = [
            s2.albums.getData({ userId: t2.account.data.uid, metaType: "music", page: 0, pageSize: 20 }),
            s2.albums.getPresaves({ userId: t2.account.data.uid }),
            i2.getData()
          ];
          (0, o.use)(Promise.allSettled(e3));
        }
        return (0, l.jsx)(d.nVz, {
          pageId: d._Q$.OWN_ALBUMS,
          children: (0, l.jsx)(c.hO, {
            scrollElement: u2,
            headerThreshold: 148,
            children: (0, l.jsxs)("div", {
              className: _().root,
              ...(0, n.Am)(n.Xk.collection.COLLECTION_ALBUMS_PAGE),
              children: [(0, l.jsx)(M, { tabsState: p2, tabElementId: h2 }), x2]
            })
          })
        });
      });
    },
    40188: (e, t, s) => {
      "use strict";
      s.d(t, { useSort: () => n });
      var l = s(61910), i = s(11405), a = s(74125), o = s(90229);
      let n = (e2) => {
        let { sortModel: t2 } = e2, s2 = (0, a.XJ9)();
        (0, l.useLayoutEffect)(() => {
          let e3 = new URL(window.location.href).searchParams.get(a.K3F.SORT);
          e3 && (0, o.W)(e3) ? t2.setSortBy(e3) : t2.setSortBy(i.g.YEAR);
        }, [t2]), (0, l.useEffect)(() => {
          if (t2.sortBy) {
            let e3 = (0, a.bJ)(a.K3F.SORT, t2.sortBy);
            e3 && s2(e3);
          }
        }, [s2, t2.sortBy]);
      };
    },
    41663: (e, t, s) => {
      "use strict";
      s.d(t, { a: () => l });
      var l = (function(e2) {
        return e2[e2.CREATED = 0] = "CREATED", e2[e2.LIKED = 1] = "LIKED", e2;
      })({});
    },
    42421: (e, t, s) => {
      "use strict";
      s.d(t, { M: () => l.NotFound });
      var l = s(65034);
    },
    42520: (e, t, s) => {
      "use strict";
      let l;
      s.d(t, { useMetrika: () => o });
      var i = s(61910), a = s(80506);
      let o = () => {
        let e2 = (l || (l = (0, a.a)()), l), t2 = (0, i.useSyncExternalStore)(e2.isLoaded.onChange, () => e2.isLoaded.value);
        return (0, i.useMemo)(() => ({ ...e2, isLoaded: t2 }), [t2]);
      };
    },
    43448: (e) => {
      e.exports = {
        root: "CollectionArtistsPageEmpty_root__D39tF",
        emptyContent: "CollectionArtistsPageEmpty_emptyContent__oJc6T",
        emptyContentIcon: "CollectionArtistsPageEmpty_emptyContentIcon__uZQwm",
        emptyContentTitle: "CollectionArtistsPageEmpty_emptyContentTitle__Vqy_Q",
        footer: "CollectionArtistsPageEmpty_footer__O_8aS"
      };
    },
    44285: (e) => {
      e.exports = {
        root: "CollectionClipsPageClipsWillLike_root__uS0_8",
        carouselItem: "CollectionClipsPageClipsWillLike_carouselItem__0C0_W",
        important: "CollectionClipsPageClipsWillLike_important__U_2ET",
        carouselBlockHeader: "CollectionClipsPageClipsWillLike_carouselBlockHeader__wDnJp",
        carouselBlock: "CollectionClipsPageClipsWillLike_carouselBlock__La_8Q"
      };
    },
    46026: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionPlaylistsLikedPage: () => P });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(61288), m = s(47168), u = s(97800), _ = s(33276), C = s(83909), h = s(74125), g = s(80585), p = s(36845), x = s.n(p);
      let P = (0, a.PA)(() => {
        let {
          user: e2,
          collection: {
            playlists: { playlistsLiked: t2 }
          },
          settings: { isMobile: s2 }
        } = (0, h.Pjs)(), { formatMessage: a2 } = (0, n.A)(), { contentScrollRef: p2, setContentScrollRef: P2 } = (0, h.gKY)(), j = (0, h.W6M)(), y = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(g.A, { children: (0, l.jsx)(g.wi, { className: x().footer }) }) }),
          []
        );
        (0, h.Jzs)(t2.isResolved);
        let b = (0, o.useCallback)(
          (s3) => {
            e2.account.data.uid && t2.getData({
              userId: e2.account.data.uid,
              sortOrder: d.x.DESC,
              playlistMetaType: m.S.MUSIC,
              page: s3,
              pageSize: 20
            });
          },
          [t2, e2.account.data.uid]
        );
        (0, h.XcE)(t2.pagesLoader, b), (0, o.useEffect)(
          () => () => {
            t2.reset();
          },
          [t2]
        ), e2.account.data.uid && t2.isNeededToLoad && (0, o.use)(
          t2.getData({
            userId: e2.account.data.uid,
            sortOrder: d.x.DESC,
            playlistMetaType: m.S.MUSIC,
            page: 0,
            pageSize: 20
          })
        );
        let A = t2.isShimmerVisible ? 20 : t2.items.length;
        return (0, l.jsx)(h.nVz, {
          pageId: h._Q$.OWN_PLAYLISTS,
          children: (0, l.jsx)(_.hO, {
            scrollElement: p2,
            outerTitle: a2({ id: "entity-names.favourite-playlists" }),
            children: (0, l.jsxs)("div", {
              className: x().root,
              ...(0, c.Am)(c.Xk.collection.COLLECTION_PLAYLISTS_LIKED_PAGE),
              children: [
                (0, l.jsx)(g.Y9, {
                  variant: g.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: j.canBack,
                  children: (0, l.jsx)(u.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: (0, l.jsx)(r.A, { id: "entity-names.favourite-playlists" })
                  })
                }),
                (0, l.jsx)(g.$$, {
                  className: (0, i.$)(x().scrollContainer, x().important),
                  customComponents: y,
                  itemContentCallback: (e3) => {
                    let s3 = t2.items[e3], i2 = a2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: a2({ id: "entity-names.playlist" }) }
                    );
                    return s3 ? (0, l.jsx)(C.B6, { playlist: s3, contentLinesCount: 3 }, s3.key) : (0, l.jsx)(g.Vt, { "aria-label": i2 });
                  },
                  totalCount: A,
                  onGetDataByPage: b,
                  pageSize: 20,
                  totalRequests: t2.requestsCount,
                  listClassName: x().content,
                  itemClassName: x().item,
                  handleRef: P2,
                  context: { listAriaLabel: a2({ id: "collection.liked-playlists-list" }) },
                  isMobileLayout: s2,
                  useWindowScroll: s2
                })
              ]
            })
          })
        });
      });
    },
    46353: (e) => {
      e.exports = {
        root: "SortDropdown_root__d1JmQ",
        button: "SortDropdown_button__SjTI7",
        header: "SortDropdown_header__kj8yV",
        container: "SortDropdown_container__dyVF_"
      };
    },
    47168: (e, t, s) => {
      "use strict";
      var l;
      s.d(t, { S: () => l }), (function(e2) {
        e2.MUSIC = "music", e2.CHILDREN = "children";
      })(l || (l = {}));
    },
    49756: (e, t, s) => {
      "use strict";
      s.d(t, { z: () => n });
      var l = s(61910), i = s(74125), a = s(11900), o = s(27584);
      let n = (e2) => {
        let t2 = (0, i.XJ9)();
        return (0, l.useCallback)(
          (s2) => {
            var l2;
            switch (null == (l2 = e2.onTabChange) || l2.call(e2, s2), s2) {
              case o.j.TRACKS: {
                let { href: e3 } = (0, i.uvd)(i.Zyd.collectionDislikes.href, { query: { tab: a.h.TRACKS } });
                t2(e3);
                break;
              }
              case o.j.ARTISTS: {
                let { href: e3 } = (0, i.uvd)(i.Zyd.collectionDislikes.href, { query: { tab: a.h.ARTISTS } });
                t2(e3);
              }
            }
          },
          [t2, e2]
        );
      };
    },
    50492: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionKidsPage: () => S });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(63585), m = s(8075), u = s(27510), _ = s(5956), C = s(56231), h = s(97800), g = s(82644), p = s(94376), x = s(33276), P = s(83909), j = s(21365), y = s(74125), b = s(80585), A = s(2192), k = s.n(A);
      let S = (0, a.PA)(() => {
        let {
          collection: { kids: e2 }
        } = (0, y.Pjs)(), { contentScrollRef: t2, setContentScrollRef: s2 } = (0, y.gKY)(), a2 = (0, y.W6M)(), { from: A2 } = (0, y.fyy)({ pageId: y._Q$.COLLECTION_KIDS }), { formatMessage: S2 } = (0, n.A)();
        (0, o.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), (0, y.Jzs)(e2.isResolved);
        let v = (0, u.L)(
          () => e2.tracks.loadedItems.slice(0, 5).map((t3, s3) => {
            let i2 = {
              contextData: { type: d.K.Various, meta: { id: t3.entityId }, from: A2 },
              queueParams: { index: s3 },
              loadContextMeta: false,
              entitiesData: e2.tracks.sonataEntitiesData
            };
            return t3.type === m.S.MUSIC ? (0, l.jsx)(j.Kt, { track: t3, playContextParams: i2 }, s3) : (0, l.jsx)(j.Kd, { track: t3, playContextParams: i2, withPodcastName: t3.isTrackPodcast }, s3);
          })
        );
        if (e2.isNeededToLoad) {
          let t3 = [
            e2.albums.getData({ pageSize: 8 }),
            e2.playlists.getData({ pageSize: 8 }),
            e2.tracks.getData({ pageSize: 5 })
          ];
          (0, o.use)(Promise.allSettled(t3));
        }
        return e2.isRejected ? (0, l.jsx)(g.w, {}) : (0, l.jsx)(y.nVz, {
          pageId: y._Q$.COLLECTION_KIDS,
          children: (0, l.jsxs)(x.hO, {
            scrollElement: t2,
            outerTitle: S2({ id: "kids.for-kids" }),
            children: [
              (0, l.jsx)(b.Y9, {
                variant: b.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: a2.canBack,
                children: (0, l.jsx)(h.Heading, {
                  variant: "h2",
                  weight: "bold",
                  size: "xl",
                  children: (0, l.jsx)(r.A, { id: "kids.for-kids" })
                })
              }),
              (0, l.jsxs)(C.N, {
                className: k().root,
                containerClassName: k().content,
                ref: s2,
                ...(0, c.Am)(c.Xk.collection.COLLECTION_KIDS_PAGE),
                children: [
                  !e2.shouldShowContent && (0, l.jsxs)("div", {
                    className: k().emptyBlock,
                    children: [
                      (0, l.jsx)(_.Icon, { className: k().emptyBlockIcon, variant: "album" }),
                      (0, l.jsx)(h.Heading, {
                        className: k().emptyBlockTitle,
                        variant: "h3",
                        size: "xs",
                        children: (0, l.jsx)(r.A, { id: "kids.empty-collection-text" })
                      })
                    ]
                  }),
                  e2.tracks.shouldShowContent && (0, l.jsx)(b.$2, {
                    blockHeaderClassName: (0, i.$)(k().carouselBlockHeader, k().carouselBlock),
                    carouselItemClassName: (0, i.$)(k().tracksCarouselItem, k().important),
                    blockHeaderTitle: S2({ id: "kids.favourite-tracks-and-episodes" }),
                    shimmer: (0, l.jsx)(b.DS, { variant: y.Xjt.PLAYLIST, isActive: true }),
                    maxColumnsCount: b.DI.ONE,
                    isShimmerVisible: e2.tracks.isShimmerVisible,
                    isShimmerActive: true,
                    itemsCountPerColumn: 5,
                    viewAllActionLink: y.Zyd.collectionKidsTracks.href,
                    children: v
                  }),
                  e2.albums.shouldShowContent && (0, l.jsx)(p.pZ, {
                    headerClassName: (0, i.$)(k().carouselBlock, k().carouselBlockHeader),
                    containerClassName: k().carouselBlock,
                    title: S2({ id: "kids.albums-and-podcasts" }),
                    albums: e2.albums.loadedItems,
                    headingVariant: "h2",
                    isShimmerVisible: e2.albums.isShimmerVisible,
                    isShimmerActive: true,
                    viewAllActionLink: y.Zyd.collectionKidsAlbums.href
                  }),
                  e2.playlists.shouldShowContent && (0, l.jsx)(P.EC, {
                    headerClassName: (0, i.$)(k().carouselBlock, k().carouselBlockHeader),
                    containerClassName: k().carouselBlock,
                    title: S2({ id: "entity-names.artist-playlist" }),
                    playlists: e2.playlists.loadedItems,
                    headingVariant: "h2",
                    isShimmerVisible: e2.playlists.isShimmerVisible,
                    isShimmerActive: true,
                    viewAllActionLink: y.Zyd.collectionKidsPlaylists.href
                  }),
                  (0, l.jsx)(b.A, { children: (0, l.jsx)(b.wi, { className: k().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    52855: (e) => {
      e.exports = {
        root: "CollectionClipsPageEmpty_root__P29ns",
        content: "CollectionClipsPageEmpty_content__gIM_C",
        icon: "CollectionClipsPageEmpty_icon__jDAZP",
        title: "CollectionClipsPageEmpty_title__DKJ_3",
        text: "CollectionClipsPageEmpty_text__F_Too"
      };
    },
    53793: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionDislikesPage: () => z });
      var l = s(54486), i = s(28303), a = s(97396), o = s(61910), n = s(31500), r = s(51321), c = s(33276), d = s(74125), m = s(11900), u = s(27584), _ = s(73450), C = s.n(_), h = s(50420), g = s(43426), p = s(82644), x = s(55616), P = s(80585), j = s(47713), y = s(97800), b = s(13144), A = s.n(b), k = s(49756), S = s(22674);
      let v = () => (0, l.jsxs)("div", {
        className: A().tabsShimmer,
        children: [
          (0, l.jsx)(S.Shimmer, { className: A().tabShimmer }),
          (0, l.jsx)(S.Shimmer, { className: A().tabShimmer })
        ]
      }), N = (0, i.PA)((e2) => {
        var t2, s2, i2, a2, n2, r2, c2, m2, _2, C2;
        let { tabsState: h2, tabElementId: p2, isStickyHeader: x2 = false } = e2, {
          collection: { dislikes: j2 }
        } = (0, d.Pjs)(), { formatMessage: y2 } = (0, g.A)(), { isScrolling: b2 } = (0, o.useContext)(P.B9), S2 = (0, k.z)(h2), N2 = b2 ? -1 : 0;
        x2 && (N2 = b2 ? 0 : -1);
        let L2 = (0, o.useMemo)(() => {
          var e3, t3;
          return (null == (t3 = j2.tracks) || null == (e3 = t3.items) ? void 0 : e3.length) ? "".concat(y2({ id: "entity-names.tracks" }), " • ").concat(j2.tracks.items.length) : y2({ id: "entity-names.tracks" });
        }, [null == (s2 = j2.tracks) || null == (t2 = s2.items) ? void 0 : t2.length, y2]), E2 = (0, o.useMemo)(() => {
          var e3, t3;
          return (null == (t3 = j2.artists) || null == (e3 = t3.items) ? void 0 : e3.length) ? "".concat(y2({ id: "entity-names.artists" }), " • ").concat(j2.artists.items.length) : y2({ id: "entity-names.artists" });
        }, [null == (a2 = j2.artists) || null == (i2 = a2.items) ? void 0 : i2.length, y2]);
        return (0, l.jsxs)(P.wI, {
          isShimmerVisible: j2.isLoading,
          shimmer: (0, l.jsx)(v, {}),
          className: A().tabs,
          elementId: p2,
          ...h2,
          onTabChange: S2,
          children: [
            (0, l.jsx)(P.oz, {
              className: A().tab,
              value: u.j.TRACKS,
              title: L2,
              "aria-label": y2(
                { id: "entity-names.tracks-count" },
                { value: null != (_2 = null == (r2 = j2.tracks) || null == (n2 = r2.items) ? void 0 : n2.length) ? _2 : 0 }
              ),
              "aria-hidden": b2,
              tabIndex: N2
            }),
            (0, l.jsx)(P.oz, {
              className: A().tab,
              value: u.j.ARTISTS,
              title: E2,
              "aria-label": y2(
                { id: "entity-names.artists-count" },
                { value: null != (C2 = null == (m2 = j2.artists) || null == (c2 = m2.items) ? void 0 : c2.length) ? C2 : 0 }
              ),
              "aria-hidden": b2,
              tabIndex: N2
            })
          ]
        });
      }), L = (0, i.PA)((e2) => {
        let { tabsState: t2, tabElementId: s2 } = e2, i2 = (0, d.W6M)(), { isScrolling: a2 } = (0, o.useContext)(P.B9);
        return (0, l.jsxs)("header", {
          className: A().root,
          "aria-hidden": a2,
          ...(0, n.Am)(n.Xk.collection.COLLECTION_DISLIKES_PAGE_STATIC_HEADER),
          children: [
            (0, l.jsxs)("div", {
              className: A().container,
              children: [
                i2.canBack && (0, l.jsx)(P.Lh, {
                  withForwardControl: false,
                  withBackwardControl: i2.canBack,
                  shouldFocusOnMount: !a2
                }),
                (0, l.jsx)(y.Heading, {
                  variant: "h2",
                  weight: "bold",
                  size: "xl",
                  lineClamp: 1,
                  className: A().title,
                  ...(0, n.Am)(n.Xk.collection.COLLECTION_DISLIKES_PAGE_STATIC_HEADER_TITLE),
                  children: (0, l.jsx)(j.A, { id: "collection.my-dislikes" })
                })
              ]
            }),
            (0, l.jsx)(N, { tabsState: t2, tabElementId: s2 })
          ]
        });
      });
      var E = s(61354), I = s.n(E);
      let T = (0, i.PA)((e2) => {
        var t2, s2, i2;
        let { forwardRef: a2, tabsState: n2, tabElementId: c2 } = e2, {
          collection: { dislikes: m2 },
          settings: { isMobile: _2 }
        } = (0, d.Pjs)(), { formatMessage: C2 } = (0, g.A)(), j2 = m2.artists.isLoading ? 10 : null != (i2 = null == (s2 = m2.artists) || null == (t2 = s2.items) ? void 0 : t2.length) ? i2 : 0, y2 = (0, o.useMemo)(
          () => ({
            Header: () => (0, l.jsx)(L, { tabsState: n2, tabElementId: c2 }),
            Footer: () => (0, l.jsx)(P.A, { children: (0, l.jsx)(P.wi, { className: I().footer }) })
          }),
          [c2, n2]
        );
        return m2.artists.isRejected ? (0, l.jsx)(p.w, {}) : (0, l.jsx)("div", {
          className: I().root,
          children: (0, l.jsx)(r.TabPanel, {
            value: n2.value,
            name: u.j.ARTISTS,
            elementId: c2,
            className: I().tabPanel,
            children: (0, l.jsx)(P.$$, {
              className: (0, h.$)(I().scrollContainer, I().important),
              listClassName: (0, h.$)(I().content, I().content_withGrid),
              customComponents: y2,
              initialItemCount: j2,
              totalCount: j2,
              itemContentCallback: (e3) => {
                var t3, s3;
                let i3 = null == (s3 = m2.artists) || null == (t3 = s3.items) ? void 0 : t3[e3];
                if (!i3) {
                  let e4 = C2(
                    { id: "loading-messages.entity-is-loading" },
                    { entityName: C2({ id: "entity-names.artist" }) }
                  );
                  return (0, l.jsx)(P.Vt, { "aria-label": e4, round: true, centered: true });
                }
                return (0, l.jsx)(x.ao, { artist: i3, contentLinesCount: 3, className: I().item }, i3.id);
              },
              handleRef: a2,
              context: { listAriaLabel: C2({ id: "entity-names.artists" }) },
              isMobileLayout: _2,
              useWindowScroll: _2
            })
          })
        });
      });
      var f = s(63585), w = s(21365);
      let D = (0, i.PA)((e2) => {
        var t2, s2, i2;
        let { forwardRef: a2, tabsState: n2, tabElementId: c2 } = e2, { from: m2 } = (0, d.fyy)(), {
          collection: { dislikes: _2 },
          settings: { isMobile: C2 }
        } = (0, d.Pjs)(), { formatMessage: x2 } = (0, g.A)(), j2 = (0, d.wZZ)(), y2 = _2.tracks.isLoading ? 10 : null != (i2 = null == (s2 = _2.tracks) || null == (t2 = s2.items) ? void 0 : t2.length) ? i2 : 0, b2 = (0, o.useCallback)(
          (e3) => {
            var t3;
            null == (t3 = _2.tracks) || t3.getTracksByRange(e3.startIndex, e3.endIndex);
          },
          [_2.tracks]
        ), A2 = (0, o.useMemo)(
          () => ({
            Header: () => (0, l.jsx)(L, { tabsState: n2, tabElementId: c2 }),
            Footer: () => (0, l.jsx)(P.A, { children: (0, l.jsx)(P.wi, { className: I().footer }) })
          }),
          [c2, n2]
        );
        return _2.tracks.isRejected ? (0, l.jsx)(p.w, {}) : (0, l.jsx)("div", {
          className: I().root,
          children: (0, l.jsx)(r.TabPanel, {
            value: n2.value,
            name: u.j.TRACKS,
            elementId: c2,
            className: I().tabPanel,
            children: (0, l.jsx)(P.$$, {
              className: (0, h.$)(I().scrollContainer, I().important),
              listClassName: (0, h.$)(I().content, I().content_tracks),
              customComponents: A2,
              totalCount: y2,
              itemContentCallback: (e3) => {
                var t3, s3, i3;
                let a3 = null == (i3 = _2.tracks) || null == (s3 = i3.items) || null == (t3 = s3[e3]) ? void 0 : t3.data;
                if (!a3)
                  return (0, l.jsx)(P.DS, { isActive: true, className: I().shimmerItem, variant: d.Xjt.PLAYLIST });
                let o2 = j2(e3, {
                  contextData: { type: f.K.Various, meta: { id: "disliked-tracks" }, from: m2, playDisliked: true },
                  entitiesData: _2.tracks.sonataEntitiesData,
                  queueParams: { index: e3 },
                  loadContextMeta: false
                });
                return a3.isTrackNonMusic ? (0, l.jsx)(w.Kd, {
                  track: a3,
                  playContextParams: o2,
                  ignoreDislikedStyles: true,
                  withPodcastName: true
                }) : (0, l.jsx)(w.Kt, { track: a3, playContextParams: o2, ignoreDislikedStyles: true });
              },
              onGetDataByRange: b2,
              debounceDurationInMs: 300,
              handleRef: a2,
              context: { listAriaLabel: x2({ id: "entity-names.tracks" }) },
              isMobileLayout: C2,
              useWindowScroll: C2
            })
          })
        });
      });
      var M = s(5956), B = s(26722), O = s.n(B);
      let R = (0, i.PA)((e2) => {
        let { tabsState: t2, tabElementId: s2 } = e2;
        return (0, l.jsxs)(l.Fragment, {
          children: [
            (0, l.jsx)(L, { tabsState: t2, tabElementId: s2 }),
            (0, l.jsxs)(r.TabPanel, {
              value: t2.value,
              name: t2.value,
              elementId: s2,
              className: O().root,
              ...(0, n.Am)(n.Xk.collection.COLLECTION_DISLIKES_PAGE_EMPTY_ROOT),
              children: [
                (0, l.jsx)(M.Icon, {
                  className: O().icon,
                  size: "l",
                  variant: "album",
                  ...(0, n.Am)(n.Xk.collection.COLLECTION_DISLIKES_PAGE_EMPTY_ICON)
                }),
                (0, l.jsx)(y.Heading, {
                  className: O().title,
                  variant: "h3",
                  size: "xs",
                  ...(0, n.Am)(n.Xk.collection.COLLECTION_DISLIKES_PAGE_EMPTY_HEAD),
                  children: (0, l.jsx)(j.A, { id: "entity-names.list-is-empty" })
                })
              ]
            })
          ]
        });
      }), K = (0, i.PA)((e2) => {
        let { tabsState: t2, tabElementId: s2 } = e2, { isScrolling: i2 } = (0, o.useContext)(P.B9), a2 = (0, d.W6M)();
        return (0, l.jsx)(P.Y9, {
          variant: P.Vw.COMPOSITE,
          staticClassName: (0, h.$)(A().staticHeader, A().important),
          "aria-hidden": !i2,
          stickyClassName: (0, h.$)(A().stickyHeader, A().important),
          containerProps: (0, n.Am)(n.Xk.collection.COLLECTION_DISLIKES_PAGE_STICKY_HEADER),
          stickyChild: (0, l.jsxs)("div", {
            className: A().container,
            children: [
              a2.canBack && (0, l.jsx)(P.Lh, {
                withForwardControl: false,
                withBackwardControl: a2.canBack,
                shouldFocusOnMount: false,
                buttonSize: "xs"
              }),
              (0, l.jsx)(N, { tabsState: t2, tabElementId: s2, isStickyHeader: true })
            ]
          })
        });
      }), z = (0, i.PA)(() => {
        let e2 = (0, a.useSearchParams)(), {
          user: t2,
          collection: { dislikes: s2 },
          library: i2
        } = (0, d.Pjs)(), { contentScrollRef: _2, setContentScrollRef: h2 } = (0, d.gKY)(), g2 = (0, o.useId)(), p2 = (0, o.useMemo)(() => {
          switch (e2.get(d.K3F.TAB)) {
            case m.h.TRACKS:
              break;
            case m.h.ARTISTS:
              return u.j.ARTISTS;
          }
          return u.j.TRACKS;
        }, [e2]), x2 = (0, r.useTabsState)(p2);
        t2.account.data.uid || (0, a.notFound)(), (0, d.Jzs)(s2.isResolved), (0, o.useEffect)(
          () => () => {
            s2.reset();
          },
          [s2]
        );
        let P2 = (0, o.useMemo)(() => {
          switch (x2.value) {
            case u.j.TRACKS:
              if (s2.tracks.isEmpty) return (0, l.jsx)(R, { tabsState: x2, tabElementId: g2 });
              return (0, l.jsx)(D, { forwardRef: h2, tabsState: x2, tabElementId: g2 });
            case u.j.ARTISTS:
              if (s2.artists.isEmpty) return (0, l.jsx)(R, { tabsState: x2, tabElementId: g2 });
              return (0, l.jsx)(T, { forwardRef: h2, tabsState: x2, tabElementId: g2 });
          }
        }, [s2.artists.isEmpty, s2.tracks.isEmpty, h2, g2, x2]);
        if (s2.isNeededToLoad) {
          let e3 = [s2.tracks.getData(), s2.artists.getData(), i2.getData()];
          (0, o.use)(Promise.allSettled(e3));
        }
        return (0, l.jsx)(d.nVz, {
          pageId: d._Q$.OWN_DISLIKES,
          children: (0, l.jsx)(c.hO, {
            scrollElement: _2,
            headerThreshold: 148,
            children: (0, l.jsxs)("div", {
              className: C().root,
              ...(0, n.Am)(n.Xk.collection.COLLECTION_DISLIKES_PAGE),
              children: [(0, l.jsx)(K, { tabsState: x2, tabElementId: g2 }), P2]
            })
          })
        });
      });
    },
    57202: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionShelfRecentlyPlayedPage: () => b });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(8817), m = s(97800), u = s(82644), _ = s(33276), C = s(21365), h = s(74125), g = s(80585), p = s(4696), x = s(1690), P = s(12652), j = s(19434), y = s.n(j);
      let b = (0, a.PA)(() => {
        let {
          settings: { isMobile: e2 },
          collection: { shelfRecentlyPlayed: t2 }
        } = (0, h.Pjs)(), { contentScrollRef: s2, setContentScrollRef: a2 } = (0, h.gKY)(), j2 = (0, h.W6M)(), { formatMessage: b2 } = (0, n.A)(), A = (0, h.wZZ)(), k = (0, d.c)((e3) => {
          t2.getData({ page: e3, pageSize: p.c });
        });
        (0, h.XcE)(t2.pagesLoader, k);
        let S = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(g.A, { children: (0, l.jsx)(g.wi, { className: y().footer }) }) }),
          []
        ), v = t2.isShimmerVisible ? 20 : t2.items.length;
        return ((0, o.useEffect)(
          () => () => {
            t2.reset();
          },
          [t2]
        ), (0, h.Jzs)(t2.isResolved), t2.isNeededToLoad && (0, o.use)(t2.getData({ pageSize: p.c })), t2.isRejected) ? (0, l.jsx)(u.w, {}) : t2.isEmpty ? (0, l.jsx)(P.F, { title: b2({ id: "error-messages.empty-shelf-page-title" }) }) : (0, l.jsx)(_.hO, {
          scrollElement: s2,
          outerTitle: b2({ id: "podcast.shelf-recently-played-title" }),
          children: (0, l.jsxs)("div", {
            className: y().root,
            ...(0, c.Am)(c.Xk.collection.COLLECTION_SHELF_RECENTLY_PLAYED_PAGE),
            children: [
              (0, l.jsx)(g.Y9, {
                variant: g.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: j2.canBack,
                children: (0, l.jsx)(m.Heading, {
                  variant: "h2",
                  weight: "bold",
                  size: "xl",
                  lineClamp: 1,
                  children: (0, l.jsx)(r.A, { id: "podcast.shelf-recently-played-title" })
                })
              }),
              (0, l.jsx)(g.$$, {
                className: (0, i.$)(y().scrollContainer, y().important),
                customComponents: S,
                itemContentCallback: (e3) => {
                  let s3 = t2.items[e3];
                  if (!s3) return (0, l.jsx)(g.DS, { variant: h.Xjt.PLAYLIST, isActive: true }, e3);
                  let i2 = (0, x.T)(s3, t2.typeForFrom);
                  return (0, l.jsx)(
                    C.Kd,
                    {
                      track: s3.track,
                      playContextParams: A(e3, {
                        contextData: i2,
                        queueParams: { entityId: s3.track.id, index: e3 }
                      }),
                      withPodcastName: true
                    },
                    e3
                  );
                },
                initialItemCount: v,
                totalCount: v,
                onGetDataByPage: k,
                pageSize: p.c,
                totalRequests: t2.requestsCount,
                listClassName: y().content,
                itemClassName: y().item,
                handleRef: a2,
                context: { listAriaLabel: b2({ id: "podcast.shelf-recently-played-title" }) },
                isMobileLayout: e2,
                useWindowScroll: e2
              })
            ]
          })
        });
      });
    },
    57956: (e) => {
      e.exports = {
        root: "CollectionKidsAlbumsPage_root__Fjk4C",
        scrollContainer: "CollectionKidsAlbumsPage_scrollContainer__OWiCy",
        important: "CollectionKidsAlbumsPage_important__1ghiQ",
        footer: "CollectionKidsAlbumsPage_footer__9niUH",
        item: "CollectionKidsAlbumsPage_item__A5TuB",
        content: "CollectionKidsAlbumsPage_content__6w_jh"
      };
    },
    59127: (e) => {
      e.exports = {
        header: "CollectionShelfLiked_header__u9MqV",
        shelfColumn: "CollectionShelfLiked_shelfColumn__4KX_5",
        important: "CollectionShelfLiked_important__0K3qk"
      };
    },
    59255: (e, t, s) => {
      "use strict";
      s.d(t, { E: () => m });
      var l = s(54486), i = s(28303), a = s(22674), o = s(74125), n = s(80585), r = s(30919), c = s.n(r);
      let d = () => Array.from(
        { length: 5 },
        (e2) => (0, l.jsx)(n.DS, { variant: o.Xjt.PLAYLIST, className: c().track, isActive: true }, e2)
      ), m = (0, i.PA)((e2) => {
        let { className: t2, withHeader: s2 } = e2;
        return (0, l.jsxs)("div", {
          className: t2,
          children: [
            s2 && (0, l.jsx)(a.Shimmer, { radius: "l", width: 100, height: 24, className: c().title, isActive: true }),
            (0, l.jsx)(d, {})
          ]
        });
      });
    },
    59790: (e) => {
      e.exports = {
        root: "CollectionAlbumsPageContent_root__2Ya18",
        scrollContainer: "CollectionAlbumsPageContent_scrollContainer__0TjJm",
        important: "CollectionAlbumsPageContent_important__fixM8",
        content: "CollectionAlbumsPageContent_content__jcwRU",
        footer: "CollectionAlbumsPageContent_footer__ZkUKY",
        item: "CollectionAlbumsPageContent_item__I_Wuz",
        tabPanel: "CollectionAlbumsPageContent_tabPanel__0qXKZ"
      };
    },
    61288: (e, t, s) => {
      "use strict";
      var l;
      s.d(t, { x: () => l }), (function(e2) {
        e2.ASC = "asc", e2.DESC = "desc";
      })(l || (l = {}));
    },
    61354: (e) => {
      e.exports = {
        root: "CollectionDislikesPageContent_root__3AoS5",
        scrollContainer: "CollectionDislikesPageContent_scrollContainer__px7Vr",
        important: "CollectionDislikesPageContent_important__Oz6io",
        content: "CollectionDislikesPageContent_content__fScA9",
        content_withGrid: "CollectionDislikesPageContent_content_withGrid__wcx80",
        content_tracks: "CollectionDislikesPageContent_content_tracks__Hyiz_",
        footer: "CollectionDislikesPageContent_footer__E6nZG",
        item: "CollectionDislikesPageContent_item__aty4k",
        tabPanel: "CollectionDislikesPageContent_tabPanel__5L5T_",
        shimmerItem: "CollectionDislikesPageContent_shimmerItem__FMFR5"
      };
    },
    62567: (e) => {
      e.exports = {
        header: "CollectionShelfRecentlyPlayed_header__Nx7Cc",
        shelfColumn: "CollectionShelfRecentlyPlayed_shelfColumn__9xHhf",
        important: "CollectionShelfRecentlyPlayed_important__HS0GM"
      };
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65681: (e) => {
      e.exports = {
        title: "CollectionShelfNewEpisodes_title__y_SoT",
        root: "CollectionShelfNewEpisodes_root__VojSS",
        root_emptyList: "CollectionShelfNewEpisodes_root_emptyList__jsjSW",
        wrapper: "CollectionShelfNewEpisodes_wrapper__Z2EOe",
        iconBackground: "CollectionShelfNewEpisodes_iconBackground__K4Xui",
        button: "CollectionShelfNewEpisodes_button__3DALk"
      };
    },
    65696: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionKidsTracksPage: () => b });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(63585), m = s(8075), u = s(97800), _ = s(82644), C = s(33276), h = s(21365), g = s(74125), p = s(80585), x = s(4696), P = s(70366), j = s(89076), y = s.n(j);
      let b = (0, a.PA)(() => {
        let {
          collection: {
            kids: { tracks: e2 }
          },
          settings: { isMobile: t2 }
        } = (0, g.Pjs)(), { contentScrollRef: s2, setContentScrollRef: a2 } = (0, g.gKY)(), j2 = (0, g.W6M)(), { from: b2 } = (0, g.fyy)({ pageId: g._Q$.COLLECTION_KIDS_TRACKS }), { formatMessage: A } = (0, n.A)(), k = (0, g.wZZ)();
        (0, o.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), (0, g.Jzs)(e2.isResolved);
        let S = (0, o.useCallback)(
          (t3) => {
            e2.getData({ page: t3, pageSize: x.c });
          },
          [e2]
        );
        (0, g.XcE)(e2.pagesLoader, S);
        let v = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(p.A, { children: (0, l.jsx)(p.wi, { className: y().footer }) }) }),
          []
        ), N = e2.isShimmerVisible ? 20 : e2.items.length;
        return (e2.isNeededToLoad && (0, o.use)(e2.getData({ pageSize: x.c })), e2.isRejected) ? (0, l.jsx)(_.w, {}) : e2.isEmpty ? (0, l.jsx)(P.i, { title: A({ id: "kids.favourite-tracks-and-episodes" }) }) : (0, l.jsx)(g.nVz, {
          pageId: g._Q$.COLLECTION_KIDS_TRACKS,
          children: (0, l.jsx)(C.hO, {
            scrollElement: s2,
            outerTitle: A({ id: "kids.favourite-tracks-and-episodes" }),
            children: (0, l.jsxs)("div", {
              className: y().root,
              ...(0, c.Am)(c.Xk.collection.COLLECTION_KIDS_TRACKS_PAGE),
              children: [
                (0, l.jsx)(p.Y9, {
                  variant: p.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: j2.canBack,
                  children: (0, l.jsx)(u.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: t2 ? "m" : "xl",
                    lineClamp: 2,
                    children: (0, l.jsx)(r.A, { id: "kids.favourite-tracks-and-episodes" })
                  })
                }),
                (0, l.jsx)(p.$$, {
                  className: (0, i.$)(y().scrollContainer, y().important),
                  listClassName: y().content,
                  customComponents: v,
                  itemContentCallback: (t3) => {
                    let s3 = e2.items[t3];
                    if (!s3)
                      return (0, l.jsx)(p.DS, {
                        isActive: true,
                        className: y().shimmerItem,
                        variant: g.Xjt.PLAYLIST
                      });
                    let i2 = k(s3.entityId, {
                      contextData: { type: d.K.Various, meta: { id: s3.entityId }, from: b2 },
                      queueParams: { index: t3 },
                      loadContextMeta: false,
                      entitiesData: e2.sonataEntitiesData
                    });
                    return s3.type === m.S.MUSIC ? (0, l.jsx)(h.Kt, { track: s3, playContextParams: i2 }, t3) : (0, l.jsx)(
                      h.Kd,
                      { track: s3, playContextParams: i2, withPodcastName: s3.isTrackPodcast },
                      t3
                    );
                  },
                  initialItemCount: N,
                  totalCount: N,
                  onGetDataByPage: S,
                  pageSize: x.c,
                  totalRequests: e2.requestsCount,
                  handleRef: a2,
                  context: { listAriaLabel: A({ id: "entity-names.tracks" }) },
                  isMobileLayout: t2,
                  useWindowScroll: t2
                })
              ]
            })
          })
        });
      });
    },
    66401: (e, t, s) => {
      "use strict";
      s.d(t, { q: () => i });
      var l = s(63585);
      let i = (e2, t2, s2) => {
        let i2 = { type: l.K.Various, meta: { id: e2.id }, from: s2 || "" };
        return void 0 !== e2.albumId && (i2 = { type: l.K.Album, meta: { id: e2.albumId }, from: s2 || "" }), { contextData: i2, queueParams: { entityId: e2.id, index: t2 }, loadContextMeta: true };
      };
    },
    66875: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionClipsPage: () => O });
      var l = s(54486), i = s(28303), a = s(97396), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(85284), m = s(97800), u = s(82644), _ = s(33276), C = s(54830), h = s(74125), g = s(80585), p = s(31818), x = s.n(p), P = s(50420), j = s(1365), y = s(8817), b = s(67648), A = s(65779), k = s(77516);
      let S = () => window.innerWidth > 1920 ? 4 : window.innerWidth > 1200 ? 3 : 2;
      var v = s(44285), N = s.n(v);
      let L = (0, i.PA)((e2) => {
        var t2;
        let { className: s2 } = e2, { formatMessage: i2 } = (0, n.A)(), { clipsWillLike: a2 } = (0, h.Pjs)().collection.clips;
        return a2.isNeededToLoad && (0, o.use)(a2.getData()), (0, l.jsx)(h.FoH, {
          blockId: h.hf$.CLIPS_CAROUSEL,
          blockType: h.hf$.CLIPS_CAROUSEL,
          blockPosX: 1,
          blockPosY: 7,
          objectsCount: null == (t2 = a2.clips) ? void 0 : t2.length,
          children: (0, l.jsx)(A.KR, {
            className: (0, P.$)(N().root, s2),
            containerClassName: N().carouselBlock,
            carouselItemClassName: (0, P.$)(N().carouselItem, N().important),
            headerClassName: (0, P.$)(N().carouselBlockHeader, N().carouselBlock),
            isShimmerVisible: a2.isLoading,
            isShimmerActive: true,
            title: i2({ id: "entity-names.clips-will-like" }),
            clips: a2.clips || [],
            headingVariant: "h2",
            ...(0, c.Am)(c.Kq.clip.CLIPS_CAROUSEL)
          })
        });
      });
      var E = s(5956), I = s(52855), T = s.n(I);
      let f = (0, i.PA)(() => {
        let {
          collection: {
            clips: { clipsWillLike: e2 }
          }
        } = (0, h.Pjs)(), t2 = !e2.isEmpty && !e2.isRejected;
        return (0, l.jsxs)("div", {
          className: T().root,
          children: [
            (0, l.jsxs)("div", {
              className: T().content,
              children: [
                (0, l.jsx)(E.Icon, { className: T().icon, size: "xl", variant: "clip" }),
                (0, l.jsx)(m.Heading, {
                  className: T().title,
                  variant: "h3",
                  size: "xs",
                  ...(0, c.Am)(c.e8.landing.COLLECTION_CLIPS_BLOCK_LIKED_EMPTY_BLOCK_TITLE),
                  children: (0, l.jsx)(r.A, { id: "error-messages.empty-collection-clips-title" })
                }),
                (0, l.jsx)(m.Caption, {
                  className: T().text,
                  variant: "span",
                  type: "controls",
                  size: "l",
                  weight: "normal",
                  ...(0, c.Am)(c.e8.landing.COLLECTION_CLIPS_BLOCK_LIKED_EMPTY_BLOCK_TEXT),
                  children: (0, l.jsx)(r.A, { id: "error-messages.empty-collection-clips-text" })
                })
              ]
            }),
            t2 && (0, l.jsx)(L, {})
          ]
        });
      });
      var w = s(95955), D = s.n(w);
      let M = (0, i.PA)((e2) => {
        let { virtualItem: t2, resizeObserver: s2, columns: i2 } = e2, [a2, r2] = (0, b.d)(), { formatMessage: c2 } = (0, n.A)(), {
          collection: { clips: d2 }
        } = (0, h.Pjs)();
        (0, o.useEffect)(
          () => (a2 && s2 && s2.observe(a2), () => {
            a2 && s2 && s2.unobserve(a2);
          }),
          [a2, s2]
        );
        let m2 = d2.items.slice(t2.index * i2, t2.index * i2 + i2), u2 = d2.pager && d2.pager.total <= i2 ? 0 : 1, _2 = !d2.clipsWillLike.isEmpty && !d2.clipsWillLike.isRejected;
        return (0, l.jsxs)(
          "div",
          {
            ref: r2,
            "data-index": t2.index,
            className: D().virtualItem,
            style: { transform: "translateY(".concat(t2.start, "px)") },
            children: [
              (0, l.jsx)("div", {
                style: { gridTemplateColumns: "repeat(".concat(i2, ", minmax(0, 1fr))") },
                className: (0, P.$)(D().virtualItemRow, {
                  [D().virtualItemRow_withTopBorder]: t2.index === u2 + 1 && _2,
                  [D().virtualItemRow_withBottomBorder]: t2.index === u2 && _2
                }),
                children: null == m2 ? void 0 : m2.map((e3, t3) => {
                  if (!e3) {
                    let e4 = c2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: c2({ id: "entity-names.clip" }) }
                    );
                    return (0, l.jsx)(A.kV, { "aria-label": e4 }, t3);
                  }
                  return (0, l.jsx)(A.FC, { clip: e3 }, e3.clipId);
                })
              }),
              t2.index === u2 && _2 && (0, l.jsx)(L, { className: D().clipsWillLike })
            ]
          },
          t2.key
        );
      }), B = (0, i.PA)((e2) => {
        var t2;
        let { contentScrollRef: s2 } = e2, {
          collection: { clips: i2 },
          user: a2
        } = (0, h.Pjs)(), [n2, r2] = (0, o.useState)(S), [d2, m2] = (0, b.d)(), _2 = i2.pager && i2.pager.total <= n2 ? 0 : 1, { virtualizer: C2, resizeObserver: g2 } = (0, k.rA)({
          gap: 24,
          count: i2.pager ? Math.ceil((null == (t2 = i2.pager) ? void 0 : t2.total) / n2) : 5,
          getEstimateSize: (e3) => e3 === _2 ? 800 : 400,
          containerRef: d2
        }), p2 = (0, y.c)((e3) => {
          a2.account.data.uid && i2.getData({ userId: a2.account.data.uid, page: e3, pageSize: 20 });
        }), x2 = C2.getTotalSize(), P2 = C2.getVirtualItems(), A2 = (0, y.c)((e3) => {
          let t3 = Math.floor(e3.startIndex * n2 / 20), s3 = Math.ceil(e3.endIndex * n2 / 20);
          for (let e4 = t3; e4 <= s3; e4++) p2(e4);
        });
        (0, o.useEffect)(() => {
          i2.isNeededToLoad && (null == s2 || s2.scrollTo({ top: 0, behavior: "instant" }), i2.setInitialShimmer(), p2());
        }, [i2, i2.isNeededToLoad, p2, s2]), (0, o.useEffect)(() => {
          !C2.isScrolling && C2.range && A2(C2.range);
        }, [A2, C2.range, C2.isScrolling]);
        let v2 = (0, j.A)(() => {
          r2(S);
        }, 100);
        return ((0, o.useEffect)(
          () => (v2(), window.addEventListener("resize", v2), () => {
            window.removeEventListener("resize", v2);
          }),
          [v2]
        ), i2.isEmpty) ? (0, l.jsx)(f, {}) : i2.isRejected ? (0, l.jsx)(u.w, {}) : (0, l.jsx)("div", {
          className: D().virtualScroll,
          style: { height: "".concat(x2, "px") },
          ref: m2,
          ...(0, c.Am)(c.Kq.clip.COLLECTION_LIKED_CLIPS_BLOCK),
          children: P2.map((e3) => (0, l.jsx)(M, { virtualItem: e3, resizeObserver: g2, columns: n2 }, e3.index))
        });
      }), O = (0, i.PA)(() => {
        let {
          collection: { clips: e2 }
        } = (0, h.Pjs)(), { formatMessage: t2 } = (0, n.A)(), s2 = (0, h.W6M)(), i2 = (0, C.df)(), { contentScrollRef: p2, setContentScrollRef: P2 } = (0, h.gKY)();
        return (!i2 && e2.isLoaded && (0, a.redirect)(h.Zyd.collection.href), (0, h.Jzs)(e2.isResolved), (0, o.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), e2.isRejected) ? (0, l.jsx)(u.w, {}) : (0, l.jsx)(h.nVz, {
          pageId: h._Q$.OWN_CLIPS,
          children: (0, l.jsx)(h.jPc, {
            children: (0, l.jsxs)(_.hO, {
              scrollElement: p2,
              outerTitle: t2({ id: "entity-names.clips" }),
              children: [
                (0, l.jsx)(g.Y9, {
                  variant: g.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: s2.canBack,
                  children: (0, l.jsx)(m.Heading, {
                    id: "collection-artists-header",
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: (0, l.jsx)(r.A, { id: "entity-names.clips" })
                  })
                }),
                (0, l.jsxs)(d.C, {
                  scrollableContainerRef: P2,
                  className: x().root,
                  containerClassName: x().content,
                  scrollContentClassName: x().scrollContent,
                  ...(0, c.Am)(c.Xk.collection.COLLECTION_CLIPS_PAGE),
                  children: [
                    (0, l.jsx)(B, { contentScrollRef: p2 }),
                    (0, l.jsx)(g.A, { children: (0, l.jsx)(g.wi, { className: x().footer }) })
                  ]
                })
              ]
            })
          })
        });
      });
    },
    68696: (e) => {
      e.exports = {
        root: "CollectionPlaylistsCreatedPage_root__o77CF",
        scrollContainer: "CollectionPlaylistsCreatedPage_scrollContainer__Spb2M",
        important: "CollectionPlaylistsCreatedPage_important__DLkOq",
        content: "CollectionPlaylistsCreatedPage_content___qalr",
        footer: "CollectionPlaylistsCreatedPage_footer__I2jJa",
        item: "CollectionPlaylistsCreatedPage_item__2RmBg"
      };
    },
    70366: (e, t, s) => {
      "use strict";
      s.d(t, { i: () => h });
      var l = s(54486), i = s(28303), a = s(47713), o = s(77881), n = s(5956), r = s(56231), c = s(97800), d = s(33276), m = s(74125), u = s(80585), _ = s(94298), C = s.n(_);
      let h = (0, i.PA)((e2) => {
        let { title: t2 } = e2, {
          settings: { isMobile: s2 }
        } = (0, m.Pjs)(), { contentScrollRef: i2, setContentScrollRef: _2 } = (0, m.gKY)(), h2 = (0, m.W6M)(), g = (0, m.ZpR)(m.Zyd.collectionKids.href);
        return (0, l.jsxs)(d.hO, {
          scrollElement: i2,
          outerTitle: t2,
          children: [
            (0, l.jsx)(u.Y9, {
              variant: u.Vw.TEXT,
              withForwardControl: false,
              withBackwardControl: h2.canBack,
              children: (0, l.jsx)(c.Heading, {
                variant: "h2",
                weight: "bold",
                size: s2 ? "m" : "xl",
                lineClamp: 2,
                children: t2
              })
            }),
            (0, l.jsxs)(r.N, {
              ref: _2,
              containerClassName: C().scrollableContainer,
              className: C().root,
              children: [
                (0, l.jsxs)("div", {
                  className: C().content,
                  children: [
                    (0, l.jsx)("div", {
                      className: C().icon,
                      children: (0, l.jsx)(n.Icon, { variant: "like", size: "l" })
                    }),
                    (0, l.jsx)(c.Heading, {
                      className: C().title,
                      variant: "h3",
                      size: "xs",
                      children: (0, l.jsx)(a.A, { id: "error-messages.empty-collection-kids-sub-page-title" })
                    }),
                    (0, l.jsx)(o.$, {
                      onClick: g,
                      className: C().button,
                      role: "link",
                      color: "secondary",
                      size: "s",
                      radius: "xxxl",
                      children: (0, l.jsx)(c.Caption, {
                        type: "controls",
                        variant: "span",
                        size: "m",
                        children: (0, l.jsx)(a.A, { id: "error-messages.empty-collection-kids-sub-page-link" })
                      })
                    })
                  ]
                }),
                (0, l.jsx)(u.A, { children: (0, l.jsx)(u.wi, { className: C().footer }) })
              ]
            })
          ]
        });
      });
    },
    71550: (e) => {
      e.exports = {
        root: "CollectionNonMusicLikedPage_root__0e_hz",
        scrollContainer: "CollectionNonMusicLikedPage_scrollContainer__OthtN",
        important: "CollectionNonMusicLikedPage_important__MNJX3",
        footer: "CollectionNonMusicLikedPage_footer__F_mtD",
        item: "CollectionNonMusicLikedPage_item__Rb0yS",
        emptyBlock: "CollectionNonMusicLikedPage_emptyBlock__WAdri",
        content: "CollectionNonMusicLikedPage_content__9WDX5"
      };
    },
    71898: (e) => {
      e.exports = {
        root: "CollectionShelfNewEpisodesPage_root__HTWkS",
        scrollableContainer: "CollectionShelfNewEpisodesPage_scrollableContainer__xGZcJ",
        footer: "CollectionShelfNewEpisodesPage_footer__0i466"
      };
    },
    72230: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionNonMusicLikedPage: () => P });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(97800), m = s(82644), u = s(94376), _ = s(33276), C = s(74125), h = s(80585), g = s(32290), p = s(71550), x = s.n(p);
      let P = (0, a.PA)(() => {
        var e2, t2, s2;
        let {
          user: a2,
          collection: { nonMusicLiked: p2 },
          settings: { isMobile: P2 },
          library: j
        } = (0, C.Pjs)(), { formatMessage: y } = (0, n.A)(), { contentScrollRef: b, setContentScrollRef: A } = (0, C.gKY)(), k = (0, C.W6M)();
        (0, C.Jzs)(p2.isResolved);
        let S = (0, o.useCallback)(
          (e3) => {
            a2.account.data.uid && p2.getData({ userId: a2.account.data.uid, metaType: "podcast", page: e3, pageSize: 20 });
          },
          [p2, a2.account.data.uid]
        );
        if (p2.isRejected) return (0, l.jsx)(m.w, {});
        (0, o.useEffect)(
          () => () => {
            p2.reset();
          },
          [p2]
        );
        let v = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(h.A, { children: (0, l.jsx)(h.wi, { className: x().footer }) }) }),
          []
        );
        if (a2.account.data.uid && p2.isNeededToLoad) {
          let e3 = [p2.getData({ userId: a2.account.data.uid, metaType: "podcast", pageSize: 20 }), j.getData()];
          (0, o.use)(Promise.allSettled(e3));
        }
        return (0, l.jsx)(C.nVz, {
          pageId: C._Q$.OWN_PODCASTS,
          children: (0, l.jsx)(_.hO, {
            scrollElement: b,
            outerTitle: y({ id: "page.delayed-non-music" }),
            children: (0, l.jsxs)("div", {
              className: x().root,
              ...(0, c.Am)(c.Xk.collection.COLLECTION_NON_MUSIC_LIKED_PAGE),
              children: [
                (0, l.jsx)(h.Y9, {
                  variant: h.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: k.canBack,
                  children: (0, l.jsx)(d.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: (0, l.jsx)(r.A, { id: "page.delayed-non-music" })
                  })
                }),
                p2.isEmptyItems && !p2.isRejected && (0, l.jsx)(g.M, { className: x().emptyBlock }),
                (0, l.jsx)(h.$$, {
                  className: (0, i.$)(x().scrollContainer, x().important),
                  listClassName: x().content,
                  itemClassName: x().item,
                  customComponents: v,
                  itemContentCallback: (e3) => {
                    var t3;
                    let s3 = null == (t3 = p2.items) ? void 0 : t3[e3], i2 = y(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: y({ id: "entity-names.podcast" }) }
                    );
                    return s3 ? (0, l.jsx)(u.aX, { album: s3, contentLinesCount: 3, withLikesCount: true, withAddition: false }, s3.id) : (0, l.jsx)(h.Vt, { "aria-label": i2 });
                  },
                  totalCount: null != (t2 = null == (e2 = p2.pager) ? void 0 : e2.total) ? t2 : 0,
                  onGetDataByPage: S,
                  pageSize: 20,
                  totalRequests: null != (s2 = p2.requestsCount) ? s2 : 0,
                  handleRef: A,
                  context: { listAriaLabel: y({ id: "collection.liked-non-music-list" }) },
                  isMobileLayout: P2,
                  useWindowScroll: P2
                })
              ]
            })
          })
        });
      });
    },
    72736: (e) => {
      e.exports = {
        emptyContent: "CollectionNonMusicEmpty_emptyContent__Km4Xo",
        emptyContentIcon: "CollectionNonMusicEmpty_emptyContentIcon__ZHVte",
        emptyContentTitle: "CollectionNonMusicEmpty_emptyContentTitle__PJIFd"
      };
    },
    73450: (e) => {
      e.exports = { root: "CollectionDislikesPage_root__Qnohu" };
    },
    75312: (e, t, s) => {
      "use strict";
      s.d(t, { SomethingWentWrong: () => g });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(77881), d = s(5956), m = s(97800), u = s(74125), _ = s(80585), C = s(63708), h = s.n(C);
      let g = (0, a.PA)((e2) => {
        let { className: t2, withBackwardControl: s2 = true } = e2, { formatMessage: a2 } = (0, n.A)(), C2 = a2({ id: "error-messages.something-went-wrong" });
        (0, u.CgZ)(C2);
        let { sendRefreshEvent: g2 } = (0, u.cYT)(), p = (0, o.useCallback)(() => {
          g2(), window.location.href = u.Zyd.main.href;
        }, [g2]), { contentRef: x } = (0, u.gKY)();
        return (0, l.jsxs)("div", {
          className: (0, i.$)(h().root, t2),
          children: [
            s2 && (0, l.jsx)(_.Lh, {
              withBackwardFallback: "/",
              className: (0, i.$)(h().navigation, { [h().navigation_desktop]: !x }),
              withForwardControl: false
            }),
            (0, l.jsxs)("div", {
              className: (0, i.$)(h().content, { [h().content_shrink]: !s2 }),
              children: [
                (0, l.jsx)(d.Icon, { className: h().icon, variant: "attention", size: "xxl" }),
                (0, l.jsx)(m.Heading, {
                  className: (0, i.$)(h().title, h().important),
                  variant: "h3",
                  size: "xs",
                  children: C2
                }),
                (0, l.jsxs)(m.Caption, {
                  className: (0, i.$)(h().text, h().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, l.jsx)(r.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, l.jsx)(c.$, {
                  onClick: p,
                  className: h().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, l.jsxs)(m.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, l.jsx)(r.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    77770: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionNonMusicPage: () => b });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(27510), m = s(56231), u = s(97800), _ = s(82644), C = s(94376), h = s(33276), g = s(74125), p = s(80585), x = s(99227), P = s(32290), j = s(17714), y = s.n(j);
      let b = (0, a.PA)(() => {
        var e2;
        let {
          user: t2,
          collection: { nonMusicLiked: s2, shelf: a2 },
          library: j2
        } = (0, g.Pjs)(), { formatMessage: b2 } = (0, n.A)(), { contentScrollRef: A, setContentScrollRef: k } = (0, g.gKY)(), S = (0, g.W6M)();
        if ((0, g.Jzs)(s2.isResolved), s2.isRejected && !a2.hasLiked) return (0, l.jsx)(_.w, {});
        (0, o.useEffect)(
          () => () => {
            s2.reset(), a2.reset();
          },
          [s2, a2]
        );
        let v = (0, d.L)(() => {
          var e3;
          return null == (e3 = s2.items) ? void 0 : e3.slice(0, 10).map(
            (e4, t3) => e4 ? (0, l.jsx)(
              C.aX,
              { album: e4, contentLinesCount: 3, withLikesCount: true, withAddition: false },
              null == e4 ? void 0 : e4.id
            ) : (0, l.jsx)(p.Vt, {}, "shimmer-".concat(t3))
          );
        }), N = (0, o.useMemo)(() => {
          var e3;
          return !s2.isEmptyItems || s2.isRejected || a2.hasLiked ? s2.isRejected || !(null == (e3 = s2.items) ? void 0 : e3.length) && s2.requestsCount ? null : (0, l.jsx)(p.OY, {
            headerClassName: y().blockHeader,
            containerClassName: y().carousel,
            isShimmerVisible: s2.isLoading,
            isShimmerActive: true,
            title: b2({ id: "page.delayed-non-music" }),
            viewAllActionLink: g.Zyd.collectionNonMusicLiked.href,
            children: v
          }) : (0, l.jsx)(P.M, {});
        }, [
          s2.isLoading,
          b2,
          v,
          s2.isRejected,
          a2.hasLiked,
          s2.isEmptyItems,
          null == (e2 = s2.items) ? void 0 : e2.length,
          s2.requestsCount
        ]);
        if (t2.account.data.uid && s2.isNeededToLoad) {
          let e3 = [s2.getData({ userId: t2.account.data.uid, metaType: "podcast", pageSize: 10 }), j2.getData()];
          (0, o.use)(Promise.allSettled(e3));
        }
        return (0, l.jsx)(g.nVz, {
          pageId: g._Q$.OWN_PODCASTS,
          children: (0, l.jsx)(h.hO, {
            scrollElement: A,
            outerTitle: b2({ id: "page.podcasts-and-books" }),
            children: (0, l.jsxs)("div", {
              className: y().root,
              ...(0, c.Am)(c.Xk.collection.COLLECTION_NON_MUSIC_PAGE),
              children: [
                (0, l.jsx)(p.Y9, {
                  variant: p.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: S.canBack,
                  children: (0, l.jsx)(u.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: (0, l.jsx)(r.A, { id: "page.podcasts-and-books" })
                  })
                }),
                (0, l.jsx)(m.N, {
                  ref: k,
                  containerClassName: (0, i.$)(y().scrollableContainer, y().important),
                  className: y().root,
                  children: (0, l.jsxs)("div", {
                    className: y().content,
                    children: [
                      (0, l.jsxs)("div", {
                        className: y().likedBlocks,
                        children: [
                          N,
                          a2.hasLiked && (0, l.jsx)(x.m, {
                            carouselClassName: y().shelfBlockCarousel,
                            headerClassName: y().shelfBlockHeader,
                            itemsCount: 5
                          })
                        ]
                      }),
                      (0, l.jsx)(p.A, { children: (0, l.jsx)(p.wi, { className: y().footer }) })
                    ]
                  })
                })
              ]
            })
          })
        });
      });
    },
    80506: (e, t, s) => {
      "use strict";
      s.d(t, { a: () => i });
      var l = s(87965);
      let i = () => {
        let e2 = null, t2 = new l.cJ(false), s2 = [];
        return {
          isLoaded: t2,
          init: (l2) => {
            var i2, a;
            if (void 0 !== (null == (i2 = window.Ya) ? void 0 : i2.Metrika2) && !t2.value)
              try {
                e2 = new window.Ya.Metrika2({ ...l2 }), t2.value = true, a = e2, s2.forEach((e3) => {
                  e3(a);
                }), s2.length = 0;
              } catch (e3) {
                ("string" == typeof e3 || e3 instanceof Error) && l2.logger.error(e3);
              }
          },
          count: function(t3) {
            let l2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "counter";
            e2 ? e2.params({ [l2]: t3 }) : s2.push((e3) => {
              e3.params({ [l2]: t3 });
            });
          },
          hit: (t3) => {
            e2 ? e2.hit(t3) : s2.push((e3) => {
              e3.hit(t3);
            });
          },
          reachGoal: (t3, l2) => {
            if (!e2) return void s2.push((e3) => e3.reachGoal(t3, l2));
            e2.reachGoal(t3, l2);
          }
        };
      };
    },
    82206: (e) => {
      e.exports = {
        subTitle: "CollectionArtistsPageTopArtists_subTitle__xJdoJ",
        gridLayout: "CollectionArtistsPageTopArtists_gridLayout__H2AR_",
        chart: "CollectionArtistsPageTopArtists_chart__inbPE",
        position: "CollectionArtistsPageTopArtists_position__YDoRC",
        listenTime: "CollectionArtistsPageTopArtists_listenTime__NqxRf"
      };
    },
    82552: (e) => {
      e.exports = {
        root: "CollectionShelfPageEmpty_root__KrMco",
        iconBackground: "CollectionShelfPageEmpty_iconBackground__limUg",
        title: "CollectionShelfPageEmpty_title__cwF4m",
        button: "CollectionShelfPageEmpty_button___uzMX"
      };
    },
    82644: (e, t, s) => {
      "use strict";
      s.d(t, { w: () => l.SomethingWentWrong });
      var l = s(75312);
    },
    83155: (e) => {
      e.exports = {
        root: "CollectionPlaylistsPageHeader_root__GfGIl",
        container: "CollectionPlaylistsPageHeader_container__oh7C2",
        title: "CollectionPlaylistsPageHeader_title__2D23I",
        staticTabs: "CollectionPlaylistsPageHeader_staticTabs__9c9yq",
        stickyTabs: "CollectionPlaylistsPageHeader_stickyTabs__Iot6U",
        tab: "CollectionPlaylistsPageHeader_tab__aNTOB",
        tabsShimmer: "CollectionPlaylistsPageHeader_tabsShimmer__u9JIN",
        tabShimmer: "CollectionPlaylistsPageHeader_tabShimmer__ekXeT",
        staticHeader: "CollectionPlaylistsPageHeader_staticHeader__lzc4l",
        important: "CollectionPlaylistsPageHeader_important__uR36G",
        stickyHeader: "CollectionPlaylistsPageHeader_stickyHeader__ojvbQ"
      };
    },
    85872: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionShelfLikedPage: () => A });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(27510), m = s(97800), u = s(82644), _ = s(94376), C = s(33276), h = s(21365), g = s(74125), p = s(80585), x = s(4696), P = s(66401), j = s(12652), y = s(17928), b = s.n(y);
      let A = (0, a.PA)(() => {
        let {
          settings: { isMobile: e2 },
          collection: { shelfLiked: t2 }
        } = (0, g.Pjs)(), { contentScrollRef: s2, setContentScrollRef: a2 } = (0, g.gKY)(), y2 = (0, g.W6M)(), { formatMessage: A2 } = (0, n.A)(), k = (0, g.wZZ)(), S = (0, o.useCallback)(
          (e3) => {
            t2.getData({ page: e3, pageSize: x.c });
          },
          [t2]
        );
        (0, g.XcE)(t2.pagesLoader, S);
        let v = (0, d.L)(() => ({
          Footer: () => (0, l.jsx)(p.A, { children: (0, l.jsx)(p.wi, { className: b().footer }) })
        })), N = t2.isShimmerVisible ? 20 : t2.items.length;
        return ((0, o.useEffect)(
          () => () => {
            t2.reset();
          },
          [t2]
        ), (0, g.Jzs)(t2.isResolved), t2.isNeededToLoad && (0, o.use)(t2.getData({ pageSize: x.c })), t2.isRejected) ? (0, l.jsx)(u.w, {}) : t2.isEmpty ? (0, l.jsx)(j.F, { title: A2({ id: "error-messages.empty-shelf-liked-page-title" }) }) : (0, l.jsx)(C.hO, {
          scrollElement: s2,
          outerTitle: A2({ id: "podcast.shelf-liked-title" }),
          children: (0, l.jsxs)("div", {
            className: b().root,
            ...(0, c.Am)(c.Xk.collection.COLLECTION_SHELF_LIKED_PAGE),
            children: [
              (0, l.jsx)(p.Y9, {
                variant: p.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: y2.canBack,
                children: (0, l.jsx)(m.Heading, {
                  variant: "h2",
                  weight: "bold",
                  size: "xl",
                  lineClamp: 1,
                  children: (0, l.jsx)(r.A, { id: "podcast.shelf-liked-title" })
                })
              }),
              (0, l.jsx)(p.$$, {
                className: (0, i.$)(b().scrollContainer, b().important),
                customComponents: v,
                itemContentCallback: (e3) => {
                  let s3 = t2.items[e3];
                  if (!s3) return (0, l.jsx)(p.DS, { variant: g.Xjt.PLAYLIST, isActive: true }, e3);
                  if (s3.album) return (0, l.jsx)(_.M_, { album: s3.album }, s3.album.getKey(e3));
                  let i2 = k(e3, (0, P.q)(s3.track, e3, t2.typeForFrom));
                  return (0, l.jsx)(
                    h.Kd,
                    { track: s3.track, playContextParams: i2, withPodcastName: true },
                    s3.track.getKey(e3)
                  );
                },
                initialItemCount: N,
                totalCount: N,
                onGetDataByPage: S,
                pageSize: x.c,
                totalRequests: t2.requestsCount,
                listClassName: b().content,
                itemClassName: b().item,
                handleRef: a2,
                context: { listAriaLabel: A2({ id: "podcast.shelf-liked-title" }) },
                isMobileLayout: e2,
                useWindowScroll: e2
              })
            ]
          })
        });
      });
    },
    88798: (e) => {
      e.exports = {
        root: "CollectionAlbumsPageEmpty_root__7yn1F",
        icon: "CollectionAlbumsPageEmpty_icon__XFf9x",
        title: "CollectionAlbumsPageEmpty_title__hMQde",
        text: "CollectionAlbumsPageEmpty_text__jp_lj"
      };
    },
    89076: (e) => {
      e.exports = {
        root: "CollectionKidsTracksPage_root__8nP0n",
        scrollContainer: "CollectionKidsTracksPage_scrollContainer__1d9Pm",
        important: "CollectionKidsTracksPage_important__oX_Ny",
        footer: "CollectionKidsTracksPage_footer__dujIV",
        content: "CollectionKidsTracksPage_content__Vf43s"
      };
    },
    90229: (e, t, s) => {
      "use strict";
      s.d(t, { W: () => i });
      var l = s(11405);
      let i = (e2) => !!e2 && (e2 === l.g.RATING || e2 === l.g.YEAR);
    },
    90392: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionKidsAlbumsPage: () => j });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(97800), m = s(82644), u = s(94376), _ = s(33276), C = s(74125), h = s(80585), g = s(4696), p = s(70366), x = s(57956), P = s.n(x);
      let j = (0, a.PA)(() => {
        let {
          settings: { isMobile: e2 },
          collection: {
            kids: { albums: t2 }
          }
        } = (0, C.Pjs)(), { contentScrollRef: s2, setContentScrollRef: a2 } = (0, C.gKY)(), x2 = (0, C.W6M)(), { formatMessage: j2 } = (0, n.A)(), y = (0, o.useCallback)(
          (e3) => {
            t2.getData({ page: e3, pageSize: g.c });
          },
          [t2]
        );
        (0, C.XcE)(t2.pagesLoader, y);
        let b = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(h.A, { children: (0, l.jsx)(h.wi, { className: P().footer }) }) }),
          []
        ), A = t2.isShimmerVisible ? 20 : t2.items.length;
        return ((0, o.useEffect)(
          () => () => {
            t2.reset();
          },
          [t2]
        ), (0, C.Jzs)(t2.isResolved), t2.isNeededToLoad && (0, o.use)(t2.getData({ pageSize: g.c })), t2.isRejected) ? (0, l.jsx)(m.w, {}) : t2.isEmpty ? (0, l.jsx)(p.i, { title: j2({ id: "kids.albums-and-podcasts" }) }) : (0, l.jsx)(C.nVz, {
          pageId: C._Q$.COLLECTION_KIDS_ALBUMS,
          children: (0, l.jsx)(_.hO, {
            scrollElement: s2,
            outerTitle: j2({ id: "kids.albums-and-podcasts" }),
            children: (0, l.jsxs)("div", {
              className: P().root,
              ...(0, c.Am)(c.Xk.collection.COLLECTION_KIDS_ALBUMS_PAGE),
              children: [
                (0, l.jsx)(h.Y9, {
                  variant: h.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: x2.canBack,
                  children: (0, l.jsx)(d.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: e2 ? "m" : "xl",
                    lineClamp: 2,
                    children: (0, l.jsx)(r.A, { id: "kids.albums-and-podcasts" })
                  })
                }),
                (0, l.jsx)(h.$$, {
                  className: (0, i.$)(P().scrollContainer, P().important),
                  listClassName: P().content,
                  itemClassName: P().item,
                  customComponents: b,
                  itemContentCallback: (e3) => {
                    let s3 = t2.items[e3], i2 = j2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: j2({ id: "entity-names.album" }) }
                    );
                    return s3 ? (0, l.jsx)(u.aX, { album: s3, contentLinesCount: 4, withLikesCount: true }, s3.id) : (0, l.jsx)(h.Vt, { "aria-label": i2, linesCount: 4 });
                  },
                  initialItemCount: A,
                  totalCount: A,
                  onGetDataByPage: y,
                  pageSize: g.c,
                  totalRequests: t2.requestsCount,
                  handleRef: a2,
                  context: { listAriaLabel: j2({ id: "entity-names.albums" }) },
                  isMobileLayout: e2,
                  useWindowScroll: e2
                })
              ]
            })
          })
        });
      });
    },
    92066: (e) => {
      e.exports = { root: "CollectionAlbumsPage_root__qMtcC" };
    },
    94162: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionKidsPlaylistsPage: () => j });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(43426), r = s(47713), c = s(31500), d = s(97800), m = s(82644), u = s(33276), _ = s(83909), C = s(74125), h = s(80585), g = s(4696), p = s(70366), x = s(8162), P = s.n(x);
      let j = (0, a.PA)(() => {
        let {
          settings: { isMobile: e2 },
          collection: {
            kids: { playlists: t2 }
          }
        } = (0, C.Pjs)(), { contentScrollRef: s2, setContentScrollRef: a2 } = (0, C.gKY)(), x2 = (0, C.W6M)(), { formatMessage: j2 } = (0, n.A)(), y = (0, o.useCallback)(
          (e3) => {
            t2.getData({ page: e3, pageSize: g.c });
          },
          [t2]
        );
        (0, C.XcE)(t2.pagesLoader, y);
        let b = (0, o.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(h.A, { children: (0, l.jsx)(h.wi, { className: P().footer }) }) }),
          []
        ), A = t2.isShimmerVisible ? 20 : t2.items.length;
        return ((0, o.useEffect)(
          () => () => {
            t2.reset();
          },
          [t2]
        ), (0, C.Jzs)(t2.isResolved), t2.isNeededToLoad && (0, o.use)(t2.getData({ pageSize: g.c })), t2.isRejected) ? (0, l.jsx)(m.w, {}) : t2.isEmpty ? (0, l.jsx)(p.i, { title: j2({ id: "entity-names.artist-playlist" }) }) : (0, l.jsx)(C.nVz, {
          pageId: C._Q$.COLLECTION_KIDS_PLAYLISTS,
          children: (0, l.jsx)(u.hO, {
            scrollElement: s2,
            outerTitle: j2({ id: "entity-names.artist-playlist" }),
            children: (0, l.jsxs)("div", {
              className: P().root,
              ...(0, c.Am)(c.Xk.collection.COLLECTION_KIDS_PLAYLISTS_PAGE),
              children: [
                (0, l.jsx)(h.Y9, {
                  variant: h.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: x2.canBack,
                  children: (0, l.jsx)(d.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: (0, l.jsx)(r.A, { id: "entity-names.artist-playlist" })
                  })
                }),
                (0, l.jsx)(h.$$, {
                  className: (0, i.$)(P().scrollContainer, P().important),
                  customComponents: b,
                  itemContentCallback: (e3) => {
                    let s3 = t2.items[e3], i2 = j2(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: j2({ id: "entity-names.album" }) }
                    );
                    return s3 ? (0, l.jsx)(_.B6, { playlist: s3, contentLinesCount: 3 }, s3.id) : (0, l.jsx)(h.Vt, { "aria-label": i2, linesCount: 3 });
                  },
                  initialItemCount: A,
                  totalCount: A,
                  onGetDataByPage: y,
                  totalRequests: t2.requestsCount,
                  pageSize: g.c,
                  listClassName: P().content,
                  itemClassName: P().item,
                  handleRef: a2,
                  context: { listAriaLabel: j2({ id: "entity-names.albums" }) },
                  isMobileLayout: e2,
                  useWindowScroll: e2
                })
              ]
            })
          })
        });
      });
    },
    94298: (e) => {
      e.exports = {
        root: "CollectionKidsSubPageEmpty_root__53xVY",
        scrollableContainer: "CollectionKidsSubPageEmpty_scrollableContainer__Dh6Sp",
        content: "CollectionKidsSubPageEmpty_content__VZZg5",
        icon: "CollectionKidsSubPageEmpty_icon__IQAON",
        title: "CollectionKidsSubPageEmpty_title__t9H4h",
        button: "CollectionKidsSubPageEmpty_button__26EKY",
        footer: "CollectionKidsSubPageEmpty_footer__XQnAw"
      };
    },
    95955: (e) => {
      e.exports = {
        root: "CollectionClipsPageClips_root__uB8s_",
        virtualScroll: "CollectionClipsPageClips_virtualScroll__o3uWm",
        virtualItem: "CollectionClipsPageClips_virtualItem__UDzx8",
        virtualItemRow: "CollectionClipsPageClips_virtualItemRow__RPIOY",
        virtualItemRow_withTopBorder: "CollectionClipsPageClips_virtualItemRow_withTopBorder__Q6k2l",
        virtualItemRow_withBottomBorder: "CollectionClipsPageClips_virtualItemRow_withBottomBorder__D5Dep",
        clipsWillLike: "CollectionClipsPageClips_clipsWillLike__IhK8Q"
      };
    },
    97296: (e, t, s) => {
      "use strict";
      s.d(t, { CollectionNotFoundPage: () => o });
      var l = s(54486), i = s(28303), a = s(42421);
      let o = (0, i.PA)(() => (0, l.jsx)(a.M, {}));
    },
    99227: (e, t, s) => {
      "use strict";
      s.d(t, { m: () => p });
      var l = s(54486), i = s(50420), a = s(28303), o = s(61910), n = s(31500), r = s(27510), c = s(94376), d = s(21365), m = s(74125), u = s(80585), _ = s(66401), C = s(59255), h = s(59127), g = s.n(h);
      let p = (0, a.PA)((e2) => {
        var t2;
        let { className: s2, itemsCount: a2, headerClassName: h2, carouselClassName: p2 } = e2, {
          collection: {
            shelf: { liked: x }
          }
        } = (0, m.Pjs)(), P = (0, r.L)(() => {
          var e3;
          return null == (e3 = x.entities) ? void 0 : e3.map((e4, t3) => {
            if (e4.album) return (0, l.jsx)(c.M_, { album: e4.album }, e4.album.getKey(t3));
            let s3 = (0, _.q)(e4.track, t3, x.typeForFrom);
            return (0, l.jsx)(
              d.Kd,
              { track: e4.track, playContextParams: s3, withPodcastName: true },
              e4.track.getKey(t3)
            );
          });
        });
        return (x.isNeededToLoad && (0, o.use)(x.getData()), !x.isLoading && (null == (t2 = x.entities) ? void 0 : t2.length)) ? (0, l.jsx)(u.$2, {
          shimmer: (0, l.jsx)(u.DS, { variant: m.Xjt.PLAYLIST, isActive: true }),
          isShimmerActive: true,
          isShimmerVisible: x.isLoading,
          className: s2,
          carouselItemClassName: (0, i.$)(g().shelfColumn, g().important),
          blockHeaderClassName: (0, i.$)(g().header, h2),
          carouselClassName: p2,
          blockHeaderTitle: x.title,
          itemsCountPerColumn: null != a2 ? a2 : 0,
          maxColumnsCount: u.DI.ONE,
          viewAllActionLink: m.Zyd.collectionShelfLiked.href,
          ...(0, n.Am)(n.Xk.collection.COLLECTION_SHELF_PAGE_SHELF_LIKED_BLOCK),
          children: P
        }) : (0, l.jsx)(C.E, { className: s2, withHeader: true });
      });
    }
  }
]);
