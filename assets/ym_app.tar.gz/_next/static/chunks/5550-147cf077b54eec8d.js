(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [5550],
  {
    2677: (e) => {
      e.exports = {
        root: "ArtistSimilarPage_root__rvTLl",
        scrollableContent: "ArtistSimilarPage_scrollableContent__WD72A",
        container: "ArtistSimilarPage_container__DDj5O",
        content: "ArtistSimilarPage_content__X71xs",
        footer: "ArtistSimilarPage_footer__FdVkO"
      };
    },
    6098: (e) => {
      e.exports = { root: "ArtistPageSkeleton_root___Cj4n", error: "ArtistPageSkeleton_error__GMCzn" };
    },
    6237: (e, t, a) => {
      "use strict";
      a.d(t, { ArtistConcertsPage: () => T });
      var i = a(54486), s = a(28303), r = a(97396), l = a(61910), o = a(43426), n = a(47713), c = a(9348), d = a(31500), u = a(56231), m = a(97800), p = a(33276), g = a(63695), h = a(77217), A = a(74125), f = a(80585), _ = a(43350), b = a(62395), v = a(79190), S = a(82678), k = a(74064), C = a(23629), x = a.n(C);
      let T = (0, s.PA)((e2) => {
        var t2, a2, s2;
        let { artistId: C2, preloadedArtist: T2, preloadedConcerts: N } = e2, { artist: j, disclaimerModalState: I, experiments: L } = (0, A.Pjs)(), { formatMessage: P } = (0, o.A)(), { contentScrollRef: E, setContentScrollRef: R } = (0, A.gKY)(), y = (0, A.W6M)(), w = (0, l.useRef)(String((0, c.A)())), B = ((e3) => {
          let { artistId: t3, viewUuid: a3 } = e3, i2 = (0, b.st)(), { hash: s3 } = (0, b.gf)(), r2 = (0, A.UlF)();
          return (0, l.useCallback)(() => {
            if (!i2 || !t3) return;
            let e4 = (0, _.Fx)({
              params: { hash: s3, artistId: t3, viewUuid: a3 },
              logger: r2,
              context: "useSendEventOnConcertsPageOpened"
            });
            e4 && (0, _.__)(i2.evgenInstance, e4);
          }, [i2, t3, s3, r2, a3]);
        })({ artistId: C2, viewUuid: w.current }), O = ((e3) => {
          let { artistId: t3, viewUuid: a3 } = e3, i2 = (0, b.st)(), { hash: s3 } = (0, b.gf)(), r2 = (0, A.UlF)();
          return (0, l.useCallback)(() => {
            if (!i2 || !t3) return;
            let e4 = (0, _.Fx)({
              params: { hash: s3, artistId: t3, viewUuid: a3 },
              logger: r2,
              context: "useSendEventOnConcertsPageClosed"
            });
            e4 && (0, _.pe)(i2.evgenInstance, e4);
          }, [i2, t3, s3, r2, a3]);
        })({ artistId: C2, viewUuid: w.current });
        (0, l.useEffect)(
          () => (B(), () => {
            O();
          }),
          [O, B]
        );
        let M = (0, g.SA)({ artist: null == (t2 = j.meta) ? void 0 : t2.artist, shouldHistoryBack: true });
        (0, k.G)(C2), (0, l.useEffect)(() => {
          var e3;
          (null == (e3 = j.meta) ? void 0 : e3.artist.isUnsafeLegal) && M();
        }, [null == (a2 = j.meta) ? void 0 : a2.artist.isUnsafeLegal, M]), (0, S._)(j, C2), (0, l.useEffect)(
          () => () => {
            j.concertsSubpage.reset();
          },
          [j]
        ), (0, A.Jzs)(j.concertsSubpage.isResolved), (j.concertsSubpage.isNotFound || L.checkExperiment(A.zal.disableAllConcerts, "on")) && (0, r.notFound)();
        let U = (0, l.useMemo)(() => {
          var e3;
          return j.concertsSubpage.isLoading ? (0, f.Tb)(10) : null == (e3 = j.concertsSubpage.concerts) ? void 0 : e3.map(
            (e4, t3) => (0, i.jsx)(
              A.Bki,
              {
                objectId: String(e4.id),
                objectPos: t3 + 1,
                children: (0, i.jsx)(h.VN, {
                  artistId: C2,
                  concert: e4,
                  viewUuid: w.current,
                  meta: (0, i.jsx)(h.ZH, {})
                })
              },
              e4.id
            )
          );
        }, [j.concertsSubpage.concerts, j.concertsSubpage.isLoading, C2, w]), F = [];
        return (j.concertsSubpage.isNeededToLoad && F.push(j.concertsSubpage.getData({ artistId: Number(C2), preloadedConcerts: N })), j.isNeededToLoad && F.push(j.getData({ artistId: C2, preloadedArtist: T2 })), ((e3) => {
          (0, l.useEffect)(() => {
            if (!(null == e3 ? void 0 : e3.meta) || e3.isLoading) return;
            let t3 = (0, g.NE)(e3.meta.artist);
            (0, v.U)({ artist: t3 }, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, A.jxB)(e4);
            });
          }, [null == e3 ? void 0 : e3.meta, null == e3 ? void 0 : e3.isLoading]);
        })(j), F.length && (0, l.use)(Promise.allSettled(F)), null == (s2 = j.meta) ? void 0 : s2.artist.isLegalRejected) ? (0, i.jsx)(f.MW, { modalState: I }) : (0, i.jsx)(A.nVz, {
          pageId: A._Q$.ARTIST_CONCERTS,
          pageEntityId: C2,
          children: (0, i.jsx)(A.jPc, {
            children: (0, i.jsxs)(p.hO, {
              scrollElement: E,
              outerTitle: P({ id: "page.artist-concerts-header" }, { artistName: j.commonSubPage.artistName }),
              children: [
                (0, i.jsx)(f.Y9, {
                  variant: f.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: y.canBack,
                  children: (0, i.jsx)(m.Heading, {
                    id: "concerts-header",
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: (0, i.jsx)(n.A, {
                      id: "page.artist-concerts-header",
                      values: { artistName: j.commonSubPage.artistName }
                    })
                  })
                }),
                (0, i.jsx)(u.N, {
                  ref: R,
                  className: x().root,
                  containerClassName: x().scrollableContainer,
                  children: (0, i.jsxs)("div", {
                    className: x().container,
                    ...(0, d.Am)(d.Xk.artist.ARTIST_CONCERTS_PAGE),
                    children: [
                      (0, i.jsx)("div", {
                        className: x().content,
                        "aria-labelledby": "concerts-header",
                        tabIndex: 0,
                        children: U
                      }),
                      (0, i.jsx)(f.A, { children: (0, i.jsx)(f.wi, { className: x().footer }) })
                    ]
                  })
                })
              ]
            })
          })
        });
      });
    },
    7425: (e, t, a) => {
      "use strict";
      a.d(t, { ArtistSimilarPage: () => C });
      var i = a(54486), s = a(28303), r = a(97396), l = a(61910), o = a(43426), n = a(47713), c = a(31500), d = a(56231), u = a(97800), m = a(82644), p = a(55616), g = a(33276), h = a(63695), A = a(74125), f = a(80585), _ = a(91280), b = a(82678), v = a(74064), S = a(2677), k = a.n(S);
      let C = (0, s.PA)((e2) => {
        var t2, a2, s2, S2;
        let { artistId: C2, preloadedArtist: x, preloadedSimilarArtists: T } = e2, { artist: N, disclaimerModalState: j } = (0, A.Pjs)(), { formatMessage: I } = (0, o.A)(), { contentScrollRef: L, setContentScrollRef: P } = (0, A.gKY)(), E = (0, A.W6M)(), R = (0, h.SA)({ artist: null == (t2 = N.meta) ? void 0 : t2.artist, shouldHistoryBack: true });
        (0, v.G)(C2), (0, l.useEffect)(() => {
          var e3;
          (null == (e3 = N.meta) ? void 0 : e3.artist.isUnsafeLegal) && R();
        }, [null == (a2 = N.meta) ? void 0 : a2.artist.isUnsafeLegal, R]), (0, b._)(N, C2), (0, l.useEffect)(
          () => () => {
            N.similarArtistsSubPage.reset();
          },
          [N]
        ), N.similarArtistsSubPage.isNotFound && (0, r.notFound)(), (0, A.Jzs)(N.similarArtistsSubPage.isResolved);
        let y = (0, l.useMemo)(() => {
          if (N.similarArtistsSubPage.isResolved) {
            var e3;
            return null == (e3 = N.similarArtistsSubPage.similarArtists) ? void 0 : e3.map((e4) => (0, i.jsx)(p.ao, { className: k().item, artist: e4, contentLinesCount: 3 }, e4.id));
          }
          let t3 = I(
            { id: "loading-messages.entity-is-loading" },
            { entityName: I({ id: "entity-names.similar-artists" }) }
          );
          return (0, i.jsx)(f.eI, {
            isActive: true,
            itemClassName: k().item,
            round: true,
            centered: true,
            "aria-label": t3
          });
        }, [
          N.similarArtistsSubPage.loadingState,
          N.similarArtistsSubPage.similarArtists,
          I,
          null == (s2 = N.similarArtistsSubPage.similarArtists) ? void 0 : s2.length
        ]), w = [];
        return (N.similarArtistsSubPage.isNeededToLoad && w.push(N.similarArtistsSubPage.getData({ artistId: C2, preloadedSimilarArtists: T })), N.isNeededToLoad && w.push(N.getData({ artistId: C2, preloadedArtist: x })), ((e3) => {
          (0, l.useEffect)(() => {
            if (!(null == e3 ? void 0 : e3.meta) || e3.isLoading) return;
            let t3 = (0, h.NE)(e3.meta.artist);
            (0, _.y)({ artist: t3 }, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, A.jxB)(e4);
            });
          }, [null == e3 ? void 0 : e3.meta, null == e3 ? void 0 : e3.isLoading]);
        })(N), w.length && (0, l.use)(Promise.allSettled(w)), null == (S2 = N.meta) ? void 0 : S2.artist.isLegalRejected) ? (0, i.jsx)(f.MW, { modalState: j }) : N.isRejected ? (0, i.jsx)(m.w, {}) : (0, i.jsx)(A.nVz, {
          pageId: A._Q$.ARTIST_SIMILAR,
          pageEntityId: C2,
          children: (0, i.jsx)(g.hO, {
            scrollElement: L,
            outerTitle: I({ id: "page.artist-similar-header" }, { artistName: N.commonSubPage.artistName }),
            children: (0, i.jsxs)("div", {
              className: k().root,
              children: [
                (0, i.jsx)(f.Y9, {
                  variant: f.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: E.canBack,
                  children: (0, i.jsx)(u.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: (0, i.jsx)(n.A, {
                      id: "page.artist-similar-header",
                      values: { artistName: N.commonSubPage.artistName }
                    })
                  })
                }),
                (0, i.jsxs)(d.N, {
                  className: k().scrollableContent,
                  containerClassName: k().container,
                  ref: P,
                  children: [
                    (0, i.jsx)("div", {
                      ...(0, c.Am)(c.Xk.artist.ARTIST_SIMILAR_PAGE),
                      children: (0, i.jsx)("div", {
                        className: k().content,
                        "aria-labelledby": "collection-artists-header",
                        tabIndex: 0,
                        children: y
                      })
                    }),
                    (0, i.jsx)(f.A, { children: (0, i.jsx)(f.wi, { className: k().footer }) })
                  ]
                })
              ]
            })
          })
        });
      });
    },
    8242: (e, t, a) => {
      "use strict";
      a.d(t, { T: () => s });
      var i = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let l = await (0, i.WGy)(t2.locale), o = l({ id: "metadata.artist-albums-title" }, { artistName: e2.artist.name }), n = l({ id: "metadata.artist-albums-description" }, { artistName: e2.artist.name });
        return {
          title: o,
          description: n,
          openGraph: (0, i.i$E)({
            ogTitle: o,
            ogDescription: n,
            ogType: "website",
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            customImage: (0, i.vWM)({ tld: t2.tld }),
            siteName: l({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({ cardType: i.WfF.SUMMARY_LARGE_IMAGE, title: o, description: n }),
          facebook: (0, i.kRl)(),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: l({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/artist/:artistId/albums", t2.tld, { params: { artistId: e2.artist.id } })
        };
      }
    },
    20121: (e, t, a) => {
      "use strict";
      a.d(t, { z: () => s });
      var i = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let l = await (0, i.WGy)(t2.locale), o = (0, i.NsT)(e2.artist.name), n = l({ id: "metadata.artist-title" }, { artistTitle: e2.artist.name }), c = l({ id: "metadata.artist-description" }, { artistTitle: e2.artist.name });
        return {
          title: n,
          description: c,
          openGraph: (0, i.i$E)({
            ogTitle: o,
            ogDescription: c,
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            ogImage: e2.artist.ogImage,
            siteName: l({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: o,
            url: t2.url,
            appName: l({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: l({ id: "metadata.yandex-music" })
          }),
          other: { "music:musician": e2.artist.name },
          alternates: (0, i.SEs)("/artist/:artistId", t2.tld, { params: { artistId: e2.artist.id } })
        };
      }
    },
    21225: (e) => {
      e.exports = {
        root: "ArtistFamiliarPageHeader_root__0Wxyx",
        container: "ArtistFamiliarPageHeader_container__HFQzt",
        title: "ArtistFamiliarPageHeader_title__YpVQg",
        tabs: "ArtistFamiliarPageHeader_tabs__CrnJC",
        tab: "ArtistFamiliarPageHeader_tab__RK4OK",
        tabsShimmer: "ArtistFamiliarPageHeader_tabsShimmer__cbLvV",
        tabShimmer: "ArtistFamiliarPageHeader_tabShimmer__iLiqI",
        staticHeader: "ArtistFamiliarPageHeader_staticHeader__LrzR8",
        important: "ArtistFamiliarPageHeader_important__buc81",
        stickyHeader: "ArtistFamiliarPageHeader_stickyHeader__u7JdF"
      };
    },
    22051: (e) => {
      e.exports = {
        root: "ArtistFamiliarPageContent_root__0Mc9t",
        scrollContainer: "ArtistFamiliarPageContent_scrollContainer__TD6Kj",
        important: "ArtistFamiliarPageContent_important__o2KTP",
        content: "ArtistFamiliarPageContent_content__QquDA",
        block: "ArtistFamiliarPageContent_block__Cr2H_",
        blockHeader: "ArtistFamiliarPageContent_blockHeader__Z_uvq",
        tracksBlock: "ArtistFamiliarPageContent_tracksBlock__SCCLT",
        footer: "ArtistFamiliarPageContent_footer__nveR8",
        item: "ArtistFamiliarPageContent_item__fyC2q",
        shimmerTitle: "ArtistFamiliarPageContent_shimmerTitle__WU3vH"
      };
    },
    23629: (e) => {
      e.exports = {
        root: "ArtistConcertsPage_root__DDTmb",
        scrollableContainer: "ArtistConcertsPage_scrollableContainer__qrAF_",
        container: "ArtistConcertsPage_container__ho6Fw",
        content: "ArtistConcertsPage_content__Ynto2",
        footer: "ArtistConcertsPage_footer__kQL7m"
      };
    },
    25751: (e, t, a) => {
      "use strict";
      a.d(t, { useDownloadedTracks: () => n });
      var i = a(61910), s = a(12460), r = a(8817), l = a(74125);
      let o = [s.DT.IDLE, s.DT.DOWNLOADED], n = (e2) => {
        var t2;
        let a2 = (0, l.jRO)(), n2 = (0, r.c)((t3) => {
          let { state: a3 } = t3;
          o.includes(a3.loadingState) && e2();
        });
        (0, i.useEffect)(() => {
          var t3, i2;
          return null == (t3 = a2.store) || t3.tracks.events.on(s.je.STATE_CHANGED, e2), null == (i2 = a2.store) || i2.tracks.events.on(s.je.ENTITY_CHANGED, n2), () => {
            var t4, i3;
            null == (t4 = a2.store) || t4.tracks.events.off(s.je.STATE_CHANGED, e2), null == (i3 = a2.store) || i3.tracks.events.off(s.je.ENTITY_CHANGED, n2);
          };
        }, [e2, n2, null == (t2 = a2.store) ? void 0 : t2.tracks.events]);
      };
    },
    30697: (e, t, a) => {
      "use strict";
      a.d(t, { t: () => s });
      var i = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let l = await (0, i.WGy)(t2.locale), o = l({ id: "metadata.artist-compilations-title" }, { artistName: e2.artist.name }), n = l({ id: "metadata.artist-compilations-description" }, { artistName: e2.artist.name });
        return {
          title: o,
          description: n,
          openGraph: (0, i.i$E)({
            ogTitle: o,
            ogDescription: n,
            ogType: "website",
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            customImage: (0, i.vWM)({ tld: t2.tld }),
            siteName: l({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({ cardType: i.WfF.SUMMARY_LARGE_IMAGE, title: o, description: n }),
          facebook: (0, i.kRl)(),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: l({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/artist/:artistId/compilations", t2.tld, { params: { artistId: e2.artist.id } })
        };
      }
    },
    35335: (e, t, a) => {
      "use strict";
      a.d(t, { ArtistPage: () => eu });
      var i = a(54486), s = a(28303), r = a(97396), l = a(61910), o = a(43426), n = a(31500), c = a(6024), d = a(8817), u = a(35537), m = a(27510), p = a(56231), g = a(32353), h = a(82644), A = a(33276), f = a(63695), _ = a(74125), b = a(80585), v = a(20121), S = a(82678), k = a(74064), C = a(50420), x = a(63585), T = a(89511), N = a(21365), j = a(44437), I = a.n(j);
      let L = (0, s.PA)((e2) => {
        let { artistId: t2, isWebNextNavigationOn: a2 } = e2, s2 = (0, _.jRO)(), { contentScrollRef: c2, setContentScrollRef: m2 } = (0, _.gKY)(), { formatMessage: p2 } = (0, o.A)(), {
          artist: { offlineArtist: f2 }
        } = (0, _.Pjs)(), { trackIds: v2, downloadedTracks: S2 } = f2, { from: k2 } = (0, _.fyy)({ pageId: _._Q$.ARTIST, blockId: _.UfI.TRACK_LIST }), j2 = (0, _.v8w)(), L2 = (0, _.wZZ)(), { forceUpdateRefCallback: P2, offsetY: E2 } = (0, u.G)(c2), { topColorStyle: R2, headerStyle: y2 } = (0, A.QZ)(null, E2, a2), w2 = (0, d.c)(() => {
          s2.tracksController && v2.ids && S2.getData(s2.tracksController, v2.ids);
        });
        (0, T.L)(w2), (0, l.useEffect)(() => {
          f2.meta && S2.isResolved && S2.items && f2.setTracksCount(S2.items.length);
        }, [f2, f2.meta, S2.isResolved, S2.items]), (0, l.useEffect)(() => {
          S2.isNeededToLoad && v2.isResolved && w2();
        }, [S2.isNeededToLoad, v2.isResolved, w2]), (0, l.useEffect)(
          () => () => {
            f2.reset();
          },
          [f2, t2]
        ), (0, _.Jzs)(f2.isResolved);
        let B2 = (0, l.useMemo)(
          () => f2.isLoading || !f2.meta ? (0, i.jsx)(g.c6, { className: I().header, coverRadius: "round" }) : (0, i.jsx)(g.qi, { className: I().header, artistMeta: f2.meta, entitiesData: S2.entitiesData, ref: P2 }),
          [f2.isLoading, f2.meta, S2.entitiesData, P2]
        ), O2 = (0, l.useMemo)(
          () => ({
            Header: () => B2,
            Footer: () => (0, i.jsx)(b.A, { children: (0, i.jsx)(b.wi, { className: I().footer }) })
          }),
          [B2]
        ), M2 = S2.items ? S2.items.length : 10;
        if (f2.isNeededToLoad && j2) {
          let e3 = [f2.getArtist(t2, j2), v2.getIds(t2, j2)];
          (0, l.use)(Promise.allSettled(e3));
        }
        return (f2.isNotFound && (0, r.notFound)(), f2.isRejected || v2.isRejected || S2.isRejected) ? (0, i.jsx)(h.w, {}) : (0, i.jsx)(_.nVz, {
          pageId: _._Q$.ARTIST,
          pageEntityId: t2,
          children: (0, i.jsxs)(A.hO, {
            scrollElement: c2,
            children: [
              (0, i.jsx)(b.Y9, { style: y2 }),
              (0, i.jsx)("div", { className: I().averageColorBackground, style: R2 }),
              (0, i.jsx)(b.$$, {
                context: { listAriaLabel: p2({ id: "offline.downloaded-track-list" }) },
                className: (0, C.$)(I().root, I().important),
                listClassName: I().content,
                customComponents: O2,
                totalCount: M2,
                itemContentCallback: (e3) => {
                  var t3;
                  let a3 = null == (t3 = S2.items) ? void 0 : t3[e3];
                  return a3 ? (0, i.jsx)(
                    N.Kt,
                    {
                      track: a3,
                      playContextParams: L2(a3.id, {
                        contextData: { type: x.K.Various, meta: { id: _._Q$.ARTIST }, from: k2 },
                        entitiesData: S2.entitiesData,
                        queueParams: { index: e3, entityId: a3.id },
                        loadContextMeta: false
                      })
                    },
                    a3.id
                  ) : (0, i.jsx)(b.DS, { isActive: true, className: I().trackShimmer, variant: _.Xjt.PLAYLIST });
                },
                debounceDurationInMs: 300,
                initialItemCount: M2,
                handleRef: m2,
                shouldTriggerRangeChangedOn: [M2],
                testId: n.Xk.artist.OFFLINE_ARTIST_DOWNLOADED_TRACKS
              })
            ]
          })
        });
      });
      var P = a(97303), E = a.n(P), R = a(22674), y = a(94376), w = a(54830), B = (function(e2) {
        return e2.UPCOMING_RELEASE = "upcoming_release", e2.TRACKS = "tracks", e2.FAMILIAR = "familiar", e2.CONCERTS = "concerts", e2.ARTIST_PICK = "artist_pick", e2;
      })({}), O = a(96990), M = a.n(O);
      let U = (e2) => {
        let { withReleaseBlock: t2, children: a2, isLoading: s2, viewAllActionLink: r2, ...l2 } = e2, { formatMessage: c2 } = (0, o.A)();
        return (0, i.jsxs)("div", {
          className: (0, C.$)(M().popularTracksBlock, { [M().popularTracksBlock_withReleaseBlock]: t2 }),
          ...l2,
          ...(0, n.Am)(n.Xk.artist.POPULAR_TRACKS),
          children: [
            (0, i.jsx)(b.Tw, {
              className: M().popularTracksBlockHeader,
              title: c2({ id: "entity-names.popular-tracks" }),
              viewAllActionLink: r2,
              headingVariant: "h2"
            }),
            (0, i.jsx)(b.L5, {
              isShimmerVisible: s2,
              isShimmerActive: true,
              className: M().popularTracksBlockList,
              variant: _.Xjt.PLAYLIST,
              children: a2
            })
          ]
        });
      }, F = (0, s.PA)((e2) => {
        var t2;
        let { artistId: a2, artist: s2 } = e2, r2 = (0, _.wZZ)(), { from: l2, utmLink: o2 } = (0, _.fyy)({
          pageId: _._Q$.ARTIST,
          blockId: _.UfI.ARTIST,
          pageEntityId: a2,
          contextType: x.K.Artist,
          contextId: a2
        }), n2 = (0, d.c)(
          (e3, t3) => r2(e3, {
            contextData: { type: x.K.Artist, meta: { id: Number(a2) }, from: l2, utmLink: o2 },
            queueParams: { index: t3, entityId: e3 },
            loadContextMeta: true
          })
        );
        return (0, i.jsx)(U, {
          withReleaseBlock: s2.hasReleaseBlock,
          isLoading: s2.isLoading,
          viewAllActionLink: s2.tracksUrl,
          id: B.TRACKS,
          children: null == (t2 = s2.popularTracks) ? void 0 : t2.map((e3, t3) => (0, i.jsx)(N.Kt, { track: e3, playContextParams: n2(e3.id, t3) }, e3.id))
        });
      });
      var D = a(43350), H = a(65779);
      let G = (0, s.PA)((e2) => {
        let { artist: t2 } = e2, { formatMessage: a2 } = (0, o.A)();
        return (0, i.jsx)(_.FoH, {
          mainObjectType: D.ky.Artist,
          mainObjectId: String(t2.id),
          blockId: _.hf$.CLIPS_CAROUSEL,
          blockType: _.hf$.CLIPS_CAROUSEL,
          blockPosX: 1,
          blockPosY: 7,
          objectsCount: t2.clips.length,
          children: (0, i.jsx)(H.KR, {
            containerClassName: M().carouselBlock,
            headerClassName: (0, C.$)(M().carouselBlockHeader, M().carouselBlock),
            isShimmerVisible: t2.isLoading,
            isShimmerActive: true,
            title: a2({ id: "entity-names.clips" }),
            artistIdWithoutLink: String(t2.id),
            viewAllActionLink: t2.clipsUrl,
            clips: t2.clips,
            headingVariant: "h2",
            ...(0, n.Am)(n.Xk.artist.ARTIST_CLIPS_CAROUSEL)
          })
        });
      }), V = (0, s.PA)((e2) => {
        let { artist: t2 } = e2, { formatMessage: a2 } = (0, o.A)();
        return (0, i.jsx)(_.FoH, {
          blockId: _.hf$.COMPILATIONS_CAROUSEL,
          blockType: "albums_carousel",
          blockPosX: 1,
          blockPosY: 5,
          blockIdForFrom: _.hf$.COMPILATIONS_CAROUSEL,
          objectsCount: t2.compilations.length,
          children: (0, i.jsx)(y.pZ, {
            isShimmerVisible: t2.isLoading,
            isShimmerActive: true,
            headerClassName: (0, C.$)(M().carouselBlockHeader, M().carouselBlock),
            containerClassName: M().carouselBlock,
            albums: t2.compilations,
            title: a2({ id: "entity-names.compilations" }),
            viewAllActionLink: t2.compilationsUrl,
            headingVariant: "h2",
            ...(0, n.Am)(n.Xk.artist.COMPILATIONS)
          })
        });
      });
      var $ = a(77217);
      let Y = (0, s.PA)((e2) => {
        var t2, a2, s2;
        let { artistId: r2, artist: l2 } = e2, { formatMessage: n2 } = (0, o.A)();
        return (0, i.jsx)(_.Bki, {
          objectType: D.ky.Shortcut,
          objectId: l2.concertsUrl,
          objectPosX: 0,
          objectPosY: 0,
          objectsCount: null != (s2 = null == (t2 = l2.concerts) ? void 0 : t2.length) ? s2 : 0,
          children: (0, i.jsx)($.BD, {
            id: B.CONCERTS,
            artistId: r2,
            title: n2({ id: "entity-names.concerts" }),
            isLoading: l2.isLoading,
            headerClassName: (0, C.$)(M().carouselBlockHeader, M().carouselBlock),
            containerClassName: M().concertsBlock,
            viewAllActionLink: l2.concertsUrl,
            headingVariant: "h2",
            children: null == (a2 = l2.concerts) ? void 0 : a2.map((e3, t3) => {
              var a3, s3;
              return (0, i.jsx)(
                _.Bki,
                {
                  objectType: D.ky.Concert,
                  objectId: String(e3.id),
                  objectPosX: Math.floor(t3 / 2) + 1,
                  objectPosY: t3 % 2 + 1,
                  objectsCount: null != (s3 = null == (a3 = l2.concerts) ? void 0 : a3.length) ? s3 : 0,
                  children: (0, i.jsx)($.VN, { artistId: r2, concert: e3, meta: (0, i.jsx)($.ZH, {}) })
                },
                e3.id
              );
            })
          })
        });
      }), z = (0, s.PA)((e2) => {
        let { artist: t2 } = e2, { formatMessage: a2 } = (0, o.A)();
        return (0, i.jsx)(_.FoH, {
          blockId: _.hf$.DISCOGRAPHY_CAROUSEL,
          blockType: _.hf$.ALBUMS_CAROUSEL,
          blockPosX: 1,
          blockPosY: 2,
          blockIdForFrom: _.hf$.DISCOGRAPHY_CAROUSEL,
          objectsCount: t2.discography.length,
          children: (0, i.jsx)(y.pZ, {
            isShimmerVisible: t2.isLoading,
            isShimmerActive: true,
            headerClassName: (0, C.$)(M().carouselBlockHeader, M().carouselBlock),
            containerClassName: M().carouselBlock,
            albums: t2.discography,
            title: a2({ id: "entity-names.studio-albums" }),
            viewAllActionLink: t2.discographyUrl,
            headingVariant: "h2",
            ...(0, n.Am)(n.Xk.artist.STUDIO_ALBUMS)
          })
        });
      });
      var W = a(83909);
      let X = (0, s.PA)((e2) => {
        let { artist: t2 } = e2, { formatMessage: a2 } = (0, o.A)();
        return (0, i.jsx)(W.EC, {
          isShimmerVisible: t2.isLoading,
          isShimmerActive: true,
          containerClassName: M().carouselBlock,
          headerClassName: (0, C.$)(M().carouselBlockHeader, M().carouselBlock),
          title: a2({ id: "entity-names.artist-playlist" }),
          playlists: t2.playlists,
          headingVariant: "h2",
          ...(0, n.Am)(n.Xk.artist.ARTIST_PLAYLISTS)
        });
      }), K = (0, s.PA)((e2) => {
        let { artist: t2 } = e2, { formatMessage: a2 } = (0, o.A)();
        return (0, i.jsx)(_.FoH, {
          blockId: _.hf$.ALBUMS_CAROUSEL,
          blockType: _.hf$.ALBUMS_CAROUSEL,
          blockPosX: 1,
          blockPosY: 3,
          blockIdForFrom: _.hf$.ALBUMS_CAROUSEL,
          objectsCount: t2.albums.length,
          children: (0, i.jsx)(y.pZ, {
            isShimmerVisible: t2.isLoading,
            isShimmerActive: true,
            headerClassName: (0, C.$)(M().carouselBlockHeader, M().carouselBlock),
            containerClassName: M().carouselBlock,
            albums: t2.albums,
            title: a2({ id: "entity-names.popular-albums" }),
            viewAllActionLink: t2.albumsUrl,
            headingVariant: "h2",
            ...(0, n.Am)(n.Xk.artist.POPULAR_ALBUMS)
          })
        });
      });
      var Q = a(55616);
      let q = (0, s.PA)((e2) => {
        let { artist: t2 } = e2, { formatMessage: a2 } = (0, o.A)();
        return (0, i.jsx)(b.OY, {
          isShimmerVisible: t2.isLoading,
          isShimmerActive: true,
          headerClassName: (0, C.$)(M().carouselBlockHeader, M().carouselBlock),
          containerClassName: M().carouselBlock,
          title: a2({ id: "entity-names.similar-artists" }),
          viewAllActionLink: t2.similarArtistsUrl,
          headingVariant: "h2",
          ...(0, n.Am)(n.Xk.artist.SIMILAR_ARTISTS),
          children: t2.similarArtists.map((e3) => (0, i.jsx)(Q.ao, { artist: e3, contentLinesCount: 3 }, e3.id))
        });
      });
      var J = a(47713), Z = a(6971), ee = a(39610), et = a(97800), ea = a(41176), ei = a.n(ea);
      let es = (e2) => {
        let {
          artistPick: t2,
          coverContainerClassName: a2,
          artistCoverUrl: s2,
          artistName: r2,
          isArtistAvailable: l2,
          ...o2
        } = e2, { artists: n2, playlist: c2 } = t2;
        return (0, i.jsx)(b.Tw, {
          coverUrl: c2.coverUri,
          viewAllActionLink: c2.url,
          title: c2.title,
          controls: false,
          coverContainerClassName: a2,
          titleLineClamp: 1,
          withDescriptionWidthLimit: false,
          ...o2,
          subTitle: (0, i.jsxs)("div", {
            className: ei().subTitle,
            children: [
              (0, i.jsx)(ee.q, {
                children: (0, i.jsx)(et.Heading, {
                  variant: "h4",
                  children: (0, i.jsx)(J.A, { id: "page.artist-pick-aria-label", values: { artistName: r2 } })
                })
              }),
              (0, i.jsx)(et.Caption, {
                variant: "span",
                size: "l",
                weight: "medium",
                className: ei().text,
                "aria-hidden": true,
                children: (0, i.jsx)(J.A, { id: "page.artist-pick-subtitle" })
              }),
              (0, i.jsx)(Z.Paper, {
                radius: "round",
                className: ei().coverContainer,
                children: (0, i.jsx)(b.BW, {
                  fit: "cover",
                  src: s2,
                  size: 50,
                  className: ei().cover,
                  withAvatarReplace: true,
                  isAvailable: l2,
                  "aria-hidden": true
                })
              }),
              r2 && (0, i.jsx)(et.Caption, {
                variant: "span",
                size: "l",
                weight: "medium",
                className: ei().text,
                lineClamp: 1,
                "aria-hidden": true,
                children: r2
              })
            ]
          }),
          description: (0, i.jsx)(f.iQ, {
            artists: n2,
            linkClassName: ei().artistLink,
            spoilerClassName: ei().artistsSpoiler,
            lineClamp: 1,
            visibleArtistsCount: 3,
            spoilerComponent: (0, i.jsx)(J.A, { id: "entity-names.and-more-artists", values: { artists: "" } })
          })
        });
      }, er = (0, s.PA)((e2) => {
        var t2, a2, s2;
        let { artist: r2, artistId: n2 } = e2, { experiments: c2, user: d2 } = (0, _.Pjs)(), { formatMessage: u2 } = (0, o.A)(), m2 = c2.checkExperiment(_.zal.WebNextArtistPick, "on"), p2 = (0, w.df)(), g2 = r2.hasClips && p2, h2 = d2.isAuthorized && r2.familiarInfo.hasFamiliarInfo, A2 = (0, l.useMemo)(() => {
          let e3 = [];
          return r2.familiarInfo.tracksCount && e3.push(u2({ id: "entity-names.tracks-count" }, { value: r2.familiarInfo.tracksCount })), r2.familiarInfo.collectionAlbumCount && e3.push(u2({ id: "entity-names.albums-count" }, { value: r2.familiarInfo.collectionAlbumCount })), e3.join(" • ");
        }, [r2.familiarInfo.collectionAlbumCount, r2.familiarInfo.tracksCount, u2]), f2 = (0, l.useMemo)(
          () => r2.isLoading ? (0, i.jsxs)("div", {
            className: M().releaseBlock,
            children: [
              (0, i.jsx)(R.Shimmer, { radius: "l", className: M().releaseBlockHeaderShimmer }),
              (0, i.jsx)(b.Vt, { className: (0, C.$)(M().releaseBlockCard, M().important) })
            ]
          }) : r2.upcomingAlbum ? (0, i.jsxs)("div", {
            className: M().releaseBlock,
            id: B.UPCOMING_RELEASE,
            children: [
              (0, i.jsx)(b.Tw, {
                className: M().releaseBlockHeader,
                title: u2({ id: "entity-names.upcoming-album" }),
                headingVariant: "h2"
              }),
              (0, i.jsx)(y.M3, {
                className: (0, C.$)(M().releaseBlockCard, M().important),
                upcomingAlbum: r2.upcomingAlbum
              })
            ]
          }) : r2.lastRelease ? (0, i.jsxs)("div", {
            className: M().releaseBlock,
            children: [
              (0, i.jsx)(b.Tw, {
                className: M().releaseBlockHeader,
                title: u2({ id: "entity-names.recently-release" }),
                headingVariant: "h2"
              }),
              (0, i.jsx)(y.aX, {
                className: (0, C.$)(M().releaseBlockCard, M().important),
                album: r2.lastRelease
              })
            ]
          }) : void 0,
          [r2.isLoading, r2.lastRelease, r2.upcomingAlbum, u2]
        ), v2 = (0, l.useMemo)(() => {
          if (r2.isLoading)
            return (0, i.jsx)("div", {
              className: (0, C.$)(M().carouselBlockHeader, M().carouselBlock, M().panel),
              children: (0, i.jsx)(b.Mo, { coverRadius: "s", isActive: true, withDescription: true })
            });
          if (m2 && r2.artistPick || h2) {
            var e3, t3, a3;
            return (0, i.jsxs)("div", {
              className: (0, C.$)(M().carouselBlockHeader, M().carouselBlock, M().panel),
              children: [
                m2 && r2.artistPick && (0, i.jsx)(es, {
                  id: B.ARTIST_PICK,
                  artistPick: r2.artistPick,
                  isArtistAvailable: !!(null == (e3 = r2.meta) ? void 0 : e3.artist.isAvailable),
                  artistCoverUrl: null == (t3 = r2.meta) ? void 0 : t3.artist.coverUri,
                  coverContainerClassName: (0, C.$)(M().blockCoverContainer, M().important),
                  artistName: null == (a3 = r2.meta) ? void 0 : a3.artist.name,
                  className: M().panelItem
                }),
                h2 && (0, i.jsx)(b.Tw, {
                  id: B.FAMILIAR,
                  coverUrl: "avatars.mds.yandex.net/get-music-misc/2419084/img.65faec7dd0866004f49a38bc/%%",
                  viewAllActionLink: r2.familiarInfo.href(n2),
                  controls: false,
                  title: u2({ id: "page.familiar-you" }),
                  description: A2,
                  coverContainerClassName: (0, C.$)(M().blockCoverContainer, M().important),
                  titleLineClamp: 1,
                  className: M().panelItem,
                  headingVariant: "h2",
                  withDescription: !!A2
                })
              ]
            });
          }
        }, [
          r2.artistPick,
          r2.familiarInfo,
          r2.isLoading,
          null == (t2 = r2.meta) ? void 0 : t2.artist.coverUri,
          null == (a2 = r2.meta) ? void 0 : a2.artist.isAvailable,
          null == (s2 = r2.meta) ? void 0 : s2.artist.name,
          n2,
          A2,
          u2,
          m2,
          h2
        ]);
        return (0, i.jsxs)(i.Fragment, {
          children: [
            (0, i.jsx)("div", {
              className: M().recentsContainer,
              children: (0, i.jsxs)("div", {
                className: M().recents,
                children: [r2.hasPopularTracks && (0, i.jsx)(F, { artist: r2, artistId: n2 }), f2]
              })
            }),
            (0, i.jsxs)("div", {
              className: M().carouselBlocks,
              children: [
                v2,
                r2.hasDiscography && (0, i.jsx)(z, { artist: r2 }),
                r2.hasAlbums && (0, i.jsx)(K, { artist: r2 }),
                r2.hasConcerts && (0, i.jsx)(Y, { artistId: n2, artist: r2 }),
                r2.hasPlaylists && (0, i.jsx)(X, { artist: r2 }),
                r2.hasCompilations && (0, i.jsx)(V, { artist: r2 }),
                r2.hasSimilarArtists && (0, i.jsx)(q, { artist: r2 }),
                g2 && (0, i.jsx)(G, { artist: r2 })
              ]
            })
          ]
        });
      });
      var el = a(4542), eo = a(6098), en = a.n(eo);
      let ec = (0, s.PA)((e2) => {
        let { artist: t2 } = e2;
        return (0, i.jsx)(el.EA, {
          landing: t2.landing,
          errorComponent: (0, i.jsx)(h.w, { className: en().error, withBackwardControl: false }),
          containerClassName: en().root
        });
      }), ed = (0, s.PA)((e2) => {
        var t2, a2, s2, C2, x2, T2;
        let { artistId: N2, preloadedArtist: j2, isWebNextNavigationOn: I2 } = e2, { notify: P2 } = (0, _.lkh)(), {
          artist: R2,
          experiments: y2,
          disclaimerModalState: w2,
          user: B2,
          slam: O2,
          modals: { imageSliderModal: M2 }
        } = (0, _.Pjs)(), { formatMessage: U2 } = (0, o.A)(), F2 = (0, l.useRef)(0), { contentScrollRef: D2, setContentScrollRef: H2 } = (0, _.gKY)(), { forceUpdateRefCallback: G2, offsetY: V2 } = (0, u.G)(D2), $2 = (0, l.useRef)(null), Y2 = (0, _.ytd)(null == R2 || null == (a2 = R2.meta) || null == (t2 = a2.artist) ? void 0 : t2.averageColor), { topColorStyle: z2, headerStyle: W2 } = (0, A.QZ)(Y2, V2, I2), X2 = null == (s2 = R2.meta) ? void 0 : s2.hasCovers, K2 = (0, r.useSearchParams)();
        (0, k.G)(N2), (0, _.ACS)(), (0, l.useEffect)(() => {
          let e3 = K2.get(_.K3F.BLOCK);
          e3 && R2.isResolved && R2.familiarInfo.isResolved && ((e4) => {
            let { blockId: t3, scrollRef: a3, headerRef: i2 } = e4, s3 = document.getElementById(t3);
            if (s3 && a3) {
              var r2;
              let e5 = s3.getBoundingClientRect().top, t4 = (null == (r2 = i2.current) ? void 0 : r2.offsetHeight) ? e5 - i2.current.offsetHeight : e5;
              a3.scrollTo({ top: t4 - 10, behavior: "smooth" });
            }
          })({ blockId: e3, scrollRef: D2, headerRef: $2 });
        }, [R2.isResolved, R2.familiarInfo.isResolved, D2, K2]);
        let Q2 = (0, f.SA)({ artist: null == (C2 = R2.meta) ? void 0 : C2.artist, shouldHistoryBack: true });
        (0, l.useEffect)(() => {
          var e3;
          (null == (e3 = R2.meta) ? void 0 : e3.artist.isUnsafeLegal) && Q2();
        }, [null == (x2 = R2.meta) ? void 0 : x2.artist.isUnsafeLegal, Q2]), (0, S._)(R2, N2), (0, l.useEffect)(
          () => () => {
            B2.isAuthorized && R2.familiarInfo.reset();
          },
          [R2, N2, B2.isAuthorized]
        );
        let q2 = (0, d.c)(() => {
          var e3;
          (null == (e3 = R2.meta) ? void 0 : e3.hasCovers) && R2.meta.covers && M2.openImages({ images: R2.meta.covers });
        });
        if (R2.isCacheNotFound || O2.isOfflineModeEnabled)
          return (0, i.jsx)(L, { artistId: N2, isWebNextNavigationOn: I2 });
        if (R2.deprecationTargetArtistId) {
          let { href: e3 } = (0, _.uvd)("/artist/:artistId", { params: { artistId: R2.deprecationTargetArtistId } });
          (0, r.redirect)(e3);
        }
        (0, l.useMemo)(
          () => () => {
            (R2.isRejected || !R2.meta && !R2.isLoading) && F2 && !(F2.current > 0) && (P2((0, i.jsx)(b.hT, { error: U2({ id: "artist-errors.error-during-loading-artist" }) }), {
              containerId: _.uQT.ERROR
            }), F2.current++);
          },
          [R2.isRejected, R2.meta, R2.isLoading, P2, U2]
        )(), (0, _.Jzs)(R2.isResolved), R2.isNotFound && (0, r.notFound)(), R2.isInfoNotFound && (0, r.notFound)(), ((e3) => {
          (0, l.useEffect)(() => {
            if (!(null == e3 ? void 0 : e3.meta) || e3.isLoading) return;
            let t3 = (0, f.NE)(e3.meta.artist);
            (0, v.z)({ artist: t3 }, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, _.jxB)(e4);
            });
          }, [null == e3 ? void 0 : e3.meta, null == e3 ? void 0 : e3.isLoading]);
        })(R2);
        let J2 = y2.checkExperiment(_.zal.WebNextArtistSkeletonHeader, "on"), Z2 = y2.checkExperiment(_.zal.WebNextArtistSkeleton, "on"), ee2 = !J2 || !Z2, et2 = (0, l.useMemo)(
          () => (J2 ? R2.infoLoadingState.isLoading : R2.isLoading) || !R2.meta ? (0, i.jsx)(g.c6, { className: E().header, coverRadius: "round" }) : (0, i.jsx)(g.qi, {
            className: E().header,
            artistMeta: R2.meta,
            ref: G2,
            onCoverClick: X2 ? q2 : void 0
          }),
          [J2, R2.infoLoadingState.isLoading, R2.isLoading, R2.meta, X2, G2, q2]
        ), ea2 = (0, m.L)(() => Z2 ? (0, i.jsx)(ec, { artist: R2 }) : (0, i.jsx)(er, { artist: R2, artistId: N2 })), ei2 = [];
        return (R2.isNeededToLoad && ee2 && ei2.push(R2.getData({ artistId: N2, preloadedArtist: j2 })), R2.infoLoadingState.isNeededToLoad && J2 && ei2.push(R2.getInfo({ artistId: N2 })), R2.landing.isNeededToLoad && Z2 && ei2.push(R2.landing.getArtistSkeleton({ artistId: N2, skeletonId: c.p.ARTIST }, { preloadBlocksCount: 2 })), B2.isAuthorized && R2.familiarInfo.isNeededToLoad && !Z2 && ei2.push(R2.familiarInfo.getData({ artistId: N2 })), ei2.length && (0, l.use)(Promise.allSettled(ei2)), R2.isSomethingWentWrong || R2.isInfoSomethingWentWrong) ? (0, i.jsx)(h.w, {}) : (null == (T2 = R2.meta) ? void 0 : T2.artist.isLegalRejected) ? (0, i.jsx)(b.MW, { modalState: w2 }) : (0, i.jsx)(_.jPc, {
          children: (0, i.jsxs)(A.hO, {
            scrollElement: D2,
            children: [
              (0, i.jsx)(b.Y9, { style: W2, innerHeaderRef: $2 }),
              (0, i.jsx)("div", { className: E().averageColorBackground, style: z2 }),
              (0, i.jsxs)(p.N, {
                className: E().root,
                containerClassName: E().content,
                ref: H2,
                ...(0, n.Am)(n.Xk.artist.ARTIST_PAGE),
                children: [
                  (0, i.jsxs)("div", { children: [et2, ea2] }),
                  (0, i.jsx)(b.A, { children: (0, i.jsx)(b.wi, { className: E().footer }) })
                ]
              })
            ]
          })
        });
      }), eu = (0, s.PA)(
        (e2) => (0, i.jsx)(_.nVz, { pageId: _._Q$.ARTIST, pageEntityId: e2.artistId, children: (0, i.jsx)(ed, { ...e2 }) })
      );
    },
    35537: (e, t, a) => {
      "use strict";
      a.d(t, { G: () => d });
      var i, s = a(94377), r = a(61910), l = {
        6699: (e2, t2, a2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let i2 = a2(352), s2 = a2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: a3, throttleTimeout: r2 } = e3, l2 = (0, s2.useRef)(null), [o2, n2] = (0, s2.useState)(!!a3), c2 = (0, s2.useMemo)(
              () => (0, i2.throttle)(() => {
                n2(!a3), l2.current && window.clearTimeout(l2.current), l2.current = window.setTimeout(() => {
                  n2(!!a3);
                }, t3);
              }, r2),
              [t3, a3, r2]
            ), d2 = (0, s2.useCallback)(() => {
              n2(!!a3), l2.current && window.clearTimeout(l2.current);
            }, [a3]);
            return (0, s2.useEffect)(
              () => () => {
                l2.current && window.clearTimeout(l2.current);
              },
              []
            ), { state: o2, handleDebouncedToggle: c2, reset: d2 };
          };
        },
        2767: (e2, t2, a2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForceUpdateRef = void 0;
          let i2 = a2(810);
          t2.useForceUpdateRef = () => {
            let [e3, t3] = (0, i2.useState)(null);
            return [
              e3,
              (0, i2.useCallback)((e4) => {
                t3((t4) => t4 !== e4 ? e4 : t4);
              }, [])
            ];
          };
        },
        2067: (e2, t2, a2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useScroll = void 0;
          let i2 = a2(810), s2 = a2(361), r2 = a2(6699);
          t2.useScroll = (e3) => {
            let { onScroll: t3, listenIsScrolling: a3, elementRef: l2 } = e3, { state: o2, handleDebouncedToggle: n2 } = (0, r2.useDebouncedToggle)({
              delay: 1e3,
              throttleTimeout: 100
            }), c2 = (0, i2.useCallback)(() => {
              a3 && n2(), null == t3 || t3();
            }, [a3, n2, t3]);
            return (0, i2.useEffect)(() => {
              let e4 = (0, s2.getElementFromRefOrElement)(l2);
              if (null === e4) return;
              let t4 = null != e4 ? e4 : window, a4 = { capture: true, passive: true };
              return t4.addEventListener("scroll", c2, a4), () => t4.removeEventListener("scroll", c2, a4);
            }, [l2, c2]), o2;
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        352: (e2) => {
          e2.exports = s;
        },
        810: (e2) => {
          e2.exports = i || (i = a.t(r, 2));
        }
      }, o = {};
      function n(e2) {
        var t2 = o[e2];
        if (void 0 !== t2) return t2.exports;
        var a2 = o[e2] = { exports: {} };
        return l[e2](a2, a2.exports, n), a2.exports;
      }
      var c = {};
      (() => {
        Object.defineProperty(c, "__esModule", { value: true }), c.useElementOffsetY = void 0;
        let e2 = n(810), t2 = n(2067), a2 = n(2767);
        c.useElementOffsetY = (i2) => {
          let [s2, r2] = (0, a2.useForceUpdateRef)(), [l2, o2] = (0, e2.useState)(), n2 = (0, e2.useCallback)(() => {
            let e3 = null == s2 ? void 0 : s2.getBoundingClientRect();
            e3 && o2(e3.y);
          }, [s2]);
          return (0, e2.useLayoutEffect)(n2), (0, t2.useScroll)({ onScroll: n2, elementRef: i2 }), { forceUpdateRefCallback: r2, offsetY: l2 };
        };
      })(), c.__esModule;
      var d = c.useElementOffsetY;
    },
    41176: (e) => {
      e.exports = {
        artistLink: "ArtistPick_artistLink__uYvRX",
        artistsSpoiler: "ArtistPick_artistsSpoiler__zP3T5",
        subTitle: "ArtistPick_subTitle__vfdza",
        text: "ArtistPick_text__Oiceb",
        coverContainer: "ArtistPick_coverContainer__epurf",
        cover: "ArtistPick_cover__KGKal"
      };
    },
    42509: (e, t, a) => {
      "use strict";
      a.d(t, { ArtistAlbumsPage: () => j });
      var i = a(54486), s = a(50420), r = a(28303), l = a(97396), o = a(61910), n = a(43426), c = a(31500), d = a(11405), u = a(8817), m = a(97800), p = a(82644), g = a(94376), h = a(55616), A = a(33276), f = a(63695), _ = a(74125), b = a(80585), v = a(8242), S = a(30697), k = a(71284), C = a(82678), x = a(74064), T = a(69635), N = a.n(T);
      let j = (0, r.PA)((e2) => {
        var t2, a2, r2;
        let { artistId: T2, variant: j2, preloadedArtist: I, preloadedAlbums: L } = e2, {
          artist: P,
          disclaimerModalState: E,
          settings: { isMobile: R }
        } = (0, _.Pjs)(), { formatMessage: y } = (0, n.A)(), { contentScrollRef: w, setContentScrollRef: B } = (0, _.gKY)(), O = (0, _.W6M)(), M = P.albumsSubpage.isShimmerVisible ? h.r3 : P.albumsSubpage.items.length, U = (0, u.c)((e3) => {
          P.albumsSubpage.getData({ artistId: T2, page: e3, pageSize: h.r3, sort: { sortBy: d.g.YEAR } });
        });
        (0, _.XcE)(P.albumsSubpage.pagesLoader, U);
        let F = (0, f.SA)({ artist: null == (t2 = P.meta) ? void 0 : t2.artist, shouldHistoryBack: true });
        (0, x.G)(T2), (0, o.useEffect)(() => {
          var e3;
          (null == (e3 = P.meta) ? void 0 : e3.artist.isUnsafeLegal) && F();
        }, [null == (a2 = P.meta) ? void 0 : a2.artist.isUnsafeLegal, F]), (0, C._)(P, T2), (0, o.useEffect)(
          () => () => {
            P.albumsSubpage.reset();
          },
          [P, P.albumsSubpage]
        ), P.albumsSubpage.isNotFound && (0, l.notFound)(), (0, _.Jzs)(P.albumsSubpage.isResolved), ((e3, t3) => {
          (0, o.useEffect)(() => {
            if (!(null == e3 ? void 0 : e3.meta) || e3.isLoading) return;
            let a3 = (0, f.NE)(e3.meta.artist);
            switch (t3) {
              case _.hVl.ALBUMS:
                (0, v.T)({ artist: a3 }, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
                  (0, _.jxB)(e4);
                });
                break;
              case _.hVl.COMPILATIONS:
                (0, S.t)({ artist: a3 }, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
                  (0, _.jxB)(e4);
                });
                break;
              case _.hVl.DISCOGRAPHY:
                (0, k.s)({ artist: a3 }, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
                  (0, _.jxB)(e4);
                });
            }
          }, [null == e3 ? void 0 : e3.meta, null == e3 ? void 0 : e3.isLoading, t3]);
        })(P, j2);
        let D = (0, o.useMemo)(
          () => ({ Footer: () => (0, i.jsx)(b.A, { children: (0, i.jsx)(b.wi, { className: N().footer }) }) }),
          []
        ), H = (0, o.useMemo)(() => {
          switch (j2) {
            case _.hVl.DISCOGRAPHY:
              return y({ id: "page.artist-discography-header" }, { artistName: P.commonSubPage.artistName });
            case _.hVl.COMPILATIONS:
              return y({ id: "page.artist-compilations-header" }, { artistName: P.commonSubPage.artistName });
            default:
              return y({ id: "page.artist-albums-header" }, { artistName: P.commonSubPage.artistName });
          }
        }, [P.commonSubPage.artistName, y, j2]), G = (0, o.useMemo)(() => {
          switch (j2) {
            case _.hVl.DISCOGRAPHY:
              return y({ id: "entity-names.artist-studio-albums-list" });
            case _.hVl.COMPILATIONS:
              return y({ id: "entity-names.artist-compilations-list" });
            default:
              return y({ id: "entity-names.artist-albums-list" });
          }
        }, [y, j2]), V = (0, o.useMemo)(() => {
          switch (j2) {
            case _.hVl.DISCOGRAPHY:
              return _._Q$.ARTIST_DISCOGRAPHY;
            case _.hVl.COMPILATIONS:
              return _._Q$.ARTIST_COMPILATIONS;
            default:
              return _._Q$.ARTIST_ALBUMS;
          }
        }, [j2]), $ = [];
        return (T2 && P.albumsSubpage.isNeededToLoad && (P.albumsSubpage.setVariant(j2), $.push(
          P.albumsSubpage.getData({
            artistId: T2,
            page: 0,
            pageSize: h.r3,
            sort: { sortBy: d.g.YEAR },
            preloadedAlbums: L
          })
        )), T2 && P.isNeededToLoad && $.push(P.getData({ artistId: T2, preloadedArtist: I })), $.length && (0, o.use)(Promise.allSettled($)), null == (r2 = P.meta) ? void 0 : r2.artist.isLegalRejected) ? (0, i.jsx)(b.MW, { modalState: E }) : P.albumsSubpage.isRejected && !P.albumsSubpage.isNotFound ? (0, i.jsx)(p.w, {}) : (0, i.jsx)(_.nVz, {
          pageId: V,
          pageEntityId: T2,
          children: (0, i.jsx)(A.hO, {
            scrollElement: w,
            outerTitle: H,
            children: (0, i.jsxs)("div", {
              className: N().root,
              ...(0, c.Am)(c.Xk.artist.ARTIST_ALBUMS_PAGE),
              children: [
                (0, i.jsx)(b.Y9, {
                  variant: b.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: O.canBack,
                  children: (0, i.jsx)(m.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: H
                  })
                }),
                (0, i.jsx)(b.$$, {
                  className: (0, s.$)(N().scrollContainer, N().important),
                  listClassName: N().content,
                  itemClassName: N().item,
                  customComponents: D,
                  itemContentCallback: (e3) => {
                    let t3 = P.albumsSubpage.items[e3], a3 = y(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: y({ id: "entity-names.playlist" }) }
                    );
                    return t3 ? (0, i.jsx)(g.aX, { album: t3, contentLinesCount: 4 }, t3.id) : (0, i.jsx)(b.Vt, { "aria-label": a3, linesCount: 4 });
                  },
                  totalCount: M,
                  onGetDataByPage: U,
                  pageSize: h.r3,
                  totalRequests: P.albumsSubpage.requestsCount,
                  handleRef: B,
                  context: { listAriaLabel: G },
                  isMobileLayout: R,
                  useWindowScroll: R
                })
              ]
            })
          })
        });
      });
    },
    44034: (e, t, a) => {
      "use strict";
      a.d(t, { Q: () => s });
      var i = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let l = await (0, i.WGy)(t2.locale), o = l({ id: "metadata.artist-familiar-you-title" }, { artistName: e2.artist.name }), n = l({ id: "metadata.artist-familiar-you-description" }, { artistName: e2.artist.name });
        return {
          title: o,
          description: n,
          openGraph: (0, i.i$E)({
            ogTitle: o,
            ogDescription: n,
            ogType: "website",
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            customImage: (0, i.vWM)({ tld: t2.tld }),
            siteName: l({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({ cardType: i.WfF.SUMMARY_LARGE_IMAGE, title: o, description: n }),
          facebook: (0, i.kRl)(),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: l({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/artist/:artistId/familiar", t2.tld, { params: { artistId: e2.artist.id } })
        };
      }
    },
    44437: (e) => {
      e.exports = {
        root: "OfflineArtistPage_root__u1qco",
        important: "OfflineArtistPage_important__Kt9GU",
        header: "OfflineArtistPage_header__PR4N7",
        averageColorBackground: "OfflineArtistPage_averageColorBackground__6WlL4",
        content: "OfflineArtistPage_content__Y71zx",
        footer: "OfflineArtistPage_footer__mB2rh"
      };
    },
    45957: (e, t, a) => {
      "use strict";
      a.d(t, { ArtistNotFoundPage: () => c });
      var i = a(54486), s = a(28303), r = a(61910), l = a(42421), o = a(74125);
      let n = (0, s.PA)(() => {
        let { artist: e2 } = (0, o.Pjs)();
        return (0, o.ACS)(), (0, r.useEffect)(() => {
          e2.reset();
        }, []), (0, i.jsx)(l.M, {});
      }), c = (0, s.PA)(() => (0, i.jsx)(o.nVz, { pageId: o._Q$.PAGE_NOT_FOUND_SCREEN, children: (0, i.jsx)(n, {}) }));
    },
    46310: (e, t, a) => {
      "use strict";
      a.d(t, { E: () => s });
      var i = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let l = await (0, i.WGy)(t2.locale), o = l({ id: "metadata.artist-clips-title" }, { artistName: e2.artist.name }), n = l({ id: "metadata.artist-clips-description" }, { artistName: e2.artist.name });
        return {
          title: o,
          description: n,
          openGraph: (0, i.i$E)({
            ogTitle: o,
            ogDescription: n,
            ogType: "website",
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            customImage: (0, i.vWM)({ tld: t2.tld }),
            siteName: l({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({ cardType: i.WfF.SUMMARY_LARGE_IMAGE, title: o, description: n }),
          facebook: (0, i.kRl)(),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: l({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/artist/:artistId/clips", t2.tld, { params: { artistId: e2.artist.id } })
        };
      }
    },
    50365: (e, t, a) => {
      "use strict";
      a.d(t, { z: () => s });
      var i = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let l = await (0, i.WGy)(t2.locale), o = l({ id: "metadata.artist-tracks-title" }, { artistName: e2.artist.name }), n = l({ id: "metadata.artist-tracks-description" }, { artistName: e2.artist.name });
        return {
          title: o,
          description: n,
          openGraph: (0, i.i$E)({
            ogTitle: o,
            ogDescription: n,
            ogType: "website",
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            customImage: (0, i.vWM)({ tld: t2.tld }),
            siteName: l({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({ cardType: i.WfF.SUMMARY_LARGE_IMAGE, title: o, description: n }),
          facebook: (0, i.kRl)(),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: l({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/artist/:artistId/tracks", t2.tld, { params: { artistId: e2.artist.id } })
        };
      }
    },
    55273: (e, t, a) => {
      "use strict";
      a.d(t, { ArtistTracksPage: () => T });
      var i = a(54486), s = a(50420), r = a(28303), l = a(97396), o = a(61910), n = a(43426), c = a(47713), d = a(31500), u = a(63585), m = a(8817), p = a(97800), g = a(82644), h = a(33276), A = a(21365), f = a(63695), _ = a(74125), b = a(80585), v = a(50365), S = a(82678), k = a(74064), C = a(85395), x = a.n(C);
      let T = (0, r.PA)((e2) => {
        var t2, a2, r2, C2, T2, N;
        let { artistId: j, preloadedArtist: I } = e2, {
          artist: L,
          sonataState: P,
          disclaimerModalState: E,
          settings: { isMobile: R }
        } = (0, _.Pjs)(), { formatMessage: y } = (0, n.A)(), { from: w, utmLink: B } = (0, _.fyy)({
          pageId: _._Q$.ARTIST_TRACKS,
          pageEntityId: j,
          contextType: u.K.Artist,
          contextId: j
        }), { contentScrollRef: O, setContentScrollRef: M } = (0, _.gKY)(), U = (0, _.W6M)(), F = (0, _.wZZ)(), D = (0, f.SA)({ artist: null == (t2 = L.meta) ? void 0 : t2.artist, shouldHistoryBack: true });
        (0, k.G)(j), (0, o.useEffect)(() => {
          var e3;
          (null == (e3 = L.meta) ? void 0 : e3.artist.isUnsafeLegal) && D();
        }, [null == (a2 = L.meta) ? void 0 : a2.artist.isUnsafeLegal, D]), (0, S._)(L, j), (0, o.useEffect)(
          () => () => {
            L.fullTracksListSubpage.reset();
          },
          [L]
        ), L.fullTracksListSubpage.isNotFound && (0, l.notFound)(), (0, _.Jzs)(L.fullTracksListSubpage.isResolved);
        let H = (0, o.useMemo)(
          () => ({ Footer: () => (0, i.jsx)(b.A, { children: (0, i.jsx)(b.wi, { className: x().footer }) }) }),
          []
        ), G = (0, m.c)((e3) => {
          let t3 = [];
          for (let i2 = e3.startIndex; i2 <= e3.endIndex; i2++) {
            var a3;
            let e4 = null == (a3 = L.fullTracksListSubpage.ids) ? void 0 : a3[i2];
            !L.fullTracksListSubpage.getTrackByIndex(i2) && e4 && t3.push(e4);
          }
          t3.length && L.fullTracksListSubpage.getTracks({ trackIds: t3 });
        }), V = [];
        return (L.fullTracksListSubpage.isNeededToLoad && V.push(L.fullTracksListSubpage.getTracksIds({ artistId: j })), L.isNeededToLoad && V.push(L.getData({ artistId: j, preloadedArtist: I })), ((e3) => {
          (0, o.useEffect)(() => {
            if (!(null == e3 ? void 0 : e3.meta) || e3.isLoading) return;
            let t3 = (0, f.NE)(e3.meta.artist);
            (0, v.z)({ artist: t3 }, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, _.jxB)(e4);
            });
          }, [null == e3 ? void 0 : e3.meta, null == e3 ? void 0 : e3.isLoading]);
        })(L), V.length && (0, o.use)(Promise.allSettled(V)), L.fullTracksListSubpage.isRejected && !L.fullTracksListSubpage.isNotFound) ? (0, i.jsx)(g.w, {}) : (null == (r2 = L.meta) ? void 0 : r2.artist.isLegalRejected) ? (0, i.jsx)(b.MW, { modalState: E }) : (0, i.jsx)(_.nVz, {
          pageId: _._Q$.ARTIST_TRACKS,
          pageEntityId: j,
          children: (0, i.jsx)(h.hO, {
            scrollElement: O,
            outerTitle: y({ id: "page.artist-tracks-header" }, { artistName: L.commonSubPage.artistName }),
            children: (0, i.jsxs)("div", {
              className: x().root,
              ...(0, d.Am)(d.Xk.artist.ARTIST_TRACKS_PAGE),
              children: [
                (0, i.jsx)(b.Y9, {
                  variant: b.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: U.canBack,
                  children: (0, i.jsx)(p.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: (0, i.jsx)(c.A, {
                      id: "page.artist-tracks-header",
                      values: { artistName: null == (C2 = L.meta) ? void 0 : C2.artist.name }
                    })
                  })
                }),
                (0, i.jsx)(b.$$, {
                  className: (0, s.$)(x().scrollContainer, x().important),
                  customComponents: H,
                  itemContentCallback: (e3) => {
                    let t3 = L.fullTracksListSubpage.getTrackByIndex(e3), a3 = y(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: y({ id: "search-filters.track" }) }
                    );
                    return t3 ? (0, i.jsx)(A.Kt, {
                      track: t3,
                      playContextParams: F(e3, {
                        contextData: { type: u.K.Artist, meta: { id: Number(j) }, from: w, utmLink: B },
                        queueParams: { index: e3, entityId: t3.id },
                        loadContextMeta: true,
                        entitiesData: P.unloadedEntitiesDataFromModels
                      })
                    }) : (0, i.jsx)(b.DS, {
                      isActive: true,
                      "aria-label": a3,
                      variant: _.Xjt.PLAYLIST,
                      className: x().shimmerItem
                    });
                  },
                  totalCount: null != (N = null == (T2 = L.fullTracksListSubpage.ids) ? void 0 : T2.length) ? N : 0,
                  onGetDataByRange: G,
                  pageSize: 20,
                  listClassName: x().content,
                  itemClassName: x().item,
                  totalRequests: L.fullTracksListSubpage.tracks.size,
                  handleRef: M,
                  context: { listAriaLabel: y({ id: "entity-names.artist-tracks-list" }) },
                  isMobileLayout: R,
                  useWindowScroll: R
                })
              ]
            })
          })
        });
      });
    },
    69635: (e) => {
      e.exports = {
        root: "ArtistAlbumsPage_root__UVZDz",
        scrollContainer: "ArtistAlbumsPage_scrollContainer__2FrjI",
        important: "ArtistAlbumsPage_important__Id_vh",
        footer: "ArtistAlbumsPage_footer__6Nrct",
        item: "ArtistAlbumsPage_item__kiegh",
        content: "ArtistAlbumsPage_content__65D6P"
      };
    },
    70768: (e, t, a) => {
      "use strict";
      a.d(t, { ArtistFamiliarPage: () => X });
      var i = a(54486), s = a(28303), r = a(97396), l = a(61910), o = a(31500), n = a(51321), c = a(82644), d = a(33276), u = a(63695), m = a(74125), p = a(80585), g = a(44034), h = (function(e2) {
        return e2[e2.COLLECTION = 0] = "COLLECTION", e2[e2.VIBE = 1] = "VIBE", e2;
      })({}), A = a(82678), f = a(74064), _ = a(74749), b = a.n(_), v = a(50420), S = a(43426), k = a(29064), C = a(63585), x = a(77710), T = a(56231), N = a(22674), j = a(94376), I = a(21365), L = a(54460);
      let P = (e2) => {
        let { artistId: t2, entityContextType: a2 } = e2;
        return (0, l.useMemo)(
          () => t2 ? (0, L.tW)({ contextType: C.K.Artist, contextId: t2, entityContextType: a2 }) : null,
          [t2, a2]
        );
      };
      var E = a(47713), R = a(97800), y = a(8817);
      let w = (e2) => {
        let t2 = (0, m.XJ9)(), a2 = (0, r.useSearchParams)();
        return (0, y.c)((i2) => {
          var s2;
          let r2 = new URLSearchParams(a2);
          switch (null == (s2 = e2.onTabChange) || s2.call(e2, i2), i2) {
            case h.COLLECTION:
              r2.set(m.K3F.TAB, m.JCK.COLLECTION), t2((0, m.Cvn)(window.location.pathname, r2));
              break;
            case h.VIBE:
              r2.set(m.K3F.TAB, m.JCK.VIBE), t2((0, m.Cvn)(window.location.pathname, r2));
          }
        });
      };
      var B = a(21225), O = a.n(B);
      let M = () => (0, i.jsxs)("div", {
        className: O().tabsShimmer,
        children: [
          (0, i.jsx)(N.Shimmer, { className: O().tabShimmer }),
          (0, i.jsx)(N.Shimmer, { className: O().tabShimmer })
        ]
      }), U = (0, s.PA)((e2) => {
        let { tabsState: t2, tabElementId: a2 } = e2, { artist: s2 } = (0, m.Pjs)(), { formatMessage: r2 } = (0, S.A)(), o2 = (0, m.W6M)(), { isScrolling: n2 } = (0, l.useContext)(p.B9), c2 = w(t2);
        return (0, i.jsxs)("header", {
          className: O().root,
          "aria-hidden": n2,
          children: [
            (0, i.jsxs)("div", {
              className: O().container,
              children: [
                o2.canBack && (0, i.jsx)(p.Lh, {
                  withForwardControl: false,
                  withBackwardControl: o2.canBack,
                  shouldFocusOnMount: !n2
                }),
                (0, i.jsx)(R.Heading, {
                  variant: "h1",
                  weight: "bold",
                  size: "xl",
                  lineClamp: 1,
                  className: O().title,
                  children: (0, i.jsx)(E.A, { id: "page.familiar-you" })
                })
              ]
            }),
            (0, i.jsxs)(p.wI, {
              isShimmerVisible: s2.familiarSubpage.isLoading,
              shimmer: (0, i.jsx)(M, {}),
              className: O().tabs,
              elementId: a2,
              ...t2,
              onTabChange: c2,
              children: [
                (0, i.jsx)(p.oz, {
                  className: O().tab,
                  value: h.COLLECTION,
                  title: r2({ id: "page.familiar-collection" }),
                  "aria-hidden": n2,
                  tabIndex: n2 ? -1 : 0
                }),
                (0, i.jsx)(p.oz, {
                  className: O().tab,
                  value: h.VIBE,
                  title: r2({ id: "page.familiar-vibe" }),
                  "aria-hidden": n2,
                  tabIndex: n2 ? -1 : 0
                })
              ]
            })
          ]
        });
      });
      var F = a(22051), D = a.n(F);
      let H = (0, s.PA)((e2) => {
        var t2;
        let { forwardRef: a2, tabsState: s2, tabElementId: r2, artistId: c2 } = e2, { artist: d2 } = (0, m.Pjs)(), { formatMessage: u2 } = (0, S.A)(), { from: g2 } = (0, m.fyy)(), A2 = P({ artistId: c2, entityContextType: k.h.ARTIST_MY_COLLECTION }), f2 = (0, l.useCallback)(
          (e3, t3) => ({
            contextData: {
              type: C.K.Various,
              meta: { id: String(c2) },
              from: g2,
              overrideAutoflowSeeds: ["artist:".concat(c2)],
              overrideContextType: x.b.Artist
            },
            queueParams: { index: t3 },
            loadContextMeta: false,
            entitiesData: d2.familiarSubpage.collectionEntitiesData
          }),
          [d2.familiarSubpage.collectionEntitiesData, c2, g2]
        ), _2 = (0, l.useMemo)(() => {
          var e3;
          return (0, i.jsx)(p.L5, {
            isShimmerVisible: d2.familiarSubpage.isLoading,
            isShimmerActive: true,
            variant: m.Xjt.PLAYLIST,
            shimmersCount: 10,
            className: (0, v.$)(D().block, D().tracksBlock),
            children: null == (e3 = d2.familiarSubpage.collectionTracks) ? void 0 : e3.map((e4, t3) => (0, i.jsx)(I.Kt, { track: e4, playContextParams: f2(e4, t3) }, e4.id))
          });
        }, [d2.familiarSubpage.collectionTracks, d2.familiarSubpage.isLoading, f2]), b2 = (0, l.useMemo)(() => {
          if (d2.familiarSubpage.shouldShowTitleBlocks)
            return d2.familiarSubpage.isLoading ? (0, i.jsx)("div", {
              className: (0, v.$)(D().block, D().blockHeader),
              children: (0, i.jsx)(N.Shimmer, {
                isActive: d2.familiarSubpage.isLoading,
                className: D().shimmerTitle,
                radius: "l"
              })
            }) : (0, i.jsx)(p.Tw, {
              className: (0, v.$)(D().block, D().blockHeader),
              title: u2({ id: "entity-names.tracks" })
            });
        }, [d2.familiarSubpage.isLoading, d2.familiarSubpage.shouldShowTitleBlocks, u2]), L2 = (0, l.useMemo)(() => {
          if (d2.familiarSubpage.shouldShowTitleBlocks) return u2({ id: "entity-names.albums" });
        }, [d2.familiarSubpage.shouldShowTitleBlocks, u2]);
        return (0, i.jsx)(m._Fn, {
          sourceContextData: A2,
          children: (0, i.jsxs)(T.N, {
            className: D().root,
            containerClassName: (0, v.$)(D().scrollContainer, D().important),
            ref: a2,
            ...(0, o.Am)(o.Xk.familiarYou.FAMILIAR_YOU_SCROLLABLE_CONTENT_COLLECTION),
            children: [
              (0, i.jsx)(U, { tabsState: s2, tabElementId: r2 }),
              (0, i.jsxs)(n.TabPanel, {
                value: s2.value,
                name: h.COLLECTION,
                elementId: r2,
                className: D().content,
                children: [
                  (0, i.jsxs)("section", {
                    ...(0, o.Am)(o.Xk.familiarYou.FAMILIAR_YOU_SECTION_TRACK),
                    children: [b2, _2]
                  }),
                  (0, i.jsx)(p.OY, {
                    isShimmerVisible: d2.familiarSubpage.isLoading,
                    isShimmerActive: true,
                    headerClassName: D().blockHeader,
                    containerClassName: D().block,
                    title: L2,
                    showHeaderShimmer: d2.familiarSubpage.shouldShowTitleBlocks,
                    ...(0, o.Am)(o.Xk.familiarYou.FAMILIAR_YOU_SECTION_ALBUM),
                    children: null == (t2 = d2.familiarSubpage.collectionAlbums) ? void 0 : t2.map((e3) => (0, i.jsx)(j.aX, { album: e3, contentLinesCount: 3 }, e3.id))
                  })
                ]
              }),
              (0, i.jsx)(p.A, { children: (0, i.jsx)(p.wi, { className: D().footer }) })
            ]
          })
        });
      }), G = (0, s.PA)((e2) => {
        let { forwardRef: t2, tabsState: a2, tabElementId: s2, artistId: r2 } = e2, { artist: c2 } = (0, m.Pjs)(), { from: d2 } = (0, m.fyy)(), u2 = P({ artistId: r2, entityContextType: k.h.ARTIST_FAMILIAR_FROM_WAVE }), g2 = (0, l.useCallback)(
          (e3, t3) => ({
            contextData: {
              type: C.K.Various,
              meta: { id: String(r2) },
              from: d2,
              overrideAutoflowSeeds: ["artist:".concat(r2)],
              overrideContextType: x.b.Artist
            },
            queueParams: { index: t3 },
            loadContextMeta: false,
            entitiesData: c2.familiarSubpage.vibeEntitiesData
          }),
          [c2.familiarSubpage.vibeEntitiesData, r2, d2]
        ), A2 = (0, l.useMemo)(() => {
          var e3;
          return (0, i.jsx)(p.L5, {
            isShimmerVisible: c2.familiarSubpage.isLoading,
            isShimmerActive: true,
            variant: m.Xjt.PLAYLIST,
            shimmersCount: 10,
            className: (0, v.$)(D().block, D().tracksBlock),
            children: null == (e3 = c2.familiarSubpage.vibeTracks) ? void 0 : e3.map((e4, t3) => (0, i.jsx)(I.Kt, { track: e4, playContextParams: g2(e4, t3) }, e4.id))
          });
        }, [c2.familiarSubpage.isLoading, c2.familiarSubpage.vibeTracks, g2]);
        return (0, i.jsx)(m._Fn, {
          sourceContextData: u2,
          children: (0, i.jsxs)(T.N, {
            className: D().root,
            containerClassName: (0, v.$)(D().scrollContainer, D().important),
            ref: t2,
            ...(0, o.Am)(o.Xk.familiarYou.FAMILIAR_YOU_SCROLLABLE_CONTENT_VIBE),
            children: [
              (0, i.jsx)(U, { tabsState: a2, tabElementId: s2 }),
              (0, i.jsx)(n.TabPanel, {
                value: a2.value,
                name: h.VIBE,
                elementId: s2,
                className: D().content,
                children: A2
              }),
              (0, i.jsx)(p.A, { children: (0, i.jsx)(p.wi, { className: D().footer }) })
            ]
          })
        });
      });
      var V = a(5956), $ = a(81723), Y = a.n($);
      let z = (e2) => {
        let { tabsState: t2, tabElementId: a2 } = e2, s2 = (0, l.useMemo)(() => {
          switch (t2.value) {
            case h.COLLECTION:
              return (0, i.jsx)(E.A, { id: "error-messages.empty-artist-familiar-collection-title" });
            case h.VIBE:
              return (0, i.jsx)(E.A, { id: "error-messages.empty-artist-familiar-vibe-title" });
          }
        }, [t2.value]);
        return (0, i.jsxs)(i.Fragment, {
          children: [
            (0, i.jsx)(U, { tabsState: t2, tabElementId: a2 }),
            (0, i.jsxs)("div", {
              className: Y().root,
              children: [
                (0, i.jsx)(V.Icon, { className: Y().icon, variant: "attention", size: "xxxl" }),
                (0, i.jsx)(R.Heading, { className: Y().title, variant: "h3", size: "xs", children: s2 })
              ]
            })
          ]
        });
      }, W = (0, s.PA)((e2) => {
        let { tabsState: t2, tabElementId: a2 } = e2, { artist: s2 } = (0, m.Pjs)(), { formatMessage: r2 } = (0, S.A)(), { isScrolling: o2 } = (0, l.useContext)(p.B9), n2 = (0, m.W6M)(), c2 = w(t2);
        return (0, i.jsx)(p.Y9, {
          variant: p.Vw.COMPOSITE,
          staticClassName: (0, v.$)(O().staticHeader, O().important),
          "aria-hidden": !o2,
          stickyClassName: (0, v.$)(O().stickyHeader, O().important),
          stickyChild: (0, i.jsxs)("div", {
            className: O().container,
            children: [
              n2.canBack && (0, i.jsx)(p.Lh, {
                withForwardControl: false,
                withBackwardControl: n2.canBack,
                shouldFocusOnMount: false,
                buttonSize: "xs"
              }),
              (0, i.jsxs)(p.wI, {
                isShimmerVisible: s2.familiarSubpage.isLoading,
                shimmer: (0, i.jsx)(M, {}),
                className: O().tabs,
                elementId: a2,
                onTabChange: c2,
                ...t2,
                children: [
                  (0, i.jsx)(p.oz, {
                    className: O().tab,
                    value: h.COLLECTION,
                    title: r2({ id: "page.familiar-collection" }),
                    "aria-hidden": !o2,
                    tabIndex: o2 ? 0 : -1
                  }),
                  (0, i.jsx)(p.oz, {
                    className: O().tab,
                    value: h.VIBE,
                    title: r2({ id: "page.familiar-vibe" }),
                    "aria-hidden": !o2,
                    tabIndex: o2 ? 0 : -1
                  })
                ]
              })
            ]
          })
        });
      }), X = (0, s.PA)((e2) => {
        var t2, a2, s2;
        let { artistId: _2, preloadedArtist: v2, preloadedFamiliar: S2 } = e2, k2 = (0, r.useSearchParams)(), { artist: C2, disclaimerModalState: x2 } = (0, m.Pjs)(), { contentScrollRef: T2, setContentScrollRef: N2 } = (0, m.gKY)(), j2 = (0, l.useId)(), I2 = (0, l.useMemo)(() => {
          switch (k2.get(m.K3F.TAB)) {
            case m.JCK.COLLECTION:
              break;
            case m.JCK.VIBE:
              return h.VIBE;
          }
          return h.COLLECTION;
        }, [k2]), L2 = (0, n.useTabsState)(I2), P2 = (0, u.SA)({ artist: null == (t2 = C2.meta) ? void 0 : t2.artist, shouldHistoryBack: true });
        (0, f.G)(_2), (0, l.useEffect)(() => {
          var e3;
          (null == (e3 = C2.meta) ? void 0 : e3.artist.isUnsafeLegal) && P2();
        }, [null == (a2 = C2.meta) ? void 0 : a2.artist.isUnsafeLegal, P2]), (0, A._)(C2, _2), (0, l.useEffect)(
          () => () => {
            C2.familiarSubpage.reset();
          },
          [C2]
        ), (0, m.Jzs)(C2.familiarSubpage.isResolved), C2.familiarSubpage.isNotFound && (0, r.notFound)();
        let E2 = (0, l.useMemo)(() => {
          switch (L2.value) {
            case h.COLLECTION:
              if (C2.familiarSubpage.isResolved && !C2.familiarSubpage.hasCollectionEntities)
                return (0, i.jsx)(z, { tabsState: L2, tabElementId: j2 });
              return (0, i.jsx)(H, { tabsState: L2, forwardRef: N2, tabElementId: j2, artistId: _2 });
            case h.VIBE:
              if (C2.familiarSubpage.isResolved && !C2.familiarSubpage.hasVibeTracks)
                return (0, i.jsx)(z, { tabsState: L2, tabElementId: j2 });
              return (0, i.jsx)(G, { tabsState: L2, forwardRef: N2, tabElementId: j2, artistId: _2 });
          }
        }, [
          C2.familiarSubpage.hasCollectionEntities,
          C2.familiarSubpage.hasVibeTracks,
          C2.familiarSubpage.isResolved,
          _2,
          N2,
          j2,
          L2
        ]), R2 = [];
        return (C2.familiarSubpage.isNeededToLoad && R2.push(C2.familiarSubpage.getData({ preloadedFamiliar: S2, artistId: _2 })), C2.isNeededToLoad && R2.push(C2.getData({ artistId: _2, preloadedArtist: v2 })), ((e3) => {
          (0, l.useEffect)(() => {
            if (!(null == e3 ? void 0 : e3.meta) || e3.isLoading) return;
            let t3 = (0, u.NE)(e3.meta.artist);
            (0, g.Q)({ artist: t3 }, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, m.jxB)(e4);
            });
          }, [null == e3 ? void 0 : e3.meta, null == e3 ? void 0 : e3.isLoading]);
        })(C2), R2.length && (0, l.use)(Promise.allSettled(R2)), C2.familiarSubpage.isRejected && !C2.familiarSubpage.isNotFound) ? (0, i.jsx)(c.w, {}) : (null == (s2 = C2.meta) ? void 0 : s2.artist.isLegalRejected) ? (0, i.jsx)(p.MW, { modalState: x2 }) : (0, i.jsx)(m.nVz, {
          pageId: m._Q$.FAMILIAR_YOU,
          pageEntityId: _2,
          children: (0, i.jsx)(d.hO, {
            scrollElement: T2,
            headerThreshold: 148,
            children: (0, i.jsxs)("div", {
              className: b().root,
              ...(0, o.Am)(o.Xk.artist.ARTIST_FAMILIAR_PAGE),
              children: [
                (0, i.jsx)(W, { tabElementId: j2, tabsState: L2 }),
                (0, i.jsx)(m.FoH, { blockIdForFrom: m.UfI.DEFAULT, children: E2 })
              ]
            })
          })
        });
      });
    },
    71284: (e, t, a) => {
      "use strict";
      a.d(t, { s: () => s });
      var i = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let l = await (0, i.WGy)(t2.locale), o = l({ id: "metadata.artist-discography-title" }, { artistName: e2.artist.name }), n = l({ id: "metadata.artist-discography-description" }, { artistName: e2.artist.name });
        return {
          title: o,
          description: n,
          openGraph: (0, i.i$E)({
            ogTitle: o,
            ogDescription: n,
            ogType: "website",
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            customImage: (0, i.vWM)({ tld: t2.tld }),
            siteName: l({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({ cardType: i.WfF.SUMMARY_LARGE_IMAGE, title: o, description: n }),
          facebook: (0, i.kRl)(),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: l({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/artist/:artistId/discography", t2.tld, { params: { artistId: e2.artist.id } })
        };
      }
    },
    74064: (e, t, a) => {
      "use strict";
      a.d(t, { G: () => r });
      var i = a(61910), s = a(74125);
      let r = (e2) => {
        var t2;
        let { setDeeplink: a2 } = null != (t2 = (0, s.P7Q)()) ? t2 : {};
        (0, i.useEffect)(() => {
          if (e2) {
            let { href: t3 } = (0, s.uvd)("/artist/:artistId", { params: { artistId: e2 } });
            null == a2 || a2(t3);
          }
          return () => {
            null == a2 || a2(null);
          };
        }, [e2, a2]);
      };
    },
    74749: (e) => {
      e.exports = { root: "ArtistFamiliarPage_root__9Zjo0" };
    },
    79190: (e, t, a) => {
      "use strict";
      a.d(t, { U: () => s });
      var i = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {} };
        let l = await (0, i.WGy)(t2.locale), o = l({ id: "metadata.artist-concerts-title" }, { artistName: e2.artist.name }), n = l({ id: "metadata.artist-concerts-description" }, { artistName: e2.artist.name });
        return {
          title: o,
          description: n,
          openGraph: (0, i.i$E)({
            ogTitle: o,
            ogDescription: n,
            ogType: "website",
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            customImage: (0, i.vWM)({ tld: t2.tld }),
            siteName: l({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({ cardType: i.WfF.SUMMARY_LARGE_IMAGE, title: o, description: n }),
          facebook: (0, i.kRl)(),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: l({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/artist/:artistId/concerts", t2.tld, { params: { artistId: e2.artist.id } })
        };
      }
    },
    79929: (e) => {
      e.exports = {
        root: "ArtistClipsPage_root__3efVS",
        scrollContainer: "ArtistClipsPage_scrollContainer___2pJZ",
        important: "ArtistClipsPage_important__UBPcN",
        footer: "ArtistClipsPage_footer__mhu_A",
        item: "ArtistClipsPage_item__fonRp",
        content: "ArtistClipsPage_content__GFs51"
      };
    },
    81723: (e) => {
      e.exports = {
        root: "ArtistFamiliarPageEmpty_root__s5xX9",
        icon: "ArtistFamiliarPageEmpty_icon__b7kR5",
        title: "ArtistFamiliarPageEmpty_title__wvBGS"
      };
    },
    82678: (e, t, a) => {
      "use strict";
      a.d(t, { _: () => s });
      var i = a(61910);
      let s = (e2, t2) => {
        (0, i.useEffect)(
          () => () => {
            window.location.pathname.includes(e2.selfLink) || e2.reset();
          },
          [e2, t2]
        );
      };
    },
    85395: (e) => {
      e.exports = {
        root: "ArtistTracksPage_root__ad3rI",
        footer: "ArtistTracksPage_footer__KN2i_",
        scrollContainer: "ArtistTracksPage_scrollContainer__9iO2g",
        important: "ArtistTracksPage_important__iulth",
        content: "ArtistTracksPage_content__6LJJd",
        shimmerItem: "ArtistTracksPage_shimmerItem__136_r"
      };
    },
    89071: (e, t, a) => {
      "use strict";
      a.d(t, { ArtistClipsPage: () => T });
      var i = a(54486), s = a(50420), r = a(28303), l = a(97396), o = a(61910), n = a(43426), c = a(31500), d = a(8817), u = a(97800), m = a(82644), p = a(55616), g = a(65779), h = a(33276), A = a(63695), f = a(54830), _ = a(74125), b = a(80585), v = a(46310), S = a(82678), k = a(74064), C = a(79929), x = a.n(C);
      let T = (0, r.PA)((e2) => {
        var t2, a2;
        let { artistId: r2, preloadedArtist: C2, preloadedClips: T2 } = e2, {
          artist: N,
          disclaimerModalState: j,
          settings: { isMobile: I }
        } = (0, _.Pjs)(), { formatMessage: L } = (0, n.A)(), { contentScrollRef: P, setContentScrollRef: E } = (0, _.gKY)(), R = (0, _.W6M)(), y = (0, f.df)();
        (0, A.SA)({ artist: null == (t2 = N.meta) ? void 0 : t2.artist, shouldHistoryBack: true });
        let w = (0, d.c)((e3) => {
          N.clipsSubpage.getData({ artistId: r2, page: e3, pageSize: p.EV });
        });
        (0, _.XcE)(N.clipsSubpage.pagesLoader, w), (0, k.G)(r2), (0, S._)(N, r2), (0, o.useEffect)(
          () => () => {
            N.clipsSubpage.reset();
          },
          [N, N.clipsSubpage]
        ), (0, _.Jzs)(N.clipsSubpage.isResolved), ((e3) => {
          (0, o.useEffect)(() => {
            if (!(null == e3 ? void 0 : e3.meta) || e3.isLoading) return;
            let t3 = (0, A.NE)(e3.meta.artist);
            (0, v.E)({ artist: t3 }, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e4) => {
              (0, _.jxB)(e4);
            });
          }, [null == e3 ? void 0 : e3.meta, null == e3 ? void 0 : e3.isLoading]);
        })(N);
        let B = N.clipsSubpage.isShimmerVisible ? 20 : N.clipsSubpage.items.length, O = (0, o.useMemo)(
          () => ({ Footer: () => (0, i.jsx)(b.A, { children: (0, i.jsx)(b.wi, { className: x().footer }) }) }),
          []
        ), M = (0, o.useMemo)(
          () => L({ id: "page.artist-clips-header" }, { artistName: N.commonSubPage.artistName }),
          [N.commonSubPage.artistName, L]
        ), U = [];
        return (N.clipsSubpage.isNeededToLoad && U.push(N.clipsSubpage.getData({ artistId: r2, page: 0, pageSize: p.EV, preloadedClips: T2 })), N.isNeededToLoad && U.push(N.getData({ artistId: r2, preloadedArtist: C2 })), U.length && (0, o.use)(Promise.allSettled(U)), (N.clipsSubpage.isNotFound || !y) && (0, l.notFound)(), null == (a2 = N.meta) ? void 0 : a2.artist.isLegalRejected) ? (0, i.jsx)(b.MW, { modalState: j }) : N.clipsSubpage.isRejected ? (0, i.jsx)(m.w, {}) : (0, i.jsx)(_.nVz, {
          pageId: _._Q$.ARTIST_CLIPS,
          pageEntityId: r2,
          children: (0, i.jsx)(h.hO, {
            scrollElement: P,
            outerTitle: M,
            children: (0, i.jsxs)("div", {
              className: x().root,
              ...(0, c.Am)(c.Xk.artist.ARTIST_CLIPS_PAGE),
              children: [
                (0, i.jsx)(b.Y9, {
                  variant: b.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: R.canBack,
                  children: (0, i.jsx)(u.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: M
                  })
                }),
                (0, i.jsx)(b.$$, {
                  className: (0, s.$)(x().scrollContainer, x().important),
                  listClassName: x().content,
                  itemClassName: x().item,
                  customComponents: O,
                  itemContentCallback: (e3) => {
                    let t3 = N.clipsSubpage.items[e3];
                    return t3 ? (0, i.jsx)(g.FC, { clip: t3 }, t3.clipId) : (0, i.jsx)(g.kV, { isActive: true });
                  },
                  totalCount: B,
                  onGetDataByPage: w,
                  pageSize: p.EV,
                  totalRequests: N.clipsSubpage.requestsCount,
                  handleRef: E,
                  context: { listAriaLabel: L({ id: "entity-names.artist-clips-list" }) },
                  isMobileLayout: I,
                  useWindowScroll: I
                })
              ]
            })
          })
        });
      });
    },
    89511: (e, t, a) => {
      "use strict";
      a.d(t, { b: () => c, L: () => i.useDownloadedTracks });
      var i = a(25751), s = a(93064), r = a(5693), l = a(21365), o = a(74125), n = a(26433);
      let c = s.gK.compose(
        s.gK.model("DownloadedTracks", {
          items: s.gK.maybeNull(s.gK.array(l.vj)),
          tracks: s.gK.maybeNull(s.gK.frozen())
        }),
        n.XT
      ).views((e2) => ({
        get tracksDurationInMinutes() {
          var t2, a2;
          return (null != (a2 = null == (t2 = e2.tracks) ? void 0 : t2.reduce((e3, t3) => t3.durationMs ? e3 + t3.durationMs : e3, 0)) ? a2 : 0) / 1e3 / 60;
        },
        get entitiesData() {
          if (!e2.tracks) return [];
          return e2.tracks.map((e3) => ({ type: r.R.DownloadedMusic, meta: e3 }));
        },
        get isEmpty() {
          var i2;
          return e2.isResolved && (null == (i2 = e2.items) ? void 0 : i2.length) === 0;
        }
      })).actions((e2) => ({
        getData: (0, s.L3)(function* (t2, a2) {
          let { modelActionsLogger: i2 } = (0, s._$)(e2);
          if (e2.loadingState !== o.GuX.PENDING)
            try {
              e2.loadingState = o.GuX.PENDING;
              let i3 = yield t2.getTracks(a2);
              e2.tracks = i3, e2.items = (0, s.wg)(i3.map((e3) => (0, l.vU)(e3))), e2.loadingState !== o.GuX.IDLE && (e2.loadingState = o.GuX.RESOLVE);
            } catch (t3) {
              i2.error(t3), e2.loadingState !== o.GuX.IDLE && (e2.loadingState = o.GuX.REJECT);
            }
        }),
        reset() {
          e2.items = null, e2.tracks = null, e2.loadingState = o.GuX.IDLE;
        }
      }));
    },
    91280: (e, t, a) => {
      "use strict";
      a.d(t, { y: () => s });
      var i = a(74125);
      async function s(e2, t2) {
        var a2, s2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let l = await (0, i.WGy)(t2.locale), o = l({ id: "metadata.artist-similar-title" }, { artistName: e2.artist.name }), n = l({ id: "metadata.artist-similar-description" }, { artistName: e2.artist.name });
        return {
          title: o,
          description: n,
          openGraph: (0, i.i$E)({
            ogTitle: o,
            ogDescription: n,
            ogType: "website",
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            customImage: (0, i.vWM)({ tld: t2.tld }),
            siteName: l({ id: "metadata.yandex-music" })
          }),
          twitter: (0, i.HRN)({ cardType: i.WfF.SUMMARY_LARGE_IMAGE, title: o, description: n }),
          facebook: (0, i.kRl)(),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (s2 = t2.url) ? s2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: l({ id: "metadata.yandex-music" })
          }),
          alternates: (0, i.SEs)("/artist/:artistId/similar", t2.tld, { params: { artistId: e2.artist.id } })
        };
      }
    },
    96990: (e) => {
      e.exports = {
        panel: "ArtistPageContent_panel__pT_94",
        panelItem: "ArtistPageContent_panelItem__AfA_r",
        blockCoverContainer: "ArtistPageContent_blockCoverContainer__LDl_I",
        important: "ArtistPageContent_important__tPJqk",
        recentsContainer: "ArtistPageContent_recentsContainer__iw_AC",
        recents: "ArtistPageContent_recents__TkT7y",
        popularTracksBlock: "ArtistPageContent_popularTracksBlock__M19rf",
        popularTracksBlock_withReleaseBlock: "ArtistPageContent_popularTracksBlock_withReleaseBlock__S1eO_",
        carouselBlockHeader: "ArtistPageContent_carouselBlockHeader__LO9is",
        popularTracksBlockHeader: "ArtistPageContent_popularTracksBlockHeader__yE3Z8",
        releaseBlockHeader: "ArtistPageContent_releaseBlockHeader__OSBh1",
        releaseBlockHeaderShimmer: "ArtistPageContent_releaseBlockHeaderShimmer__07Uep",
        popularTracksBlockList: "ArtistPageContent_popularTracksBlockList__z02_G",
        releaseBlock: "ArtistPageContent_releaseBlock__dmcUs",
        releaseBlockCard: "ArtistPageContent_releaseBlockCard__GeAp7",
        concertsBlock: "ArtistPageContent_concertsBlock__o_vhY",
        carouselBlock: "ArtistPageContent_carouselBlock__21pOp",
        carouselBlocks: "ArtistPageContent_carouselBlocks__f1w09"
      };
    },
    97303: (e) => {
      e.exports = {
        root: "ArtistPage_root__QPg3p",
        averageColorBackground: "ArtistPage_averageColorBackground__wXTSY",
        header: "ArtistPage_header__tQnNe",
        content: "ArtistPage_content__iZHVN",
        footer: "ArtistPage_footer__8m6P9"
      };
    }
  }
]);
