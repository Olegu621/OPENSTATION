"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [558],
  {
    24269: (e, t, i) => {
      i.d(t, { y: () => a });
      var n = i(6493), r = i(71942), o = (function(e2) {
        return e2.WEB = "YandexMusicWebNext", e2.DESKTOP = "YandexMusicDesktopApp", e2;
      })({});
      let a = () => "".concat(o.DESKTOP).concat((0, r.t)((0, n.u)()));
    },
    34720: (e, t, i) => {
      i.d(t, { c: () => a });
      var n = i(96559), r = i(77220), o = i(53676);
      class a extends r.X {
        async progressSync(e2, t2) {
          return (await this.httpClient.post(
            "streams/progress/sync",
            this.createHttpOptions({
              timeoutKey: "progressSync",
              params: e2,
              json: { lastSyncTimestamp: e2.lastSyncTimestamp, trackStreams: e2.trackStreams },
              signal: null == t2 ? void 0 : t2.signal
            })
          )).json();
        }
        async markAlbumFinished(e2, t2) {
          return (await this.httpClient.post(
            "streams/progress/mark-album-finished",
            this.createHttpOptions({
              timeoutKey: "markAlbumFinished",
              params: e2,
              searchParams: (0, o.P)({ albumId: e2.albumId }),
              signal: null == t2 ? void 0 : t2.signal
            })
          )).json();
        }
        async markAlbumUnfinished(e2, t2) {
          return (await this.httpClient.post(
            "streams/progress/mark-album-unfinished",
            this.createHttpOptions({
              timeoutKey: "markAlbumUnfinished",
              params: e2,
              searchParams: (0, o.P)({ albumId: e2.albumId }),
              signal: null == t2 ? void 0 : t2.signal
            })
          )).json();
        }
        async markFinished(e2, t2) {
          return (await this.httpClient.post(
            "streams/progress/mark-finished",
            this.createHttpOptions({
              timeoutKey: "markFinished",
              params: e2,
              searchParams: (0, o.P)({ trackId: e2.trackId }),
              signal: null == t2 ? void 0 : t2.signal
            })
          )).json();
        }
        async markUnfinished(e2, t2) {
          return (await this.httpClient.post(
            "streams/progress/mark-unfinished",
            this.createHttpOptions({
              timeoutKey: "markUnfinished",
              params: e2,
              searchParams: (0, o.P)({ trackId: e2.trackId }),
              signal: null == t2 ? void 0 : t2.signal
            })
          )).json();
        }
        async progressSaveCurrent(e2, t2) {
          return (await this.httpClient.post(
            "streams/progress/save-current",
            this.createHttpOptions({
              timeoutKey: "progressSaveCurrent",
              params: e2,
              searchParams: (0, o.P)({
                trackId: e2.trackId,
                positionSec: e2.positionSec,
                trackLengthSec: e2.trackLengthSec,
                finished: e2.finished,
                timestamp: e2.timestamp
              }),
              signal: null == t2 ? void 0 : t2.signal
            })
          )).json();
        }
        constructor(e2, t2) {
          super(e2, t2), (0, n._)(this, "httpClient", void 0), (0, n._)(this, "config", void 0), this.httpClient = e2, this.config = t2;
        }
      }
    },
    65630: (e, t, i) => {
      i.d(t, { _: () => o });
      var n = i(37538), r = i(24269);
      let o = () => {
        let e2, t2 = (0, n.H)() || "1.0.0";
        return e2 = (0, r.y)(), "".concat(e2, "/").concat(t2);
      };
    },
    74338: (e, t, i) => {
      i.d(t, {
        bq: () => f,
        O5: () => p,
        p$: () => n,
        Jd: () => ei,
        yi: () => h,
        oh: () => y,
        $P: () => b,
        ot: () => d,
        F4: () => R,
        fD: () => _
      }), (function(e2) {
        e2.UPDATED = "UPDATED", e2.PARSING_ERROR = "PARSING_ERROR";
      })(n || (n = {}));
      var n, r, o, a, s, l, c, u, p = 1, f = {
        UNSPECIFIED: "UNSPECIFIED",
        WEB: "WEB",
        ANDROID: "ANDROID",
        IOS: "IOS",
        SMART_SPEAKER: "SMART_SPEAKER",
        WEB_TV: "WEB_TV",
        ANDROID_TV: "ANDROID_TV",
        APPLE_TV: "APPLE_TV",
        ANDROID_WEAR: "ANDROID_WEAR",
        WEB_DESKTOP: "WEB_DESKTOP"
      }, d = { UNSPECIFIED: "UNSPECIFIED", NONE: "NONE", ONE: "ONE", ALL: "ALL" }, v = { DO_NOT_INTERCEPT_BY_DEFAULT: "DO_NOT_INTERCEPT_BY_DEFAULT", INTERCEPT_EAGER: "INTERCEPT_EAGER" }, h = {
        UNSPECIFIED: "UNSPECIFIED",
        TRACK: "TRACK",
        LOCAL_TRACK: "LOCAL_TRACK",
        INFINITE: "INFINITE",
        VIDEO_CLIP: "VIDEO_CLIP"
      }, y = {
        BASED_ON_ENTITY_BY_DEFAULT: "BASED_ON_ENTITY_BY_DEFAULT",
        USER_TRACKS: "USER_TRACKS",
        DOWNLOADED_TRACKS: "DOWNLOADED_TRACKS",
        SEARCH: "SEARCH",
        MUSIC_HISTORY: "MUSIC_HISTORY",
        MUSIC_HISTORY_SEARCH: "MUSIC_HISTORY_SEARCH",
        ARTIST_MY_COLLECTION: "ARTIST_MY_COLLECTION",
        ARTIST_FAMILIAR_FROM_WAVE: "ARTIST_FAMILIAR_FROM_WAVE"
      }, b = {
        UNSPECIFIED: "UNSPECIFIED",
        ARTIST: "ARTIST",
        PLAYLIST: "PLAYLIST",
        ALBUM: "ALBUM",
        RADIO: "RADIO",
        VARIOUS: "VARIOUS",
        GENERATIVE: "GENERATIVE",
        FM_RADIO: "FM_RADIO",
        VIDEO_WAVE: "VIDEO_WAVE",
        LOCAL_TRACKS: "LOCAL_TRACKS"
      }, _ = function(e2, t2) {
        return {
          device_id: e2,
          version: Math.floor(9223372036854776e3 * Math.random()) + 0,
          timestamp_ms: void 0 !== t2 ? t2 : Date.now()
        };
      };
      function m(e2) {
        return JSON.parse(JSON.stringify(e2));
      }
      function g(e2) {
        return e2 instanceof Error ? { name: e2.name, message: e2.message, stack: e2.stack, cause: e2.cause } : { data: e2 };
      }
      var O = i(9123), C = /* @__PURE__ */ (function() {
        var e2 = function(t2, i2) {
          return (e2 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e3, t3) {
            e3.__proto__ = t3;
          } || function(e3, t3) {
            for (var i3 in t3) Object.prototype.hasOwnProperty.call(t3, i3) && (e3[i3] = t3[i3]);
          })(t2, i2);
        };
        return function(t2, i2) {
          if ("function" != typeof i2 && null !== i2)
            throw TypeError("Class extends value " + String(i2) + " is not a constructor or null");
          function n2() {
            this.constructor = t2;
          }
          e2(t2, i2), t2.prototype = null === i2 ? Object.create(i2) : (n2.prototype = i2.prototype, new n2());
        };
      })(), S = (function(e2) {
        function t2() {
          return null !== e2 && e2.apply(this, arguments) || this;
        }
        return C(t2, e2), Object.defineProperty(t2.prototype, "on", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3, i2, n2) {
            return e2.prototype.on.call(this, t3, i2, n2), this;
          }
        }), Object.defineProperty(t2.prototype, "once", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3, i2, n2) {
            return e2.prototype.once.call(this, t3, i2, n2), this;
          }
        }), Object.defineProperty(t2.prototype, "emit", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3, i2, n2) {
            return e2.prototype.emit.call(this, t3, i2, n2), this;
          }
        }), Object.defineProperty(t2.prototype, "off", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3, i2) {
            return e2.prototype.off.call(this, t3, i2), this;
          }
        }), t2;
      })(O.TinyEmitter);
      function E(e2) {
        var t2 = _(e2, 0);
        return {
          player_state: {
            player_queue: {
              current_playable_index: -1,
              entity_id: "",
              entity_type: b.VARIOUS,
              playable_list: [],
              options: { repeat_mode: d.NONE },
              shuffle_optional: null,
              entity_context: y.BASED_ON_ENTITY_BY_DEFAULT,
              version: t2,
              from_optional: "",
              initial_entity_optional: null,
              adding_options_optional: null,
              queue: null
            },
            status: { duration_ms: 0, paused: true, playback_speed: 1, progress_ms: 0, version: t2 },
            player_queue_inject_optional: null
          },
          devices: [],
          active_device_id_optional: ""
        };
      }
      var R = function(e2, t2) {
        return Number((Math.round(e2 * t2) / t2).toFixed(4));
      }, P = i(56258);
      function w(e2, t2, i2) {
        return void 0 === e2 && (e2 = false), !!e2 || !t2 || !i2 || Number(t2.timestamp_ms) < Number(i2.timestamp_ms);
      }
      var N = function() {
        return (N = Object.assign || function(e2) {
          for (var t2, i2 = 1, n2 = arguments.length; i2 < n2; i2++)
            for (var r2 in t2 = arguments[i2]) Object.prototype.hasOwnProperty.call(t2, r2) && (e2[r2] = t2[r2]);
          return e2;
        }).apply(this, arguments);
      }, T = (function() {
        function e2(e3) {
          Object.defineProperty(this, "state", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "prevState", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "diff", { enumerable: true, configurable: true, writable: true, value: {} }), Object.defineProperty(this, "options", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "diffCalculators", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "lastActiveRemoteControllerDevice", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "onlineRemoteControllerDevice", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "emitter", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new S()
          }), this.options = e3, this.state = E(e3.deviceConfig.info.device_id), this.prevState = E(e3.deviceConfig.info.device_id), this.diffCalculators = {
            active_device_id_optional: this.calculateActiveDeviceDiff.bind(this),
            devices: this.calculateDevicesDiff.bind(this),
            player_state: {
              player_queue: {
                entity_id: this.calculateEntityIdDiff.bind(this),
                entity_type: this.calculateEntityTypeDiff.bind(this),
                entity_context: function() {
                },
                current_playable_index: this.calculateCurrentPlayableIndexDiff.bind(this),
                playable_list: this.calculatePlayableListDiff.bind(this),
                options: { repeat_mode: this.calculateRepeatDiff.bind(this) },
                version: function() {
                },
                shuffle_optional: this.calculateShuffleDiff.bind(this),
                from_optional: function() {
                },
                initial_entity_optional: function() {
                },
                adding_options_optional: function() {
                },
                queue: function() {
                }
              },
              status: {
                progress_ms: this.calculateProgressMsDiff.bind(this),
                duration_ms: function() {
                },
                paused: this.calculatePausedDiff.bind(this),
                playback_speed: this.calculateSpeedDiff.bind(this),
                version: function() {
                }
              },
              player_queue_inject_optional: function() {
              }
            }
          };
        }
        return Object.defineProperty(e2.prototype, "on", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2, i2) {
            var n2 = this, r2 = function(e4, i3) {
              this.trigger && this.trigger === (null == i3 ? void 0 : i3.trigger) || t2(e4);
            };
            return this.emitter.on(e3, r2, { trigger: i2 }), function() {
              n2.emitter.off(e3, r2);
            };
          }
        }), Object.defineProperty(e2.prototype, "currentState", {
          get: function() {
            return m(this.state);
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e2.prototype, "remoteControllerDevice", {
          get: function() {
            return this.lastActiveRemoteControllerDevice || this.onlineRemoteControllerDevice;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e2.prototype, "fullState", {
          get: function() {
            return m({
              state: this.state,
              prevState: this.prevState,
              diff: this.diff,
              remoteControllerDevice: this.remoteControllerDevice
            });
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e2.prototype, "updateState", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = this, i2 = [this.diffCalculators];
            this.diff = {};
            try {
              for (var r2 = e3.isSetNewState; i2.length > 0; )
                for (var o2 = i2.pop(), a2 = 0, s2 = Object.keys(o2); a2 < s2.length; a2++) {
                  var l2 = o2[s2[a2]];
                  "function" == typeof l2 ? l2(e3) : i2.push(l2);
                }
              var c2 = Object.keys(this.diff);
              if ((void 0 === r2 || r2) && c2.length) {
                var u2 = m(this.state);
                c2.forEach(function(i3) {
                  (i3 in e3.newState || i3 in t2.state) && (u2[i3] = e3.newState[i3]);
                }), this.prevState = m(this.state), this.state = u2;
              }
              this.updateLastRemoteControllerDevice();
              var p2 = N(N({}, this.fullState), { options: e3 });
              this.emitter.emit(n.UPDATED, p2, { trigger: e3.trigger });
            } catch (e4) {
              var f2 = new P.t("YnisonStateController. Parsing error", { cause: g(e4) });
              this.emitter.emit(n.PARSING_ERROR, f2);
              return;
            }
          }
        }), Object.defineProperty(e2.prototype, "calculateActiveDeviceDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.newState.active_device_id_optional;
            t2 !== this.state.active_device_id_optional && (this.diff.active_device_id_optional = t2);
          }
        }), Object.defineProperty(e2.prototype, "calculateDevicesDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = this, i2 = e3.newState, n2 = e3.skipVersionCompare, r2 = this.state.devices.find(function(e4) {
              var i3;
              return (null == (i3 = e4.info) ? void 0 : i3.device_id) === t2.options.deviceConfig.info.device_id;
            }), o2 = i2.devices.find(function(e4) {
              var i3;
              return (null == (i3 = e4.info) ? void 0 : i3.device_id) === t2.options.deviceConfig.info.device_id;
            }), a2 = (function(e4, t3, i3) {
              if (!t3 || !i3) return { isVolumeChanged: false, isNewVersion: false };
              var n3 = t3.volume_info, r3 = i3.volume_info, o3 = w(e4, n3.version, r3.version);
              return {
                isVolumeChanged: R(n3.volume, t3.capabilities.volume_granularity) !== R(r3.volume, i3.capabilities.volume_granularity),
                isNewVersion: o3
              };
            })(void 0 !== n2 && n2, r2, o2), s2 = a2.isVolumeChanged, l2 = a2.isNewVersion;
            s2 && l2 && o2 && (this.diff.deviceVolume = o2.volume_info);
            var c2 = (function(e4, t3) {
              for (var i3 = function(t4) {
                var i4 = e4.find(function(e5) {
                  return e5.info.device_id === t4.info.device_id;
                });
                if (!i4 || i4.is_offline !== t4.is_offline)
                  return { value: { isAnyoneConnectionChanged: true, changedConnectionStatusDevice: t4 } };
              }, n3 = 0; n3 < t3.length; n3++) {
                var r3 = i3(t3[n3]);
                if ("object" == typeof r3) return r3.value;
              }
              return { isAnyoneConnectionChanged: false };
            })(this.state.devices, i2.devices), u2 = c2.isAnyoneConnectionChanged, p2 = c2.changedConnectionStatusDevice;
            p2 && (this.diff.changedConnectionStatusDevice = p2), (s2 && l2 || u2) && (this.diff.devices = i2.devices);
          }
        }), Object.defineProperty(e2.prototype, "calculateEntityIdDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.newState.player_state.player_queue, i2 = e3.skipVersionCompare, n2 = t2.entity_id, r2 = t2.version, o2 = this.state.player_state.player_queue, a2 = o2.entity_id;
            w(void 0 !== i2 && i2, o2.version, r2) && a2 !== n2 && (this.initPlayerState(true, false), this.diff.player_state && this.diff.player_state.player_queue && (this.diff.player_state.player_queue.entity_id = n2));
          }
        }), Object.defineProperty(e2.prototype, "calculateEntityTypeDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.newState.player_state.player_queue, i2 = t2.entity_type, n2 = t2.version, r2 = e3.skipVersionCompare, o2 = this.state.player_state.player_queue, a2 = o2.entity_type;
            w(void 0 !== r2 && r2, o2.version, n2) && a2 !== i2 && (this.initPlayerState(true, false), this.diff.player_state && this.diff.player_state.player_queue && (this.diff.player_state.player_queue.entity_type = i2));
          }
        }), Object.defineProperty(e2.prototype, "calculateCurrentPlayableIndexDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.newState.player_state.player_queue, i2 = e3.skipVersionCompare, n2 = t2.entity_id, r2 = t2.current_playable_index, o2 = t2.version, a2 = this.state.player_state.player_queue, s2 = a2.entity_id, l2 = a2.current_playable_index;
            w(void 0 !== i2 && i2, a2.version, o2) && s2 === n2 && l2 !== r2 && (this.initPlayerState(true, false), this.diff.player_state && this.diff.player_state.player_queue && (this.diff.player_state.player_queue.current_playable_index = r2));
          }
        }), Object.defineProperty(e2.prototype, "calculatePlayableListDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.newState.player_state.player_queue, i2 = e3.skipVersionCompare, n2 = t2.playable_list, r2 = t2.version, o2 = this.state.player_state.player_queue, a2 = o2.playable_list, s2 = w(void 0 !== i2 && i2, o2.version, r2), l2 = (function(e4, t3) {
              var i3, n3;
              if (e4.length === t3.length) {
                for (var r3 = e4.length, o3 = 0; o3 < r3; o3++)
                  if (t3[o3] && (null == (i3 = e4[o3]) ? void 0 : i3.playable_id) !== (null == (n3 = t3[o3]) ? void 0 : n3.playable_id))
                    return false;
                return true;
              }
              return false;
            })(a2, n2);
            s2 && !l2 && (this.initPlayerState(true, false), this.diff.player_state && this.diff.player_state.player_queue && (this.diff.player_state.player_queue.playable_list = n2));
          }
        }), Object.defineProperty(e2.prototype, "calculateShuffleDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.newState.player_state.player_queue, i2 = t2.shuffle_optional, n2 = t2.version, r2 = e3.skipVersionCompare, o2 = this.state.player_state.player_queue, a2 = o2.shuffle_optional, s2 = w(void 0 !== r2 && r2, o2.version, n2), l2 = (function(e4, t3) {
              if (!e4 && !t3) return true;
              if (e4 && t3 && e4.playable_indices.length === t3.playable_indices.length) {
                for (var i3 = true, n3 = 0; n3 <= e4.playable_indices.length; n3++)
                  if (e4.playable_indices[n3] !== t3.playable_indices[n3]) {
                    i3 = false;
                    break;
                  }
                return i3;
              }
              return false;
            })(a2, i2);
            s2 && !l2 && (this.initPlayerState(true, false), this.diff.player_state && this.diff.player_state.player_queue && (i2 ? this.diff.player_state.player_queue.shuffle_optional = i2 : this.diff.player_state.player_queue.shuffle_optional = { playable_indices: [] }));
          }
        }), Object.defineProperty(e2.prototype, "calculateRepeatDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.newState.player_state.player_queue, i2 = t2.options, n2 = t2.version, r2 = e3.skipVersionCompare, o2 = i2.repeat_mode, a2 = this.state.player_state.player_queue, s2 = a2.options, l2 = a2.version, c2 = s2.repeat_mode;
            w(void 0 !== r2 && r2, l2, n2) && c2 !== o2 && (this.initPlayerState(true, false), this.diff.player_state && this.diff.player_state.player_queue && (this.diff.player_state.player_queue.options = i2));
          }
        }), Object.defineProperty(e2.prototype, "calculateProgressMsDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2, i2, n2 = e3.newState.player_state.status, r2 = e3.skipVersionCompare, o2 = n2.progress_ms, a2 = n2.version, s2 = this.state.player_state.status, l2 = s2.progress_ms, c2 = w(void 0 !== r2 && r2, s2.version, a2), u2 = (t2 = Number(o2)) !== (i2 = Number(l2)) && (i2 < 1500 || Math.abs(t2 - i2) > p);
            c2 && u2 && (this.initPlayerState(false, true), this.diff.player_state && this.diff.player_state.status && (this.diff.player_state.status.progress_ms = o2));
          }
        }), Object.defineProperty(e2.prototype, "calculateSpeedDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.newState.player_state.status, i2 = t2.playback_speed, n2 = t2.version, r2 = e3.skipVersionCompare, o2 = this.state.player_state.status, a2 = o2.playback_speed;
            w(void 0 !== r2 && r2, o2.version, n2) && a2 !== i2 && (this.initPlayerState(false, true), this.diff.player_state && this.diff.player_state.status && (this.diff.player_state.status.playback_speed = i2));
          }
        }), Object.defineProperty(e2.prototype, "calculatePausedDiff", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.newState.player_state.status, i2 = e3.skipVersionCompare, n2 = t2.paused, r2 = t2.version, o2 = this.state.player_state.status, a2 = o2.paused;
            w(void 0 !== i2 && i2, o2.version, r2) && a2 !== n2 && (this.initPlayerState(false, true), this.diff.player_state && this.diff.player_state.status && (this.diff.player_state.status.paused = n2));
          }
        }), Object.defineProperty(e2.prototype, "initPlayerState", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            this.diff.player_state || (this.diff.player_state = {}), e3 && !this.diff.player_state.player_queue && (this.diff.player_state.player_queue = {}), t2 && !this.diff.player_state.status && (this.diff.player_state.status = {});
          }
        }), Object.defineProperty(e2.prototype, "getLastActiveRemoteControllerDevice", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e3, t2, i2 = this, n2 = this.options.deviceConfig.info.device_id, r2 = this.state.active_device_id_optional, o2 = this.state.devices.find(function(e4) {
              var t3;
              return (null == (t3 = e4.info) ? void 0 : t3.device_id) === r2;
            }), a2 = [this.state.player_state.player_queue.version, this.state.player_state.status.version];
            (null == (e3 = null == o2 ? void 0 : o2.volume_info) ? void 0 : e3.version) && a2.push(null == (t2 = null == o2 ? void 0 : o2.volume_info) ? void 0 : t2.version);
            var s2 = a2.sort(function(e4, t3) {
              return t3.timestamp_ms - e4.timestamp_ms;
            }).find(function(e4) {
              if (e4.device_id === n2 || 0 === e4.timestamp_ms) return false;
              var t3, r3 = i2.state.devices.find(function(t4) {
                var i3, n3;
                return (null == (i3 = t4.info) ? void 0 : i3.device_id) === e4.device_id && (null == (n3 = t4.capabilities) ? void 0 : n3.can_be_remote_controller);
              });
              return !!(r3 && (null == (t3 = null == r3 ? void 0 : r3.capabilities) ? void 0 : t3.can_be_remote_controller));
            });
            if (s2)
              return this.state.devices.find(function(e4) {
                var t3;
                return (null == (t3 = e4.info) ? void 0 : t3.device_id) === (null == s2 ? void 0 : s2.device_id);
              });
          }
        }), Object.defineProperty(e2.prototype, "getOnlineRemoteControllerDevice", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            for (var e3, t2, i2, n2, r2, o2, a2 = 0, s2 = this.state.devices; a2 < s2.length; a2++) {
              var l2 = s2[a2];
              if (!l2.is_offline && (null == (e3 = l2.capabilities) ? void 0 : e3.can_be_remote_controller)) {
                if (this.lastActiveRemoteControllerDevice && (null == (t2 = l2.info) ? void 0 : t2.device_id) === (null == (i2 = this.lastActiveRemoteControllerDevice.info) ? void 0 : i2.device_id))
                  return l2;
                this.onlineRemoteControllerDevice && (null == (n2 = l2.info) ? void 0 : n2.device_id) === (null == (r2 = this.onlineRemoteControllerDevice.info) ? void 0 : r2.device_id) && (o2 = l2), o2 || (o2 = l2);
              }
            }
            return o2;
          }
        }), Object.defineProperty(e2.prototype, "updateLastRemoteControllerDevice", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e3 = this.getLastActiveRemoteControllerDevice();
            e3 ? this.onlineRemoteControllerDevice = void 0 : this.onlineRemoteControllerDevice = this.getOnlineRemoteControllerDevice(), this.lastActiveRemoteControllerDevice = e3;
          }
        }), e2;
      })();
      !(function(e2) {
        e2.PRODUCTION = "ynison.music.yandex.ru", e2.QA = "qa.ynison.music.yandex.ru";
      })(r || (r = {})), (function(e2) {
        e2.CONNECTING = "CONNECTING", e2.CONNECTED = "CONNECTED", e2.DISCONNECTED = "DISCONNECTED", e2.WAITING_FOR_RECONNECT = "WAITING_FOR_RECONNECT", e2.READY_TO_RECONNECT = "READY_TO_RECONNECT";
      })(o || (o = {})), (function(e2) {
        e2.RECEIVE_MESSAGE = "RECEIVE_MESSAGE", e2.NEW_CONNECTION_ATTEMPT = "NEW_CONNECTION_ATTEMPT", e2.CONNECTED = "CONNECTED", e2.CONNECTION_ERROR = "CONNECTION_ERROR", e2.HUB_ERROR = "HUB_ERROR", e2.HUB_MESSAGE_PARSING_ERROR = "HUB_MESSAGE_PARSING_ERROR", e2.DISCONNECTED = "DISCONNECTED", e2.MESSAGE_SENT = "MESSAGE_SENT", e2.MESSAGE_LOST = "MESSAGE_LOST";
      })(a || (a = {})), (function(e2) {
        e2.ynisonBackoffMillis = "ynison-backoff-millis", e2.ynisonErrorCode = "ynison-error-code", e2.ynisonGoAwayForSeconds = "ynison-go-away-for-seconds";
      })(s || (s = {})), (function(e2) {
        e2.CLIENT = "CLIENT", e2.SERVER = "SERVER";
      })(l || (l = {})), (function(e2) {
        e2.REDIRECTOR = "redirector", e2.HUB = "hub";
      })(c || (c = {}));
      var A = /* @__PURE__ */ (function() {
        var e2 = function(t2, i2) {
          return (e2 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e3, t3) {
            e3.__proto__ = t3;
          } || function(e3, t3) {
            for (var i3 in t3) Object.prototype.hasOwnProperty.call(t3, i3) && (e3[i3] = t3[i3]);
          })(t2, i2);
        };
        return function(t2, i2) {
          if ("function" != typeof i2 && null !== i2)
            throw TypeError("Class extends value " + String(i2) + " is not a constructor or null");
          function n2() {
            this.constructor = t2;
          }
          e2(t2, i2), t2.prototype = null === i2 ? Object.create(i2) : (n2.prototype = i2.prototype, new n2());
        };
      })(), I = function() {
        return (I = Object.assign || function(e2) {
          for (var t2, i2 = 1, n2 = arguments.length; i2 < n2; i2++)
            for (var r2 in t2 = arguments[i2]) Object.prototype.hasOwnProperty.call(t2, r2) && (e2[r2] = t2[r2]);
          return e2;
        }).apply(this, arguments);
      }, D = function(e2, t2) {
        var i2 = {};
        for (var n2 in e2) Object.prototype.hasOwnProperty.call(e2, n2) && 0 > t2.indexOf(n2) && (i2[n2] = e2[n2]);
        if (null != e2 && "function" == typeof Object.getOwnPropertySymbols)
          for (var r2 = 0, n2 = Object.getOwnPropertySymbols(e2); r2 < n2.length; r2++)
            0 > t2.indexOf(n2[r2]) && Object.prototype.propertyIsEnumerable.call(e2, n2[r2]) && (i2[n2[r2]] = e2[n2[r2]]);
        return i2;
      }, j = (function(e2) {
        function t2(i2, n2) {
          void 0 === n2 && (n2 = {});
          var r2 = this, o2 = n2.code, a2 = D(n2, ["code"]);
          return Object.defineProperty(
            r2 = e2.call(this, i2, I({ code: void 0 === o2 ? "E_HUB_MESSAGE_EXCEPTION" : o2 }, a2)) || this,
            "name",
            { enumerable: true, configurable: true, writable: true, value: "HubMessageException" }
          ), Object.setPrototypeOf(r2, t2.prototype), r2;
        }
        return A(t2, e2), t2;
      })(P.t), k = i(87965), M = function(e2) {
        Object.defineProperty(this, "redirectorResponse", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        }), Object.defineProperty(this, "connectionState", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        }), this.redirectorResponse = new k.cJ(e2.redirectorResponse), this.connectionState = new k.cJ(e2.connectionState);
      }, U = /* @__PURE__ */ (function() {
        var e2 = function(t2, i2) {
          return (e2 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e3, t3) {
            e3.__proto__ = t3;
          } || function(e3, t3) {
            for (var i3 in t3) Object.prototype.hasOwnProperty.call(t3, i3) && (e3[i3] = t3[i3]);
          })(t2, i2);
        };
        return function(t2, i2) {
          if ("function" != typeof i2 && null !== i2)
            throw TypeError("Class extends value " + String(i2) + " is not a constructor or null");
          function n2() {
            this.constructor = t2;
          }
          e2(t2, i2), t2.prototype = null === i2 ? Object.create(i2) : (n2.prototype = i2.prototype, new n2());
        };
      })(), L = function() {
        return (L = Object.assign || function(e2) {
          for (var t2, i2 = 1, n2 = arguments.length; i2 < n2; i2++)
            for (var r2 in t2 = arguments[i2]) Object.prototype.hasOwnProperty.call(t2, r2) && (e2[r2] = t2[r2]);
          return e2;
        }).apply(this, arguments);
      }, F = function(e2, t2) {
        var i2 = {};
        for (var n2 in e2) Object.prototype.hasOwnProperty.call(e2, n2) && 0 > t2.indexOf(n2) && (i2[n2] = e2[n2]);
        if (null != e2 && "function" == typeof Object.getOwnPropertySymbols)
          for (var r2 = 0, n2 = Object.getOwnPropertySymbols(e2); r2 < n2.length; r2++)
            0 > t2.indexOf(n2[r2]) && Object.prototype.propertyIsEnumerable.call(e2, n2[r2]) && (i2[n2[r2]] = e2[n2[r2]]);
        return i2;
      }, V = (function(e2) {
        function t2(i2, n2) {
          void 0 === n2 && (n2 = {});
          var r2 = this, o2 = n2.code, a2 = F(n2, ["code"]);
          return Object.defineProperty(
            r2 = e2.call(this, i2, L({ code: void 0 === o2 ? "E_REDIRECTOR_EXCEPTION" : o2 }, a2)) || this,
            "name",
            { enumerable: true, configurable: true, writable: true, value: "RedirectorException" }
          ), Object.setPrototypeOf(r2, t2.prototype), r2;
        }
        return U(t2, e2), t2;
      })(P.t);
      function q(e2) {
        var t2;
        switch (e2) {
          case f.WEB:
            t2 = 1;
            break;
          case f.WEB_TV:
            t2 = 5;
            break;
          default:
            t2 = 1;
        }
        return t2;
      }
      !(function(e2) {
        e2.ynisonDeviceId = "Ynison-Device-Id", e2.ynisonRedirectTicket = "Ynison-Redirect-Ticket", e2.ynisonSessionId = "Ynison-Session-Id", e2.ynisonDeviceInfo = "Ynison-Device-Info", e2.multiAuthUserId = "X-Yandex-Music-Multi-Auth-User-Id";
      })(u || (u = {}));
      var x = function(e2, t2) {
        var i2, n2, r2, o2, a2 = {
          label: 0,
          sent: function() {
            if (1 & r2[0]) throw r2[1];
            return r2[1];
          },
          trys: [],
          ops: []
        };
        return o2 = { next: s2(0), throw: s2(1), return: s2(2) }, "function" == typeof Symbol && (o2[Symbol.iterator] = function() {
          return this;
        }), o2;
        function s2(s3) {
          return function(l2) {
            var c2 = [s3, l2];
            if (i2) throw TypeError("Generator is already executing.");
            for (; o2 && (o2 = 0, c2[0] && (a2 = 0)), a2; )
              try {
                if (i2 = 1, n2 && (r2 = 2 & c2[0] ? n2.return : c2[0] ? n2.throw || ((r2 = n2.return) && r2.call(n2), 0) : n2.next) && !(r2 = r2.call(n2, c2[1])).done)
                  return r2;
                switch (n2 = 0, r2 && (c2 = [2 & c2[0], r2.value]), c2[0]) {
                  case 0:
                  case 1:
                    r2 = c2;
                    break;
                  case 4:
                    return a2.label++, { value: c2[1], done: false };
                  case 5:
                    a2.label++, n2 = c2[1], c2 = [0];
                    continue;
                  case 7:
                    c2 = a2.ops.pop(), a2.trys.pop();
                    continue;
                  default:
                    if (!(r2 = (r2 = a2.trys).length > 0 && r2[r2.length - 1]) && (6 === c2[0] || 2 === c2[0])) {
                      a2 = 0;
                      continue;
                    }
                    if (3 === c2[0] && (!r2 || c2[1] > r2[0] && c2[1] < r2[3])) {
                      a2.label = c2[1];
                      break;
                    }
                    if (6 === c2[0] && a2.label < r2[1]) {
                      a2.label = r2[1], r2 = c2;
                      break;
                    }
                    if (r2 && a2.label < r2[2]) {
                      a2.label = r2[2], a2.ops.push(c2);
                      break;
                    }
                    r2[2] && a2.ops.pop(), a2.trys.pop();
                    continue;
                }
                c2 = t2.call(e2, a2);
              } catch (e3) {
                c2 = [6, e3], n2 = 0;
              } finally {
                i2 = r2 = 0;
              }
            if (5 & c2[0]) throw c2[1];
            return { value: c2[0] ? c2[1] : void 0, done: true };
          };
        }
      }, G = (function() {
        function e2(e3) {
          Object.defineProperty(this, "device", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "connectionConfig", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), this.device = e3.device, this.connectionConfig = e3.connectionConfig;
        }
        return Object.defineProperty(e2.prototype, "getHub", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2, i2, n2, r2;
            return t2 = this, i2 = void 0, n2 = void 0, r2 = function() {
              var t3 = this;
              return x(this, function(i3) {
                return [
                  2,
                  new Promise(function(i4, n3) {
                    var r3, o2, a2, s2, l2, c2, p2 = e3.oauth, f2 = e3.multiAuthUserId, d2 = (a2 = (r3 = t3.device).device_id, s2 = r3.app_name, l2 = r3.app_version, c2 = q(r3.type), (o2 = {})[u.ynisonDeviceId] = a2, o2[u.ynisonDeviceInfo] = JSON.stringify({ app_name: s2, app_version: l2, type: c2 }), o2);
                    void 0 !== p2 && (d2.authorization = "OAuth ".concat(p2)), void 0 !== f2 && (d2["X-Yandex-Music-Multi-Auth-User-Id"] = String(f2));
                    var v2 = new WebSocket(Object.values(t3.connectionConfig).join(""), [
                      "Bearer",
                      "v2",
                      encodeURIComponent(JSON.stringify(d2))
                    ]), h2 = function(e4) {
                      try {
                        var t4 = JSON.parse(e4.data);
                        "error" in t4 ? (v2.close(), n3(
                          new V("Error message from redirector", { data: { redirectorResponse: t4.error } })
                        )) : (v2.close(), i4(t4));
                      } catch (e5) {
                        new V("Error while processing message from redirector", {
                          data: { redirectorResponse: {} },
                          cause: g(e5)
                        });
                      }
                    }, y2 = function() {
                      n3(new V("Error in connection to redirector", { data: { redirectorResponse: {} } }));
                    }, b2 = function() {
                      v2.removeEventListener("message", h2), v2.removeEventListener("error", y2), v2.removeEventListener("close", b2);
                    };
                    v2.addEventListener("message", h2), v2.addEventListener("error", y2), v2.addEventListener("close", b2);
                  })
                ];
              });
            }, new (n2 || (n2 = Promise))(function(e4, o2) {
              function a2(e5) {
                try {
                  l2(r2.next(e5));
                } catch (e6) {
                  o2(e6);
                }
              }
              function s2(e5) {
                try {
                  l2(r2.throw(e5));
                } catch (e6) {
                  o2(e6);
                }
              }
              function l2(t3) {
                var i3;
                t3.done ? e4(t3.value) : ((i3 = t3.value) instanceof n2 ? i3 : new n2(function(e5) {
                  e5(i3);
                })).then(a2, s2);
              }
              l2((r2 = r2.apply(t2, i2 || [])).next());
            });
          }
        }), e2;
      })(), B = i(9348), H = function() {
        return (H = Object.assign || function(e2) {
          for (var t2, i2 = 1, n2 = arguments.length; i2 < n2; i2++)
            for (var r2 in t2 = arguments[i2]) Object.prototype.hasOwnProperty.call(t2, r2) && (e2[r2] = t2[r2]);
          return e2;
        }).apply(this, arguments);
      }, W = function(e2, t2) {
        var i2 = (0, B.A)(), n2 = H(H({}, e2), { rid: i2 });
        if (t2) {
          var r2 = t2.player_action_timestamp_ms, o2 = void 0 === r2 ? Date.now() : r2, a2 = t2.activity_interception_type, s2 = void 0 === a2 ? v.DO_NOT_INTERCEPT_BY_DEFAULT : a2;
          n2.player_action_timestamp_ms = o2, n2.activity_interception_type = s2;
        } else
          n2.player_action_timestamp_ms = Date.now(), n2.activity_interception_type = v.DO_NOT_INTERCEPT_BY_DEFAULT;
        return { request: n2, rid: i2 };
      }, Y = (function() {
        function e2(e3) {
          Object.defineProperty(this, "history", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "limit", { enumerable: true, configurable: true, writable: true, value: void 0 }), this.limit = e3.limit, this.history = /* @__PURE__ */ new Map();
        }
        return Object.defineProperty(e2.prototype, "onMessageSent", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            this.history.set(e3, t2), this.deleteOldRecords();
          }
        }), Object.defineProperty(e2.prototype, "shouldIgnoreIncomingMessage", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2, i2 = this.history.get(e3);
            return null != (t2 = null == i2 ? void 0 : i2.ignoreResponse) && t2;
          }
        }), Object.defineProperty(e2.prototype, "clear", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.history.clear();
          }
        }), Object.defineProperty(e2.prototype, "deleteOldRecords", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            for (var e3 = this.history.keys(); this.history.size >= this.limit; )
              this.history.delete(e3.next().value);
          }
        }), e2;
      })(), K = /* @__PURE__ */ (function() {
        var e2 = function(t2, i2) {
          return (e2 = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e3, t3) {
            e3.__proto__ = t3;
          } || function(e3, t3) {
            for (var i3 in t3) Object.prototype.hasOwnProperty.call(t3, i3) && (e3[i3] = t3[i3]);
          })(t2, i2);
        };
        return function(t2, i2) {
          if ("function" != typeof i2 && null !== i2)
            throw TypeError("Class extends value " + String(i2) + " is not a constructor or null");
          function n2() {
            this.constructor = t2;
          }
          e2(t2, i2), t2.prototype = null === i2 ? Object.create(i2) : (n2.prototype = i2.prototype, new n2());
        };
      })(), J = function() {
        return (J = Object.assign || function(e2) {
          for (var t2, i2 = 1, n2 = arguments.length; i2 < n2; i2++)
            for (var r2 in t2 = arguments[i2]) Object.prototype.hasOwnProperty.call(t2, r2) && (e2[r2] = t2[r2]);
          return e2;
        }).apply(this, arguments);
      }, X = function(e2, t2) {
        var i2 = {};
        for (var n2 in e2) Object.prototype.hasOwnProperty.call(e2, n2) && 0 > t2.indexOf(n2) && (i2[n2] = e2[n2]);
        if (null != e2 && "function" == typeof Object.getOwnPropertySymbols)
          for (var r2 = 0, n2 = Object.getOwnPropertySymbols(e2); r2 < n2.length; r2++)
            0 > t2.indexOf(n2[r2]) && Object.prototype.propertyIsEnumerable.call(e2, n2[r2]) && (i2[n2[r2]] = e2[n2[r2]]);
        return i2;
      }, z = (function(e2) {
        function t2(i2, n2) {
          void 0 === n2 && (n2 = {});
          var r2 = this, o2 = n2.code, a2 = X(n2, ["code"]);
          return Object.defineProperty(
            r2 = e2.call(this, i2, J({ code: void 0 === o2 ? "E_HUB_CONNECTION_EXCEPTION" : o2 }, a2)) || this,
            "name",
            { enumerable: true, configurable: true, writable: true, value: "HubConnectionException" }
          ), Object.setPrototypeOf(r2, t2.prototype), r2;
        }
        return K(t2, e2), t2;
      })(P.t), $ = function() {
        return ($ = Object.assign || function(e2) {
          for (var t2, i2 = 1, n2 = arguments.length; i2 < n2; i2++)
            for (var r2 in t2 = arguments[i2]) Object.prototype.hasOwnProperty.call(t2, r2) && (e2[r2] = t2[r2]);
          return e2;
        }).apply(this, arguments);
      }, Q = "[CLIENT-REASON] ", Z = (function() {
        function e2(e3) {
          Object.defineProperty(this, "connectorConfig", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "socket", { enumerable: true, configurable: true, writable: true, value: null }), Object.defineProperty(this, "redirectorSocket", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "reconnectTimeout", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
          }), Object.defineProperty(this, "reconnectAttempts", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 0
          }), Object.defineProperty(this, "historyController", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "emitter", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new S()
          }), Object.defineProperty(this, "state", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new M({ redirectorResponse: null, connectionState: o.DISCONNECTED })
          }), this.connectorConfig = e3.config, this.redirectorSocket = new G({
            device: this.connectorConfig.device,
            connectionConfig: this.connectorConfig.redirectorConnectionConfig
          }), this.historyController = new Y({ limit: this.connectorConfig.historyLimit });
        }
        return Object.defineProperty(e2.prototype, "on", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            var i2 = this;
            return this.emitter.on(e3, t2), function() {
              i2.emitter.off(e3, t2);
            };
          }
        }), Object.defineProperty(e2.prototype, "config", {
          get: function() {
            return m(this.connectorConfig);
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e2.prototype, "updateFullState", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            var i2 = $({}, e3);
            i2.player_state.player_queue.version = _(this.connectorConfig.device.device_id, 0), i2.player_state.status.version = _(this.connectorConfig.device.device_id, 0);
            var n2 = W({ update_full_state: i2 }, $({ player_action_timestamp_ms: 0 }, t2)), r2 = n2.request, o2 = n2.rid;
            return this.sendRequest(r2), this.historyController.onMessageSent(o2, { ignoreResponse: false }), o2;
          }
        }), Object.defineProperty(e2.prototype, "updatePlayingStatus", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            var i2 = W({ update_playing_status: $({}, e3) }, t2), n2 = i2.request, r2 = i2.rid;
            return this.sendRequest(n2), this.historyController.onMessageSent(r2, { ignoreResponse: true }), r2;
          }
        }), Object.defineProperty(e2.prototype, "updateActiveDevice", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            var i2 = W({ update_active_device: e3 }, t2), n2 = i2.request, r2 = i2.rid;
            return this.sendRequest(n2), this.historyController.onMessageSent(r2, { ignoreResponse: true }), r2;
          }
        }), Object.defineProperty(e2.prototype, "updateSessionParams", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            var i2 = W({ update_session_params: e3 }, t2), n2 = i2.request, r2 = i2.rid;
            return this.sendRequest(n2), this.historyController.onMessageSent(r2, { ignoreResponse: true }), r2;
          }
        }), Object.defineProperty(e2.prototype, "updatePlayerState", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            var i2 = W({ update_player_state: $({}, e3) }, t2), n2 = i2.request, r2 = i2.rid;
            return this.sendRequest(n2), this.historyController.onMessageSent(r2, { ignoreResponse: true }), r2;
          }
        }), Object.defineProperty(e2.prototype, "updateVolumeInfo", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            var i2 = W({ update_volume_info: $({}, e3) }, t2), n2 = i2.request, r2 = i2.rid;
            return this.sendRequest(n2), this.historyController.onMessageSent(r2, { ignoreResponse: true }), r2;
          }
        }), Object.defineProperty(e2.prototype, "connect", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = this, i2 = e3.oauth, n2 = e3.multiAuthUserId;
            void 0 !== i2 && (this.connectorConfig.oauth = i2), void 0 !== n2 && (this.connectorConfig.multiAuthUserId = n2), [o.DISCONNECTED, o.READY_TO_RECONNECT].includes(this.state.connectionState.value) && (this.state.connectionState.value = o.CONNECTING, this.emitter.emit(a.NEW_CONNECTION_ATTEMPT, {}), this.redirectorSocket.getHub({
              oauth: this.connectorConfig.oauth,
              multiAuthUserId: this.connectorConfig.multiAuthUserId
            }).then(function(e4) {
              t2.state.redirectorResponse.value = e4, t2.connectToHub();
            }).catch(function(e4) {
              t2.state.connectionState.value = o.DISCONNECTED;
              var i3 = (16 !== e4.data.redirectorResponse.grpc_code || 401 !== e4.data.redirectorResponse.http_code) && t2.reconnectAttempts < t2.connectorConfig.reconnectAttemptsLimit;
              if (t2.emitter.emit(a.CONNECTION_ERROR, {
                destination: c.REDIRECTOR,
                error: e4,
                shouldReconnect: i3
              }), i3) {
                var n3 = e4.data.redirectorResponse.extra_headers && e4.data.redirectorResponse.extra_headers[s.ynisonGoAwayForSeconds] ? 1e3 * Number(e4.data.redirectorResponse.extra_headers[s.ynisonGoAwayForSeconds]) : t2.connectorConfig.defaultReconnectTimeoutMS;
                t2.reconnect({ timeout: n3 });
              } else t2.reconnectAttempts = 0;
            }));
          }
        }), Object.defineProperty(e2.prototype, "disconnect", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            this.reconnectTimeout && (clearTimeout(this.reconnectTimeout), this.reconnectTimeout = null), this.reconnectAttempts = 0, this.closeConnection(1e3, "".concat(Q).concat(e3));
          }
        }), Object.defineProperty(e2.prototype, "closeConnection", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            var i2, n2;
            this.state.connectionState.value = o.DISCONNECTED, ((null == (i2 = this.socket) ? void 0 : i2.readyState) === WebSocket.CONNECTING || (null == (n2 = this.socket) ? void 0 : n2.readyState) === WebSocket.OPEN) && this.socket.close(e3, t2);
          }
        }), Object.defineProperty(e2.prototype, "clearConnection", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.socket = null, this.historyController.clear();
          }
        }), Object.defineProperty(e2.prototype, "connectToHub", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e3 = this, t2 = this.connectorConfig, i2 = t2.oauth, n2 = t2.device, r2 = t2.multiAuthUserId, s2 = this.connectorConfig.hubConnectionConfig, p2 = s2.protocol, f2 = s2.path;
            if (this.state.redirectorResponse.value) {
              var d2, v2, h2, y2, b2, _2, m2, g2, O2, C2 = this.state.redirectorResponse.value.host, S2 = (d2 = this.state.redirectorResponse.value, h2 = n2.type, y2 = n2.app_name, b2 = n2.app_version, _2 = n2.device_id, m2 = d2.session_id, g2 = d2.redirect_ticket, O2 = q(h2), (v2 = {})[u.ynisonDeviceId] = _2, v2[u.ynisonRedirectTicket] = g2, v2[u.ynisonSessionId] = m2, v2[u.ynisonDeviceInfo] = JSON.stringify({ app_name: y2, app_version: b2, type: O2 }), v2);
              void 0 !== i2 && (S2.authorization = "OAuth ".concat(i2)), void 0 !== r2 && (S2["X-Yandex-Music-Multi-Auth-User-Id"] = String(r2));
              var E2 = "".concat(p2).concat(C2).concat(f2), R2 = ["Bearer", "v2", encodeURIComponent(JSON.stringify(S2))];
              this.socket = new WebSocket(E2, R2), this.socket.addEventListener("message", function(t3) {
                e3.onReceiveMessage(t3);
              }), this.socket.addEventListener("error", function() {
                e3.state.connectionState.value = o.DISCONNECTED;
                var t3 = e3.reconnectAttempts < e3.connectorConfig.reconnectAttemptsLimit, i3 = new z("Error in connection to hub", {
                  data: { redirectorResponse: e3.state.redirectorResponse.value || {}, shouldReconnect: t3 }
                });
                e3.emitter.emit(a.CONNECTION_ERROR, { destination: c.HUB, error: i3, shouldReconnect: t3 }), t3 ? e3.reconnect() : e3.reconnectAttempts = 0;
              }), this.socket.addEventListener("open", function() {
                e3.state.connectionState.value = o.CONNECTED, e3.emitter.emit(a.CONNECTED, {});
              }), this.socket.addEventListener("close", function(t3) {
                e3.state.connectionState.value = o.DISCONNECTED, e3.clearConnection();
                var i3 = t3.reason.includes(Q);
                e3.emitter.emit(a.DISCONNECTED, { trigger: i3 ? l.CLIENT : l.SERVER, event: t3 });
              });
            }
          }
        }), Object.defineProperty(e2.prototype, "reconnect", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = this;
            void 0 === e3 && (e3 = {});
            var i2 = e3.timeout, n2 = void 0 === i2 ? this.connectorConfig.defaultReconnectTimeoutMS : i2;
            this.state.connectionState.value === o.DISCONNECTED && (this.reconnectAttempts += 1, this.reconnectTimeout = setTimeout(function() {
              t2.state.connectionState.value = o.READY_TO_RECONNECT, t2.connect({});
            }, n2), this.state.connectionState.value = o.WAITING_FOR_RECONNECT);
          }
        }), Object.defineProperty(e2.prototype, "onReceiveMessage", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            try {
              var t2 = JSON.parse(e3.data);
              if ("error" in t2) {
                var i2 = this.reconnectAttempts < this.connectorConfig.reconnectAttemptsLimit;
                this.closeConnection(1e3, "".concat(Q, "Error in message"));
                var n2 = new j("Error message from hub", {
                  data: {
                    redirectorResponse: this.state.redirectorResponse.value || {},
                    hubResponse: t2.error,
                    hubResponseRaw: e3.data
                  }
                });
                if (this.emitter.emit(a.HUB_ERROR, { error: n2, shouldReconnect: i2 }), i2) {
                  var r2 = t2.error.details[s.ynisonGoAwayForSeconds] ? 1e3 * Number(t2.error.details[s.ynisonGoAwayForSeconds]) : this.connectorConfig.defaultReconnectTimeoutMS;
                  this.reconnect({ timeout: r2 });
                } else this.reconnectAttempts = 0;
              } else
                this.reconnectAttempts = 0, this.historyController.shouldIgnoreIncomingMessage(t2.rid) || this.emitter.emit(a.RECEIVE_MESSAGE, { rawData: t2 });
            } catch (t3) {
              this.emitter.emit(
                a.HUB_MESSAGE_PARSING_ERROR,
                new j("Error while processing message from hub", {
                  data: {
                    redirectorResponse: this.state.redirectorResponse.value || {},
                    hubResponse: {},
                    hubResponseRaw: e3.data
                  },
                  cause: g(t3)
                })
              );
            }
          }
        }), Object.defineProperty(e2.prototype, "sendRequest", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            null !== this.socket && this.socket.readyState === WebSocket.OPEN && this.state.connectionState.value === o.CONNECTED ? (this.socket.send(JSON.stringify(e3)), this.emitter.emit(a.MESSAGE_SENT, e3)) : this.emitter.emit(a.MESSAGE_LOST, e3);
          }
        }), e2;
      })(), ee = function(e2, t2, i2) {
        var n2, r2, o2;
        return {
          volume: null != (n2 = t2.value) ? n2 : 0.5,
          capabilities: {
            can_be_player: true,
            can_be_remote_controller: false,
            volume_granularity: null != (r2 = t2.granularity) ? r2 : 16
          },
          info: e2,
          volume_info: { volume: null != (o2 = t2.value) ? o2 : 0.5, version: null },
          is_shadow: !!i2.isShadow
        };
      }, et = function() {
        return (et = Object.assign || function(e2) {
          for (var t2, i2 = 1, n2 = arguments.length; i2 < n2; i2++)
            for (var r2 in t2 = arguments[i2]) Object.prototype.hasOwnProperty.call(t2, r2) && (e2[r2] = t2[r2]);
          return e2;
        }).apply(this, arguments);
      }, ei = (function() {
        function e2(e3) {
          var t2 = this;
          Object.defineProperty(this, "stateController", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "connector", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "deviceConfig", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "logger", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "variables", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "updateFullStateMessageRid", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: null
          }), Object.defineProperty(this, "isUpdateFullStateCompleted", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
          }), this.deviceConfig = e3.deviceConfig, this.variables = e3.variables, this.logger = e3.logger, this.stateController = new T({ deviceConfig: this.deviceConfig }), this.connector = new Z({
            config: {
              device: this.deviceConfig.info,
              oauth: e3.oauth,
              multiAuthUserId: e3.multiAuthUserId,
              redirectorConnectionConfig: {
                protocol: "wss://",
                host: e3.ynisonConnectionConfig.ynisonHost,
                path: e3.ynisonConnectionConfig.redirectorPath
              },
              hubConnectionConfig: { protocol: "wss://", path: e3.ynisonConnectionConfig.hubConnectioPath },
              defaultReconnectTimeoutMS: e3.ynisonConnectionConfig.reconnectTimeout,
              reconnectAttemptsLimit: e3.ynisonConnectionConfig.reconnectAttempts,
              historyLimit: e3.ynisonConnectionConfig.historyLimit
            }
          }), this.connector.on(a.RECEIVE_MESSAGE, this.onMessageReceived.bind(this)), this.stateController.on(n.UPDATED, this.onStateChanged.bind(this), "WSConnector"), this.connector.state.connectionState.onChange(function(e4) {
            switch (e4) {
              case o.CONNECTED:
                t2.onConnected();
                break;
              case o.DISCONNECTED:
                t2.onDisconnected();
            }
          }), this.connector.on(a.CONNECTION_ERROR, function(e4) {
            t2.logger.error("[Ynison] Connection error: ".concat(e4.error.message), et({}, e4));
          }), this.connector.on(a.HUB_MESSAGE_PARSING_ERROR, function(e4) {
            t2.logger.error("[Ynison] Hub message error: ".concat(e4.message), { error: e4 });
          }), this.connector.on(a.HUB_ERROR, function(e4) {
            t2.logger.error("[Ynison] Hub error: ".concat(e4.error.message), et({}, e4));
          });
        }
        return Object.defineProperty(e2.prototype, "isActive", {
          get: function() {
            var e3 = this.stateController.currentState.active_device_id_optional;
            return !!(e3 && e3 === this.deviceConfig.info.device_id);
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e2.prototype, "onMessageReceived", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = this.getMessageContext(e3);
            if (this.updateFullStateCompletion(t2), !this.shouldIgnoreMessage(t2)) {
              var i2 = this.processMessageState(e3, t2);
              this.stateController.updateState(i2);
            }
          }
        }), Object.defineProperty(e2.prototype, "getMessageContext", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            return {
              isCurrentUpdateFullStateMessage: e3.rawData.rid === this.updateFullStateMessageRid,
              deviceTransition: this.getDeviceStateTransition(e3)
            };
          }
        }), Object.defineProperty(e2.prototype, "getDeviceStateTransition", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = e3.rawData.active_device_id_optional === this.deviceConfig.info.device_id, i2 = e3.rawData.active_device_id_optional !== this.stateController.currentState.active_device_id_optional;
            return {
              willBecomeActive: !this.isActive && t2,
              willBecomePassive: this.isActive && !t2,
              willStayPassive: !this.isActive && !t2,
              isAnotherActiveDeviceUpdated: !this.isActive && !t2 && i2
            };
          }
        }), Object.defineProperty(e2.prototype, "shouldIgnoreMessage", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            return !e3.deviceTransition.isAnotherActiveDeviceUpdated && this.shouldIgnorePlayerStateUpdate(e3);
          }
        }), Object.defineProperty(e2.prototype, "shouldIgnorePlayerStateUpdate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            return !this.isUpdateFullStateCompleted || (e3.isCurrentUpdateFullStateMessage ? false === this.stateController.currentState.player_state.status.paused : this.variables.isShadow || e3.deviceTransition.willStayPassive);
          }
        }), Object.defineProperty(e2.prototype, "processMessageState", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3, t2) {
            var i2 = e3.rawData;
            return (this.isActive || (i2 = this.overrideIncomingDeviceVolume(i2)), this.shouldIgnorePlayerStateUpdate(t2)) ? this.createActiveDeviceStateUpdate(i2) : this.shouldOverridePauseState(t2) ? this.createPausedStateUpdate(i2) : { newState: i2, trigger: "WSConnector" };
          }
        }), Object.defineProperty(e2.prototype, "updateFullStateCompletion", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            this.isUpdateFullStateCompleted = this.isUpdateFullStateCompleted || e3.isCurrentUpdateFullStateMessage;
          }
        }), Object.defineProperty(e2.prototype, "shouldOverridePauseState", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            return e3.isCurrentUpdateFullStateMessage && e3.deviceTransition.willStayPassive || e3.deviceTransition.willBecomePassive;
          }
        }), Object.defineProperty(e2.prototype, "createPausedStateUpdate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = m(e3);
            return t2.player_state.status.paused = true, t2.player_state.status.version = _(this.deviceConfig.info.device_id, 0), { newState: t2, skipVersionCompare: true, trigger: "WSConnector" };
          }
        }), Object.defineProperty(e2.prototype, "overrideIncomingDeviceVolume", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2, i2, n2, r2, o2, a2 = this, s2 = m(e3), l2 = this.stateController.currentState, c2 = s2.devices.find(function(e4) {
              var t3;
              return (null == (t3 = e4.info) ? void 0 : t3.device_id) === a2.deviceConfig.info.device_id;
            }), u2 = l2.devices.find(function(e4) {
              var t3;
              return (null == (t3 = e4.info) ? void 0 : t3.device_id) === a2.deviceConfig.info.device_id;
            });
            if (c2) {
              var p2 = {
                volume: null != (n2 = null != (i2 = null == (t2 = null == u2 ? void 0 : u2.volume_info) ? void 0 : t2.volume) ? i2 : this.deviceConfig.defaultVolume) ? n2 : 0.5,
                version: null != (o2 = null == (r2 = null == u2 ? void 0 : u2.volume_info) ? void 0 : r2.version) ? o2 : null
              };
              c2.volume = p2.volume, c2.volume_info = p2;
            }
            return s2;
          }
        }), Object.defineProperty(e2.prototype, "createActiveDeviceStateUpdate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2 = m(e3);
            return t2.player_state = m(this.stateController.currentState.player_state), { newState: t2, skipVersionCompare: true, trigger: "WSConnector" };
          }
        }), Object.defineProperty(e2.prototype, "processOutgoingPlayerState", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            return et(et({}, e3), { status: this.processOutgoingPlayerStatus(e3.status) });
          }
        }), Object.defineProperty(e2.prototype, "processOutgoingPlayerStatus", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            return this.variables.isShadow ? et(et({}, e3), { paused: true }) : e3;
          }
        }), Object.defineProperty(e2.prototype, "createOutgoingDeviceData", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e3, t2, i2 = this, n2 = this.stateController.currentState.devices.find(function(e4) {
              var t3;
              return (null == (t3 = e4.info) ? void 0 : t3.device_id) === i2.deviceConfig.info.device_id;
            });
            return ee(
              this.deviceConfig.info,
              {
                value: null != (t2 = null == (e3 = null == n2 ? void 0 : n2.volume_info) ? void 0 : e3.volume) ? t2 : this.deviceConfig.defaultVolume,
                granularity: this.deviceConfig.volumeGranularity
              },
              { isShadow: this.variables.isShadow }
            );
          }
        }), Object.defineProperty(e2.prototype, "onStateChanged", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            var t2, i2, n2 = !!(this.stateController.currentState.active_device_id_optional && !this.isActive);
            this.isUpdateFullStateCompleted && !n2 && ((t2 = e3.diff).player_state && t2.player_state.player_queue ? this.connector.updatePlayerState({
              player_state: this.processOutgoingPlayerState(e3.state.player_state)
            }) : (i2 = e3.diff).player_state && i2.player_state.status && this.connector.updatePlayingStatus({
              playing_status: this.processOutgoingPlayerStatus(e3.state.player_state.status)
            }), e3.diff.deviceVolume && this.isActive && this.connector.updateVolumeInfo({
              device_id: this.deviceConfig.info.device_id,
              volume_info: e3.diff.deviceVolume
            }));
          }
        }), Object.defineProperty(e2.prototype, "onConnected", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e3;
            this.updateFullStateMessageRid = this.connector.updateFullState(
              (e3 = this.createOutgoingDeviceData(), {
                player_state: this.processOutgoingPlayerState(this.stateController.currentState.player_state),
                device: e3,
                is_currently_active: (this.variables.isShadow, false),
                sync_state_from_eov_optional: null
              })
            );
          }
        }), Object.defineProperty(e2.prototype, "onDisconnected", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.isUpdateFullStateCompleted = false, this.updateFullStateMessageRid = null;
          }
        }), Object.defineProperty(e2.prototype, "interceptActivity", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            void 0 === e3 && (e3 = v.INTERCEPT_EAGER), this.connector.updatePlayerState(
              { player_state: this.stateController.currentState.player_state },
              { activity_interception_type: e3 }
            );
            var t2 = this.stateController.currentState;
            t2.active_device_id_optional = this.deviceConfig.info.device_id, this.stateController.updateState({ newState: t2, trigger: "WSConnector" });
          }
        }), Object.defineProperty(e2.prototype, "becomePassive", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.connector.updateActiveDevice({ device_id_optional: null });
            var e3 = this.stateController.currentState;
            e3.active_device_id_optional = null, e3.player_state.status.paused = true, e3.player_state.status.version = _(this.deviceConfig.info.device_id), this.stateController.updateState({ newState: e3, trigger: "WSConnector" });
          }
        }), Object.defineProperty(e2.prototype, "updateVariables", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            Object.assign(this.variables, e3);
          }
        }), Object.defineProperty(e2.prototype, "updateDeviceInfo", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e3) {
            Object.assign(this.deviceConfig.info, e3);
          }
        }), e2;
      })();
    }
  }
]);
