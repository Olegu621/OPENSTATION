(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [585],
  {
    62: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "EntityMeta_root__Zn4Th",
        root_disabled: "EntityMeta_root_disabled__u3DaR",
        albumLink: "EntityMeta_albumLink__vxRG7",
        artistCaption: "EntityMeta_artistCaption__3JqiO",
        artistLink: "EntityMeta_artistLink__rMKgI",
        description: "EntityMeta_description__cSa2I",
        explicitMark: "EntityMeta_explicitMark__wOyns",
        likesCount: "EntityMeta_likesCount__cw2GN",
        subtitle: "EntityMeta_subtitle__yE1NK",
        title: "EntityMeta_title__6_ChR",
        titleContainer: "EntityMeta_titleContainer__WMe1r",
        version: "EntityMeta_version__7Z948",
        root_disliked: "EntityMeta_root_disliked__PhzHW",
        title_withVersion: "EntityMeta_title_withVersion__rbXWv",
        text: "EntityMeta_text___lB4k",
        icon: "EntityMeta_icon__tTxs3"
      };
    },
    1131: (e) => {
      e.exports = {
        root: "PaywallFAQAnswer_root__IGMDE",
        list: "PaywallFAQAnswer_list__rPZmm",
        listItem: "PaywallFAQAnswer_listItem__5UQmO",
        link: "PaywallFAQAnswer_link__WM9Xr"
      };
    },
    1220: (e, t, r) => {
      "use strict";
      r.d(t, { EditContentModal: () => b });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(43426), l = r(47713), c = r(31500), u = r(77881), f = r(5956), d = r(19009), x = r(32692), p = r(97800), _ = r(60440), m = r(55088), v = r.n(m);
      let g = (e2) => {
        let t2 = e2.value.trim().length;
        return "number" == typeof e2.minLength && !!(t2 < e2.minLength) || "number" == typeof e2.maxLength && !!(t2 > e2.maxLength);
      }, b = (0, a.PA)((e2) => {
        let { open: t2, title: r2, content: a2, onClose: m2, onChange: b2 } = e2, {
          settings: { isMobile: y }
        } = (0, _.useStore)(), { formatMessage: h } = (0, o.A)(), [k, E] = (0, i.useState)(a2), [w, j] = (0, i.useState)(false), O = (0, i.useCallback)(
          (e3) => (t3) => {
            let r3 = t3.target.value, n2 = k.find((t4) => t4.key === e3);
            n2 && (n2.value = r3), E([...k]), j(false);
          },
          [k]
        ), R = (0, i.useCallback)(() => {
          if (k.some(g)) return void j(true);
          b2(k);
        }, [b2, k]), C = (0, i.useMemo)(
          () => k.map((e3) => {
            let t3 = O(e3.key), r3 = w && g(e3);
            return (0, n.jsxs)(
              "div",
              {
                className: v().field,
                children: [
                  (0, n.jsx)(p.Caption, { variant: "div", size: "m", className: v().label, children: e3.title }),
                  (0, n.jsx)(d.p, {
                    value: e3.value,
                    containerClassName: (0, s.$)(v().input, { [v().input_error]: r3 }),
                    placeholder: e3.title,
                    onChange: t3,
                    minLength: e3.minLength,
                    maxLength: e3.maxLength
                  })
                ]
              },
              e3.key
            );
          }),
          [O, w, k]
        );
        return (0, n.jsxs)(x.a, {
          size: "fitContent",
          placement: y ? "default" : "center",
          open: t2,
          className: v().root,
          contentClassName: v().modalContent,
          showHeader: false,
          escapeKey: false,
          closeOnOutsidePress: false,
          isMobile: y,
          containerProps: (0, c.Am)(c.e8.ugc.UGC_EDIT_MODAL),
          overlayColor: "full",
          children: [
            (0, n.jsxs)("div", {
              className: v().header,
              children: [
                (0, n.jsx)(p.Heading, {
                  variant: "h4",
                  size: "m",
                  weight: "bold",
                  className: v().title,
                  children: r2
                }),
                (0, n.jsx)(u.$, {
                  radius: "round",
                  color: "secondary",
                  size: "xxs",
                  icon: (0, n.jsx)(f.Icon, { variant: "close", size: "xxs" }),
                  onClick: m2,
                  "aria-label": h({ id: "ugc.close-edit-popup" }),
                  ...(0, c.Am)(c.e8.ugc.UGC_EDIT_MODAL_CLOSE_BUTTON)
                })
              ]
            }),
            (0, n.jsxs)("div", {
              className: v().content,
              children: [
                C,
                (0, n.jsxs)("div", {
                  className: v().buttons,
                  children: [
                    (0, n.jsx)(u.$, {
                      radius: "xxxl",
                      color: "secondary",
                      size: y ? "l" : "m",
                      className: v().button,
                      onClick: m2,
                      children: (0, n.jsx)(l.A, { id: "interface-actions.cancel" })
                    }),
                    (0, n.jsx)(u.$, {
                      radius: "xxxl",
                      color: "primary",
                      size: y ? "l" : "m",
                      className: v().button,
                      onClick: R,
                      children: (0, n.jsx)(l.A, { id: "interface-actions.save" })
                    })
                  ]
                })
              ]
            })
          ]
        });
      });
    },
    1810: (e) => {
      e.exports = {
        root: "EntityCardShimmer_root__Sh7ah",
        subcover: "EntityCardShimmer_subcover__ESt3R",
        cover: "EntityCardShimmer_cover__BXtjT",
        cover_round: "EntityCardShimmer_cover_round__Ci3zW",
        cover_withSubcover: "EntityCardShimmer_cover_withSubcover__v9l5y",
        infoContainer: "EntityCardShimmer_infoContainer__22kYk",
        infoContainer_centered: "EntityCardShimmer_infoContainer_centered__cxlPO",
        title: "EntityCardShimmer_title__GQ2jX",
        title_withSubcover: "EntityCardShimmer_title_withSubcover__lBHBC",
        content_linesCount_1: "EntityCardShimmer_content_linesCount_1__JHlue",
        content_linesCount_2: "EntityCardShimmer_content_linesCount_2__CMvO5",
        content_linesCount_3: "EntityCardShimmer_content_linesCount_3__mPzav",
        content_linesCount_4: "EntityCardShimmer_content_linesCount_4__8KtHO"
      };
    },
    2569: (e) => {
      e.exports = {
        root: "PaywallFAQItem_root__008Hj",
        questionCollapse: "PaywallFAQItem_questionCollapse__dN7g9",
        questionContainer: "PaywallFAQItem_questionContainer__gOalt",
        answer: "PaywallFAQItem_answer__mgvr2",
        answerContainer: "PaywallFAQItem_answerContainer__z_P3g",
        answerContainer_enter: "PaywallFAQItem_answerContainer_enter__zAisZ",
        answerContainer_enter_active: "PaywallFAQItem_answerContainer_enter_active__N5iad",
        "animation-show": "PaywallFAQItem_animation-show__YWHaS",
        answerContainer_exit: "PaywallFAQItem_answerContainer_exit__y_3_j",
        answerContainer_exit_active: "PaywallFAQItem_answerContainer_exit_active__IUs7C",
        "animation-hide": "PaywallFAQItem_animation-hide__Eqrf5"
      };
    },
    3270: (e, t, r) => {
      "use strict";
      r.d(t, { DownloadingProgress: () => u });
      var n = r(54486), s = r(50420), a = r(43426), i = r(35190), o = r(5956), l = r(14266), c = r.n(l);
      let u = (e2) => {
        let {
          value: t2,
          size: r2,
          strokeWidth: l2,
          withCancelIcon: u2,
          className: f,
          progressBarClassName: d,
          cancelIconClassName: x
        } = e2, { formatMessage: p } = (0, a.A)();
        return (0, n.jsxs)("div", {
          className: (0, s.$)(c().root, f),
          children: [
            (0, n.jsx)(i.q, {
              value: t2,
              size: r2,
              strokeWidth: l2,
              max: 100,
              withRoundStroke: true,
              className: c().progressBar,
              progressCircleClassName: d,
              "aria-valuetext": p({ id: "offline.download-progress" })
            }),
            u2 && (0, n.jsx)(o.Icon, { variant: "close", size: "xxxs", className: (0, s.$)(c().cancelIcon, x) })
          ]
        });
      };
    },
    3728: (e, t, r) => {
      "use strict";
      r.d(t, { y: () => o });
      var n = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        1950: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "i0E_2NX4cuGTUSRVsza3",
            rotate: "SMKp_W9v6gety5k24_TU",
            root_size_xxxs: "OSqyMcSTAjYqzIL992Yw",
            root_size_xxs: "wc4asYHkCHxWpvH_vfHV",
            root_size_xs: "_EehQphkMVEVJTlcOqgz",
            root_size_s: "R_2xF0Onip_K0GrDRV97",
            root_size_m: "tQV7pWeuTErBtRna7Fxx",
            root_size_l: "OJsrGLXpsIsmbj65C9AC",
            root_size_xl: "Vo4fBR82NKcVtfQCh508",
            root_size_xxl: "F45u5jR26w00BDX1OFHX",
            gradient: "xNNiKSvH1JTxlAkvyDlr"
          };
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        248: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Spinner = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = n2(r2(1950));
          t2.Spinner = (e3) => {
            let { className: t3, thicknessSizeRatio: r3 = 0.1, paddingSizeRatio: n3 = 0.08, size: o2, ...l } = e3, c = 100 * r3, u = 50 - c / 2 - 100 * n3, f = 3 * Math.PI / 2 * u;
            return (0, s2.jsxs)("svg", {
              viewBox: "0 0 ".concat(100, " ").concat(100),
              className: (0, a2.clsx)(i2.default.root, i2.default["root_size_".concat(o2)], t3),
              "aria-hidden": true,
              ...l,
              children: [
                (0, s2.jsx)("defs", {
                  children: (0, s2.jsx)("mask", {
                    id: "mask",
                    maskContentUnits: "userSpaceOnUse",
                    children: (0, s2.jsx)("circle", {
                      cx: 50,
                      cy: 50,
                      r: u,
                      stroke: "white",
                      strokeLinecap: "round",
                      strokeWidth: c,
                      strokeDasharray: f,
                      fill: "none"
                    })
                  })
                }),
                (0, s2.jsx)("foreignObject", {
                  x: "0",
                  y: "0",
                  width: 100,
                  height: 100,
                  mask: "url(#mask)",
                  children: (0, s2.jsx)("div", { className: i2.default.gradient })
                })
              ]
            });
          };
        }
      }, s = {};
      function a(e2) {
        var t2 = s[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = s[e2] = { exports: {} };
        return n[e2].call(r2.exports, r2, r2.exports, a), r2.exports;
      }
      a.d = (e2, t2) => {
        for (var r2 in t2) a.o(t2, r2) && !a.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, a.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), a.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var i = {};
      (() => {
        Object.defineProperty(i, "X", { value: true }), i.$ = void 0;
        var e2 = a(248);
        Object.defineProperty(i, "$", {
          enumerable: true,
          get: function() {
            return e2.Spinner;
          }
        });
      })();
      var o = i.$;
      i.X;
    },
    5048: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuShareItem: () => m });
      var n = r(54486), s = r(43426), a = r(47713), i = r(31500), o = r(8817), l = r(5956), c = r(61958), u = r(39139), f = r(17061), d = r(60440), x = r(37809), p = r(23834), _ = r(50215);
      let m = (e2) => {
        let { shareLink: t2, entityMeta: r2, disabled: m2, className: v } = e2, {
          settings: { isMobile: g },
          shareIframe: b
        } = (0, d.useStore)(), { formatMessage: y } = (0, s.A)(), { notify: h } = (0, f.l)(), k = (0, o.c)(async () => {
          await window.navigator.clipboard.writeText(t2), h((0, n.jsx)(_.NotificationCopy, { entityVariant: r2.variant, entityTitle: r2.title }), {
            containerId: u.u.INFO
          });
        }), E = (0, o.c)(() => {
          r2.id && b.openModal(r2);
        }), w = r2.id && r2.variant !== x.Y.ARTIST && r2.variant !== x.Y.CLIP;
        return (0, n.jsxs)(c.W1, {
          offsetOptions: 3,
          isMobile: g,
          className: v,
          label: y({ id: "interface-actions.share" }),
          icon: (0, n.jsx)(l.Icon, { variant: "share", size: "xxs" }),
          disabled: m2,
          submenuProps: { ...(0, i.Am)(i.S7.CONTEXT_MENU_SHARE) },
          ...(0, i.Am)(i.S7.CONTEXT_MENU_SHARE_BUTTON),
          children: [
            (0, n.jsx)(c.Dr, {
              onClick: k,
              icon: (0, n.jsx)(l.Icon, { variant: "chain", size: "xxs" }),
              ...(0, i.Am)(i.S7.CONTEXT_MENU_SHARE_COPY_LINK_BUTTON),
              children: (0, n.jsx)(a.A, { id: "interface-actions.copy-link" })
            }),
            w && (0, n.jsx)(p.WithOffline, {
              fallback: (0, n.jsx)(c.Dr, {
                onClick: E,
                icon: (0, n.jsx)(l.Icon, { variant: "code", size: "xxs" }),
                ...(0, i.Am)(i.S7.CONTEXT_MENU_SHARE_IFRAME_BUTTON),
                children: (0, n.jsx)(a.A, { id: "interface-actions.copy-iframe" })
              })
            })
          ]
        });
      };
    },
    5185: (e, t, r) => {
      "use strict";
      r.d(t, { PaywallFAQItem: () => _ });
      var n = r(54486), s = r(61910), a = r(63664), i = r(62443), o = r(77881), l = r(50420), c = r(85353), u = r.n(c);
      let f = (e2) => {
        let { className: t2, isCollapsed: r2 } = e2;
        return (0, n.jsx)("div", { className: (0, l.$)(u().root, { [u().root_collapsed]: r2 }, t2) });
      };
      var d = r(2569), x = r.n(d);
      let p = {
        exit: x().answerContainer_exit,
        exitActive: x().answerContainer_exit_active,
        enter: x().answerContainer_enter,
        enterActive: x().answerContainer_enter_active
      }, _ = (e2) => {
        let { question: t2, answer: r2, questionDataTestId: l2, answerDataTestId: c2 } = e2, { state: u2, toggle: d2 } = (0, i.e)(true), _2 = (0, s.useRef)(null);
        return (0, n.jsxs)("div", {
          className: x().root,
          children: [
            (0, n.jsxs)(o.$, {
              className: x().questionContainer,
              withRipple: false,
              withHover: false,
              variant: "text",
              onClick: d2,
              "aria-expanded": !u2,
              ...l2,
              children: [t2, (0, n.jsx)(f, { className: x().questionCollapse, isCollapsed: u2 })]
            }),
            (0, n.jsx)(a.A, {
              nodeRef: _2,
              in: !u2,
              timeout: 300,
              classNames: p,
              unmountOnExit: true,
              children: (0, n.jsx)("div", {
                className: x().answerContainer,
                ref: _2,
                ...c2,
                children: (0, n.jsx)("div", { className: x().answer, children: r2 })
              })
            })
          ]
        });
      };
    },
    5602: (e, t, r) => {
      "use strict";
      r.d(t, { PaywallFooter: () => m });
      var n = r(54486), s = r(50420), a = r(28303), i = r(43426), o = r(47713), l = r(31500), c = r(97800), u = r(22628), f = r(33427), d = r(60440), x = r(24036), p = r(71710), _ = r.n(p);
      let m = (0, a.PA)((e2) => {
        let { links: t2, ageRestriction: r2 } = e2, { location: a2 } = (0, d.useStore)(), { language: p2 } = (0, f.useI18nStorage)(), { formatDate: m2 } = (0, i.A)();
        return (0, n.jsxs)("footer", {
          className: _().root,
          ...(0, l.Am)(l.e8.paywall.PAYWALL_FOOTER),
          children: [
            (0, n.jsx)("ul", {
              className: (0, s.$)(_().list, _().list_primary),
              children: t2.map((e3, t3) => {
                let { href: r3, text: a3, testId: i2 } = e3;
                return (0, n.jsx)(
                  "li",
                  {
                    className: _().item,
                    ...(0, l.Am)(i2),
                    children: (0, n.jsx)(x.Link, {
                      className: (0, s.$)(_().link, _().important),
                      href: r3,
                      children: (0, n.jsx)(c.Caption, {
                        type: "controls",
                        variant: "span",
                        size: "l",
                        weight: "medium",
                        children: a3
                      })
                    })
                  },
                  t3
                );
              })
            }),
            (0, n.jsxs)("ul", {
              className: (0, s.$)(_().list, _().list_secondary),
              children: [
                (0, n.jsx)("li", {
                  className: _().item,
                  ...(0, l.Am)(l.e8.paywall.PAYWALL_FOOTER_ITEM_YANDEX_LINK),
                  children: (0, n.jsx)(x.Link, {
                    className: (0, s.$)(_().link, _().important),
                    target: "_blank",
                    href: "https://ya.".concat(a2.tld),
                    children: (0, n.jsxs)(c.Caption, {
                      type: "controls",
                      variant: "span",
                      size: "l",
                      weight: "medium",
                      children: [
                        "©",
                        " 2018–",
                        m2(/* @__PURE__ */ new Date(), (0, u.m)()),
                        " ",
                        (0, n.jsx)(o.A, { id: "footer.yandex-music" })
                      ]
                    })
                  })
                }),
                (0, n.jsxs)("li", {
                  className: _().item,
                  ...(0, l.Am)(l.e8.paywall.PAYWALL_FOOTER_ITEM_ALL_PROJECTS_LINK),
                  children: [
                    (0, n.jsx)(x.Link, {
                      className: (0, s.$)(_().link, _().important),
                      target: "_blank",
                      href: "https://yandex.".concat(a2.tld, "/all?lang=").concat(p2),
                      children: (0, n.jsx)(c.Caption, {
                        type: "controls",
                        variant: "span",
                        size: "l",
                        weight: "medium",
                        children: (0, n.jsx)(o.A, { id: "footer.yandex-project" })
                      })
                    }),
                    (0, n.jsx)(c.Caption, {
                      className: (0, s.$)(_().item, _().ageRestriction),
                      type: "controls",
                      variant: "span",
                      size: "l",
                      weight: "medium",
                      children: r2
                    })
                  ]
                })
              ]
            })
          ]
        });
      });
    },
    5866: (e) => {
      e.exports = {
        root: "Footer_root__ugyur",
        root_withOffsetForDeeplink: "Footer_root_withOffsetForDeeplink__qcs6U",
        important: "Footer_important__mCXZp",
        links: "Footer_links__3kOY7",
        list: "Footer_list__0sCXQ",
        copyrights: "Footer_copyrights__IsnbJ",
        link: "Footer_link__av50q",
        copyrightLink: "Footer_copyrightLink__6NOkg",
        yandexMusicLink: "Footer_yandexMusicLink__k7ILf",
        explicitText: "Footer_explicitText__Px3wr",
        text: "Footer_text__lMPwl",
        empty: "Footer_empty__RR_zf"
      };
    },
    6323: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuVideoQuality: () => d });
      var n = r(54486), s = r(28303), a = r(61910), i = r(43426), o = r(31500), l = r(61958), c = r(60440), u = (function(e2) {
        return e2.AUTO = "Авто", e2.P1080 = "1080p", e2.P720 = "720p", e2.P480 = "480p", e2.P360 = "360p", e2.P240 = "240p", e2.P144 = "144p", e2;
      })({});
      let f = [u.AUTO, u.P1080, u.P720, u.P480, u.P360, u.P240, u.P144], d = (0, s.PA)((e2) => {
        let { isDisabled: t2, className: r2, menuClassName: s2 } = e2, {
          settings: { isMobile: u2 }
        } = (0, c.useStore)(), { formatMessage: d2 } = (0, i.A)(), x = (0, a.useMemo)(() => f.map((e3) => (0, n.jsx)(l.Dr, { iconPosition: "right", children: e3 }, e3)), []);
        return (0, n.jsx)(l.W1, {
          menuClassName: s2,
          offsetOptions: 3,
          isMobile: u2,
          className: r2,
          label: d2({ id: "interface-actions.quality" }),
          disabled: t2,
          ...(0, o.Am)(o.S7.CONTEXT_MENU_VIDEO_QUALITY_BUTTON),
          children: x
        });
      });
    },
    7230: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuWithCheckItem: () => u });
      var n = r(54486), s = r(50420), a = r(5956), i = r(61958), o = r(97800), l = r(91930), c = r.n(l);
      let u = (e2) => {
        let { text: t2, onClick: r2, isDisabled: l2, className: u2, isActive: f, "aria-label": d } = e2;
        return (0, n.jsxs)(i.Dr, {
          className: (0, s.$)(u2, c().menuItem),
          onClick: r2,
          disabled: l2,
          isSubMenu: true,
          children: [
            (0, n.jsx)(o.Caption, { variant: "div", lineClamp: 1, children: t2 }),
            f && (0, n.jsx)(a.Icon, { className: c().icon, size: "xxxs", variant: "check", "aria-label": d })
          ]
        });
      };
    },
    7430: (e, t, r) => {
      "use strict";
      r.d(t, { HorizontalCardContainer: () => c });
      var n = r(54486), s = r(50420), a = r(61910), i = r(8546), o = r.n(i);
      let l = (e2) => {
        let { className: t2, children: r2, forwardRef: a2, onClick: i2, ...l2 } = e2;
        return (0, n.jsx)("div", { ref: a2, onClick: i2, className: (0, s.$)(o().root, t2), ...l2, children: r2 });
      }, c = (0, a.forwardRef)((e2, t2) => (0, n.jsx)(l, { forwardRef: t2, ...e2 }));
    },
    7482: (e) => {
      e.exports = {
        animation_scaled: "LikeButton_animation_scaled___NgPW",
        scale: "LikeButton_scale__Gv0fD",
        animation_unscaled: "LikeButton_animation_unscaled__YdYoQ",
        unscale: "LikeButton_unscale__4Kprg"
      };
    },
    8075: (e, t, r) => {
      "use strict";
      var n;
      r.d(t, { S: () => n }), (function(e2) {
        e2.TRACK = "track", e2.MUSIC = "music", e2.NOISE = "noise", e2.PODCAST = "podcast-episode", e2.COMMENT = "comment", e2.ARTICLE = "article", e2.ASMR = "asmr", e2.RADIO = "radio", e2.SHOW = "show", e2.LECTURE = "lecture", e2.FAIRY_TALE = "fairy-tale", e2.AUDIOBOOK = "audiobook", e2.POETRY = "poetry";
      })(n || (n = {}));
    },
    8546: (e) => {
      e.exports = { root: "HorizontalCardContainer_root__YoAAP" };
    },
    8607: (e) => {
      e.exports = {
        root: "PlayingAnimation_root__YrWz7",
        "bubble-out": "PlayingAnimation_bubble-out__k2fBS",
        root_stopAnimation: "PlayingAnimation_root_stopAnimation__qOw_g"
      };
    },
    8740: (e) => {
      e.exports = {
        root: "DeeplinkAndOnelinkContainer_root__69SNc",
        button: "DeeplinkAndOnelinkContainer_button__QzMwG",
        buttonTitle: "DeeplinkAndOnelinkContainer_buttonTitle__KmdNV",
        buttonIcon: "DeeplinkAndOnelinkContainer_buttonIcon__U6JJv",
        musicIcon: "DeeplinkAndOnelinkContainer_musicIcon__jIu2m",
        onelinkIcon: "DeeplinkAndOnelinkContainer_onelinkIcon__ELZLH"
      };
    },
    8765: (e, t, r) => {
      "use strict";
      r.d(t, { AdvertBanner: () => d });
      var n = r(54486), s = r(28303), a = r(61910), i = r(57270), o = r(80411), l = r(7286), c = r(85192), u = r(60440), f = r(1756);
      let d = (0, s.PA)((e2) => {
        let { className: t2, productionBlockId: r2, testBlockId: s2, onRender: d2, onNoAds: x, onError: p, isAsync: _ } = e2, { experiments: m } = (0, u.useStore)(), { render: v } = (0, l.useAdfox)(), g = (0, c.D)(), b = (0, a.useMemo)(() => {
          let e3 = m.checkExperiment(f.z.WebNextAdvertTest, "on"), t3 = "production" === g;
          return e3 || !t3 ? s2 : r2;
        }, [g, m, r2, s2]), y = "".concat(i.l, "_").concat(b);
        return (0, a.useEffect)(() => {
          v(
            {
              blockId: b,
              renderTo: y,
              async: _,
              onRender: () => {
                null == d2 || d2(o.h.DIRECT);
              },
              onError: p
            },
            () => {
              null == x || x();
            }
          );
        }, [b, y, v, d2, p, x, _]), (0, n.jsx)("div", { id: y, className: t2, tabIndex: -1, "aria-hidden": true });
      });
    },
    10084: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuTrackProgressItem: () => f });
      var n = r(54486), s = r(28303), a = r(61910), i = r(47713), o = r(31500), l = r(5956), c = r(61958), u = r(60440);
      let f = (0, s.PA)((e2) => {
        let { isFinished: t2, onClick: r2, className: s2 } = e2, { user: f2 } = (0, u.useStore)(), d = (0, a.useMemo)(
          () => t2 ? (0, n.jsx)(i.A, { id: "interface-actions.mark-non-listened" }) : (0, n.jsx)(i.A, { id: "interface-actions.mark-listened" }),
          [t2]
        );
        return (0, n.jsx)(c.Dr, {
          className: s2,
          onClick: r2,
          icon: (0, n.jsx)(l.Icon, { variant: "check", size: "xxs" }),
          disabled: !f2.isAuthorized,
          ...(0, o.Am)(o.S7.CONTEXT_MENU_MARK_LISTENED_BUTTON),
          children: d
        });
      });
    },
    10196: (e) => {
      e.exports = {
        root: "CarouselWithColumnsBlock_root__v_qoo",
        controls: "CarouselWithColumnsBlock_controls__yCSFo",
        item: "CarouselWithColumnsBlock_item__RBGs4",
        item_columns_one: "CarouselWithColumnsBlock_item_columns_one__GuhDB",
        item_columns_two: "CarouselWithColumnsBlock_item_columns_two__46rgZ",
        column: "CarouselWithColumnsBlock_column__oMRES",
        backwardControl: "CarouselWithColumnsBlock_backwardControl__b_uKR",
        controlsContainer: "CarouselWithColumnsBlock_controlsContainer__4_1Ao"
      };
    },
    10358: (e, t, r) => {
      "use strict";
      r.d(t, { TrailerOnboarding: () => y });
      var n = r(54486), s = r(28303), a = r(61910), i = r(43426), o = r(47713), l = r(67648), c = r(77881), u = r(5956), f = r(93666), d = r(97800), x = r(30878), p = r(58436), _ = r(36578), m = r(66989), v = r(94426), g = r.n(v);
      let b = { width: 20, height: 8, tipRadius: 2, fill: "var(--ym-background-color-primary-enabled-tooltip)" }, y = (0, s.PA)((e2) => {
        let { children: t2, customMessage: r2, shouldForceOpenTooltip: s2 } = e2, { formatMessage: v2 } = (0, i.A)(), { contentRef: y2 } = (0, x.useLayout)(), { setIsOnboardingOpened: h } = (0, m.useOnboardingContext)(), [k, E] = (0, l.d)(), w = (0, _.useOnboarding)({ id: p.h.TRAILER_BUTTON, ref: k }) || !!s2, [j, O] = (0, a.useState)(w), R = (0, a.useCallback)(
          (e3) => {
            null == e3 || e3.stopPropagation(), O(false), h(false);
          },
          [h]
        ), C = (0, a.useCallback)(
          (e3) => {
            e3 || R();
          },
          [R]
        );
        return (0, n.jsxs)(f.m_, {
          placement: "bottom",
          arrowProps: b,
          offsetOptions: 14,
          isHoverEnabled: false,
          open: j,
          onOpenChange: C,
          enableAriaDescribedby: true,
          referenceRef: E,
          children: [
            t2,
            (0, n.jsxs)(f.ZI, {
              className: g().root,
              rootNode: y2,
              children: [
                (0, n.jsx)(c.$, {
                  icon: (0, n.jsx)(u.Icon, { variant: "close", size: "xxs" }),
                  onClick: R,
                  variant: "text",
                  className: g().close,
                  withRipple: false,
                  "aria-label": v2({ id: "interface-actions.close" })
                }),
                (0, n.jsx)(d.Caption, {
                  variant: "span",
                  className: g().text,
                  children: r2 || (0, n.jsx)(o.A, { id: "onboarding.trailer", values: { br: (0, n.jsx)("br", {}) } })
                })
              ]
            })
          ]
        });
      });
    },
    10790: (e, t, r) => {
      "use strict";
      r.d(t, { CarouselBlock: () => g });
      var n = r(54486), s = r(50420), a = r(61910), i = r(43350), o = r(15209), l = r(81203), c = r(22674), u = r(47564), f = r(65140), d = r(52862), x = r(78684), p = r(86226), _ = r(77722), m = r.n(_);
      let v = (e2) => {
        let {
          forwardRef: t2,
          shimmerClassName: r2,
          isShimmerVisible: _2,
          isShimmerActive: v2,
          isShimmerWithSubcover: g2,
          isShimmerCentered: b,
          isShimmerRounded: y,
          title: h,
          description: k,
          coverUrl: E,
          viewAllActionLink: w,
          titleChildren: j,
          children: O,
          className: R,
          containerClassName: C,
          headerClassName: S,
          itemClassName: P,
          showHeaderShimmer: A = false,
          showShimmerInfo: T = true,
          showControls: H = true,
          headingRef: M,
          headingVariant: N,
          ...I
        } = e2, L = (0, a.useId)(), B = (0, a.useRef)(null), { objectsCount: D } = (0, u.useAnalyticsBlock)(), z = (0, a.useMemo)(
          () => A && _2 ? (0, n.jsx)("div", {
            className: S,
            children: (0, n.jsx)(c.Shimmer, { isActive: v2, className: m().shimmerTitle, radius: "l" })
          }) : h || k || j ? (0, n.jsx)(f.B, {
            objectType: i.ky.Shortcut,
            objectId: String(w),
            objectPosX: 0,
            objectPosY: 0,
            objectsCount: null != D ? D : 0,
            children: (0, n.jsx)(d.BlockHeader, {
              className: S,
              labeledForId: L,
              title: h,
              description: k,
              coverUrl: E,
              viewAllActionLink: w,
              controls: H && (0, n.jsx)(x.CarouselControls, { className: m().controls, carouselRef: B }),
              headingRef: M,
              headingVariant: N,
              withDescription: !!k,
              children: j
            })
          }) : void 0,
          [E, k, S, M, N, L, v2, _2, D, H, A, h, j, w]
        );
        return (0, n.jsxs)("section", {
          ref: t2,
          className: (0, s.$)(m().root, R),
          ...(0, o.getDataAttrFromProps)(I),
          children: [
            z,
            (0, n.jsx)(l.Carousel, {
              className: C,
              ref: B,
              itemClassName: (0, s.$)(m().item, m().important, P),
              "aria-labelledby": "".concat(L, " ").concat(L, "-description"),
              children: _2 ? (0, p.k)({ className: r2, isActive: v2, withInfo: T, withSubcover: g2, centered: b, round: y }) : O
            })
          ]
        });
      }, g = (0, a.forwardRef)((e2, t2) => (0, n.jsx)(v, { forwardRef: t2, ...e2 }));
    },
    11718: (e) => {
      e.exports = {
        root: "PlusPaywallButton_root__ftsxl",
        title: "PlusPaywallButton_title__8PpX0",
        subtitle: "PlusPaywallButton_subtitle__brC59"
      };
    },
    12126: (e, t, r) => {
      "use strict";
      r.d(t, { useFuture: () => l });
      var n = r(61910), s = r(62901), a = r(67454), i = r(88416), o = r(90461);
      let l = () => {
        let e2 = (0, i.useContainer)(), t2 = e2.get(a.U2), r2 = e2.get(a.P0).get(s.qV), [l2, c] = (0, n.useState)(false);
        (0, n.useEffect)(() => {
          c(!!r2 && !!t2.get(o.c.Future));
        }, [r2, t2]);
        let u = (0, n.useCallback)(() => {
          t2.set(o.c.Future, !l2), window.location.reload();
        }, [t2, l2]);
        return { isFuture: l2, toggleFuture: u };
      };
    },
    12390: (e, t, r) => {
      "use strict";
      r.d(t, { PinButton: () => _ });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(43426), l = r(31500), c = r(45427), u = r(77881), f = r(5956), d = r(60440), x = r(68554), p = r.n(x);
      let _ = (0, a.PA)((e2) => {
        let {
          isPinned: t2,
          onClick: r2,
          className: a2,
          size: x2 = "s",
          iconSize: _2 = "xxs",
          withScaleAnimation: m = true,
          withRipple: v,
          isDisabled: g
        } = e2, { user: b } = (0, d.useStore)(), { formatMessage: y } = (0, o.A)(), {
          scaleAnimation: h,
          unscaleAnimation: k,
          handleAnimationEnd: E,
          handleClick: w
        } = (0, c.C)({ shouldStartFromUnscale: t2, onClick: r2, isEnabled: m }), j = t2 ? "pin_filled" : "pin", O = (0, i.useMemo)(
          () => t2 ? y({ id: "interface-actions.unpin" }) : y({ id: "interface-actions.pin" }),
          [y, t2]
        );
        return (0, n.jsx)(u.$, {
          className: (0, s.$)(p().root, { [p().animation_scaled]: h, [p().animation_unscaled]: k }, a2),
          onAnimationEnd: E,
          variant: "default",
          color: "secondary",
          onClick: w,
          "aria-label": O,
          "aria-pressed": t2,
          size: x2,
          withRipple: v,
          radius: "round",
          disabled: g || !b.isAuthorized,
          icon: (0, n.jsx)(f.Icon, { className: p().icon, variant: j, size: _2 }),
          ...(0, l.Am)(l.S7.PIN_BUTTON)
        });
      });
    },
    13811: (e, t, r) => {
      "use strict";
      r.d(t, { AlbumTrackShimmer: () => u });
      var n = r(54486), s = r(50420), a = r(61910), i = r(43426), o = r(22674), l = r(47345), c = r.n(l);
      let u = (e2) => {
        let { isActive: t2, className: r2 } = e2, { formatMessage: l2 } = (0, i.A)(), u2 = (0, a.useMemo)(
          () => l2({ id: "loading-messages.entity-is-loading" }, { entityName: l2({ id: "entity-names.track" }) }),
          [l2]
        );
        return (0, n.jsxs)("div", {
          "aria-label": u2,
          "aria-live": t2 ? "polite" : "off",
          "aria-busy": t2,
          className: (0, s.$)(c().root, r2),
          children: [
            (0, n.jsxs)("div", {
              className: c().infoContainer,
              children: [
                (0, n.jsx)("div", {
                  className: c().coverContainer,
                  children: (0, n.jsx)(o.Shimmer, { isActive: t2, className: c().cover, radius: "round" })
                }),
                (0, n.jsx)("div", {
                  className: c().textContainer,
                  children: (0, n.jsx)(o.Shimmer, { isActive: t2, className: c().title, radius: "l" })
                })
              ]
            }),
            (0, n.jsx)(o.Shimmer, { isActive: t2, className: c().action, radius: "l" })
          ]
        });
      };
    },
    13872: (e) => {
      e.exports = { explicitMark: "ExplicitMarkIcon_explicitMark__0BPeQ" };
    },
    13967: (e) => {
      e.exports = {
        root: "PlaylistTrackShimmer_root__nZ9KR",
        infoContainer: "PlaylistTrackShimmer_infoContainer__xLd7a",
        textContainer: "PlaylistTrackShimmer_textContainer__QI5cC",
        title: "PlaylistTrackShimmer_title__MojYd",
        cover: "PlaylistTrackShimmer_cover__xyDhR",
        action: "PlaylistTrackShimmer_action__tT5xx"
      };
    },
    14196: (e, t, r) => {
      "use strict";
      r.d(t, { ErrorBoundary: () => c });
      var n = r(96559), s = r(54486), a = r(61910), i = r(67454), o = r(88416);
      class l extends a.Component {
        static getDerivedStateFromError(e2) {
          return { hasError: true, error: e2 };
        }
        componentDidCatch(e2, t2) {
          this.props.logger.error(e2, { additional: t2, type: "error-boundary" });
        }
        render() {
          let { hasError: e2 } = this.state, { fallback: t2, children: r2 } = this.props;
          return e2 ? (0, s.jsx)(t2, {}) : r2;
        }
        constructor(...e2) {
          super(...e2), (0, n._)(this, "state", { hasError: false });
        }
      }
      let c = (function(e2) {
        let t2 = (t3) => {
          let r2 = (0, o.useContainer)().get(i.Zf);
          return (0, s.jsx)(e2, { ...t3, logger: r2 });
        };
        return t2.displayName = "withContainer(".concat(e2.displayName || e2.name || "Component", ")"), t2;
      })(l);
    },
    14266: (e) => {
      e.exports = {
        root: "DownloadingProgress_root__2Wsc5",
        cancelIcon: "DownloadingProgress_cancelIcon__Eq2uD",
        progressBar: "DownloadingProgress_progressBar__ajbBU"
      };
    },
    15497: (e) => {
      e.exports = {
        collectionLink: "BaseNotificationLike_collectionLink__HDZIi",
        collectionTitle: "BaseNotificationLike_collectionTitle__42dz9",
        entityLink: "BaseNotificationLike_entityLink__PW80J",
        entityTitle: "BaseNotificationLike_entityTitle__Eyv0h",
        text: "BaseNotificationLike_text__Jvlq8",
        image: "BaseNotificationLike_image__8wD5H"
      };
    },
    16372: (e, t, r) => {
      "use strict";
      r.d(t, { PopoverWithActions: () => _ });
      var n = r(54486), s = r(50420), a = r(61910), i = r(43426), o = r(31500), l = r(77881), c = r(5956), u = r(92304), f = r(29896), d = r.n(f);
      let x = { mainAxis: 10 }, p = { isEnabled: true, width: 20, height: 8, tipRadius: 2, className: d().arrow }, _ = (e2) => {
        let {
          contentElement: t2,
          buttons: r2,
          className: f2,
          popoverContentClassName: _2,
          renderChildren: m,
          renderChildrenText: v,
          isOpened: g,
          onOpenChange: b,
          arrowProps: y,
          offsetOptions: h,
          isNested: k,
          isEnabled: E = true,
          contentProps: w,
          ...j
        } = e2, [O, R] = (0, a.useState)(false), C = null != b ? b : R, [S, P] = (0, a.useState)(true), { formatMessage: A } = (0, i.A)(), T = (0, a.useCallback)(() => {
          P(true), C(false);
        }, [P, C]), H = (0, a.useCallback)((e3) => {
          e3.stopPropagation();
        }, []), M = (0, a.useCallback)(
          (e3) => (t3) => {
            var r3;
            t3.stopPropagation(), P(null != (r3 = null == e3 ? void 0 : e3(t3)) && r3), C(false);
          },
          [P, C]
        ), N = (0, a.useMemo)(() => ({ ...p, ...y }), [y]), I = (0, a.useMemo)(
          () => r2.map(
            (e3) => (0, a.cloneElement)(e3, {
              className: (0, s.$)(d().button, e3.props.className),
              onClick: M(e3.props.onClick),
              ...(0, o.Am)(o.S7.POPOVER_WITH_ACTIONS_ACTION_BUTTON)
            })
          ),
          [r2, M]
        ), L = (0, a.useMemo)(() => {
          let e3 = { isPopoverEnabled: E };
          return E && (e3.popoverText = v), m(e3);
        }, [m, E, v]);
        return E ? (0, n.jsxs)(u.AM, {
          open: null != g ? g : O,
          onOpenChange: C,
          arrowProps: N,
          offsetOptions: h || x,
          isNested: k,
          returnFocus: S,
          ...j,
          children: [
            L,
            (0, n.jsx)(u.hl, {
              className: (0, s.$)(d().popoverContent, _2),
              onClick: H,
              ...w,
              children: (0, n.jsxs)("div", {
                className: (0, s.$)(d().root, f2),
                children: [
                  !k && (0, n.jsx)(l.$, {
                    className: d().closeButton,
                    color: "primary",
                    variant: "text",
                    radius: "round",
                    size: "xxs",
                    onClick: T,
                    icon: (0, n.jsx)(c.Icon, { variant: "close", size: "xs" }),
                    "aria-label": A({ id: "interface-actions.close" }),
                    ...(0, o.Am)(o.S7.POPOVER_WITH_ACTIONS_CLOSE_BUTTON)
                  }),
                  (0, n.jsxs)("div", {
                    className: d().content,
                    ...(0, o.Am)(o.S7.POPOVER_WITH_ACTIONS_TEXT),
                    children: [t2, (0, n.jsx)("div", { className: d().buttons, children: I })]
                  })
                ]
              })
            })
          ]
        }) : L;
      };
    },
    16834: (e, t, r) => {
      "use strict";
      r.d(t, { V: () => l });
      var n = r(54486), s = r(50420), a = r(22674), i = r(1810), o = r.n(i);
      let l = (e2) => {
        let {
          isActive: t2,
          className: r2,
          shimmerClassName: i2,
          round: l2,
          "aria-label": c,
          centered: u,
          withInfo: f = true,
          linesCount: d = 3,
          withSubcover: x,
          radius: p = "l"
        } = e2;
        return (0, n.jsxs)("div", {
          "aria-label": c,
          "aria-live": t2 ? "polite" : "off",
          "aria-busy": t2,
          className: (0, s.$)(o().root, r2),
          children: [
            x && (0, n.jsx)(a.Shimmer, { isActive: t2, className: o().subcover, radius: "l" }),
            (0, n.jsx)(a.Shimmer, {
              isActive: t2,
              className: (0, s.$)(o().cover, i2, { [o().cover_round]: l2, [o().cover_withSubcover]: x }),
              radius: p
            }),
            f && (0, n.jsx)("div", {
              className: (0, s.$)(o().infoContainer, o()["content_linesCount_".concat(d)], {
                [o().infoContainer_centered]: u
              }),
              children: (0, n.jsx)(a.Shimmer, {
                isActive: t2,
                className: (0, s.$)(o().title, { [o().title_withSubcover]: x }),
                radius: "s"
              })
            })
          ]
        });
      };
    },
    16934: (e) => {
      e.exports = { root: "DisclaimerModal_root__l96Bq", content: "DisclaimerModal_content__rPx5x" };
    },
    17519: (e, t, r) => {
      "use strict";
      r.d(t, { PlusPaywallAlbumButton: () => _ });
      var n = r(54486), s = r(50420), a = r(61910), i = r(43426), o = r(47713), l = r(31500), c = r(15099), u = r(77881), f = r(97800), d = r(60440), x = r(11718), p = r.n(x);
      let _ = (e2) => {
        let { className: t2, albumType: r2 } = e2, {
          settings: { isMobile: x2 },
          paywall: _2
        } = (0, d.useStore)(), { formatMessage: m } = (0, i.A)(), v = (0, a.useCallback)(
          (e3) => {
            _2.openModal(), e3.stopPropagation();
          },
          [_2]
        ), g = (0, a.useMemo)(() => {
          switch (r2) {
            case c._.SINGLE:
              return m({ id: "payment.single-offer-button-title" });
            case c._.PODCAST:
              return m({ id: "payment.podcast-offer-button-title" });
            case c._.AUDIOBOOK:
              return m({ id: "payment.books-offer-button-title" });
            case c._.FAIRY_TALE:
              return m({ id: "payment.fairy-tale-offer-button-title" });
            default:
              return m({ id: "payment.album-offer-button-title" });
          }
        }, [r2, m]);
        return x2 ? (0, n.jsxs)(u.$, {
          onClick: v,
          className: (0, s.$)(p().root, t2),
          color: "plus",
          size: "l",
          radius: "xxxl",
          children: [
            (0, n.jsx)(f.Caption, { className: p().title, weight: "bold", variant: "div", size: "l", children: g }),
            (0, n.jsx)(f.Caption, {
              className: p().subtitle,
              weight: "normal",
              variant: "div",
              size: "xs",
              children: (0, n.jsx)(o.A, { id: "payment.yandex-plus-offer-button" })
            })
          ]
        }) : (0, n.jsxs)(u.$, {
          onClick: v,
          className: (0, s.$)(p().root, t2),
          color: "plus",
          size: "l",
          radius: "xxxl",
          ...(0, l.Am)(l.S7.PLUS_PAYWALL_BUTTON),
          children: [
            (0, n.jsx)(f.Caption, { className: p().title, weight: "bold", variant: "div", size: "m", children: g }),
            (0, n.jsx)(f.Caption, {
              className: p().subtitle,
              weight: "normal",
              variant: "div",
              size: "xs",
              children: (0, n.jsx)(o.A, { id: "payment.yandex-plus-offer-button" })
            })
          ]
        });
      };
    },
    18242: (e) => {
      e.exports = { descriptionTextItem: "DescriptionTextsDisclaimer_descriptionTextItem__XtzRU" };
    },
    18606: (e, t, r) => {
      "use strict";
      r.d(t, { DescriptionTextsDisclaimer: () => l });
      var n = r(54486), s = r(61910), a = r(97800), i = r(18242), o = r.n(i);
      let l = (e2) => {
        let { getDescriptionTexts: t2, entityId: r2 } = e2, [i2, l2] = (0, s.useState)(null);
        if ((0, s.useEffect)(() => {
          t2 && t2().then(l2);
        }, [t2]), i2)
          return i2.map(
            (e3, t3) => (0, n.jsx)(
              a.Caption,
              {
                className: o().descriptionTextItem,
                variant: "div",
                type: "text",
                size: "m",
                weight: "normal",
                children: e3
              },
              "".concat(r2, "-descpription-text-").concat(t3)
            )
          );
      };
    },
    18608: (e) => {
      e.exports = { shimmer: "TracksList_shimmer__jD4N4" };
    },
    18658: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuVibeItem: () => _ });
      var n = r(54486), s = r(28303), a = r(61910), i = r(47713), o = r(31500), l = r(5956), c = r(61958), u = r(39610), f = r(62452), d = r(60440), x = r(79326);
      let p = {
        album: (0, n.jsx)(i.A, { id: "vibe-actions.vibe-by-album" }),
        artist: (0, n.jsx)(i.A, { id: "vibe-actions.vibe-by-artist" }),
        playlist: (0, n.jsx)(i.A, { id: "vibe-actions.vibe-by-playlist" }),
        track: (0, n.jsx)(i.A, { id: "vibe-actions.vibe-by-track" })
      }, _ = (0, s.PA)((e2) => {
        let { variant: t2, className: r2, onClick: s2, disabled: i2, onOpenMenuChange: _2 } = e2, {
          settings: { isMobile: m },
          user: v
        } = (0, d.useStore)(), { isFreemium: g } = (0, f.X)(), b = (0, a.useCallback)(
          (e3) => {
            let { isPopoverEnabled: a2, popoverText: f2 } = e3;
            return (0, n.jsxs)(c.Dr, {
              onClick: s2,
              disabled: i2 || a2 || !v.isAuthorized,
              className: r2,
              icon: (0, n.jsx)(l.Icon, { variant: "vibe", size: "xxs" }),
              ...(0, o.Am)(o.S7.CONTEXT_MENU_VIBE_BUTTON),
              children: [p[t2], " ", (0, n.jsx)(u.q, { children: f2 })]
            });
          },
          [s2, i2, r2, t2, v.isAuthorized]
        );
        return (0, n.jsx)(x.BuyPlusPopover, {
          isNested: true,
          isEnabled: g && !m,
          placement: "right",
          textVariant: "vibe",
          vibeTextVariant: t2,
          renderChildren: b,
          onOpenMenuChange: _2
        });
      });
    },
    19009: (e, t, r) => {
      "use strict";
      r.d(t, { p: () => u });
      var n, s = r(94377), a = r(61910), i = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        9160: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "kAYDswAvA1AJoAzRV4rY",
            root_disabled: "vkAwJpSGxne16yE82eHh",
            root_size_xxxs: "i690pcQGptnPbYcI77fh",
            root_size_xxs: "K2cOFeQVOaRzGAOv6gWL",
            input: "GRggPQ1rZgvcyCxPPgvw",
            root_variant_secondary: "o9HhnHzukPG4e94AXBNT",
            textShadowing: "ceR_9q_roxCLdCPR87Qw",
            actions: "XsBFSZAjR3ZRN8oqetex"
          };
        },
        4490: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { DOWN: () => o2, LEFT: () => s2, RIGHT: () => a2, UP: () => i2, useSwipeable: () => x });
          var n2 = r2(810);
          let s2 = "Left", a2 = "Right", i2 = "Up", o2 = "Down", l2 = {
            delta: 10,
            preventScrollOnSwipe: false,
            rotationAngle: 0,
            trackMouse: false,
            trackTouch: true,
            swipeDuration: 1 / 0,
            touchEventOptions: { passive: true }
          }, c2 = { first: true, initial: [0, 0], start: 0, swiping: false, xy: [0, 0] }, u2 = "mousemove", f = "mouseup";
          function d(e3, t3) {
            if (0 === t3) return e3;
            let r3 = Math.PI / 180 * t3;
            return [e3[0] * Math.cos(r3) + e3[1] * Math.sin(r3), e3[1] * Math.cos(r3) - e3[0] * Math.sin(r3)];
          }
          function x(e3) {
            var t3, r3, x2;
            let p, { trackMouse: _ } = e3, m = n2.useRef(Object.assign({}, c2)), v = n2.useRef(Object.assign({}, l2)), g = n2.useRef(Object.assign({}, v.current));
            for (p in g.current = Object.assign({}, v.current), v.current = Object.assign(Object.assign({}, l2), e3), l2)
              void 0 === v.current[p] && (v.current[p] = l2[p]);
            let [b, y] = n2.useMemo(
              () => (function(e4, t4) {
                let r4 = (t5) => {
                  let r5 = "touches" in t5;
                  r5 && t5.touches.length > 1 || e4((e5, s3) => {
                    s3.trackMouse && !r5 && (document.addEventListener(u2, n3), document.addEventListener(f, p2));
                    let { clientX: a3, clientY: i3 } = r5 ? t5.touches[0] : t5, o3 = d([a3, i3], s3.rotationAngle);
                    return s3.onTouchStartOrOnMouseDown && s3.onTouchStartOrOnMouseDown({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), {
                      initial: o3.slice(),
                      xy: o3,
                      start: t5.timeStamp || 0
                    });
                  });
                }, n3 = (t5) => {
                  e4((e5, r5) => {
                    var n4, c3, u3, f2;
                    let x4 = "touches" in t5;
                    if (x4 && t5.touches.length > 1) return e5;
                    if (t5.timeStamp - e5.start > r5.swipeDuration)
                      return e5.swiping ? Object.assign(Object.assign({}, e5), { swiping: false }) : e5;
                    let { clientX: p3, clientY: _3 } = x4 ? t5.touches[0] : t5, [m3, v2] = d([p3, _3], r5.rotationAngle), g2 = m3 - e5.xy[0], b2 = v2 - e5.xy[1], y2 = Math.abs(g2), h = Math.abs(b2), k = (t5.timeStamp || 0) - e5.start, E = Math.sqrt(y2 * y2 + h * h) / (k || 1), w = [g2 / (k || 1), b2 / (k || 1)], j = (n4 = y2, c3 = h, u3 = g2, f2 = b2, n4 > c3 ? u3 > 0 ? a2 : s2 : f2 > 0 ? o2 : i2), O = "number" == typeof r5.delta ? r5.delta : r5.delta[j.toLowerCase()] || l2.delta;
                    if (y2 < O && h < O && !e5.swiping) return e5;
                    let R = {
                      absX: y2,
                      absY: h,
                      deltaX: g2,
                      deltaY: b2,
                      dir: j,
                      event: t5,
                      first: e5.first,
                      initial: e5.initial,
                      velocity: E,
                      vxvy: w
                    };
                    R.first && r5.onSwipeStart && r5.onSwipeStart(R), r5.onSwiping && r5.onSwiping(R);
                    let C = false;
                    return (r5.onSwiping || r5.onSwiped || r5["onSwiped".concat(j)]) && (C = true), C && r5.preventScrollOnSwipe && r5.trackTouch && t5.cancelable && t5.preventDefault(), Object.assign(Object.assign({}, e5), { first: false, eventData: R, swiping: true });
                  });
                }, x3 = (t5) => {
                  e4((e5, r5) => {
                    let n4;
                    if (e5.swiping && e5.eventData) {
                      if (t5.timeStamp - e5.start < r5.swipeDuration) {
                        n4 = Object.assign(Object.assign({}, e5.eventData), { event: t5 }), r5.onSwiped && r5.onSwiped(n4);
                        let s3 = r5["onSwiped".concat(n4.dir)];
                        s3 && s3(n4);
                      }
                    } else r5.onTap && r5.onTap({ event: t5 });
                    return r5.onTouchEndOrOnMouseUp && r5.onTouchEndOrOnMouseUp({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), { eventData: n4 });
                  });
                }, p2 = (e5) => {
                  document.removeEventListener(u2, n3), document.removeEventListener(f, p2), x3(e5);
                }, _2 = (e5, t5) => {
                  let s3 = () => {
                  };
                  if (e5 && e5.addEventListener) {
                    let a3 = Object.assign(Object.assign({}, l2.touchEventOptions), t5.touchEventOptions), i3 = [
                      ["touchstart", r4, a3],
                      [
                        "touchmove",
                        n3,
                        Object.assign(Object.assign({}, a3), t5.preventScrollOnSwipe ? { passive: false } : {})
                      ],
                      ["touchend", x3, a3]
                    ];
                    i3.forEach((t6) => {
                      let [r5, n4, s4] = t6;
                      return e5.addEventListener(r5, n4, s4);
                    }), s3 = () => i3.forEach((t6) => {
                      let [r5, n4] = t6;
                      return e5.removeEventListener(r5, n4);
                    });
                  }
                  return s3;
                }, m2 = {
                  ref: (t5) => {
                    null !== t5 && e4((e5, r5) => {
                      if (e5.el === t5) return e5;
                      let n4 = {};
                      return e5.el && e5.el !== t5 && e5.cleanUpTouch && (e5.cleanUpTouch(), n4.cleanUpTouch = void 0), r5.trackTouch && t5 && (n4.cleanUpTouch = _2(t5, r5)), Object.assign(Object.assign(Object.assign({}, e5), { el: t5 }), n4);
                    });
                  }
                };
                return t4.trackMouse && (m2.onMouseDown = r4), [m2, _2];
              })((e4) => m.current = e4(m.current, v.current), { trackMouse: _ }),
              [_]
            );
            return t3 = m.current, r3 = v.current, x2 = g.current, m.current = r3.trackTouch && t3.el ? t3.cleanUpTouch ? r3.preventScrollOnSwipe !== x2.preventScrollOnSwipe || r3.touchEventOptions.passive !== x2.touchEventOptions.passive ? (t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) })) : t3 : Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) }) : (t3.cleanUpTouch && t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: void 0 })), b;
          }
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        9110: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.usePopoverSwipeable = t2.useReturnValue = t2.useCallbackRef = t2.useDebouncedToggle = t2.useResize = t2.useIsomorphicEffect = t2.useForceUpdateRef = t2.useElementOffsetY = t2.getElementNameByDataAttribute = t2.createIntersectionObserver = t2.useIntersectionObserver = t2.useKeyboardNavigation = t2.useScroll = t2.useForwardRef = void 0;
          var n2 = r2(245);
          Object.defineProperty(t2, "useForwardRef", {
            enumerable: true,
            get: function() {
              return n2.useForwardRef;
            }
          });
          var s2 = r2(2067);
          Object.defineProperty(t2, "useScroll", {
            enumerable: true,
            get: function() {
              return s2.useScroll;
            }
          });
          var a2 = r2(5188);
          Object.defineProperty(t2, "useKeyboardNavigation", {
            enumerable: true,
            get: function() {
              return a2.useKeyboardNavigation;
            }
          });
          var i2 = r2(5663);
          Object.defineProperty(t2, "useIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.useIntersectionObserver;
            }
          }), Object.defineProperty(t2, "createIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.createIntersectionObserver;
            }
          }), Object.defineProperty(t2, "getElementNameByDataAttribute", {
            enumerable: true,
            get: function() {
              return i2.getElementNameByDataAttribute;
            }
          });
          var o2 = r2(2101);
          Object.defineProperty(t2, "useElementOffsetY", {
            enumerable: true,
            get: function() {
              return o2.useElementOffsetY;
            }
          });
          var l2 = r2(2767);
          Object.defineProperty(t2, "useForceUpdateRef", {
            enumerable: true,
            get: function() {
              return l2.useForceUpdateRef;
            }
          });
          var c2 = r2(9019);
          Object.defineProperty(t2, "useIsomorphicEffect", {
            enumerable: true,
            get: function() {
              return c2.useIsomorphicEffect;
            }
          });
          var u2 = r2(2947);
          Object.defineProperty(t2, "useResize", {
            enumerable: true,
            get: function() {
              return u2.useResize;
            }
          });
          var f = r2(6699);
          Object.defineProperty(t2, "useDebouncedToggle", {
            enumerable: true,
            get: function() {
              return f.useDebouncedToggle;
            }
          });
          var d = r2(8691);
          Object.defineProperty(t2, "useCallbackRef", {
            enumerable: true,
            get: function() {
              return d.useCallbackRef;
            }
          });
          var x = r2(998);
          Object.defineProperty(t2, "useReturnValue", {
            enumerable: true,
            get: function() {
              return x.useReturnValue;
            }
          });
          var p = r2(4395);
          Object.defineProperty(t2, "usePopoverSwipeable", {
            enumerable: true,
            get: function() {
              return p.usePopoverSwipeable;
            }
          });
          var _ = r2(5969);
          Object.defineProperty(t2, "useDynamicText", {
            enumerable: true,
            get: function() {
              return _.useDynamicText;
            }
          });
        },
        8691: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useCallbackRef = void 0;
          let n2 = r2(810);
          t2.useCallbackRef = function(e3) {
            let t3 = (0, n2.useRef)({
              stableFn: function() {
                for (var e4 = arguments.length, r3 = Array(e4), n3 = 0; n3 < e4; n3++) r3[n3] = arguments[n3];
                return t3.current.callback(...r3);
              },
              callback: e3
            });
            return (0, n2.useInsertionEffect)(() => {
              t3.current.callback = e3;
            }), t3.current.stableFn;
          };
        },
        1381: (e2, t2, r2) => {
          var n2;
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useComponentSwipeable = t2.SwipeablePlacement = void 0;
          let s2 = r2(4490), a2 = r2(8691);
          !(function(e3) {
            e3.TOP = "top", e3.BOTTOM = "bottom", e3.RIGHT = "right", e3.LEFT = "left";
          })(n2 || (t2.SwipeablePlacement = n2 = {}));
          let i2 = (e3) => {
            let { ref: t3, deltaY: r3, deltaX: s3, placement: a3 } = e3;
            requestAnimationFrame(() => {
              t3.current && (t3.current.style.willChange = "transform", t3.current.style.transform = a3 === n2.TOP || a3 === n2.BOTTOM ? "translateY(".concat(r3 || 0, "px)") : "translateX(".concat(s3 || 0, "px)"));
            });
          }, o2 = (e3) => {
            requestAnimationFrame(() => {
              e3.current && (e3.current.style.transition = "none", e3.current.style.willChange = "", e3.current.style.transform = "");
            });
          };
          t2.useComponentSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: l2, disableSwipe: c2, placement: u2, threshold: f } = e3, d = (0, a2.useCallbackRef)(() => {
              l2 && (o2(t3), l2());
            }), x = (0, a2.useCallbackRef)((e4) => {
              c2 || ((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3 } = e5;
                switch (a3) {
                  case n2.TOP:
                    r4 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.RIGHT:
                    s3 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.LEFT:
                    s3 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  default:
                    r4 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2 });
            }), p = (0, a2.useCallbackRef)((e4) => {
              !c2 && (((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3, threshold: i3 = 25 } = e5;
                if (!t4.current) return false;
                let o3 = i3 / 100 * (a3 === n2.TOP || a3 === n2.BOTTOM ? t4.current.offsetHeight : t4.current.offsetWidth);
                switch (a3) {
                  case n2.TOP:
                    return r4 < 0 && Math.abs(r4) >= o3;
                  case n2.RIGHT:
                    return s3 > 0 && s3 >= o3;
                  case n2.LEFT:
                    return s3 < 0 && Math.abs(s3) >= o3;
                  default:
                    return r4 > 0 && r4 >= o3;
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2, threshold: f }) ? l2 && (o2(t3), l2()) : o2(t3));
            });
            return {
              handlers: (0, s2.useSwipeable)({ onSwiped: p, onSwiping: x, trackMouse: true, trackTouch: true, ...r3 }),
              onCloseCallback: d
            };
          };
        },
        6699: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let n2 = r2(352), s2 = r2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: r3, throttleTimeout: a2 } = e3, i2 = (0, s2.useRef)(null), [o2, l2] = (0, s2.useState)(!!r3), c2 = (0, s2.useMemo)(
              () => (0, n2.throttle)(() => {
                l2(!r3), i2.current && window.clearTimeout(i2.current), i2.current = window.setTimeout(() => {
                  l2(!!r3);
                }, t3);
              }, a2),
              [t3, r3, a2]
            ), u2 = (0, s2.useCallback)(() => {
              l2(!!r3), i2.current && window.clearTimeout(i2.current);
            }, [r3]);
            return (0, s2.useEffect)(
              () => () => {
                i2.current && window.clearTimeout(i2.current);
              },
              []
            ), { state: o2, handleDebouncedToggle: c2, reset: u2 };
          };
        },
        5969: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.findOptimalFontSize = void 0;
          let n2 = r2(810), s2 = (e3) => {
            e3.style.wordBreak = "keep-all", e3.style.overflowWrap = "normal", e3.style.maxHeight = "none", e3.style.height = "auto", e3.style.overflow = "visible", Array.from(e3.children).forEach((e4) => {
              e4 instanceof HTMLElement && s2(e4);
            });
          };
          t2.findOptimalFontSize = (e3) => {
            let {
              container: t3,
              containerWidth: r3,
              containerHeight: n3,
              minFontSize: a2,
              maxFontSize: i2,
              lineHeight: o2,
              maxLines: l2
            } = e3, c2 = ((e4, t4, r4) => {
              let n4 = e4.cloneNode(true);
              return n4.style.cssText = "\n        position: absolute !important;\n        visibility: hidden !important;\n        pointer-events: none !important;\n        width: ".concat(
                t4,
                "px !important;\n    "
              ), s2(n4), n4.style.setProperty("--dynamic-line-height", String(r4)), document.body.appendChild(n4), n4;
            })(t3, r3, o2);
            try {
              let e4 = a2, t4 = i2, s3 = a2;
              for (; e4 <= t4; ) {
                let a3 = Math.floor((e4 + t4) / 2);
                c2.style.setProperty("--dynamic-font-size", "".concat(a3, "px"));
                let i3 = Math.min(l2 * a3 * o2, n3), u2 = c2.scrollHeight <= i3, f = c2.scrollWidth <= r3 + 1;
                u2 && f ? (s3 = a3, e4 = a3 + 1) : t4 = a3 - 1;
              }
              return s3 - 1;
            } finally {
              c2.remove();
            }
          }, t2.useDynamicText = (e3, r3) => {
            (0, n2.useLayoutEffect)(() => {
              if (null === e3) return;
              e3.style.setProperty("--dynamic-line-height", String(r3.lineHeight));
              let n3 = () => {
                let { width: n4, height: s4 } = e3.getBoundingClientRect(), a3 = e3.childNodes.length > 0;
                if (0 === n4 || 0 === s4 || !a3) return;
                let i2 = (0, t2.findOptimalFontSize)({ container: e3, containerWidth: n4, containerHeight: s4, ...r3 });
                e3.style.setProperty("--dynamic-font-size", "".concat(i2, "px"));
              }, s3 = new ResizeObserver(n3), a2 = new MutationObserver(n3);
              return s3.observe(e3), a2.observe(e3, { childList: true, characterData: true, subtree: true }), document.fonts.ready.then(n3), n3(), () => {
                s3.disconnect(), a2.disconnect();
              };
            }, [e3, r3]);
          };
        },
        2101: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useElementOffsetY = void 0;
          let n2 = r2(810), s2 = r2(2067), a2 = r2(2767);
          t2.useElementOffsetY = (e3) => {
            let [t3, r3] = (0, a2.useForceUpdateRef)(), [i2, o2] = (0, n2.useState)(), l2 = (0, n2.useCallback)(() => {
              let e4 = null == t3 ? void 0 : t3.getBoundingClientRect();
              e4 && o2(e4.y);
            }, [t3]);
            return (0, n2.useLayoutEffect)(l2), (0, s2.useScroll)({ onScroll: l2, elementRef: e3 }), { forceUpdateRefCallback: r3, offsetY: i2 };
          };
        },
        2767: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForceUpdateRef = void 0;
          let n2 = r2(810);
          t2.useForceUpdateRef = () => {
            let [e3, t3] = (0, n2.useState)(null);
            return [
              e3,
              (0, n2.useCallback)((e4) => {
                t3((t4) => t4 !== e4 ? e4 : t4);
              }, [])
            ];
          };
        },
        245: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForwardRef = void 0;
          let n2 = r2(810);
          t2.useForwardRef = function(e3, t3) {
            let r3 = (0, n2.useRef)(t3);
            return (0, n2.useEffect)(() => {
              e3 && ("function" == typeof e3 ? e3(r3.current) : e3.current = r3.current);
            }, [e3]), r3;
          };
        },
        5663: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIntersectionObserver = t2.createIntersectionObserver = t2.getElementNameByDataAttribute = t2.isInViewportNow = t2.defaultOptions = void 0;
          let n2 = r2(810), { innerWidth: s2 = 0, innerHeight: a2 = 0 } = window;
          function i2(e3) {
            let { top: t3, right: r3, bottom: n3, left: i3 } = e3.getBoundingClientRect();
            return (t3 >= 0 && t3 <= a2 || n3 >= 0 && n3 <= a2) && (i3 >= 0 && i3 <= s2 || r3 >= 0 && r3 <= s2);
          }
          function o2(e3) {
            var t3, r3;
            let n3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "data-intersection-property-id";
            return null != (r3 = null == e3 || null == (t3 = e3.getAttribute) ? void 0 : t3.call(e3, n3)) ? r3 : e3.attributes[0];
          }
          function l2(e3, t3) {
            let r3 = new IntersectionObserver((t4) => {
              t4.forEach((t5) => {
                e3(t5, r3);
              });
            }, t3);
            return r3;
          }
          t2.defaultOptions = { threshold: 0, preflightCheck: true }, t2.isInViewportNow = i2, t2.getElementNameByDataAttribute = o2, t2.createIntersectionObserver = l2, t2.useIntersectionObserver = function(e3, r3, s3) {
            let [{ freezeOnceVisible: a3, preflightCheck: c2, ...u2 }, f = false] = "boolean" == typeof r3 || void 0 === r3 ? [t2.defaultOptions, r3] : [{ ...t2.defaultOptions, ...r3 }, s3], [d, x] = (0, n2.useState)({}), p = (0, n2.useRef)(/* @__PURE__ */ new Set()), _ = (0, n2.useMemo)(
              () => f ? null : l2((e4) => {
                let t3 = o2(e4.target);
                if (t3 && _) {
                  if (p.current.has(t3)) return;
                  x((r4) => ({ ...r4, [t3]: { isIntersecting: e4.isIntersecting } })), a3 && e4.isIntersecting && (p.current.add(t3), _.unobserve(e4.target));
                }
              }, u2),
              [f]
            );
            return (0, n2.useLayoutEffect)(
              () => (_ && !f && e3.forEach((e4) => {
                if (e4.current) {
                  let t3 = false;
                  if (c2 && (t3 = i2(e4.current))) {
                    let t4 = o2(e4.current);
                    x((e5) => ({ ...e5, [t4]: { isIntersecting: true } }));
                  }
                  t3 || _.observe(e4.current);
                }
              }), () => {
                _ && _.disconnect();
              }),
              [f, _, e3.length]
            ), d;
          };
        },
        9019: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIsomorphicEffect = void 0;
          let n2 = r2(810);
          t2.useIsomorphicEffect = "undefined" != typeof document ? n2.useLayoutEffect : n2.useEffect;
        },
        5188: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useKeyboardNavigation = void 0;
          let n2 = r2(810);
          function s2(e3, t3) {
            return e3.current ? Array.from(t3 ? e3.current.querySelectorAll(t3) : e3.current.children) : [];
          }
          t2.useKeyboardNavigation = function(e3) {
            let t3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, { navigationItemsSelector: r3, activeAttributeName: a2 = "aria-selected" } = t3, i2 = (0, n2.useCallback)(
              (t4) => {
                let n3 = s2(e3, r3);
                if (!n3.length) return;
                let a3 = t4.target, i3 = n3.indexOf(a3);
                if (-1 === i3) return;
                let [o2] = n3, l2 = n3.at(-1), c2 = null;
                switch (t4.key) {
                  case "ArrowLeft":
                  case "ArrowUp":
                    c2 = n3[i3 - 1] || l2;
                    break;
                  case "ArrowRight":
                  case "ArrowDown":
                    c2 = n3[i3 + 1] || o2;
                    break;
                  case "Home":
                    c2 = o2;
                    break;
                  case "End":
                    c2 = l2;
                }
                null !== c2 && (c2.focus(), t4.preventDefault());
              },
              [r3, e3]
            );
            (0, n2.useEffect)(() => {
              let t4 = e3.current;
              return null == t4 || t4.addEventListener("keydown", i2), () => null == t4 ? void 0 : t4.removeEventListener("keydown", i2);
            }, [e3, i2]), (0, n2.useEffect)(() => {
              s2(e3, r3).forEach((e4) => {
                e4.hasAttribute(a2) && ("true" === e4.getAttribute(a2) ? e4.tabIndex = 0 : e4.tabIndex = -1);
              });
            });
          };
        },
        4395: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.usePopoverSwipeable = void 0;
          let n2 = r2(810), s2 = r2(1381);
          t2.usePopoverSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: a2, disableSwipe: i2, placement: o2, threshold: l2 } = e3, c2 = (0, n2.useMemo)(() => {
              switch (o2) {
                case "top":
                case "top-end":
                case "top-start":
                  return s2.SwipeablePlacement.TOP;
                case "right":
                case "right-end":
                case "right-start":
                  return s2.SwipeablePlacement.RIGHT;
                case "left":
                case "left-end":
                case "left-start":
                  return s2.SwipeablePlacement.LEFT;
                default:
                  return s2.SwipeablePlacement.BOTTOM;
              }
            }, [o2]);
            return (0, s2.useComponentSwipeable)({
              ref: t3,
              swipeableProps: r3,
              onClose: a2,
              disableSwipe: i2,
              placement: c2,
              threshold: l2
            });
          };
        },
        2947: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useResize = void 0;
          let n2 = r2(810), s2 = r2(361);
          t2.useResize = (e3, t3) => {
            (0, n2.useEffect)(() => {
              let r3 = (0, s2.getElementFromRefOrElement)(t3);
              if (null === r3) return;
              let n3 = null != r3 ? r3 : document.documentElement, a2 = new ResizeObserver(e3);
              return a2.observe(n3), () => a2.disconnect();
            }, [t3, e3]);
          };
        },
        998: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useReturnValue = void 0, t2.useReturnValue = (e3) => e3();
        },
        2067: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useScroll = void 0;
          let n2 = r2(810), s2 = r2(361), a2 = r2(6699);
          t2.useScroll = (e3) => {
            let { onScroll: t3, listenIsScrolling: r3, elementRef: i2 } = e3, { state: o2, handleDebouncedToggle: l2 } = (0, a2.useDebouncedToggle)({
              delay: 1e3,
              throttleTimeout: 100
            }), c2 = (0, n2.useCallback)(() => {
              r3 && l2(), null == t3 || t3();
            }, [r3, l2, t3]);
            return (0, n2.useEffect)(() => {
              let e4 = (0, s2.getElementFromRefOrElement)(i2);
              if (null === e4) return;
              let t4 = null != e4 ? e4 : window, r4 = { capture: true, passive: true };
              return t4.addEventListener("scroll", c2, r4), () => t4.removeEventListener("scroll", c2, r4);
            }, [i2, c2]), o2;
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        3642: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Input = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(9110), l2 = n2(r2(9160)), c2 = (e3) => {
            let {
              containerClassName: t3,
              inputClassName: r3,
              actionsClassName: n3,
              icon: c3 = null,
              actions: u2 = null,
              disabled: f,
              forwardRef: d,
              value: x,
              size: p = "xxxs",
              variant: _ = "primary",
              ...m
            } = e3, v = (0, o2.useForwardRef)(d, null), g = (0, i2.useCallback)(() => {
              var e4;
              null == (e4 = v.current) || e4.focus();
            }, [v]);
            return (0, s2.jsxs)("div", {
              className: (0, a2.clsx)(
                l2.default.root,
                {
                  [l2.default.root_disabled]: f,
                  [l2.default["root_size_".concat(p)]]: p,
                  [l2.default["root_variant_".concat(_)]]: _
                },
                t3
              ),
              onClick: g,
              children: [
                c3,
                (0, s2.jsx)("input", {
                  className: (0, a2.clsx)(l2.default.input, r3, { [l2.default.textShadowing]: m.readOnly }),
                  ref: v,
                  value: x,
                  disabled: f,
                  ...m
                }),
                (0, s2.jsx)("div", { className: (0, a2.clsx)(l2.default.actions, n3), children: u2 })
              ]
            });
          };
          t2.Input = (0, i2.forwardRef)((e3, t3) => (0, s2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        352: (e2) => {
          e2.exports = s;
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(a, 2));
        }
      }, o = {};
      function l(e2) {
        var t2 = o[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = o[e2] = { exports: {} };
        return i[e2].call(r2.exports, r2, r2.exports, l), r2.exports;
      }
      l.d = (e2, t2) => {
        for (var r2 in t2) l.o(t2, r2) && !l.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, l.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), l.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var c = {};
      (() => {
        Object.defineProperty(c, "__esModule", { value: true }), c.Input = void 0;
        var e2 = l(3642);
        Object.defineProperty(c, "Input", {
          enumerable: true,
          get: function() {
            return e2.Input;
          }
        });
      })();
      var u = c.Input;
      c.__esModule;
    },
    20406: (e, t, r) => {
      "use strict";
      r.d(t, { SpeedButton: () => p });
      var n = r(54486), s = r(61910), a = r(43426), i = r(31500), o = r(8817), l = r(77881), c = r(5956), u = r(91350), f = r(66505);
      let d = Object.keys(f.l).map(Number).sort((e2, t2) => e2 - t2), x = (e2) => {
        let {
          className: t2,
          variant: r2 = "text",
          iconSize: x2,
          onClick: p2,
          iconClassName: _,
          withRipple: m = false,
          size: v = "s",
          forwardRef: g,
          children: b,
          color: y,
          disabled: h = false,
          isIconCentered: k = false
        } = e2, E = (0, u.useSonata)(), { formatMessage: w } = (0, a.A)(), j = (null == E ? void 0 : E.state.playerState.speed.value) || 1, O = d.indexOf(j) || 0, [R, C] = (0, s.useState)(O), S = d[R], P = (0, f.C)(S, k), A = (0, o.c)(() => {
          let e3 = (R + 1) % d.length;
          C(e3), null == E || E.setSpeed(Number(d[e3])), null == p2 || p2();
        });
        return (0, s.useEffect)(() => {
          let e3 = null == E ? void 0 : E.state.playerState.speed.onChange(() => {
            let e4 = E.state.playerState.speed.value;
            C(d.indexOf(e4) || 0);
          });
          return () => {
            null == e3 || e3();
          };
        }, [E]), (0, n.jsx)(l.$, {
          className: t2,
          color: y,
          withRipple: m,
          variant: r2,
          size: v,
          radius: "xxxl",
          "aria-label": w({ id: "interface-actions.speed" }, { speed: S }),
          onClick: A,
          icon: (0, n.jsx)(c.Icon, { size: x2, className: _, variant: P }),
          ref: g,
          disabled: h,
          ...(0, i.Am)(i.S7.SPEED_BUTTON),
          children: b
        });
      }, p = (0, s.forwardRef)((e2, t2) => (0, n.jsx)(x, { forwardRef: t2, ...e2 }));
    },
    20576: (e, t, r) => {
      "use strict";
      r.d(t, { ExplicitMarkIcon: () => m });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(43426), l = r(31500), c = r(27510), u = r(5956), f = r(60440), d = r(92946), x = r(26086), p = r(13872), _ = r.n(p);
      let m = (0, a.PA)((e2) => {
        let {
          className: t2,
          getDescriptionTexts: r2,
          trackId: a2,
          containerClassName: p2,
          variant: m2,
          size: v = "xxxs",
          ...g
        } = e2, { formatMessage: b } = (0, o.A)(), {
          settings: { isMobile: y }
        } = (0, f.useStore)(), [h, k] = (0, i.useState)(null), E = (0, c.L)(() => {
          switch (m2) {
            case d.J.E:
              return "explicit";
            case d.J.NUMERIC:
              return "adult";
            case d.J.EXCLAMATION:
          }
          return "exclamation";
        }), w = (0, i.useMemo)(() => b({ id: "extra-explicit.explicit-mark" }), [b]);
        (0, i.useEffect)(() => {
          r2 && r2().then(k);
        }, [r2, a2]);
        let j = (null == h ? void 0 : h.join("\n")) || "", O = !!(null == h ? void 0 : h.length) && !y, R = j.length > 0 ? j : w;
        return (0, n.jsx)(x.TooltipWithTitle, {
          description: j,
          placement: "bottom-start",
          enabled: O,
          children: (0, n.jsx)("span", {
            className: p2,
            children: (0, n.jsx)(u.Icon, {
              className: (0, s.$)(_().explicitMark, t2),
              "aria-label": R,
              variant: E,
              size: v,
              ...g,
              ...(0, l.Am)(l.S7.EXPLICIT_MARK_ICON)
            })
          })
        });
      });
    },
    21940: (e, t, r) => {
      "use strict";
      r.d(t, { StateEventScript: () => n }), r(54486);
      let n = (e2) => {
        let { nonce: t2 } = e2;
        return null;
      };
    },
    22038: (e) => {
      e.exports = { icon: "CardLikes_icon__l95lW", root: "CardLikes_root__g8ala" };
    },
    22674: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { Shimmer: () => o, __esModule: () => l });
      var n = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        702: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "JD1RZC0EtdwegdYvGm6W",
            root_active: "K4G7ASZk9TWzXzAWMZKF",
            "gradient-horizontal": "GTZfWL5aq48rDurR2xQI",
            root_radius_xs: "PyJ4CgcZYC2CpTwW_q0e",
            root_radius_s: "Ig8cmdGxncIa4g0mjlzw",
            root_radius_m: "lJbeO5iovzBwUTpu7hFA",
            root_radius_l: "Gc3Wyk8uCohdTadkf7NR",
            root_radius_xl: "iKi9AOB1TOi3ZWzmbCkq",
            root_radius_xxl: "nYTL841hItMUZhvJq_ob",
            root_radius_xxxl: "LXGqiB6_V45plhG242mA",
            root_radius_round: "psTzstoF82tSOz1JHMB3"
          };
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        3186: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Shimmer = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = n2(r2(702));
          t2.Shimmer = function(e3) {
            let { isActive: t3, className: r3, radius: n3 = "m", width: o2, height: l2, children: c, ...u } = e3, f = {};
            return void 0 !== o2 && (f.width = "string" == typeof o2 ? o2 : "".concat(o2, "px")), void 0 !== l2 && (f.height = "string" == typeof l2 ? l2 : "".concat(l2, "px")), (0, s2.jsx)("div", {
              className: (0, a2.clsx)(
                i2.default.root,
                i2.default["root_radius_".concat(n3)],
                { [i2.default.root_active]: t3 },
                r3
              ),
              "aria-live": t3 ? "polite" : "off",
              "aria-busy": t3,
              ...u,
              style: f,
              children: c
            });
          };
        }
      }, s = {};
      function a(e2) {
        var t2 = s[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = s[e2] = { exports: {} };
        return n[e2].call(r2.exports, r2, r2.exports, a), r2.exports;
      }
      a.d = (e2, t2) => {
        for (var r2 in t2) a.o(t2, r2) && !a.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, a.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), a.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var i = {};
      (() => {
        Object.defineProperty(i, "X", { value: true }), i.q = void 0;
        var e2 = a(3186);
        Object.defineProperty(i, "q", {
          enumerable: true,
          get: function() {
            return e2.Shimmer;
          }
        });
      })();
      var o = i.q, l = i.X;
    },
    22808: (e) => {
      e.exports = {
        root: "PlusModalLogoBlock_root__cKh28",
        icon: "PlusModalLogoBlock_icon__fMixB",
        icon_ru: "PlusModalLogoBlock_icon_ru__JAn4U",
        icon_en: "PlusModalLogoBlock_icon_en__OmrOY"
      };
    },
    23035: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuLikeItem: () => l });
      var n = r(54486), s = r(47713), a = r(31500), i = r(5956), o = r(61958);
      let l = (e2) => {
        let { isLiked: t2, onClick: r2, disabled: l2, className: c } = e2;
        return (0, n.jsx)(o.Dr, {
          className: c,
          onClick: r2,
          disabled: l2,
          icon: (0, n.jsx)(i.Icon, { variant: t2 ? "liked" : "like", size: "xxs" }),
          role: "menuitemcheckbox",
          "aria-checked": t2,
          ...(0, a.Am)(a.S7.CONTEXT_MENU_LIKE_BUTTON),
          children: (0, n.jsx)(s.A, { id: "interface-actions.like" })
        });
      };
    },
    23143: (e, t, r) => {
      "use strict";
      r.d(t, { TrailerTooltip: () => i });
      var n = r(54486), s = r(43426), a = r(93666);
      let i = (e2) => {
        let { children: t2 } = e2, { formatMessage: r2 } = (0, s.A)();
        return (0, n.jsx)(a.m_, {
          placement: "top",
          offsetOptions: 8,
          hoverSettings: { delay: { open: 500, close: 0 } },
          text: r2({ id: "entity-names.trailer" }),
          isFocusEnabled: false,
          children: t2
        });
      };
    },
    23834: (e, t, r) => {
      "use strict";
      r.d(t, { WithOffline: () => l });
      var n = r(28303), s = r(67454), a = r(88416), i = r(47339), o = r(60440);
      let l = (0, n.PA)((e2) => {
        let { fallback: t2, children: r2 } = e2, n2 = (0, a.useContainer)(), { slam: l2 } = (0, o.useStore)(), c = n2.get(s.U2);
        return (0, i.g)(c) || l2.isOfflineModeEnabled ? r2 : t2;
      });
    },
    24036: (e, t, r) => {
      "use strict";
      r.d(t, { Link: () => p });
      var n = r(54486), s = r(28303), a = r(78179), i = r.n(a), o = r(61910), l = r(8817), c = r(65749), u = r(60440), f = r(1756), d = r(85105);
      let x = (e2) => {
        let [t2, r2] = (0, o.useState)(false), s2 = (0, l.c)(() => {
          r2(true);
        });
        return (0, n.jsx)(i(), { prefetch: t2, ...e2, onMouseEnter: s2 });
      }, p = (0, s.PA)((e2) => {
        let { href: t2, component: r2, ...s2 } = e2, { experiments: a2 } = (0, u.useStore)(), { href: l2, target: p2, rel: _ } = (0, d.u)(null != t2 ? t2 : ""), m = a2.checkExperiment(f.z.WebNextDisablePrefetchRequests, "on"), v = a2.checkExperiment(f.z.WebNextDisablePrefetchRequests, "hover"), g = (0, o.isValidElement)(r2) ? r2 : (function(e3, t3, r3) {
          return e3 ? t3 ? (0, n.jsx)(i(), { prefetch: false }) : r3 ? (0, n.jsx)(x, { href: e3 }) : (0, n.jsx)(i(), {}) : (0, n.jsx)("a", {});
        })(t2, m, v);
        return (0, n.jsx)(c.N, { component: g, href: t2 ? l2 : void 0, target: p2, rel: _, ...s2 });
      });
    },
    24126: (e, t, r) => {
      "use strict";
      r.d(t, { VerticalListItemShimmer: () => l });
      var n = r(54486), s = r(50420), a = r(22674), i = r(43222), o = r.n(i);
      let l = (e2) => {
        let { isActive: t2, className: r2, ariaLabel: i2 } = e2;
        return (0, n.jsxs)("div", {
          "aria-label": i2,
          "aria-live": t2 ? "polite" : "off",
          "aria-busy": t2,
          className: (0, s.$)(o().root, r2),
          children: [
            (0, n.jsxs)("div", {
              className: o().infoContainer,
              children: [
                (0, n.jsx)(a.Shimmer, { isActive: t2, className: o().cover, radius: "s" }),
                (0, n.jsx)("div", {
                  className: o().textContainer,
                  children: (0, n.jsx)(a.Shimmer, { isActive: t2, className: o().title, radius: "l" })
                })
              ]
            }),
            (0, n.jsx)(a.Shimmer, { isActive: t2, className: o().action, radius: "l" })
          ]
        });
      };
    },
    24491: (e, t, r) => {
      "use strict";
      r.d(t, { PlayButtonWithCover: () => g });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(43426), l = r(31500), c = r(6971), u = r(3728), f = r(60440), d = r(95405), x = r(58376), p = r(61993), _ = r(37257), m = r.n(_);
      let v = (0, a.PA)((e2) => {
        let {
          className: t2,
          isAvailable: r2,
          isDisliked: a2,
          coverUri: i2,
          title: _2,
          onPlayButtonClick: v2,
          isPlaying: g2,
          isCurrent: b,
          radius: y,
          isPlayButtonLoading: h,
          isLoading: k,
          shouldShowControl: E = true,
          ariaDescribedBy: w,
          ignoreDislikedStyles: j,
          entityCoverStyle: O,
          forwardRef: R,
          playButtonIconSize: C,
          alt: S,
          withLoadingIndicator: P,
          coverClassName: A,
          controlClassName: T
        } = e2, { formatMessage: H } = (0, o.A)(), {
          settings: { isMobile: M }
        } = (0, f.useStore)();
        return (0, n.jsx)("div", {
          className: (0, s.$)(m().root, t2, {
            [m().root_disabled]: !r2,
            [m().root_current]: b,
            [m().root_disliked]: a2 && !j,
            [m().root_playing]: g2
          }),
          ...(0, l.Am)(l.S7.PLAY_BUTTON_WITH_COVER),
          children: (0, n.jsxs)(c.Paper, {
            className: (0, s.$)(m().cover, A),
            radius: y,
            children: [
              (0, n.jsx)(d.B, {
                className: m().coverImage,
                src: i2,
                size: 100,
                alt: null != S ? S : H({ id: "entity-names.track-name" }, { trackName: _2 }),
                fit: "cover",
                withAvatarReplace: true,
                isAvailable: r2,
                fallbackIconSize: "xs",
                style: O,
                withLoadingIndicator: P
              }),
              E && (0, n.jsxs)("div", {
                className: (0, s.$)(m().control, T),
                children: [
                  !k && (0, n.jsx)(p.PlayingAnimation, { stopAnimation: !g2, className: m().playingAnimation }),
                  k && M && (0, n.jsx)(u.y, { size: "xs", className: m().spinner }),
                  !M && (0, n.jsx)(x.PlayButton, {
                    ref: R,
                    variant: "filled",
                    className: (0, s.$)(m().playButton, { [m().playButton_loading]: h }),
                    iconClassName: m().playButtonIcon,
                    isPlaying: g2,
                    onClick: v2,
                    iconSize: C,
                    ariaDescribedBy: w,
                    disabled: !r2
                  })
                ]
              })
            ]
          })
        });
      }), g = (0, i.forwardRef)((e2, t2) => (0, n.jsx)(v, { forwardRef: t2, ...e2 }));
    },
    24624: (e, t, r) => {
      "use strict";
      r.d(t, { YanalyticsScript: () => i });
      var n = r(54486), s = r(85097), a = r(78299);
      let i = (e2) => {
        let { nonce: t2 } = e2, { init: r2 } = (0, a.R)();
        return (0, n.jsx)(s.default, {
          id: "yanalytics-script",
          src: "https://yastatic.net/s3/distribution/yanalytics/v7/yanalytics.js",
          nonce: null != t2 ? t2 : void 0,
          onReady: r2
        });
      };
    },
    24786: (e, t, r) => {
      "use strict";
      r.d(t, { LikeButton: () => _ });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(43426), l = r(31500), c = r(45427), u = r(77881), f = r(5956), d = r(7482), x = r.n(d);
      let p = (0, a.PA)((e2) => {
        let {
          className: t2,
          variant: r2 = "text",
          iconSize: a2,
          isLiked: i2 = false,
          onClick: d2,
          iconClassName: p2,
          withRipple: _2 = false,
          size: m = "s",
          forwardRef: v,
          children: g,
          color: b,
          disabled: y = false,
          "aria-label": h
        } = e2, { formatMessage: k } = (0, o.A)(), {
          scaleAnimation: E,
          unscaleAnimation: w,
          handleAnimationEnd: j,
          handleClick: O
        } = (0, c.C)({ shouldStartFromUnscale: i2, onClick: d2 }), R = i2 ? "liked" : "like";
        return (0, n.jsx)(u.$, {
          className: (0, s.$)(x().root, { [x().animation_scaled]: E, [x().animation_unscaled]: w }, t2),
          color: b,
          onAnimationEnd: j,
          withRipple: _2,
          variant: r2,
          size: m,
          radius: "xxxl",
          "aria-label": h || k({ id: "interface-actions.like" }),
          "aria-pressed": i2,
          onClick: O,
          icon: (0, n.jsx)(f.Icon, { size: a2, className: (0, s.$)(x().icon, p2), variant: R }),
          ref: v,
          disabled: y,
          ...(0, l.Am)(l.S7.LIKE_BUTTON),
          children: g
        });
      }), _ = (0, i.forwardRef)((e2, t2) => (0, n.jsx)(p, { forwardRef: t2, ...e2 }));
    },
    24892: (e) => {
      e.exports = {
        inner: "PromoLandingHeader_inner__hKls8",
        header: "PromoLandingHeader_header__gKwtu",
        container: "PromoLandingHeader_container__JD5rw",
        leftBlock: "PromoLandingHeader_leftBlock__jEcOR",
        title: "PromoLandingHeader_title__LqClE",
        plusButton: "PromoLandingHeader_plusButton__27yUf",
        backdrop: "PromoLandingHeader_backdrop__AYF3a",
        root: "PromoLandingHeader_root__zLOun",
        root_visible: "PromoLandingHeader_root_visible__yB3YQ"
      };
    },
    25554: (e) => {
      e.exports = {
        root: "Disclaimer_root__ciLA2",
        container: "Disclaimer_container__cB_wK",
        title: "Disclaimer_title__I5hOj",
        text: "Disclaimer_text__2Yo3R",
        link: "Disclaimer_link__4UMOz",
        buttons: "Disclaimer_buttons__mpL9o",
        button: "Disclaimer_button__qIuMB",
        shimmer: "Disclaimer_shimmer__Bg0HE"
      };
    },
    25582: (e) => {
      e.exports = { root: "TabCarousel_root__8DoRy" };
    },
    25933: (e) => {
      e.exports = {
        message: "NotificationCopy_message__zVlYi",
        icon: "NotificationCopy_icon__FTmM9",
        title: "NotificationCopy_title__UEiU0"
      };
    },
    26086: (e, t, r) => {
      "use strict";
      r.d(t, { TooltipWithTitle: () => u });
      var n = r(54486), s = r(31500), a = r(93666), i = r(97800), o = r(64794), l = r.n(o);
      let c = { padding: 8 }, u = (e2) => {
        let { description: t2, enabled: r2, title: o2, placement: u2 = "top", children: f } = e2;
        return (0, n.jsxs)(a.m_, {
          enabled: r2,
          offsetOptions: 4,
          shiftOptions: c,
          flipOptions: c,
          placement: u2,
          children: [
            f,
            (0, n.jsx)(a.ZI, {
              className: l().root,
              ...(0, s.Am)(s.S7.TOOLTIP_WITH_TITLE),
              children: (0, n.jsxs)("div", {
                className: l().text,
                children: [
                  o2 && (0, n.jsx)(i.Caption, { variant: "span", type: "text", size: "s", weight: "bold", children: o2 }),
                  (0, n.jsx)(i.Caption, {
                    variant: "span",
                    type: "text",
                    size: "s",
                    weight: "normal",
                    className: l().description,
                    children: t2
                  })
                ]
              })
            })
          ]
        });
      };
    },
    27314: (e, t, r) => {
      "use strict";
      r.d(t, { Schema: () => a });
      var n = r(54486), s = r(15209);
      let a = (e2) => {
        let { value: t2 } = e2, r2 = { "@context": "https://schema.org", ...t2 };
        return (0, n.jsx)("script", {
          type: "application/ld+json",
          dangerouslySetInnerHTML: { __html: (0, s.stringifyJSONSafely)(r2) }
        });
      };
    },
    27754: (e, t, r) => {
      "use strict";
      r.d(t, { BaseNotificationLike: () => y });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(31500), l = r(8817), c = r(39610), u = r(97800), f = r(43426), d = r(47713), x = r(48861), p = r(60440), _ = r(95405), m = r(24036), v = r(22096), g = r(15497), b = r.n(g);
      let y = (0, a.PA)((e2) => {
        let {
          closeToast: t2,
          entityVariant: r2,
          entityUrl: a2,
          collectionUrl: g2,
          entityTitle: y2,
          coverUri: h,
          isLiked: k,
          className: E,
          withLink: w = true
        } = e2, { fullscreenPlayer: j, fullscreenVideoPlayer: O } = (0, p.useStore)(), R = r2 === x.c.ARTIST, C = (() => {
          let { formatMessage: e3 } = (0, f.A)();
          return (0, i.useCallback)(
            (t3) => {
              let { entityVariant: r3, values: s2, entityTitle: a3 } = t3;
              switch (r3) {
                case x.c.TRACK:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.track-added-to-collection", values: s2 }),
                    ariaLabel: e3({ id: "notifications-info.track-added-to-collection-aria-label" }, { entity: a3 })
                  };
                case x.c.PLAYLIST:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.playlist-added-to-collection", values: s2 }),
                    ariaLabel: e3({ id: "notifications-info.playlist-added-to-collection-aria-label" }, { entity: a3 })
                  };
                case x.c.ALBUM:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.album-added-to-collection", values: s2 }),
                    ariaLabel: e3({ id: "notifications-info.album-added-to-collection-aria-label" }, { entity: a3 })
                  };
                case x.c.FAIRY_TALE:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.fairytale-added-to-collection", values: s2 }),
                    ariaLabel: e3(
                      { id: "notifications-info.fairytale-added-to-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.ARTIST:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.artist-added-to-collection", values: s2 }),
                    ariaLabel: e3({ id: "notifications-info.artist-added-to-collection-aria-label" }, { entity: a3 })
                  };
                case x.c.PODCAST:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.podcast-added-to-collection", values: s2 }),
                    ariaLabel: e3({ id: "notifications-info.podcast-added-to-collection-aria-label" }, { entity: a3 })
                  };
                case x.c.PODCAST_EPISODE:
                  return {
                    caption: (0, n.jsx)(d.A, {
                      id: "notifications-info.podcast-episode-added-to-collection",
                      values: s2
                    }),
                    ariaLabel: e3(
                      { id: "notifications-info.podcast-episode-added-to-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.AUDIOBOOK:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.audiobook-added-to-collection", values: s2 }),
                    ariaLabel: e3(
                      { id: "notifications-info.audiobook-added-to-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.AUDIOBOOK_EPISODE:
                  return {
                    caption: (0, n.jsx)(d.A, {
                      id: "notifications-info.audiobook-episode-added-to-shelf",
                      values: s2
                    }),
                    ariaLabel: e3(
                      { id: "notifications-info.audiobook-episode-added-to-shelf-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.CLIP:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.clip-added-to-collection", values: s2 }),
                    ariaLabel: e3({ id: "notifications-info.clip-added-to-collection-aria-label" }, { entity: a3 })
                  };
              }
            },
            [e3]
          );
        })(), S = (() => {
          let { formatMessage: e3 } = (0, f.A)();
          return (0, i.useCallback)(
            (t3) => {
              let { entityVariant: r3, values: s2, entityTitle: a3 } = t3;
              switch (r3) {
                case x.c.TRACK:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.track-removed-from-collection", values: s2 }),
                    ariaLabel: e3({ id: "notifications-info.track-removed-to-collection-aria-label" }, { entity: a3 })
                  };
                case x.c.PLAYLIST:
                  return {
                    caption: (0, n.jsx)(d.A, {
                      id: "notifications-info.playlist-removed-from-collection",
                      values: s2
                    }),
                    ariaLabel: e3(
                      { id: "notifications-info.playlist-removed-from-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.ALBUM:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.album-removed-from-collection", values: s2 }),
                    ariaLabel: e3(
                      { id: "notifications-info.album-removed-from-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.FAIRY_TALE:
                  return {
                    caption: (0, n.jsx)(d.A, {
                      id: "notifications-info.fairytale-removed-from-collection",
                      values: s2
                    }),
                    ariaLabel: e3(
                      { id: "notifications-info.fairytale-removed-from-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.ARTIST:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.artist-removed-from-collection", values: s2 }),
                    ariaLabel: e3(
                      { id: "notifications-info.artist-removed-from-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.PODCAST:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.podcast-removed-from-collection", values: s2 }),
                    ariaLabel: e3(
                      { id: "notifications-info.podcast-remove-from-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.PODCAST_EPISODE:
                  return {
                    caption: (0, n.jsx)(d.A, {
                      id: "notifications-info.podcast-episode-removed-from-collection",
                      values: s2
                    }),
                    ariaLabel: e3(
                      { id: "notifications-info.podcast-episode-removed-from-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.AUDIOBOOK:
                  return {
                    caption: (0, n.jsx)(d.A, {
                      id: "notifications-info.audiobook-removed-from-collection",
                      values: s2
                    }),
                    ariaLabel: e3(
                      { id: "notifications-info.audiobook-removed-from-collection-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.AUDIOBOOK_EPISODE:
                  return {
                    caption: (0, n.jsx)(d.A, {
                      id: "notifications-info.audiobook-episode-removed-from-shelf",
                      values: s2
                    }),
                    ariaLabel: e3(
                      { id: "notifications-info.audiobook-episode-removed-from-shelf-aria-label" },
                      { entity: a3 }
                    )
                  };
                case x.c.CLIP:
                  return {
                    caption: (0, n.jsx)(d.A, { id: "notifications-info.clip-removed-from-collection", values: s2 }),
                    ariaLabel: e3({ id: "notifications-info.clip-removed-from-collection-aria-label" }, { entity: a3 })
                  };
              }
            },
            [e3]
          );
        })(), P = (0, l.c)(() => {
          j.modal.isOpened && j.modal.close(), O.modal.isOpened && O.modal.close();
        }), A = (0, i.useMemo)(
          () => a2 && y2 && w ? (0, n.jsx)(m.Link, {
            className: b().entityLink,
            href: a2,
            onClick: P,
            children: (0, n.jsxs)(u.Caption, {
              className: b().entityTitle,
              variant: "span",
              type: "controls",
              size: "m",
              lineClamp: 1,
              children: [" ", y2, " "]
            })
          }) : y2 ? (0, n.jsxs)(u.Caption, {
            className: b().entityTitle,
            variant: "span",
            type: "controls",
            size: "m",
            lineClamp: 1,
            title: y2,
            children: [" ", y2, " "]
          }) : void 0,
          [y2, a2, P, w]
        ), T = (0, i.useMemo)(() => {
          let e3 = {
            entity: A,
            collection: (e4) => w ? (0, n.jsx)(m.Link, {
              className: b().collectionLink,
              href: g2,
              onClick: P,
              children: (0, n.jsxs)(u.Caption, {
                className: b().collectionTitle,
                variant: "span",
                type: "controls",
                size: "m",
                lineClamp: 1,
                children: [" ", e4, " "]
              })
            }) : (0, n.jsxs)(u.Caption, {
              className: b().collectionTitle,
              variant: "span",
              type: "controls",
              size: "m",
              lineClamp: 1,
              children: [" ", e4, " "]
            })
          };
          return k ? C({ entityVariant: r2, values: e3, entityTitle: y2 }) : S({ entityVariant: r2, values: e3, entityTitle: y2 });
        }, [g2, r2, P, k, A, y2, C, S, w]);
        return (0, n.jsx)(v.BaseNotification, {
          className: (0, s.$)(b().root, E),
          message: (0, n.jsxs)(n.Fragment, {
            children: [
              (0, n.jsx)(c.q, { children: (0, n.jsx)("p", { role: "alert", "aria-label": T.ariaLabel }) }),
              (0, n.jsx)(u.Caption, {
                className: b().text,
                variant: "div",
                type: "controls",
                size: "m",
                ...(0, o.Am)(o.S7.BASE_NOTIFICATION_LIKE_TEXT),
                "aria-hidden": true,
                children: T.caption
              })
            ]
          }),
          cover: (0, n.jsx)(_.B, {
            className: b().image,
            src: h,
            size: 100,
            fit: "cover",
            alt: y2,
            withAvatarReplace: true
          }),
          coverRadius: R ? "round" : "s",
          closeToast: t2
        });
      });
    },
    29070: (e, t, r) => {
      "use strict";
      r.d(t, { Copyrights: () => h, Footer: () => k });
      var n = r(54486), s = r(50420), a = r(28303), i = r(43426), o = r(47713), l = r(97800), c = r(22628), u = r(66904), f = r(33427), d = r(60440), x = r(1756), p = (function(e2) {
        return e2.YANDEX = "YANDEX", e2.YANDEX_PROJECTS = "YANDEX_PROJECTS", e2.COPYRIGHT_HOLDER = "COPYRIGHT_HOLDER", e2.AGREEMENT = "AGREEMENT", e2.RECOMMENDATION_RULES = "RECOMMENDATION_RULES", e2.HELP = "HELP", e2.PRIVACY_POLICY = "PRIVACY_POLICY", e2;
      })({});
      let _ = (e2, t2, r2) => {
        switch (e2) {
          case p.YANDEX:
            if ("ru" === t2) return "https://ya.ru";
            return;
          case p.YANDEX_PROJECTS:
            return "https://yandex.".concat(t2, "/all?lang=").concat(r2);
          case p.COPYRIGHT_HOLDER:
            return "https://yandex.".concat(t2, "/support/music/performers-and-copyright-holders/copyright.html?lang=").concat(r2);
          case p.AGREEMENT:
            return "https://yandex.ru/legal/music_termsofuse?lang=".concat(r2);
          case p.RECOMMENDATION_RULES:
            return "https://music.yandex.ru/legal/recommendations/ru/#music";
          case p.HELP:
            return "https://yandex.".concat(t2, "/support/music/index.html?lang=").concat(r2);
          case p.PRIVACY_POLICY:
            return "https://yandex.".concat(t2, "/legal/confidential/").concat(r2);
        }
      };
      var m = r(5866), v = r.n(m), g = r(27510), b = r(24036);
      let y = (0, a.PA)((e2) => {
        let { href: t2, className: r2, withCaption: s2, children: a2 } = e2, i2 = (0, g.L)(
          () => s2 ? (0, n.jsx)(l.Caption, {
            type: "controls",
            variant: "span",
            size: "s",
            weight: "medium",
            className: v().link,
            children: a2
          }) : a2
        );
        return t2 ? (0, n.jsx)(b.Link, { target: "_blank", href: t2, className: r2, children: i2 }) : i2;
      }), h = (0, a.PA)((e2) => {
        let { className: t2 } = e2, { location: r2 } = (0, d.useStore)(), { formatDate: a2 } = (0, i.A)(), { language: u2 } = (0, f.useI18nStorage)();
        return (0, n.jsxs)("div", {
          className: (0, s.$)(v().copyrights, t2),
          children: [
            (0, n.jsxs)(l.Caption, {
              variant: "span",
              type: "text",
              size: "s",
              weight: "medium",
              className: v().text,
              children: [
                "© ",
                a2(/* @__PURE__ */ new Date(), (0, c.m)()),
                "  ",
                (0, n.jsx)(y, {
                  href: _(p.YANDEX, r2.tld, u2),
                  className: (0, s.$)(v().copyrightLink, v().yandexMusicLink),
                  withCaption: false,
                  children: (0, n.jsx)(o.A, { id: "footer.yandex-music" })
                })
              ]
            }),
            (0, n.jsx)(y, {
              href: _(p.YANDEX_PROJECTS, r2.tld, u2),
              className: v().copyrightLink,
              children: (0, n.jsx)(o.A, { id: "footer.yandex-project" })
            })
          ]
        });
      }), k = (0, a.PA)((e2) => {
        var t2;
        let { className: r2 } = e2, { user: a2, experiments: c2, location: m2 } = (0, d.useStore)(), { isEnabled: g2 } = null != (t2 = (0, u.useDeeplinkToMobile)()) ? t2 : {}, { formatMessage: b2 } = (0, i.A)(), { language: k2 } = (0, f.useI18nStorage)(), E = b2(
          "ru" === a2.account.data.userSessionRegionIso && c2.checkExperiment(x.z.WebNextFooterDisclaimer, "on") ? { id: "footer.disclaimer-content" } : { id: "footer.explicit-content" }
        ), w = ((e3) => {
          let { platform: t3, tld: r3, language: s2, userRegion: a3 } = e3, i2 = {
            title: (0, n.jsx)(o.A, { id: "footer.links-copyright-holders" }),
            url: _(p.COPYRIGHT_HOLDER, r3, s2)
          }, l2 = { title: (0, n.jsx)(o.A, { id: "footer.links-privacy-policy" }), url: _(p.PRIVACY_POLICY, r3, s2) }, c3 = { title: (0, n.jsx)(o.A, { id: "footer.links-terms" }), url: _(p.AGREEMENT, r3, s2) }, u2 = {
            title: (0, n.jsx)(o.A, { id: "footer.links-recommendation-rules" }),
            url: _(p.RECOMMENDATION_RULES, r3, s2)
          }, f2 = { title: (0, n.jsx)(o.A, { id: "footer.links-help" }), url: _(p.HELP, r3, s2) };
          switch (t3) {
            case "web": {
              let e4 = [i2, c3, u2];
              return "ru" === a3 && e4.push(l2), e4.push(f2), e4;
            }
            case "desktop":
              return [i2, c3, u2, f2];
          }
        })({ platform: "desktop", tld: m2.tld, language: k2, userRegion: a2.account.data.userSessionRegionIso });
        return (0, n.jsxs)("footer", {
          className: (0, s.$)(v().root, v().important, { [v().root_withOffsetForDeeplink]: g2 }, r2),
          children: [
            (0, n.jsxs)("div", {
              className: v().links,
              children: [
                (0, n.jsx)("ol", {
                  className: v().list,
                  children: w.map((e3) => {
                    let { title: t3, url: r3 } = e3;
                    return (0, n.jsx)(
                      "li",
                      { className: v().item, children: (0, n.jsx)(y, { href: r3, className: v().link, children: t3 }) },
                      r3
                    );
                  })
                }),
                (0, n.jsx)(l.Caption, {
                  variant: "span",
                  type: "text",
                  size: "s",
                  weight: "normal",
                  className: v().explicitText,
                  tabIndex: 0,
                  dangerouslySetInnerHTML: { __html: E }
                })
              ]
            }),
            (0, n.jsx)(h, {})
          ]
        });
      });
    },
    29896: (e) => {
      e.exports = {
        root: "PopoverWithActions_root__g2_xV",
        arrow: "PopoverWithActions_arrow__LOVdU",
        popoverContent: "PopoverWithActions_popoverContent__uPXzG",
        content: "PopoverWithActions_content__FwBlK",
        closeButton: "PopoverWithActions_closeButton__c5mHz",
        buttons: "PopoverWithActions_buttons__kiIc3",
        button: "PopoverWithActions_button__XDFYY"
      };
    },
    30142: (e) => {
      e.exports = {
        root: "VirtualScroll_root__pCptn",
        root_scrolling: "VirtualScroll_root_scrolling__dsQ6K",
        root_notScrolling: "VirtualScroll_root_notScrolling__x4qdd",
        scroller_withFooter: "VirtualScroll_scroller_withFooter__ntDaU",
        scroller_withHeader: "VirtualScroll_scroller_withHeader__9yzCK",
        scroller_withForceScroll: "VirtualScroll_scroller_withForceScroll__w7q1L"
      };
    },
    32692: (e, t, r) => {
      "use strict";
      r.d(t, { a: () => u });
      var n, s = r(88834), a = r(61910), i = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        1920: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            contentContainer: "JjlbHZ4FaP9EAcR_1DxF",
            contentContainer_block: "iOlzvyUREgDkthkrx7Sf",
            flexIcon: "WsKeF73pWotx9W1tWdYY",
            root: "cpeagBA1_PblpJn8Xgtv",
            root_withoutBorder: "qU2apWBO1yyEK0lZ3lPO",
            root_radius_xs: "MmZbSs387gu2qrJ1lDWd",
            root_radius_s: "mlcrraysn7mW6xrBXSBF",
            root_radius_m: "dgV08FKVLZKFsucuiryn",
            root_radius_l: "S97_5dtzhpxo_amtfYRg",
            root_radius_xl: "nNBJnDHRlyLTniWosJhk",
            root_radius_xxxl: "zIMibMuH7wcqUoW7KH1B",
            root_radius_round: "uwk3hfWzB2VT7kE13SQk",
            root_size: "IlG7b1K0AD7E7AMx6F5p",
            root_size_default: "C_QGmfTz6UFX93vfPt6Z",
            root_size_xxxs: "eQt33MLDiQ6DRSuLaYEp",
            root_size_xxs: "oR11LfCBVqMbUJiAgknd",
            root_size_xs: "j1jXIVckFgZECecFzZMe",
            root_size_s: "WtFdWDF44egSVM_YiMUX",
            root_size_m: "Y2uqxoU7xa_AZ8FUCVOW",
            root_size_l: "SGYcNjvjmMsXeEVGUV2Z",
            root_icon_left: "kc5CjvU5hT9KEj0iTt3C",
            root_icon_right: "et24Jf7pT_X9Fvc7TznR",
            root_primary: "fXlFz1qMkliFUWOkHo8T",
            root_primary_default: "_eTRQi5ADZCUvUKMZqJU",
            ripple: "spMT3NcRD9Yb0ntNaNct",
            root_primary_outline: "fCUSh2B0Ye9kEvceE8zc",
            root_primary_text: "qlPp6CSQQEMVZPqtqLiQ",
            root_primary_withHover: "KZF6_4K1p_Y_GMIAxaAn",
            root_primary_withHover_default: "rWukOKAJh5Ga7JuIp62L",
            root_primary_withHover_outline: "fdwWCJKgUqml5wNqrRcN",
            root_primary_withHover_text: "IgYbZLnYjW0nMahgpkus",
            root_secondary: "_T4p_w41oaq6L4sztSdw",
            root_secondary_default: "iJVAJMgccD4vj4E4o068",
            root_secondary_outline: "pnM3iSP9keZOELI2oohr",
            root_secondary_text: "UDMYhpDjiAFT3xUx268O",
            root_secondary_withHover: "qUbrkhZIOVrvM0roV1QF",
            root_secondary_withHover_default: "nHWc2sto1C6Gm0Dpw_l0",
            root_secondary_withHover_outline: "i5WuBm5mfG0mflk_1jH_",
            root_secondary_withHover_text: "HbaqudSqu7Q3mv3zMPGr",
            root_plus: "ixLRsIJ2FvXO2k04n_QY",
            root_plus_default: "yRHwHzEGfDgRXGzYJqw2",
            root_plus_outline: "e777irPFmyQFFrURLF_U",
            root_plus_text: "vRqDhvmt3gt8TFp45_Zw",
            root_plus_withHover: "TZif6q3I2RwBEYXwK_iA",
            root_plus_withHover_default: "k3DhvmzpnM_Fb9oFdE4q",
            root_plus_withHover_outline: "RiDWYwGIxqbrUPR699DM",
            root_plus_withHover_text: "hC_mMCzWjkTn2j9xZzGc",
            root_accent: "jqD2jMT6n7F0WKyqwMsn",
            root_accent_default: "bDp0r9MtoYECZ8ObMoCh",
            root_accent_outline: "rXNyGp8NBAw2MUjACZNj",
            root_accent_text: "hmV4ERaXWAJc4uPLZL30",
            root_accent_withHover: "uKuxXu1N4TP5cWaEK5Ke",
            root_accent_withHover_default: "t_hequUaUgAMhFuxizLb",
            root_accent_withHover_outline: "Oy9sPFTxNTo1_E29U4aF",
            root_accent_withHover_text: "LcKRSd3DLoh7k60Oqox8",
            root_withActiveSpinner: "nAGvO87rLs15SJgft6Hh",
            block: "BbCxxIjBGupN28bq2lSP",
            icon: "J9wTKytjOWG73QMoN5WP",
            icon_position_left: "elJfazUBui03YWZgHCbW",
            icon_position_right: "RBoEbyJKP5rEtLsXM1ji",
            icon_withButtonSize: "cE17_kCWJgx8kzQEkeVr",
            spinnerContainer: "STbBDGqYjUEcLuNvhu9w"
          };
        },
        2964: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_size_xxxs: "Rkdd2vKC_3xa1eUdRdHP",
            root_size_xxs: "l3tE1hAMmBj2aoPPwU08",
            root_size_xs: "UwnL5AJBMMAp6NwMDdZk",
            root_size_s: "DzJFnuf7XgdkFh28JAsM",
            root_size_m: "o_v2ds2BaqtzAsRuCVjw",
            root_size_l: "YjRa1ZjM_lXFlrfS7jcu",
            root_size_xl: "Seq0GowcqQmiA9LdLP_g",
            root_size_xxl: "mfy69_BvBIamD0e22rCQ",
            root_size_xxxl: "JY1OniQewgW9iHgfllZS"
          };
        },
        2260: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "ifxS_8bgSnwBoCsyow0E",
            root_withBlackShadow: "mjhMCLd6OX1d1_cJo5Cm",
            root_placement_default: "dZRym9qfncGclvrSfIP7",
            root_placement_center: "GKgBufCxWa9erUCTU3Fp",
            root_placement_right: "ptxrCeHwJ9gOgMXsd0w6",
            root_size_default: "hOyjx9DIyxwQAtbHFUtN",
            root_size_fitContent: "t7tk8IYH3tGrhDZJpi3Z",
            root_size_fullscreen: "xZzTMqgg0qtV5vqUIrkK",
            overlay: "l66GiFKS1Ux_BNd603Cu",
            overlay_transparent: "Gr0NtROEpipzr518Mwr6",
            overlay_full: "NaZE1NCUxSM1MvpZuLJV",
            header: "wEOFUiLOfluq86BrDUfg",
            title: "xuw9gha2dQiGgdRcHNgU",
            closeButton: "YUY9QjXr1E4DQfQdMjGt",
            content: "fp0QgCrX1y48p3elvLVi",
            content_withHeader: "ni3sfTj4hRfj63FbfQTG"
          };
        },
        3641: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_controls_xxs: "tRaaBpDMg9Qu8v6gKjtn",
            root_entity_xxs: "M9zvtlcpLUVn6DKdcHhj",
            root_text_xxs: "ln0PYYwDmFnfYxCDJsFU",
            root_controls_xs: "n5AeWEsJC3_AYXcbK4Lt",
            root_entity_xs: "__hrMKGmNbw54T54IUyh",
            root_text_xs: "SehSa7OyRpC2nzYTVb2Q",
            root_controls_s: "_oBLf5gprWsKjCw4Ce58",
            root_entity_s: "mxSPe5xpZnie9gpIqacd",
            root_text_s: "Ai2iRN9elHpk_u5splD6",
            root_controls_m: "tk7ahHRDYXJMMB879KUA",
            root_entity_m: "Z_WIr2W8JU4MPQek3hgR",
            root_text_m: "g3qWNP6xl__7qxNmtrvd",
            root_controls_l: "grvxapJE3vGArOKDWf6n",
            root_entity_l: "Esj5A1UeSi4xV4tZ839D",
            root_text_l: "V3WU123oO65AxsprotU9",
            root_weight_normal: "ZYV27jeWd30QDXu4GhaH",
            root_weight_medium: "_3_Mxw7Si7j2g4kWjlpR",
            root_weight_bold: "Vi7Rd0SZWqD17F0872TB"
          };
        },
        5153: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_size_xs: "qJJ288377iHlWN_RXeEE",
            root_size_s: "_sd8Q9d_Ttn0Ufe4ISWS",
            root_size_m: "Ctk8dbecq31Qh7isOJPQ",
            root_size_l: "M_Djh6ppIkCO3A2k_BTA",
            root_size_xl: "dtxlzGQMPAbM2MEndXWX",
            root_size_xxl: "IUb9XLplTAoZqne9rNUL",
            root_size_xxxl: "ZYZamUwql_rfFR4RpI2B",
            root_size_xxxxl: "ZBZyxow5njdq8z5dnRPY",
            root_size_xxxxxl: "WdvQQNwdDNCdRSwRkAtT",
            root_weight_bold: "nSU6fV9y80WrZEfafvww",
            root_weight_black: "KBeGPPK4DinQzAP41Y_N"
          };
        },
        5818: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "_MWOVuZRvUQdXKTMcOPx",
            root_clamp: "LezmJlldtbHWqU7l1950",
            root_clamp_oneline: "oyQL2RSmoNbNQf3Vc6YI",
            root_clamp_multiline: "jMyoZB5J9iZbzJmWOrF0"
          };
        },
        6544: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { RemoveScroll: () => Y });
          var n2, s2, a2 = function() {
            return (a2 = Object.assign || function(e3) {
              for (var t3, r3 = 1, n3 = arguments.length; r3 < n3; r3++)
                for (var s3 in t3 = arguments[r3]) Object.prototype.hasOwnProperty.call(t3, s3) && (e3[s3] = t3[s3]);
              return e3;
            }).apply(this, arguments);
          };
          function i2(e3, t3) {
            var r3 = {};
            for (var n3 in e3) Object.prototype.hasOwnProperty.call(e3, n3) && 0 > t3.indexOf(n3) && (r3[n3] = e3[n3]);
            if (null != e3 && "function" == typeof Object.getOwnPropertySymbols)
              for (var s3 = 0, n3 = Object.getOwnPropertySymbols(e3); s3 < n3.length; s3++)
                0 > t3.indexOf(n3[s3]) && Object.prototype.propertyIsEnumerable.call(e3, n3[s3]) && (r3[n3[s3]] = e3[n3[s3]]);
            return r3;
          }
          Object.create;
          Object.create;
          var o2 = ("function" == typeof SuppressedError && SuppressedError, r2(810)), l2 = "right-scroll-bar-position", c2 = "width-before-scroll-bar";
          function u2(e3, t3) {
            return "function" == typeof e3 ? e3(t3) : e3 && (e3.current = t3), e3;
          }
          var f = o2.useLayoutEffect, d = /* @__PURE__ */ new WeakMap();
          function x(e3) {
            return e3;
          }
          var p = (function(e3) {
            void 0 === e3 && (e3 = {});
            var t3, r3, n3, s3 = (void 0 === t3 && (t3 = x), r3 = [], n3 = false, {
              read: function() {
                if (n3)
                  throw Error(
                    "Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`."
                  );
                return r3.length ? r3[r3.length - 1] : null;
              },
              useMedium: function(e4) {
                var s4 = t3(e4, n3);
                return r3.push(s4), function() {
                  r3 = r3.filter(function(e5) {
                    return e5 !== s4;
                  });
                };
              },
              assignSyncMedium: function(e4) {
                for (n3 = true; r3.length; ) {
                  var t4 = r3;
                  r3 = [], t4.forEach(e4);
                }
                r3 = {
                  push: function(t5) {
                    return e4(t5);
                  },
                  filter: function() {
                    return r3;
                  }
                };
              },
              assignMedium: function(e4) {
                n3 = true;
                var t4 = [];
                if (r3.length) {
                  var s4 = r3;
                  r3 = [], s4.forEach(e4), t4 = r3;
                }
                var a3 = function() {
                  var r4 = t4;
                  t4 = [], r4.forEach(e4);
                }, i3 = function() {
                  return Promise.resolve().then(a3);
                };
                i3(), r3 = {
                  push: function(e5) {
                    t4.push(e5), i3();
                  },
                  filter: function(e5) {
                    return t4 = t4.filter(e5), r3;
                  }
                };
              }
            });
            return s3.options = a2({ async: true, ssr: false }, e3), s3;
          })(), _ = function() {
          }, m = o2.forwardRef(function(e3, t3) {
            var r3, n3, s3, l3, c3 = o2.useRef(null), x2 = o2.useState({ onScrollCapture: _, onWheelCapture: _, onTouchMoveCapture: _ }), m2 = x2[0], v2 = x2[1], g2 = e3.forwardProps, b2 = e3.children, y2 = e3.className, h2 = e3.removeScrollBar, k2 = e3.enabled, E2 = e3.shards, w2 = e3.sideCar, j2 = e3.noIsolation, O2 = e3.inert, R2 = e3.allowPinchZoom, C2 = e3.as, S2 = e3.gapMode, P2 = i2(e3, [
              "forwardProps",
              "children",
              "className",
              "removeScrollBar",
              "enabled",
              "shards",
              "sideCar",
              "noIsolation",
              "inert",
              "allowPinchZoom",
              "as",
              "gapMode"
            ]), A2 = (r3 = [c3, t3], n3 = function(e4) {
              return r3.forEach(function(t4) {
                return u2(t4, e4);
              });
            }, (s3 = (0, o2.useState)(function() {
              return {
                value: null,
                callback: n3,
                facade: {
                  get current() {
                    return s3.value;
                  },
                  set current(value) {
                    var e4 = s3.value;
                    e4 !== value && (s3.value = value, s3.callback(value, e4));
                  }
                }
              };
            })[0]).callback = n3, l3 = s3.facade, f(
              function() {
                var e4 = d.get(l3);
                if (e4) {
                  var t4 = new Set(e4), n4 = new Set(r3), s4 = l3.current;
                  t4.forEach(function(e5) {
                    n4.has(e5) || u2(e5, null);
                  }), n4.forEach(function(e5) {
                    t4.has(e5) || u2(e5, s4);
                  });
                }
                d.set(l3, r3);
              },
              [r3]
            ), l3), T2 = a2(a2({}, P2), m2);
            return o2.createElement(
              o2.Fragment,
              null,
              k2 && o2.createElement(w2, {
                sideCar: p,
                removeScrollBar: h2,
                shards: E2,
                noIsolation: j2,
                inert: O2,
                setCallbacks: v2,
                allowPinchZoom: !!R2,
                lockRef: c3,
                gapMode: S2
              }),
              g2 ? o2.cloneElement(o2.Children.only(b2), a2(a2({}, T2), { ref: A2 })) : o2.createElement(void 0 === C2 ? "div" : C2, a2({}, T2, { className: y2, ref: A2 }), b2)
            );
          });
          m.defaultProps = { enabled: true, removeScrollBar: true, inert: false }, m.classNames = { fullWidth: c2, zeroRight: l2 };
          var v = function(e3) {
            var t3 = e3.sideCar, r3 = i2(e3, ["sideCar"]);
            if (!t3) throw Error("Sidecar: please provide `sideCar` property to import the right car");
            var n3 = t3.read();
            if (!n3) throw Error("Sidecar medium not found");
            return o2.createElement(n3, a2({}, r3));
          };
          v.isSideCarExport = true;
          var g = function() {
            var e3 = 0, t3 = null;
            return {
              add: function(n3) {
                if (0 == e3 && (t3 = (function() {
                  if (!document) return null;
                  var e4 = document.createElement("style");
                  e4.type = "text/css";
                  var t4 = s2 || r2.nc;
                  return t4 && e4.setAttribute("nonce", t4), e4;
                })())) {
                  var a3, i3;
                  (a3 = t3).styleSheet ? a3.styleSheet.cssText = n3 : a3.appendChild(document.createTextNode(n3)), i3 = t3, (document.head || document.getElementsByTagName("head")[0]).appendChild(i3);
                }
                e3++;
              },
              remove: function() {
                --e3 || !t3 || (t3.parentNode && t3.parentNode.removeChild(t3), t3 = null);
              }
            };
          }, b = function() {
            var e3 = g();
            return function(t3, r3) {
              o2.useEffect(
                function() {
                  return e3.add(t3), function() {
                    e3.remove();
                  };
                },
                [t3 && r3]
              );
            };
          }, y = function() {
            var e3 = b();
            return function(t3) {
              return e3(t3.styles, t3.dynamic), null;
            };
          }, h = function(e3) {
            return parseInt(e3 || "", 10) || 0;
          }, k = function(e3) {
            var t3 = window.getComputedStyle(document.body), r3 = t3["padding" === e3 ? "paddingLeft" : "marginLeft"], n3 = t3["padding" === e3 ? "paddingTop" : "marginTop"], s3 = t3["padding" === e3 ? "paddingRight" : "marginRight"];
            return [h(r3), h(n3), h(s3)];
          }, E = function(e3) {
            void 0 === e3 && (e3 = "margin");
            var t3 = k(e3), r3 = document.documentElement.clientWidth, n3 = window.innerWidth;
            return { left: t3[0], top: t3[1], right: t3[2], gap: Math.max(0, n3 - r3 + t3[2] - t3[0]) };
          }, w = y(), j = "data-scroll-locked", O = function(e3, t3, r3, n3) {
            var s3 = e3.left, a3 = e3.top, i3 = e3.right, o3 = e3.gap;
            return void 0 === r3 && (r3 = "margin"), "\n  .".concat("with-scroll-bars-hidden", " {\n   overflow: hidden ").concat(n3, ";\n   padding-right: ").concat(o3, "px ").concat(n3, ";\n  }\n  body[").concat(j, "] {\n    overflow: hidden ").concat(n3, ";\n    overscroll-behavior: contain;\n    ").concat(
              [
                t3 && "position: relative ".concat(n3, ";"),
                "margin" === r3 && "\n    padding-left: ".concat(s3, "px;\n    padding-top: ").concat(a3, "px;\n    padding-right: ").concat(i3, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(o3, "px ").concat(n3, ";\n    "),
                "padding" === r3 && "padding-right: ".concat(o3, "px ").concat(n3, ";")
              ].filter(Boolean).join(""),
              "\n  }\n  \n  ."
            ).concat(l2, " {\n    right: ").concat(o3, "px ").concat(n3, ";\n  }\n  \n  .").concat(c2, " {\n    margin-right: ").concat(o3, "px ").concat(n3, ";\n  }\n  \n  .").concat(l2, " .").concat(l2, " {\n    right: 0 ").concat(n3, ";\n  }\n  \n  .").concat(c2, " .").concat(c2, " {\n    margin-right: 0 ").concat(n3, ";\n  }\n  \n  body[").concat(j, "] {\n    ").concat("--removed-body-scroll-bar-size", ": ").concat(o3, "px;\n  }\n");
          }, R = function() {
            var e3 = parseInt(document.body.getAttribute(j) || "0", 10);
            return isFinite(e3) ? e3 : 0;
          }, C = function() {
            o2.useEffect(function() {
              return document.body.setAttribute(j, (R() + 1).toString()), function() {
                var e3 = R() - 1;
                e3 <= 0 ? document.body.removeAttribute(j) : document.body.setAttribute(j, e3.toString());
              };
            }, []);
          }, S = function(e3) {
            var t3 = e3.noRelative, r3 = e3.noImportant, n3 = e3.gapMode, s3 = void 0 === n3 ? "margin" : n3;
            C();
            var a3 = o2.useMemo(
              function() {
                return E(s3);
              },
              [s3]
            );
            return o2.createElement(w, { styles: O(a3, !t3, s3, r3 ? "" : "!important") });
          }, P = false;
          try {
            var A = Object.defineProperty({}, "passive", {
              get: function() {
                return P = true, true;
              }
            });
            window.addEventListener("test", A, A), window.removeEventListener("test", A, A);
          } catch (e3) {
            P = false;
          }
          var T = !!P && { passive: false }, H = function(e3, t3) {
            if (!(e3 instanceof Element)) return false;
            var r3 = window.getComputedStyle(e3);
            return "hidden" !== r3[t3] && (r3.overflowY !== r3.overflowX || "TEXTAREA" === e3.tagName || "visible" !== r3[t3]);
          }, M = function(e3, t3) {
            var r3 = t3.ownerDocument, n3 = t3;
            do {
              if ("undefined" != typeof ShadowRoot && n3 instanceof ShadowRoot && (n3 = n3.host), N(e3, n3)) {
                var s3 = I(e3, n3);
                if (s3[1] > s3[2]) return true;
              }
              n3 = n3.parentNode;
            } while (n3 && n3 !== r3.body);
            return false;
          }, N = function(e3, t3) {
            return "v" === e3 ? H(t3, "overflowY") : H(t3, "overflowX");
          }, I = function(e3, t3) {
            return "v" === e3 ? [t3.scrollTop, t3.scrollHeight, t3.clientHeight] : [t3.scrollLeft, t3.scrollWidth, t3.clientWidth];
          }, L = function(e3, t3, r3, n3, s3) {
            var a3, i3 = (a3 = window.getComputedStyle(t3).direction, "h" === e3 && "rtl" === a3 ? -1 : 1), o3 = i3 * n3, l3 = r3.target, c3 = t3.contains(l3), u3 = false, f2 = o3 > 0, d2 = 0, x2 = 0;
            do {
              var p2 = I(e3, l3), _2 = p2[0], m2 = p2[1] - p2[2] - i3 * _2;
              (_2 || m2) && N(e3, l3) && (d2 += m2, x2 += _2), l3 = l3 instanceof ShadowRoot ? l3.host : l3.parentNode;
            } while (!c3 && l3 !== document.body || c3 && (t3.contains(l3) || t3 === l3));
            return f2 && (s3 && 1 > Math.abs(d2) || !s3 && o3 > d2) ? u3 = true : !f2 && (s3 && 1 > Math.abs(x2) || !s3 && -o3 > x2) && (u3 = true), u3;
          }, B = function(e3) {
            return "changedTouches" in e3 ? [e3.changedTouches[0].clientX, e3.changedTouches[0].clientY] : [0, 0];
          }, D = function(e3) {
            return [e3.deltaX, e3.deltaY];
          }, z = function(e3) {
            return e3 && "current" in e3 ? e3.current : e3;
          }, F = 0, U = [];
          let W = (n2 = function(e3) {
            var t3 = o2.useRef([]), r3 = o2.useRef([0, 0]), n3 = o2.useRef(), s3 = o2.useState(F++)[0], a3 = o2.useState(y)[0], i3 = o2.useRef(e3);
            o2.useEffect(
              function() {
                i3.current = e3;
              },
              [e3]
            ), o2.useEffect(
              function() {
                if (e3.inert) {
                  document.body.classList.add("block-interactivity-".concat(s3));
                  var t4 = (function(e4, t5, r4) {
                    if (r4 || 2 == arguments.length)
                      for (var n4, s4 = 0, a4 = t5.length; s4 < a4; s4++)
                        !n4 && s4 in t5 || (n4 || (n4 = Array.prototype.slice.call(t5, 0, s4)), n4[s4] = t5[s4]);
                    return e4.concat(n4 || Array.prototype.slice.call(t5));
                  })([e3.lockRef.current], (e3.shards || []).map(z), true).filter(Boolean);
                  return t4.forEach(function(e4) {
                    return e4.classList.add("allow-interactivity-".concat(s3));
                  }), function() {
                    document.body.classList.remove("block-interactivity-".concat(s3)), t4.forEach(function(e4) {
                      return e4.classList.remove("allow-interactivity-".concat(s3));
                    });
                  };
                }
              },
              [e3.inert, e3.lockRef.current, e3.shards]
            );
            var l3 = o2.useCallback(function(e4, t4) {
              if ("touches" in e4 && 2 === e4.touches.length || "wheel" === e4.type && e4.ctrlKey)
                return !i3.current.allowPinchZoom;
              var s4, a4 = B(e4), o3 = r3.current, l4 = "deltaX" in e4 ? e4.deltaX : o3[0] - a4[0], c4 = "deltaY" in e4 ? e4.deltaY : o3[1] - a4[1], u4 = e4.target, f3 = Math.abs(l4) > Math.abs(c4) ? "h" : "v";
              if ("touches" in e4 && "h" === f3 && "range" === u4.type) return false;
              var d3 = M(f3, u4);
              if (!d3) return true;
              if (d3 ? s4 = f3 : (s4 = "v" === f3 ? "h" : "v", d3 = M(f3, u4)), !d3) return false;
              if (!n3.current && "changedTouches" in e4 && (l4 || c4) && (n3.current = s4), !s4) return true;
              var x3 = n3.current || s4;
              return L(x3, t4, e4, "h" === x3 ? l4 : c4, true);
            }, []), c3 = o2.useCallback(function(e4) {
              if (U.length && U[U.length - 1] === a3) {
                var r4 = "deltaY" in e4 ? D(e4) : B(e4), n4 = t3.current.filter(function(t4) {
                  var n5;
                  return t4.name === e4.type && (t4.target === e4.target || e4.target === t4.shadowParent) && (n5 = t4.delta, n5[0] === r4[0] && n5[1] === r4[1]);
                })[0];
                if (n4 && n4.should) {
                  e4.cancelable && e4.preventDefault();
                  return;
                }
                if (!n4) {
                  var s4 = (i3.current.shards || []).map(z).filter(Boolean).filter(function(t4) {
                    return t4.contains(e4.target);
                  });
                  (s4.length > 0 ? l3(e4, s4[0]) : !i3.current.noIsolation) && e4.cancelable && e4.preventDefault();
                }
              }
            }, []), u3 = o2.useCallback(function(e4, r4, n4, s4) {
              var a4 = {
                name: e4,
                delta: r4,
                target: n4,
                should: s4,
                shadowParent: (function(e5) {
                  for (var t4 = null; null !== e5; )
                    e5 instanceof ShadowRoot && (t4 = e5.host, e5 = e5.host), e5 = e5.parentNode;
                  return t4;
                })(n4)
              };
              t3.current.push(a4), setTimeout(function() {
                t3.current = t3.current.filter(function(e5) {
                  return e5 !== a4;
                });
              }, 1);
            }, []), f2 = o2.useCallback(function(e4) {
              r3.current = B(e4), n3.current = void 0;
            }, []), d2 = o2.useCallback(function(t4) {
              u3(t4.type, D(t4), t4.target, l3(t4, e3.lockRef.current));
            }, []), x2 = o2.useCallback(function(t4) {
              u3(t4.type, B(t4), t4.target, l3(t4, e3.lockRef.current));
            }, []);
            o2.useEffect(function() {
              return U.push(a3), e3.setCallbacks({ onScrollCapture: d2, onWheelCapture: d2, onTouchMoveCapture: x2 }), document.addEventListener("wheel", c3, T), document.addEventListener("touchmove", c3, T), document.addEventListener("touchstart", f2, T), function() {
                U = U.filter(function(e4) {
                  return e4 !== a3;
                }), document.removeEventListener("wheel", c3, T), document.removeEventListener("touchmove", c3, T), document.removeEventListener("touchstart", f2, T);
              };
            }, []);
            var p2 = e3.removeScrollBar, _2 = e3.inert;
            return o2.createElement(
              o2.Fragment,
              null,
              _2 ? o2.createElement(a3, {
                styles: "\n  .block-interactivity-".concat(s3, " {pointer-events: none;}\n  .allow-interactivity-").concat(s3, " {pointer-events: all;}\n")
              }) : null,
              p2 ? o2.createElement(S, { gapMode: e3.gapMode }) : null
            );
          }, p.useMedium(n2), v);
          var V = o2.forwardRef(function(e3, t3) {
            return o2.createElement(m, a2({}, e3, { ref: t3, sideCar: W }));
          });
          V.classNames = m.classNames;
          let Y = V;
        },
        4490: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { DOWN: () => o2, LEFT: () => s2, RIGHT: () => a2, UP: () => i2, useSwipeable: () => x });
          var n2 = r2(810);
          let s2 = "Left", a2 = "Right", i2 = "Up", o2 = "Down", l2 = {
            delta: 10,
            preventScrollOnSwipe: false,
            rotationAngle: 0,
            trackMouse: false,
            trackTouch: true,
            swipeDuration: 1 / 0,
            touchEventOptions: { passive: true }
          }, c2 = { first: true, initial: [0, 0], start: 0, swiping: false, xy: [0, 0] }, u2 = "mousemove", f = "mouseup";
          function d(e3, t3) {
            if (0 === t3) return e3;
            let r3 = Math.PI / 180 * t3;
            return [e3[0] * Math.cos(r3) + e3[1] * Math.sin(r3), e3[1] * Math.cos(r3) - e3[0] * Math.sin(r3)];
          }
          function x(e3) {
            var t3, r3, x2;
            let p, { trackMouse: _ } = e3, m = n2.useRef(Object.assign({}, c2)), v = n2.useRef(Object.assign({}, l2)), g = n2.useRef(Object.assign({}, v.current));
            for (p in g.current = Object.assign({}, v.current), v.current = Object.assign(Object.assign({}, l2), e3), l2)
              void 0 === v.current[p] && (v.current[p] = l2[p]);
            let [b, y] = n2.useMemo(
              () => (function(e4, t4) {
                let r4 = (t5) => {
                  let r5 = "touches" in t5;
                  r5 && t5.touches.length > 1 || e4((e5, s3) => {
                    s3.trackMouse && !r5 && (document.addEventListener(u2, n3), document.addEventListener(f, p2));
                    let { clientX: a3, clientY: i3 } = r5 ? t5.touches[0] : t5, o3 = d([a3, i3], s3.rotationAngle);
                    return s3.onTouchStartOrOnMouseDown && s3.onTouchStartOrOnMouseDown({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), {
                      initial: o3.slice(),
                      xy: o3,
                      start: t5.timeStamp || 0
                    });
                  });
                }, n3 = (t5) => {
                  e4((e5, r5) => {
                    var n4, c3, u3, f2;
                    let x4 = "touches" in t5;
                    if (x4 && t5.touches.length > 1) return e5;
                    if (t5.timeStamp - e5.start > r5.swipeDuration)
                      return e5.swiping ? Object.assign(Object.assign({}, e5), { swiping: false }) : e5;
                    let { clientX: p3, clientY: _3 } = x4 ? t5.touches[0] : t5, [m3, v2] = d([p3, _3], r5.rotationAngle), g2 = m3 - e5.xy[0], b2 = v2 - e5.xy[1], y2 = Math.abs(g2), h = Math.abs(b2), k = (t5.timeStamp || 0) - e5.start, E = Math.sqrt(y2 * y2 + h * h) / (k || 1), w = [g2 / (k || 1), b2 / (k || 1)], j = (n4 = y2, c3 = h, u3 = g2, f2 = b2, n4 > c3 ? u3 > 0 ? a2 : s2 : f2 > 0 ? o2 : i2), O = "number" == typeof r5.delta ? r5.delta : r5.delta[j.toLowerCase()] || l2.delta;
                    if (y2 < O && h < O && !e5.swiping) return e5;
                    let R = {
                      absX: y2,
                      absY: h,
                      deltaX: g2,
                      deltaY: b2,
                      dir: j,
                      event: t5,
                      first: e5.first,
                      initial: e5.initial,
                      velocity: E,
                      vxvy: w
                    };
                    R.first && r5.onSwipeStart && r5.onSwipeStart(R), r5.onSwiping && r5.onSwiping(R);
                    let C = false;
                    return (r5.onSwiping || r5.onSwiped || r5["onSwiped".concat(j)]) && (C = true), C && r5.preventScrollOnSwipe && r5.trackTouch && t5.cancelable && t5.preventDefault(), Object.assign(Object.assign({}, e5), { first: false, eventData: R, swiping: true });
                  });
                }, x3 = (t5) => {
                  e4((e5, r5) => {
                    let n4;
                    if (e5.swiping && e5.eventData) {
                      if (t5.timeStamp - e5.start < r5.swipeDuration) {
                        n4 = Object.assign(Object.assign({}, e5.eventData), { event: t5 }), r5.onSwiped && r5.onSwiped(n4);
                        let s3 = r5["onSwiped".concat(n4.dir)];
                        s3 && s3(n4);
                      }
                    } else r5.onTap && r5.onTap({ event: t5 });
                    return r5.onTouchEndOrOnMouseUp && r5.onTouchEndOrOnMouseUp({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), { eventData: n4 });
                  });
                }, p2 = (e5) => {
                  document.removeEventListener(u2, n3), document.removeEventListener(f, p2), x3(e5);
                }, _2 = (e5, t5) => {
                  let s3 = () => {
                  };
                  if (e5 && e5.addEventListener) {
                    let a3 = Object.assign(Object.assign({}, l2.touchEventOptions), t5.touchEventOptions), i3 = [
                      ["touchstart", r4, a3],
                      [
                        "touchmove",
                        n3,
                        Object.assign(Object.assign({}, a3), t5.preventScrollOnSwipe ? { passive: false } : {})
                      ],
                      ["touchend", x3, a3]
                    ];
                    i3.forEach((t6) => {
                      let [r5, n4, s4] = t6;
                      return e5.addEventListener(r5, n4, s4);
                    }), s3 = () => i3.forEach((t6) => {
                      let [r5, n4] = t6;
                      return e5.removeEventListener(r5, n4);
                    });
                  }
                  return s3;
                }, m2 = {
                  ref: (t5) => {
                    null !== t5 && e4((e5, r5) => {
                      if (e5.el === t5) return e5;
                      let n4 = {};
                      return e5.el && e5.el !== t5 && e5.cleanUpTouch && (e5.cleanUpTouch(), n4.cleanUpTouch = void 0), r5.trackTouch && t5 && (n4.cleanUpTouch = _2(t5, r5)), Object.assign(Object.assign(Object.assign({}, e5), { el: t5 }), n4);
                    });
                  }
                };
                return t4.trackMouse && (m2.onMouseDown = r4), [m2, _2];
              })((e4) => m.current = e4(m.current, v.current), { trackMouse: _ }),
              [_]
            );
            return t3 = m.current, r3 = v.current, x2 = g.current, m.current = r3.trackTouch && t3.el ? t3.cleanUpTouch ? r3.preventScrollOnSwipe !== x2.preventScrollOnSwipe || r3.touchEventOptions.passive !== x2.touchEventOptions.passive ? (t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) })) : t3 : Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) }) : (t3.cleanUpTouch && t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: void 0 })), b;
          }
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        8442: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "addToPlaylist_xxs", xlinkHref: "/icons/sprite.svg#addToPlaylist_xxs" })
            ]);
          });
        },
        6644: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "add_l", xlinkHref: "/icons/sprite.svg#add_l" })
            ]);
          });
        },
        7319: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "add_xxs", xlinkHref: "/icons/sprite.svg#add_xxs" })
            ]);
          });
        },
        9351: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_s", xlinkHref: "/icons/sprite.svg#adult_s" })
            ]);
          });
        },
        7171: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xs", xlinkHref: "/icons/sprite.svg#adult_xs" })
            ]);
          });
        },
        2586: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xxs", xlinkHref: "/icons/sprite.svg#adult_xxs" })
            ]);
          });
        },
        4656: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xxxs", xlinkHref: "/icons/sprite.svg#adult_xxxs" })
            ]);
          });
        },
        996: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_l", xlinkHref: "/icons/sprite.svg#album_l" })
            ]);
          });
        },
        2092: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_s", xlinkHref: "/icons/sprite.svg#album_s" })
            ]);
          });
        },
        6304: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xl", xlinkHref: "/icons/sprite.svg#album_xl" })
            ]);
          });
        },
        9030: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xs", xlinkHref: "/icons/sprite.svg#album_xs" })
            ]);
          });
        },
        5822: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xxs", xlinkHref: "/icons/sprite.svg#album_xxs" })
            ]);
          });
        },
        9422: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowDown_xs", xlinkHref: "/icons/sprite.svg#arrowDown_xs" })
            ]);
          });
        },
        5272: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowDown_xxs", xlinkHref: "/icons/sprite.svg#arrowDown_xxs" })
            ]);
          });
        },
        1491: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowLeft_xs", xlinkHref: "/icons/sprite.svg#arrowLeft_xs" })
            ]);
          });
        },
        4860: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowLeft_xxs", xlinkHref: "/icons/sprite.svg#arrowLeft_xxs" })
            ]);
          });
        },
        2337: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xs", xlinkHref: "/icons/sprite.svg#arrowRight_xs" })
            ]);
          });
        },
        8711: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxs" })
            ]);
          });
        },
        8170: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xxxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxxs" })
            ]);
          });
        },
        8109: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "artist_xxs", xlinkHref: "/icons/sprite.svg#artist_xxs" })
            ]);
          });
        },
        7341: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "attention_xxl", xlinkHref: "/icons/sprite.svg#attention_xxl" })
            ]);
          });
        },
        2435: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "attention_xxxl", xlinkHref: "/icons/sprite.svg#attention_xxxl" })
            ]);
          });
        },
        3918: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "bandlink", xlinkHref: "/icons/sprite.svg#bandlink" })
            ]);
          });
        },
        2571: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "booksLogo", xlinkHref: "/icons/sprite.svg#booksLogo" })
            ]);
          });
        },
        4904: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "bucket_xxs", xlinkHref: "/icons/sprite.svg#bucket_xxs" })
            ]);
          });
        },
        9202: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "cast_xs", xlinkHref: "/icons/sprite.svg#cast_xs" })
            ]);
          });
        },
        130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chain_xs", xlinkHref: "/icons/sprite.svg#chain_xs" })
            ]);
          });
        },
        5971: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chain_xxs", xlinkHref: "/icons/sprite.svg#chain_xxs" })
            ]);
          });
        },
        3331: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartDown_xxs", xlinkHref: "/icons/sprite.svg#chartDown_xxs" })
            ]);
          });
        },
        9783: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartNew_xxs", xlinkHref: "/icons/sprite.svg#chartNew_xxs" })
            ]);
          });
        },
        8184: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartSame_xxs", xlinkHref: "/icons/sprite.svg#chartSame_xxs" })
            ]);
          });
        },
        4926: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartUp_xxs", xlinkHref: "/icons/sprite.svg#chartUp_xxs" })
            ]);
          });
        },
        9505: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxl", xlinkHref: "/icons/sprite.svg#check_xxl" })
            ]);
          });
        },
        3176: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxs", xlinkHref: "/icons/sprite.svg#check_xxs" })
            ]);
          });
        },
        5565: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxxs", xlinkHref: "/icons/sprite.svg#check_xxxs" })
            ]);
          });
        },
        9040: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "clip_xl", xlinkHref: "/icons/sprite.svg#clip_xl" })
            ]);
          });
        },
        4789: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "clip_xxs", xlinkHref: "/icons/sprite.svg#clip_xxs" })
            ]);
          });
        },
        7923: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xs", xlinkHref: "/icons/sprite.svg#close_xs" })
            ]);
          });
        },
        8151: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xxs", xlinkHref: "/icons/sprite.svg#close_xxs" })
            ]);
          });
        },
        8127: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xxxs", xlinkHref: "/icons/sprite.svg#close_xxxs" })
            ]);
          });
        },
        8690: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "code_xxs", xlinkHref: "/icons/sprite.svg#code_xxs" })
            ]);
          });
        },
        3076: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "collections_m", xlinkHref: "/icons/sprite.svg#collections_m" })
            ]);
          });
        },
        2495: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "collections_selected_m",
                xlinkHref: "/icons/sprite.svg#collections_selected_m"
              })
            ]);
          });
        },
        1524: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "crown_xxs", xlinkHref: "/icons/sprite.svg#crown_xxs" })
            ]);
          });
        },
        1162: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_s", xlinkHref: "/icons/sprite.svg#dislike_s" })
            ]);
          });
        },
        3654: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_xs", xlinkHref: "/icons/sprite.svg#dislike_xs" })
            ]);
          });
        },
        2361: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_xxs", xlinkHref: "/icons/sprite.svg#dislike_xxs" })
            ]);
          });
        },
        6837: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_s", xlinkHref: "/icons/sprite.svg#disliked_s" })
            ]);
          });
        },
        6507: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_xs", xlinkHref: "/icons/sprite.svg#disliked_xs" })
            ]);
          });
        },
        3972: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_xxs", xlinkHref: "/icons/sprite.svg#disliked_xxs" })
            ]);
          });
        },
        8993: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "donation_xxxs", xlinkHref: "/icons/sprite.svg#donation_xxxs" })
            ]);
          });
        },
        7031: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "download_l", xlinkHref: "/icons/sprite.svg#download_l" })
            ]);
          });
        },
        9330: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "download_xxs", xlinkHref: "/icons/sprite.svg#download_xxs" })
            ]);
          });
        },
        7346: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "downloaded_xxs", xlinkHref: "/icons/sprite.svg#downloaded_xxs" })
            ]);
          });
        },
        2604: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dragDots_xxs", xlinkHref: "/icons/sprite.svg#dragDots_xxs" })
            ]);
          });
        },
        6894: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "edit_xxs", xlinkHref: "/icons/sprite.svg#edit_xxs" })
            ]);
          });
        },
        2024: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_s", xlinkHref: "/icons/sprite.svg#exclamation_s" })
            ]);
          });
        },
        3193: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xs", xlinkHref: "/icons/sprite.svg#exclamation_xs" })
            ]);
          });
        },
        6391: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xxs", xlinkHref: "/icons/sprite.svg#exclamation_xxs" })
            ]);
          });
        },
        2933: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xxxs", xlinkHref: "/icons/sprite.svg#exclamation_xxxs" })
            ]);
          });
        },
        776: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_s", xlinkHref: "/icons/sprite.svg#explicit_s" })
            ]);
          });
        },
        30: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xs", xlinkHref: "/icons/sprite.svg#explicit_xs" })
            ]);
          });
        },
        9369: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xxs", xlinkHref: "/icons/sprite.svg#explicit_xxs" })
            ]);
          });
        },
        1334: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xxxs", xlinkHref: "/icons/sprite.svg#explicit_xxxs" })
            ]);
          });
        },
        226: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "eye_crossed_xxs", xlinkHref: "/icons/sprite.svg#eye_crossed_xxs" })
            ]);
          });
        },
        7802: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "filter_xs", xlinkHref: "/icons/sprite.svg#filter_xs" })
            ]);
          });
        },
        8130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "filter_xxs", xlinkHref: "/icons/sprite.svg#filter_xxs" })
            ]);
          });
        },
        3738: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "fullscreen_xs", xlinkHref: "/icons/sprite.svg#fullscreen_xs" })
            ]);
          });
        },
        2161: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "googlePlay", xlinkHref: "/icons/sprite.svg#googlePlay" })
            ]);
          });
        },
        9509: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "history_m", xlinkHref: "/icons/sprite.svg#history_m" })
            ]);
          });
        },
        8987: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "home_m", xlinkHref: "/icons/sprite.svg#home_m" })
            ]);
          });
        },
        190: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "home_selected_m", xlinkHref: "/icons/sprite.svg#home_selected_m" })
            ]);
          });
        },
        5304: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "huaweiAppGallery", xlinkHref: "/icons/sprite.svg#huaweiAppGallery" })
            ]);
          });
        },
        5270: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "info_xxs", xlinkHref: "/icons/sprite.svg#info_xxs" })
            ]);
          });
        },
        843: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kids_m", xlinkHref: "/icons/sprite.svg#kids_m" })
            ]);
          });
        },
        5122: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kids_selected_m", xlinkHref: "/icons/sprite.svg#kids_selected_m" })
            ]);
          });
        },
        2646: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kinopoiskEn", xlinkHref: "/icons/sprite.svg#kinopoiskEn" })
            ]);
          });
        },
        7500: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kinopoiskRu", xlinkHref: "/icons/sprite.svg#kinopoiskRu" })
            ]);
          });
        },
        3560: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lightning_xxs", xlinkHref: "/icons/sprite.svg#lightning_xxs" })
            ]);
          });
        },
        9838: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likeVariant_xxs", xlinkHref: "/icons/sprite.svg#likeVariant_xxs" })
            ]);
          });
        },
        4793: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_l", xlinkHref: "/icons/sprite.svg#like_l" })
            ]);
          });
        },
        7405: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_m", xlinkHref: "/icons/sprite.svg#like_m" })
            ]);
          });
        },
        2340: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_xs", xlinkHref: "/icons/sprite.svg#like_xs" })
            ]);
          });
        },
        7513: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_xxs", xlinkHref: "/icons/sprite.svg#like_xxs" })
            ]);
          });
        },
        5720: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likedVariant_s", xlinkHref: "/icons/sprite.svg#likedVariant_s" })
            ]);
          });
        },
        7399: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likedVariant_xxs", xlinkHref: "/icons/sprite.svg#likedVariant_xxs" })
            ]);
          });
        },
        820: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_m", xlinkHref: "/icons/sprite.svg#liked_m" })
            ]);
          });
        },
        2125: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_xs", xlinkHref: "/icons/sprite.svg#liked_xs" })
            ]);
          });
        },
        9104: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_xxs", xlinkHref: "/icons/sprite.svg#liked_xxs" })
            ]);
          });
        },
        5849: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "link_xxs", xlinkHref: "/icons/sprite.svg#link_xxs" })
            ]);
          });
        },
        1426: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "listen_xxxs", xlinkHref: "/icons/sprite.svg#listen_xxxs" })
            ]);
          });
        },
        4014: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liteVersion_xs", xlinkHref: "/icons/sprite.svg#liteVersion_xs" })
            ]);
          });
        },
        5443: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_m", xlinkHref: "/icons/sprite.svg#lock_m" })
            ]);
          });
        },
        896: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_xs", xlinkHref: "/icons/sprite.svg#lock_xs" })
            ]);
          });
        },
        3613: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_xxs", xlinkHref: "/icons/sprite.svg#lock_xxs" })
            ]);
          });
        },
        9372: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lyrics_xxs", xlinkHref: "/icons/sprite.svg#lyrics_xxs" })
            ]);
          });
        },
        6104: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "macos", xlinkHref: "/icons/sprite.svg#macos" })
            ]);
          });
        },
        3709: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "macos_xxs", xlinkHref: "/icons/sprite.svg#macos_xxs" })
            ]);
          });
        },
        3685: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "menuArrow_xxs", xlinkHref: "/icons/sprite.svg#menuArrow_xxs" })
            ]);
          });
        },
        8782: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_m", xlinkHref: "/icons/sprite.svg#more_m" })
            ]);
          });
        },
        1829: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_xs", xlinkHref: "/icons/sprite.svg#more_xs" })
            ]);
          });
        },
        3302: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_xxs", xlinkHref: "/icons/sprite.svg#more_xxs" })
            ]);
          });
        },
        2502: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogo", xlinkHref: "/icons/sprite.svg#musicLogo" })
            ]);
          });
        },
        1754: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoCenterEn", xlinkHref: "/icons/sprite.svg#musicLogoCenterEn" })
            ]);
          });
        },
        6615: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoCenterRu", xlinkHref: "/icons/sprite.svg#musicLogoCenterRu" })
            ]);
          });
        },
        7942: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoLeftEn", xlinkHref: "/icons/sprite.svg#musicLogoLeftEn" })
            ]);
          });
        },
        1498: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoLeftRu", xlinkHref: "/icons/sprite.svg#musicLogoLeftRu" })
            ]);
          });
        },
        1893: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationCollection_xs",
                xlinkHref: "/icons/sprite.svg#navigationCollection_xs"
              })
            ]);
          });
        },
        1563: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationConcerts_xs",
                xlinkHref: "/icons/sprite.svg#navigationConcerts_xs"
              })
            ]);
          });
        },
        1578: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationForYouAndTrends_xs",
                xlinkHref: "/icons/sprite.svg#navigationForYouAndTrends_xs"
              })
            ]);
          });
        },
        9348: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "navigationKids_xs", xlinkHref: "/icons/sprite.svg#navigationKids_xs" })
            ]);
          });
        },
        965: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationMyVibe_xs",
                xlinkHref: "/icons/sprite.svg#navigationMyVibe_xs"
              })
            ]);
          });
        },
        3877: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationNonMusic_xs",
                xlinkHref: "/icons/sprite.svg#navigationNonMusic_xs"
              })
            ]);
          });
        },
        9968: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "navigationPlus_xs", xlinkHref: "/icons/sprite.svg#navigationPlus_xs" })
            ]);
          });
        },
        3778: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationSearch_xs",
                xlinkHref: "/icons/sprite.svg#navigationSearch_xs"
              })
            ]);
          });
        },
        1084: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xs", xlinkHref: "/icons/sprite.svg#next_xs" })
            ]);
          });
        },
        4483: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xxl", xlinkHref: "/icons/sprite.svg#next_xxl" })
            ]);
          });
        },
        811: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xxs", xlinkHref: "/icons/sprite.svg#next_xxs" })
            ]);
          });
        },
        7252: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "non_music_m", xlinkHref: "/icons/sprite.svg#non_music_m" })
            ]);
          });
        },
        3013: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "non_music_selected_m",
                xlinkHref: "/icons/sprite.svg#non_music_selected_m"
              })
            ]);
          });
        },
        2774: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_s", xlinkHref: "/icons/sprite.svg#note_s" })
            ]);
          });
        },
        4298: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_xl", xlinkHref: "/icons/sprite.svg#note_xl" })
            ]);
          });
        },
        4254: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_xs", xlinkHref: "/icons/sprite.svg#note_xs" })
            ]);
          });
        },
        8499: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "offline_xxl", xlinkHref: "/icons/sprite.svg#offline_xxl" })
            ]);
          });
        },
        4997: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pauseVibe_s", xlinkHref: "/icons/sprite.svg#pauseVibe_s" })
            ]);
          });
        },
        7076: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_l", xlinkHref: "/icons/sprite.svg#pause_filled_l" })
            ]);
          });
        },
        3792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_m", xlinkHref: "/icons/sprite.svg#pause_filled_m" })
            ]);
          });
        },
        5132: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xl", xlinkHref: "/icons/sprite.svg#pause_filled_xl" })
            ]);
          });
        },
        8131: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xs", xlinkHref: "/icons/sprite.svg#pause_filled_xs" })
            ]);
          });
        },
        705: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xxl", xlinkHref: "/icons/sprite.svg#pause_filled_xxl" })
            ]);
          });
        },
        5346: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_m", xlinkHref: "/icons/sprite.svg#pause_m" })
            ]);
          });
        },
        792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_xs", xlinkHref: "/icons/sprite.svg#pause_xs" })
            ]);
          });
        },
        6122: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_xxs", xlinkHref: "/icons/sprite.svg#pause_xxs" })
            ]);
          });
        },
        5386: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pencil_xxs", xlinkHref: "/icons/sprite.svg#pencil_xxs" })
            ]);
          });
        },
        3146: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_s", xlinkHref: "/icons/sprite.svg#picture_s" })
            ]);
          });
        },
        8868: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_xl", xlinkHref: "/icons/sprite.svg#picture_xl" })
            ]);
          });
        },
        1125: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_xs", xlinkHref: "/icons/sprite.svg#picture_xs" })
            ]);
          });
        },
        976: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_filled_xs", xlinkHref: "/icons/sprite.svg#pin_filled_xs" })
            ]);
          });
        },
        9434: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_filled_xxs", xlinkHref: "/icons/sprite.svg#pin_filled_xxs" })
            ]);
          });
        },
        9288: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_xs", xlinkHref: "/icons/sprite.svg#pin_xs" })
            ]);
          });
        },
        3201: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_xxs", xlinkHref: "/icons/sprite.svg#pin_xxs" })
            ]);
          });
        },
        8112: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playLast_xxs", xlinkHref: "/icons/sprite.svg#playLast_xxs" })
            ]);
          });
        },
        8044: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playNext_xxs", xlinkHref: "/icons/sprite.svg#playNext_xxs" })
            ]);
          });
        },
        8303: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playQueue_m", xlinkHref: "/icons/sprite.svg#playQueue_m" })
            ]);
          });
        },
        9863: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playQueue_xs", xlinkHref: "/icons/sprite.svg#playQueue_xs" })
            ]);
          });
        },
        2084: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playVibe_s", xlinkHref: "/icons/sprite.svg#playVibe_s" })
            ]);
          });
        },
        8582: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_l", xlinkHref: "/icons/sprite.svg#play_filled_l" })
            ]);
          });
        },
        4777: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_m", xlinkHref: "/icons/sprite.svg#play_filled_m" })
            ]);
          });
        },
        8779: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xl", xlinkHref: "/icons/sprite.svg#play_filled_xl" })
            ]);
          });
        },
        1945: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xs", xlinkHref: "/icons/sprite.svg#play_filled_xs" })
            ]);
          });
        },
        7402: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xxl", xlinkHref: "/icons/sprite.svg#play_filled_xxl" })
            ]);
          });
        },
        1351: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_m", xlinkHref: "/icons/sprite.svg#play_m" })
            ]);
          });
        },
        1874: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xs", xlinkHref: "/icons/sprite.svg#play_xs" })
            ]);
          });
        },
        2026: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xxs", xlinkHref: "/icons/sprite.svg#play_xxs" })
            ]);
          });
        },
        5378: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xxxs", xlinkHref: "/icons/sprite.svg#play_xxxs" })
            ]);
          });
        },
        3751: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_s", xlinkHref: "/icons/sprite.svg#playlist_s" })
            ]);
          });
        },
        8503: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_xl", xlinkHref: "/icons/sprite.svg#playlist_xl" })
            ]);
          });
        },
        1580: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_xs", xlinkHref: "/icons/sprite.svg#playlist_xs" })
            ]);
          });
        },
        8861: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plus", xlinkHref: "/icons/sprite.svg#plus" })
            ]);
          });
        },
        6809: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusBadge", xlinkHref: "/icons/sprite.svg#plusBadge" })
            ]);
          });
        },
        5266: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusColor", xlinkHref: "/icons/sprite.svg#plusColor" })
            ]);
          });
        },
        1179: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusOutlined", xlinkHref: "/icons/sprite.svg#plusOutlined" })
            ]);
          });
        },
        735: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusOutlined_m", xlinkHref: "/icons/sprite.svg#plusOutlined_m" })
            ]);
          });
        },
        2754: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "podcasts_xxs", xlinkHref: "/icons/sprite.svg#podcasts_xxs" })
            ]);
          });
        },
        4091: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xs", xlinkHref: "/icons/sprite.svg#previous_xs" })
            ]);
          });
        },
        1427: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xxl", xlinkHref: "/icons/sprite.svg#previous_xxl" })
            ]);
          });
        },
        5251: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xxs", xlinkHref: "/icons/sprite.svg#previous_xxs" })
            ]);
          });
        },
        895: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_one_xs", xlinkHref: "/icons/sprite.svg#repeat_one_xs" })
            ]);
          });
        },
        5632: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_one_xxs", xlinkHref: "/icons/sprite.svg#repeat_one_xxs" })
            ]);
          });
        },
        8090: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_xs", xlinkHref: "/icons/sprite.svg#repeat_xs" })
            ]);
          });
        },
        9370: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_xxs", xlinkHref: "/icons/sprite.svg#repeat_xxs" })
            ]);
          });
        },
        1001: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "reset_xxs", xlinkHref: "/icons/sprite.svg#reset_xxs" })
            ]);
          });
        },
        6579: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "reset_xxxs", xlinkHref: "/icons/sprite.svg#reset_xxxs" })
            ]);
          });
        },
        5910: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "rewindBackwards_xs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xs"
              })
            ]);
          });
        },
        893: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "rewindBackwards_xxs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xxs"
              })
            ]);
          });
        },
        4892: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "rewindForward_xs", xlinkHref: "/icons/sprite.svg#rewindForward_xs" })
            ]);
          });
        },
        6331: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "rewindForward_xxs", xlinkHref: "/icons/sprite.svg#rewindForward_xxs" })
            ]);
          });
        },
        2176: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_m", xlinkHref: "/icons/sprite.svg#ruble_m" })
            ]);
          });
        },
        9876: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_xxs", xlinkHref: "/icons/sprite.svg#ruble_xxs" })
            ]);
          });
        },
        3935: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_xxxs", xlinkHref: "/icons/sprite.svg#ruble_xxxs" })
            ]);
          });
        },
        7643: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_l", xlinkHref: "/icons/sprite.svg#search_l" })
            ]);
          });
        },
        8235: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_m", xlinkHref: "/icons/sprite.svg#search_m" })
            ]);
          });
        },
        8915: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_selected_m", xlinkHref: "/icons/sprite.svg#search_selected_m" })
            ]);
          });
        },
        3366: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_xs", xlinkHref: "/icons/sprite.svg#search_xs" })
            ]);
          });
        },
        7934: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_xxl", xlinkHref: "/icons/sprite.svg#search_xxl" })
            ]);
          });
        },
        5034: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "settings_xs", xlinkHref: "/icons/sprite.svg#settings_xs" })
            ]);
          });
        },
        1758: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "settings_xxs", xlinkHref: "/icons/sprite.svg#settings_xxs" })
            ]);
          });
        },
        7196: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "share_xxs", xlinkHref: "/icons/sprite.svg#share_xxs" })
            ]);
          });
        },
        5792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "shuffle_xs", xlinkHref: "/icons/sprite.svg#shuffle_xs" })
            ]);
          });
        },
        7951: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "shuffle_xxs", xlinkHref: "/icons/sprite.svg#shuffle_xxs" })
            ]);
          });
        },
        9545: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "site_xs", xlinkHref: "/icons/sprite.svg#site_xs" })
            ]);
          });
        },
        2037: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_25x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_m"
              })
            ]);
          });
        },
        3362: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_25x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_xs"
              })
            ]);
          });
        },
        9846: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_25x_l", xlinkHref: "/icons/sprite.svg#speed_1_25x_l" })
            ]);
          });
        },
        5197: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_5x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_m"
              })
            ]);
          });
        },
        1079: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_5x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_xs"
              })
            ]);
          });
        },
        6275: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_5x_l", xlinkHref: "/icons/sprite.svg#speed_1_5x_l" })
            ]);
          });
        },
        7026: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_75x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_m"
              })
            ]);
          });
        },
        8994: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_75x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_xs"
              })
            ]);
          });
        },
        3702: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_75x_l", xlinkHref: "/icons/sprite.svg#speed_1_75x_l" })
            ]);
          });
        },
        8664: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_m"
              })
            ]);
          });
        },
        51: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_xs"
              })
            ]);
          });
        },
        8550: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1x_l", xlinkHref: "/icons/sprite.svg#speed_1x_l" })
            ]);
          });
        },
        8619: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_2x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_m"
              })
            ]);
          });
        },
        5218: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_2x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_xs"
              })
            ]);
          });
        },
        857: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_2x_l", xlinkHref: "/icons/sprite.svg#speed_2x_l" })
            ]);
          });
        },
        6130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_m", xlinkHref: "/icons/sprite.svg#syncLyrics_m" })
            ]);
          });
        },
        3049: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_xs", xlinkHref: "/icons/sprite.svg#syncLyrics_xs" })
            ]);
          });
        },
        126: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_xxs", xlinkHref: "/icons/sprite.svg#syncLyrics_xxs" })
            ]);
          });
        },
        6210: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ticket_m", xlinkHref: "/icons/sprite.svg#ticket_m" })
            ]);
          });
        },
        5596: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ticket_selected_m", xlinkHref: "/icons/sprite.svg#ticket_selected_m" })
            ]);
          });
        },
        380: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "trailer_xs", xlinkHref: "/icons/sprite.svg#trailer_xs" })
            ]);
          });
        },
        3112: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "trailer_xxs", xlinkHref: "/icons/sprite.svg#trailer_xxs" })
            ]);
          });
        },
        1045: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unavailable_xl", xlinkHref: "/icons/sprite.svg#unavailable_xl" })
            ]);
          });
        },
        2834: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unavailable_xs", xlinkHref: "/icons/sprite.svg#unavailable_xs" })
            ]);
          });
        },
        8819: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unpin_xxs", xlinkHref: "/icons/sprite.svg#unpin_xxs" })
            ]);
          });
        },
        8772: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "upload_xxs", xlinkHref: "/icons/sprite.svg#upload_xxs" })
            ]);
          });
        },
        3522: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "users_xxxs", xlinkHref: "/icons/sprite.svg#users_xxxs" })
            ]);
          });
        },
        5695: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "vibe_xxs", xlinkHref: "/icons/sprite.svg#vibe_xxs" })
            ]);
          });
        },
        6174: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "volumeOff_xs", xlinkHref: "/icons/sprite.svg#volumeOff_xs" })
            ]);
          });
        },
        540: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "volume_xs", xlinkHref: "/icons/sprite.svg#volume_xs" })
            ]);
          });
        },
        6206: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "windows", xlinkHref: "/icons/sprite.svg#windows" })
            ]);
          });
        },
        7185: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "windows_xs", xlinkHref: "/icons/sprite.svg#windows_xs" })
            ]);
          });
        },
        9481: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexBooksEn", xlinkHref: "/icons/sprite.svg#yandexBooksEn" })
            ]);
          });
        },
        7364: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexBooksRu", xlinkHref: "/icons/sprite.svg#yandexBooksRu" })
            ]);
          });
        },
        8577: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPayEn", xlinkHref: "/icons/sprite.svg#yandexPayEn" })
            ]);
          });
        },
        5760: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPayRu", xlinkHref: "/icons/sprite.svg#yandexPayRu" })
            ]);
          });
        },
        5667: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPlusEn", xlinkHref: "/icons/sprite.svg#yandexPlusEn" })
            ]);
          });
        },
        2639: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPlusRu", xlinkHref: "/icons/sprite.svg#yandexPlusRu" })
            ]);
          });
        },
        8691: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useCallbackRef = void 0;
          let n2 = r2(810);
          t2.useCallbackRef = function(e3) {
            let t3 = (0, n2.useRef)({
              stableFn: function() {
                for (var e4 = arguments.length, r3 = Array(e4), n3 = 0; n3 < e4; n3++) r3[n3] = arguments[n3];
                return t3.current.callback(...r3);
              },
              callback: e3
            });
            return (0, n2.useInsertionEffect)(() => {
              t3.current.callback = e3;
            }), t3.current.stableFn;
          };
        },
        1381: (e2, t2, r2) => {
          var n2;
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useComponentSwipeable = t2.SwipeablePlacement = void 0;
          let s2 = r2(4490), a2 = r2(8691);
          !(function(e3) {
            e3.TOP = "top", e3.BOTTOM = "bottom", e3.RIGHT = "right", e3.LEFT = "left";
          })(n2 || (t2.SwipeablePlacement = n2 = {}));
          let i2 = (e3) => {
            let { ref: t3, deltaY: r3, deltaX: s3, placement: a3 } = e3;
            requestAnimationFrame(() => {
              t3.current && (t3.current.style.willChange = "transform", t3.current.style.transform = a3 === n2.TOP || a3 === n2.BOTTOM ? "translateY(".concat(r3 || 0, "px)") : "translateX(".concat(s3 || 0, "px)"));
            });
          }, o2 = (e3) => {
            requestAnimationFrame(() => {
              e3.current && (e3.current.style.transition = "none", e3.current.style.willChange = "", e3.current.style.transform = "");
            });
          };
          t2.useComponentSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: l2, disableSwipe: c2, placement: u2, threshold: f } = e3, d = (0, a2.useCallbackRef)(() => {
              l2 && (o2(t3), l2());
            }), x = (0, a2.useCallbackRef)((e4) => {
              c2 || ((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3 } = e5;
                switch (a3) {
                  case n2.TOP:
                    r4 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.RIGHT:
                    s3 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.LEFT:
                    s3 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  default:
                    r4 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2 });
            }), p = (0, a2.useCallbackRef)((e4) => {
              !c2 && (((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3, threshold: i3 = 25 } = e5;
                if (!t4.current) return false;
                let o3 = i3 / 100 * (a3 === n2.TOP || a3 === n2.BOTTOM ? t4.current.offsetHeight : t4.current.offsetWidth);
                switch (a3) {
                  case n2.TOP:
                    return r4 < 0 && Math.abs(r4) >= o3;
                  case n2.RIGHT:
                    return s3 > 0 && s3 >= o3;
                  case n2.LEFT:
                    return s3 < 0 && Math.abs(s3) >= o3;
                  default:
                    return r4 > 0 && r4 >= o3;
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2, threshold: f }) ? l2 && (o2(t3), l2()) : o2(t3));
            });
            return {
              handlers: (0, s2.useSwipeable)({ onSwiped: p, onSwiping: x, trackMouse: true, trackTouch: true, ...r3 }),
              onCloseCallback: d
            };
          };
        },
        2451: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useModalSwipeable = void 0;
          let n2 = r2(810), s2 = r2(1381);
          t2.useModalSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: a2, disableSwipe: i2, placement: o2, threshold: l2 } = e3, c2 = (0, n2.useMemo)(() => {
              switch (o2) {
                case "default":
                default:
                  return s2.SwipeablePlacement.BOTTOM;
                case "right":
                  return s2.SwipeablePlacement.RIGHT;
              }
            }, [o2]);
            return (0, s2.useComponentSwipeable)({
              ref: t3,
              swipeableProps: r3,
              onClose: a2,
              disableSwipe: i2,
              placement: c2,
              threshold: l2
            });
          };
        },
        5932: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useNavigationListener = void 0;
          let n2 = r2(810);
          t2.useNavigationListener = function(e3) {
            let t3 = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1];
            (0, n2.useEffect)(() => {
              if (!t3) return;
              let r3 = window.navigation;
              if (r3)
                return r3.addEventListener("navigate", e3), () => {
                  r3.removeEventListener("navigate", e3);
                };
            }, [e3, t3]);
          };
        },
        8796: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.createRipple = void 0, t2.createRipple = function(e3, t3, r2) {
            let n2 = null != r2 ? r2 : e3.currentTarget, s2 = document.createElement("span"), a2 = Math.max(n2.clientWidth, n2.clientHeight), i2 = a2 / 2, o2 = n2.getBoundingClientRect(), l2 = 0 === e3.clientX ? Math.round(o2.width / 2) : e3.clientX - o2.left, c2 = 0 === e3.clientY ? Math.round(o2.height / 2) : e3.clientY - o2.top;
            s2.style.width = "".concat(a2, "px"), s2.style.height = "".concat(a2, "px"), s2.style.left = 0 === e3.clientX ? "0px" : "".concat(l2 - i2, "px"), s2.style.top = "".concat(c2 - i2, "px"), s2.classList.add(t3);
            let u2 = n2.getElementsByClassName(t3)[0];
            u2 && u2.remove(), n2.insertBefore(s2, n2.firstChild);
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        8216: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = t2.createRipple = void 0;
          var n2 = r2(8796);
          Object.defineProperty(t2, "createRipple", {
            enumerable: true,
            get: function() {
              return n2.createRipple;
            }
          });
          var s2 = r2(361);
          Object.defineProperty(t2, "getElementFromRefOrElement", {
            enumerable: true,
            get: function() {
              return s2.getElementFromRefOrElement;
            }
          });
        },
        8119: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = r2(8216), l2 = n2(r2(1920)), c2 = (e3) => {
            let {
              forwardRef: t3,
              isBlock: r3,
              iconPosition: n3 = "left",
              children: c3,
              className: u2,
              color: f = "secondary",
              flexIcon: d,
              icon: x,
              spinner: p,
              role: _,
              onClick: m,
              radius: v = "m",
              size: g,
              type: b = "button",
              variant: y = "default",
              withRipple: h = true,
              withHover: k = true,
              withBorder: E = false,
              disabled: w,
              iconClassName: j,
              contentContainerClassName: O,
              ...R
            } = e3, C = (0, a2.useId)(), S = !a2.Children.toArray(c3).filter(Boolean).length, P = "left" === n3, A = null, T = (0, a2.isValidElement)(p);
            if (x) {
              var H, M;
              A = (0, a2.cloneElement)(x, {
                className: (0, i2.clsx)(
                  l2.default.icon,
                  {
                    [l2.default["icon_position_".concat(n3)]]: n3 && !S,
                    [l2.default.icon_withButtonSize]: !(null == (H = x.props) ? void 0 : H.size)
                  },
                  null == (M = x.props) ? void 0 : M.className,
                  j
                ),
                key: C
              });
            }
            let N = (0, a2.useMemo)(
              () => T ? (0, s2.jsx)("div", { className: l2.default.spinnerContainer, children: p }) : null,
              [T, p]
            ), I = (0, a2.useCallback)(
              (e4) => {
                T || (h && (0, o2.createRipple)(e4, l2.default.ripple), null == m || m(e4));
              },
              [T, m, h]
            );
            return (0, s2.jsx)("button", {
              ref: t3,
              className: (0, i2.clsx)(
                l2.default.root,
                l2.default["root_".concat(f, "_").concat(y)],
                l2.default["root_radius_".concat(v)],
                l2.default.root_size,
                {
                  [l2.default["root_".concat(f, "_withHover_").concat(y)]]: k && !w && !T,
                  [l2.default["root_size_".concat(g)]]: g,
                  [l2.default.root_withoutBorder]: !E,
                  [l2.default.root_withActiveSpinner]: T,
                  [l2.default.block]: r3,
                  [l2.default.flexIcon]: d,
                  [l2.default.iconOnly]: S,
                  [l2.default.root_icon_left]: x && !S && P,
                  [l2.default.root_icon_right]: x && !S && !P
                },
                u2
              ),
              type: b,
              role: _,
              onClick: I,
              ...R,
              disabled: w,
              "aria-live": T ? "polite" : "off",
              "aria-busy": T,
              children: x || T ? (0, s2.jsxs)("span", {
                className: (0, i2.clsx)(
                  l2.default.contentContainer,
                  { [l2.default.contentContainer_block]: r3 },
                  O
                ),
                children: [x && P && A, !S && c3, x && !P && A, N]
              }) : c3
            });
          };
          t2.Button = (0, a2.forwardRef)((e3, t3) => (0, s2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        5928: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          var n2 = r2(8119);
          Object.defineProperty(t2, "Button", {
            enumerable: true,
            get: function() {
              return n2.Button;
            }
          });
        },
        5189: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = t2.IconComponent = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = r2(5151), l2 = n2(r2(2964));
          t2.IconComponent = (e3) => {
            let { "aria-label": t3, className: r3, focusable: n3 = false, variant: a3, size: c2, forwardRef: u2, ...f } = e3, d = c2 ? "".concat(a3, "_").concat(c2) : a3, x = o2.iconsCollection[d];
            return x ? (0, s2.jsx)(x, {
              className: (0, i2.clsx)(l2.default.root, r3, l2.default["root_size_".concat(c2)]),
              focusable: n3,
              "aria-label": t3,
              ...f,
              "aria-hidden": !t3,
              ref: u2
            }) : null;
          }, t2.Icon = (0, a2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.IconComponent, { forwardRef: r3, ...e3 }));
        },
        5151: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e10) {
            return e10 && e10.__esModule ? e10 : { default: e10 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.iconsCollection = t2.iconsCollectionBySize = void 0;
          let s2 = n2(r2(4656)), a2 = n2(r2(8170)), i2 = n2(r2(5565)), o2 = n2(r2(8127)), l2 = n2(r2(8993)), c2 = n2(r2(2933)), u2 = n2(r2(1334)), f = n2(r2(1426)), d = n2(r2(5378)), x = n2(r2(6579)), p = n2(r2(3935)), _ = n2(r2(3522)), m = n2(r2(7319)), v = n2(r2(8442)), g = n2(r2(2586)), b = n2(r2(5822)), y = n2(r2(5272)), h = n2(r2(4860)), k = n2(r2(8711)), E = n2(r2(8109)), w = n2(r2(4904)), j = n2(r2(5971)), O = n2(r2(3331)), R = n2(r2(9783)), C = n2(r2(8184)), S = n2(r2(4926)), P = n2(r2(3176)), A = n2(r2(4789)), T = n2(r2(8151)), H = n2(r2(8690)), M = n2(r2(1524)), N = n2(r2(2361)), I = n2(r2(3972)), L = n2(r2(9330)), B = n2(r2(7346)), D = n2(r2(2604)), z = n2(r2(6894)), F = n2(r2(6391)), U = n2(r2(9369)), W = n2(r2(226)), V = n2(r2(8130)), Y = n2(r2(5270)), K = n2(r2(3560)), X = n2(r2(7513)), q = n2(r2(9838)), Q = n2(r2(9104)), G = n2(r2(7399)), Z = n2(r2(5849)), $ = n2(r2(3613)), J = n2(r2(9372)), ee = n2(r2(3709)), et = n2(r2(3685)), er = n2(r2(3302)), en = n2(r2(811)), es = n2(r2(6122)), ea = n2(r2(5386)), ei = n2(r2(3201)), eo = n2(r2(9434)), el = n2(r2(2026)), ec = n2(r2(8112)), eu = n2(r2(8044)), ef = n2(r2(2754)), ed = n2(r2(5251)), ex = n2(r2(9370)), ep = n2(r2(5632)), e_ = n2(r2(1001)), em = n2(r2(893)), ev = n2(r2(6331)), eg = n2(r2(9876)), eb = n2(r2(1758)), ey = n2(r2(7196)), eh = n2(r2(7951)), ek = n2(r2(126)), eE = n2(r2(3112)), ew = n2(r2(8819)), ej = n2(r2(8772)), eO = n2(r2(5695)), eR = n2(r2(7171)), eC = n2(r2(9030)), eS = n2(r2(9422)), eP = n2(r2(1491)), eA = n2(r2(2337)), eT = n2(r2(9202)), eH = n2(r2(130)), eM = n2(r2(7923)), eN = n2(r2(3654)), eI = n2(r2(6507)), eL = n2(r2(3193)), eB = n2(r2(30)), eD = n2(r2(7802)), ez = n2(r2(3738)), eF = n2(r2(2340)), eU = n2(r2(2125)), eW = n2(r2(4014)), eV = n2(r2(896)), eY = n2(r2(1829)), eK = n2(r2(1893)), eX = n2(r2(1563)), eq = n2(r2(1578)), eQ = n2(r2(9348)), eG = n2(r2(965)), eZ = n2(r2(3877)), e$ = n2(r2(9968)), eJ = n2(r2(3778)), e0 = n2(r2(1084)), e1 = n2(r2(4254)), e8 = n2(r2(792)), e4 = n2(r2(8131)), e5 = n2(r2(1125)), e6 = n2(r2(9288)), e7 = n2(r2(976)), e22 = n2(r2(1874)), e3 = n2(r2(9863)), e9 = n2(r2(1945)), te = n2(r2(1580)), tt = n2(r2(4091)), tr = n2(r2(8090)), tn = n2(r2(895)), ts = n2(r2(5910)), ta = n2(r2(4892)), ti = n2(r2(3366)), to = n2(r2(5034)), tl = n2(r2(5792)), tc = n2(r2(9545)), tu = n2(r2(3362)), tf = n2(r2(1079)), td = n2(r2(8994)), tx = n2(r2(51)), tp = n2(r2(5218)), t_ = n2(r2(3049)), tm = n2(r2(380)), tv = n2(r2(2834)), tg = n2(r2(540)), tb = n2(r2(6174)), ty = n2(r2(7185)), th = n2(r2(9351)), tk = n2(r2(2092)), tE = n2(r2(1162)), tw = n2(r2(6837)), tj = n2(r2(2024)), tO = n2(r2(776)), tR = n2(r2(5720)), tC = n2(r2(2774)), tS = n2(r2(4997)), tP = n2(r2(3146)), tA = n2(r2(2084)), tT = n2(r2(3751)), tH = n2(r2(3076)), tM = n2(r2(2495)), tN = n2(r2(9509)), tI = n2(r2(8987)), tL = n2(r2(190)), tB = n2(r2(843)), tD = n2(r2(5122)), tz = n2(r2(7405)), tF = n2(r2(820)), tU = n2(r2(5443)), tW = n2(r2(8782)), tV = n2(r2(7252)), tY = n2(r2(3013)), tK = n2(r2(5346)), tX = n2(r2(3792)), tq = n2(r2(1351)), tQ = n2(r2(8303)), tG = n2(r2(4777)), tZ = n2(r2(735)), t$ = n2(r2(2176)), tJ = n2(r2(8235)), t0 = n2(r2(8915)), t1 = n2(r2(2037)), t8 = n2(r2(5197)), t4 = n2(r2(7026)), t5 = n2(r2(8664)), t6 = n2(r2(8619)), t7 = n2(r2(6130)), t22 = n2(r2(6210)), t3 = n2(r2(5596)), t9 = n2(r2(6644)), re = n2(r2(996)), rt = n2(r2(7031)), rr = n2(r2(4793)), rn = n2(r2(7076)), rs = n2(r2(8582)), ra = n2(r2(7643)), ri = n2(r2(9846)), ro = n2(r2(6275)), rl = n2(r2(3702)), rc = n2(r2(8550)), ru = n2(r2(857)), rf = n2(r2(6304)), rd = n2(r2(9040)), rx = n2(r2(4298)), rp = n2(r2(5132)), r_ = n2(r2(8868)), rm = n2(r2(8779)), rv = n2(r2(8503)), rg = n2(r2(1045)), rb = n2(r2(7341)), ry = n2(r2(9505)), rh = n2(r2(4483)), rk = n2(r2(8499)), rE = n2(r2(705)), rw = n2(r2(7402)), rj = n2(r2(1427)), rO = n2(r2(7934)), rR = n2(r2(2435)), rC = n2(r2(3918)), rS = n2(r2(2571)), rP = n2(r2(2161)), rA = n2(r2(5304)), rT = n2(r2(2646)), rH = n2(r2(7500)), rM = n2(r2(6104)), rN = n2(r2(2502)), rI = n2(r2(1754)), rL = n2(r2(6615)), rB = n2(r2(7942)), rD = n2(r2(1498)), rz = n2(r2(8861)), rF = n2(r2(6809)), rU = n2(r2(5266)), rW = n2(r2(1179)), rV = n2(r2(6206)), rY = n2(r2(9481)), rK = n2(r2(7364)), rX = n2(r2(8577)), rq = n2(r2(5760)), rQ = n2(r2(5667)), rG = n2(r2(2639));
          t2.iconsCollectionBySize = {
            xxxs: [
              "adult",
              "arrowRight",
              "check",
              "close",
              "donation",
              "exclamation",
              "explicit",
              "listen",
              "play",
              "reset",
              "ruble",
              "users"
            ],
            xxs: [
              "add",
              "addToPlaylist",
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "artist",
              "bucket",
              "chain",
              "chartDown",
              "chartNew",
              "chartSame",
              "chartUp",
              "check",
              "clip",
              "close",
              "code",
              "crown",
              "dislike",
              "disliked",
              "download",
              "downloaded",
              "dragDots",
              "edit",
              "exclamation",
              "explicit",
              "eye_crossed",
              "filter",
              "info",
              "lightning",
              "like",
              "likeVariant",
              "liked",
              "likedVariant",
              "link",
              "lock",
              "lyrics",
              "macos",
              "menuArrow",
              "more",
              "next",
              "pause",
              "pencil",
              "pin",
              "pin_filled",
              "play",
              "playLast",
              "playNext",
              "podcasts",
              "previous",
              "repeat",
              "repeat_one",
              "reset",
              "rewindBackwards",
              "rewindForward",
              "ruble",
              "settings",
              "share",
              "shuffle",
              "syncLyrics",
              "trailer",
              "unpin",
              "upload",
              "vibe"
            ],
            xs: [
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "cast",
              "chain",
              "close",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "filter",
              "fullscreen",
              "like",
              "liked",
              "liteVersion",
              "lock",
              "more",
              "navigationCollection",
              "navigationConcerts",
              "navigationForYouAndTrends",
              "navigationKids",
              "navigationMyVibe",
              "navigationNonMusic",
              "navigationPlus",
              "navigationSearch",
              "next",
              "note",
              "pause",
              "pause_filled",
              "picture",
              "pin",
              "pin_filled",
              "play",
              "playQueue",
              "play_filled",
              "playlist",
              "previous",
              "repeat",
              "repeat_one",
              "rewindBackwards",
              "rewindForward",
              "search",
              "settings",
              "shuffle",
              "site",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "trailer",
              "unavailable",
              "volume",
              "volumeOff",
              "windows"
            ],
            s: [
              "adult",
              "album",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "likedVariant",
              "note",
              "pauseVibe",
              "picture",
              "playVibe",
              "playlist"
            ],
            m: [
              "collections",
              "collections_selected",
              "history",
              "home",
              "home_selected",
              "kids",
              "kids_selected",
              "like",
              "liked",
              "lock",
              "more",
              "non_music",
              "non_music_selected",
              "pause",
              "pause_filled",
              "play",
              "playQueue",
              "play_filled",
              "plusOutlined",
              "ruble",
              "search",
              "search_selected",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "ticket",
              "ticket_selected"
            ],
            l: [
              "add",
              "album",
              "download",
              "like",
              "pause_filled",
              "play_filled",
              "search",
              "speed_1_25x",
              "speed_1_5x",
              "speed_1_75x",
              "speed_1x",
              "speed_2x"
            ],
            xl: ["album", "clip", "note", "pause_filled", "picture", "play_filled", "playlist", "unavailable"],
            xxl: ["attention", "check", "next", "offline", "pause_filled", "play_filled", "previous", "search"],
            xxxl: ["attention"],
            "": [
              "bandlink",
              "booksLogo",
              "googlePlay",
              "huaweiAppGallery",
              "kinopoiskEn",
              "kinopoiskRu",
              "macos",
              "musicLogo",
              "musicLogoCenterEn",
              "musicLogoCenterRu",
              "musicLogoLeftEn",
              "musicLogoLeftRu",
              "plus",
              "plusBadge",
              "plusColor",
              "plusOutlined",
              "windows",
              "yandexBooksEn",
              "yandexBooksRu",
              "yandexPayEn",
              "yandexPayRu",
              "yandexPlusEn",
              "yandexPlusRu"
            ]
          }, t2.iconsCollection = {
            adult_xxxs: s2.default,
            arrowRight_xxxs: a2.default,
            check_xxxs: i2.default,
            close_xxxs: o2.default,
            donation_xxxs: l2.default,
            exclamation_xxxs: c2.default,
            explicit_xxxs: u2.default,
            listen_xxxs: f.default,
            play_xxxs: d.default,
            reset_xxxs: x.default,
            ruble_xxxs: p.default,
            users_xxxs: _.default,
            add_xxs: m.default,
            addToPlaylist_xxs: v.default,
            adult_xxs: g.default,
            album_xxs: b.default,
            arrowDown_xxs: y.default,
            arrowLeft_xxs: h.default,
            arrowRight_xxs: k.default,
            artist_xxs: E.default,
            bucket_xxs: w.default,
            chain_xxs: j.default,
            chartDown_xxs: O.default,
            chartNew_xxs: R.default,
            chartSame_xxs: C.default,
            chartUp_xxs: S.default,
            check_xxs: P.default,
            clip_xxs: A.default,
            close_xxs: T.default,
            code_xxs: H.default,
            crown_xxs: M.default,
            dislike_xxs: N.default,
            disliked_xxs: I.default,
            download_xxs: L.default,
            downloaded_xxs: B.default,
            dragDots_xxs: D.default,
            edit_xxs: z.default,
            exclamation_xxs: F.default,
            explicit_xxs: U.default,
            eye_crossed_xxs: W.default,
            filter_xxs: V.default,
            info_xxs: Y.default,
            lightning_xxs: K.default,
            like_xxs: X.default,
            likeVariant_xxs: q.default,
            liked_xxs: Q.default,
            likedVariant_xxs: G.default,
            link_xxs: Z.default,
            lock_xxs: $.default,
            lyrics_xxs: J.default,
            macos_xxs: ee.default,
            menuArrow_xxs: et.default,
            more_xxs: er.default,
            next_xxs: en.default,
            pause_xxs: es.default,
            pencil_xxs: ea.default,
            pin_xxs: ei.default,
            pin_filled_xxs: eo.default,
            play_xxs: el.default,
            playLast_xxs: ec.default,
            playNext_xxs: eu.default,
            podcasts_xxs: ef.default,
            previous_xxs: ed.default,
            repeat_xxs: ex.default,
            repeat_one_xxs: ep.default,
            reset_xxs: e_.default,
            rewindBackwards_xxs: em.default,
            rewindForward_xxs: ev.default,
            ruble_xxs: eg.default,
            settings_xxs: eb.default,
            share_xxs: ey.default,
            shuffle_xxs: eh.default,
            syncLyrics_xxs: ek.default,
            trailer_xxs: eE.default,
            unpin_xxs: ew.default,
            upload_xxs: ej.default,
            vibe_xxs: eO.default,
            adult_xs: eR.default,
            album_xs: eC.default,
            arrowDown_xs: eS.default,
            arrowLeft_xs: eP.default,
            arrowRight_xs: eA.default,
            cast_xs: eT.default,
            chain_xs: eH.default,
            close_xs: eM.default,
            dislike_xs: eN.default,
            disliked_xs: eI.default,
            exclamation_xs: eL.default,
            explicit_xs: eB.default,
            filter_xs: eD.default,
            fullscreen_xs: ez.default,
            like_xs: eF.default,
            liked_xs: eU.default,
            liteVersion_xs: eW.default,
            lock_xs: eV.default,
            more_xs: eY.default,
            navigationCollection_xs: eK.default,
            navigationConcerts_xs: eX.default,
            navigationForYouAndTrends_xs: eq.default,
            navigationKids_xs: eQ.default,
            navigationMyVibe_xs: eG.default,
            navigationNonMusic_xs: eZ.default,
            navigationPlus_xs: e$.default,
            navigationSearch_xs: eJ.default,
            next_xs: e0.default,
            note_xs: e1.default,
            pause_xs: e8.default,
            pause_filled_xs: e4.default,
            picture_xs: e5.default,
            pin_xs: e6.default,
            pin_filled_xs: e7.default,
            play_xs: e22.default,
            playQueue_xs: e3.default,
            play_filled_xs: e9.default,
            playlist_xs: te.default,
            previous_xs: tt.default,
            repeat_xs: tr.default,
            repeat_one_xs: tn.default,
            rewindBackwards_xs: ts.default,
            rewindForward_xs: ta.default,
            search_xs: ti.default,
            settings_xs: to.default,
            shuffle_xs: tl.default,
            site_xs: tc.default,
            speed_1_25x_centered_xs: tu.default,
            speed_1_5x_centered_xs: tf.default,
            speed_1_75x_centered_xs: td.default,
            speed_1x_centered_xs: tx.default,
            speed_2x_centered_xs: tp.default,
            syncLyrics_xs: t_.default,
            trailer_xs: tm.default,
            unavailable_xs: tv.default,
            volume_xs: tg.default,
            volumeOff_xs: tb.default,
            windows_xs: ty.default,
            adult_s: th.default,
            album_s: tk.default,
            dislike_s: tE.default,
            disliked_s: tw.default,
            exclamation_s: tj.default,
            explicit_s: tO.default,
            likedVariant_s: tR.default,
            note_s: tC.default,
            pauseVibe_s: tS.default,
            picture_s: tP.default,
            playVibe_s: tA.default,
            playlist_s: tT.default,
            collections_m: tH.default,
            collections_selected_m: tM.default,
            history_m: tN.default,
            home_m: tI.default,
            home_selected_m: tL.default,
            kids_m: tB.default,
            kids_selected_m: tD.default,
            like_m: tz.default,
            liked_m: tF.default,
            lock_m: tU.default,
            more_m: tW.default,
            non_music_m: tV.default,
            non_music_selected_m: tY.default,
            pause_m: tK.default,
            pause_filled_m: tX.default,
            play_m: tq.default,
            playQueue_m: tQ.default,
            play_filled_m: tG.default,
            plusOutlined_m: tZ.default,
            ruble_m: t$.default,
            search_m: tJ.default,
            search_selected_m: t0.default,
            speed_1_25x_centered_m: t1.default,
            speed_1_5x_centered_m: t8.default,
            speed_1_75x_centered_m: t4.default,
            speed_1x_centered_m: t5.default,
            speed_2x_centered_m: t6.default,
            syncLyrics_m: t7.default,
            ticket_m: t22.default,
            ticket_selected_m: t3.default,
            add_l: t9.default,
            album_l: re.default,
            download_l: rt.default,
            like_l: rr.default,
            pause_filled_l: rn.default,
            play_filled_l: rs.default,
            search_l: ra.default,
            speed_1_25x_l: ri.default,
            speed_1_5x_l: ro.default,
            speed_1_75x_l: rl.default,
            speed_1x_l: rc.default,
            speed_2x_l: ru.default,
            album_xl: rf.default,
            clip_xl: rd.default,
            note_xl: rx.default,
            pause_filled_xl: rp.default,
            picture_xl: r_.default,
            play_filled_xl: rm.default,
            playlist_xl: rv.default,
            unavailable_xl: rg.default,
            attention_xxl: rb.default,
            check_xxl: ry.default,
            next_xxl: rh.default,
            offline_xxl: rk.default,
            pause_filled_xxl: rE.default,
            play_filled_xxl: rw.default,
            previous_xxl: rj.default,
            search_xxl: rO.default,
            attention_xxxl: rR.default,
            bandlink: rC.default,
            booksLogo: rS.default,
            googlePlay: rP.default,
            huaweiAppGallery: rA.default,
            kinopoiskEn: rT.default,
            kinopoiskRu: rH.default,
            macos: rM.default,
            musicLogo: rN.default,
            musicLogoCenterEn: rI.default,
            musicLogoCenterRu: rL.default,
            musicLogoLeftEn: rB.default,
            musicLogoLeftRu: rD.default,
            plus: rz.default,
            plusBadge: rF.default,
            plusColor: rU.default,
            plusOutlined: rW.default,
            windows: rV.default,
            yandexBooksEn: rY.default,
            yandexBooksRu: rK.default,
            yandexPayEn: rX.default,
            yandexPayRu: rq.default,
            yandexPlusEn: rQ.default,
            yandexPlusRu: rG.default
          };
        },
        7066: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = void 0;
          var n2 = r2(5189);
          Object.defineProperty(t2, "Icon", {
            enumerable: true,
            get: function() {
              return n2.Icon;
            }
          });
        },
        3219: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Modal = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(1964), l2 = r2(6544), c2 = r2(5928), u2 = r2(7066), f = r2(2582), d = r2(2451), x = r2(5932), p = n2(r2(2260));
          t2.Modal = (e3) => {
            let {
              initialOpen: t3 = false,
              open: r3,
              onOpenChange: n3,
              children: _,
              className: m,
              labelClose: v,
              onClose: g,
              placement: b = "default",
              size: y = "default",
              title: h,
              header: k,
              showHeader: E = true,
              headerClassName: w,
              style: j,
              contentClassName: O,
              overlayClassName: R,
              portalNode: C,
              closeOnOutsidePress: S = true,
              withOverlay: P = true,
              withAnimation: A = true,
              closeButtonProps: T,
              containerProps: H,
              titleProps: M,
              escapeKey: N = true,
              lockScroll: I = true,
              overlayColor: L = "transparent",
              isMobile: B,
              disableFocusTrap: D = false,
              disableGuards: z = false,
              enableSwipe: F = false,
              swipableProps: U = {},
              transitionDuration: W = 300,
              customCloseButton: V,
              shouldCloseOnNavigate: Y = false,
              ...K
            } = e3, [X, q] = (0, i2.useState)(t3), Q = (0, i2.useRef)(null), G = null != r3 ? r3 : X, { context: Z, refs: $ } = (0, o2.useFloating)({ open: G, onOpenChange: null != n3 ? n3 : q }), { handlers: J } = (0, d.useModalSwipeable)({
              ref: $.floating,
              onClose: g,
              placement: b,
              disableSwipe: !F || !B || "center" === b,
              swipeableProps: { ...U, preventScrollOnSwipe: F }
            }), ee = (0, o2.useMergeRefs)([$.setFloating, null == J ? void 0 : J.ref]), et = (0, o2.useRole)(Z), er = (0, o2.useDismiss)(Z, { outsidePressEvent: "mousedown", outsidePress: S, escapeKey: N }), en = (0, o2.useClick)(Z), { getFloatingProps: es } = (0, o2.useInteractions)([et, er, en]), { status: ea } = (0, o2.useTransitionStatus)(Z), [ei, eo] = (() => {
              switch (b) {
                case "default":
                  return ["translate(-50%, 10%)", "translate(-50%, 0)"];
                case "center":
                  return ["translate(-50%, -40%)", "translate(-50%, -50%)"];
                case "right":
                  if ("undefined" != typeof document && "rtl" === document.dir)
                    return ["translateX(-5%)", "translateX(0)"];
                  return ["translateX(5%)", "translateX(0)"];
              }
            })(), { isMounted: el, styles: ec } = (0, o2.useTransitionStyles)(Z, {
              initial: { opacity: 0, transform: ei },
              open: { opacity: 1, transform: eo },
              duration: W
            }), eu = (0, i2.useMemo)(() => {
              var e4;
              return {
                ...j,
                "--header-height": Q.current ? "".concat(null == (e4 = Q.current) ? void 0 : e4.clientHeight, "px") : 0,
                ...A ? ec : {},
                ...B && (G || "close" === ea) && "center" !== b ? { insetInline: 0, insetBlockEnd: 0, transform: "none" } : {},
                onMouseDown: null == J ? void 0 : J.onMouseDown
              };
            }, [j, A, ec, G, null == J ? void 0 : J.onMouseDown, B, ea, b]), ef = (0, i2.useCallback)((e4) => {
              e4.stopPropagation();
            }, []), ed = (0, i2.useCallback)(() => {
              null == g || g();
            }, [g]);
            return ((0, x.useNavigationListener)(ed, Y && G), el) ? (0, s2.jsxs)(o2.FloatingPortal, {
              root: C,
              children: [
                P && (0, s2.jsx)(o2.FloatingOverlay, {
                  className: (0, a2.clsx)(p.default.overlay, R, p.default["overlay_".concat(L)]),
                  onClick: ef
                }),
                (0, s2.jsx)(o2.FloatingFocusManager, {
                  context: Z,
                  guards: !z,
                  modal: !D,
                  children: (0, s2.jsx)(l2.RemoveScroll, {
                    enabled: I && G,
                    children: (0, s2.jsxs)("div", {
                      ...K,
                      ref: ee,
                      ...es(),
                      style: eu,
                      className: (0, a2.clsx)(
                        p.default.root,
                        p.default["root_size_".concat(y)],
                        p.default["root_placement_".concat(b)],
                        { [p.default.root_withBlackShadow]: P && "full" === L },
                        m
                      ),
                      ...H,
                      children: [
                        E && (0, s2.jsxs)("header", {
                          className: (0, a2.clsx)(p.default.header, w),
                          ref: Q,
                          children: [
                            h && (0, s2.jsx)(f.Heading, {
                              className: p.default.title,
                              variant: "h3",
                              ...M,
                              children: h
                            }),
                            k,
                            null != V ? V : (0, s2.jsx)(c2.Button, {
                              radius: "round",
                              size: "xxs",
                              icon: (0, s2.jsx)(u2.Icon, { variant: "close", size: "xxs" }),
                              onClick: g,
                              "aria-label": v,
                              className: p.default.closeButton,
                              ...T,
                              color: "secondary"
                            })
                          ]
                        }),
                        (0, s2.jsx)("div", {
                          className: (0, a2.clsx)(p.default.content, { [p.default.content_withHeader]: E }, O),
                          children: _
                        })
                      ]
                    })
                  })
                })
              ]
            }) : null;
          };
        },
        7743: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Caption = t2.CaptionComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(4721), l2 = n2(r2(3641));
          t2.CaptionComponent = (e3) => {
            let {
              forwardRef: t3,
              variant: r3,
              type: n3 = "text",
              size: i3 = "s",
              className: c2,
              children: u2,
              weight: f = "medium",
              ...d
            } = e3;
            return (0, s2.jsx)(o2.Typography, {
              variant: r3,
              ref: t3,
              className: (0, a2.clsx)(
                l2.default.root,
                l2.default["root_".concat(n3, "_").concat(i3)],
                l2.default["root_weight_".concat(f)],
                c2
              ),
              ...d,
              children: u2
            });
          }, t2.Caption = (0, i2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.CaptionComponent, { forwardRef: r3, ...e3 }));
        },
        404: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.HeadingComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(4721), l2 = n2(r2(5153));
          t2.HeadingComponent = (e3) => {
            let { forwardRef: t3, variant: r3, weight: n3 = "bold", size: i3 = "s", className: c2, children: u2, ...f } = e3;
            return (0, s2.jsx)(o2.Typography, {
              variant: r3,
              ref: t3,
              className: (0, a2.clsx)(
                l2.default.root,
                l2.default["root_size_".concat(i3)],
                l2.default["root_weight_".concat(n3)],
                c2
              ),
              ...f,
              children: u2
            });
          }, t2.Heading = (0, i2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.HeadingComponent, { forwardRef: r3, ...e3 }));
        },
        4721: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Typography = t2.TypographyComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = n2(r2(5818));
          function l2(e3) {
            let { forwardRef: t3, style: r3, className: n3, children: i3, variant: l3, lineClamp: c2, ...u2 } = e3, f = c2 && "string" == typeof i3 ? i3 : void 0;
            return (0, s2.jsx)(l3, {
              style: { ...r3, WebkitLineClamp: c2 },
              ref: t3,
              title: f,
              className: (0, a2.clsx)(
                o2.default.root,
                {
                  [o2.default.root_clamp]: c2 && c2 > 0,
                  [o2.default.root_clamp_oneline]: c2 && 1 === c2,
                  [o2.default.root_clamp_multiline]: c2 && c2 > 1
                },
                n3
              ),
              ...u2,
              children: i3
            });
          }
          t2.TypographyComponent = l2, t2.Typography = (0, i2.forwardRef)((e3, t3) => (0, s2.jsx)(l2, { forwardRef: t3, ...e3 }));
        },
        2582: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.Caption = void 0;
          var n2 = r2(7743);
          Object.defineProperty(t2, "Caption", {
            enumerable: true,
            get: function() {
              return n2.Caption;
            }
          });
          var s2 = r2(404);
          Object.defineProperty(t2, "Heading", {
            enumerable: true,
            get: function() {
              return s2.Heading;
            }
          });
        },
        1964: (e2) => {
          e2.exports = s;
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(a, 2));
        }
      }, o = {};
      function l(e2) {
        var t2 = o[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = o[e2] = { exports: {} };
        return i[e2].call(r2.exports, r2, r2.exports, l), r2.exports;
      }
      l.d = (e2, t2) => {
        for (var r2 in t2) l.o(t2, r2) && !l.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, l.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), l.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      }, l.nc = void 0;
      var c = {};
      (() => {
        Object.defineProperty(c, "X", { value: true }), c.u = void 0;
        var e2 = l(3219);
        Object.defineProperty(c, "u", {
          enumerable: true,
          get: function() {
            return e2.Modal;
          }
        });
      })();
      var u = c.u;
      c.X;
    },
    33158: (e, t, r) => {
      "use strict";
      r.d(t, { RumScript: () => n }), r(54486), r(61910), r(67454), r(95723);
      let n = (e2) => {
        let { nonce: t2, requestId: r2, hostTld: n2, assetPrefix: s, env: a } = e2;
        return null;
      };
    },
    34932: (e, t, r) => {
      "use strict";
      r.d(t, { LoginPopover: () => _ });
      var n = r(54486), s = r(61910), a = r(43426), i = r(31500), o = r(8817), l = r(77881), c = r(97800), u = r(60440), f = r(1756), d = r(21673), x = r(16372), p = r(51828);
      let _ = (e2) => {
        let { textVariant: t2, vibeTextVariant: r2, ..._2 } = e2, m = (0, s.useId)(), { formatMessage: v } = (0, a.A)(), g = (() => {
          let { formatMessage: e3 } = (0, a.A)();
          return (0, s.useCallback)(
            (t3, r3) => {
              if ("vibe" === t3)
                switch (r3) {
                  case d.I.ALBUM:
                    return e3(
                      { id: "onboarding.authorize-and-buy-plus-to-listen-vibe-by-album" },
                      { br: "\n", nbsp: " " }
                    );
                  case d.I.ARTIST:
                    return e3(
                      { id: "onboarding.authorize-and-buy-plus-to-listen-vibe-by-artist" },
                      { br: "\n", nbsp: " " }
                    );
                  case d.I.PLAYLIST:
                    return e3(
                      { id: "onboarding.authorize-and-buy-plus-to-listen-vibe-by-playlist" },
                      { br: "\n", nbsp: " " }
                    );
                  case d.I.TRACK:
                    return e3(
                      { id: "onboarding.authorize-and-buy-plus-to-listen-vibe-by-track" },
                      { br: "\n", nbsp: " " }
                    );
                  case d.I.GENRE:
                  case d.I.MICRO_GENRE:
                    return e3(
                      { id: "onboarding.authorize-and-buy-plus-to-listen-vibe-by-genre" },
                      { br: "\n", nbsp: " " }
                    );
                  case d.I.MOOD:
                    return e3(
                      { id: "onboarding.authorize-and-buy-plus-to-listen-vibe-by-mood" },
                      { br: "\n", nbsp: " " }
                    );
                  case d.I.ACTIVITY:
                    return e3(
                      { id: "onboarding.authorize-and-buy-plus-to-listen-vibe-by-activity" },
                      { br: "\n", nbsp: " " }
                    );
                  default:
                    return e3({ id: "onboarding.authorize-and-buy-plus-to-listen-vibe" }, { nbsp: " " });
                }
              switch (t3) {
                case "fullTracks":
                  return e3({ id: "onboarding.authorize-and-buy-plus-to-listen-full" }, { br: "\n", nbsp: " " });
                case "changeQuality":
                  return e3({ id: "onboarding.authorize-and-buy-plus-to-change-quality" }, { br: "\n", nbsp: " " });
                case "addToCollection":
                  return e3(
                    { id: "onboarding.authorize-and-buy-plus-to-add-to-collection" },
                    { br: "\n", nbsp: " " }
                  );
                case "openQueue":
                  return e3({ id: "onboarding.authorize-and-buy-plus-to-open-queue" }, { br: "\n", nbsp: " " });
                case "addToQueue":
                  return e3(
                    { id: "onboarding.authorize-and-buy-plus-to-add-track-to-queue" },
                    { br: "\n", nbsp: " " }
                  );
                case "like":
                  return e3({ id: "onboarding.authorize-and-buy-plus-to-like" }, { br: "\n", nbsp: " " });
                case "dislike":
                  return e3({ id: "onboarding.authorize-and-buy-plus-to-dislike" }, { br: "\n", nbsp: " " });
                case "pin":
                  return e3({ id: "onboarding.authorize-and-buy-plus-to-pin" }, { br: "\n", nbsp: " " });
                case "sync-lyrics":
                  return e3(
                    { id: "onboarding.authorize-and-buy-plus-to-view-sync-lyrics" },
                    { br: "\n", nbsp: " " }
                  );
                default:
                  return "";
              }
            },
            [e3]
          );
        })(), {
          experiments: b,
          paywall: { modal: y }
        } = (0, u.useStore)(), h = b.checkExperiment(f.z.WebNextUnauthorizedSubscriptionButton, "on"), k = (0, s.useMemo)(() => {
          switch (r2) {
            case d.I.ALBUM:
              return v({ id: "onboarding.authorize-to-listen-vibe-by-album" }, { br: "\n", nbsp: " " });
            case d.I.ARTIST:
              return v({ id: "onboarding.authorize-to-listen-vibe-by-artist" }, { br: "\n", nbsp: " " });
            case d.I.PLAYLIST:
              return v({ id: "onboarding.authorize-to-listen-vibe-by-playlist" }, { br: "\n", nbsp: " " });
            case d.I.TRACK:
              return v({ id: "onboarding.authorize-to-listen-vibe-by-track" }, { br: "\n", nbsp: " " });
            case d.I.GENRE:
            case d.I.MICRO_GENRE:
              return v({ id: "onboarding.authorize-to-listen-vibe-by-genre" }, { br: "\n", nbsp: " " });
            case d.I.MOOD:
              return v({ id: "onboarding.authorize-to-listen-vibe-by-mood" }, { br: "\n", nbsp: " " });
            case d.I.ACTIVITY:
              return v({ id: "onboarding.authorize-to-listen-vibe-by-activity" }, { br: "\n", nbsp: " " });
            default:
              return v({ id: "onboarding.authorize-to-listen-vibe" }, { br: "\n", nbsp: " " });
          }
        }, [r2, v]), E = (0, s.useMemo)(() => {
          if (h) return g(t2, r2);
          switch (t2) {
            case "fullTracks":
              return v({ id: "onboarding.authorize-to-listen-full" }, { br: "\n", nbsp: " " });
            case "changeQuality":
              return v({ id: "onboarding.authorize-to-change-quality" }, { br: "\n", nbsp: " " });
            case "addToCollection":
              return v({ id: "onboarding.authorize-to-add-to-collection" }, { br: "\n", nbsp: " " });
            case "openQueue":
              return v({ id: "onboarding.authorize-to-open-queue" }, { br: "\n", nbsp: " " });
            case "addToQueue":
              return v({ id: "onboarding.authorize-to-add-track-to-queue" }, { br: "\n", nbsp: " " });
            case "like":
              return v({ id: "onboarding.authorize-to-like" }, { br: "\n", nbsp: " " });
            case "dislike":
              return v({ id: "onboarding.authorize-to-dislike" }, { br: "\n", nbsp: " " });
            case "pin":
              return v({ id: "onboarding.authorize-to-pin" }, { br: "\n", nbsp: " " });
            case "sync-lyrics":
              return v({ id: "onboarding.authorize-to-view-sync-lyrics" }, { br: "\n", nbsp: " " });
            case "vibe":
              return k;
            default:
              return "";
          }
        }, [v, g, h, t2, k, r2]), w = (0, o.c)(() => {
          y.open();
        }), j = (0, s.useMemo)(
          () => h ? (0, n.jsx)(l.$, {
            color: "plus",
            size: "xxs",
            radius: "xxxl",
            onClick: w,
            children: (0, n.jsx)(c.Caption, {
              variant: "div",
              size: "m",
              children: v({ id: "authorization.start-button" })
            })
          }) : (0, n.jsx)(p.UnauthorizedButton, { size: "xxs" }, m),
          [v, w, m, h]
        );
        return (0, n.jsx)(x.PopoverWithActions, {
          contentElement: (0, n.jsx)(c.Caption, { variant: "div", size: "l", weight: "bold", children: E }),
          buttons: [j],
          renderChildrenText: E,
          contentProps: (0, i.Am)(i.S7.LOGIN_POPOVER),
          ..._2
        });
      };
    },
    35190: (e, t, r) => {
      "use strict";
      r.d(t, { q: () => c });
      var n, s = r(61910), a = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        8445: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            wrapper: "EOWonrlAZfCxgDQrLIdO",
            fullCircle: "TNOA7GEcjPELn4mw8Zjz",
            progressCircle: "LyZUu89TXyP3Jmnxrn9r",
            progressCircle_withRoundStroke: "meplzQA7jf7cO_eu_HlZ"
          };
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        833: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.CircleProgress = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = n2(r2(8445));
          t2.CircleProgress = (e3) => {
            let {
              className: t3,
              value: r3,
              max: n3 = 100,
              size: l2 = 14,
              strokeWidth: c2 = 2,
              withRoundStroke: u,
              "aria-valuetext": f,
              "aria-busy": d,
              progressCircleClassName: x,
              fullCircleClassName: p,
              ..._
            } = e3, m = (l2 - c2) / 2, v = m + c2 / 2, g = 2 * Math.PI * m, b = 0.25 * g, y = (0, a2.useMemo)(() => {
              let e4 = Math.max(Math.min(r3, n3), 0) / n3;
              return "".concat(e4 * g, " ").concat((1 - e4) * g);
            }, [n3, r3, g]);
            return (0, s2.jsx)("div", {
              "aria-busy": d,
              className: t3,
              "aria-valuetext": f,
              role: "progressbar",
              "aria-valuemin": 0,
              "aria-valuemax": n3,
              "aria-valuenow": r3,
              "data-test-id": _["data-test-id"],
              children: (0, s2.jsxs)("svg", {
                className: o2.default.wrapper,
                width: l2,
                height: l2,
                viewBox: "0 0 ".concat(l2, " ").concat(l2),
                children: [
                  (0, s2.jsx)("circle", {
                    className: (0, i2.clsx)(o2.default.fullCircle, p),
                    r: m,
                    strokeWidth: c2,
                    cx: v,
                    cy: v,
                    role: "presentation"
                  }),
                  (0, s2.jsx)("circle", {
                    className: (0, i2.clsx)(
                      o2.default.progressCircle,
                      { [o2.default.progressCircle_withRoundStroke]: u },
                      x
                    ),
                    r: m,
                    strokeWidth: c2,
                    cx: v,
                    cy: v,
                    strokeDashoffset: b,
                    strokeDasharray: y,
                    role: "presentation"
                  })
                ]
              })
            });
          };
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(s, 2));
        }
      }, i = {};
      function o(e2) {
        var t2 = i[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = i[e2] = { exports: {} };
        return a[e2].call(r2.exports, r2, r2.exports, o), r2.exports;
      }
      o.d = (e2, t2) => {
        for (var r2 in t2) o.o(t2, r2) && !o.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, o.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), o.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var l = {};
      (() => {
        Object.defineProperty(l, "X", { value: true }), l.m = void 0;
        var e2 = o(833);
        Object.defineProperty(l, "m", {
          enumerable: true,
          get: function() {
            return e2.CircleProgress;
          }
        });
      })();
      var c = l.m;
      l.X;
    },
    35203: (e, t, r) => {
      "use strict";
      r.d(t, { FreemiumButton: () => c });
      var n = r(54486), s = r(61910), a = r(77881), i = r(22674), o = r(97800);
      let l = (e2) => {
        let {
          className: t2,
          mainTextFontSize: r2 = "l",
          mainTextClassName: l2,
          additionTextClassName: c2,
          onClick: u,
          isShimmerActive: f,
          isShimmerVisible: d,
          mainText: x,
          ariaLabel: p,
          additionText: _,
          forwardRef: m,
          ...v
        } = e2, g = (0, s.useCallback)(
          (e3) => {
            e3.stopPropagation(), e3.preventDefault(), null == u || u();
          },
          [u]
        );
        return d ? (0, n.jsx)(i.Shimmer, { className: t2, isActive: f, radius: "xxxl" }) : (0, n.jsxs)(a.$, {
          ref: m,
          className: t2,
          isBlock: true,
          color: "plus",
          variant: "default",
          size: "l",
          radius: "xxxl",
          onClick: g,
          "aria-label": p,
          ...v,
          children: [
            (0, n.jsx)(o.Caption, { className: l2, variant: "div", size: r2, lineClamp: 1, children: x }),
            (0, n.jsx)(o.Caption, { className: c2, variant: "div", size: "xs", lineClamp: 1, children: _ })
          ]
        });
      }, c = (0, s.forwardRef)((e2, t2) => (0, n.jsx)(l, { forwardRef: t2, ...e2 }));
    },
    35609: (e, t, r) => {
      "use strict";
      r.d(t, { DeeplinkToMobileProvider: () => c });
      var n = r(54486), s = r(61910), a = r(8817), i = r(39011), o = r(66904), l = r(85105);
      let c = (e2) => {
        let { children: t2, isEnabled: r2 } = e2, [c2, u] = (0, s.useState)(i.Lz), f = (0, a.c)((e3) => {
          let { href: t3 } = (0, l.u)(null != e3 ? e3 : "", { options: { host: i.Lz } });
          u(t3);
        }), d = (0, s.useMemo)(() => ({ deeplink: c2, setDeeplink: f, isEnabled: r2 }), [r2, f, c2]);
        return r2 ? (0, n.jsx)(o.H.Provider, { value: d, children: t2 }) : t2;
      };
    },
    36987: (e) => {
      e.exports = { root: "PaywallFAQQuestion_root__pS9KT" };
    },
    37226: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { ConcertShimmer: () => c });
      var n = r(54486), s = r(50420), a = r(43426), i = r(22674), o = r(91098), l = r.n(o);
      let c = (e2) => {
        let { className: t2, isShimmerActive: r2 } = e2, { formatMessage: o2 } = (0, a.A)();
        return (0, n.jsxs)("div", {
          "aria-label": o2({ id: "loading-messages.concert-is-loading" }),
          "aria-live": "polite",
          "aria-busy": true,
          className: (0, s.$)(l().root, t2),
          children: [
            (0, n.jsx)(i.Shimmer, { className: l().date, radius: "m", isActive: r2 }),
            (0, n.jsxs)("div", {
              className: l().meta,
              children: [
                (0, n.jsx)(i.Shimmer, { className: l().title, radius: "s", isActive: r2 }),
                (0, n.jsx)(i.Shimmer, { className: l().description, radius: "s", isActive: r2 })
              ]
            }),
            (0, n.jsx)(i.Shimmer, { className: l().action, radius: "l", isActive: r2 })
          ]
        });
      };
    },
    37257: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "PlayButtonWithCover_root__s6Orw",
        coverImage: "PlayButtonWithCover_coverImage__DhS1R",
        cover: "PlayButtonWithCover_cover__5__Ms",
        playingAnimation: "PlayButtonWithCover_playingAnimation__HWuOW",
        control: "PlayButtonWithCover_control__iZy3t",
        playButton: "PlayButtonWithCover_playButton__rV9pQ",
        playButton_loading: "PlayButtonWithCover_playButton_loading__bqydK",
        "applying-setting": "PlayButtonWithCover_applying-setting__ZvViA",
        root_current: "PlayButtonWithCover_root_current__2QYEm",
        root_playing: "PlayButtonWithCover_root_playing__tAgph",
        root_disabled: "PlayButtonWithCover_root_disabled__EHoIx",
        root_disliked: "PlayButtonWithCover_root_disliked__FoWzV",
        spinner: "PlayButtonWithCover_spinner__ryn04",
        playButtonIcon: "PlayButtonWithCover_playButtonIcon__DRjkN"
      };
    },
    38378: (e, t, r) => {
      "use strict";
      r.d(t, { DeeplinkAndOnelinkContainer: () => E });
      var n = r(54486), s = r(50420), a = r(28303), i = r(47713), o = r(8817), l = r(27510), c = r(77881), u = r(5956), f = r(97800), d = r(27915), x = r(66904), p = r(66446), _ = r(60440), m = r(79626), v = r(90461), g = r(16637), b = r(56999), y = r(8740), h = r.n(y);
      let k = "noreferrer noopener", E = (0, a.PA)(() => {
        var e2;
        let {
          settings: { browserInfo: t2 },
          user: { account: r2 }
        } = (0, _.useStore)(), { deeplink: a2 } = null != (e2 = (0, x.useDeeplinkToMobile)()) ? e2 : {}, y2 = (0, d.q)({ browserInfo: t2, login: r2.data.login }), { shouldShow: E2 } = (0, p.useSearchParamVisibility)({
          searchParamKey: b.K.UTM_SOURCE,
          storageKey: v.c.HideDeeplinkAndOnelink,
          searchParamHideValue: "bottomsheet"
        }), w = (0, l.L)(
          () => (null == t2 ? void 0 : t2.hasHuaweiAppGallery) ? "huaweiAppGallery" : (null == t2 ? void 0 : t2.OSFamily) === m.j.IOS ? "macos" : "googlePlay"
        ), j = (0, l.L)(
          () => (null == t2 ? void 0 : t2.hasHuaweiAppGallery) ? (0, n.jsx)(i.A, { id: "deeplinks.download-from-app-gallery" }) : (null == t2 ? void 0 : t2.OSFamily) === m.j.IOS ? (0, n.jsx)(i.A, { id: "deeplinks.download-from-app-store" }) : (0, n.jsx)(i.A, { id: "deeplinks.download-from-google-play" })
        ), O = (0, o.c)(() => {
          if (!a2) return;
          let e3 = new URLSearchParams(window.location.search);
          window.open((0, g.C)(a2, e3), "_self", k);
        }), R = (0, o.c)(() => {
          let e3 = new URLSearchParams(window.location.search), t3 = y2(a2 && (0, g.C)(a2, e3));
          window.open(t3, "_blank", k);
        });
        return E2 ? (0, n.jsxs)("div", {
          className: h().root,
          children: [
            (0, n.jsx)(c.$, {
              withRipple: false,
              withHover: false,
              onClick: O,
              radius: "xxxl",
              className: h().button,
              role: "link",
              icon: (0, n.jsx)(u.Icon, {
                className: (0, s.$)(h().buttonIcon, h().musicIcon),
                variant: "musicLogo"
              }),
              children: (0, n.jsx)(f.Caption, {
                className: h().buttonTitle,
                variant: "div",
                type: "text",
                size: "m",
                weight: "normal",
                children: (0, n.jsx)(i.A, { id: "deeplinks.listen-in-app" })
              })
            }),
            (0, n.jsx)(c.$, {
              withRipple: false,
              withHover: false,
              onClick: R,
              radius: "xxxl",
              className: h().button,
              role: "link",
              icon: (0, n.jsx)(u.Icon, { className: (0, s.$)(h().buttonIcon, h().onelinkIcon), variant: w }),
              children: (0, n.jsx)(f.Caption, {
                className: h().buttonTitle,
                variant: "div",
                type: "text",
                size: "m",
                weight: "normal",
                children: j
              })
            })
          ]
        }) : null;
      });
    },
    38644: (e, t, r) => {
      "use strict";
      r.d(t, { PlusModal: () => v });
      var n = r(54486), s = r(50420), a = r(28303), i = r(43426), o = r(31500), l = r(32692), c = r(60440), u = r(65250), f = r.n(u), d = r(5956), x = r(27187), p = r(22808), _ = r.n(p);
      let m = () => {
        let e2 = (0, x.j)();
        return (0, n.jsx)("div", {
          className: _().root,
          ...(0, o.Am)(o.e8.crackdownModal.CRACKDOWN_MODAL_LOGO),
          children: (0, n.jsx)(d.Icon, {
            variant: "yandexPlus".concat(e2),
            className: (0, s.$)(_().icon, _()["icon_".concat(e2.toLocaleLowerCase())])
          })
        });
      }, v = (0, a.PA)((e2) => {
        let { hasError: t2, children: r2, ...a2 } = e2, {
          settings: { isMobile: u2 }
        } = (0, c.useStore)(), { formatMessage: d2 } = (0, i.A)();
        return (0, n.jsxs)(l.a, {
          size: "fitContent",
          placement: u2 ? "default" : "center",
          labelClose: d2({ id: "interface-actions.close" }),
          className: (0, s.$)(f().root, { [f().root_mobile]: u2, [f().root_error]: t2 }),
          headerClassName: f().header,
          contentClassName: f().content,
          ...a2,
          closeButtonProps: (0, o.Am)(o.e8.crackdownModal.CRACKDOWN_MODAL_CLOSE_BUTTON),
          children: [!u2 && (0, n.jsx)(m, {}), (0, n.jsx)("div", { className: f().contentWrapper, children: r2 })]
        });
      });
    },
    39450: (e, t, r) => {
      "use strict";
      r.d(t, { Header: () => W, HeaderVariant: () => U });
      var n = r(54486), s = r(28303), a = r(8394), i = r(10744), o = r(87130), l = r(50420), c = r(61910), u = r(43426), f = r(31500), d = r(8817), x = r(67648), p = (r(77881), r(5956), r(97800)), _ = r(42593), m = r(88416), v = r(60440), g = r(1756);
      r(90461);
      var b = r(35203), y = r(60608), h = r(89305), k = r.n(h), E = r(77607), w = r(68300), j = r.n(w);
      let O = (0, s.PA)((e2) => {
        let { showControls: t2 = true, ...r2 } = e2, {
          isScrolledTitle: s2,
          isScrolledChild: a2,
          isScrolling: i2,
          title: o2,
          titleElement: h2,
          child: w2,
          childElement: O2
        } = (0, c.useContext)(E.HeaderContext), {
          experiments: R2,
          settings: { isMobile: C2, browserInfo: S2 },
          user: { hasPlus: P2, isAuthorized: A2 }
        } = (0, v.useStore)(), { formatMessage: T2 } = (0, u.A)();
        (0, m.useContainer)();
        let [H2, M2] = (0, x.d)(), N2 = R2.checkExperiment(g.z.WebNextHeaderOffer, "on") && !P2 && !(null == S2 ? void 0 : S2.isTouch), {
          openPaymentWidgetModal: I2,
          saveOfferAndAuthorize: L2,
          isShimmerActive: B2,
          isShimmerVisible: D2,
          mainText: z2,
          mainTextA11y: F2
        } = (0, _.useBuySubscription)({
          storeName: "music",
          isEnabled: !P2,
          offerElement: { element: H2, intersectionPropertyId: "header-block-controls" }
        }), U2 = (0, d.c)(() => {
          var e3;
          null == h2 || null == (e3 = h2.current) || e3.scrollIntoView({ block: "center", behavior: "smooth" });
        }), W2 = (0, d.c)(() => {
          var e3;
          null == O2 || null == (e3 = O2.current) || e3.scrollIntoView({ block: "center", behavior: "smooth" });
        }), V = (0, d.c)(() => {
          if (!A2) return void L2();
          I2();
        });
        return (0, n.jsx)("header", {
          className: (0, l.$)(j().root, {
            [j().root_sticky]: i2,
            [j().root_withChildren]: a2,
            [j().root_blurWithTitle]: !s2
          }),
          ...(0, f.Am)(f.S7.BRANDED_PLAYLIST_HEADER),
          ...r2,
          children: (0, n.jsxs)("div", {
            className: j().header,
            children: [
              (0, n.jsxs)("div", {
                className: (0, l.$)(j().container, { [j().container_withMultipleChildren]: (0, c.isValidElement)(w2) }),
                children: [
                  (0, n.jsx)("div", { className: j().backdrop }),
                  (0, n.jsxs)("div", {
                    className: j().leftBlock,
                    children: [
                      t2 && (0, n.jsx)(y.NavigationControls, { withForwardControl: !C2, className: j().actions }),
                      s2 && (0, n.jsxs)(n.Fragment, {
                        children: [
                          (0, n.jsx)(p.Caption, {
                            variant: "div",
                            type: "text",
                            className: (0, l.$)(j().title, { [j().title_show]: s2, [j().title_withOffset]: t2 }),
                            lineClamp: 1,
                            onClick: U2,
                            title: i2 && o2 ? o2 : "",
                            "aria-hidden": true,
                            children: o2
                          }),
                          N2 && (0, n.jsx)(b.FreemiumButton, {
                            mainText: z2,
                            ariaLabel: F2,
                            mainTextFontSize: "m",
                            ref: M2,
                            onClick: V,
                            isShimmerActive: B2,
                            isShimmerVisible: D2,
                            className: k().plusButton,
                            ...(0, f.Am)(f.S7.HEADER_PLUS_BUTTON)
                          })
                        ]
                      })
                    ]
                  }),
                  (0, c.isValidElement)(w2) && (0, n.jsx)("div", {
                    onClick: W2,
                    className: (0, l.$)(j().child, { [j().child_show]: a2 }),
                    "aria-hidden": true,
                    children: w2
                  })
                ]
              }),
              false
            ]
          })
        });
      });
      var R = r(88018), C = r.n(R);
      let S = (e2) => {
        let { className: t2, children: r2, onClick: s2, "aria-hidden": a2, "data-testid": i2 } = e2, { isScrolling: o2 } = (0, c.useContext)(E.HeaderContext), {
          experiments: u2,
          user: { hasPlus: p2, isAuthorized: m2 },
          settings: { browserInfo: y2 }
        } = (0, v.useStore)(), h2 = u2.checkExperiment(g.z.WebNextHeaderOffer, "on") && !p2 && !(null == y2 ? void 0 : y2.isTouch), [w2, j2] = (0, x.d)(), {
          openPaymentWidgetModal: O2,
          saveOfferAndAuthorize: R2,
          isShimmerActive: S2,
          isShimmerVisible: P2,
          mainText: A2,
          mainTextA11y: T2
        } = (0, _.useBuySubscription)({
          storeName: "music",
          isEnabled: !p2,
          offerElement: { element: w2, intersectionPropertyId: "header-block-controls" }
        }), H2 = (0, d.c)(() => {
          if (!m2) return void R2();
          O2();
        });
        return (0, n.jsx)("div", {
          className: C().root,
          children: (0, n.jsxs)("div", {
            className: (0, l.$)(C().container, { [C().container_scrolling]: o2 }, t2),
            onClick: s2,
            "aria-hidden": a2,
            "data-testid": i2,
            ...(0, f.Am)(f.S7.STICKY_HEADER),
            children: [
              (0, n.jsx)("div", { className: C().backdrop }),
              (0, n.jsx)("div", { className: C().children, children: r2 }),
              h2 && (0, n.jsx)(b.FreemiumButton, {
                mainText: A2,
                ariaLabel: T2,
                mainTextFontSize: "m",
                ref: j2,
                onClick: H2,
                isShimmerActive: S2,
                isShimmerVisible: P2,
                className: (0, l.$)(k().plusButton, C().plusButton, { [C().plusButton_show]: o2 }),
                ...(0, f.Am)(f.S7.HEADER_PLUS_BUTTON)
              })
            ]
          })
        });
      };
      var P = r(60936), A = r.n(P);
      let T = (0, s.PA)((e2) => {
        let {
          className: t2,
          children: r2,
          stickyChild: s2,
          isScrolledToTop: a2 = true,
          staticClassName: i2,
          stickyClassName: o2,
          "aria-hidden": u2
        } = e2, { isScrolling: d2, scrollElement: x2 } = (0, c.useContext)(E.HeaderContext), p2 = (0, c.useRef)(null), _2 = (0, c.useCallback)(() => {
          if (x2 && a2) x2.scrollTo({ top: 0, behavior: "smooth" });
          else {
            var e3;
            null == p2 || null == (e3 = p2.current) || e3.scrollIntoView({ block: "center", behavior: "smooth" });
          }
        }, [p2, x2, a2]);
        return (0, n.jsxs)("header", {
          className: (0, l.$)(A().root, t2),
          "aria-hidden": u2,
          ...(0, f.Am)(f.S7.COMPOSITE_HEADER_CONTAINER),
          children: [
            (0, n.jsx)("div", {
              className: (0, l.$)(A().static, { [A().static_hidden]: d2 }, i2),
              ref: p2,
              ...(0, f.Am)(f.S7.COMPOSITE_HEADER),
              children: r2
            }),
            (0, n.jsx)(S, {
              className: o2,
              onClick: _2,
              "aria-hidden": true,
              ...(0, f.Am)(f.S7.COMPOSITE_STICKY_HEADER),
              children: s2
            })
          ]
        });
      });
      var H = r(74524), M = r.n(H);
      let N = (0, s.PA)((e2) => {
        let { headerRef: t2, ...r2 } = e2, {
          isScrolledTitle: s2,
          isScrolledChild: a2,
          isScrolling: i2,
          title: o2,
          titleElement: h2,
          child: w2,
          childElement: j2
        } = (0, c.useContext)(E.HeaderContext), {
          experiments: O2,
          settings: { isMobile: R2, browserInfo: C2 },
          user: { hasPlus: S2, isAuthorized: P2 }
        } = (0, v.useStore)(), { formatMessage: A2 } = (0, u.A)();
        (0, m.useContainer)();
        let [T2, H2] = (0, x.d)(), N2 = O2.checkExperiment(g.z.WebNextHeaderOffer, "on") && !S2 && !(null == C2 ? void 0 : C2.isTouch), {
          openPaymentWidgetModal: I2,
          saveOfferAndAuthorize: L2,
          isShimmerActive: B2,
          isShimmerVisible: D2,
          mainText: z2,
          mainTextA11y: F2
        } = (0, _.useBuySubscription)({
          storeName: "music",
          isEnabled: !S2,
          offerElement: { element: T2, intersectionPropertyId: "header-block-controls" }
        }), U2 = (0, d.c)(() => {
          var e3;
          null == h2 || null == (e3 = h2.current) || e3.scrollIntoView({ block: "center", behavior: "smooth" });
        }), W2 = (0, d.c)(() => {
          var e3;
          null == j2 || null == (e3 = j2.current) || e3.scrollIntoView({ block: "center", behavior: "smooth" });
        }), V = (0, d.c)(() => {
          if (!P2) return void L2();
          I2();
        });
        return (0, n.jsx)("header", {
          className: (0, l.$)(k().inner, M().root, { [M().root_sticky]: i2, [M().root_withChildren]: a2 }),
          ref: t2,
          ...(0, f.Am)(f.S7.INNER_HEADER),
          ...r2,
          children: (0, n.jsxs)("div", {
            className: k().header,
            children: [
              (0, n.jsxs)("div", {
                className: k().container,
                children: [
                  (0, n.jsx)("div", { className: M().backdrop }),
                  (0, n.jsxs)("div", {
                    className: k().leftBlock,
                    children: [
                      (0, n.jsx)(y.NavigationControls, { withForwardControl: !R2, className: M().actions }),
                      (0, n.jsx)(p.Caption, {
                        variant: "div",
                        type: "text",
                        className: (0, l.$)(k().title, M().title, { [M().title_show]: s2 }),
                        lineClamp: 1,
                        onClick: U2,
                        title: i2 && o2 ? o2 : "",
                        "aria-hidden": true,
                        children: o2
                      }),
                      N2 && (0, n.jsx)(b.FreemiumButton, {
                        mainText: z2,
                        ariaLabel: F2,
                        mainTextFontSize: "m",
                        ref: H2,
                        onClick: V,
                        isShimmerActive: B2,
                        isShimmerVisible: D2,
                        className: (0, l.$)(k().plusButton, M().plusButton, { [M().plusButton_show]: s2 }),
                        ...(0, f.Am)(f.S7.HEADER_PLUS_BUTTON)
                      })
                    ]
                  }),
                  (0, n.jsx)("div", {
                    onClick: W2,
                    className: (0, l.$)(M().child, { [M().child_show]: a2 }),
                    "aria-hidden": true,
                    children: w2
                  })
                ]
              }),
              false
            ]
          })
        });
      });
      var I = r(24892), L = r.n(I);
      let B = (e2) => {
        let { style: t2 } = e2, { isScrolling: r2, title: s2, titleElement: a2, isScrolledTitle: i2 } = (0, c.useContext)(E.HeaderContext), {
          experiments: o2,
          user: { hasPlus: u2, isAuthorized: m2 },
          settings: { browserInfo: y2 }
        } = (0, v.useStore)(), h2 = o2.checkExperiment(g.z.WebNextHeaderOffer, "on") && !u2 && !(null == y2 ? void 0 : y2.isTouch), [w2, j2] = (0, x.d)(), {
          openPaymentWidgetModal: O2,
          saveOfferAndAuthorize: R2,
          isShimmerActive: C2,
          isShimmerVisible: S2,
          mainText: P2,
          mainTextA11y: A2
        } = (0, _.useBuySubscription)({
          storeName: "music",
          isEnabled: !u2,
          offerElement: { element: w2, intersectionPropertyId: "header-block-controls" }
        }), T2 = (0, d.c)(() => {
          var e3;
          null == a2 || null == (e3 = a2.current) || e3.scrollIntoView({ block: "center", behavior: "smooth" });
        }), H2 = (0, d.c)(() => {
          if (!m2) return void R2();
          O2();
        });
        return (0, n.jsx)("header", {
          className: (0, l.$)(k().inner, L().root, { [L().root_visible]: i2 }),
          style: t2,
          ...(0, f.Am)(f.S7.PROMO_LANDING_HEADER),
          children: (0, n.jsx)("div", {
            className: k().header,
            children: (0, n.jsxs)("div", {
              className: (0, l.$)(k().container, L().container),
              children: [
                (0, n.jsx)("div", { className: L().backdrop }),
                (0, n.jsxs)("div", {
                  className: k().leftBlock,
                  children: [
                    (0, n.jsx)(p.Caption, {
                      variant: "div",
                      type: "text",
                      className: (0, l.$)(k().title, L().title),
                      lineClamp: 1,
                      onClick: T2,
                      title: r2 && s2 ? s2 : "",
                      "aria-hidden": true,
                      children: s2
                    }),
                    h2 && (0, n.jsx)(b.FreemiumButton, {
                      mainText: P2,
                      ariaLabel: A2,
                      mainTextFontSize: "m",
                      ref: j2,
                      onClick: H2,
                      isShimmerActive: C2,
                      isShimmerVisible: S2,
                      className: k().plusButton,
                      ...(0, f.Am)(f.S7.HEADER_PLUS_BUTTON)
                    })
                  ]
                })
              ]
            })
          })
        });
      };
      var D = r(42102), z = r.n(D);
      let F = (0, s.PA)((e2) => {
        let {
          className: t2,
          children: r2,
          showControls: s2 = true,
          withForwardControl: a2 = true,
          withBackwardControl: i2 = true,
          disableStickyVariant: o2 = false
        } = e2, { isScrolling: u2, title: m2, scrollElement: h2, isHeaderHidden: w2 } = (0, c.useContext)(E.HeaderContext), j2 = (0, c.useRef)(null), [O2, R2] = (0, x.d)(), {
          experiments: C2,
          user: { hasPlus: S2, isAuthorized: P2 },
          settings: { browserInfo: A2 }
        } = (0, v.useStore)(), T2 = C2.checkExperiment(g.z.WebNextHeaderOffer, "on") && !S2 && !(null == A2 ? void 0 : A2.isTouch), {
          openPaymentWidgetModal: H2,
          saveOfferAndAuthorize: M2,
          isShimmerActive: N2,
          isShimmerVisible: I2,
          mainText: L2,
          mainTextA11y: B2
        } = (0, _.useBuySubscription)({
          storeName: "music",
          isEnabled: !S2,
          offerElement: { element: O2, intersectionPropertyId: "header-block-controls" }
        }), D2 = (0, c.useCallback)(() => {
          if (h2) h2.scrollTo({ top: 0, behavior: "smooth" });
          else {
            var e3;
            null == j2 || null == (e3 = j2.current) || e3.scrollIntoView({ block: "center", behavior: "smooth" });
          }
        }, [h2]), F2 = (0, c.useMemo)(
          () => (0, n.jsx)(p.Heading, { variant: "h2", weight: "bold", size: "s", lineClamp: 1, children: m2 }),
          [m2]
        ), U2 = s2 && (a2 || i2), W2 = (0, d.c)(() => {
          if (!P2) return void M2();
          H2();
        });
        return (0, n.jsxs)("header", {
          className: (0, l.$)(z().root, t2),
          children: [
            (0, n.jsxs)("div", {
              className: (0, l.$)(z().staticItem, { [z().staticItem_hide]: u2 || w2 }),
              ref: j2,
              ...(0, f.Am)(f.S7.TEXT_HEADER),
              children: [U2 && (0, n.jsx)(y.NavigationControls, { withForwardControl: a2, withBackwardControl: i2 }), r2]
            }),
            !o2 && (0, n.jsxs)("div", {
              className: (0, l.$)(z().stickyItem, { [z().stickyItem_scrolling]: u2 }),
              onClick: D2,
              "aria-hidden": true,
              ...(0, f.Am)(f.S7.TEXT_STICKY_HEADER),
              children: [
                (0, n.jsx)("div", { className: z().backdrop }),
                (0, n.jsxs)("div", {
                  className: z().container,
                  children: [
                    U2 && (0, n.jsx)(y.NavigationControls, {
                      withForwardControl: a2,
                      withBackwardControl: i2,
                      shouldFocusOnMount: false
                    }),
                    F2
                  ]
                }),
                T2 && (0, n.jsx)(b.FreemiumButton, {
                  mainText: L2,
                  ariaLabel: B2,
                  mainTextFontSize: "m",
                  ref: R2,
                  onClick: W2,
                  isShimmerActive: N2,
                  isShimmerVisible: I2,
                  className: k().plusButton,
                  ...(0, f.Am)(f.S7.HEADER_PLUS_BUTTON)
                })
              ]
            })
          ]
        });
      });
      var U = (function(e2) {
        return e2.INNER = "INNER", e2.TEXT = "TEXT", e2.COMPOSITE = "COMPOSITE", e2.PROMO_LANDING = "PROMO_LANDING", e2.BRANDED_PLAYLIST = "BRANDED_PLAYLIST", e2.STICKY = "STICKY", e2;
      })({});
      let W = (0, s.PA)((e2) => {
        let {
          variant: t2 = "INNER",
          style: r2,
          children: s2,
          showControls: l2,
          withBackwardControl: c2,
          withForwardControl: u2,
          className: f2 = "",
          stickyChild: d2,
          staticClassName: x2,
          stickyClassName: p2,
          innerHeaderRef: _2,
          disableStickyVariant: m2,
          ...v2
        } = e2;
        switch (t2) {
          case "INNER":
            return (0, n.jsx)(a.AcqProvider, {
              page: i.l.HEADER,
              places: [o.R.BUTTON],
              children: (0, n.jsx)(N, { headerRef: _2, style: r2 })
            });
          case "TEXT":
            return (0, n.jsx)(a.AcqProvider, {
              page: i.l.HEADER,
              places: [o.R.BUTTON],
              children: (0, n.jsx)(F, {
                showControls: l2,
                withBackwardControl: c2,
                withForwardControl: u2,
                disableStickyVariant: m2,
                children: s2
              })
            });
          case "COMPOSITE":
            return (0, n.jsx)(a.AcqProvider, {
              page: i.l.HEADER,
              places: [o.R.BUTTON],
              children: (0, n.jsx)(T, {
                className: f2,
                stickyChild: d2,
                staticClassName: x2,
                stickyClassName: p2,
                ...v2,
                children: s2
              })
            });
          case "PROMO_LANDING":
            return (0, n.jsx)(a.AcqProvider, {
              page: i.l.HEADER,
              places: [o.R.BUTTON],
              children: (0, n.jsx)(B, { style: r2 })
            });
          case "BRANDED_PLAYLIST":
            return (0, n.jsx)(a.AcqProvider, {
              page: i.l.HEADER,
              places: [o.R.BUTTON],
              children: (0, n.jsx)(O, { showControls: l2, children: s2 })
            });
          case "STICKY":
            return (0, n.jsx)("header", {
              className: f2,
              children: (0, n.jsx)(a.AcqProvider, {
                page: i.l.HEADER,
                places: [o.R.BUTTON],
                children: (0, n.jsx)(S, { className: p2, ...v2, children: d2 })
              })
            });
        }
      });
    },
    41682: (e, t, r) => {
      "use strict";
      r.d(t, { AdfoxBanner: () => p });
      var n = r(54486), s = r(28303), a = r(97396), i = r(61910), o = r(80411), l = r(7286), c = r(91574), u = r(60440), f = r(24887), d = r(66688), x = r(1756);
      let p = (0, s.PA)((e2) => {
        let { className: t2, ownerId: r2, containerId: s2, params: p2, onLoad: _, onRender: m, onNoAds: v, onError: g } = e2, { user: b, experiments: y } = (0, u.useStore)(), h = (0, a.usePathname)(), k = (0, a.useSearchParams)(), { create: E, reload: w, destroy: j, initialize: O } = (0, l.useAdfox)(), { theme: R } = (0, d.useTheme)(), C = (0, c.U)(), S = (0, i.useRef)(true), P = { ...p2 };
        return P.puid1 = b.advertRole, (0, i.useEffect)(() => {
          E({
            ownerId: r2,
            containerId: s2,
            params: P,
            insertionCodeParams: { darkTheme: R === f.S.Dark, additionalClasses: R ? [R] : [] },
            onClose: () => {
              C.log("[AdvertBanner] Close");
            },
            onLoad: (e3) => {
              if (C.log("[AdvertBanner] Load", { data: e3 }), void 0 === e3) {
                null == _ || _(o.h.EMPTY);
                return;
              }
              if ((null == e3 ? void 0 : e3.bundleName) === "banner.direct") {
                null == _ || _(o.h.DIRECT);
                return;
              }
              null == _ || _(o.h.CREATIVE);
            },
            onRender: () => {
              C.log("[AdvertBanner] Render"), null == m || m();
            },
            onStub: () => {
              C.log("[AdvertBanner] Stub"), null == v || v();
            },
            onError: (e3) => {
              C.log("[AdvertBanner] Error", { error: e3 }), null == g || g();
            }
          });
        }, []), (0, i.useEffect)(() => {
          if (S.current) {
            S.current = false;
            return;
          }
          y.checkExperiment(x.z.WebNextAdfoxDestroyAndInitializeBanner, "on") ? (C.log("[AdvertBanner] Destroy"), j(s2), C.log("[AdvertBanner] Initialize"), O(s2)) : (C.log("[AdvertBanner] Reload"), w(s2, { onlyIfWasVisible: true }));
        }, [h, k, s2, w, j, O, C, y]), (0, n.jsx)("div", { id: s2, className: t2, tabIndex: -1, "aria-hidden": true });
      });
    },
    42102: (e) => {
      e.exports = {
        staticItem: "TextHeader_staticItem__OMNew",
        staticItem_hide: "TextHeader_staticItem_hide__JtdeC",
        backdrop: "TextHeader_backdrop__39FkE",
        stickyItem: "TextHeader_stickyItem__WF2hh",
        container: "TextHeader_container__I0pVO",
        stickyItem_scrolling: "TextHeader_stickyItem_scrolling__YPBOL"
      };
    },
    43222: (e) => {
      e.exports = {
        root: "VerticalListItemShimmer_root__Ppz8c",
        infoContainer: "VerticalListItemShimmer_infoContainer__ycrKq",
        textContainer: "VerticalListItemShimmer_textContainer__kHkGo",
        title: "VerticalListItemShimmer_title__z_x63",
        cover: "VerticalListItemShimmer_cover__0SqgP",
        action: "VerticalListItemShimmer_action__DvEuY"
      };
    },
    45427: (e, t, r) => {
      "use strict";
      r.d(t, { C: () => c });
      var n, s = r(61910), a = {
        4601: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useToggle = void 0;
          let n2 = r2(810);
          t2.useToggle = (e3) => {
            let [t3, r3] = (0, n2.useState)(e3);
            (0, n2.useEffect)(() => {
              r3(e3);
            }, [e3]);
            let s2 = (0, n2.useCallback)(() => {
              r3((e4) => !e4);
            }, []), a2 = (0, n2.useCallback)(() => {
              r3(true);
            }, []), i2 = (0, n2.useCallback)(() => {
              r3(false);
            }, []);
            return { state: t3, toggle: s2, setState: r3, toggleTrue: a2, toggleFalse: i2 };
          };
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(s, 2));
        }
      }, i = {};
      function o(e2) {
        var t2 = i[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = i[e2] = { exports: {} };
        return a[e2](r2, r2.exports, o), r2.exports;
      }
      var l = {};
      (() => {
        Object.defineProperty(l, "X", { value: true }), l.l = void 0;
        let e2 = o(810), t2 = o(4601);
        l.l = (r2) => {
          let { isEnabled: n2 = true, onClick: s2, shouldStartFromUnscale: a2 } = r2, { state: i2, toggleFalse: o2, toggleTrue: l2 } = (0, t2.useToggle)(false), { state: c2, toggleFalse: u, toggleTrue: f } = (0, t2.useToggle)(false), d = (0, e2.useCallback)(
            (e3) => {
              null == s2 || s2(), n2 && (a2 ? f() : l2()), e3.stopPropagation(), e3.preventDefault();
            },
            [n2, s2, a2, l2, f]
          );
          return {
            handleAnimationEnd: (0, e2.useCallback)(() => {
              o2(), u();
            }, [o2, u]),
            handleClick: d,
            scaleAnimation: i2,
            unscaleAnimation: c2
          };
        };
      })(), l.X;
      var c = l.l;
    },
    45591: (e, t, r) => {
      "use strict";
      r.d(t, { BaseNotificationPresave: () => v });
      var n = r(54486), s = r(50420), a = r(61910), i = r(43426), o = r(47713), l = r(31500), c = r(39610), u = r(97800), f = r(14848), d = r(95405), x = r(24036), p = r(22096), _ = r(82825), m = r.n(_);
      let v = (e2) => {
        let { closeToast: t2, albumTitle: r2, coverUri: _2, isPresave: v2, entityTitle: g, className: b } = e2, { formatMessage: y } = (0, i.A)(), h = (0, a.useMemo)(
          () => v2 ? (0, n.jsx)(o.A, { id: "notifications-info.added-to" }) : (0, n.jsx)(o.A, { id: "notifications-info.removed-from" }),
          [v2]
        ), k = (0, a.useMemo)(
          () => v2 ? (0, n.jsx)(o.A, { id: "notifications-info.to-collection" }) : (0, n.jsx)(o.A, { id: "notifications-info.from-collection" }),
          [v2]
        ), E = (0, a.useMemo)(
          () => v2 ? y({ id: "notifications-info.album-added-to-collection-aria-label" }, { entity: g }) : y({ id: "notifications-info.album-removed-from-collection-aria-label" }, { entity: g }),
          [v2, g, y]
        ), w = (0, a.useMemo)(
          () => (0, n.jsxs)(u.Caption, {
            className: m().text,
            variant: "div",
            type: "controls",
            size: "m",
            ...(0, l.Am)(l.S7.BASE_NOTIFICATION_PRESAVE_TEXT),
            "aria-hidden": true,
            children: [
              (0, n.jsx)(o.A, { id: "entity-names.album" }),
              " ",
              (0, n.jsxs)(u.Caption, {
                className: m().title,
                variant: "span",
                type: "controls",
                size: "m",
                lineClamp: 1,
                children: [g, " "]
              }),
              h,
              " ",
              (0, n.jsx)(x.Link, {
                className: m().link,
                href: "/collection/albums?tab=".concat(f.H.UPCOMING_ALBUMS),
                title: String(k),
                children: (0, n.jsx)(u.Caption, {
                  variant: "span",
                  type: "controls",
                  size: "m",
                  lineClamp: 1,
                  children: k
                })
              })
            ]
          }),
          [g, h, k]
        );
        return (0, n.jsx)(p.BaseNotification, {
          className: (0, s.$)(m().root, b),
          message: (0, n.jsxs)(n.Fragment, {
            children: [(0, n.jsx)(c.q, { children: (0, n.jsx)("p", { role: "alert", "aria-label": E }) }), w]
          }),
          cover: (0, n.jsx)(d.B, {
            className: m().image,
            src: _2,
            size: 100,
            fit: "cover",
            alt: r2,
            withAvatarReplace: true
          }),
          closeToast: t2,
          coverRadius: "s"
        });
      };
    },
    45645: (e, t, r) => {
      "use strict";
      r.d(t, { PlaylistTrackShimmer: () => u });
      var n = r(54486), s = r(50420), a = r(61910), i = r(43426), o = r(22674), l = r(13967), c = r.n(l);
      let u = (e2) => {
        let { isActive: t2, className: r2 } = e2, { formatMessage: l2 } = (0, i.A)(), u2 = (0, a.useMemo)(
          () => l2({ id: "loading-messages.entity-is-loading" }, { entityName: l2({ id: "entity-names.track" }) }),
          [l2]
        );
        return (0, n.jsxs)("div", {
          "aria-label": u2,
          "aria-live": t2 ? "polite" : "off",
          "aria-busy": t2,
          className: (0, s.$)(c().root, r2),
          children: [
            (0, n.jsxs)("div", {
              className: c().infoContainer,
              children: [
                (0, n.jsx)(o.Shimmer, { isActive: t2, className: c().cover, radius: "s" }),
                (0, n.jsx)("div", {
                  className: c().textContainer,
                  children: (0, n.jsx)(o.Shimmer, { isActive: t2, className: c().title, radius: "l" })
                })
              ]
            }),
            (0, n.jsx)(o.Shimmer, { isActive: t2, className: c().action, radius: "l" })
          ]
        });
      };
    },
    46144: (e) => {
      e.exports = {
        root: "PaywallFAQ_root__lDVk4",
        title: "PaywallFAQ_title__G44Rp",
        content: "PaywallFAQ_content__QJL9h"
      };
    },
    47345: (e) => {
      e.exports = {
        root: "AlbumTrackShimmer_root__fBjbK",
        infoContainer: "AlbumTrackShimmer_infoContainer__4fdAk",
        coverContainer: "AlbumTrackShimmer_coverContainer__frW12",
        textContainer: "AlbumTrackShimmer_textContainer__5wNPM",
        title: "AlbumTrackShimmer_title__HC_Pa",
        cover: "AlbumTrackShimmer_cover__36UkV",
        action: "AlbumTrackShimmer_action__oI5t5"
      };
    },
    47347: (e, t, r) => {
      "use strict";
      r.d(t, { BaseNotificationPin: () => y });
      var n = r(54486), s = r(50420), a = r(61910), i = r(31500), o = r(58360), l = r(39610), c = r(97800), u = r(43426), f = r(47713), d = r(8817), x = r(48861), p = r(60440), _ = r(1756), m = r(24036), v = r(22096), g = r(73125), b = r.n(g);
      let y = (e2) => {
        let {
          closeToast: t2,
          className: r2,
          coverUri: g2,
          entityTitle: y2,
          entityDescription: h,
          entityVariant: k,
          entityUrl: E,
          customCover: w,
          radius: j,
          isPinned: O
        } = e2, R = (() => {
          let { formatMessage: e3 } = (0, u.A)(), { experiments: t3 } = (0, p.useStore)();
          return (0, d.c)((r3) => {
            let { entityVariant: s2, values: a2, entityTitle: i2, entityDescription: o2 } = r3;
            switch (s2) {
              case x.c.ALBUM:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.album-pinned-in-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.album-pinned-in-menu" }, { entity: i2 })
                };
              case x.c.AUDIOBOOK:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.audiobook-pinned-in-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.audiobook-pinned-in-menu" }, { entity: i2 })
                };
              case x.c.FAIRY_TALE:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.fairytale-pinned-in-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.fairytale-pinned-in-menu" }, { entity: i2 })
                };
              case x.c.PODCAST:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.podcast-pinned-in-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.podcast-pinned-in-menu" }, { entity: i2 })
                };
              case x.c.PLAYLIST:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.playlist-pinned-in-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.playlist-pinned-in-menu" }, { entity: i2 })
                };
              case x.c.ARTIST:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.artist-pinned-in-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.artist-pinned-in-menu" }, { entity: i2 })
                };
              case x.c.VIBE:
                if (!t3.checkExperiment(_.z.WebNextVibeDescription, "on"))
                  return {
                    caption: (0, n.jsx)(f.A, { id: "notifications-info.my-vibe-pinned-in-menu", values: a2 }),
                    ariaLabel: e3({ id: "notifications-info.my-vibe-pinned-in-menu" }, { entity: i2 })
                  };
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.entity-pinned-in-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.entity-pinned-in-menu" }, { entity: i2, description: o2 })
                };
            }
          });
        })(), C = (() => {
          let { formatMessage: e3 } = (0, u.A)(), { experiments: t3 } = (0, p.useStore)();
          return (0, d.c)((r3) => {
            let { entityVariant: s2, values: a2, entityTitle: i2, entityDescription: o2 } = r3;
            switch (s2) {
              case x.c.ALBUM:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.album-unpinned-from-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.album-unpinned-from-menu" }, { entity: i2 })
                };
              case x.c.AUDIOBOOK:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.audiobook-unpinned-from-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.audiobook-unpinned-from-menu" }, { entity: i2 })
                };
              case x.c.FAIRY_TALE:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.fairytale-unpinned-from-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.fairytale-unpinned-from-menu" }, { entity: i2 })
                };
              case x.c.PODCAST:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.podcast-unpinned-from-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.podcast-unpinned-from-menu" }, { entity: i2 })
                };
              case x.c.PLAYLIST:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.playlist-unpinned-from-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.playlist-unpinned-from-menu" }, { entity: i2 })
                };
              case x.c.ARTIST:
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.artist-unpinned-from-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.artist-unpinned-from-menu" }, { entity: i2 })
                };
              case x.c.VIBE:
                if (!t3.checkExperiment(_.z.WebNextVibeDescription, "on"))
                  return {
                    caption: (0, n.jsx)(f.A, { id: "notifications-info.my-vibe-unpinned-from-menu", values: a2 }),
                    ariaLabel: e3({ id: "notifications-info.my-vibe-unpinned-from-menu" }, { entity: i2 })
                  };
                return {
                  caption: (0, n.jsx)(f.A, { id: "notifications-info.entity-unpinned-from-menu", values: a2 }),
                  ariaLabel: e3({ id: "notifications-info.entity-unpinned-from-menu" }, { entity: i2, description: o2 })
                };
            }
          });
        })(), S = (0, a.useMemo)(
          () => E ? (0, n.jsx)(m.Link, {
            className: b().link,
            href: E,
            title: y2,
            children: (0, n.jsxs)(c.Caption, {
              className: b().title,
              variant: "span",
              type: "controls",
              size: "m",
              lineClamp: 1,
              children: [" ", y2, " "]
            })
          }) : (0, n.jsxs)(c.Caption, {
            className: b().title,
            variant: "span",
            type: "controls",
            size: "m",
            lineClamp: 1,
            title: y2,
            children: [" ", y2, " "]
          }),
          [y2, E]
        ), P = (0, a.useMemo)(
          () => w || (0, n.jsx)(o.Image, {
            className: b().image,
            src: g2,
            size: 100,
            fit: "cover",
            withAvatarReplace: true,
            "aria-hidden": true
          }),
          [g2, w]
        ), A = (0, a.useMemo)(() => {
          let e3 = { entity: S, description: h };
          return O ? R({ entityVariant: k, values: e3, entityTitle: y2, entityDescription: h }) : C({ entityVariant: k, values: e3, entityTitle: y2, entityDescription: h });
        }, [S, h, O, C, k, y2, R]);
        return (0, n.jsx)(v.BaseNotification, {
          className: (0, s.$)(b().root, { [b().root_withLongText]: k === x.c.AUDIOBOOK }, r2),
          closeToast: t2,
          cover: P,
          message: (0, n.jsxs)(n.Fragment, {
            children: [
              (0, n.jsx)(l.q, { children: (0, n.jsx)("p", { role: "alert", "aria-label": A.ariaLabel }) }),
              (0, n.jsx)(c.Caption, {
                className: b().text,
                variant: "div",
                type: "controls",
                size: "m",
                ...(0, i.Am)(i.S7.BASE_NOTIFICATION_PIN_TEXT),
                "aria-hidden": true,
                children: A.caption
              })
            ]
          }),
          coverRadius: j
        });
      };
    },
    48384: (e) => {
      e.exports = {
        root: "TabShimmer_root__NGwwm",
        root_withCovers: "TabShimmer_root_withCovers__ZPmX0",
        covers: "TabShimmer_covers__eLlh6",
        cover: "TabShimmer_cover__uiC2w",
        lines: "TabShimmer_lines__fbU4_",
        title: "TabShimmer_title__qhG5i",
        subtitle: "TabShimmer_subtitle__JuLWD"
      };
    },
    48670: (e, t, r) => {
      "use strict";
      r.d(t, { ApplicationInformationHeadTags: () => s });
      var n = r(54486);
      let s = (e2) => {
        let { assetPrefix: t2 } = e2;
        return (0, n.jsxs)(n.Fragment, {
          children: [
            (0, n.jsx)("link", {
              rel: "icon",
              type: "image/png",
              sizes: "48x48",
              href: "".concat(t2, "/favicon-48x48.png")
            }),
            (0, n.jsx)("link", { rel: "icon", type: "image/svg+xml", href: "".concat(t2, "/favicon.svg") }),
            (0, n.jsx)("link", { rel: "shortcut icon", href: "".concat(t2, "/favicon.ico") }),
            (0, n.jsx)("link", {
              rel: "apple-touch-icon",
              sizes: "180x180",
              href: "".concat(t2, "/apple-touch-icon.png")
            }),
            (0, n.jsx)("link", {
              rel: "manifest",
              crossOrigin: "use-credentials",
              href: "".concat(t2, "/site.webmanifest")
            }),
            (0, n.jsx)("meta", { name: "apple-mobile-web-app-capable", content: "yes" }),
            (0, n.jsx)("meta", { name: "apple-mobile-web-app-status-bar-style", content: "black" }),
            (0, n.jsx)("meta", { name: "apple-mobile-web-app-title", content: "Яндекс Музыка" }),
            (0, n.jsx)("link", {
              rel: "search",
              type: "application/opensearchdescription+xml",
              title: "Яндекс Музыка",
              href: "".concat(t2, "/opensearch.xml")
            }),
            (0, n.jsx)("meta", { name: "robots", content: "noyaca" })
          ]
        });
      };
    },
    48861: (e, t, r) => {
      "use strict";
      r.d(t, { c: () => n });
      var n = (function(e2) {
        return e2.ARTIST = "artist", e2.ALBUM = "album", e2.PLAYLIST = "playlist", e2.TRACK = "track", e2.VIBE = "vibe", e2.PODCAST = "podcast", e2.PODCAST_EPISODE = "podcast-episode", e2.AUDIOBOOK = "audiobook", e2.AUDIOBOOK_EPISODE = "audiobook-episode", e2.FAIRY_TALE = "fairy-tale", e2.CLIP = "clip", e2;
      })({});
    },
    50215: (e, t, r) => {
      "use strict";
      r.d(t, { NotificationCopy: () => d });
      var n = r(54486), s = r(61910), a = r(47713), i = r(5956), o = r(97800), l = r(22096), c = r(25933), u = r.n(c);
      let f = {
        track: (0, n.jsx)(a.A, { id: "notifications-info.track-link" }),
        artist: (0, n.jsx)(a.A, { id: "notifications-info.artist-link" }),
        album: (0, n.jsx)(a.A, { id: "notifications-info.album-link" }),
        playlist: (0, n.jsx)(a.A, { id: "notifications-info.playlist-link" }),
        clip: (0, n.jsx)(a.A, { id: "notifications-info.clip-link" }),
        label: (0, n.jsx)(a.A, { id: "notifications-info.label-link" }),
        concert: (0, n.jsx)(a.A, { id: "notifications-info.concert-link" })
      }, d = (e2) => {
        let { entityVariant: t2, entityTitle: r2, closeToast: c2 } = e2, d2 = (0, s.useMemo)(
          () => (0, n.jsxs)(o.Caption, {
            className: u().message,
            variant: "div",
            type: "controls",
            size: "m",
            children: [
              f[t2],
              " ",
              (0, n.jsx)(o.Caption, {
                className: u().title,
                variant: "span",
                type: "controls",
                size: "m",
                lineClamp: 1,
                children: r2
              }),
              " ",
              (0, n.jsx)(a.A, { id: "notifications-info.copied" })
            ]
          }),
          [t2, r2]
        );
        return (0, n.jsx)(l.BaseNotification, {
          closeToast: c2,
          cover: (0, n.jsx)(i.Icon, { className: u().icon, size: "xs", variant: "chain" }),
          message: d2,
          coverRadius: "s"
        });
      };
    },
    50711: (e, t, r) => {
      "use strict";
      r.d(t, { PaywallFAQAnswer: () => o });
      var n = r(54486), s = r(97800), a = r(1131), i = r.n(a);
      let o = (e2) => {
        let { children: t2 } = e2;
        return (0, n.jsx)(s.Caption, {
          className: i().root,
          variant: "span",
          size: "l",
          weight: "normal",
          children: t2
        });
      };
    },
    51321: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { Tab: () => c, TabPanel: () => u, Tabs: () => f, __esModule: () => d, useTabsState: () => x });
      var n, s = r(61910), a = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        1920: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            contentContainer: "JjlbHZ4FaP9EAcR_1DxF",
            contentContainer_block: "iOlzvyUREgDkthkrx7Sf",
            flexIcon: "WsKeF73pWotx9W1tWdYY",
            root: "cpeagBA1_PblpJn8Xgtv",
            root_withoutBorder: "qU2apWBO1yyEK0lZ3lPO",
            root_radius_xs: "MmZbSs387gu2qrJ1lDWd",
            root_radius_s: "mlcrraysn7mW6xrBXSBF",
            root_radius_m: "dgV08FKVLZKFsucuiryn",
            root_radius_l: "S97_5dtzhpxo_amtfYRg",
            root_radius_xl: "nNBJnDHRlyLTniWosJhk",
            root_radius_xxxl: "zIMibMuH7wcqUoW7KH1B",
            root_radius_round: "uwk3hfWzB2VT7kE13SQk",
            root_size: "IlG7b1K0AD7E7AMx6F5p",
            root_size_default: "C_QGmfTz6UFX93vfPt6Z",
            root_size_xxxs: "eQt33MLDiQ6DRSuLaYEp",
            root_size_xxs: "oR11LfCBVqMbUJiAgknd",
            root_size_xs: "j1jXIVckFgZECecFzZMe",
            root_size_s: "WtFdWDF44egSVM_YiMUX",
            root_size_m: "Y2uqxoU7xa_AZ8FUCVOW",
            root_size_l: "SGYcNjvjmMsXeEVGUV2Z",
            root_icon_left: "kc5CjvU5hT9KEj0iTt3C",
            root_icon_right: "et24Jf7pT_X9Fvc7TznR",
            root_primary: "fXlFz1qMkliFUWOkHo8T",
            root_primary_default: "_eTRQi5ADZCUvUKMZqJU",
            ripple: "spMT3NcRD9Yb0ntNaNct",
            root_primary_outline: "fCUSh2B0Ye9kEvceE8zc",
            root_primary_text: "qlPp6CSQQEMVZPqtqLiQ",
            root_primary_withHover: "KZF6_4K1p_Y_GMIAxaAn",
            root_primary_withHover_default: "rWukOKAJh5Ga7JuIp62L",
            root_primary_withHover_outline: "fdwWCJKgUqml5wNqrRcN",
            root_primary_withHover_text: "IgYbZLnYjW0nMahgpkus",
            root_secondary: "_T4p_w41oaq6L4sztSdw",
            root_secondary_default: "iJVAJMgccD4vj4E4o068",
            root_secondary_outline: "pnM3iSP9keZOELI2oohr",
            root_secondary_text: "UDMYhpDjiAFT3xUx268O",
            root_secondary_withHover: "qUbrkhZIOVrvM0roV1QF",
            root_secondary_withHover_default: "nHWc2sto1C6Gm0Dpw_l0",
            root_secondary_withHover_outline: "i5WuBm5mfG0mflk_1jH_",
            root_secondary_withHover_text: "HbaqudSqu7Q3mv3zMPGr",
            root_plus: "ixLRsIJ2FvXO2k04n_QY",
            root_plus_default: "yRHwHzEGfDgRXGzYJqw2",
            root_plus_outline: "e777irPFmyQFFrURLF_U",
            root_plus_text: "vRqDhvmt3gt8TFp45_Zw",
            root_plus_withHover: "TZif6q3I2RwBEYXwK_iA",
            root_plus_withHover_default: "k3DhvmzpnM_Fb9oFdE4q",
            root_plus_withHover_outline: "RiDWYwGIxqbrUPR699DM",
            root_plus_withHover_text: "hC_mMCzWjkTn2j9xZzGc",
            root_accent: "jqD2jMT6n7F0WKyqwMsn",
            root_accent_default: "bDp0r9MtoYECZ8ObMoCh",
            root_accent_outline: "rXNyGp8NBAw2MUjACZNj",
            root_accent_text: "hmV4ERaXWAJc4uPLZL30",
            root_accent_withHover: "uKuxXu1N4TP5cWaEK5Ke",
            root_accent_withHover_default: "t_hequUaUgAMhFuxizLb",
            root_accent_withHover_outline: "Oy9sPFTxNTo1_E29U4aF",
            root_accent_withHover_text: "LcKRSd3DLoh7k60Oqox8",
            root_withActiveSpinner: "nAGvO87rLs15SJgft6Hh",
            block: "BbCxxIjBGupN28bq2lSP",
            icon: "J9wTKytjOWG73QMoN5WP",
            icon_position_left: "elJfazUBui03YWZgHCbW",
            icon_position_right: "RBoEbyJKP5rEtLsXM1ji",
            icon_withButtonSize: "cE17_kCWJgx8kzQEkeVr",
            spinnerContainer: "STbBDGqYjUEcLuNvhu9w"
          };
        },
        1896: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "d50IqTKJZhJIMd5aTqAn",
            button: "Yqh9GVOagMQpvymD877t",
            button_active: "cBxrIXbcPeS3kSzdJdhS"
          };
        },
        3346: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "oSPcFawW7MIQ9ZTANH9N" };
        },
        1883: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "TjoCDDIf5PrIGU4w8G6Z" };
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        8796: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.createRipple = void 0, t2.createRipple = function(e3, t3, r2) {
            let n2 = null != r2 ? r2 : e3.currentTarget, s2 = document.createElement("span"), a2 = Math.max(n2.clientWidth, n2.clientHeight), i2 = a2 / 2, o2 = n2.getBoundingClientRect(), l2 = 0 === e3.clientX ? Math.round(o2.width / 2) : e3.clientX - o2.left, c2 = 0 === e3.clientY ? Math.round(o2.height / 2) : e3.clientY - o2.top;
            s2.style.width = "".concat(a2, "px"), s2.style.height = "".concat(a2, "px"), s2.style.left = 0 === e3.clientX ? "0px" : "".concat(l2 - i2, "px"), s2.style.top = "".concat(c2 - i2, "px"), s2.classList.add(t3);
            let u2 = n2.getElementsByClassName(t3)[0];
            u2 && u2.remove(), n2.insertBefore(s2, n2.firstChild);
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        8216: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = t2.createRipple = void 0;
          var n2 = r2(8796);
          Object.defineProperty(t2, "createRipple", {
            enumerable: true,
            get: function() {
              return n2.createRipple;
            }
          });
          var s2 = r2(361);
          Object.defineProperty(t2, "getElementFromRefOrElement", {
            enumerable: true,
            get: function() {
              return s2.getElementFromRefOrElement;
            }
          });
        },
        8119: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = r2(8216), l2 = n2(r2(1920)), c2 = (e3) => {
            let {
              forwardRef: t3,
              isBlock: r3,
              iconPosition: n3 = "left",
              children: c3,
              className: u2,
              color: f2 = "secondary",
              flexIcon: d2,
              icon: x2,
              spinner: p,
              role: _,
              onClick: m,
              radius: v = "m",
              size: g,
              type: b = "button",
              variant: y = "default",
              withRipple: h = true,
              withHover: k = true,
              withBorder: E = false,
              disabled: w,
              iconClassName: j,
              contentContainerClassName: O,
              ...R
            } = e3, C = (0, a2.useId)(), S = !a2.Children.toArray(c3).filter(Boolean).length, P = "left" === n3, A = null, T = (0, a2.isValidElement)(p);
            if (x2) {
              var H, M;
              A = (0, a2.cloneElement)(x2, {
                className: (0, i2.clsx)(
                  l2.default.icon,
                  {
                    [l2.default["icon_position_".concat(n3)]]: n3 && !S,
                    [l2.default.icon_withButtonSize]: !(null == (H = x2.props) ? void 0 : H.size)
                  },
                  null == (M = x2.props) ? void 0 : M.className,
                  j
                ),
                key: C
              });
            }
            let N = (0, a2.useMemo)(
              () => T ? (0, s2.jsx)("div", { className: l2.default.spinnerContainer, children: p }) : null,
              [T, p]
            ), I = (0, a2.useCallback)(
              (e4) => {
                T || (h && (0, o2.createRipple)(e4, l2.default.ripple), null == m || m(e4));
              },
              [T, m, h]
            );
            return (0, s2.jsx)("button", {
              ref: t3,
              className: (0, i2.clsx)(
                l2.default.root,
                l2.default["root_".concat(f2, "_").concat(y)],
                l2.default["root_radius_".concat(v)],
                l2.default.root_size,
                {
                  [l2.default["root_".concat(f2, "_withHover_").concat(y)]]: k && !w && !T,
                  [l2.default["root_size_".concat(g)]]: g,
                  [l2.default.root_withoutBorder]: !E,
                  [l2.default.root_withActiveSpinner]: T,
                  [l2.default.block]: r3,
                  [l2.default.flexIcon]: d2,
                  [l2.default.iconOnly]: S,
                  [l2.default.root_icon_left]: x2 && !S && P,
                  [l2.default.root_icon_right]: x2 && !S && !P
                },
                u2
              ),
              type: b,
              role: _,
              onClick: I,
              ...R,
              disabled: w,
              "aria-live": T ? "polite" : "off",
              "aria-busy": T,
              children: x2 || T ? (0, s2.jsxs)("span", {
                className: (0, i2.clsx)(
                  l2.default.contentContainer,
                  { [l2.default.contentContainer_block]: r3 },
                  O
                ),
                children: [x2 && P && A, !S && c3, x2 && !P && A, N]
              }) : c3
            });
          };
          t2.Button = (0, a2.forwardRef)((e3, t3) => (0, s2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        5928: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          var n2 = r2(8119);
          Object.defineProperty(t2, "Button", {
            enumerable: true,
            get: function() {
              return n2.Button;
            }
          });
        },
        848: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Tab = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(5928), l2 = n2(r2(1896));
          t2.Tab = (e3) => {
            let {
              className: t3,
              onTabChange: r3,
              active: n3,
              value: c2,
              loadingComponent: u2,
              isLoadingInProgress: f2,
              children: d2,
              elementId: x2 = "",
              ...p
            } = e3, _ = (0, i2.useCallback)(() => {
              null == r3 || r3(c2);
            }, [r3, c2]);
            return f2 ? u2 : (0, s2.jsx)("li", {
              className: l2.default.root,
              children: (0, s2.jsx)(o2.Button, {
                className: (0, a2.clsx)(l2.default.button, { [l2.default.button_active]: n3 }, t3),
                onClick: _,
                role: "tab",
                id: "".concat(x2, "-").concat(c2, "-tab"),
                "aria-controls": "".concat(x2, "-").concat(c2, "-tabpanel"),
                "aria-selected": n3,
                ...p,
                children: d2
              })
            });
          };
        },
        8778: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.TabPanel = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = n2(r2(3346)), l2 = (e3) => {
            let { className: t3, name: r3, value: n3, children: i3, elementId: l3 = "", forwardRef: c2, ...u2 } = e3;
            return (0, s2.jsx)("div", {
              className: (0, a2.clsx)(o2.default.root, t3),
              role: "tabpanel",
              hidden: n3 !== r3,
              id: "".concat(l3, "-").concat(n3, "-tabpanel"),
              "aria-labelledby": "".concat(l3, "-").concat(n3, "-tab"),
              ref: c2,
              ...u2,
              children: n3 === r3 && i3
            });
          };
          t2.TabPanel = (0, i2.forwardRef)((e3, t3) => (0, s2.jsx)(l2, { forwardRef: t3, ...e3 }));
        },
        2044: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Tabs = t2.useTabsState = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = n2(r2(1883));
          t2.useTabsState = (e3) => {
            let [t3, r3] = (0, i2.useState)(e3);
            (0, i2.useLayoutEffect)(() => {
              r3(e3);
            }, [e3]);
            let n3 = (0, i2.useCallback)((e4) => {
              r3(e4);
            }, []);
            return (0, i2.useMemo)(() => ({ value: t3, onTabChange: n3 }), [t3, n3]);
          };
          let l2 = (e3) => {
            let {
              className: t3,
              variant: r3 = "default",
              value: n3,
              disabled: l3,
              onTabChange: c2,
              children: u2,
              forwardRef: f2,
              elementId: d2 = "",
              ...x2
            } = e3;
            return (0, s2.jsx)("ol", {
              className: (0, a2.clsx)(o2.default.root, o2.default["root_variant_".concat(r3)], t3),
              ref: f2,
              role: "tablist",
              ...x2,
              children: u2 && i2.Children.map(
                u2,
                (e4) => (0, i2.cloneElement)(e4, { onTabChange: c2, active: e4.props.value === n3, disabled: l3, elementId: d2 })
              )
            });
          };
          t2.Tabs = (0, i2.forwardRef)((e3, t3) => (0, s2.jsx)(l2, { forwardRef: t3, ...e3 }));
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(s, 2));
        }
      }, i = {};
      function o(e2) {
        var t2 = i[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = i[e2] = { exports: {} };
        return a[e2].call(r2.exports, r2, r2.exports, o), r2.exports;
      }
      o.d = (e2, t2) => {
        for (var r2 in t2) o.o(t2, r2) && !o.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, o.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), o.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var l = {};
      (() => {
        Object.defineProperty(l, "X$", { value: true }), l.x4 = l.OK = l.nT = l.mQ = void 0;
        var e2 = o(2044);
        Object.defineProperty(l, "mQ", {
          enumerable: true,
          get: function() {
            return e2.Tabs;
          }
        }), Object.defineProperty(l, "nT", {
          enumerable: true,
          get: function() {
            return e2.useTabsState;
          }
        });
        var t2 = o(848);
        Object.defineProperty(l, "OK", {
          enumerable: true,
          get: function() {
            return t2.Tab;
          }
        });
        var r2 = o(8778);
        Object.defineProperty(l, "x4", {
          enumerable: true,
          get: function() {
            return r2.TabPanel;
          }
        });
      })();
      var c = l.OK, u = l.x4, f = l.mQ, d = l.X$, x = l.nT;
    },
    51725: (e, t, r) => {
      "use strict";
      r.d(t, { VirtualScroll: () => v });
      var n = r(54486), s = r(50420), a = r(1365), i = r(61910), o = r(31500);
      let l = (e2) => {
        let { style: t2, forwardRef: r2, context: s2, ...a2 } = e2, i2 = (null == s2 ? void 0 : s2.listAriaLabel) || void 0, o2 = (null == s2 ? void 0 : s2.listRole) || "region";
        return (0, n.jsx)("div", {
          "aria-labelledby": "virtual-grid-header",
          role: o2,
          "aria-label": i2,
          style: { ...t2 },
          ref: r2,
          ...a2
        });
      }, c = (0, i.forwardRef)((e2, t2) => (0, n.jsx)(l, { forwardRef: t2, ...e2 }));
      var u = r(30142), f = r.n(u);
      let d = (e2) => {
        let { style: t2, forwardRef: r2, withFooter: a2, withHeader: i2, withForceScroll: o2, ...l2 } = e2;
        return (0, n.jsx)("div", {
          className: (0, s.$)(f().scroller, {
            [f().scroller_withFooter]: a2,
            [f().scroller_withHeader]: i2,
            [f().scroller_withForceScroll]: o2
          }),
          style: { ...t2 },
          ref: r2,
          ...l2,
          tabIndex: -1
        });
      }, x = (0, i.forwardRef)((e2, t2) => (0, n.jsx)(d, { forwardRef: t2, ...e2 }));
      var p = r(12186), _ = r(16143);
      let m = (e2) => {
        let {
          pageSize: t2,
          onPageHandler: r2,
          onRangeHandler: s2,
          debounceDurationInMs: a2 = 100,
          totalCount: o2 = 0,
          shouldTriggerRangeChangedOn: l2 = [],
          endReached: c2,
          ...u2
        } = e2, [f2, d2] = (0, i.useState)(null), x2 = (0, i.useMemo)(
          () => (0, p.A)((e3) => {
            if (null == s2 || s2(e3), l2.length > 0 && d2(e3), t2 && r2) {
              let n2 = Math.floor(e3.endIndex / t2) + 1, s3 = Math.floor(e3.startIndex / t2);
              for (let e4 = s3; e4 < n2; e4++) r2(e4);
            }
          }, a2),
          [a2, s2, t2, r2, l2]
        );
        (0, i.useEffect)(() => {
          l2.length > 0 && f2 && x2(f2);
        }, l2);
        let m2 = (0, i.useMemo)(() => {
          if (c2)
            return (0, p.A)((e3) => {
              c2(e3);
            }, a2);
        }, [c2, a2]);
        return (0, n.jsx)(_.sN, { rangeChanged: x2, totalCount: o2, endReached: m2, ...u2 });
      }, v = (e2) => {
        let {
          className: t2,
          customComponents: r2,
          onGetDataByPage: l2,
          onGetDataByRange: u2,
          itemClassName: d2,
          itemContentCallback: p2,
          listClassName: _2,
          overscan: v2 = 700,
          pageSize: g = 20,
          totalCount: b,
          totalRequests: y,
          debounceDurationInMs: h,
          initialItemCount: k,
          minInitialItemCount: E = 20,
          handleRef: w,
          alwaysShowScrollbar: j = false,
          testId: O,
          isMobileLayout: R = false,
          shouldTriggerRangeChangedOn: C,
          ...S
        } = e2, [P, A] = (0, i.useState)(false), T = (0, i.useMemo)(
          () => (0, a.A)((e3) => {
            A(e3);
          }, 100),
          []
        ), H = (0, i.useMemo)(() => {
          var e3, t3;
          return R ? {
            Scroller: x,
            List: null != (e3 = null == r2 ? void 0 : r2.List) ? e3 : c,
            Item: null == r2 ? void 0 : r2.Item,
            ScrollSeekPlaceholder: null == r2 ? void 0 : r2.ScrollSeekPlaceholder
          } : {
            Scroller: x,
            List: null != (t3 = null == r2 ? void 0 : r2.List) ? t3 : c,
            Item: null == r2 ? void 0 : r2.Item,
            Header: null == r2 ? void 0 : r2.Header,
            Footer: null == r2 ? void 0 : r2.Footer,
            ScrollSeekPlaceholder: null == r2 ? void 0 : r2.ScrollSeekPlaceholder
          };
        }, [r2, y, R]), M = k ? Math.min(k, E) : void 0, N = O ? (0, o.Am)(O) : {};
        return (0, n.jsxs)("div", {
          className: (0, s.$)(f().root, { [f().root_scrolling]: P || j, [f().root_notScrolling]: !P && !j }, t2),
          ...N,
          children: [
            R && (null == r2 ? void 0 : r2.Header) && r2.Header(),
            (0, n.jsx)(m, {
              overscan: v2,
              components: H,
              listClassName: _2,
              itemClassName: d2,
              isScrolling: T,
              itemContent: p2,
              scrollerRef: w,
              totalCount: b,
              pageSize: g,
              onPageHandler: l2,
              onRangeHandler: u2,
              debounceDurationInMs: h,
              initialItemCount: M,
              shouldTriggerRangeChangedOn: C,
              ...S
            }),
            R && (null == r2 ? void 0 : r2.Footer) && r2.Footer()
          ]
        });
      };
    },
    51828: (e, t, r) => {
      "use strict";
      r.d(t, { UnauthorizedButton: () => f });
      var n = r(54486), s = r(97396), a = r(47713), i = r(8817), o = r(77881), l = r(97800), c = r(67454), u = r(88416);
      let f = (e2) => {
        let {
          size: t2 = "m",
          variant: r2 = "default",
          withRipple: f2 = true,
          buttonText: d,
          isBlock: x,
          key: p,
          className: _
        } = e2, m = (0, s.useRouter)(), v = (0, u.useContainer)().get(c.QG), g = (0, i.c)(() => {
          v.authorizationUrl && m.push(v.authorizationUrl);
        });
        return (0, n.jsx)(
          o.$,
          {
            onClick: g,
            className: _,
            isBlock: x,
            color: "primary",
            variant: r2,
            size: t2,
            radius: "xxxl",
            withRipple: f2,
            children: d || (0, n.jsx)(l.Caption, {
              variant: "div",
              size: "l",
              lineClamp: 1,
              children: (0, n.jsx)(a.A, { id: "authorization.enter-button" })
            })
          },
          p
        );
      };
    },
    52742: (e, t, r) => {
      "use strict";
      r.d(t, { Disclaimer: () => E });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(47713), l = r(31500), c = r(8817), u = r(77881), f = r(97800), d = r(67454), x = r(88416), p = r(58094), _ = r(77706), m = r(50820), v = r(26779), g = r(90461), b = r(24036), y = r(25554), h = r.n(y);
      let k = {
        [v.n.ALBUM]: (0, n.jsx)(o.A, { id: "extra-explicit.confirm-unsafe-album" }),
        [v.n.PODCAST]: (0, n.jsx)(o.A, { id: "extra-explicit.confirm-unsafe-podcast" }),
        [v.n.ARTIST]: (0, n.jsx)(o.A, { id: "extra-explicit.confirm-unsafe-artist" }),
        [v.n.TRACK]: (0, n.jsx)(o.A, { id: "extra-explicit.confirm-unsafe-track" }),
        [v.n.AUDIOBOOK]: (0, n.jsx)(o.A, { id: "extra-explicit.confirm-unsafe-audiobook" }),
        [v.n.CLIP]: (0, n.jsx)(o.A, { id: "extra-explicit.confirm-unsafe-clip" })
      }, E = (0, a.PA)((e2) => {
        var t2;
        let { modalState: r2, onClose: a2, className: y2 } = e2, E2 = null == r2 ? void 0 : r2.modalData, w = (0, p.useHistory)(), j = (0, m.Z)(_.Z.main.href), O = (0, x.useContainer)().get(d.U2), R = (0, c.c)(() => {
          if (a2) return a2();
          w.canBack && w.back(), j();
        }), C = (null == E2 || null == (t2 = E2.details) ? void 0 : t2.url) && E2.details.text, S = (0, c.c)(() => {
          null == r2 || r2.setConfirmUnsafeDisclaimer(true);
          let e3 = O.get(g.c.ExEx), t3 = /* @__PURE__ */ new Date(), n2 = t3.setMinutes(t3.getMinutes() + 15);
          e3 ? O.set(
            g.c.ExEx,
            [...e3, "".concat(null == r2 ? void 0 : r2.entityType, "_").concat(null == r2 ? void 0 : r2.entityId)],
            { expires: new Date(n2) }
          ) : O.set(
            g.c.ExEx,
            ["".concat(null == r2 ? void 0 : r2.entityType, "_").concat(null == r2 ? void 0 : r2.entityId)],
            { expires: new Date(n2) }
          ), null == a2 || a2(), (null == r2 ? void 0 : r2.onDisclaimerConfirmHandler) && r2.onDisclaimerConfirmHandler();
        }), P = (0, c.c)(() => {
          (null == r2 ? void 0 : r2.shouldHistoryBack) ? (null == a2 || a2(), w.canBack && w.back(), j()) : null == a2 || a2(), (null == r2 ? void 0 : r2.onDisclaimerRejectHandler) && r2.onDisclaimerRejectHandler();
        });
        (0, i.useEffect)(
          () => () => {
            null == r2 || r2.reset();
          },
          [r2]
        );
        let A = (0, i.useMemo)(() => {
          if (E2) {
            var e3, t3;
            return (0, n.jsxs)(n.Fragment, {
              children: [
                (0, n.jsx)(f.Heading, {
                  variant: "h4",
                  size: "l",
                  className: (0, s.$)(h().title, h().text),
                  ...(0, l.Am)(l.OA.disclaimer.DISCLAIMER_TITLE),
                  children: E2.title
                }),
                (0, n.jsx)(f.Caption, {
                  variant: "div",
                  size: "l",
                  weight: "normal",
                  className: h().text,
                  ...(0, l.Am)(l.OA.disclaimer.DISCLAIMER_DESCRIPTION),
                  children: E2.description
                }),
                C && (0, n.jsx)(b.Link, {
                  href: null == (e3 = E2.details) ? void 0 : e3.url,
                  className: h().link,
                  children: (0, n.jsx)(f.Caption, {
                    variant: "span",
                    size: "l",
                    weight: "normal",
                    children: null == (t3 = E2.details) ? void 0 : t3.text
                  })
                })
              ]
            });
          }
          return null;
        }, [E2, C]), T = (0, i.useMemo)(
          () => (null == r2 ? void 0 : r2.type) === v.Y.UNSAFE ? (0, n.jsxs)("div", {
            className: h().buttons,
            children: [
              (0, n.jsx)(u.$, {
                color: "primary",
                onClick: P,
                size: "l",
                radius: "xxxl",
                className: h().button,
                ...(0, l.Am)(l.OA.disclaimer.DISCLAIMER_REJECT_BUTTON),
                children: (0, n.jsx)(o.A, { id: "extra-explicit.reject-unsafe-entity" })
              }),
              (0, n.jsx)(u.$, {
                color: "secondary",
                onClick: S,
                size: "l",
                radius: "xxxl",
                className: h().button,
                ...(0, l.Am)(l.OA.disclaimer.DISCLAIMER_CONFIRM_BUTTON),
                children: r2.entityType && k[r2.entityType]
              })
            ]
          }) : (0, n.jsx)("div", {
            className: h().buttons,
            children: (0, n.jsx)(u.$, {
              color: "primary",
              onClick: R,
              size: "l",
              radius: "xxxl",
              className: h().button,
              ...(0, l.Am)(l.OA.disclaimer.DISCLAIMER_REJECT_BUTTON),
              children: (0, n.jsx)(o.A, { id: "interface-actions.confirm" })
            })
          }),
          [S, null == r2 ? void 0 : r2.entityType, null == r2 ? void 0 : r2.type, R, P]
        );
        return (0, n.jsx)("div", {
          className: (0, s.$)(h().root, y2),
          ...(0, l.Am)(l.OA.disclaimer.DISCLAIMER_CONTENT),
          children: (0, n.jsxs)("div", { className: h().container, children: [A, T] })
        });
      });
    },
    52862: (e, t, r) => {
      "use strict";
      r.d(t, { BlockHeader: () => g });
      var n = r(54486), s = r(50420), a = r(61910), i = r(43350), o = r(31500), l = r(5956), c = r(58360), u = r(6971), f = r(22674), d = r(97800), x = r(61015), p = r(24036), _ = r(91786), m = r.n(_);
      let v = (e2) => {
        let {
          className: t2,
          coverUrl: r2,
          labeledForId: _2,
          subTitle: v2,
          title: g2,
          description: b,
          viewAllActionLink: y,
          controls: h,
          titleSize: k = "m",
          coverBackgroundColor: E,
          coverRadius: w = "s",
          titleClassName: j,
          titleLineClamp: O,
          fallbackIconVariant: R,
          available: C = true,
          onViewAllAction: S,
          children: P,
          headingRef: A,
          coverContainerClassName: T,
          headingVariant: H = "h3",
          withDescriptionWidthLimit: M = true,
          isShimmerVisible: N,
          isShimmerActive: I,
          withCover: L,
          withDescription: B,
          forwardRef: D,
          shimmerCoverClassName: z,
          ...F
        } = e2, U = (0, a.useRef)(null), W = r2 || L, V = b || B, Y = (0, a.useCallback)(() => {
          U.current && "focus" in U.current && U.current.focus();
        }, []), K = (0, x.useSendEventOnBlockNavigated)(), X = (0, a.useCallback)(() => {
          S ? S() : K({ to: i.QT.Link });
        }, [K, S]), q = (0, a.useMemo)(
          () => g2 && y && C ? (0, n.jsx)(p.Link, {
            className: m().title,
            containerClassName: m().linkContainer,
            textClassName: m().linkText,
            icon: (0, n.jsx)(l.Icon, { className: m().titleIcon, size: "xs", variant: "arrowRight" }),
            iconPosition: "right",
            href: y,
            onClick: X,
            ...(0, o.Am)(o.S7.BLOCK_HEADER_TITLE),
            children: (0, n.jsx)(d.Heading, {
              id: _2,
              className: (0, s.$)(m().heading, j),
              variant: H,
              size: k,
              weight: "bold",
              lineClamp: O,
              ref: A,
              children: g2
            })
          }) : (0, n.jsx)("div", {
            className: m().title,
            children: (0, n.jsx)(d.Heading, {
              id: _2,
              className: (0, s.$)(m().heading, j, { [m().heading_notAvailable]: !C }),
              variant: H,
              size: k,
              weight: "bold",
              lineClamp: O,
              ref: A,
              ...(0, o.Am)(o.S7.BLOCK_HEADER_TITLE),
              children: g2
            })
          }),
          [C, X, A, H, _2, g2, j, O, k, y]
        ), Q = (0, a.useMemo)(
          () => B && N ? (0, n.jsx)(f.Shimmer, { isActive: I, className: m().shimmerDescription }) : b,
          [B, N, b, I]
        ), G = (0, a.useMemo)(
          () => L && N ? (0, n.jsx)(f.Shimmer, { isActive: I, className: (0, s.$)(m().shimmerCover, z), radius: "s" }) : (0, n.jsx)(c.Image, {
            src: r2,
            fallbackIconVariant: R,
            style: { backgroundColor: E },
            className: m().cover,
            ref: U,
            onClick: Y,
            fit: "cover",
            withAvatarReplace: true,
            fallbackIconSize: "s",
            "aria-hidden": true,
            ...(0, o.Am)(o.S7.BLOCK_HEADER_COVER)
          }),
          [E, r2, R, Y, I, N, z, L]
        );
        return (0, n.jsxs)("div", {
          className: (0, s.$)(m().root, t2),
          ref: D,
          ...F,
          ...(0, o.Am)(o.S7.BLOCK_HEADER),
          children: [
            (0, n.jsxs)("div", {
              className: m().start,
              children: [
                W && (0, n.jsx)(u.Paper, { radius: w, className: (0, s.$)(m().coverContainer, T), children: G }),
                (0, n.jsxs)("div", {
                  className: m().textContainer,
                  children: [
                    v2,
                    q,
                    V && (0, n.jsx)(d.Caption, {
                      id: "".concat(_2, "-description"),
                      variant: "span",
                      type: "text",
                      size: "m",
                      weight: "medium",
                      lineClamp: M ? 2 : void 0,
                      className: (0, s.$)(m().description, { [m().description_widthLimit]: M }),
                      ...(0, o.Am)(o.S7.BLOCK_HEADER_DESCRIPTION),
                      children: Q
                    })
                  ]
                })
              ]
            }),
            h || P
          ]
        });
      }, g = (0, a.forwardRef)((e2, t2) => (0, n.jsx)(v, { forwardRef: t2, ...e2 }));
    },
    54598: (e, t, r) => {
      "use strict";
      r.d(t, { ErrorBoosterScript: () => n }), r(54486), r(61910), r(67454), r(95723);
      let n = (e2) => {
        let { nonce: t2, hostTld: r2, assetPrefix: n2, env: s } = e2;
        return null;
      };
    },
    55088: (e) => {
      e.exports = {
        root: "EditContentModal_root__spGT4",
        modalContent: "EditContentModal_modalContent__uk5Di",
        header: "EditContentModal_header__F6BJQ",
        title: "EditContentModal_title__OFu19",
        content: "EditContentModal_content__6yEGM",
        field: "EditContentModal_field__rexIL",
        label: "EditContentModal_label__Cf3Kp",
        input: "EditContentModal_input__8O8GH",
        input_error: "EditContentModal_input_error__fxTOr",
        buttons: "EditContentModal_buttons__bHzfS",
        button: "EditContentModal_button__usS1Z"
      };
    },
    56204: (e, t, r) => {
      "use strict";
      r.d(t, { MainSuspenseLoader: () => o });
      var n = r(54486), s = r(5956), a = r(62624), i = r.n(a);
      let o = (e2) => {
        let { style: t2 } = e2, r2 = {
          display: "flex",
          position: "fixed",
          insetBlockStart: 0,
          insetInlineEnd: 0,
          insetBlockEnd: 0,
          insetInlineStart: 0,
          zIndex: "var(--ym-z-index-loader)",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
          background: "var(--ym-background-color-primary-enabled-basic)",
          ...t2
        };
        return (0, n.jsx)("div", {
          style: r2,
          children: (0, n.jsx)(s.Icon, {
            variant: "musicLogo",
            style: { width: "100%", maxWidth: "100px", color: "var(--ym-logo-color-primary-variant)" },
            className: i().icon
          })
        });
      };
    },
    58360: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { FallbackImage: () => f, Image: () => d, __esModule: () => x });
      var n, s = r(15209), a = r(94377), i = r(61910), o = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        2964: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_size_xxxs: "Rkdd2vKC_3xa1eUdRdHP",
            root_size_xxs: "l3tE1hAMmBj2aoPPwU08",
            root_size_xs: "UwnL5AJBMMAp6NwMDdZk",
            root_size_s: "DzJFnuf7XgdkFh28JAsM",
            root_size_m: "o_v2ds2BaqtzAsRuCVjw",
            root_size_l: "YjRa1ZjM_lXFlrfS7jcu",
            root_size_xl: "Seq0GowcqQmiA9LdLP_g",
            root_size_xxl: "mfy69_BvBIamD0e22rCQ",
            root_size_xxxl: "JY1OniQewgW9iHgfllZS"
          };
        },
        1652: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "qQ7GQU14EkggPBC6jdeS",
            root_withContainPaint: "rWaMH5WAcj6HcPXwO6_g",
            root_fit_cover: "fosYvyLDok3Kjj9OWmxG",
            root_fit_contain: "qq6y6t3GDqWHbY9QpSrd",
            root_fit_fill: "tqnS8b3151lnOu_CX7kk",
            fallback: "iha4fse_uYSR5XdCNFvU",
            fallbackIcon: "IXo8WeM40YvVigqgCP7J",
            loading: "POCNC8sLlvh3j1hU13Ct",
            "gradient-horizontal": "K2VhfffBoVbgaaugfOoH"
          };
        },
        4490: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { DOWN: () => o2, LEFT: () => s2, RIGHT: () => a2, UP: () => i2, useSwipeable: () => x2 });
          var n2 = r2(810);
          let s2 = "Left", a2 = "Right", i2 = "Up", o2 = "Down", l2 = {
            delta: 10,
            preventScrollOnSwipe: false,
            rotationAngle: 0,
            trackMouse: false,
            trackTouch: true,
            swipeDuration: 1 / 0,
            touchEventOptions: { passive: true }
          }, c2 = { first: true, initial: [0, 0], start: 0, swiping: false, xy: [0, 0] }, u2 = "mousemove", f2 = "mouseup";
          function d2(e3, t3) {
            if (0 === t3) return e3;
            let r3 = Math.PI / 180 * t3;
            return [e3[0] * Math.cos(r3) + e3[1] * Math.sin(r3), e3[1] * Math.cos(r3) - e3[0] * Math.sin(r3)];
          }
          function x2(e3) {
            var t3, r3, x3;
            let p, { trackMouse: _ } = e3, m = n2.useRef(Object.assign({}, c2)), v = n2.useRef(Object.assign({}, l2)), g = n2.useRef(Object.assign({}, v.current));
            for (p in g.current = Object.assign({}, v.current), v.current = Object.assign(Object.assign({}, l2), e3), l2)
              void 0 === v.current[p] && (v.current[p] = l2[p]);
            let [b, y] = n2.useMemo(
              () => (function(e4, t4) {
                let r4 = (t5) => {
                  let r5 = "touches" in t5;
                  r5 && t5.touches.length > 1 || e4((e5, s3) => {
                    s3.trackMouse && !r5 && (document.addEventListener(u2, n3), document.addEventListener(f2, p2));
                    let { clientX: a3, clientY: i3 } = r5 ? t5.touches[0] : t5, o3 = d2([a3, i3], s3.rotationAngle);
                    return s3.onTouchStartOrOnMouseDown && s3.onTouchStartOrOnMouseDown({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), {
                      initial: o3.slice(),
                      xy: o3,
                      start: t5.timeStamp || 0
                    });
                  });
                }, n3 = (t5) => {
                  e4((e5, r5) => {
                    var n4, c3, u3, f3;
                    let x5 = "touches" in t5;
                    if (x5 && t5.touches.length > 1) return e5;
                    if (t5.timeStamp - e5.start > r5.swipeDuration)
                      return e5.swiping ? Object.assign(Object.assign({}, e5), { swiping: false }) : e5;
                    let { clientX: p3, clientY: _3 } = x5 ? t5.touches[0] : t5, [m3, v2] = d2([p3, _3], r5.rotationAngle), g2 = m3 - e5.xy[0], b2 = v2 - e5.xy[1], y2 = Math.abs(g2), h = Math.abs(b2), k = (t5.timeStamp || 0) - e5.start, E = Math.sqrt(y2 * y2 + h * h) / (k || 1), w = [g2 / (k || 1), b2 / (k || 1)], j = (n4 = y2, c3 = h, u3 = g2, f3 = b2, n4 > c3 ? u3 > 0 ? a2 : s2 : f3 > 0 ? o2 : i2), O = "number" == typeof r5.delta ? r5.delta : r5.delta[j.toLowerCase()] || l2.delta;
                    if (y2 < O && h < O && !e5.swiping) return e5;
                    let R = {
                      absX: y2,
                      absY: h,
                      deltaX: g2,
                      deltaY: b2,
                      dir: j,
                      event: t5,
                      first: e5.first,
                      initial: e5.initial,
                      velocity: E,
                      vxvy: w
                    };
                    R.first && r5.onSwipeStart && r5.onSwipeStart(R), r5.onSwiping && r5.onSwiping(R);
                    let C = false;
                    return (r5.onSwiping || r5.onSwiped || r5["onSwiped".concat(j)]) && (C = true), C && r5.preventScrollOnSwipe && r5.trackTouch && t5.cancelable && t5.preventDefault(), Object.assign(Object.assign({}, e5), { first: false, eventData: R, swiping: true });
                  });
                }, x4 = (t5) => {
                  e4((e5, r5) => {
                    let n4;
                    if (e5.swiping && e5.eventData) {
                      if (t5.timeStamp - e5.start < r5.swipeDuration) {
                        n4 = Object.assign(Object.assign({}, e5.eventData), { event: t5 }), r5.onSwiped && r5.onSwiped(n4);
                        let s3 = r5["onSwiped".concat(n4.dir)];
                        s3 && s3(n4);
                      }
                    } else r5.onTap && r5.onTap({ event: t5 });
                    return r5.onTouchEndOrOnMouseUp && r5.onTouchEndOrOnMouseUp({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), { eventData: n4 });
                  });
                }, p2 = (e5) => {
                  document.removeEventListener(u2, n3), document.removeEventListener(f2, p2), x4(e5);
                }, _2 = (e5, t5) => {
                  let s3 = () => {
                  };
                  if (e5 && e5.addEventListener) {
                    let a3 = Object.assign(Object.assign({}, l2.touchEventOptions), t5.touchEventOptions), i3 = [
                      ["touchstart", r4, a3],
                      [
                        "touchmove",
                        n3,
                        Object.assign(Object.assign({}, a3), t5.preventScrollOnSwipe ? { passive: false } : {})
                      ],
                      ["touchend", x4, a3]
                    ];
                    i3.forEach((t6) => {
                      let [r5, n4, s4] = t6;
                      return e5.addEventListener(r5, n4, s4);
                    }), s3 = () => i3.forEach((t6) => {
                      let [r5, n4] = t6;
                      return e5.removeEventListener(r5, n4);
                    });
                  }
                  return s3;
                }, m2 = {
                  ref: (t5) => {
                    null !== t5 && e4((e5, r5) => {
                      if (e5.el === t5) return e5;
                      let n4 = {};
                      return e5.el && e5.el !== t5 && e5.cleanUpTouch && (e5.cleanUpTouch(), n4.cleanUpTouch = void 0), r5.trackTouch && t5 && (n4.cleanUpTouch = _2(t5, r5)), Object.assign(Object.assign(Object.assign({}, e5), { el: t5 }), n4);
                    });
                  }
                };
                return t4.trackMouse && (m2.onMouseDown = r4), [m2, _2];
              })((e4) => m.current = e4(m.current, v.current), { trackMouse: _ }),
              [_]
            );
            return t3 = m.current, r3 = v.current, x3 = g.current, m.current = r3.trackTouch && t3.el ? t3.cleanUpTouch ? r3.preventScrollOnSwipe !== x3.preventScrollOnSwipe || r3.touchEventOptions.passive !== x3.touchEventOptions.passive ? (t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) })) : t3 : Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) }) : (t3.cleanUpTouch && t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: void 0 })), b;
          }
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        8442: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "addToPlaylist_xxs", xlinkHref: "/icons/sprite.svg#addToPlaylist_xxs" })
            ]);
          });
        },
        6644: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "add_l", xlinkHref: "/icons/sprite.svg#add_l" })
            ]);
          });
        },
        7319: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "add_xxs", xlinkHref: "/icons/sprite.svg#add_xxs" })
            ]);
          });
        },
        9351: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_s", xlinkHref: "/icons/sprite.svg#adult_s" })
            ]);
          });
        },
        7171: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xs", xlinkHref: "/icons/sprite.svg#adult_xs" })
            ]);
          });
        },
        2586: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xxs", xlinkHref: "/icons/sprite.svg#adult_xxs" })
            ]);
          });
        },
        4656: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xxxs", xlinkHref: "/icons/sprite.svg#adult_xxxs" })
            ]);
          });
        },
        996: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_l", xlinkHref: "/icons/sprite.svg#album_l" })
            ]);
          });
        },
        2092: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_s", xlinkHref: "/icons/sprite.svg#album_s" })
            ]);
          });
        },
        6304: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xl", xlinkHref: "/icons/sprite.svg#album_xl" })
            ]);
          });
        },
        9030: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xs", xlinkHref: "/icons/sprite.svg#album_xs" })
            ]);
          });
        },
        5822: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xxs", xlinkHref: "/icons/sprite.svg#album_xxs" })
            ]);
          });
        },
        9422: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowDown_xs", xlinkHref: "/icons/sprite.svg#arrowDown_xs" })
            ]);
          });
        },
        5272: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowDown_xxs", xlinkHref: "/icons/sprite.svg#arrowDown_xxs" })
            ]);
          });
        },
        1491: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowLeft_xs", xlinkHref: "/icons/sprite.svg#arrowLeft_xs" })
            ]);
          });
        },
        4860: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowLeft_xxs", xlinkHref: "/icons/sprite.svg#arrowLeft_xxs" })
            ]);
          });
        },
        2337: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xs", xlinkHref: "/icons/sprite.svg#arrowRight_xs" })
            ]);
          });
        },
        8711: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxs" })
            ]);
          });
        },
        8170: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xxxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxxs" })
            ]);
          });
        },
        8109: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "artist_xxs", xlinkHref: "/icons/sprite.svg#artist_xxs" })
            ]);
          });
        },
        7341: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "attention_xxl", xlinkHref: "/icons/sprite.svg#attention_xxl" })
            ]);
          });
        },
        2435: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "attention_xxxl", xlinkHref: "/icons/sprite.svg#attention_xxxl" })
            ]);
          });
        },
        3918: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "bandlink", xlinkHref: "/icons/sprite.svg#bandlink" })
            ]);
          });
        },
        2571: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "booksLogo", xlinkHref: "/icons/sprite.svg#booksLogo" })
            ]);
          });
        },
        4904: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "bucket_xxs", xlinkHref: "/icons/sprite.svg#bucket_xxs" })
            ]);
          });
        },
        9202: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "cast_xs", xlinkHref: "/icons/sprite.svg#cast_xs" })
            ]);
          });
        },
        130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chain_xs", xlinkHref: "/icons/sprite.svg#chain_xs" })
            ]);
          });
        },
        5971: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chain_xxs", xlinkHref: "/icons/sprite.svg#chain_xxs" })
            ]);
          });
        },
        3331: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartDown_xxs", xlinkHref: "/icons/sprite.svg#chartDown_xxs" })
            ]);
          });
        },
        9783: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartNew_xxs", xlinkHref: "/icons/sprite.svg#chartNew_xxs" })
            ]);
          });
        },
        8184: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartSame_xxs", xlinkHref: "/icons/sprite.svg#chartSame_xxs" })
            ]);
          });
        },
        4926: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartUp_xxs", xlinkHref: "/icons/sprite.svg#chartUp_xxs" })
            ]);
          });
        },
        9505: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxl", xlinkHref: "/icons/sprite.svg#check_xxl" })
            ]);
          });
        },
        3176: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxs", xlinkHref: "/icons/sprite.svg#check_xxs" })
            ]);
          });
        },
        5565: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxxs", xlinkHref: "/icons/sprite.svg#check_xxxs" })
            ]);
          });
        },
        9040: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "clip_xl", xlinkHref: "/icons/sprite.svg#clip_xl" })
            ]);
          });
        },
        4789: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "clip_xxs", xlinkHref: "/icons/sprite.svg#clip_xxs" })
            ]);
          });
        },
        7923: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xs", xlinkHref: "/icons/sprite.svg#close_xs" })
            ]);
          });
        },
        8151: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xxs", xlinkHref: "/icons/sprite.svg#close_xxs" })
            ]);
          });
        },
        8127: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xxxs", xlinkHref: "/icons/sprite.svg#close_xxxs" })
            ]);
          });
        },
        8690: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "code_xxs", xlinkHref: "/icons/sprite.svg#code_xxs" })
            ]);
          });
        },
        3076: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "collections_m", xlinkHref: "/icons/sprite.svg#collections_m" })
            ]);
          });
        },
        2495: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "collections_selected_m",
                xlinkHref: "/icons/sprite.svg#collections_selected_m"
              })
            ]);
          });
        },
        1524: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "crown_xxs", xlinkHref: "/icons/sprite.svg#crown_xxs" })
            ]);
          });
        },
        1162: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_s", xlinkHref: "/icons/sprite.svg#dislike_s" })
            ]);
          });
        },
        3654: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_xs", xlinkHref: "/icons/sprite.svg#dislike_xs" })
            ]);
          });
        },
        2361: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_xxs", xlinkHref: "/icons/sprite.svg#dislike_xxs" })
            ]);
          });
        },
        6837: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_s", xlinkHref: "/icons/sprite.svg#disliked_s" })
            ]);
          });
        },
        6507: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_xs", xlinkHref: "/icons/sprite.svg#disliked_xs" })
            ]);
          });
        },
        3972: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_xxs", xlinkHref: "/icons/sprite.svg#disliked_xxs" })
            ]);
          });
        },
        8993: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "donation_xxxs", xlinkHref: "/icons/sprite.svg#donation_xxxs" })
            ]);
          });
        },
        7031: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "download_l", xlinkHref: "/icons/sprite.svg#download_l" })
            ]);
          });
        },
        9330: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "download_xxs", xlinkHref: "/icons/sprite.svg#download_xxs" })
            ]);
          });
        },
        7346: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "downloaded_xxs", xlinkHref: "/icons/sprite.svg#downloaded_xxs" })
            ]);
          });
        },
        2604: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dragDots_xxs", xlinkHref: "/icons/sprite.svg#dragDots_xxs" })
            ]);
          });
        },
        6894: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "edit_xxs", xlinkHref: "/icons/sprite.svg#edit_xxs" })
            ]);
          });
        },
        2024: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_s", xlinkHref: "/icons/sprite.svg#exclamation_s" })
            ]);
          });
        },
        3193: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xs", xlinkHref: "/icons/sprite.svg#exclamation_xs" })
            ]);
          });
        },
        6391: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xxs", xlinkHref: "/icons/sprite.svg#exclamation_xxs" })
            ]);
          });
        },
        2933: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xxxs", xlinkHref: "/icons/sprite.svg#exclamation_xxxs" })
            ]);
          });
        },
        776: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_s", xlinkHref: "/icons/sprite.svg#explicit_s" })
            ]);
          });
        },
        30: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xs", xlinkHref: "/icons/sprite.svg#explicit_xs" })
            ]);
          });
        },
        9369: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xxs", xlinkHref: "/icons/sprite.svg#explicit_xxs" })
            ]);
          });
        },
        1334: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xxxs", xlinkHref: "/icons/sprite.svg#explicit_xxxs" })
            ]);
          });
        },
        226: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "eye_crossed_xxs", xlinkHref: "/icons/sprite.svg#eye_crossed_xxs" })
            ]);
          });
        },
        7802: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "filter_xs", xlinkHref: "/icons/sprite.svg#filter_xs" })
            ]);
          });
        },
        8130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "filter_xxs", xlinkHref: "/icons/sprite.svg#filter_xxs" })
            ]);
          });
        },
        3738: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "fullscreen_xs", xlinkHref: "/icons/sprite.svg#fullscreen_xs" })
            ]);
          });
        },
        2161: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "googlePlay", xlinkHref: "/icons/sprite.svg#googlePlay" })
            ]);
          });
        },
        9509: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "history_m", xlinkHref: "/icons/sprite.svg#history_m" })
            ]);
          });
        },
        8987: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "home_m", xlinkHref: "/icons/sprite.svg#home_m" })
            ]);
          });
        },
        190: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "home_selected_m", xlinkHref: "/icons/sprite.svg#home_selected_m" })
            ]);
          });
        },
        5304: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "huaweiAppGallery", xlinkHref: "/icons/sprite.svg#huaweiAppGallery" })
            ]);
          });
        },
        5270: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "info_xxs", xlinkHref: "/icons/sprite.svg#info_xxs" })
            ]);
          });
        },
        843: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kids_m", xlinkHref: "/icons/sprite.svg#kids_m" })
            ]);
          });
        },
        5122: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kids_selected_m", xlinkHref: "/icons/sprite.svg#kids_selected_m" })
            ]);
          });
        },
        2646: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kinopoiskEn", xlinkHref: "/icons/sprite.svg#kinopoiskEn" })
            ]);
          });
        },
        7500: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kinopoiskRu", xlinkHref: "/icons/sprite.svg#kinopoiskRu" })
            ]);
          });
        },
        3560: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lightning_xxs", xlinkHref: "/icons/sprite.svg#lightning_xxs" })
            ]);
          });
        },
        9838: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likeVariant_xxs", xlinkHref: "/icons/sprite.svg#likeVariant_xxs" })
            ]);
          });
        },
        4793: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_l", xlinkHref: "/icons/sprite.svg#like_l" })
            ]);
          });
        },
        7405: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_m", xlinkHref: "/icons/sprite.svg#like_m" })
            ]);
          });
        },
        2340: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_xs", xlinkHref: "/icons/sprite.svg#like_xs" })
            ]);
          });
        },
        7513: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_xxs", xlinkHref: "/icons/sprite.svg#like_xxs" })
            ]);
          });
        },
        5720: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likedVariant_s", xlinkHref: "/icons/sprite.svg#likedVariant_s" })
            ]);
          });
        },
        7399: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likedVariant_xxs", xlinkHref: "/icons/sprite.svg#likedVariant_xxs" })
            ]);
          });
        },
        820: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_m", xlinkHref: "/icons/sprite.svg#liked_m" })
            ]);
          });
        },
        2125: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_xs", xlinkHref: "/icons/sprite.svg#liked_xs" })
            ]);
          });
        },
        9104: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_xxs", xlinkHref: "/icons/sprite.svg#liked_xxs" })
            ]);
          });
        },
        5849: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "link_xxs", xlinkHref: "/icons/sprite.svg#link_xxs" })
            ]);
          });
        },
        1426: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "listen_xxxs", xlinkHref: "/icons/sprite.svg#listen_xxxs" })
            ]);
          });
        },
        4014: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liteVersion_xs", xlinkHref: "/icons/sprite.svg#liteVersion_xs" })
            ]);
          });
        },
        5443: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_m", xlinkHref: "/icons/sprite.svg#lock_m" })
            ]);
          });
        },
        896: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_xs", xlinkHref: "/icons/sprite.svg#lock_xs" })
            ]);
          });
        },
        3613: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_xxs", xlinkHref: "/icons/sprite.svg#lock_xxs" })
            ]);
          });
        },
        9372: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lyrics_xxs", xlinkHref: "/icons/sprite.svg#lyrics_xxs" })
            ]);
          });
        },
        6104: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "macos", xlinkHref: "/icons/sprite.svg#macos" })
            ]);
          });
        },
        3709: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "macos_xxs", xlinkHref: "/icons/sprite.svg#macos_xxs" })
            ]);
          });
        },
        3685: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "menuArrow_xxs", xlinkHref: "/icons/sprite.svg#menuArrow_xxs" })
            ]);
          });
        },
        8782: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_m", xlinkHref: "/icons/sprite.svg#more_m" })
            ]);
          });
        },
        1829: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_xs", xlinkHref: "/icons/sprite.svg#more_xs" })
            ]);
          });
        },
        3302: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_xxs", xlinkHref: "/icons/sprite.svg#more_xxs" })
            ]);
          });
        },
        2502: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogo", xlinkHref: "/icons/sprite.svg#musicLogo" })
            ]);
          });
        },
        1754: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoCenterEn", xlinkHref: "/icons/sprite.svg#musicLogoCenterEn" })
            ]);
          });
        },
        6615: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoCenterRu", xlinkHref: "/icons/sprite.svg#musicLogoCenterRu" })
            ]);
          });
        },
        7942: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoLeftEn", xlinkHref: "/icons/sprite.svg#musicLogoLeftEn" })
            ]);
          });
        },
        1498: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoLeftRu", xlinkHref: "/icons/sprite.svg#musicLogoLeftRu" })
            ]);
          });
        },
        1893: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationCollection_xs",
                xlinkHref: "/icons/sprite.svg#navigationCollection_xs"
              })
            ]);
          });
        },
        1563: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationConcerts_xs",
                xlinkHref: "/icons/sprite.svg#navigationConcerts_xs"
              })
            ]);
          });
        },
        1578: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationForYouAndTrends_xs",
                xlinkHref: "/icons/sprite.svg#navigationForYouAndTrends_xs"
              })
            ]);
          });
        },
        9348: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "navigationKids_xs", xlinkHref: "/icons/sprite.svg#navigationKids_xs" })
            ]);
          });
        },
        965: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationMyVibe_xs",
                xlinkHref: "/icons/sprite.svg#navigationMyVibe_xs"
              })
            ]);
          });
        },
        3877: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationNonMusic_xs",
                xlinkHref: "/icons/sprite.svg#navigationNonMusic_xs"
              })
            ]);
          });
        },
        9968: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "navigationPlus_xs", xlinkHref: "/icons/sprite.svg#navigationPlus_xs" })
            ]);
          });
        },
        3778: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationSearch_xs",
                xlinkHref: "/icons/sprite.svg#navigationSearch_xs"
              })
            ]);
          });
        },
        1084: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xs", xlinkHref: "/icons/sprite.svg#next_xs" })
            ]);
          });
        },
        4483: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xxl", xlinkHref: "/icons/sprite.svg#next_xxl" })
            ]);
          });
        },
        811: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xxs", xlinkHref: "/icons/sprite.svg#next_xxs" })
            ]);
          });
        },
        7252: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "non_music_m", xlinkHref: "/icons/sprite.svg#non_music_m" })
            ]);
          });
        },
        3013: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "non_music_selected_m",
                xlinkHref: "/icons/sprite.svg#non_music_selected_m"
              })
            ]);
          });
        },
        2774: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_s", xlinkHref: "/icons/sprite.svg#note_s" })
            ]);
          });
        },
        4298: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_xl", xlinkHref: "/icons/sprite.svg#note_xl" })
            ]);
          });
        },
        4254: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_xs", xlinkHref: "/icons/sprite.svg#note_xs" })
            ]);
          });
        },
        8499: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "offline_xxl", xlinkHref: "/icons/sprite.svg#offline_xxl" })
            ]);
          });
        },
        4997: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pauseVibe_s", xlinkHref: "/icons/sprite.svg#pauseVibe_s" })
            ]);
          });
        },
        7076: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_l", xlinkHref: "/icons/sprite.svg#pause_filled_l" })
            ]);
          });
        },
        3792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_m", xlinkHref: "/icons/sprite.svg#pause_filled_m" })
            ]);
          });
        },
        5132: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xl", xlinkHref: "/icons/sprite.svg#pause_filled_xl" })
            ]);
          });
        },
        8131: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xs", xlinkHref: "/icons/sprite.svg#pause_filled_xs" })
            ]);
          });
        },
        705: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xxl", xlinkHref: "/icons/sprite.svg#pause_filled_xxl" })
            ]);
          });
        },
        5346: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_m", xlinkHref: "/icons/sprite.svg#pause_m" })
            ]);
          });
        },
        792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_xs", xlinkHref: "/icons/sprite.svg#pause_xs" })
            ]);
          });
        },
        6122: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_xxs", xlinkHref: "/icons/sprite.svg#pause_xxs" })
            ]);
          });
        },
        5386: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pencil_xxs", xlinkHref: "/icons/sprite.svg#pencil_xxs" })
            ]);
          });
        },
        3146: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_s", xlinkHref: "/icons/sprite.svg#picture_s" })
            ]);
          });
        },
        8868: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_xl", xlinkHref: "/icons/sprite.svg#picture_xl" })
            ]);
          });
        },
        1125: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_xs", xlinkHref: "/icons/sprite.svg#picture_xs" })
            ]);
          });
        },
        976: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_filled_xs", xlinkHref: "/icons/sprite.svg#pin_filled_xs" })
            ]);
          });
        },
        9434: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_filled_xxs", xlinkHref: "/icons/sprite.svg#pin_filled_xxs" })
            ]);
          });
        },
        9288: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_xs", xlinkHref: "/icons/sprite.svg#pin_xs" })
            ]);
          });
        },
        3201: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_xxs", xlinkHref: "/icons/sprite.svg#pin_xxs" })
            ]);
          });
        },
        8112: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playLast_xxs", xlinkHref: "/icons/sprite.svg#playLast_xxs" })
            ]);
          });
        },
        8044: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playNext_xxs", xlinkHref: "/icons/sprite.svg#playNext_xxs" })
            ]);
          });
        },
        8303: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playQueue_m", xlinkHref: "/icons/sprite.svg#playQueue_m" })
            ]);
          });
        },
        9863: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playQueue_xs", xlinkHref: "/icons/sprite.svg#playQueue_xs" })
            ]);
          });
        },
        2084: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playVibe_s", xlinkHref: "/icons/sprite.svg#playVibe_s" })
            ]);
          });
        },
        8582: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_l", xlinkHref: "/icons/sprite.svg#play_filled_l" })
            ]);
          });
        },
        4777: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_m", xlinkHref: "/icons/sprite.svg#play_filled_m" })
            ]);
          });
        },
        8779: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xl", xlinkHref: "/icons/sprite.svg#play_filled_xl" })
            ]);
          });
        },
        1945: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xs", xlinkHref: "/icons/sprite.svg#play_filled_xs" })
            ]);
          });
        },
        7402: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xxl", xlinkHref: "/icons/sprite.svg#play_filled_xxl" })
            ]);
          });
        },
        1351: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_m", xlinkHref: "/icons/sprite.svg#play_m" })
            ]);
          });
        },
        1874: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xs", xlinkHref: "/icons/sprite.svg#play_xs" })
            ]);
          });
        },
        2026: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xxs", xlinkHref: "/icons/sprite.svg#play_xxs" })
            ]);
          });
        },
        5378: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xxxs", xlinkHref: "/icons/sprite.svg#play_xxxs" })
            ]);
          });
        },
        3751: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_s", xlinkHref: "/icons/sprite.svg#playlist_s" })
            ]);
          });
        },
        8503: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_xl", xlinkHref: "/icons/sprite.svg#playlist_xl" })
            ]);
          });
        },
        1580: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_xs", xlinkHref: "/icons/sprite.svg#playlist_xs" })
            ]);
          });
        },
        8861: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plus", xlinkHref: "/icons/sprite.svg#plus" })
            ]);
          });
        },
        6809: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusBadge", xlinkHref: "/icons/sprite.svg#plusBadge" })
            ]);
          });
        },
        5266: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusColor", xlinkHref: "/icons/sprite.svg#plusColor" })
            ]);
          });
        },
        1179: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusOutlined", xlinkHref: "/icons/sprite.svg#plusOutlined" })
            ]);
          });
        },
        735: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusOutlined_m", xlinkHref: "/icons/sprite.svg#plusOutlined_m" })
            ]);
          });
        },
        2754: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "podcasts_xxs", xlinkHref: "/icons/sprite.svg#podcasts_xxs" })
            ]);
          });
        },
        4091: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xs", xlinkHref: "/icons/sprite.svg#previous_xs" })
            ]);
          });
        },
        1427: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xxl", xlinkHref: "/icons/sprite.svg#previous_xxl" })
            ]);
          });
        },
        5251: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xxs", xlinkHref: "/icons/sprite.svg#previous_xxs" })
            ]);
          });
        },
        895: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_one_xs", xlinkHref: "/icons/sprite.svg#repeat_one_xs" })
            ]);
          });
        },
        5632: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_one_xxs", xlinkHref: "/icons/sprite.svg#repeat_one_xxs" })
            ]);
          });
        },
        8090: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_xs", xlinkHref: "/icons/sprite.svg#repeat_xs" })
            ]);
          });
        },
        9370: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_xxs", xlinkHref: "/icons/sprite.svg#repeat_xxs" })
            ]);
          });
        },
        1001: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "reset_xxs", xlinkHref: "/icons/sprite.svg#reset_xxs" })
            ]);
          });
        },
        6579: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "reset_xxxs", xlinkHref: "/icons/sprite.svg#reset_xxxs" })
            ]);
          });
        },
        5910: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "rewindBackwards_xs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xs"
              })
            ]);
          });
        },
        893: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "rewindBackwards_xxs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xxs"
              })
            ]);
          });
        },
        4892: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "rewindForward_xs", xlinkHref: "/icons/sprite.svg#rewindForward_xs" })
            ]);
          });
        },
        6331: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "rewindForward_xxs", xlinkHref: "/icons/sprite.svg#rewindForward_xxs" })
            ]);
          });
        },
        2176: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_m", xlinkHref: "/icons/sprite.svg#ruble_m" })
            ]);
          });
        },
        9876: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_xxs", xlinkHref: "/icons/sprite.svg#ruble_xxs" })
            ]);
          });
        },
        3935: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_xxxs", xlinkHref: "/icons/sprite.svg#ruble_xxxs" })
            ]);
          });
        },
        7643: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_l", xlinkHref: "/icons/sprite.svg#search_l" })
            ]);
          });
        },
        8235: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_m", xlinkHref: "/icons/sprite.svg#search_m" })
            ]);
          });
        },
        8915: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_selected_m", xlinkHref: "/icons/sprite.svg#search_selected_m" })
            ]);
          });
        },
        3366: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_xs", xlinkHref: "/icons/sprite.svg#search_xs" })
            ]);
          });
        },
        7934: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_xxl", xlinkHref: "/icons/sprite.svg#search_xxl" })
            ]);
          });
        },
        5034: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "settings_xs", xlinkHref: "/icons/sprite.svg#settings_xs" })
            ]);
          });
        },
        1758: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "settings_xxs", xlinkHref: "/icons/sprite.svg#settings_xxs" })
            ]);
          });
        },
        7196: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "share_xxs", xlinkHref: "/icons/sprite.svg#share_xxs" })
            ]);
          });
        },
        5792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "shuffle_xs", xlinkHref: "/icons/sprite.svg#shuffle_xs" })
            ]);
          });
        },
        7951: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "shuffle_xxs", xlinkHref: "/icons/sprite.svg#shuffle_xxs" })
            ]);
          });
        },
        9545: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "site_xs", xlinkHref: "/icons/sprite.svg#site_xs" })
            ]);
          });
        },
        2037: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_25x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_m"
              })
            ]);
          });
        },
        3362: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_25x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_xs"
              })
            ]);
          });
        },
        9846: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_25x_l", xlinkHref: "/icons/sprite.svg#speed_1_25x_l" })
            ]);
          });
        },
        5197: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_5x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_m"
              })
            ]);
          });
        },
        1079: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_5x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_xs"
              })
            ]);
          });
        },
        6275: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_5x_l", xlinkHref: "/icons/sprite.svg#speed_1_5x_l" })
            ]);
          });
        },
        7026: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_75x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_m"
              })
            ]);
          });
        },
        8994: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_75x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_xs"
              })
            ]);
          });
        },
        3702: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_75x_l", xlinkHref: "/icons/sprite.svg#speed_1_75x_l" })
            ]);
          });
        },
        8664: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_m"
              })
            ]);
          });
        },
        51: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_xs"
              })
            ]);
          });
        },
        8550: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1x_l", xlinkHref: "/icons/sprite.svg#speed_1x_l" })
            ]);
          });
        },
        8619: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_2x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_m"
              })
            ]);
          });
        },
        5218: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_2x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_xs"
              })
            ]);
          });
        },
        857: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_2x_l", xlinkHref: "/icons/sprite.svg#speed_2x_l" })
            ]);
          });
        },
        6130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_m", xlinkHref: "/icons/sprite.svg#syncLyrics_m" })
            ]);
          });
        },
        3049: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_xs", xlinkHref: "/icons/sprite.svg#syncLyrics_xs" })
            ]);
          });
        },
        126: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_xxs", xlinkHref: "/icons/sprite.svg#syncLyrics_xxs" })
            ]);
          });
        },
        6210: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ticket_m", xlinkHref: "/icons/sprite.svg#ticket_m" })
            ]);
          });
        },
        5596: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ticket_selected_m", xlinkHref: "/icons/sprite.svg#ticket_selected_m" })
            ]);
          });
        },
        380: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "trailer_xs", xlinkHref: "/icons/sprite.svg#trailer_xs" })
            ]);
          });
        },
        3112: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "trailer_xxs", xlinkHref: "/icons/sprite.svg#trailer_xxs" })
            ]);
          });
        },
        1045: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unavailable_xl", xlinkHref: "/icons/sprite.svg#unavailable_xl" })
            ]);
          });
        },
        2834: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unavailable_xs", xlinkHref: "/icons/sprite.svg#unavailable_xs" })
            ]);
          });
        },
        8819: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unpin_xxs", xlinkHref: "/icons/sprite.svg#unpin_xxs" })
            ]);
          });
        },
        8772: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "upload_xxs", xlinkHref: "/icons/sprite.svg#upload_xxs" })
            ]);
          });
        },
        3522: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "users_xxxs", xlinkHref: "/icons/sprite.svg#users_xxxs" })
            ]);
          });
        },
        5695: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "vibe_xxs", xlinkHref: "/icons/sprite.svg#vibe_xxs" })
            ]);
          });
        },
        6174: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "volumeOff_xs", xlinkHref: "/icons/sprite.svg#volumeOff_xs" })
            ]);
          });
        },
        540: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "volume_xs", xlinkHref: "/icons/sprite.svg#volume_xs" })
            ]);
          });
        },
        6206: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "windows", xlinkHref: "/icons/sprite.svg#windows" })
            ]);
          });
        },
        7185: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "windows_xs", xlinkHref: "/icons/sprite.svg#windows_xs" })
            ]);
          });
        },
        9481: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexBooksEn", xlinkHref: "/icons/sprite.svg#yandexBooksEn" })
            ]);
          });
        },
        7364: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexBooksRu", xlinkHref: "/icons/sprite.svg#yandexBooksRu" })
            ]);
          });
        },
        8577: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPayEn", xlinkHref: "/icons/sprite.svg#yandexPayEn" })
            ]);
          });
        },
        5760: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPayRu", xlinkHref: "/icons/sprite.svg#yandexPayRu" })
            ]);
          });
        },
        5667: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPlusEn", xlinkHref: "/icons/sprite.svg#yandexPlusEn" })
            ]);
          });
        },
        2639: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPlusRu", xlinkHref: "/icons/sprite.svg#yandexPlusRu" })
            ]);
          });
        },
        9110: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.usePopoverSwipeable = t2.useReturnValue = t2.useCallbackRef = t2.useDebouncedToggle = t2.useResize = t2.useIsomorphicEffect = t2.useForceUpdateRef = t2.useElementOffsetY = t2.getElementNameByDataAttribute = t2.createIntersectionObserver = t2.useIntersectionObserver = t2.useKeyboardNavigation = t2.useScroll = t2.useForwardRef = void 0;
          var n2 = r2(245);
          Object.defineProperty(t2, "useForwardRef", {
            enumerable: true,
            get: function() {
              return n2.useForwardRef;
            }
          });
          var s2 = r2(2067);
          Object.defineProperty(t2, "useScroll", {
            enumerable: true,
            get: function() {
              return s2.useScroll;
            }
          });
          var a2 = r2(5188);
          Object.defineProperty(t2, "useKeyboardNavigation", {
            enumerable: true,
            get: function() {
              return a2.useKeyboardNavigation;
            }
          });
          var i2 = r2(5663);
          Object.defineProperty(t2, "useIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.useIntersectionObserver;
            }
          }), Object.defineProperty(t2, "createIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.createIntersectionObserver;
            }
          }), Object.defineProperty(t2, "getElementNameByDataAttribute", {
            enumerable: true,
            get: function() {
              return i2.getElementNameByDataAttribute;
            }
          });
          var o2 = r2(2101);
          Object.defineProperty(t2, "useElementOffsetY", {
            enumerable: true,
            get: function() {
              return o2.useElementOffsetY;
            }
          });
          var l2 = r2(2767);
          Object.defineProperty(t2, "useForceUpdateRef", {
            enumerable: true,
            get: function() {
              return l2.useForceUpdateRef;
            }
          });
          var c2 = r2(9019);
          Object.defineProperty(t2, "useIsomorphicEffect", {
            enumerable: true,
            get: function() {
              return c2.useIsomorphicEffect;
            }
          });
          var u2 = r2(2947);
          Object.defineProperty(t2, "useResize", {
            enumerable: true,
            get: function() {
              return u2.useResize;
            }
          });
          var f2 = r2(6699);
          Object.defineProperty(t2, "useDebouncedToggle", {
            enumerable: true,
            get: function() {
              return f2.useDebouncedToggle;
            }
          });
          var d2 = r2(8691);
          Object.defineProperty(t2, "useCallbackRef", {
            enumerable: true,
            get: function() {
              return d2.useCallbackRef;
            }
          });
          var x2 = r2(998);
          Object.defineProperty(t2, "useReturnValue", {
            enumerable: true,
            get: function() {
              return x2.useReturnValue;
            }
          });
          var p = r2(4395);
          Object.defineProperty(t2, "usePopoverSwipeable", {
            enumerable: true,
            get: function() {
              return p.usePopoverSwipeable;
            }
          });
          var _ = r2(5969);
          Object.defineProperty(t2, "useDynamicText", {
            enumerable: true,
            get: function() {
              return _.useDynamicText;
            }
          });
        },
        8691: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useCallbackRef = void 0;
          let n2 = r2(810);
          t2.useCallbackRef = function(e3) {
            let t3 = (0, n2.useRef)({
              stableFn: function() {
                for (var e4 = arguments.length, r3 = Array(e4), n3 = 0; n3 < e4; n3++) r3[n3] = arguments[n3];
                return t3.current.callback(...r3);
              },
              callback: e3
            });
            return (0, n2.useInsertionEffect)(() => {
              t3.current.callback = e3;
            }), t3.current.stableFn;
          };
        },
        1381: (e2, t2, r2) => {
          var n2;
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useComponentSwipeable = t2.SwipeablePlacement = void 0;
          let s2 = r2(4490), a2 = r2(8691);
          !(function(e3) {
            e3.TOP = "top", e3.BOTTOM = "bottom", e3.RIGHT = "right", e3.LEFT = "left";
          })(n2 || (t2.SwipeablePlacement = n2 = {}));
          let i2 = (e3) => {
            let { ref: t3, deltaY: r3, deltaX: s3, placement: a3 } = e3;
            requestAnimationFrame(() => {
              t3.current && (t3.current.style.willChange = "transform", t3.current.style.transform = a3 === n2.TOP || a3 === n2.BOTTOM ? "translateY(".concat(r3 || 0, "px)") : "translateX(".concat(s3 || 0, "px)"));
            });
          }, o2 = (e3) => {
            requestAnimationFrame(() => {
              e3.current && (e3.current.style.transition = "none", e3.current.style.willChange = "", e3.current.style.transform = "");
            });
          };
          t2.useComponentSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: l2, disableSwipe: c2, placement: u2, threshold: f2 } = e3, d2 = (0, a2.useCallbackRef)(() => {
              l2 && (o2(t3), l2());
            }), x2 = (0, a2.useCallbackRef)((e4) => {
              c2 || ((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3 } = e5;
                switch (a3) {
                  case n2.TOP:
                    r4 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.RIGHT:
                    s3 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.LEFT:
                    s3 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  default:
                    r4 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2 });
            }), p = (0, a2.useCallbackRef)((e4) => {
              !c2 && (((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3, threshold: i3 = 25 } = e5;
                if (!t4.current) return false;
                let o3 = i3 / 100 * (a3 === n2.TOP || a3 === n2.BOTTOM ? t4.current.offsetHeight : t4.current.offsetWidth);
                switch (a3) {
                  case n2.TOP:
                    return r4 < 0 && Math.abs(r4) >= o3;
                  case n2.RIGHT:
                    return s3 > 0 && s3 >= o3;
                  case n2.LEFT:
                    return s3 < 0 && Math.abs(s3) >= o3;
                  default:
                    return r4 > 0 && r4 >= o3;
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2, threshold: f2 }) ? l2 && (o2(t3), l2()) : o2(t3));
            });
            return {
              handlers: (0, s2.useSwipeable)({ onSwiped: p, onSwiping: x2, trackMouse: true, trackTouch: true, ...r3 }),
              onCloseCallback: d2
            };
          };
        },
        6699: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let n2 = r2(352), s2 = r2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: r3, throttleTimeout: a2 } = e3, i2 = (0, s2.useRef)(null), [o2, l2] = (0, s2.useState)(!!r3), c2 = (0, s2.useMemo)(
              () => (0, n2.throttle)(() => {
                l2(!r3), i2.current && window.clearTimeout(i2.current), i2.current = window.setTimeout(() => {
                  l2(!!r3);
                }, t3);
              }, a2),
              [t3, r3, a2]
            ), u2 = (0, s2.useCallback)(() => {
              l2(!!r3), i2.current && window.clearTimeout(i2.current);
            }, [r3]);
            return (0, s2.useEffect)(
              () => () => {
                i2.current && window.clearTimeout(i2.current);
              },
              []
            ), { state: o2, handleDebouncedToggle: c2, reset: u2 };
          };
        },
        5969: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.findOptimalFontSize = void 0;
          let n2 = r2(810), s2 = (e3) => {
            e3.style.wordBreak = "keep-all", e3.style.overflowWrap = "normal", e3.style.maxHeight = "none", e3.style.height = "auto", e3.style.overflow = "visible", Array.from(e3.children).forEach((e4) => {
              e4 instanceof HTMLElement && s2(e4);
            });
          };
          t2.findOptimalFontSize = (e3) => {
            let {
              container: t3,
              containerWidth: r3,
              containerHeight: n3,
              minFontSize: a2,
              maxFontSize: i2,
              lineHeight: o2,
              maxLines: l2
            } = e3, c2 = ((e4, t4, r4) => {
              let n4 = e4.cloneNode(true);
              return n4.style.cssText = "\n        position: absolute !important;\n        visibility: hidden !important;\n        pointer-events: none !important;\n        width: ".concat(
                t4,
                "px !important;\n    "
              ), s2(n4), n4.style.setProperty("--dynamic-line-height", String(r4)), document.body.appendChild(n4), n4;
            })(t3, r3, o2);
            try {
              let e4 = a2, t4 = i2, s3 = a2;
              for (; e4 <= t4; ) {
                let a3 = Math.floor((e4 + t4) / 2);
                c2.style.setProperty("--dynamic-font-size", "".concat(a3, "px"));
                let i3 = Math.min(l2 * a3 * o2, n3), u2 = c2.scrollHeight <= i3, f2 = c2.scrollWidth <= r3 + 1;
                u2 && f2 ? (s3 = a3, e4 = a3 + 1) : t4 = a3 - 1;
              }
              return s3 - 1;
            } finally {
              c2.remove();
            }
          }, t2.useDynamicText = (e3, r3) => {
            (0, n2.useLayoutEffect)(() => {
              if (null === e3) return;
              e3.style.setProperty("--dynamic-line-height", String(r3.lineHeight));
              let n3 = () => {
                let { width: n4, height: s4 } = e3.getBoundingClientRect(), a3 = e3.childNodes.length > 0;
                if (0 === n4 || 0 === s4 || !a3) return;
                let i2 = (0, t2.findOptimalFontSize)({ container: e3, containerWidth: n4, containerHeight: s4, ...r3 });
                e3.style.setProperty("--dynamic-font-size", "".concat(i2, "px"));
              }, s3 = new ResizeObserver(n3), a2 = new MutationObserver(n3);
              return s3.observe(e3), a2.observe(e3, { childList: true, characterData: true, subtree: true }), document.fonts.ready.then(n3), n3(), () => {
                s3.disconnect(), a2.disconnect();
              };
            }, [e3, r3]);
          };
        },
        2101: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useElementOffsetY = void 0;
          let n2 = r2(810), s2 = r2(2067), a2 = r2(2767);
          t2.useElementOffsetY = (e3) => {
            let [t3, r3] = (0, a2.useForceUpdateRef)(), [i2, o2] = (0, n2.useState)(), l2 = (0, n2.useCallback)(() => {
              let e4 = null == t3 ? void 0 : t3.getBoundingClientRect();
              e4 && o2(e4.y);
            }, [t3]);
            return (0, n2.useLayoutEffect)(l2), (0, s2.useScroll)({ onScroll: l2, elementRef: e3 }), { forceUpdateRefCallback: r3, offsetY: i2 };
          };
        },
        2767: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForceUpdateRef = void 0;
          let n2 = r2(810);
          t2.useForceUpdateRef = () => {
            let [e3, t3] = (0, n2.useState)(null);
            return [
              e3,
              (0, n2.useCallback)((e4) => {
                t3((t4) => t4 !== e4 ? e4 : t4);
              }, [])
            ];
          };
        },
        245: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForwardRef = void 0;
          let n2 = r2(810);
          t2.useForwardRef = function(e3, t3) {
            let r3 = (0, n2.useRef)(t3);
            return (0, n2.useEffect)(() => {
              e3 && ("function" == typeof e3 ? e3(r3.current) : e3.current = r3.current);
            }, [e3]), r3;
          };
        },
        5663: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIntersectionObserver = t2.createIntersectionObserver = t2.getElementNameByDataAttribute = t2.isInViewportNow = t2.defaultOptions = void 0;
          let n2 = r2(810), { innerWidth: s2 = 0, innerHeight: a2 = 0 } = window;
          function i2(e3) {
            let { top: t3, right: r3, bottom: n3, left: i3 } = e3.getBoundingClientRect();
            return (t3 >= 0 && t3 <= a2 || n3 >= 0 && n3 <= a2) && (i3 >= 0 && i3 <= s2 || r3 >= 0 && r3 <= s2);
          }
          function o2(e3) {
            var t3, r3;
            let n3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "data-intersection-property-id";
            return null != (r3 = null == e3 || null == (t3 = e3.getAttribute) ? void 0 : t3.call(e3, n3)) ? r3 : e3.attributes[0];
          }
          function l2(e3, t3) {
            let r3 = new IntersectionObserver((t4) => {
              t4.forEach((t5) => {
                e3(t5, r3);
              });
            }, t3);
            return r3;
          }
          t2.defaultOptions = { threshold: 0, preflightCheck: true }, t2.isInViewportNow = i2, t2.getElementNameByDataAttribute = o2, t2.createIntersectionObserver = l2, t2.useIntersectionObserver = function(e3, r3, s3) {
            let [{ freezeOnceVisible: a3, preflightCheck: c2, ...u2 }, f2 = false] = "boolean" == typeof r3 || void 0 === r3 ? [t2.defaultOptions, r3] : [{ ...t2.defaultOptions, ...r3 }, s3], [d2, x2] = (0, n2.useState)({}), p = (0, n2.useRef)(/* @__PURE__ */ new Set()), _ = (0, n2.useMemo)(
              () => f2 ? null : l2((e4) => {
                let t3 = o2(e4.target);
                if (t3 && _) {
                  if (p.current.has(t3)) return;
                  x2((r4) => ({ ...r4, [t3]: { isIntersecting: e4.isIntersecting } })), a3 && e4.isIntersecting && (p.current.add(t3), _.unobserve(e4.target));
                }
              }, u2),
              [f2]
            );
            return (0, n2.useLayoutEffect)(
              () => (_ && !f2 && e3.forEach((e4) => {
                if (e4.current) {
                  let t3 = false;
                  if (c2 && (t3 = i2(e4.current))) {
                    let t4 = o2(e4.current);
                    x2((e5) => ({ ...e5, [t4]: { isIntersecting: true } }));
                  }
                  t3 || _.observe(e4.current);
                }
              }), () => {
                _ && _.disconnect();
              }),
              [f2, _, e3.length]
            ), d2;
          };
        },
        9019: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIsomorphicEffect = void 0;
          let n2 = r2(810);
          t2.useIsomorphicEffect = "undefined" != typeof document ? n2.useLayoutEffect : n2.useEffect;
        },
        5188: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useKeyboardNavigation = void 0;
          let n2 = r2(810);
          function s2(e3, t3) {
            return e3.current ? Array.from(t3 ? e3.current.querySelectorAll(t3) : e3.current.children) : [];
          }
          t2.useKeyboardNavigation = function(e3) {
            let t3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, { navigationItemsSelector: r3, activeAttributeName: a2 = "aria-selected" } = t3, i2 = (0, n2.useCallback)(
              (t4) => {
                let n3 = s2(e3, r3);
                if (!n3.length) return;
                let a3 = t4.target, i3 = n3.indexOf(a3);
                if (-1 === i3) return;
                let [o2] = n3, l2 = n3.at(-1), c2 = null;
                switch (t4.key) {
                  case "ArrowLeft":
                  case "ArrowUp":
                    c2 = n3[i3 - 1] || l2;
                    break;
                  case "ArrowRight":
                  case "ArrowDown":
                    c2 = n3[i3 + 1] || o2;
                    break;
                  case "Home":
                    c2 = o2;
                    break;
                  case "End":
                    c2 = l2;
                }
                null !== c2 && (c2.focus(), t4.preventDefault());
              },
              [r3, e3]
            );
            (0, n2.useEffect)(() => {
              let t4 = e3.current;
              return null == t4 || t4.addEventListener("keydown", i2), () => null == t4 ? void 0 : t4.removeEventListener("keydown", i2);
            }, [e3, i2]), (0, n2.useEffect)(() => {
              s2(e3, r3).forEach((e4) => {
                e4.hasAttribute(a2) && ("true" === e4.getAttribute(a2) ? e4.tabIndex = 0 : e4.tabIndex = -1);
              });
            });
          };
        },
        4395: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.usePopoverSwipeable = void 0;
          let n2 = r2(810), s2 = r2(1381);
          t2.usePopoverSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: a2, disableSwipe: i2, placement: o2, threshold: l2 } = e3, c2 = (0, n2.useMemo)(() => {
              switch (o2) {
                case "top":
                case "top-end":
                case "top-start":
                  return s2.SwipeablePlacement.TOP;
                case "right":
                case "right-end":
                case "right-start":
                  return s2.SwipeablePlacement.RIGHT;
                case "left":
                case "left-end":
                case "left-start":
                  return s2.SwipeablePlacement.LEFT;
                default:
                  return s2.SwipeablePlacement.BOTTOM;
              }
            }, [o2]);
            return (0, s2.useComponentSwipeable)({
              ref: t3,
              swipeableProps: r3,
              onClose: a2,
              disableSwipe: i2,
              placement: c2,
              threshold: l2
            });
          };
        },
        2947: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useResize = void 0;
          let n2 = r2(810), s2 = r2(361);
          t2.useResize = (e3, t3) => {
            (0, n2.useEffect)(() => {
              let r3 = (0, s2.getElementFromRefOrElement)(t3);
              if (null === r3) return;
              let n3 = null != r3 ? r3 : document.documentElement, a2 = new ResizeObserver(e3);
              return a2.observe(n3), () => a2.disconnect();
            }, [t3, e3]);
          };
        },
        998: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useReturnValue = void 0, t2.useReturnValue = (e3) => e3();
        },
        2067: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useScroll = void 0;
          let n2 = r2(810), s2 = r2(361), a2 = r2(6699);
          t2.useScroll = (e3) => {
            let { onScroll: t3, listenIsScrolling: r3, elementRef: i2 } = e3, { state: o2, handleDebouncedToggle: l2 } = (0, a2.useDebouncedToggle)({
              delay: 1e3,
              throttleTimeout: 100
            }), c2 = (0, n2.useCallback)(() => {
              r3 && l2(), null == t3 || t3();
            }, [r3, l2, t3]);
            return (0, n2.useEffect)(() => {
              let e4 = (0, s2.getElementFromRefOrElement)(i2);
              if (null === e4) return;
              let t4 = null != e4 ? e4 : window, r4 = { capture: true, passive: true };
              return t4.addEventListener("scroll", c2, r4), () => t4.removeEventListener("scroll", c2, r4);
            }, [i2, c2]), o2;
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        5189: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = t2.IconComponent = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = r2(5151), l2 = n2(r2(2964));
          t2.IconComponent = (e3) => {
            let { "aria-label": t3, className: r3, focusable: n3 = false, variant: a3, size: c2, forwardRef: u2, ...f2 } = e3, d2 = c2 ? "".concat(a3, "_").concat(c2) : a3, x2 = o2.iconsCollection[d2];
            return x2 ? (0, s2.jsx)(x2, {
              className: (0, i2.clsx)(l2.default.root, r3, l2.default["root_size_".concat(c2)]),
              focusable: n3,
              "aria-label": t3,
              ...f2,
              "aria-hidden": !t3,
              ref: u2
            }) : null;
          }, t2.Icon = (0, a2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.IconComponent, { forwardRef: r3, ...e3 }));
        },
        5151: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e10) {
            return e10 && e10.__esModule ? e10 : { default: e10 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.iconsCollection = t2.iconsCollectionBySize = void 0;
          let s2 = n2(r2(4656)), a2 = n2(r2(8170)), i2 = n2(r2(5565)), o2 = n2(r2(8127)), l2 = n2(r2(8993)), c2 = n2(r2(2933)), u2 = n2(r2(1334)), f2 = n2(r2(1426)), d2 = n2(r2(5378)), x2 = n2(r2(6579)), p = n2(r2(3935)), _ = n2(r2(3522)), m = n2(r2(7319)), v = n2(r2(8442)), g = n2(r2(2586)), b = n2(r2(5822)), y = n2(r2(5272)), h = n2(r2(4860)), k = n2(r2(8711)), E = n2(r2(8109)), w = n2(r2(4904)), j = n2(r2(5971)), O = n2(r2(3331)), R = n2(r2(9783)), C = n2(r2(8184)), S = n2(r2(4926)), P = n2(r2(3176)), A = n2(r2(4789)), T = n2(r2(8151)), H = n2(r2(8690)), M = n2(r2(1524)), N = n2(r2(2361)), I = n2(r2(3972)), L = n2(r2(9330)), B = n2(r2(7346)), D = n2(r2(2604)), z = n2(r2(6894)), F = n2(r2(6391)), U = n2(r2(9369)), W = n2(r2(226)), V = n2(r2(8130)), Y = n2(r2(5270)), K = n2(r2(3560)), X = n2(r2(7513)), q = n2(r2(9838)), Q = n2(r2(9104)), G = n2(r2(7399)), Z = n2(r2(5849)), $ = n2(r2(3613)), J = n2(r2(9372)), ee = n2(r2(3709)), et = n2(r2(3685)), er = n2(r2(3302)), en = n2(r2(811)), es = n2(r2(6122)), ea = n2(r2(5386)), ei = n2(r2(3201)), eo = n2(r2(9434)), el = n2(r2(2026)), ec = n2(r2(8112)), eu = n2(r2(8044)), ef = n2(r2(2754)), ed = n2(r2(5251)), ex = n2(r2(9370)), ep = n2(r2(5632)), e_ = n2(r2(1001)), em = n2(r2(893)), ev = n2(r2(6331)), eg = n2(r2(9876)), eb = n2(r2(1758)), ey = n2(r2(7196)), eh = n2(r2(7951)), ek = n2(r2(126)), eE = n2(r2(3112)), ew = n2(r2(8819)), ej = n2(r2(8772)), eO = n2(r2(5695)), eR = n2(r2(7171)), eC = n2(r2(9030)), eS = n2(r2(9422)), eP = n2(r2(1491)), eA = n2(r2(2337)), eT = n2(r2(9202)), eH = n2(r2(130)), eM = n2(r2(7923)), eN = n2(r2(3654)), eI = n2(r2(6507)), eL = n2(r2(3193)), eB = n2(r2(30)), eD = n2(r2(7802)), ez = n2(r2(3738)), eF = n2(r2(2340)), eU = n2(r2(2125)), eW = n2(r2(4014)), eV = n2(r2(896)), eY = n2(r2(1829)), eK = n2(r2(1893)), eX = n2(r2(1563)), eq = n2(r2(1578)), eQ = n2(r2(9348)), eG = n2(r2(965)), eZ = n2(r2(3877)), e$ = n2(r2(9968)), eJ = n2(r2(3778)), e0 = n2(r2(1084)), e1 = n2(r2(4254)), e8 = n2(r2(792)), e4 = n2(r2(8131)), e5 = n2(r2(1125)), e6 = n2(r2(9288)), e7 = n2(r2(976)), e22 = n2(r2(1874)), e3 = n2(r2(9863)), e9 = n2(r2(1945)), te = n2(r2(1580)), tt = n2(r2(4091)), tr = n2(r2(8090)), tn = n2(r2(895)), ts = n2(r2(5910)), ta = n2(r2(4892)), ti = n2(r2(3366)), to = n2(r2(5034)), tl = n2(r2(5792)), tc = n2(r2(9545)), tu = n2(r2(3362)), tf = n2(r2(1079)), td = n2(r2(8994)), tx = n2(r2(51)), tp = n2(r2(5218)), t_ = n2(r2(3049)), tm = n2(r2(380)), tv = n2(r2(2834)), tg = n2(r2(540)), tb = n2(r2(6174)), ty = n2(r2(7185)), th = n2(r2(9351)), tk = n2(r2(2092)), tE = n2(r2(1162)), tw = n2(r2(6837)), tj = n2(r2(2024)), tO = n2(r2(776)), tR = n2(r2(5720)), tC = n2(r2(2774)), tS = n2(r2(4997)), tP = n2(r2(3146)), tA = n2(r2(2084)), tT = n2(r2(3751)), tH = n2(r2(3076)), tM = n2(r2(2495)), tN = n2(r2(9509)), tI = n2(r2(8987)), tL = n2(r2(190)), tB = n2(r2(843)), tD = n2(r2(5122)), tz = n2(r2(7405)), tF = n2(r2(820)), tU = n2(r2(5443)), tW = n2(r2(8782)), tV = n2(r2(7252)), tY = n2(r2(3013)), tK = n2(r2(5346)), tX = n2(r2(3792)), tq = n2(r2(1351)), tQ = n2(r2(8303)), tG = n2(r2(4777)), tZ = n2(r2(735)), t$ = n2(r2(2176)), tJ = n2(r2(8235)), t0 = n2(r2(8915)), t1 = n2(r2(2037)), t8 = n2(r2(5197)), t4 = n2(r2(7026)), t5 = n2(r2(8664)), t6 = n2(r2(8619)), t7 = n2(r2(6130)), t22 = n2(r2(6210)), t3 = n2(r2(5596)), t9 = n2(r2(6644)), re = n2(r2(996)), rt = n2(r2(7031)), rr = n2(r2(4793)), rn = n2(r2(7076)), rs = n2(r2(8582)), ra = n2(r2(7643)), ri = n2(r2(9846)), ro = n2(r2(6275)), rl = n2(r2(3702)), rc = n2(r2(8550)), ru = n2(r2(857)), rf = n2(r2(6304)), rd = n2(r2(9040)), rx = n2(r2(4298)), rp = n2(r2(5132)), r_ = n2(r2(8868)), rm = n2(r2(8779)), rv = n2(r2(8503)), rg = n2(r2(1045)), rb = n2(r2(7341)), ry = n2(r2(9505)), rh = n2(r2(4483)), rk = n2(r2(8499)), rE = n2(r2(705)), rw = n2(r2(7402)), rj = n2(r2(1427)), rO = n2(r2(7934)), rR = n2(r2(2435)), rC = n2(r2(3918)), rS = n2(r2(2571)), rP = n2(r2(2161)), rA = n2(r2(5304)), rT = n2(r2(2646)), rH = n2(r2(7500)), rM = n2(r2(6104)), rN = n2(r2(2502)), rI = n2(r2(1754)), rL = n2(r2(6615)), rB = n2(r2(7942)), rD = n2(r2(1498)), rz = n2(r2(8861)), rF = n2(r2(6809)), rU = n2(r2(5266)), rW = n2(r2(1179)), rV = n2(r2(6206)), rY = n2(r2(9481)), rK = n2(r2(7364)), rX = n2(r2(8577)), rq = n2(r2(5760)), rQ = n2(r2(5667)), rG = n2(r2(2639));
          t2.iconsCollectionBySize = {
            xxxs: [
              "adult",
              "arrowRight",
              "check",
              "close",
              "donation",
              "exclamation",
              "explicit",
              "listen",
              "play",
              "reset",
              "ruble",
              "users"
            ],
            xxs: [
              "add",
              "addToPlaylist",
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "artist",
              "bucket",
              "chain",
              "chartDown",
              "chartNew",
              "chartSame",
              "chartUp",
              "check",
              "clip",
              "close",
              "code",
              "crown",
              "dislike",
              "disliked",
              "download",
              "downloaded",
              "dragDots",
              "edit",
              "exclamation",
              "explicit",
              "eye_crossed",
              "filter",
              "info",
              "lightning",
              "like",
              "likeVariant",
              "liked",
              "likedVariant",
              "link",
              "lock",
              "lyrics",
              "macos",
              "menuArrow",
              "more",
              "next",
              "pause",
              "pencil",
              "pin",
              "pin_filled",
              "play",
              "playLast",
              "playNext",
              "podcasts",
              "previous",
              "repeat",
              "repeat_one",
              "reset",
              "rewindBackwards",
              "rewindForward",
              "ruble",
              "settings",
              "share",
              "shuffle",
              "syncLyrics",
              "trailer",
              "unpin",
              "upload",
              "vibe"
            ],
            xs: [
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "cast",
              "chain",
              "close",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "filter",
              "fullscreen",
              "like",
              "liked",
              "liteVersion",
              "lock",
              "more",
              "navigationCollection",
              "navigationConcerts",
              "navigationForYouAndTrends",
              "navigationKids",
              "navigationMyVibe",
              "navigationNonMusic",
              "navigationPlus",
              "navigationSearch",
              "next",
              "note",
              "pause",
              "pause_filled",
              "picture",
              "pin",
              "pin_filled",
              "play",
              "playQueue",
              "play_filled",
              "playlist",
              "previous",
              "repeat",
              "repeat_one",
              "rewindBackwards",
              "rewindForward",
              "search",
              "settings",
              "shuffle",
              "site",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "trailer",
              "unavailable",
              "volume",
              "volumeOff",
              "windows"
            ],
            s: [
              "adult",
              "album",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "likedVariant",
              "note",
              "pauseVibe",
              "picture",
              "playVibe",
              "playlist"
            ],
            m: [
              "collections",
              "collections_selected",
              "history",
              "home",
              "home_selected",
              "kids",
              "kids_selected",
              "like",
              "liked",
              "lock",
              "more",
              "non_music",
              "non_music_selected",
              "pause",
              "pause_filled",
              "play",
              "playQueue",
              "play_filled",
              "plusOutlined",
              "ruble",
              "search",
              "search_selected",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "ticket",
              "ticket_selected"
            ],
            l: [
              "add",
              "album",
              "download",
              "like",
              "pause_filled",
              "play_filled",
              "search",
              "speed_1_25x",
              "speed_1_5x",
              "speed_1_75x",
              "speed_1x",
              "speed_2x"
            ],
            xl: ["album", "clip", "note", "pause_filled", "picture", "play_filled", "playlist", "unavailable"],
            xxl: ["attention", "check", "next", "offline", "pause_filled", "play_filled", "previous", "search"],
            xxxl: ["attention"],
            "": [
              "bandlink",
              "booksLogo",
              "googlePlay",
              "huaweiAppGallery",
              "kinopoiskEn",
              "kinopoiskRu",
              "macos",
              "musicLogo",
              "musicLogoCenterEn",
              "musicLogoCenterRu",
              "musicLogoLeftEn",
              "musicLogoLeftRu",
              "plus",
              "plusBadge",
              "plusColor",
              "plusOutlined",
              "windows",
              "yandexBooksEn",
              "yandexBooksRu",
              "yandexPayEn",
              "yandexPayRu",
              "yandexPlusEn",
              "yandexPlusRu"
            ]
          }, t2.iconsCollection = {
            adult_xxxs: s2.default,
            arrowRight_xxxs: a2.default,
            check_xxxs: i2.default,
            close_xxxs: o2.default,
            donation_xxxs: l2.default,
            exclamation_xxxs: c2.default,
            explicit_xxxs: u2.default,
            listen_xxxs: f2.default,
            play_xxxs: d2.default,
            reset_xxxs: x2.default,
            ruble_xxxs: p.default,
            users_xxxs: _.default,
            add_xxs: m.default,
            addToPlaylist_xxs: v.default,
            adult_xxs: g.default,
            album_xxs: b.default,
            arrowDown_xxs: y.default,
            arrowLeft_xxs: h.default,
            arrowRight_xxs: k.default,
            artist_xxs: E.default,
            bucket_xxs: w.default,
            chain_xxs: j.default,
            chartDown_xxs: O.default,
            chartNew_xxs: R.default,
            chartSame_xxs: C.default,
            chartUp_xxs: S.default,
            check_xxs: P.default,
            clip_xxs: A.default,
            close_xxs: T.default,
            code_xxs: H.default,
            crown_xxs: M.default,
            dislike_xxs: N.default,
            disliked_xxs: I.default,
            download_xxs: L.default,
            downloaded_xxs: B.default,
            dragDots_xxs: D.default,
            edit_xxs: z.default,
            exclamation_xxs: F.default,
            explicit_xxs: U.default,
            eye_crossed_xxs: W.default,
            filter_xxs: V.default,
            info_xxs: Y.default,
            lightning_xxs: K.default,
            like_xxs: X.default,
            likeVariant_xxs: q.default,
            liked_xxs: Q.default,
            likedVariant_xxs: G.default,
            link_xxs: Z.default,
            lock_xxs: $.default,
            lyrics_xxs: J.default,
            macos_xxs: ee.default,
            menuArrow_xxs: et.default,
            more_xxs: er.default,
            next_xxs: en.default,
            pause_xxs: es.default,
            pencil_xxs: ea.default,
            pin_xxs: ei.default,
            pin_filled_xxs: eo.default,
            play_xxs: el.default,
            playLast_xxs: ec.default,
            playNext_xxs: eu.default,
            podcasts_xxs: ef.default,
            previous_xxs: ed.default,
            repeat_xxs: ex.default,
            repeat_one_xxs: ep.default,
            reset_xxs: e_.default,
            rewindBackwards_xxs: em.default,
            rewindForward_xxs: ev.default,
            ruble_xxs: eg.default,
            settings_xxs: eb.default,
            share_xxs: ey.default,
            shuffle_xxs: eh.default,
            syncLyrics_xxs: ek.default,
            trailer_xxs: eE.default,
            unpin_xxs: ew.default,
            upload_xxs: ej.default,
            vibe_xxs: eO.default,
            adult_xs: eR.default,
            album_xs: eC.default,
            arrowDown_xs: eS.default,
            arrowLeft_xs: eP.default,
            arrowRight_xs: eA.default,
            cast_xs: eT.default,
            chain_xs: eH.default,
            close_xs: eM.default,
            dislike_xs: eN.default,
            disliked_xs: eI.default,
            exclamation_xs: eL.default,
            explicit_xs: eB.default,
            filter_xs: eD.default,
            fullscreen_xs: ez.default,
            like_xs: eF.default,
            liked_xs: eU.default,
            liteVersion_xs: eW.default,
            lock_xs: eV.default,
            more_xs: eY.default,
            navigationCollection_xs: eK.default,
            navigationConcerts_xs: eX.default,
            navigationForYouAndTrends_xs: eq.default,
            navigationKids_xs: eQ.default,
            navigationMyVibe_xs: eG.default,
            navigationNonMusic_xs: eZ.default,
            navigationPlus_xs: e$.default,
            navigationSearch_xs: eJ.default,
            next_xs: e0.default,
            note_xs: e1.default,
            pause_xs: e8.default,
            pause_filled_xs: e4.default,
            picture_xs: e5.default,
            pin_xs: e6.default,
            pin_filled_xs: e7.default,
            play_xs: e22.default,
            playQueue_xs: e3.default,
            play_filled_xs: e9.default,
            playlist_xs: te.default,
            previous_xs: tt.default,
            repeat_xs: tr.default,
            repeat_one_xs: tn.default,
            rewindBackwards_xs: ts.default,
            rewindForward_xs: ta.default,
            search_xs: ti.default,
            settings_xs: to.default,
            shuffle_xs: tl.default,
            site_xs: tc.default,
            speed_1_25x_centered_xs: tu.default,
            speed_1_5x_centered_xs: tf.default,
            speed_1_75x_centered_xs: td.default,
            speed_1x_centered_xs: tx.default,
            speed_2x_centered_xs: tp.default,
            syncLyrics_xs: t_.default,
            trailer_xs: tm.default,
            unavailable_xs: tv.default,
            volume_xs: tg.default,
            volumeOff_xs: tb.default,
            windows_xs: ty.default,
            adult_s: th.default,
            album_s: tk.default,
            dislike_s: tE.default,
            disliked_s: tw.default,
            exclamation_s: tj.default,
            explicit_s: tO.default,
            likedVariant_s: tR.default,
            note_s: tC.default,
            pauseVibe_s: tS.default,
            picture_s: tP.default,
            playVibe_s: tA.default,
            playlist_s: tT.default,
            collections_m: tH.default,
            collections_selected_m: tM.default,
            history_m: tN.default,
            home_m: tI.default,
            home_selected_m: tL.default,
            kids_m: tB.default,
            kids_selected_m: tD.default,
            like_m: tz.default,
            liked_m: tF.default,
            lock_m: tU.default,
            more_m: tW.default,
            non_music_m: tV.default,
            non_music_selected_m: tY.default,
            pause_m: tK.default,
            pause_filled_m: tX.default,
            play_m: tq.default,
            playQueue_m: tQ.default,
            play_filled_m: tG.default,
            plusOutlined_m: tZ.default,
            ruble_m: t$.default,
            search_m: tJ.default,
            search_selected_m: t0.default,
            speed_1_25x_centered_m: t1.default,
            speed_1_5x_centered_m: t8.default,
            speed_1_75x_centered_m: t4.default,
            speed_1x_centered_m: t5.default,
            speed_2x_centered_m: t6.default,
            syncLyrics_m: t7.default,
            ticket_m: t22.default,
            ticket_selected_m: t3.default,
            add_l: t9.default,
            album_l: re.default,
            download_l: rt.default,
            like_l: rr.default,
            pause_filled_l: rn.default,
            play_filled_l: rs.default,
            search_l: ra.default,
            speed_1_25x_l: ri.default,
            speed_1_5x_l: ro.default,
            speed_1_75x_l: rl.default,
            speed_1x_l: rc.default,
            speed_2x_l: ru.default,
            album_xl: rf.default,
            clip_xl: rd.default,
            note_xl: rx.default,
            pause_filled_xl: rp.default,
            picture_xl: r_.default,
            play_filled_xl: rm.default,
            playlist_xl: rv.default,
            unavailable_xl: rg.default,
            attention_xxl: rb.default,
            check_xxl: ry.default,
            next_xxl: rh.default,
            offline_xxl: rk.default,
            pause_filled_xxl: rE.default,
            play_filled_xxl: rw.default,
            previous_xxl: rj.default,
            search_xxl: rO.default,
            attention_xxxl: rR.default,
            bandlink: rC.default,
            booksLogo: rS.default,
            googlePlay: rP.default,
            huaweiAppGallery: rA.default,
            kinopoiskEn: rT.default,
            kinopoiskRu: rH.default,
            macos: rM.default,
            musicLogo: rN.default,
            musicLogoCenterEn: rI.default,
            musicLogoCenterRu: rL.default,
            musicLogoLeftEn: rB.default,
            musicLogoLeftRu: rD.default,
            plus: rz.default,
            plusBadge: rF.default,
            plusColor: rU.default,
            plusOutlined: rW.default,
            windows: rV.default,
            yandexBooksEn: rY.default,
            yandexBooksRu: rK.default,
            yandexPayEn: rX.default,
            yandexPayRu: rq.default,
            yandexPlusEn: rQ.default,
            yandexPlusRu: rG.default
          };
        },
        7066: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = void 0;
          var n2 = r2(5189);
          Object.defineProperty(t2, "Icon", {
            enumerable: true,
            get: function() {
              return n2.Icon;
            }
          });
        },
        1434: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.FallbackImage = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(7066), l2 = n2(r2(1652)), c2 = (e3) => {
            let { forwardRef: t3, className: r3, iconVariant: n3 = "note", iconSize: i3 = "xl", ...c3 } = e3;
            return (0, s2.jsx)("div", {
              className: (0, a2.clsx)(l2.default.fallback, r3),
              ref: t3,
              ...c3,
              children: (0, s2.jsx)(o2.Icon, { variant: n3, size: i3, className: l2.default.fallbackIcon })
            });
          };
          t2.FallbackImage = (0, i2.forwardRef)((e3, t3) => (0, s2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        3571: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Image = t2.ImageComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(2660), l2 = r2(9110), c2 = r2(1434), u2 = r2(2008), f2 = n2(r2(1652));
          t2.ImageComponent = (e3) => {
            let {
              forwardRef: t3,
              className: r3,
              size: n3 = o2.AVATAR_DEFAULT_SIZE,
              withAvatarReplace: d2,
              fit: x2,
              fallbackIconVariant: p,
              withAspectRatio: _ = false,
              withFallback: m = true,
              withLoadingIndicator: v,
              fallbackIconSize: g,
              alt: b = "",
              src: y,
              srcSet: h,
              withSrcSet: k = true,
              createUrlReplacer: E = o2.createAvatarUrl,
              loading: w = "eager",
              onLoadBySrc: j,
              ...O
            } = e3, R = (0, l2.useForwardRef)(t3, null), [C, S] = (0, u2.useImageLoading)(R, v), [P, A] = (0, i2.useState)(false), [T, H] = (0, i2.useState)(!y), M = y, N = h;
            if (y && y.startsWith("blob:")) M = y, N = "".concat(M, ", ").concat(M, " 2x");
            else if (d2 && y) {
              let e4 = "orig" === n3 ? n3 : 2 * n3;
              M = E(y, n3, _), N = "".concat(M, ", ").concat(E(y, e4, _), " 2x");
            }
            k || (N = void 0);
            let I = (0, l2.useCallbackRef)(() => {
              null == j || j(y), S();
            });
            (0, i2.useEffect)(() => {
              R.current && P && M && (R.current.src = M);
            }, [y, P, M, R]), (0, i2.useEffect)(() => {
              A(true);
            }, []), (0, i2.useEffect)(() => {
              H(false);
            }, [y]);
            let L = (0, i2.useCallback)(() => {
              H(true);
            }, []);
            return T || !y ? m ? (0, s2.jsx)(c2.FallbackImage, { className: r3, iconSize: g, iconVariant: p, ref: R }) : null : (0, s2.jsx)("img", {
              ref: R,
              className: (0, a2.clsx)(
                f2.default.root,
                f2.default["root_fit_".concat(x2)],
                { [f2.default.loading]: C, [f2.default.root_withContainPaint]: v },
                r3
              ),
              src: M,
              srcSet: N,
              onError: L,
              onLoad: I,
              alt: b,
              loading: w,
              ...O
            });
          }, t2.Image = (0, i2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.ImageComponent, { forwardRef: r3, ...e3 }));
        },
        2008: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useImageLoading = void 0;
          var n2 = r2(3124);
          Object.defineProperty(t2, "useImageLoading", {
            enumerable: true,
            get: function() {
              return n2.useImageLoading;
            }
          });
        },
        3124: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useImageLoading = void 0;
          let n2 = r2(810), s2 = r2(9110);
          t2.useImageLoading = function(e3) {
            let t3 = !(arguments.length > 1) || void 0 === arguments[1] || arguments[1], [r3, a2] = (0, n2.useState)(t3), i2 = (0, s2.useCallbackRef)(() => {
              a2(false);
            });
            return (0, n2.useLayoutEffect)(() => {
              var t4;
              (null == (t4 = e3.current) ? void 0 : t4.complete) && a2(false);
            }, [e3, a2]), [r3, i2];
          };
        },
        2660: (e2) => {
          e2.exports = s;
        },
        352: (e2) => {
          e2.exports = a;
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(i, 2));
        }
      }, l = {};
      function c(e2) {
        var t2 = l[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = l[e2] = { exports: {} };
        return o[e2].call(r2.exports, r2, r2.exports, c), r2.exports;
      }
      c.d = (e2, t2) => {
        for (var r2 in t2) c.o(t2, r2) && !c.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, c.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), c.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var u = {};
      (() => {
        Object.defineProperty(u, "X$", { value: true }), u.vL = u.Ee = void 0;
        var e2 = c(3571);
        Object.defineProperty(u, "Ee", {
          enumerable: true,
          get: function() {
            return e2.Image;
          }
        });
        var t2 = c(1434);
        Object.defineProperty(u, "vL", {
          enumerable: true,
          get: function() {
            return t2.FallbackImage;
          }
        });
      })();
      var f = u.vL, d = u.Ee, x = u.X$;
    },
    58376: (e, t, r) => {
      "use strict";
      r.d(t, { PlayButton: () => _ });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(43426), l = r(31500), c = r(8817), u = r(77881), f = r(5956), d = r(79500), x = r.n(d);
      let p = (0, a.PA)((e2) => {
        let {
          iconSize: t2 = "xs",
          className: r2,
          size: a2,
          variant: i2 = "default",
          isPlaying: d2 = false,
          onClick: p2,
          iconClassName: _2,
          disabled: m,
          color: v,
          buttonVariant: g = "text",
          children: b,
          radius: y = "round",
          withHover: h,
          withRipple: k = false,
          ariaDescribedBy: E,
          forwardRef: w,
          tabIndex: j,
          ariaHidden: O
        } = e2, { formatMessage: R } = (0, o.A)(), C = "".concat(d2 ? "pause" : "play").concat("filled" === i2 ? "_filled" : ""), S = d2 ? l.S7.PAUSE_BUTTON : l.S7.PLAY_BUTTON, P = R(d2 ? { id: "player-actions.pause" } : { id: "player-actions.play" }), A = (0, c.c)((e3) => {
          e3.stopPropagation(), e3.preventDefault(), null == p2 || p2(e3);
        });
        return (0, n.jsx)(u.$, {
          className: (0, s.$)(x().root, x().button, r2),
          variant: g,
          color: v,
          radius: y,
          size: a2,
          flexIcon: true,
          withRipple: k,
          "aria-label": P,
          onClick: A,
          icon: (0, n.jsx)(f.Icon, { variant: C, size: t2, className: _2 }),
          disabled: m,
          withHover: h,
          "aria-describedby": E,
          ref: w,
          tabIndex: j,
          "aria-hidden": O,
          ...(0, l.Am)(S),
          children: b
        });
      }), _ = (0, i.forwardRef)((e2, t2) => (0, n.jsx)(p, { forwardRef: t2, ...e2 }));
    },
    58681: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuTrailerItem: () => l });
      var n = r(54486), s = r(47713), a = r(31500), i = r(5956), o = r(61958);
      let l = (e2) => {
        let { onClick: t2, className: r2, disabled: l2 } = e2;
        return (0, n.jsx)(o.Dr, {
          className: r2,
          onClick: t2,
          icon: (0, n.jsx)(i.Icon, { variant: "trailer", size: "xxs" }),
          disabled: l2,
          ...(0, a.Am)(a.S7.CONTEXT_MENU_TRAILER_BUTTON),
          children: (0, n.jsx)(s.A, { id: "entity-names.trailer" })
        });
      };
    },
    60608: (e, t, r) => {
      "use strict";
      r.d(t, { NavigationControls: () => _ });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(43426), l = r(31500), c = r(8817), u = r(77881), f = r(5956), d = r(47281), x = r(70588), p = r.n(x);
      let _ = (0, a.PA)((e2) => {
        let {
          withBackwardControl: t2 = true,
          withForwardControl: r2 = true,
          shouldFocusOnMount: a2 = true,
          className: x2,
          withBackwardFallback: _2,
          buttonSize: m = "xxs"
        } = e2, { formatMessage: v } = (0, o.A)(), { canBack: g, canForward: b, moveBack: y, moveForward: h } = (0, d.J)(_2), k = (0, i.useRef)(null), E = (0, c.c)((e3) => {
          e3.stopPropagation(), y();
        }), w = (0, c.c)((e3) => {
          e3.stopPropagation(), h();
        });
        return (0, i.useEffect)(() => {
          a2 && k.current && g && k.current.focus();
        }, [g]), (0, n.jsxs)("div", {
          className: (0, s.$)(p().root, x2),
          ...(0, l.Am)(l.Kq.navigation.NAVIGATION_CONTROLS),
          children: [
            t2 && (0, n.jsx)(u.$, {
              ref: k,
              "aria-label": v({ id: "navigation.go-back" }),
              radius: "round",
              disabled: !g,
              size: m,
              icon: (0, n.jsx)(f.Icon, { size: "xxs", variant: "arrowLeft" }),
              onClick: E,
              ...(0, l.Am)(l.Kq.navigation.NAVIGATION_BACKWARD_BUTTON)
            }),
            r2 && (0, n.jsx)(u.$, {
              "aria-label": v({ id: "navigation.go-forward" }),
              radius: "round",
              disabled: !b,
              size: m,
              icon: (0, n.jsx)(f.Icon, { size: "xxs", variant: "arrowRight" }),
              onClick: w,
              ...(0, l.Am)(l.Kq.navigation.NAVIGATION_FORWARD_BUTTON)
            })
          ]
        });
      });
    },
    60673: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuPinItem: () => f });
      var n = r(54486), s = r(28303), a = r(61910), i = r(47713), o = r(31500), l = r(5956), c = r(61958), u = r(60440);
      let f = (0, s.PA)((e2) => {
        let { isPinned: t2, onClick: r2, disabled: s2, className: f2 } = e2, { user: d } = (0, u.useStore)(), x = t2 ? "unpin" : "pin", p = t2 ? o.S7.CONTEXT_MENU_UNPIN_BUTTON : o.S7.CONTEXT_MENU_PIN_BUTTON, _ = (0, a.useMemo)(
          () => t2 ? (0, n.jsx)(i.A, { id: "interface-actions.unpin" }) : (0, n.jsx)(i.A, { id: "interface-actions.pin" }),
          [t2]
        );
        return (0, n.jsx)(c.Dr, {
          className: f2,
          onClick: r2,
          icon: (0, n.jsx)(l.Icon, { variant: x, size: "xxs" }),
          ...(0, o.Am)(p),
          disabled: s2 || !d.isAuthorized,
          children: _
        });
      });
    },
    60936: (e) => {
      e.exports = { static: "CompositeHeader_static__pZdrc", static_hidden: "CompositeHeader_static_hidden__jHPYh" };
    },
    61176: (e, t, r) => {
      "use strict";
      r.d(t, { CarouselWithColumnsBlock: () => b, ColumnsCount: () => v });
      var n = r(54486), s = r(50420), a = r(44282), i = r(61910), o = r(43350), l = r(15209), c = r(31500), u = r(81203), f = r(47564), d = r(65140), x = r(52862), p = r(78684), _ = r(10196), m = r.n(_), v = (function(e2) {
        return e2.ONE = "one", e2.TWO = "two", e2;
      })({});
      let g = (e2) => {
        let {
          className: t2,
          forwardRef: r2,
          isShimmerVisible: _2,
          isColumnsShimmerVisible: v2,
          isHeaderWithoutControls: g2,
          maxColumnsCount: b2,
          carouselItemClassName: y,
          carouselClassName: h,
          children: k,
          itemsCountPerColumn: E,
          shimmer: w,
          viewAllActionLink: j,
          blockHeaderClassName: O,
          additionalControl: R,
          blockHeaderDescription: C,
          blockHeaderTitle: S,
          blockHeaderCoverUrl: P,
          withBlockHeaderDescription: A,
          withBlockHeaderCover: T,
          blockHeaderHeadingVariant: H,
          isShimmerActive: M,
          shouldResetCarouselScroll: N,
          beforeCarousel: I,
          ...L
        } = e2, { objectsCount: B } = (0, f.useAnalyticsBlock)(), [D, z] = (0, i.useState)(), F = (0, i.useId)(), U = (0, i.useRef)(null), W = "two" === b2, V = "string" == typeof j ? String(j) : void 0, Y = null != v2 ? v2 : _2, K = (0, i.useCallback)(
          (e3) => {
            let t3 = (0, a.A)(e3, E).slice(0, W ? 2 : 1);
            return 1 === t3.length ? z("one") : z("two"), t3.map(
              (e4, t4) => (0, n.jsx)(
                "div",
                { className: m().column, ...(0, c.Am)(c.S7.CAROUSEL_WITH_COLUMNS_BLOCK_COLUMN), children: e4 },
                t4
              )
            );
          },
          [E, W]
        ), X = (0, i.useMemo)(() => {
          if (Y) return K(Array.from({ length: 2 * E }, (e3, t3) => (0, i.cloneElement)(w, { key: t3 })));
          return K(k);
        }, [k, K, Y, E, w]), q = (0, i.useMemo)(
          () => g2 ? null : (0, n.jsxs)("div", {
            className: m().controlsContainer,
            children: [
              R,
              (0, n.jsx)(p.CarouselControls, {
                carouselRef: U,
                className: m().controls,
                backwardControlClassName: m().backwardControl
              })
            ]
          }),
          [R, g2]
        );
        return (0, i.useEffect)(() => {
          U.current && N && U.current.scrollTo(0, 0);
        }, [N]), (0, n.jsxs)("section", {
          ref: r2,
          className: (0, s.$)(m().root, t2),
          ...(0, l.getDataAttrFromProps)(L),
          children: [
            (0, n.jsx)(d.B, {
              objectType: o.ky.Shortcut,
              objectId: V,
              objectPosX: 0,
              objectPosY: 0,
              objectsCount: null != B ? B : 0,
              children: (0, n.jsx)(x.BlockHeader, {
                coverUrl: P,
                title: S,
                description: C,
                className: O,
                labeledForId: F,
                viewAllActionLink: j,
                controls: q,
                isShimmerVisible: _2,
                isShimmerActive: M,
                withDescription: A,
                withCover: T,
                headingVariant: H
              })
            }),
            I,
            (0, n.jsx)(u.Carousel, {
              itemClassName: (0, s.$)(m().item, m()["item_columns_".concat(Y && W ? "two" : D)], y),
              className: h,
              ref: U,
              "aria-labelledby": F,
              ...(0, c.Am)(c.S7.CAROUSEL_WITH_COLUMNS_BLOCK_CAROUSEL),
              children: X
            })
          ]
        });
      }, b = (0, i.forwardRef)((e2, t2) => (0, n.jsx)(g, { forwardRef: t2, ...e2 }));
    },
    61958: (e, t, r) => {
      "use strict";
      r.d(t, { Dr: () => d, W1: () => f });
      var n, s = r(88834), a = r(94377), i = r(61910), o = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        1920: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            contentContainer: "JjlbHZ4FaP9EAcR_1DxF",
            contentContainer_block: "iOlzvyUREgDkthkrx7Sf",
            flexIcon: "WsKeF73pWotx9W1tWdYY",
            root: "cpeagBA1_PblpJn8Xgtv",
            root_withoutBorder: "qU2apWBO1yyEK0lZ3lPO",
            root_radius_xs: "MmZbSs387gu2qrJ1lDWd",
            root_radius_s: "mlcrraysn7mW6xrBXSBF",
            root_radius_m: "dgV08FKVLZKFsucuiryn",
            root_radius_l: "S97_5dtzhpxo_amtfYRg",
            root_radius_xl: "nNBJnDHRlyLTniWosJhk",
            root_radius_xxxl: "zIMibMuH7wcqUoW7KH1B",
            root_radius_round: "uwk3hfWzB2VT7kE13SQk",
            root_size: "IlG7b1K0AD7E7AMx6F5p",
            root_size_default: "C_QGmfTz6UFX93vfPt6Z",
            root_size_xxxs: "eQt33MLDiQ6DRSuLaYEp",
            root_size_xxs: "oR11LfCBVqMbUJiAgknd",
            root_size_xs: "j1jXIVckFgZECecFzZMe",
            root_size_s: "WtFdWDF44egSVM_YiMUX",
            root_size_m: "Y2uqxoU7xa_AZ8FUCVOW",
            root_size_l: "SGYcNjvjmMsXeEVGUV2Z",
            root_icon_left: "kc5CjvU5hT9KEj0iTt3C",
            root_icon_right: "et24Jf7pT_X9Fvc7TznR",
            root_primary: "fXlFz1qMkliFUWOkHo8T",
            root_primary_default: "_eTRQi5ADZCUvUKMZqJU",
            ripple: "spMT3NcRD9Yb0ntNaNct",
            root_primary_outline: "fCUSh2B0Ye9kEvceE8zc",
            root_primary_text: "qlPp6CSQQEMVZPqtqLiQ",
            root_primary_withHover: "KZF6_4K1p_Y_GMIAxaAn",
            root_primary_withHover_default: "rWukOKAJh5Ga7JuIp62L",
            root_primary_withHover_outline: "fdwWCJKgUqml5wNqrRcN",
            root_primary_withHover_text: "IgYbZLnYjW0nMahgpkus",
            root_secondary: "_T4p_w41oaq6L4sztSdw",
            root_secondary_default: "iJVAJMgccD4vj4E4o068",
            root_secondary_outline: "pnM3iSP9keZOELI2oohr",
            root_secondary_text: "UDMYhpDjiAFT3xUx268O",
            root_secondary_withHover: "qUbrkhZIOVrvM0roV1QF",
            root_secondary_withHover_default: "nHWc2sto1C6Gm0Dpw_l0",
            root_secondary_withHover_outline: "i5WuBm5mfG0mflk_1jH_",
            root_secondary_withHover_text: "HbaqudSqu7Q3mv3zMPGr",
            root_plus: "ixLRsIJ2FvXO2k04n_QY",
            root_plus_default: "yRHwHzEGfDgRXGzYJqw2",
            root_plus_outline: "e777irPFmyQFFrURLF_U",
            root_plus_text: "vRqDhvmt3gt8TFp45_Zw",
            root_plus_withHover: "TZif6q3I2RwBEYXwK_iA",
            root_plus_withHover_default: "k3DhvmzpnM_Fb9oFdE4q",
            root_plus_withHover_outline: "RiDWYwGIxqbrUPR699DM",
            root_plus_withHover_text: "hC_mMCzWjkTn2j9xZzGc",
            root_accent: "jqD2jMT6n7F0WKyqwMsn",
            root_accent_default: "bDp0r9MtoYECZ8ObMoCh",
            root_accent_outline: "rXNyGp8NBAw2MUjACZNj",
            root_accent_text: "hmV4ERaXWAJc4uPLZL30",
            root_accent_withHover: "uKuxXu1N4TP5cWaEK5Ke",
            root_accent_withHover_default: "t_hequUaUgAMhFuxizLb",
            root_accent_withHover_outline: "Oy9sPFTxNTo1_E29U4aF",
            root_accent_withHover_text: "LcKRSd3DLoh7k60Oqox8",
            root_withActiveSpinner: "nAGvO87rLs15SJgft6Hh",
            block: "BbCxxIjBGupN28bq2lSP",
            icon: "J9wTKytjOWG73QMoN5WP",
            icon_position_left: "elJfazUBui03YWZgHCbW",
            icon_position_right: "RBoEbyJKP5rEtLsXM1ji",
            icon_withButtonSize: "cE17_kCWJgx8kzQEkeVr",
            spinnerContainer: "STbBDGqYjUEcLuNvhu9w"
          };
        },
        4092: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "sLuudThzDxW_5ARYjgjx",
            horizontal: "xd6ji7lvp0et4nirt0TL",
            hasLabel: "abbPp8VtL2D_PdW0Q_Wc",
            vertical: "sMz62rSqViFDkXAMfGeO"
          };
        },
        2964: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_size_xxxs: "Rkdd2vKC_3xa1eUdRdHP",
            root_size_xxs: "l3tE1hAMmBj2aoPPwU08",
            root_size_xs: "UwnL5AJBMMAp6NwMDdZk",
            root_size_s: "DzJFnuf7XgdkFh28JAsM",
            root_size_m: "o_v2ds2BaqtzAsRuCVjw",
            root_size_l: "YjRa1ZjM_lXFlrfS7jcu",
            root_size_xl: "Seq0GowcqQmiA9LdLP_g",
            root_size_xxl: "mfy69_BvBIamD0e22rCQ",
            root_size_xxxl: "JY1OniQewgW9iHgfllZS"
          };
        },
        5059: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            menu: "s7_MO4NdsYs7nPQALD8W",
            menu_mobile: "sosP6mIvWewsOZVT21Px",
            content: "ggP7WX2_erziDHFOo32s",
            overlay: "NOqNiasunvfLvvi75zl9",
            popoverContentMobile: "tvGooYX6bNVNK3J_JoS6"
          };
        },
        5335: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { button: "HGpuwJDpKFwHQqUJON3Q", icon: "eC27fYltxpLry7SDJxTp" };
        },
        4455: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            textContainer: "JPAmBFrOXX4d4bx9EKfb",
            divider: "z5CsOAxKVqLcSHE9VOQr",
            title: "KBeCai7nnFqNjlSGuZaa",
            description: "qwZedCqgtvYBSq9614MB",
            header: "gbDaIjMMVhQbYCLQ9ayQ",
            closeButton: "tL83zSeRGU8yQ6oMLh0i",
            closeButtonIcon: "gSTzuA90nlY4DzKXFOow"
          };
        },
        3309: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            icon: "vqAVPWFJlhAOleK_SLk4",
            rootIcon: "wy8tgXoSb23KtiD3EFWg",
            menuItem: "EiyUV4aCJzpfNzuihfMM",
            subMenu: "yEz9swZp79y4eG7Rj2Gv",
            rootMenu: "zmtVwO34EPppZErNrlIC",
            rootMenu_onlyIcon: "UOiSiy5boMAzphK1PFFN",
            root: "igzh4MWOlw4hplWZS2Hf",
            root_disabled: "r4YN7pH6cpei7HCbmlLw",
            subMenuArrow: "KNLFZ4Jd_xKFInxHox4i",
            subMenuArrow_disabled: "OGnSe5iu8hhq0gzV01m3"
          };
        },
        6176: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "PGTLp3PHEMzX9vkA7vMr" };
        },
        7820: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { overlay: "ZSjQrniulol6xKOq2Bou" };
        },
        4123: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "TYgwct6DZLAMvvFaBZ7z" };
        },
        5909: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "dJZf0Flxzx7PR15g7zqM" };
        },
        3641: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_controls_xxs: "tRaaBpDMg9Qu8v6gKjtn",
            root_entity_xxs: "M9zvtlcpLUVn6DKdcHhj",
            root_text_xxs: "ln0PYYwDmFnfYxCDJsFU",
            root_controls_xs: "n5AeWEsJC3_AYXcbK4Lt",
            root_entity_xs: "__hrMKGmNbw54T54IUyh",
            root_text_xs: "SehSa7OyRpC2nzYTVb2Q",
            root_controls_s: "_oBLf5gprWsKjCw4Ce58",
            root_entity_s: "mxSPe5xpZnie9gpIqacd",
            root_text_s: "Ai2iRN9elHpk_u5splD6",
            root_controls_m: "tk7ahHRDYXJMMB879KUA",
            root_entity_m: "Z_WIr2W8JU4MPQek3hgR",
            root_text_m: "g3qWNP6xl__7qxNmtrvd",
            root_controls_l: "grvxapJE3vGArOKDWf6n",
            root_entity_l: "Esj5A1UeSi4xV4tZ839D",
            root_text_l: "V3WU123oO65AxsprotU9",
            root_weight_normal: "ZYV27jeWd30QDXu4GhaH",
            root_weight_medium: "_3_Mxw7Si7j2g4kWjlpR",
            root_weight_bold: "Vi7Rd0SZWqD17F0872TB"
          };
        },
        5153: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_size_xs: "qJJ288377iHlWN_RXeEE",
            root_size_s: "_sd8Q9d_Ttn0Ufe4ISWS",
            root_size_m: "Ctk8dbecq31Qh7isOJPQ",
            root_size_l: "M_Djh6ppIkCO3A2k_BTA",
            root_size_xl: "dtxlzGQMPAbM2MEndXWX",
            root_size_xxl: "IUb9XLplTAoZqne9rNUL",
            root_size_xxxl: "ZYZamUwql_rfFR4RpI2B",
            root_size_xxxxl: "ZBZyxow5njdq8z5dnRPY",
            root_size_xxxxxl: "WdvQQNwdDNCdRSwRkAtT",
            root_weight_bold: "nSU6fV9y80WrZEfafvww",
            root_weight_black: "KBeGPPK4DinQzAP41Y_N"
          };
        },
        5818: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "_MWOVuZRvUQdXKTMcOPx",
            root_clamp: "LezmJlldtbHWqU7l1950",
            root_clamp_oneline: "oyQL2RSmoNbNQf3Vc6YI",
            root_clamp_multiline: "jMyoZB5J9iZbzJmWOrF0"
          };
        },
        6544: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { RemoveScroll: () => Y });
          var n2, s2, a2 = function() {
            return (a2 = Object.assign || function(e3) {
              for (var t3, r3 = 1, n3 = arguments.length; r3 < n3; r3++)
                for (var s3 in t3 = arguments[r3]) Object.prototype.hasOwnProperty.call(t3, s3) && (e3[s3] = t3[s3]);
              return e3;
            }).apply(this, arguments);
          };
          function i2(e3, t3) {
            var r3 = {};
            for (var n3 in e3) Object.prototype.hasOwnProperty.call(e3, n3) && 0 > t3.indexOf(n3) && (r3[n3] = e3[n3]);
            if (null != e3 && "function" == typeof Object.getOwnPropertySymbols)
              for (var s3 = 0, n3 = Object.getOwnPropertySymbols(e3); s3 < n3.length; s3++)
                0 > t3.indexOf(n3[s3]) && Object.prototype.propertyIsEnumerable.call(e3, n3[s3]) && (r3[n3[s3]] = e3[n3[s3]]);
            return r3;
          }
          Object.create;
          Object.create;
          var o2 = ("function" == typeof SuppressedError && SuppressedError, r2(810)), l2 = "right-scroll-bar-position", c2 = "width-before-scroll-bar";
          function u2(e3, t3) {
            return "function" == typeof e3 ? e3(t3) : e3 && (e3.current = t3), e3;
          }
          var f2 = o2.useLayoutEffect, d2 = /* @__PURE__ */ new WeakMap();
          function x(e3) {
            return e3;
          }
          var p = (function(e3) {
            void 0 === e3 && (e3 = {});
            var t3, r3, n3, s3 = (void 0 === t3 && (t3 = x), r3 = [], n3 = false, {
              read: function() {
                if (n3)
                  throw Error(
                    "Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`."
                  );
                return r3.length ? r3[r3.length - 1] : null;
              },
              useMedium: function(e4) {
                var s4 = t3(e4, n3);
                return r3.push(s4), function() {
                  r3 = r3.filter(function(e5) {
                    return e5 !== s4;
                  });
                };
              },
              assignSyncMedium: function(e4) {
                for (n3 = true; r3.length; ) {
                  var t4 = r3;
                  r3 = [], t4.forEach(e4);
                }
                r3 = {
                  push: function(t5) {
                    return e4(t5);
                  },
                  filter: function() {
                    return r3;
                  }
                };
              },
              assignMedium: function(e4) {
                n3 = true;
                var t4 = [];
                if (r3.length) {
                  var s4 = r3;
                  r3 = [], s4.forEach(e4), t4 = r3;
                }
                var a3 = function() {
                  var r4 = t4;
                  t4 = [], r4.forEach(e4);
                }, i3 = function() {
                  return Promise.resolve().then(a3);
                };
                i3(), r3 = {
                  push: function(e5) {
                    t4.push(e5), i3();
                  },
                  filter: function(e5) {
                    return t4 = t4.filter(e5), r3;
                  }
                };
              }
            });
            return s3.options = a2({ async: true, ssr: false }, e3), s3;
          })(), _ = function() {
          }, m = o2.forwardRef(function(e3, t3) {
            var r3, n3, s3, l3, c3 = o2.useRef(null), x2 = o2.useState({ onScrollCapture: _, onWheelCapture: _, onTouchMoveCapture: _ }), m2 = x2[0], v2 = x2[1], g2 = e3.forwardProps, b2 = e3.children, y2 = e3.className, h2 = e3.removeScrollBar, k2 = e3.enabled, E2 = e3.shards, w2 = e3.sideCar, j2 = e3.noIsolation, O2 = e3.inert, R2 = e3.allowPinchZoom, C2 = e3.as, S2 = e3.gapMode, P2 = i2(e3, [
              "forwardProps",
              "children",
              "className",
              "removeScrollBar",
              "enabled",
              "shards",
              "sideCar",
              "noIsolation",
              "inert",
              "allowPinchZoom",
              "as",
              "gapMode"
            ]), A2 = (r3 = [c3, t3], n3 = function(e4) {
              return r3.forEach(function(t4) {
                return u2(t4, e4);
              });
            }, (s3 = (0, o2.useState)(function() {
              return {
                value: null,
                callback: n3,
                facade: {
                  get current() {
                    return s3.value;
                  },
                  set current(value) {
                    var e4 = s3.value;
                    e4 !== value && (s3.value = value, s3.callback(value, e4));
                  }
                }
              };
            })[0]).callback = n3, l3 = s3.facade, f2(
              function() {
                var e4 = d2.get(l3);
                if (e4) {
                  var t4 = new Set(e4), n4 = new Set(r3), s4 = l3.current;
                  t4.forEach(function(e5) {
                    n4.has(e5) || u2(e5, null);
                  }), n4.forEach(function(e5) {
                    t4.has(e5) || u2(e5, s4);
                  });
                }
                d2.set(l3, r3);
              },
              [r3]
            ), l3), T2 = a2(a2({}, P2), m2);
            return o2.createElement(
              o2.Fragment,
              null,
              k2 && o2.createElement(w2, {
                sideCar: p,
                removeScrollBar: h2,
                shards: E2,
                noIsolation: j2,
                inert: O2,
                setCallbacks: v2,
                allowPinchZoom: !!R2,
                lockRef: c3,
                gapMode: S2
              }),
              g2 ? o2.cloneElement(o2.Children.only(b2), a2(a2({}, T2), { ref: A2 })) : o2.createElement(void 0 === C2 ? "div" : C2, a2({}, T2, { className: y2, ref: A2 }), b2)
            );
          });
          m.defaultProps = { enabled: true, removeScrollBar: true, inert: false }, m.classNames = { fullWidth: c2, zeroRight: l2 };
          var v = function(e3) {
            var t3 = e3.sideCar, r3 = i2(e3, ["sideCar"]);
            if (!t3) throw Error("Sidecar: please provide `sideCar` property to import the right car");
            var n3 = t3.read();
            if (!n3) throw Error("Sidecar medium not found");
            return o2.createElement(n3, a2({}, r3));
          };
          v.isSideCarExport = true;
          var g = function() {
            var e3 = 0, t3 = null;
            return {
              add: function(n3) {
                if (0 == e3 && (t3 = (function() {
                  if (!document) return null;
                  var e4 = document.createElement("style");
                  e4.type = "text/css";
                  var t4 = s2 || r2.nc;
                  return t4 && e4.setAttribute("nonce", t4), e4;
                })())) {
                  var a3, i3;
                  (a3 = t3).styleSheet ? a3.styleSheet.cssText = n3 : a3.appendChild(document.createTextNode(n3)), i3 = t3, (document.head || document.getElementsByTagName("head")[0]).appendChild(i3);
                }
                e3++;
              },
              remove: function() {
                --e3 || !t3 || (t3.parentNode && t3.parentNode.removeChild(t3), t3 = null);
              }
            };
          }, b = function() {
            var e3 = g();
            return function(t3, r3) {
              o2.useEffect(
                function() {
                  return e3.add(t3), function() {
                    e3.remove();
                  };
                },
                [t3 && r3]
              );
            };
          }, y = function() {
            var e3 = b();
            return function(t3) {
              return e3(t3.styles, t3.dynamic), null;
            };
          }, h = function(e3) {
            return parseInt(e3 || "", 10) || 0;
          }, k = function(e3) {
            var t3 = window.getComputedStyle(document.body), r3 = t3["padding" === e3 ? "paddingLeft" : "marginLeft"], n3 = t3["padding" === e3 ? "paddingTop" : "marginTop"], s3 = t3["padding" === e3 ? "paddingRight" : "marginRight"];
            return [h(r3), h(n3), h(s3)];
          }, E = function(e3) {
            void 0 === e3 && (e3 = "margin");
            var t3 = k(e3), r3 = document.documentElement.clientWidth, n3 = window.innerWidth;
            return { left: t3[0], top: t3[1], right: t3[2], gap: Math.max(0, n3 - r3 + t3[2] - t3[0]) };
          }, w = y(), j = "data-scroll-locked", O = function(e3, t3, r3, n3) {
            var s3 = e3.left, a3 = e3.top, i3 = e3.right, o3 = e3.gap;
            return void 0 === r3 && (r3 = "margin"), "\n  .".concat("with-scroll-bars-hidden", " {\n   overflow: hidden ").concat(n3, ";\n   padding-right: ").concat(o3, "px ").concat(n3, ";\n  }\n  body[").concat(j, "] {\n    overflow: hidden ").concat(n3, ";\n    overscroll-behavior: contain;\n    ").concat(
              [
                t3 && "position: relative ".concat(n3, ";"),
                "margin" === r3 && "\n    padding-left: ".concat(s3, "px;\n    padding-top: ").concat(a3, "px;\n    padding-right: ").concat(i3, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(o3, "px ").concat(n3, ";\n    "),
                "padding" === r3 && "padding-right: ".concat(o3, "px ").concat(n3, ";")
              ].filter(Boolean).join(""),
              "\n  }\n  \n  ."
            ).concat(l2, " {\n    right: ").concat(o3, "px ").concat(n3, ";\n  }\n  \n  .").concat(c2, " {\n    margin-right: ").concat(o3, "px ").concat(n3, ";\n  }\n  \n  .").concat(l2, " .").concat(l2, " {\n    right: 0 ").concat(n3, ";\n  }\n  \n  .").concat(c2, " .").concat(c2, " {\n    margin-right: 0 ").concat(n3, ";\n  }\n  \n  body[").concat(j, "] {\n    ").concat("--removed-body-scroll-bar-size", ": ").concat(o3, "px;\n  }\n");
          }, R = function() {
            var e3 = parseInt(document.body.getAttribute(j) || "0", 10);
            return isFinite(e3) ? e3 : 0;
          }, C = function() {
            o2.useEffect(function() {
              return document.body.setAttribute(j, (R() + 1).toString()), function() {
                var e3 = R() - 1;
                e3 <= 0 ? document.body.removeAttribute(j) : document.body.setAttribute(j, e3.toString());
              };
            }, []);
          }, S = function(e3) {
            var t3 = e3.noRelative, r3 = e3.noImportant, n3 = e3.gapMode, s3 = void 0 === n3 ? "margin" : n3;
            C();
            var a3 = o2.useMemo(
              function() {
                return E(s3);
              },
              [s3]
            );
            return o2.createElement(w, { styles: O(a3, !t3, s3, r3 ? "" : "!important") });
          }, P = false;
          try {
            var A = Object.defineProperty({}, "passive", {
              get: function() {
                return P = true, true;
              }
            });
            window.addEventListener("test", A, A), window.removeEventListener("test", A, A);
          } catch (e3) {
            P = false;
          }
          var T = !!P && { passive: false }, H = function(e3, t3) {
            if (!(e3 instanceof Element)) return false;
            var r3 = window.getComputedStyle(e3);
            return "hidden" !== r3[t3] && (r3.overflowY !== r3.overflowX || "TEXTAREA" === e3.tagName || "visible" !== r3[t3]);
          }, M = function(e3, t3) {
            var r3 = t3.ownerDocument, n3 = t3;
            do {
              if ("undefined" != typeof ShadowRoot && n3 instanceof ShadowRoot && (n3 = n3.host), N(e3, n3)) {
                var s3 = I(e3, n3);
                if (s3[1] > s3[2]) return true;
              }
              n3 = n3.parentNode;
            } while (n3 && n3 !== r3.body);
            return false;
          }, N = function(e3, t3) {
            return "v" === e3 ? H(t3, "overflowY") : H(t3, "overflowX");
          }, I = function(e3, t3) {
            return "v" === e3 ? [t3.scrollTop, t3.scrollHeight, t3.clientHeight] : [t3.scrollLeft, t3.scrollWidth, t3.clientWidth];
          }, L = function(e3, t3, r3, n3, s3) {
            var a3, i3 = (a3 = window.getComputedStyle(t3).direction, "h" === e3 && "rtl" === a3 ? -1 : 1), o3 = i3 * n3, l3 = r3.target, c3 = t3.contains(l3), u3 = false, f3 = o3 > 0, d3 = 0, x2 = 0;
            do {
              var p2 = I(e3, l3), _2 = p2[0], m2 = p2[1] - p2[2] - i3 * _2;
              (_2 || m2) && N(e3, l3) && (d3 += m2, x2 += _2), l3 = l3 instanceof ShadowRoot ? l3.host : l3.parentNode;
            } while (!c3 && l3 !== document.body || c3 && (t3.contains(l3) || t3 === l3));
            return f3 && (s3 && 1 > Math.abs(d3) || !s3 && o3 > d3) ? u3 = true : !f3 && (s3 && 1 > Math.abs(x2) || !s3 && -o3 > x2) && (u3 = true), u3;
          }, B = function(e3) {
            return "changedTouches" in e3 ? [e3.changedTouches[0].clientX, e3.changedTouches[0].clientY] : [0, 0];
          }, D = function(e3) {
            return [e3.deltaX, e3.deltaY];
          }, z = function(e3) {
            return e3 && "current" in e3 ? e3.current : e3;
          }, F = 0, U = [];
          let W = (n2 = function(e3) {
            var t3 = o2.useRef([]), r3 = o2.useRef([0, 0]), n3 = o2.useRef(), s3 = o2.useState(F++)[0], a3 = o2.useState(y)[0], i3 = o2.useRef(e3);
            o2.useEffect(
              function() {
                i3.current = e3;
              },
              [e3]
            ), o2.useEffect(
              function() {
                if (e3.inert) {
                  document.body.classList.add("block-interactivity-".concat(s3));
                  var t4 = (function(e4, t5, r4) {
                    if (r4 || 2 == arguments.length)
                      for (var n4, s4 = 0, a4 = t5.length; s4 < a4; s4++)
                        !n4 && s4 in t5 || (n4 || (n4 = Array.prototype.slice.call(t5, 0, s4)), n4[s4] = t5[s4]);
                    return e4.concat(n4 || Array.prototype.slice.call(t5));
                  })([e3.lockRef.current], (e3.shards || []).map(z), true).filter(Boolean);
                  return t4.forEach(function(e4) {
                    return e4.classList.add("allow-interactivity-".concat(s3));
                  }), function() {
                    document.body.classList.remove("block-interactivity-".concat(s3)), t4.forEach(function(e4) {
                      return e4.classList.remove("allow-interactivity-".concat(s3));
                    });
                  };
                }
              },
              [e3.inert, e3.lockRef.current, e3.shards]
            );
            var l3 = o2.useCallback(function(e4, t4) {
              if ("touches" in e4 && 2 === e4.touches.length || "wheel" === e4.type && e4.ctrlKey)
                return !i3.current.allowPinchZoom;
              var s4, a4 = B(e4), o3 = r3.current, l4 = "deltaX" in e4 ? e4.deltaX : o3[0] - a4[0], c4 = "deltaY" in e4 ? e4.deltaY : o3[1] - a4[1], u4 = e4.target, f4 = Math.abs(l4) > Math.abs(c4) ? "h" : "v";
              if ("touches" in e4 && "h" === f4 && "range" === u4.type) return false;
              var d4 = M(f4, u4);
              if (!d4) return true;
              if (d4 ? s4 = f4 : (s4 = "v" === f4 ? "h" : "v", d4 = M(f4, u4)), !d4) return false;
              if (!n3.current && "changedTouches" in e4 && (l4 || c4) && (n3.current = s4), !s4) return true;
              var x3 = n3.current || s4;
              return L(x3, t4, e4, "h" === x3 ? l4 : c4, true);
            }, []), c3 = o2.useCallback(function(e4) {
              if (U.length && U[U.length - 1] === a3) {
                var r4 = "deltaY" in e4 ? D(e4) : B(e4), n4 = t3.current.filter(function(t4) {
                  var n5;
                  return t4.name === e4.type && (t4.target === e4.target || e4.target === t4.shadowParent) && (n5 = t4.delta, n5[0] === r4[0] && n5[1] === r4[1]);
                })[0];
                if (n4 && n4.should) {
                  e4.cancelable && e4.preventDefault();
                  return;
                }
                if (!n4) {
                  var s4 = (i3.current.shards || []).map(z).filter(Boolean).filter(function(t4) {
                    return t4.contains(e4.target);
                  });
                  (s4.length > 0 ? l3(e4, s4[0]) : !i3.current.noIsolation) && e4.cancelable && e4.preventDefault();
                }
              }
            }, []), u3 = o2.useCallback(function(e4, r4, n4, s4) {
              var a4 = {
                name: e4,
                delta: r4,
                target: n4,
                should: s4,
                shadowParent: (function(e5) {
                  for (var t4 = null; null !== e5; )
                    e5 instanceof ShadowRoot && (t4 = e5.host, e5 = e5.host), e5 = e5.parentNode;
                  return t4;
                })(n4)
              };
              t3.current.push(a4), setTimeout(function() {
                t3.current = t3.current.filter(function(e5) {
                  return e5 !== a4;
                });
              }, 1);
            }, []), f3 = o2.useCallback(function(e4) {
              r3.current = B(e4), n3.current = void 0;
            }, []), d3 = o2.useCallback(function(t4) {
              u3(t4.type, D(t4), t4.target, l3(t4, e3.lockRef.current));
            }, []), x2 = o2.useCallback(function(t4) {
              u3(t4.type, B(t4), t4.target, l3(t4, e3.lockRef.current));
            }, []);
            o2.useEffect(function() {
              return U.push(a3), e3.setCallbacks({ onScrollCapture: d3, onWheelCapture: d3, onTouchMoveCapture: x2 }), document.addEventListener("wheel", c3, T), document.addEventListener("touchmove", c3, T), document.addEventListener("touchstart", f3, T), function() {
                U = U.filter(function(e4) {
                  return e4 !== a3;
                }), document.removeEventListener("wheel", c3, T), document.removeEventListener("touchmove", c3, T), document.removeEventListener("touchstart", f3, T);
              };
            }, []);
            var p2 = e3.removeScrollBar, _2 = e3.inert;
            return o2.createElement(
              o2.Fragment,
              null,
              _2 ? o2.createElement(a3, {
                styles: "\n  .block-interactivity-".concat(s3, " {pointer-events: none;}\n  .allow-interactivity-").concat(s3, " {pointer-events: all;}\n")
              }) : null,
              p2 ? o2.createElement(S, { gapMode: e3.gapMode }) : null
            );
          }, p.useMedium(n2), v);
          var V = o2.forwardRef(function(e3, t3) {
            return o2.createElement(m, a2({}, e3, { ref: t3, sideCar: W }));
          });
          V.classNames = m.classNames;
          let Y = V;
        },
        4490: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { DOWN: () => o2, LEFT: () => s2, RIGHT: () => a2, UP: () => i2, useSwipeable: () => x });
          var n2 = r2(810);
          let s2 = "Left", a2 = "Right", i2 = "Up", o2 = "Down", l2 = {
            delta: 10,
            preventScrollOnSwipe: false,
            rotationAngle: 0,
            trackMouse: false,
            trackTouch: true,
            swipeDuration: 1 / 0,
            touchEventOptions: { passive: true }
          }, c2 = { first: true, initial: [0, 0], start: 0, swiping: false, xy: [0, 0] }, u2 = "mousemove", f2 = "mouseup";
          function d2(e3, t3) {
            if (0 === t3) return e3;
            let r3 = Math.PI / 180 * t3;
            return [e3[0] * Math.cos(r3) + e3[1] * Math.sin(r3), e3[1] * Math.cos(r3) - e3[0] * Math.sin(r3)];
          }
          function x(e3) {
            var t3, r3, x2;
            let p, { trackMouse: _ } = e3, m = n2.useRef(Object.assign({}, c2)), v = n2.useRef(Object.assign({}, l2)), g = n2.useRef(Object.assign({}, v.current));
            for (p in g.current = Object.assign({}, v.current), v.current = Object.assign(Object.assign({}, l2), e3), l2)
              void 0 === v.current[p] && (v.current[p] = l2[p]);
            let [b, y] = n2.useMemo(
              () => (function(e4, t4) {
                let r4 = (t5) => {
                  let r5 = "touches" in t5;
                  r5 && t5.touches.length > 1 || e4((e5, s3) => {
                    s3.trackMouse && !r5 && (document.addEventListener(u2, n3), document.addEventListener(f2, p2));
                    let { clientX: a3, clientY: i3 } = r5 ? t5.touches[0] : t5, o3 = d2([a3, i3], s3.rotationAngle);
                    return s3.onTouchStartOrOnMouseDown && s3.onTouchStartOrOnMouseDown({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), {
                      initial: o3.slice(),
                      xy: o3,
                      start: t5.timeStamp || 0
                    });
                  });
                }, n3 = (t5) => {
                  e4((e5, r5) => {
                    var n4, c3, u3, f3;
                    let x4 = "touches" in t5;
                    if (x4 && t5.touches.length > 1) return e5;
                    if (t5.timeStamp - e5.start > r5.swipeDuration)
                      return e5.swiping ? Object.assign(Object.assign({}, e5), { swiping: false }) : e5;
                    let { clientX: p3, clientY: _3 } = x4 ? t5.touches[0] : t5, [m3, v2] = d2([p3, _3], r5.rotationAngle), g2 = m3 - e5.xy[0], b2 = v2 - e5.xy[1], y2 = Math.abs(g2), h = Math.abs(b2), k = (t5.timeStamp || 0) - e5.start, E = Math.sqrt(y2 * y2 + h * h) / (k || 1), w = [g2 / (k || 1), b2 / (k || 1)], j = (n4 = y2, c3 = h, u3 = g2, f3 = b2, n4 > c3 ? u3 > 0 ? a2 : s2 : f3 > 0 ? o2 : i2), O = "number" == typeof r5.delta ? r5.delta : r5.delta[j.toLowerCase()] || l2.delta;
                    if (y2 < O && h < O && !e5.swiping) return e5;
                    let R = {
                      absX: y2,
                      absY: h,
                      deltaX: g2,
                      deltaY: b2,
                      dir: j,
                      event: t5,
                      first: e5.first,
                      initial: e5.initial,
                      velocity: E,
                      vxvy: w
                    };
                    R.first && r5.onSwipeStart && r5.onSwipeStart(R), r5.onSwiping && r5.onSwiping(R);
                    let C = false;
                    return (r5.onSwiping || r5.onSwiped || r5["onSwiped".concat(j)]) && (C = true), C && r5.preventScrollOnSwipe && r5.trackTouch && t5.cancelable && t5.preventDefault(), Object.assign(Object.assign({}, e5), { first: false, eventData: R, swiping: true });
                  });
                }, x3 = (t5) => {
                  e4((e5, r5) => {
                    let n4;
                    if (e5.swiping && e5.eventData) {
                      if (t5.timeStamp - e5.start < r5.swipeDuration) {
                        n4 = Object.assign(Object.assign({}, e5.eventData), { event: t5 }), r5.onSwiped && r5.onSwiped(n4);
                        let s3 = r5["onSwiped".concat(n4.dir)];
                        s3 && s3(n4);
                      }
                    } else r5.onTap && r5.onTap({ event: t5 });
                    return r5.onTouchEndOrOnMouseUp && r5.onTouchEndOrOnMouseUp({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), { eventData: n4 });
                  });
                }, p2 = (e5) => {
                  document.removeEventListener(u2, n3), document.removeEventListener(f2, p2), x3(e5);
                }, _2 = (e5, t5) => {
                  let s3 = () => {
                  };
                  if (e5 && e5.addEventListener) {
                    let a3 = Object.assign(Object.assign({}, l2.touchEventOptions), t5.touchEventOptions), i3 = [
                      ["touchstart", r4, a3],
                      [
                        "touchmove",
                        n3,
                        Object.assign(Object.assign({}, a3), t5.preventScrollOnSwipe ? { passive: false } : {})
                      ],
                      ["touchend", x3, a3]
                    ];
                    i3.forEach((t6) => {
                      let [r5, n4, s4] = t6;
                      return e5.addEventListener(r5, n4, s4);
                    }), s3 = () => i3.forEach((t6) => {
                      let [r5, n4] = t6;
                      return e5.removeEventListener(r5, n4);
                    });
                  }
                  return s3;
                }, m2 = {
                  ref: (t5) => {
                    null !== t5 && e4((e5, r5) => {
                      if (e5.el === t5) return e5;
                      let n4 = {};
                      return e5.el && e5.el !== t5 && e5.cleanUpTouch && (e5.cleanUpTouch(), n4.cleanUpTouch = void 0), r5.trackTouch && t5 && (n4.cleanUpTouch = _2(t5, r5)), Object.assign(Object.assign(Object.assign({}, e5), { el: t5 }), n4);
                    });
                  }
                };
                return t4.trackMouse && (m2.onMouseDown = r4), [m2, _2];
              })((e4) => m.current = e4(m.current, v.current), { trackMouse: _ }),
              [_]
            );
            return t3 = m.current, r3 = v.current, x2 = g.current, m.current = r3.trackTouch && t3.el ? t3.cleanUpTouch ? r3.preventScrollOnSwipe !== x2.preventScrollOnSwipe || r3.touchEventOptions.passive !== x2.touchEventOptions.passive ? (t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) })) : t3 : Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) }) : (t3.cleanUpTouch && t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: void 0 })), b;
          }
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        8442: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "addToPlaylist_xxs", xlinkHref: "/icons/sprite.svg#addToPlaylist_xxs" })
            ]);
          });
        },
        6644: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "add_l", xlinkHref: "/icons/sprite.svg#add_l" })
            ]);
          });
        },
        7319: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "add_xxs", xlinkHref: "/icons/sprite.svg#add_xxs" })
            ]);
          });
        },
        9351: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_s", xlinkHref: "/icons/sprite.svg#adult_s" })
            ]);
          });
        },
        7171: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xs", xlinkHref: "/icons/sprite.svg#adult_xs" })
            ]);
          });
        },
        2586: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xxs", xlinkHref: "/icons/sprite.svg#adult_xxs" })
            ]);
          });
        },
        4656: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "adult_xxxs", xlinkHref: "/icons/sprite.svg#adult_xxxs" })
            ]);
          });
        },
        996: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_l", xlinkHref: "/icons/sprite.svg#album_l" })
            ]);
          });
        },
        2092: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_s", xlinkHref: "/icons/sprite.svg#album_s" })
            ]);
          });
        },
        6304: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xl", xlinkHref: "/icons/sprite.svg#album_xl" })
            ]);
          });
        },
        9030: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xs", xlinkHref: "/icons/sprite.svg#album_xs" })
            ]);
          });
        },
        5822: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "album_xxs", xlinkHref: "/icons/sprite.svg#album_xxs" })
            ]);
          });
        },
        9422: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowDown_xs", xlinkHref: "/icons/sprite.svg#arrowDown_xs" })
            ]);
          });
        },
        5272: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowDown_xxs", xlinkHref: "/icons/sprite.svg#arrowDown_xxs" })
            ]);
          });
        },
        1491: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowLeft_xs", xlinkHref: "/icons/sprite.svg#arrowLeft_xs" })
            ]);
          });
        },
        4860: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowLeft_xxs", xlinkHref: "/icons/sprite.svg#arrowLeft_xxs" })
            ]);
          });
        },
        2337: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xs", xlinkHref: "/icons/sprite.svg#arrowRight_xs" })
            ]);
          });
        },
        8711: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxs" })
            ]);
          });
        },
        8170: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "arrowRight_xxxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxxs" })
            ]);
          });
        },
        8109: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "artist_xxs", xlinkHref: "/icons/sprite.svg#artist_xxs" })
            ]);
          });
        },
        7341: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "attention_xxl", xlinkHref: "/icons/sprite.svg#attention_xxl" })
            ]);
          });
        },
        2435: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "attention_xxxl", xlinkHref: "/icons/sprite.svg#attention_xxxl" })
            ]);
          });
        },
        3918: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "bandlink", xlinkHref: "/icons/sprite.svg#bandlink" })
            ]);
          });
        },
        2571: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "booksLogo", xlinkHref: "/icons/sprite.svg#booksLogo" })
            ]);
          });
        },
        4904: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "bucket_xxs", xlinkHref: "/icons/sprite.svg#bucket_xxs" })
            ]);
          });
        },
        9202: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "cast_xs", xlinkHref: "/icons/sprite.svg#cast_xs" })
            ]);
          });
        },
        130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chain_xs", xlinkHref: "/icons/sprite.svg#chain_xs" })
            ]);
          });
        },
        5971: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chain_xxs", xlinkHref: "/icons/sprite.svg#chain_xxs" })
            ]);
          });
        },
        3331: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartDown_xxs", xlinkHref: "/icons/sprite.svg#chartDown_xxs" })
            ]);
          });
        },
        9783: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartNew_xxs", xlinkHref: "/icons/sprite.svg#chartNew_xxs" })
            ]);
          });
        },
        8184: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartSame_xxs", xlinkHref: "/icons/sprite.svg#chartSame_xxs" })
            ]);
          });
        },
        4926: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "chartUp_xxs", xlinkHref: "/icons/sprite.svg#chartUp_xxs" })
            ]);
          });
        },
        9505: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxl", xlinkHref: "/icons/sprite.svg#check_xxl" })
            ]);
          });
        },
        3176: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxs", xlinkHref: "/icons/sprite.svg#check_xxs" })
            ]);
          });
        },
        5565: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "check_xxxs", xlinkHref: "/icons/sprite.svg#check_xxxs" })
            ]);
          });
        },
        9040: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "clip_xl", xlinkHref: "/icons/sprite.svg#clip_xl" })
            ]);
          });
        },
        4789: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "clip_xxs", xlinkHref: "/icons/sprite.svg#clip_xxs" })
            ]);
          });
        },
        7923: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xs", xlinkHref: "/icons/sprite.svg#close_xs" })
            ]);
          });
        },
        8151: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xxs", xlinkHref: "/icons/sprite.svg#close_xxs" })
            ]);
          });
        },
        8127: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "close_xxxs", xlinkHref: "/icons/sprite.svg#close_xxxs" })
            ]);
          });
        },
        8690: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "code_xxs", xlinkHref: "/icons/sprite.svg#code_xxs" })
            ]);
          });
        },
        3076: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "collections_m", xlinkHref: "/icons/sprite.svg#collections_m" })
            ]);
          });
        },
        2495: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "collections_selected_m",
                xlinkHref: "/icons/sprite.svg#collections_selected_m"
              })
            ]);
          });
        },
        1524: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "crown_xxs", xlinkHref: "/icons/sprite.svg#crown_xxs" })
            ]);
          });
        },
        1162: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_s", xlinkHref: "/icons/sprite.svg#dislike_s" })
            ]);
          });
        },
        3654: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_xs", xlinkHref: "/icons/sprite.svg#dislike_xs" })
            ]);
          });
        },
        2361: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dislike_xxs", xlinkHref: "/icons/sprite.svg#dislike_xxs" })
            ]);
          });
        },
        6837: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_s", xlinkHref: "/icons/sprite.svg#disliked_s" })
            ]);
          });
        },
        6507: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_xs", xlinkHref: "/icons/sprite.svg#disliked_xs" })
            ]);
          });
        },
        3972: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "disliked_xxs", xlinkHref: "/icons/sprite.svg#disliked_xxs" })
            ]);
          });
        },
        8993: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "donation_xxxs", xlinkHref: "/icons/sprite.svg#donation_xxxs" })
            ]);
          });
        },
        7031: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "download_l", xlinkHref: "/icons/sprite.svg#download_l" })
            ]);
          });
        },
        9330: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "download_xxs", xlinkHref: "/icons/sprite.svg#download_xxs" })
            ]);
          });
        },
        7346: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "downloaded_xxs", xlinkHref: "/icons/sprite.svg#downloaded_xxs" })
            ]);
          });
        },
        2604: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "dragDots_xxs", xlinkHref: "/icons/sprite.svg#dragDots_xxs" })
            ]);
          });
        },
        6894: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "edit_xxs", xlinkHref: "/icons/sprite.svg#edit_xxs" })
            ]);
          });
        },
        2024: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_s", xlinkHref: "/icons/sprite.svg#exclamation_s" })
            ]);
          });
        },
        3193: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xs", xlinkHref: "/icons/sprite.svg#exclamation_xs" })
            ]);
          });
        },
        6391: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xxs", xlinkHref: "/icons/sprite.svg#exclamation_xxs" })
            ]);
          });
        },
        2933: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "exclamation_xxxs", xlinkHref: "/icons/sprite.svg#exclamation_xxxs" })
            ]);
          });
        },
        776: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_s", xlinkHref: "/icons/sprite.svg#explicit_s" })
            ]);
          });
        },
        30: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xs", xlinkHref: "/icons/sprite.svg#explicit_xs" })
            ]);
          });
        },
        9369: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xxs", xlinkHref: "/icons/sprite.svg#explicit_xxs" })
            ]);
          });
        },
        1334: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "explicit_xxxs", xlinkHref: "/icons/sprite.svg#explicit_xxxs" })
            ]);
          });
        },
        226: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "eye_crossed_xxs", xlinkHref: "/icons/sprite.svg#eye_crossed_xxs" })
            ]);
          });
        },
        7802: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "filter_xs", xlinkHref: "/icons/sprite.svg#filter_xs" })
            ]);
          });
        },
        8130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "filter_xxs", xlinkHref: "/icons/sprite.svg#filter_xxs" })
            ]);
          });
        },
        3738: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "fullscreen_xs", xlinkHref: "/icons/sprite.svg#fullscreen_xs" })
            ]);
          });
        },
        2161: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "googlePlay", xlinkHref: "/icons/sprite.svg#googlePlay" })
            ]);
          });
        },
        9509: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "history_m", xlinkHref: "/icons/sprite.svg#history_m" })
            ]);
          });
        },
        8987: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "home_m", xlinkHref: "/icons/sprite.svg#home_m" })
            ]);
          });
        },
        190: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "home_selected_m", xlinkHref: "/icons/sprite.svg#home_selected_m" })
            ]);
          });
        },
        5304: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "huaweiAppGallery", xlinkHref: "/icons/sprite.svg#huaweiAppGallery" })
            ]);
          });
        },
        5270: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "info_xxs", xlinkHref: "/icons/sprite.svg#info_xxs" })
            ]);
          });
        },
        843: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kids_m", xlinkHref: "/icons/sprite.svg#kids_m" })
            ]);
          });
        },
        5122: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kids_selected_m", xlinkHref: "/icons/sprite.svg#kids_selected_m" })
            ]);
          });
        },
        2646: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kinopoiskEn", xlinkHref: "/icons/sprite.svg#kinopoiskEn" })
            ]);
          });
        },
        7500: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "kinopoiskRu", xlinkHref: "/icons/sprite.svg#kinopoiskRu" })
            ]);
          });
        },
        3560: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lightning_xxs", xlinkHref: "/icons/sprite.svg#lightning_xxs" })
            ]);
          });
        },
        9838: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likeVariant_xxs", xlinkHref: "/icons/sprite.svg#likeVariant_xxs" })
            ]);
          });
        },
        4793: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_l", xlinkHref: "/icons/sprite.svg#like_l" })
            ]);
          });
        },
        7405: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_m", xlinkHref: "/icons/sprite.svg#like_m" })
            ]);
          });
        },
        2340: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_xs", xlinkHref: "/icons/sprite.svg#like_xs" })
            ]);
          });
        },
        7513: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "like_xxs", xlinkHref: "/icons/sprite.svg#like_xxs" })
            ]);
          });
        },
        5720: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likedVariant_s", xlinkHref: "/icons/sprite.svg#likedVariant_s" })
            ]);
          });
        },
        7399: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "likedVariant_xxs", xlinkHref: "/icons/sprite.svg#likedVariant_xxs" })
            ]);
          });
        },
        820: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_m", xlinkHref: "/icons/sprite.svg#liked_m" })
            ]);
          });
        },
        2125: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_xs", xlinkHref: "/icons/sprite.svg#liked_xs" })
            ]);
          });
        },
        9104: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liked_xxs", xlinkHref: "/icons/sprite.svg#liked_xxs" })
            ]);
          });
        },
        5849: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "link_xxs", xlinkHref: "/icons/sprite.svg#link_xxs" })
            ]);
          });
        },
        1426: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "listen_xxxs", xlinkHref: "/icons/sprite.svg#listen_xxxs" })
            ]);
          });
        },
        4014: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "liteVersion_xs", xlinkHref: "/icons/sprite.svg#liteVersion_xs" })
            ]);
          });
        },
        5443: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_m", xlinkHref: "/icons/sprite.svg#lock_m" })
            ]);
          });
        },
        896: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_xs", xlinkHref: "/icons/sprite.svg#lock_xs" })
            ]);
          });
        },
        3613: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lock_xxs", xlinkHref: "/icons/sprite.svg#lock_xxs" })
            ]);
          });
        },
        9372: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "lyrics_xxs", xlinkHref: "/icons/sprite.svg#lyrics_xxs" })
            ]);
          });
        },
        6104: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "macos", xlinkHref: "/icons/sprite.svg#macos" })
            ]);
          });
        },
        3709: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "macos_xxs", xlinkHref: "/icons/sprite.svg#macos_xxs" })
            ]);
          });
        },
        3685: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "menuArrow_xxs", xlinkHref: "/icons/sprite.svg#menuArrow_xxs" })
            ]);
          });
        },
        8782: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_m", xlinkHref: "/icons/sprite.svg#more_m" })
            ]);
          });
        },
        1829: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_xs", xlinkHref: "/icons/sprite.svg#more_xs" })
            ]);
          });
        },
        3302: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "more_xxs", xlinkHref: "/icons/sprite.svg#more_xxs" })
            ]);
          });
        },
        2502: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogo", xlinkHref: "/icons/sprite.svg#musicLogo" })
            ]);
          });
        },
        1754: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoCenterEn", xlinkHref: "/icons/sprite.svg#musicLogoCenterEn" })
            ]);
          });
        },
        6615: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoCenterRu", xlinkHref: "/icons/sprite.svg#musicLogoCenterRu" })
            ]);
          });
        },
        7942: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoLeftEn", xlinkHref: "/icons/sprite.svg#musicLogoLeftEn" })
            ]);
          });
        },
        1498: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "musicLogoLeftRu", xlinkHref: "/icons/sprite.svg#musicLogoLeftRu" })
            ]);
          });
        },
        1893: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationCollection_xs",
                xlinkHref: "/icons/sprite.svg#navigationCollection_xs"
              })
            ]);
          });
        },
        1563: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationConcerts_xs",
                xlinkHref: "/icons/sprite.svg#navigationConcerts_xs"
              })
            ]);
          });
        },
        1578: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationForYouAndTrends_xs",
                xlinkHref: "/icons/sprite.svg#navigationForYouAndTrends_xs"
              })
            ]);
          });
        },
        9348: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "navigationKids_xs", xlinkHref: "/icons/sprite.svg#navigationKids_xs" })
            ]);
          });
        },
        965: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationMyVibe_xs",
                xlinkHref: "/icons/sprite.svg#navigationMyVibe_xs"
              })
            ]);
          });
        },
        3877: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationNonMusic_xs",
                xlinkHref: "/icons/sprite.svg#navigationNonMusic_xs"
              })
            ]);
          });
        },
        9968: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "navigationPlus_xs", xlinkHref: "/icons/sprite.svg#navigationPlus_xs" })
            ]);
          });
        },
        3778: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "navigationSearch_xs",
                xlinkHref: "/icons/sprite.svg#navigationSearch_xs"
              })
            ]);
          });
        },
        1084: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xs", xlinkHref: "/icons/sprite.svg#next_xs" })
            ]);
          });
        },
        4483: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xxl", xlinkHref: "/icons/sprite.svg#next_xxl" })
            ]);
          });
        },
        811: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "next_xxs", xlinkHref: "/icons/sprite.svg#next_xxs" })
            ]);
          });
        },
        7252: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "non_music_m", xlinkHref: "/icons/sprite.svg#non_music_m" })
            ]);
          });
        },
        3013: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "non_music_selected_m",
                xlinkHref: "/icons/sprite.svg#non_music_selected_m"
              })
            ]);
          });
        },
        2774: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_s", xlinkHref: "/icons/sprite.svg#note_s" })
            ]);
          });
        },
        4298: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_xl", xlinkHref: "/icons/sprite.svg#note_xl" })
            ]);
          });
        },
        4254: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "note_xs", xlinkHref: "/icons/sprite.svg#note_xs" })
            ]);
          });
        },
        8499: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "offline_xxl", xlinkHref: "/icons/sprite.svg#offline_xxl" })
            ]);
          });
        },
        4997: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pauseVibe_s", xlinkHref: "/icons/sprite.svg#pauseVibe_s" })
            ]);
          });
        },
        7076: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_l", xlinkHref: "/icons/sprite.svg#pause_filled_l" })
            ]);
          });
        },
        3792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_m", xlinkHref: "/icons/sprite.svg#pause_filled_m" })
            ]);
          });
        },
        5132: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xl", xlinkHref: "/icons/sprite.svg#pause_filled_xl" })
            ]);
          });
        },
        8131: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xs", xlinkHref: "/icons/sprite.svg#pause_filled_xs" })
            ]);
          });
        },
        705: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_filled_xxl", xlinkHref: "/icons/sprite.svg#pause_filled_xxl" })
            ]);
          });
        },
        5346: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_m", xlinkHref: "/icons/sprite.svg#pause_m" })
            ]);
          });
        },
        792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_xs", xlinkHref: "/icons/sprite.svg#pause_xs" })
            ]);
          });
        },
        6122: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pause_xxs", xlinkHref: "/icons/sprite.svg#pause_xxs" })
            ]);
          });
        },
        5386: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pencil_xxs", xlinkHref: "/icons/sprite.svg#pencil_xxs" })
            ]);
          });
        },
        3146: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_s", xlinkHref: "/icons/sprite.svg#picture_s" })
            ]);
          });
        },
        8868: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_xl", xlinkHref: "/icons/sprite.svg#picture_xl" })
            ]);
          });
        },
        1125: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "picture_xs", xlinkHref: "/icons/sprite.svg#picture_xs" })
            ]);
          });
        },
        976: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_filled_xs", xlinkHref: "/icons/sprite.svg#pin_filled_xs" })
            ]);
          });
        },
        9434: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_filled_xxs", xlinkHref: "/icons/sprite.svg#pin_filled_xxs" })
            ]);
          });
        },
        9288: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_xs", xlinkHref: "/icons/sprite.svg#pin_xs" })
            ]);
          });
        },
        3201: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "pin_xxs", xlinkHref: "/icons/sprite.svg#pin_xxs" })
            ]);
          });
        },
        8112: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playLast_xxs", xlinkHref: "/icons/sprite.svg#playLast_xxs" })
            ]);
          });
        },
        8044: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playNext_xxs", xlinkHref: "/icons/sprite.svg#playNext_xxs" })
            ]);
          });
        },
        8303: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playQueue_m", xlinkHref: "/icons/sprite.svg#playQueue_m" })
            ]);
          });
        },
        9863: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playQueue_xs", xlinkHref: "/icons/sprite.svg#playQueue_xs" })
            ]);
          });
        },
        2084: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playVibe_s", xlinkHref: "/icons/sprite.svg#playVibe_s" })
            ]);
          });
        },
        8582: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_l", xlinkHref: "/icons/sprite.svg#play_filled_l" })
            ]);
          });
        },
        4777: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_m", xlinkHref: "/icons/sprite.svg#play_filled_m" })
            ]);
          });
        },
        8779: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xl", xlinkHref: "/icons/sprite.svg#play_filled_xl" })
            ]);
          });
        },
        1945: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xs", xlinkHref: "/icons/sprite.svg#play_filled_xs" })
            ]);
          });
        },
        7402: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_filled_xxl", xlinkHref: "/icons/sprite.svg#play_filled_xxl" })
            ]);
          });
        },
        1351: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_m", xlinkHref: "/icons/sprite.svg#play_m" })
            ]);
          });
        },
        1874: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xs", xlinkHref: "/icons/sprite.svg#play_xs" })
            ]);
          });
        },
        2026: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xxs", xlinkHref: "/icons/sprite.svg#play_xxs" })
            ]);
          });
        },
        5378: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "play_xxxs", xlinkHref: "/icons/sprite.svg#play_xxxs" })
            ]);
          });
        },
        3751: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_s", xlinkHref: "/icons/sprite.svg#playlist_s" })
            ]);
          });
        },
        8503: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_xl", xlinkHref: "/icons/sprite.svg#playlist_xl" })
            ]);
          });
        },
        1580: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "playlist_xs", xlinkHref: "/icons/sprite.svg#playlist_xs" })
            ]);
          });
        },
        8861: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plus", xlinkHref: "/icons/sprite.svg#plus" })
            ]);
          });
        },
        6809: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusBadge", xlinkHref: "/icons/sprite.svg#plusBadge" })
            ]);
          });
        },
        5266: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusColor", xlinkHref: "/icons/sprite.svg#plusColor" })
            ]);
          });
        },
        1179: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusOutlined", xlinkHref: "/icons/sprite.svg#plusOutlined" })
            ]);
          });
        },
        735: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "plusOutlined_m", xlinkHref: "/icons/sprite.svg#plusOutlined_m" })
            ]);
          });
        },
        2754: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "podcasts_xxs", xlinkHref: "/icons/sprite.svg#podcasts_xxs" })
            ]);
          });
        },
        4091: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xs", xlinkHref: "/icons/sprite.svg#previous_xs" })
            ]);
          });
        },
        1427: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xxl", xlinkHref: "/icons/sprite.svg#previous_xxl" })
            ]);
          });
        },
        5251: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "previous_xxs", xlinkHref: "/icons/sprite.svg#previous_xxs" })
            ]);
          });
        },
        895: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_one_xs", xlinkHref: "/icons/sprite.svg#repeat_one_xs" })
            ]);
          });
        },
        5632: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_one_xxs", xlinkHref: "/icons/sprite.svg#repeat_one_xxs" })
            ]);
          });
        },
        8090: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_xs", xlinkHref: "/icons/sprite.svg#repeat_xs" })
            ]);
          });
        },
        9370: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "repeat_xxs", xlinkHref: "/icons/sprite.svg#repeat_xxs" })
            ]);
          });
        },
        1001: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "reset_xxs", xlinkHref: "/icons/sprite.svg#reset_xxs" })
            ]);
          });
        },
        6579: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "reset_xxxs", xlinkHref: "/icons/sprite.svg#reset_xxxs" })
            ]);
          });
        },
        5910: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "rewindBackwards_xs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xs"
              })
            ]);
          });
        },
        893: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "rewindBackwards_xxs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xxs"
              })
            ]);
          });
        },
        4892: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "rewindForward_xs", xlinkHref: "/icons/sprite.svg#rewindForward_xs" })
            ]);
          });
        },
        6331: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "rewindForward_xxs", xlinkHref: "/icons/sprite.svg#rewindForward_xxs" })
            ]);
          });
        },
        2176: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_m", xlinkHref: "/icons/sprite.svg#ruble_m" })
            ]);
          });
        },
        9876: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_xxs", xlinkHref: "/icons/sprite.svg#ruble_xxs" })
            ]);
          });
        },
        3935: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ruble_xxxs", xlinkHref: "/icons/sprite.svg#ruble_xxxs" })
            ]);
          });
        },
        7643: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_l", xlinkHref: "/icons/sprite.svg#search_l" })
            ]);
          });
        },
        8235: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_m", xlinkHref: "/icons/sprite.svg#search_m" })
            ]);
          });
        },
        8915: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_selected_m", xlinkHref: "/icons/sprite.svg#search_selected_m" })
            ]);
          });
        },
        3366: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_xs", xlinkHref: "/icons/sprite.svg#search_xs" })
            ]);
          });
        },
        7934: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "search_xxl", xlinkHref: "/icons/sprite.svg#search_xxl" })
            ]);
          });
        },
        5034: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "settings_xs", xlinkHref: "/icons/sprite.svg#settings_xs" })
            ]);
          });
        },
        1758: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "settings_xxs", xlinkHref: "/icons/sprite.svg#settings_xxs" })
            ]);
          });
        },
        7196: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "share_xxs", xlinkHref: "/icons/sprite.svg#share_xxs" })
            ]);
          });
        },
        5792: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "shuffle_xs", xlinkHref: "/icons/sprite.svg#shuffle_xs" })
            ]);
          });
        },
        7951: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "shuffle_xxs", xlinkHref: "/icons/sprite.svg#shuffle_xxs" })
            ]);
          });
        },
        9545: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "site_xs", xlinkHref: "/icons/sprite.svg#site_xs" })
            ]);
          });
        },
        2037: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_25x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_m"
              })
            ]);
          });
        },
        3362: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_25x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_xs"
              })
            ]);
          });
        },
        9846: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_25x_l", xlinkHref: "/icons/sprite.svg#speed_1_25x_l" })
            ]);
          });
        },
        5197: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_5x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_m"
              })
            ]);
          });
        },
        1079: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_5x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_xs"
              })
            ]);
          });
        },
        6275: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_5x_l", xlinkHref: "/icons/sprite.svg#speed_1_5x_l" })
            ]);
          });
        },
        7026: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_75x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_m"
              })
            ]);
          });
        },
        8994: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1_75x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_xs"
              })
            ]);
          });
        },
        3702: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1_75x_l", xlinkHref: "/icons/sprite.svg#speed_1_75x_l" })
            ]);
          });
        },
        8664: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_m"
              })
            ]);
          });
        },
        51: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_1x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_xs"
              })
            ]);
          });
        },
        8550: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_1x_l", xlinkHref: "/icons/sprite.svg#speed_1x_l" })
            ]);
          });
        },
        8619: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_2x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_m"
              })
            ]);
          });
        },
        5218: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", {
                key: "speed_2x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_xs"
              })
            ]);
          });
        },
        857: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "speed_2x_l", xlinkHref: "/icons/sprite.svg#speed_2x_l" })
            ]);
          });
        },
        6130: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_m", xlinkHref: "/icons/sprite.svg#syncLyrics_m" })
            ]);
          });
        },
        3049: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_xs", xlinkHref: "/icons/sprite.svg#syncLyrics_xs" })
            ]);
          });
        },
        126: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "syncLyrics_xxs", xlinkHref: "/icons/sprite.svg#syncLyrics_xxs" })
            ]);
          });
        },
        6210: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ticket_m", xlinkHref: "/icons/sprite.svg#ticket_m" })
            ]);
          });
        },
        5596: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "ticket_selected_m", xlinkHref: "/icons/sprite.svg#ticket_selected_m" })
            ]);
          });
        },
        380: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "trailer_xs", xlinkHref: "/icons/sprite.svg#trailer_xs" })
            ]);
          });
        },
        3112: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "trailer_xxs", xlinkHref: "/icons/sprite.svg#trailer_xxs" })
            ]);
          });
        },
        1045: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unavailable_xl", xlinkHref: "/icons/sprite.svg#unavailable_xl" })
            ]);
          });
        },
        2834: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unavailable_xs", xlinkHref: "/icons/sprite.svg#unavailable_xs" })
            ]);
          });
        },
        8819: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "unpin_xxs", xlinkHref: "/icons/sprite.svg#unpin_xxs" })
            ]);
          });
        },
        8772: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "upload_xxs", xlinkHref: "/icons/sprite.svg#upload_xxs" })
            ]);
          });
        },
        3522: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "users_xxxs", xlinkHref: "/icons/sprite.svg#users_xxxs" })
            ]);
          });
        },
        5695: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "vibe_xxs", xlinkHref: "/icons/sprite.svg#vibe_xxs" })
            ]);
          });
        },
        6174: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "volumeOff_xs", xlinkHref: "/icons/sprite.svg#volumeOff_xs" })
            ]);
          });
        },
        540: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "volume_xs", xlinkHref: "/icons/sprite.svg#volume_xs" })
            ]);
          });
        },
        6206: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "windows", xlinkHref: "/icons/sprite.svg#windows" })
            ]);
          });
        },
        7185: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "windows_xs", xlinkHref: "/icons/sprite.svg#windows_xs" })
            ]);
          });
        },
        9481: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexBooksEn", xlinkHref: "/icons/sprite.svg#yandexBooksEn" })
            ]);
          });
        },
        7364: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexBooksRu", xlinkHref: "/icons/sprite.svg#yandexBooksRu" })
            ]);
          });
        },
        8577: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPayEn", xlinkHref: "/icons/sprite.svg#yandexPayEn" })
            ]);
          });
        },
        5760: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPayRu", xlinkHref: "/icons/sprite.svg#yandexPayRu" })
            ]);
          });
        },
        5667: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPlusEn", xlinkHref: "/icons/sprite.svg#yandexPlusEn" })
            ]);
          });
        },
        2639: (e2, t2, r2) => {
          var n2 = r2(810);
          e2.exports = n2.forwardRef(function(e3, t3) {
            return n2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              n2.createElement("use", { key: "yandexPlusRu", xlinkHref: "/icons/sprite.svg#yandexPlusRu" })
            ]);
          });
        },
        9110: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.usePopoverSwipeable = t2.useReturnValue = t2.useCallbackRef = t2.useDebouncedToggle = t2.useResize = t2.useIsomorphicEffect = t2.useForceUpdateRef = t2.useElementOffsetY = t2.getElementNameByDataAttribute = t2.createIntersectionObserver = t2.useIntersectionObserver = t2.useKeyboardNavigation = t2.useScroll = t2.useForwardRef = void 0;
          var n2 = r2(245);
          Object.defineProperty(t2, "useForwardRef", {
            enumerable: true,
            get: function() {
              return n2.useForwardRef;
            }
          });
          var s2 = r2(2067);
          Object.defineProperty(t2, "useScroll", {
            enumerable: true,
            get: function() {
              return s2.useScroll;
            }
          });
          var a2 = r2(5188);
          Object.defineProperty(t2, "useKeyboardNavigation", {
            enumerable: true,
            get: function() {
              return a2.useKeyboardNavigation;
            }
          });
          var i2 = r2(5663);
          Object.defineProperty(t2, "useIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.useIntersectionObserver;
            }
          }), Object.defineProperty(t2, "createIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.createIntersectionObserver;
            }
          }), Object.defineProperty(t2, "getElementNameByDataAttribute", {
            enumerable: true,
            get: function() {
              return i2.getElementNameByDataAttribute;
            }
          });
          var o2 = r2(2101);
          Object.defineProperty(t2, "useElementOffsetY", {
            enumerable: true,
            get: function() {
              return o2.useElementOffsetY;
            }
          });
          var l2 = r2(2767);
          Object.defineProperty(t2, "useForceUpdateRef", {
            enumerable: true,
            get: function() {
              return l2.useForceUpdateRef;
            }
          });
          var c2 = r2(9019);
          Object.defineProperty(t2, "useIsomorphicEffect", {
            enumerable: true,
            get: function() {
              return c2.useIsomorphicEffect;
            }
          });
          var u2 = r2(2947);
          Object.defineProperty(t2, "useResize", {
            enumerable: true,
            get: function() {
              return u2.useResize;
            }
          });
          var f2 = r2(6699);
          Object.defineProperty(t2, "useDebouncedToggle", {
            enumerable: true,
            get: function() {
              return f2.useDebouncedToggle;
            }
          });
          var d2 = r2(8691);
          Object.defineProperty(t2, "useCallbackRef", {
            enumerable: true,
            get: function() {
              return d2.useCallbackRef;
            }
          });
          var x = r2(998);
          Object.defineProperty(t2, "useReturnValue", {
            enumerable: true,
            get: function() {
              return x.useReturnValue;
            }
          });
          var p = r2(4395);
          Object.defineProperty(t2, "usePopoverSwipeable", {
            enumerable: true,
            get: function() {
              return p.usePopoverSwipeable;
            }
          });
          var _ = r2(5969);
          Object.defineProperty(t2, "useDynamicText", {
            enumerable: true,
            get: function() {
              return _.useDynamicText;
            }
          });
        },
        8691: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useCallbackRef = void 0;
          let n2 = r2(810);
          t2.useCallbackRef = function(e3) {
            let t3 = (0, n2.useRef)({
              stableFn: function() {
                for (var e4 = arguments.length, r3 = Array(e4), n3 = 0; n3 < e4; n3++) r3[n3] = arguments[n3];
                return t3.current.callback(...r3);
              },
              callback: e3
            });
            return (0, n2.useInsertionEffect)(() => {
              t3.current.callback = e3;
            }), t3.current.stableFn;
          };
        },
        1381: (e2, t2, r2) => {
          var n2;
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useComponentSwipeable = t2.SwipeablePlacement = void 0;
          let s2 = r2(4490), a2 = r2(8691);
          !(function(e3) {
            e3.TOP = "top", e3.BOTTOM = "bottom", e3.RIGHT = "right", e3.LEFT = "left";
          })(n2 || (t2.SwipeablePlacement = n2 = {}));
          let i2 = (e3) => {
            let { ref: t3, deltaY: r3, deltaX: s3, placement: a3 } = e3;
            requestAnimationFrame(() => {
              t3.current && (t3.current.style.willChange = "transform", t3.current.style.transform = a3 === n2.TOP || a3 === n2.BOTTOM ? "translateY(".concat(r3 || 0, "px)") : "translateX(".concat(s3 || 0, "px)"));
            });
          }, o2 = (e3) => {
            requestAnimationFrame(() => {
              e3.current && (e3.current.style.transition = "none", e3.current.style.willChange = "", e3.current.style.transform = "");
            });
          };
          t2.useComponentSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: l2, disableSwipe: c2, placement: u2, threshold: f2 } = e3, d2 = (0, a2.useCallbackRef)(() => {
              l2 && (o2(t3), l2());
            }), x = (0, a2.useCallbackRef)((e4) => {
              c2 || ((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3 } = e5;
                switch (a3) {
                  case n2.TOP:
                    r4 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.RIGHT:
                    s3 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.LEFT:
                    s3 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  default:
                    r4 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2 });
            }), p = (0, a2.useCallbackRef)((e4) => {
              !c2 && (((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3, threshold: i3 = 25 } = e5;
                if (!t4.current) return false;
                let o3 = i3 / 100 * (a3 === n2.TOP || a3 === n2.BOTTOM ? t4.current.offsetHeight : t4.current.offsetWidth);
                switch (a3) {
                  case n2.TOP:
                    return r4 < 0 && Math.abs(r4) >= o3;
                  case n2.RIGHT:
                    return s3 > 0 && s3 >= o3;
                  case n2.LEFT:
                    return s3 < 0 && Math.abs(s3) >= o3;
                  default:
                    return r4 > 0 && r4 >= o3;
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2, threshold: f2 }) ? l2 && (o2(t3), l2()) : o2(t3));
            });
            return {
              handlers: (0, s2.useSwipeable)({ onSwiped: p, onSwiping: x, trackMouse: true, trackTouch: true, ...r3 }),
              onCloseCallback: d2
            };
          };
        },
        6699: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let n2 = r2(352), s2 = r2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: r3, throttleTimeout: a2 } = e3, i2 = (0, s2.useRef)(null), [o2, l2] = (0, s2.useState)(!!r3), c2 = (0, s2.useMemo)(
              () => (0, n2.throttle)(() => {
                l2(!r3), i2.current && window.clearTimeout(i2.current), i2.current = window.setTimeout(() => {
                  l2(!!r3);
                }, t3);
              }, a2),
              [t3, r3, a2]
            ), u2 = (0, s2.useCallback)(() => {
              l2(!!r3), i2.current && window.clearTimeout(i2.current);
            }, [r3]);
            return (0, s2.useEffect)(
              () => () => {
                i2.current && window.clearTimeout(i2.current);
              },
              []
            ), { state: o2, handleDebouncedToggle: c2, reset: u2 };
          };
        },
        5969: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.findOptimalFontSize = void 0;
          let n2 = r2(810), s2 = (e3) => {
            e3.style.wordBreak = "keep-all", e3.style.overflowWrap = "normal", e3.style.maxHeight = "none", e3.style.height = "auto", e3.style.overflow = "visible", Array.from(e3.children).forEach((e4) => {
              e4 instanceof HTMLElement && s2(e4);
            });
          };
          t2.findOptimalFontSize = (e3) => {
            let {
              container: t3,
              containerWidth: r3,
              containerHeight: n3,
              minFontSize: a2,
              maxFontSize: i2,
              lineHeight: o2,
              maxLines: l2
            } = e3, c2 = ((e4, t4, r4) => {
              let n4 = e4.cloneNode(true);
              return n4.style.cssText = "\n        position: absolute !important;\n        visibility: hidden !important;\n        pointer-events: none !important;\n        width: ".concat(
                t4,
                "px !important;\n    "
              ), s2(n4), n4.style.setProperty("--dynamic-line-height", String(r4)), document.body.appendChild(n4), n4;
            })(t3, r3, o2);
            try {
              let e4 = a2, t4 = i2, s3 = a2;
              for (; e4 <= t4; ) {
                let a3 = Math.floor((e4 + t4) / 2);
                c2.style.setProperty("--dynamic-font-size", "".concat(a3, "px"));
                let i3 = Math.min(l2 * a3 * o2, n3), u2 = c2.scrollHeight <= i3, f2 = c2.scrollWidth <= r3 + 1;
                u2 && f2 ? (s3 = a3, e4 = a3 + 1) : t4 = a3 - 1;
              }
              return s3 - 1;
            } finally {
              c2.remove();
            }
          }, t2.useDynamicText = (e3, r3) => {
            (0, n2.useLayoutEffect)(() => {
              if (null === e3) return;
              e3.style.setProperty("--dynamic-line-height", String(r3.lineHeight));
              let n3 = () => {
                let { width: n4, height: s4 } = e3.getBoundingClientRect(), a3 = e3.childNodes.length > 0;
                if (0 === n4 || 0 === s4 || !a3) return;
                let i2 = (0, t2.findOptimalFontSize)({ container: e3, containerWidth: n4, containerHeight: s4, ...r3 });
                e3.style.setProperty("--dynamic-font-size", "".concat(i2, "px"));
              }, s3 = new ResizeObserver(n3), a2 = new MutationObserver(n3);
              return s3.observe(e3), a2.observe(e3, { childList: true, characterData: true, subtree: true }), document.fonts.ready.then(n3), n3(), () => {
                s3.disconnect(), a2.disconnect();
              };
            }, [e3, r3]);
          };
        },
        2101: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useElementOffsetY = void 0;
          let n2 = r2(810), s2 = r2(2067), a2 = r2(2767);
          t2.useElementOffsetY = (e3) => {
            let [t3, r3] = (0, a2.useForceUpdateRef)(), [i2, o2] = (0, n2.useState)(), l2 = (0, n2.useCallback)(() => {
              let e4 = null == t3 ? void 0 : t3.getBoundingClientRect();
              e4 && o2(e4.y);
            }, [t3]);
            return (0, n2.useLayoutEffect)(l2), (0, s2.useScroll)({ onScroll: l2, elementRef: e3 }), { forceUpdateRefCallback: r3, offsetY: i2 };
          };
        },
        2767: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForceUpdateRef = void 0;
          let n2 = r2(810);
          t2.useForceUpdateRef = () => {
            let [e3, t3] = (0, n2.useState)(null);
            return [
              e3,
              (0, n2.useCallback)((e4) => {
                t3((t4) => t4 !== e4 ? e4 : t4);
              }, [])
            ];
          };
        },
        245: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForwardRef = void 0;
          let n2 = r2(810);
          t2.useForwardRef = function(e3, t3) {
            let r3 = (0, n2.useRef)(t3);
            return (0, n2.useEffect)(() => {
              e3 && ("function" == typeof e3 ? e3(r3.current) : e3.current = r3.current);
            }, [e3]), r3;
          };
        },
        5663: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIntersectionObserver = t2.createIntersectionObserver = t2.getElementNameByDataAttribute = t2.isInViewportNow = t2.defaultOptions = void 0;
          let n2 = r2(810), { innerWidth: s2 = 0, innerHeight: a2 = 0 } = window;
          function i2(e3) {
            let { top: t3, right: r3, bottom: n3, left: i3 } = e3.getBoundingClientRect();
            return (t3 >= 0 && t3 <= a2 || n3 >= 0 && n3 <= a2) && (i3 >= 0 && i3 <= s2 || r3 >= 0 && r3 <= s2);
          }
          function o2(e3) {
            var t3, r3;
            let n3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "data-intersection-property-id";
            return null != (r3 = null == e3 || null == (t3 = e3.getAttribute) ? void 0 : t3.call(e3, n3)) ? r3 : e3.attributes[0];
          }
          function l2(e3, t3) {
            let r3 = new IntersectionObserver((t4) => {
              t4.forEach((t5) => {
                e3(t5, r3);
              });
            }, t3);
            return r3;
          }
          t2.defaultOptions = { threshold: 0, preflightCheck: true }, t2.isInViewportNow = i2, t2.getElementNameByDataAttribute = o2, t2.createIntersectionObserver = l2, t2.useIntersectionObserver = function(e3, r3, s3) {
            let [{ freezeOnceVisible: a3, preflightCheck: c2, ...u2 }, f2 = false] = "boolean" == typeof r3 || void 0 === r3 ? [t2.defaultOptions, r3] : [{ ...t2.defaultOptions, ...r3 }, s3], [d2, x] = (0, n2.useState)({}), p = (0, n2.useRef)(/* @__PURE__ */ new Set()), _ = (0, n2.useMemo)(
              () => f2 ? null : l2((e4) => {
                let t3 = o2(e4.target);
                if (t3 && _) {
                  if (p.current.has(t3)) return;
                  x((r4) => ({ ...r4, [t3]: { isIntersecting: e4.isIntersecting } })), a3 && e4.isIntersecting && (p.current.add(t3), _.unobserve(e4.target));
                }
              }, u2),
              [f2]
            );
            return (0, n2.useLayoutEffect)(
              () => (_ && !f2 && e3.forEach((e4) => {
                if (e4.current) {
                  let t3 = false;
                  if (c2 && (t3 = i2(e4.current))) {
                    let t4 = o2(e4.current);
                    x((e5) => ({ ...e5, [t4]: { isIntersecting: true } }));
                  }
                  t3 || _.observe(e4.current);
                }
              }), () => {
                _ && _.disconnect();
              }),
              [f2, _, e3.length]
            ), d2;
          };
        },
        9019: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIsomorphicEffect = void 0;
          let n2 = r2(810);
          t2.useIsomorphicEffect = "undefined" != typeof document ? n2.useLayoutEffect : n2.useEffect;
        },
        5188: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useKeyboardNavigation = void 0;
          let n2 = r2(810);
          function s2(e3, t3) {
            return e3.current ? Array.from(t3 ? e3.current.querySelectorAll(t3) : e3.current.children) : [];
          }
          t2.useKeyboardNavigation = function(e3) {
            let t3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, { navigationItemsSelector: r3, activeAttributeName: a2 = "aria-selected" } = t3, i2 = (0, n2.useCallback)(
              (t4) => {
                let n3 = s2(e3, r3);
                if (!n3.length) return;
                let a3 = t4.target, i3 = n3.indexOf(a3);
                if (-1 === i3) return;
                let [o2] = n3, l2 = n3.at(-1), c2 = null;
                switch (t4.key) {
                  case "ArrowLeft":
                  case "ArrowUp":
                    c2 = n3[i3 - 1] || l2;
                    break;
                  case "ArrowRight":
                  case "ArrowDown":
                    c2 = n3[i3 + 1] || o2;
                    break;
                  case "Home":
                    c2 = o2;
                    break;
                  case "End":
                    c2 = l2;
                }
                null !== c2 && (c2.focus(), t4.preventDefault());
              },
              [r3, e3]
            );
            (0, n2.useEffect)(() => {
              let t4 = e3.current;
              return null == t4 || t4.addEventListener("keydown", i2), () => null == t4 ? void 0 : t4.removeEventListener("keydown", i2);
            }, [e3, i2]), (0, n2.useEffect)(() => {
              s2(e3, r3).forEach((e4) => {
                e4.hasAttribute(a2) && ("true" === e4.getAttribute(a2) ? e4.tabIndex = 0 : e4.tabIndex = -1);
              });
            });
          };
        },
        4395: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.usePopoverSwipeable = void 0;
          let n2 = r2(810), s2 = r2(1381);
          t2.usePopoverSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: a2, disableSwipe: i2, placement: o2, threshold: l2 } = e3, c2 = (0, n2.useMemo)(() => {
              switch (o2) {
                case "top":
                case "top-end":
                case "top-start":
                  return s2.SwipeablePlacement.TOP;
                case "right":
                case "right-end":
                case "right-start":
                  return s2.SwipeablePlacement.RIGHT;
                case "left":
                case "left-end":
                case "left-start":
                  return s2.SwipeablePlacement.LEFT;
                default:
                  return s2.SwipeablePlacement.BOTTOM;
              }
            }, [o2]);
            return (0, s2.useComponentSwipeable)({
              ref: t3,
              swipeableProps: r3,
              onClose: a2,
              disableSwipe: i2,
              placement: c2,
              threshold: l2
            });
          };
        },
        2947: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useResize = void 0;
          let n2 = r2(810), s2 = r2(361);
          t2.useResize = (e3, t3) => {
            (0, n2.useEffect)(() => {
              let r3 = (0, s2.getElementFromRefOrElement)(t3);
              if (null === r3) return;
              let n3 = null != r3 ? r3 : document.documentElement, a2 = new ResizeObserver(e3);
              return a2.observe(n3), () => a2.disconnect();
            }, [t3, e3]);
          };
        },
        998: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useReturnValue = void 0, t2.useReturnValue = (e3) => e3();
        },
        2067: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useScroll = void 0;
          let n2 = r2(810), s2 = r2(361), a2 = r2(6699);
          t2.useScroll = (e3) => {
            let { onScroll: t3, listenIsScrolling: r3, elementRef: i2 } = e3, { state: o2, handleDebouncedToggle: l2 } = (0, a2.useDebouncedToggle)({
              delay: 1e3,
              throttleTimeout: 100
            }), c2 = (0, n2.useCallback)(() => {
              r3 && l2(), null == t3 || t3();
            }, [r3, l2, t3]);
            return (0, n2.useEffect)(() => {
              let e4 = (0, s2.getElementFromRefOrElement)(i2);
              if (null === e4) return;
              let t4 = null != e4 ? e4 : window, r4 = { capture: true, passive: true };
              return t4.addEventListener("scroll", c2, r4), () => t4.removeEventListener("scroll", c2, r4);
            }, [i2, c2]), o2;
          };
        },
        4601: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useToggle = void 0;
          let n2 = r2(810);
          t2.useToggle = (e3) => {
            let [t3, r3] = (0, n2.useState)(e3);
            (0, n2.useEffect)(() => {
              r3(e3);
            }, [e3]);
            let s2 = (0, n2.useCallback)(() => {
              r3((e4) => !e4);
            }, []), a2 = (0, n2.useCallback)(() => {
              r3(true);
            }, []), i2 = (0, n2.useCallback)(() => {
              r3(false);
            }, []);
            return { state: t3, toggle: s2, setState: r3, toggleTrue: a2, toggleFalse: i2 };
          };
        },
        8796: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.createRipple = void 0, t2.createRipple = function(e3, t3, r2) {
            let n2 = null != r2 ? r2 : e3.currentTarget, s2 = document.createElement("span"), a2 = Math.max(n2.clientWidth, n2.clientHeight), i2 = a2 / 2, o2 = n2.getBoundingClientRect(), l2 = 0 === e3.clientX ? Math.round(o2.width / 2) : e3.clientX - o2.left, c2 = 0 === e3.clientY ? Math.round(o2.height / 2) : e3.clientY - o2.top;
            s2.style.width = "".concat(a2, "px"), s2.style.height = "".concat(a2, "px"), s2.style.left = 0 === e3.clientX ? "0px" : "".concat(l2 - i2, "px"), s2.style.top = "".concat(c2 - i2, "px"), s2.classList.add(t3);
            let u2 = n2.getElementsByClassName(t3)[0];
            u2 && u2.remove(), n2.insertBefore(s2, n2.firstChild);
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        8216: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = t2.createRipple = void 0;
          var n2 = r2(8796);
          Object.defineProperty(t2, "createRipple", {
            enumerable: true,
            get: function() {
              return n2.createRipple;
            }
          });
          var s2 = r2(361);
          Object.defineProperty(t2, "getElementFromRefOrElement", {
            enumerable: true,
            get: function() {
              return s2.getElementFromRefOrElement;
            }
          });
        },
        8119: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = r2(8216), l2 = n2(r2(1920)), c2 = (e3) => {
            let {
              forwardRef: t3,
              isBlock: r3,
              iconPosition: n3 = "left",
              children: c3,
              className: u2,
              color: f2 = "secondary",
              flexIcon: d2,
              icon: x,
              spinner: p,
              role: _,
              onClick: m,
              radius: v = "m",
              size: g,
              type: b = "button",
              variant: y = "default",
              withRipple: h = true,
              withHover: k = true,
              withBorder: E = false,
              disabled: w,
              iconClassName: j,
              contentContainerClassName: O,
              ...R
            } = e3, C = (0, a2.useId)(), S = !a2.Children.toArray(c3).filter(Boolean).length, P = "left" === n3, A = null, T = (0, a2.isValidElement)(p);
            if (x) {
              var H, M;
              A = (0, a2.cloneElement)(x, {
                className: (0, i2.clsx)(
                  l2.default.icon,
                  {
                    [l2.default["icon_position_".concat(n3)]]: n3 && !S,
                    [l2.default.icon_withButtonSize]: !(null == (H = x.props) ? void 0 : H.size)
                  },
                  null == (M = x.props) ? void 0 : M.className,
                  j
                ),
                key: C
              });
            }
            let N = (0, a2.useMemo)(
              () => T ? (0, s2.jsx)("div", { className: l2.default.spinnerContainer, children: p }) : null,
              [T, p]
            ), I = (0, a2.useCallback)(
              (e4) => {
                T || (h && (0, o2.createRipple)(e4, l2.default.ripple), null == m || m(e4));
              },
              [T, m, h]
            );
            return (0, s2.jsx)("button", {
              ref: t3,
              className: (0, i2.clsx)(
                l2.default.root,
                l2.default["root_".concat(f2, "_").concat(y)],
                l2.default["root_radius_".concat(v)],
                l2.default.root_size,
                {
                  [l2.default["root_".concat(f2, "_withHover_").concat(y)]]: k && !w && !T,
                  [l2.default["root_size_".concat(g)]]: g,
                  [l2.default.root_withoutBorder]: !E,
                  [l2.default.root_withActiveSpinner]: T,
                  [l2.default.block]: r3,
                  [l2.default.flexIcon]: d2,
                  [l2.default.iconOnly]: S,
                  [l2.default.root_icon_left]: x && !S && P,
                  [l2.default.root_icon_right]: x && !S && !P
                },
                u2
              ),
              type: b,
              role: _,
              onClick: I,
              ...R,
              disabled: w,
              "aria-live": T ? "polite" : "off",
              "aria-busy": T,
              children: x || T ? (0, s2.jsxs)("span", {
                className: (0, i2.clsx)(
                  l2.default.contentContainer,
                  { [l2.default.contentContainer_block]: r3 },
                  O
                ),
                children: [x && P && A, !S && c3, x && !P && A, N]
              }) : c3
            });
          };
          t2.Button = (0, a2.forwardRef)((e3, t3) => (0, s2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        5928: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          var n2 = r2(8119);
          Object.defineProperty(t2, "Button", {
            enumerable: true,
            get: function() {
              return n2.Button;
            }
          });
        },
        5455: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Divider = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = n2(r2(4092));
          t2.Divider = (e3) => {
            let { className: t3, orientation: r3 = "horizontal", children: n3, ...o2 } = e3, l2 = n3 && (0, s2.jsx)("span", { children: n3 });
            return (0, s2.jsx)("div", {
              className: (0, a2.clsx)(i2.default.root, { [i2.default[r3]]: r3, [i2.default.hasLabel]: l2 }, t3),
              ...o2,
              role: "separator",
              "aria-orientation": r3,
              children: l2
            });
          };
        },
        8062: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Divider = void 0;
          var n2 = r2(5455);
          Object.defineProperty(t2, "Divider", {
            enumerable: true,
            get: function() {
              return n2.Divider;
            }
          });
        },
        5189: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = t2.IconComponent = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = r2(5151), l2 = n2(r2(2964));
          t2.IconComponent = (e3) => {
            let { "aria-label": t3, className: r3, focusable: n3 = false, variant: a3, size: c2, forwardRef: u2, ...f2 } = e3, d2 = c2 ? "".concat(a3, "_").concat(c2) : a3, x = o2.iconsCollection[d2];
            return x ? (0, s2.jsx)(x, {
              className: (0, i2.clsx)(l2.default.root, r3, l2.default["root_size_".concat(c2)]),
              focusable: n3,
              "aria-label": t3,
              ...f2,
              "aria-hidden": !t3,
              ref: u2
            }) : null;
          }, t2.Icon = (0, a2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.IconComponent, { forwardRef: r3, ...e3 }));
        },
        5151: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e10) {
            return e10 && e10.__esModule ? e10 : { default: e10 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.iconsCollection = t2.iconsCollectionBySize = void 0;
          let s2 = n2(r2(4656)), a2 = n2(r2(8170)), i2 = n2(r2(5565)), o2 = n2(r2(8127)), l2 = n2(r2(8993)), c2 = n2(r2(2933)), u2 = n2(r2(1334)), f2 = n2(r2(1426)), d2 = n2(r2(5378)), x = n2(r2(6579)), p = n2(r2(3935)), _ = n2(r2(3522)), m = n2(r2(7319)), v = n2(r2(8442)), g = n2(r2(2586)), b = n2(r2(5822)), y = n2(r2(5272)), h = n2(r2(4860)), k = n2(r2(8711)), E = n2(r2(8109)), w = n2(r2(4904)), j = n2(r2(5971)), O = n2(r2(3331)), R = n2(r2(9783)), C = n2(r2(8184)), S = n2(r2(4926)), P = n2(r2(3176)), A = n2(r2(4789)), T = n2(r2(8151)), H = n2(r2(8690)), M = n2(r2(1524)), N = n2(r2(2361)), I = n2(r2(3972)), L = n2(r2(9330)), B = n2(r2(7346)), D = n2(r2(2604)), z = n2(r2(6894)), F = n2(r2(6391)), U = n2(r2(9369)), W = n2(r2(226)), V = n2(r2(8130)), Y = n2(r2(5270)), K = n2(r2(3560)), X = n2(r2(7513)), q = n2(r2(9838)), Q = n2(r2(9104)), G = n2(r2(7399)), Z = n2(r2(5849)), $ = n2(r2(3613)), J = n2(r2(9372)), ee = n2(r2(3709)), et = n2(r2(3685)), er = n2(r2(3302)), en = n2(r2(811)), es = n2(r2(6122)), ea = n2(r2(5386)), ei = n2(r2(3201)), eo = n2(r2(9434)), el = n2(r2(2026)), ec = n2(r2(8112)), eu = n2(r2(8044)), ef = n2(r2(2754)), ed = n2(r2(5251)), ex = n2(r2(9370)), ep = n2(r2(5632)), e_ = n2(r2(1001)), em = n2(r2(893)), ev = n2(r2(6331)), eg = n2(r2(9876)), eb = n2(r2(1758)), ey = n2(r2(7196)), eh = n2(r2(7951)), ek = n2(r2(126)), eE = n2(r2(3112)), ew = n2(r2(8819)), ej = n2(r2(8772)), eO = n2(r2(5695)), eR = n2(r2(7171)), eC = n2(r2(9030)), eS = n2(r2(9422)), eP = n2(r2(1491)), eA = n2(r2(2337)), eT = n2(r2(9202)), eH = n2(r2(130)), eM = n2(r2(7923)), eN = n2(r2(3654)), eI = n2(r2(6507)), eL = n2(r2(3193)), eB = n2(r2(30)), eD = n2(r2(7802)), ez = n2(r2(3738)), eF = n2(r2(2340)), eU = n2(r2(2125)), eW = n2(r2(4014)), eV = n2(r2(896)), eY = n2(r2(1829)), eK = n2(r2(1893)), eX = n2(r2(1563)), eq = n2(r2(1578)), eQ = n2(r2(9348)), eG = n2(r2(965)), eZ = n2(r2(3877)), e$ = n2(r2(9968)), eJ = n2(r2(3778)), e0 = n2(r2(1084)), e1 = n2(r2(4254)), e8 = n2(r2(792)), e4 = n2(r2(8131)), e5 = n2(r2(1125)), e6 = n2(r2(9288)), e7 = n2(r2(976)), e22 = n2(r2(1874)), e3 = n2(r2(9863)), e9 = n2(r2(1945)), te = n2(r2(1580)), tt = n2(r2(4091)), tr = n2(r2(8090)), tn = n2(r2(895)), ts = n2(r2(5910)), ta = n2(r2(4892)), ti = n2(r2(3366)), to = n2(r2(5034)), tl = n2(r2(5792)), tc = n2(r2(9545)), tu = n2(r2(3362)), tf = n2(r2(1079)), td = n2(r2(8994)), tx = n2(r2(51)), tp = n2(r2(5218)), t_ = n2(r2(3049)), tm = n2(r2(380)), tv = n2(r2(2834)), tg = n2(r2(540)), tb = n2(r2(6174)), ty = n2(r2(7185)), th = n2(r2(9351)), tk = n2(r2(2092)), tE = n2(r2(1162)), tw = n2(r2(6837)), tj = n2(r2(2024)), tO = n2(r2(776)), tR = n2(r2(5720)), tC = n2(r2(2774)), tS = n2(r2(4997)), tP = n2(r2(3146)), tA = n2(r2(2084)), tT = n2(r2(3751)), tH = n2(r2(3076)), tM = n2(r2(2495)), tN = n2(r2(9509)), tI = n2(r2(8987)), tL = n2(r2(190)), tB = n2(r2(843)), tD = n2(r2(5122)), tz = n2(r2(7405)), tF = n2(r2(820)), tU = n2(r2(5443)), tW = n2(r2(8782)), tV = n2(r2(7252)), tY = n2(r2(3013)), tK = n2(r2(5346)), tX = n2(r2(3792)), tq = n2(r2(1351)), tQ = n2(r2(8303)), tG = n2(r2(4777)), tZ = n2(r2(735)), t$ = n2(r2(2176)), tJ = n2(r2(8235)), t0 = n2(r2(8915)), t1 = n2(r2(2037)), t8 = n2(r2(5197)), t4 = n2(r2(7026)), t5 = n2(r2(8664)), t6 = n2(r2(8619)), t7 = n2(r2(6130)), t22 = n2(r2(6210)), t3 = n2(r2(5596)), t9 = n2(r2(6644)), re = n2(r2(996)), rt = n2(r2(7031)), rr = n2(r2(4793)), rn = n2(r2(7076)), rs = n2(r2(8582)), ra = n2(r2(7643)), ri = n2(r2(9846)), ro = n2(r2(6275)), rl = n2(r2(3702)), rc = n2(r2(8550)), ru = n2(r2(857)), rf = n2(r2(6304)), rd = n2(r2(9040)), rx = n2(r2(4298)), rp = n2(r2(5132)), r_ = n2(r2(8868)), rm = n2(r2(8779)), rv = n2(r2(8503)), rg = n2(r2(1045)), rb = n2(r2(7341)), ry = n2(r2(9505)), rh = n2(r2(4483)), rk = n2(r2(8499)), rE = n2(r2(705)), rw = n2(r2(7402)), rj = n2(r2(1427)), rO = n2(r2(7934)), rR = n2(r2(2435)), rC = n2(r2(3918)), rS = n2(r2(2571)), rP = n2(r2(2161)), rA = n2(r2(5304)), rT = n2(r2(2646)), rH = n2(r2(7500)), rM = n2(r2(6104)), rN = n2(r2(2502)), rI = n2(r2(1754)), rL = n2(r2(6615)), rB = n2(r2(7942)), rD = n2(r2(1498)), rz = n2(r2(8861)), rF = n2(r2(6809)), rU = n2(r2(5266)), rW = n2(r2(1179)), rV = n2(r2(6206)), rY = n2(r2(9481)), rK = n2(r2(7364)), rX = n2(r2(8577)), rq = n2(r2(5760)), rQ = n2(r2(5667)), rG = n2(r2(2639));
          t2.iconsCollectionBySize = {
            xxxs: [
              "adult",
              "arrowRight",
              "check",
              "close",
              "donation",
              "exclamation",
              "explicit",
              "listen",
              "play",
              "reset",
              "ruble",
              "users"
            ],
            xxs: [
              "add",
              "addToPlaylist",
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "artist",
              "bucket",
              "chain",
              "chartDown",
              "chartNew",
              "chartSame",
              "chartUp",
              "check",
              "clip",
              "close",
              "code",
              "crown",
              "dislike",
              "disliked",
              "download",
              "downloaded",
              "dragDots",
              "edit",
              "exclamation",
              "explicit",
              "eye_crossed",
              "filter",
              "info",
              "lightning",
              "like",
              "likeVariant",
              "liked",
              "likedVariant",
              "link",
              "lock",
              "lyrics",
              "macos",
              "menuArrow",
              "more",
              "next",
              "pause",
              "pencil",
              "pin",
              "pin_filled",
              "play",
              "playLast",
              "playNext",
              "podcasts",
              "previous",
              "repeat",
              "repeat_one",
              "reset",
              "rewindBackwards",
              "rewindForward",
              "ruble",
              "settings",
              "share",
              "shuffle",
              "syncLyrics",
              "trailer",
              "unpin",
              "upload",
              "vibe"
            ],
            xs: [
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "cast",
              "chain",
              "close",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "filter",
              "fullscreen",
              "like",
              "liked",
              "liteVersion",
              "lock",
              "more",
              "navigationCollection",
              "navigationConcerts",
              "navigationForYouAndTrends",
              "navigationKids",
              "navigationMyVibe",
              "navigationNonMusic",
              "navigationPlus",
              "navigationSearch",
              "next",
              "note",
              "pause",
              "pause_filled",
              "picture",
              "pin",
              "pin_filled",
              "play",
              "playQueue",
              "play_filled",
              "playlist",
              "previous",
              "repeat",
              "repeat_one",
              "rewindBackwards",
              "rewindForward",
              "search",
              "settings",
              "shuffle",
              "site",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "trailer",
              "unavailable",
              "volume",
              "volumeOff",
              "windows"
            ],
            s: [
              "adult",
              "album",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "likedVariant",
              "note",
              "pauseVibe",
              "picture",
              "playVibe",
              "playlist"
            ],
            m: [
              "collections",
              "collections_selected",
              "history",
              "home",
              "home_selected",
              "kids",
              "kids_selected",
              "like",
              "liked",
              "lock",
              "more",
              "non_music",
              "non_music_selected",
              "pause",
              "pause_filled",
              "play",
              "playQueue",
              "play_filled",
              "plusOutlined",
              "ruble",
              "search",
              "search_selected",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "ticket",
              "ticket_selected"
            ],
            l: [
              "add",
              "album",
              "download",
              "like",
              "pause_filled",
              "play_filled",
              "search",
              "speed_1_25x",
              "speed_1_5x",
              "speed_1_75x",
              "speed_1x",
              "speed_2x"
            ],
            xl: ["album", "clip", "note", "pause_filled", "picture", "play_filled", "playlist", "unavailable"],
            xxl: ["attention", "check", "next", "offline", "pause_filled", "play_filled", "previous", "search"],
            xxxl: ["attention"],
            "": [
              "bandlink",
              "booksLogo",
              "googlePlay",
              "huaweiAppGallery",
              "kinopoiskEn",
              "kinopoiskRu",
              "macos",
              "musicLogo",
              "musicLogoCenterEn",
              "musicLogoCenterRu",
              "musicLogoLeftEn",
              "musicLogoLeftRu",
              "plus",
              "plusBadge",
              "plusColor",
              "plusOutlined",
              "windows",
              "yandexBooksEn",
              "yandexBooksRu",
              "yandexPayEn",
              "yandexPayRu",
              "yandexPlusEn",
              "yandexPlusRu"
            ]
          }, t2.iconsCollection = {
            adult_xxxs: s2.default,
            arrowRight_xxxs: a2.default,
            check_xxxs: i2.default,
            close_xxxs: o2.default,
            donation_xxxs: l2.default,
            exclamation_xxxs: c2.default,
            explicit_xxxs: u2.default,
            listen_xxxs: f2.default,
            play_xxxs: d2.default,
            reset_xxxs: x.default,
            ruble_xxxs: p.default,
            users_xxxs: _.default,
            add_xxs: m.default,
            addToPlaylist_xxs: v.default,
            adult_xxs: g.default,
            album_xxs: b.default,
            arrowDown_xxs: y.default,
            arrowLeft_xxs: h.default,
            arrowRight_xxs: k.default,
            artist_xxs: E.default,
            bucket_xxs: w.default,
            chain_xxs: j.default,
            chartDown_xxs: O.default,
            chartNew_xxs: R.default,
            chartSame_xxs: C.default,
            chartUp_xxs: S.default,
            check_xxs: P.default,
            clip_xxs: A.default,
            close_xxs: T.default,
            code_xxs: H.default,
            crown_xxs: M.default,
            dislike_xxs: N.default,
            disliked_xxs: I.default,
            download_xxs: L.default,
            downloaded_xxs: B.default,
            dragDots_xxs: D.default,
            edit_xxs: z.default,
            exclamation_xxs: F.default,
            explicit_xxs: U.default,
            eye_crossed_xxs: W.default,
            filter_xxs: V.default,
            info_xxs: Y.default,
            lightning_xxs: K.default,
            like_xxs: X.default,
            likeVariant_xxs: q.default,
            liked_xxs: Q.default,
            likedVariant_xxs: G.default,
            link_xxs: Z.default,
            lock_xxs: $.default,
            lyrics_xxs: J.default,
            macos_xxs: ee.default,
            menuArrow_xxs: et.default,
            more_xxs: er.default,
            next_xxs: en.default,
            pause_xxs: es.default,
            pencil_xxs: ea.default,
            pin_xxs: ei.default,
            pin_filled_xxs: eo.default,
            play_xxs: el.default,
            playLast_xxs: ec.default,
            playNext_xxs: eu.default,
            podcasts_xxs: ef.default,
            previous_xxs: ed.default,
            repeat_xxs: ex.default,
            repeat_one_xxs: ep.default,
            reset_xxs: e_.default,
            rewindBackwards_xxs: em.default,
            rewindForward_xxs: ev.default,
            ruble_xxs: eg.default,
            settings_xxs: eb.default,
            share_xxs: ey.default,
            shuffle_xxs: eh.default,
            syncLyrics_xxs: ek.default,
            trailer_xxs: eE.default,
            unpin_xxs: ew.default,
            upload_xxs: ej.default,
            vibe_xxs: eO.default,
            adult_xs: eR.default,
            album_xs: eC.default,
            arrowDown_xs: eS.default,
            arrowLeft_xs: eP.default,
            arrowRight_xs: eA.default,
            cast_xs: eT.default,
            chain_xs: eH.default,
            close_xs: eM.default,
            dislike_xs: eN.default,
            disliked_xs: eI.default,
            exclamation_xs: eL.default,
            explicit_xs: eB.default,
            filter_xs: eD.default,
            fullscreen_xs: ez.default,
            like_xs: eF.default,
            liked_xs: eU.default,
            liteVersion_xs: eW.default,
            lock_xs: eV.default,
            more_xs: eY.default,
            navigationCollection_xs: eK.default,
            navigationConcerts_xs: eX.default,
            navigationForYouAndTrends_xs: eq.default,
            navigationKids_xs: eQ.default,
            navigationMyVibe_xs: eG.default,
            navigationNonMusic_xs: eZ.default,
            navigationPlus_xs: e$.default,
            navigationSearch_xs: eJ.default,
            next_xs: e0.default,
            note_xs: e1.default,
            pause_xs: e8.default,
            pause_filled_xs: e4.default,
            picture_xs: e5.default,
            pin_xs: e6.default,
            pin_filled_xs: e7.default,
            play_xs: e22.default,
            playQueue_xs: e3.default,
            play_filled_xs: e9.default,
            playlist_xs: te.default,
            previous_xs: tt.default,
            repeat_xs: tr.default,
            repeat_one_xs: tn.default,
            rewindBackwards_xs: ts.default,
            rewindForward_xs: ta.default,
            search_xs: ti.default,
            settings_xs: to.default,
            shuffle_xs: tl.default,
            site_xs: tc.default,
            speed_1_25x_centered_xs: tu.default,
            speed_1_5x_centered_xs: tf.default,
            speed_1_75x_centered_xs: td.default,
            speed_1x_centered_xs: tx.default,
            speed_2x_centered_xs: tp.default,
            syncLyrics_xs: t_.default,
            trailer_xs: tm.default,
            unavailable_xs: tv.default,
            volume_xs: tg.default,
            volumeOff_xs: tb.default,
            windows_xs: ty.default,
            adult_s: th.default,
            album_s: tk.default,
            dislike_s: tE.default,
            disliked_s: tw.default,
            exclamation_s: tj.default,
            explicit_s: tO.default,
            likedVariant_s: tR.default,
            note_s: tC.default,
            pauseVibe_s: tS.default,
            picture_s: tP.default,
            playVibe_s: tA.default,
            playlist_s: tT.default,
            collections_m: tH.default,
            collections_selected_m: tM.default,
            history_m: tN.default,
            home_m: tI.default,
            home_selected_m: tL.default,
            kids_m: tB.default,
            kids_selected_m: tD.default,
            like_m: tz.default,
            liked_m: tF.default,
            lock_m: tU.default,
            more_m: tW.default,
            non_music_m: tV.default,
            non_music_selected_m: tY.default,
            pause_m: tK.default,
            pause_filled_m: tX.default,
            play_m: tq.default,
            playQueue_m: tQ.default,
            play_filled_m: tG.default,
            plusOutlined_m: tZ.default,
            ruble_m: t$.default,
            search_m: tJ.default,
            search_selected_m: t0.default,
            speed_1_25x_centered_m: t1.default,
            speed_1_5x_centered_m: t8.default,
            speed_1_75x_centered_m: t4.default,
            speed_1x_centered_m: t5.default,
            speed_2x_centered_m: t6.default,
            syncLyrics_m: t7.default,
            ticket_m: t22.default,
            ticket_selected_m: t3.default,
            add_l: t9.default,
            album_l: re.default,
            download_l: rt.default,
            like_l: rr.default,
            pause_filled_l: rn.default,
            play_filled_l: rs.default,
            search_l: ra.default,
            speed_1_25x_l: ri.default,
            speed_1_5x_l: ro.default,
            speed_1_75x_l: rl.default,
            speed_1x_l: rc.default,
            speed_2x_l: ru.default,
            album_xl: rf.default,
            clip_xl: rd.default,
            note_xl: rx.default,
            pause_filled_xl: rp.default,
            picture_xl: r_.default,
            play_filled_xl: rm.default,
            playlist_xl: rv.default,
            unavailable_xl: rg.default,
            attention_xxl: rb.default,
            check_xxl: ry.default,
            next_xxl: rh.default,
            offline_xxl: rk.default,
            pause_filled_xxl: rE.default,
            play_filled_xxl: rw.default,
            previous_xxl: rj.default,
            search_xxl: rO.default,
            attention_xxxl: rR.default,
            bandlink: rC.default,
            booksLogo: rS.default,
            googlePlay: rP.default,
            huaweiAppGallery: rA.default,
            kinopoiskEn: rT.default,
            kinopoiskRu: rH.default,
            macos: rM.default,
            musicLogo: rN.default,
            musicLogoCenterEn: rI.default,
            musicLogoCenterRu: rL.default,
            musicLogoLeftEn: rB.default,
            musicLogoLeftRu: rD.default,
            plus: rz.default,
            plusBadge: rF.default,
            plusColor: rU.default,
            plusOutlined: rW.default,
            windows: rV.default,
            yandexBooksEn: rY.default,
            yandexBooksRu: rK.default,
            yandexPayEn: rX.default,
            yandexPayRu: rq.default,
            yandexPlusEn: rQ.default,
            yandexPlusRu: rG.default
          };
        },
        7066: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = void 0;
          var n2 = r2(5189);
          Object.defineProperty(t2, "Icon", {
            enumerable: true,
            get: function() {
              return n2.Icon;
            }
          });
        },
        2647: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Menu = t2.MenuComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(1964), o2 = r2(810), l2 = r2(6544), c2 = r2(8119), u2 = r2(5556), f2 = r2(7066), d2 = r2(8765), x = n2(r2(5059)), p = n2(r2(3309));
          t2.MenuComponent = (e3) => {
            let {
              className: t3,
              listClassName: r3,
              children: n3,
              label: d3,
              icon: _2,
              shouldOpenOnHover: m = false,
              size: v = "xs",
              radius: g = "round",
              disabled: b,
              variant: y,
              onShow: h,
              nestedOffsetOptions: k = 3,
              offsetOptions: E = 10,
              ariaLabel: w,
              open: j,
              onOpenChange: O,
              withRipple: R = false,
              menuRole: C = "menu",
              placement: S = "bottom",
              forwardRef: P,
              containerProps: A,
              wrapperClassName: T,
              menuClassName: H,
              footer: M,
              disableFloatingStyles: N = false,
              transform: I,
              portalNode: L,
              transition: B,
              lockScroll: D,
              hoverSettings: z,
              dismissSettings: F = { bubbles: true },
              submenuProps: U,
              ...W
            } = e3, [V, Y] = (0, o2.useState)(false), K = null != j ? j : V, X = null != O ? O : Y, [q, Q] = (0, o2.useState)(false), [G, Z] = (0, o2.useState)(null), $ = (0, o2.useRef)([]), J = (0, o2.useRef)([]), ee = (0, o2.useContext)(u2.MenuContext), et = (0, i2.useFloatingTree)(), er = (0, i2.useFloatingNodeId)(), en = (0, i2.useFloatingParentNodeId)(), es = (0, i2.useListItem)(), ea = null !== en, {
              floatingStyles: ei,
              refs: eo,
              context: el
            } = (0, i2.useFloating)({
              nodeId: er,
              open: K,
              onOpenChange: X,
              placement: ea ? "right-start" : S,
              middleware: [
                (0, i2.offset)(ea ? k : E),
                (0, i2.flip)({ fallbackAxisSideDirection: "start", crossAxis: false }),
                (0, i2.shift)(),
                (0, i2.size)({
                  apply(e4) {
                    let { availableHeight: t4, elements: r4 } = e4;
                    Object.assign(r4.floating.style, { maxHeight: "".concat(t4, "px") });
                  }
                })
              ],
              whileElementsMounted: i2.autoUpdate,
              transform: I
            }), { isMounted: ec, styles: eu } = (0, i2.useTransitionStyles)(el, B), ef = (0, i2.useHover)(el, {
              enabled: (ea || m) && !b,
              delay: { open: 75 },
              handleClose: (0, i2.safePolygon)({ blockPointerEvents: true }),
              ...z
            }), ed = (0, i2.useClick)(el, {
              enabled: !b,
              event: "mousedown",
              keyboardHandlers: true,
              toggle: !ea,
              ignoreMouse: ea
            }), ex = (0, i2.useRole)(el, { role: C }), ep = (0, i2.useDismiss)(el, F), e_ = (0, i2.useListNavigation)(el, { listRef: $, activeIndex: G, nested: ea, onNavigate: Z }), em = (0, i2.useTypeahead)(el, { listRef: J, onMatch: K ? Z : void 0, activeIndex: G }), {
              getReferenceProps: ev,
              getFloatingProps: eg,
              getItemProps: eb
            } = (0, i2.useInteractions)([ef, ed, ex, ep, e_, em]);
            (0, o2.useEffect)(() => {
              if (et)
                return et.events.on("click", e4), et.events.on("menuopen", t4), () => {
                  et.events.off("click", e4), et.events.off("menuopen", t4);
                };
              function e4() {
                X(false);
              }
              function t4(e5) {
                e5.nodeId !== er && e5.parentId === en && X(false);
              }
            }, [et, er, en, X]), (0, o2.useEffect)(() => {
              K && et && et.events.emit("menuopen", { parentId: en, nodeId: er });
            }, [et, K, er, en]), (0, o2.useEffect)(() => {
              K && (null == h || h());
            }, [h, K]);
            let ey = (0, o2.useCallback)((e4) => {
              e4.stopPropagation();
            }, []), eh = (0, o2.useCallback)((e4) => {
              e4.stopPropagation();
            }, []);
            return (0, s2.jsx)(i2.FloatingNode, {
              id: er,
              children: (0, s2.jsxs)("div", {
                className: T,
                onClick: eh,
                children: [
                  (0, s2.jsxs)(c2.Button, {
                    ...W,
                    ref: (0, i2.useMergeRefs)([eo.setReference, es.ref, P]),
                    tabIndex: ea ? ee.activeIndex === es.index ? 0 : -1 : void 0,
                    role: ea ? "menuitem" : void 0,
                    "data-open": K ? "" : void 0,
                    "data-nested": ea ? "" : void 0,
                    "data-focus-inside": q ? "" : void 0,
                    className: (0, a2.clsx)(
                      {
                        [p.default.menuItem]: ea,
                        [p.default.rootMenu]: !ea,
                        [p.default.rootMenu_onlyIcon]: !ea && "text" === y
                      },
                      t3
                    ),
                    icon: _2,
                    size: v,
                    radius: g,
                    withRipple: !ea && R,
                    iconClassName: ea ? p.default.icon : p.default.rootIcon,
                    variant: ea ? void 0 : y,
                    "aria-label": ea ? void 0 : w,
                    disabled: b,
                    ...ev(
                      ee.getItemProps({
                        ...W,
                        onFocus(e4) {
                          var t4;
                          null == (t4 = W.onFocus) || t4.call(W, e4), Q(false), ee.setHasFocusInside(true);
                        }
                      })
                    ),
                    children: [
                      d3,
                      ea && (0, s2.jsx)(f2.Icon, {
                        "aria-hidden": true,
                        size: "xxs",
                        variant: "menuArrow",
                        className: (0, a2.clsx)(p.default.subMenuArrow, { [p.default.subMenuArrow_disabled]: b })
                      })
                    ]
                  }),
                  (0, s2.jsx)(u2.MenuContext.Provider, {
                    value: { activeIndex: G, setActiveIndex: Z, getItemProps: eb, setHasFocusInside: Q, isOpen: K },
                    children: (0, s2.jsx)(i2.FloatingList, {
                      elementsRef: $,
                      labelsRef: J,
                      children: ec && (0, s2.jsx)(i2.FloatingPortal, {
                        root: L,
                        children: (0, s2.jsx)(i2.FloatingOverlay, {
                          className: x.default.overlay,
                          onClick: ey,
                          children: (0, s2.jsx)(i2.FloatingFocusManager, {
                            context: el,
                            modal: false,
                            initialFocus: ea ? -1 : 0,
                            returnFocus: !ea,
                            children: (0, s2.jsx)(l2.RemoveScroll, {
                              enabled: D && K,
                              children: (0, s2.jsx)("div", {
                                ref: eo.setFloating,
                                className: (0, a2.clsx)(x.default.menu, H),
                                style: N ? void 0 : ei,
                                ...U,
                                children: (0, s2.jsxs)("div", {
                                  className: (0, a2.clsx)(x.default.content, r3),
                                  style: eu,
                                  ...eg(),
                                  ...A,
                                  children: [n3, M]
                                })
                              })
                            })
                          })
                        })
                      })
                    })
                  })
                ]
              })
            });
          };
          let _ = (e3) => null === (0, i2.useFloatingParentNodeId)() ? (0, s2.jsx)(i2.FloatingTree, { children: (0, s2.jsx)(t2.MenuComponent, { ...e3 }) }) : (0, s2.jsx)(t2.MenuComponent, { ...e3 });
          t2.Menu = (0, o2.forwardRef)((e3, t3) => {
            let { isMobile: r3, lockScroll: n3 = true, ...a3 } = e3;
            return r3 ? (0, s2.jsx)(d2.MenuMobile, { forwardRef: t3, ...a3, isMobile: r3, lockScroll: n3 }) : (0, s2.jsx)(_, { forwardRef: t3, ...a3, lockScroll: n3 });
          });
        },
        8448: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.MenuBackHeader = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5189), o2 = r2(8119), l2 = n2(r2(5335));
          t2.MenuBackHeader = (e3) => {
            let { onClick: t3, title: r3 } = e3, n3 = (0, a2.useRef)(null);
            return (0, a2.useEffect)(() => {
              n3.current && n3.current.focus();
            }, []), (0, s2.jsx)(o2.Button, {
              variant: "text",
              color: "secondary",
              isBlock: true,
              onClick: t3,
              icon: (0, s2.jsx)(i2.Icon, { variant: "arrowLeft", size: "xxs", className: l2.default.icon }),
              withHover: false,
              className: l2.default.button,
              iconClassName: l2.default.icon,
              ref: n3,
              children: r3
            });
          };
        },
        5556: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.MenuContext = void 0, t2.MenuContext = (0, r2(810).createContext)({
            getItemProps: () => ({}),
            activeIndex: null,
            setActiveIndex: () => {
            },
            setHasFocusInside: () => {
            },
            isOpen: false
          });
        },
        7653: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.MenuHeader = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(1964), o2 = r2(8119), l2 = r2(5189), c2 = r2(7743), u2 = r2(404), f2 = r2(8062), d2 = n2(r2(4455));
          t2.MenuHeader = (e3) => {
            let { title: t3, description: r3, onClose: n3, withDivider: x = true, withClose: p = true } = e3, _ = (0, i2.useFloatingTree)(), m = (0, a2.useCallback)(() => {
              null == n3 || n3(), null == _ || _.events.emit("click");
            }, [n3, null == _ ? void 0 : _.events]);
            return (0, s2.jsxs)(s2.Fragment, {
              children: [
                (0, s2.jsxs)("div", {
                  className: d2.default.header,
                  children: [
                    (t3 || r3) && (0, s2.jsxs)("div", {
                      className: d2.default.textContainer,
                      children: [
                        !!t3 && (0, s2.jsx)(u2.Heading, {
                          variant: "h3",
                          size: "s",
                          weight: "bold",
                          lineClamp: 2,
                          className: d2.default.title,
                          children: t3
                        }),
                        !!r3 && (0, s2.jsx)(c2.Caption, {
                          variant: "span",
                          type: "controls",
                          size: "s",
                          lineClamp: 2,
                          className: d2.default.description,
                          children: r3
                        })
                      ]
                    }),
                    p && (0, s2.jsx)("div", {
                      className: d2.default.close,
                      children: (0, s2.jsx)(o2.Button, {
                        variant: "text",
                        icon: (0, s2.jsx)(l2.Icon, {
                          variant: "close",
                          size: "xs",
                          className: d2.default.closeButtonIcon
                        }),
                        color: "secondary",
                        size: "xxs",
                        radius: "round",
                        onClick: m,
                        withRipple: false,
                        className: d2.default.closeButton
                      })
                    })
                  ]
                }),
                x && (0, s2.jsx)(f2.Divider, { className: d2.default.divider })
              ]
            });
          };
        },
        5515: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.MenuItem = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(1964), o2 = r2(810), l2 = r2(5556), c2 = r2(5853), u2 = r2(8119), f2 = n2(r2(3309)), d2 = (e3) => {
            let {
              label: t3,
              disabled: r3,
              icon: n3,
              children: d3,
              role: x = "menuitem",
              forwardRef: p,
              isSubMenu: _,
              isBlock: m,
              className: v,
              autoFocus: g,
              ...b
            } = e3, y = (0, o2.useId)(), h = null, k = (0, o2.useContext)(c2.PopoverContext), E = (0, o2.useContext)(l2.MenuContext), w = E.isOpen ? E : k, j = (0, i2.useListItem)({ label: r3 ? null : t3 }), O = (0, i2.useFloatingTree)(), R = j.index === w.activeIndex;
            if (n3) {
              let e4 = n3.props && "object" == typeof n3.props ? n3.props : {}, t4 = "className" in e4 && "string" == typeof e4.className ? e4.className : "";
              h = (0, o2.cloneElement)(n3, {
                className: (0, a2.clsx)(t4, f2.default.icon, { [f2.default.icon_disabled]: r3 }),
                key: y
              });
            }
            return (0, s2.jsxs)(u2.Button, {
              ...b,
              autoFocus: g,
              ref: (0, i2.useMergeRefs)([j.ref, p]),
              type: "button",
              role: x,
              variant: "text",
              className: (0, a2.clsx)(f2.default.menuItem, v),
              tabIndex: R ? 0 : -1,
              disabled: r3,
              icon: h,
              withRipple: false,
              "aria-label": t3,
              isBlock: m,
              ...w.getItemProps({
                onClick(e4) {
                  var t4;
                  null == (t4 = b.onClick) || t4.call(b, e4), _ || null == O || O.events.emit("click");
                },
                onFocus(e4) {
                  var t4, r4;
                  null == (t4 = b.onFocus) || t4.call(b, e4), "setHasFocusInside" in w && (null == (r4 = w.setHasFocusInside) || r4.call(w, true));
                }
              }),
              children: [t3, d3]
            });
          };
          t2.MenuItem = (0, o2.forwardRef)((e3, t3) => {
            let { ...r3 } = e3;
            return (0, s2.jsx)(d2, { forwardRef: t3, ...r3 });
          });
        },
        8765: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.MenuMobile = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(1964), o2 = r2(810), l2 = r2(5062), c2 = r2(5928), u2 = r2(7066), f2 = r2(8448), d2 = r2(4771), x = r2(9661), p = r2(5515), _ = n2(r2(5059)), m = n2(r2(3309)), v = (e3) => {
            let {
              className: t3,
              children: r3,
              onShow: n3,
              offsetOptions: c3 = 10,
              open: u3,
              onOpenChange: f3,
              menuRole: p2 = "menu",
              placement: m2 = "bottom",
              isMobile: v2,
              reference: g,
              containerProps: b,
              header: y,
              footer: h,
              listClassName: k,
              menuClassName: E,
              lockScroll: w,
              ...j
            } = e3, O = (0, i2.useFloatingNodeId)(), R = null !== (0, i2.useFloatingParentNodeId)(), { header: C, body: S, reset: P } = (0, o2.useContext)(d2.MenuMobileContext), A = (0, o2.useMemo)(
              () => (0, s2.jsxs)(s2.Fragment, { children: [(0, s2.jsx)(x.MenuSwipeHeader, {}), y, C] }),
              [C, y]
            ), T = v2 && S || r3, H = g.props && "object" == typeof g.props ? g.props : {}, M = (0, o2.cloneElement)(g, {
              onClick: (e4) => {
                P(), "onClick" in H && "function" == typeof H.onClick && H.onClick(e4);
              }
            }), N = (0, o2.useCallback)((e4) => {
              e4.stopPropagation();
            }, []);
            return (0, s2.jsx)(i2.FloatingNode, {
              id: O,
              children: (0, s2.jsxs)(l2.Popover, {
                placement: R ? "right-start" : m2,
                open: u3,
                onOpenChange: f3,
                isNested: R,
                offsetOptions: c3,
                onShow: n3,
                returnFocus: !R,
                isMobile: true,
                lockScroll: w,
                ...j,
                children: [
                  M,
                  (0, s2.jsx)(l2.PopoverContent, {
                    onClick: N,
                    className: (0, a2.clsx)(t3, { [_.default.popoverContentMobile]: v2 }),
                    children: (0, s2.jsxs)("div", {
                      className: (0, a2.clsx)(_.default.menu, _.default.menu_mobile, E),
                      ...b,
                      children: [A, (0, s2.jsx)("div", { className: k, role: p2, children: T }), h]
                    })
                  })
                ]
              })
            });
          };
          t2.MenuMobile = (e3) => {
            let t3 = (0, i2.useFloatingParentNodeId)(), { moveForward: r3, moveBackward: n3 } = (0, o2.useContext)(d2.MenuMobileContext), {
              children: l3,
              onShow: x2,
              label: _2,
              forwardRef: g,
              className: b,
              icon: y,
              size: h = "xs",
              radius: k = "round",
              withRipple: E = false,
              variant: w,
              ariaLabel: j,
              disabled: O,
              open: R,
              "data-test-id": C
            } = e3, S = null !== t3, P = (0, o2.useMemo)(
              () => S ? (0, s2.jsx)(p.MenuItem, {
                icon: y,
                size: h,
                isSubMenu: true,
                disabled: O,
                "data-test-id": C,
                children: (0, s2.jsxs)(s2.Fragment, {
                  children: [
                    _2,
                    S && (0, s2.jsx)(u2.Icon, {
                      "aria-hidden": true,
                      size: "xxs",
                      variant: "menuArrow",
                      className: (0, a2.clsx)(m.default.subMenuArrow, {
                        [m.default.subMenuArrow_disabled]: O
                      })
                    })
                  ]
                })
              }) : (0, s2.jsx)("div", {
                ref: g,
                children: (0, s2.jsx)(c2.Button, {
                  "data-open": R ? "" : void 0,
                  className: (0, a2.clsx)(
                    {
                      [m.default.menuItem]: S,
                      [m.default.rootMenu]: !S,
                      [m.default.rootMenu_onlyIcon]: !S && "text" === w
                    },
                    b
                  ),
                  icon: y,
                  size: h,
                  radius: k,
                  withRipple: E,
                  iconClassName: m.default.rootIcon,
                  variant: w,
                  "aria-label": j,
                  disabled: O,
                  "data-test-id": C,
                  children: _2
                })
              }),
              [S, _2, O, w, j, b, g, y, R, k, h, E, C]
            ), A = (0, o2.useCallback)(() => {
              null == x2 || x2(), r3((0, s2.jsx)(f2.MenuBackHeader, { title: _2, onClick: n3 }), l3);
            }, [x2, r3, _2, n3, l3]);
            return null === t3 ? (0, s2.jsx)(i2.FloatingTree, {
              children: (0, s2.jsx)(d2.MenuMobileProvider, { children: (0, s2.jsx)(v, { ...e3, reference: P }) })
            }) : (0, o2.cloneElement)(P, { onClick: A });
          };
        },
        4771: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.MenuMobileProvider = t2.MenuMobileContext = void 0;
          let n2 = r2(4377), s2 = r2(810);
          t2.MenuMobileContext = (0, s2.createContext)({
            header: [],
            body: [],
            moveForward: () => {
            },
            moveBackward: () => {
            },
            onClose: () => {
            },
            reset: () => {
            }
          }), t2.MenuMobileProvider = (e3) => {
            let { onClose: r3, children: a2 } = e3, [i2, o2] = (0, s2.useState)([]), [l2, c2] = (0, s2.useState)([]), u2 = (0, s2.useCallback)((e4, t3) => {
              o2((t4) => [...t4, e4]), c2((e5) => [...e5, t3]);
            }, []), f2 = (0, s2.useCallback)(() => {
              o2((e4) => e4.slice(0, -1)), c2((e4) => e4.slice(0, -1));
            }, []), d2 = (0, s2.useCallback)(() => {
              o2([]), c2([]);
            }, []), x = (0, s2.useMemo)(
              () => ({ header: i2.at(-1), body: l2.at(-1), moveForward: u2, moveBackward: f2, onClose: r3, reset: d2 }),
              [l2, i2, f2, u2, r3, d2]
            );
            return (0, n2.jsx)(t2.MenuMobileContext.Provider, { value: x, children: a2 });
          };
        },
        9661: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.MenuSwipeHeader = void 0;
          let s2 = r2(4377), a2 = n2(r2(6176));
          t2.MenuSwipeHeader = () => (0, s2.jsx)("div", { className: a2.default.root });
        },
        9430: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Popover = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(1964), o2 = r2(5881), l2 = r2(6544), c2 = r2(5853), u2 = r2(7601), f2 = r2(4395), d2 = n2(r2(7820));
          t2.Popover = (e3) => {
            var t3;
            let {
              children: r3,
              offsetOptions: n3,
              strategy: x,
              placement: p,
              isMobile: _,
              visuallyHiddenDismiss: m,
              positionElement: v,
              transform: g,
              initialOpen: b = false,
              open: y,
              onOpenChange: h,
              disableFloatingStyles: k = false,
              overlayClassName: E,
              style: w,
              returnFocus: j,
              isNested: O = false,
              onShow: R,
              customRoleProps: C,
              portalNode: S,
              isEnabled: P = true,
              arrowProps: A,
              lockScroll: T = true,
              popoverContentRef: H,
              transitionDuration: M = 150
            } = e3, [N, I] = r3, [L, B] = (0, a2.useState)(b), [D, z] = (0, a2.useState)(null), F = (0, a2.useRef)([]), U = (0, a2.useRef)([]), W = (0, i2.useFloatingNodeId)(), V = (0, i2.useFloatingParentNodeId)(), Y = (0, i2.useListItem)(), K = (0, i2.useFloatingTree)(), X = (0, a2.useRef)(null), q = h || B, Q = void 0 !== y, G = (0, a2.useCallback)(() => {
              q(false);
            }, [q]), {
              refs: Z,
              floatingStyles: $,
              context: J
            } = (0, i2.useFloating)({
              nodeId: W,
              open: Q ? y : L,
              onOpenChange: q,
              placement: p,
              middleware: [
                (0, i2.offset)(n3),
                (0, i2.flip)({ crossAxis: null == p ? void 0 : p.includes("end") }),
                (0, i2.shift)({ padding: 5 }),
                ...(null == A ? void 0 : A.isEnabled) ? [(0, i2.arrow)({ element: X })] : []
              ],
              whileElementsMounted: i2.autoUpdate,
              strategy: x,
              transform: g
            }), ee = (0, a2.useId)(), et = (0, a2.useId)(), er = (0, i2.useListNavigation)(J, { listRef: F, activeIndex: D, nested: O, onNavigate: z }), en = (0, i2.useTypeahead)(J, { listRef: U, onMatch: L ? z : void 0, activeIndex: D });
            (0, a2.useEffect)(() => {
              if (!K) return;
              let e4 = () => {
                B(false);
              }, t4 = (e5) => {
                e5.nodeId !== W && e5.parentId === V && B(false);
              };
              return K.events.on("click", e4), K.events.on("menuopen", t4), () => {
                K.events.off("click", e4), K.events.off("menuopen", t4);
              };
            }, [K, W, V, B]), (0, a2.useEffect)(() => {
              L && (null == R || R());
            }, [R, L]), (0, a2.useEffect)(() => {
              L && K && K.events.emit("menuopen", { parentId: V, nodeId: W });
            }, [K, L, W, V]), (0, a2.useLayoutEffect)(() => {
              v && Z.setPositionReference(v);
            }, [Z, v]);
            let { handlers: es } = (0, f2.usePopoverSwipeable)({
              ref: Z.floating,
              onClose: G,
              placement: p,
              disableSwipe: !_,
              swipeableProps: { preventScrollOnSwipe: true }
            }), ea = H ? [Z.setFloating, H] : [Z.setFloating, null == es ? void 0 : es.ref], ei = (0, i2.useMergeRefs)(ea), eo = (0, i2.useRole)(J, C), el = (0, i2.useDismiss)(J, { referencePress: true }), ec = (0, i2.useClick)(J, { enabled: P, toggle: !O, ignoreMouse: O }), eu = (0, i2.useHover)(J, {
              enabled: O && P,
              handleClose: (0, i2.safePolygon)({ blockPointerEvents: true })
            }), ef = (0, a2.useCallback)((e4) => {
              e4.stopPropagation();
            }, []), {
              getReferenceProps: ed,
              getFloatingProps: ex,
              getItemProps: ep
            } = (0, i2.useInteractions)([eo, el, ec, eu, er, en]), [e_, em] = (() => {
              switch (p) {
                case "bottom":
                default:
                  return ["translate(0, 10%)", "translate(0, 0)"];
                case "right":
                  if ("undefined" != typeof document && "rtl" === document.dir)
                    return ["translateX(-5%)", "translateX(0)"];
                  return ["translateX(5%)", "translateX(0)"];
              }
            })(), { isMounted: ev, styles: eg } = (0, i2.useTransitionStyles)(J, {
              initial: { opacity: 0, transform: e_ },
              open: { opacity: 1, transform: em },
              duration: M
            }), eb = (0, i2.useMergeRefs)([Z.setReference, Y.ref]), ey = N && (0, a2.cloneElement)(N, {
              ref: eb,
              ...ed({ onClick: null == (t3 = N.props) ? void 0 : t3.onClick }),
              key: ee
            }), eh = (0, a2.useMemo)(
              () => _ ? { ...k ? {} : $, ...w, bottom: 0, left: 0, right: 0, top: "auto", transform: "none" } : { ...k ? {} : $, ...w },
              [_, k, $, w]
            ), ek = (0, a2.useMemo)(() => {
              if (null == A ? void 0 : A.isEnabled) return (0, s2.jsx)(u2.PopoverArrow, { ref: X, context: J, ...A });
            }, [A, J]), eE = {
              ref: ei,
              style: { ...eg, ...eh },
              ...ex(),
              onMouseDown: H || null == es ? void 0 : es.onMouseDown,
              arrow: ek,
              children: (0, a2.cloneElement)(I.props.children, { onClose: G, key: et })
            }, ew = (0, a2.cloneElement)(I, eE), ej = (0, a2.useMemo)(
              () => ({ activeIndex: D, setActiveIndex: z, getItemProps: ep, isOpen: L }),
              [D, ep, L]
            ), eO = O ? -1 : 0;
            return (0, s2.jsxs)(c2.PopoverContext.Provider, {
              value: ej,
              children: [
                ey,
                (0, s2.jsx)(i2.FloatingList, {
                  elementsRef: F,
                  children: ev && (0, s2.jsxs)(i2.FloatingPortal, {
                    root: S,
                    children: [
                      (0, s2.jsx)(i2.FloatingOverlay, { className: (0, o2.clsx)(d2.default.overlay, E), onClick: ef }),
                      (0, s2.jsx)(i2.FloatingFocusManager, {
                        context: J,
                        returnFocus: j,
                        initialFocus: eO,
                        visuallyHiddenDismiss: m,
                        children: (0, s2.jsx)(l2.RemoveScroll, { enabled: T && L, children: ew })
                      })
                    ]
                  })
                })
              ]
            });
          };
        },
        7601: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverArrow = t2.PopoverArrowComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(9110), l2 = r2(4601), c2 = n2(r2(4123)), u2 = { top: "", left: "rotate(-90deg)", bottom: "rotate(180deg)", right: "rotate(90deg)" };
          t2.PopoverArrowComponent = (e3) => {
            let {
              forwardRef: t3,
              className: r3,
              context: n3,
              width: i3 = 14,
              height: f2 = 7,
              tipRadius: d2 = 0,
              customClipPath: x,
              staticOffset: p,
              style: { transform: _, ...m } = {},
              isEnabled: v,
              ...g
            } = e3, {
              placement: b,
              elements: { floating: y },
              middlewareData: { arrow: h }
            } = n3, { state: k, toggleTrue: E } = (0, l2.useToggle)(false);
            if ((0, o2.useIsomorphicEffect)(() => {
              y && "rtl" === getComputedStyle(y).direction && E();
            }, [y, E]), !y || !v)
              return null;
            let w = i3 / 2 * (-(d2 / 8) + 1), j = f2 / 2 * d2 / 4, [O, R] = b.split("-"), C = p && "end" === R ? "right" : "left";
            p && k && (C = "end" === R ? "left" : "right");
            let S = (null == h ? void 0 : h.x) ? p || h.x : "", P = (null == h ? void 0 : h.y) ? p || h.y : "", A = u2[O], T = x || '"M0,0' + " H".concat(i3) + " L".concat(i3 - w, ",").concat(f2 - j) + " Q".concat(i3 / 2, ",").concat(f2, " ").concat(w, ",").concat(f2 - j) + ' Z"', H = {
              [C]: S,
              [p && "end" === R ? "bottom" : "top"]: P,
              [O]: "100%",
              transform: "".concat(A).concat(null != _ ? _ : ""),
              "--arrow-width": "".concat(i3, "px"),
              "--arrow-clip-path": T,
              ...m
            };
            return (0, s2.jsx)("div", { ...g, className: (0, a2.clsx)(c2.default.root, r3), ref: t3, style: H });
          }, t2.PopoverArrow = (0, i2.forwardRef)(
            (e3, r3) => (0, s2.jsx)(t2.PopoverArrowComponent, { forwardRef: r3, ...e3 })
          );
        },
        1688: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverContent = t2.PopoverContentComponent = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = n2(r2(5909));
          t2.PopoverContentComponent = (e3) => {
            let { className: t3, children: r3, forwardRef: n3, arrow: l2, ...c2 } = e3;
            return (0, s2.jsxs)("div", {
              className: (0, i2.clsx)(o2.default.root, t3),
              ref: n3,
              ...c2,
              children: [r3, (0, a2.isValidElement)(l2) && l2]
            });
          }, t2.PopoverContent = (0, a2.forwardRef)(
            (e3, r3) => (0, s2.jsx)(t2.PopoverContentComponent, { forwardRef: r3, ...e3 })
          );
        },
        5853: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverContext = void 0, t2.PopoverContext = (0, r2(810).createContext)({
            getItemProps: () => ({}),
            activeIndex: null,
            setActiveIndex: () => {
            },
            isOpen: false
          });
        },
        5062: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverContent = t2.Popover = void 0;
          var n2 = r2(9430);
          Object.defineProperty(t2, "Popover", {
            enumerable: true,
            get: function() {
              return n2.Popover;
            }
          });
          var s2 = r2(1688);
          Object.defineProperty(t2, "PopoverContent", {
            enumerable: true,
            get: function() {
              return s2.PopoverContent;
            }
          });
        },
        7743: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Caption = t2.CaptionComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(4721), l2 = n2(r2(3641));
          t2.CaptionComponent = (e3) => {
            let {
              forwardRef: t3,
              variant: r3,
              type: n3 = "text",
              size: i3 = "s",
              className: c2,
              children: u2,
              weight: f2 = "medium",
              ...d2
            } = e3;
            return (0, s2.jsx)(o2.Typography, {
              variant: r3,
              ref: t3,
              className: (0, a2.clsx)(
                l2.default.root,
                l2.default["root_".concat(n3, "_").concat(i3)],
                l2.default["root_weight_".concat(f2)],
                c2
              ),
              ...d2,
              children: u2
            });
          }, t2.Caption = (0, i2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.CaptionComponent, { forwardRef: r3, ...e3 }));
        },
        404: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Heading = t2.HeadingComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(4721), l2 = n2(r2(5153));
          t2.HeadingComponent = (e3) => {
            let { forwardRef: t3, variant: r3, weight: n3 = "bold", size: i3 = "s", className: c2, children: u2, ...f2 } = e3;
            return (0, s2.jsx)(o2.Typography, {
              variant: r3,
              ref: t3,
              className: (0, a2.clsx)(
                l2.default.root,
                l2.default["root_size_".concat(i3)],
                l2.default["root_weight_".concat(n3)],
                c2
              ),
              ...f2,
              children: u2
            });
          }, t2.Heading = (0, i2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.HeadingComponent, { forwardRef: r3, ...e3 }));
        },
        4721: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Typography = t2.TypographyComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = n2(r2(5818));
          function l2(e3) {
            let { forwardRef: t3, style: r3, className: n3, children: i3, variant: l3, lineClamp: c2, ...u2 } = e3, f2 = c2 && "string" == typeof i3 ? i3 : void 0;
            return (0, s2.jsx)(l3, {
              style: { ...r3, WebkitLineClamp: c2 },
              ref: t3,
              title: f2,
              className: (0, a2.clsx)(
                o2.default.root,
                {
                  [o2.default.root_clamp]: c2 && c2 > 0,
                  [o2.default.root_clamp_oneline]: c2 && 1 === c2,
                  [o2.default.root_clamp_multiline]: c2 && c2 > 1
                },
                n3
              ),
              ...u2,
              children: i3
            });
          }
          t2.TypographyComponent = l2, t2.Typography = (0, i2.forwardRef)((e3, t3) => (0, s2.jsx)(l2, { forwardRef: t3, ...e3 }));
        },
        1964: (e2) => {
          e2.exports = s;
        },
        352: (e2) => {
          e2.exports = a;
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(i, 2));
        }
      }, l = {};
      function c(e2) {
        var t2 = l[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = l[e2] = { exports: {} };
        return o[e2].call(r2.exports, r2, r2.exports, c), r2.exports;
      }
      c.d = (e2, t2) => {
        for (var r2 in t2) c.o(t2, r2) && !c.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, c.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), c.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      }, c.nc = void 0;
      var u = {};
      (() => {
        Object.defineProperty(u, "X$", { value: true }), u.sN = u.ti = u.v2 = void 0;
        var e2 = c(2647);
        Object.defineProperty(u, "v2", {
          enumerable: true,
          get: function() {
            return e2.Menu;
          }
        });
        var t2 = c(7653);
        Object.defineProperty(u, "ti", {
          enumerable: true,
          get: function() {
            return t2.MenuHeader;
          }
        });
        var r2 = c(5515);
        Object.defineProperty(u, "sN", {
          enumerable: true,
          get: function() {
            return r2.MenuItem;
          }
        });
      })();
      var f = u.v2;
      u.ti;
      var d = u.sN;
      u.X$;
    },
    61993: (e, t, r) => {
      "use strict";
      r.d(t, { PlayingAnimation: () => l });
      var n = r(54486), s = r(50420), a = r(31500), i = r(8607), o = r.n(i);
      let l = (e2) => {
        let { className: t2, stopAnimation: r2 } = e2;
        return (0, n.jsx)("div", {
          className: (0, s.$)(o().root, { [o().root_stopAnimation]: r2 }, t2),
          ...(0, a.Am)(a.S7.PLAYING_ANIMATION)
        });
      };
    },
    62010: (e, t, r) => {
      "use strict";
      r.d(t, { PlusPaywallButton: () => d });
      var n = r(54486), s = r(50420), a = r(31500), i = r(8817), o = r(77881), l = r(97800), c = r(60440), u = r(11718), f = r.n(u);
      let d = (e2) => {
        let { className: t2, text: r2, analyticsNavigatedCallback: u2 } = e2, {
          settings: { isMobile: d2 },
          paywall: x
        } = (0, c.useStore)(), p = (0, i.c)((e3) => {
          x.openModal(), e3.stopPropagation(), null == u2 || u2();
        });
        return d2 ? (0, n.jsx)(o.$, {
          onClick: p,
          className: (0, s.$)(f().root, t2),
          color: "plus",
          size: "l",
          radius: "xxxl",
          children: (0, n.jsx)(l.Caption, {
            className: f().title,
            weight: "bold",
            variant: "div",
            size: "l",
            children: r2
          })
        }) : (0, n.jsx)(o.$, {
          onClick: p,
          className: (0, s.$)(f().root, t2),
          color: "plus",
          size: "m",
          radius: "xxxl",
          ...(0, a.Am)(a.S7.PLUS_PAYWALL_BUTTON),
          children: (0, n.jsx)(l.Caption, {
            className: f().title,
            weight: "bold",
            variant: "div",
            size: "m",
            children: r2
          })
        });
      };
    },
    62108: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuAlbumProgressItem: () => f });
      var n = r(54486), s = r(28303), a = r(61910), i = r(47713), o = r(31500), l = r(5956), c = r(61958), u = r(60440);
      let f = (0, s.PA)((e2) => {
        let { isFinished: t2, onClick: r2, className: s2 } = e2, { user: f2 } = (0, u.useStore)(), d = (0, a.useMemo)(
          () => t2 ? (0, n.jsx)(i.A, { id: "interface-actions.mark-all-non-listened" }) : (0, n.jsx)(i.A, { id: "interface-actions.mark-all-listened" }),
          [t2]
        );
        return (0, n.jsx)(c.Dr, {
          className: s2,
          onClick: r2,
          icon: (0, n.jsx)(l.Icon, { variant: "check", size: "xxs" }),
          disabled: !f2.isAuthorized,
          ...(0, o.Am)(o.S7.CONTEXT_MENU_MARK_ALL_LISTENED_BUTTON),
          children: d
        });
      });
    },
    62443: (e, t, r) => {
      "use strict";
      r.d(t, { e: () => l });
      var n, s = r(61910), a = {
        810: (e2) => {
          e2.exports = n || (n = r.t(s, 2));
        }
      }, i = {}, o = {};
      (() => {
        Object.defineProperty(o, "__esModule", { value: true }), o.useToggle = void 0;
        let e2 = (function e3(t2) {
          var r2 = i[t2];
          if (void 0 !== r2) return r2.exports;
          var n2 = i[t2] = { exports: {} };
          return a[t2](n2, n2.exports, e3), n2.exports;
        })(810);
        o.useToggle = (t2) => {
          let [r2, n2] = (0, e2.useState)(t2);
          (0, e2.useEffect)(() => {
            n2(t2);
          }, [t2]);
          let s2 = (0, e2.useCallback)(() => {
            n2((e3) => !e3);
          }, []), a2 = (0, e2.useCallback)(() => {
            n2(true);
          }, []), i2 = (0, e2.useCallback)(() => {
            n2(false);
          }, []);
          return { state: r2, toggle: s2, setState: n2, toggleTrue: a2, toggleFalse: i2 };
        };
      })(), o.__esModule;
      var l = o.useToggle;
    },
    62624: (e) => {
      e.exports = {
        icon: "MainSuspenseLoader_icon__MceTD",
        "animate-pop": "MainSuspenseLoader_animate-pop__vkpff",
        heartbeat: "MainSuspenseLoader_heartbeat__6RDpM"
      };
    },
    63886: (e) => {
      e.exports = { root: "TextShimmer_root__qqWug", text: "TextShimmer_text__z8oN9" };
    },
    64434: (e, t, r) => {
      "use strict";
      r.d(t, { RSCCacheScripts: () => n }), r(54486), r(61910), r(67454), r(95723), r(49124);
      let n = (e2) => {
        let { nonce: t2, serverDetectedLanguage: r2, hostTld: n2, env: s } = e2;
        return null;
      };
    },
    64794: (e) => {
      e.exports = {
        root: "TooltipWithTitle_root__7jLY3",
        text: "TooltipWithTitle_text__ElBtq",
        description: "TooltipWithTitle_description__HsGcR"
      };
    },
    65250: (e) => {
      e.exports = {
        root: "PlusModal_root__RA4rI",
        root_error: "PlusModal_root_error__BYJfM",
        root_mobile: "PlusModal_root_mobile__pEOEu",
        header: "PlusModal_header__Xj_1a",
        content: "PlusModal_content__QHgFY",
        contentWrapper: "PlusModal_contentWrapper__dYFpI",
        growContainer: "PlusModal_growContainer__eDnbY",
        growContainer_withoutPaddings: "PlusModal_growContainer_withoutPaddings__H4fPH",
        buttons: "PlusModal_buttons___Gy1Y",
        text: "PlusModal_text__ioQgs",
        title: "PlusModal_title__znUSU",
        description: "PlusModal_description__PjqMm",
        link: "PlusModal_link__va_hh",
        linkContainer: "PlusModal_linkContainer__5NaN1",
        linkArrow: "PlusModal_linkArrow__xDKKi"
      };
    },
    65508: (e) => {
      e.exports = {
        button: "PlusModalButton_button__Ayw3M",
        shimmer: "PlusModalButton_shimmer__JDPqE",
        button_mobile: "PlusModalButton_button_mobile__V2Et4",
        shimmer_mobile: "PlusModalButton_shimmer_mobile__ndcfv",
        text: "PlusModalButton_text__GRAK7"
      };
    },
    65674: (e) => {
      e.exports = {
        root: "DevPanel_root__Gu7qn",
        panel: "DevPanel_panel__LnoO2",
        group: "DevPanel_group__yDdVt",
        block: "DevPanel_block__SJ_76",
        changeLanguageBlock: "DevPanel_changeLanguageBlock__WGj1D",
        generativeBlock: "DevPanel_generativeBlock__CwcM2",
        changeLanguageInput: "DevPanel_changeLanguageInput__nQ01C",
        generativeInput: "DevPanel_generativeInput__hYqt3"
      };
    },
    65749: (e, t, r) => {
      "use strict";
      r.d(t, { N: () => c });
      var n, s = r(61910), a = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        4814: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "buOTZq_TKQOVyjMLrXvB",
            block: "BSPmaubc8UL2KHOMLV4A",
            iconContainer: "VUb2BxfgkGQhG1RDQGwF",
            iconOnly: "WhDaA5aAfZSjxalYb_Ex",
            flexIcon: "vIGeuYz4Cf60Cnuq3WKA",
            icon_position_left: "GoUQfg7mJlSkcbAZ28Rj",
            icon_position_right: "TXa2RKc_Hf0QPdmUDMwI"
          };
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        3937: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Link = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = n2(r2(4814)), l2 = (e3) => {
            let {
              component: t3 = (0, s2.jsx)("a", {}),
              block: r3,
              target: n3,
              rel: l3,
              href: c2,
              forwardRef: u,
              iconPosition: f = "left",
              flexIcon: d,
              icon: x,
              className: p,
              children: _,
              textClassName: m = "",
              containerClassName: v,
              ...g
            } = e3, b = (0, a2.useId)(), y = !a2.Children.count(_), h = "left" === f, k = null;
            if (void 0 !== x) {
              var E;
              k = (0, a2.cloneElement)(x, {
                className: (0, i2.clsx)(
                  o2.default.icon,
                  { [o2.default["icon_position_".concat(f)]]: !y && f },
                  null == (E = x.props) ? void 0 : E.className
                ),
                key: b
              });
            }
            let w = (0, a2.useMemo)(
              () => x ? (0, s2.jsxs)("div", {
                className: (0, i2.clsx)(o2.default.iconContainer, v),
                children: [h && k, !y && (0, s2.jsx)("span", { className: m, children: _ }), !h && k]
              }) : _,
              [_, v, x, h, y, k, m]
            );
            return (0, a2.cloneElement)(
              t3,
              {
                ref: u,
                target: n3,
                rel: "_blank" === n3 && void 0 === l3 ? "noopener noreferrer" : l3,
                href: c2,
                className: (0, i2.clsx)(
                  o2.default.root,
                  { [o2.default.block]: r3, [o2.default.flexIcon]: x && d, [o2.default.iconOnly]: x && y },
                  p
                ),
                ...g,
                ...t3.props
              },
              w
            );
          };
          t2.Link = (0, a2.forwardRef)((e3, t3) => (0, s2.jsx)(l2, { forwardRef: t3, ...e3 }));
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(s, 2));
        }
      }, i = {};
      function o(e2) {
        var t2 = i[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = i[e2] = { exports: {} };
        return a[e2].call(r2.exports, r2, r2.exports, o), r2.exports;
      }
      o.d = (e2, t2) => {
        for (var r2 in t2) o.o(t2, r2) && !o.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, o.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), o.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var l = {};
      (() => {
        Object.defineProperty(l, "X", { value: true }), l.r = void 0;
        var e2 = o(3937);
        Object.defineProperty(l, "r", {
          enumerable: true,
          get: function() {
            return e2.Link;
          }
        });
      })();
      var c = l.r;
      l.X;
    },
    66154: (e) => {
      e.exports = {
        buttonArrow: "EntityCard_buttonArrow__ussa7",
        titleLink: "EntityCard_titleLink__3ucPa",
        titleText: "EntityCard_titleText___EU9t",
        root: "EntityCard_root__HNsWx",
        root_disabled: "EntityCard_root_disabled__qdBaH",
        ripple: "EntityCard_ripple__iMHNo",
        playButtonCell: "EntityCard_playButtonCell__AYoR5",
        controlsBarCell: "EntityCard_controlsBarCell__GpbEX",
        text: "EntityCard_text__hChwj"
      };
    },
    67648: (e, t, r) => {
      "use strict";
      r.d(t, { d: () => l });
      var n, s = r(61910), a = {
        810: (e2) => {
          e2.exports = n || (n = r.t(s, 2));
        }
      }, i = {}, o = {};
      (() => {
        Object.defineProperty(o, "__esModule", { value: true }), o.useForceUpdateRef = void 0;
        let e2 = (function e3(t2) {
          var r2 = i[t2];
          if (void 0 !== r2) return r2.exports;
          var n2 = i[t2] = { exports: {} };
          return a[t2](n2, n2.exports, e3), n2.exports;
        })(810);
        o.useForceUpdateRef = () => {
          let [t2, r2] = (0, e2.useState)(null);
          return [
            t2,
            (0, e2.useCallback)((e3) => {
              r2((t3) => t3 !== e3 ? e3 : t3);
            }, [])
          ];
        };
      })(), o.__esModule;
      var l = o.useForceUpdateRef;
    },
    68014: (e, t, r) => {
      "use strict";
      r.d(t, { DevPanel: () => I });
      var n = r(54486), s = r(28303), a = r(61910), i = r(77881), o = r(62901), l = r(67454), c = r(88416), u = r(60440), f = r(90461), d = r(65674), x = r.n(d), p = r(43426), _ = r(5956), m = r(32692), v = r(93666), g = r(97800), b = r(50420), y = r(63930), h = r(19009), k = r(98313), E = r(92750), w = r.n(E);
      let j = (0, s.PA)((e2) => {
        let { experiment: t2 = { name: "", value: {} }, readOnly: r2, deleteMode: s2 } = e2, { experiments: o2 } = (0, u.useStore)(), d2 = (0, c.useContainer)().get(l.oo), x2 = (0, a.useRef)(null), p2 = (0, a.useRef)(null), _2 = o2.overwrittenExperiments, m2 = (0, a.useCallback)(
          (e3) => {
            var t3, r3, n2;
            let s3;
            e3.preventDefault();
            let a2 = Object.fromEntries(new FormData(e3.currentTarget));
            if (!a2.name || !a2.group) return;
            try {
              s3 = JSON.parse(String(a2.value || "{}"));
            } catch (e4) {
              null == (r3 = p2.current) || r3.setCustomValidity("Невалидный JSON в поле value"), null == (n2 = p2.current) || n2.reportValidity();
              return;
            }
            null == (t3 = x2.current) || t3.reset();
            let i2 = (0, k.jU)({ name: String(a2.name), group: String(a2.group), value: s3 });
            d2.set(f.c.OverwrittenExperiments, { ...Object.fromEntries((0, y.HO)(_2)), ...i2 }), o2.updateOverwrittenExperiments(a2.name, i2[a2.name]);
          },
          [d2, _2, o2]
        ), v2 = (0, a.useCallback)(() => {
          let e3 = Object.fromEntries((0, y.HO)(_2));
          delete e3[t2.name], o2.deleteOverwrittenExperiments(t2.name), d2.set(f.c.OverwrittenExperiments, { ...e3 });
        }, [_2, t2.name, o2, d2]), g2 = (0, a.useCallback)(() => {
          var e3, t3;
          null == (e3 = p2.current) || e3.setCustomValidity(""), null == (t3 = p2.current) || t3.reportValidity();
        }, []);
        return (0, n.jsxs)("form", {
          className: w().overrideForm,
          onSubmit: m2,
          ref: x2,
          children: [
            (0, n.jsx)(h.p, {
              containerClassName: w().overrideInput,
              type: "text",
              name: "name",
              placeholder: "Experiment name",
              required: true,
              defaultValue: t2.name,
              readOnly: r2
            }),
            (0, n.jsx)(h.p, {
              containerClassName: w().overrideInput,
              type: "text",
              name: "group",
              placeholder: "Experiment group",
              required: true,
              defaultValue: t2.value.group
            }),
            (0, n.jsx)(h.p, {
              ref: p2,
              containerClassName: w().overrideInput,
              inputClassName: w().valueInput,
              type: "text",
              name: "value",
              placeholder: "Optional experiment value in JSON format",
              defaultValue: JSON.stringify(t2.value.value),
              onInput: g2
            }),
            (0, n.jsx)(i.$, {
              className: (0, b.$)({ [w().submitButton]: !s2 }),
              size: "xxs",
              type: "submit",
              children: s2 ? "Обновить эксперимент" : "Переопределить эксперимент"
            }),
            s2 && (0, n.jsx)(i.$, { size: "xxs", type: "submit", onClick: v2, children: "Удалить эксперимент" })
          ]
        });
      }), O = { className: w().closeModalButton }, R = (0, s.PA)(() => {
        let {
          modals: { overwrittenExperimentsModal: e2 },
          experiments: t2
        } = (0, u.useStore)(), { formatMessage: r2 } = (0, p.A)(), s2 = (0, a.useCallback)(() => {
          window.location.reload();
        }, []), o2 = Array.from(t2.overwrittenExperiments, (e3) => {
          let [t3, r3] = e3;
          return { name: t3, value: r3 };
        });
        return (0, n.jsxs)(m.a, {
          className: w().root,
          headerClassName: w().header,
          contentClassName: w().content,
          closeButtonProps: O,
          title: "Переопределение экспериментов",
          header: (0, n.jsx)(
            v.m_,
            {
              offsetOptions: 4,
              placement: "left",
              text: "Перезагрузить страницу",
              children: (0, n.jsx)(i.$, {
                className: w().reloadButton,
                size: "xxs",
                radius: "round",
                icon: (0, n.jsx)(_.Icon, { variant: "reset", size: "xxs" }),
                onClick: s2
              })
            },
            "reloadTooltip"
          ),
          open: e2.isOpened,
          onOpenChange: e2.onOpenChange,
          onClose: e2.close,
          size: "fitContent",
          placement: "center",
          labelClose: r2({ id: "interface-actions.close" }),
          children: [
            (0, n.jsx)(j, {}),
            (0, n.jsx)(g.Heading, {
              variant: "h1",
              size: "s",
              weight: "bold",
              className: w().heading,
              lineClamp: 2,
              children: "Список переопределенных экспериментов"
            }),
            (0, n.jsxs)("ul", {
              className: w().experimentsList,
              children: [
                o2.map(
                  (e3) => (0, n.jsx)(
                    "li",
                    {
                      className: w().overridedExperiment,
                      children: (0, n.jsx)(j, { experiment: e3, readOnly: true, deleteMode: true })
                    },
                    e3.name
                  )
                ),
                0 === o2.length && (0, n.jsx)("li", {
                  className: w().overridedExperiment,
                  children: (0, n.jsx)(g.Caption, {
                    variant: "span",
                    size: "m",
                    weight: "medium",
                    lineClamp: 2,
                    children: "Нет переопределенных экспериментов"
                  })
                })
              ]
            })
          ]
        });
      });
      var C = r(12126);
      let S = () => {
        let [e2, t2] = (0, a.useState)(false), r2 = (0, a.useCallback)(() => {
          t2(!e2), document.documentElement.setAttribute("dir", e2 ? "ltr" : "rtl");
        }, [e2, t2]);
        return (0, n.jsxs)(i.$, {
          size: "xxs",
          className: x().block,
          variant: "default",
          isBlock: true,
          onClick: r2,
          children: ["Поменять на ", e2 ? "LTR" : "RTL"]
        });
      }, P = () => {
        let e2 = (0, c.useContainer)().get(l.oo), t2 = "on" === e2.get(f.c.AllowAnalyticsLogs), r2 = (0, a.useCallback)(() => {
          e2.set(f.c.AllowAnalyticsLogs, t2 ? "default" : "on"), window.location.reload();
        }, [e2, t2]);
        return (0, n.jsxs)(i.$, {
          size: "xxs",
          className: x().block,
          variant: "default",
          isBlock: true,
          onClick: r2,
          children: [t2 ? "Выключить" : "Включить", " логи евгена"]
        });
      }, A = () => {
        let { isFuture: e2, toggleFuture: t2 } = (0, C.useFuture)();
        return (0, n.jsxs)(i.$, {
          size: "xxs",
          className: x().block,
          variant: "default",
          isBlock: true,
          onClick: t2,
          children: [e2 ? "Выключить" : "Включить", " недоступные функции"]
        });
      }, T = () => {
        let e2 = (0, c.useContainer)().get(l.oo), t2 = e2.get(f.c.UseNewCorrespondenceBetweenQualityParams), r2 = (0, a.useCallback)(() => {
          e2.set(f.c.UseNewCorrespondenceBetweenQualityParams, !t2), window.location.reload();
        }, [e2, t2]);
        return (0, n.jsxs)(i.$, {
          size: "xxs",
          className: x().block,
          variant: "default",
          isBlock: true,
          onClick: r2,
          children: [t2 ? "Выключить" : "Включить", " aac/192 в hq, he-acc в nq"]
        });
      }, H = () => {
        let e2 = (0, c.useContainer)().get(l.oo), t2 = e2.get(f.c.EnableMetricsPluginDebugMode), r2 = (0, a.useCallback)(() => {
          e2.set(f.c.EnableMetricsPluginDebugMode, !t2), window.location.reload();
        }, [e2, t2]);
        return (0, n.jsxs)(i.$, {
          size: "xxs",
          className: x().block,
          variant: "default",
          isBlock: true,
          onClick: r2,
          children: [t2 ? "Выключить" : "Включить", " debug режим плагина метрик"]
        });
      }, M = (0, s.PA)((e2) => {
        let { togglePanel: t2 } = e2, {
          modals: { overwrittenExperimentsModal: r2 }
        } = (0, u.useStore)(), s2 = (0, a.useCallback)(() => {
          r2.open(), t2();
        }, [r2, t2]);
        return (0, n.jsx)(i.$, {
          size: "xxs",
          className: x().block,
          variant: "default",
          isBlock: true,
          onClick: s2,
          children: "Переопределение экспериментов"
        });
      }), N = (e2) => {
        let { togglePanel: t2 } = e2;
        return (0, n.jsxs)("div", {
          className: x().panel,
          children: [
            (0, n.jsx)(S, {}),
            false,
            (0, n.jsx)(P, {}),
            (0, n.jsx)(A, {}),
            (0, n.jsx)(T, {}),
            (0, n.jsx)(H, {}),
            (0, n.jsx)(M, { togglePanel: t2 })
          ]
        });
      }, I = () => {
        let e2 = (0, c.useContainer)().get(l.P0).get(o.qV), [t2, r2] = (0, a.useState)(false), s2 = (0, a.useCallback)(() => r2((e3) => !e3), []);
        return e2 ? (0, n.jsxs)(n.Fragment, {
          children: [
            (0, n.jsxs)("div", {
              className: x().root,
              children: [
                (0, n.jsx)(i.$, { size: "xxs", onClick: s2, children: "dev" }),
                t2 && (0, n.jsx)(N, { togglePanel: s2 })
              ]
            }),
            (0, n.jsx)(R, {})
          ]
        }) : null;
      };
    },
    68098: (e, t, r) => {
      "use strict";
      r.d(t, { DisclaimerModal: () => f });
      var n = r(54486), s = r(28303), a = r(31500), i = r(32692), o = r(60440), l = r(52742), c = r(16934), u = r.n(c);
      let f = (0, s.PA)(() => {
        let {
          disclaimerModalState: e2,
          modals: { disclaimerModal: t2 }
        } = (0, o.useStore)();
        return (0, n.jsx)(i.a, {
          size: "fitContent",
          placement: "center",
          open: t2.isOpened,
          onOpenChange: t2.onOpenChange,
          onClose: t2.close,
          showHeader: false,
          className: u().root,
          contentClassName: u().content,
          overlayColor: "full",
          containerProps: (0, a.Am)(a.OA.disclaimer.DISCLAIMER_MODAL),
          closeOnOutsidePress: e2.shouldCloseModalOnOutsidePress,
          escapeKey: e2.shouldCloseModalOnEscape,
          children: (0, n.jsx)(l.Disclaimer, { modalState: e2, onClose: t2.close })
        });
      });
    },
    68300: (e) => {
      e.exports = {
        backdrop: "BrandedPlaylistHeader_backdrop__hLImj",
        title: "BrandedPlaylistHeader_title__gPU9U",
        title_show: "BrandedPlaylistHeader_title_show__e4u0h",
        show: "BrandedPlaylistHeader_show__42bNL",
        title_withOffset: "BrandedPlaylistHeader_title_withOffset__QppO0",
        root: "BrandedPlaylistHeader_root__jXK4F",
        root_withChildren: "BrandedPlaylistHeader_root_withChildren__6BMwV",
        root_sticky: "BrandedPlaylistHeader_root_sticky__E_n81",
        root_blurWithTitle: "BrandedPlaylistHeader_root_blurWithTitle__lmykd",
        child: "BrandedPlaylistHeader_child__35wjg",
        child_show: "BrandedPlaylistHeader_child_show__Uvbef",
        container: "BrandedPlaylistHeader_container__s66Ay",
        container_withMultipleChildren: "BrandedPlaylistHeader_container_withMultipleChildren__76B6E",
        header: "BrandedPlaylistHeader_header__jdTQJ",
        actions: "BrandedPlaylistHeader_actions__we7tI",
        leftBlock: "BrandedPlaylistHeader_leftBlock__iSsfy",
        buttonClose: "BrandedPlaylistHeader_buttonClose__WXaMz"
      };
    },
    68554: (e) => {
      e.exports = {
        animation_scaled: "PinButton_animation_scaled__Aj6LA",
        scale: "PinButton_scale__nyvJS",
        animation_unscaled: "PinButton_animation_unscaled__QM3sC",
        unscale: "PinButton_unscale__a8LwS"
      };
    },
    69191: (e) => {
      e.exports = { root: "TabCoversShimmers_root__0Uskz", cover: "TabCoversShimmers_cover__HZu32" };
    },
    69672: (e, t, r) => {
      "use strict";
      r.d(t, { PaywallFAQ: () => c });
      var n = r(54486), s = r(50420), a = r(47713), i = r(97800), o = r(46144), l = r.n(o);
      let c = (e2) => {
        let { className: t2, children: r2, ...o2 } = e2;
        return (0, n.jsxs)("section", {
          className: (0, s.$)(l().root, t2),
          ...o2,
          children: [
            (0, n.jsx)(i.Heading, {
              className: l().title,
              variant: "h2",
              size: "xxl",
              children: (0, n.jsx)(a.A, { id: "faq.title", values: { nbsp: " " } })
            }),
            (0, n.jsx)("div", { className: l().content, children: r2 })
          ]
        });
      };
    },
    70588: (e) => {
      e.exports = { root: "NavigationControls_root__V2A3_" };
    },
    70692: (e) => {
      e.exports = {
        control: "CarouselWithArrows_control__3uyYB",
        list: "CarouselWithArrows_list__2f6lz",
        buttons: "CarouselWithArrows_buttons__fW_Dp",
        root: "CarouselWithArrows_root__RreSk",
        root_arrowLeft_hidden: "CarouselWithArrows_root_arrowLeft_hidden__WmoMn",
        root_arrowRight_hidden: "CarouselWithArrows_root_arrowRight_hidden__sQTGA",
        root_arrow_hidden: "CarouselWithArrows_root_arrow_hidden__sltkz",
        control_left: "CarouselWithArrows_control_left__GrTcO",
        control_right: "CarouselWithArrows_control_right__Si_BV",
        root_carouselBetweenArrows: "CarouselWithArrows_root_carouselBetweenArrows___aN_d",
        wrapper: "CarouselWithArrows_wrapper__Kezgl",
        carousel: "CarouselWithArrows_carousel__gm5sM",
        important: "CarouselWithArrows_important__ZFlvq"
      };
    },
    71262: (e) => {
      e.exports = { root: "MaskedImage_root__Dquqg" };
    },
    71710: (e) => {
      e.exports = {
        root: "PaywallFooter_root__L_WxQ",
        link: "PaywallFooter_link__rbIbe",
        important: "PaywallFooter_important__bAbYb",
        list: "PaywallFooter_list__WeuCr",
        list_primary: "PaywallFooter_list_primary__A6hNR",
        list_secondary: "PaywallFooter_list_secondary__QH2qi",
        item: "PaywallFooter_item__4rY_9",
        ageRestriction: "PaywallFooter_ageRestriction__bOKoH"
      };
    },
    72724: (e) => {
      e.exports = {
        root: "CarouselControls_root__E_hwc",
        control: "CarouselControls_control__L8t4i",
        control_hidden: "CarouselControls_control_hidden__pLrn6",
        control_withSecondaryColor: "CarouselControls_control_withSecondaryColor__KqSEN"
      };
    },
    73125: (e) => {
      e.exports = {
        root_withLongText: "BaseNotificationPin_root_withLongText__BKqhi",
        title: "BaseNotificationPin_title__46xmX",
        link: "BaseNotificationPin_link__4EvPj",
        capitalizedEntity: "BaseNotificationPin_capitalizedEntity__HePYm",
        text: "BaseNotificationPin_text__LF3L_",
        image: "BaseNotificationPin_image__O7ptT"
      };
    },
    73922: (e, t, r) => {
      "use strict";
      r.d(t, { CardLikes: () => d });
      var n = r(54486), s = r(50420), a = r(43426), i = r(31500), o = r(77881), l = r(5956), c = r(97800), u = r(22038), f = r.n(u);
      let d = (e2) => {
        let { className: t2, isLiked: r2, likesCount: u2, handleLikeClick: d2, ariaLabel: x } = e2, { formatNumber: p } = (0, a.A)();
        return (0, n.jsx)(o.$, {
          className: (0, s.$)(f().root, t2),
          onClick: d2,
          variant: "text",
          withRipple: false,
          icon: (0, n.jsx)(l.Icon, { variant: r2 ? "likedVariant" : "likeVariant", size: "xxs", className: f().icon }),
          "aria-label": x,
          ...(0, i.Am)(i.S7.CARD_LIKES),
          children: (0, n.jsx)(c.Caption, {
            variant: "div",
            size: "s",
            type: "entity",
            weight: "medium",
            children: p(u2)
          })
        });
      };
    },
    74524: (e) => {
      e.exports = {
        title: "InnerHeader_title__5aVLP",
        title_show: "InnerHeader_title_show__RvHsQ",
        show: "InnerHeader_show__ji3KF",
        backdrop: "InnerHeader_backdrop__iRxvk",
        root: "InnerHeader_root__u0zu1",
        root_withChildren: "InnerHeader_root_withChildren__rLTCN",
        root_sticky: "InnerHeader_root_sticky__baN8o",
        child: "InnerHeader_child__DGTfK",
        child_show: "InnerHeader_child_show__7MFTV",
        actions: "InnerHeader_actions__x6ruG",
        buttonClose: "InnerHeader_buttonClose__E3WWy",
        plusButton: "InnerHeader_plusButton__eH4NP",
        plusButton_show: "InnerHeader_plusButton_show__jwPtB"
      };
    },
    75053: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuDislikeItem: () => u });
      var n = r(54486), s = r(28303), a = r(47713), i = r(31500), o = r(5956), l = r(61958), c = r(60440);
      let u = (0, s.PA)((e2) => {
        let { isDisliked: t2, onClick: r2, disabled: s2, className: u2 } = e2, { user: f } = (0, c.useStore)();
        return (0, n.jsx)(l.Dr, {
          onClick: r2,
          className: u2,
          icon: (0, n.jsx)(o.Icon, { variant: t2 ? "disliked" : "dislike", size: "xxs" }),
          role: "menuitemcheckbox",
          "aria-checked": t2,
          disabled: s2 || !f.isAuthorized,
          ...(0, i.Am)(i.S7.CONTEXT_MENU_DISLIKE_BUTTON),
          children: (0, n.jsx)(a.A, { id: "interface-actions.do-not-like" })
        });
      });
    },
    75450: (e, t, r) => {
      "use strict";
      r.d(t, { MetrikaScript: () => c });
      var n = r(54486), s = r(85097), a = r(61910), i = r(74125), o = r(37525), l = r(91574);
      let c = (e2) => {
        let { nonce: t2, initialMetrikaSettings: r2 } = e2, c2 = (0, l.U)(), u = (0, i.NFA)().get(i.vgk), f = (0, a.useCallback)(() => {
          r2 && u.init({ ...r2, id: (0, o.R)(), logger: c2 });
        }, [r2, u, c2]);
        return r2 ? (0, n.jsx)(s.default, {
          id: "metrika-script",
          src: "https://mc.yandex.ru/metrika/tag.js",
          nonce: null != t2 ? t2 : void 0,
          onReady: f
        }) : null;
      };
    },
    76877: (e, t, r) => {
      "use strict";
      r.d(t, { CarouselWithArrows: () => k });
      var n = r(54486), s = r(50420), a = r(22711), i = r(28303), o = r(61910), l = r.t(o, 2), c = r(31500), u = r(91549), f = {
        810: (e2) => {
          e2.exports = l;
        }
      }, d = {}, x = {};
      (() => {
        Object.defineProperty(x, "__esModule", { value: true }), x.useForwardRef = void 0;
        let e2 = (function e3(t2) {
          var r2 = d[t2];
          if (void 0 !== r2) return r2.exports;
          var n2 = d[t2] = { exports: {} };
          return f[t2](n2, n2.exports, e3), n2.exports;
        })(810);
        x.useForwardRef = function(t2, r2) {
          let n2 = (0, e2.useRef)(r2);
          return (0, e2.useEffect)(() => {
            t2 && ("function" == typeof t2 ? t2(n2.current) : t2.current = n2.current);
          }, [t2]), n2;
        };
      })(), x.__esModule;
      var p = x.useForwardRef, _ = r(23753), m = r(60440), v = r(78684), g = r(70692), b = r.n(g);
      let y = { [_.u.Desktop]: { start: 40, end: 20 }, [_.u.Mobile]: { start: 40, end: 40 } }, h = (0, i.PA)((e2) => {
        let {
          className: t2,
          carouselElement: r2,
          forwardRef: i2,
          scrollPadding: l2,
          isCarouselBetweenArrows: f2 = false,
          controlsWrapperClassName: d2,
          buttonSize: x2,
          buttonVariant: g2,
          withSecondaryColor: h2
        } = e2, {
          settings: { isMobile: k2 }
        } = (0, m.useStore)(), E = p(i2, null), {
          shouldBackwardButtonBeDisabled: w,
          shouldForwardButtonBeDisabled: j,
          shouldHideControls: O
        } = (0, u.Y)(E), [R, C] = (0, o.useMemo)(() => {
          let e3 = (0, a.A)(y, l2);
          return [k2 ? e3[_.u.Mobile].start : e3[_.u.Desktop].start, k2 ? e3[_.u.Mobile].end : e3[_.u.Desktop].end];
        }, [l2, k2]), S = (0, o.useCallback)(
          (e3) => {
            var t3;
            let r3 = null == (t3 = E.current) ? void 0 : t3.children[e3], { current: n2 } = E;
            if (!n2 || !(r3 instanceof HTMLElement)) return;
            if (r3.offsetLeft - n2.scrollLeft < R) {
              n2.scrollLeft = r3.offsetLeft - R;
              return;
            }
            let s2 = n2.scrollLeft + n2.clientWidth - r3.offsetLeft - r3.offsetWidth;
            s2 < C && (n2.scrollLeft -= s2 - C);
          },
          [E, C, R]
        ), P = (0, o.useCallback)(
          (e3) => {
            var t3, n2;
            S(e3), null == (t3 = (n2 = r2.props).onTabChange) || t3.call(n2, e3);
          },
          [r2, S]
        ), A = (0, o.cloneElement)(r2, {
          forwardRef: E,
          className: (0, s.$)(b().wrapper, r2.props.className, b().carousel, b().important),
          onTabChange: P
        });
        return (0, n.jsxs)("div", {
          className: (0, s.$)(
            b().root,
            {
              [b().root_carouselBetweenArrows]: f2,
              [b().root_arrowLeft_hidden]: w,
              [b().root_arrowRight_hidden]: j,
              [b().root_arrow_hidden]: w && j && O
            },
            t2
          ),
          ...(0, c.Am)(c.S7.CAROUSEL_WITH_ARROWS),
          children: [
            (0, n.jsx)("div", { className: b().list, children: A }),
            !k2 && (0, n.jsx)(v.CarouselControls, {
              className: (0, s.$)(b().buttons, d2),
              carouselRef: E,
              backwardControlClassName: b().control,
              forwardControlClassName: b().control,
              withSecondaryColor: h2,
              buttonSize: x2,
              buttonVariant: g2
            })
          ]
        });
      }), k = (0, o.forwardRef)((e2, t2) => (0, n.jsx)(h, { forwardRef: t2, ...e2 }));
    },
    77607: (e, t, r) => {
      "use strict";
      r.d(t, { HeaderContext: () => n });
      let n = (0, r(61910).createContext)({
        title: null,
        setTitle: () => {
        },
        titleElement: null,
        scrollElement: null,
        setTitleElement: () => {
        },
        child: null,
        setChild: () => {
        },
        childElement: null,
        setChildElement: () => {
        },
        isScrolledChild: false,
        isScrolledTitle: false,
        isScrolling: false,
        isHeaderHidden: false
      });
    },
    77666: (e, t, r) => {
      "use strict";
      r.d(t, { AdfoxScript: () => c });
      var n = r(54486), s = r(28303), a = r(85097), i = r(8817), o = r(7286), l = r(60440);
      let c = (0, s.PA)((e2) => {
        let { nonce: t2 } = e2, { location: r2 } = (0, l.useStore)(), { init: s2 } = (0, o.useAdfox)(), c2 = (0, i.c)(() => {
          s2({ cspNonce: t2 });
        }), u = "https://yandex.".concat(r2.tld, "/ads/system/context.js");
        return (0, n.jsx)(a.default, { id: "adfox-script", src: u, nonce: null != t2 ? t2 : void 0, onReady: c2 });
      });
    },
    77722: (e) => {
      e.exports = {
        root: "CarouselBlock_root__aeOla",
        controls: "CarouselBlock_controls__vsHCR",
        shimmerTitle: "CarouselBlock_shimmerTitle__ZXIRx",
        item: "CarouselBlock_item__DatZ2",
        important: "CarouselBlock_important__AARmP"
      };
    },
    78308: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuSubscribeItem: () => u });
      var n = r(54486), s = r(28303), a = r(31500), i = r(5956), o = r(61958), l = r(17012), c = r(60440);
      let u = (0, s.PA)((e2) => {
        let { isLiked: t2, onClick: r2, className: s2, albumType: u2, disabled: f } = e2, { user: d } = (0, c.useStore)(), x = t2 ? "liked" : "like", p = (0, l.useNonMusicSubscribeText)(t2, u2);
        return (0, n.jsx)(o.Dr, {
          className: s2,
          onClick: r2,
          icon: (0, n.jsx)(i.Icon, { variant: x, size: "xxs" }),
          "aria-pressed": t2,
          disabled: f || !d.isAuthorized,
          ...(0, a.Am)(a.S7.CONTEXT_MENU_SUBSCRIBE_BUTTON),
          children: p
        });
      });
    },
    78684: (e, t, r) => {
      "use strict";
      r.d(t, { CarouselControls: () => d });
      var n = r(54486), s = r(50420), a = r(61910), i = r(31500), o = r(91549), l = r(77881), c = r(5956), u = r(72724), f = r.n(u);
      let d = (e2) => {
        let {
          carouselRef: t2,
          backwardControlClassName: r2,
          forwardControlClassName: u2,
          className: d2,
          withSecondaryColor: x,
          buttonSize: p = "xxxs",
          buttonVariant: _ = "outline"
        } = e2, {
          swipeBackward: m,
          swipeForward: v,
          shouldBackwardButtonBeDisabled: g,
          shouldForwardButtonBeDisabled: b,
          shouldHideControls: y
        } = (0, o.Y)(t2), h = (0, a.useCallback)(
          (e3) => {
            m(), e3.stopPropagation();
          },
          [m]
        ), k = (0, a.useCallback)(
          (e3) => {
            v(), e3.stopPropagation();
          },
          [v]
        );
        return (0, n.jsxs)("div", {
          className: (0, s.$)(f().root, d2),
          ...(0, i.Am)(i.S7.CAROUSEL_CONTROLS),
          children: [
            (0, n.jsx)(l.$, {
              tabIndex: -1,
              "aria-hidden": true,
              className: (0, s.$)(f().control, r2, { [f().control_hidden]: y, [f().control_withSecondaryColor]: x }),
              onClick: h,
              size: p,
              radius: "round",
              variant: _,
              withRipple: false,
              icon: (0, n.jsx)(c.Icon, { size: "xxs", variant: "arrowLeft" }),
              disabled: g,
              ...(0, i.Am)(i.S7.CAROUSEL_CONTROLS_BACKWARD_BUTTON)
            }),
            (0, n.jsx)(l.$, {
              tabIndex: -1,
              "aria-hidden": true,
              className: (0, s.$)(f().control, u2, { [f().control_hidden]: y, [f().control_withSecondaryColor]: x }),
              onClick: k,
              size: p,
              radius: "round",
              variant: _,
              withRipple: false,
              icon: (0, n.jsx)(c.Icon, { size: "xxs", variant: "arrowRight" }),
              disabled: b,
              ...(0, i.Am)(i.S7.CAROUSEL_CONTROLS_FORWARD_BUTTON)
            })
          ]
        });
      };
    },
    78817: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuVideoSpeed: () => u });
      var n = r(54486), s = r(28303), a = r(61910), i = r(43426), o = r(31500), l = r(61958), c = r(60440);
      let u = (0, s.PA)((e2) => {
        let { isDisabled: t2, className: r2, menuClassName: s2 } = e2, {
          settings: { isMobile: u2 }
        } = (0, c.useStore)(), { formatMessage: f } = (0, i.A)(), d = (0, a.useMemo)(
          () => Array.from({ length: 8 }, (e3, t3) => {
            let r3 = (t3 + 1) * 0.25;
            return (0, n.jsx)(l.Dr, { children: 1 === r3 ? f({ id: "player-actions.video-speed-normal" }) : r3 }, r3);
          }),
          [f]
        );
        return (0, n.jsx)(l.W1, {
          menuClassName: s2,
          offsetOptions: 3,
          isMobile: u2,
          className: r2,
          label: f({ id: "player-actions.video-speed" }),
          disabled: t2,
          ...(0, o.Am)(o.S7.CONTEXT_MENU_SPEED_BUTTON),
          children: d
        });
      });
    },
    79326: (e, t, r) => {
      "use strict";
      r.d(t, { BuyPlusPopover: () => p });
      var n = r(54486), s = r(61910), a = r(43426), i = r(31500), o = r(15099), l = r(77881), c = r(97800), u = r(60440), f = r(1756), d = r(21673), x = r(16372);
      let p = (e2) => {
        let {
          textVariant: t2,
          vibeTextVariant: r2,
          albumTextVariant: p2,
          buttonText: _,
          customButtons: m,
          onOpenMenuChange: v,
          ...g
        } = e2, b = (0, s.useId)(), { formatMessage: y } = (0, a.A)(), {
          experiments: h,
          paywall: { modal: k }
        } = (0, u.useStore)(), E = h.checkExperiment(f.z.WebNextUnauthorizedSubscriptionButton, "on") ? y({ id: "authorization.start-button" }) : y({ id: "payment.try-button" }), w = (0, s.useMemo)(() => {
          switch (r2) {
            case d.I.ALBUM:
              return y({ id: "onboarding.try-plus-to-listen-vibe-by-album" }, { br: "\n", nbsp: " " });
            case d.I.ARTIST:
              return y({ id: "onboarding.try-plus-to-listen-vibe-by-artist" }, { br: "\n", nbsp: " " });
            case d.I.PLAYLIST:
              return y({ id: "onboarding.try-plus-to-listen-vibe-by-playlist" }, { br: "\n", nbsp: " " });
            case d.I.TRACK:
              return y({ id: "onboarding.try-plus-to-listen-vibe-by-track" }, { br: "\n", nbsp: " " });
            case d.I.GENRE:
            case d.I.MICRO_GENRE:
              return y({ id: "onboarding.try-plus-to-listen-vibe-by-genre" }, { br: "\n", nbsp: " " });
            case d.I.MOOD:
              return y({ id: "onboarding.try-plus-to-listen-vibe-by-mood" }, { br: "\n", nbsp: " " });
            case d.I.ACTIVITY:
              return y({ id: "onboarding.try-plus-to-listen-vibe-by-activity" }, { br: "\n", nbsp: " " });
            default:
              return y({ id: "onboarding.try-plus-to-listen-vibe" }, { br: "\n", nbsp: " " });
          }
        }, [r2, y]), j = (0, s.useMemo)(() => {
          switch (p2) {
            case o._.SINGLE:
              return y({ id: "entity-names.single-available-with-plus" });
            case o._.PODCAST:
              return y({ id: "non-music.podcast-available-with-plus" });
            case o._.AUDIOBOOK:
              return y({ id: "non-music.book-available-with-plus" });
            case o._.FAIRY_TALE:
              return y({ id: "non-music.fairy-tale-available-with-plus" });
            default:
              return y({ id: "entity-names.album-available-with-plus" });
          }
        }, [p2, y]), O = (0, s.useMemo)(() => {
          switch (t2) {
            case "fullTracks":
              return y({ id: "onboarding.try-plus-to-listen-full" }, { br: "\n", nbsp: " " });
            case "highQuality":
              return y({ id: "onboarding.try-plus-to-enable-high-quality" }, { br: "\n", nbsp: " " });
            case "sync-lyrics":
              return y({ id: "onboarding.try-plus-to-view-sync-lyrics" }, { br: "\n" });
            case "vibe":
              return w;
            case "album":
              return j;
            default:
              return "";
          }
        }, [t2, y, w, j]), R = (0, s.useCallback)(() => {
          k.open(), null == v || v(false);
        }, [k, v]), C = (0, s.useMemo)(
          () => [
            (0, n.jsx)(
              l.$,
              {
                color: "plus",
                size: "xxs",
                radius: "xxxl",
                onClick: R,
                children: (0, n.jsx)(c.Caption, { variant: "div", size: "m", children: _ || E })
              },
              b
            )
          ],
          [b, R, _, E]
        );
        return (0, n.jsx)(x.PopoverWithActions, {
          contentElement: (0, n.jsx)(c.Caption, { variant: "div", size: "l", weight: "bold", children: O }),
          renderChildrenText: O,
          buttons: null != m ? m : C,
          contentProps: (0, i.Am)(i.S7.BUY_PLUS_POPOVER),
          ...g
        });
      };
    },
    79500: () => {
    },
    80585: (e, t, r) => {
      "use strict";
      r.d(t, {
        NX: () => u.AdfoxBanner,
        fJ: () => f.AdvertBanner,
        $W: () => d.BaseNotification,
        cp: () => x.c,
        hT: () => p.BaseNotificationError,
        OM: () => _.BaseNotificationLike,
        k4: () => m.BaseNotificationPin,
        Pv: () => v.BaseNotificationPresave,
        Tw: () => g.BlockHeader,
        Mo: () => j,
        SU: () => O.BuyPlusPopover,
        xW: () => R.CardLikes,
        OY: () => C.CarouselBlock,
        X9: () => S.CarouselControls,
        km: () => eW.k,
        FY: () => P.CarouselWithArrows,
        $2: () => A.CarouselWithColumnsBlock,
        DI: () => A.ColumnsCount,
        WO: () => eV.ConcertShimmer,
        Tb: () => eY,
        iF: () => T.ContextMenuAlbumProgressItem,
        DZ: () => H.ContextMenuDislikeItem,
        TW: () => M.ContextMenuLikeItem,
        f: () => N.ContextMenuNavigateToAlbumItem,
        L1: () => I.ContextMenuPinItem,
        Ht: () => L.ContextMenuShareItem,
        Uc: () => D.ContextMenuSubscribeItem,
        W$: () => z.ContextMenuTrackProgressItem,
        No: () => F.ContextMenuTrailerItem,
        C6: () => U.ContextMenuVibeItem,
        Kb: () => W.ContextMenuWithCheckItem,
        Z7: () => er.Copyrights,
        jg: () => V.DeeplinkAndOnelinkContainer,
        do: () => Y.DeeplinkToMobileProvider,
        Cu: () => K.DescriptionTextsDisclaimer,
        MW: () => X.Disclaimer,
        Pe: () => q.DisclaimerModal,
        _I: () => Q.DislikeButton,
        AD: () => G.DownloadingProgress,
        $: () => Z.EditContentModal,
        Vt: () => eK.V,
        BW: () => J.B,
        ro: () => $.EntityMeta,
        tH: () => ee.ErrorBoundary,
        Nq: () => et.ExplicitMarkIcon,
        wi: () => er.Footer,
        b4: () => ei.FreemiumButton,
        eI: () => eX,
        Y9: () => eo.Header,
        B9: () => el.HeaderContext,
        Vw: () => eo.HeaderVariant,
        Cj: () => ec.HorizontalCardContainer,
        cy: () => eu.LikeButton,
        N_: () => ef.Link,
        Zr: () => ed.LoginPopover,
        JR: () => ex.MainSuspenseLoader,
        jL: () => ey,
        pU: () => ew,
        Lh: () => ej.NavigationControls,
        Do: () => B.NotificationCopy,
        LV: () => eO.NotificationReloadBlocks,
        Bh: () => eR.PaywallFAQ,
        L9: () => eC.PaywallFAQAnswer,
        ot: () => eS.PaywallFAQItem,
        nI: () => eP.PaywallFAQQuestion,
        c: () => eA.PaywallFooter,
        O0: () => eT.PinButton,
        DM: () => eH.PlayButton,
        q1: () => eM.PlayButtonWithCover,
        PD: () => eN.PlayingAnimation,
        cu: () => eI.PlusModal,
        mv: () => eL.PlusModalButton,
        bb: () => eB.PlusModalButtonShimmer,
        w1: () => eD.PlusPaywallAlbumButton,
        hS: () => ez.PlusPaywallButton,
        Sj: () => eF.Schema,
        wD: () => eU.ShareButton,
        ig: () => tr.SpeedButton,
        oz: () => tl,
        wI: () => tp,
        zr: () => td,
        nR: () => tx,
        q$: () => e4,
        nN: () => e7,
        hj: () => t_.TooltipWithTitle,
        DS: () => te,
        L5: () => tb,
        kJ: () => ty.TrailerButton,
        cv: () => th.TrailerOnboarding,
        nE: () => tk.TrailerTooltip,
        Hi: () => tE.UnauthorizedButton,
        RJ: () => tt.VerticalListItemShimmer,
        $$: () => tw.VirtualScroll,
        A: () => ea,
        aQ: () => tj.WithOffline,
        v2: () => c.default,
        $f: () => s(),
        VN: () => i(),
        SE: () => l()
      });
      var n = r(66154), s = r.n(n), a = r(1131), i = r.n(a), o = r(65250), l = r.n(o), c = r(88343), u = r(41682);
      r(77666);
      var f = r(8765);
      r(48670);
      var d = r(22096), x = r(48861), p = r(33655), _ = r(27754), m = r(47347), v = r(45591), g = r(52862), b = r(54486), y = r(50420), h = r(6971), k = r(22674), E = r(91786), w = r.n(E);
      let j = (e10) => {
        let { isActive: t2, coverRadius: r2 = "m", withDescription: n2, className: s2 } = e10;
        return (0, b.jsxs)("div", {
          className: (0, y.$)(w().start, s2),
          children: [
            (0, b.jsx)(h.Paper, {
              className: w().coverContainer,
              radius: r2,
              children: (0, b.jsx)(k.Shimmer, { isActive: t2, className: w().shimmerCover, radius: "xl" })
            }),
            (0, b.jsxs)("div", {
              className: w().textShimmerContainer,
              children: [
                (0, b.jsx)(k.Shimmer, { isActive: t2, className: w().shimmerTitle, radius: "xl" }),
                n2 && (0, b.jsx)(k.Shimmer, { isActive: t2, className: w().shimmerDescription })
              ]
            })
          ]
        });
      };
      var O = r(79326), R = r(73922), C = r(10790), S = r(78684), P = r(76877), A = r(61176), T = r(62108), H = r(75053), M = r(23035), N = r(82315), I = r(60673), L = r(5048), B = r(50215), D = r(78308), z = r(10084), F = r(58681), U = r(18658);
      r(6323), r(78817);
      var W = r(7230), V = r(38378), Y = r(35609), K = r(18606);
      r(68014), r(12126);
      var X = r(52742), q = r(68098), Q = r(89190), G = r(3270), Z = r(1220), $ = r(96584), J = r(95405);
      r(54598);
      var ee = r(14196), et = r(20576), er = r(29070), en = r(5866), es = r.n(en);
      let ea = (e10) => {
        let { children: t2 } = e10;
        return (0, b.jsx)("footer", { className: es().empty });
      };
      var ei = r(35203), eo = r(39450), el = r(77607), ec = r(7430), eu = r(24786), ef = r(24036), ed = r(34932), ex = r(56204), ep = r(61910), e_ = r(15209), em = r(58360), ev = r(71262), eg = r.n(ev);
      let eb = (e10) => {
        let {
          forwardRef: t2,
          createUrlReplacer: r2 = e_.createAvatarUrl,
          className: n2,
          maskSrc: s2,
          style: a2 = {},
          withAspectRatio: i2 = false,
          withAvatarReplace: o2,
          withMaskReplace: l2 = o2,
          ...c2
        } = e10, u2 = s2 ? "url(".concat(l2 ? r2(s2, "orig", i2) : s2, ")") : "none";
        return (0, b.jsx)(em.Image, {
          className: (0, y.$)(eg().root, n2),
          createUrlReplacer: r2,
          ref: t2,
          style: { ...a2, maskImage: u2 },
          withAspectRatio: i2,
          withAvatarReplace: o2,
          ...c2
        });
      }, ey = (0, ep.forwardRef)((e10, t2) => (0, b.jsx)(eb, { forwardRef: t2, ...e10 }));
      var eh = r(86318), ek = r.n(eh);
      let eE = (e10) => {
        let {
          backgroundSrc: t2,
          className: r2,
          forwardRef: n2,
          maskSrc: s2,
          size: a2,
          src: i2,
          withAvatarReplace: o2,
          ...l2
        } = e10;
        return (0, b.jsxs)("div", {
          className: ek().root,
          children: [
            t2 && (0, b.jsx)(em.Image, { className: ek().background, src: t2, size: a2, withAvatarReplace: o2, ...l2 }),
            (0, b.jsx)(ey, { className: r2, maskSrc: s2, ref: n2, size: a2, src: i2, withAvatarReplace: o2, ...l2 })
          ]
        });
      }, ew = (0, ep.forwardRef)((e10, t2) => (0, b.jsx)(eE, { forwardRef: t2, ...e10 }));
      r(75450);
      var ej = r(60608);
      r(33648);
      var eO = r(43548), eR = r(69672), eC = r(50711), eS = r(5185), eP = r(90555), eA = r(5602), eT = r(12390), eH = r(58376), eM = r(24491), eN = r(61993), eI = r(38644), eL = r(93668), eB = r(85949), eD = r(17519), ez = r(62010);
      r(16372), r(97396), r(62901), r(54574), r(13067), r(1756), r(64434), r(33158);
      var eF = r(27314), eU = r(93206), eW = r(86226), eV = r(37226);
      let eY = (e10) => Array.from({ length: e10 }, (e11, t2) => (0, b.jsx)(eV.ConcertShimmer, {}, t2));
      var eK = r(16834);
      let eX = (e10) => {
        let {
          isActive: t2,
          itemClassName: r2,
          round: n2,
          centered: s2,
          withInfo: a2,
          count: i2 = 10,
          shimmerClassName: o2,
          linesCount: l2,
          "aria-label": c2,
          withSubcover: u2
        } = e10;
        return Array.from(Array(i2).keys()).map(
          (e11) => (0, b.jsx)(
            eK.V,
            {
              isActive: t2,
              linesCount: l2,
              className: r2,
              round: n2,
              centered: s2,
              withInfo: a2,
              withSubcover: u2,
              "aria-label": c2,
              shimmerClassName: o2
            },
            e11
          )
        );
      };
      var eq = r(69191), eQ = r.n(eq);
      let eG = (e10) => {
        let { isActive: t2, count: r2 = 2, className: n2, width: s2 } = e10;
        return (0, b.jsx)("div", {
          className: (0, y.$)(eQ().root, n2),
          children: Array.from(
            { length: r2 },
            (e11, r3) => (0, b.jsx)(k.Shimmer, { isActive: t2, width: s2, className: eQ().cover, radius: "round" }, r3)
          )
        });
      };
      var eZ = r(48384), e$ = r.n(eZ);
      let eJ = (e10) => {
        let { isActive: t2 } = e10;
        return (0, b.jsxs)("div", {
          className: (0, y.$)(e$().root, e$().root_withCovers),
          children: [
            (0, b.jsx)(eG, { width: 36 }),
            (0, b.jsxs)("div", {
              className: e$().lines,
              children: [
                (0, b.jsx)(k.Shimmer, { isActive: t2, width: 98, className: e$().title }),
                (0, b.jsx)(k.Shimmer, { isActive: t2, width: 85, className: e$().subtitle })
              ]
            })
          ]
        });
      }, e0 = (e10) => {
        let { isActive: t2, className: r2 } = e10;
        return (0, b.jsx)("div", {
          className: (0, y.$)(e$().root, r2),
          children: (0, b.jsx)("div", {
            className: e$().lines,
            children: (0, b.jsx)(k.Shimmer, { isActive: t2, width: 78, className: e$().title })
          })
        });
      };
      var e1 = r(83690), e8 = r.n(e1);
      let e4 = (e10) => {
        let {
          className: t2,
          shimmerClassName: r2,
          isActive: n2 = false,
          count: s2 = 10,
          minWidth: a2 = 50,
          maxWidth: i2 = 90,
          multiplicity: o2 = 1
        } = e10;
        return (0, b.jsx)("div", {
          className: (0, y.$)(e8().root, t2),
          children: Array.from({ length: s2 }, (e11, t3) => {
            let s3 = "".concat(
              ((e12, t4, r3) => Math.floor((Math.floor(Math.random() * (t4 - e12 + 1)) + e12) / r3) * r3)(a2, i2, o2),
              "%"
            );
            return (0, b.jsx)(
              k.Shimmer,
              { width: s3, className: (0, y.$)(e8().shimmer, r2), isActive: n2, radius: "s" },
              t3
            );
          })
        });
      };
      var e5 = r(63886), e6 = r.n(e5);
      let e7 = (e10) => {
        let { className: t2, textClassName: r2, isActive: n2 } = e10;
        return (0, b.jsx)("div", {
          className: (0, y.$)(e6().root, t2),
          children: (0, b.jsx)(k.Shimmer, { className: (0, y.$)(e6().text, r2), isActive: n2, radius: "s" })
        });
      };
      var e2 = r(47788), e3 = r(13811), e9 = r(45645);
      let te = (e10) => {
        let { isActive: t2, variant: r2, className: n2 } = e10;
        switch (r2) {
          case e2.X.PLAYLIST:
            return (0, b.jsx)(e9.PlaylistTrackShimmer, { isActive: t2, className: n2 });
          case e2.X.ALBUM:
            return (0, b.jsx)(e3.AlbumTrackShimmer, { isActive: t2, className: n2 });
        }
      };
      var tt = r(24126), tr = r(20406);
      r(21940);
      var tn = r(31500), ts = r(51321), ta = r(97800), ti = r(99882), to = r.n(ti);
      let tl = (e10) => {
        let {
          className: t2,
          value: r2,
          title: n2,
          subtitle: s2,
          covers: a2,
          titleClassName: i2,
          withCovers: o2,
          withHeading: l2,
          withSubtitle: c2,
          isShimmerVisible: u2,
          ...f2
        } = e10, d2 = (0, ep.useMemo)(
          () => l2 ? (0, b.jsx)(ta.Heading, {
            className: (0, y.$)(to().title, i2),
            variant: "div",
            size: "xs",
            weight: "bold",
            lineClamp: 1,
            children: n2
          }) : (0, b.jsx)(ta.Caption, {
            className: (0, y.$)(to().title, i2),
            variant: "div",
            type: "controls",
            size: "m",
            weight: "bold",
            lineClamp: 1,
            children: n2
          }),
          [n2, i2, l2]
        ), x2 = (0, ep.useMemo)(
          () => o2 && !a2 && u2 ? (0, b.jsx)(eG, { width: 36, count: 1 }) : a2 ? (0, b.jsx)("span", {
            className: to().covers,
            children: a2.map(
              (e11, t3) => (0, b.jsx)(
                J.B,
                { className: to().image, src: e11, fit: "cover", size: 50, withAvatarReplace: true },
                t3
              )
            )
          }) : null,
          [a2, u2, o2]
        ), p2 = (0, ep.useMemo)(
          () => c2 && !s2 && u2 ? (0, b.jsx)(k.Shimmer, { isActive: true, width: 84, className: to().shimmerSubtitle }) : s2 ? (0, b.jsx)(ta.Caption, {
            className: to().subtitle,
            variant: "div",
            type: "controls",
            size: "s",
            weight: "medium",
            lineClamp: 1,
            children: s2
          }) : null,
          [u2, s2, c2]
        );
        return (0, b.jsxs)(ts.Tab, {
          value: r2,
          className: (0, y.$)(
            to().root,
            {
              [to().tab_size_s]: !c2 && o2,
              [to().tab_size_m]: !c2 && !o2,
              [to().tab_withCovers]: o2,
              [to().tab_withMissingCovers]: o2 && !a2
            },
            t2
          ),
          ...(0, tn.Am)(tn.S7.TAB),
          ...f2,
          children: [x2, (0, b.jsxs)("span", { className: to().description, children: [d2, p2] })]
        });
      };
      var tc = r(25582), tu = r.n(tc);
      let tf = (e10) => {
        let {
          isShimmerVisible: t2,
          value: r2,
          shimmer: n2,
          children: s2,
          onTabChange: a2,
          className: i2,
          elementId: o2,
          forwardRef: l2,
          ...c2
        } = e10;
        return t2 && n2 ? n2 : (0, b.jsx)(ts.Tabs, {
          className: (0, y.$)(tu().root, i2),
          value: r2,
          elementId: o2,
          onTabChange: a2,
          ref: l2,
          ...c2,
          children: s2
        });
      }, td = (e10) => {
        let { isActive: t2, className: r2, shimmerClassName: n2, count: s2 = 2 } = e10;
        return (0, b.jsx)("div", {
          className: (0, y.$)(tu().root, r2),
          children: Array.from({ length: s2 }, (e11, r3) => (0, b.jsx)(e0, { isActive: t2, className: n2 }, r3))
        });
      }, tx = (e10) => {
        let { className: t2, isActive: r2, count: n2 = 2 } = e10;
        return (0, b.jsx)("div", {
          className: (0, y.$)(tu().root, t2),
          children: Array.from({ length: n2 }, (e11, t3) => (0, b.jsx)(eJ, { isActive: r2 }, t3))
        });
      }, tp = (0, ep.forwardRef)((e10, t2) => {
        let { ...r2 } = e10;
        return (0, b.jsx)(tf, { forwardRef: t2, ...r2, ...(0, tn.Am)(tn.S7.TAB_CAROUSEL) });
      });
      var t_ = r(26086), tm = r(18608), tv = r.n(tm);
      let tg = function(e10, t2) {
        let r2 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 5;
        return Array.from(
          { length: r2 },
          (r3, n2) => (0, b.jsx)(te, { variant: t2, className: tv().shimmer, isActive: e10 }, n2)
        );
      }, tb = (e10) => {
        let {
          isShimmerVisible: t2,
          isShimmerActive: r2,
          variant: n2,
          shimmersCount: s2,
          className: a2,
          children: i2,
          ...o2
        } = e10;
        return (0, b.jsx)("div", {
          className: (0, y.$)(tv().root, a2),
          ...(0, e_.getDataAttrFromProps)(o2),
          children: t2 ? tg(r2, n2, s2) : i2
        });
      };
      var ty = r(96838), th = r(10358), tk = r(23143), tE = r(51828), tw = r(51725), tj = r(23834);
      r(24624);
    },
    81203: (e, t, r) => {
      "use strict";
      r.d(t, { Carousel: () => c });
      var n, s = r(61910), a = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        9438: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "IZnFMW4gXBshJODnvB1P", item: "VJ9IexhAEuYSCyGiMfN4" };
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        5056: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Carousel = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = n2(r2(9438)), l2 = (e3) => {
            let { className: t3, itemClassName: r3, children: n3, forwardRef: l3, role: c2, ...u } = e3;
            return (0, s2.jsx)("ol", {
              ref: l3,
              className: (0, a2.clsx)(o2.default.root, t3),
              ...u,
              role: null != c2 ? c2 : "list",
              children: i2.Children.map(
                n3,
                (e4) => (0, s2.jsx)("li", { className: (0, a2.clsx)(o2.default.item, r3), children: e4 })
              )
            });
          };
          t2.Carousel = (0, i2.forwardRef)((e3, t3) => (0, s2.jsx)(l2, { forwardRef: t3, ...e3 }));
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(s, 2));
        }
      }, i = {};
      function o(e2) {
        var t2 = i[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = i[e2] = { exports: {} };
        return a[e2].call(r2.exports, r2, r2.exports, o), r2.exports;
      }
      o.d = (e2, t2) => {
        for (var r2 in t2) o.o(t2, r2) && !o.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, o.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), o.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var l = {};
      (() => {
        Object.defineProperty(l, "X", { value: true }), l.l = void 0;
        var e2 = o(5056);
        Object.defineProperty(l, "l", {
          enumerable: true,
          get: function() {
            return e2.Carousel;
          }
        });
      })();
      var c = l.l;
      l.X;
    },
    82315: (e, t, r) => {
      "use strict";
      r.d(t, { ContextMenuNavigateToAlbumItem: () => _ });
      var n = r(54486), s = r(28303), a = r(61910), i = r(47713), o = r(31500), l = r(15099), c = r(8075), u = r(8817), f = r(5956), d = r(61958), x = r(50820), p = r(60440);
      let _ = (0, s.PA)((e2) => {
        let { className: t2, albumType: r2, albumUrl: s2, trackType: _2 } = e2, { fullscreenPlayer: m } = (0, p.useStore)(), v = (0, x.Z)(s2), g = (0, a.useMemo)(() => {
          switch (r2) {
            case l._.AUDIOBOOK:
              return (0, n.jsx)(i.A, { id: "non-music.navigate-to-book-album" });
            case l._.ALBUM:
            case l._.SINGLE:
              return (0, n.jsx)(i.A, { id: "interface-actions.navigate-to-album" });
            case l._.PODCAST:
              return (0, n.jsx)(i.A, { id: "non-music.navigate-to-podcast-album" });
            default:
              return null;
          }
        }, [r2]), b = (0, a.useMemo)(() => {
          switch (_2) {
            case c.S.AUDIOBOOK:
              return (0, n.jsx)(i.A, { id: "non-music.navigate-to-book-album" });
            case c.S.TRACK:
            case c.S.MUSIC:
              return (0, n.jsx)(i.A, { id: "interface-actions.navigate-to-album" });
            case c.S.PODCAST:
              return (0, n.jsx)(i.A, { id: "non-music.navigate-to-podcast-album" });
            default:
              return null;
          }
        }, [_2]), y = (0, u.c)(() => {
          v(), m.modal.close();
        }), h = (0, a.useMemo)(
          () => r2 ? [l._.ALBUM, l._.SINGLE].includes(r2) ? "album" : "podcasts" : _2 ? [c.S.TRACK, c.S.MUSIC].includes(_2) ? "album" : "podcasts" : "album",
          [r2, _2]
        );
        return g || b ? (0, n.jsx)(d.Dr, {
          className: t2,
          onClick: y,
          icon: (0, n.jsx)(f.Icon, { variant: h, size: "xxs" }),
          ...(0, o.Am)(o.Kq.track.TRACK_CONTEXT_MENU_NAVIGATE_TO_ALBUM),
          children: g || b
        }) : null;
      });
    },
    82825: (e) => {
      e.exports = {
        link: "BaseNotificationPresave_link__4uQhM",
        title: "BaseNotificationPresave_title__bEloI",
        text: "BaseNotificationPresave_text__3Kv9j",
        image: "BaseNotificationPresave_image__Hb7ve"
      };
    },
    83690: (e) => {
      e.exports = { root: "TextBlockShimmer_root__og5Bj", shimmer: "TextBlockShimmer_shimmer__TpDdq" };
    },
    85353: (e) => {
      e.exports = {
        root: "PaywallFAQCollapse_root___gwrQ",
        root_collapsed: "PaywallFAQCollapse_root_collapsed__gx8IK"
      };
    },
    85949: (e, t, r) => {
      "use strict";
      r.d(t, { PlusModalButtonShimmer: () => l });
      var n = r(54486), s = r(50420), a = r(22674), i = r(65508), o = r.n(i);
      let l = (e2) => {
        let { isMobile: t2, isActive: r2, className: i2 } = e2;
        return (0, n.jsx)(a.Shimmer, {
          className: (0, s.$)(o().shimmer, { [o().shimmer_mobile]: t2 }, i2),
          isActive: r2,
          radius: "xxxl"
        });
      };
    },
    86226: (e, t, r) => {
      "use strict";
      r.d(t, { k: () => a });
      var n = r(54486), s = r(16834);
      let a = function() {
        let e2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return Array.from({ length: 9 }, (t2, r2) => (0, n.jsx)(s.V, { ...e2 }, r2));
      };
    },
    86318: (e) => {
      e.exports = {
        root: "MaskedImageWithBackground_root__jLo5w",
        background: "MaskedImageWithBackground_background__9PdlN"
      };
    },
    88018: (e) => {
      e.exports = {
        root: "StickyHeader_root__s_rPg",
        backdrop: "StickyHeader_backdrop__fCnOw",
        container: "StickyHeader_container__8mTBx",
        container_scrolling: "StickyHeader_container_scrolling__nV9EK",
        plusButton: "StickyHeader_plusButton__80nx5",
        plusButton_show: "StickyHeader_plusButton_show__lN22Y",
        children: "StickyHeader_children__5Jlr1"
      };
    },
    88343: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { default: () => n });
      let n = {
        src: "/_next/static/media/artist.c49b2bfa.png",
        height: 327,
        width: 327,
        blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAOVBMVEU7SUNzfno6TEYVIB4tOTVMaXExOjY1PTpEUEw+T0k2RUA0Qz40Qz1UXVpAS0dncG1IUk6VnZuIkI3hJMzHAAAADHRSTlMu/e4u/gCv7fix563DJ+jkAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAPUlEQVR4nAXBhxHAIAwEsMe4ci6Q/YeNBEG4BwSg9VYSEL3e8A1QzjfcB5ZZlXmg7FXOim23+9qGQM0U8gNH4wIMxKVMaQAAAABJRU5ErkJggg==",
        blurWidth: 8,
        blurHeight: 8
      };
    },
    89190: (e, t, r) => {
      "use strict";
      r.d(t, { DislikeButton: () => p });
      var n = r(54486), s = r(50420), a = r(28303), i = r(61910), o = r(43426), l = r(31500), c = r(77881), u = r(5956), f = r(60440), d = r(92714), x = r.n(d);
      let p = (0, a.PA)((e2) => {
        let {
          className: t2,
          variant: r2 = "text",
          isDisliked: a2 = false,
          onClick: d2,
          iconClassName: p2,
          iconSize: _,
          size: m = "s",
          disabled: v = false
        } = e2, { user: g } = (0, f.useStore)(), { formatMessage: b } = (0, o.A)(), y = (0, i.useCallback)(
          (e3) => {
            null == d2 || d2(), e3.stopPropagation();
          },
          [d2]
        );
        return (0, n.jsx)(c.$, {
          className: (0, s.$)(x().root, t2),
          withRipple: false,
          variant: r2,
          size: m,
          radius: "round",
          disabled: !g.isAuthorized || v,
          "aria-label": b({ id: "interface-actions.do-not-like" }),
          "aria-pressed": a2,
          onClick: y,
          icon: (0, n.jsx)(u.Icon, { size: _, className: p2, variant: a2 ? "disliked" : "dislike" }),
          ...(0, l.Am)(l.S7.DISLIKE_BUTTON)
        });
      });
    },
    89305: (e) => {
      e.exports = {
        inner: "CommonHeader_inner__DFpbr",
        header: "CommonHeader_header__41HAE",
        container: "CommonHeader_container__Jgf0s",
        leftBlock: "CommonHeader_leftBlock__dJUBK",
        title: "CommonHeader_title__RSbBG",
        plusButton: "CommonHeader_plusButton__oe8Gh"
      };
    },
    90555: (e, t, r) => {
      "use strict";
      r.d(t, { PaywallFAQQuestion: () => o });
      var n = r(54486), s = r(97800), a = r(36987), i = r.n(a);
      let o = (e2) => {
        let { children: t2 } = e2;
        return (0, n.jsx)(s.Caption, { className: i().root, variant: "span", size: "m", children: t2 });
      };
    },
    91098: (e) => {
      e.exports = {
        root: "ConcertShimmer_root__yp58v",
        date: "ConcertShimmer_date__GEOK7",
        meta: "ConcertShimmer_meta__y8Y2_",
        title: "ConcertShimmer_title__Rj3Dc",
        description: "ConcertShimmer_description__tJ4Qp",
        action: "ConcertShimmer_action__6c4QF"
      };
    },
    91549: (e, t, r) => {
      "use strict";
      r.d(t, { Y: () => u });
      var n, s = r(94377), a = r(61910), i = {
        352: (e2) => {
          e2.exports = s;
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(a, 2));
        }
      }, o = {};
      function l(e2) {
        var t2 = o[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = o[e2] = { exports: {} };
        return i[e2](r2, r2.exports, l), r2.exports;
      }
      var c = {};
      (() => {
        Object.defineProperty(c, "X", { value: true }), c.l = void 0;
        let e2 = l(810), t2 = l(352);
        c.l = (r2) => {
          let [n2, s2] = (0, e2.useState)(true), [a2, i2] = (0, e2.useState)(true), o2 = () => {
            let e3 = null == r2 ? void 0 : r2.current;
            e3 && (s2(0 === e3.scrollLeft), i2(e3.scrollWidth - e3.scrollLeft <= e3.offsetWidth + 10));
          };
          (0, e2.useEffect)(() => {
            o2();
          }, [r2, o2]), (0, e2.useEffect)(() => {
            let e3 = null == r2 ? void 0 : r2.current;
            return null == e3 || e3.addEventListener("scroll", o2), window.addEventListener("resize", o2), () => {
              null == e3 || e3.removeEventListener("scroll", o2), window.removeEventListener("resize", o2);
            };
          }, [r2, o2]);
          let l2 = (0, e2.useMemo)(
            () => (0, t2.throttle)(
              () => {
                r2 && r2.current && (r2.current.scrollLeft += r2.current.offsetWidth / 2);
              },
              420,
              { trailing: false }
            ),
            [r2]
          );
          return {
            swipeBackward: (0, e2.useMemo)(
              () => (0, t2.throttle)(
                () => {
                  r2 && r2.current && (r2.current.scrollLeft -= r2.current.offsetWidth / 2);
                },
                420,
                { trailing: false }
              ),
              [r2]
            ),
            swipeForward: l2,
            shouldBackwardButtonBeDisabled: n2,
            shouldForwardButtonBeDisabled: a2,
            shouldHideControls: n2 && a2
          };
        };
      })(), c.X;
      var u = c.l;
    },
    91786: (e) => {
      e.exports = {
        root: "BlockHeader_root__j3mbg",
        titleIcon: "BlockHeader_titleIcon__GQFEK",
        start: "BlockHeader_start__ZrGP5",
        coverContainer: "BlockHeader_coverContainer__lATZT",
        cover: "BlockHeader_cover__koOXq",
        textContainer: "BlockHeader_textContainer___2wn9",
        title: "BlockHeader_title__5xlx6",
        description: "BlockHeader_description__hAk9D",
        description_widthLimit: "BlockHeader_description_widthLimit__CXxK1",
        linkContainer: "BlockHeader_linkContainer__EuW_L",
        linkText: "BlockHeader_linkText__Or6VB",
        heading: "BlockHeader_heading__4iqvS",
        heading_notAvailable: "BlockHeader_heading_notAvailable__r_dm1",
        shimmerCover: "BlockHeader_shimmerCover__m2PJl",
        textShimmerContainer: "BlockHeader_textShimmerContainer__hT_Zo",
        shimmerTitle: "BlockHeader_shimmerTitle__kAkgm",
        shimmerDescription: "BlockHeader_shimmerDescription__Bya4z"
      };
    },
    91930: (e) => {
      e.exports = {
        menuItem: "ContextMenuWithCheckItem_menuItem__x6QcI",
        icon: "ContextMenuWithCheckItem_icon__GowgV"
      };
    },
    92304: (e, t, r) => {
      "use strict";
      r.d(t, { AM: () => f, hl: () => d });
      var n, s = r(88834), a = r(94377), i = r(61910), o = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        7820: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { overlay: "ZSjQrniulol6xKOq2Bou" };
        },
        4123: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "TYgwct6DZLAMvvFaBZ7z" };
        },
        5909: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "dJZf0Flxzx7PR15g7zqM" };
        },
        6544: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { RemoveScroll: () => Y });
          var n2, s2, a2 = function() {
            return (a2 = Object.assign || function(e3) {
              for (var t3, r3 = 1, n3 = arguments.length; r3 < n3; r3++)
                for (var s3 in t3 = arguments[r3]) Object.prototype.hasOwnProperty.call(t3, s3) && (e3[s3] = t3[s3]);
              return e3;
            }).apply(this, arguments);
          };
          function i2(e3, t3) {
            var r3 = {};
            for (var n3 in e3) Object.prototype.hasOwnProperty.call(e3, n3) && 0 > t3.indexOf(n3) && (r3[n3] = e3[n3]);
            if (null != e3 && "function" == typeof Object.getOwnPropertySymbols)
              for (var s3 = 0, n3 = Object.getOwnPropertySymbols(e3); s3 < n3.length; s3++)
                0 > t3.indexOf(n3[s3]) && Object.prototype.propertyIsEnumerable.call(e3, n3[s3]) && (r3[n3[s3]] = e3[n3[s3]]);
            return r3;
          }
          Object.create;
          Object.create;
          var o2 = ("function" == typeof SuppressedError && SuppressedError, r2(810)), l2 = "right-scroll-bar-position", c2 = "width-before-scroll-bar";
          function u2(e3, t3) {
            return "function" == typeof e3 ? e3(t3) : e3 && (e3.current = t3), e3;
          }
          var f2 = o2.useLayoutEffect, d2 = /* @__PURE__ */ new WeakMap();
          function x(e3) {
            return e3;
          }
          var p = (function(e3) {
            void 0 === e3 && (e3 = {});
            var t3, r3, n3, s3 = (void 0 === t3 && (t3 = x), r3 = [], n3 = false, {
              read: function() {
                if (n3)
                  throw Error(
                    "Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`."
                  );
                return r3.length ? r3[r3.length - 1] : null;
              },
              useMedium: function(e4) {
                var s4 = t3(e4, n3);
                return r3.push(s4), function() {
                  r3 = r3.filter(function(e5) {
                    return e5 !== s4;
                  });
                };
              },
              assignSyncMedium: function(e4) {
                for (n3 = true; r3.length; ) {
                  var t4 = r3;
                  r3 = [], t4.forEach(e4);
                }
                r3 = {
                  push: function(t5) {
                    return e4(t5);
                  },
                  filter: function() {
                    return r3;
                  }
                };
              },
              assignMedium: function(e4) {
                n3 = true;
                var t4 = [];
                if (r3.length) {
                  var s4 = r3;
                  r3 = [], s4.forEach(e4), t4 = r3;
                }
                var a3 = function() {
                  var r4 = t4;
                  t4 = [], r4.forEach(e4);
                }, i3 = function() {
                  return Promise.resolve().then(a3);
                };
                i3(), r3 = {
                  push: function(e5) {
                    t4.push(e5), i3();
                  },
                  filter: function(e5) {
                    return t4 = t4.filter(e5), r3;
                  }
                };
              }
            });
            return s3.options = a2({ async: true, ssr: false }, e3), s3;
          })(), _ = function() {
          }, m = o2.forwardRef(function(e3, t3) {
            var r3, n3, s3, l3, c3 = o2.useRef(null), x2 = o2.useState({ onScrollCapture: _, onWheelCapture: _, onTouchMoveCapture: _ }), m2 = x2[0], v2 = x2[1], g2 = e3.forwardProps, b2 = e3.children, y2 = e3.className, h2 = e3.removeScrollBar, k2 = e3.enabled, E2 = e3.shards, w2 = e3.sideCar, j2 = e3.noIsolation, O2 = e3.inert, R2 = e3.allowPinchZoom, C2 = e3.as, S2 = e3.gapMode, P2 = i2(e3, [
              "forwardProps",
              "children",
              "className",
              "removeScrollBar",
              "enabled",
              "shards",
              "sideCar",
              "noIsolation",
              "inert",
              "allowPinchZoom",
              "as",
              "gapMode"
            ]), A2 = (r3 = [c3, t3], n3 = function(e4) {
              return r3.forEach(function(t4) {
                return u2(t4, e4);
              });
            }, (s3 = (0, o2.useState)(function() {
              return {
                value: null,
                callback: n3,
                facade: {
                  get current() {
                    return s3.value;
                  },
                  set current(value) {
                    var e4 = s3.value;
                    e4 !== value && (s3.value = value, s3.callback(value, e4));
                  }
                }
              };
            })[0]).callback = n3, l3 = s3.facade, f2(
              function() {
                var e4 = d2.get(l3);
                if (e4) {
                  var t4 = new Set(e4), n4 = new Set(r3), s4 = l3.current;
                  t4.forEach(function(e5) {
                    n4.has(e5) || u2(e5, null);
                  }), n4.forEach(function(e5) {
                    t4.has(e5) || u2(e5, s4);
                  });
                }
                d2.set(l3, r3);
              },
              [r3]
            ), l3), T2 = a2(a2({}, P2), m2);
            return o2.createElement(
              o2.Fragment,
              null,
              k2 && o2.createElement(w2, {
                sideCar: p,
                removeScrollBar: h2,
                shards: E2,
                noIsolation: j2,
                inert: O2,
                setCallbacks: v2,
                allowPinchZoom: !!R2,
                lockRef: c3,
                gapMode: S2
              }),
              g2 ? o2.cloneElement(o2.Children.only(b2), a2(a2({}, T2), { ref: A2 })) : o2.createElement(void 0 === C2 ? "div" : C2, a2({}, T2, { className: y2, ref: A2 }), b2)
            );
          });
          m.defaultProps = { enabled: true, removeScrollBar: true, inert: false }, m.classNames = { fullWidth: c2, zeroRight: l2 };
          var v = function(e3) {
            var t3 = e3.sideCar, r3 = i2(e3, ["sideCar"]);
            if (!t3) throw Error("Sidecar: please provide `sideCar` property to import the right car");
            var n3 = t3.read();
            if (!n3) throw Error("Sidecar medium not found");
            return o2.createElement(n3, a2({}, r3));
          };
          v.isSideCarExport = true;
          var g = function() {
            var e3 = 0, t3 = null;
            return {
              add: function(n3) {
                if (0 == e3 && (t3 = (function() {
                  if (!document) return null;
                  var e4 = document.createElement("style");
                  e4.type = "text/css";
                  var t4 = s2 || r2.nc;
                  return t4 && e4.setAttribute("nonce", t4), e4;
                })())) {
                  var a3, i3;
                  (a3 = t3).styleSheet ? a3.styleSheet.cssText = n3 : a3.appendChild(document.createTextNode(n3)), i3 = t3, (document.head || document.getElementsByTagName("head")[0]).appendChild(i3);
                }
                e3++;
              },
              remove: function() {
                --e3 || !t3 || (t3.parentNode && t3.parentNode.removeChild(t3), t3 = null);
              }
            };
          }, b = function() {
            var e3 = g();
            return function(t3, r3) {
              o2.useEffect(
                function() {
                  return e3.add(t3), function() {
                    e3.remove();
                  };
                },
                [t3 && r3]
              );
            };
          }, y = function() {
            var e3 = b();
            return function(t3) {
              return e3(t3.styles, t3.dynamic), null;
            };
          }, h = function(e3) {
            return parseInt(e3 || "", 10) || 0;
          }, k = function(e3) {
            var t3 = window.getComputedStyle(document.body), r3 = t3["padding" === e3 ? "paddingLeft" : "marginLeft"], n3 = t3["padding" === e3 ? "paddingTop" : "marginTop"], s3 = t3["padding" === e3 ? "paddingRight" : "marginRight"];
            return [h(r3), h(n3), h(s3)];
          }, E = function(e3) {
            void 0 === e3 && (e3 = "margin");
            var t3 = k(e3), r3 = document.documentElement.clientWidth, n3 = window.innerWidth;
            return { left: t3[0], top: t3[1], right: t3[2], gap: Math.max(0, n3 - r3 + t3[2] - t3[0]) };
          }, w = y(), j = "data-scroll-locked", O = function(e3, t3, r3, n3) {
            var s3 = e3.left, a3 = e3.top, i3 = e3.right, o3 = e3.gap;
            return void 0 === r3 && (r3 = "margin"), "\n  .".concat("with-scroll-bars-hidden", " {\n   overflow: hidden ").concat(n3, ";\n   padding-right: ").concat(o3, "px ").concat(n3, ";\n  }\n  body[").concat(j, "] {\n    overflow: hidden ").concat(n3, ";\n    overscroll-behavior: contain;\n    ").concat(
              [
                t3 && "position: relative ".concat(n3, ";"),
                "margin" === r3 && "\n    padding-left: ".concat(s3, "px;\n    padding-top: ").concat(a3, "px;\n    padding-right: ").concat(i3, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(o3, "px ").concat(n3, ";\n    "),
                "padding" === r3 && "padding-right: ".concat(o3, "px ").concat(n3, ";")
              ].filter(Boolean).join(""),
              "\n  }\n  \n  ."
            ).concat(l2, " {\n    right: ").concat(o3, "px ").concat(n3, ";\n  }\n  \n  .").concat(c2, " {\n    margin-right: ").concat(o3, "px ").concat(n3, ";\n  }\n  \n  .").concat(l2, " .").concat(l2, " {\n    right: 0 ").concat(n3, ";\n  }\n  \n  .").concat(c2, " .").concat(c2, " {\n    margin-right: 0 ").concat(n3, ";\n  }\n  \n  body[").concat(j, "] {\n    ").concat("--removed-body-scroll-bar-size", ": ").concat(o3, "px;\n  }\n");
          }, R = function() {
            var e3 = parseInt(document.body.getAttribute(j) || "0", 10);
            return isFinite(e3) ? e3 : 0;
          }, C = function() {
            o2.useEffect(function() {
              return document.body.setAttribute(j, (R() + 1).toString()), function() {
                var e3 = R() - 1;
                e3 <= 0 ? document.body.removeAttribute(j) : document.body.setAttribute(j, e3.toString());
              };
            }, []);
          }, S = function(e3) {
            var t3 = e3.noRelative, r3 = e3.noImportant, n3 = e3.gapMode, s3 = void 0 === n3 ? "margin" : n3;
            C();
            var a3 = o2.useMemo(
              function() {
                return E(s3);
              },
              [s3]
            );
            return o2.createElement(w, { styles: O(a3, !t3, s3, r3 ? "" : "!important") });
          }, P = false;
          try {
            var A = Object.defineProperty({}, "passive", {
              get: function() {
                return P = true, true;
              }
            });
            window.addEventListener("test", A, A), window.removeEventListener("test", A, A);
          } catch (e3) {
            P = false;
          }
          var T = !!P && { passive: false }, H = function(e3, t3) {
            if (!(e3 instanceof Element)) return false;
            var r3 = window.getComputedStyle(e3);
            return "hidden" !== r3[t3] && (r3.overflowY !== r3.overflowX || "TEXTAREA" === e3.tagName || "visible" !== r3[t3]);
          }, M = function(e3, t3) {
            var r3 = t3.ownerDocument, n3 = t3;
            do {
              if ("undefined" != typeof ShadowRoot && n3 instanceof ShadowRoot && (n3 = n3.host), N(e3, n3)) {
                var s3 = I(e3, n3);
                if (s3[1] > s3[2]) return true;
              }
              n3 = n3.parentNode;
            } while (n3 && n3 !== r3.body);
            return false;
          }, N = function(e3, t3) {
            return "v" === e3 ? H(t3, "overflowY") : H(t3, "overflowX");
          }, I = function(e3, t3) {
            return "v" === e3 ? [t3.scrollTop, t3.scrollHeight, t3.clientHeight] : [t3.scrollLeft, t3.scrollWidth, t3.clientWidth];
          }, L = function(e3, t3, r3, n3, s3) {
            var a3, i3 = (a3 = window.getComputedStyle(t3).direction, "h" === e3 && "rtl" === a3 ? -1 : 1), o3 = i3 * n3, l3 = r3.target, c3 = t3.contains(l3), u3 = false, f3 = o3 > 0, d3 = 0, x2 = 0;
            do {
              var p2 = I(e3, l3), _2 = p2[0], m2 = p2[1] - p2[2] - i3 * _2;
              (_2 || m2) && N(e3, l3) && (d3 += m2, x2 += _2), l3 = l3 instanceof ShadowRoot ? l3.host : l3.parentNode;
            } while (!c3 && l3 !== document.body || c3 && (t3.contains(l3) || t3 === l3));
            return f3 && (s3 && 1 > Math.abs(d3) || !s3 && o3 > d3) ? u3 = true : !f3 && (s3 && 1 > Math.abs(x2) || !s3 && -o3 > x2) && (u3 = true), u3;
          }, B = function(e3) {
            return "changedTouches" in e3 ? [e3.changedTouches[0].clientX, e3.changedTouches[0].clientY] : [0, 0];
          }, D = function(e3) {
            return [e3.deltaX, e3.deltaY];
          }, z = function(e3) {
            return e3 && "current" in e3 ? e3.current : e3;
          }, F = 0, U = [];
          let W = (n2 = function(e3) {
            var t3 = o2.useRef([]), r3 = o2.useRef([0, 0]), n3 = o2.useRef(), s3 = o2.useState(F++)[0], a3 = o2.useState(y)[0], i3 = o2.useRef(e3);
            o2.useEffect(
              function() {
                i3.current = e3;
              },
              [e3]
            ), o2.useEffect(
              function() {
                if (e3.inert) {
                  document.body.classList.add("block-interactivity-".concat(s3));
                  var t4 = (function(e4, t5, r4) {
                    if (r4 || 2 == arguments.length)
                      for (var n4, s4 = 0, a4 = t5.length; s4 < a4; s4++)
                        !n4 && s4 in t5 || (n4 || (n4 = Array.prototype.slice.call(t5, 0, s4)), n4[s4] = t5[s4]);
                    return e4.concat(n4 || Array.prototype.slice.call(t5));
                  })([e3.lockRef.current], (e3.shards || []).map(z), true).filter(Boolean);
                  return t4.forEach(function(e4) {
                    return e4.classList.add("allow-interactivity-".concat(s3));
                  }), function() {
                    document.body.classList.remove("block-interactivity-".concat(s3)), t4.forEach(function(e4) {
                      return e4.classList.remove("allow-interactivity-".concat(s3));
                    });
                  };
                }
              },
              [e3.inert, e3.lockRef.current, e3.shards]
            );
            var l3 = o2.useCallback(function(e4, t4) {
              if ("touches" in e4 && 2 === e4.touches.length || "wheel" === e4.type && e4.ctrlKey)
                return !i3.current.allowPinchZoom;
              var s4, a4 = B(e4), o3 = r3.current, l4 = "deltaX" in e4 ? e4.deltaX : o3[0] - a4[0], c4 = "deltaY" in e4 ? e4.deltaY : o3[1] - a4[1], u4 = e4.target, f4 = Math.abs(l4) > Math.abs(c4) ? "h" : "v";
              if ("touches" in e4 && "h" === f4 && "range" === u4.type) return false;
              var d4 = M(f4, u4);
              if (!d4) return true;
              if (d4 ? s4 = f4 : (s4 = "v" === f4 ? "h" : "v", d4 = M(f4, u4)), !d4) return false;
              if (!n3.current && "changedTouches" in e4 && (l4 || c4) && (n3.current = s4), !s4) return true;
              var x3 = n3.current || s4;
              return L(x3, t4, e4, "h" === x3 ? l4 : c4, true);
            }, []), c3 = o2.useCallback(function(e4) {
              if (U.length && U[U.length - 1] === a3) {
                var r4 = "deltaY" in e4 ? D(e4) : B(e4), n4 = t3.current.filter(function(t4) {
                  var n5;
                  return t4.name === e4.type && (t4.target === e4.target || e4.target === t4.shadowParent) && (n5 = t4.delta, n5[0] === r4[0] && n5[1] === r4[1]);
                })[0];
                if (n4 && n4.should) {
                  e4.cancelable && e4.preventDefault();
                  return;
                }
                if (!n4) {
                  var s4 = (i3.current.shards || []).map(z).filter(Boolean).filter(function(t4) {
                    return t4.contains(e4.target);
                  });
                  (s4.length > 0 ? l3(e4, s4[0]) : !i3.current.noIsolation) && e4.cancelable && e4.preventDefault();
                }
              }
            }, []), u3 = o2.useCallback(function(e4, r4, n4, s4) {
              var a4 = {
                name: e4,
                delta: r4,
                target: n4,
                should: s4,
                shadowParent: (function(e5) {
                  for (var t4 = null; null !== e5; )
                    e5 instanceof ShadowRoot && (t4 = e5.host, e5 = e5.host), e5 = e5.parentNode;
                  return t4;
                })(n4)
              };
              t3.current.push(a4), setTimeout(function() {
                t3.current = t3.current.filter(function(e5) {
                  return e5 !== a4;
                });
              }, 1);
            }, []), f3 = o2.useCallback(function(e4) {
              r3.current = B(e4), n3.current = void 0;
            }, []), d3 = o2.useCallback(function(t4) {
              u3(t4.type, D(t4), t4.target, l3(t4, e3.lockRef.current));
            }, []), x2 = o2.useCallback(function(t4) {
              u3(t4.type, B(t4), t4.target, l3(t4, e3.lockRef.current));
            }, []);
            o2.useEffect(function() {
              return U.push(a3), e3.setCallbacks({ onScrollCapture: d3, onWheelCapture: d3, onTouchMoveCapture: x2 }), document.addEventListener("wheel", c3, T), document.addEventListener("touchmove", c3, T), document.addEventListener("touchstart", f3, T), function() {
                U = U.filter(function(e4) {
                  return e4 !== a3;
                }), document.removeEventListener("wheel", c3, T), document.removeEventListener("touchmove", c3, T), document.removeEventListener("touchstart", f3, T);
              };
            }, []);
            var p2 = e3.removeScrollBar, _2 = e3.inert;
            return o2.createElement(
              o2.Fragment,
              null,
              _2 ? o2.createElement(a3, {
                styles: "\n  .block-interactivity-".concat(s3, " {pointer-events: none;}\n  .allow-interactivity-").concat(s3, " {pointer-events: all;}\n")
              }) : null,
              p2 ? o2.createElement(S, { gapMode: e3.gapMode }) : null
            );
          }, p.useMedium(n2), v);
          var V = o2.forwardRef(function(e3, t3) {
            return o2.createElement(m, a2({}, e3, { ref: t3, sideCar: W }));
          });
          V.classNames = m.classNames;
          let Y = V;
        },
        4490: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { DOWN: () => o2, LEFT: () => s2, RIGHT: () => a2, UP: () => i2, useSwipeable: () => x });
          var n2 = r2(810);
          let s2 = "Left", a2 = "Right", i2 = "Up", o2 = "Down", l2 = {
            delta: 10,
            preventScrollOnSwipe: false,
            rotationAngle: 0,
            trackMouse: false,
            trackTouch: true,
            swipeDuration: 1 / 0,
            touchEventOptions: { passive: true }
          }, c2 = { first: true, initial: [0, 0], start: 0, swiping: false, xy: [0, 0] }, u2 = "mousemove", f2 = "mouseup";
          function d2(e3, t3) {
            if (0 === t3) return e3;
            let r3 = Math.PI / 180 * t3;
            return [e3[0] * Math.cos(r3) + e3[1] * Math.sin(r3), e3[1] * Math.cos(r3) - e3[0] * Math.sin(r3)];
          }
          function x(e3) {
            var t3, r3, x2;
            let p, { trackMouse: _ } = e3, m = n2.useRef(Object.assign({}, c2)), v = n2.useRef(Object.assign({}, l2)), g = n2.useRef(Object.assign({}, v.current));
            for (p in g.current = Object.assign({}, v.current), v.current = Object.assign(Object.assign({}, l2), e3), l2)
              void 0 === v.current[p] && (v.current[p] = l2[p]);
            let [b, y] = n2.useMemo(
              () => (function(e4, t4) {
                let r4 = (t5) => {
                  let r5 = "touches" in t5;
                  r5 && t5.touches.length > 1 || e4((e5, s3) => {
                    s3.trackMouse && !r5 && (document.addEventListener(u2, n3), document.addEventListener(f2, p2));
                    let { clientX: a3, clientY: i3 } = r5 ? t5.touches[0] : t5, o3 = d2([a3, i3], s3.rotationAngle);
                    return s3.onTouchStartOrOnMouseDown && s3.onTouchStartOrOnMouseDown({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), {
                      initial: o3.slice(),
                      xy: o3,
                      start: t5.timeStamp || 0
                    });
                  });
                }, n3 = (t5) => {
                  e4((e5, r5) => {
                    var n4, c3, u3, f3;
                    let x4 = "touches" in t5;
                    if (x4 && t5.touches.length > 1) return e5;
                    if (t5.timeStamp - e5.start > r5.swipeDuration)
                      return e5.swiping ? Object.assign(Object.assign({}, e5), { swiping: false }) : e5;
                    let { clientX: p3, clientY: _3 } = x4 ? t5.touches[0] : t5, [m3, v2] = d2([p3, _3], r5.rotationAngle), g2 = m3 - e5.xy[0], b2 = v2 - e5.xy[1], y2 = Math.abs(g2), h = Math.abs(b2), k = (t5.timeStamp || 0) - e5.start, E = Math.sqrt(y2 * y2 + h * h) / (k || 1), w = [g2 / (k || 1), b2 / (k || 1)], j = (n4 = y2, c3 = h, u3 = g2, f3 = b2, n4 > c3 ? u3 > 0 ? a2 : s2 : f3 > 0 ? o2 : i2), O = "number" == typeof r5.delta ? r5.delta : r5.delta[j.toLowerCase()] || l2.delta;
                    if (y2 < O && h < O && !e5.swiping) return e5;
                    let R = {
                      absX: y2,
                      absY: h,
                      deltaX: g2,
                      deltaY: b2,
                      dir: j,
                      event: t5,
                      first: e5.first,
                      initial: e5.initial,
                      velocity: E,
                      vxvy: w
                    };
                    R.first && r5.onSwipeStart && r5.onSwipeStart(R), r5.onSwiping && r5.onSwiping(R);
                    let C = false;
                    return (r5.onSwiping || r5.onSwiped || r5["onSwiped".concat(j)]) && (C = true), C && r5.preventScrollOnSwipe && r5.trackTouch && t5.cancelable && t5.preventDefault(), Object.assign(Object.assign({}, e5), { first: false, eventData: R, swiping: true });
                  });
                }, x3 = (t5) => {
                  e4((e5, r5) => {
                    let n4;
                    if (e5.swiping && e5.eventData) {
                      if (t5.timeStamp - e5.start < r5.swipeDuration) {
                        n4 = Object.assign(Object.assign({}, e5.eventData), { event: t5 }), r5.onSwiped && r5.onSwiped(n4);
                        let s3 = r5["onSwiped".concat(n4.dir)];
                        s3 && s3(n4);
                      }
                    } else r5.onTap && r5.onTap({ event: t5 });
                    return r5.onTouchEndOrOnMouseUp && r5.onTouchEndOrOnMouseUp({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), { eventData: n4 });
                  });
                }, p2 = (e5) => {
                  document.removeEventListener(u2, n3), document.removeEventListener(f2, p2), x3(e5);
                }, _2 = (e5, t5) => {
                  let s3 = () => {
                  };
                  if (e5 && e5.addEventListener) {
                    let a3 = Object.assign(Object.assign({}, l2.touchEventOptions), t5.touchEventOptions), i3 = [
                      ["touchstart", r4, a3],
                      [
                        "touchmove",
                        n3,
                        Object.assign(Object.assign({}, a3), t5.preventScrollOnSwipe ? { passive: false } : {})
                      ],
                      ["touchend", x3, a3]
                    ];
                    i3.forEach((t6) => {
                      let [r5, n4, s4] = t6;
                      return e5.addEventListener(r5, n4, s4);
                    }), s3 = () => i3.forEach((t6) => {
                      let [r5, n4] = t6;
                      return e5.removeEventListener(r5, n4);
                    });
                  }
                  return s3;
                }, m2 = {
                  ref: (t5) => {
                    null !== t5 && e4((e5, r5) => {
                      if (e5.el === t5) return e5;
                      let n4 = {};
                      return e5.el && e5.el !== t5 && e5.cleanUpTouch && (e5.cleanUpTouch(), n4.cleanUpTouch = void 0), r5.trackTouch && t5 && (n4.cleanUpTouch = _2(t5, r5)), Object.assign(Object.assign(Object.assign({}, e5), { el: t5 }), n4);
                    });
                  }
                };
                return t4.trackMouse && (m2.onMouseDown = r4), [m2, _2];
              })((e4) => m.current = e4(m.current, v.current), { trackMouse: _ }),
              [_]
            );
            return t3 = m.current, r3 = v.current, x2 = g.current, m.current = r3.trackTouch && t3.el ? t3.cleanUpTouch ? r3.preventScrollOnSwipe !== x2.preventScrollOnSwipe || r3.touchEventOptions.passive !== x2.touchEventOptions.passive ? (t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) })) : t3 : Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) }) : (t3.cleanUpTouch && t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: void 0 })), b;
          }
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        9110: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.usePopoverSwipeable = t2.useReturnValue = t2.useCallbackRef = t2.useDebouncedToggle = t2.useResize = t2.useIsomorphicEffect = t2.useForceUpdateRef = t2.useElementOffsetY = t2.getElementNameByDataAttribute = t2.createIntersectionObserver = t2.useIntersectionObserver = t2.useKeyboardNavigation = t2.useScroll = t2.useForwardRef = void 0;
          var n2 = r2(245);
          Object.defineProperty(t2, "useForwardRef", {
            enumerable: true,
            get: function() {
              return n2.useForwardRef;
            }
          });
          var s2 = r2(2067);
          Object.defineProperty(t2, "useScroll", {
            enumerable: true,
            get: function() {
              return s2.useScroll;
            }
          });
          var a2 = r2(5188);
          Object.defineProperty(t2, "useKeyboardNavigation", {
            enumerable: true,
            get: function() {
              return a2.useKeyboardNavigation;
            }
          });
          var i2 = r2(5663);
          Object.defineProperty(t2, "useIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.useIntersectionObserver;
            }
          }), Object.defineProperty(t2, "createIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.createIntersectionObserver;
            }
          }), Object.defineProperty(t2, "getElementNameByDataAttribute", {
            enumerable: true,
            get: function() {
              return i2.getElementNameByDataAttribute;
            }
          });
          var o2 = r2(2101);
          Object.defineProperty(t2, "useElementOffsetY", {
            enumerable: true,
            get: function() {
              return o2.useElementOffsetY;
            }
          });
          var l2 = r2(2767);
          Object.defineProperty(t2, "useForceUpdateRef", {
            enumerable: true,
            get: function() {
              return l2.useForceUpdateRef;
            }
          });
          var c2 = r2(9019);
          Object.defineProperty(t2, "useIsomorphicEffect", {
            enumerable: true,
            get: function() {
              return c2.useIsomorphicEffect;
            }
          });
          var u2 = r2(2947);
          Object.defineProperty(t2, "useResize", {
            enumerable: true,
            get: function() {
              return u2.useResize;
            }
          });
          var f2 = r2(6699);
          Object.defineProperty(t2, "useDebouncedToggle", {
            enumerable: true,
            get: function() {
              return f2.useDebouncedToggle;
            }
          });
          var d2 = r2(8691);
          Object.defineProperty(t2, "useCallbackRef", {
            enumerable: true,
            get: function() {
              return d2.useCallbackRef;
            }
          });
          var x = r2(998);
          Object.defineProperty(t2, "useReturnValue", {
            enumerable: true,
            get: function() {
              return x.useReturnValue;
            }
          });
          var p = r2(4395);
          Object.defineProperty(t2, "usePopoverSwipeable", {
            enumerable: true,
            get: function() {
              return p.usePopoverSwipeable;
            }
          });
          var _ = r2(5969);
          Object.defineProperty(t2, "useDynamicText", {
            enumerable: true,
            get: function() {
              return _.useDynamicText;
            }
          });
        },
        8691: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useCallbackRef = void 0;
          let n2 = r2(810);
          t2.useCallbackRef = function(e3) {
            let t3 = (0, n2.useRef)({
              stableFn: function() {
                for (var e4 = arguments.length, r3 = Array(e4), n3 = 0; n3 < e4; n3++) r3[n3] = arguments[n3];
                return t3.current.callback(...r3);
              },
              callback: e3
            });
            return (0, n2.useInsertionEffect)(() => {
              t3.current.callback = e3;
            }), t3.current.stableFn;
          };
        },
        1381: (e2, t2, r2) => {
          var n2;
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useComponentSwipeable = t2.SwipeablePlacement = void 0;
          let s2 = r2(4490), a2 = r2(8691);
          !(function(e3) {
            e3.TOP = "top", e3.BOTTOM = "bottom", e3.RIGHT = "right", e3.LEFT = "left";
          })(n2 || (t2.SwipeablePlacement = n2 = {}));
          let i2 = (e3) => {
            let { ref: t3, deltaY: r3, deltaX: s3, placement: a3 } = e3;
            requestAnimationFrame(() => {
              t3.current && (t3.current.style.willChange = "transform", t3.current.style.transform = a3 === n2.TOP || a3 === n2.BOTTOM ? "translateY(".concat(r3 || 0, "px)") : "translateX(".concat(s3 || 0, "px)"));
            });
          }, o2 = (e3) => {
            requestAnimationFrame(() => {
              e3.current && (e3.current.style.transition = "none", e3.current.style.willChange = "", e3.current.style.transform = "");
            });
          };
          t2.useComponentSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: l2, disableSwipe: c2, placement: u2, threshold: f2 } = e3, d2 = (0, a2.useCallbackRef)(() => {
              l2 && (o2(t3), l2());
            }), x = (0, a2.useCallbackRef)((e4) => {
              c2 || ((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3 } = e5;
                switch (a3) {
                  case n2.TOP:
                    r4 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.RIGHT:
                    s3 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  case n2.LEFT:
                    s3 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                    break;
                  default:
                    r4 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: s3, placement: a3 });
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2 });
            }), p = (0, a2.useCallbackRef)((e4) => {
              !c2 && (((e5) => {
                let { ref: t4, deltaY: r4, deltaX: s3, placement: a3, threshold: i3 = 25 } = e5;
                if (!t4.current) return false;
                let o3 = i3 / 100 * (a3 === n2.TOP || a3 === n2.BOTTOM ? t4.current.offsetHeight : t4.current.offsetWidth);
                switch (a3) {
                  case n2.TOP:
                    return r4 < 0 && Math.abs(r4) >= o3;
                  case n2.RIGHT:
                    return s3 > 0 && s3 >= o3;
                  case n2.LEFT:
                    return s3 < 0 && Math.abs(s3) >= o3;
                  default:
                    return r4 > 0 && r4 >= o3;
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2, threshold: f2 }) ? l2 && (o2(t3), l2()) : o2(t3));
            });
            return {
              handlers: (0, s2.useSwipeable)({ onSwiped: p, onSwiping: x, trackMouse: true, trackTouch: true, ...r3 }),
              onCloseCallback: d2
            };
          };
        },
        6699: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let n2 = r2(352), s2 = r2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: r3, throttleTimeout: a2 } = e3, i2 = (0, s2.useRef)(null), [o2, l2] = (0, s2.useState)(!!r3), c2 = (0, s2.useMemo)(
              () => (0, n2.throttle)(() => {
                l2(!r3), i2.current && window.clearTimeout(i2.current), i2.current = window.setTimeout(() => {
                  l2(!!r3);
                }, t3);
              }, a2),
              [t3, r3, a2]
            ), u2 = (0, s2.useCallback)(() => {
              l2(!!r3), i2.current && window.clearTimeout(i2.current);
            }, [r3]);
            return (0, s2.useEffect)(
              () => () => {
                i2.current && window.clearTimeout(i2.current);
              },
              []
            ), { state: o2, handleDebouncedToggle: c2, reset: u2 };
          };
        },
        5969: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.findOptimalFontSize = void 0;
          let n2 = r2(810), s2 = (e3) => {
            e3.style.wordBreak = "keep-all", e3.style.overflowWrap = "normal", e3.style.maxHeight = "none", e3.style.height = "auto", e3.style.overflow = "visible", Array.from(e3.children).forEach((e4) => {
              e4 instanceof HTMLElement && s2(e4);
            });
          };
          t2.findOptimalFontSize = (e3) => {
            let {
              container: t3,
              containerWidth: r3,
              containerHeight: n3,
              minFontSize: a2,
              maxFontSize: i2,
              lineHeight: o2,
              maxLines: l2
            } = e3, c2 = ((e4, t4, r4) => {
              let n4 = e4.cloneNode(true);
              return n4.style.cssText = "\n        position: absolute !important;\n        visibility: hidden !important;\n        pointer-events: none !important;\n        width: ".concat(
                t4,
                "px !important;\n    "
              ), s2(n4), n4.style.setProperty("--dynamic-line-height", String(r4)), document.body.appendChild(n4), n4;
            })(t3, r3, o2);
            try {
              let e4 = a2, t4 = i2, s3 = a2;
              for (; e4 <= t4; ) {
                let a3 = Math.floor((e4 + t4) / 2);
                c2.style.setProperty("--dynamic-font-size", "".concat(a3, "px"));
                let i3 = Math.min(l2 * a3 * o2, n3), u2 = c2.scrollHeight <= i3, f2 = c2.scrollWidth <= r3 + 1;
                u2 && f2 ? (s3 = a3, e4 = a3 + 1) : t4 = a3 - 1;
              }
              return s3 - 1;
            } finally {
              c2.remove();
            }
          }, t2.useDynamicText = (e3, r3) => {
            (0, n2.useLayoutEffect)(() => {
              if (null === e3) return;
              e3.style.setProperty("--dynamic-line-height", String(r3.lineHeight));
              let n3 = () => {
                let { width: n4, height: s4 } = e3.getBoundingClientRect(), a3 = e3.childNodes.length > 0;
                if (0 === n4 || 0 === s4 || !a3) return;
                let i2 = (0, t2.findOptimalFontSize)({ container: e3, containerWidth: n4, containerHeight: s4, ...r3 });
                e3.style.setProperty("--dynamic-font-size", "".concat(i2, "px"));
              }, s3 = new ResizeObserver(n3), a2 = new MutationObserver(n3);
              return s3.observe(e3), a2.observe(e3, { childList: true, characterData: true, subtree: true }), document.fonts.ready.then(n3), n3(), () => {
                s3.disconnect(), a2.disconnect();
              };
            }, [e3, r3]);
          };
        },
        2101: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useElementOffsetY = void 0;
          let n2 = r2(810), s2 = r2(2067), a2 = r2(2767);
          t2.useElementOffsetY = (e3) => {
            let [t3, r3] = (0, a2.useForceUpdateRef)(), [i2, o2] = (0, n2.useState)(), l2 = (0, n2.useCallback)(() => {
              let e4 = null == t3 ? void 0 : t3.getBoundingClientRect();
              e4 && o2(e4.y);
            }, [t3]);
            return (0, n2.useLayoutEffect)(l2), (0, s2.useScroll)({ onScroll: l2, elementRef: e3 }), { forceUpdateRefCallback: r3, offsetY: i2 };
          };
        },
        2767: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForceUpdateRef = void 0;
          let n2 = r2(810);
          t2.useForceUpdateRef = () => {
            let [e3, t3] = (0, n2.useState)(null);
            return [
              e3,
              (0, n2.useCallback)((e4) => {
                t3((t4) => t4 !== e4 ? e4 : t4);
              }, [])
            ];
          };
        },
        245: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForwardRef = void 0;
          let n2 = r2(810);
          t2.useForwardRef = function(e3, t3) {
            let r3 = (0, n2.useRef)(t3);
            return (0, n2.useEffect)(() => {
              e3 && ("function" == typeof e3 ? e3(r3.current) : e3.current = r3.current);
            }, [e3]), r3;
          };
        },
        5663: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIntersectionObserver = t2.createIntersectionObserver = t2.getElementNameByDataAttribute = t2.isInViewportNow = t2.defaultOptions = void 0;
          let n2 = r2(810), { innerWidth: s2 = 0, innerHeight: a2 = 0 } = window;
          function i2(e3) {
            let { top: t3, right: r3, bottom: n3, left: i3 } = e3.getBoundingClientRect();
            return (t3 >= 0 && t3 <= a2 || n3 >= 0 && n3 <= a2) && (i3 >= 0 && i3 <= s2 || r3 >= 0 && r3 <= s2);
          }
          function o2(e3) {
            var t3, r3;
            let n3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "data-intersection-property-id";
            return null != (r3 = null == e3 || null == (t3 = e3.getAttribute) ? void 0 : t3.call(e3, n3)) ? r3 : e3.attributes[0];
          }
          function l2(e3, t3) {
            let r3 = new IntersectionObserver((t4) => {
              t4.forEach((t5) => {
                e3(t5, r3);
              });
            }, t3);
            return r3;
          }
          t2.defaultOptions = { threshold: 0, preflightCheck: true }, t2.isInViewportNow = i2, t2.getElementNameByDataAttribute = o2, t2.createIntersectionObserver = l2, t2.useIntersectionObserver = function(e3, r3, s3) {
            let [{ freezeOnceVisible: a3, preflightCheck: c2, ...u2 }, f2 = false] = "boolean" == typeof r3 || void 0 === r3 ? [t2.defaultOptions, r3] : [{ ...t2.defaultOptions, ...r3 }, s3], [d2, x] = (0, n2.useState)({}), p = (0, n2.useRef)(/* @__PURE__ */ new Set()), _ = (0, n2.useMemo)(
              () => f2 ? null : l2((e4) => {
                let t3 = o2(e4.target);
                if (t3 && _) {
                  if (p.current.has(t3)) return;
                  x((r4) => ({ ...r4, [t3]: { isIntersecting: e4.isIntersecting } })), a3 && e4.isIntersecting && (p.current.add(t3), _.unobserve(e4.target));
                }
              }, u2),
              [f2]
            );
            return (0, n2.useLayoutEffect)(
              () => (_ && !f2 && e3.forEach((e4) => {
                if (e4.current) {
                  let t3 = false;
                  if (c2 && (t3 = i2(e4.current))) {
                    let t4 = o2(e4.current);
                    x((e5) => ({ ...e5, [t4]: { isIntersecting: true } }));
                  }
                  t3 || _.observe(e4.current);
                }
              }), () => {
                _ && _.disconnect();
              }),
              [f2, _, e3.length]
            ), d2;
          };
        },
        9019: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIsomorphicEffect = void 0;
          let n2 = r2(810);
          t2.useIsomorphicEffect = "undefined" != typeof document ? n2.useLayoutEffect : n2.useEffect;
        },
        5188: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useKeyboardNavigation = void 0;
          let n2 = r2(810);
          function s2(e3, t3) {
            return e3.current ? Array.from(t3 ? e3.current.querySelectorAll(t3) : e3.current.children) : [];
          }
          t2.useKeyboardNavigation = function(e3) {
            let t3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, { navigationItemsSelector: r3, activeAttributeName: a2 = "aria-selected" } = t3, i2 = (0, n2.useCallback)(
              (t4) => {
                let n3 = s2(e3, r3);
                if (!n3.length) return;
                let a3 = t4.target, i3 = n3.indexOf(a3);
                if (-1 === i3) return;
                let [o2] = n3, l2 = n3.at(-1), c2 = null;
                switch (t4.key) {
                  case "ArrowLeft":
                  case "ArrowUp":
                    c2 = n3[i3 - 1] || l2;
                    break;
                  case "ArrowRight":
                  case "ArrowDown":
                    c2 = n3[i3 + 1] || o2;
                    break;
                  case "Home":
                    c2 = o2;
                    break;
                  case "End":
                    c2 = l2;
                }
                null !== c2 && (c2.focus(), t4.preventDefault());
              },
              [r3, e3]
            );
            (0, n2.useEffect)(() => {
              let t4 = e3.current;
              return null == t4 || t4.addEventListener("keydown", i2), () => null == t4 ? void 0 : t4.removeEventListener("keydown", i2);
            }, [e3, i2]), (0, n2.useEffect)(() => {
              s2(e3, r3).forEach((e4) => {
                e4.hasAttribute(a2) && ("true" === e4.getAttribute(a2) ? e4.tabIndex = 0 : e4.tabIndex = -1);
              });
            });
          };
        },
        4395: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.usePopoverSwipeable = void 0;
          let n2 = r2(810), s2 = r2(1381);
          t2.usePopoverSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: a2, disableSwipe: i2, placement: o2, threshold: l2 } = e3, c2 = (0, n2.useMemo)(() => {
              switch (o2) {
                case "top":
                case "top-end":
                case "top-start":
                  return s2.SwipeablePlacement.TOP;
                case "right":
                case "right-end":
                case "right-start":
                  return s2.SwipeablePlacement.RIGHT;
                case "left":
                case "left-end":
                case "left-start":
                  return s2.SwipeablePlacement.LEFT;
                default:
                  return s2.SwipeablePlacement.BOTTOM;
              }
            }, [o2]);
            return (0, s2.useComponentSwipeable)({
              ref: t3,
              swipeableProps: r3,
              onClose: a2,
              disableSwipe: i2,
              placement: c2,
              threshold: l2
            });
          };
        },
        2947: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useResize = void 0;
          let n2 = r2(810), s2 = r2(361);
          t2.useResize = (e3, t3) => {
            (0, n2.useEffect)(() => {
              let r3 = (0, s2.getElementFromRefOrElement)(t3);
              if (null === r3) return;
              let n3 = null != r3 ? r3 : document.documentElement, a2 = new ResizeObserver(e3);
              return a2.observe(n3), () => a2.disconnect();
            }, [t3, e3]);
          };
        },
        998: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useReturnValue = void 0, t2.useReturnValue = (e3) => e3();
        },
        2067: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useScroll = void 0;
          let n2 = r2(810), s2 = r2(361), a2 = r2(6699);
          t2.useScroll = (e3) => {
            let { onScroll: t3, listenIsScrolling: r3, elementRef: i2 } = e3, { state: o2, handleDebouncedToggle: l2 } = (0, a2.useDebouncedToggle)({
              delay: 1e3,
              throttleTimeout: 100
            }), c2 = (0, n2.useCallback)(() => {
              r3 && l2(), null == t3 || t3();
            }, [r3, l2, t3]);
            return (0, n2.useEffect)(() => {
              let e4 = (0, s2.getElementFromRefOrElement)(i2);
              if (null === e4) return;
              let t4 = null != e4 ? e4 : window, r4 = { capture: true, passive: true };
              return t4.addEventListener("scroll", c2, r4), () => t4.removeEventListener("scroll", c2, r4);
            }, [i2, c2]), o2;
          };
        },
        4601: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useToggle = void 0;
          let n2 = r2(810);
          t2.useToggle = (e3) => {
            let [t3, r3] = (0, n2.useState)(e3);
            (0, n2.useEffect)(() => {
              r3(e3);
            }, [e3]);
            let s2 = (0, n2.useCallback)(() => {
              r3((e4) => !e4);
            }, []), a2 = (0, n2.useCallback)(() => {
              r3(true);
            }, []), i2 = (0, n2.useCallback)(() => {
              r3(false);
            }, []);
            return { state: t3, toggle: s2, setState: r3, toggleTrue: a2, toggleFalse: i2 };
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        9430: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Popover = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(1964), o2 = r2(5881), l2 = r2(6544), c2 = r2(5853), u2 = r2(7601), f2 = r2(4395), d2 = n2(r2(7820));
          t2.Popover = (e3) => {
            var t3;
            let {
              children: r3,
              offsetOptions: n3,
              strategy: x,
              placement: p,
              isMobile: _,
              visuallyHiddenDismiss: m,
              positionElement: v,
              transform: g,
              initialOpen: b = false,
              open: y,
              onOpenChange: h,
              disableFloatingStyles: k = false,
              overlayClassName: E,
              style: w,
              returnFocus: j,
              isNested: O = false,
              onShow: R,
              customRoleProps: C,
              portalNode: S,
              isEnabled: P = true,
              arrowProps: A,
              lockScroll: T = true,
              popoverContentRef: H,
              transitionDuration: M = 150
            } = e3, [N, I] = r3, [L, B] = (0, a2.useState)(b), [D, z] = (0, a2.useState)(null), F = (0, a2.useRef)([]), U = (0, a2.useRef)([]), W = (0, i2.useFloatingNodeId)(), V = (0, i2.useFloatingParentNodeId)(), Y = (0, i2.useListItem)(), K = (0, i2.useFloatingTree)(), X = (0, a2.useRef)(null), q = h || B, Q = void 0 !== y, G = (0, a2.useCallback)(() => {
              q(false);
            }, [q]), {
              refs: Z,
              floatingStyles: $,
              context: J
            } = (0, i2.useFloating)({
              nodeId: W,
              open: Q ? y : L,
              onOpenChange: q,
              placement: p,
              middleware: [
                (0, i2.offset)(n3),
                (0, i2.flip)({ crossAxis: null == p ? void 0 : p.includes("end") }),
                (0, i2.shift)({ padding: 5 }),
                ...(null == A ? void 0 : A.isEnabled) ? [(0, i2.arrow)({ element: X })] : []
              ],
              whileElementsMounted: i2.autoUpdate,
              strategy: x,
              transform: g
            }), ee = (0, a2.useId)(), et = (0, a2.useId)(), er = (0, i2.useListNavigation)(J, { listRef: F, activeIndex: D, nested: O, onNavigate: z }), en = (0, i2.useTypeahead)(J, { listRef: U, onMatch: L ? z : void 0, activeIndex: D });
            (0, a2.useEffect)(() => {
              if (!K) return;
              let e4 = () => {
                B(false);
              }, t4 = (e5) => {
                e5.nodeId !== W && e5.parentId === V && B(false);
              };
              return K.events.on("click", e4), K.events.on("menuopen", t4), () => {
                K.events.off("click", e4), K.events.off("menuopen", t4);
              };
            }, [K, W, V, B]), (0, a2.useEffect)(() => {
              L && (null == R || R());
            }, [R, L]), (0, a2.useEffect)(() => {
              L && K && K.events.emit("menuopen", { parentId: V, nodeId: W });
            }, [K, L, W, V]), (0, a2.useLayoutEffect)(() => {
              v && Z.setPositionReference(v);
            }, [Z, v]);
            let { handlers: es } = (0, f2.usePopoverSwipeable)({
              ref: Z.floating,
              onClose: G,
              placement: p,
              disableSwipe: !_,
              swipeableProps: { preventScrollOnSwipe: true }
            }), ea = H ? [Z.setFloating, H] : [Z.setFloating, null == es ? void 0 : es.ref], ei = (0, i2.useMergeRefs)(ea), eo = (0, i2.useRole)(J, C), el = (0, i2.useDismiss)(J, { referencePress: true }), ec = (0, i2.useClick)(J, { enabled: P, toggle: !O, ignoreMouse: O }), eu = (0, i2.useHover)(J, {
              enabled: O && P,
              handleClose: (0, i2.safePolygon)({ blockPointerEvents: true })
            }), ef = (0, a2.useCallback)((e4) => {
              e4.stopPropagation();
            }, []), {
              getReferenceProps: ed,
              getFloatingProps: ex,
              getItemProps: ep
            } = (0, i2.useInteractions)([eo, el, ec, eu, er, en]), [e_, em] = (() => {
              switch (p) {
                case "bottom":
                default:
                  return ["translate(0, 10%)", "translate(0, 0)"];
                case "right":
                  if ("undefined" != typeof document && "rtl" === document.dir)
                    return ["translateX(-5%)", "translateX(0)"];
                  return ["translateX(5%)", "translateX(0)"];
              }
            })(), { isMounted: ev, styles: eg } = (0, i2.useTransitionStyles)(J, {
              initial: { opacity: 0, transform: e_ },
              open: { opacity: 1, transform: em },
              duration: M
            }), eb = (0, i2.useMergeRefs)([Z.setReference, Y.ref]), ey = N && (0, a2.cloneElement)(N, {
              ref: eb,
              ...ed({ onClick: null == (t3 = N.props) ? void 0 : t3.onClick }),
              key: ee
            }), eh = (0, a2.useMemo)(
              () => _ ? { ...k ? {} : $, ...w, bottom: 0, left: 0, right: 0, top: "auto", transform: "none" } : { ...k ? {} : $, ...w },
              [_, k, $, w]
            ), ek = (0, a2.useMemo)(() => {
              if (null == A ? void 0 : A.isEnabled) return (0, s2.jsx)(u2.PopoverArrow, { ref: X, context: J, ...A });
            }, [A, J]), eE = {
              ref: ei,
              style: { ...eg, ...eh },
              ...ex(),
              onMouseDown: H || null == es ? void 0 : es.onMouseDown,
              arrow: ek,
              children: (0, a2.cloneElement)(I.props.children, { onClose: G, key: et })
            }, ew = (0, a2.cloneElement)(I, eE), ej = (0, a2.useMemo)(
              () => ({ activeIndex: D, setActiveIndex: z, getItemProps: ep, isOpen: L }),
              [D, ep, L]
            ), eO = O ? -1 : 0;
            return (0, s2.jsxs)(c2.PopoverContext.Provider, {
              value: ej,
              children: [
                ey,
                (0, s2.jsx)(i2.FloatingList, {
                  elementsRef: F,
                  children: ev && (0, s2.jsxs)(i2.FloatingPortal, {
                    root: S,
                    children: [
                      (0, s2.jsx)(i2.FloatingOverlay, { className: (0, o2.clsx)(d2.default.overlay, E), onClick: ef }),
                      (0, s2.jsx)(i2.FloatingFocusManager, {
                        context: J,
                        returnFocus: j,
                        initialFocus: eO,
                        visuallyHiddenDismiss: m,
                        children: (0, s2.jsx)(l2.RemoveScroll, { enabled: T && L, children: ew })
                      })
                    ]
                  })
                })
              ]
            });
          };
        },
        7601: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverArrow = t2.PopoverArrowComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(9110), l2 = r2(4601), c2 = n2(r2(4123)), u2 = { top: "", left: "rotate(-90deg)", bottom: "rotate(180deg)", right: "rotate(90deg)" };
          t2.PopoverArrowComponent = (e3) => {
            let {
              forwardRef: t3,
              className: r3,
              context: n3,
              width: i3 = 14,
              height: f2 = 7,
              tipRadius: d2 = 0,
              customClipPath: x,
              staticOffset: p,
              style: { transform: _, ...m } = {},
              isEnabled: v,
              ...g
            } = e3, {
              placement: b,
              elements: { floating: y },
              middlewareData: { arrow: h }
            } = n3, { state: k, toggleTrue: E } = (0, l2.useToggle)(false);
            if ((0, o2.useIsomorphicEffect)(() => {
              y && "rtl" === getComputedStyle(y).direction && E();
            }, [y, E]), !y || !v)
              return null;
            let w = i3 / 2 * (-(d2 / 8) + 1), j = f2 / 2 * d2 / 4, [O, R] = b.split("-"), C = p && "end" === R ? "right" : "left";
            p && k && (C = "end" === R ? "left" : "right");
            let S = (null == h ? void 0 : h.x) ? p || h.x : "", P = (null == h ? void 0 : h.y) ? p || h.y : "", A = u2[O], T = x || '"M0,0' + " H".concat(i3) + " L".concat(i3 - w, ",").concat(f2 - j) + " Q".concat(i3 / 2, ",").concat(f2, " ").concat(w, ",").concat(f2 - j) + ' Z"', H = {
              [C]: S,
              [p && "end" === R ? "bottom" : "top"]: P,
              [O]: "100%",
              transform: "".concat(A).concat(null != _ ? _ : ""),
              "--arrow-width": "".concat(i3, "px"),
              "--arrow-clip-path": T,
              ...m
            };
            return (0, s2.jsx)("div", { ...g, className: (0, a2.clsx)(c2.default.root, r3), ref: t3, style: H });
          }, t2.PopoverArrow = (0, i2.forwardRef)(
            (e3, r3) => (0, s2.jsx)(t2.PopoverArrowComponent, { forwardRef: r3, ...e3 })
          );
        },
        1688: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverContent = t2.PopoverContentComponent = void 0;
          let s2 = r2(4377), a2 = r2(810), i2 = r2(5881), o2 = n2(r2(5909));
          t2.PopoverContentComponent = (e3) => {
            let { className: t3, children: r3, forwardRef: n3, arrow: l2, ...c2 } = e3;
            return (0, s2.jsxs)("div", {
              className: (0, i2.clsx)(o2.default.root, t3),
              ref: n3,
              ...c2,
              children: [r3, (0, a2.isValidElement)(l2) && l2]
            });
          }, t2.PopoverContent = (0, a2.forwardRef)(
            (e3, r3) => (0, s2.jsx)(t2.PopoverContentComponent, { forwardRef: r3, ...e3 })
          );
        },
        5853: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.PopoverContext = void 0, t2.PopoverContext = (0, r2(810).createContext)({
            getItemProps: () => ({}),
            activeIndex: null,
            setActiveIndex: () => {
            },
            isOpen: false
          });
        },
        1964: (e2) => {
          e2.exports = s;
        },
        352: (e2) => {
          e2.exports = a;
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(i, 2));
        }
      }, l = {};
      function c(e2) {
        var t2 = l[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = l[e2] = { exports: {} };
        return o[e2].call(r2.exports, r2, r2.exports, c), r2.exports;
      }
      c.d = (e2, t2) => {
        for (var r2 in t2) c.o(t2, r2) && !c.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, c.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), c.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      }, c.nc = void 0;
      var u = {};
      (() => {
        Object.defineProperty(u, "__esModule", { value: true }), u.PopoverContent = u.Popover = void 0;
        var e2 = c(9430);
        Object.defineProperty(u, "Popover", {
          enumerable: true,
          get: function() {
            return e2.Popover;
          }
        });
        var t2 = c(1688);
        Object.defineProperty(u, "PopoverContent", {
          enumerable: true,
          get: function() {
            return t2.PopoverContent;
          }
        });
      })();
      var f = u.Popover, d = u.PopoverContent;
      u.__esModule;
    },
    92714: () => {
    },
    92750: (e) => {
      e.exports = {
        root: "OverwrittenExperimentsModal_root__amBOc",
        header: "OverwrittenExperimentsModal_header__9LrO1",
        content: "OverwrittenExperimentsModal_content__Eki5k",
        closeModalButton: "OverwrittenExperimentsModal_closeModalButton__k0LqG",
        reloadButton: "OverwrittenExperimentsModal_reloadButton__bskTH",
        heading: "OverwrittenExperimentsModal_heading__9oiHL",
        overrideForm: "OverwrittenExperimentsModal_overrideForm__cJ8PH",
        overrideInput: "OverwrittenExperimentsModal_overrideInput__cYffP",
        valueInput: "OverwrittenExperimentsModal_valueInput__goR3Y",
        shake: "OverwrittenExperimentsModal_shake__mFxEK",
        submitButton: "OverwrittenExperimentsModal_submitButton___VRmz",
        experimentsList: "OverwrittenExperimentsModal_experimentsList__PFRVV",
        overridedExperiment: "OverwrittenExperimentsModal_overridedExperiment__w1bng"
      };
    },
    92946: (e, t, r) => {
      "use strict";
      r.d(t, { J: () => n });
      var n = (function(e2) {
        return e2.E = "e", e2.NUMERIC = "18+", e2.EXCLAMATION = "!", e2;
      })({});
    },
    93206: (e, t, r) => {
      "use strict";
      r.d(t, { ShareButton: () => x });
      var n = r(54486), s = r(28303), a = r(43426), i = r(31500), o = r(8817), l = r(77881), c = r(5956), u = r(39139), f = r(17061), d = r(50215);
      let x = (0, s.PA)((e2) => {
        let {
          className: t2,
          size: r2 = "s",
          iconSize: s2 = "xxs",
          withRipple: x2,
          isDisabled: p,
          entityMeta: _,
          shareLink: m,
          onClick: v
        } = e2, { formatMessage: g } = (0, a.A)(), { notify: b } = (0, f.l)(), y = (0, o.c)(async () => {
          null == v || v(), await window.navigator.clipboard.writeText(m), b((0, n.jsx)(d.NotificationCopy, { entityVariant: _.variant, entityTitle: _.title }), {
            containerId: u.u.INFO
          });
        });
        return (0, n.jsx)(l.$, {
          className: t2,
          variant: "default",
          color: "secondary",
          onClick: y,
          "aria-label": g({ id: "interface-actions.share" }),
          size: r2,
          withRipple: x2,
          radius: "round",
          disabled: p,
          icon: (0, n.jsx)(c.Icon, { variant: "share", size: s2 }),
          ...(0, i.Am)(i.S7.SHARE_BUTTON)
        });
      });
    },
    93666: (e, t, r) => {
      "use strict";
      r.d(t, { ZI: () => d, m_: () => f });
      var n, s = r(88834), a = r(15209), i = r(61910), o = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, s3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) s3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (s3 && (s3 += " "), s3 += n4);
                  else for (r4 in t4) t4[r4] && (s3 && (s3 += " "), s3 += r4);
                return s3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => s2 });
          let s2 = n2;
        },
        2322: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = { root: "QhR4J536RmNHBB5bZYwF", text: "Fqg1VWCJUfasVVxqICeO" };
        },
        3641: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root_controls_xxs: "tRaaBpDMg9Qu8v6gKjtn",
            root_entity_xxs: "M9zvtlcpLUVn6DKdcHhj",
            root_text_xxs: "ln0PYYwDmFnfYxCDJsFU",
            root_controls_xs: "n5AeWEsJC3_AYXcbK4Lt",
            root_entity_xs: "__hrMKGmNbw54T54IUyh",
            root_text_xs: "SehSa7OyRpC2nzYTVb2Q",
            root_controls_s: "_oBLf5gprWsKjCw4Ce58",
            root_entity_s: "mxSPe5xpZnie9gpIqacd",
            root_text_s: "Ai2iRN9elHpk_u5splD6",
            root_controls_m: "tk7ahHRDYXJMMB879KUA",
            root_entity_m: "Z_WIr2W8JU4MPQek3hgR",
            root_text_m: "g3qWNP6xl__7qxNmtrvd",
            root_controls_l: "grvxapJE3vGArOKDWf6n",
            root_entity_l: "Esj5A1UeSi4xV4tZ839D",
            root_text_l: "V3WU123oO65AxsprotU9",
            root_weight_normal: "ZYV27jeWd30QDXu4GhaH",
            root_weight_medium: "_3_Mxw7Si7j2g4kWjlpR",
            root_weight_bold: "Vi7Rd0SZWqD17F0872TB"
          };
        },
        5818: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "_MWOVuZRvUQdXKTMcOPx",
            root_clamp: "LezmJlldtbHWqU7l1950",
            root_clamp_oneline: "oyQL2RSmoNbNQf3Vc6YI",
            root_clamp_multiline: "jMyoZB5J9iZbzJmWOrF0"
          };
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var s2 = null;
            if (void 0 !== n3 && (s2 = "" + n3), void 0 !== t3.key && (s2 = "" + t3.key), "key" in t3)
              for (var a2 in n3 = {}, t3) "key" !== a2 && (n3[a2] = t3[a2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: s2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        58: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Tooltip = void 0;
          let n2 = r2(4377), s2 = r2(810), a2 = r2(1964), i2 = r2(2660), o2 = r2(3770), l2 = r2(5481);
          t2.Tooltip = (e3) => {
            let { enableAriaDescribedby: t3 = false, text: r3, children: c2, referenceRef: u2, ...f2 } = e3, [d2, x] = Array.isArray(c2) ? c2 : [c2], p = (0, l2.useTooltip)(f2), _ = (0, s2.useId)(), m = (0, s2.useId)(), v = (0, s2.useId)(), g = (0, a2.useMergeRefs)([p.refs.setReference, u2]);
            return (0, n2.jsxs)(n2.Fragment, {
              children: [
                (0, s2.cloneElement)(d2, {
                  ref: g,
                  ...t3 ? { "aria-describedby": _ } : {},
                  ...p.getReferenceProps(),
                  ...(0, i2.getDataAttrFromProps)(f2),
                  key: m
                }),
                p.context.open ? (0, s2.cloneElement)(null != x ? x : (0, n2.jsx)(o2.TooltipContent, {}), {
                  ref: p.refs.setFloating,
                  style: { ...p.floatingStyles, visibility: p.referenceHidden ? "hidden" : "visible" },
                  text: r3,
                  arrow: p.arrow,
                  ...t3 ? { id: _ } : {},
                  ...p.getFloatingProps(),
                  key: v
                }) : null
              ]
            });
          };
        },
        3770: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.TooltipContent = t2.TooltipContentComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(1964), l2 = r2(7743), c2 = n2(r2(2322));
          t2.TooltipContentComponent = (e3) => {
            let { className: t3, children: r3, arrow: n3, rootNode: u2, forwardRef: f2, text: d2, ...x } = e3;
            return (0, s2.jsx)(o2.FloatingPortal, {
              root: u2,
              children: (0, s2.jsxs)("div", {
                className: (0, a2.clsx)(c2.default.root, t3),
                ref: f2,
                ...x,
                children: [
                  (0, i2.isValidElement)(n3) && n3,
                  (0, s2.jsx)(l2.Caption, {
                    variant: "div",
                    type: "text",
                    size: "s",
                    weight: "medium",
                    className: c2.default.text,
                    children: null != r3 ? r3 : d2
                  })
                ]
              })
            });
          }, t2.TooltipContent = (0, i2.forwardRef)(
            (e3, r3) => (0, s2.jsx)(t2.TooltipContentComponent, { forwardRef: r3, ...e3 })
          );
        },
        5481: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useTooltip = void 0;
          let n2 = r2(4377), s2 = r2(810), a2 = r2(1964), i2 = { delay: { open: 200, close: 0 } };
          t2.useTooltip = function(e3) {
            let {
              initialOpen: t3 = false,
              placement: r3 = "top",
              open: o2,
              onOpenChange: l2,
              isHoverEnabled: c2 = true,
              isFocusEnabled: u2 = true,
              offsetOptions: f2,
              flipOptions: d2 = {},
              shiftOptions: x = {},
              hoverSettings: p = i2,
              enabled: _ = true,
              arrowProps: m
            } = e3, [v, g] = (0, s2.useState)(t3), b = (0, s2.useRef)(null), y = null != o2 ? o2 : v, h = null != l2 ? l2 : g, k = (0, a2.useFloating)({
              placement: r3,
              open: y,
              onOpenChange: h,
              whileElementsMounted: a2.autoUpdate,
              middleware: [
                (0, a2.offset)(f2),
                (0, a2.flip)({ crossAxis: r3.includes("-"), ...d2 }),
                (0, a2.shift)(x),
                (0, a2.arrow)({ element: b }),
                (0, a2.hide)()
              ]
            }), E = k.context, w = (0, a2.useHover)(E, { move: false, enabled: c2 && _, ...p }), j = (0, a2.useFocus)(E, { enabled: u2 && _ }), O = (0, a2.useDismiss)(E), R = (0, a2.useRole)(E, { role: "tooltip" }), C = (0, a2.useInteractions)([w, j, O, R]), S = (0, s2.useMemo)(() => {
              if (m) return (0, n2.jsx)(a2.FloatingArrow, { ref: b, context: k.context, ...m });
            }, [m, k.context]);
            return (0, s2.useMemo)(() => {
              var e4;
              return {
                open: y,
                setOpen: h,
                arrow: S,
                referenceHidden: null == (e4 = k.middlewareData.hide) ? void 0 : e4.referenceHidden,
                ...C,
                ...k
              };
            }, [y, h, S, C, k]);
          };
        },
        7743: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Caption = t2.CaptionComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = r2(4721), l2 = n2(r2(3641));
          t2.CaptionComponent = (e3) => {
            let {
              forwardRef: t3,
              variant: r3,
              type: n3 = "text",
              size: i3 = "s",
              className: c2,
              children: u2,
              weight: f2 = "medium",
              ...d2
            } = e3;
            return (0, s2.jsx)(o2.Typography, {
              variant: r3,
              ref: t3,
              className: (0, a2.clsx)(
                l2.default.root,
                l2.default["root_".concat(n3, "_").concat(i3)],
                l2.default["root_weight_".concat(f2)],
                c2
              ),
              ...d2,
              children: u2
            });
          }, t2.Caption = (0, i2.forwardRef)((e3, r3) => (0, s2.jsx)(t2.CaptionComponent, { forwardRef: r3, ...e3 }));
        },
        4721: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Typography = t2.TypographyComponent = void 0;
          let s2 = r2(4377), a2 = r2(5881), i2 = r2(810), o2 = n2(r2(5818));
          function l2(e3) {
            let { forwardRef: t3, style: r3, className: n3, children: i3, variant: l3, lineClamp: c2, ...u2 } = e3, f2 = c2 && "string" == typeof i3 ? i3 : void 0;
            return (0, s2.jsx)(l3, {
              style: { ...r3, WebkitLineClamp: c2 },
              ref: t3,
              title: f2,
              className: (0, a2.clsx)(
                o2.default.root,
                {
                  [o2.default.root_clamp]: c2 && c2 > 0,
                  [o2.default.root_clamp_oneline]: c2 && 1 === c2,
                  [o2.default.root_clamp_multiline]: c2 && c2 > 1
                },
                n3
              ),
              ...u2,
              children: i3
            });
          }
          t2.TypographyComponent = l2, t2.Typography = (0, i2.forwardRef)((e3, t3) => (0, s2.jsx)(l2, { forwardRef: t3, ...e3 }));
        },
        1964: (e2) => {
          e2.exports = s;
        },
        2660: (e2) => {
          e2.exports = a;
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(i, 2));
        }
      }, l = {};
      function c(e2) {
        var t2 = l[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = l[e2] = { exports: {} };
        return o[e2].call(r2.exports, r2, r2.exports, c), r2.exports;
      }
      c.d = (e2, t2) => {
        for (var r2 in t2) c.o(t2, r2) && !c.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, c.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), c.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var u = {};
      (() => {
        Object.defineProperty(u, "X$", { value: true }), u._v = u.u = void 0;
        var e2 = c(58);
        Object.defineProperty(u, "u", {
          enumerable: true,
          get: function() {
            return e2.Tooltip;
          }
        });
        var t2 = c(3770);
        Object.defineProperty(u, "_v", {
          enumerable: true,
          get: function() {
            return t2.TooltipContent;
          }
        });
      })();
      var f = u.u, d = u._v;
      u.X$;
    },
    93668: (e, t, r) => {
      "use strict";
      r.d(t, { PlusModalButton: () => d });
      var n = r(54486), s = r(50420), a = r(61910), i = r(77881), o = r(3728), l = r(97800), c = r(65508), u = r.n(c);
      let f = (e2) => {
        let {
          children: t2,
          forwardRef: r2,
          text: a2,
          isMobile: c2,
          showSpinner: f2,
          size: d2 = "m",
          className: x,
          ...p
        } = e2;
        return (0, n.jsx)(i.$, {
          className: (0, s.$)(u().button, { [u().button_mobile]: c2 }, x),
          isBlock: true,
          radius: "xxxl",
          size: d2,
          ref: r2,
          spinner: f2 ? (0, n.jsx)(o.y, {}) : null,
          ...p,
          children: null != t2 ? t2 : (0, n.jsx)(l.Caption, { className: u().text, variant: "div", size: "m", children: a2 })
        });
      }, d = (0, a.forwardRef)((e2, t2) => (0, n.jsx)(f, { forwardRef: t2, ...e2 }));
    },
    94426: (e) => {
      e.exports = {
        root: "TrailerOnboarding_root__I3fd0",
        text: "TrailerOnboarding_text__HU4RO",
        close: "TrailerOnboarding_close__ywMIK"
      };
    },
    95405: (e, t, r) => {
      "use strict";
      r.d(t, { B: () => l });
      var n = r(54486), s = r(61910), a = r(31500), i = r(58360);
      let o = (e2) => {
        let { isAvailable: t2 = true, className: r2, fallbackIconSize: s2, forwardRef: o2, ...l2 } = e2;
        return t2 ? (0, n.jsx)(i.Image, {
          ref: o2,
          className: r2,
          fallbackIconSize: s2,
          ...l2,
          ...(0, a.Am)(a.S7.ENTITY_COVER_IMAGE)
        }) : (0, n.jsx)(i.FallbackImage, {
          className: r2,
          iconSize: s2,
          iconVariant: "unavailable",
          ...(0, a.Am)(a.S7.ENTITY_COVER_FALLBACK_IMAGE)
        });
      }, l = (0, s.forwardRef)((e2, t2) => (0, n.jsx)(o, { forwardRef: t2, ...e2 }));
    },
    96584: (e, t, r) => {
      "use strict";
      r.d(t, { EntityMeta: () => x });
      var n = r(54486), s = r(50420), a = r(43426), i = r(31500), o = r(27510), l = r(5956), c = r(97800), u = r(20576), f = r(62), d = r.n(f);
      let x = (e2) => {
        let {
          isDisliked: t2,
          isDisabled: r2,
          description: f2,
          getDescriptionTexts: x2,
          explicitMarkVariant: p,
          className: _,
          version: m,
          title: v,
          artistsComponent: g,
          likesCount: b,
          isLiked: y,
          releaseYear: h
        } = e2, { formatMessage: k, formatNumber: E } = (0, a.A)(), w = (0, o.L)(() => {
          let e3 = null == g ? void 0 : g((0, s.$)(d().text, d().artistLink), (0, s.$)(d().text, d().artistCaption));
          if (!e3 && !b) return;
          let t3 = (0, n.jsx)(c.Caption, {
            variant: "span",
            size: "m",
            weight: "medium",
            "aria-hidden": true,
            children: "•"
          });
          return (0, n.jsxs)("div", {
            className: d().subtitle,
            ...(0, i.Am)(i.S7.ENTITY_CARD_ENTITY_META_SUBTITLE),
            children: [
              "number" == typeof b && b > 0 && (0, n.jsxs)("div", {
                className: d().likesCount,
                "aria-label": k({ id: "entity-names.likes-counter" }, { counter: b }),
                ...(0, i.Am)(i.S7.ENTITY_CARD_ENTITY_META_SUBTITLE_LIKES_COUNT),
                children: [
                  (0, n.jsx)(l.Icon, {
                    className: d().icon,
                    variant: y ? "likedVariant" : "likeVariant",
                    size: "xxs",
                    ...(0, i.Am)(i.S7.ENTITY_CARD_ENTITY_META_SUBTITLE_LIKES_COUNT_ICON)
                  }),
                  (0, n.jsx)(c.Caption, {
                    variant: "span",
                    size: "m",
                    weight: "medium",
                    "aria-hidden": true,
                    ...(0, i.Am)(i.S7.ENTITY_CARD_ENTITY_META_SUBTITLE_LIKES_COUNT_TEXT),
                    children: E(b)
                  })
                ]
              }),
              !!b && e3 && t3,
              e3,
              !!h && e3 && t3,
              (0, n.jsx)(c.Caption, { variant: "span", size: "m", weight: "medium", children: h })
            ]
          });
        });
        return (0, n.jsxs)("div", {
          className: (0, s.$)(d().root, { [d().root_disabled]: r2, [d().root_disliked]: t2 }, _),
          ...(0, i.Am)(i.S7.ENTITY_CARD_ENTITY_META),
          children: [
            (0, n.jsxs)("div", {
              className: d().titleContainer,
              children: [
                (0, n.jsxs)(c.Caption, {
                  className: (0, s.$)(d().text, d().title, { [d().title_withVersion]: m }),
                  size: "m",
                  variant: "div",
                  lineClamp: 1,
                  type: "text",
                  ...(0, i.Am)(i.S7.ENTITY_CARD_ENTITY_META_TITLE),
                  children: [
                    v,
                    m && (0, n.jsx)(c.Caption, {
                      className: (0, s.$)(d().text, d().version),
                      size: "m",
                      variant: "div",
                      type: "text",
                      ...(0, i.Am)(i.S7.ENTITY_CARD_ENTITY_META_VERSION),
                      children: " ".concat(m)
                    })
                  ]
                }),
                p && (0, n.jsx)(u.ExplicitMarkIcon, { className: d().explicitMark, getDescriptionTexts: x2, variant: p })
              ]
            }),
            f2 && (0, n.jsx)(c.Caption, {
              className: (0, s.$)(d().text, d().description),
              variant: "span",
              size: "m",
              weight: "medium",
              lineClamp: 1,
              ...(0, i.Am)(i.S7.ENTITY_CARD_ENTITY_META_DESCRIPTION),
              children: f2
            }),
            w
          ]
        });
      };
    },
    96838: (e, t, r) => {
      "use strict";
      r.d(t, { TrailerButton: () => f });
      var n = r(54486), s = r(61910), a = r(43426), i = r(31500), o = r(77881), l = r(5956), c = r(33566);
      let u = (e2) => {
        let {
          variant: t2,
          withRipple: r2,
          size: s2,
          radius: u2,
          iconSize: f2,
          disabled: d,
          onClick: x,
          iconClassName: p,
          className: _,
          forwardRef: m,
          style: v,
          children: g
        } = e2, { formatMessage: b } = (0, a.A)(), y = b({ id: "trailer.button-aria-label" });
        return (0, n.jsx)(o.$, {
          className: _,
          color: "secondary",
          radius: u2,
          size: s2,
          variant: t2,
          withRipple: r2,
          flexIcon: true,
          "aria-label": y,
          onClick: x,
          ref: m,
          icon: (0, n.jsx)(l.Icon, { variant: "trailer", size: f2, className: p }),
          disabled: d,
          "data-intersection-property-id": c.N,
          style: v,
          ...(0, i.Am)(i.S7.TRAILER_BUTTON),
          children: g
        });
      }, f = (0, s.forwardRef)((e2, t2) => (0, n.jsx)(u, { forwardRef: t2, ...e2 }));
    },
    99882: (e) => {
      e.exports = {
        root: "Tab_root__LUukY",
        image: "Tab_image__Hen3_",
        tab_size_s: "Tab_tab_size_s__zXitP",
        tab_size_m: "Tab_tab_size_m__c7tVg",
        tab_size_l: "Tab_tab_size_l__goM4A",
        tab_withCovers: "Tab_tab_withCovers__dJzMH",
        tab_withMissingCovers: "Tab_tab_withMissingCovers__RzwR0",
        covers: "Tab_covers__cvYeI",
        description: "Tab_description__p1fTO",
        title: "Tab_title__hAYZk",
        subtitle: "Tab_subtitle__fLp9S",
        shimmerTitle: "Tab_shimmerTitle__eQFFI",
        shimmerSubtitle: "Tab_shimmerSubtitle__0Yf3E"
      };
    }
  }
]);
