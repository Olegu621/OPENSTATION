(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [5973],
  {
    1038: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { lock: () => g, unlock: () => w });
      var n, a = r(36078);
      function o(e2) {
        return "undefined" != typeof window && null != window.navigator && e2.test(window.navigator.userAgent);
      }
      function c() {
        return o(/iphone|ipod|ipad/i) || o(/macintosh/i) && navigator.maxTouchPoints > 1;
      }
      function i(e2, t2) {
        var r2 = {};
        for (var n2 in t2) t2.hasOwnProperty(n2) && (r2[n2] = e2.style[n2]);
        for (var n2 in t2) t2.hasOwnProperty(n2) && (e2.style[n2] = t2[n2]);
        return r2;
      }
      function l(e2) {
        return e2 === document.body || e2 === document.documentElement;
      }
      var s = Math.random().toString(36).slice(2), u = "__scrollLockState$".concat(s), d = !(function() {
        var e2 = false;
        if (!a.O) return false;
        try {
          var t2 = function() {
            return null;
          };
          window.addEventListener("testPassive", t2, {
            get passive() {
              e2 = true;
              return;
            }
          }), window.removeEventListener("testPassive", t2);
        } catch (e3) {
        }
        return e2;
      })() ? void 0 : { passive: false }, f = { count: 0, lastX: 0, lastY: 0, scrollable: null, scrollX: 0, scrollY: 0 };
      function v(e2) {
        1 === e2.changedTouches.length && (f.scrollable = (function(e3) {
          for (var t2; e3 && (t2 = getComputedStyle(e3), !/(auto|scroll)/.test(t2.overflow + t2.overflowX + t2.overflowY)); )
            e3 = e3.parentElement;
          return e3 || document.documentElement;
        })(e2.target), l(f.scrollable) || (f.lastX = e2.changedTouches[0].pageX, f.lastY = e2.changedTouches[0].pageY));
      }
      function m(e2) {
        var t2 = f.scrollable, r2 = f.lastX, n2 = f.lastY;
        if (!(e2.changedTouches.length > 1)) {
          if (!t2 || l(t2)) return void e2.preventDefault();
          var a2 = e2.changedTouches[0].pageX, o2 = e2.changedTouches[0].pageY, c2 = Math.abs(n2 - o2) > Math.abs(r2 - a2), i2 = t2.scrollTop, s2 = t2.scrollHeight - t2.clientHeight, u2 = t2.scrollLeft, d2 = t2.scrollWidth - t2.clientWidth, v2 = !c2 && (u2 <= 0 && a2 > r2 || u2 >= d2 && a2 < r2);
          (c2 && (i2 <= 0 && o2 > n2 || i2 >= s2 && o2 < n2) || v2) && e2.preventDefault(), f.lastX = a2, f.lastY = o2;
        }
      }
      function h() {
        f.scrollable && (f.scrollable = null);
      }
      function p(e2) {
        return e2 || document.body;
      }
      function g(e2) {
        if (a.O) {
          var t2 = p(e2);
          !(function(e3) {
            var t3 = e3[u];
            if (t3) return t3.count++;
            var r2 = (function(e4) {
              var t4, r3 = l(e4) && window.innerWidth - document.documentElement.clientWidth > 0, a3 = e4.scrollHeight > e4.clientHeight;
              if (r3 || a3 || (t4 = getComputedStyle(e4).overflowY, /scroll/.test(t4))) {
                if ("undefined" == typeof document) return 0;
                if (void 0 === n) {
                  var o3 = document.createElement("div");
                  o3.style.width = "100%", o3.style.height = "200px";
                  var c2 = document.createElement("div");
                  c2.style.position = "absolute", c2.style.top = "0", c2.style.left = "0", c2.style.pointerEvents = "none", c2.style.visibility = "hidden", c2.style.width = "200px", c2.style.height = "150px", c2.style.overflow = "hidden", c2.appendChild(o3), document.body.appendChild(c2);
                  var i2 = o3.offsetWidth;
                  c2.style.overflow = "scroll";
                  var s2 = o3.offsetWidth;
                  i2 === s2 && (s2 = c2.clientWidth), document.body.removeChild(c2), n = i2 - s2;
                }
                return n;
              }
              return 0;
            })(e3), a2 = parseInt(getComputedStyle(e3).getPropertyValue("padding-right"), 10), o2 = i(e3, {
              paddingRight: "".concat(a2 + r2, "px"),
              overflow: "hidden",
              overflowX: "hidden",
              overflowY: "hidden"
            });
            e3[u] = { initialStyle: o2, count: 1 };
          })(t2), c() && l(t2) && (f.count++, 1 === f.count && (f.scrollX = window.pageXOffset, f.scrollY = window.pageYOffset, document.addEventListener("touchstart", v, d), document.addEventListener("touchmove", m, d), document.addEventListener("touchend", h, d)));
        }
      }
      function w(e2) {
        if (a.O) {
          var t2 = p(e2), r2 = t2[u];
          r2 && (r2.count--, 0 === r2.count) && (i(t2, r2.initialStyle), delete t2[u]), c() && l(t2) && 0 !== f.count && (f.count--, 0 === f.count && (document.removeEventListener("touchstart", v), document.removeEventListener("touchmove", m), document.removeEventListener("touchend", h), window.scrollTo(f.scrollX, f.scrollY)));
        }
      }
    },
    6018: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { Content: () => n.U, cnUserID: () => n.K });
      var n = r(34295);
    },
    6796: (e, t, r) => {
      "use strict";
      r.d(t, { E: () => a });
      var n = r(61910), a = r(36078).O ? n.useLayoutEffect : n.useEffect;
    },
    10497: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { withUserID: () => n.B });
      var n = r(39424);
    },
    18553: () => {
    },
    20102: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { useUserID: () => n.w });
      var n = r(57399);
    },
    20495: () => {
    },
    34295: (e, t, r) => {
      "use strict";
      r.d(t, { K: () => o, U: () => c });
      var n = r(61910), a = r(35618);
      r(64731);
      var o = (0, a.cn)("UserWidget", "Content"), c = n.forwardRef(function(e2, t2) {
        var r2 = e2.loading, a2 = e2.preload, c2 = e2.height, i = e2.colorScheme, l = e2.className, s = e2.src, u = e2.width;
        return n.createElement(
          "div",
          { className: o({ loading: r2, colorScheme: i }, [l]) },
          a2 && n.createElement("iframe", {
            className: "UserWidget-Iframe",
            ref: t2,
            width: u,
            src: s,
            height: r2 ? 300 : c2
          }),
          r2 && n.createElement("div", { className: "UserWidget-Spin" })
        );
      });
    },
    35618: (e, t, r) => {
      "use strict";
      e.exports = r(64921);
    },
    35761: (e, t) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true });
    },
    36078: (e, t, r) => {
      "use strict";
      r.d(t, { O: () => n });
      var n = "undefined" != typeof window && void 0 !== window.document && void 0 !== window.document.createElement;
    },
    39424: (e, t, r) => {
      "use strict";
      r.d(t, { B: () => i });
      var n = r(41500), a = r(61910), o = r(34295), c = r(57399);
      function i(e2, t2) {
        var r2, i2 = function(r3) {
          var i3 = r3.onOpen, l = r3.onClose, s = (0, n.__read)((0, a.useState)(false), 2), u = s[0], d = s[1], f = (0, a.useCallback)(
            function() {
              d(true), null == i3 || i3();
            },
            [d, i3]
          ), v = (0, a.useCallback)(
            function() {
              d(false), null == l || l();
            },
            [d, l]
          ), m = (0, c.w)((0, n.__assign)((0, n.__assign)({}, r3), { visible: u, onOpen: f, onClose: v })), h = m.avatarProps, p = m.contentProps, g = m.dialogProps;
          return a.createElement(
            e2,
            (0, n.__assign)({}, r3, h),
            r3.children,
            a.createElement(t2, (0, n.__assign)({}, g, { onClose: v }), a.createElement(o.U, (0, n.__assign)({}, p)))
          );
        };
        return i2.displayName = "'withUserID(" + (null != (r2 = e2.displayName) ? r2 : e2) + ")'", i2;
      }
    },
    46723: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { Dialog: () => n.l });
      var n = r(85319);
    },
    53357: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { User: () => m, UserBase: () => f });
      var n = r(61910), a = r(35618), o = r(71962), c = r(41500), i = function(e2, t2, r2) {
        return (void 0 === t2 && (t2 = "0/0-0"), "prod_yateam" === e2) ? "https://center.yandex-team.ru/api/v1/user/" + ("0/0-0" === t2 ? "404" : t2) + "/avatar/" + (r2 ? "85" : "42") + ".jpg" : ("test" !== e2 ? "https://avatars.mds.yandex.net" : "https://avatars.mdst.yandex.net") + "/get-yapic/" + t2 + "/" + (r2 ? "islands-retina-middle" : "islands-middle");
      };
      r(20495);
      var l = (0, a.cn)("UserID", "Avatar"), s = function(e2) {
        var t2, r2, a2, o2, s2 = e2.env, u2 = e2.avatarId, d2 = e2.plus, f2 = e2.child, v2 = e2.colorScheme, m2 = e2.className, h = (0, c.__read)((0, n.useState)(false), 2), p = h[0], g = h[1], w = (r2 = (t2 = { avatarId: u2, env: s2 }).env, a2 = t2.avatarId, {
          src: o2 = (0, n.useMemo)(
            function() {
              return i(r2, a2, false);
            },
            [r2, a2]
          ),
          srcSet: o2 + " 1x, " + (0, n.useMemo)(
            function() {
              return i(r2, a2, true);
            },
            [r2, a2]
          ) + " 2x"
        }), C = w.src, y = w.srcSet, E = (0, n.useRef)(null);
        return (0, n.useEffect)(
          function() {
            var e3 = E.current;
            window && f2 && e3 && g(e3.getBoundingClientRect().width <= 36);
          },
          [f2, E]
        ), n.createElement(
          "div",
          { className: l({ child: f2, plus: d2, small: p, dark: "dark" === v2 }, [m2]), ref: E },
          n.createElement("img", { src: C, className: "UserID-Avatar-Image", srcSet: y }),
          f2 && n.createElement(
            "svg",
            {
              className: "UserID-Avatar-ChildStroke",
              xmlns: "http://www.w3.org/2000/svg",
              viewBox: "0 0 300 300"
            },
            n.createElement("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M165.9 37.9822L166.068 38.0049C166.221 38.0257 166.442 38.0562 166.726 38.0968C167.295 38.1778 168.118 38.2987 169.162 38.4618C171.249 38.7878 174.224 39.283 177.813 39.9651C184.975 41.3261 194.666 43.4461 204.678 46.4778C214.632 49.492 225.211 53.4982 233.986 58.7338C242.568 63.8543 250.611 70.8545 253.512 80.3646C262.231 108.946 272.638 153.705 267.746 188.864C263.821 217.084 243.295 239.946 214.374 255.633C185.337 271.383 152.717 277.077 132.993 274.341C113.268 271.605 83.4377 257.247 59.8001 234.191C36.2561 211.225 22.7482 183.642 26.674 155.422C33.0239 109.778 55.8032 71.8059 70.7041 51.2431C76.2121 43.6422 85.9125 39.8089 95.3615 37.7283C105.121 35.5793 116.278 34.95 126.593 35.003C136.965 35.0564 146.789 35.8036 153.998 36.5322C157.61 36.8972 160.584 37.2595 162.664 37.5319C163.704 37.6681 164.522 37.782 165.085 37.8627C165.367 37.903 165.585 37.9351 165.736 37.9575L165.9 37.9822ZM210.975 249.385C238.745 234.322 257.19 213.071 260.694 187.886C265.355 154.381 255.388 110.913 246.701 82.4364C238.203 54.5778 164.895 45.0216 164.895 45.0216C164.895 45.0216 92.1316 33.8026 76.4727 55.4113C61.8934 75.5303 39.8488 112.394 33.7267 156.401C30.2229 181.586 42.1687 207.053 64.7756 229.104C87.5594 251.328 116.05 264.812 133.973 267.298C151.895 269.784 182.987 264.566 210.975 249.385Z"
            })
          )
        );
      };
      s.displayName = "UserIDAvatar", r(91683);
      var u = function(e2) {
        var t2 = e2.children, r2 = e2.fetchMail, a2 = e2.tld, o2 = e2.showCounter, i2 = e2.counterVariant, l2 = void 0 === i2 ? "number" : i2, s2 = e2.colorScheme, u2 = (0, c.__read)((0, n.useState)(0), 2), d2 = u2[0], f2 = u2[1];
        (0, n.useEffect)(
          function() {
            r2 && o2 && fetch("https://mail.yandex." + a2 + "/api/v2/userid/counters?silent", { credentials: "include" }).then(function(e3) {
              return e3.json();
            }).then(function(e3) {
              return f2(e3.counters.unread);
            }).catch(function(e3) {
            });
          },
          [a2, r2, o2]
        );
        var v2 = r2 && d2 > 0 ? Math.min(d2, 99) : void 0, m2 = !!(r2 && v2 && d2 > v2), h = v2 && o2 ? "" + v2 + (m2 ? "+" : "") : null, p = r2 || o2, g = ["UserID-Badge-Dot", "UserID-Badge-Dot_colorScheme_" + s2, "UserID-Badge-Dot_variant_" + l2].join(" ");
        return n.createElement(
          "div",
          { className: "UserID-Badge" },
          t2,
          p && n.createElement("div", { className: g }, "number" === l2 && h)
        );
      };
      u.displayName = "UserIDBadge", r(96835);
      var d = (0, a.cn)("UserID", "Wrapper"), f = (0, n.forwardRef)(function(e2, t2) {
        var r2 = e2.tld, a2 = e2.tabIndex, c2 = e2.children, i2 = e2.env, l2 = e2.colorScheme, f2 = e2.userData, v2 = e2.onClick, m2 = e2.onPointerEnter, h = e2.className, p = e2.fetchMail, g = e2.showCounter, w = e2.counterVariant, C = e2.visible, y = e2.ariaLabel, E = e2.avatarSize, b = e2.platform, _ = e2.beforeAvatar, S = e2.afterAvatar, k = f2 || {}, L = k.child, I = k.plus, P = k.avatarId, R = (0, n.useRef)(null);
        return (0, o.N)(R, t2), n.createElement(
          "div",
          {
            className: d({ child: L, plus: I, default: !I }, [h]),
            style: null !== E ? { "--user-id-size": (E || 42) + "px" } : void 0
          },
          n.createElement(
            "button",
            {
              "aria-expanded": C,
              "aria-haspopup": true,
              "aria-label": y || "Ваш профиль",
              className: "UserID-Account",
              ref: R,
              role: "button",
              tabIndex: void 0 === a2 ? 0 : a2,
              onClick: v2,
              onPointerEnter: m2
            },
            _,
            n.createElement(
              u,
              {
                fetchMail: p && "test" !== i2,
                counterVariant: w,
                tld: void 0 === r2 ? "ru" : r2,
                colorScheme: l2,
                showCounter: "touch" !== b && (p || true === g)
              },
              n.createElement(s, { env: i2, avatarId: P, plus: I, child: L, colorScheme: l2 })
            ),
            S
          ),
          c2
        );
      });
      f.displayName = "UserBase";
      var v = r(85319), m = (0, r(39424).B)(f, v.l);
    },
    57399: (e, t, r) => {
      "use strict";
      r.d(t, { w: () => I });
      var n, a, o = r(41500), c = r(61910), i = r(71962), l = r(6796), s = [], u = null, d = null;
      function f() {
        return s[s.length - 1];
      }
      function v(e2, t2, r2) {
        var n2, a2, o2 = f();
        o2 && o2.onClose && (!r2 || r2 === o2.closeStrategy) && ("click" === t2 && (n2 = o2.refs, a2 = e2.target, n2.some(function(e3) {
          return e3.current instanceof HTMLElement && e3.current.contains(a2);
        })) || o2.onClose({ nativeEvent: e2, source: t2 }));
      }
      function m(e2) {
        var t2 = e2.key;
        ("Escape" === t2 || "Esc" === t2) && v(e2, "esc");
      }
      function h(e2) {
        u = e2.target, d = f(), v(e2, "click", "pressdown");
      }
      function p(e2) {
        var t2 = u;
        u = null;
        var r2 = d;
        d = null, e2.button > 0 || r2 !== f() || t2 === e2.target && v(e2, "click", "pressup");
      }
      var g = Object.freeze({
        count: function() {
          return s.length;
        },
        addOverlay: function(e2) {
          0 === s.length && (document.addEventListener("keyup", m), document.addEventListener("pointerdown", h, true), document.addEventListener("click", p, true)), s.push(e2);
        },
        removeOverlay: function(e2) {
          s.splice(s.indexOf(e2), 1), 0 === s.length && (document.removeEventListener("keyup", m), document.removeEventListener("pointerdown", h, true), document.removeEventListener("click", p, true));
        },
        getTopOverlayOptions: f
      }), w = Date.now(), C = "undefined" != typeof performance ? performance : null;
      (null == (n = null == C ? void 0 : C.timing) ? void 0 : n.navigationStart) && (w = null == (a = null == performance ? void 0 : performance.timing) ? void 0 : a.navigationStart);
      var y = C && "function" == typeof C.now ? function() {
        return C.now();
      } : "function" == typeof Date.now ? function() {
        return Date.now() - w;
      } : function() {
        return (/* @__PURE__ */ new Date()).getTime() - w;
      }, E = "undefined" != typeof window, b = function() {
        return window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
      }, _ = function(e2) {
        var t2 = e2.enabled, r2 = e2.onHeightChange, n2 = (0, o.__read)((0, c.useState)(E ? b() : void 0), 2), a2 = n2[0], i2 = n2[1], s2 = (0, c.useCallback)(
          function() {
            var e3 = b();
            a2 !== e3 && (i2(b()), r2(e3));
          },
          [a2, r2]
        );
        (0, l.E)(
          function() {
            if (t2)
              return window.addEventListener("resize", s2), function() {
                window.removeEventListener("resize", s2);
              };
          },
          [s2, t2]
        );
      }, S = function(e2) {
        var t2 = e2.touchBreakpointWidth, r2 = void 0 === t2 ? 520 : t2, n2 = e2.platform, a2 = void 0 === n2 ? "auto" : n2, i2 = (0, o.__read)((0, c.useState)(), 2), s2 = i2[0], u2 = i2[1];
        return (0, c.useEffect)(
          function() {
            if ("auto" !== a2) return void u2(a2);
            E && u2(window.matchMedia("(max-width: " + r2 + "px)").matches ? "touch" : "desktop");
          },
          [r2, a2]
        ), (0, l.E)(
          function() {
            if (E && "auto" === a2) {
              var e3 = window.matchMedia("(max-width: " + r2 + "px)");
              return t3(e3), e3.addEventListener ? e3.addEventListener("change", t3) : e3.addListener(t3), function() {
                e3.removeEventListener ? e3.removeEventListener("change", t3) : e3.removeListener(t3);
              };
            }
            function t3(e4) {
              e4.matches ? u2("touch") : u2("desktop");
            }
          },
          [s2, u2, r2]
        ), s2;
      }, k = ["tr", "am", "ge"], L = ["il"];
      function I(e2) {
        var t2, r2, n2, a2, s2, u2, d2, f2, v2, m2, h2, p2, w2, C2, I2, P = e2.avatarRef, R = e2.avatarSize, x = void 0 === R ? [42, 22] : R, D = e2.colorScheme, U = void 0 === D ? "light" : D, M = e2.dialogClassName, O = e2.dialogRef, N = e2.dir, T = void 0 === N ? "ltr" : N, B = e2.env, H = void 0 === B ? "prod" : B, W = e2.essentialRef, j = e2.features, Y = e2.fetchUserData, A = e2.host, X = e2.iframeRef, z = e2.lang, K = e2.onClose, V = e2.onLoad, J = e2.onMenuItemClick, Z = e2.onOpen, q = e2.onThemeChange, F = e2.onLocaleChange, $ = e2.platform, G = e2.preload, Q = void 0 !== G && G, ee = e2.project, et = e2.queryParams, er = e2.dynamicParams, en = e2.retpath, ea = e2.rpcHandlers, eo = e2.theme, ec = e2.tld, ei = e2.touchBreakpointWidth, el = e2.userData, es = e2.visible, eu = void 0 !== es && es, ed = (0, c.useRef)({}), ef = (0, c.useRef)(null), ev = (0, c.useRef)(null), em = (0, c.useRef)(null), eh = (t2 = void 0 === ec ? "ru" : ec, (0, c.useMemo)(
          function() {
            return k.includes(t2) ? "com." + t2 : L.includes(t2) ? "co." + t2 : t2;
          },
          [t2]
        ));
        (0, i.N)(ef, P || (0, c.createRef)()), ev = null != O ? O : ev, em = null != X ? X : em;
        var ep = (0, o.__read)((0, c.useState)(true), 2), eg = ep[0], ew = ep[1], eC = (0, c.useMemo)(
          function() {
            return E ? en || location.href : en;
          },
          [en]
        ), ey = (0, o.__read)((0, c.useState)(Q), 2), eE = ey[0], eb = ey[1], e_ = (0, c.useRef)({ colorScheme: U, theme: eo, retpath: eC }), eS = (0, c.useMemo)(
          function() {
            if (A) return "https://" + A;
            if ("prod_yateam" === H) return "https://user-id.yandex-team.ru";
            if (E) {
              var e3 = new URL(location.href).searchParams.get("user_id_host");
              if (e3) return "https://" + e3;
            }
            return "https://yandex." + eh;
          },
          [A, eh, H]
        ), ek = (0, c.useMemo)(
          function() {
            eE || e_.current.colorScheme === U && e_.current.theme === eo && e_.current.retpath === eC || (e_.current = { colorScheme: U, theme: eo, retpath: eC });
            var e3 = new URL("user-id", eS);
            if (e_.current.retpath && e3.searchParams.set("encodedRetpath", encodeURIComponent(e_.current.retpath)), e_.current.colorScheme && e3.searchParams.set("colorScheme", e_.current.colorScheme), e_.current.theme && e3.searchParams.set("theme", e_.current.theme), z && e3.searchParams.set("l10n", z), Array.isArray(j)) {
              var t3 = j.join(",");
              e3.searchParams.set("exp_flags", t3);
            }
            for (var r3 in ee && e3.searchParams.set("project", ee), H && e3.searchParams.set("env", H), e3.searchParams.set("dir", T), et)
              e3.searchParams.set(r3, et[r3]);
            for (var r3 in er) e3.searchParams.set(r3, er[r3]);
            return e3.toString();
          },
          [eS, j, ee, et, er, U, eo, eC, eE, H, T, z]
        );
        (0, c.useEffect)(
          function() {
            !eE && (Q || Y) && eb(true);
          },
          [eE, Q, Y]
        );
        var eL = S({ platform: $, touchBreakpointWidth: ei }), eI = (0, c.useCallback)(
          function() {
            eE || eb(true);
          },
          [eE]
        ), eP = (0, c.useMemo)(
          function() {
            return null === x ? null : "number" == typeof x ? x : "touch" === eL ? x[1] : x[0];
          },
          [eL, x]
        ), eR = (0, c.useCallback)(
          function() {
            var e3;
            null == (e3 = ef.current) || e3.focus(), null == K || K();
          },
          [K]
        ), ex = (0, o.__read)((0, c.useState)(), 2), eD = ex[0], eU = ex[1], eM = (0, o.__read)((0, c.useState)(el), 2), eO = eM[0], eN = eM[1];
        (0, c.useEffect)(
          function() {
            eN(el);
          },
          [el]
        );
        var eT = (0, c.useCallback)(
          function(e3) {
            if (E) {
              if ("desktop" === eL) return void eU(e3);
              eU(b());
            }
          },
          [eL]
        );
        _({ enabled: "touch" === eL, onHeightChange: eT });
        var eB = (0, c.useRef)(), eH = (n2 = (r2 = {
          loading: eg,
          iframeRef: em,
          origin: eS,
          rpcHandler: (0, c.useCallback)(
            function(e3, t3) {
              var r3;
              switch (e3.methodCall) {
                case "onInit":
                  Y && eN(e3.params[0]), null == V || V();
                  break;
                case "onDataLoad":
                  var n3 = ed.current;
                  if ("number" == typeof n3.start && "number" != typeof n3.end && eB.current) {
                    n3.end = y();
                    var a3 = n3.end - n3.start;
                    eB.current({ methodCall: "onSendTimeToInteractive", params: [{ delta: a3 }] });
                  }
                case "updateUserHeight":
                  eT(e3.params[0].height), ew(false);
                  break;
                case "ITEM_CLICK":
                  var c2 = e3.params[0];
                  null == J || J(c2.item, c2, { onClose: eR });
                  break;
                case "closeUserID":
                  null == eR || eR();
                  break;
                case "updateTheme":
                  var i2 = e3.params[0].theme;
                  null == q || q(i2);
                  break;
                case "updateLocale":
                  var l2 = e3.params[0].locale;
                  null == F || F(l2);
                  break;
                default:
                  if (!(null == ea ? void 0 : ea[e3.methodCall])) return;
                  Promise.resolve(
                    null == (r3 = null == ea ? void 0 : ea[e3.methodCall]) ? void 0 : r3.call.apply(r3, (0, o.__spread)([ea], e3.params))
                  ).then(t3);
              }
            },
            [ea, J, eR, q, F, eT, eN, Y, V]
          )
        }).loading, a2 = r2.iframeRef, s2 = r2.origin, u2 = r2.rpcHandler, d2 = (0, c.useRef)([]), f2 = (0, c.useCallback)(
          function(e3) {
            var t3, r3, o2 = JSON.stringify(e3);
            n2 ? d2.current.push(o2) : null == (r3 = null == (t3 = a2.current) ? void 0 : t3.contentWindow) || r3.postMessage(o2, "*");
          },
          [n2, a2]
        ), v2 = (0, c.useCallback)(
          function(e3) {
            var t3;
            if (e3.origin === s2) {
              try {
                t3 = JSON.parse(e3.data);
              } catch (e4) {
                return;
              }
              t3.methodCall && (null == u2 || u2((0, o.__assign)({}, t3), function(e4) {
                var r3;
                f2({
                  returnCall: true,
                  params: [e4],
                  resultCallbackIndex: (null == (r3 = t3.resultCallbackIndex) ? void 0 : r3.__callbackId) || -1
                });
              }));
            }
          },
          [s2, u2, f2]
        ), (0, c.useEffect)(
          function() {
            return window.addEventListener("message", v2), function() {
              window.removeEventListener("message", v2);
            };
          },
          [v2]
        ), (0, c.useEffect)(
          function() {
            a2 && !n2 && 0 !== d2.current.length && (d2.current.forEach(function(e3) {
              var t3, r3;
              null == (r3 = null == (t3 = a2.current) ? void 0 : t3.contentWindow) || r3.postMessage(e3, "*");
            }), d2.current = []);
          },
          [n2, a2]
        ), { sendMessage: f2 }).sendMessage;
        eB.current = eH, (0, c.useEffect)(
          function() {
            eH({ methodCall: "updateRetpath", params: [{ retpath: eC }] });
          },
          [eC, eH]
        ), (0, c.useEffect)(
          function() {
            eH({ methodCall: "onParamsChange", params: [(0, o.__assign)({}, er)] });
          },
          [er, eH]
        ), (0, c.useEffect)(
          function() {
            eH({ methodCall: "updateTheme", params: [{ colorScheme: U, theme: eo }] });
          },
          [U, eH, eo]
        );
        var eW = (0, c.useCallback)(
          function(e3) {
            eH({ methodCall: "focusFirst", params: [{ fromKeyboard: e3 }] });
          },
          [eH]
        ), ej = (0, c.useCallback)(
          function() {
            eu ? (eW(true), eR()) : (eE || eb(true), eW(false), null == Z || Z());
          },
          [eW, Z, eE, eu, eR]
        );
        h2 = (m2 = {
          visible: eu,
          onClose: eR,
          essentialRefs: (0, c.useMemo)(
            function() {
              var e3 = [ev, ef];
              return W && e3.push(W), e3;
            },
            [ev, ef, W]
          )
        }).visible, p2 = m2.onClose, w2 = m2.essentialRefs, C2 = m2.unsafe_strategy, (I2 = (0, c.useRef)({ onClose: p2, refs: w2, closeStrategy: void 0 === C2 ? "pressdown" : C2 })).current.onClose = p2, I2.current.refs = w2, (0, c.useEffect)(
          function() {
            if (h2) {
              var e3 = I2.current;
              return g.addOverlay(e3), function() {
                g.removeOverlay(e3);
              };
            }
          },
          [h2]
        ), (0, l.E)(
          function() {
            var e3;
            eu && (null != (e3 = ed.current).start || (e3.start = y()));
          },
          [eu]
        );
        var eY = {
          colorScheme: U,
          height: eD,
          loading: eg,
          preload: eE,
          ref: em,
          src: ek,
          width: "desktop" === eL ? 320 : "100%"
        }, eA = { className: M, colorScheme: U, platform: eL, ref: ev, visible: eu, onClose: eR, loading: eg };
        return {
          avatarProps: {
            avatarSize: eP,
            env: H,
            onClick: ej,
            onPointerEnter: eI,
            platform: eL,
            ref: ef,
            retpath: eC,
            userData: eO,
            visible: eu,
            tld: eh
          },
          contentProps: eY,
          dialogProps: eA
        };
      }
    },
    59860: (e, t, r) => {
      "use strict";
      t.H = void 0;
      var n = r(41500), a = r(61910), o = r(90573), c = n.__importStar(r(1038));
      t.H = function(e2) {
        var t2 = e2.enabled, r2 = e2.containerRef, n2 = (0, a.useRef)(null), i = (0, a.useRef)(false);
        (0, o.useIsomorphicLayoutEffect)(function() {
          var e3 = r2 ? r2.current : null;
          n2.current !== e3 && (t2 && i.current && (c.unlock(n2.current), c.lock(e3)), n2.current = e3);
        }), (0, o.useIsomorphicLayoutEffect)(
          function() {
            if (t2)
              return i.current = true, c.lock(n2.current), function() {
                i.current = false, c.unlock(n2.current);
              };
          },
          [t2]
        );
      };
    },
    62088: (e, t, r) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true });
      var n = r(41500);
      n.__exportStar(r(6018), t), n.__exportStar(r(46723), t), n.__exportStar(r(35761), t), n.__exportStar(r(53357), t), n.__exportStar(r(20102), t), n.__exportStar(r(10497), t);
    },
    64731: () => {
    },
    64921: (e, t) => {
      "use strict";
      t.cn = (function(e2) {
        function t2(t3, a, o, c) {
          var i = a ? r + t3 + e2.e + a : r + t3, l = i;
          if (o) {
            var s = " " + l + e2.m;
            for (var u in o)
              if (o.hasOwnProperty(u)) {
                var d = o[u];
                true === d ? l += s + u : d && (l += s + u + n + d);
              }
          }
          if (void 0 !== c)
            for (var f = 0, v = c.length; f < v; f++) {
              var m = c[f];
              if (m && "string" == typeof m.valueOf())
                for (var h = m.valueOf().split(" "), p = 0; p < h.length; p++) {
                  var g = h[p];
                  g !== i && (l += " " + g);
                }
            }
          return l;
        }
        var r = e2.n || "", n = e2.v || e2.m;
        return function(e3, r2) {
          return function(n2, a, o) {
            return "string" == typeof n2 ? Array.isArray(a) ? t2(e3, n2, void 0, a) : t2(e3, n2, a, o) : t2(e3, r2, n2, a);
          };
        };
      })({ e: "-", m: "_" });
    },
    71962: (e, t, r) => {
      "use strict";
      r.d(t, { N: () => a });
      var n = r(61910);
      function a(e2, t2) {
        (0, n.useImperativeHandle)(t2, function() {
          return e2.current;
        });
      }
    },
    85319: (e, t, r) => {
      "use strict";
      r.d(t, { l: () => s });
      var n = r(61910), a = r(35618), o = r(59860);
      r(99551);
      var c = (0, a.cn)("UserID", "CloseButton"), i = function(e2) {
        var t2 = e2.onClick, r2 = e2.colorScheme;
        return n.createElement(
          "button",
          { className: c({ colorScheme: r2 }), onClick: t2, "aria-label": "Закрыть", tabIndex: 1 },
          n.createElement(
            "svg",
            { width: 24, height: 24, viewBox: "0 0 24 24", fill: "none", focusable: "false", "aria-hidden": "true" },
            n.createElement("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M19.207 6.207a1 1 0 0 0-1.414-1.414L12 10.586 6.207 4.793a1 1 0 0 0-1.414 1.414L10.586 12l-5.793 5.793a1 1 0 1 0 1.414 1.414L12 13.414l5.793 5.793a1 1 0 0 0 1.414-1.414L13.414 12l5.793-5.793z",
              fill: "currentColor"
            })
          )
        );
      };
      r(18553);
      var l = (0, a.cn)("UserWidget", "Dialog"), s = (0, n.forwardRef)(function(e2, t2) {
        var r2, a2, c2 = e2.visible, s2 = e2.loading, u = e2.colorScheme, d = e2.platform, f = e2.onClose, v = e2.className;
        return (0, o.H)({ enabled: c2 && "touch" === d }), r2 = { onScroll: f }, (a2 = (0, n.useRef)(r2)).current = r2, (0, n.useEffect)(function() {
          var e3 = function() {
            var e4, t3;
            null == (t3 = (e4 = a2.current).onScroll) || t3.call(e4);
          };
          if (a2.current.onScroll)
            return document.addEventListener("scroll", e3), function() {
              document.removeEventListener("scroll", e3);
            };
        }, []), n.createElement(
          "div",
          {
            role: "dialog",
            "aria-busy": s2,
            "aria-modal": "true",
            className: l("Dialog", { visible: c2, loading: s2, colorScheme: u, platform: d }, [v]),
            ref: t2
          },
          s2 && n.createElement(i, { colorScheme: u, onClick: f }),
          e2.children
        );
      });
    },
    90573: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { useIsomorphicLayoutEffect: () => n.E });
      var n = r(6796);
    },
    91165: (e, t, r) => {
      "use strict";
      function n(e2) {
        let { reason: t2, children: r2 } = e2;
        return r2;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return n;
        }
      }), r(39201);
    },
    91683: () => {
    },
    96835: () => {
    },
    98944: (e, t, r) => {
      "use strict";
      function n(e2) {
        let { moduleIds: t2 } = e2;
        return null;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return n;
        }
      }), r(54486), r(92803), r(14367), r(32038);
    },
    99551: () => {
    }
  }
]);
