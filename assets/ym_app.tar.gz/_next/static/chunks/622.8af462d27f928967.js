"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [622, 2580, 8357, 9399],
  {
    342: (e, t, n) => {
      n.d(t, { A: () => a });
      var r = n(3210), o = Math.max;
      let a = function(e2, t2, n2) {
        return t2 = o(void 0 === t2 ? e2.length - 1 : t2, 0), function() {
          for (var a2 = arguments, i = -1, c = o(a2.length - t2, 0), s = Array(c); ++i < c; ) s[i] = a2[t2 + i];
          i = -1;
          for (var l = Array(t2 + 1); ++i < t2; ) l[i] = a2[i];
          return l[t2] = n2(s), (0, r.A)(e2, this, l);
        };
      };
    },
    1630: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = (0, n(92938).A)();
    },
    3210: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = function(e2, t2, n2) {
        switch (n2.length) {
          case 0:
            return e2.call(t2);
          case 1:
            return e2.call(t2, n2[0]);
          case 2:
            return e2.call(t2, n2[0], n2[1]);
          case 3:
            return e2.call(t2, n2[0], n2[1], n2[2]);
        }
        return e2.apply(t2, n2);
      };
    },
    9710: (e, t, n) => {
      n.d(t, { A: () => c });
      var r = n(83745), o = n(7812), a = n(27115), i = o.A ? function(e2, t2) {
        return (0, o.A)(e2, "toString", { configurable: true, enumerable: false, value: (0, r.A)(t2), writable: true });
      } : a.A;
      let c = (0, n(38928).A)(i);
    },
    10622: (e, t, n) => {
      n.d(t, { config: () => u });
      var r = n(22711), o = n(15209), a = n(22001), i = n(78171), c = n(80738), s = n(39399), l = n(49124);
      let u = () => {
        let e2 = "https://api.music.yandex.".concat(i.B);
        return (0, o.toBoolean)(false) && !(0, o.toBoolean)(l.env.LOCAL_PROD_BUILD) && (e2 = "http://music-backend-music-api-gateway.envoy.localhost:9080"), (0, r.A)((0, c.config)(), {
          resources: { musicExternalApi: { prefixUrl: e2 } },
          player: { overembed: false, secretKey: (0, a.E)(), externalDomain: "next.music.yandex.ru", prefixUrl: e2 },
          blackbox: {
            ...(0, o.toBoolean)(l.env.LOCAL_PROD_BUILD) ? { host: "http://local-music-dev.vla.yp-c.yandex.net/bbm/blackbox" } : {},
            enabled: true
          },
          tvm: { enabled: (0, o.toBoolean)(l.env.LOCAL_PROD_BUILD) },
          oldWebHost: "music.yandex.".concat(i.B),
          afisha: { clientId: (0, s.t)(), host: "https://widget.afisha.yandex.ru" },
          payment: { environment: "production" }
        });
      };
    },
    11260: (e, t, n) => {
      n.d(t, { A: () => u });
      var r = n(11828), o = n(55796), a = n(21793), i = Object.prototype, c = Function.prototype.toString, s = i.hasOwnProperty, l = c.call(Object);
      let u = function(e2) {
        if (!(0, a.A)(e2) || "[object Object]" != (0, r.A)(e2)) return false;
        var t2 = (0, o.A)(e2);
        if (null === t2) return true;
        var n2 = s.call(t2, "constructor") && t2.constructor;
        return "function" == typeof n2 && n2 instanceof n2 && c.call(n2) == l;
      };
    },
    22711: (e, t, n) => {
      n.d(t, { A: () => o });
      var r = n(77480);
      let o = (0, n(28736).A)(function(e2, t2, n2) {
        (0, r.A)(e2, t2, n2);
      });
    },
    27115: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = function(e2) {
        return e2;
      };
    },
    28736: (e, t, n) => {
      n.d(t, { A: () => a });
      var r = n(36021), o = n(40675);
      let a = function(e2) {
        return (0, r.A)(function(t2, n2) {
          var r2 = -1, a2 = n2.length, i = a2 > 1 ? n2[a2 - 1] : void 0, c = a2 > 2 ? n2[2] : void 0;
          for (i = e2.length > 3 && "function" == typeof i ? (a2--, i) : void 0, c && (0, o.A)(n2[0], n2[1], c) && (i = a2 < 3 ? void 0 : i, a2 = 1), t2 = Object(t2); ++r2 < a2; ) {
            var s = n2[r2];
            s && e2(t2, s, r2, i);
          }
          return t2;
        });
      };
    },
    36021: (e, t, n) => {
      n.d(t, { A: () => i });
      var r = n(27115), o = n(342), a = n(9710);
      let i = function(e2, t2) {
        return (0, a.A)((0, o.A)(e2, t2, r.A), e2 + "");
      };
    },
    38928: (e, t, n) => {
      n.d(t, { A: () => o });
      var r = Date.now;
      let o = function(e2) {
        var t2 = 0, n2 = 0;
        return function() {
          var o2 = r(), a = 16 - (o2 - n2);
          if (n2 = o2, a > 0) {
            if (++t2 >= 800) return arguments[0];
          } else t2 = 0;
          return e2.apply(void 0, arguments);
        };
      };
    },
    39399: (e, t, n) => {
      n.d(t, { t: () => c });
      var r = n(6493), o = n(71942), a = n(13132);
      let i = {
        WINDOWS: "0d8ab1a6-1667-42cb-a98f-2fe7eff4b137",
        MACOS: "05c45ae8-b869-4ec1-848c-4b314fbadc17",
        LINUX: "d2bcdb71-90ac-493b-b68f-024321954a5d",
        WEB: "b200fd55-5a52-4fa2-b5db-d163e986a61d"
      }, c = () => {
        switch ((0, o.t)((0, r.u)())) {
          case a.V.WINDOWS:
            return i.WINDOWS;
          case a.V.MACOS:
            return i.MACOS;
          case a.V.LINUX:
            return i.LINUX;
        }
        return i.WEB;
      };
    },
    40675: (e, t, n) => {
      n.d(t, { A: () => c });
      var r = n(6575), o = n(43713), a = n(59994), i = n(71270);
      let c = function(e2, t2, n2) {
        if (!(0, i.A)(n2)) return false;
        var c2 = typeof t2;
        return ("number" == c2 ? !!((0, o.A)(n2) && (0, a.A)(t2, n2.length)) : "string" == c2 && t2 in n2) && (0, r.A)(n2[t2], e2);
      };
    },
    52580: (e, t, n) => {
    },
    77480: (e, t, n) => {
      n.d(t, { A: () => _ });
      var r = n(75856), o = n(9959), a = n(6575);
      let i = function(e2, t2, n2) {
        (void 0 === n2 || (0, a.A)(e2[t2], n2)) && (void 0 !== n2 || t2 in e2) || (0, o.A)(e2, t2, n2);
      };
      var c = n(1630), s = n(12841), l = n(53222), u = n(84296), d = n(67450), f = n(63339), p = n(24422), A = n(89326), v = n(88947), m = n(15993), y = n(71270), b = n(11260), h = n(6808);
      let g = function(e2, t2) {
        if (("constructor" !== t2 || "function" != typeof e2[t2]) && "__proto__" != t2) return e2[t2];
      };
      var S = n(98799);
      let E = function(e2, t2, n2, r2, o2, a2, c2) {
        var E2 = g(e2, n2), x2 = g(t2, n2), _2 = c2.get(x2);
        if (_2) return void i(e2, n2, _2);
        var P = a2 ? a2(E2, x2, n2 + "", e2, t2, c2) : void 0, k = void 0 === P;
        if (k) {
          var O = (0, p.A)(x2), w = !O && (0, v.A)(x2), C = !O && !w && (0, h.A)(x2);
          P = x2, O || w || C ? (0, p.A)(E2) ? P = E2 : (0, A.A)(E2) ? P = (0, u.A)(E2) : w ? (k = false, P = (0, s.A)(x2, true)) : C ? (k = false, P = (0, l.A)(x2, true)) : P = [] : (0, b.A)(x2) || (0, f.A)(x2) ? (P = E2, (0, f.A)(E2) ? P = (0, S.A)(E2) : (!(0, y.A)(E2) || (0, m.A)(E2)) && (P = (0, d.A)(x2))) : k = false;
        }
        k && (c2.set(x2, P), o2(P, x2, r2, a2, c2), c2.delete(x2)), i(e2, n2, P);
      };
      var x = n(47931);
      let _ = function e2(t2, n2, o2, a2, s2) {
        t2 !== n2 && (0, c.A)(
          n2,
          function(c2, l2) {
            if (s2 || (s2 = new r.A()), (0, y.A)(c2)) E(t2, n2, l2, o2, e2, a2, s2);
            else {
              var u2 = a2 ? a2(g(t2, l2), c2, l2 + "", t2, n2, s2) : void 0;
              void 0 === u2 && (u2 = c2), i(t2, l2, u2);
            }
          },
          x.A
        );
      };
    },
    80738: (e, t, n) => {
      n.d(t, { config: () => s });
      var r = n(49544), o = n(8171), a = n(78171), i = n(49775);
      n(52580);
      var c = n(49124);
      let s = () => {
        var e2;
        return {
          logger: {
            uaDisabled: !!c.env.SERVER_UNIFIED_AGENT_DISABLED,
            uaServerAddress: null != (e2 = c.env.SERVER_UNIFIED_AGENT_ADDRESS) ? e2 : "http://localhost:12344",
            uaProtoPath: c.env.UA_PROTO_PATH || "../../packages/unified-agent/build/proto/unified_agent.proto",
            errorBooster: {
              ...{ project: "music.frontend.desktop", platform: "desktop" },
              page: "window.location.pathname",
              version: c.env.APP_VERSION || "",
              environment: "production",
              unhandledRejection: true,
              uncaughtException: true,
              resourceFails: true
            }
          },
          oauthCredentials: { host: "https://oauth.yandex.".concat(a.B), clientId: "97fe03033fa34407ac9bcf91d5afed5b" },
          tvm: {
            tvmtoolAuthToken: c.env.TVMTOOL_LOCAL_AUTHTOKEN,
            self: "music_test",
            destinations: ["blackbox"],
            host: "http://localhost:8001",
            enabled: false
          },
          rumSettings: {
            ...{
              rumId: "ru.music.frontend.desktop",
              project: "music.frontend.desktop",
              service: "frontend-desktop",
              platform: "desktop"
            },
            page: "window.location.pathname",
            heroElement: "body",
            version: c.env.APP_VERSION || "",
            environment: "production"
          },
          passportCredentials: { host: "https://passport.yandex.".concat(a.B), origin: "music_desktop" },
          blackbox: { host: "http://blackbox.envoy.localhost:9080", enabled: false },
          resources: { musicExternalApi: { retryPolicyConfig: i.t, defaultTimeout: o.Aj, timeouts: o.LE } },
          payment: { environment: "testing" },
          i18n: { cookieExpirationDays: 365 },
          ynisonConnectionConfig: {
            ynisonHost: "ynison.music.yandex.ru",
            redirectorPath: "/redirector.YnisonRedirectService/GetRedirectToYnison",
            hubConnectioPath: "/ynison_state.YnisonStateService/PutYnisonState",
            reconnectTimeout: 2e3,
            reconnectAttempts: 2,
            historyLimit: 100
          },
          player: {
            configVariablesMainPlayback: {
              entitiesToPreloadStrmUrlsCount: 1,
              entitiesToPreloadSourceCount: 1,
              preloadedSourcesMaxCount: 1,
              strmUrlsTtlMs: 36e5,
              mediaElementErrorReloadCount: 2,
              windowSize: 30,
              setupQueueWindowSize: 80,
              bufferGoal: 5
            },
            configVariablesPromoLandingPlayback: {
              entitiesToPreloadStrmUrlsCount: 1,
              entitiesToPreloadSourceCount: 1,
              preloadedSourcesMaxCount: 1,
              strmUrlsTtlMs: 36e5,
              mediaElementErrorReloadCount: 2,
              windowSize: 30,
              setupQueueWindowSize: 80,
              bufferGoal: 5
            },
            configVariablesTrailerPlayback: {
              mediaElementErrorReloadCount: 2,
              windowSize: 30,
              setupQueueWindowSize: 80,
              storePlaysProgressIntervalMs: 5e3
            },
            hlsErrorRetryLimit: 2,
            yaspVersionStable: "12946",
            yaspSourceLimit: 3,
            yaspLoadRetryDelayMs: 1e3,
            yaspExpName: void 0,
            yaspCandidateVersion: void 0,
            vhMediaProvider: { service: "ya-music", from: "ya-music", vhUrl: "https://frontend.vh.yandex.ru/player/" },
            vhPlayerSdkVersion: "12569",
            telemetry: {
              telemetryUrl: "https://log.strm.yandex.ru",
              testTelemetryUrl: "https://log-test.strm.yandex.net",
              service: "WebMusic",
              from: "ya-music",
              playerTypeForVsid: "MWE",
              rumUrl: "https://yandex.ru/clck/click"
            }
          },
          downloadDesktop: { url: "https://music.yandex.".concat(a.B, "/download/?autodownload=1") },
          iframe: { entityBaseUrl: "https://music.yandex.".concat(a.B) },
          redirects: { KZ: { fromTLD: [r.r.RU], toTLD: r.r.KZ }, UZ: { fromTLD: [r.r.RU], toTLD: r.r.UZ } },
          acqOffers: { environment: "production", brand: "YANDEX", service: "music", appVersion: c.env.APP_VERSION },
          rsc: { useCache: true }
        };
      };
    },
    83745: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = function(e2) {
        return function() {
          return e2;
        };
      };
    },
    89326: (e, t, n) => {
      n.d(t, { A: () => a });
      var r = n(43713), o = n(21793);
      let a = function(e2) {
        return (0, o.A)(e2) && (0, r.A)(e2);
      };
    },
    92938: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = function(e2) {
        return function(t2, n2, r2) {
          for (var o = -1, a = Object(t2), i = r2(t2), c = i.length; c--; ) {
            var s = i[e2 ? c : ++o];
            if (false === n2(a[s], s, a)) break;
          }
          return t2;
        };
      };
    },
    98799: (e, t, n) => {
      n.d(t, { A: () => a });
      var r = n(41620), o = n(47931);
      let a = function(e2) {
        return (0, r.A)(e2, (0, o.A)(e2));
      };
    }
  }
]);
