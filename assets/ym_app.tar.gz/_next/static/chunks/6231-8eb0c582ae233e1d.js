"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6231],
  {
    56231: (e, t, r) => {
      r.d(t, { N: () => c });
      var n, o = r(94377), l = r(61910), u = {
        5881: (e2, t2, r2) => {
          function n2() {
            for (var e3, t3, r3 = 0, n3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, n4, o3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) o3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (n4 = e4(t4[r4])) && (o3 && (o3 += " "), o3 += n4);
                  else for (r4 in t4) t4[r4] && (o3 && (o3 += " "), o3 += r4);
                return o3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => n2, default: () => o2 });
          let o2 = n2;
        },
        8239: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => n2 });
          let n2 = {
            root: "By12CU9obvaH0jYtauNw",
            root_scrolling: "MFfv7uDaaJhS_oiAzQNT",
            root_notScrolling: "pnFSEGiRmI9JuhUxbfVe",
            container: "YsFmmSnMXb5VMh5VyqeV"
          };
        },
        4490: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { DOWN: () => a2, LEFT: () => o2, RIGHT: () => l2, UP: () => u2, useSwipeable: () => p });
          var n2 = r2(810);
          let o2 = "Left", l2 = "Right", u2 = "Up", a2 = "Down", i2 = {
            delta: 10,
            preventScrollOnSwipe: false,
            rotationAngle: 0,
            trackMouse: false,
            trackTouch: true,
            swipeDuration: 1 / 0,
            touchEventOptions: { passive: true }
          }, s2 = { first: true, initial: [0, 0], start: 0, swiping: false, xy: [0, 0] }, c2 = "mousemove", f = "mouseup";
          function d(e3, t3) {
            if (0 === t3) return e3;
            let r3 = Math.PI / 180 * t3;
            return [e3[0] * Math.cos(r3) + e3[1] * Math.sin(r3), e3[1] * Math.cos(r3) - e3[0] * Math.sin(r3)];
          }
          function p(e3) {
            var t3, r3, p2;
            let b, { trackMouse: v } = e3, m = n2.useRef(Object.assign({}, s2)), g = n2.useRef(Object.assign({}, i2)), O = n2.useRef(Object.assign({}, g.current));
            for (b in O.current = Object.assign({}, g.current), g.current = Object.assign(Object.assign({}, i2), e3), i2)
              void 0 === g.current[b] && (g.current[b] = i2[b]);
            let [h, y] = n2.useMemo(
              () => (function(e4, t4) {
                let r4 = (t5) => {
                  let r5 = "touches" in t5;
                  r5 && t5.touches.length > 1 || e4((e5, o3) => {
                    o3.trackMouse && !r5 && (document.addEventListener(c2, n3), document.addEventListener(f, b2));
                    let { clientX: l3, clientY: u3 } = r5 ? t5.touches[0] : t5, a3 = d([l3, u3], o3.rotationAngle);
                    return o3.onTouchStartOrOnMouseDown && o3.onTouchStartOrOnMouseDown({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), s2), {
                      initial: a3.slice(),
                      xy: a3,
                      start: t5.timeStamp || 0
                    });
                  });
                }, n3 = (t5) => {
                  e4((e5, r5) => {
                    var n4, s3, c3, f2;
                    let p4 = "touches" in t5;
                    if (p4 && t5.touches.length > 1) return e5;
                    if (t5.timeStamp - e5.start > r5.swipeDuration)
                      return e5.swiping ? Object.assign(Object.assign({}, e5), { swiping: false }) : e5;
                    let { clientX: b3, clientY: v3 } = p4 ? t5.touches[0] : t5, [m3, g2] = d([b3, v3], r5.rotationAngle), O2 = m3 - e5.xy[0], h2 = g2 - e5.xy[1], y2 = Math.abs(O2), w = Math.abs(h2), S = (t5.timeStamp || 0) - e5.start, j = Math.sqrt(y2 * y2 + w * w) / (S || 1), E = [O2 / (S || 1), h2 / (S || 1)], T = (n4 = y2, s3 = w, c3 = O2, f2 = h2, n4 > s3 ? c3 > 0 ? l2 : o2 : f2 > 0 ? a2 : u2), P = "number" == typeof r5.delta ? r5.delta : r5.delta[T.toLowerCase()] || i2.delta;
                    if (y2 < P && w < P && !e5.swiping) return e5;
                    let R = {
                      absX: y2,
                      absY: w,
                      deltaX: O2,
                      deltaY: h2,
                      dir: T,
                      event: t5,
                      first: e5.first,
                      initial: e5.initial,
                      velocity: j,
                      vxvy: E
                    };
                    R.first && r5.onSwipeStart && r5.onSwipeStart(R), r5.onSwiping && r5.onSwiping(R);
                    let M = false;
                    return (r5.onSwiping || r5.onSwiped || r5["onSwiped".concat(T)]) && (M = true), M && r5.preventScrollOnSwipe && r5.trackTouch && t5.cancelable && t5.preventDefault(), Object.assign(Object.assign({}, e5), { first: false, eventData: R, swiping: true });
                  });
                }, p3 = (t5) => {
                  e4((e5, r5) => {
                    let n4;
                    if (e5.swiping && e5.eventData) {
                      if (t5.timeStamp - e5.start < r5.swipeDuration) {
                        n4 = Object.assign(Object.assign({}, e5.eventData), { event: t5 }), r5.onSwiped && r5.onSwiped(n4);
                        let o3 = r5["onSwiped".concat(n4.dir)];
                        o3 && o3(n4);
                      }
                    } else r5.onTap && r5.onTap({ event: t5 });
                    return r5.onTouchEndOrOnMouseUp && r5.onTouchEndOrOnMouseUp({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), s2), { eventData: n4 });
                  });
                }, b2 = (e5) => {
                  document.removeEventListener(c2, n3), document.removeEventListener(f, b2), p3(e5);
                }, v2 = (e5, t5) => {
                  let o3 = () => {
                  };
                  if (e5 && e5.addEventListener) {
                    let l3 = Object.assign(Object.assign({}, i2.touchEventOptions), t5.touchEventOptions), u3 = [
                      ["touchstart", r4, l3],
                      [
                        "touchmove",
                        n3,
                        Object.assign(Object.assign({}, l3), t5.preventScrollOnSwipe ? { passive: false } : {})
                      ],
                      ["touchend", p3, l3]
                    ];
                    u3.forEach((t6) => {
                      let [r5, n4, o4] = t6;
                      return e5.addEventListener(r5, n4, o4);
                    }), o3 = () => u3.forEach((t6) => {
                      let [r5, n4] = t6;
                      return e5.removeEventListener(r5, n4);
                    });
                  }
                  return o3;
                }, m2 = {
                  ref: (t5) => {
                    null !== t5 && e4((e5, r5) => {
                      if (e5.el === t5) return e5;
                      let n4 = {};
                      return e5.el && e5.el !== t5 && e5.cleanUpTouch && (e5.cleanUpTouch(), n4.cleanUpTouch = void 0), r5.trackTouch && t5 && (n4.cleanUpTouch = v2(t5, r5)), Object.assign(Object.assign(Object.assign({}, e5), { el: t5 }), n4);
                    });
                  }
                };
                return t4.trackMouse && (m2.onMouseDown = r4), [m2, v2];
              })((e4) => m.current = e4(m.current, g.current), { trackMouse: v }),
              [v]
            );
            return t3 = m.current, r3 = g.current, p2 = O.current, m.current = r3.trackTouch && t3.el ? t3.cleanUpTouch ? r3.preventScrollOnSwipe !== p2.preventScrollOnSwipe || r3.touchEventOptions.passive !== p2.touchEventOptions.passive ? (t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) })) : t3 : Object.assign(Object.assign({}, t3), { cleanUpTouch: y(t3.el, r3) }) : (t3.cleanUpTouch && t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: void 0 })), h;
          }
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var o2 = null;
            if (void 0 !== n3 && (o2 = "" + n3), void 0 !== t3.key && (o2 = "" + t3.key), "key" in t3)
              for (var l2 in n3 = {}, t3) "key" !== l2 && (n3[l2] = t3[l2]);
            else n3 = t3;
            return { $$typeof: r2, type: e3, key: o2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        9110: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.usePopoverSwipeable = t2.useReturnValue = t2.useCallbackRef = t2.useDebouncedToggle = t2.useResize = t2.useIsomorphicEffect = t2.useForceUpdateRef = t2.useElementOffsetY = t2.getElementNameByDataAttribute = t2.createIntersectionObserver = t2.useIntersectionObserver = t2.useKeyboardNavigation = t2.useScroll = t2.useForwardRef = void 0;
          var n2 = r2(245);
          Object.defineProperty(t2, "useForwardRef", {
            enumerable: true,
            get: function() {
              return n2.useForwardRef;
            }
          });
          var o2 = r2(2067);
          Object.defineProperty(t2, "useScroll", {
            enumerable: true,
            get: function() {
              return o2.useScroll;
            }
          });
          var l2 = r2(5188);
          Object.defineProperty(t2, "useKeyboardNavigation", {
            enumerable: true,
            get: function() {
              return l2.useKeyboardNavigation;
            }
          });
          var u2 = r2(5663);
          Object.defineProperty(t2, "useIntersectionObserver", {
            enumerable: true,
            get: function() {
              return u2.useIntersectionObserver;
            }
          }), Object.defineProperty(t2, "createIntersectionObserver", {
            enumerable: true,
            get: function() {
              return u2.createIntersectionObserver;
            }
          }), Object.defineProperty(t2, "getElementNameByDataAttribute", {
            enumerable: true,
            get: function() {
              return u2.getElementNameByDataAttribute;
            }
          });
          var a2 = r2(2101);
          Object.defineProperty(t2, "useElementOffsetY", {
            enumerable: true,
            get: function() {
              return a2.useElementOffsetY;
            }
          });
          var i2 = r2(2767);
          Object.defineProperty(t2, "useForceUpdateRef", {
            enumerable: true,
            get: function() {
              return i2.useForceUpdateRef;
            }
          });
          var s2 = r2(9019);
          Object.defineProperty(t2, "useIsomorphicEffect", {
            enumerable: true,
            get: function() {
              return s2.useIsomorphicEffect;
            }
          });
          var c2 = r2(2947);
          Object.defineProperty(t2, "useResize", {
            enumerable: true,
            get: function() {
              return c2.useResize;
            }
          });
          var f = r2(6699);
          Object.defineProperty(t2, "useDebouncedToggle", {
            enumerable: true,
            get: function() {
              return f.useDebouncedToggle;
            }
          });
          var d = r2(8691);
          Object.defineProperty(t2, "useCallbackRef", {
            enumerable: true,
            get: function() {
              return d.useCallbackRef;
            }
          });
          var p = r2(998);
          Object.defineProperty(t2, "useReturnValue", {
            enumerable: true,
            get: function() {
              return p.useReturnValue;
            }
          });
          var b = r2(4395);
          Object.defineProperty(t2, "usePopoverSwipeable", {
            enumerable: true,
            get: function() {
              return b.usePopoverSwipeable;
            }
          });
          var v = r2(5969);
          Object.defineProperty(t2, "useDynamicText", {
            enumerable: true,
            get: function() {
              return v.useDynamicText;
            }
          });
        },
        8691: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useCallbackRef = void 0;
          let n2 = r2(810);
          t2.useCallbackRef = function(e3) {
            let t3 = (0, n2.useRef)({
              stableFn: function() {
                for (var e4 = arguments.length, r3 = Array(e4), n3 = 0; n3 < e4; n3++) r3[n3] = arguments[n3];
                return t3.current.callback(...r3);
              },
              callback: e3
            });
            return (0, n2.useInsertionEffect)(() => {
              t3.current.callback = e3;
            }), t3.current.stableFn;
          };
        },
        1381: (e2, t2, r2) => {
          var n2;
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useComponentSwipeable = t2.SwipeablePlacement = void 0;
          let o2 = r2(4490), l2 = r2(8691);
          !(function(e3) {
            e3.TOP = "top", e3.BOTTOM = "bottom", e3.RIGHT = "right", e3.LEFT = "left";
          })(n2 || (t2.SwipeablePlacement = n2 = {}));
          let u2 = (e3) => {
            let { ref: t3, deltaY: r3, deltaX: o3, placement: l3 } = e3;
            requestAnimationFrame(() => {
              t3.current && (t3.current.style.willChange = "transform", t3.current.style.transform = l3 === n2.TOP || l3 === n2.BOTTOM ? "translateY(".concat(r3 || 0, "px)") : "translateX(".concat(o3 || 0, "px)"));
            });
          }, a2 = (e3) => {
            requestAnimationFrame(() => {
              e3.current && (e3.current.style.transition = "none", e3.current.style.willChange = "", e3.current.style.transform = "");
            });
          };
          t2.useComponentSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: i2, disableSwipe: s2, placement: c2, threshold: f } = e3, d = (0, l2.useCallbackRef)(() => {
              i2 && (a2(t3), i2());
            }), p = (0, l2.useCallbackRef)((e4) => {
              s2 || ((e5) => {
                let { ref: t4, deltaY: r4, deltaX: o3, placement: l3 } = e5;
                switch (l3) {
                  case n2.TOP:
                    r4 <= 0 && u2({ ref: t4, deltaY: r4, deltaX: o3, placement: l3 });
                    break;
                  case n2.RIGHT:
                    o3 >= 0 && u2({ ref: t4, deltaY: r4, deltaX: o3, placement: l3 });
                    break;
                  case n2.LEFT:
                    o3 <= 0 && u2({ ref: t4, deltaY: r4, deltaX: o3, placement: l3 });
                    break;
                  default:
                    r4 >= 0 && u2({ ref: t4, deltaY: r4, deltaX: o3, placement: l3 });
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: c2 });
            }), b = (0, l2.useCallbackRef)((e4) => {
              !s2 && (((e5) => {
                let { ref: t4, deltaY: r4, deltaX: o3, placement: l3, threshold: u3 = 25 } = e5;
                if (!t4.current) return false;
                let a3 = u3 / 100 * (l3 === n2.TOP || l3 === n2.BOTTOM ? t4.current.offsetHeight : t4.current.offsetWidth);
                switch (l3) {
                  case n2.TOP:
                    return r4 < 0 && Math.abs(r4) >= a3;
                  case n2.RIGHT:
                    return o3 > 0 && o3 >= a3;
                  case n2.LEFT:
                    return o3 < 0 && Math.abs(o3) >= a3;
                  default:
                    return r4 > 0 && r4 >= a3;
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: c2, threshold: f }) ? i2 && (a2(t3), i2()) : a2(t3));
            });
            return {
              handlers: (0, o2.useSwipeable)({ onSwiped: b, onSwiping: p, trackMouse: true, trackTouch: true, ...r3 }),
              onCloseCallback: d
            };
          };
        },
        6699: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let n2 = r2(352), o2 = r2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: r3, throttleTimeout: l2 } = e3, u2 = (0, o2.useRef)(null), [a2, i2] = (0, o2.useState)(!!r3), s2 = (0, o2.useMemo)(
              () => (0, n2.throttle)(() => {
                i2(!r3), u2.current && window.clearTimeout(u2.current), u2.current = window.setTimeout(() => {
                  i2(!!r3);
                }, t3);
              }, l2),
              [t3, r3, l2]
            ), c2 = (0, o2.useCallback)(() => {
              i2(!!r3), u2.current && window.clearTimeout(u2.current);
            }, [r3]);
            return (0, o2.useEffect)(
              () => () => {
                u2.current && window.clearTimeout(u2.current);
              },
              []
            ), { state: a2, handleDebouncedToggle: s2, reset: c2 };
          };
        },
        5969: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.findOptimalFontSize = void 0;
          let n2 = r2(810), o2 = (e3) => {
            e3.style.wordBreak = "keep-all", e3.style.overflowWrap = "normal", e3.style.maxHeight = "none", e3.style.height = "auto", e3.style.overflow = "visible", Array.from(e3.children).forEach((e4) => {
              e4 instanceof HTMLElement && o2(e4);
            });
          };
          t2.findOptimalFontSize = (e3) => {
            let {
              container: t3,
              containerWidth: r3,
              containerHeight: n3,
              minFontSize: l2,
              maxFontSize: u2,
              lineHeight: a2,
              maxLines: i2
            } = e3, s2 = ((e4, t4, r4) => {
              let n4 = e4.cloneNode(true);
              return n4.style.cssText = "\n        position: absolute !important;\n        visibility: hidden !important;\n        pointer-events: none !important;\n        width: ".concat(
                t4,
                "px !important;\n    "
              ), o2(n4), n4.style.setProperty("--dynamic-line-height", String(r4)), document.body.appendChild(n4), n4;
            })(t3, r3, a2);
            try {
              let e4 = l2, t4 = u2, o3 = l2;
              for (; e4 <= t4; ) {
                let l3 = Math.floor((e4 + t4) / 2);
                s2.style.setProperty("--dynamic-font-size", "".concat(l3, "px"));
                let u3 = Math.min(i2 * l3 * a2, n3), c2 = s2.scrollHeight <= u3, f = s2.scrollWidth <= r3 + 1;
                c2 && f ? (o3 = l3, e4 = l3 + 1) : t4 = l3 - 1;
              }
              return o3 - 1;
            } finally {
              s2.remove();
            }
          }, t2.useDynamicText = (e3, r3) => {
            (0, n2.useLayoutEffect)(() => {
              if (null === e3) return;
              e3.style.setProperty("--dynamic-line-height", String(r3.lineHeight));
              let n3 = () => {
                let { width: n4, height: o4 } = e3.getBoundingClientRect(), l3 = e3.childNodes.length > 0;
                if (0 === n4 || 0 === o4 || !l3) return;
                let u2 = (0, t2.findOptimalFontSize)({ container: e3, containerWidth: n4, containerHeight: o4, ...r3 });
                e3.style.setProperty("--dynamic-font-size", "".concat(u2, "px"));
              }, o3 = new ResizeObserver(n3), l2 = new MutationObserver(n3);
              return o3.observe(e3), l2.observe(e3, { childList: true, characterData: true, subtree: true }), document.fonts.ready.then(n3), n3(), () => {
                o3.disconnect(), l2.disconnect();
              };
            }, [e3, r3]);
          };
        },
        2101: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useElementOffsetY = void 0;
          let n2 = r2(810), o2 = r2(2067), l2 = r2(2767);
          t2.useElementOffsetY = (e3) => {
            let [t3, r3] = (0, l2.useForceUpdateRef)(), [u2, a2] = (0, n2.useState)(), i2 = (0, n2.useCallback)(() => {
              let e4 = null == t3 ? void 0 : t3.getBoundingClientRect();
              e4 && a2(e4.y);
            }, [t3]);
            return (0, n2.useLayoutEffect)(i2), (0, o2.useScroll)({ onScroll: i2, elementRef: e3 }), { forceUpdateRefCallback: r3, offsetY: u2 };
          };
        },
        2767: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForceUpdateRef = void 0;
          let n2 = r2(810);
          t2.useForceUpdateRef = () => {
            let [e3, t3] = (0, n2.useState)(null);
            return [
              e3,
              (0, n2.useCallback)((e4) => {
                t3((t4) => t4 !== e4 ? e4 : t4);
              }, [])
            ];
          };
        },
        245: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForwardRef = void 0;
          let n2 = r2(810);
          t2.useForwardRef = function(e3, t3) {
            let r3 = (0, n2.useRef)(t3);
            return (0, n2.useEffect)(() => {
              e3 && ("function" == typeof e3 ? e3(r3.current) : e3.current = r3.current);
            }, [e3]), r3;
          };
        },
        5663: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIntersectionObserver = t2.createIntersectionObserver = t2.getElementNameByDataAttribute = t2.isInViewportNow = t2.defaultOptions = void 0;
          let n2 = r2(810), { innerWidth: o2 = 0, innerHeight: l2 = 0 } = window;
          function u2(e3) {
            let { top: t3, right: r3, bottom: n3, left: u3 } = e3.getBoundingClientRect();
            return (t3 >= 0 && t3 <= l2 || n3 >= 0 && n3 <= l2) && (u3 >= 0 && u3 <= o2 || r3 >= 0 && r3 <= o2);
          }
          function a2(e3) {
            var t3, r3;
            let n3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "data-intersection-property-id";
            return null != (r3 = null == e3 || null == (t3 = e3.getAttribute) ? void 0 : t3.call(e3, n3)) ? r3 : e3.attributes[0];
          }
          function i2(e3, t3) {
            let r3 = new IntersectionObserver((t4) => {
              t4.forEach((t5) => {
                e3(t5, r3);
              });
            }, t3);
            return r3;
          }
          t2.defaultOptions = { threshold: 0, preflightCheck: true }, t2.isInViewportNow = u2, t2.getElementNameByDataAttribute = a2, t2.createIntersectionObserver = i2, t2.useIntersectionObserver = function(e3, r3, o3) {
            let [{ freezeOnceVisible: l3, preflightCheck: s2, ...c2 }, f = false] = "boolean" == typeof r3 || void 0 === r3 ? [t2.defaultOptions, r3] : [{ ...t2.defaultOptions, ...r3 }, o3], [d, p] = (0, n2.useState)({}), b = (0, n2.useRef)(/* @__PURE__ */ new Set()), v = (0, n2.useMemo)(
              () => f ? null : i2((e4) => {
                let t3 = a2(e4.target);
                if (t3 && v) {
                  if (b.current.has(t3)) return;
                  p((r4) => ({ ...r4, [t3]: { isIntersecting: e4.isIntersecting } })), l3 && e4.isIntersecting && (b.current.add(t3), v.unobserve(e4.target));
                }
              }, c2),
              [f]
            );
            return (0, n2.useLayoutEffect)(
              () => (v && !f && e3.forEach((e4) => {
                if (e4.current) {
                  let t3 = false;
                  if (s2 && (t3 = u2(e4.current))) {
                    let t4 = a2(e4.current);
                    p((e5) => ({ ...e5, [t4]: { isIntersecting: true } }));
                  }
                  t3 || v.observe(e4.current);
                }
              }), () => {
                v && v.disconnect();
              }),
              [f, v, e3.length]
            ), d;
          };
        },
        9019: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIsomorphicEffect = void 0;
          let n2 = r2(810);
          t2.useIsomorphicEffect = "undefined" != typeof document ? n2.useLayoutEffect : n2.useEffect;
        },
        5188: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useKeyboardNavigation = void 0;
          let n2 = r2(810);
          function o2(e3, t3) {
            return e3.current ? Array.from(t3 ? e3.current.querySelectorAll(t3) : e3.current.children) : [];
          }
          t2.useKeyboardNavigation = function(e3) {
            let t3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, { navigationItemsSelector: r3, activeAttributeName: l2 = "aria-selected" } = t3, u2 = (0, n2.useCallback)(
              (t4) => {
                let n3 = o2(e3, r3);
                if (!n3.length) return;
                let l3 = t4.target, u3 = n3.indexOf(l3);
                if (-1 === u3) return;
                let [a2] = n3, i2 = n3.at(-1), s2 = null;
                switch (t4.key) {
                  case "ArrowLeft":
                  case "ArrowUp":
                    s2 = n3[u3 - 1] || i2;
                    break;
                  case "ArrowRight":
                  case "ArrowDown":
                    s2 = n3[u3 + 1] || a2;
                    break;
                  case "Home":
                    s2 = a2;
                    break;
                  case "End":
                    s2 = i2;
                }
                null !== s2 && (s2.focus(), t4.preventDefault());
              },
              [r3, e3]
            );
            (0, n2.useEffect)(() => {
              let t4 = e3.current;
              return null == t4 || t4.addEventListener("keydown", u2), () => null == t4 ? void 0 : t4.removeEventListener("keydown", u2);
            }, [e3, u2]), (0, n2.useEffect)(() => {
              o2(e3, r3).forEach((e4) => {
                e4.hasAttribute(l2) && ("true" === e4.getAttribute(l2) ? e4.tabIndex = 0 : e4.tabIndex = -1);
              });
            });
          };
        },
        4395: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.usePopoverSwipeable = void 0;
          let n2 = r2(810), o2 = r2(1381);
          t2.usePopoverSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: l2, disableSwipe: u2, placement: a2, threshold: i2 } = e3, s2 = (0, n2.useMemo)(() => {
              switch (a2) {
                case "top":
                case "top-end":
                case "top-start":
                  return o2.SwipeablePlacement.TOP;
                case "right":
                case "right-end":
                case "right-start":
                  return o2.SwipeablePlacement.RIGHT;
                case "left":
                case "left-end":
                case "left-start":
                  return o2.SwipeablePlacement.LEFT;
                default:
                  return o2.SwipeablePlacement.BOTTOM;
              }
            }, [a2]);
            return (0, o2.useComponentSwipeable)({
              ref: t3,
              swipeableProps: r3,
              onClose: l2,
              disableSwipe: u2,
              placement: s2,
              threshold: i2
            });
          };
        },
        2947: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useResize = void 0;
          let n2 = r2(810), o2 = r2(361);
          t2.useResize = (e3, t3) => {
            (0, n2.useEffect)(() => {
              let r3 = (0, o2.getElementFromRefOrElement)(t3);
              if (null === r3) return;
              let n3 = null != r3 ? r3 : document.documentElement, l2 = new ResizeObserver(e3);
              return l2.observe(n3), () => l2.disconnect();
            }, [t3, e3]);
          };
        },
        998: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useReturnValue = void 0, t2.useReturnValue = (e3) => e3();
        },
        2067: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useScroll = void 0;
          let n2 = r2(810), o2 = r2(361), l2 = r2(6699);
          t2.useScroll = (e3) => {
            let { onScroll: t3, listenIsScrolling: r3, elementRef: u2 } = e3, { state: a2, handleDebouncedToggle: i2 } = (0, l2.useDebouncedToggle)({
              delay: 1e3,
              throttleTimeout: 100
            }), s2 = (0, n2.useCallback)(() => {
              r3 && i2(), null == t3 || t3();
            }, [r3, i2, t3]);
            return (0, n2.useEffect)(() => {
              let e4 = (0, o2.getElementFromRefOrElement)(u2);
              if (null === e4) return;
              let t4 = null != e4 ? e4 : window, r4 = { capture: true, passive: true };
              return t4.addEventListener("scroll", s2, r4), () => t4.removeEventListener("scroll", s2, r4);
            }, [u2, s2]), a2;
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        8429: function(e2, t2, r2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.ScrollableContent = t2.ScrollableContentComponent = void 0;
          let o2 = r2(4377), l2 = r2(810), u2 = r2(5881), a2 = r2(9110), i2 = n2(r2(8239));
          t2.ScrollableContentComponent = (e3) => {
            let { forwardRef: t3, className: r3, containerClassName: n3, children: l3, ...s2 } = e3, c2 = (0, a2.useForwardRef)(t3, null), f = (0, a2.useScroll)({ listenIsScrolling: true, elementRef: c2 });
            return (0, o2.jsx)("div", {
              className: (0, u2.clsx)(
                i2.default.root,
                { [i2.default.root_scrolling]: f, [i2.default.root_notScrolling]: !f },
                r3
              ),
              ref: c2,
              ...s2,
              children: (0, o2.jsx)("div", { className: (0, u2.clsx)(i2.default.container, n3), children: l3 })
            });
          }, t2.ScrollableContent = (0, l2.forwardRef)(
            (e3, r3) => (0, o2.jsx)(t2.ScrollableContentComponent, { forwardRef: r3, ...e3 })
          );
        },
        352: (e2) => {
          e2.exports = o;
        },
        810: (e2) => {
          e2.exports = n || (n = r.t(l, 2));
        }
      }, a = {};
      function i(e2) {
        var t2 = a[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = a[e2] = { exports: {} };
        return u[e2].call(r2.exports, r2, r2.exports, i), r2.exports;
      }
      i.d = (e2, t2) => {
        for (var r2 in t2) i.o(t2, r2) && !i.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, i.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), i.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var s = {};
      (() => {
        Object.defineProperty(s, "X", { value: true }), s.t = void 0;
        var e2 = i(8429);
        Object.defineProperty(s, "t", {
          enumerable: true,
          get: function() {
            return e2.ScrollableContent;
          }
        });
      })();
      var c = s.t;
      s.X;
    }
  }
]);
