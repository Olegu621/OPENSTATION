"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6433],
  {
    26433: (e, t, i) => {
      i.d(t, {
        JE: () => a,
        qt: () => n,
        lg: () => g,
        $B: () => u,
        xE: () => b,
        CA: () => E,
        aQ: () => h,
        YL: () => M,
        Ec: () => k,
        br: () => J,
        tP: () => X,
        XT: () => p,
        FN: () => Z,
        pl: () => q,
        Fr: () => eC,
        jd: () => j,
        dA: () => eG,
        vE: () => ew,
        Hp: () => eq,
        eD: () => ej,
        Ij: () => V
      });
      var s, l = i(93064), r = i(80411);
      let a = l.gK.model("BaseAdvertBanner", {
        type: l.gK.enumeration(Object.values(r.h)),
        noAds: l.gK.boolean,
        hasError: l.gK.boolean,
        isShowBanner: l.gK.boolean
      }).views((e2) => ({
        get isVisible() {
          if (e2.noAds || e2.hasError || !e2.isShowBanner) return false;
          let { advertBanners: t2 } = (0, l.Zn)(e2);
          if (t2.hasBranding) return false;
          return t2.isVisible(e2.type);
        }
      })).actions((e2) => ({
        setType(t2) {
          e2.type = t2;
        },
        toggleNoAdsTrue() {
          e2.noAds = true;
        },
        setIsShowBanner(t2) {
          e2.isShowBanner = t2;
        },
        toggleHasErrorTrue() {
          e2.hasError = true;
        },
        reset() {
          e2.type = r.h.EMPTY, e2.noAds = false, e2.isShowBanner = true, e2.hasError = false;
        }
      })), n = l.gK.model("BaseModal", { isOpened: l.gK.optional(l.gK.boolean, false) }).actions((e2) => ({
        onOpenChange(t2) {
          e2.isOpened = t2;
        },
        open() {
          e2.isOpened = true;
        },
        close() {
          e2.isOpened = false;
        }
      })), o = l.gK.model("BrowserInfo", {
        hasHuaweiAppGallery: l.gK.boolean,
        inAppBrowser: l.gK.boolean,
        isBrowser: l.gK.boolean,
        isMobile: l.gK.boolean,
        isTablet: l.gK.boolean,
        isTouch: l.gK.boolean,
        name: l.gK.maybe(l.gK.string),
        version: l.gK.maybe(l.gK.string),
        OSFamily: l.gK.maybe(l.gK.string)
      }).views((e2) => ({
        get isSafari() {
          var t2;
          return null == (t2 = e2.name) ? void 0 : t2.toLowerCase().includes("safari");
        }
      })), g = l.gK.model("CaseForms", {
        nominative: l.gK.optional(l.gK.string, ""),
        genitive: l.gK.optional(l.gK.string, ""),
        dative: l.gK.optional(l.gK.string, ""),
        accusative: l.gK.optional(l.gK.string, ""),
        instrumental: l.gK.optional(l.gK.string, ""),
        prepositional: l.gK.optional(l.gK.string, "")
      }), u = l.gK.model("Cover", {
        uri: l.gK.maybe(l.gK.string),
        color: l.gK.maybe(l.gK.string),
        videoUrl: l.gK.maybe(l.gK.string)
      }), d = l.gK.model("DisclaimerDetails", { text: l.gK.maybe(l.gK.string), url: l.gK.maybe(l.gK.string) }), m = l.gK.model("DisclaimerData", {
        title: l.gK.maybe(l.gK.string),
        description: l.gK.maybe(l.gK.string),
        details: l.gK.maybe(d)
      }), c = l.gK.compose(l.gK.model({ id: l.gK.string, type: l.gK.string }), m);
      var K = i(26779), f = i(51197);
      let p = l.gK.model("LoadingState", { loadingState: l.gK.enumeration(Object.values(f.G)) }).views((e2) => ({
        get isNeededToLoad() {
          return e2.loadingState === f.G.IDLE;
        },
        get isLoading() {
          return e2.loadingState === f.G.PENDING;
        },
        get isResolved() {
          return e2.loadingState === f.G.RESOLVE;
        },
        get isRejected() {
          return e2.loadingState === f.G.REJECT;
        }
      })), v = l.gK.model("EntityRef", {
        entityType: l.gK.enumeration(Object.values(K.n)),
        entityId: l.gK.union(l.gK.string, l.gK.number)
      }), b = l.gK.compose(
        l.gK.model("DisclaimerModalState", {
          currentEntityRef: l.gK.maybeNull(v),
          type: l.gK.maybeNull(l.gK.enumeration(Object.values(K.Y))),
          id: l.gK.maybeNull(l.gK.string),
          isUnsafeDisclaimerConfirmed: l.gK.optional(l.gK.boolean, false),
          shouldHistoryBack: l.gK.optional(l.gK.boolean, false),
          shouldCloseModalOnOutsidePress: l.gK.optional(l.gK.boolean, true),
          shouldCloseModalOnEscape: l.gK.optional(l.gK.boolean, true),
          entityKey: l.gK.maybeNull(l.gK.string),
          modalData: l.gK.maybeNull(l.gK.frozen())
        }),
        p
      ).volatile(() => ({ onDisclaimerConfirmHandler: null, onDisclaimerRejectHandler: null })).views((e2) => ({
        get entityType() {
          var t2, i2;
          return null != (i2 = null == (t2 = e2.currentEntityRef) ? void 0 : t2.entityType) ? i2 : null;
        },
        get entityId() {
          var s2, l2;
          return null != (l2 = null == (s2 = e2.currentEntityRef) ? void 0 : s2.entityId) ? l2 : null;
        },
        get isNeededToLoad() {
          return e2.loadingState === f.G.IDLE;
        }
      })).actions((e2) => ({
        setCurrentEntityRef(t2, i2) {
          e2.currentEntityRef = { entityType: t2, entityId: i2 };
        },
        setId(t2) {
          e2.id = t2;
        },
        setType(t2) {
          e2.type = t2;
        },
        setConfirmUnsafeDisclaimer(t2) {
          e2.isUnsafeDisclaimerConfirmed = t2;
        },
        setShouldHistoryBack(t2) {
          e2.shouldHistoryBack = t2;
        },
        setShouldCloseModalOnOutsidePress(t2) {
          e2.shouldCloseModalOnOutsidePress = t2;
        },
        setShouldCloseModalOnEscape(t2) {
          e2.shouldCloseModalOnEscape = t2;
        },
        setDisclaimerConfirmHandler(t2) {
          e2.onDisclaimerConfirmHandler = t2;
        },
        setDisclaimerRejectHandler(t2) {
          e2.onDisclaimerRejectHandler = t2;
        },
        setModalData(t2) {
          e2.modalData = t2;
        },
        reset() {
          e2.currentEntityRef = null, e2.id = null, e2.type = null, e2.isUnsafeDisclaimerConfirmed = false, e2.shouldHistoryBack = false, e2.shouldCloseModalOnOutsidePress = true, e2.shouldCloseModalOnEscape = true, e2.loadingState = f.G.IDLE, e2.entityKey = null, e2.modalData = null;
        }
      }));
      var I = i(63930);
      let y = (e2) => {
        var t2, i2;
        return {
          id: e2.id,
          type: e2.type,
          title: e2.title,
          description: e2.description,
          details: { text: null == (t2 = e2.details) ? void 0 : t2.text, url: null == (i2 = e2.details) ? void 0 : i2.url }
        };
      }, E = l.gK.compose(
        l.gK.model("DisclaimersDictionary", {
          disclaimers: l.gK.maybe(l.gK.array(c)),
          recentDisclaimersRequestTS: l.gK.number
        }),
        p
      ).actions((e2) => {
        let t2 = {
          getDisclaimers: (0, l.L3)(function* () {
            let { disclaimersResource: t3, modelActionsLogger: i2 } = (0, l._$)(e2);
            if (e2.loadingState !== f.G.PENDING)
              try {
                e2.loadingState = f.G.PENDING, e2.recentDisclaimersRequestTS = Date.now();
                let i3 = yield t3.getDisclaimers();
                e2.disclaimers = (0, l.wg)(i3.map(y)), e2.loadingState !== f.G.IDLE && (e2.loadingState = f.G.RESOLVE);
              } catch (t4) {
                i2.error(t4), e2.loadingState !== f.G.IDLE && (e2.loadingState = f.G.REJECT);
              }
          }),
          getDisclaimerById: (0, l.L3)(function* (i2) {
            var s2, l2;
            e2.loadingState === f.G.PENDING && (yield (0, I.z7)(() => e2.loadingState !== f.G.PENDING)), e2.disclaimers || (yield t2.getDisclaimers());
            let r2 = null == (s2 = e2.disclaimers) ? void 0 : s2.find((e3) => e3.id === i2);
            return r2 || (Date.now() - e2.recentDisclaimersRequestTS > 18e5 && (yield t2.getDisclaimers()), null == (l2 = e2.disclaimers) ? void 0 : l2.find((e3) => e3.id === i2));
          })
        };
        return t2;
      });
      var L = i(79899), D = i(8075), T = i(73975);
      let O = (e2, t2) => {
        let i2 = [];
        for (let s2 of e2)
          if (s2.includes(":")) {
            let [e3, l2] = s2.split(":");
            e3 === t2 && l2 && i2.push({ type: e3, id: l2 });
          }
        return i2.length > 0 ? i2 : null;
      };
      var S = i(92946);
      let k = l.gK.model("ExplicitModel", {
        contentWarning: l.gK.maybe(l.gK.enumeration(Object.values(L.K))),
        trackType: l.gK.maybe(l.gK.enumeration(Object.values(D.S))),
        disclaimers: l.gK.maybe(l.gK.array(l.gK.string)),
        resolvedDisclaimers: l.gK.maybe(l.gK.frozen())
      }).views((e2) => ({
        get isExplicit() {
          return e2.contentWarning === L.K.EXPLICIT;
        },
        get explicitDisclaimer() {
          if (!(0, l._n)(e2) || !e2.disclaimers) return null;
          let t2 = ((e3, t3) => {
            for (let s2 of t3) {
              let t4 = O(e3, s2);
              if (t4 && t4.length > 0) {
                var i2;
                return null != (i2 = t4[0]) ? i2 : null;
              }
            }
            return null;
          })(e2.disclaimers, [T.M.EXPLICIT_ICON, T.M.AGE_18_ICON, T.M.EXCLAMATION_ICON]);
          if ((null == t2 ? void 0 : t2.type) === T.M.EXCLAMATION_ICON) return S.J.EXCLAMATION;
          if ((null == t2 ? void 0 : t2.type) === T.M.EXPLICIT_ICON) return S.J.E;
          if ((null == t2 ? void 0 : t2.type) === T.M.AGE_18_ICON) return S.J.NUMERIC;
          return null;
        },
        get hasModalDisclaimer() {
          if (!e2.disclaimers) return false;
          let t2 = O(e2.disclaimers, T.M.MODAL);
          return !!(t2 && t2.length > 0);
        },
        getIsLegalRejected(t2) {
          return !!(0, l._n)(e2) && !t2 && this.hasModalDisclaimer;
        },
        getIsUnsafeLegal(t2) {
          return !!(0, l._n)(e2) && !!e2.disclaimers && t2 && this.hasModalDisclaimer;
        },
        get isForeignAgent() {
          if (!(0, l._n)(e2) || !e2.disclaimers) return false;
          let t2 = O(e2.disclaimers, T.M.FOREIGN_AGENT);
          return !!(t2 && t2.length > 0);
        },
        get resolvedForeignAgentData() {
          var t2;
          if (!e2.resolvedDisclaimers) return null;
          let i2 = e2.resolvedDisclaimers[T.M.FOREIGN_AGENT];
          return null != (t2 = null == i2 ? void 0 : i2[0]) ? t2 : null;
        },
        get resolvedDescriptionTexts() {
          if (!e2.resolvedDisclaimers) return null;
          let t2 = e2.resolvedDisclaimers[T.M.DESCRIPTION_TEXT];
          if (!t2 || 0 === t2.length) return null;
          let i2 = [];
          for (let e3 of t2) e3.title && i2.push(e3.title);
          return i2.length > 0 ? i2 : null;
        },
        get resolvedModalData() {
          var i2;
          if (!e2.resolvedDisclaimers) return null;
          let t2 = e2.resolvedDisclaimers[T.M.MODAL];
          return null != (i2 = null == t2 ? void 0 : t2[0]) ? i2 : null;
        }
      })).actions((e2) => {
        let t2 = (0, l.L3)(function* (t3) {
          let { modelActionsLogger: i2 } = (0, l._$)(e2);
          try {
            if (!(0, l._n)(e2) || !e2.disclaimers) return null;
            let i3 = O(e2.disclaimers, t3);
            if (!i3 || 0 === i3.length) return null;
            let { disclaimersDictionary: s2 } = (0, l.Zn)(e2);
            if (!s2) return null;
            let r2 = [];
            for (let e3 of i3) {
              let t4 = yield s2.getDisclaimerById(e3.id);
              t4 && r2.push((0, I.HO)(t4));
            }
            return r2;
          } catch (e3) {
            return i2.error(e3), null;
          }
        });
        return {
          getDisclaimerData: (0, l.L3)(function* (e3) {
            return yield t2(e3);
          }),
          getModalDisclaimerData: (0, l.L3)(function* () {
            let e3 = yield t2(T.M.MODAL);
            return e3 ? e3[0] : null;
          }),
          getForeignAgentDisclaimerData: (0, l.L3)(function* () {
            let e3 = yield t2(T.M.FOREIGN_AGENT);
            return e3 ? e3[0] : null;
          }),
          getDescriptionTexts: (0, l.L3)(function* () {
            if (e2.resolvedDescriptionTexts) return e2.resolvedDescriptionTexts;
            let i2 = yield t2(T.M.DESCRIPTION_TEXT);
            if (!i2) return null;
            let s2 = [];
            for (let e3 of i2) s2.push(e3.title);
            return s2;
          }),
          resolveAllDisclaimers: (0, l.L3)(function* () {
            if ((0, l._n)(e2) && e2.disclaimers && 0 !== e2.disclaimers.length)
              for (let i2 of (e2.resolvedDisclaimers || (e2.resolvedDisclaimers = {}), Object.values(T.M))) {
                let s2 = yield t2(i2);
                s2 && s2.length > 0 && (e2.resolvedDisclaimers = { ...e2.resolvedDisclaimers, [i2]: s2 });
              }
          })
        };
      }), A = ["Safari", "MobileSafari"], N = ["iOS", "MacOS"], h = l.gK.model("DomainTrailerEntity", { available: l.gK.boolean }).views((e2) => ({
        get isAvailable() {
          if (!(0, l._n)(e2)) return false;
          let { settings: t2 } = (0, l.Zn)(e2);
          if (!(null == t2 ? void 0 : t2.browserInfo) || ((e3) => {
            let t3 = e3.version ? Number(e3.version.split(".")[0]) : void 0;
            return !!(e3.name && A.includes(e3.name) && e3.OSFamily && N.includes(e3.OSFamily) && t3 && t3 < 18);
          })(t2.browserInfo))
            return false;
          return e2.available;
        }
      }));
      var C = i(1211), R = i(62901), P = i(54574), x = i(19806);
      let _ = l.gK.model("Experiment", { group: l.gK.maybe(l.gK.string), value: l.gK.maybe(l.gK.frozen()) }), M = l.gK.model("Experiments", {
        loadingState: l.gK.enumeration(Object.values(f.G)),
        experiments: l.gK.optional(l.gK.map(_), {}),
        overwrittenExperiments: l.gK.optional(l.gK.map(_), {})
      }).views((e2) => {
        let t2 = {
          getOverwrittenExperiments() {
            let { containerStorage: t3, clientSafeConfig: i2 } = (0, l._$)(e2), s2 = i2.get(R.yc);
            return (0, x._)(t3, s2);
          },
          getExperiment(i2) {
            var s2;
            let l2 = e2.experiments.get(i2), r2 = t2.getOverwrittenExperiments();
            return r2 && null != (s2 = r2[i2]) ? s2 : l2;
          },
          isExperimentEnabled(e3) {
            let i2 = t2.getExperiment(e3);
            return (0, C.A)(null == i2 ? void 0 : i2.value.enabled) ? null == i2 ? void 0 : i2.value.enabled : t2.checkExperiment(e3, null == i2 ? void 0 : i2.value.value);
          },
          getEnabledFlags() {
            let i2 = [];
            for (let s2 of (/* @__PURE__ */ new Set([...e2.overwrittenExperiments.keys(), ...e2.experiments.keys()])).keys())
              t2.isExperimentEnabled(s2) && i2.push(s2);
            return i2;
          },
          checkExperiment(t3, i2) {
            let s2 = e2.experiments.get(t3), { containerStorage: r2, clientSafeConfig: a2 } = (0, l._$)(e2), n2 = a2.get(R.yc);
            return (0, P.i)({ containerStorage: r2, name: t3, value: i2, experimentDetail: s2 }, n2);
          },
          isRejected: () => e2.loadingState === f.G.REJECT
        };
        return t2;
      }).actions((e2) => ({
        getData: (0, l.L3)(function* (t2) {
          let { accountResource: i2, modelActionsLogger: s2 } = (0, l._$)(e2);
          if (e2.loadingState !== f.G.PENDING)
            try {
              e2.loadingState = f.G.PENDING;
              let s3 = t2;
              s3 || (s3 = yield i2.experimentsDetails()), e2.experiments.clear(), Object.entries(s3).forEach((t3) => {
                let [i3, s4] = t3;
                e2.experiments.set(i3, s4);
              }), e2.loadingState = f.G.RESOLVE;
            } catch (t3) {
              s2.error(t3), e2.loadingState = f.G.REJECT;
            } finally {
              var r2;
              Object.entries(null != (r2 = e2.getOverwrittenExperiments()) ? r2 : {}).forEach((t3) => {
                let [i3, s3] = t3;
                e2.overwrittenExperiments.set(i3, s3);
              });
            }
        }),
        updateOverwrittenExperiments(t2, i2) {
          let { clientSafeConfig: s2 } = (0, l._$)(e2);
          s2.get(R.yc) && e2.overwrittenExperiments.set(t2, i2);
        },
        deleteOverwrittenExperiments(t2) {
          let { clientSafeConfig: i2 } = (0, l._$)(e2);
          i2.get(R.yc) && e2.overwrittenExperiments.delete(t2);
        }
      }));
      var G = i(81786), w = i(99431);
      let q = l.gK.model("ModelDestroyManager").actions(() => ({
        destroyItems(e2) {
          e2.forEach((e3) => {
            e3 && (0, l.Yo)(e3);
          }), queueMicrotask(() => {
            e2.forEach((e3) => {
              e3 && (0, l.zr)(e3);
            });
          });
        }
      })), j = l.gK.model("Pager", { page: l.gK.number, perPage: l.gK.number, total: l.gK.number });
      function V(e2) {
        return l.gK.compose(
          l.gK.model("PageLoader", {
            items: l.gK.maybeNull(l.gK.array(l.gK.maybeNull(e2))),
            requestsCount: l.gK.optional(l.gK.number, 0),
            initialRequestLoadingState: l.gK.optional(l.gK.enumeration(Object.values(f.G)), f.G.IDLE),
            lastRejectedPagesList: l.gK.optional(l.gK.array(l.gK.number), []),
            pager: l.gK.maybeNull(j),
            pageStates: l.gK.maybeNull(l.gK.array(l.gK.enumeration(Object.values(f.G))))
          }),
          q
        ).views((e3) => {
          let t2 = {
            isPageNeedToLoad: (t3) => {
              var i2;
              return null == (i2 = e3.pageStates) || !i2[t3] || e3.pageStates[t3] === f.G.IDLE;
            },
            get isSomePageResolved() {
              var i2;
              return !!((null == (i2 = e3.pageStates) ? void 0 : i2.length) && e3.pageStates.some((e4) => e4 === f.G.RESOLVE));
            },
            get isEmpty() {
              var s2;
              return t2.isSomePageResolved && !(null == (s2 = e3.items) ? void 0 : s2.length);
            },
            get isNeedToMakeInitialRequest() {
              return e3.initialRequestLoadingState === f.G.IDLE;
            },
            get isInitialRequestRejected() {
              return e3.initialRequestLoadingState === f.G.REJECT;
            },
            get rejectedPagesCount() {
              var l2;
              if (t2.isInitialRequestRejected || !(null == (l2 = e3.pageStates) ? void 0 : l2.length)) return 0;
              return e3.pageStates.filter((e4) => e4 === f.G.REJECT).length;
            }
          };
          return t2;
        }).actions((e3) => {
          let t2 = {
            setPageState: (i2, s2) => {
              var l2, r2, a2, n2;
              [f.G.IDLE, f.G.PENDING].includes(e3.initialRequestLoadingState) && (e3.initialRequestLoadingState = s2);
              let o2 = Math.max(
                i2 + 1,
                Math.ceil(
                  (null != (a2 = null == (l2 = e3.pager) ? void 0 : l2.total) ? a2 : 0) / (null != (n2 = null == (r2 = e3.pager) ? void 0 : r2.perPage) ? n2 : 1)
                )
              );
              t2.ensurePageStatesInitialized(o2), e3.pageStates && (e3.pageStates[i2] = s2), s2 === f.G.REJECT && t2.addLastRejectedPageToList(i2);
            },
            setItems: (i2, s2) => {
              var r2;
              let { page: a2, pager: n2, responseStatus: o2 } = s2;
              if (e3.requestsCount = (null != (r2 = e3.requestsCount) ? r2 : 0) + 1, o2 === G.F.ERROR || !i2 || !n2)
                return void t2.setPageState(a2, f.G.REJECT);
              e3.pager || (e3.pager = { page: n2.page, perPage: n2.perPage, total: n2.total }), t2.setPageState(a2, f.G.RESOLVE), e3.pager.page = a2, e3.items || (e3.items = (0, l.wg)(Array.from({ length: e3.pager.total }, () => null))), e3.items && (0, w.I)({ items: e3.items, mappedRawItems: i2, page: a2, pageSize: e3.pager.perPage });
            },
            resetRejectedPagesState() {
              var t3, i2, s2;
              for (let l2 = 0; l2 < (null != (i2 = null == (t3 = e3.pageStates) ? void 0 : t3.length) ? i2 : 0); l2++)
                (null == (s2 = e3.pageStates) ? void 0 : s2[l2]) === f.G.REJECT && (e3.pageStates[l2] = f.G.IDLE);
            },
            addLastRejectedPageToList(t3) {
              var i2, s2, l2;
              for (e3.lastRejectedPagesList.push(t3); (null != (s2 = null == (i2 = e3.lastRejectedPagesList) ? void 0 : i2.length) ? s2 : 0) > 5; )
                null == (l2 = e3.lastRejectedPagesList) || l2.shift();
            },
            ensurePageStatesInitialized(t3) {
              if (t3 <= 0) return;
              if (!e3.pageStates) {
                let i3 = Array.from({ length: t3 }, () => f.G.IDLE);
                e3.pageStates = (0, l.wg)(i3);
                return;
              }
              let i2 = e3.pageStates.length;
              if (t3 > i2) {
                let s2 = Array.from({ length: t3 - i2 }, () => f.G.IDLE);
                e3.pageStates.push(...s2);
              }
            },
            reset() {
              e3.initialRequestLoadingState = f.G.IDLE, e3.requestsCount = 0, e3.lastRejectedPagesList = (0, l.wg)([]), e3.destroyItems([e3.items, e3.pager, e3.pageStates]);
            }
          };
          return t2;
        });
      }
      var F = i(77534);
      let B = (e2) => e2 ? { revision: e2 } : { allValuesRequired: true };
      var U = i(30361), W = i(35141);
      let $ = [U.s.LIKED_ALBUMS, U.s.LIKED_ARTISTS, U.s.LIKED_PLAYLISTS, U.s.LIKED_TRACKS, U.s.LIKED_CLIPS], H = l.gK.optional(l.gK.map(l.gK.enumeration(Object.values(W.O))), {}), z = l.gK.model("LibraryRecord", { revision: l.gK.maybeNull(l.gK.number), items: H }), J = l.gK.compose(l.gK.model("Library", { tracks: z, albums: z, artists: z, playlists: z, clips: z }), p).views((e2) => ({
        isTrackLiked: (t2) => e2.tracks.items.get(String(t2)) === W.O.LIKED,
        isTrackDisliked: (t2) => e2.tracks.items.get(String(t2)) === W.O.DISLIKED,
        isArtistLiked: (t2) => e2.artists.items.get(String(t2)) === W.O.LIKED,
        isArtistDisliked: (t2) => e2.artists.items.get(String(t2)) === W.O.DISLIKED,
        isAlbumLiked: (t2) => e2.albums.items.get(String(t2)) === W.O.LIKED,
        isPlaylistLiked: (t2) => e2.playlists.items.get(String(t2)) === W.O.LIKED,
        isClipLiked: (t2) => e2.clips.items.get(String(t2)) === W.O.LIKED
      })).actions((e2) => {
        let t2 = {
          getData: (0, l.L3)(function* () {
            let i2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : $, { modelActionsLogger: s2, collectionResource: r2 } = (0, l._$)(e2);
            if (e2.loadingState !== f.G.PENDING)
              try {
                e2.loadingState = f.G.PENDING;
                let s3 = {};
                i2.includes(U.s.LIKED_ALBUMS) && (s3.likedAlbums = B(e2.albums.revision)), i2.includes(U.s.LIKED_ARTISTS) && (s3.likedArtists = B(e2.artists.revision)), i2.includes(U.s.LIKED_TRACKS) && (s3.likedTracks = B(e2.tracks.revision)), i2.includes(U.s.LIKED_CLIPS) && (s3.likedClips = B(e2.clips.revision)), i2.includes(U.s.LIKED_PLAYLISTS) && (s3.likedPlaylists = {});
                let l2 = yield r2.sync(s3);
                t2.setAlbums(l2.values.likedAlbums), t2.setArtists(l2.values.likedArtists), t2.setPlaylists(l2.values.likedPlaylists), t2.setTracks(l2.values.likedTracks), t2.setClips(l2.values.likedClips), e2.loadingState = f.G.RESOLVE;
              } catch (t3) {
                s2.error(t3), e2.loadingState = f.G.REJECT;
              }
          }),
          setArtists: (i2) => {
            (null == i2 ? void 0 : i2.values) && e2.artists.revision !== i2.info.revision && (t2.clearArtists(), e2.artists.revision = i2.info.revision, i2.values.liked.map((t3) => {
              e2.artists.items.set(t3.artistId.toString(), W.O.LIKED);
            }), i2.values.disliked.map((t3) => {
              e2.artists.items.set(t3.artistId.toString(), W.O.DISLIKED);
            }));
          },
          setAlbums: (i2) => {
            (null == i2 ? void 0 : i2.values) && e2.albums.revision !== i2.info.revision && (t2.clearAlbums(), e2.albums.revision = i2.info.revision, i2.values.liked.map((t3) => {
              e2.albums.items.set(t3.albumId.toString(), W.O.LIKED);
            }));
          },
          setPlaylists: (i2) => {
            (null == i2 ? void 0 : i2.values) && (t2.clearPlaylists(), i2.values.liked.map((t3) => {
              e2.playlists.items.set("".concat(t3.compositeData.uid, ":").concat(t3.compositeData.kind), W.O.LIKED);
            }));
          },
          setTracks: (i2) => {
            (null == i2 ? void 0 : i2.values) && e2.tracks.revision !== i2.info.revision && (t2.clearTracks(), e2.tracks.revision = i2.info.revision, i2.values.liked.map((t3) => {
              e2.tracks.items.set(t3.trackId, W.O.LIKED);
            }), i2.values.disliked.map((t3) => {
              e2.tracks.items.set(t3.trackId, W.O.DISLIKED);
            }));
          },
          setClips: (i2) => {
            (null == i2 ? void 0 : i2.values) && e2.clips.revision !== i2.info.revision && (t2.clearClips(), e2.clips.revision = i2.info.revision, i2.values.liked.map((t3) => {
              e2.clips.items.set(t3.clipId.toString(), W.O.LIKED);
            }));
          },
          clearArtists: () => {
            e2.artists.revision = null, e2.artists.items.clear();
          },
          clearAlbums: () => {
            e2.albums.revision = null, e2.albums.items.clear();
          },
          clearPlaylists: () => {
            e2.playlists.revision = null, e2.playlists.items.clear();
          },
          clearTracks: () => {
            e2.tracks.revision = null, e2.tracks.items.clear();
          },
          clearClips: () => {
            e2.clips.revision = null, e2.clips.items.clear();
          },
          toggleTrackLike: (0, l.L3)(function* (i2) {
            let { usersResource: s2, modelActionsLogger: r2 } = (0, l._$)(e2), a2 = String(i2.entityId), n2 = e2.tracks.items.get(a2);
            try {
              let l2, r3 = {
                entityId: i2.albumId ? "".concat(i2.entityId, ":").concat(i2.albumId) : i2.entityId,
                userId: i2.userId
              };
              return e2.tracks.items.get(a2) === W.O.LIKED ? (e2.tracks.items.delete(a2), l2 = yield s2.unlikeTrack(r3)) : (e2.tracks.items.set(a2, W.O.LIKED), l2 = yield s2.likeTrack(r3)), t2.getData([U.s.LIKED_TRACKS]), l2;
            } catch (t3) {
              return n2 ? e2.tracks.items.set(a2, n2) : e2.tracks.items.delete(a2), r2.error(t3), F.f.ERROR;
            }
          }),
          toggleTrackDislike: (0, l.L3)(function* (i2) {
            let { usersResource: s2, modelActionsLogger: r2 } = (0, l._$)(e2), a2 = String(i2.entityId), n2 = e2.tracks.items.get(a2);
            try {
              let l2, r3 = {
                entityId: i2.albumId ? "".concat(i2.entityId, ":").concat(i2.albumId) : i2.entityId,
                userId: i2.userId
              };
              return e2.tracks.items.get(a2) === W.O.DISLIKED ? (e2.tracks.items.delete(a2), l2 = yield s2.undislikeTrack(r3)) : (e2.tracks.items.set(a2, W.O.DISLIKED), l2 = yield s2.dislikeTrack(r3)), t2.getData([U.s.LIKED_TRACKS]), l2;
            } catch (t3) {
              return n2 ? e2.tracks.items.set(a2, n2) : e2.tracks.items.delete(a2), r2.error(t3), F.f.ERROR;
            }
          }),
          toggleArtistLike: (0, l.L3)(function* (i2) {
            let { usersResource: s2, modelActionsLogger: r2 } = (0, l._$)(e2), a2 = String(i2.entityId), n2 = e2.artists.items.get(a2);
            try {
              let l2;
              return e2.artists.items.get(a2) === W.O.LIKED ? (e2.artists.items.delete(a2), l2 = yield s2.unlikeArtist(i2)) : (e2.artists.items.set(a2, W.O.LIKED), l2 = yield s2.likeArtist(i2)), t2.getData([U.s.LIKED_ARTISTS]), l2;
            } catch (t3) {
              return n2 ? e2.artists.items.set(a2, n2) : e2.artists.items.delete(a2), r2.error(t3), F.f.ERROR;
            }
          }),
          toggleArtistDislike: (0, l.L3)(function* (i2) {
            let { usersResource: s2, modelActionsLogger: r2 } = (0, l._$)(e2), a2 = String(i2.entityId), n2 = e2.artists.items.get(a2);
            try {
              let l2;
              return e2.artists.items.get(a2) === W.O.DISLIKED ? (e2.artists.items.delete(a2), l2 = yield s2.undislikeArtist(i2)) : (e2.artists.items.set(a2, W.O.DISLIKED), l2 = yield s2.dislikeArtist(i2)), t2.getData([U.s.LIKED_ARTISTS]), l2;
            } catch (t3) {
              return n2 ? e2.artists.items.set(a2, n2) : e2.artists.items.delete(a2), r2.error(t3), F.f.ERROR;
            }
          }),
          toggleAlbumLike: (0, l.L3)(function* (i2) {
            let { usersResource: s2, modelActionsLogger: r2 } = (0, l._$)(e2), a2 = String(i2.entityId), n2 = e2.albums.items.get(a2);
            try {
              let l2;
              return e2.albums.items.get(a2) === W.O.LIKED ? (e2.albums.items.delete(a2), l2 = yield s2.unlikeAlbum(i2)) : (e2.albums.items.set(a2, W.O.LIKED), l2 = yield s2.likeAlbum(i2)), t2.getData([U.s.LIKED_ALBUMS]), l2;
            } catch (t3) {
              return n2 ? e2.albums.items.set(a2, n2) : e2.albums.items.delete(a2), r2.error(t3), F.f.ERROR;
            }
          }),
          togglePlaylistLike: (0, l.L3)(function* (i2) {
            let { usersResource: s2, modelActionsLogger: r2 } = (0, l._$)(e2), a2 = String(i2.entityId), n2 = e2.playlists.items.get(a2);
            try {
              let l2;
              return e2.playlists.items.get(a2) === W.O.LIKED ? (e2.playlists.items.delete(a2), l2 = yield s2.unlikePlaylist(i2)) : (e2.playlists.items.set(a2, W.O.LIKED), l2 = yield s2.likePlaylist(i2)), t2.getData([U.s.LIKED_PLAYLISTS]), l2;
            } catch (t3) {
              return n2 ? e2.playlists.items.set(a2, n2) : e2.playlists.items.delete(a2), r2.error(t3), F.f.ERROR;
            }
          }),
          toggleClipLike: (0, l.L3)(function* (i2) {
            let { usersResource: s2, modelActionsLogger: r2 } = (0, l._$)(e2), a2 = String(i2.entityId), n2 = e2.clips.items.get(a2);
            try {
              return e2.clips.items.get(a2) === W.O.LIKED ? (e2.clips.items.delete(a2), yield s2.unlikeClip(i2)) : (e2.clips.items.set(a2, W.O.LIKED), yield s2.likeClip(i2)), t2.getData([U.s.LIKED_CLIPS]), F.f.OK;
            } catch (t3) {
              return n2 ? e2.clips.items.set(a2, n2) : e2.clips.items.delete(a2), r2.error(t3), F.f.ERROR;
            }
          })
        };
        return t2;
      }), X = l.gK.model("LikesCount", {
        likesCount: l.gK.maybe(l.gK.number),
        pendingLikesCount: l.gK.optional(l.gK.number, 0)
      }).views((e2) => ({
        get actualLikesCount() {
          if ("number" == typeof e2.likesCount) {
            var t2;
            return e2.likesCount + (null != (t2 = e2.pendingLikesCount) ? t2 : 0);
          }
          return 0;
        }
      })).actions((e2) => ({
        likePending() {
          e2.pendingLikesCount += 1;
        },
        unlikePending() {
          e2.pendingLikesCount -= 1;
        }
      })), Z = l.gK.model("Location", {
        pathname: l.gK.optional(l.gK.string, ""),
        searchParams: l.gK.optional(l.gK.string, ""),
        host: l.gK.optional(l.gK.string, ""),
        tld: l.gK.optional(l.gK.string, ""),
        origin: l.gK.optional(l.gK.string, ""),
        href: l.gK.optional(l.gK.string, ""),
        isNotFound: l.gK.optional(l.gK.boolean, false)
      }).actions((e2) => ({
        setPathname(t2) {
          e2.pathname = t2;
        },
        setSearchParams(t2) {
          e2.searchParams = t2;
        },
        setHost(t2) {
          e2.host = t2;
        },
        setTld(t2) {
          e2.tld = t2;
        },
        setOrigin(t2) {
          e2.origin = t2;
        },
        setHref(t2) {
          e2.href = t2;
        },
        setNotFound(t2) {
          e2.isNotFound = t2;
        }
      }));
      var Y = i(9348), Q = i(10744), ee = i(41670);
      let et = {
        INTRO_PLAN: ee.N.IntroPlan,
        INTRO_UNTIL_PLAN: ee.N.IntroUntilPlan,
        TRIAL_PLAN: ee.N.TrialPlan,
        TRIAL_UNTIL_PLAN: ee.N.TrialUntilPlan
      }, ei = (e2) => {
        let { repetitionCount: t2, typename: i2, ...s2 } = e2;
        return { ...Number.isFinite(t2) ? { repeatCount: t2 } : {}, ...s2, typename: et[i2] || i2 };
      };
      var es = i(47049);
      let el = (e2) => (0, l.wg)(e2), er = (e2) => {
        let { plans: t2, ...i2 } = e2;
        return (0, l.wg)({ ...i2, plans: t2.map(el) });
      }, ea = (e2) => {
        let { option: t2, ...i2 } = e2;
        return (0, l.wg)({ ...er(i2), option: t2 });
      }, en = (e2) => {
        let { positionId: t2, silentInvoiceAvailable: i2, structureType: s2, tariffOffer: r2, optionOffers: a2 } = e2;
        return (0, l.wg)({
          positionId: t2,
          silentInvoiceAvailable: i2,
          structureType: s2,
          tariffOffer: ((e3) => {
            if (!e3) return null;
            let { tariff: t3, ...i3 } = e3;
            return (0, l.wg)({ ...er(i3), tariff: t3 });
          })(r2),
          optionsOffers: a2.map(ea)
        });
      }, eo = (e2) => (0, l.wg)({ offer: en(e2) }), eg = (e2) => (0, l.wg)({
        acqOffer: ((e3) => {
          let {
            analyticData: t2,
            catalogCompositeOffer: i2,
            offerTexts: s2,
            target: r2,
            requestedFeatures: a2,
            position: n2,
            oneClickAvailable: o2,
            place: g2,
            purchaseToken: u2
          } = e3;
          return (0, l.wg)({
            analyticData: t2,
            catalogCompositeOffer: en(
              ((e4) => {
                var t3;
                let { tariffOffer: i3, optionOffers: s3 } = e4;
                return {
                  ...e4,
                  silentInvoiceAvailable: !!e4.silentInvoiceAvailable,
                  structureType: e4.structureType,
                  tariffOffer: i3 ? {
                    ...i3,
                    offerVendorType: i3.offerVendorType,
                    plans: null == (t3 = i3.plans) ? void 0 : t3.map(ei)
                  } : void 0,
                  optionOffers: null == s3 ? void 0 : s3.map((e5) => ({ ...e5, plans: (e5.plans || []).map(ei) }))
                };
              })(i2)
            ),
            offerTexts: ((e4) => {
              let { customTexts: t3 = {}, ...i3 } = e4;
              return {
                ...i3,
                customTexts: Object.entries(t3).reduce((e5, t4) => {
                  let [i4, s3] = t4;
                  return e5[(0, es.A)(i4)] = s3, e5;
                }, {})
              };
            })(s2),
            target: r2,
            requestedFeatures: a2,
            position: n2,
            oneClickAvailable: o2,
            place: g2,
            purchaseToken: u2
          });
        })(e2)
      });
      var eu = i(1756);
      let ed = l.gK.model({ batchId: l.gK.string, positionId: l.gK.string, placeId: l.gK.maybe(l.gK.string) }), em = l.gK.model({
        buttonText: l.gK.maybe(l.gK.string),
        buttonAdditionalText: l.gK.maybe(l.gK.string),
        buttonTextA11y: l.gK.maybe(l.gK.string),
        oneClickDisclaimerText: l.gK.maybe(l.gK.string),
        oneClickDisclaimerTextA11y: l.gK.maybe(l.gK.string)
      }), ec = l.gK.model({
        subscriptionName: l.gK.string,
        buttonText: l.gK.string,
        buttonTextWithDetails: l.gK.string,
        combinedIntroductoryText: l.gK.string,
        combinedPriceText: l.gK.string,
        combinedFullOfferText: l.gK.string,
        priceInMonth: l.gK.string,
        customTexts: em
      });
      !(function(e2) {
        e2.COMPOSITE = "COMPOSITE", e2.OPTION = "OPTION", e2.TARIFF = "TARIFF";
      })(s || (s = {}));
      let eK = l.gK.model({ amount: l.gK.number, currency: l.gK.string }), ef = l.gK.model({
        typename: l.gK.literal(ee.N.IntroPlan),
        period: l.gK.string,
        price: eK,
        repeatCount: l.gK.maybe(l.gK.number)
      }), ep = l.gK.model({ typename: l.gK.literal(ee.N.IntroUntilPlan), price: eK, until: l.gK.string }), ev = l.gK.model({ typename: l.gK.literal(ee.N.TrialPlan), period: l.gK.string }), eb = l.gK.model({ typename: l.gK.literal(ee.N.TrialUntilPlan), until: l.gK.string }), eI = l.gK.union(ef, ep, ev, eb), ey = l.gK.model({ name: l.gK.string }), eE = l.gK.model({
        additionText: l.gK.string,
        description: l.gK.string,
        name: l.gK.string,
        text: l.gK.string,
        title: l.gK.string,
        plans: l.gK.array(eI),
        commonPeriod: l.gK.string,
        commonPrice: eK
      }), eL = eE.props({ option: ey }), eD = eE.props({ tariff: ey }), eT = l.gK.model({
        positionId: l.gK.string,
        silentInvoiceAvailable: l.gK.boolean,
        structureType: l.gK.enumeration(Object.values(s)),
        tariffOffer: l.gK.maybeNull(eD),
        optionsOffers: l.gK.array(eL)
      }), eO = l.gK.model({
        analyticData: ed,
        catalogCompositeOffer: eT,
        offerTexts: ec,
        target: l.gK.string,
        requestedFeatures: l.gK.maybe(l.gK.array(l.gK.string)),
        position: l.gK.number,
        oneClickAvailable: l.gK.maybe(l.gK.boolean),
        place: l.gK.maybe(l.gK.string),
        purchaseToken: l.gK.maybe(l.gK.string)
      }), eS = l.gK.model({ offer: l.gK.maybeNull(eT), acqOffer: l.gK.maybeNull(eO) }).views((e2) => {
        let t2 = {
          get target() {
            var i2;
            return (null == (i2 = e2.acqOffer) ? void 0 : i2.target) || "music";
          },
          get offerPosition() {
            var s2, l2;
            return null != (l2 = null == (s2 = e2.acqOffer) ? void 0 : s2.position) ? l2 : 0;
          },
          get place() {
            var r2;
            return null == (r2 = e2.acqOffer) ? void 0 : r2.place;
          },
          get catalogCompositeOffer() {
            var a2;
            return (null == (a2 = e2.acqOffer) ? void 0 : a2.catalogCompositeOffer) || e2.offer;
          },
          get offersPositionId() {
            var n2, o2;
            return (null == (n2 = e2.acqOffer) ? void 0 : n2.analyticData.positionId) || (null == (o2 = t2.catalogCompositeOffer) ? void 0 : o2.positionId) || "";
          },
          get tariffOffer() {
            var g2;
            return null == (g2 = t2.catalogCompositeOffer) ? void 0 : g2.tariffOffer;
          },
          get customTexts() {
            var u2, d2;
            return null == (d2 = e2.acqOffer) || null == (u2 = d2.offerTexts) ? void 0 : u2.customTexts;
          },
          get oneClickAvailable() {
            var m2, c2;
            return !!((null == (m2 = e2.acqOffer) ? void 0 : m2.oneClickAvailable) && (null == (c2 = t2.oneClickDisclaimerText) ? void 0 : c2.trim()));
          },
          get oneClickDisclaimerText() {
            var K2;
            return null == (K2 = t2.customTexts) ? void 0 : K2.oneClickDisclaimerText;
          },
          get oneClickDisclaimerTextA11y() {
            var f2;
            return null == (f2 = t2.customTexts) ? void 0 : f2.oneClickDisclaimerTextA11y;
          },
          get mainText() {
            var p2, v2;
            return (null == (p2 = t2.customTexts) ? void 0 : p2.buttonText) || (null == (v2 = t2.tariffOffer) ? void 0 : v2.text);
          },
          get mainTextA11y() {
            var b2;
            return null == (b2 = t2.customTexts) ? void 0 : b2.buttonTextA11y;
          },
          get additionText() {
            var I2, y2;
            return (null == (I2 = t2.customTexts) ? void 0 : I2.buttonAdditionalText) || (null == (y2 = t2.tariffOffer) ? void 0 : y2.additionText);
          },
          get offersBatchId() {
            var E2, L2;
            return (null == (E2 = e2.acqOffer) ? void 0 : E2.analyticData.batchId) || (null == (L2 = e2.offer) ? void 0 : L2.positionId) || "";
          }
        };
        return t2;
      }), ek = l.gK.model({
        sessionId: l.gK.maybeNull(l.gK.string),
        page: l.gK.maybeNull(l.gK.string),
        offers: l.gK.array(eS),
        mlRequestId: l.gK.maybeNull(l.gK.string),
        offerConfigId: l.gK.maybeNull(l.gK.number),
        language: l.gK.maybeNull(l.gK.string)
      }), eA = l.gK.compose(ek, p, l.gK.model({ isLoadOffersResultSent: l.gK.boolean })), eN = l.gK.model({ eventSessionId: l.gK.string, batchPositionId: l.gK.string, offers: l.gK.array(eS) }), eh = l.gK.compose(
        l.gK.model({
          isWebNextPlusAcqToolkitOn: l.gK.maybe(l.gK.boolean),
          isLoadOffersResultSent: l.gK.maybe(l.gK.boolean),
          data: l.gK.maybeNull(eN),
          acqData: l.gK.map(eA),
          customTarget: l.gK.maybe(l.gK.string)
        }),
        p
      ).volatile(() => ({ sessionId: (0, Y.A)(), isFrontSessionStartSent: false })).views((e2) => {
        let t2 = {
          getIsShimmerVisible(t3) {
            let i2 = e2.isWebNextPlusAcqToolkitOn && t3 && e2.acqData.get(t3);
            return i2 ? i2.isNeededToLoad || i2.isLoading || i2.isRejected : e2.isNeededToLoad || e2.isLoading || e2.isRejected;
          },
          getIsShimmerActive(t3) {
            let i2 = e2.isWebNextPlusAcqToolkitOn && t3 && e2.acqData.get(t3);
            return i2 ? i2.isLoading : e2.isLoading;
          },
          getIsNeededToLoad(t3) {
            let i2 = e2.isWebNextPlusAcqToolkitOn && t3 && e2.acqData.get(t3);
            return i2 ? i2.isNeededToLoad : e2.isNeededToLoad;
          },
          getIsLoadOffersResultSent(t3) {
            let i2 = e2.isWebNextPlusAcqToolkitOn && t3 && e2.acqData.get(t3);
            return i2 ? i2.isLoadOffersResultSent : e2.isLoadOffersResultSent;
          },
          getLoadingState(t3) {
            let i2 = e2.isWebNextPlusAcqToolkitOn && t3 && e2.acqData.get(t3);
            return i2 ? i2.loadingState : e2.loadingState;
          },
          get serviceSessionId() {
            return e2.sessionId;
          },
          getOffersPositionIds(t3) {
            var i2, s2, l2, r2, a2;
            return e2.isWebNextPlusAcqToolkitOn && t3 && (null == (l2 = e2.acqData) || null == (s2 = l2.get(t3)) || null == (i2 = s2.offers) ? void 0 : i2.map((e3) => e3.offersPositionId)) || (null == (a2 = e2.data) || null == (r2 = a2.offers) ? void 0 : r2.map((e3) => e3.offersPositionId)) || [];
          },
          getOffer(t3, i2) {
            var s2, l2;
            let r2 = e2.isWebNextPlusAcqToolkitOn && (null == (s2 = e2.acqData) ? void 0 : s2.get(t3));
            return r2 ? i2 ? r2.offers.find((e3) => e3.place === i2) : r2.offers[0] : null == (l2 = e2.data) ? void 0 : l2.offers[0];
          },
          getTarget(i2, s2) {
            var l2;
            return e2.isWebNextPlusAcqToolkitOn && (null == (l2 = t2.getOffer(i2, s2)) ? void 0 : l2.target) || e2.customTarget || "music";
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          toggleIsFrontSessionStartSentTrue() {
            e2.isFrontSessionStartSent = true;
          },
          toggleIsLoadOffersResultSentTrue() {
            let i2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Q.l.NO_VALUE;
            e2.isWebNextPlusAcqToolkitOn ? t2.setAcqData(i2, { isLoadOffersResultSent: true }) : e2.isLoadOffersResultSent = true;
          },
          setCustomTarget(t3) {
            e2.customTarget = t3;
          },
          setLoadingState(i2) {
            let s2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Q.l.NO_VALUE;
            e2.isWebNextPlusAcqToolkitOn ? t2.setAcqData(s2, { ...e2.acqData.get(s2), loadingState: i2 }) : e2.loadingState = i2;
          },
          setAcqData(t3, i2) {
            var s2;
            e2.acqData.set(t3, {
              loadingState: f.G.IDLE,
              isLoadOffersResultSent: false,
              ...null != (s2 = e2.acqData.get(t3)) ? s2 : {},
              ...i2
            });
          },
          getData: (0, l.L3)(function* (i2) {
            let s2, {
              uid: r2,
              page: a2,
              places: n2,
              communicationId: o2,
              campaignId: g2,
              customTarget: u2,
              widgetServiceName: d2
            } = i2, { acqOffers: m2, offersResource: c2, modelActionsLogger: K2 } = (0, l._$)(e2), { experiments: p2 } = (0, l.Zn)(e2), v2 = p2.getEnabledFlags(), b2 = p2.checkExperiment(eu.z.WebNextPlusAcqToolkit, "on"), I2 = b2 ? a2 || Q.l.NO_VALUE : void 0;
            if (e2.isWebNextPlusAcqToolkitOn = b2, e2.getLoadingState(a2) !== f.G.PENDING) {
              e2.isLoadOffersResultSent = false;
              try {
                if (t2.setLoadingState(f.G.PENDING, I2), b2) {
                  let i3 = {};
                  o2 && (i3.communication_id = o2), g2 && (i3.campaign_id = g2), s2 = yield m2.getOffers(I2, n2, {
                    expFlags: v2,
                    eventSessionId: e2.sessionId,
                    customProperties: i3,
                    widgetServiceName: d2
                  }), t2.setAcqData(I2 || Q.l.NO_VALUE, {
                    ...((e3) => {
                      let { sessionId: t3, result: i4, offerConfigId: s3, mlRequestId: r3, page: a3, language: n3 } = e3;
                      return (0, l.wg)({
                        sessionId: t3,
                        page: a3,
                        offers: i4.map(eg),
                        mlRequestId: r3,
                        offerConfigId: s3,
                        language: n3
                      });
                    })(s2),
                    loadingState: f.G.RESOLVE,
                    isLoadOffersResultSent: false
                  });
                } else
                  s2 = yield c2.getCompositeOffers({ uid: r2, target: u2 || "music" }), e2.data = ((e3) => {
                    let { eventSessionId: t3, batchPositionId: i3, offers: s3 } = e3;
                    return (0, l.wg)({ eventSessionId: t3, batchPositionId: i3, offers: s3.map(eo) });
                  })(s2), u2 && t2.setCustomTarget(u2);
                t2.setLoadingState(f.G.RESOLVE, I2);
              } catch (e3) {
                t2.setLoadingState(f.G.REJECT, I2), K2.error(e3);
              }
            }
          })
        };
        return t2;
      }).named("MusicOffers"), eC = l.gK.model("Offers", { music: eh });
      var eR = i(23753), eP = i(76294), ex = i(29895), e_ = i(29143), eM = i(90461);
      let eG = l.gK.model("Settings", {
        layout: l.gK.maybeNull(l.gK.enumeration(Object.keys(eR.u))),
        isLandscape: l.gK.boolean,
        isMobileLandscapeHeight: l.gK.boolean,
        platform: l.gK.maybe(l.gK.enumeration(Object.values(e_.O))),
        browserInfo: o,
        liteVersionMode: l.gK.maybe(l.gK.enumeration(Object.values(ex.w))),
        selectedThumbId: l.gK.enumeration(Object.values(eP.T))
      }).views((e2) => {
        let t2 = {
          get isMobile() {
            return e2.layout === eR.u.Mobile;
          },
          get isWindowsApplication() {
            return e2.platform === e_.O.WINDOWS;
          },
          get isMacOSApplication() {
            return e2.platform === e_.O.MACOS;
          },
          get isLinuxApplication() {
            return e2.platform === e_.O.LINUX;
          },
          get isLiteVersionModeEnabled() {
            return e2.liteVersionMode === ex.w.ENABLED;
          },
          get isLiteVersionModeDisabled() {
            return e2.liteVersionMode === ex.w.DISABLED;
          },
          get isLiteVersionModeAvailableForToggle() {
            return t2.isLiteVersionModeDisabled || t2.isLiteVersionModeEnabled;
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          setLayout(t3) {
            e2.layout = t3;
          },
          setPlatform(t3) {
            e2.platform = t3;
          },
          setIsLandscape(t3) {
            e2.isLandscape = t3;
          },
          setIsMobileLandscapeHeight(t3) {
            e2.isMobileLandscapeHeight = t3;
          },
          setBrowserInfo(t3) {
            let i2 = void 0 !== t3.version ? String(t3.version) : void 0;
            e2.browserInfo = (0, l.wg)({ ...t3, version: i2 });
          },
          initializeLiteVersionMode() {
            if (!(0, l._n)(e2)) return;
            let { experiments: i2 } = (0, l.Zn)(e2), { containerStorage: s2 } = (0, l._$)(e2), r2 = s2.get(eM.c.LiteVersionMode);
            if (r2) {
              if ("2" !== r2.version || !i2.checkExperiment(eu.z.WebNextLiteVersion, "on"))
                return void s2.remove(eM.c.LiteVersionMode);
              t2.setLiteVersionMode(r2.mode, false);
            }
          },
          setLiteVersionMode(t3, i2) {
            let { containerStorage: s2 } = (0, l._$)(e2);
            e2.liteVersionMode = t3, i2 && s2.set(eM.c.LiteVersionMode, { version: "2", mode: t3 });
          },
          setCustomPlayerThumb(t3) {
            let { localStorage: i2 } = (0, l._$)(e2), s2 = t3;
            Object.values(eP.T).includes(t3) || (s2 = eP.T.DEFAULT), e2.selectedThumbId = s2;
            let r2 = i2.get(eM.c.CustomPlayerThumbConfig);
            i2.set(eM.c.CustomPlayerThumbConfig, { ...r2, selectedThumbId: s2, version: "1" });
          },
          initializeCustomPlayerThumb() {
            if (!(0, l._n)(e2)) return;
            let { experiments: i2, user: s2 } = (0, l.Zn)(e2), { localStorage: r2 } = (0, l._$)(e2), a2 = r2.get(eM.c.CustomPlayerThumbConfig);
            if (a2) {
              if ("1" !== a2.version || !i2.checkExperiment(eu.z.WebNextCustomThumb, "on") || !s2.hasPlus) {
                e2.selectedThumbId = eP.T.DEFAULT, r2.remove(eM.c.CustomPlayerThumbConfig);
                return;
              }
              if (a2.selectedThumbId === eP.T.BRANDED && s2.hasPlus) return void t2.setCustomPlayerThumb(eP.T.DEFAULT);
              t2.setCustomPlayerThumb(a2.selectedThumbId);
            }
          }
        };
        return t2;
      }), ew = a.extend((e2) => ({
        views: {
          get isVisible() {
            let {
              experiments: t2,
              advertBanners: {
                banners: { brandedPlaylistBanner: i2, brandedEntityAxeBanner: s2 }
              }
            } = (0, l.Zn)(e2), r2 = t2.checkExperiment(eu.z.WebNextDisableAds, "on");
            if (i2.isVisible || s2.isVisible || r2) return false;
            return true;
          }
        }
      })).named("SideAdvertBanner"), eq = a.extend((e2) => ({
        views: {
          get isVisible() {
            var t2;
            let {
              experiments: i2,
              settings: s2,
              advertBanners: {
                banners: { brandedPlaylistBanner: r2, brandedEntityAxeBanner: a2 }
              }
            } = (0, l.Zn)(e2), n2 = s2.isMobile && (i2.checkExperiment(eu.z.WebNextTouchAds, "small_banner") || i2.checkExperiment(eu.z.WebNextTouchAds, "large_banner")), o2 = r2.isVisible || a2.isVisible;
            return !(null == (t2 = s2.browserInfo) ? void 0 : t2.isTouch) && !n2 && !o2;
          }
        }
      })).named("TopAdvertBanner"), ej = l.gK.model("TrackIdModel", {
        id: l.gK.union(l.gK.string, l.gK.number),
        albumId: l.gK.maybe(l.gK.number),
        timestamp: l.gK.maybe(l.gK.string)
      });
    },
    73975: (e, t, i) => {
      var s;
      i.d(t, { M: () => s }), (function(e2) {
        e2.MODAL = "modal", e2.FOREIGN_AGENT = "foreignAgent", e2.INFORMATIONAL = "informational", e2.AGE_18 = "age18", e2.EXPLICIT = "explicit", e2.DESCRIPTION_TEXT = "descriptionText", e2.AGE_18_ICON = "age18Icon", e2.EXPLICIT_ICON = "explicitIcon", e2.EXCLAMATION_ICON = "exclamationIcon";
      })(s || (s = {}));
    },
    77534: (e, t, i) => {
      var s;
      i.d(t, { f: () => s }), (function(e2) {
        e2.OK = "ok", e2.ERROR = "error";
      })(s || (s = {}));
    },
    79899: (e, t, i) => {
      var s;
      i.d(t, { K: () => s }), (function(e2) {
        e2.EXPLICIT = "explicit", e2.CLEAN = "clean";
      })(s || (s = {}));
    }
  }
]);
