(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [671],
  {
    607: (e, t, n) => {
      "use strict";
      n.d(t, { ConcertLayout: () => o });
      var r = n(28303), a = n(97396), i = n(74125);
      let o = (0, r.PA)((e2) => {
        let { children: t2 } = e2, { experiments: n2 } = (0, i.Pjs)();
        return n2.checkExperiment(i.zal.WebNextDisableConcertsTab, "on") && (0, a.redirect)("/"), t2;
      });
    },
    8459: (e, t, n) => {
      "use strict";
      n.d(t, { m: () => c });
      var r = n(54486), a = n(62662), i = n(74125), o = n(78107), s = n.n(o);
      let l = [{ id: i.uQT.INFO }, { id: i.uQT.ERROR, limit: 1 }], c = () => l.map((e2) => {
        let { id: t2, limit: n2 } = e2;
        return (0, r.jsx)(
          a.Notification,
          { className: s().root, enableMultiContainer: true, containerId: t2, position: "bottom-center", limit: n2 },
          t2
        );
      });
    },
    10209: (e, t, n) => {
      "use strict";
      n.d(t, { DefaultLayout: () => et });
      var r = n(54486), a = n(50420), i = n(28303), o = n(97396), s = n(61910), l = n(79952), c = n(69034), d = n(96909), u = n(54278), _ = n(66498), m = n(49324), p = n(13193), x = n(32061), h = n(31500), v = n(77881), f = n(97800), j = n(74125), b = n(52785), A = n.n(b);
      let C = (0, i.PA)((e2) => {
        let { className: t2 } = e2, {
          redAlert: { text: n2, buttonText: i2, href: o2 }
        } = (0, j.Pjs)(), s2 = (0, j.ZpR)(o2), { theme: l2 } = (0, j.DPo)();
        return (0, r.jsx)("div", {
          className: (0, a.$)(A().wrapper, t2),
          ...(0, h.Am)(h.e8.redAlert.RED_ALERT),
          children: (0, r.jsxs)("div", {
            className: (0, a.$)(A().root, { [A().root_light]: l2 === j.Sxu.Light }),
            children: [
              (0, r.jsx)(f.Caption, {
                className: A().text,
                type: "controls",
                variant: "p",
                size: "m",
                weight: "medium",
                ...(0, h.Am)(h.e8.redAlert.RED_ALERT_TEXT),
                children: n2
              }),
              (0, r.jsx)(v.$, {
                className: A().button,
                color: "secondary",
                size: "m",
                radius: "xxxl",
                onClick: s2,
                ...(0, h.Am)(h.e8.redAlert.RED_ALERT_BUTTON),
                children: (0, r.jsx)(f.Caption, {
                  type: "controls",
                  variant: "span",
                  size: "m",
                  weight: "medium",
                  children: i2
                })
              })
            ]
          })
        });
      });
      var g = n(82644), y = n(95373), k = n(13403), N = n(98845), T = n(55616), L = n(88294), P = n(69610), w = n(91803), D = n(51376), E = n(21514), M = n(7186), R = n(21365), B = n(54830), O = n(34942), S = n(80585), I = n(95369), W = n.n(I), z = n(8459), F = n(33115), V = n.n(F), $ = n(1365), K = n(21390), U = n(43426), Y = n(8817);
      let H = { p1: "czmwt", p2: "hsnu", puid1: "", puid2: "" };
      var G = n(98626), X = n.n(G);
      let Z = (0, i.PA)((e2) => {
        let { className: t2, forwardRef: n2, onAdvertChange: i2, ...o2 } = e2, {
          advertBanners: {
            banners: { topAdvertBanner: s2 }
          }
        } = (0, j.Pjs)(), { formatMessage: l2 } = (0, U.A)(), c2 = (0, Y.c)((e3) => {
          void 0 !== e3 && s2.setType(e3), i2();
        });
        return (0, r.jsx)("section", {
          ref: n2,
          className: (0, a.$)(X().root, t2, { [X().root_hidden]: !s2.isVisible }),
          "aria-label": l2({ id: "advert.banner" }),
          role: "banner",
          ...o2,
          children: (0, r.jsx)(S.NX, {
            className: X().advert,
            ownerId: j.PVv,
            containerId: "adfox_173831489272852769",
            params: H,
            onLoad: s2.setType,
            onRender: c2,
            onError: s2.toggleHasErrorTrue,
            onNoAds: s2.toggleNoAdsTrue
          })
        });
      }), q = (0, s.forwardRef)((e2, t2) => (0, r.jsx)(Z, { forwardRef: t2, ...e2 }));
      var Q = n(16319), J = n.n(Q);
      let ee = (0, i.PA)((e2) => {
        let { children: t2 } = e2, [n2, i2] = (0, s.useState)(false), [o2, l2] = (0, s.useState)(true), [c2, d2] = (0, s.useState)(false), { contentRef: u2, contentScrollRef: _2 } = (0, j.gKY)(), m2 = (0, s.useRef)(null), { isFreemium: p2 } = (0, j.XCI)(), {
          user: x2,
          advertBanners: {
            banners: { topAdvertBanner: h2 }
          }
        } = (0, j.Pjs)(), v2 = (!x2.isAuthorized || p2) && h2.isVisible, f2 = (0, s.useCallback)(() => {
          l2(false), i2(true);
        }, [l2, i2]), b2 = (0, s.useCallback)(() => {
          l2(true), i2(false);
        }, [l2, i2]), A2 = (0, s.useCallback)(() => {
          d2(false);
        }, [d2]), C2 = (0, s.useMemo)(
          () => v2 ? (0, r.jsx)(q, {
            className: (0, a.$)(J().banner, { [J().banner_canShow]: n2 }),
            onFocus: f2,
            onBlur: b2,
            onAdvertChange: A2,
            ref: m2
          }) : null,
          [v2, n2, f2, b2, A2]
        ), g2 = (0, s.useCallback)(() => {
          var e3;
          if (!C2) return;
          if (!u2 || !_2) return void i2(true);
          let t3 = _2.scrollTop > 0, n3 = u2.clientHeight + ((null == (e3 = m2.current) ? void 0 : e3.offsetHeight) || 0) < _2.scrollHeight;
          if (n3 ? l2(true) : !n3 && t3 && l2(false), !o2 || !t3 && c2) return;
          let r2 = !t3;
          i2(r2), r2 && d2(true);
        }, [u2, _2, C2, o2, c2, i2, l2, d2]);
        (0, s.useEffect)(() => {
          g2();
        }, [g2, _2]);
        let y2 = (0, s.useMemo)(() => (0, $.A)(g2, 200), [g2]);
        return (0, K.L)({ onScroll: y2, elementRef: _2 }), (0, r.jsxs)("div", {
          className: J().root,
          children: [C2, (0, r.jsx)("div", { className: J().content, children: t2 })]
        });
      }), et = (0, i.PA)((e2) => {
        var t2, n2, i2, h2, v2, f2;
        let { className: b2, children: A2 } = e2, I2 = (0, o.usePathname)(), { setCompositePlayerBarRef: F2 } = (0, j.gKY)(), $2 = (0, j.NFA)().get(j.ooW), K2 = (0, m.Yp)(), {
          settings: {
            browserInfo: U2,
            isMobile: Y2,
            isWindowsApplication: H2,
            isMacOSApplication: G2,
            isLinuxApplication: X2
          },
          experiments: Z2,
          communication: q2,
          user: Q2,
          redAlert: J2,
          downloadMobileApp: et2,
          album: en,
          albumCPA: { isPlusCPAPlayerBarEnabled: er, isHidePlusModalEnabled: ea },
          modals: { buySubscriptionModal: ei },
          advertBanners: {
            banners: { brandedEntityAxeBanner: eo }
          }
        } = (0, j.Pjs)(), { isFreemium: es } = (0, j.XCI)(), [el, ec] = (0, s.useState)(null != (f2 = $2.get(j.cYZ.NavbarCollapsed)) ? f2 : K2), ed = (0, s.useMemo)(() => ({ isCollapsed: el || K2, setIsCollapsed: ec }), [el, K2]);
        (0, j.dKN)();
        let eu = (!Q2.isAuthorized || es) && (null == U2 ? void 0 : U2.isTouch), e_ = (0, B.df)(), em = Z2.checkExperiment(j.zal.WebNextArtistInfo, "on"), ep = !J2.isVisible && !Y2 && (null == (t2 = q2.list) ? void 0 : t2.barBelow.isVisible) && (null == (n2 = q2.list) ? void 0 : n2.barBelow.hasAnimationAlreadyBeenStarted), ex = Z2.checkExperiment(j.zal.WebNextDeeplinksToMobile, "on") && Q2.hasPlus && !!(null == U2 ? void 0 : U2.isMobile) && false, { setDefaultLayoutRef: eh } = (0, j.gKY)(), ev = er(null == en ? void 0 : en.id, null == en || null == (i2 = en.meta) ? void 0 : i2.isNonMusic), ef = ea(null == en ? void 0 : en.id, null == en || null == (h2 = en.meta) ? void 0 : h2.isNonMusic), ej = !eu || ev, eb = ev && (null == U2 ? void 0 : U2.isTouch);
        return (0, s.useEffect)(() => {
          ef && ei.close();
        }, [ef, ei]), (0, r.jsx)(j.qTt.Provider, {
          value: ed,
          children: (0, r.jsx)(ee, {
            children: (0, r.jsx)(S.do, {
              isEnabled: ex,
              children: (0, r.jsx)(D.sO, {
                children: (0, r.jsxs)("div", {
                  ref: eh,
                  className: (0, a.$)(
                    W().root,
                    V().root,
                    {
                      [V().root_applicationPreserveTitleBar]: H2 || X2,
                      [V().root_withBarBelow]: J2.isVisible || ep,
                      [W().root_withAxeBanner]: eo.isVisible
                    },
                    b2
                  ),
                  children: [
                    eb && (0, r.jsx)(P.BZ, { modal: ei }),
                    !Y2 && ej && (0, r.jsx)(m.Fp, {
                      className: (0, a.$)(V().navbar, {
                        [V().navbar_application_windows]: H2,
                        [V().navbar_application_macos]: G2,
                        [V().navbar_application_linux]: X2
                      }),
                      externalIsCollapsed: el,
                      externalSetIsCollapsed: ec
                    }),
                    (0, r.jsx)(c.UC, {
                      className: (0, a.$)(W().content, {
                        [W().content_withPlayerBar]: Y2,
                        [W().content_withAxeBanner]: eo.isVisible
                      }),
                      children: (0, r.jsxs)(S.tH, { fallback: g.w, children: [A2, (0, r.jsx)(z.m, {})] }, I2)
                    }),
                    !Y2 && ej && (0, r.jsx)(j.nVz, {
                      pageId: j._Q$.PLAYER,
                      children: (0, r.jsx)(x.LN, { className: W().playerBar })
                    }),
                    Y2 && ej && (0, r.jsxs)("div", {
                      ref: F2,
                      className: W().compositePlayerBar,
                      children: [
                        ex && (0, r.jsx)(S.jg, {}),
                        (0, r.jsx)(j.nVz, {
                          pageId: j._Q$.PLAYER,
                          children: (0, r.jsx)(x.LN, { className: W().playerBar })
                        }),
                        (0, r.jsx)(m.Fp, {
                          className: (0, a.$)(V().navbar, {
                            [V().navbar_application_windows]: H2,
                            [V().navbar_application_macos]: G2,
                            [V().navbar_application_linux]: X2
                          }),
                          externalIsCollapsed: el,
                          externalSetIsCollapsed: ec
                        })
                      ]
                    }),
                    J2.isVisible && (0, r.jsx)(C, { className: V().barBelow }),
                    !J2.isVisible && !Y2 && q2.list && (0, r.jsx)(L.Bx, { className: V().barBelow, barBelow: q2.list.barBelow }),
                    (null == (v2 = q2.list) ? void 0 : v2.modal) && (0, r.jsx)(w.ov, { modal: q2.list.modal }),
                    (0, r.jsx)(j.nVz, { pageId: j._Q$.PLAYER, children: (0, r.jsx)(x.vR, {}) }),
                    e_ && (0, r.jsx)(j.nVz, { pageId: j._Q$.VIDEO_PLAYER, children: (0, r.jsx)(k.A2, {}) }),
                    (0, r.jsx)(S.Pe, {}),
                    (0, r.jsx)(j.nVz, { pageId: j._Q$.TRAILER, children: (0, r.jsx)(y.f, {}) }),
                    (0, r.jsx)(N.p, {}),
                    e_ && (0, r.jsx)(c.$9, {}),
                    (0, r.jsx)(c.US, {}),
                    em && (0, r.jsx)(T.y8, {}),
                    !Q2.hasPlus && (0, r.jsxs)(r.Fragment, {
                      children: [(0, r.jsx)(p.cw, {}), (0, r.jsx)(d.g, {}), (0, r.jsx)(x.BG, {})]
                    }),
                    !Q2.hasPlus && (0, r.jsx)(_.x8, {}),
                    (0, r.jsx)(M.P, {}),
                    (0, r.jsx)(c.VW, {}),
                    (0, r.jsx)(l.hq, {}),
                    (0, r.jsx)(O.mt, {}),
                    (0, r.jsx)(R.U6, {}),
                    et2.shouldShow() && (0, r.jsx)(u.h, {}),
                    (0, r.jsx)(E.w, {})
                  ]
                })
              })
            })
          })
        });
      });
    },
    10877: (e, t, n) => {
      "use strict";
      n.d(t, { NonMusicLayout: () => o });
      var r = n(28303), a = n(97396), i = n(74125);
      let o = (0, r.PA)((e2) => {
        let { children: t2 } = e2, { experiments: n2 } = (0, i.Pjs)();
        return n2.checkExperiment(i.zal.WebNextDisableNonMusic, "on") && (0, a.redirect)(i.Zyd.main.href), t2;
      });
    },
    16319: (e) => {
      e.exports = {
        root: "WithTopBanner_root__P__x3",
        banner: "WithTopBanner_banner__x1Ia2",
        banner_canShow: "WithTopBanner_banner_canShow__5KA30",
        content: "WithTopBanner_content__6Vh7a"
      };
    },
    19713: (e, t, n) => {
      "use strict";
      n.d(t, { FN: () => a, gj: () => r }), n(99215);
      let r = (e2) => {
        let { containerNodeRect: t2, draggingNodeRect: n2, transform: r2 } = e2;
        return n2 && t2 ? (function(e3, t3, n3) {
          let r3 = { ...e3 };
          return t3.top + e3.y <= n3.top ? r3.y = n3.top - t3.top : t3.bottom + e3.y >= n3.top + n3.height && (r3.y = n3.top + n3.height - t3.bottom), t3.left + e3.x <= n3.left ? r3.x = n3.left - t3.left : t3.right + e3.x >= n3.left + n3.width && (r3.x = n3.left + n3.width - t3.right), r3;
        })(r2, n2, t2) : r2;
      }, a = (e2) => {
        let { transform: t2 } = e2;
        return { ...t2, x: 0 };
      };
    },
    19741: (e, t, n) => {
      "use strict";
      n.d(t, { CollectionLayout: () => o });
      var r = n(28303), a = n(97396), i = n(74125);
      let o = (0, r.PA)((e2) => {
        let { children: t2 } = e2, { experiments: n2 } = (0, i.Pjs)();
        return n2.checkExperiment(i.zal.WebNextDisableCollection, "on") && (0, a.redirect)(i.Zyd.main.href), t2;
      });
    },
    23266: (e) => {
      e.exports = { root: "PromoLandingContent_root__QrRKX", main: "PromoLandingContent_main__ELiBu" };
    },
    27604: (e) => {
      e.exports = {
        root: "TrackAboutModalDesktop_root__NHeeO",
        root_withFullscreen: "TrackAboutModalDesktop_root_withFullscreen__jOu4X",
        root_withCustomControls: "TrackAboutModalDesktop_root_withCustomControls__b2JDR",
        header: "TrackAboutModalDesktop_header__7Zl2n",
        modalContent: "TrackAboutModalDesktop_modalContent__yf4i5",
        explicitMark: "TrackAboutModalDesktop_explicitMark__tgVyh",
        important: "TrackAboutModalDesktop_important__tCPvh",
        version: "TrackAboutModalDesktop_version__m0z2v",
        explicit: "TrackAboutModalDesktop_explicit__FGMHf",
        content: "TrackAboutModalDesktop_content__eEGZu",
        artistLink: "TrackAboutModalDesktop_artistLink__ao_zU",
        artists: "TrackAboutModalDesktop_artists__2SlTA",
        overlay: "TrackAboutModalDesktop_overlay__7cEGE",
        textShimmer: "TrackAboutModalDesktop_textShimmer__r5_AA",
        text: "TrackAboutModalDesktop_text__zcpo0"
      };
    },
    33115: (e) => {
      e.exports = {
        root: "DefaultLayout_root__7J0wo",
        root_applicationPreserveTitleBar: "DefaultLayout_root_applicationPreserveTitleBar__ygJtq",
        root_withBarBelow: "DefaultLayout_root_withBarBelow__jPsaV",
        barBelow: "DefaultLayout_barBelow__y6PFU",
        navbar: "DefaultLayout_navbar__LIQWG",
        navbar_application_macos: "DefaultLayout_navbar_application_macos__9dj3u",
        navbar_application_linux: "DefaultLayout_navbar_application_linux__ejlGn",
        navbar_application_windows: "DefaultLayout_navbar_application_windows__3hDQ_"
      };
    },
    37491: (e, t, n) => {
      "use strict";
      n.d(t, { KidsLayout: () => o });
      var r = n(28303), a = n(97396), i = n(74125);
      let o = (0, r.PA)((e2) => {
        let { children: t2 } = e2, { experiments: n2 } = (0, i.Pjs)();
        return n2.checkExperiment(i.zal.WebNextDisableKids, "on") && (0, a.redirect)(i.Zyd.main.href), t2;
      });
    },
    46865: (e, t, n) => {
      "use strict";
      n.d(t, { PromoLandingLayout: () => y });
      var r = n(54486), a = n(50420), i = n(28303), o = n(97396), s = n(61910), l = n(63664), c = n(69034), d = n(96909), u = n(13193), _ = n(32061), m = n(82644), p = n(69610), x = n(34942), h = n(74125), v = n(80585), f = n(95369), j = n.n(f), b = n(8459), A = n(99481), C = n.n(A);
      let g = {
        enter: C().animatedPlayer_enter,
        enterActive: C().animatedPlayer_enter_active,
        exit: C().animatedPlayer_exit,
        exitActive: C().animatedPlayer_exit_active
      }, y = (0, i.PA)((e2) => {
        let { className: t2, children: n2 } = e2, i2 = (0, o.usePathname)(), f2 = (0, s.useRef)(null), {
          settings: { isMobile: A2 },
          modals: { promoLandingBuySubscriptionModal: y2 },
          promolanding: { state: k }
        } = (0, h.Pjs)(), { isFreemium: N } = (0, h.XCI)();
        return (0, r.jsxs)("div", {
          style: { "--promo-landing-layout-transition-duration": "".concat(220, "ms") },
          className: (0, a.$)((0, h.JH_)(h.Sxu.Dark), j().root, C().root, t2),
          children: [
            (0, r.jsx)(c.i6, {
              className: (0, a.$)(j().content, { [j().content_withPlayerBar]: A2 }),
              children: (0, r.jsxs)(v.tH, { fallback: m.w, children: [n2, (0, r.jsx)(b.m, {})] }, i2)
            }),
            (0, r.jsx)(l.A, {
              nodeRef: f2,
              in: !!k.entityMeta,
              timeout: 220,
              classNames: g,
              unmountOnExit: true,
              children: (0, r.jsx)(h.nVz, {
                pageId: h._Q$.PLAYER,
                children: (0, r.jsx)("div", {
                  ref: f2,
                  className: (0, a.$)(C().playerBar, { [j().compositePlayerBar]: A2, [j().playerBar]: !A2 }),
                  children: (0, r.jsx)(_.Hq, { className: (0, a.$)({ [j().playerBar]: A2 }) })
                })
              })
            }),
            N && (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(p.BZ, { modal: y2 }),
                (0, r.jsx)(d.g, { withAlreadyInPlusButton: true }),
                (0, r.jsx)(x.mt, {}),
                (0, r.jsx)(u.cw, {})
              ]
            }),
            (0, r.jsx)(v.Pe, {})
          ]
        });
      });
    },
    47691: (e) => {
      e.exports = {
        root: "ClipAboutModalDesktop_root__F8UU5",
        root_withFullscreen: "ClipAboutModalDesktop_root_withFullscreen__nTO1X",
        root_withWindows: "ClipAboutModalDesktop_root_withWindows__kl4sc",
        header: "ClipAboutModalDesktop_header__at6X6",
        modalContent: "ClipAboutModalDesktop_modalContent__Rp_ON",
        explicitMark: "ClipAboutModalDesktop_explicitMark__SLwRj",
        important: "ClipAboutModalDesktop_important__LkqWo",
        content: "ClipAboutModalDesktop_content__0dUY1",
        titleShimmer: "ClipAboutModalDesktop_titleShimmer__zTtu_"
      };
    },
    52785: (e) => {
      e.exports = {
        wrapper: "RedAlert_wrapper__rGvGN",
        root: "RedAlert_root__1VZOr",
        root_light: "RedAlert_root_light__j7Kr3",
        text: "RedAlert_text__UB_Bq",
        button: "RedAlert_button__Ho43z"
      };
    },
    53497: (e, t, n) => {
      "use strict";
      n.d(t, { A: () => _ });
      var r = n(20427), a = n(41330), i = n(8197), o = n(61910), s = n(35948);
      function l(e2, t2) {
        var n2 = /* @__PURE__ */ Object.create(null);
        return e2 && o.Children.map(e2, function(e3) {
          return e3;
        }).forEach(function(e3) {
          n2[e3.key] = t2 && (0, o.isValidElement)(e3) ? t2(e3) : e3;
        }), n2;
      }
      function c(e2, t2, n2) {
        return null != n2[t2] ? n2[t2] : e2.props[t2];
      }
      var d = Object.values || function(e2) {
        return Object.keys(e2).map(function(t2) {
          return e2[t2];
        });
      }, u = (function(e2) {
        function t2(t3, n3) {
          var r2 = e2.call(this, t3, n3) || this, a2 = r2.handleExited.bind(
            (function(e3) {
              if (void 0 === e3) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
              return e3;
            })(r2)
          );
          return r2.state = { contextValue: { isMounting: true }, handleExited: a2, firstRender: true }, r2;
        }
        (0, i.A)(t2, e2);
        var n2 = t2.prototype;
        return n2.componentDidMount = function() {
          this.mounted = true, this.setState({ contextValue: { isMounting: false } });
        }, n2.componentWillUnmount = function() {
          this.mounted = false;
        }, t2.getDerivedStateFromProps = function(e3, t3) {
          var n3, r2, a2 = t3.children, i2 = t3.handleExited;
          return {
            children: t3.firstRender ? l(e3.children, function(t4) {
              return (0, o.cloneElement)(t4, {
                onExited: i2.bind(null, t4),
                in: true,
                appear: c(t4, "appear", e3),
                enter: c(t4, "enter", e3),
                exit: c(t4, "exit", e3)
              });
            }) : (Object.keys(
              r2 = (function(e4, t4) {
                function n4(n5) {
                  return n5 in t4 ? t4[n5] : e4[n5];
                }
                e4 = e4 || {}, t4 = t4 || {};
                var r3, a3 = /* @__PURE__ */ Object.create(null), i3 = [];
                for (var o2 in e4) o2 in t4 ? i3.length && (a3[o2] = i3, i3 = []) : i3.push(o2);
                var s2 = {};
                for (var l2 in t4) {
                  if (a3[l2])
                    for (r3 = 0; r3 < a3[l2].length; r3++) {
                      var c2 = a3[l2][r3];
                      s2[a3[l2][r3]] = n4(c2);
                    }
                  s2[l2] = n4(l2);
                }
                for (r3 = 0; r3 < i3.length; r3++) s2[i3[r3]] = n4(i3[r3]);
                return s2;
              })(a2, n3 = l(e3.children))
            ).forEach(function(t4) {
              var s2 = r2[t4];
              if ((0, o.isValidElement)(s2)) {
                var l2 = t4 in a2, d2 = t4 in n3, u2 = a2[t4], _2 = (0, o.isValidElement)(u2) && !u2.props.in;
                d2 && (!l2 || _2) ? r2[t4] = (0, o.cloneElement)(s2, {
                  onExited: i2.bind(null, s2),
                  in: true,
                  exit: c(s2, "exit", e3),
                  enter: c(s2, "enter", e3)
                }) : d2 || !l2 || _2 ? d2 && l2 && (0, o.isValidElement)(u2) && (r2[t4] = (0, o.cloneElement)(s2, {
                  onExited: i2.bind(null, s2),
                  in: u2.props.in,
                  exit: c(s2, "exit", e3),
                  enter: c(s2, "enter", e3)
                })) : r2[t4] = (0, o.cloneElement)(s2, { in: false });
              }
            }), r2),
            firstRender: false
          };
        }, n2.handleExited = function(e3, t3) {
          var n3 = l(this.props.children);
          e3.key in n3 || (e3.props.onExited && e3.props.onExited(t3), this.mounted && this.setState(function(t4) {
            var n4 = (0, a.A)({}, t4.children);
            return delete n4[e3.key], { children: n4 };
          }));
        }, n2.render = function() {
          var e3 = this.props, t3 = e3.component, n3 = e3.childFactory, a2 = (0, r.A)(e3, ["component", "childFactory"]), i2 = this.state.contextValue, l2 = d(this.state.children).map(n3);
          return (delete a2.appear, delete a2.enter, delete a2.exit, null === t3) ? o.createElement(s.A.Provider, { value: i2 }, l2) : o.createElement(s.A.Provider, { value: i2 }, o.createElement(t3, a2, l2));
        }, t2;
      })(o.Component);
      u.propTypes = {}, u.defaultProps = {
        component: "div",
        childFactory: function(e2) {
          return e2;
        }
      };
      let _ = u;
    },
    57249: (e, t, n) => {
      "use strict";
      e.exports = n.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    67628: (e) => {
      e.exports = {
        root: "TrackLyricsModal_root__KsVRf",
        header: "TrackLyricsModal_header__nWar3",
        modalContent: "TrackLyricsModal_modalContent__uYdL2",
        content: "TrackLyricsModal_content__Cstzi",
        explicitMark: "TrackLyricsModal_explicitMark__eL04d",
        important: "TrackLyricsModal_important__0Ie9h",
        version: "TrackLyricsModal_version__l9sxZ",
        overlay: "TrackLyricsModal_overlay__0Ehwu"
      };
    },
    69034: (e, t, n) => {
      "use strict";
      n.d(t, { $9: () => h, UC: () => L, i6: () => D, US: () => W, VW: () => $ });
      var r = n(54486), a = n(28303), i = n(74125), o = n(50420), s = n(61910), l = n(43426), c = n(31500), d = n(32692), u = n(34284), _ = n(80585), m = n(47691), p = n.n(m);
      let x = (0, a.PA)(() => {
        let { formatMessage: e2 } = (0, l.A)(), { notify: t2 } = (0, i.lkh)(), { contentRef: n2 } = (0, i.gKY)(), {
          currentClipInfo: a2,
          settings: { isMobile: m2, isWindowsApplication: x2 },
          fullscreenVideoPlayer: h2
        } = (0, i.Pjs)(), { modal: v2, clip: f2 } = a2;
        !f2 && a2.isClipIdle && a2.getClip(), !a2.credits && a2.isCreditsIdle && a2.getCreditsInfo();
        let j2 = null == f2 ? void 0 : f2.title, b2 = null == f2 ? void 0 : f2.explicitDisclaimer, A2 = (0, s.useMemo)(
          () => a2.isClipLoading || a2.isClipRejected ? (0, r.jsx)(_.q$, { className: p().titleShimmer, count: 1 }) : f2 ? (0, r.jsxs)("span", {
            children: [
              j2,
              b2 && (0, r.jsx)(_.Nq, {
                getDescriptionTexts: f2.getDescriptionTexts,
                className: (0, o.$)(p().explicitMark, p().important),
                size: "xxs",
                variant: b2
              })
            ]
          }) : void 0,
          [f2, j2, b2, a2.isClipLoading, a2.isClipRejected]
        );
        (0, s.useEffect)(
          () => () => {
            v2.close(), a2.reset();
          },
          [a2, v2]
        );
        let C2 = (0, s.useCallback)(() => {
          v2.close(), a2.reset();
        }, [a2, v2]), g2 = (0, s.useCallback)(
          (e3) => {
            var t3;
            e3 || a2.reset(), null == (t3 = v2.onOpenChange) || t3.call(v2, e3);
          },
          [a2, v2]
        );
        a2.isRejected && (C2(), t2((0, r.jsx)(_.hT, { error: e2({ id: "error-messages.error-during-action" }) }), {
          containerId: i.uQT.ERROR
        }));
        let y2 = (0, s.useMemo)(() => {
          var e3;
          return a2.isCreditsLoading || a2.isCreditsRejected ? (0, r.jsx)(_.q$, {}) : (null == (e3 = a2.credits) ? void 0 : e3.length) ? a2.credits.map((e4) => {
            let t3 = (0, r.jsx)(u.D, { children: e4.value });
            return (0, r.jsx)(u.O, { infoDescription: t3, title: e4.title }, e4.title);
          }) : null;
        }, [a2.credits, a2.isCreditsLoading, a2.isCreditsRejected]);
        return (0, r.jsx)(d.a, {
          containerProps: (0, c.Am)(c.Kq.clip.CLIP_ABOUT_MODAL),
          placement: m2 ? "default" : "right",
          open: v2.isOpened,
          onClose: C2,
          contentClassName: p().modalContent,
          title: A2,
          headerClassName: p().header,
          className: (0, o.$)(p().root, { [p().root_withFullscreen]: h2.modal.isOpened, [p().root_withWindows]: x2 }),
          onOpenChange: g2,
          labelClose: e2({ id: "interface-actions.close" }),
          portalNode: m2 || h2.modal.isOpened ? null : n2,
          children: (0, r.jsx)("div", { className: p().content, children: y2 })
        });
      }), h = (0, a.PA)(() => {
        let {
          settings: { isMobile: e2 }
        } = (0, i.Pjs)();
        return e2 ? null : (0, r.jsx)(x, {});
      });
      n(53497), n(63664);
      var v = n(8817), f = n(27510), j = n(69306), b = n(71858), A = n.n(b);
      A().secondaryEnter, A().secondaryEnterActive;
      var C = (function(e2) {
        return e2.LARGE = "large", e2.SMALL = "small", e2;
      })({}), g = n(97396);
      let y = ["album", "users", "artist", "chart"];
      var k = n(1365);
      let N = () => 30 * window.innerHeight / 100, T = (e2, t2) => e2 > 0 && t2 > 0, L = (0, a.PA)((e2) => {
        let { className: t2, children: n2 } = e2;
        (0, i.NFA)();
        let { formatMessage: a2 } = (0, l.A)(), {
          setContentRef: c2,
          setContentRootRef: d2,
          setSideBannerRef: u2,
          paywallRef: m2,
          contentScrollRef: p2
        } = (0, i.gKY)(), x2 = (0, i.UlF)(), {
          settings: { isMobile: h2 },
          experiments: b2,
          user: L2,
          advertBanners: {
            banners: { brandedEntityAxeBanner: P2 }
          }
        } = (0, i.Pjs)(), w2 = (0, j.y)(), D2 = (b2.checkExperiment(i.zal.WebNextTouchAds, "small_banner") || b2.checkExperiment(i.zal.WebNextTouchAds, "large_banner")) && !m2 && h2 && !L2.hasPlus && !P2.isVisible, E2 = (D2 && b2.checkExperiment(i.zal.WebNextTouchAds, "small_banner") ? C.SMALL : C.LARGE) === C.SMALL ? "R-I-16641233-1" : "R-I-16641233-2", M2 = ((() => {
          let e3 = (0, g.usePathname)();
          return (0, s.useMemo)(() => {
            let [, t3] = e3.split("/");
            return !!t3 && y.includes(t3);
          }, [e3]);
        })(), ((e3) => {
          let [t3, n3] = (0, s.useState)(N), r2 = (0, s.useRef)(null), a3 = (0, s.useRef)(false), i2 = (0, s.useRef)(N()), o2 = (0, s.useRef)(N()), l2 = (0, v.c)((e4) => {
            let t4 = e4.scrollTop, n4 = e4.scrollHeight, r3 = e4.clientHeight, a4 = o2.current, i3 = t4 <= 5;
            if (!T(n4, r3)) return a4;
            let s2 = n4 - r3;
            return s2 <= 0 ? a4 : s2 >= a4 ? i3 ? a4 : 0 : i3 ? a4 : Math.max(0, a4 - s2);
          }), c3 = (0, v.c)((e4) => {
            n3(Math.round(e4)), i2.current = e4;
          }), d3 = (0, v.c)(() => {
            o2.current = N();
          }), u3 = (0, v.c)((e4) => {
            let t4 = r2.current;
            null !== t4 && cancelAnimationFrame(t4), r2.current = requestAnimationFrame(() => {
              r2.current = null;
              let t5 = l2(e4), n4 = Math.abs(t5 - i2.current), a4 = o2.current;
              (0 === t5 || t5 >= a4 || n4 >= 2) && c3(t5);
            });
          });
          (0, s.useLayoutEffect)(() => {
            if (!e3) {
              let e4 = N();
              o2.current = e4, c3(e4), a3.current = false;
              return;
            }
            if (a3.current) return;
            a3.current = true;
            let t4 = N();
            return (o2.current = t4, e3.scrollTop <= 50) ? void c3(t4) : T(e3.scrollHeight, e3.clientHeight) ? void c3(l2(e3)) : void c3(t4);
          }, [e3, c3, l2]);
          let _2 = (0, s.useMemo)(
            () => e3 ? (0, k.A)(() => {
              d3(), u3(e3);
            }, 100) : null,
            [e3, u3, d3]
          );
          return (0, s.useEffect)(() => {
            if (!e3 || !_2) return;
            u3(e3);
            let t4 = () => {
              u3(e3);
            };
            e3.addEventListener("scroll", t4, { passive: true });
            let n4 = new ResizeObserver(_2);
            n4.observe(e3);
            let a4 = () => {
              d3(), _2();
            };
            return window.addEventListener("resize", a4, { passive: true }), () => {
              _2.cancel();
              let s2 = r2.current;
              null !== s2 && (cancelAnimationFrame(s2), r2.current = null);
              let l3 = N();
              i2.current = l3, o2.current = l3, e3.removeEventListener("scroll", t4), n4.disconnect(), window.removeEventListener("resize", a4);
            };
          }, [e3, u3, _2, d3]), t3;
        })(p2)), R2 = P2.isVisible ? { marginBlockStart: "".concat(M2, "px") } : void 0, B2 = ((0, s.useRef)(null), (0, v.c)(() => {
          x2.error("Cannot render advert banner", { adBlockId: E2 });
        })), O2 = (0, f.L)(() => {
          if (D2)
            return (0, r.jsx)("div", {
              className: A().adContainer,
              "aria-label": a2({ id: "advert.banner" }),
              role: "banner",
              children: (0, r.jsx)(_.fJ, {
                isAsync: false,
                onError: B2,
                productionBlockId: E2,
                testBlockId: E2,
                className: A().adBanner
              })
            });
        });
        return (0, r.jsxs)("div", {
          className: (0, o.$)(A().rootOld, t2),
          ref: d2,
          children: [
            O2,
            (0, r.jsx)("main", {
              className: (0, o.$)(A().main, { [A().withBrandedBanner]: P2.isVisible }),
              style: R2,
              ref: c2,
              children: (0, r.jsx)(s.Suspense, { children: n2 })
            }),
            w2 && (0, r.jsx)(j.u, { className: A().sideBanner, ref: u2 })
          ]
        });
      });
      var P = n(23266), w = n.n(P);
      let D = (e2) => {
        let { className: t2, children: n2 } = e2, { setContentRef: a2, setContentRootRef: l2 } = (0, i.gKY)();
        return (0, r.jsx)("div", {
          className: (0, o.$)(w().root, t2),
          ref: l2,
          children: (0, r.jsx)("main", {
            className: w().main,
            ref: a2,
            children: (0, r.jsx)(s.Suspense, { children: n2 })
          })
        });
      };
      var E = n(8075);
      let M = (0, a.PA)(() => {
        let { formatMessage: e2 } = (0, l.A)(), { currentTrackInfo: t2 } = (0, i.Pjs)(), { fullTrack: n2 } = t2, a2 = (0, f.L)(() => {
          var t3, a3, i2;
          if (!(null == n2 || null == (t3 = n2.mainAlbum) ? void 0 : t3.title)) return;
          let o3 = (0, r.jsx)(u.D, {
            href: null == n2 || null == (a3 = n2.mainAlbum) ? void 0 : a3.url,
            children: null == n2 || null == (i2 = n2.mainAlbum) ? void 0 : i2.title
          });
          return (0, r.jsx)(u.O, { title: e2({ id: "entity-names.audiobook" }), infoDescription: o3 });
        }), o2 = (0, f.L)(() => {
          if (!(null == n2 ? void 0 : n2.shortDescription)) return;
          let e3 = (0, r.jsx)(u.D, { children: null == n2 ? void 0 : n2.shortDescription });
          return (0, r.jsx)(u.O, { infoDescription: e3 });
        });
        return (0, r.jsxs)(r.Fragment, { children: [o2, a2] });
      });
      var R = n(15209), B = n(27604), O = n.n(B);
      let S = (0, a.PA)(() => {
        let { formatMessage: e2 } = (0, l.A)(), { currentTrackInfo: t2 } = (0, i.Pjs)(), n2 = t2.fullTrack, a2 = (0, s.useMemo)(
          () => t2.fullDescription ? (0, r.jsx)("span", {
            className: O().text,
            dangerouslySetInnerHTML: { __html: (0, R.sanitizeDOM)(t2.fullDescription) }
          }) : null == n2 ? void 0 : n2.shortDescription,
          [null == n2 ? void 0 : n2.shortDescription, t2.fullDescription]
        ), o2 = (0, f.L)(() => {
          if (!a2) return;
          let e3 = (0, r.jsx)(u.D, { children: a2 });
          return (0, r.jsx)(u.O, { infoDescription: e3 });
        }), c2 = (0, f.L)(() => {
          var t3, a3, i2;
          if (!(null == n2 || null == (t3 = n2.mainAlbum) ? void 0 : t3.title)) return;
          let o3 = (0, r.jsx)(u.D, {
            href: null == n2 || null == (a3 = n2.mainAlbum) ? void 0 : a3.url,
            children: null == n2 || null == (i2 = n2.mainAlbum) ? void 0 : i2.title
          });
          return (0, r.jsx)(u.O, { title: e2({ id: "entity-names.podcast" }), infoDescription: o3 });
        });
        return (0, r.jsxs)(r.Fragment, { children: [o2, c2] });
      }), I = (0, a.PA)(() => {
        var e2, t2, n2, a2, m2;
        let { formatMessage: p2 } = (0, l.A)(), { notify: x2 } = (0, i.lkh)(), { contentRef: h2 } = (0, i.gKY)(), {
          currentTrackInfo: v2,
          settings: { isMobile: f2, isWindowsApplication: j2, isLinuxApplication: b2 },
          fullscreenPlayer: A2,
          experiments: C2
        } = (0, i.Pjs)(), { modal: g2 } = v2, y2 = v2.isUGC, k2 = C2.checkExperiment(i.zal.WebEditorsFeatures, "on");
        y2 && v2.isTrackIdle && v2.getTrackMeta(), v2.fullTrack || !v2.isTrackIdle || y2 || v2.getFullTrack(), !v2.credits && v2.isCreditsIdle && v2.getCreditsInfo(), ((null == (e2 = v2.fullTrack) ? void 0 : e2.isTrackPodcast) || (null == (n2 = v2.fullTrack) || null == (t2 = n2.mainAlbum) ? void 0 : t2.isPodcast)) && v2.getFullDescription(), (0, s.useEffect)(
          () => () => {
            g2.close(), v2.reset();
          },
          [v2, g2]
        );
        let N2 = (0, s.useCallback)(() => {
          g2.close(), v2.reset();
        }, [v2, g2]), T2 = (0, s.useCallback)(
          (e3) => {
            var t3;
            e3 || v2.reset(), null == (t3 = g2.onOpenChange) || t3.call(g2, e3);
          },
          [v2, g2]
        );
        v2.isRejected && (N2(), x2((0, r.jsx)(_.hT, { error: p2({ id: "error-messages.error-during-action" }) }), {
          containerId: i.uQT.ERROR
        }));
        let L2 = v2.fullTrack, P2 = null == L2 ? void 0 : L2.explicitDisclaimer, w2 = (0, s.useMemo)(() => {
          var e3;
          if (L2)
            return (0, r.jsxs)("span", {
              children: [
                L2.title,
                L2.version && (0, r.jsx)("span", { className: O().version, children: L2.version }),
                P2 && (0, r.jsx)(_.Nq, {
                  className: (0, o.$)(O().explicitMark, O().important, { [O().explicit]: !L2.isTrackNonMusic }),
                  getDescriptionTexts: null == (e3 = v2.fullTrack) ? void 0 : e3.getDescriptionTexts,
                  size: "xxs",
                  variant: P2
                })
              ]
            });
        }, [L2, P2, null == (a2 = v2.fullTrack) ? void 0 : a2.getDescriptionTexts]), D2 = (0, s.useMemo)(() => {
          var e3;
          return (null == L2 ? void 0 : L2.type) === E.S.AUDIOBOOK ? (0, r.jsx)(M, {}) : (null == L2 ? void 0 : L2.isTrackPodcast) || (null == L2 || null == (e3 = L2.mainAlbum) ? void 0 : e3.isPodcast) ? (0, r.jsx)(S, {}) : void 0;
        }, [L2]), R2 = (0, s.useMemo)(() => {
          var e3;
          return (null == (e3 = v2.credits) ? void 0 : e3.length) ? v2.credits.map((e4) => {
            let { title: t3, value: n3 } = e4, a3 = (0, r.jsx)(u.D, { children: n3 });
            return (0, r.jsx)(u.O, { title: t3, infoDescription: a3 }, t3);
          }) : null;
        }, [v2.credits]), B2 = (0, s.useMemo)(() => {
          var e3;
          if ((null == (e3 = v2.fullTrack) ? void 0 : e3.major) && k2) {
            let e4 = v2.fullTrack.major.name;
            if (e4) {
              let t3 = (0, r.jsx)(u.D, { children: e4 });
              return (0, r.jsx)(u.O, { title: "Major", infoDescription: t3 }, e4);
            }
          }
          return null;
        }, [null == (m2 = v2.fullTrack) ? void 0 : m2.major, k2]);
        return (0, r.jsx)(d.a, {
          placement: f2 ? "default" : "right",
          open: g2.isOpened,
          onClose: N2,
          contentClassName: O().modalContent,
          title: w2,
          headerClassName: O().header,
          className: (0, o.$)(O().root, {
            [O().root_withFullscreen]: A2.modal.isOpened,
            [O().root_withCustomControls]: j2 || b2
          }),
          overlayClassName: O().overlay,
          onOpenChange: T2,
          labelClose: p2({ id: "interface-actions.close" }),
          portalNode: f2 || A2.modal.isOpened ? null : h2,
          containerProps: (0, c.Am)(c.Xk.track.TRACK_ABOUT_MODAL),
          closeButtonProps: (0, c.Am)(c.Xk.track.TRACK_ABOUT_MODAL_CLOSE_BUTTON),
          children: (0, r.jsxs)("div", {
            className: O().content,
            children: [
              (v2.isTrackLoading || v2.isTrackRejected) && (0, r.jsx)(_.nN, { textClassName: O().textShimmer }),
              D2,
              (v2.isCreditsLoading || v2.isCreditsRejected) && (0, r.jsx)(_.nN, { textClassName: O().textShimmer }),
              R2,
              B2
            ]
          })
        });
      }), W = (0, a.PA)(() => {
        let {
          settings: { isMobile: e2 }
        } = (0, i.Pjs)();
        return e2 ? null : (0, r.jsx)(I, {});
      });
      var z = n(21365), F = n(67628), V = n.n(F);
      let $ = (0, a.PA)(() => {
        var e2;
        let { formatMessage: t2 } = (0, l.A)(), { notify: n2 } = (0, i.lkh)(), { contentRef: a2 } = (0, i.gKY)(), {
          trackLyrics: u2,
          settings: { isMobile: m2 },
          fullscreenPlayer: p2
        } = (0, i.Pjs)(), { modal: x2, track: h2 } = u2, v2 = null == h2 ? void 0 : h2.explicitDisclaimer;
        (0, s.useEffect)(() => {
          h2 && h2.isLyricsAvailable && u2.modal.isOpened && u2.getLyrics(h2.id);
        }, [h2, u2, u2.modal.isOpened]), (0, s.useEffect)(() => {
          x2.isOpened && h2 && u2.isResolved && u2.sendViews({ trackId: h2.id, albumId: h2.albumId });
        }, [h2, u2, u2.isResolved, x2.isOpened]);
        let f2 = (0, s.useCallback)(
          (e3) => {
            var t3;
            null == (t3 = x2.onOpenChange) || t3.call(x2, e3);
          },
          [x2]
        );
        u2.isRejected && u2.modal.isOpened && n2((0, r.jsx)(_.hT, { error: t2({ id: "error-messages.error-during-action" }) }), { containerId: i.uQT.ERROR });
        let j2 = (0, s.useMemo)(() => {
          if (h2)
            return (0, r.jsxs)("span", {
              ...(0, c.Am)(c.e8.content.TRACK_LYRICS_TITLE),
              children: [
                h2.title,
                h2.version && (0, r.jsx)("span", { className: V().version, children: h2.version }),
                v2 && (0, r.jsx)(_.Nq, {
                  className: (0, o.$)(V().explicitMark, V().important),
                  getDescriptionTexts: h2.getDescriptionTexts,
                  size: "xxs",
                  variant: v2
                })
              ]
            });
        }, [h2, null == h2 ? void 0 : h2.title, null == h2 ? void 0 : h2.version, v2]);
        return (0, r.jsx)(d.a, {
          size: "fitContent",
          placement: m2 ? "default" : "right",
          open: x2.isOpened,
          onOpenChange: f2,
          onClose: x2.close,
          className: V().root,
          contentClassName: V().modalContent,
          portalNode: m2 || p2.modal.isOpened ? null : a2,
          title: j2,
          headerClassName: V().header,
          overlayClassName: V().overlay,
          labelClose: t2({ id: "interface-actions.close" }),
          restoreFocus: true,
          containerProps: (0, c.Am)(c.e8.content.TRACK_LYRICS_MODAL),
          closeButtonProps: (0, c.Am)(c.e8.content.TRACK_LYRICS_CLOSE_BUTTON),
          lockScroll: m2,
          children: (0, r.jsx)("div", {
            className: V().content,
            ...(0, c.Am)(c.e8.content.TRACK_LYRICS_TEXT),
            children: (0, r.jsx)(z.xe, {
              lyrics: u2.lyrics,
              authors: u2.writersNames,
              source: null == (e2 = u2.major) ? void 0 : e2.prettyName,
              isShimmerVisible: u2.isShimmerVisible,
              isShimmerActive: u2.isLoading
            })
          })
        });
      });
    },
    71858: (e) => {
      e.exports = {
        rootOld: "Content_rootOld__g85_m",
        main: "Content_main__8_wIa",
        root: "Content_root__IsH8s",
        sideBanner: "Content_sideBanner__Na07D",
        primary: "Content_primary__dInSS",
        primary_isMobile: "Content_primary_isMobile__ApDi2",
        primary_short: "Content_primary_short__TSM3L",
        adContainer: "Content_adContainer__4t8fj",
        adBanner: "Content_adBanner__hxXvf",
        secondary: "Content_secondary__tGLLS",
        secondary_isMobile: "Content_secondary_isMobile__CbF7M",
        secondaryEnter: "Content_secondaryEnter__Nsp_f",
        secondaryEnterActive: "Content_secondaryEnterActive__Ks_PK",
        secondaryExit: "Content_secondaryExit__m4gOK",
        secondaryExitActive: "Content_secondaryExitActive__miNnR",
        withBrandedBanner: "Content_withBrandedBanner__ipwOK"
      };
    },
    75312: (e, t, n) => {
      "use strict";
      n.d(t, { SomethingWentWrong: () => h });
      var r = n(54486), a = n(50420), i = n(28303), o = n(61910), s = n(43426), l = n(47713), c = n(77881), d = n(5956), u = n(97800), _ = n(74125), m = n(80585), p = n(63708), x = n.n(p);
      let h = (0, i.PA)((e2) => {
        let { className: t2, withBackwardControl: n2 = true } = e2, { formatMessage: i2 } = (0, s.A)(), p2 = i2({ id: "error-messages.something-went-wrong" });
        (0, _.CgZ)(p2);
        let { sendRefreshEvent: h2 } = (0, _.cYT)(), v = (0, o.useCallback)(() => {
          h2(), window.location.href = _.Zyd.main.href;
        }, [h2]), { contentRef: f } = (0, _.gKY)();
        return (0, r.jsxs)("div", {
          className: (0, a.$)(x().root, t2),
          children: [
            n2 && (0, r.jsx)(m.Lh, {
              withBackwardFallback: "/",
              className: (0, a.$)(x().navigation, { [x().navigation_desktop]: !f }),
              withForwardControl: false
            }),
            (0, r.jsxs)("div", {
              className: (0, a.$)(x().content, { [x().content_shrink]: !n2 }),
              children: [
                (0, r.jsx)(d.Icon, { className: x().icon, variant: "attention", size: "xxl" }),
                (0, r.jsx)(u.Heading, {
                  className: (0, a.$)(x().title, x().important),
                  variant: "h3",
                  size: "xs",
                  children: p2
                }),
                (0, r.jsxs)(u.Caption, {
                  className: (0, a.$)(x().text, x().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, r.jsx)(l.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, r.jsx)(c.$, {
                  onClick: v,
                  className: x().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, r.jsxs)(u.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, r.jsx)(l.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    78107: (e) => {
      e.exports = { root: "LayoutNotificationContainers_root__5HClw" };
    },
    82644: (e, t, n) => {
      "use strict";
      n.d(t, { w: () => r.SomethingWentWrong });
      var r = n(75312);
    },
    85237: (e) => {
      e.exports = {
        button: "CrackdownModal_button__IWTpu",
        important: "CrackdownModal_important__eKBtD",
        buttonMainText: "CrackdownModal_buttonMainText__pAlET"
      };
    },
    95369: (e) => {
      e.exports = {
        root: "CommonLayout_root__WC_W1",
        root_withAxeBanner: "CommonLayout_root_withAxeBanner__2_ep2",
        content: "CommonLayout_content__zy_Ja",
        content_withPlayerBar: "CommonLayout_content_withPlayerBar__wTpoS",
        content_withAxeBanner: "CommonLayout_content_withAxeBanner__gmyVS",
        playerBar: "CommonLayout_playerBar__zXRxq",
        compositePlayerBar: "CommonLayout_compositePlayerBar__hjZRp"
      };
    },
    96909: (e, t, n) => {
      "use strict";
      n.d(t, { g: () => y });
      var r = n(54486), a = n(50420), i = n(28303), o = n(61910), s = n(47713), l = n(31500), c = n(8817), d = n(67648), u = n(27510), _ = n(58360), m = n(39610), p = n(97800), x = n(74125), h = n(80585), v = n(97396), f = n(77881), j = n(85237), b = n.n(j);
      let A = (0, i.PA)(() => {
        let {
          modals: { crackdownModal: e2 }
        } = (0, x.Pjs)(), t2 = (0, v.useRouter)(), n2 = (0, x.NFA)().get(x.QGx), i2 = (0, c.c)(() => {
          e2.close(), n2.authorizationUrl && t2.push(n2.authorizationUrl);
        });
        return (0, r.jsx)(f.$, {
          className: (0, a.$)(b().button, b().important),
          variant: "default",
          color: "secondary",
          isBlock: true,
          radius: "xxxl",
          size: "xs",
          onClick: i2,
          ...(0, l.Am)(l.e8.crackdownModal.CRACKDOWN_MODAL_ALREADY_IN_PLUS_BUTTON),
          children: (0, r.jsx)(p.Caption, {
            className: b().buttonMainText,
            variant: "span",
            children: (0, r.jsx)(s.A, { id: "buy-subscription.already-in-plus", values: { nbsp: " " } })
          })
        });
      }), C = "crackdown-buy-subscription-button", g = (0, i.PA)((e2) => {
        let { withAlreadyInPlusButton: t2 } = e2, {
          user: n2,
          modals: { crackdownModal: i2 }
        } = (0, x.Pjs)(), [v2, f2] = (0, d.d)(), [j2, g2] = (0, o.useState)(i2.isOpened), {
          mainText: y2,
          mainTextA11y: k,
          additionText: N,
          isShimmerVisible: T,
          isShimmerActive: L,
          openPaymentWidgetModal: P,
          saveOfferAndAuthorize: w
        } = (0, x.DpZ)({
          storeName: "music",
          isEnabled: j2,
          offerElement: { element: v2, intersectionPropertyId: C }
        }), D = (0, c.c)(() => {
          if (i2.close(), !n2.isAuthorized) return void w();
          P();
        }), E = (0, u.L)(
          () => T ? (0, r.jsx)(h.bb, { className: (0, a.$)(b().button, b().important), isActive: L }) : (0, r.jsxs)(h.mv, {
            className: (0, a.$)(b().button, b().important),
            color: "plus",
            size: "xs",
            ref: f2,
            "data-intersection-property-id": C,
            onClick: D,
            "aria-label": k,
            ...(0, l.Am)(l.e8.crackdownModal.CRACKDOWN_MODAL_SUBSCRIPTION_BUTTON),
            children: [
              (0, r.jsx)(p.Caption, { variant: "div", className: b().buttonMainText, children: y2 }),
              N && (0, r.jsx)(p.Caption, { variant: "div", size: "m", weight: "normal", children: N })
            ]
          })
        );
        return (0, o.useEffect)(() => {
          setTimeout(() => {
            g2(true);
          }, 2500);
        }, []), (0, r.jsxs)(h.cu, {
          open: i2.isOpened,
          onClose: i2.close,
          ...(0, l.Am)(l.e8.crackdownModal.CRACKDOWN_MODAL),
          children: [
            (0, r.jsx)("div", {
              className: h.SE.growContainer,
              ...(0, l.Am)(l.e8.crackdownModal.CRACKDOWN_MODAL_PICTURE),
              children: (0, r.jsx)(_.Image, {
                src: "https://avatars.mds.yandex.net/get-music-misc/70850/img.672491383c0f014022130e5b/orig",
                srcSet: "https://avatars.mds.yandex.net/get-music-misc/2419084/img.6724913d3c0f014022130e5e/orig 2x"
              })
            }),
            (0, r.jsxs)("div", {
              className: h.SE.text,
              "aria-hidden": true,
              children: [
                (0, r.jsx)(p.Heading, {
                  variant: "h1",
                  size: "xl",
                  className: h.SE.title,
                  ...(0, l.Am)(l.e8.crackdownModal.CRACKDOWN_MODAL_TITLE_TEXT),
                  children: (0, r.jsx)(s.A, {
                    id: "crackdown.title",
                    values: { br: (0, r.jsx)("br", {}), nbsp: " " }
                  })
                }),
                (0, r.jsx)(p.Caption, {
                  variant: "span",
                  size: "m",
                  className: h.SE.description,
                  ...(0, l.Am)(l.e8.crackdownModal.CRACKDOWN_MODAL_DESCRIPTION_TEXT),
                  children: (0, r.jsx)(s.A, {
                    id: "crackdown.description",
                    values: { br: (0, r.jsx)("br", {}), nbsp: " " }
                  })
                })
              ]
            }),
            (0, r.jsxs)(m.q, {
              children: [
                (0, r.jsx)(p.Heading, {
                  variant: "h1",
                  children: (0, r.jsx)(s.A, { id: "crackdown.title", values: { br: " ", nbsp: " " } })
                }),
                (0, r.jsx)(p.Caption, {
                  variant: "div",
                  children: (0, r.jsx)(s.A, { id: "crackdown.description", values: { br: " ", nbsp: " " } })
                })
              ]
            }),
            (0, r.jsxs)("div", { className: h.SE.buttons, children: [E, t2 && (0, r.jsx)(A, {})] })
          ]
        });
      });
      g.displayName = "CrackdownModalComponent";
      let y = (e2) => (0, r.jsx)(x.rtM, {
        page: x.l7W.CRACKDOWN_SCREEN,
        places: [x.RBW.TOP_BUTTON],
        children: (0, r.jsx)(g, { ...e2 })
      });
    },
    97151: (e, t, n) => {
      "use strict";
      n.d(t, { XU: () => u });
      var r, a, i = n(41500), o = n(61910), s = n(43426);
      !(function(e2) {
        e2.formatDate = "FormattedDate", e2.formatTime = "FormattedTime", e2.formatNumber = "FormattedNumber", e2.formatList = "FormattedList", e2.formatDisplayName = "FormattedDisplayName";
      })(r || (r = {})), (function(e2) {
        e2.formatDate = "FormattedDateParts", e2.formatTime = "FormattedTimeParts", e2.formatNumber = "FormattedNumberParts", e2.formatList = "FormattedListParts";
      })(a || (a = {}));
      var l = function(e2) {
        var t2 = (0, s.A)(), n2 = e2.value, r2 = e2.children, a2 = (0, i.__rest)(e2, ["value", "children"]);
        return r2(t2.formatNumberToParts(n2, a2));
      };
      function c(e2) {
        var t2 = function(t3) {
          var n2 = (0, s.A)(), r2 = t3.value, a2 = t3.children, o2 = (0, i.__rest)(t3, ["value", "children"]), l2 = "string" == typeof r2 ? new Date(r2 || 0) : r2;
          return a2("formatDate" === e2 ? n2.formatDateToParts(l2, o2) : n2.formatTimeToParts(l2, o2));
        };
        return t2.displayName = a[e2], t2;
      }
      function d(e2) {
        var t2 = function(t3) {
          var n2 = (0, s.A)(), r2 = t3.value, a2 = t3.children, l2 = (0, i.__rest)(t3, ["value", "children"]), c2 = n2[e2](r2, l2);
          if ("function" == typeof a2) return a2(c2);
          var d2 = n2.textComponent || o.Fragment;
          return o.createElement(d2, null, c2);
        };
        return t2.displayName = r[e2], t2;
      }
      l.displayName = "FormattedNumberParts", l.displayName = "FormattedNumberParts";
      var u = d("formatDate");
      d("formatTime"), d("formatNumber"), d("formatList"), d("formatDisplayName"), c("formatDate"), c("formatTime");
    },
    98626: (e) => {
      e.exports = {
        root: "TopAdvertBanner_root__aAZ0o",
        root_hidden: "TopAdvertBanner_root_hidden__l3FTx",
        advert: "TopAdvertBanner_advert__LjAj_"
      };
    },
    99481: (e) => {
      e.exports = {
        root: "PromoLandingLayout_root__nFZZ7",
        playerBar: "PromoLandingLayout_playerBar__7tyD3",
        animatedPlayer_enter: "PromoLandingLayout_animatedPlayer_enter__0MM1u",
        animatedPlayer_enter_active: "PromoLandingLayout_animatedPlayer_enter_active__mEGFp",
        "enter-fade": "PromoLandingLayout_enter-fade__fGSAV",
        "enter-move": "PromoLandingLayout_enter-move__800PQ",
        animatedPlayer_exit: "PromoLandingLayout_animatedPlayer_exit__D9q3r",
        animatedPlayer_exit_active: "PromoLandingLayout_animatedPlayer_exit_active__VnBYL",
        "exit-fade": "PromoLandingLayout_exit-fade__4rLUP",
        "exit-move": "PromoLandingLayout_exit-move__cg_8c"
      };
    }
  }
]);
