"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [722],
  {
    50722: (t, e, r) => {
      r.d(e, { A: () => H });
      var n = r(41500), a = r(31692), o = r(61910), i = r(90310), s = r(73473), l = r(48147), m = r(81959);
      function u(t2, e2) {
        return Object.keys(t2).reduce(function(r2, a2) {
          return r2[a2] = (0, n.__assign)({ timeZone: e2 }, t2[a2]), r2;
        }, {});
      }
      function c(t2, e2) {
        return Object.keys((0, n.__assign)((0, n.__assign)({}, t2), e2)).reduce(function(r2, a2) {
          return r2[a2] = (0, n.__assign)((0, n.__assign)({}, t2[a2] || {}), e2[a2] || {}), r2;
        }, {});
      }
      function f(t2, e2) {
        if (!e2) return t2;
        var r2 = l.S.formats;
        return (0, n.__assign)((0, n.__assign)((0, n.__assign)({}, r2), t2), {
          date: c(u(r2.date, e2), u(t2.date || {}, e2)),
          time: c(u(r2.time, e2), u(t2.time || {}, e2))
        });
      }
      var g = function(t2, e2, r2, o2, i2) {
        var l2 = t2.locale, u2 = t2.formats, c2 = t2.messages, g2 = t2.defaultLocale, d2 = t2.defaultFormats, p2 = t2.fallbackOnEmptyString, y2 = t2.onError, v2 = t2.timeZone, h2 = t2.defaultRichTextElements;
        void 0 === r2 && (r2 = { id: "" });
        var _2 = r2.id, b2 = r2.defaultMessage;
        (0, a.V1)(
          !!_2,
          "[@formatjs/intl] An `id` must be provided to format a message. You can either:\n1. Configure your build toolchain with [babel-plugin-formatjs](https://formatjs.github.io/docs/tooling/babel-plugin)\nor [@formatjs/ts-transformer](https://formatjs.github.io/docs/tooling/ts-transformer) OR\n2. Configure your `eslint` config to include [eslint-plugin-formatjs](https://formatjs.github.io/docs/tooling/linter#enforce-id)\nto autofix this issue"
        );
        var E2 = String(_2), T2 = c2 && Object.prototype.hasOwnProperty.call(c2, E2) && c2[E2];
        if (Array.isArray(T2) && 1 === T2.length && T2[0].type === s.TYPE.literal) return T2[0].value;
        if (!o2 && T2 && "string" == typeof T2 && !h2) return T2.replace(/'\{(.*?)\}'/gi, "{$1}");
        if (o2 = (0, n.__assign)((0, n.__assign)({}, h2), o2 || {}), u2 = f(u2, v2), d2 = f(d2, v2), !T2) {
          if (false === p2 && "" === T2) return T2;
          if ((!b2 || l2 && l2.toLowerCase() !== g2.toLowerCase()) && y2(new m.sb(r2, l2)), b2)
            try {
              var F2 = e2.getMessageFormat(b2, g2, d2, i2);
              return F2.format(o2);
            } catch (t3) {
              return y2(
                new m.Ho(
                  'Error formatting default message for: "'.concat(E2, '", rendering default message verbatim'),
                  l2,
                  r2,
                  t3
                )
              ), "string" == typeof b2 ? b2 : E2;
            }
          return E2;
        }
        try {
          var F2 = e2.getMessageFormat(T2, l2, u2, (0, n.__assign)({ formatters: e2 }, i2 || {}));
          return F2.format(o2);
        } catch (t3) {
          y2(
            new m.Ho(
              'Error formatting message: "'.concat(E2, '", using ').concat(b2 ? "default message" : "id", " as fallback."),
              l2,
              r2,
              t3
            )
          );
        }
        if (b2)
          try {
            var F2 = e2.getMessageFormat(b2, g2, d2, i2);
            return F2.format(o2);
          } catch (t3) {
            y2(
              new m.Ho(
                'Error formatting the default message for: "'.concat(E2, '", rendering message verbatim'),
                l2,
                r2,
                t3
              )
            );
          }
        return "string" == typeof T2 ? T2 : "string" == typeof b2 ? b2 : E2;
      }, d = [
        "formatMatcher",
        "timeZone",
        "hour12",
        "weekday",
        "era",
        "year",
        "month",
        "day",
        "hour",
        "minute",
        "second",
        "timeZoneName",
        "hourCycle",
        "dateStyle",
        "timeStyle",
        "calendar",
        "numberingSystem",
        "fractionalSecondDigits"
      ];
      function p(t2, e2, r2, o2) {
        var i2 = t2.locale, s2 = t2.formats, l2 = t2.onError, m2 = t2.timeZone;
        void 0 === o2 && (o2 = {});
        var u2 = o2.format, c2 = (0, n.__assign)((0, n.__assign)({}, m2 && { timeZone: m2 }), u2 && (0, a.F3)(s2, e2, u2, l2)), f2 = (0, a.J9)(o2, d, c2);
        return "time" !== e2 || f2.hour || f2.minute || f2.second || f2.timeStyle || f2.dateStyle || (f2 = (0, n.__assign)((0, n.__assign)({}, f2), { hour: "numeric", minute: "numeric" })), r2(i2, f2);
      }
      function y(t2, e2) {
        for (var r2 = [], n2 = 2; n2 < arguments.length; n2++) r2[n2 - 2] = arguments[n2];
        var a2 = r2[0], o2 = r2[1], i2 = "string" == typeof a2 ? new Date(a2 || 0) : a2;
        try {
          return p(t2, "date", e2, void 0 === o2 ? {} : o2).format(i2);
        } catch (e3) {
          t2.onError(new m.pg("Error formatting date.", t2.locale, e3));
        }
        return String(i2);
      }
      function v(t2, e2) {
        for (var r2 = [], n2 = 2; n2 < arguments.length; n2++) r2[n2 - 2] = arguments[n2];
        var a2 = r2[0], o2 = r2[1], i2 = "string" == typeof a2 ? new Date(a2 || 0) : a2;
        try {
          return p(t2, "time", e2, void 0 === o2 ? {} : o2).format(i2);
        } catch (e3) {
          t2.onError(new m.pg("Error formatting time.", t2.locale, e3));
        }
        return String(i2);
      }
      function h(t2, e2) {
        for (var r2 = [], n2 = 2; n2 < arguments.length; n2++) r2[n2 - 2] = arguments[n2];
        var a2 = r2[0], o2 = r2[1], i2 = r2[2], s2 = "string" == typeof a2 ? new Date(a2 || 0) : a2, l2 = "string" == typeof o2 ? new Date(o2 || 0) : o2;
        try {
          return p(t2, "dateTimeRange", e2, void 0 === i2 ? {} : i2).formatRange(s2, l2);
        } catch (e3) {
          t2.onError(new m.pg("Error formatting date time range.", t2.locale, e3));
        }
        return String(s2);
      }
      function _(t2, e2) {
        for (var r2 = [], n2 = 2; n2 < arguments.length; n2++) r2[n2 - 2] = arguments[n2];
        var a2 = r2[0], o2 = r2[1], i2 = "string" == typeof a2 ? new Date(a2 || 0) : a2;
        try {
          return p(t2, "date", e2, void 0 === o2 ? {} : o2).formatToParts(i2);
        } catch (e3) {
          t2.onError(new m.pg("Error formatting date.", t2.locale, e3));
        }
        return [];
      }
      function b(t2, e2) {
        for (var r2 = [], n2 = 2; n2 < arguments.length; n2++) r2[n2 - 2] = arguments[n2];
        var a2 = r2[0], o2 = r2[1], i2 = "string" == typeof a2 ? new Date(a2 || 0) : a2;
        try {
          return p(t2, "time", e2, void 0 === o2 ? {} : o2).formatToParts(i2);
        } catch (e3) {
          t2.onError(new m.pg("Error formatting time.", t2.locale, e3));
        }
        return [];
      }
      var E = r(93470), T = ["style", "type", "fallback", "languageDisplay"];
      function F(t2, e2, r2, n2) {
        var o2 = t2.locale, i2 = t2.onError;
        Intl.DisplayNames || i2(
          new E.IF(
            'Intl.DisplayNames is not available in this environment.\nTry polyfilling it using "@formatjs/intl-displaynames"\n',
            E.O4.MISSING_INTL_API
          )
        );
        var s2 = (0, a.J9)(n2, T);
        try {
          return e2(o2, s2).of(r2);
        } catch (t3) {
          i2(new m.pg("Error formatting display name.", o2, t3));
        }
      }
      var w = ["type", "style"], I = Date.now();
      function S(t2, e2, r2, n2) {
        void 0 === n2 && (n2 = {});
        var a2 = D(t2, e2, r2, n2).reduce(function(t3, e3) {
          var r3 = e3.value;
          return "string" != typeof r3 ? t3.push(r3) : "string" == typeof t3[t3.length - 1] ? t3[t3.length - 1] += r3 : t3.push(r3), t3;
        }, []);
        return 1 === a2.length ? a2[0] : 0 === a2.length ? "" : a2;
      }
      function D(t2, e2, r2, o2) {
        var i2 = t2.locale, s2 = t2.onError;
        void 0 === o2 && (o2 = {}), Intl.ListFormat || s2(
          new E.IF(
            'Intl.ListFormat is not available in this environment.\nTry polyfilling it using "@formatjs/intl-listformat"\n',
            E.O4.MISSING_INTL_API
          )
        );
        var l2 = (0, a.J9)(o2, w);
        try {
          var u2 = {}, c2 = r2.map(function(t3, e3) {
            if ("object" == typeof t3) {
              var r3 = "".concat(I, "_").concat(e3, "_").concat(I);
              return u2[r3] = t3, r3;
            }
            return String(t3);
          });
          return e2(i2, l2).formatToParts(c2).map(function(t3) {
            return "literal" === t3.type ? t3 : (0, n.__assign)((0, n.__assign)({}, t3), { value: u2[t3.value] || t3.value });
          });
        } catch (t3) {
          s2(new m.pg("Error formatting list.", i2, t3));
        }
        return r2;
      }
      var P = [
        "style",
        "currency",
        "unit",
        "unitDisplay",
        "useGrouping",
        "minimumIntegerDigits",
        "minimumFractionDigits",
        "maximumFractionDigits",
        "minimumSignificantDigits",
        "maximumSignificantDigits",
        "compactDisplay",
        "currencyDisplay",
        "currencySign",
        "notation",
        "signDisplay",
        "unit",
        "unitDisplay",
        "numberingSystem",
        "trailingZeroDisplay",
        "roundingPriority",
        "roundingIncrement",
        "roundingMode"
      ];
      function j(t2, e2, r2) {
        var n2 = t2.locale, o2 = t2.formats, i2 = t2.onError;
        void 0 === r2 && (r2 = {});
        var s2 = r2.format, l2 = s2 && (0, a.F3)(o2, "number", s2, i2) || {};
        return e2(n2, (0, a.J9)(r2, P, l2));
      }
      function N(t2, e2, r2, n2) {
        void 0 === n2 && (n2 = {});
        try {
          return j(t2, e2, n2).format(r2);
        } catch (e3) {
          t2.onError(new m.pg("Error formatting number.", t2.locale, e3));
        }
        return String(r2);
      }
      function R(t2, e2, r2, n2) {
        void 0 === n2 && (n2 = {});
        try {
          return j(t2, e2, n2).formatToParts(r2);
        } catch (e3) {
          t2.onError(new m.pg("Error formatting number.", t2.locale, e3));
        }
        return [];
      }
      var k = ["type"];
      function L(t2, e2, r2, n2) {
        var o2 = t2.locale, i2 = t2.onError;
        void 0 === n2 && (n2 = {}), Intl.PluralRules || i2(
          new E.IF(
            'Intl.PluralRules is not available in this environment.\nTry polyfilling it using "@formatjs/intl-pluralrules"\n',
            E.O4.MISSING_INTL_API
          )
        );
        var s2 = (0, a.J9)(n2, k);
        try {
          return e2(o2, s2).select(r2);
        } catch (t3) {
          i2(new m.pg("Error formatting plural.", o2, t3));
        }
        return "other";
      }
      var O = ["numeric", "style"];
      function x(t2, e2, r2, n2, o2) {
        void 0 === o2 && (o2 = {}), n2 || (n2 = "second"), Intl.RelativeTimeFormat || t2.onError(
          new E.IF(
            'Intl.RelativeTimeFormat is not available in this environment.\nTry polyfilling it using "@formatjs/intl-relativetimeformat"\n',
            E.O4.MISSING_INTL_API
          )
        );
        try {
          var i2, s2, l2, u2, c2, f2;
          return (i2 = o2, s2 = t2.locale, l2 = t2.formats, u2 = t2.onError, void 0 === i2 && (i2 = {}), f2 = !!(c2 = i2.format) && (0, a.F3)(l2, "relative", c2, u2) || {}, e2(s2, (0, a.J9)(i2, O, f2))).format(r2, n2);
        } catch (e3) {
          t2.onError(new m.pg("Error formatting relative time.", t2.locale, e3));
        }
        return String(r2);
      }
      var M = r(5075);
      function C(t2) {
        return t2 ? Object.keys(t2).reduce(function(e2, r2) {
          var n2 = t2[r2];
          return e2[r2] = (0, M.RK)(n2) ? (0, i.yU)(n2) : n2, e2;
        }, {}) : t2;
      }
      var A = function(t2, e2, r2, a2) {
        for (var o2 = [], s2 = 4; s2 < arguments.length; s2++) o2[s2 - 4] = arguments[s2];
        var l2 = C(a2), m2 = g.apply(void 0, (0, n.__spreadArray)([t2, e2, r2, l2], o2, false));
        return Array.isArray(m2) ? (0, i.SP)(m2) : m2;
      }, Z = function(t2, e2) {
        var r2, o2, s2, l2, u2, c2, f2, d2 = t2.defaultRichTextElements, p2 = (0, n.__rest)(t2, ["defaultRichTextElements"]), E2 = C(d2), T2 = (r2 = (0, n.__assign)((0, n.__assign)((0, n.__assign)({}, i.JF), p2), { defaultRichTextElements: E2 }), o2 = (0, a.GT)(e2), l2 = (s2 = (0, n.__assign)((0, n.__assign)({}, a.JF), r2)).locale, u2 = s2.defaultLocale, c2 = s2.onError, l2 ? !Intl.NumberFormat.supportedLocalesOf(l2).length && c2 ? c2(
          new m.hr(
            'Missing locale data for locale: "'.concat(l2, '" in Intl.NumberFormat. Using default locale: "').concat(
              u2,
              '" as fallback. See https://formatjs.github.io/docs/react-intl#runtime-requirements for more details'
            )
          )
        ) : !Intl.DateTimeFormat.supportedLocalesOf(l2).length && c2 && c2(
          new m.hr(
            'Missing locale data for locale: "'.concat(l2, '" in Intl.DateTimeFormat. Using default locale: "').concat(
              u2,
              '" as fallback. See https://formatjs.github.io/docs/react-intl#runtime-requirements for more details'
            )
          )
        ) : (c2 && c2(
          new m.uo(
            '"locale" was not configured, using "'.concat(
              u2,
              '" as fallback. See https://formatjs.github.io/docs/react-intl/api#intlshape for more details'
            )
          )
        ), s2.locale = s2.defaultLocale || "en"), s2.onWarn && s2.defaultRichTextElements && "string" == typeof (f2 = s2.messages || {})[Object.keys(f2)[0]] && s2.onWarn(
          '[@formatjs/intl] "defaultRichTextElements" was specified but "message" was not pre-compiled. \nPlease consider using "@formatjs/cli" to pre-compile your messages for performance.\nFor more details see https://formatjs.github.io/docs/getting-started/message-distribution'
        ), (0, n.__assign)((0, n.__assign)({}, s2), {
          formatters: o2,
          formatNumber: N.bind(null, s2, o2.getNumberFormat),
          formatNumberToParts: R.bind(null, s2, o2.getNumberFormat),
          formatRelativeTime: x.bind(null, s2, o2.getRelativeTimeFormat),
          formatDate: y.bind(null, s2, o2.getDateTimeFormat),
          formatDateToParts: _.bind(null, s2, o2.getDateTimeFormat),
          formatTime: v.bind(null, s2, o2.getDateTimeFormat),
          formatDateTimeRange: h.bind(null, s2, o2.getDateTimeFormat),
          formatTimeToParts: b.bind(null, s2, o2.getDateTimeFormat),
          formatPlural: L.bind(null, s2, o2.getPluralRules),
          formatMessage: g.bind(null, s2, o2),
          $t: g.bind(null, s2, o2),
          formatList: S.bind(null, s2, o2.getListFormat),
          formatListToParts: D.bind(null, s2, o2.getListFormat),
          formatDisplayName: F.bind(null, s2, o2.getDisplayNames)
        })), w2 = {
          locale: T2.locale,
          timeZone: T2.timeZone,
          fallbackOnEmptyString: T2.fallbackOnEmptyString,
          formats: T2.formats,
          defaultLocale: T2.defaultLocale,
          defaultFormats: T2.defaultFormats,
          messages: T2.messages,
          onError: T2.onError,
          defaultRichTextElements: E2
        };
        return (0, n.__assign)((0, n.__assign)({}, T2), {
          formatMessage: A.bind(null, w2, T2.formatters),
          $t: A.bind(null, w2, T2.formatters)
        });
      }, J = r(28568);
      function G(t2) {
        return {
          locale: t2.locale,
          timeZone: t2.timeZone,
          fallbackOnEmptyString: t2.fallbackOnEmptyString,
          formats: t2.formats,
          textComponent: t2.textComponent,
          messages: t2.messages,
          defaultLocale: t2.defaultLocale,
          defaultFormats: t2.defaultFormats,
          onError: t2.onError,
          onWarn: t2.onWarn,
          wrapRichTextChunksInFragment: t2.wrapRichTextChunksInFragment,
          defaultRichTextElements: t2.defaultRichTextElements
        };
      }
      let H = (function(t2) {
        function e2() {
          var e3 = null !== t2 && t2.apply(this, arguments) || this;
          return e3.cache = (0, a.MT)(), e3.state = { cache: e3.cache, intl: Z(G(e3.props), e3.cache), prevConfig: G(e3.props) }, e3;
        }
        return (0, n.__extends)(e2, t2), e2.getDerivedStateFromProps = function(t3, e3) {
          var r2 = e3.prevConfig, n2 = e3.cache, a2 = G(t3);
          return (0, i.bN)(r2, a2) ? null : { intl: Z(a2, n2), prevConfig: a2 };
        }, e2.prototype.render = function() {
          return (0, i.HM)(this.state.intl), o.createElement(J.Kq, { value: this.state.intl }, this.props.children);
        }, e2.displayName = "IntlProvider", e2.defaultProps = i.JF, e2;
      })(o.PureComponent);
    }
  }
]);
