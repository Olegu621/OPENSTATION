(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7363],
  {
    2576: (e, t, a) => {
      "use strict";
      a.d(t, { W: () => n });
      var i = a(74125);
      let n = (e2) => {
        let { albumId: t2, deprecationTargetAlbumId: a2, trackId: n2, realId: l, searchParams: s } = e2, o = Number(t2), r = new URLSearchParams(s);
        r.delete("albumId"), r.delete("trackId");
        let d = Object.fromEntries(r);
        if ("number" == typeof a2 && a2 !== o) {
          if (n2) {
            let { href: e4 } = (0, i.uvd)("/album/:albumId/track/:trackId", {
              params: { albumId: a2, trackId: n2 },
              query: d
            });
            return { deprecationUrl: e4, shouldRedirect: true };
          }
          let { href: e3 } = (0, i.uvd)("/album/:albumId", { params: { albumId: a2 }, query: d });
          return { deprecationUrl: e3, shouldRedirect: true };
        }
        if (n2 && l && l !== n2) {
          let { href: e3 } = (0, i.uvd)("/album/:albumId/track/:trackId", {
            params: { albumId: t2, trackId: l },
            query: d
          });
          return { deprecationUrl: e3, shouldRedirect: true };
        }
        return { deprecationUrl: "", shouldRedirect: false };
      };
    },
    8593: (e, t, a) => {
      "use strict";
      a.d(t, { ro: () => b.LastEpisodes, ZM: () => p.RelatedContent, N3: () => l, PX: () => m });
      var i = a(93064), n = a(94376);
      let l = i.gK.model("RelatedContentItem", {
        id: i.gK.string,
        type: i.gK.string,
        title: i.gK.string,
        albums: i.gK.array(n.JC)
      });
      var s = a(8075), o = a(21365), r = a(46423), d = a(26433);
      let u = i.gK.compose(
        i.gK.model("VolumeItemTrack", {
          type: i.gK.maybe(i.gK.enumeration(Object.values(s.S))),
          id: i.gK.union(i.gK.string, i.gK.number),
          data: i.gK.maybeNull(o.vj),
          position: i.gK.maybe(i.gK.number),
          positionInContext: i.gK.number,
          isBest: i.gK.maybe(i.gK.boolean),
          hasEverFinished: i.gK.maybe(i.gK.boolean)
        }),
        d.XT
      ).actions((e2) => ({
        updateEverFinished: (t2) => {
          e2.hasEverFinished = t2;
        }
      })).named("VolumeItemTrack"), c = i.gK.compose(
        i.gK.model("VolumeItemText", { type: i.gK.literal(r.rU.TEXT), data: i.gK.maybeNull(i.gK.number) }),
        d.XT
      ), m = i.gK.union(c, u);
      var b = a(32928), p = a(80453);
    },
    9897: (e) => {
      e.exports = { popover: "AlbumDonationMenu_popover__Fswfa" };
    },
    10612: (e, t, a) => {
      "use strict";
      a.d(t, { F: () => m });
      var i = a(54486), n = a(28303), l = a(61910), s = a(31500), o = a(67648), r = a(77516), d = a(26273), u = a.n(d);
      let c = (e2) => {
        let { item: t2, itemContentCallback: a2, resizeObserver: n2, scrollMargin: s2 } = e2, [r2, d2] = (0, o.d)();
        (0, l.useEffect)(
          () => (r2 && n2 && n2.observe(r2), () => {
            r2 && n2 && n2.unobserve(r2);
          }),
          [r2, n2]
        );
        let c2 = { transform: "translate3d(0, ".concat(t2.start - s2, "px, 0)") };
        return (0, i.jsx)(
          "div",
          { "data-index": t2.index, className: u().virtualItem, ref: d2, style: c2, children: a2(t2.index) },
          t2.key
        );
      }, m = (0, n.PA)((e2) => {
        let { count: t2, getDataByRange: a2, itemContentCallback: n2, role: d2 = "region", ariaLabel: m2 } = e2, [b, p] = (0, o.d)(), { virtualizer: g, resizeObserver: v } = (0, r.rA)({ count: t2, getEstimateSize: () => 56, containerRef: b });
        (0, l.useEffect)(() => {
          !g.isScrolling && g.range && a2(g.range);
        }, [a2, g.isScrolling, g.range]);
        let h = g.getTotalSize(), x = g.getVirtualItems();
        return (0, i.jsx)("div", {
          className: u().virtualScroll,
          style: { height: "".concat(h, "px") },
          ref: p,
          role: d2,
          "aria-label": m2,
          ...(0, s.Am)(s.S7.TRACK_LIST, true),
          children: x.map(
            (e3) => (0, i.jsx)(
              c,
              { item: e3, itemContentCallback: n2, resizeObserver: v, scrollMargin: g.options.scrollMargin },
              e3.key
            )
          )
        });
      });
    },
    17930: (e, t, a) => {
      "use strict";
      a.d(t, { j: () => j });
      var i = a(54486), n = a(43426), l = a(8075), s = a(46423), o = a(74125), r = a(50420), d = a(80585), u = (function(e2) {
        return e2.TRACK = "TRACK", e2.TEXT = "TEXT", e2;
      })({}), c = a(22905), m = a.n(c);
      let b = (e2) => {
        let { shimmerVariant: t2, trackVariant: a2 = o.Xjt.ALBUM } = e2;
        switch (t2) {
          case u.TRACK:
            return (0, i.jsx)(d.DS, {
              isActive: true,
              className: (0, r.$)({ [m().root]: a2 === o.Xjt.ALBUM }),
              variant: a2
            });
          case u.TEXT:
            return (0, i.jsx)(d.nN, { className: m().root });
        }
      };
      var p = a(97800), g = a(26273), v = a.n(g), h = a(27073), x = a.n(h);
      let A = (e2) => {
        let { text: t2 } = e2;
        return (0, i.jsx)("div", {
          className: x().root,
          children: (0, i.jsx)(p.Heading, { variant: "h2", className: v().text, children: t2 })
        });
      }, j = (e2) => {
        let { element: t2, isNonMusic: a2, album: r2 } = e2, { formatMessage: d2 } = (0, n.A)();
        return (e3) => {
          var n2;
          let c2 = null == r2 || null == (n2 = r2.items) ? void 0 : n2[e3];
          if (!c2 || !r2.meta || r2.isRejected || !((e4) => !!e4 && "object" == typeof e4 && ("type" in e4 && e4.type === s.rU.TEXT || "id" in e4 && "positionInContext" in e4))(c2))
            return (0, i.jsx)(b, { shimmerVariant: u.TRACK, trackVariant: o.Xjt.ALBUM });
          if (!c2.data && !c2.isRejected)
            switch (c2.type) {
              case s.rU.TEXT:
                return (0, i.jsx)(b, { shimmerVariant: u.TEXT });
              case l.S.TRACK:
                return (0, i.jsx)(b, { shimmerVariant: u.TRACK, trackVariant: o.Xjt.ALBUM });
              default:
                if (a2) return (0, i.jsx)(b, { shimmerVariant: u.TRACK, trackVariant: o.Xjt.PLAYLIST });
            }
          return c2.type !== s.rU.TEXT ? t2(c2, e3) : a2 ? (0, i.jsx)(A, { text: d2({ id: "entity-names.season-number" }, { number: c2.data }) }) : (0, i.jsx)(A, { text: d2({ id: "entity-names.disk-number" }, { number: c2.data }) });
        };
      };
    },
    22905: (e) => {
      e.exports = { root: "Shimmer_root__NvUMY" };
    },
    23970: (e) => {
      e.exports = {
        header: "PromoLandingAlbumPageContent_header__olZnY",
        advert: "PromoLandingAlbumPageContent_advert__V34EQ",
        footerContainer: "PromoLandingAlbumPageContent_footerContainer__QiHrX",
        footer: "PromoLandingAlbumPageContent_footer__ICBBF",
        contentBlocks: "PromoLandingAlbumPageContent_contentBlocks__b18_R",
        donationBanner: "PromoLandingAlbumPageContent_donationBanner__gvkEC",
        donationBannerTitle: "PromoLandingAlbumPageContent_donationBannerTitle__FS9IZ",
        concertsBlockHeader: "PromoLandingAlbumPageContent_concertsBlockHeader__RRhNC",
        concertsBlockContainer: "PromoLandingAlbumPageContent_concertsBlockContainer__onkAq"
      };
    },
    25326: (e, t, a) => {
      "use strict";
      a.d(t, { k: () => l, n: () => n });
      var i = a(54672);
      let n = [i.O.ABOUT, i.O.TRACKS], l = 10;
    },
    26273: (e) => {
      e.exports = {
        root: "CommonAlbumPage_root__E8c_3",
        content: "CommonAlbumPage_content__vRSnu",
        scrollContent: "CommonAlbumPage_scrollContent__0XS83",
        header: "CommonAlbumPage_header__jS_be",
        text: "CommonAlbumPage_text__kqBSb",
        footerContainer: "CommonAlbumPage_footerContainer__JvjKN",
        footer: "CommonAlbumPage_footer__dBXP4",
        averageColorBackground: "CommonAlbumPage_averageColorBackground__hs1_3",
        virtualScroll: "CommonAlbumPage_virtualScroll__Sc_gs",
        virtualItem: "CommonAlbumPage_virtualItem__yhvPB",
        label: "CommonAlbumPage_label__TErtx",
        important: "CommonAlbumPage_important__GXaZH",
        labelLink: "CommonAlbumPage_labelLink__v4EnM"
      };
    },
    26478: (e, t, a) => {
      "use strict";
      a.d(t, { c: () => s });
      var i = a(61910), n = a(8075), l = a(74125);
      let s = (e2) => {
        let { album: t2 } = e2;
        return (0, i.useCallback)(
          (e3) => {
            let a2 = [];
            for (let i2 = e3.startIndex; i2 <= e3.endIndex; i2++) {
              let e4 = t2.items[i2];
              (null == e4 ? void 0 : e4.type) === n.S.TRACK && (null == e4 ? void 0 : e4.loadingState) === l.GuX.IDLE && a2.push(e4.id);
            }
            a2.length && t2.getTracks({ trackIds: a2 });
          },
          [t2]
        );
      };
    },
    27073: (e) => {
      e.exports = { root: "TextVolume_root__wxSaK" };
    },
    32600: (e) => {
      e.exports = {
        tabCarousel: "NonMusicContent_tabCarousel__EBHWC",
        tab: "NonMusicContent_tab__LIh_U",
        contentAbout: "NonMusicContent_contentAbout__BMIP5",
        infoBlock: "NonMusicContent_infoBlock__IyjXA",
        infoTitle: "NonMusicContent_infoTitle__Wf9EC",
        lastEpisodes: "NonMusicContent_lastEpisodes__Xa8Xp",
        rewindControl: "NonMusicContent_rewindControl__7tncY",
        label: "NonMusicContent_label__9GlIS"
      };
    },
    32928: (e, t, a) => {
      "use strict";
      a.d(t, { LastEpisodes: () => p });
      var i = a(54486), n = a(50420), l = a(28303), s = a(61910), o = a(43426), r = a(63585), d = a(21365), u = a(74125), c = a(80585), m = a(51778), b = a.n(m);
      let p = (0, l.PA)((e2) => {
        let { className: t2, headingVariant: a2 = "h2" } = e2, { formatMessage: l2 } = (0, o.A)(), { album: m2, sonataState: p2 } = (0, u.Pjs)(), { from: g, utmLink: v } = (0, u.fyy)({
          pageId: u._Q$.PODCAST,
          blockId: u.UfI.PODCAST,
          contextId: m2.id,
          contextType: r.K.Album
        }), h = (0, s.useMemo)(
          () => m2.lastEpisodes.map(
            (e3, t3) => m2.isResolved && e3.data ? (0, i.jsx)(
              d.Kd,
              {
                track: e3.data,
                playContextParams: {
                  contextData: { type: r.K.Album, meta: m2.contextMeta, from: g, utmLink: v },
                  queueParams: { index: e3.positionInContext, entityId: e3.data.id },
                  loadContextMeta: true,
                  entitiesData: p2.unloadedEntitiesDataFromModels
                }
              },
              e3.data.id
            ) : (0, i.jsx)(c.DS, { isActive: true, className: b().shimmerItem, variant: u.Xjt.ALBUM }, t3)
          ),
          [m2.lastEpisodes, m2.isResolved, m2.contextMeta, g, v, p2.unloadedEntitiesDataFromModels]
        );
        return (0, i.jsxs)("div", {
          className: (0, n.$)(t2, b().root),
          children: [
            (0, i.jsx)(c.Tw, {
              headingVariant: a2,
              className: b().blockHeader,
              title: l2({ id: "entity-names.podcast-last-episodes" })
            }),
            (0, i.jsx)("div", {
              role: "list",
              "aria-label": l2({ id: "podcast.last-episodes-list" }),
              tabIndex: 0,
              children: h
            })
          ]
        });
      });
    },
    38981: (e) => {
      e.exports = { averageColorBackground: "PromoLandingAlbumPage_averageColorBackground__QcQaQ" };
    },
    40238: (e) => {
      e.exports = {
        root: "AlbumDonationMenuItem_root__Ajw_w",
        cover: "AlbumDonationMenuItem_cover__Gg8_a",
        image: "AlbumDonationMenuItem_image__AI5zU"
      };
    },
    44820: (e) => {
      e.exports = {
        root: "PromoLandingExternalStreamings_root___QUMo",
        title: "PromoLandingExternalStreamings_title__v6E19",
        list: "PromoLandingExternalStreamings_list__zNDey"
      };
    },
    51778: (e) => {
      e.exports = {
        root: "LastEpisodes_root__4JPKj",
        blockHeader: "LastEpisodes_blockHeader__se7bd",
        shimmerItem: "LastEpisodes_shimmerItem__Iirx5"
      };
    },
    53936: (e, t, a) => {
      "use strict";
      a.d(t, { AlbumPage: () => em });
      var i = a(54486), n = a(28303), l = a(97396), s = a(61910), o = a(31500), r = a(27510), d = a(85284), u = a(84262), c = a(94376), m = a(33276), b = a(46423), p = a(74125), g = a(80585), v = a(2576), h = a(56053), x = a(76048), A = a(26273), j = a.n(A), C = a(50420), _ = a(43426), k = a(43350), f = a(63585), I = a(89461), T = a(4542), N = a(32353), y = a(7981), P = a(21365), L = a(25326), O = a(26478), S = a(17930), E = a(8817);
      let B = (0, n.PA)((e2) => {
        let { url: t2 } = e2, a2 = (0, y.cg)(), n2 = (0, y.CC)(), { ref: l2, intersectionPropertyId: s2 } = (0, p.nMI)({ callback: n2, withViewUuid: true }), o2 = (0, p.ZpR)(t2), r2 = (0, E.c)((e3) => {
          a2(k.QT.Link, t2), o2(e3);
        });
        return (0, i.jsx)(y.vK, { onClick: r2, ref: l2, "data-intersection-property-id": s2 });
      });
      var R = a(63695);
      let M = (0, n.PA)((e2) => {
        let { donation: t2 } = e2, a2 = (0, y.cg)(), n2 = (0, y.CC)(), l2 = (0, y.Q$)()(t2.url), { ref: s2, intersectionPropertyId: o2 } = (0, p.nMI)({ callback: n2, withViewUuid: true }), r2 = (0, p.ZpR)(l2), d2 = (0, p.ZpR)(t2.artist.url), u2 = (0, E.c)((e3) => {
          a2(k.QT.ArtistScreen), d2(e3);
        }), c2 = (0, E.c)(() => {
          a2(k.QT.Link, l2), r2();
        }), m2 = (0, R.SA)({ artist: t2.artist, callback: u2 });
        return (0, i.jsx)(y.Xx, {
          ref: s2,
          "data-intersection-property-id": o2,
          artist: t2.artist,
          goal: t2.goal,
          onNavigateToArtist: m2,
          onNavigateToDonation: c2
        });
      }), D = (0, n.PA)((e2) => {
        var t2, a2, n2;
        let { className: l2, headerClassName: o2, containerClassName: r2, headingVariant: d2 } = e2, { formatMessage: u2 } = (0, _.A)(), { album: c2 } = (0, p.Pjs)(), m2 = (0, s.useMemo)(() => {
          var e3, t3;
          return (null == (e3 = c2.donations) ? void 0 : e3.isLoading) || !(null == (t3 = c2.donations) ? void 0 : t3.items) ? (0, y.kZ)(true) : c2.donations.items.map((e4, t4) => {
            var a3, n3, l3;
            return (0, i.jsx)(
              p.Bki,
              {
                objectType: k.ky.Donation,
                objectId: e4.artist.id,
                objectPosX: t4 + 1,
                objectPosY: 1,
                objectsCount: Number(null == (n3 = c2.donations) || null == (a3 = n3.items) ? void 0 : a3.length),
                mainObjectId: String(null == (l3 = c2.meta) ? void 0 : l3.id),
                mainObjectType: k.ky.Album,
                children: (0, i.jsx)(M, { donation: e4 }, e4.artist.id)
              },
              e4.artist.id
            );
          });
        }, [
          null == (t2 = c2.donations) ? void 0 : t2.isLoading,
          null == (a2 = c2.donations) ? void 0 : a2.items,
          null == (n2 = c2.meta) ? void 0 : n2.id
        ]);
        return (0, i.jsx)(y.x0, {
          className: l2,
          headerClassName: o2,
          containerClassName: r2,
          title: u2({ id: "donation.support-text" }),
          headingVariant: d2,
          children: m2
        });
      });
      var U = a(5956), K = a(61958), w = a(9348), F = a(62395), X = a(9897), V = a.n(X), z = a(58360), H = a(6971), Y = a(97800), Q = a(40238), $ = a.n(Q);
      let Z = (0, n.PA)((e2) => {
        let { donation: t2 } = e2, a2 = (0, y.Q$)()(t2.url), n2 = (0, p.ZpR)(a2), l2 = (() => {
          let { hash: e3 } = (0, F.gf)(), t3 = (0, p.UlF)(), a3 = (0, F.st)(), { pageId: i2 } = (0, p.$au)(), { blockId: n3, blockType: l3, blockPosX: s3, blockPosY: o3 } = (0, p.N8n)(), {
            objectType: r3,
            objectId: d3,
            objectPosX: u2,
            objectPosY: c2,
            objectsCount: m2,
            mainObjectId: b2,
            mainObjectType: g2
          } = (0, p.Jfv)();
          return (0, E.c)(() => {
            if (!a3 || !i2) return;
            let v2 = p.Wft[i2];
            if (!v2) return;
            let h2 = {
              userInteractionType: k.gi.Tap,
              hash: e3,
              pageId: v2,
              pageStyle: k.QL.ContextMenu,
              pagePlacement: k.c4.Hover,
              mainObjectType: g2,
              mainObjectId: b2,
              objectType: r3,
              objectId: d3,
              objectPosX: u2,
              objectPosY: c2,
              entityType: l3,
              entityId: n3,
              entityPosX: s3,
              entityPosY: o3,
              objectsCount: m2,
              actionType: k.N6.CLICK
            }, x2 = (0, k.Fx)({ params: h2, logger: t3, context: "useSendEventOnDonationMenuItemActionPerformed" });
            x2 && (0, k.l6)(a3.evgenInstance, x2);
          });
        })(), s2 = (0, y.CC)(), { ref: o2, intersectionPropertyId: r2 } = (0, p.nMI)({ callback: s2, withViewUuid: true }), d2 = (0, E.c)(() => {
          l2(), n2();
        });
        return (0, i.jsxs)(
          K.Dr,
          {
            ref: o2,
            "data-intersection-property-id": r2,
            className: $().root,
            isBlock: true,
            onClick: d2,
            children: [
              (0, i.jsx)(H.Paper, {
                radius: "round",
                className: $().cover,
                children: (0, i.jsx)(z.Image, {
                  withAvatarReplace: true,
                  src: t2.artist.coverUri,
                  size: 100,
                  fit: "contain",
                  className: $().image
                })
              }),
              (0, i.jsx)(Y.Caption, {
                variant: "span",
                size: "m",
                weight: "medium",
                lineClamp: 1,
                children: t2.artist.name
              })
            ]
          },
          a2
        );
      }), G = (0, n.PA)(() => {
        var e2;
        let {
          settings: { isMobile: t2 },
          album: { donations: a2, meta: n2 }
        } = (0, p.Pjs)(), { formatMessage: l2 } = (0, _.A)(), o2 = (() => {
          let e3 = (0, F.st)(), t3 = (0, p.UlF)(), { hash: a3 } = (0, F.gf)(), { pageId: i2 } = (0, p.$au)(), { mainObjectId: n3, mainObjectType: l3 } = (0, p.Jfv)();
          return (0, E.c)((s2) => {
            if (!e3 || !i2 || !p.Wft[i2]) return;
            let o3 = {
              pageStyle: k.QL.ContextMenu,
              pagePlacement: k.c4.Hover,
              mainObjectType: l3,
              mainObjectId: n3,
              hash: a3,
              pageId: i2
            };
            s2 && (o3.viewUuid = String((0, w.A)()));
            let r3 = (0, k.Fx)({ params: o3, logger: t3, context: "useSendEventOnDonationMenuOpenedOrClosed" });
            r3 && (s2 ? (0, k.Fn)(null == e3 ? void 0 : e3.evgenInstance, r3) : (0, k.Ig)(null == e3 ? void 0 : e3.evgenInstance, r3));
          });
        })(), [r2, d2] = (0, s.useState)(false), u2 = (0, s.useRef)(false);
        return (0, s.useEffect)(() => {
          r2 && (u2.current = true);
        }, [r2]), (0, s.useEffect)(() => {
          u2.current && o2(r2);
        }, [r2, o2]), (0, i.jsx)(K.W1, {
          ariaLabel: l2({ id: "donation.button-text" }),
          size: "s",
          variant: "default",
          radius: "round",
          color: "secondary",
          icon: (0, i.jsx)(U.Icon, { size: "xxs", variant: "ruble" }),
          onOpenChange: d2,
          open: r2,
          isMobile: t2,
          placement: "bottom",
          offsetOptions: 8,
          listClassName: V().popover,
          children: null == a2 || null == (e2 = a2.items) ? void 0 : e2.map((e3, t3) => {
            var l3;
            return (0, i.jsx)(
              p.Bki,
              {
                objectType: k.ky.Donation,
                objectId: e3.artist.id,
                objectPosX: 1,
                objectPosY: t3 + 1,
                objectsCount: Number(null == (l3 = a2.items) ? void 0 : l3.length),
                mainObjectId: String(null == n2 ? void 0 : n2.id),
                mainObjectType: k.ky.Album,
                children: (0, i.jsx)(Z, { donation: e3 })
              },
              e3.artist.id
            );
          })
        });
      });
      var W = a(10612);
      let q = (0, n.PA)((e2) => {
        var t2, a2, n2;
        let { album: l2, size: s2, weight: r2, className: d2 } = e2, { formatMessage: u2 } = (0, _.A)(), c2 = null == (t2 = l2.labels) ? void 0 : t2.length, m2 = u2(
          (null == (a2 = l2.meta) ? void 0 : a2.isPodcast) ? { id: "page.album-publisher-title" } : { id: "page.album-label-title" },
          { count: c2 }
        );
        return (0, i.jsxs)("div", {
          className: (0, C.$)(j().label, j().important, d2),
          children: [
            (0, i.jsx)(Y.Caption, { variant: "span", size: s2, weight: r2, children: m2 }),
            " ",
            (0, i.jsx)(Y.Caption, {
              variant: "span",
              size: s2,
              weight: r2,
              lineClamp: 1,
              children: null == (n2 = l2.labels) ? void 0 : n2.map((e3) => {
                let { id: t3, name: a3 } = e3;
                return (0, i.jsx)(
                  g.N_,
                  {
                    role: "link",
                    "aria-label": a3,
                    href: l2.labelUrl(t3),
                    className: (0, C.$)(j().labelLink, j().important),
                    ...(0, o.Am)(o.Xk.album.ALBUM_LABEL_LINK),
                    children: (0, i.jsx)(Y.Caption, { variant: "span", children: a3 })
                  },
                  t3
                );
              })
            })
          ]
        });
      });
      var J = a(88762), ee = a.n(J);
      let et = (0, n.PA)(() => {
        var e2, t2, a2, n2, l2, d2, u2, m2, v2, h2, x2, A2, E2, R2, M2, U2;
        let K2 = (0, s.useRef)(null), w2 = (0, s.useRef)(0), F2 = (0, p.wZZ)(), { notify: X2 } = (0, p.lkh)(), V2 = (0, y.Q$)(), {
          album: z2,
          albumCPA: H2,
          experiments: Y2,
          sonataState: Q2,
          settings: { isMobile: $2 },
          track: { isTrackPage: Z2 }
        } = (0, p.Pjs)(), { from: J2, utmLink: et2 } = (0, p.fyy)({
          pageId: p._Q$.ALBUM,
          blockId: p.UfI.ALBUM,
          contextType: f.K.Album,
          contextId: z2.id
        }), { formatMessage: ea2 } = (0, _.A)(), [ei2, en2] = (0, s.useState)(false), el2 = (0, O.c)({ album: z2 }), es2 = Z2 ? "div" : "h2", eo2 = z2.items.length || L.k, { isCPAEnabled: er2 } = (0, p.IQF)(), ed2 = !er2 || er2 && !H2.cpa, eu2 = Y2.checkExperiment(p.zal.WebNextAlbumDonationButton, "on") && z2.hasDonations, ec2 = eu2 && $2, { showBuySubscriptionModal: em2 } = (0, p.qBP)(), eb = H2.isPlusCPAPlayerBarEnabled(z2.id, null == (e2 = z2.meta) ? void 0 : e2.isNonMusic) && $2;
        (0, s.useEffect)(
          () => () => {
            w2.current = 0;
          },
          [z2]
        ), (0, s.useEffect)(() => {
          eb && Q2.status === I.MT.ENDED && em2();
        }, [Q2.status, em2, eb]), (0, s.useEffect)(() => {
          var e3, t3;
          if ((null == (e3 = z2.otherArtistAlbums) ? void 0 : e3.isRejected) || (null == (t3 = z2.latestGenreAlbums) ? void 0 : t3.isRejected)) {
            if (!w2 || w2.current > 0) return;
            X2((0, i.jsx)(g.hT, { error: ea2({ id: "album-errors.error-during-loading-similar-albums" }) }), {
              containerId: p.uQT.ERROR
            }), w2.current++;
          }
        }, [
          null == (t2 = z2.latestGenreAlbums) ? void 0 : t2.isRejected,
          null == (a2 = z2.otherArtistAlbums) ? void 0 : a2.isRejected,
          ea2,
          X2
        ]), (0, s.useEffect)(() => {
          z2.isResolved && z2.hasOtherAlbumVersions && en2(true);
        }, [z2.hasOtherAlbumVersions, z2.isResolved]);
        let ep = (0, s.useCallback)(() => {
          let e3 = K2.current;
          null == e3 || e3.scrollIntoView({ behavior: "smooth" });
        }, []), eg = (0, r.L)(() => {
          var e3, t3, a3, n3, l3;
          if (!eu2 || !(null == (e3 = z2.donations) ? void 0 : e3.items)) return;
          if (Number(null == (a3 = z2.meta) || null == (t3 = a3.artists) ? void 0 : t3.length) > 1)
            return (0, i.jsx)(p.FoH, {
              blockType: k.LA.Donations,
              blockId: p.UfI.DONATY,
              blockPosX: 1,
              blockPosY: 1,
              children: (0, i.jsx)(p.Bki, {
                mainObjectId: String(null == (l3 = z2.meta) ? void 0 : l3.id),
                mainObjectType: k.ky.Album,
                children: (0, i.jsx)(G, {})
              })
            });
          let [s2] = z2.donations.items;
          if (s2)
            return (0, i.jsx)(p.FoH, {
              blockType: k.LA.Donations,
              blockId: p.UfI.DONATY,
              blockPosX: 1,
              blockPosY: 1,
              children: (0, i.jsx)(p.Bki, {
                objectType: k.ky.Donation,
                objectId: s2.artist.id,
                objectPosX: 0,
                objectPosY: 0,
                objectsCount: 1,
                mainObjectId: String(null == (n3 = z2.meta) ? void 0 : n3.id),
                mainObjectType: k.ky.Album,
                children: (0, i.jsx)(B, { url: V2(s2.url) })
              })
            });
        }), ev = (0, s.useMemo)(
          () => z2.isLoading || !z2.meta || z2.isRejected ? (0, i.jsx)(N.c6, { className: j().header, isActive: true }) : (0, i.jsx)(N.c0, {
            album: z2.meta,
            donationButton: eg,
            className: j().header,
            onVersionClick: ei2 ? ep : void 0
          }),
          [z2.isLoading, z2.meta, z2.isRejected, eg, ei2, ep]
        ), eh = (0, S.j)({
          element: (e3, t3) => {
            var a3;
            if (e3.data && e3.type !== b.rU.TEXT)
              return (0, i.jsx)(p.Bki, {
                objectType: k.ky.Track,
                objectId: String(e3.data.id),
                objectPosX: 1,
                objectPosY: t3 + 1,
                objectsCount: eo2,
                children: (0, i.jsx)(P.FR, {
                  withLightning: e3.isBest && !e3.data.isRemoved,
                  track: e3.data,
                  position: e3.position,
                  albumArtists: null == z2 || null == (a3 = z2.meta) ? void 0 : a3.artists,
                  playContextParams: F2(t3, {
                    contextData: { type: f.K.Album, meta: z2.contextMeta, from: J2, utmLink: et2 },
                    queueParams: { index: e3.positionInContext, entityId: e3.data.id },
                    loadContextMeta: true,
                    entitiesData: Q2.unloadedEntitiesDataFromModels
                  })
                })
              });
          },
          album: z2
        });
        return z2.id && z2.isResolved && z2.similarEntities.isNeededToLoad && z2.isSimilarEntitiesEnabled && (0, s.use)(z2.getSimilarEntities({ albumId: z2.id })), (0, i.jsxs)(i.Fragment, {
          children: [
            ev,
            (0, i.jsx)(p.FoH, {
              blockType: k.LA.Tracks,
              blockId: k.LA.Tracks,
              blockPosX: 1,
              blockPosY: 1,
              objectsCount: eo2,
              mainObjectId: String(null == (n2 = z2.meta) ? void 0 : n2.id),
              mainObjectType: k.ky.Album,
              children: (0, i.jsx)(W.F, {
                count: eo2,
                itemContentCallback: eh,
                getDataByRange: el2,
                ariaLabel: ea2(
                  { id: "entity-names.albums-tracks-list" },
                  { albumName: (null == (l2 = z2.meta) ? void 0 : l2.title) || "" }
                )
              })
            }),
            (0, i.jsxs)("div", {
              className: j().footerContainer,
              children: [
                z2.shouldShowLabel && (0, i.jsx)(q, { album: z2, size: "s", weight: "normal", className: ee().label }),
                (0, i.jsxs)("div", {
                  className: ee().carouselBlocks,
                  children: [
                    ec2 && (null == (d2 = z2.donations) ? void 0 : d2.items) && (0, i.jsx)(p.FoH, {
                      blockType: k.LA.Donations,
                      blockId: p.UfI.DONATY,
                      blockPosX: 1,
                      blockPosY: 2,
                      children: (0, i.jsx)(D, {
                        headingVariant: es2,
                        className: ee().carouselContainer,
                        headerClassName: (0, C.$)(ee().carouselBlock, ee().carouselBlockHeader),
                        containerClassName: ee().carouselBlock
                      })
                    }),
                    z2.hasSimilarEntities && (0, i.jsx)(p.FoH, {
                      blockType: k.LA.SimilarEntities,
                      blockId: k.LA.SimilarEntities,
                      blockPosX: 1,
                      blockPosY: 3,
                      objectsCount: null == (u2 = z2.similarEntities.data) ? void 0 : u2.items.length,
                      mainObjectId: String(null == (m2 = z2.meta) ? void 0 : m2.id),
                      mainObjectType: k.ky.Album,
                      children: (0, i.jsx)(T.Qh, {
                        ...z2.similarEntities,
                        meta: { title: ea2({ id: "page.similar-entities-block-title" }) },
                        headingVariant: es2,
                        className: ee().carouselContainer,
                        headerClassName: (0, C.$)(ee().carouselBlock, ee().carouselBlockHeader),
                        containerClassName: ee().carouselBlock,
                        shouldSentAnalyticsOnLoaded: true,
                        setHasSentAnalyticsOnLoaded: z2.similarEntities.setHasSentAnalyticsOnLoaded
                      })
                    }),
                    z2.hasOtherAlbumVersions && (0, i.jsx)(p.FoH, {
                      blockType: k.LA.OtherAlbumVersions,
                      blockId: k.LA.OtherAlbumVersions,
                      blockPosX: 1,
                      blockPosY: 4,
                      objectsCount: null == (v2 = z2.otherAlbumVersions) ? void 0 : v2.length,
                      mainObjectId: String(null == (h2 = z2.meta) ? void 0 : h2.id),
                      mainObjectType: k.ky.Album,
                      children: (0, i.jsx)(c.pZ, {
                        isShimmerVisible: z2.isLoading,
                        isShimmerActive: true,
                        className: ee().carouselContainer,
                        headerClassName: (0, C.$)(ee().carouselBlock, ee().carouselBlockHeader),
                        containerClassName: ee().carouselBlock,
                        title: ea2({ id: "entity-names.other-album-versions" }),
                        albums: z2.otherAlbumVersions,
                        headingRef: K2,
                        headingVariant: es2,
                        ...(0, o.Am)(o.Xk.album.OTHER_VERSIONS_CAROUSEL)
                      })
                    }),
                    z2.hasLatestGenreAlbums && ed2 && (0, i.jsx)(p.FoH, {
                      blockType: k.LA.GenreAlbums,
                      blockId: k.LA.GenreAlbums,
                      blockPosX: 1,
                      blockPosY: 5,
                      objectsCount: null == (x2 = z2.latestGenreAlbums) ? void 0 : x2.items.length,
                      mainObjectId: String(null == (A2 = z2.meta) ? void 0 : A2.id),
                      mainObjectType: k.ky.Album,
                      children: (0, i.jsx)(c.pZ, {
                        isShimmerVisible: z2.isLatestGenreAlbumsLoading,
                        isShimmerActive: true,
                        className: ee().carouselContainer,
                        headerClassName: (0, C.$)(ee().carouselBlock, ee().carouselBlockHeader),
                        containerClassName: ee().carouselBlock,
                        title: ea2({ id: "entity-names.new-albums-in-genre" }),
                        albums: null == (E2 = z2.latestGenreAlbums) ? void 0 : E2.items,
                        headingVariant: es2,
                        ...(0, o.Am)(o.Xk.album.GENRE_ALBUMS_CAROUSEL)
                      })
                    }),
                    z2.hasOtherArtistAlbums && (0, i.jsx)(p.FoH, {
                      blockType: k.LA.OtherAlbums,
                      blockId: k.LA.OtherAlbums,
                      blockPosX: 1,
                      blockPosY: 6,
                      objectsCount: null == (R2 = z2.otherArtistAlbums) ? void 0 : R2.items.length,
                      mainObjectId: String(null == (M2 = z2.meta) ? void 0 : M2.id),
                      mainObjectType: k.ky.Album,
                      children: (0, i.jsx)(c.pZ, {
                        isShimmerVisible: z2.isOtherArtistAlbumsLoading,
                        isShimmerActive: true,
                        className: ee().carouselContainer,
                        headerClassName: (0, C.$)(ee().carouselBlock, ee().carouselBlockHeader),
                        containerClassName: ee().carouselBlock,
                        title: ea2({ id: "entity-names.other-albums-of-artist" }),
                        albums: null == (U2 = z2.otherArtistAlbums) ? void 0 : U2.items,
                        headingVariant: es2,
                        ...(0, o.Am)(o.Xk.album.OTHER_ARTIST_ALBUMS_CAROUSEL)
                      })
                    })
                  ]
                }),
                (0, i.jsx)(g.A, { children: (0, i.jsx)(g.wi, { className: j().footer }) })
              ]
            })
          ]
        });
      });
      var ea = a(47713), ei = a(15209), en = a(77881), el = a(51321), es = a(8593), eo = a(54672), er = a(32600), ed = a.n(er);
      let eu = (0, n.PA)(() => {
        var e2, t2, a2, n2, o2, d2, u2, c2, m2, v2;
        let h2 = (0, s.useRef)(0), x2 = (0, s.useRef)(null), A2 = (0, p.wZZ)(), { album: C2, experiments: k2, sonataState: I2, slides: T2 } = (0, p.Pjs)(), y2 = (null == (e2 = C2.meta) ? void 0 : e2.isAudiobook) ? p._Q$.AUDIOBOOK : p._Q$.PODCAST, E2 = (null == (t2 = C2.meta) ? void 0 : t2.isAudiobook) ? p.UfI.AUDIOBOOK : p.UfI.PODCAST, { from: B2, utmLink: R2 } = (0, p.fyy)({ pageId: y2, blockId: E2, contextType: f.K.Album, contextId: C2.id }), { href: M2 } = (0, p.uvd)("/slides/podcast/:podcastId", {
          params: { podcastId: null != (v2 = C2.id) ? v2 : "" }
        }), D2 = (0, p.ZpR)(M2), U2 = (0, s.useId)(), { formatMessage: K2 } = (0, _.A)(), w2 = (0, l.useSearchParams)(), F2 = (0, p.XJ9)(), X2 = k2.checkExperiment(p.zal.WebNextRewind2024, "on") && (null == (a2 = C2.meta) ? void 0 : a2.isPodcast), V2 = (0, s.useMemo)(() => {
          let e3 = w2.get(p.K3F.ACTIVE_TAB), t3 = L.n.findIndex((t4) => t4 === e3);
          return t3 >= 0 ? t3 : null;
        }, [w2]), z2 = (0, el.useTabsState)(null != V2 ? V2 : 0), [H2, Q2] = (0, s.useState)(L.n[z2.value]), $2 = (0, O.c)({ album: C2 });
        (0, s.useEffect)(
          () => () => {
            h2.current = 0, T2.resetPodcast();
          },
          [C2, T2]
        );
        let Z2 = (0, s.useMemo)(() => {
          var e3, t3;
          let a3 = X2 && T2.podcastSlidesLoadingState === p.GuX.RESOLVE && !!(null == (e3 = T2.podcastItems) ? void 0 : e3.length), n3 = { "--action-button-color-background": (0, N.Wm)(null == (t3 = C2.meta) ? void 0 : t3.averageColor) };
          return a3 ? (0, i.jsx)(en.$, {
            className: ed().rewindControl,
            style: n3,
            withRipple: false,
            withHover: false,
            radius: "xxxl",
            size: "s",
            color: "primary",
            onClick: D2,
            variant: "default",
            role: "link",
            children: (0, i.jsx)(Y.Caption, {
              variant: "span",
              lineClamp: 1,
              children: (0, i.jsx)(ea.A, { id: "rewind.button-title" })
            })
          }) : null;
        }, [
          null == (n2 = C2.meta) ? void 0 : n2.averageColor,
          X2,
          D2,
          null == (o2 = T2.podcastItems) ? void 0 : o2.length,
          T2.podcastSlidesLoadingState
        ]), G2 = (0, s.useMemo)(() => {
          var e3, t3;
          return (null == (e3 = C2.meta) ? void 0 : e3.isFairyTale) ? {
            about: K2({ id: "non-music.fairytale-tab-about" }),
            "track-list": K2({ id: "non-music.audiobook-tab-tracks" })
          } : (null == (t3 = C2.meta) ? void 0 : t3.isAudiobook) ? {
            about: K2({ id: "non-music.audiobook-tab-about" }),
            "track-list": K2({ id: "non-music.audiobook-tab-tracks" })
          } : {
            about: K2({ id: "podcast.tab-about" }),
            "track-list": K2({ id: "podcast.tab-tracks" }, { value: C2.tracks.length })
          };
        }, [
          null == (d2 = C2.meta) ? void 0 : d2.isAudiobook,
          null == (u2 = C2.meta) ? void 0 : u2.isFairyTale,
          C2.tracks.length,
          K2
        ]), J2 = (0, s.useMemo)(
          () => (e3) => {
            var t3;
            if (!z2.onTabChange || e3 === z2.value) return;
            z2.onTabChange(e3);
            let a3 = null != (t3 = L.n[e3]) ? t3 : eo.O.ABOUT;
            Q2(a3);
            let i2 = (0, p.bJ)(p.K3F.ACTIVE_TAB, a3);
            i2 && F2(i2);
          },
          [z2, F2]
        ), ee2 = (e3, t3) => (0, i.jsxs)("div", {
          className: ed().infoBlock,
          children: [
            (0, i.jsx)(Y.Caption, {
              variant: "span",
              type: "entity",
              size: "m",
              className: ed().infoTitle,
              children: e3
            }),
            (0, i.jsx)(Y.Caption, { variant: "span", type: "entity", size: "m", children: t3 })
          ]
        }), et2 = ((e3) => {
          let { formatMessage: t3 } = (0, _.A)(), { minutes: a3, hours: i2 } = (0, p.VEg)(e3), n3 = "";
          return i2 > 0 && (n3 += t3({ id: "time.hours" }, { hours: i2 })), a3 > 0 && (n3 += n3.length > 0 ? " " : "", n3 += t3({ id: "time.minutes-left" }, { minutes: a3 })), n3;
        })((null == (c2 = C2.meta) ? void 0 : c2.durationSec) || 0), er2 = (0, s.useMemo)(() => {
          var e3, t3, a3, n3, l2, s2, o3, r2, d3, u3, c3, m3, b2, p2, g2;
          let v3 = Number(null == (e3 = C2.labels) ? void 0 : e3.length) > 1 ? K2({ id: "podcast.publishers-title" }) : K2({ id: "podcast.publisher-title" }), h3 = null == (t3 = C2.labels) ? void 0 : t3.map((e4) => e4.name).join(", "), x3 = K2({ id: "podcast.age-limit" }), A3 = Number(null == (n3 = C2.meta) || null == (a3 = n3.artists) ? void 0 : a3.length) > 1 ? K2({ id: "non-music.audiobook-artists" }) : K2({ id: "non-music.audiobook-artist" }), _2 = null == (s2 = C2.meta) || null == (l2 = s2.artists) ? void 0 : l2.map((e4) => e4.name).join(", "), k3 = (null == (r2 = C2.meta) || null == (o3 = r2.artists) ? void 0 : o3.length) || (null == (d3 = C2.meta) ? void 0 : d3.durationSec) || (null == (u3 = C2.labels) ? void 0 : u3.length) || C2.isExplicit, f2 = _2 && ee2("".concat(A3, ":"), String(_2)), I3 = (null == (c3 = C2.meta) ? void 0 : c3.durationSec) && ee2("".concat(K2({ id: "time.duration" }), ":"), et2), T3 = h3 && ee2("".concat(v3, ":"), String(h3)), N2 = ee2("".concat(x3, ":"), "18+"), y3 = C2.shouldShowLabel ? (0, i.jsx)(q, { album: C2, size: "m", weight: "medium", className: ed().label }) : T3;
          return (0, i.jsx)(el.TabPanel, {
            name: 0,
            value: z2.value,
            elementId: U2,
            children: (0, i.jsxs)("div", {
              className: ed().contentAbout,
              children: [
                C2.description && !!(null == (m3 = C2.description) ? void 0 : m3.length) && (0, i.jsx)(Y.Caption, {
                  variant: "div",
                  type: "entity",
                  size: "m",
                  className: j().text,
                  children: (0, i.jsx)("span", {
                    dangerouslySetInnerHTML: { __html: (0, ei.sanitizeDOM)(C2.description) }
                  })
                }),
                k3 && (0, i.jsxs)("div", {
                  className: j().text,
                  children: [
                    !!(null == (p2 = C2.meta) || null == (b2 = p2.artists) ? void 0 : b2.length) && f2,
                    (null == (g2 = C2.meta) ? void 0 : g2.durationSec) && I3,
                    y3,
                    C2.isExplicit && N2
                  ]
                })
              ]
            })
          });
        }, [C2, K2, et2, z2.value, U2]), eu2 = (0, r.L)(
          () => C2.isLoading || !C2.meta || C2.isRejected ? (0, i.jsx)(N.c6, { className: j().header, isActive: true }) : (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)(N.hW, { album: C2.meta, actionButton: Z2, className: j().header }),
              (0, i.jsx)(g.wI, {
                className: ed().tabCarousel,
                ...z2,
                onTabChange: J2,
                ref: x2,
                children: L.n.map(
                  (e3, t3) => (0, i.jsx)(g.oz, { className: ed().tab, title: G2[e3], value: t3 }, e3)
                )
              }),
              er2
            ]
          })
        );
        (0, s.useEffect)(() => {
          C2.isResolved && (C2.loadLastEpisodes(), C2.getRelatedContent());
        }, [C2, C2.isResolved, C2.loadLastEpisodes, C2.getRelatedContent]);
        let ec2 = H2 === eo.O.ABOUT && (null == (m2 = C2.meta) ? void 0 : m2.isPodcast) && C2.lastEpisodes.length > 0, em2 = H2 === eo.O.ABOUT && C2.relatedContent && C2.relatedContent.items && C2.relatedContent.items.length > 0, eb = (0, S.j)({
          element: (e3, t3) => {
            if (e3.data && e3.type !== b.rU.TEXT)
              return (0, i.jsx)(P.Kd, {
                track: e3.data,
                viewType: P.Df.ALBUM,
                position: e3.position,
                playContextParams: A2(t3, {
                  contextData: { type: f.K.Album, meta: C2.contextMeta, from: B2, utmLink: R2 },
                  queueParams: { index: e3.positionInContext, entityId: e3.data.id },
                  loadContextMeta: true,
                  entitiesData: I2.unloadedEntitiesDataFromModels
                })
              });
          },
          isNonMusic: true,
          album: C2
        }), ep = H2 === eo.O.ABOUT ? 0 : C2.items.length || L.k, eg = (0, r.L)(() => {
          if (H2 === eo.O.TRACKS) {
            var e3, t3, a3;
            return (null == (e3 = C2.meta) ? void 0 : e3.isAudiobook) ? K2(
              { id: "non-music.audiobook-list" },
              { albumName: (null == (a3 = C2.meta) ? void 0 : a3.title) || "" }
            ) : K2({ id: "podcast.episodes-list" }, { albumName: (null == (t3 = C2.meta) ? void 0 : t3.title) || "" });
          }
        }), ev = (0, r.L)(
          () => H2 === eo.O.ABOUT ? null : (0, i.jsx)(W.F, {
            count: ep,
            getDataByRange: $2,
            itemContentCallback: eb,
            role: "tabpanel",
            ariaLabel: eg
          })
        ), eh = X2 && T2.podcastSlidesLoadingState === p.GuX.IDLE;
        return "number" == typeof C2.id && eh && (0, s.use)(T2.getPodcastSlides({ podcastId: C2.id })), (0, i.jsxs)(i.Fragment, {
          children: [
            eu2,
            ev,
            (0, i.jsxs)("div", {
              className: j().footerContainer,
              children: [
                ec2 && (0, i.jsx)(es.ro, { className: ed().lastEpisodes }),
                em2 && (0, i.jsx)(es.ZM, { isShimmerVisible: C2.isRelatedContentLoading, isShimmerActive: true }),
                (0, i.jsx)(g.A, { children: (0, i.jsx)(g.wi, { className: j().footer }) })
              ]
            })
          ]
        });
      }), ec = (0, n.PA)((e2) => {
        var t2, a2, n2, A2, C2, _2;
        let { albumId: k2, trackId: f2, preloadedAlbum: I2, preloadedCpa: T2 } = e2, { contentScrollRef: N2, setContentScrollRef: y2 } = (0, p.gKY)(), P2 = (0, l.useSearchParams)(), L2 = (0, c.yb)({ searchParams: Object.fromEntries(P2.entries()) }), { album: O2, disclaimerModalState: S2, track: E2, sonataState: B2, albumCPA: R2 } = (0, p.Pjs)(), { checkIsValidClid: M2, setClidToQuery: D2, deleteClidFromQuery: U2 } = (0, p.IQF)(), K2 = (0, p.ytd)(null == (t2 = O2.meta) ? void 0 : t2.averageColor), { headerStyle: w2 } = (0, m.QZ)(K2), { deprecationUrl: F2, shouldRedirect: X2 } = (0, v.W)({
          albumId: k2,
          deprecationTargetAlbumId: O2.deprecationTargetAlbumId,
          trackId: f2,
          realId: (null == (a2 = E2.meta) ? void 0 : a2.id) === f2 ? null == (n2 = E2.meta) ? void 0 : n2.realId : void 0,
          searchParams: P2
        }), V2 = (0, b.cp)({ album: O2.meta, shouldHistoryBack: true }), z2 = !!(null == (A2 = O2.meta) ? void 0 : A2.isNonMusic);
        (0, p.ACS)(), ((e3) => {
          var t3;
          let { albumId: a3, trackId: i2, isNonMusic: n3 } = e3, { setDeeplink: l2 } = null != (t3 = (0, p.P7Q)()) ? t3 : {};
          (0, s.useEffect)(() => {
            if (i2) {
              let e4 = n3 ? void 0 : { playTrack: i2, openPlayer: true, lyricsMode: true }, { href: t4 } = (0, p.uvd)("/album/:albumId/track/:trackId", {
                params: { albumId: a3, trackId: i2 },
                query: e4
              });
              null == l2 || l2(t4);
            } else {
              let { href: e4 } = (0, p.uvd)("/album/:albumId", { params: { albumId: a3 } });
              null == l2 || l2(e4);
            }
            return () => {
              null == l2 || l2(null);
            };
          }, [a3, n3, l2, i2]);
        })({ albumId: k2, trackId: f2, isNonMusic: z2 }), (0, s.useEffect)(() => {
          var e3;
          (null == (e3 = O2.meta) ? void 0 : e3.isUnsafeLegal) && V2();
        }, [null == (C2 = O2.meta) ? void 0 : C2.isUnsafeLegal, V2]), (0, s.useLayoutEffect)(
          () => (f2 && k2 && E2.open({ trackId: f2, albumId: Number(k2) }), () => {
            E2.reset();
          }),
          [k2, f2, E2]
        ), (0, s.useEffect)(() => {
          M2(R2.cpa, Number(k2)) || U2();
        }, [M2, k2, R2.cpa, U2]), (0, s.useEffect)(
          () => (O2.id && O2.id !== Number(k2) && (O2.reset(B2), U2()), () => {
            O2.reset(B2), U2();
          }),
          [O2, k2, B2, U2, R2]
        ), (0, p.Jzs)(O2.isResolved), (0, h.h)(O2, E2.isOpened, f2);
        let H2 = (0, r.L)(() => z2 ? (0, i.jsx)(eu, {}) : (0, i.jsx)(et, {})), Y2 = [];
        return (k2 && O2.isNeededToLoad && (Y2.push(
          O2.getData({ albumId: Number(k2), resumeStream: false, preloadedAlbum: I2, sonataState: B2 }),
          O2.getDonations({ albumId: Number(k2) })
        ), (L2 || T2) && Y2.push(R2.getCpa({ albumId: Number(k2), preloadedCpa: T2 }))), Y2.length && (0, s.use)(Promise.allSettled(Y2)), (0, s.useEffect)(() => {
          R2.cpa && O2.id && D2(R2.cpa, O2.id);
        }, [R2.cpa, O2.id, D2]), O2.isNotFound && (0, l.notFound)(), X2 && (0, l.redirect)(F2), (0, x.Y)({ album: O2 }), O2.isCacheNotFound) ? (0, i.jsx)(u.m, {}) : (null == (_2 = O2.meta) ? void 0 : _2.isLegalRejected) ? (0, i.jsx)(g.MW, { modalState: S2 }) : (0, i.jsx)(p.pVJ, {
          pageAlbumId: Number(k2),
          children: (0, i.jsx)(p.jPc, {
            children: (0, i.jsxs)(m.hO, {
              scrollElement: N2,
              children: [
                (0, i.jsx)(g.Y9, {}),
                (0, i.jsxs)(d.C, {
                  scrollableContainerRef: y2,
                  className: j().root,
                  containerClassName: j().content,
                  scrollContentClassName: j().scrollContent,
                  ...(0, o.Am)(z2 ? o.Xk.album.NON_MUSIC_ALBUM_PAGE : o.Xk.album.ALBUM_PAGE),
                  children: [(0, i.jsx)("div", { className: j().averageColorBackground, style: w2 }), H2]
                })
              ]
            })
          })
        });
      }), em = (0, n.PA)(
        (e2) => (0, i.jsx)(p.nVz, { pageId: p._Q$.ALBUM, pageEntityId: e2.albumId, children: (0, i.jsx)(ec, { ...e2 }) })
      );
    },
    54672: (e, t, a) => {
      "use strict";
      a.d(t, { O: () => i });
      var i = (function(e2) {
        return e2.ABOUT = "about", e2.TRACKS = "track-list", e2;
      })({});
    },
    56053: (e, t, a) => {
      "use strict";
      a.d(t, { h: () => o });
      var i = a(61910), n = a(94376), l = a(74125), s = a(70717);
      let o = (e2, t2, a2) => {
        (0, i.useEffect)(() => {
          let i2 = t2 && a2;
          if (!(null == e2 ? void 0 : e2.meta) || e2.isLoading || i2) return;
          let o2 = (0, n.fO)(e2.meta);
          t2 || (0, s.v)(o2, { fullUrl: null, locale: null, url: null, tld: "", host: "" }).then((e3) => {
            (0, l.jxB)(e3);
          });
        }, [null == e2 ? void 0 : e2.meta, null == e2 ? void 0 : e2.isLoading, a2, t2]);
      };
    },
    57159: (e) => {
      e.exports = {
        root: "ExternalStreamingCard_root__7XtH7",
        logo: "ExternalStreamingCard_logo__NbEj3",
        logoImage: "ExternalStreamingCard_logoImage__FCbdH",
        name: "ExternalStreamingCard_name__QWiJe"
      };
    },
    64566: (e) => {
      e.exports = {
        root: "RelatedContent_root__Dl1Nr",
        carousel: "RelatedContent_carousel__pmv5c",
        header: "RelatedContent_header__527S3"
      };
    },
    70717: (e, t, a) => {
      "use strict";
      a.d(t, { v: () => o });
      var i = a(74125), n = a(15099);
      function l(e2) {
        let { type: t2, genre: a2 } = e2;
        return [n._.AUDIOBOOK, n._.FAIRY_TALE].includes(null != t2 ? t2 : "") || ["audiobooksinenglish", "fiction"].includes(null != a2 ? a2 : "");
      }
      function s(e2) {
        let { albumType: t2, messageFormatter: a2 } = e2;
        switch (t2) {
          case n._.SINGLE:
            return a2({ id: "metadata.single" });
          case n._.PODCAST:
            return a2({ id: "metadata.podcast" });
          case n._.AUDIOBOOK:
            return a2({ id: "metadata.audiobook" });
          case n._.FAIRY_TALE:
            return a2({ id: "metadata.fairy-tale" });
          default:
            return a2({ id: "metadata.album" });
        }
      }
      async function o(e2, t2) {
        var a2, o2, r;
        if (!e2) return { title: "", description: "", openGraph: {}, twitter: {}, appLinks: {}, other: {} };
        let d = await (0, i.WGy)(t2.locale), u = (0, i.NsT)(e2.title);
        return {
          title: (function(e3) {
            let { albumMeta: t3, messageFormatter: a3 } = e3, s2 = (0, i.j4K)(t3.artists);
            return l({ type: t3.type, genre: t3.genre }) ? s2 ? a3(
              { id: "metadata.audiobook-title-with-artists" },
              { albumTitle: t3.title, artistsNames: s2, artistsNamesCount: t3.artists.length }
            ) : a3({ id: "metadata.audiobook-title-without-artists" }, { albumTitle: t3.title }) : t3.type === n._.PODCAST ? a3({ id: "metadata.podcast-title" }, { albumTitle: t3.title }) : s2 ? a3({ id: "metadata.album-title-with-artists" }, { albumTitle: t3.title, artistsNames: s2 }) : a3({ id: "metadata.album-title-without-artists" }, { albumTitle: t3.title });
          })({ albumMeta: e2, messageFormatter: d }),
          description: (function(e3) {
            let { albumMeta: t3, messageFormatter: a3 } = e3, s2 = (0, i.j4K)(t3.artists);
            return l({ type: t3.type, genre: t3.genre }) ? s2 ? a3(
              { id: "metadata.audiobook-title-with-artists" },
              { albumTitle: t3.title, artistsNames: s2, artistsNamesCount: t3.artists.length }
            ) : a3({ id: "metadata.audiobook-title-without-artists" }, { albumTitle: t3.title }) : t3.type === n._.PODCAST ? a3({ id: "metadata.podcast-title" }, { albumTitle: t3.title }) : s2 ? a3({ id: "metadata.album-title-with-artists" }, { albumTitle: t3.title, artistsNames: s2 }) : a3({ id: "metadata.album-title-without-artists" }, { albumTitle: t3.title });
          })({ albumMeta: e2, messageFormatter: d }),
          openGraph: (0, i.i$E)({
            ogTitle: u,
            ogDescription: (function(e3) {
              var t3, a3, o3;
              let { albumMeta: r2, messageFormatter: d2 } = e3, u2 = (0, i.YFq)((0, i.j4K)(r2.artists), 96, false);
              if (l({ type: r2.type, genre: r2.genre })) {
                let { hours: e4, minutes: a4 } = (0, i.VEg)(null != (t3 = r2.durationSec) ? t3 : 0), n2 = d2({ id: "metadata.hours-and-minutes" }, { hours: e4, minutes: a4 });
                return [u2, s({ albumType: r2.type, messageFormatter: d2 }), n2].join(" • ");
              }
              return r2.type === n._.PODCAST ? [
                (0, i.YFq)(null != (a3 = r2.description) ? a3 : "", 96, false),
                s({ albumType: r2.type, messageFormatter: d2 }),
                d2({ id: "metadata.subscribers" }, { subscribers: null != (o3 = r2.likesCount) ? o3 : 0 })
              ].join(" • ") : [u2, s({ albumType: r2.type, messageFormatter: d2 }), r2.year].join(" • ");
            })({ albumMeta: e2, messageFormatter: d }),
            fullUrl: null != (a2 = t2.fullUrl) ? a2 : "",
            locale: t2.locale,
            ogImage: e2.ogImage,
            siteName: d({ id: "metadata.yandex-music" }),
            ogType: "music.album"
          }),
          twitter: (0, i.HRN)({
            cardType: i.WfF.APP,
            title: u,
            url: t2.url,
            appName: d({ id: "metadata.yandex-music" })
          }),
          appLinks: (0, i.X5i)({
            additional: {
              ...t2,
              url: null != (o2 = t2.url) ? o2 : "",
              fullUrl: null != (r = t2.fullUrl) ? r : "",
              host: t2.host
            },
            appName: d({ id: "metadata.yandex-music" })
          }),
          other: { "music:musician": (0, i.xdV)(e2.artists, t2.host) },
          alternates: (0, i.SEs)("/album/:albumId", t2.tld, { params: { albumId: e2.id } })
        };
      }
    },
    72880: (e, t, a) => {
      "use strict";
      a.d(t, { PromoLandingAlbumPage: () => et });
      var i = a(54486), n = a(50420), l = a(28303), s = a(97396), o = a(61910), r = a(31500), d = a(27510), u = a(85284), c = a(33276), m = a(91283), b = a(46423), p = a(74125), g = a(80585), v = a(56053), h = a(76048), x = a(26273), A = a.n(x), j = a(38981), C = a.n(j), _ = a(43426), k = a(43350), f = a(63585), I = a(7981), T = a(21365), N = a(77217), y = a(25326), P = a(26478), L = a(17930), O = a(10612), S = a(23970), E = a.n(S), B = (function(e2) {
        return e2.TOP = "TOP", e2.BOTTOM = "BOTTOM", e2;
      })({}), R = a(8817);
      let M = {
        MOBILE: {
          TEST: { [B.BOTTOM]: "R-A-14568769-4", [B.TOP]: "R-A-14568769-3" },
          PROD: { [B.BOTTOM]: "R-A-14568769-2", [B.TOP]: "R-A-14568769-1" }
        },
        DESKTOP: {
          TEST: { [B.BOTTOM]: "R-A-14568770-4", [B.TOP]: "R-A-14568770-3" },
          PROD: { [B.BOTTOM]: "R-A-14568770-2", [B.TOP]: "R-A-14568770-1" }
        }
      }, D = (0, l.PA)((e2) => {
        let { variant: t2, className: a2 } = e2, { formatMessage: n2 } = (0, _.A)(), l2 = (0, p.UlF)(), { productionBlockId: s2, testBlockId: o2 } = ((e3) => {
          let {
            settings: { isMobile: t3 }
          } = (0, p.Pjs)();
          return t3 ? { productionBlockId: M.MOBILE.PROD[e3], testBlockId: M.MOBILE.TEST[e3] } : { productionBlockId: M.DESKTOP.PROD[e3], testBlockId: M.DESKTOP.TEST[e3] };
        })(t2), r2 = (0, R.c)(() => {
          l2.error("Cannot render promolanding advert banner", { productionBlockId: s2, testBlockId: o2 });
        });
        return (0, i.jsx)("div", {
          "aria-label": n2({ id: "advert.banner" }),
          role: "banner",
          children: (0, i.jsx)(g.fJ, { isAsync: false, onError: r2, productionBlockId: s2, testBlockId: o2, className: a2 })
        });
      }), U = (e2) => {
        let { shouldPlaceAdvertOnBottom: t2 } = e2;
        return (0, i.jsxs)("div", {
          className: (0, n.$)(A().footerContainer, A().footer, E().footerContainer),
          children: [
            t2 && (0, i.jsx)(D, { variant: B.BOTTOM, className: E().advert }),
            (0, i.jsx)(g.Z7, { className: E().footer })
          ]
        });
      };
      var K = a(32353);
      let w = (0, l.PA)(() => {
        let { promolanding: e2 } = (0, p.Pjs)();
        return e2.isLoading || !e2.meta || e2.isRejected ? (0, i.jsx)(K.c6, { isActive: true }) : (0, i.jsx)(K.e4, { album: e2.meta });
      }), F = (e2) => {
        let { shouldPlaceAdvertOnTop: t2 } = e2;
        return (0, i.jsxs)("div", {
          className: (0, n.$)(A().header, E().header),
          children: [t2 && (0, i.jsx)(D, { variant: B.TOP, className: E().advert }), (0, i.jsx)(w, {})]
        });
      };
      var X = a(97800), V = a(58360), z = a(57159), H = a.n(z);
      let Y = (e2) => {
        let { link: t2 } = e2;
        return (0, i.jsxs)(g.N_, {
          href: t2.url,
          target: "_blank",
          className: H().root,
          "aria-label": t2.service.name,
          children: [
            (0, i.jsx)("div", {
              className: H().logo,
              children: (0, i.jsx)(V.Image, {
                src: t2.service.logoUrl,
                alt: t2.service.name,
                className: H().logoImage,
                size: 40
              })
            }),
            (0, i.jsx)("div", { className: H().name, children: t2.service.name })
          ]
        });
      };
      var Q = a(44820), $ = a.n(Q);
      let Z = (e2) => {
        let { links: t2 } = e2, { formatMessage: a2 } = (0, _.A)();
        return (0, i.jsxs)("div", {
          className: $().root,
          children: [
            (0, i.jsx)(X.Heading, {
              variant: "h3",
              size: "m",
              weight: "bold",
              className: $().title,
              children: a2({ id: "album.external-streamings-title" })
            }),
            (0, i.jsx)("div", { className: $().list, children: t2.map((e3) => (0, i.jsx)(Y, { link: e3 }, e3.url)) })
          ]
        });
      };
      var G = a(63695), W = a(85861), q = a.n(W);
      let J = (e2) => {
        let { links: t2, artistName: a2 } = e2, { formatMessage: n2 } = (0, _.A)();
        return (0, i.jsxs)("div", {
          className: q().root,
          children: [
            (0, i.jsx)(X.Heading, {
              variant: "h3",
              size: "m",
              weight: "bold",
              className: q().title,
              children: n2({ id: "artist.official-pages" })
            }),
            (0, i.jsx)(G.KH, { links: t2, artistName: a2 })
          ]
        });
      }, ee = (0, l.PA)(() => {
        var e2;
        let { user: t2, promolanding: a2, experiments: n2, settings: l2 } = (0, p.Pjs)(), { isFreemium: s2 } = (0, p.XCI)(), { formatMessage: r2 } = (0, _.A)(), { from: u2, utmLink: c2 } = (0, p.fyy)({
          pageId: p._Q$.PROMOLANDING_ALBUM,
          blockId: p.UfI.ALBUM,
          contextType: f.K.Album,
          contextId: a2.id
        }), v2 = (0, P.c)({ album: a2 }), h2 = (0, p.wZZ)(), x2 = (0, I.Q$)(), { contentElements: A2 } = (0, m.E8)(), j2 = s2 || !t2.isAuthorized, C2 = j2 && n2.checkExperiment(p.zal.WebNextPromoLandingAdvert, "top"), S2 = j2 && n2.checkExperiment(p.zal.WebNextPromoLandingAdvert, "bottom"), B2 = a2.items.length || y.k, R2 = (0, L.j)({
          element: (e3, t3) => {
            var n3;
            if (e3.data && e3.type !== b.rU.TEXT)
              return (0, i.jsx)(T.Pt, {
                withLightning: e3.isBest && !e3.data.isRemoved,
                track: e3.data,
                position: e3.position,
                albumArtists: null == a2 || null == (n3 = a2.meta) ? void 0 : n3.artists,
                playContextParams: h2(t3, {
                  contextData: { type: f.K.Album, meta: a2.contextMeta, from: u2, utmLink: c2, playDisliked: true },
                  queueParams: { index: e3.positionInContext },
                  loadContextMeta: true,
                  entitiesData: a2.state.unloadedEntitiesDataFromModels
                })
              });
          },
          album: a2
        }), M2 = !!((null == A2 ? void 0 : A2.includes(m.Cq.Concerts)) && a2.hasConcerts), D2 = !!((null == A2 ? void 0 : A2.includes(m.Cq.Donation)) && a2.hasDonations), K2 = !!((null == A2 ? void 0 : A2.includes(m.Cq.SocialLinks)) && a2.hasSocialLinks), w2 = !!((null == A2 ? void 0 : A2.includes(m.Cq.ExternalStreamings)) && a2.hasExternalStreamings), X2 = (0, d.L)(() => {
          var e3, t3;
          if (!l2.isMobile || !D2) return null;
          let n3 = null == (t3 = a2.donations) || null == (e3 = t3.items) ? void 0 : e3[0];
          if (!n3) return null;
          let s3 = x2(n3.url);
          return (0, i.jsx)(p.FoH, {
            blockType: k.LA.Donations,
            blockId: p.UfI.DONATY,
            children: (0, i.jsx)(p.Bki, {
              objectType: k.ky.Donation,
              objectId: String(n3.artist.id),
              children: (0, i.jsx)(g.Tw, {
                className: E().donationBanner,
                titleClassName: E().donationBannerTitle,
                coverUrl: "https://avatars.mds.yandex.net/get-music-misc/70850/img.68ee8413749d24738fe2013b/%%",
                title: r2({ id: "donation.support-artist" }, { count: 1 }),
                description: r2({ id: "donation.transfer-any-amount" }),
                viewAllActionLink: s3,
                "aria-label": r2({ id: "donation.support-artist" }, { count: 1 }),
                titleSize: "xs"
              })
            })
          });
        }), V2 = (0, d.L)(() => {
          var e3;
          if (!M2) return null;
          let t3 = a2.promoCampaign.artistId;
          return t3 ? (0, i.jsx)(N.BD, {
            artistId: String(t3),
            title: r2({ id: "entity-names.concerts" }),
            className: E().concertsBlock,
            headerClassName: E().concertsBlockHeader,
            containerClassName: E().concertsBlockContainer,
            isLoading: a2.concerts.isLoading,
            children: null == (e3 = a2.concerts.items) ? void 0 : e3.map(
              (e4) => (0, i.jsx)(
                N.VN,
                { artistId: String(t3), concert: e4, meta: (0, i.jsx)(N.ZH, {}), forceAfishaWidget: true },
                e4.id
              )
            )
          }) : null;
        }), z2 = (0, d.L)(() => {
          var e3, t3, n3, l3;
          if (!K2 || !a2.socialLinks.items) return null;
          let s3 = null != (l3 = null == (n3 = a2.meta) || null == (t3 = n3.artists) || null == (e3 = t3[0]) ? void 0 : e3.name) ? l3 : "";
          return (0, i.jsx)(J, { links: a2.socialLinks.items, artistName: s3 });
        }), H2 = (0, d.L)(
          () => w2 && a2.externalStreamings.items ? (0, i.jsx)(Z, { links: a2.externalStreamings.items }) : null
        ), Y2 = (0, o.useMemo)(() => {
          if (!A2) return [];
          let e3 = {
            [m.Cq.Donation]: X2,
            [m.Cq.Concerts]: V2,
            [m.Cq.PlusOffer]: null,
            [m.Cq.ExternalStreamings]: H2,
            [m.Cq.SocialLinks]: z2
          };
          return A2.map((t3) => e3[t3]).filter((e4) => null !== e4);
        }, [A2, X2, V2, H2, z2]);
        return (0, i.jsxs)(i.Fragment, {
          children: [
            (0, i.jsx)(F, { shouldPlaceAdvertOnTop: C2 }),
            (0, i.jsx)(O.F, {
              count: B2,
              itemContentCallback: R2,
              getDataByRange: v2,
              ariaLabel: r2(
                { id: "entity-names.albums-tracks-list" },
                { albumName: (null == (e2 = a2.meta) ? void 0 : e2.title) || "" }
              )
            }),
            Y2.length > 0 && (0, i.jsx)("div", {
              className: E().contentBlocks,
              children: Y2.map((e3, t3) => (0, i.jsx)(o.Fragment, { children: e3 }, t3))
            }),
            (0, i.jsx)(U, { shouldPlaceAdvertOnBottom: S2 })
          ]
        });
      }), et = (0, l.PA)((e2) => {
        var t2, a2, l2;
        let { albumId: x2, preloadedAlbum: j2, preloadedCpa: _2, isActive: k2, artistId: f2 } = e2, { experiments: I2, disclaimerModalState: T2, promolanding: N2, albumCPA: y2 } = (0, p.Pjs)(), { contentScrollRef: P2, setContentScrollRef: L2 } = (0, p.gKY)(), { setClidToQuery: O2, deleteClidFromQuery: S2, checkIsValidClid: E2 } = (0, p.IQF)(), { contentElements: B2, headerElements: R2 } = (0, m.E8)(), M2 = (0, p.qne)(p.K3F.UTM_CAMPAIGN) || void 0, D2 = (0, d.L)(() => {
          if (j2) {
            var e3, t3;
            return (null == (e3 = j2.deprecation) ? void 0 : e3.targetAlbumId) && (null == (t3 = j2.deprecation) ? void 0 : t3.targetAlbumId) !== Number(x2);
          }
          return N2.deprecationTargetAlbumId && N2.deprecationTargetAlbumId !== Number(x2);
        }), U2 = (0, d.L)(() => {
          var e3;
          if (j2 && (null == (e3 = j2.deprecation) ? void 0 : e3.targetAlbumId) && D2) {
            let { href: e4 } = (0, p.uvd)("/album/:albumId", { params: { albumId: j2.deprecation.targetAlbumId } });
            return e4;
          }
          if (D2 && N2.deprecationTargetAlbumId) {
            let { href: e4 } = (0, p.uvd)("/album/:albumId", { params: { albumId: N2.deprecationTargetAlbumId } });
            return e4;
          }
          let { href: t3 } = (0, p.uvd)("/album/:albumId", { params: { albumId: x2 } });
          return t3;
        }), K2 = (0, b.cp)({ album: N2.meta, shouldHistoryBack: true }), w2 = (0, p.ytd)(null == (t2 = N2.meta) ? void 0 : t2.averageColor), { headerStyle: F2 } = (0, c.QZ)(w2);
        return ((0, h.Y)({ album: N2 }), (0, p.Jzs)(N2.isResolved), (0, v.h)(N2, false), (0, o.useEffect)(() => {
          void 0 !== f2 && N2.promoCampaign.setArtistId(f2);
        }, [f2, N2.promoCampaign]), (0, o.useEffect)(() => {
          var e3;
          (null == (e3 = N2.meta) ? void 0 : e3.isUnsafeLegal) && K2();
        }, [K2, null == (a2 = N2.meta) ? void 0 : a2.isUnsafeLegal]), (!I2.checkExperiment(p.zal.WebNextPromoLanding, "on") || D2 || N2.promoCampaign.isPromoCampaignInactive) && (0, s.redirect)(U2), ((e3) => {
          let { redirectUrl: t3 } = e3, a3 = (0, s.useSearchParams)();
          p.M3M.every((e4) => {
            let { queryKey: t4 } = e4;
            return a3.has(t4);
          }) || (0, s.redirect)(t3);
        })({ redirectUrl: U2 }), (0, o.useEffect)(
          () => (E2(y2.cpa, Number(x2)) || S2(), y2.cpa && N2.id && O2(y2.cpa, N2.id), () => {
            S2();
          }),
          [x2, y2.cpa, N2.id, O2, S2, E2]
        ), x2 && N2.promoCampaign.isNeededToLoad ? (0, o.use)(
          N2.getDataByCampaign({
            albumId: Number(x2),
            preloadedAlbum: j2,
            preloadedCpa: _2,
            isActive: k2,
            campaignId: M2
          })
        ) : (N2.promoCampaign.artistId && N2.donations.isNeededToLoad && ((null == B2 ? void 0 : B2.includes(m.Cq.Donation)) || (null == R2 ? void 0 : R2.includes(m._7.Donation))) && (0, o.use)(N2.getArtistDonations({ artistId: N2.promoCampaign.artistId })), N2.promoCampaign.artistId && N2.concerts.isNeededToLoad && (null == B2 ? void 0 : B2.includes(m.Cq.Concerts)) && (0, o.use)(N2.getArtistConcerts({ artistId: N2.promoCampaign.artistId })), N2.promoCampaign.artistId && N2.socialLinks.isNeededToLoad && (null == B2 ? void 0 : B2.includes(m.Cq.SocialLinks)) && (0, o.use)(N2.getArtistSocialLinks({ artistId: N2.promoCampaign.artistId })), N2.externalStreamings.isNeededToLoad && (null == B2 ? void 0 : B2.includes(m.Cq.ExternalStreamings)) && (0, o.use)(N2.getAlbumExternalStreamings({ albumId: Number(x2) }))), null == (l2 = N2.meta) ? void 0 : l2.isLegalRejected) ? (0, i.jsx)(g.MW, { modalState: T2 }) : (0, i.jsx)(p.nVz, {
          pageId: p._Q$.PROMOLANDING_ALBUM,
          pageEntityId: x2,
          children: (0, i.jsx)(p.pVJ, {
            pageAlbumId: Number(x2),
            children: (0, i.jsxs)(c.hO, {
              scrollElement: P2,
              children: [
                (0, i.jsx)(g.Y9, { variant: g.Vw.PROMO_LANDING }),
                (0, i.jsxs)(u.C, {
                  scrollableContainerRef: L2,
                  className: A().root,
                  containerClassName: A().content,
                  scrollContentClassName: A().scrollContent,
                  ...(0, r.Am)(r.Xk.promolanding.PROMOLANDING_ALBUM_PAGE),
                  children: [
                    (0, i.jsx)("div", {
                      className: (0, n.$)(A().averageColorBackground, C().averageColorBackground),
                      style: F2
                    }),
                    (0, i.jsx)(ee, {})
                  ]
                })
              ]
            })
          })
        });
      });
    },
    75979: (e) => {
      e.exports = {
        root: "Offline_root__IxjsY",
        container: "Offline_container__2V5Vo",
        icon: "Offline_icon__jDmpJ",
        title: "Offline_title__Y2CtW",
        text: "Offline_text__Nhult",
        buttons: "Offline_buttons__ZOFI7",
        button: "Offline_button__QSA_j"
      };
    },
    76048: (e, t, a) => {
      "use strict";
      a.d(t, { Y: () => r });
      var i = a(54486), n = a(61910), l = a(43426), s = a(74125), o = a(80585);
      let r = (e2) => {
        let { album: t2 } = e2, a2 = (0, n.useRef)(0), { notify: r2 } = (0, s.lkh)(), { formatMessage: d } = (0, l.A)();
        (0, n.useMemo)(
          () => () => {
            if (!t2.isNotFound && (t2.isRejected || !t2.meta && !t2.isLoading)) {
              var e3;
              if (!a2 || a2.current > 0) return;
              let n2 = (null == (e3 = t2.meta) ? void 0 : e3.isPodcast) ? d({ id: "podcast-errors.error-during-loading-podcast" }) : d({ id: "album-errors.error-during-loading-album" });
              r2((0, i.jsx)(o.hT, { error: n2 }), { containerId: s.uQT.ERROR }), a2.current++;
            }
          },
          [t2.isLoading, t2.isNotFound, t2.isRejected, t2.meta, d, r2]
        )();
      };
    },
    79119: (e, t, a) => {
      "use strict";
      a.d(t, { AlbumNotFoundPage: () => d });
      var i = a(54486), n = a(28303), l = a(61910), s = a(42421), o = a(74125);
      let r = (0, n.PA)(() => {
        let { album: e2, sonataState: t2 } = (0, o.Pjs)();
        return (0, o.ACS)(), (0, l.useEffect)(() => {
          e2.reset(t2);
        }, []), (0, i.jsx)(s.M, {});
      }), d = (0, n.PA)(() => (0, i.jsx)(o.nVz, { pageId: o._Q$.PAGE_NOT_FOUND_SCREEN, children: (0, i.jsx)(r, {}) }));
    },
    80453: (e, t, a) => {
      "use strict";
      a.d(t, { RelatedContent: () => b });
      var i = a(54486), n = a(50420), l = a(28303), s = a(31500), o = a(94376), r = a(74125), d = a(80585);
      let u = {
        AUTHORS_BOOKS: "authors-books",
        CATEGORY_ALBUMS: "category-albums",
        LABELS_ALBUMS: "labels-albums",
        SIMILAR_ALBUMS: "similar-albums"
      };
      var c = a(64566), m = a.n(c);
      let b = (0, l.PA)((e2) => {
        var t2, a2;
        let { isShimmerVisible: l2, isShimmerActive: c2, className: b2, headingVariant: p = "h2" } = e2, { album: g } = (0, r.Pjs)();
        return (0, i.jsx)("div", {
          className: (0, n.$)(b2, m().root),
          children: null == (a2 = g.relatedContent) || null == (t2 = a2.items) ? void 0 : t2.map((e3, t3) => {
            let a3 = ((e4) => {
              let t4 = Object.keys(u).find((t5) => u[t5] === e4);
              return s.e8.album[t4] || "";
            })(e3.type);
            return (0, i.jsx)(
              d.OY,
              {
                headingVariant: p,
                title: e3.title,
                isShimmerVisible: l2,
                isShimmerActive: c2,
                className: (0, n.$)(m().root, b2),
                containerClassName: m().carousel,
                headerClassName: m().header,
                ...a3 ? (0, s.Am)(a3) : {},
                children: e3.albums.map(
                  (e4) => (0, i.jsx)(
                    o.aX,
                    { album: e4, contentLinesCount: 3, withLikesCount: true, withAddition: false },
                    e4.id
                  )
                )
              },
              "".concat(e3.type).concat(t3)
            );
          })
        });
      });
    },
    83224: (e) => {
      e.exports = {
        icon: "NotificationDownloadError_icon__r2AWx",
        message: "NotificationDownloadError_message__WwjsI"
      };
    },
    84262: (e, t, a) => {
      "use strict";
      a.d(t, { i: () => d, m: () => x });
      var i = a(54486), n = a(5956), l = a(97800), s = a(80585), o = a(83224), r = a.n(o);
      let d = (e2) => {
        let { message: t2 } = e2;
        return (0, i.jsx)(s.$W, {
          cover: (0, i.jsx)(n.Icon, { variant: "unavailable", size: "xs", className: r().icon }),
          message: (0, i.jsx)(l.Caption, {
            className: r().message,
            variant: "div",
            type: "controls",
            size: "m",
            children: t2
          }),
          coverRadius: "s"
        });
      };
      var u = a(28303), c = a(61910), m = a(47713), b = a(8817), p = a(77881), g = a(74125), v = a(75979), h = a.n(v);
      let x = (0, u.PA)(() => {
        let { slam: e2 } = (0, g.Pjs)(), t2 = (0, g.ZpR)(g.Zyd.mymusicDownloadsTracks.href), a2 = (0, g.ZpR)(g.Zyd.settings.href), s2 = (0, b.c)(() => {
          window.location.href = g.Zyd.main.href;
        }), o2 = (0, c.useMemo)(
          () => e2.isOfflineModeEnabled ? (0, i.jsx)(m.A, { id: "offline.offline-mode-enabled" }) : (0, i.jsx)(m.A, { id: "offline.no-internet-connection" }),
          [e2.isOfflineModeEnabled]
        ), r2 = (0, c.useMemo)(
          () => e2.isOfflineModeEnabled ? (0, i.jsx)(p.$, {
            onClick: a2,
            className: h().button,
            color: "secondary",
            size: "l",
            radius: "xxxl",
            children: (0, i.jsx)(l.Caption, {
              type: "controls",
              variant: "span",
              size: "m",
              children: (0, i.jsx)(m.A, { id: "offline.disable-offline-mode" })
            })
          }) : (0, i.jsx)(p.$, {
            onClick: s2,
            className: h().button,
            color: "secondary",
            size: "l",
            radius: "xxxl",
            children: (0, i.jsx)(l.Caption, {
              type: "controls",
              variant: "span",
              size: "m",
              children: (0, i.jsx)(m.A, { id: "page-error.restart-app-button" })
            })
          }),
          [s2, a2, e2.isOfflineModeEnabled]
        );
        return (0, i.jsx)("div", {
          className: h().root,
          children: (0, i.jsxs)("div", {
            className: h().container,
            children: [
              (0, i.jsx)(n.Icon, { className: h().icon, variant: "offline", size: "xxl" }),
              (0, i.jsx)(l.Heading, { className: h().title, variant: "div", size: "xs", children: o2 }),
              (0, i.jsx)(l.Caption, {
                className: h().text,
                variant: "span",
                type: "text",
                size: "l",
                weight: "normal",
                children: (0, i.jsx)(m.A, { id: "offline.listen-downloaded-content" })
              }),
              (0, i.jsxs)("div", {
                className: h().buttons,
                children: [
                  r2,
                  (0, i.jsx)(p.$, {
                    color: "primary",
                    onClick: t2,
                    role: "link",
                    size: "l",
                    radius: "xxxl",
                    className: h().button,
                    children: (0, i.jsx)(m.A, { id: "interface-actions.go-to-collection" })
                  })
                ]
              })
            ]
          })
        });
      });
    },
    85861: (e) => {
      e.exports = { root: "PromoLandingSocialLinks_root__mybk4", title: "PromoLandingSocialLinks_title__xLYQv" };
    },
    88762: (e) => {
      e.exports = {
        carouselBlocks: "AlbumContent_carouselBlocks__bOsTV",
        carouselBlock: "AlbumContent_carouselBlock__QhSlm",
        carouselBlockHeader: "AlbumContent_carouselBlockHeader__Liibv",
        carouselContainer: "AlbumContent_carouselContainer__Y1M_e",
        label: "AlbumContent_label__2jz4j"
      };
    }
  }
]);
