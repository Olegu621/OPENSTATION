(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7466],
  {
    47466: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { ShareButton: () => w });
      var l = a(54486), r = a(50420), n = a(61910), o = a(43426), i = a(43350), s = a(77881), c = a(5956), d = a(61958), u = a(74125), h = a(31756), y = a(99020), x = a.n(y), v = a(77602), f = a.n(v);
      let m = async (e2) => {
        let { domToBlob: t2 } = await a.e(2049).then(a.bind(a, 52049)), l2 = e2.clientWidth;
        return e2.querySelectorAll("[data-scale]").forEach((e3) => {
          let t3 = e3.clientWidth, a2 = Math.max(1, Math.min((l2 - 2 * h.EK) / t3, h.GF));
          e3.dataset.scale = a2.toString();
        }), t2(e2, {
          quality: h.Tu,
          scale: h.VI / e2.clientHeight,
          onCloneNode: (e3) => {
            e3 instanceof HTMLElement && (e3.querySelectorAll("[data-scale]").forEach((e4) => {
              var t3;
              e4.style.scale = null != (t3 = e4.dataset.scale) ? t3 : "1";
            }), e3.querySelectorAll(h.bg).forEach((e4) => {
              e4.style.opacity = "0";
            }), e3.querySelectorAll("[data-screenshot-visible]").forEach((e4) => {
              e4.style.display = "block";
            }));
          }
        });
      }, b = () => "ya-music-".concat(Date.now(), ".png"), w = (e2) => {
        var t2;
        let {
          data: { title: a2, textColor: h2, buttonColor: y2 },
          className: v2,
          cardRef: w2,
          wrapperClassName: p
        } = e2, {
          settings: { isMobile: E }
        } = (0, u.Pjs)(), S = (0, u.mFl)(), { formatMessage: g } = (0, o.A)(), [k, _] = (0, n.useMemo)(() => {
          let e3 = { "--text-color": h2, "--button-color": y2 };
          return [e3, E ? void 0 : e3];
        }, [y2, E, h2]), C = (0, n.useCallback)(async () => {
          var e3;
          if (!(null == w2 ? void 0 : w2.current)) return;
          S({ actionType: i.X2.SaveSlide });
          let t3 = b(), a3 = await m(w2.current);
          null == (e3 = window.desktopEvents) || e3.send(u.EE.SAVE_FILE_TO_LOCAL_DISK, t3, await a3.arrayBuffer());
        }, [w2, S]), j = (0, n.useCallback)(async () => {
          if (!(null == w2 ? void 0 : w2.current)) return;
          S({ actionType: i.X2.SaveSlide });
          let e3 = await m(w2.current), t3 = b();
          navigator.share({ files: [new File([e3], t3, { type: "image/png" })], text: t3 });
        }, [w2, S]);
        return (null == (t2 = navigator) ? void 0 : t2.share) ? (0, l.jsx)("div", {
          className: p,
          style: k,
          children: (0, l.jsxs)(d.W1, {
            ariaLabel: g({ id: "interface-actions.context-menu" }),
            className: (0, r.$)(f().root, x().root, v2),
            color: "secondary",
            isMobile: E,
            label: a2,
            placement: "right",
            radius: "xxxl",
            role: "button",
            size: "default",
            style: _,
            children: [
              (0, l.jsx)(d.Dr, {
                icon: (0, l.jsx)(c.Icon, { variant: "download", size: "xxs" }),
                onClick: C,
                children: g({ id: "rewind.download-image" })
              }),
              (0, l.jsx)(d.Dr, {
                icon: (0, l.jsx)(c.Icon, { variant: "more", size: "xxs" }),
                onClick: j,
                children: g({ id: "interface-actions.more" })
              })
            ]
          })
        }) : (0, l.jsx)(s.$, {
          className: (0, r.$)(f().root, x().root, v2),
          color: "secondary",
          onClick: C,
          radius: "xxxl",
          role: "button",
          size: "default",
          style: _,
          withHover: false,
          children: a2
        });
      };
    },
    77602: (e) => {
      e.exports = { root: "ShareButton_root__fGsNv" };
    }
  }
]);
