(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7533],
  {
    7533: (e, i, t) => {
      "use strict";
      t.r(i), t.d(i, { VibeFallbackAnimation: () => m, VibeFallbackAnimationComponent: () => d });
      var n = t(54486), a = t(50420), r = t(28303), o = t(61910), l = t(31500), _ = t(74125), c = t(49124);
      let s = (e2, i2) => {
        let t2 = c.env.ASSET_PREFIX || "";
        return "".concat(t2, "/media/vibe_animation_fallback/vibe_animation_fallback_").concat(e2, ".").concat(i2);
      };
      var v = t(68290), b = t.n(v);
      let d = (0, r.PA)((e2) => {
        var i2, t2;
        let { forwardRef: r2, className: c2 } = e2, v2 = (0, o.useRef)(null), { theme: d2 } = (0, _.DPo)(), { sonataState: m2 } = (0, _.Pjs)(), u = m2.isPlaying && m2.isVibeContext;
        (0, o.useEffect)(() => {
          var e3, i3, t3;
          let n2 = null != (t3 = null == (i3 = m2.entityMeta) || null == (e3 = i3.trackParameters) ? void 0 : e3.energy) ? t3 : 1;
          v2.current && (v2.current.playbackRate = u ? Math.max(1.5 * n2, 1) : 0.8);
        }, [u, null == (t2 = m2.entityMeta) || null == (i2 = t2.trackParameters) ? void 0 : i2.energy]);
        let f = (0, o.useMemo)(
          () => ((e3) => {
            if (e3) return { posterSrc: s(e3, "jpeg"), videoSrc: s(e3, "mp4") };
          })(d2),
          [d2]
        );
        return (0, n.jsxs)("div", {
          ref: r2,
          className: (0, a.$)(b().root, b().root_visible, c2),
          ...(0, l.Am)(l.Kq.vibeAnimation.VIBE_ANIMATION),
          children: [
            (0, n.jsx)("video", {
              ref: v2,
              preload: "metadata",
              loop: true,
              autoPlay: true,
              muted: true,
              playsInline: true,
              disablePictureInPicture: true,
              width: 1e3,
              height: 1e3,
              src: null == f ? void 0 : f.videoSrc,
              poster: null == f ? void 0 : f.posterSrc
            }),
            (0, n.jsx)("div", {})
          ]
        });
      }), m = (0, o.forwardRef)((e2, i2) => (0, n.jsx)(d, { forwardRef: i2, ...e2 }));
    },
    68290: (e) => {
      e.exports = {
        root: "VibeAnimation_root__UKMJy",
        root_visible: "VibeAnimation_root_visible__S7kXl",
        enter: "VibeAnimation_enter__c6tvj",
        enter_active: "VibeAnimation_enter_active__j0jOl",
        enter_done: "VibeAnimation_enter_done__Oi2Kz",
        exit: "VibeAnimation_exit__ioGXk",
        exit_active: "VibeAnimation_exit_active__D94vP",
        exit_done: "VibeAnimation_exit_done__LDXSJ"
      };
    }
  }
]);
