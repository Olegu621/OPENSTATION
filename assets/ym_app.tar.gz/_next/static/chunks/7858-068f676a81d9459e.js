(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3909, 7858],
  {
    3283: (e, t, i) => {
      "use strict";
      i.d(t, { PlaylistsCarousel: () => d });
      var a = i(54486), r = i(61910), n = i(43350), l = i(74125), s = i(80585), o = i(45318);
      let c = (e2) => {
        let {
          forwardRef: t2,
          isShimmerVisible: i2,
          isShimmerActive: r2,
          title: c2,
          description: d2,
          playlists: u,
          containerClassName: _,
          className: g,
          headerClassName: m,
          viewAllActionLink: p,
          headingVariant: y,
          ...v
        } = e2;
        return (0, a.jsx)(s.OY, {
          isShimmerVisible: i2,
          isShimmerActive: r2,
          className: g,
          headerClassName: m,
          containerClassName: _,
          ref: t2,
          title: c2,
          description: d2,
          viewAllActionLink: p,
          headingVariant: y,
          ...v,
          children: null == u ? void 0 : u.map(
            (e3, t3) => (0, a.jsx)(
              l.Bki,
              {
                objectType: n.ky.Playlist,
                objectId: e3.id,
                objectPosX: t3 + 1,
                objectPosY: 1,
                objectsCount: u.length,
                children: (0, a.jsx)(o.PlaylistCard, { playlist: e3, contentLinesCount: 3 })
              },
              e3.key
            )
          )
        });
      }, d = (0, r.forwardRef)((e2, t2) => (0, a.jsx)(c, { forwardRef: t2, ...e2 }));
    },
    5065: (e, t, i) => {
      "use strict";
      i.d(t, { SearchVibeCard: () => C });
      var a = i(54486), r = i(50420), n = i(28303), l = i(61910), s = i(31500), o = i(8817), c = i(73633), d = i(97800), u = i(74125), _ = i(80585), g = i(69673), m = i(55639), p = i(67075), y = i(42783), v = i.n(y);
      let C = (0, n.PA)((e2) => {
        let {
          className: t2,
          vibe: i2,
          cover: n2,
          coverClassName: y2,
          playButtonIconSize: C2,
          description: b,
          agentVariant: h
        } = e2, { ref: x, intersectionPropertyId: k } = (0, u.nMI)(), { pageId: P } = (0, u.$au)(), [A, f] = (0, l.useState)(false), { blockIdForFrom: j } = (0, u.N8n)(), { isFreemium: w } = (0, u.XCI)(), { sendPlaySearchFeedback: I } = (0, u.zEv)(), L = (0, u.brA)(), [N, B] = (0, l.useState)(false), T = (0, u.PT7)(), {
          isPlaying: K,
          togglePlay: V,
          isCurrent: S
        } = (0, u.B0S)({ seeds: i2.seeds, pageIdForFrom: P, blockIdForFrom: j }), E = (0, o.c)(() => {
          if (!T()) {
            if (w) return void B(true);
            A || K || (f(true), null == I || I()), V(), L(!K);
          }
        }), z = (0, o.c)(() => {
          K || E();
        }), R = (0, o.c)((e3) => {
          2 === e3.detail ? z() : (0, c.P)(e3, _.$f.ripple);
        }), U = (0, l.useCallback)(() => {
          if (i2.shouldShowAgent && i2.agent && h)
            switch (h) {
              case g.h.LARGE:
                return (0, a.jsxs)("div", {
                  className: (0, r.$)(v().root, _.$f.playButtonCell, y2),
                  children: [
                    (0, a.jsx)(m.VibeCardView, { agent: i2.agent, isPlaying: K }),
                    (0, a.jsx)(_.DM, {
                      variant: "filled",
                      className: v().playButton,
                      iconClassName: v().playButtonIcon,
                      isPlaying: K,
                      onClick: E,
                      iconSize: "m"
                    })
                  ]
                });
              case g.h.SMALL:
                return (0, a.jsx)(p.n, {
                  agent: i2.agent,
                  isPlaying: K,
                  isCurrent: S,
                  onPlayButtonClick: E,
                  alt: "".concat(b, " ").concat(i2.title),
                  className: (0, r.$)(_.$f.playButtonCell, y2)
                });
            }
          return (0, a.jsx)(_.q1, {
            isAvailable: true,
            coverUri: null == n2 ? void 0 : n2.uri,
            title: i2.title,
            className: (0, r.$)(_.$f.playButtonCell, y2),
            entityCoverStyle: { backgroundColor: null == n2 ? void 0 : n2.color },
            radius: "round",
            onPlayButtonClick: E,
            isPlaying: K,
            isCurrent: S,
            playButtonIconSize: C2,
            alt: "".concat(b, " ").concat(i2.title)
          });
        }, [
          h,
          null == n2 ? void 0 : n2.color,
          null == n2 ? void 0 : n2.uri,
          y2,
          b,
          E,
          S,
          K,
          C2,
          i2.agent,
          i2.shouldShowAgent,
          i2.title
        ]);
        return (0, a.jsxs)(_.Cj, {
          ref: x,
          "data-intersection-property-id": k,
          className: (0, r.$)(_.$f.root, t2),
          "aria-label": i2.title,
          onClick: R,
          ...(0, s.Am)(s.OA.vibe.SEARCH_VIBE_CARD),
          children: [
            (0, a.jsx)(_.SU, {
              isOpened: N,
              onOpenChange: B,
              isEnabled: w,
              placement: "bottom",
              textVariant: "vibe",
              vibeTextVariant: i2.stationType,
              renderChildren: U
            }),
            (0, a.jsx)(_.ro, {
              title: (0, a.jsx)(d.Caption, {
                className: (0, r.$)(_.$f.text, _.$f.titleText),
                size: "m",
                variant: "div",
                type: "text",
                children: i2.title
              }),
              description: b
            })
          ]
        });
      });
    },
    7317: (e) => {
      e.exports = {
        root: "VibeCardView_root__bt_Xt",
        root_loading: "VibeCardView_root_loading__J8fOe",
        cover: "VibeCardView_cover__fBDH_",
        cover_round: "VibeCardView_cover_round__LPs63",
        cover_loading: "VibeCardView_cover_loading__kpdrp",
        shimmer: "VibeCardView_shimmer__Rp6yh",
        shimmer_loading: "VibeCardView_shimmer_loading__74dZm",
        animation: "VibeCardView_animation__x3VEI",
        image: "VibeCardView_image__5fXOh"
      };
    },
    14148: (e, t, i) => {
      "use strict";
      var a;
      i.d(t, { h: () => a }), (function(e2) {
        e2.ALBUM = "album", e2.PLAYLIST = "playlist", e2.TRACK = "track", e2.ARTIST = "artist";
      })(a || (a = {}));
    },
    20875: (e, t, i) => {
      "use strict";
      i.d(t, { useOnPinClick: () => b });
      var a = i(54486), r = i(63930), n = i(61910), l = i(43426), s = i(60049), o = i(74125), c = i(80585), d = i(28303), u = i(31500), _ = i(27510), g = i(58360), m = i(67075), p = i(96957), y = i.n(p);
      let v = (0, d.PA)((e2) => {
        let { vibe: t2, closeToast: i2 } = e2, { experiments: r2 } = (0, o.Pjs)(), n2 = r2.checkExperiment(o.zal.WebNextWaveAgentExperiment, "on"), l2 = (0, _.L)(() => {
          var e3;
          return n2 && t2.agent ? (0, a.jsx)(m.n, { agent: t2.agent, shouldShowControl: false, className: y().view }) : (0, a.jsx)(g.Image, {
            className: y().image,
            src: t2.backgroundImageUrl,
            size: 100,
            fit: "cover",
            withAvatarReplace: true,
            "aria-hidden": true,
            style: { backgroundColor: null == (e3 = t2.colors) ? void 0 : e3.average },
            withLoadingIndicator: false,
            ...(0, u.Am)(u.S7.BASE_NOTIFICATION_PIN_VIBE_COVER)
          });
        }), s2 = n2 && t2.agent ? void 0 : "round";
        return (0, a.jsx)(c.k4, {
          closeToast: i2,
          entityVariant: c.cp.VIBE,
          entityTitle: t2.title,
          entityDescription: t2.getDescription(),
          isPinned: t2.isPinned,
          customCover: l2,
          radius: s2,
          className: y().root
        });
      });
      var C = i(35248);
      let b = (e2) => {
        let { user: t2, pinsCollection: i2 } = (0, o.Pjs)(), { notify: d2 } = (0, o.lkh)(), { formatMessage: u2 } = (0, l.A)(), [_2, g2] = (0, n.useState)(false);
        return (0, n.useCallback)(async () => {
          if (!e2) return;
          if (!t2.isAuthorized)
            return void d2((0, a.jsx)(c.hT, { error: u2({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: o.uQT.ERROR
            });
          if (_2) return;
          let n2 = { ...(0, r.HO)(e2), isPinned: !e2.isPinned, getDescription: e2.getDescription }, l2 = i2.get(e2.pinId);
          g2(true);
          let m2 = await e2.togglePin();
          g2(false), l2 && l2.type === s._.WAVE_ITEM && l2.data.backgroundImageUrl && (n2.backgroundImageUrl = l2.data.backgroundImageUrl, n2.colors = l2.data.colors, n2.agent = l2.data.agent), m2 && "object" == typeof m2 && "data" in m2 && (m2.data.backgroundImageUrl && (n2.backgroundImageUrl = m2.data.backgroundImageUrl), m2.data.colors && (n2.colors = { average: m2.data.colors.average, waveText: m2.data.colors.waveText }), m2.data.agent && (n2.agent = (0, C.K)(m2.data.agent))), m2 ? d2((0, a.jsx)(v, { vibe: n2 }), { containerId: o.uQT.INFO }) : d2((0, a.jsx)(c.hT, { error: u2({ id: "error-messages.error-during-action" }) }), {
            containerId: o.uQT.ERROR
          });
        }, [u2, d2, _2, i2, t2.isAuthorized, e2]);
      };
    },
    23265: (e, t, i) => {
      "use strict";
      i.d(t, { r: () => n });
      var a = i(61910), r = i(43426);
      let n = (e2) => {
        let { formatMessage: t2 } = (0, r.A)();
        return (0, a.useMemo)(() => {
          let i2 = "";
          e2.isLiked && !e2.actualLikesCount ? i2 = t2({ id: "entity-names.has-your-like" }) : "number" == typeof e2.actualLikesCount && (i2 = e2.actualLikesCount > 0 ? t2({ id: "entity-names.likes-counter" }, { counter: e2.actualLikesCount }) : t2({ id: "entity-names.likes-counter-empty" }));
          let a2 = t2({ id: "entity-names.playlist-name" }, { playlistName: e2.title });
          return "".concat(a2, " ").concat(i2);
        }, [t2, e2]);
      };
    },
    25325: (e) => {
      e.exports = {
        description: "HorizontalPlaylistCard_description__KYHZF",
        likesCount: "HorizontalPlaylistCard_likesCount__rgUhr",
        tracksCount: "HorizontalPlaylistCard_tracksCount__ZdjzM",
        icon: "HorizontalPlaylistCard_icon__LHymu"
      };
    },
    29443: (e, t, i) => {
      "use strict";
      i.d(t, { VibeAgentCard: () => v });
      var a = i(54486), r = i(50420), n = i(28303), l = i(61910), s = i(31500), o = i(27510), c = i(71712), d = i(97800), u = i(74125), _ = i(80585), g = i(20875), m = i(55639), p = i(97569), y = i.n(p);
      let v = (0, n.PA)((e2) => {
        let {
          vibe: t2,
          shouldShowPlayButton: i2 = true,
          shouldShowAdditionals: n2 = true,
          additionalsLinesCount: p2 = 3,
          className: v2
        } = e2, { pageId: C } = (0, u.$au)(), { blockIdForFrom: b } = (0, u.N8n)(), { ref: h, intersectionPropertyId: x } = (0, u.nMI)(), { isFreemium: k } = (0, u.XCI)(), [P, A] = (0, l.useState)(false), f = (0, g.useOnPinClick)(t2), { isPlaying: j, togglePlay: w } = (0, u.B0S)({ seeds: t2.seeds, pageIdForFrom: C, blockIdForFrom: b }), I = (0, u.brA)(), L = (0, l.useCallback)(() => {
          k || (w(), I(!j));
        }, [k, w, I, j]), N = (0, l.useCallback)(
          () => (0, a.jsx)(
            _.DM,
            {
              className: (0, r.$)(y().playButton, y().control),
              buttonVariant: "default",
              withHover: false,
              iconSize: "xl",
              variant: "filled",
              onClick: L,
              isPlaying: j
            },
            t2.getKey("PlayButton")
          ),
          [t2, L, j]
        ), B = (0, o.L)(
          () => (0, a.jsx)(_.SU, {
            isEnabled: k,
            isOpened: P,
            onOpenChange: A,
            placement: "top",
            textVariant: "vibe",
            vibeTextVariant: t2.stationType,
            renderChildren: N
          })
        ), T = (0, o.L)(
          () => (0, a.jsx)(
            _.O0,
            { onClick: f, isPinned: t2.isPinned, className: (0, r.$)(y().pinButton, y().control), withRipple: false },
            t2.getKey("PinButton")
          )
        ), K = (0, o.L)(
          () => (0, a.jsxs)("div", {
            className: y().cover,
            onClick: L,
            children: [
              t2.agent && (0, a.jsx)(m.VibeCardView, { agent: t2.agent, isPlaying: j }),
              (0, a.jsx)(c.hg, { isVisible: P, className: y().controls, playControl: i2 ? B : void 0, pinControl: T })
            ]
          })
        );
        return (0, a.jsx)(c.MN, {
          ref: h,
          className: (0, r.$)(y().root, v2),
          "data-intersection-property-id": x,
          contentLinesCount: p2,
          view: K,
          textPosition: "center",
          wrapperClassName: (0, r.$)({ [y().additionals_hide]: !n2 }),
          title: (0, a.jsx)(d.Caption, {
            variant: "div",
            type: "entity",
            size: "s",
            weight: "medium",
            lineClamp: 2,
            children: t2.title
          }),
          description: (0, a.jsx)(d.Caption, {
            variant: "div",
            type: "entity",
            size: "s",
            weight: "medium",
            lineClamp: 1,
            children: t2.description
          }),
          ...(0, s.Am)(s.OA.vibe.VIBE_AGENT_CARD)
        });
      });
    },
    29717: (e, t, i) => {
      "use strict";
      i.d(t, { VibeButton: () => x, VibeButtonShimmer: () => h });
      var a = i(54486), r = i(50420), n = i(28303), l = i(61910), s = i(43426), o = i(31500), c = i(62443), d = i(73633), u = i(77881), _ = i(5956), g = i(58360), m = i(22674), p = i(97800), y = i(74125), v = i(80585), C = i(97811), b = i.n(C);
      let h = (e2) => {
        let { isActive: t2, className: i2 } = e2;
        return (0, a.jsx)(m.Shimmer, { isActive: t2, className: (0, r.$)(b().root, i2) });
      }, x = (0, n.PA)((e2) => {
        let { className: t2, vibe: i2 } = e2, { formatMessage: n2 } = (0, s.A)(), { pageId: m2 } = (0, y.$au)(), { blockIdForFrom: C2 } = (0, y.N8n)(), { ref: h2, intersectionPropertyId: x2 } = (0, y.nMI)(), { toggleTrue: k, toggleFalse: P, state: A } = (0, c.e)(false), { isFreemium: f } = (0, y.XCI)(), j = i2.title.length > 26, { isPlaying: w, togglePlay: I } = (0, y.B0S)({ seeds: i2.seeds, pageIdForFrom: m2, blockIdForFrom: C2 }), L = (0, y.brA)(), N = (0, l.useCallback)(
          (e3) => {
            f || ((0, d.P)(e3, b().ripple), k(), I().finally(() => {
              P(), L(!w);
            }));
          },
          [P, k, I, w, L, f]
        ), B = (0, l.useMemo)(() => {
          var e3, t3;
          return {
            "--vibe-button-background": null == (e3 = i2.colors) ? void 0 : e3.average,
            "--vibe-button-text-color": null == (t3 = i2.colors) ? void 0 : t3.waveText
          };
        }, [i2.colors]), T = w ? "pause" : "play", K = w ? o.e8.landing.VIBE_DISCOVERY_ITEM_PAUSE_ICON : o.e8.landing.VIBE_DISCOVERY_ITEM_PLAY_ICON, V = (0, l.useCallback)(
          () => (0, a.jsxs)(u.$, {
            style: B,
            withRipple: false,
            withHover: false,
            variant: "text",
            onClick: N,
            className: (0, r.$)(b().root, b().button, { [b().button_loading]: A }, t2),
            "data-intersection-property-id": x2,
            ref: h2,
            ...(0, o.Am)(o.e8.landing.VIBE_DISCOVERY_ITEM),
            children: [
              (0, a.jsx)(g.Image, {
                className: b().image,
                withAvatarReplace: true,
                withFallback: false,
                src: i2.backgroundImageUrl,
                withAspectRatio: true,
                size: 400,
                fit: "cover"
              }),
              (0, a.jsxs)("span", {
                className: b().textContainer,
                children: [
                  (0, a.jsx)(p.Caption, {
                    className: b().subtitle,
                    variant: "span",
                    type: "controls",
                    size: "s",
                    weight: "bold",
                    children: i2.getDescription(n2({ id: "entity-names.my-vibe" }))
                  }),
                  (0, a.jsxs)(p.Caption, {
                    className: (0, r.$)(b().title, { [b().title_long]: j }),
                    variant: "span",
                    size: "s",
                    weight: "bold",
                    lineClamp: 2,
                    children: [
                      (0, a.jsx)(_.Icon, { className: b().icon, size: "xxs", variant: T, ...(0, o.Am)(K) }),
                      i2.title
                    ]
                  })
                ]
              })
            ]
          }),
          [t2, n2, N, K, T, x2, j, A, h2, B, i2]
        );
        return (0, a.jsx)(v.SU, {
          isEnabled: f,
          placement: "top",
          textVariant: "vibe",
          vibeTextVariant: i2.stationType,
          renderChildren: V
        });
      });
    },
    35248: (e, t, i) => {
      "use strict";
      i.d(t, { K: () => r });
      var a = i(74125);
      let r = (e2) => {
        var t2;
        if (e2)
          return {
            animationUri: e2.animationUri,
            cover: (0, a.pX4)(e2.cover),
            entityType: null == (t2 = e2.entity) ? void 0 : t2.type
          };
      };
    },
    42783: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "SearchVibeCard_root__9otOP",
        playButton: "SearchVibeCard_playButton__ZNWNz",
        playButtonIcon: "SearchVibeCard_playButtonIcon__GJrNv"
      };
    },
    45318: (e, t, i) => {
      "use strict";
      i.d(t, { PlaylistCard: () => w });
      var a = i(54486), r = i(50420), n = i(28303), l = i(61910), s = i(43426), o = i(43350), c = i(31500), d = i(63585), u = i(8817), _ = i(27510), g = i(71712), m = i(5956), p = i(6971), y = i(97800), v = i(63695), C = i(13611), b = i(74125), h = i(80585), x = i(23265), k = i(61958), P = i(83504);
      let A = (0, n.PA)((e2) => {
        var t2;
        let { playlist: i2, onOpenChange: r2, open: n2, ...l2 } = e2, { shouldShowBuySubscriptionModal: d2, showBuySubscriptionModal: _2 } = (0, b.qBP)(), {
          experiments: g2,
          settings: { isMobile: m2 },
          trailer: p2,
          user: y2
        } = (0, b.Pjs)(), v2 = (0, C.KX)(i2), x2 = (0, C.A7)(i2), A2 = (0, b.Ftl)(), { formatMessage: f2 } = (0, s.A)(), j2 = (0, b.PT7)(), w2 = g2.checkExperiment(b.zal.WebEditorsFeatures, "on"), I = (0, P.A_)({ entityVariant: b.DwC.PLAYLIST, urlParams: { id: i2.uid, kind: i2.kind } });
        (0, b.NBO)(n2);
        let L = (0, u.c)(() => {
          if (d2) return void _2();
          j2() || (p2.openPlaylistTrailer(i2.id), A2(o.ky.Playlist, i2.id));
        });
        return (0, a.jsxs)(k.W1, {
          title: i2.title,
          onOpenChange: r2,
          open: n2,
          offsetOptions: 10,
          isMobile: m2,
          ariaLabel: f2({ id: "interface-actions.context-menu" }),
          containerProps: (0, c.Am)(c.Kq.playlist.PLAYLIST_CONTEXT_MENU),
          ...l2,
          children: [
            w2 && (0, a.jsx)(P.dx, { entityVariant: b.DwC.PLAYLIST, adminUrl: i2.isFavouritePlaylist ? void 0 : I }),
            !m2 && (0, a.jsx)(h.L1, { onClick: x2, isPinned: i2.isPinned }),
            !i2.isFavouritePlaylist && (0, a.jsx)(h.TW, { onClick: v2, isLiked: i2.isLiked, disabled: !y2.isAuthorized }),
            (null == (t2 = i2.trailer) ? void 0 : t2.isAvailable) && (0, a.jsx)(h.No, { onClick: L, disabled: !i2.isAvailable })
          ]
        });
      });
      var f = i(57333), j = i.n(f);
      let w = (0, n.PA)((e2) => {
        let { className: t2, playlist: i2, children: n2, contentLinesCount: k2, customDescription: P2 } = e2, { ref: f2, intersectionPropertyId: w2 } = (0, b.nMI)(), { trailer: I, user: L } = (0, b.Pjs)(), { from: N, utmLink: B } = (0, b.fyy)({ contextId: i2.uuid, contextType: d.K.Playlist }), { formatMessage: T } = (0, s.A)(), { sendLikeSearchFeedback: K, sendNavigateSearchFeedback: V, sendPlaySearchFeedback: S } = (0, b.zEv)(), [E, z] = (0, l.useState)(false), [R, U] = (0, l.useState)(false), [O, $] = (0, l.useState)(false), M = (0, x.r)(i2), F = (0, C.KX)(i2), D = (0, C.A7)(i2), Y = (0, b.NKK)(), H = (0, b.brA)(), X = (0, b.ZpR)(i2.url), Z = (0, b.Ftl)(), W = (0, b.PT7)(), q = (0, u.c)((e3) => {
          if (e3.stopPropagation(), W()) return void e3.preventDefault();
          I.setUtmLink(B), I.openPlaylistTrailer(i2.id), Z(o.ky.Playlist, i2.id);
        }), [Q, G] = (0, l.useState)(false), { isPlaying: J, togglePlay: ee } = (0, b.Dx4)({
          playContextParams: {
            contextData: { type: d.K.Playlist, meta: { id: i2.id, uuid: i2.uuid }, from: N, utmLink: B },
            loadContextMeta: true
          }
        }), et = (0, u.c)(() => {
          Y({ to: o.QT.PlaylistScreen }), null == V || V();
        }), ei = (0, u.c)((e3) => {
          et(), X(e3);
        }), ea = (0, u.c)(() => {
          W() || (E || J || (z(true), null == S || S()), ee(), H(!J));
        }), er = (0, u.c)(() => {
          R || i2.isLiked || (U(true), null == K || K()), F();
        }), en = (0, u.c)((e3) => {
          e3.preventDefault(), e3.stopPropagation();
        }), el = (0, u.c)((e3) => {
          $(e3), G(e3);
        }), es = (0, l.useMemo)(() => {
          var e3;
          return P2 ? (0, a.jsx)(
            y.Caption,
            { variant: "span", type: "entity", size: "s", weight: "medium", lineClamp: 2, children: P2 },
            i2.getKey("description")
          ) : (null == (e3 = i2.artists) ? void 0 : e3.length) ? (0, a.jsx)(
            v.iQ,
            {
              className: j().artists,
              artists: i2.artists,
              lineClamp: 1,
              linkClassName: j().artistLink,
              captionSize: "s"
            },
            i2.getKey("description")
          ) : void 0;
        }, [P2, i2]), eo = (0, _.L)(() => {
          if (!i2.isFavouritePlaylist)
            return (0, a.jsx)(
              h.cy,
              {
                className: (0, r.$)(j().likeButton, j().control),
                isLiked: i2.isLiked,
                onClick: er,
                variant: "default",
                size: "s",
                iconSize: "xxs",
                disabled: !L.isAuthorized
              },
              i2.getKey("LikeButton")
            );
        }), ec = (0, l.useMemo)(() => {
          var e3;
          if (null == i2 || null == (e3 = i2.trailer) ? void 0 : e3.isAvailable)
            return (0, a.jsx)(
              h.nE,
              {
                children: (0, a.jsx)(
                  h.kJ,
                  {
                    className: (0, r.$)(j().trailerButton, j().control),
                    radius: "round",
                    size: "s",
                    iconSize: "xxs",
                    onClick: q
                  },
                  i2.getKey("TrailerButton")
                )
              },
              i2.getKey("PlaylilstCardTrailerTooltip")
            );
        }, [q, i2]), ed = (0, l.useMemo)(
          () => (0, a.jsx)(
            h.O0,
            { onClick: D, isPinned: i2.isPinned, className: (0, r.$)(j().pinButton, j().control), withRipple: false },
            i2.getKey("PinButton")
          ),
          [D, i2]
        ), eu = (0, l.useMemo)(
          () => (0, a.jsx)(p.Paper, {
            className: j().cover,
            radius: "s",
            withShadow: true,
            ...(0, c.Am)(c.Kq.playlist.PLAYLIST_CARD),
            children: (0, a.jsxs)("div", {
              className: j().coverBlock,
              onClick: ei,
              children: [
                (0, a.jsx)(h.BW, {
                  className: j().image,
                  src: i2.coverUri,
                  size: 200,
                  fit: "cover",
                  alt: M,
                  withAvatarReplace: true,
                  "aria-hidden": true
                }),
                (0, a.jsx)(g.hg, {
                  isVisible: O || Q,
                  className: j().controls,
                  playControl: (0, a.jsx)(
                    h.DM,
                    {
                      className: (0, r.$)(j().playButton, j().control),
                      buttonVariant: "default",
                      withHover: false,
                      iconSize: "xl",
                      variant: "filled",
                      onClick: ea,
                      isPlaying: J,
                      disabled: !i2.isAvailable
                    },
                    i2.getKey("PlayButton")
                  ),
                  likeControl: eo,
                  menuControl: (0, a.jsx)(
                    A,
                    {
                      playlist: i2,
                      onOpenChange: el,
                      open: O,
                      onClick: en,
                      className: (0, r.$)(j().menuButton, j().control),
                      icon: (0, a.jsx)(m.Icon, { size: "xxs", variant: "more" }),
                      size: "s",
                      ...(0, c.Am)(c.Kq.playlist.PLAYLIST_CONTEXT_MENU_BUTTON)
                    },
                    i2.getKey("PlaylistContextMenu")
                  ),
                  pinControl: ed,
                  trailerControl: ec
                })
              ]
            })
          }),
          [ei, i2, M, O, Q, ea, J, eo, el, en, ed, ec]
        ), e_ = !!i2.actualLikesCount && !i2.isLikesCountHidden;
        return (0, a.jsxs)(g.MN, {
          ref: f2,
          "aria-label": M,
          className: (0, r.$)(j().root, t2),
          title: (0, a.jsx)(y.Caption, {
            variant: "div",
            type: "entity",
            size: "s",
            weight: "medium",
            lineClamp: 2,
            ...(0, c.Am)(c.Kq.playlist.PLAYLIST_TITLE),
            children: (0, a.jsx)(h.N_, { className: j().titleLink, href: i2.url, onClick: et, children: i2.title })
          }),
          srTitle: (0, a.jsx)(h.N_, { href: i2.url, onClick: et, children: i2.title }),
          "data-intersection-property-id": w2,
          contentLinesCount: k2,
          view: eu,
          description: es,
          ...(0, c.Am)(c.Kq.playlist.PLAYLIST_ITEM),
          children: [
            e_ && (0, a.jsx)(h.xW, {
              ariaLabel: T({ id: "entity-names.likes-counter" }, { counter: i2.actualLikesCount }),
              likesCount: i2.actualLikesCount,
              isLiked: i2.isLiked,
              handleLikeClick: F
            }),
            n2
          ]
        });
      });
    },
    46121: (e) => {
      e.exports = {
        root: "VibeSmallView_root__6IYFM",
        root_radius_xs: "VibeSmallView_root_radius_xs__hrEG3",
        root_radius_round: "VibeSmallView_root_radius_round__t4uAR",
        root_withShadow: "VibeSmallView_root_withShadow__HU7NP"
      };
    },
    47719: (e, t, i) => {
      "use strict";
      var a;
      i.d(t, { y: () => a }), (a || (a = {})).MIX = "MIX";
    },
    55639: (e, t, i) => {
      "use strict";
      i.d(t, { VibeCardView: () => k });
      var a = i(54486), r = i(38974), n = i(57249), l = i(50420), s = i(28303), o = i(83645), c = i(61910), d = i(14148), u = i(8817), _ = i(27510), g = i(62443), m = i(58360), p = i(22674), y = i(74125);
      let v = (e2) => Math.max(0, Math.min(100, e2)) / 100;
      var C = i(7317), b = i.n(C), h = i(49124);
      let x = o.default.default(
        () => Promise.resolve().then(i.bind(i, 38974)).then((e2) => e2.DotLottieWorkerReact),
        { ssr: false }
      );
      {
        let e2 = h.env.USE_CDN_FOR_STATIC ? "https://yastatic-net.ru/s3/music-frontend-static/music/vundefined" : window.location.origin;
        (0, r.setWasmUrl)(new URL(n, e2).href);
      }
      let k = (0, s.PA)((e2) => {
        let { agent: t2, isPlaying: i2 } = e2, [r2, n2] = (0, c.useState)(null), { state: s2, toggleTrue: o2 } = (0, g.e)(false), { state: C2, toggleTrue: h2, toggleFalse: k2 } = (0, g.e)(false), { theme: P } = (0, y.DPo)(), A = (0, c.useRef)(null), f = t2.entityType === d.h.ARTIST, j = t2.cover.color, w = t2.cover.uri, I = (0, u.c)(async () => {
          if (s2 && j && P) {
            k2();
            let {
              color: e3,
              glow1: i3,
              glow2: a2,
              mask: n3
            } = ((e4) => {
              let { averageColor: t3, theme: i4, custom: a3 } = e4, { h: r3, s: n4, l: l3 } = (0, y.g8k)(t3), s3 = l3, o3 = [0, 0, 0];
              a3 ? (i4 === y.Sxu.Dark || (s3 += 79), o3 = (0, y.YLU)(r3, v(n4), v(s3))) : o3 = (0, y.YLU)(
                r3,
                (n4 > 25 ? Math.min(n4 + 25, 60) : n4) / 100,
                (s3 > 20 ? Math.min(s3 + 15, 60) : s3) / 100
              );
              let c2 = i4 === y.Sxu.Dark ? [0.07, 0.07, 0.07] : [0.96, 0.96, 0.96];
              return {
                color: o3,
                glow1: i4 === y.Sxu.Dark ? (0, y.YLU)(r3, v(n4), v(s3 + 36)) : (0, y.YLU)(r3, v(n4), v(s3 - 29)),
                glow2: i4 === y.Sxu.Dark ? (0, y.YLU)(r3, v(n4), v(s3 + 79)) : (0, y.YLU)(r3, v(n4), v(s3 - 53)),
                mask: c2
              };
            })({ averageColor: j, theme: P, custom: !t2.entityType }), l2 = JSON.stringify({
              rules: [
                { id: "color", type: "Color", value: e3 },
                { id: "glow_1", type: "Color", value: i3 },
                { id: "glow_2", type: "Color", value: a2 },
                { id: "mask", type: "Color", value: n3 }
              ]
            });
            await (null == r2 ? void 0 : r2.setThemeData(l2)), h2();
          }
        }), L = (0, u.c)(() => {
          o2(), I();
        });
        (0, c.useEffect)(() => {
          i2 ? null == r2 || r2.play() : null == r2 || r2.pause();
        }, [r2, i2]), (0, c.useEffect)(() => {
          I();
        }, [j, I, P, s2]), (0, c.useEffect)(() => {
          if (r2)
            return r2.setUseFrameInterpolation(false), r2.setRenderConfig({ devicePixelRatio: 0.1 }), r2.addEventListener("load", L), () => {
              r2.removeEventListener("load", L);
            };
        }, [r2, L]);
        let N = !s2 || !C2, B = (0, _.L)(() => {
          if (!A.current) return;
          let e3 = f ? 0.029 : 0.036;
          return { "--blur-size": "".concat(A.current.clientWidth * e3, "px") };
        });
        return (0, a.jsxs)("div", {
          ref: A,
          className: (0, l.$)(b().root, { [b().root_loading]: N }),
          style: B,
          children: [
            (0, a.jsxs)("div", {
              className: (0, l.$)(b().cover, { [b().cover_round]: f, [b().cover_loading]: N }),
              children: [
                t2.entityType && w && (0, a.jsx)(m.Image, {
                  src: w,
                  size: 200,
                  fit: "cover",
                  withAvatarReplace: true,
                  className: b().image,
                  withLoadingIndicator: false
                }),
                (0, a.jsx)(x, { src: t2.animationUri, loop: true, dotLottieRefCallback: n2, className: b().animation })
              ]
            }),
            (0, a.jsx)(p.Shimmer, {
              className: (0, l.$)(b().shimmer, { [b().shimmer_loading]: N }),
              isActive: true,
              radius: f ? "round" : "s"
            })
          ]
        });
      });
    },
    57333: (e) => {
      e.exports = {
        root: "PlaylistCard_root__i3pR4",
        controls: "PlaylistCard_controls__Ej8Rz",
        cover: "PlaylistCard_cover__tpK5L",
        coverBlock: "PlaylistCard_coverBlock__1slsN",
        image: "PlaylistCard_image__Li6oy",
        titleLink: "PlaylistCard_titleLink__H8qEc",
        artists: "PlaylistCard_artists__HtVIF",
        artistLink: "PlaylistCard_artistLink__jx3KB",
        playButton: "PlaylistCard_playButton__eaduk",
        likeButton: "PlaylistCard_likeButton__RYXJz",
        menuButton: "PlaylistCard_menuButton__jFcWr",
        pinButton: "PlaylistCard_pinButton__jhWnL",
        trailerButton: "PlaylistCard_trailerButton__Qjg_U",
        control: "PlaylistCard_control__73YUq"
      };
    },
    61352: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "ControlsBar_root__mf9o_",
        item: "ControlsBar_item__4YJMp",
        item_buttonArrow: "ControlsBar_item_buttonArrow__9hTqa",
        controls: "ControlsBar_controls__DcFpX",
        likeIcon: "ControlsBar_likeIcon__g8y02",
        trailerIcon: "ControlsBar_trailerIcon__iH6eY",
        controls_disabled: "ControlsBar_controls_disabled___hlf6"
      };
    },
    66894: (e, t, i) => {
      "use strict";
      i.d(t, { HorizontalPlaylistCard: () => f });
      var a = i(54486), r = i(50420), n = i(28303), l = i(61910), s = i(43426), o = i(47713), c = i(43350), d = i(31500), u = i(63585), _ = i(8817), g = i(73633), m = i(5956), p = i(97800), y = i(74125), v = i(80585), C = i(23265), b = i(13611), h = i(61352), x = i.n(h);
      let k = (0, n.PA)((e2) => {
        var t2;
        let { className: i2, playlist: n2, likeIconSize: s2 = "xxs" } = e2, { user: o2, trailer: d2 } = (0, y.Pjs)(), u2 = (0, y.PT7)(), { sendLikeSearchFeedback: g2 } = (0, y.zEv)(), p2 = (0, b.KX)(n2), [C2, h2] = (0, l.useState)(false), k2 = (0, _.c)(async () => {
          C2 || n2.isLiked || (h2(true), null == g2 || g2()), await p2();
        }), P2 = (0, y.Ftl)(), A2 = (0, _.c)((e3) => {
          if (e3.stopPropagation(), u2()) return void e3.preventDefault();
          d2.openPlaylistTrailer(n2.id), P2(c.ky.Playlist, n2.id);
        });
        return (0, a.jsxs)("div", {
          className: (0, r.$)(x().root, x().controls, i2, { [x().controls_disabled]: !n2.isAvailable }),
          children: [
            n2.isAvailable && (0, a.jsxs)(a.Fragment, {
              children: [
                (0, a.jsx)(v.aQ, {
                  fallback: (0, a.jsx)(v.cy, {
                    size: "xs",
                    iconSize: s2,
                    className: (0, r.$)(x().item, x().likeIcon),
                    isLiked: n2.isLiked,
                    onClick: k2,
                    disabled: !o2.isAuthorized
                  })
                }),
                (null == (t2 = n2.trailer) ? void 0 : t2.isAvailable) && (0, a.jsx)(v.aQ, {
                  fallback: (0, a.jsx)(v.kJ, {
                    className: (0, r.$)(x().item, x().trailerIcon),
                    iconSize: "xs",
                    variant: "text",
                    onClick: A2,
                    withRipple: false
                  })
                })
              ]
            }),
            (0, a.jsx)("div", {
              className: (0, r.$)(x().item, x().item_buttonArrow),
              children: (0, a.jsx)(m.Icon, { className: v.$f.buttonArrow, variant: "arrowRight", size: "xs" })
            })
          ]
        });
      });
      var P = i(25325), A = i.n(P);
      let f = (0, n.PA)((e2) => {
        let { className: t2, playlist: i2, pageId: n2, coverClassName: b2, playButtonIconSize: h2, likeIconSize: x2 } = e2, { ref: P2, intersectionPropertyId: f2 } = (0, y.nMI)(), { from: j } = (0, y.fyy)({ pageId: n2 }), [w, I] = (0, l.useState)(false), L = (0, y.brA)(), N = (0, C.r)(i2), B = i2.title || "", { formatMessage: T, formatNumber: K } = (0, s.A)(), V = (0, y.PT7)(), { sendNavigateSearchFeedback: S, sendPlaySearchFeedback: E } = (0, y.zEv)(), z = (0, y.NKK)(), {
          isPlaying: R,
          isCurrent: U,
          togglePlay: O
        } = (0, y.Dx4)({
          playContextParams: {
            contextData: { type: u.K.Playlist, meta: { id: i2.id, uuid: i2.uuid }, from: j },
            loadContextMeta: true
          }
        }), $ = (0, y.ZpR)(i2.url), M = (0, _.c)((e3) => {
          null == S || S(), z({ to: c.QT.PlaylistScreen }), e3.preventDefault(), $(e3);
        }), F = (0, _.c)(() => {
          V() || (w || R || (I(true), null == E || E()), O(), L(!R));
        }), D = (0, _.c)((e3) => {
          (0, g.P)(e3, v.$f.ripple), M(e3);
        }), Y = (0, _.c)((e3) => {
          e3.stopPropagation(), M(e3);
        }), H = (0, l.useCallback)(
          (e3) => (0, a.jsx)(v.q1, {
            isAvailable: i2.isAvailable,
            isDisliked: false,
            coverUri: i2.coverUri,
            title: B,
            className: (0, r.$)(v.$f.playButtonCell, b2),
            alt: T({ id: "entity-names.playlist-name" }, { playlistName: B }),
            radius: "xs",
            ...e3
          }),
          [i2, B, b2, T]
        ), X = null == H ? void 0 : H({ onPlayButtonClick: F, isPlaying: R, isCurrent: U, playButtonIconSize: h2 }), Z = (0, l.useMemo)(
          () => i2.url && i2.isAvailable ? (0, a.jsx)(v.N_, {
            className: (0, r.$)(v.$f.text, v.$f.titleLink),
            href: i2.url,
            onClick: Y,
            children: B
          }) : (0, a.jsx)(p.Caption, {
            className: (0, r.$)(v.$f.text, v.$f.titleText),
            size: "m",
            variant: "div",
            type: "text",
            children: B
          }),
          [Y, i2.isAvailable, i2.url, B]
        ), W = (0, l.useMemo)(() => {
          if (void 0 === i2.actualLikesCount || void 0 === i2.tracksCount) return;
          let e3 = (0, a.jsx)(p.Caption, {
            variant: "span",
            size: "m",
            weight: "medium",
            "aria-hidden": true,
            children: "•"
          }), t3 = i2.isLiked ? "likedVariant" : "likeVariant", r2 = "".concat(N, " ").concat(T({ id: "entity-names.tracks-count" }, { value: i2.tracksCount }));
          return (0, a.jsxs)("div", {
            className: A().description,
            "aria-label": r2,
            children: [
              (0, a.jsxs)("div", {
                className: A().likesCount,
                "aria-hidden": true,
                children: [
                  (0, a.jsx)(m.Icon, { className: A().icon, variant: t3, size: "xxs" }),
                  (0, a.jsx)(p.Caption, {
                    variant: "span",
                    size: "m",
                    weight: "medium",
                    children: K(i2.actualLikesCount)
                  })
                ]
              }),
              (0, a.jsxs)("div", {
                className: A().tracksCount,
                "aria-hidden": true,
                children: [
                  e3,
                  (0, a.jsx)(p.Caption, {
                    variant: "span",
                    size: "m",
                    weight: "medium",
                    children: (0, a.jsx)(o.A, {
                      id: "entity-names.tracks-count",
                      values: { value: K(i2.tracksCount) }
                    })
                  })
                ]
              })
            ]
          });
        }, [T, K, N, i2.actualLikesCount, i2.isLiked, i2.tracksCount]);
        return (0, a.jsxs)(v.Cj, {
          ref: P2,
          "data-intersection-property-id": f2,
          className: (0, r.$)(v.$f.root, { [v.$f.root_disabled]: !i2.isAvailable }, t2),
          "aria-label": i2.title || T({ id: "entity-names.playlist" }),
          onClick: D,
          ...(0, d.Am)(d.Kq.playlist.HORIZONTAL_PLAYLIST_CARD),
          children: [
            X,
            (0, a.jsx)(v.ro, { isDisabled: !i2.isAvailable, title: Z, description: W }),
            (0, a.jsx)(k, { playlist: i2, likeIconSize: x2 })
          ]
        });
      });
    },
    67075: (e, t, i) => {
      "use strict";
      i.d(t, { n: () => d });
      var a = i(54486), r = i(50420), n = i(14148), l = i(27510), s = i(80585), o = i(46121), c = i.n(o);
      let d = (e2) => {
        let {
          agent: t2,
          isPlaying: i2,
          isCurrent: o2,
          onPlayButtonClick: d2,
          shouldShowControl: u = true,
          playButtonIconSize: _,
          alt: g,
          className: m
        } = e2, p = (0, l.L)(() => {
          if (t2.entityType) return t2.entityType === n.h.ARTIST ? "round" : "xs";
        });
        return (0, a.jsx)(s.q1, {
          isAvailable: true,
          coverUri: t2.cover.uri,
          className: (0, r.$)(c().root, c()["root_radius_".concat(p)], { [c().root_withShadow]: !!t2.entityType }, m),
          radius: p,
          onPlayButtonClick: d2,
          isPlaying: i2,
          isCurrent: o2,
          alt: g,
          withLoadingIndicator: false,
          shouldShowControl: u,
          playButtonIconSize: _
        });
      };
    },
    67317: (e) => {
      e.exports = {
        root: "EmptyPlaylistBlock_root__wpA0j",
        iconBackground: "EmptyPlaylistBlock_iconBackground__pnUlz",
        title: "EmptyPlaylistBlock_title__pQQLf",
        subtitle: "EmptyPlaylistBlock_subtitle__P4Q7x"
      };
    },
    69673: (e, t, i) => {
      "use strict";
      i.d(t, { h: () => a });
      var a = (function(e2) {
        return e2.SMALL = "small", e2.LARGE = "large", e2;
      })({});
    },
    72467: (e, t, i) => {
      "use strict";
      i.d(t, { EmptyPlaylistBlock: () => _ });
      var a = i(54486), r = i(50420), n = i(61910), l = i(47713), s = i(31500), o = i(5956), c = i(97800), d = i(67317), u = i.n(d);
      let _ = (e2) => {
        let { className: t2, isEmptySearch: i2 } = e2, d2 = (0, n.useMemo)(
          () => i2 ? (0, a.jsx)(l.A, { id: "search-results.not-found-title" }) : (0, a.jsx)(l.A, { id: "error-messages.empty-collection-playlist-title" }),
          [i2]
        ), _2 = (0, n.useMemo)(
          () => i2 ? (0, a.jsx)(l.A, { id: "search-results.not-found-description" }) : (0, a.jsx)(l.A, { id: "error-messages.empty-collection-playlist-description" }),
          [i2]
        );
        return (0, a.jsxs)("div", {
          className: (0, r.$)(u().root, t2),
          ...(0, s.Am)(s.Kq.playlist.PLAYLIST_EMPTY_BLOCK),
          children: [
            (0, a.jsx)("div", {
              className: u().iconBackground,
              children: (0, a.jsx)(o.Icon, {
                variant: "search",
                size: "l",
                className: u().icon,
                ...(0, s.Am)(s.Kq.playlist.PLAYLIST_EMPTY_BLOCK_ICON)
              })
            }),
            (0, a.jsx)(c.Heading, {
              variant: "h3",
              size: "xs",
              className: u().title,
              ...(0, s.Am)(s.Kq.playlist.PLAYLIST_EMPTY_BLOCK_TITLE),
              children: d2
            }),
            (0, a.jsx)(c.Caption, {
              variant: "span",
              size: "l",
              className: u().subtitle,
              ...(0, s.Am)(s.Kq.playlist.PLAYLIST_EMPTY_BLOCK_TEXT),
              children: _2
            })
          ]
        });
      };
    },
    76866: (e, t, i) => {
      "use strict";
      i.d(t, {
        H2: () => p.SearchVibeCard,
        yi: () => y.VibeAgentCard,
        hl: () => l.h,
        xy: () => v.VibeButton,
        Eb: () => v.VibeButtonShimmer,
        Gh: () => m,
        nr: () => C.n,
        er: () => n,
        A7: () => s.useOnPinClick,
        KU: () => r.K,
        lb: () => o
      });
      var a = i(93064), r = i(35248);
      let n = (e2) => {
        var t2, i2, n2, l2;
        return (0, a.wg)({
          title: e2.title,
          description: e2.header,
          seeds: e2.seeds,
          animationUrl: e2.animationUrl,
          backgroundImageUrl: e2.backgroundImageUrl,
          imageUrl: e2.imageUrl,
          colors: {
            average: null != (n2 = null == (t2 = e2.colors) ? void 0 : t2.average) ? n2 : "",
            waveText: null != (l2 = null == (i2 = e2.colors) ? void 0 : i2.waveText) ? l2 : ""
          },
          agent: (0, r.K)(e2.agent)
        });
      };
      var l = i(69673), s = i(20875);
      let o = (e2, t2) => {
        var i2;
        return (0, a.wg)({
          title: e2.name,
          seeds: e2.seeds,
          description: e2.description,
          type: null != (i2 = e2.type) ? i2 : void 0,
          agent: (0, r.K)(t2)
        });
      };
      var c = i(26433);
      let d = a.gK.model("VibeAgent", { animationUri: a.gK.string, cover: c.$B, entityType: a.gK.maybe(a.gK.string) });
      var u = i(52509), _ = i(47719), g = i(74125);
      let m = a.gK.model("Vibe", {
        title: a.gK.optional(a.gK.string, ""),
        description: a.gK.maybe(a.gK.string),
        seeds: a.gK.array(a.gK.string),
        imageUrl: a.gK.maybe(a.gK.string),
        animationUrl: a.gK.maybe(a.gK.string),
        backgroundImageUrl: a.gK.maybe(a.gK.string),
        backgroundColor: a.gK.maybe(a.gK.string),
        type: a.gK.maybe(a.gK.string),
        colors: a.gK.maybe(a.gK.model({ average: a.gK.maybe(a.gK.string), waveText: a.gK.maybe(a.gK.string) })),
        agent: a.gK.maybe(d)
      }).views((e2) => {
        let t2 = {
          get stationId() {
            var i2;
            return null != (i2 = e2.seeds[0]) ? i2 : "";
          },
          get context() {
            if (e2.seeds) {
              if (t2.stationId !== g.M19) return e2.title;
              else if (e2.seeds.length > 1) return e2.title;
            }
            return null;
          },
          get pinId() {
            return (0, u.f)(e2.seeds);
          },
          get isPinned() {
            if (!(0, a._n)(e2)) return false;
            let { pinsCollection: t3 } = (0, a.Zn)(e2);
            return t3.isPinned(this.pinId);
          },
          get stationType() {
            var r2, n2;
            return null != (n2 = null == (r2 = t2.stationId) ? void 0 : r2.split(":")[0]) ? n2 : "";
          },
          get isMix() {
            return e2.type === _.y.MIX;
          },
          get shouldShowAgent() {
            if (!(0, a._n)(e2)) return false;
            let { experiments: t3 } = (0, a.Zn)(e2);
            return t3.checkExperiment(g.zal.WebNextWaveAgentExperiment, "on");
          },
          get cover() {
            return (0, a.wg)({ uri: e2.imageUrl, color: e2.backgroundColor });
          }
        };
        return t2;
      }).actions((e2) => ({
        getKey: (t2) => "".concat(t2, "_").concat(e2.seeds[0]),
        togglePin: (0, a.L3)(function* () {
          if (!(0, a._n)(e2)) return;
          let { pinsCollection: t2, user: i2 } = (0, a.Zn)(e2);
          if (i2.isAuthorized) return yield t2.toggleVibePin({ seeds: e2.seeds }, e2.pinId);
        }),
        getDescription() {
          let t2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
          if (!(0, a._n)(e2)) return t2;
          let { experiments: i2 } = (0, a.Zn)(e2);
          return i2.checkExperiment(g.zal.WebNextVibeDescription, "on") && void 0 !== (null == e2 ? void 0 : e2.description) ? e2.description : t2;
        }
      }));
      var p = i(5065), y = i(29443), v = i(29717);
      i(55639);
      var C = i(67075);
    },
    83909: (e, t, i) => {
      "use strict";
      i.d(t, {
        pA: () => x.EmptyPlaylistBlock,
        vf: () => k.HorizontalPlaylistCard,
        B6: () => P.PlaylistCard,
        BL: () => b,
        IP: () => h,
        EC: () => A.PlaylistsCarousel,
        bk: () => n,
        ZC: () => c,
        Ew: () => u,
        pd: () => g
      });
      var a = i(93064), r = i(74125);
      let n = (e2) => {
        var t2, i2;
        let { playlist: n2, generatedPlaylistType: l2, likesCount: s2, trailer: o2, tracksCount: c2 } = e2;
        return (0, a.wg)({
          isAvailable: null == (i2 = n2.available) || i2,
          uuid: n2.playlistUuid,
          title: n2.title,
          uid: n2.uid,
          kind: n2.kind,
          coverUri: null == (t2 = n2.cover) ? void 0 : t2.uri,
          generatedPlaylistType: l2,
          likesCount: s2,
          tracksCount: c2,
          trailer: (0, r.mxW)(o2)
        });
      };
      var l = i(97396), s = i(61910);
      (0, s.cache)(async (e2, t2) => {
        var i2;
        let a2;
        try {
          let {
            container: i3,
            backendHostTld: n2,
            locale: l2,
            host: s2,
            fullUrl: o2,
            isRSC: c2,
            requestUrl: d2
          } = await (0, r.IhE)();
          if (c2) return { playlist: void 0, backendHostTld: n2, locale: l2, host: s2, fullUrl: o2, requestUrl: d2 };
          let u2 = i3.get(r._19);
          a2 = {
            playlist: await u2.getPlaylistWithTracksIds({ userId: e2, playlistKind: t2, resumeStream: false }),
            backendHostTld: n2,
            locale: l2,
            host: s2,
            fullUrl: o2,
            requestUrl: d2
          };
        } catch (e3) {
          return (0, r.tfF)(e3, () => ({ playlist: void 0, ...(0, r.Bj3)() }));
        }
        return (null == (i2 = a2.playlist) ? void 0 : i2.error) === "not-found" && (0, l.notFound)(), a2;
      }), (0, s.cache)(async (e2) => {
        var t2;
        let i2;
        (0, r.sU0)(e2) || (0, l.notFound)();
        try {
          let {
            container: t3,
            backendHostTld: a2,
            locale: n2,
            host: l2,
            fullUrl: s2,
            isRSC: o2,
            requestUrl: c2
          } = await (0, r.IhE)();
          if (o2) return { playlist: void 0, backendHostTld: a2, locale: n2, host: l2, fullUrl: s2, requestUrl: c2 };
          let d2 = t3.get(r.qNr);
          i2 = {
            playlist: await d2.getPlaylist({ playlistUuid: e2, resumeStream: false, richTracks: false }),
            backendHostTld: a2,
            locale: n2,
            host: l2,
            fullUrl: s2,
            requestUrl: c2
          };
        } catch (e3) {
          return (0, r.tfF)(e3, () => ({ playlist: void 0, ...(0, r.Bj3)() }));
        }
        return (null == (t2 = i2.playlist) ? void 0 : t2.error) === "not-found" && (0, l.notFound)(), i2;
      });
      var o = i(13611);
      let c = (e2) => (0, a.wg)({
        ...(0, o.jX)(e2),
        owner: e2.owner ? ((e3) => ({ uid: e3.uid, login: e3.login, name: e3.name, sex: e3.sex, verified: e3.verified }))(e2.owner) : void 0,
        description: e2.description,
        tags: e2.tags,
        modified: e2.modified,
        madeFor: e2.madeFor ? ((e3) => (0, a.wg)({ caseForms: e3.caseForms ? (0, r.NH4)(e3.caseForms) : null }))(e2.madeFor) : null
      });
      var d = i(63695);
      let u = (e2) => {
        var t2, i2;
        return (0, a.wg)({
          ...(0, o.jX)(e2),
          artists: null != (i2 = null == e2 || null == (t2 = e2.artists) ? void 0 : t2.map(d.dM)) ? i2 : []
        });
      };
      var _ = i(54460);
      let g = (e2) => {
        var t2, i2;
        return (0, a.wg)({
          ...(0, o.jX)(e2),
          tracks: null != (i2 = null == e2 || null == (t2 = e2.tracks) ? void 0 : t2.map(_.Rw)) ? i2 : []
        });
      };
      var m = i(26433);
      let p = a.gK.model("PlaylistOwner", { caseForms: a.gK.maybeNull(m.lg) });
      var y = i(66534);
      let v = a.gK.model("PlaylistOwner", {
        uid: a.gK.number,
        login: a.gK.string,
        name: a.gK.string,
        sex: a.gK.enumeration(Object.values(y.U)),
        verified: a.gK.boolean
      }), C = a.gK.model("PlaylistTag", { id: a.gK.string, value: a.gK.string }), b = o.$o.props({
        owner: a.gK.maybe(v),
        modified: a.gK.string,
        description: a.gK.maybe(a.gK.string),
        tags: a.gK.maybeNull(a.gK.array(C)),
        madeFor: a.gK.maybeNull(p)
      }).views((e2) => ({
        get seeds() {
          var t2;
          return ["playlist:".concat(null == (t2 = e2.owner) ? void 0 : t2.login, "_").concat(e2.kind)];
        },
        get tagsString() {
          let { experiments: t2 } = (0, a.Zn)(e2);
          if (!t2.checkExperiment(r.zal.WebEditorsFeatures, "on") || !Array.isArray(e2.tags) || !e2.tags.length)
            return null;
          return e2.tags.map((e3) => e3.value).join(", ");
        }
      })).actions((e2) => ({
        changeDescription: (0, a.L3)(function* (t2) {
          if (!(0, a._n)(e2)) return r.FlZ.ERROR;
          if (e2.description === t2) return r.FlZ.OK;
          if (t2.length > o.iz) return r.FlZ.ERROR;
          let { usersResource: i2, modelActionsLogger: n2 } = (0, a._$)(e2);
          if (e2.canUserChange) {
            let a2 = e2.description;
            e2.description = t2;
            try {
              let a3 = yield i2.changePlaylistDescription({ description: t2, userId: e2.uid, playlistKind: e2.kind });
              return e2.description = a3.description, r.FlZ.OK;
            } catch (t3) {
              e2.description = a2, n2.error(t3);
            }
          }
          return r.FlZ.ERROR;
        }),
        changePlaylistCover: (0, a.L3)(function* (t2) {
          if (!(0, a._n)(e2)) return r.FlZ.ERROR;
          let { usersResource: i2, modelActionsLogger: n2 } = (0, a._$)(e2);
          try {
            let a2 = yield i2.uploadPlaylistCover({ userId: e2.uid, formData: t2, playlistKind: e2.kind });
            return e2.coverUri = a2.cover.uri, r.FlZ.OK;
          } catch (e3) {
            n2.error(e3);
          }
          return r.FlZ.ERROR;
        })
      })).named("PlaylistMeta"), h = o.Zq.props({ artists: a.gK.maybe(a.gK.array(d.PK)) });
      var x = i(72467), k = i(66894), P = i(45318), A = i(3283);
    },
    96957: (e) => {
      e.exports = {
        root: "NotificationPin_root__DBEub",
        view: "NotificationPin_view__daGc_",
        image: "NotificationPin_image__o5F7B"
      };
    },
    97569: (e) => {
      e.exports = {
        root: "VibeAgentCard_root__GVtqu",
        cover: "VibeAgentCard_cover__In0Nz",
        controls: "VibeAgentCard_controls__yXgoW",
        additionals_hide: "VibeAgentCard_additionals_hide__GpV7Z",
        control: "VibeAgentCard_control__toXgO",
        playButton: "VibeAgentCard_playButton__5YkZS",
        pinButton: "VibeAgentCard_pinButton___f4vw"
      };
    },
    97811: (e) => {
      e.exports = {
        root: "VibeButton_root___i3R5",
        ripple: "VibeButton_ripple__cmoBR",
        textContainer: "VibeButton_textContainer__j9nOW",
        title: "VibeButton_title__sLC0I",
        title_long: "VibeButton_title_long__gSVM5",
        subtitle: "VibeButton_subtitle__MQ_Ca",
        image: "VibeButton_image__GOwKJ",
        button: "VibeButton_button__tXFAm",
        button_loading: "VibeButton_button_loading__LYnUR",
        titleContainer: "VibeButton_titleContainer__yrRRu",
        "applying-setting": "VibeButton_applying-setting__Jd_3C",
        icon: "VibeButton_icon__KIv7n"
      };
    }
  }
]);
