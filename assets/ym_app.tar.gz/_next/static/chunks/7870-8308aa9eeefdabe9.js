(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7870],
  {
    11019: (e, t, a) => {
      "use strict";
      a.d(t, { NonMusicNotFoundPage: () => r });
      var l = a(54486), i = a(28303), o = a(61910), s = a(42421), n = a(74125);
      let r = (0, i.PA)(() => {
        let { nonMusic: e2 } = (0, n.Pjs)();
        return (0, o.useEffect)(
          () => () => {
            e2.landing.reset();
          },
          [e2.landing]
        ), (0, l.jsx)(s.M, {});
      });
    },
    22809: (e, t, a) => {
      "use strict";
      a.d(t, { NonMusicPage: () => E });
      var l = a(54486), i = a(50420), o = a(28303), s = a(61910), n = a(43426), r = a(47713), d = a(31500), u = a(6024), g = a(67648), c = a(56231), m = a(97800), N = a(4542), _ = a(82644), C = a(33276), p = a(74125), y = a(80585), A = a(43859), T = a.n(A);
      let E = (0, o.PA)(() => {
        let { nonMusic: e2, user: t2 } = (0, p.Pjs)(), { formatMessage: a2 } = (0, n.A)(), { contentScrollRef: o2, setContentScrollRef: A2 } = (0, p.gKY)(), [E2, S] = (0, g.d)();
        (0, s.useEffect)(() => () => e2.landing.reset(), [e2.landing]), (0, p.Jzs)(e2.landing.isResolved);
        let L = (0, N._9)(e2.landing);
        return e2.landing.isNeededToLoad && (0, s.use)(
          e2.landing.getSkeleton(
            { id: u.p.NON_MUSIC, showWizard: t2.settings.showWizard },
            { preloadBlocksCount: 2 }
          )
        ), (0, l.jsx)(p.nVz, {
          pageId: p._Q$.NON_MUSIC,
          children: (0, l.jsxs)(C.hO, {
            scrollElement: o2,
            outerTitle: a2({ id: "entity-names.podcasts-and-books" }),
            headerElement: E2,
            shouldHideHeader: e2.landing.hasUpperBlocks,
            children: [
              (0, l.jsx)(y.Y9, {
                variant: y.Vw.TEXT,
                showControls: false,
                disableStickyVariant: true,
                children: (0, l.jsx)("div", {
                  className: T().header,
                  children: (0, l.jsx)(m.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    children: (0, l.jsx)(r.A, { id: "entity-names.podcasts-and-books" })
                  })
                })
              }),
              (0, l.jsxs)(c.N, {
                className: T().root,
                containerClassName: T().content,
                ref: A2,
                ...(0, d.Am)(d.Xk.nonMusic.NON_MUSIC_PAGE),
                children: [
                  (0, l.jsx)("div", {
                    className: (0, i.$)(T().landing, { [T().landing_onlyWizard]: L }),
                    children: (0, l.jsx)(N.EA, {
                      landing: e2.landing,
                      headerConcealerComponent: (0, l.jsx)("div", { ref: S }),
                      errorComponent: (0, l.jsx)(_.w, { className: T().error, withBackwardControl: false })
                    })
                  }),
                  (0, l.jsx)(y.A, { children: (0, l.jsx)(y.wi, { className: T().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    29391: (e, t, a) => {
      "use strict";
      a.d(t, { NonMusicCategoryNotFoundPage: () => s });
      var l = a(54486), i = a(28303), o = a(42421);
      let s = (0, i.PA)(() => (0, l.jsx)(o.M, {}));
    },
    31085: (e, t, a) => {
      "use strict";
      a.d(t, { NonMusicCategoryPlaylistsPage: () => y });
      var l = a(54486), i = a(50420), o = a(28303), s = a(97396), n = a(61910), r = a(43426), d = a(31500), u = a(97800), g = a(82644), c = a(33276), m = a(83909), N = a(74125), _ = a(80585), C = a(52291), p = a.n(C);
      let y = (0, o.PA)((e2) => {
        var t2, a2, o2;
        let { categoryId: C2 } = e2, {
          nonMusic: { categoryPlaylistsSubpage: y2 },
          settings: A
        } = (0, N.Pjs)(), T = (0, N.W6M)(), { contentScrollRef: E, setContentScrollRef: S } = (0, N.gKY)(), { formatMessage: L } = (0, r.A)(), b = A.layout === N.u40.Mobile, P = (0, n.useCallback)(
          (e3) => {
            y2.getPlaylists({ page: e3, pageSize: 20 });
          },
          [y2]
        );
        y2.isNotFound && (0, s.notFound)(), (0, n.useEffect)(
          () => () => {
            y2.reset();
          },
          [y2]
        );
        let h = (0, n.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(_.A, { children: (0, l.jsx)(_.wi, { className: p().footer }) }) }),
          []
        );
        if ((0, N.Jzs)(y2.isResolved), (0, N.XcE)(y2.pagesLoader, P), y2.isNeededToLoad && (0, n.use)(y2.getData({ categoryId: C2, page: 0, pageSize: 20 })), y2.isSomethingWrong)
          return (0, l.jsx)(g.w, {});
        let I = y2.isLoading ? 20 : null != (a2 = null == (t2 = y2.pagesLoader.pager) ? void 0 : t2.total) ? a2 : 0;
        return (0, l.jsx)(N.nVz, {
          pageId: N._Q$.NON_MUSIC_CATEGORY_PLAYLISTS,
          children: (0, l.jsx)(c.hO, {
            scrollElement: E,
            outerTitle: y2.title,
            children: (0, l.jsxs)("div", {
              className: p().root,
              ...(0, d.Am)(d.Xk.nonMusic.NON_MUSIC_CATEGORY_PLAYLISTS),
              children: [
                (0, l.jsx)(_.Y9, {
                  variant: _.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: T.canBack,
                  children: (0, l.jsx)(u.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: y2.title
                  })
                }),
                (0, l.jsx)(_.$$, {
                  context: { listAriaLabel: L({ id: "mixes.playlists-list" }, { genreName: y2.title || "" }) },
                  className: (0, i.$)(p().scrollContainer, p().important),
                  customComponents: h,
                  itemContentCallback: (e3) => {
                    let t3 = y2.playlists[e3], a3 = L(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: L({ id: "entity-names.playlist" }) }
                    );
                    return t3 ? (0, l.jsx)(m.B6, { playlist: t3, contentLinesCount: 3 }, t3.key) : (0, l.jsx)(_.Vt, { isActive: true, "aria-label": a3 });
                  },
                  totalCount: I,
                  onGetDataByPage: P,
                  pageSize: 20,
                  totalRequests: null != (o2 = null == y2 ? void 0 : y2.pagesLoader.requestsCount) ? o2 : 0,
                  listClassName: p().content,
                  itemClassName: p().item,
                  handleRef: S,
                  isMobileLayout: b,
                  useWindowScroll: b
                })
              ]
            })
          })
        });
      });
    },
    37723: (e) => {
      e.exports = {
        root: "NonMusicAlbumsPage_root__jlDXa",
        scrollContainer: "NonMusicAlbumsPage_scrollContainer__XNRsu",
        important: "NonMusicAlbumsPage_important__Rk8LT",
        footer: "NonMusicAlbumsPage_footer__LJCIL",
        item: "NonMusicAlbumsPage_item__YArCS",
        content: "NonMusicAlbumsPage_content__phVa7"
      };
    },
    43859: (e) => {
      e.exports = {
        root: "NonMusicPage_root__IPKkH",
        content: "NonMusicPage_content__7_TYy",
        header: "NonMusicPage_header__dijgk",
        landing: "NonMusicPage_landing__kGKTh",
        landing_onlyWizard: "NonMusicPage_landing_onlyWizard__P9nN3",
        footer: "NonMusicPage_footer__juz5v",
        error: "NonMusicPage_error__oW0V3"
      };
    },
    52291: (e) => {
      e.exports = {
        root: "NonMusicCategoryPlaylistsPage_root__NvUH8",
        scrollContainer: "NonMusicCategoryPlaylistsPage_scrollContainer__uUyGe",
        important: "NonMusicCategoryPlaylistsPage_important__YBsHf",
        footer: "NonMusicCategoryPlaylistsPage_footer__TtkEO",
        item: "NonMusicCategoryPlaylistsPage_item__4YasT",
        content: "NonMusicCategoryPlaylistsPage_content__GZb1j"
      };
    },
    63059: (e) => {
      e.exports = {
        root: "NonMusicCategoryPage_root__GYeXL",
        content: "NonMusicCategoryPage_content__LJFnm",
        carouselBlocks: "NonMusicCategoryPage_carouselBlocks___BPJ_",
        carouselBlock: "NonMusicCategoryPage_carouselBlock__t41do",
        carouselBlockHeader: "NonMusicCategoryPage_carouselBlockHeader__1uIfL",
        footer: "NonMusicCategoryPage_footer__56hvJ"
      };
    },
    69029: (e, t, a) => {
      "use strict";
      a.d(t, { x: () => l });
      var l = (function(e2) {
        return e2.CATEGORY = "category", e2.EDITORIAL = "editorial", e2;
      })({});
    },
    77870: (e, t, a) => {
      "use strict";
      a.d(t, {
        gD: () => R.NonMusicAlbumsPage,
        xq: () => i.x,
        ol: () => K.NonMusicCategoryPage,
        bB: () => k.NonMusicCategoryPlaylistsPage,
        rN: () => M
      });
      var l = a(74125), i = a(69029), o = a(93064), s = a(14287), n = a(13611), r = a(26433);
      let d = o.gK.compose(
        o.gK.model("NonMusicCategoryPlaylistsPage", {
          errorStatusCode: o.gK.maybeNull(o.gK.number),
          title: o.gK.maybeNull(o.gK.string),
          playlistsData: o.gK.array(o.gK.model({ uid: o.gK.number, kind: o.gK.number })),
          pagesLoader: (0, r.Ij)(n.$o)
        }),
        r.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === l.GuX.PENDING;
          },
          get isNotFound() {
            let t3 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST, a2 = e2.pagesLoader.isEmpty;
            return e2.isRejected && t3 || a2;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          },
          get playlists() {
            var a2;
            return null != (a2 = e2.pagesLoader.items) ? a2 : [];
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          getPlaylists: (0, o.L3)(function* (t3) {
            let { page: a2 = 0, pageSize: i2 = 20 } = t3, { playlistsResource: r2, modelActionsLogger: d2 } = (0, o._$)(e2);
            if (e2.loadingState === l.GuX.RESOLVE && e2.pagesLoader.isPageNeedToLoad(a2)) {
              e2.pagesLoader.setPageState(a2, l.GuX.PENDING);
              try {
                let t4 = a2 * i2, l2 = e2.playlistsData.slice(t4, t4 + i2), o2 = yield r2.getPlaylists({
                  playlistIds: l2.map((e3) => "".concat(e3.uid, ":").concat(e3.kind)),
                  resumeStream: false
                }), s2 = { page: a2, perPage: i2, total: e2.playlistsData.length }, d3 = o2.playlists.map(n.jX);
                e2.pagesLoader.setItems(d3, { page: a2, pager: s2 });
              } catch (t4) {
                d2.error(t4), e2.pagesLoader.setItems(null, { responseStatus: l.FlZ.ERROR, page: a2 }), t4 instanceof s.GX && (t4.statusCode === s.X1.NOT_FOUND || t4.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.REJECT);
              }
            }
          }),
          getData: (0, o.L3)(function* (a2) {
            let { categoryId: i2, page: n2 = 0, pageSize: r2 = 20 } = a2, { nonMusicResource: d2, modelActionsLogger: u2 } = (0, o._$)(e2);
            if (e2.loadingState !== l.GuX.PENDING)
              try {
                var g2;
                e2.loadingState = l.GuX.PENDING;
                let a3 = yield d2.getPlaylists({ categoryId: i2 });
                e2.title = a3.title, e2.playlistsData = (0, o.wg)(
                  (null != (g2 = a3.entities) ? g2 : []).map((e3) => ({ uid: e3.uid, kind: e3.kind }))
                ), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.RESOLVE), yield t2.getPlaylists({ page: n2, pageSize: r2 });
              } catch (t3) {
                u2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.REJECT);
              }
          }),
          reset() {
            e2.pagesLoader.reset(), e2.loadingState = l.GuX.IDLE, e2.title = null, e2.playlistsData = (0, o.wg)([]), e2.errorStatusCode = null;
          }
        };
        return t2;
      });
      var u = a(4542), g = a(94376);
      let c = o.gK.model("NonMusicAlbumsPageItem", { id: o.gK.number, data: o.gK.maybeNull(g.JC) }), m = o.gK.compose(
        o.gK.model("NonMusicAlbumsPage", {
          errorStatusCode: o.gK.maybe(o.gK.number),
          title: o.gK.maybeNull(o.gK.string),
          albums: o.gK.maybeNull(o.gK.array(c)),
          requestsCount: o.gK.maybe(o.gK.number)
        }),
        r.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === l.GuX.PENDING;
          },
          get isNotFound() {
            let t3 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST;
            return e2.loadingState === l.GuX.REJECT && t3;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          }
        };
        return t2;
      }).actions((e2) => ({
        getEditorialAlbums: (0, o.L3)(function* (t2) {
          let { id: a2 } = t2, { nonMusicResource: i2, modelActionsLogger: n2 } = (0, o._$)(e2);
          if (e2.loadingState !== l.GuX.PENDING)
            try {
              var r2;
              e2.loadingState = l.GuX.PENDING;
              let t3 = yield i2.getEditorialAlbums({ id: a2 });
              e2.title = t3.title, (null == (r2 = t3.entities) ? void 0 : r2.length) && (e2.albums = (0, o.wg)(t3.entities.map((e3) => ({ id: e3 })))), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.RESOLVE);
            } catch (t3) {
              n2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.REJECT);
            }
        }),
        getCategoryAlbums: (0, o.L3)(function* (t2) {
          let { id: a2 } = t2, { nonMusicResource: i2, modelActionsLogger: n2 } = (0, o._$)(e2);
          if (e2.loadingState !== l.GuX.PENDING)
            try {
              var r2;
              e2.loadingState = l.GuX.PENDING;
              let t3 = yield i2.getCategoryAlbums({ id: a2 });
              e2.title = t3.title, (null == (r2 = t3.albums) ? void 0 : r2.length) && (e2.albums = (0, o.wg)(t3.albums.map((e3) => ({ id: e3 })))), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.RESOLVE);
            } catch (t3) {
              n2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.REJECT);
            }
        }),
        getAlbumsByRange: (0, o.L3)(function* (t2, a2) {
          var l2, i2, s2;
          let { albumResource: n2, modelActionsLogger: r2 } = (0, o._$)(e2);
          if (!(null == (l2 = e2.albums) ? void 0 : l2.length)) return null;
          t2 = Math.max(0, t2), a2 = Math.min(a2, e2.albums.length);
          let d2 = [];
          for (let l3 = t2; l3 <= a2; l3++)
            (null == (i2 = e2.albums[l3]) ? void 0 : i2.id) && !(null == (s2 = e2.albums[l3]) ? void 0 : s2.data) && d2.push(e2.albums[l3].id);
          if (!d2.length) return null;
          try {
            let t3 = yield n2.getAlbums({ albumIds: d2 });
            null == t3 || t3.forEach((t4) => {
              var a3;
              null == (a3 = e2.albums) || a3.forEach((a4, l3) => {
                var i3;
                a4.id === t4.id && (null == (i3 = e2.albums) ? void 0 : i3[l3]) && (e2.albums[l3].data = (0, g.pp)(t4));
              });
            }), e2.requestsCount ? e2.requestsCount = e2.requestsCount + 1 : e2.requestsCount = 1;
          } catch (e3) {
            r2.error(e3);
          }
          return null;
        }),
        reset() {
          e2.loadingState = l.GuX.IDLE, e2.title = null, e2.albums = null, e2.requestsCount = 0;
        }
      }));
      var N = a(84701), _ = a(35620), C = a(42140), p = a(60049), y = a(83909);
      let A = o.gK.model("NonMusicBaseBlock").props({
        type: o.gK.enumeration(Object.values(N.K.CATEGORY)),
        landingBlockType: o.gK.enumeration(Object.values(_.t)),
        id: o.gK.maybe(o.gK.string),
        title: o.gK.maybe(o.gK.string),
        description: o.gK.maybe(o.gK.string),
        viewAllActionLink: o.gK.maybe(o.gK.string)
      }), T = A.named("NonMusicCategoryBlock").props({
        type: o.gK.literal(N.K.CATEGORY),
        landingBlockType: o.gK.literal(_.t.NON_MUSIC_EDITORIAL_COMPILATION),
        items: o.gK.array(u.h9)
      }), E = A.named("NonMusicChartAlbumBlock").props({
        type: o.gK.literal(N.K.ALBUM_CHART),
        landingBlockType: o.gK.literal(_.t.CHART_ALBUMS),
        items: o.gK.array(g.JC)
      }), S = o.gK.union(u.RO, u.Od), L = A.named("NonMusicEditorialPlaylistsBlock").props({
        type: o.gK.literal(N.K.EDITORIAL_PLAYLISTS),
        landingBlockType: o.gK.literal(_.t.RECENTLY_PLAYED),
        items: o.gK.array(S)
      });
      var b = a(3095);
      let P = A.named("NonMusicMixesBlock").props({
        type: o.gK.literal(N.K.CATEGORIES_TAB),
        landingBlockType: o.gK.literal(_.t.MIXES_GRID),
        items: o.gK.array(b.bv)
      }), h = A.named("NonMusicPromotionsBlock").props({
        type: o.gK.literal(N.K.PROMOTIONS),
        landingBlockType: o.gK.literal(_.t.NON_MUSIC_PROMOTIONS),
        items: o.gK.array(u.fv)
      }), I = o.gK.union(E, L, T, h, P), O = o.gK.compose(
        o.gK.model("NonMusicCategoryPage", {
          errorStatusCode: o.gK.maybeNull(o.gK.number),
          title: o.gK.maybeNull(o.gK.string),
          blocks: o.gK.array(I)
        }),
        r.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === l.GuX.PENDING;
          },
          get isNotFound() {
            let t3 = e2.isResolved && 0 === e2.blocks.length, a2 = e2.errorStatusCode === s.X1.NOT_FOUND || e2.errorStatusCode === s.X1.BAD_REQUEST;
            return e2.isRejected && a2 || t3;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          }
        };
        return t2;
      }).actions((e2) => ({
        getData: (0, o.L3)(function* (t2) {
          let { categoryId: a2 } = t2, { nonMusicResource: i2, modelActionsLogger: n2 } = (0, o._$)(e2);
          if (e2.loadingState !== l.GuX.PENDING)
            try {
              e2.loadingState = l.GuX.PENDING;
              let t3 = yield i2.getCategory({ categoryId: a2 });
              e2.title = t3.title;
              let s2 = [];
              t3.blocks && (t3.blocks.forEach((e3) => {
                switch (e3.type) {
                  case N.K.ALBUM_CHART:
                    s2.push(
                      ((e4) => {
                        let t4 = e4.entities.map((e5) => ({
                          ...(0, g.pp)(e5.data.album),
                          chart: e5.data.chartPosition && (0, C.ws)(e5.data.chartPosition),
                          likesCount: e5.data.album.likesCount
                        }));
                        return (0, o.wg)({
                          id: e4.id,
                          type: N.K.ALBUM_CHART,
                          landingBlockType: _.t.CHART_ALBUMS,
                          title: e4.title,
                          description: e4.description,
                          viewAllActionLink: e4.viewAllUrl,
                          items: t4
                        });
                      })(e3)
                    );
                    return;
                  case N.K.EDITORIAL_PLAYLISTS:
                  case N.K.PLAYLIST_WITH_TRACKS:
                    s2.push(
                      ((e4) => {
                        let t4 = e4.entities.map((e5) => {
                          switch (e5.type) {
                            case N.j.PLAYLIST:
                              return { type: p._.PLAYLIST_ITEM, data: (0, y.Ew)({ ...e5.data, artists: [] }) };
                            case N.j.ALBUM:
                              return { type: p._.ALBUM_ITEM, data: (0, g.pp)(e5.data) };
                          }
                        });
                        return (0, o.wg)({
                          id: e4.id,
                          type: N.K.EDITORIAL_PLAYLISTS,
                          landingBlockType: _.t.RECENTLY_PLAYED,
                          title: e4.title,
                          description: e4.description,
                          viewAllActionLink: e4.viewAllUrl,
                          items: t4
                        });
                      })(e3)
                    );
                    return;
                  case N.K.CATEGORY:
                    s2.push(
                      ((e4) => {
                        let t4 = e4.entities.map((e5) => ({
                          type: p._.NON_MUSIC_ALBUM_ITEM,
                          data: (0, g.pp)(e5.data)
                        }));
                        return (0, o.wg)({
                          id: e4.id,
                          type: N.K.CATEGORY,
                          landingBlockType: _.t.NON_MUSIC_EDITORIAL_COMPILATION,
                          title: e4.title,
                          description: e4.description,
                          viewAllActionLink: e4.viewAllUrl,
                          items: t4
                        });
                      })(e3)
                    );
                    return;
                  case N.K.PROMOTIONS:
                    s2.push(
                      ((e4) => {
                        var t4;
                        let a3 = e4.entities.map((e5) => {
                          var t5, a4, l2, i3, o2;
                          return {
                            featureId: null != (t5 = e5.data.promoId) ? t5 : "",
                            title: null != (a4 = e5.data.title) ? a4 : "",
                            subtitle: null != (l2 = e5.data.subtitle) ? l2 : "",
                            imageUrl: null != (i3 = e5.data.image) ? i3 : "",
                            weblink: null != (o2 = e5.data.url) ? o2 : ""
                          };
                        });
                        return (0, o.wg)({
                          id: e4.id,
                          type: N.K.PROMOTIONS,
                          landingBlockType: _.t.NON_MUSIC_PROMOTIONS,
                          title: e4.title,
                          description: e4.description,
                          viewAllActionLink: null != (t4 = e4.viewAllUrl) ? t4 : void 0,
                          items: a3
                        });
                      })(e3)
                    );
                    return;
                  case N.K.CATEGORIES_TAB:
                    s2.push(
                      ((e4) => {
                        let t4 = e4.entities.map((e5) => {
                          var t5, a3, l2, i3, o2;
                          let s3 = [
                            {
                              uri: null != (t5 = e5.data.backgroundImageUri) ? t5 : "",
                              color: null != (a3 = e5.data.textBackgroundColor) ? a3 : "",
                              videoUrl: ""
                            }
                          ];
                          return {
                            id: null != (l2 = e5.id) ? l2 : "",
                            title: null != (i3 = e5.data.title) ? i3 : "",
                            weblink: null != (o2 = e5.data.url) ? o2 : "",
                            covers: s3
                          };
                        });
                        return (0, o.wg)({
                          id: e4.id,
                          type: N.K.CATEGORIES_TAB,
                          landingBlockType: _.t.MIXES_GRID,
                          title: e4.title,
                          items: t4
                        });
                      })(e3)
                    );
                }
              }), e2.blocks = (0, o.wg)(s2)), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.RESOLVE);
            } catch (t3) {
              n2.error(t3), t3 instanceof s.GX && (t3.statusCode === s.X1.NOT_FOUND || t3.statusCode === s.X1.BAD_REQUEST) && (e2.errorStatusCode = s.X1.NOT_FOUND), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.REJECT);
            }
        }),
        reset() {
          e2.errorStatusCode = null, e2.title = null, e2.loadingState = l.GuX.IDLE, e2.blocks = (0, o.wg)([]);
        }
      })), M = o.gK.model("NonMusicPage", { landing: u.Ju, albums: m, categorySubpage: O, categoryPlaylistsSubpage: d });
      var R = a(86977);
      a(29391);
      var K = a(86521), k = a(31085);
      a(11019), a(22809);
    },
    84701: (e, t, a) => {
      "use strict";
      var l, i;
      a.d(t, { K: () => i, j: () => l }), (function(e2) {
        e2.ALBUM = "album", e2.PLAYLIST = "playlist", e2.ALBUM_CHART_ITEM = "album-chart-item", e2.BOOKMATE_BANNER_ENTITY = "bookmate-banner-entity", e2.PROMOTION = "promotion", e2.CATEGORY_TAB = "category";
      })(l || (l = {})), (function(e2) {
        e2.ALBUM_CHART = "album-chart", e2.EDITORIAL_PLAYLISTS = "editorial-playlists", e2.PLAYLIST_WITH_TRACKS = "playlist-with-tracks", e2.CATEGORY = "category", e2.BOOKMATE_BANNER = "bookmate-banner", e2.PROMOTIONS = "promotions", e2.CATEGORIES_TAB = "categories-tab";
      })(i || (i = {}));
    },
    86521: (e, t, a) => {
      "use strict";
      a.d(t, { NonMusicCategoryPage: () => A });
      var l = a(54486), i = a(50420), o = a(28303), s = a(97396), n = a(61910), r = a(84701), d = a(56231), u = a(97800), g = a(4542), c = a(82644), m = a(33276), N = a(74125), _ = a(80585), C = a(63059), p = a.n(C);
      let y = {
        [r.K.ALBUM_CHART]: g.zt,
        [r.K.EDITORIAL_PLAYLISTS]: g.g0,
        [r.K.CATEGORY]: g.tl,
        [r.K.PROMOTIONS]: g.nM,
        [r.K.CATEGORIES_TAB]: g.qh
      }, A = (0, o.PA)((e2) => {
        let { id: t2 } = e2, {
          nonMusic: { categorySubpage: a2 }
        } = (0, N.Pjs)(), { contentScrollRef: o2, setContentScrollRef: r2 } = (0, N.gKY)(), g2 = (0, N.W6M)(), C2 = (0, n.useRef)(null);
        a2.isNotFound && (0, s.notFound)(), (0, n.useEffect)(() => {
          C2.current !== t2 && t2 && (a2.reset(), C2.current = t2);
        }, [t2, a2]), (0, n.useEffect)(() => () => a2.reset(), [a2]), (0, N.Jzs)(a2.isResolved);
        let A2 = (0, n.useMemo)(
          () => a2.blocks.map((e3, t3) => {
            let o3 = y[e3.type];
            return (0, l.jsx)(
              N.FoH,
              {
                blockId: e3.id,
                blockType: e3.type,
                blockIdForFrom: "".concat(N.hf$.DISCOVERY_BLOCK, "-").concat(e3.id),
                blockPosX: 1,
                blockPosY: t3 + 1,
                objectsCount: e3.items.length,
                children: (0, l.jsx)(
                  o3,
                  {
                    headerClassName: (0, i.$)(p().carouselBlockHeader, p().carouselBlock),
                    containerClassName: p().carouselBlock,
                    type: e3.landingBlockType,
                    loadingState: a2.loadingState,
                    id: e3.id,
                    isNotFound: a2.isNotFound,
                    hasSentAnalyticsOnLoaded: false,
                    meta: { title: e3.title, description: e3.description, viewAllActionLink: e3.viewAllActionLink },
                    data: { items: e3.items },
                    isNeededToLoad: false,
                    isLoading: a2.isLoading,
                    isLoaded: a2.isResolved,
                    isRejected: a2.isRejected,
                    isShimmerVisible: a2.isLoading,
                    isShimmerActive: true,
                    isVisible: true,
                    objectsCount: e3.items.length
                  },
                  e3.id
                )
              },
              e3.id
            );
          }),
          [a2.blocks, a2.loadingState, a2.isNotFound, a2.isLoading, a2.isResolved, a2.isRejected]
        );
        return (t2 && a2.isNeededToLoad && (0, n.use)(a2.getData({ categoryId: t2 })), a2.isSomethingWrong) ? (0, l.jsx)(c.w, {}) : (0, l.jsx)(N.nVz, {
          pageId: N._Q$.NON_MUSIC_CATEGORY,
          children: (0, l.jsxs)(m.hO, {
            scrollElement: o2,
            outerTitle: a2.title,
            children: [
              (0, l.jsx)(_.Y9, {
                variant: _.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: g2.canBack,
                children: (0, l.jsx)(u.Heading, { variant: "h2", weight: "bold", size: "xl", children: a2.title })
              }),
              (0, l.jsxs)(d.N, {
                className: p().root,
                containerClassName: p().content,
                ref: r2,
                children: [
                  (0, l.jsx)("div", { className: p().carouselBlocks, children: A2 }),
                  (0, l.jsx)(_.A, { children: (0, l.jsx)(_.wi, { className: p().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    86977: (e, t, a) => {
      "use strict";
      a.d(t, { NonMusicAlbumsPage: () => y });
      var l = a(54486), i = a(50420), o = a(28303), s = a(97396), n = a(61910), r = a(43426), d = a(31500), u = a(97800), g = a(94376), c = a(33276), m = a(74125), N = a(80585), _ = a(69029), C = a(37723), p = a.n(C);
      let y = (0, o.PA)((e2) => {
        var t2, a2;
        let { id: o2, variant: C2 } = e2, {
          nonMusic: { albums: y2 },
          settings: A
        } = (0, m.Pjs)(), { formatMessage: T } = (0, r.A)(), { contentScrollRef: E, setContentScrollRef: S } = (0, m.gKY)(), L = (0, m.W6M)(), b = A.layout === m.u40.Mobile;
        (y2.isNotFound || !o2) && (0, s.notFound)(), (0, m.Jzs)(y2.isResolved), (0, n.useEffect)(
          () => () => {
            y2.reset();
          },
          [y2]
        );
        let P = (0, n.useCallback)(
          (e3) => {
            y2.getAlbumsByRange(e3.startIndex, e3.endIndex);
          },
          [y2]
        ), h = (0, n.useMemo)(
          () => ({ Footer: () => (0, l.jsx)(N.A, { children: (0, l.jsx)(N.wi, { className: p().footer }) }) }),
          []
        ), I = y2.isLoading ? 20 : null != (a2 = null == (t2 = y2.albums) ? void 0 : t2.length) ? a2 : 0;
        return o2 && y2.isNeededToLoad && (C2 === _.x.EDITORIAL ? (0, n.use)(y2.getEditorialAlbums({ id: o2 })) : (0, n.use)(y2.getCategoryAlbums({ id: o2 }))), (0, l.jsx)(m.nVz, {
          pageId: m._Q$.NON_MUSIC_ALBUMS,
          children: (0, l.jsx)(c.hO, {
            scrollElement: E,
            outerTitle: y2.title,
            children: (0, l.jsxs)("div", {
              className: p().root,
              ...(0, d.Am)(d.Xk.nonMusic.NON_MUSIC_ALBUMS_PAGE),
              children: [
                (0, l.jsx)(N.Y9, {
                  variant: N.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: L.canBack,
                  children: (0, l.jsx)(u.Heading, {
                    id: "collection-artists-header",
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: y2.title
                  })
                }),
                (0, l.jsx)(N.$$, {
                  className: (0, i.$)(p().scrollContainer, p().important),
                  customComponents: h,
                  itemContentCallback: (e3) => {
                    var t3, a3;
                    let i2 = null == (a3 = y2.albums) || null == (t3 = a3[e3]) ? void 0 : t3.data, o3 = T(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: T({ id: "entity-names.album" }) }
                    );
                    return i2 ? (0, l.jsx)(g.aX, { withLikesCount: true, album: i2, contentLinesCount: 3 }, i2.id) : (0, l.jsx)(N.Vt, { "aria-label": o3 }, e3);
                  },
                  totalCount: I,
                  onGetDataByRange: P,
                  totalRequests: y2.requestsCount,
                  listClassName: p().content,
                  itemClassName: p().item,
                  handleRef: S,
                  context: { listAriaLabel: T({ id: "mixes.albums-list" }, { genreName: y2.title || "" }) },
                  isMobileLayout: b,
                  useWindowScroll: b
                })
              ]
            })
          })
        });
      });
    }
  }
]);
