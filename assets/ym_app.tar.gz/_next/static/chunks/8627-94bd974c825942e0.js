var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [722, 4885, 8627],
  {
    4885: (t, e, i) => {
      "use strict";
      i.d(e, { Te: () => x, XW: () => b });
      var n = i(61910), r = i(92803);
      function s(t2, e2, i2) {
        var _a;
        let n2, r2 = (_a = i2.initialDeps) != null ? _a : [];
        function s2() {
          var s3, a2, o2, l2;
          let h2, u2;
          i2.key && (null == (s3 = i2.debug) ? void 0 : s3.call(i2)) && (h2 = Date.now());
          let d2 = t2();
          if (!(d2.length !== r2.length || d2.some((t3, e3) => r2[e3] !== t3))) return n2;
          if (r2 = d2, i2.key && (null == (a2 = i2.debug) ? void 0 : a2.call(i2)) && (u2 = Date.now()), n2 = e2(...d2), i2.key && (null == (o2 = i2.debug) ? void 0 : o2.call(i2))) {
            let t3 = Math.round((Date.now() - h2) * 100) / 100, e3 = Math.round((Date.now() - u2) * 100) / 100, n3 = e3 / 16, r3 = (t4, e4) => {
              for (t4 = String(t4); t4.length < e4; ) t4 = " " + t4;
              return t4;
            };
            console.info(
              `%c⏱ ${r3(e3, 5)} /${r3(t3, 5)} ms`,
              `
            font-size: .6rem;
            font-weight: bold;
            color: hsl(${Math.max(0, Math.min(120 - 120 * n3, 120))}deg 100% 31%);`,
              null == i2 ? void 0 : i2.key
            );
          }
          return null == (l2 = null == i2 ? void 0 : i2.onChange) || l2.call(i2, n2), n2;
        }
        return s2.updateDeps = (t3) => {
          r2 = t3;
        }, s2;
      }
      function a(t2, e2) {
        if (void 0 !== t2) return t2;
        throw Error(`Unexpected undefined${e2 ? `: ${e2}` : ""}`);
      }
      let o = (t2, e2, i2) => {
        let n2;
        return function(...r2) {
          t2.clearTimeout(n2), n2 = t2.setTimeout(() => e2.apply(this, r2), i2);
        };
      }, l = (t2) => t2, h = (t2) => {
        let e2 = Math.max(t2.startIndex - t2.overscan, 0), i2 = Math.min(t2.endIndex + t2.overscan, t2.count - 1), n2 = [];
        for (let t3 = e2; t3 <= i2; t3++) n2.push(t3);
        return n2;
      }, u = (t2, e2) => {
        let i2 = t2.scrollElement;
        if (!i2) return;
        let n2 = t2.targetWindow;
        if (!n2) return;
        let r2 = (t3) => {
          let { width: i3, height: n3 } = t3;
          e2({ width: Math.round(i3), height: Math.round(n3) });
        };
        if (r2(i2.getBoundingClientRect()), !n2.ResizeObserver) return () => {
        };
        let s2 = new n2.ResizeObserver((e3) => {
          let n3 = () => {
            let t3 = e3[0];
            if (null == t3 ? void 0 : t3.borderBoxSize) {
              let e4 = t3.borderBoxSize[0];
              if (e4) return void r2({ width: e4.inlineSize, height: e4.blockSize });
            }
            r2(i2.getBoundingClientRect());
          };
          t2.options.useAnimationFrameWithResizeObserver ? requestAnimationFrame(n3) : n3();
        });
        return s2.observe(i2, { box: "border-box" }), () => {
          s2.unobserve(i2);
        };
      }, d = { passive: true }, c = (t2, e2) => {
        let i2 = t2.scrollElement;
        if (!i2) return;
        let n2 = () => {
          e2({ width: i2.innerWidth, height: i2.innerHeight });
        };
        return n2(), i2.addEventListener("resize", n2, d), () => {
          i2.removeEventListener("resize", n2);
        };
      }, m = "undefined" == typeof window || "onscrollend" in window, f = (t2, e2) => {
        let i2 = t2.scrollElement;
        if (!i2) return;
        let n2 = t2.targetWindow;
        if (!n2) return;
        let r2 = 0, s2 = t2.options.useScrollendEvent && m ? () => void 0 : o(
          n2,
          () => {
            e2(r2, false);
          },
          t2.options.isScrollingResetDelay
        ), a2 = (n3) => () => {
          let { horizontal: a3, isRtl: o2 } = t2.options;
          r2 = a3 ? i2.scrollLeft * (o2 && -1 || 1) : i2.scrollTop, s2(), e2(r2, n3);
        }, l2 = a2(true), h2 = a2(false);
        h2(), i2.addEventListener("scroll", l2, d);
        let u2 = t2.options.useScrollendEvent && m;
        return u2 && i2.addEventListener("scrollend", h2, d), () => {
          i2.removeEventListener("scroll", l2), u2 && i2.removeEventListener("scrollend", h2);
        };
      }, g = (t2, e2) => {
        let i2 = t2.scrollElement;
        if (!i2) return;
        let n2 = t2.targetWindow;
        if (!n2) return;
        let r2 = 0, s2 = t2.options.useScrollendEvent && m ? () => void 0 : o(
          n2,
          () => {
            e2(r2, false);
          },
          t2.options.isScrollingResetDelay
        ), a2 = (n3) => () => {
          r2 = i2[t2.options.horizontal ? "scrollX" : "scrollY"], s2(), e2(r2, n3);
        }, l2 = a2(true), h2 = a2(false);
        h2(), i2.addEventListener("scroll", l2, d);
        let u2 = t2.options.useScrollendEvent && m;
        return u2 && i2.addEventListener("scrollend", h2, d), () => {
          i2.removeEventListener("scroll", l2), u2 && i2.removeEventListener("scrollend", h2);
        };
      }, p = (t2, e2, i2) => {
        if (null == e2 ? void 0 : e2.borderBoxSize) {
          let t3 = e2.borderBoxSize[0];
          if (t3) return Math.round(t3[i2.options.horizontal ? "inlineSize" : "blockSize"]);
        }
        return Math.round(t2.getBoundingClientRect()[i2.options.horizontal ? "width" : "height"]);
      }, v = (t2, { adjustments: e2 = 0, behavior: i2 }, n2) => {
        var r2, s2;
        null == (s2 = null == (r2 = n2.scrollElement) ? void 0 : r2.scrollTo) || s2.call(r2, { [n2.options.horizontal ? "left" : "top"]: t2 + e2, behavior: i2 });
      }, y = (t2, { adjustments: e2 = 0, behavior: i2 }, n2) => {
        var r2, s2;
        null == (s2 = null == (r2 = n2.scrollElement) ? void 0 : r2.scrollTo) || s2.call(r2, { [n2.options.horizontal ? "left" : "top"]: t2 + e2, behavior: i2 });
      };
      class S {
        constructor(t2) {
          this.unsubs = [], this.scrollElement = null, this.targetWindow = null, this.isScrolling = false, this.scrollToIndexTimeoutId = null, this.measurementsCache = [], this.itemSizeCache = /* @__PURE__ */ new Map(), this.pendingMeasuredCacheIndexes = [], this.scrollRect = null, this.scrollOffset = null, this.scrollDirection = null, this.scrollAdjustments = 0, this.elementsCache = /* @__PURE__ */ new Map(), this.observer = /* @__PURE__ */ (() => {
            let t3 = null, e2 = () => t3 || (this.targetWindow && this.targetWindow.ResizeObserver ? t3 = new this.targetWindow.ResizeObserver((t4) => {
              t4.forEach((t5) => {
                let e3 = () => {
                  this._measureElement(t5.target, t5);
                };
                this.options.useAnimationFrameWithResizeObserver ? requestAnimationFrame(e3) : e3();
              });
            }) : null);
            return {
              disconnect: () => {
                var i2;
                null == (i2 = e2()) || i2.disconnect(), t3 = null;
              },
              observe: (t4) => {
                var i2;
                return null == (i2 = e2()) ? void 0 : i2.observe(t4, { box: "border-box" });
              },
              unobserve: (t4) => {
                var i2;
                return null == (i2 = e2()) ? void 0 : i2.unobserve(t4);
              }
            };
          })(), this.range = null, this.setOptions = (t3) => {
            Object.entries(t3).forEach(([e2, i2]) => {
              void 0 === i2 && delete t3[e2];
            }), this.options = {
              debug: false,
              initialOffset: 0,
              overscan: 1,
              paddingStart: 0,
              paddingEnd: 0,
              scrollPaddingStart: 0,
              scrollPaddingEnd: 0,
              horizontal: false,
              getItemKey: l,
              rangeExtractor: h,
              onChange: () => {
              },
              measureElement: p,
              initialRect: { width: 0, height: 0 },
              scrollMargin: 0,
              gap: 0,
              indexAttribute: "data-index",
              initialMeasurementsCache: [],
              lanes: 1,
              isScrollingResetDelay: 150,
              enabled: true,
              isRtl: false,
              useScrollendEvent: false,
              useAnimationFrameWithResizeObserver: false,
              ...t3
            };
          }, this.notify = (t3) => {
            var e2, i2;
            null == (i2 = (e2 = this.options).onChange) || i2.call(e2, this, t3);
          }, this.maybeNotify = s(
            () => (this.calculateRange(), [this.isScrolling, this.range ? this.range.startIndex : null, this.range ? this.range.endIndex : null]),
            (t3) => {
              this.notify(t3);
            },
            {
              key: false,
              debug: () => this.options.debug,
              initialDeps: [
                this.isScrolling,
                this.range ? this.range.startIndex : null,
                this.range ? this.range.endIndex : null
              ]
            }
          ), this.cleanup = () => {
            this.unsubs.filter(Boolean).forEach((t3) => t3()), this.unsubs = [], this.observer.disconnect(), this.scrollElement = null, this.targetWindow = null;
          }, this._didMount = () => () => {
            this.cleanup();
          }, this._willUpdate = () => {
            var _a;
            var t3;
            let e2 = this.options.enabled ? this.options.getScrollElement() : null;
            if (this.scrollElement !== e2) {
              if (this.cleanup(), !e2) return void this.maybeNotify();
              this.scrollElement = e2, this.scrollElement && "ownerDocument" in this.scrollElement ? this.targetWindow = this.scrollElement.ownerDocument.defaultView : this.targetWindow = (_a = null == (t3 = this.scrollElement) ? void 0 : t3.window) != null ? _a : null, this.elementsCache.forEach((t4) => {
                this.observer.observe(t4);
              }), this._scrollToOffset(this.getScrollOffset(), { adjustments: void 0, behavior: void 0 }), this.unsubs.push(
                this.options.observeElementRect(this, (t4) => {
                  this.scrollRect = t4, this.maybeNotify();
                })
              ), this.unsubs.push(
                this.options.observeElementOffset(this, (t4, e3) => {
                  this.scrollAdjustments = 0, this.scrollDirection = e3 ? this.getScrollOffset() < t4 ? "forward" : "backward" : null, this.scrollOffset = t4, this.isScrolling = e3, this.maybeNotify();
                })
              );
            }
          }, this.getSize = () => {
            var _a;
            return this.options.enabled ? (this.scrollRect = (_a = this.scrollRect) != null ? _a : this.options.initialRect, this.scrollRect[this.options.horizontal ? "width" : "height"]) : (this.scrollRect = null, 0);
          }, this.getScrollOffset = () => {
            var _a;
            return this.options.enabled ? (this.scrollOffset = (_a = this.scrollOffset) != null ? _a : "function" == typeof this.options.initialOffset ? this.options.initialOffset() : this.options.initialOffset, this.scrollOffset) : (this.scrollOffset = null, 0);
          }, this.getFurthestMeasurement = (t3, e2) => {
            let i2 = /* @__PURE__ */ new Map(), n2 = /* @__PURE__ */ new Map();
            for (let r2 = e2 - 1; r2 >= 0; r2--) {
              let e3 = t3[r2];
              if (i2.has(e3.lane)) continue;
              let s2 = n2.get(e3.lane);
              if (null == s2 || e3.end > s2.end ? n2.set(e3.lane, e3) : e3.end < s2.end && i2.set(e3.lane, true), i2.size === this.options.lanes)
                break;
            }
            return n2.size === this.options.lanes ? Array.from(n2.values()).sort((t4, e3) => t4.end === e3.end ? t4.index - e3.index : t4.end - e3.end)[0] : void 0;
          }, this.getMeasurementOptions = s(
            () => [
              this.options.count,
              this.options.paddingStart,
              this.options.scrollMargin,
              this.options.getItemKey,
              this.options.enabled
            ],
            (t3, e2, i2, n2, r2) => (this.pendingMeasuredCacheIndexes = [], { count: t3, paddingStart: e2, scrollMargin: i2, getItemKey: n2, enabled: r2 }),
            { key: false }
          ), this.getMeasurements = s(
            () => [this.getMeasurementOptions(), this.itemSizeCache],
            ({ count: t3, paddingStart: e2, scrollMargin: i2, getItemKey: n2, enabled: r2 }, s2) => {
              if (!r2) return this.measurementsCache = [], this.itemSizeCache.clear(), [];
              0 === this.measurementsCache.length && (this.measurementsCache = this.options.initialMeasurementsCache, this.measurementsCache.forEach((t4) => {
                this.itemSizeCache.set(t4.key, t4.size);
              }));
              let a2 = this.pendingMeasuredCacheIndexes.length > 0 ? Math.min(...this.pendingMeasuredCacheIndexes) : 0;
              this.pendingMeasuredCacheIndexes = [];
              let o2 = this.measurementsCache.slice(0, a2);
              for (let r3 = a2; r3 < t3; r3++) {
                let t4 = n2(r3), a3 = 1 === this.options.lanes ? o2[r3 - 1] : this.getFurthestMeasurement(o2, r3), l2 = a3 ? a3.end + this.options.gap : e2 + i2, h2 = s2.get(t4), u2 = "number" == typeof h2 ? h2 : this.options.estimateSize(r3), d2 = l2 + u2, c2 = a3 ? a3.lane : r3 % this.options.lanes;
                o2[r3] = { index: r3, start: l2, size: u2, end: d2, key: t4, lane: c2 };
              }
              return this.measurementsCache = o2, o2;
            },
            { key: false, debug: () => this.options.debug }
          ), this.calculateRange = s(
            () => [this.getMeasurements(), this.getSize(), this.getScrollOffset(), this.options.lanes],
            (t3, e2, i2, n2) => this.range = t3.length > 0 && e2 > 0 ? (function({ measurements: t4, outerSize: e3, scrollOffset: i3, lanes: n3 }) {
              let r2 = t4.length - 1, s2 = T(0, r2, (e4) => t4[e4].start, i3), a2 = s2;
              if (1 === n3) for (; a2 < r2 && t4[a2].end < i3 + e3; ) a2++;
              else if (n3 > 1) {
                let o2 = Array(n3).fill(0);
                for (; a2 < r2 && o2.some((t5) => t5 < i3 + e3); ) {
                  let e4 = t4[a2];
                  o2[e4.lane] = e4.end, a2++;
                }
                let l2 = Array(n3).fill(i3 + e3);
                for (; s2 > 0 && l2.some((t5) => t5 >= i3); ) {
                  let e4 = t4[s2];
                  l2[e4.lane] = e4.start, s2--;
                }
                s2 = Math.max(0, s2 - s2 % n3), a2 = Math.min(r2, a2 + (n3 - 1 - a2 % n3));
              }
              return { startIndex: s2, endIndex: a2 };
            })({ measurements: t3, outerSize: e2, scrollOffset: i2, lanes: n2 }) : null,
            { key: false, debug: () => this.options.debug }
          ), this.getVirtualIndexes = s(
            () => {
              let t3 = null, e2 = null, i2 = this.calculateRange();
              return i2 && (t3 = i2.startIndex, e2 = i2.endIndex), this.maybeNotify.updateDeps([this.isScrolling, t3, e2]), [this.options.rangeExtractor, this.options.overscan, this.options.count, t3, e2];
            },
            (t3, e2, i2, n2, r2) => null === n2 || null === r2 ? [] : t3({ startIndex: n2, endIndex: r2, overscan: e2, count: i2 }),
            { key: false, debug: () => this.options.debug }
          ), this.indexFromElement = (t3) => {
            let e2 = this.options.indexAttribute, i2 = t3.getAttribute(e2);
            return i2 ? parseInt(i2, 10) : (console.warn(`Missing attribute name '${e2}={index}' on measured element.`), -1);
          }, this._measureElement = (t3, e2) => {
            let i2 = this.indexFromElement(t3), n2 = this.measurementsCache[i2];
            if (!n2) return;
            let r2 = n2.key, s2 = this.elementsCache.get(r2);
            s2 !== t3 && (s2 && this.observer.unobserve(s2), this.observer.observe(t3), this.elementsCache.set(r2, t3)), t3.isConnected && this.resizeItem(i2, this.options.measureElement(t3, e2, this));
          }, this.resizeItem = (t3, e2) => {
            var _a;
            let i2 = this.measurementsCache[t3];
            if (!i2) return;
            let n2 = e2 - ((_a = this.itemSizeCache.get(i2.key)) != null ? _a : i2.size);
            0 !== n2 && ((void 0 !== this.shouldAdjustScrollPositionOnItemSizeChange ? this.shouldAdjustScrollPositionOnItemSizeChange(i2, n2, this) : i2.start < this.getScrollOffset() + this.scrollAdjustments) && this._scrollToOffset(this.getScrollOffset(), {
              adjustments: this.scrollAdjustments += n2,
              behavior: void 0
            }), this.pendingMeasuredCacheIndexes.push(i2.index), this.itemSizeCache = new Map(this.itemSizeCache.set(i2.key, e2)), this.notify(false));
          }, this.measureElement = (t3) => {
            if (!t3)
              return void this.elementsCache.forEach((t4, e2) => {
                t4.isConnected || (this.observer.unobserve(t4), this.elementsCache.delete(e2));
              });
            this._measureElement(t3, void 0);
          }, this.getVirtualItems = s(
            () => [this.getVirtualIndexes(), this.getMeasurements()],
            (t3, e2) => {
              let i2 = [];
              for (let n2 = 0, r2 = t3.length; n2 < r2; n2++) {
                let r3 = e2[t3[n2]];
                i2.push(r3);
              }
              return i2;
            },
            { key: false, debug: () => this.options.debug }
          ), this.getVirtualItemForOffset = (t3) => {
            let e2 = this.getMeasurements();
            if (0 !== e2.length) return a(e2[T(0, e2.length - 1, (t4) => a(e2[t4]).start, t3)]);
          }, this.getOffsetForAlignment = (t3, e2, i2 = 0) => {
            let n2 = this.getSize(), r2 = this.getScrollOffset();
            "auto" === e2 && (e2 = t3 >= r2 + n2 ? "end" : "start"), "center" === e2 ? t3 += (i2 - n2) / 2 : "end" === e2 && (t3 -= n2);
            let s2 = this.options.horizontal ? "scrollWidth" : "scrollHeight";
            return Math.max(
              Math.min(
                (this.scrollElement ? "document" in this.scrollElement ? this.scrollElement.document.documentElement[s2] : this.scrollElement[s2] : 0) - n2,
                t3
              ),
              0
            );
          }, this.getOffsetForIndex = (t3, e2 = "auto") => {
            t3 = Math.max(0, Math.min(t3, this.options.count - 1));
            let i2 = this.measurementsCache[t3];
            if (!i2) return;
            let n2 = this.getSize(), r2 = this.getScrollOffset();
            if ("auto" === e2)
              if (i2.end >= r2 + n2 - this.options.scrollPaddingEnd) e2 = "end";
              else {
                if (!(i2.start <= r2 + this.options.scrollPaddingStart)) return [r2, e2];
                e2 = "start";
              }
            let s2 = "end" === e2 ? i2.end + this.options.scrollPaddingEnd : i2.start - this.options.scrollPaddingStart;
            return [this.getOffsetForAlignment(s2, e2, i2.size), e2];
          }, this.isDynamicMode = () => this.elementsCache.size > 0, this.cancelScrollToIndex = () => {
            null !== this.scrollToIndexTimeoutId && this.targetWindow && (this.targetWindow.clearTimeout(this.scrollToIndexTimeoutId), this.scrollToIndexTimeoutId = null);
          }, this.scrollToOffset = (t3, { align: e2 = "start", behavior: i2 } = {}) => {
            this.cancelScrollToIndex(), "smooth" === i2 && this.isDynamicMode() && console.warn("The `smooth` scroll behavior is not fully supported with dynamic size."), this._scrollToOffset(this.getOffsetForAlignment(t3, e2), { adjustments: void 0, behavior: i2 });
          }, this.scrollToIndex = (t3, { align: e2 = "auto", behavior: i2 } = {}) => {
            t3 = Math.max(0, Math.min(t3, this.options.count - 1)), this.cancelScrollToIndex(), "smooth" === i2 && this.isDynamicMode() && console.warn("The `smooth` scroll behavior is not fully supported with dynamic size.");
            let n2 = this.getOffsetForIndex(t3, e2);
            if (!n2) return;
            let [r2, s2] = n2;
            this._scrollToOffset(r2, { adjustments: void 0, behavior: i2 }), "smooth" !== i2 && this.isDynamicMode() && this.targetWindow && (this.scrollToIndexTimeoutId = this.targetWindow.setTimeout(() => {
              if (this.scrollToIndexTimeoutId = null, this.elementsCache.has(this.options.getItemKey(t3))) {
                let [e3] = a(this.getOffsetForIndex(t3, s2));
                1 > Math.abs(e3 - this.getScrollOffset()) || this.scrollToIndex(t3, { align: s2, behavior: i2 });
              } else this.scrollToIndex(t3, { align: s2, behavior: i2 });
            }));
          }, this.scrollBy = (t3, { behavior: e2 } = {}) => {
            this.cancelScrollToIndex(), "smooth" === e2 && this.isDynamicMode() && console.warn("The `smooth` scroll behavior is not fully supported with dynamic size."), this._scrollToOffset(this.getScrollOffset() + t3, { adjustments: void 0, behavior: e2 });
          }, this.getTotalSize = () => {
            var _a;
            var t3;
            let e2, i2 = this.getMeasurements();
            if (0 === i2.length) e2 = this.options.paddingStart;
            else if (1 === this.options.lanes) e2 = (_a = null == (t3 = i2[i2.length - 1]) ? void 0 : t3.end) != null ? _a : 0;
            else {
              let t4 = Array(this.options.lanes).fill(null), n2 = i2.length - 1;
              for (; n2 > 0 && t4.some((t5) => null === t5); ) {
                let e3 = i2[n2];
                null === t4[e3.lane] && (t4[e3.lane] = e3.end), n2--;
              }
              e2 = Math.max(...t4.filter((t5) => null !== t5));
            }
            return Math.max(e2 - this.options.scrollMargin + this.options.paddingEnd, 0);
          }, this._scrollToOffset = (t3, { adjustments: e2, behavior: i2 }) => {
            this.options.scrollToFn(t3, { behavior: i2, adjustments: e2 }, this);
          }, this.measure = () => {
            this.itemSizeCache = /* @__PURE__ */ new Map(), this.notify(false);
          }, this.setOptions(t2);
        }
      }
      let T = (t2, e2, i2, n2) => {
        for (; t2 <= e2; ) {
          let r2 = (t2 + e2) / 2 | 0, s2 = i2(r2);
          if (s2 < n2) t2 = r2 + 1;
          else {
            if (!(s2 > n2)) return r2;
            e2 = r2 - 1;
          }
        }
        return t2 > 0 ? t2 - 1 : 0;
      }, w = "undefined" != typeof document ? n.useLayoutEffect : n.useEffect;
      function E(t2) {
        let e2 = n.useReducer(() => ({}), {})[1], i2 = {
          ...t2,
          onChange: (i3, n2) => {
            var s3;
            n2 ? (0, r.flushSync)(e2) : e2(), null == (s3 = t2.onChange) || s3.call(t2, i3, n2);
          }
        }, [s2] = n.useState(() => new S(i2));
        return s2.setOptions(i2), w(() => s2._didMount(), []), w(() => s2._willUpdate()), s2;
      }
      function x(t2) {
        return E({ observeElementRect: u, observeElementOffset: f, scrollToFn: y, ...t2 });
      }
      function b(t2) {
        return E({
          getScrollElement: () => "undefined" != typeof document ? window : null,
          observeElementRect: c,
          observeElementOffset: g,
          scrollToFn: v,
          initialOffset: () => "undefined" != typeof document ? window.scrollY : 0,
          ...t2
        });
      }
    },
    9123: (t) => {
      function e() {
      }
      e.prototype = {
        on: function(t2, e2, i) {
          var n = this.e || (this.e = {});
          return (n[t2] || (n[t2] = [])).push({ fn: e2, ctx: i }), this;
        },
        once: function(t2, e2, i) {
          var n = this;
          function r() {
            n.off(t2, r), e2.apply(i, arguments);
          }
          return r._ = e2, this.on(t2, r, i);
        },
        emit: function(t2) {
          for (var e2 = [].slice.call(arguments, 1), i = ((this.e || (this.e = {}))[t2] || []).slice(), n = 0, r = i.length; n < r; n++)
            i[n].fn.apply(i[n].ctx, e2);
          return this;
        },
        off: function(t2, e2) {
          var i = this.e || (this.e = {}), n = i[t2], r = [];
          if (n && e2) for (var s = 0, a = n.length; s < a; s++) n[s].fn !== e2 && n[s].fn._ !== e2 && r.push(n[s]);
          return r.length ? i[t2] = r : delete i[t2], this;
        }
      }, t.exports = e, t.exports.TinyEmitter = e;
    },
    13657: (t) => {
      "use strict";
      var e = Array.isArray, i = Object.keys, n = Object.prototype.hasOwnProperty;
      t.exports = function t2(r, s) {
        if (r === s) return true;
        if (r && s && "object" == typeof r && "object" == typeof s) {
          var a, o, l, h = e(r), u = e(s);
          if (h && u) {
            if ((o = r.length) != s.length) return false;
            for (a = o; 0 != a--; ) if (!t2(r[a], s[a])) return false;
            return true;
          }
          if (h != u) return false;
          var d = r instanceof Date, c = s instanceof Date;
          if (d != c) return false;
          if (d && c) return r.getTime() == s.getTime();
          var m = r instanceof RegExp, f = s instanceof RegExp;
          if (m != f) return false;
          if (m && f) return r.toString() == s.toString();
          var g = i(r);
          if ((o = g.length) !== i(s).length) return false;
          for (a = o; 0 != a--; ) if (!n.call(s, g[a])) return false;
          for (a = o; 0 != a--; ) if (!t2(r[l = g[a]], s[l])) return false;
          return true;
        }
        return r != r && s != s;
      };
    },
    19713: (t, e, i) => {
      "use strict";
      i.d(e, { FN: () => r, gj: () => n }), i(99215);
      let n = (t2) => {
        let { containerNodeRect: e2, draggingNodeRect: i2, transform: n2 } = t2;
        return i2 && e2 ? (function(t3, e3, i3) {
          let n3 = { ...t3 };
          return e3.top + t3.y <= i3.top ? n3.y = i3.top - e3.top : e3.bottom + t3.y >= i3.top + i3.height && (n3.y = i3.top + i3.height - e3.bottom), e3.left + t3.x <= i3.left ? n3.x = i3.left - e3.left : e3.right + t3.x >= i3.left + i3.width && (n3.x = i3.left + i3.width - e3.right), n3;
        })(n2, i2, e2) : n2;
      }, r = (t2) => {
        let { transform: e2 } = t2;
        return { ...e2, x: 0 };
      };
    },
    35606: (t, e, i) => {
      "use strict";
      var _a;
      i.d(e, { $: () => p });
      let n = "__VPUID_INLINE__", r = "vpuid";
      class s {
        constructor(t2 = {}) {
          __publicField(this, "prefix");
          __publicField(this, "path");
          this.prefix = t2.prefix || "ss_", this.path = t2.path || "/";
        }
        getItem(t2) {
          let e2 = `${this.prefix}${t2}=`, i2 = document.cookie.indexOf(e2);
          if (-1 === i2) return null;
          let n2 = i2 + e2.length, r2 = document.cookie.indexOf(";", n2);
          return document.cookie.substring(n2, -1 === r2 ? document.cookie.length : r2);
        }
        setItem(t2, e2) {
          let i2 = `${this.prefix}${t2}=${e2}; path=${this.path}; samesite=strict`;
          document.cookie = i2;
        }
        removeItem(t2) {
          document.cookie = `${this.prefix}${t2}=; path=${this.path}; max-age=-1`;
        }
        clear() {
          let t2 = document.cookie;
          if (!t2) return;
          let e2 = t2.split(";");
          for (let t3 = 0; t3 < e2.length; t3++) {
            let i2 = e2[t3].indexOf("=");
            if (-1 === i2) continue;
            let n2 = e2[t3].substring(0, i2).trim();
            n2.startsWith(this.prefix) && this.removeItem(n2.substring(this.prefix.length));
          }
        }
        get length() {
          let t2 = 0, e2 = document.cookie;
          if (!e2) return t2;
          let i2 = e2.split(";");
          for (let e3 = 0; e3 < i2.length; e3++) {
            let n2 = i2[e3].indexOf("=");
            -1 !== n2 && i2[e3].substring(0, n2).trim().startsWith(this.prefix) && t2++;
          }
          return t2;
        }
        key(t2) {
          if (t2 < 0) return null;
          let e2 = -1, i2 = document.cookie;
          if (!i2) return null;
          let n2 = i2.split(";");
          for (let i3 = 0; i3 < n2.length; i3++) {
            let r2 = n2[i3].indexOf("=");
            if (-1 === r2) continue;
            let s2 = n2[i3].substring(0, r2).trim();
            if (s2.startsWith(this.prefix) && ++e2 === t2) return s2.substring(this.prefix.length);
          }
          return null;
        }
        static isSupported() {
          try {
            let t2 = "__test_cookie__", e2 = new s();
            e2.setItem(t2, "1");
            let i2 = e2.getItem(t2);
            return e2.removeItem(t2), "1" === i2;
          } catch {
            return false;
          }
        }
      }
      class a {
        constructor() {
          __publicField(this, "data", {});
        }
        getItem(t2) {
          return this.data[t2] || null;
        }
        setItem(t2, e2) {
          this.data[t2] = e2;
        }
        removeItem(t2) {
          delete this.data[t2];
        }
        clear() {
          this.data = {};
        }
        get length() {
          return Object.keys(this.data).length;
        }
        key(t2) {
          let e2 = Object.keys(this.data);
          return t2 >= 0 && t2 < e2.length ? e2[t2] : null;
        }
      }
      function o(t2) {
        let e2 = "__test_storage__";
        try {
          return t2.setItem(e2, "test"), t2.removeItem(e2), true;
        } catch {
          return false;
        }
      }
      class l {
        constructor(t2 = ["local", "session", "cookie", "memory"]) {
          __publicField(this, "fallbackOrder");
          this.fallbackOrder = t2;
        }
        getStorage() {
          for (let t2 of this.fallbackOrder)
            if ((function(t3) {
              try {
                switch (t3) {
                  case "local":
                    return o(window.localStorage);
                  case "session":
                    return o(window.sessionStorage);
                  case "cookie":
                    return s.isSupported();
                  case "memory":
                    return true;
                  default:
                    throw Error(`Unsupported storage type: ${t3}`);
                }
              } catch {
                return false;
              }
            })(t2))
              return this.createStorage(t2);
          return new a();
        }
        createStorage(t2) {
          switch (t2) {
            case "local":
            default:
              return window.localStorage;
            case "session":
              return window.sessionStorage;
            case "cookie":
              return new s();
            case "memory":
              return new a();
          }
        }
      }
      let h = new l().getStorage(), u = new l(["local", "memory"]).getStorage(), d = new l(["session", "memory"]).getStorage();
      function c(t2) {
        return {
          getItem(e2) {
            try {
              return t2.getItem(e2);
            } catch {
              return null;
            }
          },
          setItem(e2, i2) {
            try {
              t2.setItem(e2, i2);
            } catch {
            }
          },
          removeItem(e2) {
            try {
              t2.removeItem(e2);
            } catch {
            }
          },
          clear() {
            try {
              t2.clear();
            } catch {
            }
          },
          hasItem(e2) {
            try {
              return null !== t2.getItem(e2);
            } catch {
              return false;
            }
          },
          get length() {
            try {
              return t2.length;
            } catch {
              return 0;
            }
          },
          key(e2) {
            try {
              return t2.key(e2);
            } catch {
              return null;
            }
          }
        };
      }
      let m = c(h);
      c(u), c(d);
      var f = i(70281);
      let g = "qwertyuiopasdfghjklzxcvbnm0123456789", p = -1 === n.indexOf("__VPUID") ? n : (_a = m.getItem(r)) != null ? _a : (function() {
        let t2 = [];
        for (let e2 = 0; e2 < 10; e2++) t2.push(g[Math.floor((0, f.y)() * g.length)]);
        return t2.join("");
      })();
      m.setItem(r, p);
    },
    50722: (t, e, i) => {
      "use strict";
      i.d(e, { A: () => z });
      var n = i(41500), r = i(31692), s = i(61910), a = i(90310), o = i(73473), l = i(48147), h = i(81959);
      function u(t2, e2) {
        return Object.keys(t2).reduce(function(i2, r2) {
          return i2[r2] = (0, n.__assign)({ timeZone: e2 }, t2[r2]), i2;
        }, {});
      }
      function d(t2, e2) {
        return Object.keys((0, n.__assign)((0, n.__assign)({}, t2), e2)).reduce(function(i2, r2) {
          return i2[r2] = (0, n.__assign)((0, n.__assign)({}, t2[r2] || {}), e2[r2] || {}), i2;
        }, {});
      }
      function c(t2, e2) {
        if (!e2) return t2;
        var i2 = l.S.formats;
        return (0, n.__assign)((0, n.__assign)((0, n.__assign)({}, i2), t2), {
          date: d(u(i2.date, e2), u(t2.date || {}, e2)),
          time: d(u(i2.time, e2), u(t2.time || {}, e2))
        });
      }
      var m = function(t2, e2, i2, s2, a2) {
        var l2 = t2.locale, u2 = t2.formats, d2 = t2.messages, m2 = t2.defaultLocale, f2 = t2.defaultFormats, g2 = t2.fallbackOnEmptyString, p2 = t2.onError, v2 = t2.timeZone, y2 = t2.defaultRichTextElements;
        void 0 === i2 && (i2 = { id: "" });
        var S2 = i2.id, T2 = i2.defaultMessage;
        (0, r.V1)(
          !!S2,
          "[@formatjs/intl] An `id` must be provided to format a message. You can either:\n1. Configure your build toolchain with [babel-plugin-formatjs](https://formatjs.github.io/docs/tooling/babel-plugin)\nor [@formatjs/ts-transformer](https://formatjs.github.io/docs/tooling/ts-transformer) OR\n2. Configure your `eslint` config to include [eslint-plugin-formatjs](https://formatjs.github.io/docs/tooling/linter#enforce-id)\nto autofix this issue"
        );
        var w2 = String(S2), E2 = d2 && Object.prototype.hasOwnProperty.call(d2, w2) && d2[w2];
        if (Array.isArray(E2) && 1 === E2.length && E2[0].type === o.TYPE.literal) return E2[0].value;
        if (!s2 && E2 && "string" == typeof E2 && !y2) return E2.replace(/'\{(.*?)\}'/gi, "{$1}");
        if (s2 = (0, n.__assign)((0, n.__assign)({}, y2), s2 || {}), u2 = c(u2, v2), f2 = c(f2, v2), !E2) {
          if (false === g2 && "" === E2) return E2;
          if ((!T2 || l2 && l2.toLowerCase() !== m2.toLowerCase()) && p2(new h.sb(i2, l2)), T2)
            try {
              var x2 = e2.getMessageFormat(T2, m2, f2, a2);
              return x2.format(s2);
            } catch (t3) {
              return p2(
                new h.Ho(
                  'Error formatting default message for: "'.concat(w2, '", rendering default message verbatim'),
                  l2,
                  i2,
                  t3
                )
              ), "string" == typeof T2 ? T2 : w2;
            }
          return w2;
        }
        try {
          var x2 = e2.getMessageFormat(E2, l2, u2, (0, n.__assign)({ formatters: e2 }, a2 || {}));
          return x2.format(s2);
        } catch (t3) {
          p2(
            new h.Ho(
              'Error formatting message: "'.concat(w2, '", using ').concat(T2 ? "default message" : "id", " as fallback."),
              l2,
              i2,
              t3
            )
          );
        }
        if (T2)
          try {
            var x2 = e2.getMessageFormat(T2, m2, f2, a2);
            return x2.format(s2);
          } catch (t3) {
            p2(
              new h.Ho(
                'Error formatting the default message for: "'.concat(w2, '", rendering message verbatim'),
                l2,
                i2,
                t3
              )
            );
          }
        return "string" == typeof E2 ? E2 : "string" == typeof T2 ? T2 : w2;
      }, f = [
        "formatMatcher",
        "timeZone",
        "hour12",
        "weekday",
        "era",
        "year",
        "month",
        "day",
        "hour",
        "minute",
        "second",
        "timeZoneName",
        "hourCycle",
        "dateStyle",
        "timeStyle",
        "calendar",
        "numberingSystem",
        "fractionalSecondDigits"
      ];
      function g(t2, e2, i2, s2) {
        var a2 = t2.locale, o2 = t2.formats, l2 = t2.onError, h2 = t2.timeZone;
        void 0 === s2 && (s2 = {});
        var u2 = s2.format, d2 = (0, n.__assign)((0, n.__assign)({}, h2 && { timeZone: h2 }), u2 && (0, r.F3)(o2, e2, u2, l2)), c2 = (0, r.J9)(s2, f, d2);
        return "time" !== e2 || c2.hour || c2.minute || c2.second || c2.timeStyle || c2.dateStyle || (c2 = (0, n.__assign)((0, n.__assign)({}, c2), { hour: "numeric", minute: "numeric" })), i2(a2, c2);
      }
      function p(t2, e2) {
        for (var i2 = [], n2 = 2; n2 < arguments.length; n2++) i2[n2 - 2] = arguments[n2];
        var r2 = i2[0], s2 = i2[1], a2 = "string" == typeof r2 ? new Date(r2 || 0) : r2;
        try {
          return g(t2, "date", e2, void 0 === s2 ? {} : s2).format(a2);
        } catch (e3) {
          t2.onError(new h.pg("Error formatting date.", t2.locale, e3));
        }
        return String(a2);
      }
      function v(t2, e2) {
        for (var i2 = [], n2 = 2; n2 < arguments.length; n2++) i2[n2 - 2] = arguments[n2];
        var r2 = i2[0], s2 = i2[1], a2 = "string" == typeof r2 ? new Date(r2 || 0) : r2;
        try {
          return g(t2, "time", e2, void 0 === s2 ? {} : s2).format(a2);
        } catch (e3) {
          t2.onError(new h.pg("Error formatting time.", t2.locale, e3));
        }
        return String(a2);
      }
      function y(t2, e2) {
        for (var i2 = [], n2 = 2; n2 < arguments.length; n2++) i2[n2 - 2] = arguments[n2];
        var r2 = i2[0], s2 = i2[1], a2 = i2[2], o2 = "string" == typeof r2 ? new Date(r2 || 0) : r2, l2 = "string" == typeof s2 ? new Date(s2 || 0) : s2;
        try {
          return g(t2, "dateTimeRange", e2, void 0 === a2 ? {} : a2).formatRange(o2, l2);
        } catch (e3) {
          t2.onError(new h.pg("Error formatting date time range.", t2.locale, e3));
        }
        return String(o2);
      }
      function S(t2, e2) {
        for (var i2 = [], n2 = 2; n2 < arguments.length; n2++) i2[n2 - 2] = arguments[n2];
        var r2 = i2[0], s2 = i2[1], a2 = "string" == typeof r2 ? new Date(r2 || 0) : r2;
        try {
          return g(t2, "date", e2, void 0 === s2 ? {} : s2).formatToParts(a2);
        } catch (e3) {
          t2.onError(new h.pg("Error formatting date.", t2.locale, e3));
        }
        return [];
      }
      function T(t2, e2) {
        for (var i2 = [], n2 = 2; n2 < arguments.length; n2++) i2[n2 - 2] = arguments[n2];
        var r2 = i2[0], s2 = i2[1], a2 = "string" == typeof r2 ? new Date(r2 || 0) : r2;
        try {
          return g(t2, "time", e2, void 0 === s2 ? {} : s2).formatToParts(a2);
        } catch (e3) {
          t2.onError(new h.pg("Error formatting time.", t2.locale, e3));
        }
        return [];
      }
      var w = i(93470), E = ["style", "type", "fallback", "languageDisplay"];
      function x(t2, e2, i2, n2) {
        var s2 = t2.locale, a2 = t2.onError;
        Intl.DisplayNames || a2(
          new w.IF(
            'Intl.DisplayNames is not available in this environment.\nTry polyfilling it using "@formatjs/intl-displaynames"\n',
            w.O4.MISSING_INTL_API
          )
        );
        var o2 = (0, r.J9)(n2, E);
        try {
          return e2(s2, o2).of(i2);
        } catch (t3) {
          a2(new h.pg("Error formatting display name.", s2, t3));
        }
      }
      var b = ["type", "style"], I = Date.now();
      function F(t2, e2, i2, n2) {
        void 0 === n2 && (n2 = {});
        var r2 = k(t2, e2, i2, n2).reduce(function(t3, e3) {
          var i3 = e3.value;
          return "string" != typeof i3 ? t3.push(i3) : "string" == typeof t3[t3.length - 1] ? t3[t3.length - 1] += i3 : t3.push(i3), t3;
        }, []);
        return 1 === r2.length ? r2[0] : 0 === r2.length ? "" : r2;
      }
      function k(t2, e2, i2, s2) {
        var a2 = t2.locale, o2 = t2.onError;
        void 0 === s2 && (s2 = {}), Intl.ListFormat || o2(
          new w.IF(
            'Intl.ListFormat is not available in this environment.\nTry polyfilling it using "@formatjs/intl-listformat"\n',
            w.O4.MISSING_INTL_API
          )
        );
        var l2 = (0, r.J9)(s2, b);
        try {
          var u2 = {}, d2 = i2.map(function(t3, e3) {
            if ("object" == typeof t3) {
              var i3 = "".concat(I, "_").concat(e3, "_").concat(I);
              return u2[i3] = t3, i3;
            }
            return String(t3);
          });
          return e2(a2, l2).formatToParts(d2).map(function(t3) {
            return "literal" === t3.type ? t3 : (0, n.__assign)((0, n.__assign)({}, t3), { value: u2[t3.value] || t3.value });
          });
        } catch (t3) {
          o2(new h.pg("Error formatting list.", a2, t3));
        }
        return i2;
      }
      var M = [
        "style",
        "currency",
        "unit",
        "unitDisplay",
        "useGrouping",
        "minimumIntegerDigits",
        "minimumFractionDigits",
        "maximumFractionDigits",
        "minimumSignificantDigits",
        "maximumSignificantDigits",
        "compactDisplay",
        "currencyDisplay",
        "currencySign",
        "notation",
        "signDisplay",
        "unit",
        "unitDisplay",
        "numberingSystem",
        "trailingZeroDisplay",
        "roundingPriority",
        "roundingIncrement",
        "roundingMode"
      ];
      function D(t2, e2, i2) {
        var n2 = t2.locale, s2 = t2.formats, a2 = t2.onError;
        void 0 === i2 && (i2 = {});
        var o2 = i2.format, l2 = o2 && (0, r.F3)(s2, "number", o2, a2) || {};
        return e2(n2, (0, r.J9)(i2, M, l2));
      }
      function C(t2, e2, i2, n2) {
        void 0 === n2 && (n2 = {});
        try {
          return D(t2, e2, n2).format(i2);
        } catch (e3) {
          t2.onError(new h.pg("Error formatting number.", t2.locale, e3));
        }
        return String(i2);
      }
      function P(t2, e2, i2, n2) {
        void 0 === n2 && (n2 = {});
        try {
          return D(t2, e2, n2).formatToParts(i2);
        } catch (e3) {
          t2.onError(new h.pg("Error formatting number.", t2.locale, e3));
        }
        return [];
      }
      var O = ["type"];
      function _(t2, e2, i2, n2) {
        var s2 = t2.locale, a2 = t2.onError;
        void 0 === n2 && (n2 = {}), Intl.PluralRules || a2(
          new w.IF(
            'Intl.PluralRules is not available in this environment.\nTry polyfilling it using "@formatjs/intl-pluralrules"\n',
            w.O4.MISSING_INTL_API
          )
        );
        var o2 = (0, r.J9)(n2, O);
        try {
          return e2(s2, o2).select(i2);
        } catch (t3) {
          a2(new h.pg("Error formatting plural.", s2, t3));
        }
        return "other";
      }
      var N = ["numeric", "style"];
      function A(t2, e2, i2, n2, s2) {
        void 0 === s2 && (s2 = {}), n2 || (n2 = "second"), Intl.RelativeTimeFormat || t2.onError(
          new w.IF(
            'Intl.RelativeTimeFormat is not available in this environment.\nTry polyfilling it using "@formatjs/intl-relativetimeformat"\n',
            w.O4.MISSING_INTL_API
          )
        );
        try {
          var a2, o2, l2, u2, d2, c2;
          return (a2 = s2, o2 = t2.locale, l2 = t2.formats, u2 = t2.onError, void 0 === a2 && (a2 = {}), c2 = !!(d2 = a2.format) && (0, r.F3)(l2, "relative", d2, u2) || {}, e2(o2, (0, r.J9)(a2, N, c2))).format(i2, n2);
        } catch (e3) {
          t2.onError(new h.pg("Error formatting relative time.", t2.locale, e3));
        }
        return String(i2);
      }
      var L = i(5075);
      function R(t2) {
        return t2 ? Object.keys(t2).reduce(function(e2, i2) {
          var n2 = t2[i2];
          return e2[i2] = (0, L.RK)(n2) ? (0, a.yU)(n2) : n2, e2;
        }, {}) : t2;
      }
      var V = function(t2, e2, i2, r2) {
        for (var s2 = [], o2 = 4; o2 < arguments.length; o2++) s2[o2 - 4] = arguments[o2];
        var l2 = R(r2), h2 = m.apply(void 0, (0, n.__spreadArray)([t2, e2, i2, l2], s2, false));
        return Array.isArray(h2) ? (0, a.SP)(h2) : h2;
      }, W = function(t2, e2) {
        var i2, s2, o2, l2, u2, d2, c2, f2 = t2.defaultRichTextElements, g2 = (0, n.__rest)(t2, ["defaultRichTextElements"]), w2 = R(f2), E2 = (i2 = (0, n.__assign)((0, n.__assign)((0, n.__assign)({}, a.JF), g2), { defaultRichTextElements: w2 }), s2 = (0, r.GT)(e2), l2 = (o2 = (0, n.__assign)((0, n.__assign)({}, r.JF), i2)).locale, u2 = o2.defaultLocale, d2 = o2.onError, l2 ? !Intl.NumberFormat.supportedLocalesOf(l2).length && d2 ? d2(
          new h.hr(
            'Missing locale data for locale: "'.concat(l2, '" in Intl.NumberFormat. Using default locale: "').concat(
              u2,
              '" as fallback. See https://formatjs.github.io/docs/react-intl#runtime-requirements for more details'
            )
          )
        ) : !Intl.DateTimeFormat.supportedLocalesOf(l2).length && d2 && d2(
          new h.hr(
            'Missing locale data for locale: "'.concat(l2, '" in Intl.DateTimeFormat. Using default locale: "').concat(
              u2,
              '" as fallback. See https://formatjs.github.io/docs/react-intl#runtime-requirements for more details'
            )
          )
        ) : (d2 && d2(
          new h.uo(
            '"locale" was not configured, using "'.concat(
              u2,
              '" as fallback. See https://formatjs.github.io/docs/react-intl/api#intlshape for more details'
            )
          )
        ), o2.locale = o2.defaultLocale || "en"), o2.onWarn && o2.defaultRichTextElements && "string" == typeof (c2 = o2.messages || {})[Object.keys(c2)[0]] && o2.onWarn(
          '[@formatjs/intl] "defaultRichTextElements" was specified but "message" was not pre-compiled. \nPlease consider using "@formatjs/cli" to pre-compile your messages for performance.\nFor more details see https://formatjs.github.io/docs/getting-started/message-distribution'
        ), (0, n.__assign)((0, n.__assign)({}, o2), {
          formatters: s2,
          formatNumber: C.bind(null, o2, s2.getNumberFormat),
          formatNumberToParts: P.bind(null, o2, s2.getNumberFormat),
          formatRelativeTime: A.bind(null, o2, s2.getRelativeTimeFormat),
          formatDate: p.bind(null, o2, s2.getDateTimeFormat),
          formatDateToParts: S.bind(null, o2, s2.getDateTimeFormat),
          formatTime: v.bind(null, o2, s2.getDateTimeFormat),
          formatDateTimeRange: y.bind(null, o2, s2.getDateTimeFormat),
          formatTimeToParts: T.bind(null, o2, s2.getDateTimeFormat),
          formatPlural: _.bind(null, o2, s2.getPluralRules),
          formatMessage: m.bind(null, o2, s2),
          $t: m.bind(null, o2, s2),
          formatList: F.bind(null, o2, s2.getListFormat),
          formatListToParts: k.bind(null, o2, s2.getListFormat),
          formatDisplayName: x.bind(null, o2, s2.getDisplayNames)
        })), b2 = {
          locale: E2.locale,
          timeZone: E2.timeZone,
          fallbackOnEmptyString: E2.fallbackOnEmptyString,
          formats: E2.formats,
          defaultLocale: E2.defaultLocale,
          defaultFormats: E2.defaultFormats,
          messages: E2.messages,
          onError: E2.onError,
          defaultRichTextElements: w2
        };
        return (0, n.__assign)((0, n.__assign)({}, E2), {
          formatMessage: V.bind(null, b2, E2.formatters),
          $t: V.bind(null, b2, E2.formatters)
        });
      }, B = i(28568);
      function j(t2) {
        return {
          locale: t2.locale,
          timeZone: t2.timeZone,
          fallbackOnEmptyString: t2.fallbackOnEmptyString,
          formats: t2.formats,
          textComponent: t2.textComponent,
          messages: t2.messages,
          defaultLocale: t2.defaultLocale,
          defaultFormats: t2.defaultFormats,
          onError: t2.onError,
          onWarn: t2.onWarn,
          wrapRichTextChunksInFragment: t2.wrapRichTextChunksInFragment,
          defaultRichTextElements: t2.defaultRichTextElements
        };
      }
      let z = (function(t2) {
        function e2() {
          var e3 = null !== t2 && t2.apply(this, arguments) || this;
          return e3.cache = (0, r.MT)(), e3.state = { cache: e3.cache, intl: W(j(e3.props), e3.cache), prevConfig: j(e3.props) }, e3;
        }
        return (0, n.__extends)(e2, t2), e2.getDerivedStateFromProps = function(t3, e3) {
          var i2 = e3.prevConfig, n2 = e3.cache, r2 = j(t3);
          return (0, a.bN)(i2, r2) ? null : { intl: W(r2, n2), prevConfig: r2 };
        }, e2.prototype.render = function() {
          return (0, a.HM)(this.state.intl), s.createElement(B.Kq, { value: this.state.intl }, this.props.children);
        }, e2.displayName = "IntlProvider", e2.defaultProps = a.JF, e2;
      })(s.PureComponent);
    },
    53497: (t, e, i) => {
      "use strict";
      i.d(e, { A: () => c });
      var n = i(20427), r = i(41330), s = i(8197), a = i(61910), o = i(35948);
      function l(t2, e2) {
        var i2 = /* @__PURE__ */ Object.create(null);
        return t2 && a.Children.map(t2, function(t3) {
          return t3;
        }).forEach(function(t3) {
          i2[t3.key] = e2 && (0, a.isValidElement)(t3) ? e2(t3) : t3;
        }), i2;
      }
      function h(t2, e2, i2) {
        return null != i2[e2] ? i2[e2] : t2.props[e2];
      }
      var u = Object.values || function(t2) {
        return Object.keys(t2).map(function(e2) {
          return t2[e2];
        });
      }, d = (function(t2) {
        function e2(e3, i3) {
          var n2 = t2.call(this, e3, i3) || this, r2 = n2.handleExited.bind(
            (function(t3) {
              if (void 0 === t3) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
              return t3;
            })(n2)
          );
          return n2.state = { contextValue: { isMounting: true }, handleExited: r2, firstRender: true }, n2;
        }
        (0, s.A)(e2, t2);
        var i2 = e2.prototype;
        return i2.componentDidMount = function() {
          this.mounted = true, this.setState({ contextValue: { isMounting: false } });
        }, i2.componentWillUnmount = function() {
          this.mounted = false;
        }, e2.getDerivedStateFromProps = function(t3, e3) {
          var i3, n2, r2 = e3.children, s2 = e3.handleExited;
          return {
            children: e3.firstRender ? l(t3.children, function(e4) {
              return (0, a.cloneElement)(e4, {
                onExited: s2.bind(null, e4),
                in: true,
                appear: h(e4, "appear", t3),
                enter: h(e4, "enter", t3),
                exit: h(e4, "exit", t3)
              });
            }) : (Object.keys(
              n2 = (function(t4, e4) {
                function i4(i5) {
                  return i5 in e4 ? e4[i5] : t4[i5];
                }
                t4 = t4 || {}, e4 = e4 || {};
                var n3, r3 = /* @__PURE__ */ Object.create(null), s3 = [];
                for (var a2 in t4) a2 in e4 ? s3.length && (r3[a2] = s3, s3 = []) : s3.push(a2);
                var o2 = {};
                for (var l2 in e4) {
                  if (r3[l2])
                    for (n3 = 0; n3 < r3[l2].length; n3++) {
                      var h2 = r3[l2][n3];
                      o2[r3[l2][n3]] = i4(h2);
                    }
                  o2[l2] = i4(l2);
                }
                for (n3 = 0; n3 < s3.length; n3++) o2[s3[n3]] = i4(s3[n3]);
                return o2;
              })(r2, i3 = l(t3.children))
            ).forEach(function(e4) {
              var o2 = n2[e4];
              if ((0, a.isValidElement)(o2)) {
                var l2 = e4 in r2, u2 = e4 in i3, d2 = r2[e4], c2 = (0, a.isValidElement)(d2) && !d2.props.in;
                u2 && (!l2 || c2) ? n2[e4] = (0, a.cloneElement)(o2, {
                  onExited: s2.bind(null, o2),
                  in: true,
                  exit: h(o2, "exit", t3),
                  enter: h(o2, "enter", t3)
                }) : u2 || !l2 || c2 ? u2 && l2 && (0, a.isValidElement)(d2) && (n2[e4] = (0, a.cloneElement)(o2, {
                  onExited: s2.bind(null, o2),
                  in: d2.props.in,
                  exit: h(o2, "exit", t3),
                  enter: h(o2, "enter", t3)
                })) : n2[e4] = (0, a.cloneElement)(o2, { in: false });
              }
            }), n2),
            firstRender: false
          };
        }, i2.handleExited = function(t3, e3) {
          var i3 = l(this.props.children);
          t3.key in i3 || (t3.props.onExited && t3.props.onExited(e3), this.mounted && this.setState(function(e4) {
            var i4 = (0, r.A)({}, e4.children);
            return delete i4[t3.key], { children: i4 };
          }));
        }, i2.render = function() {
          var t3 = this.props, e3 = t3.component, i3 = t3.childFactory, r2 = (0, n.A)(t3, ["component", "childFactory"]), s2 = this.state.contextValue, l2 = u(this.state.children).map(i3);
          return (delete r2.appear, delete r2.enter, delete r2.exit, null === e3) ? a.createElement(o.A.Provider, { value: s2 }, l2) : a.createElement(o.A.Provider, { value: s2 }, a.createElement(e3, r2, l2));
        }, e2;
      })(a.Component);
      d.propTypes = {}, d.defaultProps = {
        component: "div",
        childFactory: function(t2) {
          return t2;
        }
      };
      let c = d;
    },
    57249: (t, e, i) => {
      "use strict";
      t.exports = i.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    70281: (t, e, i) => {
      "use strict";
      i.d(e, { y: () => a });
      let n = !(function(t2, e2 = false) {
        if (!t2) return false;
        let i2 = e2 ? Function.prototype.toString.call(t2) : t2.toString ? t2.toString() : "";
        return /\[native code\]/.test(i2) || /\/\* source code not available \*\//.test(i2);
      })(Math.random) || Math.random() === Math.random();
      var r = i(94854);
      let s = (0, r.x3)() * (0, r.lh)() % 2147483647, a = n ? function() {
        return ((s = 16807 * s % 2147483647) - 1) / 2147483646;
      } : function() {
        return Math.random();
      };
    },
    70837: (t, e, i) => {
      "use strict";
      i.d(e, { T: () => r });
      var n = function() {
        return (n = Object.assign || function(t2) {
          for (var e2, i2 = 1, n2 = arguments.length; i2 < n2; i2++)
            for (var r2 in e2 = arguments[i2]) Object.prototype.hasOwnProperty.call(e2, r2) && (t2[r2] = e2[r2]);
          return t2;
        }).apply(this, arguments);
      }, r = (function() {
        function t2(t3, e2, i2) {
          var r2 = this;
          this.endVal = e2, this.options = i2, this.version = "2.8.1", this.defaults = {
            startVal: 0,
            decimalPlaces: 0,
            duration: 2,
            useEasing: true,
            useGrouping: true,
            useIndianSeparators: false,
            smartEasingThreshold: 999,
            smartEasingAmount: 333,
            separator: ",",
            decimal: ".",
            prefix: "",
            suffix: "",
            enableScrollSpy: false,
            scrollSpyDelay: 200,
            scrollSpyOnce: false
          }, this.finalEndVal = null, this.useEasing = true, this.countDown = false, this.error = "", this.startVal = 0, this.paused = true, this.once = false, this.count = function(t4) {
            r2.startTime || (r2.startTime = t4);
            var e3 = t4 - r2.startTime;
            r2.remaining = r2.duration - e3, r2.useEasing ? r2.countDown ? r2.frameVal = r2.startVal - r2.easingFn(e3, 0, r2.startVal - r2.endVal, r2.duration) : r2.frameVal = r2.easingFn(e3, r2.startVal, r2.endVal - r2.startVal, r2.duration) : r2.frameVal = r2.startVal + (r2.endVal - r2.startVal) * (e3 / r2.duration);
            var i3 = r2.countDown ? r2.frameVal < r2.endVal : r2.frameVal > r2.endVal;
            r2.frameVal = i3 ? r2.endVal : r2.frameVal, r2.frameVal = Number(r2.frameVal.toFixed(r2.options.decimalPlaces)), r2.printValue(r2.frameVal), e3 < r2.duration ? r2.rAF = requestAnimationFrame(r2.count) : null !== r2.finalEndVal ? r2.update(r2.finalEndVal) : r2.options.onCompleteCallback && r2.options.onCompleteCallback();
          }, this.formatNumber = function(t4) {
            var e3, i3, n2, s = (Math.abs(t4).toFixed(r2.options.decimalPlaces) + "").split(".");
            if (e3 = s[0], i3 = s.length > 1 ? r2.options.decimal + s[1] : "", r2.options.useGrouping) {
              n2 = "";
              for (var a = 3, o = 0, l = 0, h = e3.length; l < h; ++l)
                r2.options.useIndianSeparators && 4 === l && (a = 2, o = 1), 0 !== l && o % a == 0 && (n2 = r2.options.separator + n2), o++, n2 = e3[h - l - 1] + n2;
              e3 = n2;
            }
            return r2.options.numerals && r2.options.numerals.length && (e3 = e3.replace(/[0-9]/g, function(t5) {
              return r2.options.numerals[+t5];
            }), i3 = i3.replace(/[0-9]/g, function(t5) {
              return r2.options.numerals[+t5];
            })), (t4 < 0 ? "-" : "") + r2.options.prefix + e3 + i3 + r2.options.suffix;
          }, this.easeOutExpo = function(t4, e3, i3, n2) {
            return i3 * (1 - Math.pow(2, -10 * t4 / n2)) * 1024 / 1023 + e3;
          }, this.options = n(n({}, this.defaults), i2), this.formattingFn = this.options.formattingFn ? this.options.formattingFn : this.formatNumber, this.easingFn = this.options.easingFn ? this.options.easingFn : this.easeOutExpo, this.startVal = this.validateValue(this.options.startVal), this.frameVal = this.startVal, this.endVal = this.validateValue(e2), this.options.decimalPlaces = Math.max(this.options.decimalPlaces), this.resetDuration(), this.options.separator = String(this.options.separator), this.useEasing = this.options.useEasing, "" === this.options.separator && (this.options.useGrouping = false), this.el = "string" == typeof t3 ? document.getElementById(t3) : t3, this.el ? this.printValue(this.startVal) : this.error = "[CountUp] target is null or undefined", "undefined" != typeof window && this.options.enableScrollSpy && (this.error ? console.error(this.error, t3) : (window.onScrollFns = window.onScrollFns || [], window.onScrollFns.push(function() {
            return r2.handleScroll(r2);
          }), window.onscroll = function() {
            window.onScrollFns.forEach(function(t4) {
              return t4();
            });
          }, this.handleScroll(this)));
        }
        return t2.prototype.handleScroll = function(t3) {
          if (t3 && window && !t3.once) {
            var e2 = window.innerHeight + window.scrollY, i2 = t3.el.getBoundingClientRect(), n2 = i2.top + window.pageYOffset, r2 = i2.top + i2.height + window.pageYOffset;
            r2 < e2 && r2 > window.scrollY && t3.paused ? (t3.paused = false, setTimeout(function() {
              return t3.start();
            }, t3.options.scrollSpyDelay), t3.options.scrollSpyOnce && (t3.once = true)) : (window.scrollY > r2 || n2 > e2) && !t3.paused && t3.reset();
          }
        }, t2.prototype.determineDirectionAndSmartEasing = function() {
          var t3 = this.finalEndVal ? this.finalEndVal : this.endVal;
          if (this.countDown = this.startVal > t3, Math.abs(t3 - this.startVal) > this.options.smartEasingThreshold && this.options.useEasing) {
            this.finalEndVal = t3;
            var e2 = this.countDown ? 1 : -1;
            this.endVal = t3 + e2 * this.options.smartEasingAmount, this.duration = this.duration / 2;
          } else this.endVal = t3, this.finalEndVal = null;
          null !== this.finalEndVal ? this.useEasing = false : this.useEasing = this.options.useEasing;
        }, t2.prototype.start = function(t3) {
          this.error || (this.options.onStartCallback && this.options.onStartCallback(), t3 && (this.options.onCompleteCallback = t3), this.duration > 0 ? (this.determineDirectionAndSmartEasing(), this.paused = false, this.rAF = requestAnimationFrame(this.count)) : this.printValue(this.endVal));
        }, t2.prototype.pauseResume = function() {
          this.paused ? (this.startTime = null, this.duration = this.remaining, this.startVal = this.frameVal, this.determineDirectionAndSmartEasing(), this.rAF = requestAnimationFrame(this.count)) : cancelAnimationFrame(this.rAF), this.paused = !this.paused;
        }, t2.prototype.reset = function() {
          cancelAnimationFrame(this.rAF), this.paused = true, this.resetDuration(), this.startVal = this.validateValue(this.options.startVal), this.frameVal = this.startVal, this.printValue(this.startVal);
        }, t2.prototype.update = function(t3) {
          cancelAnimationFrame(this.rAF), this.startTime = null, this.endVal = this.validateValue(t3), this.endVal !== this.frameVal && (this.startVal = this.frameVal, null == this.finalEndVal && this.resetDuration(), this.finalEndVal = null, this.determineDirectionAndSmartEasing(), this.rAF = requestAnimationFrame(this.count));
        }, t2.prototype.printValue = function(t3) {
          var e2;
          if (this.el) {
            var i2 = this.formattingFn(t3);
            (null == (e2 = this.options.plugin) ? void 0 : e2.render) ? this.options.plugin.render(this.el, i2) : "INPUT" === this.el.tagName ? this.el.value = i2 : "text" === this.el.tagName || "tspan" === this.el.tagName ? this.el.textContent = i2 : this.el.innerHTML = i2;
          }
        }, t2.prototype.ensureNumber = function(t3) {
          return "number" == typeof t3 && !isNaN(t3);
        }, t2.prototype.validateValue = function(t3) {
          var e2 = Number(t3);
          return this.ensureNumber(e2) ? e2 : (this.error = "[CountUp] invalid start or end value: ".concat(t3), null);
        }, t2.prototype.resetDuration = function() {
          this.startTime = null, this.duration = 1e3 * Number(this.options.duration), this.remaining = this.duration;
        }, t2;
      })();
    },
    73532: (t, e, i) => {
      "use strict";
      i.d(e, { yv: () => $, YT: () => te, FM: () => l });
      var n, r, s, a, o, l = {};
      i.r(l), i.d(l, { g: () => n, r: () => r }), (function(t2) {
        t2.Start = "Start", t2.Watched4Sec = "4SecWatched", t2.Watched10Sec = "10SecWatched", t2.Watched20Sec = "20SecWatched", t2.Heartbeat30Sec = "30SecHeartbeat", t2.End = "End";
      })(n || (n = {})), (function(t2) {
        t2.PLAY = "play", t2.PAUSE = "pause", t2.BUFFERING = "buffering", t2.END = "end";
      })(r || (r = {}));
      var h = i(89130);
      function u(t2) {
        return Math.floor(t2 / 30);
      }
      class d {
        constructor(t2) {
          __publicField(this, "params");
          __publicField(this, "previousWatchedTime", (0, h.fP)(0));
          this.params = t2;
        }
        onWatchedTimeChange(t2) {
          let { previousWatchedTime: e2 } = this;
          e2 !== t2 && (0 === e2 && t2 > 0 ? this.params.onEvent(n.Start) : e2 < 4 && t2 >= 4 ? this.params.onEvent(n.Watched4Sec) : e2 < 10 && t2 >= 10 ? this.params.onEvent(n.Watched10Sec) : e2 < 20 && t2 >= 20 ? this.params.onEvent(n.Watched20Sec) : u(e2) < u(t2) && this.params.onEvent(n.Heartbeat30Sec), this.previousWatchedTime = t2);
        }
        onPlayingStateChange(t2) {
          t2 === r.END && this.params.onEvent(n.End);
        }
      }
      class c {
        constructor() {
          __publicField(this, "lastSourceIndexWithFatal", null);
        }
        extractSourceIndex(t2) {
          let e2 = t2.split("?")[1];
          if (e2)
            for (let t3 of e2.split("&")) {
              let [e3, i2] = t3.split("=");
              if ("source_index" === e3) return i2 ? Number(i2) : null;
            }
          return null;
        }
        checkIsFatal(t2, e2) {
          if (!t2 || !e2) return t2;
          let i2 = this.extractSourceIndex(e2);
          return null === i2 ? t2 : (null === this.lastSourceIndexWithFatal || i2 > this.lastSourceIndexWithFatal) && (this.lastSourceIndexWithFatal = i2, true);
        }
      }
      var m = i(13657);
      let f = (0, h.Wj)(1e4), g = (0, h.Wj)(1e3), p = (0, h.Wj)(5e3), v = (0, h.Wj)(3e4);
      var y = i(94854);
      class S {
        constructor(t2, e2) {
          __publicField(this, "onTick");
          __publicField(this, "onFlush");
          __publicField(this, "wasFirstFlush", false);
          __publicField(this, "isDestroyed", false);
          __publicField(this, "lastFlushTime");
          __publicField(this, "startTime");
          __publicField(this, "timer");
          __publicField(this, "handleTimeout", () => {
            this.onTick(), this.handleFlush(), this.nextTick();
          });
          this.onTick = t2, this.onFlush = e2, this.startTime = this.lastFlushTime = (0, y.lh)(), this.timer = window.setTimeout(() => {
            this.onTick(), this.nextTick();
          }, 0);
        }
        next() {
          this.isDestroyed || (window.clearTimeout(this.timer), this.handleFlush(), this.nextTick());
        }
        destroy() {
          window.clearTimeout(this.timer), this.isDestroyed = true;
        }
        nextTick() {
          this.isDestroyed || (window.clearTimeout(this.timer), this.timer = window.setTimeout(this.handleTimeout, this.getTimeout()));
        }
        handleFlush() {
          this.needFlush() && (this.onFlush(), this.lastFlushTime = this.wasFirstFlush ? (0, y.lh)() : this.startTime, this.wasFirstFlush = true);
        }
        needFlush() {
          let t2 = (0, y.lh)();
          return this.wasFirstFlush ? t2 - this.lastFlushTime >= v : t2 - this.startTime >= f;
        }
        getTimeout() {
          return (0, y.lh)() - this.startTime < f ? g : p;
        }
      }
      let T = (0, h.PY)((0, h.fP)(Math.abs(0))), w = {
        remainingBufferedTime: (0, h.PY)((0, h.fP)(Math.abs(0))),
        state: r.BUFFERING,
        currentTime: T,
        watchedTime: (0, h.PY)((0, h.fP)(Math.abs(0))),
        duration: (0, h.PY)((0, h.fP)(0))
      }, E = NaN;
      function x() {
      }
      !(function(t2) {
        t2[t2.PLAYING = 1] = "PLAYING", t2[t2.NOT_PLAYING = 2] = "NOT_PLAYING";
      })(s || (s = {})), (function(t2) {
        t2.preroll = "preroll", t2.midroll = "midroll", t2.postPauseroll = "postPauseroll", t2.postroll = "postroll", t2.inroll = "inroll";
      })(a || (a = {}));
      class b {
        constructor(t2) {
          __publicField(this, "props");
          __publicField(this, "prevState");
          __publicField(this, "states", []);
          __publicField(this, "timer");
          __publicField(this, "destroyHandlers", []);
          __publicField(this, "writeStateManually", (function(t2, e2, i2, n2) {
            3 == arguments.length && "boolean" != typeof i2 && (n2 = i2, i2 = false);
            let r2 = null, s2 = x;
            function a2() {
              null !== r2 && clearTimeout(r2), r2 = null;
            }
            let o2 = function() {
              let o3 = arguments;
              n2 = n2 || this, s2 = () => {
                a2(), s2 = x, t2.apply(n2, o3);
              }, i2 && null === r2 && t2.apply(n2, o3), a2(), r2 = window.setTimeout(function() {
                i2 || t2.apply(n2, o3), r2 = null;
              }, e2);
            };
            return o2.cancel = a2, o2.now = () => {
              s2();
            }, o2;
          })(() => {
            this.writeState(), this.timer.next();
          }, 0));
          this.props = t2, this.timer = new S(
            () => this.writeState(),
            () => this.flushStates()
          );
        }
        addDestroyHandler(t2) {
          this.destroyHandlers.push(t2);
        }
        destroy() {
          this.timer.destroy(), this.flushStates(), this.destroyHandlers.forEach((t2) => {
            t2();
          }), this.destroyHandlers = [];
        }
        getStates() {
          return [...this.states];
        }
        flushStates() {
          this.writeStateManually.now();
          let t2 = this.getStates();
          t2.length > 0 && this.props.onFlushStates(t2), this.states.length = 0;
        }
        writeState() {
          let t2 = this.getPlayerAliveState();
          m(this.prevState, t2) || (this.prevState = t2, this.states.push({ ...t2, timestamp: (0, h.Wj)(this.props.getTimestamp()) }));
        }
        getPlayerAliveState() {
          var _a, _b2;
          let t2 = {
            ...w,
            saveData: (function(t3 = window) {
              let { navigator: e3 } = t3, { connection: i3 = {} } = e3;
              return !!i3.saveData;
            })(),
            rtt: (function(t3 = window) {
              var e3;
              if (!t3.navigator) return E;
              let { connection: i3 = {} } = t3.navigator;
              return "number" == typeof (e3 = i3.rtt) && isFinite(e3) ? i3.rtt : E;
            })(),
            ...this.props.stalledController.getStalledHistory()
          }, e2 = this.props.getState();
          if (!e2) return { ...t2 };
          let {
            currentTime: i2,
            duration: n2,
            muted: r2,
            playingState: a2,
            remainingBufferedTime: o2,
            adState: l2,
            liveLatency: u2,
            videoTracks: d2,
            audioTrack: c2,
            videoSize: m2,
            isVisible: f2,
            capHeight: g2,
            capWidth: p2,
            containerHeight: v2,
            containerWidth: y2,
            bandwidthEstimate: S2,
            bandwidthSource: T2,
            droppedFrames: x2,
            shownFrames: b2,
            isFullscreen: I2,
            isPictureInPicture: F2,
            volume: k2,
            playbackRate: M2
          } = e2, D2 = d2.find((t3) => t3.selected), C2 = [...d2].sort((t3, e3) => e3.bitrate - t3.bitrate), P2 = (l2 == null ? void 0 : l2.state) === s.PLAYING, O2 = !P2, _2 = this.props.getWatchedTime();
          return {
            ...t2,
            watchedTime: Math.max(0, _2),
            currentTime: isNaN(i2) ? (0, h.fP)(0) : Math.max(0, i2),
            duration: isNaN(n2) ? (0, h.fP)(0) : Math.max(0, n2),
            isMuted: r2,
            state: a2,
            remainingBufferedTime: (o2 == null ? void 0 : o2.total) || (0, h.fP)(0),
            remainingAudioBufferedTime: (o2 == null ? void 0 : o2.audio) === void 0 ? void 0 : Math.max(0, o2.audio),
            remainingVideoBufferedTime: (o2 == null ? void 0 : o2.video) === void 0 ? void 0 : Math.max(0, o2.video),
            ad: P2 ? l2 == null ? void 0 : l2.type : void 0,
            liveLatency: void 0 === u2 ? void 0 : Math.max(0, u2),
            stalledReason: this.props.stalledController.getCurrentStalledReason(),
            auto: (D2 == null ? void 0 : D2.auto) === void 0 ? void 0 : D2.auto,
            isVisible: f2,
            bitrate: (D2 == null ? void 0 : D2.bitrate) ? Math.max(0, Math.floor((0, h.lw)(D2.bitrate, 1e3))) : void 0,
            width: (m2 == null ? void 0 : m2.videoWidth) === void 0 || isNaN(m2 == null ? void 0 : m2.videoWidth) ? void 0 : Math.max(0, Math.floor((0, h.Lp)(m2 == null ? void 0 : m2.videoWidth))),
            height: (m2 == null ? void 0 : m2.videoHeight) === void 0 || isNaN(m2 == null ? void 0 : m2.videoHeight) ? void 0 : Math.max(0, Math.floor((0, h.Lp)(m2 == null ? void 0 : m2.videoHeight))),
            maxWidth: O2 && ((_a = C2[0]) == null ? void 0 : _a.width) ? Math.max(0, Math.floor((0, h.Lp)(C2[0].width))) : void 0,
            maxHeight: O2 && ((_b2 = C2[0]) == null ? void 0 : _b2.height) ? Math.max(0, Math.floor((0, h.Lp)(C2[0].height))) : void 0,
            audioTrack: (c2 == null ? void 0 : c2.value) || void 0,
            audioLang: (c2 == null ? void 0 : c2.lang) || void 0,
            audioBitrate: (c2 == null ? void 0 : c2.bitrate) ? Math.max(0, Math.floor((0, h.lw)(c2.bitrate, 1e3))) : void 0,
            capHeight: O2 && g2 ? Math.max(0, Math.floor((0, h.Lp)(g2))) : void 0,
            capWidth: O2 && p2 ? Math.max(0, Math.floor((0, h.Lp)(p2))) : void 0,
            containerHeight: void 0 !== v2 ? Math.max(0, Math.floor(v2)) : void 0,
            containerWidth: void 0 !== y2 ? Math.max(0, Math.floor(y2)) : void 0,
            bandwidthEstimate: void 0 === S2 || isNaN(S2) ? void 0 : Math.max(0, (0, h.bY)(Math.round(S2))),
            bandwidthSource: T2 || void 0,
            droppedFrames: void 0 === x2 ? void 0 : Math.max(0, Math.floor(x2)),
            shownFrames: void 0 === b2 ? void 0 : Math.max(0, Math.floor(b2)),
            viewport: I2 ? "fullscreen" : F2 ? "pip" : "default",
            volume: k2,
            playbackRate: M2
          };
        }
      }
      !(function(t2) {
        t2.Init = "Init", t2.SetSource = "SetSource", t2.Seek = "Seek", t2.VideoTrackChange = "VideoTrackChange", t2.AudioTrackChange = "AudioTrackChange", t2.Recover = "Recover", t2.MediaError = "MediaError", t2.Offline = "Offline", t2.Other = "Other", t2.Render = "Render", t2.RepresentationsChange = "RepresentationsChange", t2.LiveEdge = "LiveEdge", t2.AdStart = "AdStart", t2.AdOther = "AdOther", t2.AdBetween = "AdBetween", t2.AdEnd = "AdEnd";
      })(o || (o = {}));
      let I = [0, 1, 4, 5], F = (0, h.fP)(0), k = I.map((t2) => F = (0, h.WQ)((0, h.fP)(t2), F)), M = (0, h.lw)(k[k.length - 1], 1e3), D = [o.Init];
      function C(t2) {
        setTimeout(() => {
          throw t2;
        }, 0);
      }
      function P(t2, e2) {
        try {
          return t2();
        } catch (t3) {
          "function" == typeof e2 && e2(t3);
        }
      }
      class O {
        setTimeout(t2, e2) {
          if (e2 <= 0) return void P(t2, C);
          let i2 = window.setTimeout(t2, e2);
          return () => window.clearTimeout(i2);
        }
        now() {
          return (0, y.x3)();
        }
      }
      class _ {
        constructor(t2, e2 = new O()) {
          __publicField(this, "distributionFunction");
          __publicField(this, "clock");
          __publicField(this, "stopped", true);
          __publicField(this, "cancel");
          __publicField(this, "lastNow", 0);
          __publicField(this, "lastKnockTime");
          __publicField(this, "lastTimeout", 0);
          __publicField(this, "restTime", 0);
          __publicField(this, "destroyed", false);
          __publicField(this, "isFirstKnock", true);
          __publicField(this, "count", 0);
          this.distributionFunction = t2, this.clock = e2;
        }
        setEnabled(t2) {
          return t2 ? this.start() : this.stop(), this;
        }
        stop() {
          return this.stopped || (this.stopped = true, this.cancelTimeout(), this.restTime = Math.max(this.restTime - (this.clock.now() - this.lastKnockTime), 0)), this;
        }
        start() {
          return this.stopped && !this.destroyed && (this.stopped = false, this.lastKnockTime = this.clock.now(), this.setTimeout(() => this.knock(this.lastNow + this.lastTimeout), this.restTime)), this;
        }
        destroy() {
          this.cancelTimeout(), this.stopped = true, this.destroyed = true;
        }
        knock(t2) {
          this.lastNow = t2, this.lastKnockTime = this.clock.now(), this.isFirstKnock ? this.isFirstKnock = false : this.count++;
          let e2 = this.restTime = this.lastTimeout = this.distributionFunction({ time: t2, count: this.count });
          this.stopped || this.destroyed || this.setTimeout(() => this.knock(t2 + e2), e2);
        }
        cancelTimeout() {
          void 0 !== this.cancel && this.cancel(), this.cancel = void 0;
        }
        setTimeout(t2, e2) {
          this.cancelTimeout();
          let i2 = this.clock.setTimeout(t2, e2);
          void 0 !== i2 && (this.cancelTimeout(), this.cancel = i2);
        }
      }
      function N(t2 = y.lh) {
        let e2 = t2();
        return () => (0, h.Wj)(Math.max(0, t2() - e2));
      }
      function A(t2, e2) {
        return { reason: t2, details: e2, getElapsedTime: N() };
      }
      class L {
        constructor({ getState: t2, logEvent: e2 }) {
          __publicField(this, "isBuffering", false);
          __publicField(this, "timer");
          __publicField(this, "stalledId", 1);
          __publicField(this, "stalledDurationRemainder", (0, h.fP)(0));
          __publicField(this, "getState");
          __publicField(this, "logEvent");
          __publicField(this, "expectedStalled", A(o.Init, {}));
          __publicField(this, "currentStalled");
          __publicField(this, "stalledTime", (0, h.fP)(0));
          __publicField(this, "stalledCount", 0);
          this.getState = t2, this.logEvent = e2;
        }
        setBuffering(t2, e2 = (0, h.Wj)(0)) {
          var _a, _b;
          if (t2 !== this.isBuffering)
            if (this.isBuffering = t2, this.isBuffering) {
              let t3 = [], i3 = I.filter((i4, n2) => {
                let r2 = this.currentStalled ? this.currentStalled.expectedStalled : this.getExpectedStalled(), s2 = k[n2];
                if ((0, h.Qr)(e2, 1e3) > s2) {
                  let t4 = this.currentStalled ? this.currentStalled.id : this.stalledId++;
                  return !this.currentStalled && this.stalledCount++, this.currentStalled = { id: t4, expectedStalled: r2, duration: s2, getElapsedTime: N() }, this.send(false, r2, s2, t4), false;
                }
                return t3.push(s2), true;
              });
              this.currentStalled && (this.stalledDurationRemainder = (0, h.gL)((0, h.Qr)(e2, 1e3), this.currentStalled.duration)), i3.length && (i3[0] = i3[0] - this.stalledDurationRemainder), this.timer = new _(({ count: e3 }) => {
                let n2 = this.currentStalled ? this.currentStalled.expectedStalled : this.getExpectedStalled();
                if (e3 > 0) {
                  let i4 = (0, h.fP)(t3[e3 - 1]), r2 = this.currentStalled ? this.currentStalled.id : this.stalledId++;
                  !this.currentStalled && this.stalledCount++, this.currentStalled = { id: r2, expectedStalled: n2, duration: i4, getElapsedTime: N() }, this.send(false, n2, i4, r2);
                }
                return e3 >= i3.length ? (this.destroyTimer(), 1 / 0) : 1e3 * i3[e3];
              }), this.timer.start();
            } else {
              if (this.currentStalled) {
                var i2;
                let { expectedStalled: t3, id: e3 } = this.currentStalled, n2 = (0, h.WQ)(
                  void 0 === (i2 = this.currentStalled) ? (0, h.fP)(0) : (0, h.WQ)(i2.duration, (0, h.Qr)(i2.getElapsedTime(), 1e3)),
                  this.stalledDurationRemainder
                );
                this.send(true, t3, (0, h.WQ)(n2), e3), this.currentStalled = void 0, this.stalledDurationRemainder = (0, h.fP)(0), this.stalledTime = (0, h.WQ)(n2, this.stalledTime);
                let r2 = ((_b = (_a = this.getState()) == null ? void 0 : _a.adState) == null ? void 0 : _b.state) === s.PLAYING ? o.AdOther : o.Other;
                this.setExpectedStalled(A(r2, void 0));
              }
              this.destroyTimer();
            }
        }
        getStalledHistory() {
          let { stalledCount: t2, stalledTime: e2 } = this;
          return { stalledCount: (0, h.Pn)(t2), stalledTime: (0, h.PY)(e2) };
        }
        clearStalledHistory() {
          this.stalledCount = 0, this.stalledTime = (0, h.fP)(0);
        }
        destroy() {
          this.destroyTimer();
        }
        getCurrentStalledReason() {
          var _a;
          return (_a = this.currentStalled) == null ? void 0 : _a.expectedStalled.reason;
        }
        setExpectedStalled(t2) {
          this.expectedStalled = t2;
        }
        isExpiredStalled(t2) {
          let { getElapsedTime: e2, reason: i2 } = t2;
          return !(D.indexOf(i2) > -1) && (!this.currentStalled || this.currentStalled.expectedStalled !== t2) && e2() >= M;
        }
        getExpectedStalled() {
          let t2 = this.expectedStalled;
          return this.isExpiredStalled(t2) ? A(o.Other, void 0) : t2;
        }
        destroyTimer() {
          this.timer && (this.timer.destroy(), this.timer = void 0);
        }
        send(t2, e2, i2, n2) {
          let { reason: r2, details: s2 } = e2, a2 = { ...s2, stalledDuration: i2, stalledId: n2 }, o2 = this.getState();
          if (o2) {
            let { muted: t3, remainingBufferedTime: e3, videoTracks: i3 } = o2, n3 = i3.find((t4) => t4.selected);
            a2 = { ...a2, remainingBufferedTime: e3, videoTrack: n3, isMuted: t3 };
          }
          this.logEvent({ name: t2 ? "StalledEnd" : "Stalled", data: a2, labels: { reason: r2 } });
        }
      }
      let R = (t2) => "hidden" in t2 ? "hidden" : "webkitHidden" in t2 ? "webkitHidden" : void 0;
      function V(t2, e2 = true) {
        let i2 = R(t2);
        return i2 ? !t2[i2] : e2;
      }
      let W = ["Start", "4SecWatched", "10SecWatched", "20SecWatched", "30SecHeartbeat", "End"];
      function B(t2, e2, i2) {
        return t2 && "number" == typeof t2 ? t2 + e2 - i2 : t2;
      }
      let j = {}.toString, z = /\[object (\w+)\]/;
      function H(t2) {
        return "function" == typeof t2 || "Function" === ((t3) => {
          let e2 = j.call(t3);
          if (!e2) return null;
          let i2 = e2.match(z);
          if (!i2) return null;
          let n2 = i2[1];
          return n2 || null;
        })(t2);
      }
      let U = RegExp(
        `^https?:\\/\\/([^\\/]+\\.)?(${"boolean" == typeof CLOUD_BUILD && CLOUD_BUILD ? ["video\\.cloud\\.yandex\\.net"] : "(an|strm)\\.yandex\\.(ru|net)|yastatic\\.net|strm-ott\\.akamaized\\.net|cdn\\.ngenix\\.net|strm\\.yandex\\.cdnga\\.net|strm-yandex\\.gcdn\\.co|(widevine|playready|fairplay)-proxy\\.ott\\.yandex\\.ru|drm\\.yandex-team\\.ru"})\\/(?!log|perf|jstracer)`
      ), Y = (0, h.Wj)(3e4);
      class $ {
        constructor(t2) {
          __publicField(this, "config");
          __publicField(this, "intervalId");
          __publicField(this, "contexts", []);
          this.config = t2;
        }
        attach(t2) {
          t2.performance && (H(t2.performance.getEntriesByType) || H(t2.performance.webkitGetEntriesByType)) && (H(t2.performance.clearResourceTimings) || H(t2.performance.webkitClearResourceTimings)) && -1 === this.contexts.indexOf(t2) && (0 === this.contexts.length && (this.intervalId = setInterval(() => this.flush(), Y)), this.contexts.push(t2));
        }
        detach(t2) {
          let e2 = this.contexts.indexOf(t2);
          -1 !== e2 && this.contexts.splice(e2, 1), 0 === this.contexts.length && clearInterval(this.intervalId);
        }
        destroy() {
          this.flush(), this.contexts.length = 0, clearInterval(this.intervalId);
        }
        flush() {
          let t2 = [], e2 = this.contexts.map(G), i2 = Math.min(...e2);
          this.contexts.forEach((n2, r2) => {
            (function(t3) {
              var _a, _b;
              try {
                let e3 = (_a = t3.performance.getEntriesByType) != null ? _a : t3.performance.webkitGetEntriesByType, i3 = (_b = t3.performance.clearResourceTimings) != null ? _b : t3.performance.webkitClearResourceTimings, n3 = e3.call(t3.performance, "resource");
                return i3.call(t3.performance), n3;
              } catch {
                return [];
              }
            })(n2).forEach((n3) => {
              U.test(n3.name) && t2.push(
                (function(t3, e3, i3) {
                  let {
                    duration: n4,
                    entryType: r3,
                    name: s2,
                    startTime: a2,
                    connectEnd: o2,
                    connectStart: l2,
                    decodedBodySize: h2,
                    domainLookupEnd: u2,
                    domainLookupStart: d2,
                    encodedBodySize: c2,
                    fetchStart: m2,
                    initiatorType: f2,
                    nextHopProtocol: g2,
                    redirectEnd: p2,
                    redirectStart: v2,
                    requestStart: y2,
                    responseEnd: S2,
                    responseStart: T2,
                    secureConnectionStart: w2,
                    transferSize: E2,
                    workerStart: x2,
                    serverTiming: b2,
                    responseStatus: I2,
                    deliveryType: F2,
                    renderBlockingStatus: k2,
                    firstInterimResponseStart: M2
                  } = t3;
                  return {
                    duration: n4,
                    entryType: r3,
                    name: s2,
                    encodedBodySize: c2,
                    decodedBodySize: h2,
                    initiatorType: f2,
                    transferSize: E2,
                    nextHopProtocol: g2,
                    serverTiming: b2,
                    responseStatus: I2,
                    deliveryType: F2,
                    renderBlockingStatus: k2,
                    startTime: B(a2, e3, i3),
                    connectEnd: B(o2, e3, i3),
                    connectStart: B(l2, e3, i3),
                    domainLookupEnd: B(u2, e3, i3),
                    domainLookupStart: B(d2, e3, i3),
                    fetchStart: B(m2, e3, i3),
                    redirectEnd: B(p2, e3, i3),
                    redirectStart: B(v2, e3, i3),
                    requestStart: B(y2, e3, i3),
                    responseEnd: B(S2, e3, i3),
                    responseStart: B(T2, e3, i3),
                    secureConnectionStart: B(w2, e3, i3),
                    workerStart: B(x2, e3, i3),
                    firstInterimResponseStart: B(M2, e3, i3)
                  };
                })(n3, e2[r2], i2)
              );
            });
          }), 0 !== t2.length && this.config.sendLog(t2, { perfnow: String((0, y.x3)()), navstart: String(i2) });
        }
      }
      function G(t2) {
        var _a, _b, _c, _d;
        return (_d = (_a = t2.performance) == null ? void 0 : _a.timeOrigin) != null ? _d : (_c = (_b = t2.performance) == null ? void 0 : _b.timing) == null ? void 0 : _c.navigationStart;
      }
      class Q {
        constructor() {
          __publicField(this, "lastUpdate");
          __publicField(this, "watchedTime", (0, h.fP)(0));
        }
        calc(t2, e2, i2) {
          if (void 0 !== this.lastUpdate) {
            var n2, r2;
            let i3 = (n2 = (0, h.Qr)((0, h.gL)(t2, this.lastUpdate.videoTime), e2), r2 = (0, h.Qr)((0, h.Wj)(this.lastUpdate.getElapsedTime()), 1e3), (0, h.fP)(Math.max(0, n2 >= 0 && n2 <= r2 + 0.5 ? n2 : r2)));
            this.watchedTime = (0, h.WQ)(this.watchedTime, i3);
          }
          this.lastUpdate = i2 ? { getElapsedTime: N(), videoTime: t2 } : void 0;
        }
        get() {
          return this.watchedTime;
        }
        restoreLastUpdate() {
          this.lastUpdate = void 0;
        }
      }
      class J {
        constructor(t2, e2) {
          __publicField(this, "getState");
          __publicField(this, "onChange");
          __publicField(this, "intervalId");
          __publicField(this, "watchedTimeCounter", new Q());
          __publicField(this, "onTick", () => {
            var _a;
            let t2 = this.getState();
            if (!t2) return;
            let { currentTime: e2, playbackRate: i2 = 1, playingState: n2, adState: a2 } = t2, o2 = (a2 == null ? void 0 : a2.state) === s.PLAYING;
            this.watchedTimeCounter.calc(e2, i2, n2 === r.PLAY && !o2), (_a = this.onChange) == null ? void 0 : _a.call(this, this.watchedTimeCounter.get());
          });
          this.getState = t2, this.onChange = e2, this.intervalId = setInterval(this.onTick, 100);
        }
        reset() {
          var _a;
          this.watchedTimeCounter = new Q(), (_a = this.onChange) == null ? void 0 : _a.call(this, this.watchedTimeCounter.get());
        }
        getWatchedTime() {
          return this.watchedTimeCounter.get();
        }
        destroy() {
          clearInterval(this.intervalId), this.intervalId = void 0;
        }
      }
      var K = i(35606);
      function q() {
        return (0, h.Wj)((0, y.x3)());
      }
      class Z {
        constructor(t2 = y.lh) {
          __publicField(this, "lastDateNow");
          __publicField(this, "lastPerformanceNow");
          __publicField(this, "total", (0, h.Wj)(0));
          __publicField(this, "interval");
          __publicField(this, "getTime");
          __publicField(this, "now", () => {
            let t2 = q(), e2 = this.getTime(), i2 = (0, h.gL)(e2, this.lastPerformanceNow), n2 = (0, h.gL)(t2, this.lastDateNow), r2 = (i3) => (this.lastDateNow = t2, this.lastPerformanceNow = e2, this.total = (0, h.WQ)(this.total, i3), this.total);
            return r2(n2 <= 0 ? i2 : n2);
          });
          this.getTime = t2, this.lastDateNow = q(), this.lastPerformanceNow = t2(), this.interval = setInterval(this.now, 1e3);
        }
        stop() {
          clearInterval(this.interval);
        }
      }
      i(70281);
      let X = { enabled: true, events: [n.Watched10Sec, n.Watched20Sec, n.Heartbeat30Sec] }, tt = { logVersion: "1.2.0" };
      class te {
        constructor({ sendLog: t2, playerInfo: e2, getState: i2 }) {
          __publicField(this, "watchedTimeTracker");
          __publicField(this, "fatalTracker");
          __publicField(this, "playbackTracker");
          __publicField(this, "playerAliveController");
          __publicField(this, "stalledController");
          __publicField(this, "remoteProgressSavingInfo", X);
          __publicField(this, "staticParams", {});
          __publicField(this, "playerInfo");
          __publicField(this, "useOfDeprecatedMethodIsLogged", false);
          __publicField(this, "timer");
          __publicField(this, "timerStartTime", Date.now());
          __publicField(this, "sendLog");
          __publicField(this, "getState");
          __publicField(this, "destroyed", false);
          __publicField(this, "wasInitBufferingLogged", false);
          __publicField(this, "externalStalledDuration", (0, h.Wj)(0));
          __publicField(this, "initialStalledDuration", (0, h.Wj)(0));
          __publicField(this, "wasInitBufferingHandled", false);
          __publicField(this, "initialStalledTimestamp");
          __publicField(this, "initialStalledTimestampStop");
          __publicField(this, "eventIndex", 0);
          __publicField(this, "reportNumber", 0);
          __publicField(this, "sourceIndexes", { current: 0, last: 0 });
          this.playerInfo = e2, this.sendLog = t2, this.getState = i2, this.playbackTracker = new d({ onEvent: (t3) => this.logEvent({ name: t3 }) }), this.stalledController = new L({ getState: this.getState, logEvent: (t3) => this.logEvent(t3) }), this.watchedTimeTracker = new J(i2, (t3) => this.playbackTracker.onWatchedTimeChange(t3)), this.playerAliveController = new b({
            getState: i2,
            onFlushStates: (t3) => this.logEvent({ name: "PlayerAlive", data: { states: t3 } }),
            getTimestamp: () => this.getLogTimestamp(),
            stalledController: this.stalledController,
            getWatchedTime: () => this.watchedTimeTracker.getWatchedTime()
          }), this.fatalTracker = new c(), this.initOnVisibilityChangeHandling(), this.timer = new Z();
        }
        static getVpuid() {
          return K.$;
        }
        getLogTimestamp() {
          return Math.round(this.timerStartTime + this.timer.now());
        }
        initOnVisibilityChangeHandling() {
          let t2 = (function(t3, e2) {
            let i2 = (function(t4) {
              let e3 = R(t4);
              if (e3) return e3.replace(/hidden/i, "visibilitychange");
            })(t3);
            if (!i2) return x;
            let n2 = () => {
              e2(V(t3));
            };
            return t3.addEventListener(i2, n2), () => t3.removeEventListener(i2, n2);
          })(document, (t3) => {
            t3 || this.playerAliveController.flushStates();
          });
          this.playerAliveController.addDestroyHandler(t2);
        }
        setStaticParams(t2, e2) {
          e2 ? this.staticParams = { ...t2 } : this.staticParams = { ...this.staticParams, ...t2 };
        }
        enableRemoteProgressSaving(t2) {
          this.remoteProgressSavingInfo.enabled = t2;
        }
        updateWatchedTime() {
          this.useOfDeprecatedMethodIsLogged || (this.logEvent({ name: "DeprecatedTelemetryMethodUsed", data: { method: "updateWatchedTime" } }), this.useOfDeprecatedMethodIsLogged = true), C(
            Error(
              "Deprecated method used. Method is Telemetry#updateWatchedTime(). Just remove. Telemetry calculates watchedTime itself now."
            )
          );
        }
        setPlayingState(t2) {
          this.playbackTracker.onPlayingStateChange(t2), this.handleInitialBuffering(), t2 === r.BUFFERING ? this.setBuffering(true) : this.setBuffering(false);
        }
        logEvent(t2, e2) {
          if (this.destroyed) return;
          let i2 = this.getFullEventLog(t2, e2), n2 = this.getUrlParams(i2.eventType, i2.eventName, t2.labels);
          this.sendData(i2, n2);
        }
        logError({ error: t2, labels: e2, extraRootFields: i2 }, n2) {
          if (this.destroyed) return;
          t2.isFatal = this.fatalTracker.checkIsFatal(t2.isFatal, this.staticParams.streamUrl);
          let r2 = this.getFullErrorLog({ error: t2, labels: e2, extraRootFields: i2, sourceIndex: n2 }), s2 = this.getUrlParams(r2.eventType, r2.eventName, e2);
          this.sendData(r2, s2);
        }
        getUrlParams(t2, e2, i2) {
          return { ...i2, [this.playerInfo.service]: this.playerInfo.version, [t2]: String(e2) };
        }
        getFullEventLog(t2, e2) {
          let i2 = this.getState(), n2 = { ...this.staticParams.labels, ...t2.labels, videoType: i2 == null ? void 0 : i2.videoType }, r2 = W.includes(t2.name) ? { ...t2.data, ...this.getDataToSend(i2) } : t2.data, s2 = {};
          return this.remoteProgressSavingInfo.events.includes(t2.name) && i2 && (s2.playbackProgress = { time: i2.currentTime }), {
            ...tt,
            ...this.staticParams,
            ...t2.extraRootFields,
            ...s2,
            ...this.playerInfo,
            vpuid: K.$,
            eventType: "event",
            eventName: t2.name,
            timestamp: this.getLogTimestamp(),
            documentIsVisible: V(document),
            eventIndex: this.eventIndex,
            data: r2,
            labels: n2,
            sourceIndex: e2 != null ? e2 : this.sourceIndexes.current
          };
        }
        getFullErrorLog({ error: t2, labels: e2, extraRootFields: i2, sourceIndex: n2 }) {
          let r2 = { ...this.staticParams.labels, ...e2 };
          return t2.details = P(() => "string" == typeof t2.details ? t2.details : JSON.stringify(t2.details)) || t2.details, {
            ...tt,
            ...this.playerInfo,
            ...this.staticParams,
            ...i2,
            vpuid: K.$,
            eventType: t2.isFatal ? "fatal" : "error",
            eventName: String(t2.code),
            timestamp: this.getLogTimestamp(),
            documentIsVisible: V(document),
            eventIndex: this.eventIndex,
            data: t2,
            labels: r2,
            sourceIndex: n2 != null ? n2 : this.sourceIndexes.current
          };
        }
        getDataToSend(t2) {
          if (!t2) return {};
          let { duration: e2, currentTime: i2, utcStartTime: n2, isFullscreen: r2, volume: s2, muted: a2 } = t2;
          return {
            watchedSec: this.watchedTimeTracker.getWatchedTime(),
            duration: isNaN(e2) ? void 0 : e2,
            time: i2,
            utcTime: void 0 === n2 ? void 0 : n2 + i2,
            isFullscreen: r2,
            isMuted: a2 || 0 === s2
          };
        }
        sendData(t2, e2) {
          void 0 !== t2 && (P(() => this.sendLog(t2, e2), C), this.eventIndex++);
        }
        checkStalledReason(t2) {
          return this.stalledController.getCurrentStalledReason() === t2;
        }
        setBuffering(t2, e2) {
          this.stalledController.setBuffering(t2, e2);
        }
        setExpectedBuffering({ reason: t2, details: e2 }) {
          switch (this.checkInitBuffering(t2), t2) {
            case o.SetSource:
              this.setBuffering(false), this.clearBufferingHistory();
              break;
            case o.Init:
              break;
            default:
              this.checkStalledReason(t2) || this.setBuffering(false);
          }
          return this.stalledController.setExpectedStalled(A(t2, e2));
        }
        checkInitBuffering(t2) {
          this.wasInitBufferingLogged || t2 === o.Init || this.onInitBuffering();
        }
        setExternalStalledDuration(t2) {
          let e2 = this.getExpectedStalled();
          e2.reason === o.Init && t2 && (e2.details = { externalStalledDuration: (0, h.Qr)(t2, 1e3) }, this.setExpectedBuffering(e2));
        }
        startInitBufferingTimer() {
          this.initialStalledTimestamp = (0, h.Wj)((0, y.lh)());
        }
        stopInitBufferingTimer() {
          this.initialStalledTimestampStop = (0, h.Wj)((0, y.lh)());
        }
        onInitBuffering(t2) {
          if (this.wasInitBufferingLogged) return;
          let e2 = this.initialStalledTimestamp && !this.initialStalledTimestampStop, i2 = this.initialStalledTimestamp && this.initialStalledTimestampStop;
          this.initialStalledDuration = e2 ? (0, h.gL)((0, h.Wj)((0, y.lh)()), this.initialStalledTimestamp) : i2 ? (0, h.gL)(this.initialStalledTimestampStop, this.initialStalledTimestamp) : (0, h.Wj)(0), this.externalStalledDuration = t2 != null ? t2 : (0, h.Wj)(0);
          let { playingState: n2 } = this.getState() || {};
          "pause" !== n2 && this.handleInitialBuffering(), this.wasInitBufferingLogged = true, this.initialStalledTimestamp = void 0, this.initialStalledTimestampStop = void 0;
        }
        handleInitialBuffering() {
          this.wasInitBufferingHandled || (this.externalStalledDuration && this.setExternalStalledDuration(this.externalStalledDuration), this.setBuffering(true, this.initialStalledDuration), this.wasInitBufferingHandled = true);
        }
        destroy(t2) {
          this.stalledController.destroy(), this.playerAliveController.destroy(), this.watchedTimeTracker.destroy(), this.logEvent({ name: "DestroyPlayer", data: { reason: t2 == null ? void 0 : t2.reason } }), this.timer.stop(), this.destroyed = true;
        }
        getExpectedStalled() {
          return this.stalledController.getExpectedStalled();
        }
        clearBufferingHistory() {
          return this.stalledController.clearStalledHistory();
        }
        setPreloadDetails() {
          this.useOfDeprecatedMethodIsLogged || (this.logEvent({ name: "DeprecatedTelemetryMethodUsed", data: { method: "setPreloadDetails" } }), this.useOfDeprecatedMethodIsLogged = true), C(Error("Deprecated method used. Method is Telemetry#setPreloadDetails(). Just remove it."));
        }
        writePlayerAliveStateManually() {
          return this.playerAliveController.writeStateManually();
        }
        flushStates() {
          return this.playerAliveController.flushStates();
        }
        onCreatePlayer(t2, e2) {
          this.logEvent({ name: "CreatePlayer", data: t2, extraRootFields: e2 });
        }
        onBeforePreload() {
          return ++this.sourceIndexes.last;
        }
        getSourceIndex() {
          return this.sourceIndexes.current;
        }
        onBeforeSetSource() {
          return ++this.sourceIndexes.last;
        }
        onSetSource(t2, e2, i2) {
          var _a;
          this.flushStates(), this.sourceIndexes.current = this.sourceIndexes.last > this.sourceIndexes.current ? this.sourceIndexes.last : ++this.sourceIndexes.last, this.watchedTimeTracker.reset(), i2 && this.setStaticParams(i2), this.logEvent({ name: "SetSource", data: t2 }), this.setExpectedBuffering({ reason: o.SetSource, details: e2 });
          let n2 = (_a = this.getState()) == null ? void 0 : _a.playingState;
          n2 !== r.PAUSE && n2 !== r.END && this.setBuffering(true);
        }
        sendReportLog(t2, e2, i2 = true) {
          let n2 = e2 != null ? e2 : this.generateReportId();
          return this.logEvent({ name: "ReportLog", data: { reportId: n2, reported: i2, reportData: t2 } }), n2;
        }
        generateReportId() {
          return `${this.playerInfo.vsid}x${this.reportNumber++}`;
        }
        onExpectedBuffering({ reason: t2, details: e2 }) {
          return this.checkInitBuffering(t2), this.stalledController.setExpectedStalled(A(t2, e2));
        }
        onSeek(t2) {
          this.setExpectedBuffering({ reason: o.Seek, details: t2 });
        }
        onVideoTrackChange(t2) {
          this.setExpectedBuffering({ reason: o.VideoTrackChange, details: t2 });
        }
        onAudioTrackChange(t2) {
          this.setExpectedBuffering({ reason: o.AudioTrackChange, details: t2 });
        }
        onRecover(t2) {
          this.setExpectedBuffering({ reason: o.Recover, details: t2 });
        }
        onMediaError(t2) {
          this.setExpectedBuffering({ reason: o.MediaError, details: t2 });
        }
        onNetworkStatusChange(t2) {
          this.setExpectedBuffering({ reason: o.Offline, details: t2 });
        }
        onRepresentationsChange(t2) {
          this.setExpectedBuffering({ reason: o.RepresentationsChange, details: t2 });
        }
        onLiveEdge(t2) {
          this.setExpectedBuffering({ reason: o.LiveEdge, details: t2 });
        }
        onAdStart(t2) {
          this.setExpectedBuffering({ reason: o.AdStart, details: t2 });
        }
        onAdBetween(t2) {
          this.setExpectedBuffering({ reason: o.AdBetween, details: t2 });
        }
        onAdEnd(t2) {
          this.setExpectedBuffering({ reason: o.AdEnd, details: t2 });
        }
      }
    },
    89130: (t, e, i) => {
      "use strict";
      function n(t2) {
        return t2;
      }
      function r(t2) {
        return Math.max(t2, 0);
      }
      function s(t2) {
        return r(t2);
      }
      function a(t2) {
        return r(Math.floor(t2));
      }
      i.d(e, {
        WQ: () => d,
        Qr: () => f,
        lw: () => m,
        gL: () => c,
        bY: () => h,
        Wj: () => u,
        Lp: () => l,
        fP: () => o,
        PY: () => s,
        Pn: () => a
      });
      let o = n, l = n, h = n, u = n, d = (t2, ...e2) => {
        let i2 = t2;
        for (let t3 = 0; t3 < e2.length; t3++) i2 += e2[t3];
        return i2;
      };
      d.operator = "+";
      let c = (t2, ...e2) => {
        let i2 = t2;
        for (let t3 = 0; t3 < e2.length; t3++) i2 -= e2[t3];
        return i2;
      };
      c.operator = "-";
      let m = (t2, ...e2) => {
        let i2 = t2;
        for (let t3 = 0; t3 < e2.length; t3++) i2 *= e2[t3];
        return i2;
      };
      m.operator = "*";
      let f = (t2, ...e2) => {
        let i2 = t2;
        for (let t3 = 0; t3 < e2.length; t3++) i2 /= e2[t3];
        return i2;
      };
      f.operator = "/";
    },
    94854: (t, e, i) => {
      "use strict";
      i.d(e, { x3: () => o, lh: () => m });
      var n = i(89130);
      let r = {}.toString, s = /\[object (\w+)\]/;
      function a(t2) {
        return "function" == typeof t2 || "Function" === ((t3) => {
          let e2 = r.call(t3);
          if (!e2) return null;
          let i2 = e2.match(s);
          if (!i2) return null;
          let n2 = i2[1];
          return n2 || null;
        })(t2);
      }
      let o = Date && a(Date.now) ? () => Date.now() : () => (/* @__PURE__ */ new Date()).getTime(), l = "undefined" == typeof window ? void 0 : window.performance, h = l && a(l.now), u = l && l.timing && l.timing.navigationStart, d = l && l.timeOrigin ? l.timeOrigin : u ? l.timing.navigationStart : o(), c = 0, m = () => (0, n.Wj)(h ? l.now() : c = Math.max(o() - d, c));
    },
    97151: (t, e, i) => {
      "use strict";
      i.d(e, { XU: () => d });
      var n, r, s = i(41500), a = i(61910), o = i(43426);
      !(function(t2) {
        t2.formatDate = "FormattedDate", t2.formatTime = "FormattedTime", t2.formatNumber = "FormattedNumber", t2.formatList = "FormattedList", t2.formatDisplayName = "FormattedDisplayName";
      })(n || (n = {})), (function(t2) {
        t2.formatDate = "FormattedDateParts", t2.formatTime = "FormattedTimeParts", t2.formatNumber = "FormattedNumberParts", t2.formatList = "FormattedListParts";
      })(r || (r = {}));
      var l = function(t2) {
        var e2 = (0, o.A)(), i2 = t2.value, n2 = t2.children, r2 = (0, s.__rest)(t2, ["value", "children"]);
        return n2(e2.formatNumberToParts(i2, r2));
      };
      function h(t2) {
        var e2 = function(e3) {
          var i2 = (0, o.A)(), n2 = e3.value, r2 = e3.children, a2 = (0, s.__rest)(e3, ["value", "children"]), l2 = "string" == typeof n2 ? new Date(n2 || 0) : n2;
          return r2("formatDate" === t2 ? i2.formatDateToParts(l2, a2) : i2.formatTimeToParts(l2, a2));
        };
        return e2.displayName = r[t2], e2;
      }
      function u(t2) {
        var e2 = function(e3) {
          var i2 = (0, o.A)(), n2 = e3.value, r2 = e3.children, l2 = (0, s.__rest)(e3, ["value", "children"]), h2 = i2[t2](n2, l2);
          if ("function" == typeof r2) return r2(h2);
          var u2 = i2.textComponent || a.Fragment;
          return a.createElement(u2, null, h2);
        };
        return e2.displayName = n[t2], e2;
      }
      l.displayName = "FormattedNumberParts", l.displayName = "FormattedNumberParts";
      var d = u("formatDate");
      u("formatTime"), u("formatNumber"), u("formatList"), u("formatDisplayName"), h("formatDate"), h("formatTime");
    }
  }
]);
