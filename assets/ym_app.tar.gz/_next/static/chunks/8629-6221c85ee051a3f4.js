(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [8629],
  {
    985: (e, t, a) => {
      "use strict";
      a.d(t, { kv: () => i, Fn: () => s.OverviewBlock, tm: () => r.t });
      var r = a(97774), n = a(93064);
      let i = n.gK.model("BaseOverview", {
        title: n.gK.maybe(n.gK.string),
        message: n.gK.maybe(n.gK.string),
        isExpandable: n.gK.optional(n.gK.boolean, true),
        visibleLinesCount: n.gK.optional(n.gK.number, 3)
      });
      var s = a(9283);
    },
    3809: (e) => {
      e.exports = {
        root: "DonationCard_root__81nc5",
        donation: "DonationCard_donation__SlArJ",
        cover: "DonationCard_cover__Mqb3g",
        image: "DonationCard_image__xABTn",
        container: "DonationCard_container__1xkqs",
        text: "DonationCard_text__mdeXx",
        artist: "DonationCard_artist__xq4Jw",
        goal: "DonationCard_goal__6BdcG",
        label: "DonationCard_label__T_hDw",
        shimmer: "DonationCard_shimmer__cMO7r",
        shimmerContainer: "DonationCard_shimmerContainer__9ZH20",
        shimmerText: "DonationCard_shimmerText__TrtjR",
        shimmerCover: "DonationCard_shimmerCover__U6Rwp",
        shimmerArtist: "DonationCard_shimmerArtist__jRQCV",
        shimmerGoal: "DonationCard_shimmerGoal__UGSTd",
        shimmerButton: "DonationCard_shimmerButton__LYfOm"
      };
    },
    4991: (e, t, a) => {
      "use strict";
      a.d(t, { m: () => o });
      var r = a(61910), n = a(43350), i = a(62395), s = a(74125);
      let o = (e2) => {
        let { artistId: t2, viewUuid: a2 } = e2, o2 = (0, i.st)(), { hash: l } = (0, i.gf)(), { pageId: c } = (0, s.$au)(), { objectsCount: d, objectType: m, objectId: u, objectPosX: _, objectPosY: C, objectPos: h } = (0, s.Jfv)(), v = (0, s.NKK)(), g = (0, s.UlF)(), p = (0, r.useCallback)(
          (e3) => {
            let a3 = (0, n.Fx)({
              params: {
                hash: l,
                artistId: t2,
                objectsCount: d,
                objectType: m,
                objectId: u,
                objectPosX: _,
                objectPosY: C,
                to: e3
              },
              logger: g,
              context: "useSendEventOnConcertNavigated"
            });
            o2 && a3 && (0, n.U6)(o2.evgenInstance, a3);
          },
          [o2, t2, l, g, u, _, C, m, d]
        ), x = (0, r.useCallback)(
          (e3) => {
            let r2 = (0, n.Fx)({
              params: { hash: l, artistId: t2, viewUuid: a2, objectId: u, objectPos: h, to: e3 },
              logger: g,
              context: "useSendEventOnConcertNavigated"
            });
            o2 && r2 && a2 && (0, n.mh)(o2.evgenInstance, r2);
          },
          [o2, t2, l, g, u, h, a2]
        );
        return (0, r.useCallback)(
          (e3) => {
            if (o2 && c && s.xKB.includes(c))
              switch (c) {
                case s._Q$.ARTIST:
                  p(e3);
                  break;
                case s._Q$.ARTIST_CONCERTS:
                  x(e3);
                  break;
                case s._Q$.SEARCH:
                  v({ to: n.QT.ConcertPurchaseScreen });
              }
          },
          [o2, c, v, x, p]
        );
      };
    },
    5631: (e, t, a) => {
      "use strict";
      a.d(t, { DonationCarousel: () => u });
      var r = a(54486), n = a(50420), i = a(61910), s = a(15209), o = a(81203), l = a(80585), c = a(91097), d = a.n(c);
      let m = (e2) => {
        let {
          className: t2,
          forwardRef: a2,
          headerClassName: c2,
          containerClassName: m2,
          headingVariant: u2,
          title: _,
          viewAllActionLink: C,
          description: h,
          children: v,
          ...g
        } = e2, p = (0, i.useId)(), x = (0, i.useRef)(null);
        return (0, r.jsxs)("section", {
          ref: a2,
          className: (0, n.$)(d().root, t2),
          ...(0, s.getDataAttrFromProps)(g),
          children: [
            (0, r.jsx)(l.Tw, {
              className: c2,
              labeledForId: p,
              title: _,
              description: h,
              viewAllActionLink: C,
              controls: (0, r.jsx)(l.X9, { className: d().controls, carouselRef: x }),
              headingVariant: u2,
              withDescription: !!h
            }),
            (0, r.jsx)(o.Carousel, {
              ref: x,
              itemClassName: (0, n.$)(d().item, d().important),
              className: m2,
              "aria-labelledby": p,
              children: v
            })
          ]
        });
      }, u = (0, i.forwardRef)((e2, t2) => (0, r.jsx)(m, { forwardRef: t2, ...e2 }));
    },
    7981: (e, t, a) => {
      "use strict";
      a.d(t, {
        vK: () => C.DonationButton,
        Xx: () => h.DonationCard,
        x0: () => v.DonationCarousel,
        kZ: () => A,
        eG: () => _,
        GT: () => o,
        Q$: () => u,
        cg: () => r.useSendEventOnDonationNavigated,
        CC: () => n.useSendEventOnDonationShowedOrHidden
      });
      var r = a(18139), n = a(31135), i = a(93064), s = a(63695);
      let o = (e2) => {
        let { url: t2, artist: a2, goal: r2 } = e2;
        return (0, i.wg)({ url: t2, goal: r2, artist: (0, s.as)({ artist: a2 }) });
      };
      var l = a(97396), c = a(61910), d = a(74125);
      let m = { [d.Sxu.Light]: "yandex_music", [d.Sxu.Dark]: "yandex_music_dark" }, u = () => {
        let e2 = (0, l.useSearchParams)(), { theme: t2 } = (0, d.DPo)();
        return (0, c.useCallback)(
          (a2) => {
            if (!t2) return a2;
            let r2 = new URLSearchParams(e2);
            r2.set("wl", m[t2]);
            let n2 = e2.get(d.K3F.UTM_CAMPAIGN);
            return n2 && r2.set("meta", "campaignid_".concat(n2)), (0, d.Cvn)(a2, r2);
          },
          [t2, e2]
        );
      }, _ = i.gK.model("Donation", { url: i.gK.string, artist: s.PK, goal: i.gK.maybe(i.gK.string) });
      var C = a(74627), h = a(30623), v = a(5631), g = a(54486), p = a(50420), x = a(22674), N = a(3809), b = a.n(N);
      let f = (e2) => {
        let { isActive: t2 } = e2;
        return (0, g.jsxs)("div", {
          className: (0, p.$)(b().shimmer, b().donation),
          children: [
            (0, g.jsx)(x.Shimmer, { isActive: t2, radius: "round", className: b().shimmerCover }),
            (0, g.jsxs)("div", {
              className: b().shimmerContainer,
              children: [
                (0, g.jsxs)("div", {
                  className: b().shimmerText,
                  children: [
                    (0, g.jsx)(x.Shimmer, { isActive: t2, radius: "xxxl", className: b().shimmerArtist }),
                    (0, g.jsx)(x.Shimmer, { isActive: t2, radius: "xxxl", className: b().shimmerGoal })
                  ]
                }),
                (0, g.jsx)(x.Shimmer, { isActive: t2, radius: "xxxl", className: b().shimmerButton })
              ]
            })
          ]
        });
      }, A = (e2) => Array.from({ length: 10 }, (t2, a2) => (0, g.jsx)(f, { isActive: e2 }, a2));
    },
    9283: (e, t, a) => {
      "use strict";
      a.d(t, { OverviewBlock: () => A });
      var r = a(54486), n = a(50420), i = a(28303), s = a(61910), o = a.t(s, 2), l = a(31500), c = a(94377), d = {
        4601: (e2, t2, a2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useToggle = void 0;
          let r2 = a2(810);
          t2.useToggle = (e3) => {
            let [t3, a3] = (0, r2.useState)(e3);
            (0, r2.useEffect)(() => {
              a3(e3);
            }, [e3]);
            let n2 = (0, r2.useCallback)(() => {
              a3((e4) => !e4);
            }, []), i2 = (0, r2.useCallback)(() => {
              a3(true);
            }, []), s2 = (0, r2.useCallback)(() => {
              a3(false);
            }, []);
            return { state: t3, toggle: n2, setState: a3, toggleTrue: i2, toggleFalse: s2 };
          };
        },
        352: (e2) => {
          e2.exports = c;
        },
        810: (e2) => {
          e2.exports = o;
        }
      }, m = {};
      function u(e2) {
        var t2 = m[e2];
        if (void 0 !== t2) return t2.exports;
        var a2 = m[e2] = { exports: {} };
        return d[e2](a2, a2.exports, u), a2.exports;
      }
      var _ = {};
      (() => {
        Object.defineProperty(_, "__esModule", { value: true }), _.useTruncate = void 0;
        let e2 = u(352), t2 = u(810), a2 = u(4601);
        _.useTruncate = (r2) => {
          let [n2, i2] = (0, t2.useState)(0), { state: s2, toggleTrue: o2, toggleFalse: l2 } = (0, a2.useToggle)(false), c2 = (0, t2.useMemo)(
            () => (0, e2.throttle)(() => {
              let { offsetHeight: e3, scrollHeight: t3 } = (null == r2 ? void 0 : r2.current) || {};
              e3 && t3 && n2 < t3 ? o2() : l2();
            }, 100),
            [n2, r2, l2, o2]
          );
          return (0, t2.useEffect)(() => {
            var e3, t3;
            !n2 && (null == (e3 = r2.current) ? void 0 : e3.offsetHeight) && i2(null == (t3 = r2.current) ? void 0 : t3.offsetHeight);
          }, [n2, r2]), (0, t2.useEffect)(
            () => (c2(), window.addEventListener("resize", c2), () => {
              window.removeEventListener("resize", c2);
            }),
            [c2]
          ), { isTruncated: s2 };
        };
      })(), _.__esModule;
      var C = _.useTruncate, h = a(77881), v = a(97800), g = a(74125), p = a(46210), x = a.n(p), N = a(43426), b = a(32692);
      let f = (0, i.PA)((e2) => {
        let { message: t2, title: a2, className: i2, credits: s2, messageClassName: o2 } = e2, {
          modals: { overviewModal: c2 },
          settings: { isMobile: d2 }
        } = (0, g.Pjs)(), { formatMessage: m2 } = (0, N.A)(), { contentRef: u2 } = (0, g.gKY)();
        return (0, r.jsxs)(b.a, {
          title: a2,
          titleProps: (0, l.Am)(l.Kq.overview.OVERVIEW_MODAL_TITLE),
          className: (0, n.$)(x().modal, i2),
          contentClassName: x().modalContent,
          overlayClassName: x().modalOverlay,
          headerClassName: (0, n.$)(x().modalHeader, { [x().modalHeader_withTitle]: a2 }),
          size: "fitContent",
          placement: d2 ? "default" : "right",
          open: c2.isOpened,
          onOpenChange: c2.onOpenChange,
          onClose: c2.close,
          portalNode: d2 ? null : u2,
          isMobile: d2,
          labelClose: m2({ id: "interface-actions.close" }),
          containerProps: (0, l.Am)(l.Kq.overview.OVERVIEW_MODAL),
          closeButtonProps: (0, l.Am)(l.Kq.overview.OVERVIEW_MODAL_CLOSE_BUTTON),
          children: [
            (0, r.jsx)(v.Caption, {
              ...(0, l.Am)(l.Kq.overview.OVERVIEW_MODAL_MESSAGE),
              className: (0, n.$)(x().message, o2),
              size: "l",
              variant: "div",
              children: t2
            }),
            s2
          ]
        });
      }), A = (0, i.PA)((e2) => {
        let {
          meta: t2,
          buttonClassName: a2,
          modalClassName: i2,
          creditsModal: o2,
          messageClassName: c2,
          messageModalClassName: d2,
          textButton: m2,
          withShowButton: u2
        } = e2, _2 = (0, s.useRef)(null), {
          modals: { overviewModal: p2 }
        } = (0, g.Pjs)(), { isTruncated: N2 } = C(_2), b2 = N2 && t2.isExpandable || u2;
        return (0, r.jsxs)(r.Fragment, {
          children: [
            (0, r.jsx)(v.Caption, {
              ref: _2,
              className: (0, n.$)(x().message, c2),
              size: "m",
              variant: "div",
              lineClamp: t2.visibleLinesCount,
              ...(0, l.Am)(l.Kq.overview.OVERVIEW_MESSAGE),
              children: t2.message
            }),
            b2 && t2.message && (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(h.$, {
                  className: (0, n.$)(x().button, a2),
                  onClick: p2.open,
                  radius: "xs",
                  variant: "text",
                  color: "secondary",
                  withRipple: false,
                  ...(0, l.Am)(l.Kq.overview.OVERVIEW_FURTHER_BUTTON),
                  children: (0, r.jsx)(v.Caption, { size: "m", variant: "span", children: m2 })
                }),
                (0, r.jsx)(f, {
                  message: t2.message,
                  title: t2.title,
                  className: i2,
                  credits: o2,
                  messageClassName: d2
                })
              ]
            })
          ]
        });
      });
    },
    10351: (e, t, a) => {
      "use strict";
      a.d(t, { AfishaWidget: () => C });
      var r = a(54486), n = a(61910), i = a(43426), s = a(31500), o = a(77881), l = a(32692), c = a(39610), d = a(74125), m = a(74391), u = a(78683), _ = a.n(u);
      let C = (e2) => {
        let { dataSessionId: t2, isOpened: a2, onOpen: u2, onClose: C2 } = e2, h = (0, d.NFA)().get(d.twC), { formatMessage: v } = (0, i.A)(), g = (0, m.v)(), p = (0, n.useCallback)(
          (e3) => {
            e3.origin === h.afisha.host && "close" === e3.data.type && C2();
          },
          [C2, h.afisha.host]
        );
        (0, n.useEffect)(
          () => (window.addEventListener("message", p), () => {
            window.removeEventListener("message", p);
          }),
          [p]
        );
        let x = (0, n.useCallback)(
          (e3) => {
            e3 ? u2() : C2();
          },
          [C2, u2]
        ), N = g("".concat(h.afisha.host, "/w/sessions/").concat(t2, "?clientKey=").concat(h.afisha.clientId));
        return (0, r.jsxs)(l.a, {
          size: "fitContent",
          placement: "center",
          open: a2,
          onOpenChange: x,
          onClose: C2,
          showHeader: false,
          className: _().widget,
          contentClassName: _().content,
          overlayColor: "full",
          containerProps: (0, s.Am)(s.OA.concert.AFISHA_MODAL),
          children: [
            (0, r.jsx)(c.q, {
              children: (0, r.jsx)(o.$, { "aria-label": v({ id: "interface-actions.close" }), onClick: C2 })
            }),
            (0, r.jsx)("iframe", {
              src: N,
              className: _().root,
              referrerPolicy: "no-referrer",
              sandbox: "allow-forms allow-modals allow-popups allow-scripts allow-same-origin",
              allow: "clipboard-read clipboard-write"
            })
          ]
        });
      };
    },
    18139: (e, t, a) => {
      "use strict";
      a.d(t, { useSendEventOnDonationNavigated: () => o });
      var r = a(43350), n = a(62395), i = a(8817), s = a(74125);
      let o = () => {
        let { hash: e2 } = (0, n.gf)(), t2 = (0, s.UlF)(), a2 = (0, n.st)(), { pageId: o2 } = (0, s.$au)(), { blockId: l, blockType: c, blockPosX: d, blockPosY: m } = (0, s.N8n)(), {
          objectType: u,
          objectId: _,
          objectPosX: C,
          objectPosY: h,
          objectsCount: v,
          mainObjectId: g,
          mainObjectType: p
        } = (0, s.Jfv)();
        return (0, i.c)((n2, i2) => {
          if (!a2 || !o2) return;
          let x = s.Wft[o2];
          if (!x) return;
          let N = {
            to: n2,
            objectType: u,
            objectId: _,
            objectPosX: C,
            objectPosY: h,
            hash: e2,
            pageId: x,
            mainObjectType: p,
            mainObjectId: g,
            entityType: c,
            entityId: l,
            entityPosX: d,
            entityPosY: m,
            objectsCount: v,
            from: x
          };
          i2 && (N.deepLink = i2);
          let b = (0, r.Fx)({ params: N, logger: t2, context: "useSendEventOnDonationNavigated" });
          b && (0, r.QS)(a2.evgenInstance, b);
        });
      };
    },
    20065: (e) => {
      e.exports = {
        root: "ConcertCardWithImage_root__NHF59",
        cover: "ConcertCardWithImage_cover__3V2fk",
        meta: "ConcertCardWithImage_meta__mhsYf",
        info: "ConcertCardWithImage_info__9VjYG",
        location: "ConcertCardWithImage_location__2mcwY",
        rating: "ConcertCardWithImage_rating__dL4_q",
        separator: "ConcertCardWithImage_separator__WhzW4",
        cashbackTitle: "ConcertCardWithImage_cashbackTitle__lfr7z",
        cashback: "ConcertCardWithImage_cashback__sNa2M",
        title: "ConcertCardWithImage_title__nPyZ6",
        shimmerCover: "ConcertCardWithImage_shimmerCover___X6xn",
        shimmerTitle: "ConcertCardWithImage_shimmerTitle__YgaQa",
        button: "ConcertCardWithImage_button__osv22",
        shimmerButton: "ConcertCardWithImage_shimmerButton__JZEFY"
      };
    },
    25045: (e, t, a) => {
      "use strict";
      a.d(t, { ConcertsBlock: () => C });
      var r = a(54486), n = a(50420), i = a(44282), s = a(61910), o = a(43350), l = a(81203), c = a(80585), d = a(4991), m = a(63693), u = a.n(m);
      let _ = (e2) => {
        let {
          artistId: t2,
          forwardRef: a2,
          isLoading: m2,
          title: _2,
          viewAllActionLink: C2,
          children: h,
          className: v,
          containerClassName: g,
          headerClassName: p,
          itemClassName: x,
          headingVariant: N,
          ...b
        } = e2, f = (0, s.useId)(), A = (0, s.useRef)(null), k = (0, d.m)({ artistId: t2 }), w = (0, s.useCallback)(() => {
          k(o.H2.ArtistConcertsScreen);
        }, [k]), j = (0, s.useMemo)(
          () => (0, i.A)(h, 2).slice(0, 4).map((e3, t3) => (0, r.jsx)("div", { className: u().concertsColumn, children: e3 }, t3)),
          [h]
        );
        return (0, r.jsxs)("section", {
          ref: a2,
          className: (0, n.$)(u().root, v),
          ...b,
          children: [
            (0, r.jsx)(c.Tw, {
              className: p,
              labeledForId: f,
              title: _2,
              viewAllActionLink: C2,
              onViewAllAction: w,
              controls: (0, r.jsx)(c.X9, { className: u().controls, carouselRef: A }),
              headingVariant: N
            }),
            (0, r.jsx)(l.Carousel, {
              itemClassName: (0, n.$)(u().item, { [u().item_singleColumn]: 2 >= s.Children.count(h) }, x),
              className: (0, n.$)(g, { [u().preventScroll]: m2 }),
              ref: A,
              "aria-labelledby": f,
              children: m2 ? Array.from(
                { length: 2 },
                (e3, t3) => (0, r.jsx)("div", { className: u().concertsColumn, children: (0, c.Tb)(2) }, t3)
              ) : j
            })
          ]
        });
      }, C = (0, s.forwardRef)((e2, t2) => (0, r.jsx)(_, { forwardRef: t2, ...e2 }));
    },
    27654: (e, t, a) => {
      "use strict";
      a.d(t, { SearchBestResultsMeta: () => c });
      var r = a(54486), n = a(28303), i = a(61910), s = a(97800), o = a(48516), l = a.n(o);
      let c = (0, n.PA)((e2) => {
        let { id: t2, concert: a2 } = e2, n2 = [], o2 = (0, r.jsx)(s.Caption, { variant: "span", size: "m", weight: "medium", "aria-hidden": true, children: "•" });
        return (null == a2 ? void 0 : a2.city) && n2.push(
          (0, r.jsx)(s.Caption, { variant: "span", size: "m", weight: "medium", lineClamp: 1, children: a2.city })
        ), (null == a2 ? void 0 : a2.contentRating) && n2.push(
          o2,
          (0, r.jsx)(s.Caption, { variant: "span", size: "m", weight: "medium", children: a2.contentRating })
        ), (0, r.jsxs)("div", {
          className: l().root,
          id: t2,
          children: [
            (0, r.jsx)(s.Caption, {
              variant: "div",
              size: "m",
              weight: "medium",
              className: l().city,
              lineClamp: 1,
              children: null == a2 ? void 0 : a2.title
            }),
            (0, r.jsx)("div", { className: l().info, children: n2.map((e3, t3) => (0, i.cloneElement)(e3, { key: t3 })) })
          ]
        });
      });
    },
    30623: (e, t, a) => {
      "use strict";
      a.d(t, { DonationCard: () => g });
      var r = a(54486), n = a(50420), i = a(61910), s = a(43426), o = a(47713), l = a(15209), c = a(77881), d = a(5956), m = a(6971), u = a(97800), _ = a(80585), C = a(3809), h = a.n(C);
      let v = (e2) => {
        let { artist: t2, goal: a2, onNavigateToArtist: i2, onNavigateToDonation: C2, forwardRef: v2, ...g2 } = e2, { formatMessage: p } = (0, s.A)();
        return (0, r.jsxs)("div", {
          ref: v2,
          className: (0, n.$)(h().root, h().donation),
          ...(0, l.getDataAttrFromProps)(g2),
          children: [
            (0, r.jsx)(m.Paper, {
              radius: "round",
              className: h().cover,
              children: (0, r.jsx)(_.N_, {
                href: t2.url,
                onClick: i2,
                "aria-label": p({ id: "entity-names.artist-name" }, { artistName: t2.name }),
                children: (0, r.jsx)(_.BW, {
                  className: h().image,
                  src: t2.coverUri,
                  isAvailable: t2.isAvailable,
                  size: 200,
                  fit: "cover",
                  withAvatarReplace: true,
                  "aria-hidden": true
                })
              })
            }),
            (0, r.jsxs)("div", {
              className: h().container,
              children: [
                (0, r.jsxs)("div", {
                  className: h().text,
                  children: [
                    (0, r.jsx)(u.Heading, {
                      variant: "span",
                      size: "xs",
                      weight: "bold",
                      lineClamp: 2,
                      className: h().artist,
                      children: t2.name
                    }),
                    (0, r.jsx)(u.Caption, {
                      variant: "span",
                      type: "text",
                      size: "l",
                      weight: "medium",
                      lineClamp: 2,
                      className: h().goal,
                      children: a2
                    })
                  ]
                }),
                (0, r.jsxs)(c.$, {
                  role: "link",
                  size: "s",
                  color: "secondary",
                  onClick: C2,
                  className: h().label,
                  withRipple: false,
                  children: [
                    (0, r.jsx)(d.Icon, { variant: "ruble", size: "xxxs" }),
                    (0, r.jsx)(u.Caption, {
                      type: "text",
                      size: "m",
                      weight: "medium",
                      variant: "span",
                      children: (0, r.jsx)(o.A, { id: "donation.support-button" })
                    })
                  ]
                })
              ]
            })
          ]
        });
      }, g = (0, i.forwardRef)((e2, t2) => (0, r.jsx)(v, { forwardRef: t2, ...e2 }));
    },
    31135: (e, t, a) => {
      "use strict";
      a.d(t, { useSendEventOnDonationShowedOrHidden: () => o });
      var r = a(43350), n = a(62395), i = a(8817), s = a(74125);
      let o = () => {
        let { hash: e2 } = (0, n.gf)(), t2 = (0, s.UlF)(), a2 = (0, n.st)(), { pageId: o2 } = (0, s.$au)(), { blockId: l, blockType: c, blockPosX: d, blockPosY: m } = (0, s.N8n)(), {
          objectType: u,
          objectId: _,
          objectPosX: C,
          objectPosY: h,
          objectsCount: v,
          mainObjectId: g,
          mainObjectType: p
        } = (0, s.Jfv)();
        return (0, i.c)((n2, i2) => {
          if (!a2 || !o2) return;
          let x = s.Wft[o2];
          if (!x) return;
          let N = (0, r.Fx)({
            params: {
              objectType: u,
              objectId: _,
              objectPosX: C,
              objectPosY: h,
              hash: e2,
              pageId: x,
              mainObjectType: p,
              mainObjectId: g,
              entityType: c,
              entityId: l,
              entityPosX: d,
              entityPosY: m,
              objectsCount: v,
              viewUuid: i2
            },
            logger: t2,
            context: "useSendEventOnDonationShowedOrHidden"
          });
          N && (n2 ? (0, r.Pf)(a2.evgenInstance, N) : (0, r.nv)(a2.evgenInstance, N));
        });
      };
    },
    31820: (e, t, a) => {
      "use strict";
      a.d(t, { useGetPriceText: () => i });
      var r = a(43426), n = a(8817);
      let i = () => {
        let { formatMessage: e2, formatNumber: t2 } = (0, r.A)();
        return (0, n.c)((a2) => {
          var r2, n2;
          return (null == (r2 = a2.price) ? void 0 : r2.value) ? e2(
            { id: "payment.min-price" },
            {
              value: t2(a2.price.value, {
                style: "currency",
                currency: null == (n2 = a2.price) ? void 0 : n2.currency,
                maximumFractionDigits: 0
              })
            }
          ) : e2({ id: "payment.buy" });
        });
      };
    },
    32949: (e, t, a) => {
      "use strict";
      a.d(t, { ArtistMeta: () => u });
      var r = a(54486), n = a(28303), i = a(61910), s = a(43426), o = a(97800), l = a(74125), c = a(67340), d = a(48516), m = a.n(d);
      let u = (0, n.PA)((e2) => {
        let { id: t2, concert: a2 } = e2, { formatDate: n2 } = (0, s.A)(), d2 = [], u2 = (0, r.jsx)(o.Caption, { variant: "span", size: "m", weight: "medium", "aria-hidden": true, children: "•" });
        return (null == a2 ? void 0 : a2.place) && d2.push(
          (0, r.jsx)(o.Caption, { variant: "span", size: "m", weight: "medium", lineClamp: 1, children: a2.place })
        ), (null == a2 ? void 0 : a2.datetime) && d2.push(
          u2,
          (0, r.jsx)(o.Caption, {
            variant: "span",
            size: "m",
            weight: "medium",
            className: m().time,
            children: n2(a2.datetime, (0, l.fS8)())
          })
        ), (null == a2 ? void 0 : a2.contentRating) && d2.push(
          u2,
          (0, r.jsx)(o.Caption, { variant: "span", size: "m", weight: "medium", children: a2.contentRating })
        ), (0, r.jsxs)("div", {
          className: m().root,
          id: t2,
          children: [
            (0, r.jsx)(o.Caption, {
              variant: "div",
              size: "m",
              weight: "medium",
              className: m().city,
              lineClamp: 1,
              children: null == a2 ? void 0 : a2.city
            }),
            (0, r.jsx)("div", { className: m().info, children: d2.map((e3, t3) => (0, i.cloneElement)(e3, { key: t3 })) }),
            (null == a2 ? void 0 : a2.isCashbackExperimentEnabled) && (null == a2 ? void 0 : a2.cashbackTitle) && (0, r.jsx)(c.m, { className: m().cashback, title: a2.cashbackTitle })
          ]
        });
      });
    },
    36245: (e) => {
      e.exports = {
        root: "ConcertImage_root__gZpOa",
        root_withMask: "ConcertImage_root_withMask__1ayfK",
        image: "ConcertImage_image__xtZCZ",
        day: "ConcertImage_day__c90Ih",
        month: "ConcertImage_month__Ic5k5",
        date: "ConcertImage_date__aH1IR",
        weekday: "ConcertImage_weekday__kXeo3",
        important: "ConcertImage_important__0o7jF"
      };
    },
    41625: (e) => {
      e.exports = {
        root: "ConcertDate_root__xnVG1",
        month: "ConcertDate_month__ti5Na",
        day: "ConcertDate_day__YibpP",
        weekday: "ConcertDate_weekday__fBZXo"
      };
    },
    46210: (e) => {
      e.exports = {
        message: "OverviewBlock_message__f41Rq",
        modal: "OverviewBlock_modal__Jxiv2",
        modalHeader: "OverviewBlock_modalHeader__nerV2",
        modalHeader_withTitle: "OverviewBlock_modalHeader_withTitle__gjKhp",
        modalContent: "OverviewBlock_modalContent__fw4fH",
        button: "OverviewBlock_button__k7t4c",
        modalOverlay: "OverviewBlock_modalOverlay__1dp_D"
      };
    },
    48516: (e) => {
      e.exports = {
        root: "ConcertMeta_root__CkKU3",
        city: "ConcertMeta_city__ngDq2",
        info: "ConcertMeta_info__czKlU",
        time: "ConcertMeta_time__gX09u",
        cashback: "ConcertMeta_cashback__fkZfk"
      };
    },
    56689: (e, t, a) => {
      "use strict";
      a.d(t, { ConcertDate: () => m });
      var r = a(54486), n = a(50420), i = a(43426), s = a(31500), o = a(97800), l = a(74125), c = a(41625), d = a.n(c);
      let m = (e2) => {
        let {
          datetime: t2,
          className: a2,
          monthClassName: c2,
          dayClassName: m2,
          weekdayClassName: u,
          withWeekday: _ = true,
          ...C
        } = e2, { formatDate: h } = (0, i.A)(), v = (0, l.mkF)(t2);
        return (0, r.jsxs)("div", {
          className: (0, n.$)(d().root, a2),
          "aria-label": h(t2, (0, l.sDH)()),
          ...C,
          ...(0, s.Am)(s.OA.concert.CONCERT_DATE),
          children: [
            (0, r.jsx)(o.Caption, {
              variant: "div",
              size: "xs",
              weight: "bold",
              className: (0, n.$)(d().month, c2),
              ...(0, s.Am)(s.OA.concert.CONCERT_DATE_MONTH),
              children: v
            }),
            (0, r.jsx)(o.Caption, {
              variant: "div",
              className: (0, n.$)(d().day, m2),
              ...(0, s.Am)(s.OA.concert.CONCERT_DATE_DAY),
              children: h(t2, (0, l.Uw7)())
            }),
            _ && (0, r.jsx)(o.Caption, {
              variant: "div",
              size: "xs",
              weight: "bold",
              className: (0, n.$)(d().weekday, u),
              ...(0, s.Am)(s.OA.concert.CONCERT_DATE_WEEKDAY),
              children: h(t2, { weekday: "short" })
            })
          ]
        });
      };
    },
    61484: (e) => {
      e.exports = {
        root: "CashbackBadge_root__hStMF",
        icon: "CashbackBadge_icon__RJ6qe",
        title: "CashbackBadge_title__neGD7"
      };
    },
    63693: (e) => {
      e.exports = {
        root: "ConcertsBlock_root__d_1G3",
        controls: "ConcertsBlock_controls__oULxu",
        item: "ConcertsBlock_item__jMAX9",
        item_singleColumn: "ConcertsBlock_item_singleColumn__p8ilp",
        preventScroll: "ConcertsBlock_preventScroll__YeeZH",
        concertsColumn: "ConcertsBlock_concertsColumn__2M2t_"
      };
    },
    64543: (e, t, a) => {
      "use strict";
      a.d(t, { J: () => n });
      var r = a(74125);
      let n = (e2) => {
        let { h: t2, s: a2, l: n2 } = (0, r.g8k)(e2);
        return "hsl(".concat(t2, ", ").concat(a2, "%, ").concat(n2 <= 55 ? n2 + 20 : n2 - 20, "%)");
      };
    },
    67340: (e, t, a) => {
      "use strict";
      a.d(t, { m: () => d });
      var r = a(54486), n = a(50420), i = a(31500), s = a(5956), o = a(97800), l = a(61484), c = a.n(l);
      let d = (e2) => {
        let { title: t2, className: a2, titleClassName: l2 } = e2;
        return (0, r.jsxs)("div", {
          className: (0, n.$)(c().root, a2),
          children: [
            (0, r.jsx)(s.Icon, { "aria-hidden": true, className: c().icon, variant: "plus" }),
            (0, r.jsx)(o.Caption, {
              variant: "span",
              type: "text",
              size: "m",
              weight: "medium",
              lineClamp: 1,
              className: (0, n.$)(c().title, l2),
              ...(0, i.Am)(i.OA.concert.CONCERT_CARD_CASHBACK),
              children: t2
            })
          ]
        });
      };
    },
    67937: (e) => {
      e.exports = {
        root: "ConcertCard_root__fcR9B",
        ripple: "ConcertCard_ripple__PW4xI",
        date: "ConcertCard_date__ECoa3",
        dateWithMask: "ConcertCard_dateWithMask__si35m",
        important: "ConcertCard_important__dQYxN",
        dateColor: "ConcertCard_dateColor__muPRD",
        button: "ConcertCard_button__GQxNL"
      };
    },
    73219: (e, t, a) => {
      "use strict";
      a.d(t, { ConcertImage: () => v });
      var r = a(54486), n = a(50420), i = a(28303), s = a(31500), o = a(27510), l = a(58360), c = a(74125), d = a(15209);
      let m = (e2) => (0, d.httpsReplacer)(e2.replace("%%", "960x690_noncrop"));
      var u = a(64543), _ = a(56689), C = a(36245), h = a.n(C);
      let v = (0, i.PA)((e2) => {
        let { uri: t2, withMask: a2, datetime: i2, coverColor: d2 } = e2, { experiments: C2 } = (0, c.Pjs)(), v2 = C2.checkExperiment(c.zal.NewConcertsTicketRedesign, "on") && a2, g = (0, o.L)(() => {
          if (d2) return { "--concert-image-date-background": (0, u.J)(d2) };
        });
        return (0, r.jsxs)("div", {
          className: (0, n.$)(h().root, { [h().root_withMask]: v2 }),
          style: g,
          children: [
            (0, r.jsx)(l.Image, {
              className: h().image,
              fit: "cover",
              src: t2,
              withAvatarReplace: true,
              createUrlReplacer: m,
              "aria-hidden": true,
              ...(0, s.Am)(s.OA.concert.CONCERT_CARD_IMAGE)
            }),
            i2 && (0, r.jsx)(_.ConcertDate, {
              dayClassName: h().day,
              weekdayClassName: (0, n.$)(h().weekday, h().important),
              monthClassName: h().month,
              className: h().date,
              datetime: i2
            })
          ]
        });
      });
    },
    74391: (e, t, a) => {
      "use strict";
      a.d(t, { v: () => s });
      var r = a(97396), n = a(61910), i = a(74125);
      let s = () => {
        let e2 = (0, r.useSearchParams)();
        return (0, n.useCallback)(
          (t2) => {
            let a2 = e2.get(i.K3F.UTM_CAMPAIGN);
            if (!a2) return t2;
            let r2 = new URLSearchParams();
            return r2.set(i.K3F.UTM_SOURCE, "campaignid_".concat(a2)), (0, i.Cvn)(t2, r2);
          },
          [e2]
        );
      };
    },
    74627: (e, t, a) => {
      "use strict";
      a.d(t, { DonationButton: () => u });
      var r = a(54486), n = a(28303), i = a(61910), s = a(43426), o = a(15209), l = a(31500), c = a(77881), d = a(5956);
      let m = (0, n.PA)((e2) => {
        let { onClick: t2, className: a2, size: n2 = "s", iconSize: i2 = "xxs", forwardRef: m2, ...u2 } = e2, { formatMessage: _ } = (0, s.A)();
        return (0, r.jsx)(c.$, {
          ref: m2,
          size: n2,
          variant: "default",
          radius: "round",
          color: "secondary",
          onClick: t2,
          className: a2,
          "aria-label": _({ id: "donation.button-text" }),
          icon: (0, r.jsx)(d.Icon, { size: i2, variant: "ruble" }),
          ...(0, o.getDataAttrFromProps)(u2),
          ...(0, l.Am)(l.S7.DONATION_BUTTON)
        });
      }), u = (0, i.forwardRef)((e2, t2) => (0, r.jsx)(m, { forwardRef: t2, ...e2 }));
    },
    77217: (e, t, a) => {
      "use strict";
      a.d(t, {
        hW: () => h.AfishaWidget,
        ZH: () => p.ArtistMeta,
        mi: () => v.m,
        VN: () => g.ConcertCard,
        Qb: () => b.ConcertCardWithImage,
        LY: () => j,
        dE: () => T.ConcertDate,
        Wt: () => y.ConcertImage,
        aR: () => C,
        BD: () => O.ConcertsBlock,
        ub: () => x.SearchBestResultsMeta,
        wP: () => N.SearchMeta,
        HN: () => l,
        oP: () => c,
        ho: () => o,
        Yi: () => d.useGetPriceText
      });
      var r = a(93064);
      let n = /[+-]\d{2}:?\d{2}/, i = (e2) => null == e2 ? void 0 : e2.replace(n, ""), s = (e2) => {
        if (e2) return { value: e2.value, currency: e2.currency };
      }, o = (e2, t2) => {
        var a2;
        let { uri: n2, color: o2 } = e2.cover || {};
        return (0, r.wg)({
          id: e2.id,
          title: e2.concertTitle,
          city: e2.city,
          place: e2.place,
          datetime: e2.datetime && i(e2.datetime),
          contentRating: e2.contentRating,
          dataSessionId: e2.dataSessionId,
          cover: { uri: n2, color: o2 },
          rank: e2.rank,
          cashbackTitle: null == (a2 = e2.cashback) ? void 0 : a2.title,
          price: s(t2)
        });
      }, l = (e2) => o(e2.data.concert, e2.data.minPrice), c = (e2) => {
        var t2, a2;
        return (0, r.wg)({
          id: e2.id,
          dataSessionId: null != (a2 = e2["data-session-id"]) ? a2 : "",
          datetime: e2.datetime && i(e2.datetime),
          city: e2.city,
          place: e2.place,
          contentRating: e2.contentRating,
          price: s(e2.minPrice),
          cashbackTitle: null == (t2 = e2.cashback) ? void 0 : t2.title,
          title: e2.concertTitle
        });
      };
      a(64543), a(74391);
      var d = a(31820), m = a(74125), u = a(26433);
      let _ = r.gK.model("Price", { value: r.gK.number, currency: r.gK.string }), C = r.gK.model("Concert", {
        id: r.gK.string,
        dataSessionId: r.gK.maybe(r.gK.string),
        datetime: r.gK.maybe(r.gK.string),
        city: r.gK.maybe(r.gK.string),
        place: r.gK.maybe(r.gK.string),
        contentRating: r.gK.maybe(r.gK.string),
        price: r.gK.maybe(_),
        cashbackTitle: r.gK.maybe(r.gK.string),
        title: r.gK.maybe(r.gK.string),
        cover: r.gK.maybe(u.$B),
        rank: r.gK.maybe(r.gK.number)
      }).views((e2) => ({
        get isCashbackExperimentEnabled() {
          let { experiments: t2 } = (0, r.Zn)(e2);
          return t2.checkExperiment(m.zal.WebNextConcertsCashback, "on");
        }
      })).actions((e2) => ({ getKey: (t2) => "".concat(t2, "_").concat(e2.id) }));
      var h = a(10351), v = a(67340), g = a(87184), p = a(32949), x = a(27654), N = a(83952), b = a(81217), f = a(54486), A = a(22674), k = a(20065), w = a.n(k);
      let j = (e2) => {
        let { isActive: t2, withPriceButton: a2 } = e2;
        return (0, f.jsxs)("div", {
          className: w().root,
          children: [
            (0, f.jsx)(A.Shimmer, { radius: "m", className: w().shimmerCover, isActive: t2 }),
            (0, f.jsx)("div", {
              className: w().meta,
              children: (0, f.jsx)(A.Shimmer, { isActive: t2, radius: "xxxl", className: w().shimmerTitle })
            }),
            a2 && (0, f.jsx)(A.Shimmer, { isActive: t2, radius: "xxxl", className: w().shimmerButton })
          ]
        });
      };
      var T = a(56689), y = a(73219), O = a(25045);
    },
    78683: (e) => {
      e.exports = {
        root: "AfishaWidget_root__Fu9a6",
        content: "AfishaWidget_content__YFmbs",
        widget: "AfishaWidget_widget__ZdvqS"
      };
    },
    81217: (e, t, a) => {
      "use strict";
      a.d(t, { ConcertCardWithImage: () => A });
      var r = a(54486), n = a(28303), i = a(47713), s = a(43350), o = a(31500), l = a(8817), c = a(27510), d = a(62443), m = a(77881), u = a(39610), _ = a(97800), C = a(74125), h = a(31820), v = a(10351), g = a(67340), p = a(73219), x = a(20065), N = a.n(x), b = (function(e2) {
        return e2.SPACE = "Space", e2.ENTER = "Enter", e2;
      })(b || {});
      let f = " • ", A = (0, n.PA)((e2) => {
        var t2, a2, n2;
        let { concert: x2, withMask: b2 = true, withPriceButton: A2 } = e2, { state: k, toggleTrue: w, toggleFalse: j } = (0, d.e)(false), { ref: T, intersectionPropertyId: y } = (0, C.nMI)(), { experiments: O } = (0, C.Pjs)(), E = O.checkExperiment(C.zal.WebNextConcertPage, "on"), I = (0, C.NKK)(), R = (0, h.useGetPriceText)(), { href: D } = (0, C.uvd)("/concert/:concertId", { params: { concertId: x2.id } }), S = (0, C.ZpR)(D), K = R(x2), P = (0, l.c)((e3) => {
          I({ to: s.QT.ConcertPurchaseScreen }), w(), null == e3 || e3.stopPropagation();
        }), B = (0, l.c)((e3) => {
          if (!E) return void P(e3);
          S(e3);
        }), M = (0, l.c)((e3) => {
          ("Space" === e3.code || "Enter" === e3.code) && (e3.preventDefault(), B());
        }), W = (0, l.c)((e3) => {
          E && (P(e3), e3.preventDefault());
        }), $ = (0, l.c)((e3) => {
          let t3 = [];
          return x2.city && t3.push(x2.city), x2.place && t3.push(x2.place), t3.join(e3);
        }), z = (0, c.L)(() => {
          if (x2.isCashbackExperimentEnabled && x2.cashbackTitle)
            return (0, r.jsx)(g.m, {
              className: N().cashback,
              titleClassName: N().cashbackTitle,
              title: x2.cashbackTitle
            });
        });
        return (0, r.jsxs)(r.Fragment, {
          children: [
            (0, r.jsxs)("div", {
              className: N().root,
              role: "button",
              tabIndex: 0,
              onClick: B,
              onKeyDown: M,
              ref: T,
              "data-intersection-property-id": y,
              ...(0, o.Am)(o.OA.concert.CONCERT_CARD),
              children: [
                (0, r.jsx)(u.q, {
                  children: (0, r.jsx)(_.Caption, {
                    variant: "div",
                    children: (0, r.jsx)(i.A, { id: "entity-names.concert" })
                  })
                }),
                (0, r.jsx)("div", {
                  className: N().cover,
                  children: (0, r.jsx)(p.ConcertImage, {
                    datetime: x2.datetime,
                    coverColor: null == (t2 = x2.cover) ? void 0 : t2.color,
                    uri: null == (a2 = x2.cover) ? void 0 : a2.uri,
                    withMask: b2
                  })
                }),
                (0, r.jsxs)("div", {
                  className: N().meta,
                  children: [
                    (0, r.jsx)(_.Caption, {
                      variant: "span",
                      type: "controls",
                      size: "l",
                      weight: "medium",
                      lineClamp: 1,
                      className: N().title,
                      ...(0, o.Am)(o.OA.concert.CONCERT_CARD_TITLE),
                      children: x2.title
                    }),
                    (0, r.jsxs)(_.Caption, {
                      variant: "span",
                      type: "controls",
                      weight: "medium",
                      className: N().info,
                      children: [
                        (0, r.jsx)(_.Caption, {
                          variant: "span",
                          type: "controls",
                          weight: "medium",
                          lineClamp: 1,
                          className: N().location,
                          "aria-label": $(" "),
                          ...(0, o.Am)(o.OA.concert.CONCERT_CARD_LOCATION),
                          children: $(f)
                        }),
                        (0, r.jsx)(_.Caption, {
                          "aria-hidden": true,
                          className: N().separator,
                          variant: "span",
                          type: "controls",
                          weight: "medium",
                          children: f
                        }),
                        (0, r.jsx)(_.Caption, {
                          variant: "span",
                          type: "controls",
                          weight: "medium",
                          className: N().rating,
                          ...(0, o.Am)(o.OA.concert.CONCERT_CARD_CONTENT_RATING),
                          children: x2.contentRating
                        })
                      ]
                    }),
                    z
                  ]
                }),
                (null == (n2 = x2.price) ? void 0 : n2.value) && (0, r.jsx)(u.q, { children: (0, r.jsx)(_.Caption, { variant: "div", children: K }) }),
                A2 && (0, r.jsx)(m.$, {
                  "aria-hidden": true,
                  tabIndex: -1,
                  radius: "xxxl",
                  className: N().button,
                  size: "default",
                  variant: "default",
                  color: "primary",
                  onClick: W,
                  ...(0, o.Am)(o.OA.concert.CONCERT_CARD_BUTTON),
                  children: K
                })
              ]
            }),
            (0, r.jsx)(v.AfishaWidget, { dataSessionId: x2.dataSessionId, isOpened: k, onOpen: w, onClose: j })
          ]
        });
      });
    },
    83952: (e, t, a) => {
      "use strict";
      a.d(t, { SearchMeta: () => l });
      var r = a(54486), n = a(28303), i = a(97800), s = a(48516), o = a.n(s);
      let l = (0, n.PA)((e2) => {
        let { id: t2, concert: a2 } = e2;
        return (0, r.jsxs)("div", {
          className: o().root,
          id: t2,
          children: [
            (0, r.jsx)(i.Caption, {
              variant: "div",
              size: "m",
              weight: "medium",
              className: o().city,
              lineClamp: 1,
              children: null == a2 ? void 0 : a2.title
            }),
            (0, r.jsx)(i.Caption, {
              variant: "span",
              size: "m",
              weight: "medium",
              lineClamp: 1,
              children: null == a2 ? void 0 : a2.city
            }),
            (0, r.jsx)(i.Caption, {
              variant: "span",
              size: "m",
              weight: "medium",
              children: null == a2 ? void 0 : a2.contentRating
            })
          ]
        });
      });
    },
    87184: (e, t, a) => {
      "use strict";
      a.d(t, { ConcertCard: () => f });
      var r = a(54486), n = a(50420), i = a(28303), s = a(61910), o = a(43350), l = a(31500), c = a(8817), d = a(62443), m = a(73633), u = a(77881), _ = a(6971), C = a(74125), h = a(4991), v = a(62395), g = a(31820), p = a(10351), x = a(56689), N = a(67937), b = a.n(N);
      let f = (0, i.PA)((e2) => {
        let {
          artistId: t2,
          concert: a2,
          meta: i2,
          viewUuid: N2,
          radius: f2 = "l",
          className: A,
          shouldSendAnalyticsOnHide: k,
          forceAfishaWidget: w,
          shouldShowMask: j
        } = e2, { state: T, toggleTrue: y, toggleFalse: O } = (0, d.e)(false), { experiments: E } = (0, C.Pjs)(), I = !w && E.checkExperiment(C.zal.WebNextConcertPage, "on"), { href: R } = (0, C.uvd)("/concert/:concertId", { params: { concertId: a2.id } }), D = (0, C.ZpR)(R), S = ((e3) => {
          let { artistId: t3, viewUuid: a3 } = e3, r2 = (0, v.st)(), { hash: n2 } = (0, v.gf)(), { pageId: i3 } = (0, C.$au)(), {
            objectsCount: l2,
            objectType: c2,
            objectId: d2,
            objectPosX: m2,
            objectPosY: u2,
            objectPos: _2
          } = (0, C.Jfv)(), h2 = (0, C.UlF)(), g2 = (0, s.useCallback)(() => {
            let e4 = (0, o.Fx)({
              params: {
                hash: n2,
                artistId: t3,
                objectsCount: l2,
                objectType: c2,
                objectId: d2,
                objectPosX: m2,
                objectPosY: u2
              },
              logger: h2,
              context: "useSendEventOnConcertShowed"
            });
            r2 && e4 && (0, o.HB)(r2.evgenInstance, e4);
          }, [r2, t3, n2, h2, d2, m2, u2, c2, l2]), p2 = (0, s.useCallback)(() => {
            let e4 = (0, o.Fx)({
              params: { hash: n2, artistId: t3, viewUuid: a3, objectId: d2, objectPos: _2 },
              logger: h2,
              context: "useSendEventOnConcertShowed"
            });
            r2 && e4 && a3 && (0, o.Z4)(r2.evgenInstance, e4);
          }, [r2, t3, n2, h2, d2, _2, a3]);
          return (0, s.useCallback)(() => {
            if (r2 && i3 && C.xKB.includes(i3))
              switch (i3) {
                case C._Q$.ARTIST:
                case C._Q$.CONCERT:
                  g2();
                  break;
                case C._Q$.ARTIST_CONCERTS:
                  p2();
              }
          }, [r2, i3, p2, g2]);
        })({ artistId: t2, viewUuid: N2 }), K = (0, h.m)({ artistId: t2, viewUuid: N2 }), { ref: P, intersectionPropertyId: B } = (0, C.nMI)({ callback: null !== t2 ? S : void 0, singleEvent: !k }), M = (0, s.useId)(), W = (0, s.useId)(), $ = (0, g.useGetPriceText)()(a2), z = (0, c.c)((e3) => {
          (0, m.P)(e3, b().ripple), I && D(e3);
        }), F = (0, c.c)((e3) => {
          y(), K(o.H2.ConcertPurchaseScreen), e3.stopPropagation(), e3.preventDefault();
        });
        return (0, r.jsxs)(_.Paper, {
          radius: f2,
          className: (0, n.$)(b().root, A),
          ref: P,
          "data-intersection-property-id": B,
          onClick: z,
          children: [
            a2.datetime && (0, r.jsx)(x.ConcertDate, {
              datetime: a2.datetime,
              id: M,
              className: (0, n.$)(b().date, { [b().dateWithMask]: j, [b().important]: j }),
              dayClassName: b().dateColor,
              monthClassName: b().dateColor
            }),
            (0, s.cloneElement)(i2, { id: W, concert: a2 }),
            a2.dataSessionId && (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(u.$, {
                  color: "primary",
                  radius: "xxxl",
                  className: b().button,
                  "aria-describedby": "".concat(M, " ").concat(W),
                  "aria-label": $,
                  onClick: F,
                  ...(0, l.Am)(l.OA.concert.CONCERT_CARD_BUTTON),
                  children: $
                }),
                (0, r.jsx)(p.AfishaWidget, { dataSessionId: a2.dataSessionId, isOpened: T, onOpen: y, onClose: O })
              ]
            })
          ]
        });
      });
    },
    91097: (e) => {
      e.exports = {
        root: "DonationCarousel_root__Uejjw",
        controls: "DonationCarousel_controls__anVvP",
        item: "DonationCarousel_item__89_B6",
        important: "DonationCarousel_important__Y52Es"
      };
    },
    97774: (e, t, a) => {
      "use strict";
      a.d(t, { t: () => n });
      var r = a(93064);
      let n = (e2) => (0, r.wg)(e2);
    }
  }
]);
