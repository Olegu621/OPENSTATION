"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2580, 8357, 8814, 9399],
  {
    342: (e, t, n) => {
      n.d(t, { A: () => a });
      var r = n(3210), o = Math.max;
      let a = function(e2, t2, n2) {
        return t2 = o(void 0 === t2 ? e2.length - 1 : t2, 0), function() {
          for (var a2 = arguments, i = -1, s = o(a2.length - t2, 0), c = Array(s); ++i < s; ) c[i] = a2[t2 + i];
          i = -1;
          for (var u = Array(t2 + 1); ++i < t2; ) u[i] = a2[i];
          return u[t2] = n2(c), (0, r.A)(e2, this, u);
        };
      };
    },
    1630: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = (0, n(92938).A)();
    },
    3210: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = function(e2, t2, n2) {
        switch (n2.length) {
          case 0:
            return e2.call(t2);
          case 1:
            return e2.call(t2, n2[0]);
          case 2:
            return e2.call(t2, n2[0], n2[1]);
          case 3:
            return e2.call(t2, n2[0], n2[1], n2[2]);
        }
        return e2.apply(t2, n2);
      };
    },
    9710: (e, t, n) => {
      n.d(t, { A: () => s });
      var r = n(83745), o = n(7812), a = n(27115), i = o.A ? function(e2, t2) {
        return (0, o.A)(e2, "toString", { configurable: true, enumerable: false, value: (0, r.A)(t2), writable: true });
      } : a.A;
      let s = (0, n(38928).A)(i);
    },
    11260: (e, t, n) => {
      n.d(t, { A: () => l });
      var r = n(11828), o = n(55796), a = n(21793), i = Object.prototype, s = Function.prototype.toString, c = i.hasOwnProperty, u = s.call(Object);
      let l = function(e2) {
        if (!(0, a.A)(e2) || "[object Object]" != (0, r.A)(e2)) return false;
        var t2 = (0, o.A)(e2);
        if (null === t2) return true;
        var n2 = c.call(t2, "constructor") && t2.constructor;
        return "function" == typeof n2 && n2 instanceof n2 && s.call(n2) == u;
      };
    },
    22711: (e, t, n) => {
      n.d(t, { A: () => o });
      var r = n(77480);
      let o = (0, n(28736).A)(function(e2, t2, n2) {
        (0, r.A)(e2, t2, n2);
      });
    },
    27115: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = function(e2) {
        return e2;
      };
    },
    28736: (e, t, n) => {
      n.d(t, { A: () => a });
      var r = n(36021), o = n(40675);
      let a = function(e2) {
        return (0, r.A)(function(t2, n2) {
          var r2 = -1, a2 = n2.length, i = a2 > 1 ? n2[a2 - 1] : void 0, s = a2 > 2 ? n2[2] : void 0;
          for (i = e2.length > 3 && "function" == typeof i ? (a2--, i) : void 0, s && (0, o.A)(n2[0], n2[1], s) && (i = a2 < 3 ? void 0 : i, a2 = 1), t2 = Object(t2); ++r2 < a2; ) {
            var c = n2[r2];
            c && e2(t2, c, r2, i);
          }
          return t2;
        });
      };
    },
    36021: (e, t, n) => {
      n.d(t, { A: () => i });
      var r = n(27115), o = n(342), a = n(9710);
      let i = function(e2, t2) {
        return (0, a.A)((0, o.A)(e2, t2, r.A), e2 + "");
      };
    },
    38928: (e, t, n) => {
      n.d(t, { A: () => o });
      var r = Date.now;
      let o = function(e2) {
        var t2 = 0, n2 = 0;
        return function() {
          var o2 = r(), a = 16 - (o2 - n2);
          if (n2 = o2, a > 0) {
            if (++t2 >= 800) return arguments[0];
          } else t2 = 0;
          return e2.apply(void 0, arguments);
        };
      };
    },
    39399: (e, t, n) => {
      n.d(t, { t: () => s });
      var r = n(6493), o = n(71942), a = n(13132);
      let i = {
        WINDOWS: "0d8ab1a6-1667-42cb-a98f-2fe7eff4b137",
        MACOS: "05c45ae8-b869-4ec1-848c-4b314fbadc17",
        LINUX: "d2bcdb71-90ac-493b-b68f-024321954a5d",
        WEB: "b200fd55-5a52-4fa2-b5db-d163e986a61d"
      }, s = () => {
        switch ((0, o.t)((0, r.u)())) {
          case a.V.WINDOWS:
            return i.WINDOWS;
          case a.V.MACOS:
            return i.MACOS;
          case a.V.LINUX:
            return i.LINUX;
        }
        return i.WEB;
      };
    },
    40675: (e, t, n) => {
      n.d(t, { A: () => s });
      var r = n(6575), o = n(43713), a = n(59994), i = n(71270);
      let s = function(e2, t2, n2) {
        if (!(0, i.A)(n2)) return false;
        var s2 = typeof t2;
        return ("number" == s2 ? !!((0, o.A)(n2) && (0, a.A)(t2, n2.length)) : "string" == s2 && t2 in n2) && (0, r.A)(n2[t2], e2);
      };
    },
    52580: (e, t, n) => {
    },
    58814: (e, t, n) => {
      n.d(t, { config: () => l });
      var r = n(22711), o = n(15209), a = n(22001), i = n(78171), s = n(80738), c = n(39399), u = n(49124);
      let l = () => {
        let e2 = u.env.NEXT_PUBLIC_USE_PRODUCTION_BACKEND ? "https://api.music.yandex.".concat(i.B) : "https://api.music.qa.yandex.".concat(i.B);
        return (0, r.A)((0, s.config)(), {
          resources: { musicExternalApi: { prefixUrl: e2 } },
          player: { prefixUrl: e2, overembed: false, secretKey: (0, a.E)(), externalDomain: "localhost.music.yandex.ru" },
          tvm: {
            enabled: true,
            destinations: ["blackbox"],
            ...(0, o.toBoolean)(u.env.USE_QYP_TVM) ? { host: "http://local-music-dev-sas.sas.yp-c.yandex.net/tvm" } : {}
          },
          passportCredentials: { host: "https://passport.yandex.".concat(i.B), origin: "music_desktop" },
          blackbox: { host: "http://local-music-dev-sas.sas.yp-c.yandex.net/bbm/blackbox", enabled: true },
          oldWebHost: u.env.NEXT_PUBLIC_USE_PRODUCTION_BACKEND ? "music.yandex.".concat(i.B) : "music.qa.yandex.".concat(i.B),
          afisha: { clientId: (0, c.t)(), host: "https://widget.afisha.yandex.ru" },
          iframe: { entityBaseUrl: "https://music.qa.yandex.".concat(i.B) },
          rsc: { useCache: false }
        });
      };
    },
    77480: (e, t, n) => {
      n.d(t, { A: () => _ });
      var r = n(75856), o = n(9959), a = n(6575);
      let i = function(e2, t2, n2) {
        (void 0 === n2 || (0, a.A)(e2[t2], n2)) && (void 0 !== n2 || t2 in e2) || (0, o.A)(e2, t2, n2);
      };
      var s = n(1630), c = n(12841), u = n(53222), l = n(84296), d = n(67450), f = n(63339), p = n(24422), A = n(89326), v = n(88947), m = n(15993), y = n(71270), h = n(11260), b = n(6808);
      let E = function(e2, t2) {
        if (("constructor" !== t2 || "function" != typeof e2[t2]) && "__proto__" != t2) return e2[t2];
      };
      var S = n(98799);
      let g = function(e2, t2, n2, r2, o2, a2, s2) {
        var g2 = E(e2, n2), x2 = E(t2, n2), _2 = s2.get(x2);
        if (_2) return void i(e2, n2, _2);
        var P = a2 ? a2(g2, x2, n2 + "", e2, t2, s2) : void 0, C = void 0 === P;
        if (C) {
          var T = (0, p.A)(x2), U = !T && (0, v.A)(x2), k = !T && !U && (0, b.A)(x2);
          P = x2, T || U || k ? (0, p.A)(g2) ? P = g2 : (0, A.A)(g2) ? P = (0, l.A)(g2) : U ? (C = false, P = (0, c.A)(x2, true)) : k ? (C = false, P = (0, u.A)(x2, true)) : P = [] : (0, h.A)(x2) || (0, f.A)(x2) ? (P = g2, (0, f.A)(g2) ? P = (0, S.A)(g2) : (!(0, y.A)(g2) || (0, m.A)(g2)) && (P = (0, d.A)(x2))) : C = false;
        }
        C && (s2.set(x2, P), o2(P, x2, r2, a2, s2), s2.delete(x2)), i(e2, n2, P);
      };
      var x = n(47931);
      let _ = function e2(t2, n2, o2, a2, c2) {
        t2 !== n2 && (0, s.A)(
          n2,
          function(s2, u2) {
            if (c2 || (c2 = new r.A()), (0, y.A)(s2)) g(t2, n2, u2, o2, e2, a2, c2);
            else {
              var l2 = a2 ? a2(E(t2, u2), s2, u2 + "", t2, n2, c2) : void 0;
              void 0 === l2 && (l2 = s2), i(t2, u2, l2);
            }
          },
          x.A
        );
      };
    },
    80738: (e, t, n) => {
      n.d(t, { config: () => c });
      var r = n(49544), o = n(8171), a = n(78171), i = n(49775);
      n(52580);
      var s = n(49124);
      let c = () => {
        var e2;
        return {
          logger: {
            uaDisabled: !!s.env.SERVER_UNIFIED_AGENT_DISABLED,
            uaServerAddress: null != (e2 = s.env.SERVER_UNIFIED_AGENT_ADDRESS) ? e2 : "http://localhost:12344",
            uaProtoPath: s.env.UA_PROTO_PATH || "../../packages/unified-agent/build/proto/unified_agent.proto",
            errorBooster: {
              ...{ project: "music.frontend.desktop", platform: "desktop" },
              page: "window.location.pathname",
              version: s.env.APP_VERSION || "",
              environment: "production",
              unhandledRejection: true,
              uncaughtException: true,
              resourceFails: true
            }
          },
          oauthCredentials: { host: "https://oauth.yandex.".concat(a.B), clientId: "97fe03033fa34407ac9bcf91d5afed5b" },
          tvm: {
            tvmtoolAuthToken: s.env.TVMTOOL_LOCAL_AUTHTOKEN,
            self: "music_test",
            destinations: ["blackbox"],
            host: "http://localhost:8001",
            enabled: false
          },
          rumSettings: {
            ...{
              rumId: "ru.music.frontend.desktop",
              project: "music.frontend.desktop",
              service: "frontend-desktop",
              platform: "desktop"
            },
            page: "window.location.pathname",
            heroElement: "body",
            version: s.env.APP_VERSION || "",
            environment: "production"
          },
          passportCredentials: { host: "https://passport.yandex.".concat(a.B), origin: "music_desktop" },
          blackbox: { host: "http://blackbox.envoy.localhost:9080", enabled: false },
          resources: { musicExternalApi: { retryPolicyConfig: i.t, defaultTimeout: o.Aj, timeouts: o.LE } },
          payment: { environment: "testing" },
          i18n: { cookieExpirationDays: 365 },
          ynisonConnectionConfig: {
            ynisonHost: "ynison.music.yandex.ru",
            redirectorPath: "/redirector.YnisonRedirectService/GetRedirectToYnison",
            hubConnectioPath: "/ynison_state.YnisonStateService/PutYnisonState",
            reconnectTimeout: 2e3,
            reconnectAttempts: 2,
            historyLimit: 100
          },
          player: {
            configVariablesMainPlayback: {
              entitiesToPreloadStrmUrlsCount: 1,
              entitiesToPreloadSourceCount: 1,
              preloadedSourcesMaxCount: 1,
              strmUrlsTtlMs: 36e5,
              mediaElementErrorReloadCount: 2,
              windowSize: 30,
              setupQueueWindowSize: 80,
              bufferGoal: 5
            },
            configVariablesPromoLandingPlayback: {
              entitiesToPreloadStrmUrlsCount: 1,
              entitiesToPreloadSourceCount: 1,
              preloadedSourcesMaxCount: 1,
              strmUrlsTtlMs: 36e5,
              mediaElementErrorReloadCount: 2,
              windowSize: 30,
              setupQueueWindowSize: 80,
              bufferGoal: 5
            },
            configVariablesTrailerPlayback: {
              mediaElementErrorReloadCount: 2,
              windowSize: 30,
              setupQueueWindowSize: 80,
              storePlaysProgressIntervalMs: 5e3
            },
            hlsErrorRetryLimit: 2,
            yaspVersionStable: "12946",
            yaspSourceLimit: 3,
            yaspLoadRetryDelayMs: 1e3,
            yaspExpName: void 0,
            yaspCandidateVersion: void 0,
            vhMediaProvider: { service: "ya-music", from: "ya-music", vhUrl: "https://frontend.vh.yandex.ru/player/" },
            vhPlayerSdkVersion: "12569",
            telemetry: {
              telemetryUrl: "https://log.strm.yandex.ru",
              testTelemetryUrl: "https://log-test.strm.yandex.net",
              service: "WebMusic",
              from: "ya-music",
              playerTypeForVsid: "MWE",
              rumUrl: "https://yandex.ru/clck/click"
            }
          },
          downloadDesktop: { url: "https://music.yandex.".concat(a.B, "/download/?autodownload=1") },
          iframe: { entityBaseUrl: "https://music.yandex.".concat(a.B) },
          redirects: { KZ: { fromTLD: [r.r.RU], toTLD: r.r.KZ }, UZ: { fromTLD: [r.r.RU], toTLD: r.r.UZ } },
          acqOffers: { environment: "production", brand: "YANDEX", service: "music", appVersion: s.env.APP_VERSION },
          rsc: { useCache: true }
        };
      };
    },
    83745: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = function(e2) {
        return function() {
          return e2;
        };
      };
    },
    89326: (e, t, n) => {
      n.d(t, { A: () => a });
      var r = n(43713), o = n(21793);
      let a = function(e2) {
        return (0, o.A)(e2) && (0, r.A)(e2);
      };
    },
    92938: (e, t, n) => {
      n.d(t, { A: () => r });
      let r = function(e2) {
        return function(t2, n2, r2) {
          for (var o = -1, a = Object(t2), i = r2(t2), s = i.length; s--; ) {
            var c = i[e2 ? s : ++o];
            if (false === n2(a[c], c, a)) break;
          }
          return t2;
        };
      };
    },
    98799: (e, t, n) => {
      n.d(t, { A: () => a });
      var r = n(41620), o = n(47931);
      let a = function(e2) {
        return (0, r.A)(e2, (0, o.A)(e2));
      };
    }
  }
]);
