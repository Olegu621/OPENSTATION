(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [8983],
  {
    2257: (e) => {
      e.exports = {
        button: "SearchHistoryBlockMobile_button__Wh_Q6",
        header: "SearchHistoryBlockMobile_header__Lx4On",
        mixedEntitiesBlock: "SearchHistoryBlockMobile_mixedEntitiesBlock__cJ3o_",
        buttonContainer: "SearchHistoryBlockMobile_buttonContainer__IppED"
      };
    },
    3724: (e) => {
      e.exports = { root: "SearchBestResultsAlbumBlock_root__j7nJ4" };
    },
    9805: (e) => {
      e.exports = {
        root: "SearchBestResultsShimmer_root__xMCOZ",
        container: "SearchBestResultsShimmer_container__Je48X",
        entity: "SearchBestResultsShimmer_entity____sr1",
        important: "SearchBestResultsShimmer_important__vbFUa",
        cover: "SearchBestResultsShimmer_cover__rzY5m",
        meta: "SearchBestResultsShimmer_meta__GlLPe",
        title: "SearchBestResultsShimmer_title__AXYX8",
        subtitle: "SearchBestResultsShimmer_subtitle__IULSY"
      };
    },
    10212: (e) => {
      e.exports = {
        root: "SearchBestResultsUpcomingBlock_root__baVsK",
        important: "SearchBestResultsUpcomingBlock_important__v_XW8",
        cover: "SearchBestResultsUpcomingBlock_cover__c45Xf",
        coverImage: "SearchBestResultsUpcomingBlock_coverImage___mLf5",
        lockIcon: "SearchBestResultsUpcomingBlock_lockIcon__yaBf_",
        likeButton: "SearchBestResultsUpcomingBlock_likeButton__Srh_v"
      };
    },
    10838: (e, t, s) => {
      "use strict";
      s.d(t, { SearchPage: () => N });
      var a = s(54486), r = s(50420), i = s(28303), o = s(97396), c = s(61910), l = s(43426), n = s(31500), d = s(34291), m = s(76421), u = s(6024), h = s(8817), _ = s(27510), S = s(79021), x = s(51321), p = s(42320), C = s(74125), j = s(80585), A = s(54830), P = s(40162), b = s.n(P), k = s(67648), y = s(56231), v = s(4542), T = s(81531), E = s(82644), I = s(33276);
      let g = (0, i.PA)((e2) => {
        let { searchResults: t2, setContentScrollRef: s2, contentScrollRef: i2, hasSearchText: o2 } = e2, {
          user: l2,
          search: d2,
          settings: { isMobile: m2 }
        } = (0, C.Pjs)(), [u2, h2] = (0, k.d)();
        return o2 ? t2 : l2.isAuthorized ? (0, a.jsx)(I.hO, {
          scrollElement: i2,
          headerElement: u2,
          children: (0, a.jsxs)(y.N, {
            className: b().scrollableContent,
            containerClassName: b().main,
            ref: s2,
            ...(0, n.Am)(n.Xk.search.SEARCH_PAGE_CONTENT),
            children: [
              (0, a.jsx)(v.EA, {
                containerClassName: b().skeletonContainer,
                stickyHeaderClassName: (0, r.$)(b().skeletonStickyHeader, b().important),
                stickyHeaderTabIndex: m2 ? null : 0,
                headerConcealerComponent: (0, a.jsx)("div", { ref: h2 }),
                landing: d2.landing,
                errorComponent: (0, a.jsx)(E.w, { className: b().error, withBackwardControl: false }),
                headerVariant: m2 ? j.Vw.COMPOSITE : j.Vw.STICKY
              }),
              (0, a.jsx)(j.A, { children: (0, a.jsx)(j.wi, { className: b().footer }) })
            ]
          })
        }) : (0, a.jsxs)(y.N, {
          className: b().scrollableContent,
          containerClassName: b().main,
          ref: s2,
          children: [
            (0, a.jsx)(c.Suspense, {
              children: (0, a.jsx)(C.FoH, {
                blockId: C.hf$.SEARCH_HISTORY,
                blockType: C.hf$.SEARCH_HISTORY,
                blockPosX: 1,
                blockPosY: 1,
                blockIdForFrom: C.hf$.SEARCH_HISTORY,
                objectsCount: d2.historyPage.items.length,
                children: (0, a.jsx)(p._K, {})
              })
            }),
            (0, a.jsx)(c.Suspense, { children: (0, a.jsx)(T.Z_, { className: b().mixes }) }),
            (0, a.jsx)(j.A, { children: (0, a.jsx)(j.wi, { className: b().footer }) })
          ]
        });
      }), R = "text", N = (0, i.PA)(() => {
        let e2 = (0, x.useTabsState)(0), [t2, s2] = (0, c.useState)(d.$.TOP), [i2, P2] = (0, c.useState)(false), { formatMessage: k2 } = (0, l.A)(), { search: y2, experiments: v2, location: T2, user: E2 } = (0, C.Pjs)(), { contentScrollRef: I2, setContentScrollRef: N2 } = (0, C.gKY)(), B = ((e3) => {
          let { formatMessage: t3 } = (0, l.A)(), s3 = (0, A.df)(), { experiments: a2 } = (0, C.Pjs)(), r2 = a2.checkExperiment(C.zal.WebNextSearchConcerts, "on") && !a2.checkExperiment(C.zal.disableAllConcerts, "on");
          return e3 ? [{ id: d.$.TOP, displayName: t3({ id: "search-filters.top" }) }, ...e3].filter((e4) => {
            if ((e4.id !== d.$.CLIP || s3) && (e4.id !== d.$.CONCERT || r2)) return e4;
          }) : [{ id: d.$.TOP, displayName: t3({ id: "search-filters.top" }) }];
        })(y2.filters), f = (0, C.XJ9)(), [L, O] = (0, c.useState)(() => {
          var e3;
          return decodeURIComponent(null != (e3 = new URLSearchParams(T2.searchParams).get(R)) ? e3 : "");
        }), H = (0, c.useRef)(L), D = L.length > 0;
        v2.checkExperiment(C.zal.WebNextDisableSearch, "on") && (0, o.redirect)(C.Zyd.main.href), (0, C.Jzs)(y2.landing.loadingState === C.GuX.RESOLVE), (0, c.useEffect)(
          () => () => {
            y2.reset(), E2.isAuthorized && y2.landing.reset();
          },
          [E2.isAuthorized, v2, y2]
        );
        let M = (0, h.c)((e3, t3) => {
          y2.resetResults(), 0 !== e3.length && y2.getSearchResults({ text: decodeURIComponent(e3), filter: t3 });
        }), w = (0, h.c)(() => {
          P2(true);
        }), K = (0, h.c)((t3) => {
          var a2, r2;
          if (!e2.onTabChange || t3 === e2.value) return;
          e2.onTabChange(t3);
          let i3 = null != (r2 = null == (a2 = B[t3]) ? void 0 : a2.id) ? r2 : d.$.TOP;
          Object.values(d.$).includes(i3) && (s2(i3), M(H.current, i3));
        }), Y = (0, h.c)((t3) => {
          let s3 = t3.trim(), a2 = encodeURIComponent(s3);
          O(a2), H.current = a2, 0 !== e2.value && K(0), M(a2, d.$.TOP), y2.history.setShouldUpdateHistory(true), y2.resetSearchCorrectedText(), P2(false);
          let r2 = new URL(window.location.href);
          r2.searchParams.set(R, s3), f(String(r2));
        }), U = (0, h.c)((e3) => {
          let { id: t3, type: s3, blockPosition: a2, position: r2, feedbackType: i3 } = e3;
          y2.sendFeedback({
            blockType: s3,
            entityId: "".concat(s3, ":").concat(t3),
            timestamp: (/* @__PURE__ */ new Date()).toISOString(),
            searchRequestId: y2.searchRequestId,
            query: H.current,
            clickType: i3,
            blockPosition: a2,
            position: r2,
            page: 0
          });
        }), $ = (0, c.useMemo)(
          () => y2.searchCorrectedText ? (0, a.jsx)(p.tn, { searchCorrectedText: y2.searchCorrectedText, onCorrectText: w }) : null,
          [w, y2.searchCorrectedText]
        ), V = (0, _.L)(() => {
          if (y2.isEmpty) return (0, a.jsx)(p.qz, { searchCorrectedText: $ });
          let e3 = {
            className: b().searchResults,
            isShimmerVisible: y2.isShimmerVisible,
            isShimmerActive: y2.isLoading,
            results: y2.results,
            bestResults: y2.bestResults,
            sendSearchFeedback: U,
            searchCorrectedText: $,
            ref: N2
          };
          switch (t2) {
            case d.$.TOP:
              return (0, a.jsx)(p.kp, { ...e3, ...(0, n.Am)(n.Xk.search.SEARCH_PAGE_RESULTS_TOP) });
            case d.$.TRACK:
              return (0, a.jsx)(p.uU, { ...e3 });
            case d.$.ALBUM:
              return (0, a.jsx)(p.ok, {
                ...e3,
                filter: m.n.ALBUM,
                ...(0, n.Am)(n.Xk.search.SEARCH_PAGE_RESULTS_ALBUM)
              });
            case d.$.PLAYLIST:
              return (0, a.jsx)(p.ok, {
                ...e3,
                filter: m.n.PLAYLIST,
                ...(0, n.Am)(n.Xk.search.SEARCH_PAGE_RESULTS_PLAYLIST)
              });
            case d.$.ARTIST:
              return (0, a.jsx)(p.ok, {
                ...e3,
                filter: m.n.ARTIST,
                ...(0, n.Am)(n.Xk.search.SEARCH_PAGE_RESULTS_ARTIST)
              });
            case d.$.PODCAST:
              return (0, a.jsx)(p.Jh, { ...e3 });
            case d.$.BOOK:
              return (0, a.jsx)(p.ok, {
                ...e3,
                filter: m.n.BOOK,
                ...(0, n.Am)(n.Xk.search.SEARCH_PAGE_RESULTS_BOOK)
              });
            case d.$.CLIP:
              return (0, a.jsx)(p.ok, {
                ...e3,
                filter: m.n.CLIP,
                ...(0, n.Am)(n.Xk.search.SEARCH_PAGE_RESULTS_CLIP)
              });
            case d.$.WAVES:
              return (0, a.jsx)(p.ok, {
                isWideResults: true,
                ...e3,
                filter: m.n.WAVE,
                ...(0, n.Am)(n.Xk.search.SEARCH_PAGE_RESULTS_WAVES)
              });
            case d.$.CONCERT:
              return (0, a.jsx)(C.hjC, {
                tabId: d.$.CONCERT,
                tabPos: 1,
                isTabSelectedByDefault: false,
                children: (0, a.jsx)(p.ok, { ...e3, filter: m.n.CONCERT })
              });
            default:
              return $;
          }
        }), X = (0, c.useMemo)(() => {
          if (D)
            return (0, a.jsx)(j.FY, {
              className: b().carousel,
              carouselElement: (0, a.jsx)(j.wI, {
                className: b().tabs,
                ...e2,
                onTabChange: K,
                children: B.map(
                  (t3, s3) => (0, a.jsx)(
                    j.oz,
                    {
                      className: (0, r.$)(b().tab, { [b().tab_selected]: s3 === e2.value }),
                      title: t3.displayName,
                      value: s3
                    },
                    s3
                  )
                )
              })
            });
        }, [B, K, e2, D]);
        return y2.isNeededToLoad && D && (0, c.use)(y2.getSearchResults({ text: decodeURIComponent(L), filter: t2 })), E2.isAuthorized && y2.landing.isNeededToLoad && !D && (0, c.use)(
          y2.landing.getSkeleton({ id: u.p.SEARCH, showWizard: E2.settings.showWizard }, { preloadBlocksCount: 2 })
        ), (0, a.jsx)(C.nVz, {
          pageId: C._Q$.SEARCH,
          children: (0, a.jsxs)("div", {
            className: (0, r.$)(b().root, { [b().root_showFilters]: D }),
            ...(0, n.Am)(n.Xk.search.SEARCH_PAGE),
            children: [
              (0, a.jsxs)("div", {
                className: b().header,
                ...(0, n.Am)(n.Xk.search.SEARCH_PAGE_HEADER_CONTAINER),
                children: [
                  (0, a.jsx)(S.D, {
                    className: b().input,
                    autoFocus: true,
                    initialValue: H.current,
                    placeholder: k2({ id: "search.input-placeholder" }),
                    onChange: Y,
                    resetButtonAriaLabel: k2({ id: "interface-actions.reset-search-input" }),
                    correctedValue: i2 ? y2.searchCorrectedText : null,
                    innerInputProps: (0, n.Am)(n.Xk.search.SEARCH_PAGE_SEARCH_INPUT),
                    resetButtonProps: (0, n.Am)(n.Xk.search.SEARCH_PAGE_SEARCH_INPUT_RESET_BUTTON),
                    searchIconProps: (0, n.Am)(n.Xk.search.SEARCH_PAGE_SEARCH_INPUT_ICON)
                  }),
                  X
                ]
              }),
              (0, a.jsx)("div", {
                className: b().content,
                children: (0, a.jsx)(C.jPc, {
                  children: (0, a.jsx)(g, {
                    hasSearchText: D,
                    contentScrollRef: I2,
                    setContentScrollRef: N2,
                    searchResults: V
                  })
                })
              })
            ]
          })
        });
      });
    },
    12200: (e, t, s) => {
      "use strict";
      s.d(t, { G: () => h });
      var a = s(54486), r = s(43350), i = s(76421), o = s(84213), c = s(94376), l = s(55616), n = s(83909), d = s(21365), m = s(76866), u = s(74125);
      let h = (e2) => {
        let {
          item: t2,
          index: s2,
          pageId: h2,
          sendSearchFeedback: _,
          blockPosition: S = 0,
          objectPosX: x,
          objectPosY: p,
          objectsCount: C
        } = e2;
        switch (t2.type) {
          case i.n.PODCAST_EPISODE:
            return (0, a.jsx)(
              u.Bki,
              {
                objectType: r.ky.PodcastEpisode,
                objectId: t2.data.id,
                objectPosX: x,
                objectPosY: p,
                objectsCount: C,
                children: (0, a.jsx)(d.c8, { pageId: h2, track: t2.data })
              },
              t2.data.id
            );
          case i.n.UGC_TRACK:
            return (0, a.jsx)(d.c8, { pageId: h2, track: t2.data });
          case i.n.TRACK:
            return (0, a.jsx)(
              u.Bki,
              {
                objectType: r.ky.Track,
                objectId: t2.data.id,
                objectPosX: x,
                objectPosY: p,
                objectsCount: C,
                children: (0, a.jsx)(u.NYB.Provider, {
                  value: { sendSearchFeedback: _, id: t2.data.entityId, type: o.o.TRACK, blockPosition: S, position: s2 },
                  children: (0, a.jsx)(d.c8, { pageId: h2, track: t2.data })
                })
              },
              t2.data.id
            );
          case i.n.ARTIST:
            return (0, a.jsx)(
              u.Bki,
              {
                objectType: r.ky.Artist,
                objectId: t2.data.id,
                objectPosX: x,
                objectPosY: p,
                objectsCount: C,
                children: (0, a.jsx)(u.NYB.Provider, {
                  value: { sendSearchFeedback: _, id: t2.data.id, type: o.o.ARTIST, blockPosition: S, position: s2 },
                  children: (0, a.jsx)(l.cz, { pageId: h2, artist: t2.data })
                })
              },
              t2.data.id
            );
          case i.n.PLAYLIST:
            return (0, a.jsx)(
              u.Bki,
              {
                objectType: r.ky.Playlist,
                objectId: t2.data.id,
                objectPosX: x,
                objectPosY: p,
                objectsCount: C,
                children: (0, a.jsx)(u.NYB.Provider, {
                  value: { sendSearchFeedback: _, id: t2.data.id, type: o.o.PLAYLIST, blockPosition: S, position: s2 },
                  children: (0, a.jsx)(n.vf, { pageId: h2, playlist: t2.data })
                })
              },
              t2.data.id
            );
          case i.n.PODCAST:
            return (0, a.jsx)(
              u.Bki,
              {
                objectType: r.ky.Podcast,
                objectId: String(t2.data.id),
                objectPosX: x,
                objectPosY: p,
                objectsCount: C,
                children: (0, a.jsx)(
                  u.NYB.Provider,
                  {
                    value: { sendSearchFeedback: _, id: t2.data.id, type: o.o.PODCAST, blockPosition: S, position: s2 },
                    children: (0, a.jsx)(c.M_, { pageId: h2, album: t2.data })
                  },
                  t2.data.id
                )
              },
              t2.data.id
            );
          case i.n.ALBUM:
            return (0, a.jsx)(
              u.Bki,
              {
                objectType: r.ky.Album,
                objectId: String(t2.data.id),
                objectPosX: x,
                objectPosY: p,
                objectsCount: C,
                children: (0, a.jsx)(
                  u.NYB.Provider,
                  {
                    value: { sendSearchFeedback: _, id: t2.data.id, type: o.o.ALBUM, blockPosition: S, position: s2 },
                    children: (0, a.jsx)(c.M_, { pageId: h2, album: t2.data })
                  },
                  t2.data.id
                )
              },
              t2.data.id
            );
          case i.n.WAVE: {
            let e3 = t2.data;
            return (0, a.jsx)(
              u.Bki,
              {
                objectType: r.ky.Wave,
                objectId: e3.stationId,
                objectPosX: x,
                objectPosY: p,
                objectsCount: C,
                children: (0, a.jsx)(u.NYB.Provider, {
                  value: { sendSearchFeedback: _, id: e3.stationId, type: o.o.WAVE, blockPosition: S, position: s2 },
                  children: (0, a.jsx)(m.H2, {
                    vibe: e3,
                    cover: e3.cover,
                    description: e3.description,
                    agentVariant: m.hl.SMALL
                  })
                })
              },
              e3.stationId
            );
          }
          default:
            return null;
        }
      };
    },
    14385: (e) => {
      e.exports = {
        root: "SearchEntitiesGrid_root__kk0fO",
        container: "SearchEntitiesGrid_container__zFcDu",
        correctedTextBlock: "SearchEntitiesGrid_correctedTextBlock__4j4cD",
        items: "SearchEntitiesGrid_items__RrGDy",
        items_withChildren: "SearchEntitiesGrid_items_withChildren__VW6y_",
        items_wideResults: "SearchEntitiesGrid_items_wideResults__HFrao",
        items_concerts: "SearchEntitiesGrid_items_concerts__mz1Lt",
        video: "SearchEntitiesGrid_video__2xHJc",
        footer: "SearchEntitiesGrid_footer__NK1iL",
        block: "SearchEntitiesGrid_block__jnP9P",
        concertShimmer: "SearchEntitiesGrid_concertShimmer__XaD4d"
      };
    },
    17820: (e) => {
      e.exports = { root: "SearchBestResultsConcertBlock_root__JDy_y" };
    },
    22782: (e) => {
      e.exports = {
        root: "SearchBestResultsOverviewBlock_root__m1nKx",
        button: "SearchBestResultsOverviewBlock_button__F2FaR",
        important: "SearchBestResultsOverviewBlock_important__oLQCU"
      };
    },
    24112: (e) => {
      e.exports = { root: "SearchBestResultsRecentReleaseBlock_root___1Eoa" };
    },
    32271: (e, t, s) => {
      "use strict";
      s.d(t, { Mixes: () => S });
      var a = s(54486), r = s(28303), i = s(61910), o = s(74125), c = s(43426), l = s(81203), n = s(27906), d = s(80585), m = s(38598), u = s.n(m);
      let h = (0, r.PA)((e2) => {
        let { isShimmerVisible: t2, isShimmerActive: s2, mixes: r2 } = e2, { formatMessage: m2 } = (0, c.A)(), h2 = (0, i.useMemo)(
          () => t2 ? (0, d.km)({ isActive: s2, withInfo: false }) : r2.map(
            (e3) => (0, a.jsx)(
              n.NZ,
              {
                title: e3.title,
                weblink: e3.weblink,
                covers: e3.covers,
                coverSize: 80,
                imagesLayoutType: e3.imagesLayoutType
              },
              e3.id
            )
          ),
          [s2, t2, r2]
        );
        return (0, a.jsxs)(a.Fragment, {
          children: [
            (0, a.jsx)(d.Tw, {
              className: u().carouselHeader,
              title: m2({ id: "entity-names.mixes" }),
              titleSize: "xs",
              viewAllActionLink: o.Zyd.mixes.href
            }),
            (0, a.jsx)(l.Carousel, { className: u().carouselBlock, itemClassName: u().mixItem, children: h2 })
          ]
        });
      });
      var _ = s(72344);
      let S = (0, r.PA)((e2) => {
        let { className: t2 } = e2, {
          settings: { isMobile: s2 },
          search: r2
        } = (0, o.Pjs)();
        return (r2.mixes.loadingState === o.GuX.IDLE && (0, i.use)(r2.mixes.getMixes(false)), s2) ? (0, a.jsx)(h, {
          isShimmerVisible: r2.mixes.isLoading || r2.mixes.isRejected,
          isShimmerActive: r2.mixes.isLoading,
          mixes: r2.mixes.items
        }) : (0, a.jsx)(_.MixesGrid, {
          isShimmerVisible: r2.mixes.isLoading || r2.mixes.isRejected,
          isShimmerActive: r2.mixes.isLoading,
          mixes: r2.mixes.items,
          className: t2,
          withTitle: true
        });
      });
    },
    32606: (e) => {
      e.exports = { root: "SearchBestResultsArtistBlock_root__ZLcy4" };
    },
    34291: (e, t, s) => {
      "use strict";
      var a;
      s.d(t, { $: () => a }), (function(e2) {
        e2.TOP = "top", e2.TRACK = "track", e2.CLIP = "clip", e2.ALBUM = "album", e2.ARTIST = "artist", e2.PLAYLIST = "playlist", e2.KIDS_MUSIC = "kids-music", e2.KIDS_PLAYLIST = "kids-playlist", e2.SPOKEN_PLAYLIST = "spoken-playlist", e2.PODCAST = "podcast", e2.BOOK = "book", e2.KIDS_PODCAST = "kids-podcast", e2.KIDS_BOOK = "kids-book", e2.WAVES = "waves", e2.CONCERT = "concert";
      })(a || (a = {}));
    },
    35183: (e, t, s) => {
      "use strict";
      s.d(t, { SearchHistoryNotFoundPage: () => o });
      var a = s(54486), r = s(28303), i = s(42421);
      let o = (0, r.PA)(() => (0, a.jsx)(i.M, {}));
    },
    35461: (e) => {
      e.exports = { root: "EntitiesListShimmer_root__Mq_tK" };
    },
    36516: (e, t, s) => {
      "use strict";
      s.d(t, { V: () => u });
      var a = s(54486), r = s(43426), i = s(50420), o = s(22674), c = s(87033), l = s.n(c);
      let n = (e2) => {
        let { className: t2, ariaLabel: s2, isShimmerActive: r2 } = e2;
        return (0, a.jsxs)("div", {
          tabIndex: 0,
          "aria-label": s2,
          "aria-live": "polite",
          "aria-busy": true,
          className: (0, i.$)(l().root, t2),
          children: [
            (0, a.jsxs)("div", {
              className: l().infoContainer,
              children: [
                (0, a.jsx)(o.Shimmer, { className: l().cover, radius: "s", isActive: r2 }),
                (0, a.jsxs)("div", {
                  className: l().textContainer,
                  children: [
                    (0, a.jsx)(o.Shimmer, { className: l().title, radius: "s", isActive: r2 }),
                    (0, a.jsx)(o.Shimmer, { className: l().description, radius: "s", isActive: r2 })
                  ]
                })
              ]
            }),
            (0, a.jsx)(o.Shimmer, { className: l().action, radius: "s", isActive: r2 })
          ]
        });
      };
      var d = s(35461), m = s.n(d);
      let u = (e2) => {
        let { shimmersCount: t2 = 3, isShimmerActive: s2 = true } = e2, { formatMessage: i2 } = (0, r.A)();
        return Array.from(
          { length: t2 },
          (e3, t3) => (0, a.jsx)(
            n,
            {
              className: m().root,
              ariaLabel: i2({ id: "loading-messages.entity-is-loading" }, { entityName: i2({ id: "search.history" }) }),
              isShimmerActive: s2
            },
            t3
          )
        );
      };
    },
    37536: (e, t, s) => {
      "use strict";
      s.d(t, { SearchMixed: () => eM });
      var a = s(54486), r = s(50420), i = s(61910), o = s(43426), c = s(15209), l = s(31500), n = s(76421), d = s(51427), m = s(34291), u = s(56231), h = s(74125), _ = s(80585), S = s(12200), x = s(82265), p = s(28303), C = s(43350), j = s(84213), A = s(9805), P = s.n(A);
      let b = (e2) => {
        let { isShimmerActive: t2 } = e2;
        return (0, a.jsxs)("div", {
          className: P().root,
          children: [
            (0, a.jsxs)("div", {
              className: P().container,
              children: [
                (0, a.jsx)(_.Vt, {
                  className: (0, r.$)(P().entity, P().important),
                  shimmerClassName: (0, r.$)(P().cover, P().important),
                  round: true,
                  withInfo: false,
                  isActive: t2
                }),
                (0, a.jsxs)("div", {
                  className: P().meta,
                  children: [
                    (0, a.jsx)(_.nN, { textClassName: (0, r.$)(P().title, P().important), isActive: t2 }),
                    (0, a.jsx)(_.nN, { textClassName: (0, r.$)(P().subtitle, P().important), isActive: t2 })
                  ]
                })
              ]
            }),
            (0, a.jsxs)("div", {
              className: P().container,
              children: [
                (0, a.jsx)(_.Vt, {
                  className: (0, r.$)(P().entity, P().important),
                  shimmerClassName: (0, r.$)(P().cover, P().important),
                  withInfo: false,
                  isActive: t2,
                  radius: "xs"
                }),
                (0, a.jsxs)("div", {
                  className: P().meta,
                  children: [
                    (0, a.jsx)(_.nN, { textClassName: (0, r.$)(P().title, P().important), isActive: t2 }),
                    (0, a.jsx)(_.nN, { textClassName: (0, r.$)(P().subtitle, P().important), isActive: t2 })
                  ]
                })
              ]
            })
          ]
        });
      };
      var k = s(82957), y = s.n(k), v = s(94376), T = s(40334), E = s.n(T), I = s(3724), g = s.n(I);
      let R = (0, p.PA)((e2) => {
        let { album: t2 } = e2;
        return (0, a.jsx)(v.M_, {
          album: t2,
          className: (0, r.$)(E().block, g().root),
          coverClassName: E().cover,
          playButtonIconSize: "l",
          likeIconSize: "xs"
        });
      });
      var N = s(55616), B = s(32606), f = s.n(B);
      let L = (0, p.PA)((e2) => {
        let { artist: t2 } = e2;
        return (0, a.jsx)(N.cz, {
          artist: t2,
          className: (0, r.$)(E().block, f().root),
          coverClassName: E().cover,
          playButtonIconSize: "l",
          likeIconSize: "xs",
          pageId: h._Q$.SEARCH
        });
      });
      var O = s(63585), H = s(27510), D = s(97800), M = s(21365), w = s(63695), K = s(81268), Y = s.n(K);
      let U = (0, p.PA)((e2) => {
        var t2;
        let { track: s2 } = e2, { from: c2 } = (0, h.fyy)(), { formatMessage: l2 } = (0, o.A)(), n2 = {
          contextData: { type: O.K.Various, meta: { id: s2.entityId }, from: c2 },
          queueParams: { index: 0, entityId: s2.id },
          loadContextMeta: true
        }, d2 = (0, h.Dx4)({ playContextParams: n2, entityId: s2.entityId }), m2 = (0, i.useCallback)(
          (e3) => (0, a.jsx)(_.q1, {
            isAvailable: s2.isAvailable,
            isDisliked: s2.isDisliked,
            coverUri: s2.coverUri,
            title: s2.title,
            className: (0, r.$)(E().cover, Y().cover),
            alt: l2({ id: "entity-names.track-name-by-type" }, { type: (0, h.yDn)(s2.type), name: s2.title }),
            radius: "xs",
            ...e3
          }),
          [l2, s2.coverUri, s2.isAvailable, s2.isDisliked, s2.title, s2.type]
        ), u2 = (0, M.O6)({ track: s2, entityType: h.nPY.AUDIOBOOK }), S2 = (0, H.L)(
          () => s2.url && s2.isAvailable ? (0, a.jsx)(_.N_, {
            className: (0, r.$)(_.$f.text, _.$f.titleLink),
            href: s2.url,
            onClick: u2,
            children: s2.title
          }) : (0, a.jsx)(D.Caption, {
            className: (0, r.$)(_.$f.text, _.$f.titleText),
            size: "m",
            variant: "div",
            type: "text",
            children: s2.title
          })
        ), x2 = (0, i.useCallback)(
          (e3, t3) => {
            var r2;
            return (null == (r2 = s2.artists) ? void 0 : r2.length) ? (0, a.jsx)(w.iQ, {
              linkClassName: e3,
              captionClassName: t3,
              artists: s2.artists,
              lineClamp: 1,
              withLink: s2.isAvailable
            }) : null;
          },
          [s2.artists, s2.isAvailable]
        );
        return (0, a.jsx)(M.CC, {
          className: (0, r.$)(E().block, Y().root, _.$f.root, { [_.$f.root_disabled]: !s2.isAvailable }),
          track: s2,
          meta: (0, a.jsx)(_.ro, {
            isDisabled: !s2.isAvailable,
            version: s2.version,
            title: S2,
            artistsComponent: x2,
            getDescriptionTexts: s2.getDescriptionTexts,
            explicitMarkVariant: s2.explicitDisclaimer,
            releaseYear: (null == (t2 = s2.mainAlbum) ? void 0 : t2.isNonMusic) ? s2.mainAlbum.year : void 0
          }),
          playButtonCellRender: m2,
          playButtonIconSize: "l",
          controls: (0, a.jsx)(M.QD, { track: s2, utmLink: n2.contextData.utmLink, likeIconSize: "xs" }),
          ...d2
        });
      });
      var $ = s(9348), V = s(65779), X = s(54830), G = s(78508), z = s.n(G);
      let W = (0, p.PA)((e2) => {
        let { clip: t2 } = e2, s2 = (0, X.df)(), r2 = (0, i.useRef)(String((0, $.A)()));
        return s2 ? (0, a.jsx)(V.Nk, {
          clip: t2,
          viewUuid: r2.current,
          className: E().block,
          coverClassName: z().cover,
          playButtonIconSize: "l",
          likeIconSize: "xs",
          shouldShowTimecode: true
        }) : null;
      });
      var F = s(77217), Q = s(17820), J = s.n(Q);
      let Z = (0, p.PA)((e2) => {
        let { concert: t2 } = e2, s2 = (0, i.useRef)(String((0, $.A)()));
        return (0, a.jsx)(F.VN, {
          artistId: null,
          viewUuid: s2.current,
          concert: t2,
          radius: "s",
          className: J().root,
          meta: (0, a.jsx)(F.ub, {}),
          shouldSendAnalyticsOnHide: true
        });
      });
      var q = s(49692), ee = s.n(q);
      let et = (0, p.PA)((e2) => {
        let { album: t2 } = e2;
        return (0, a.jsx)(v.M_, {
          album: t2,
          className: (0, r.$)(E().block, ee().root),
          coverClassName: E().cover,
          playButtonIconSize: "l",
          likeIconSize: "xs",
          shouldShowReleaseYear: true
        });
      });
      var es = s(985), ea = s(22782), er = s.n(ea);
      let ei = (0, p.PA)((e2) => {
        let { data: t2 } = e2, { formatMessage: s2 } = (0, o.A)();
        return (0, a.jsx)("div", {
          className: er().root,
          children: (0, a.jsx)(es.Fn, {
            textButton: s2({ id: "interface-actions.further" }),
            meta: t2,
            buttonClassName: (0, r.$)(er().button, er().important)
          })
        });
      });
      var eo = s(83909), ec = s(90060), el = s.n(ec);
      let en = (0, p.PA)((e2) => {
        let { playlist: t2 } = e2;
        return (0, a.jsx)(eo.vf, {
          playlist: t2,
          className: (0, r.$)(E().block, el().root),
          coverClassName: E().cover,
          playButtonIconSize: "l",
          likeIconSize: "xs"
        });
      });
      var ed = s(59214), em = s.n(ed);
      let eu = (0, p.PA)((e2) => {
        let { track: t2 } = e2, { from: s2 } = (0, h.fyy)(), { formatMessage: c2 } = (0, o.A)(), {
          settings: { isMobile: n2 }
        } = (0, h.Pjs)(), d2 = {
          contextData: { type: O.K.Various, meta: { id: t2.entityId }, from: s2 },
          queueParams: { index: 0, entityId: t2.id },
          loadContextMeta: true
        }, m2 = (0, h.Dx4)({ playContextParams: d2, entityId: t2.entityId }), u2 = (0, i.useCallback)(
          (e3) => (0, a.jsx)(_.q1, {
            isAvailable: t2.isAvailable,
            isDisliked: t2.isDisliked,
            coverUri: t2.coverUri,
            title: t2.title,
            className: (0, r.$)(E().cover, em().cover),
            alt: c2({ id: "entity-names.track-name-by-type" }, { type: (0, h.yDn)(t2.type), name: t2.title }),
            radius: "xs",
            ...e3
          }),
          [c2, t2.coverUri, t2.isAvailable, t2.isDisliked, t2.title, t2.type]
        );
        return (0, a.jsx)(M.CC, {
          className: (0, r.$)(E().block, em().root),
          track: t2,
          meta: (0, a.jsx)(M.wo, {
            podcastMetaClassName: (0, r.$)(em().podcastMeta, em().important),
            titleContainerClassName: (0, r.$)(em().titleContainer, em().important),
            textClassName: (0, r.$)(em().text, em().important),
            progressClassName: (0, r.$)(em().progress, em().important),
            track: t2,
            playContextParams: d2,
            withListeningProgress: true,
            explicitSize: "xxxs",
            titleLineClamp: 2,
            withAlbumTitleLink: !n2
          }),
          playButtonCellRender: u2,
          playButtonIconSize: "l",
          controls: (0, a.jsx)(M.QD, { track: t2, utmLink: d2.contextData.utmLink, likeIconSize: "xs" }),
          ...m2,
          ...(0, l.Am)(l.Kq.track.TRACK_PODCAST)
        });
      });
      var eh = s(47713), e_ = s(24112), eS = s.n(e_);
      let ex = (0, p.PA)((e2) => {
        let { album: t2 } = e2;
        return (0, a.jsx)(v.M_, {
          album: t2,
          className: (0, r.$)(E().block, eS().root),
          coverClassName: E().cover,
          playButtonIconSize: "l",
          likeIconSize: "xs",
          description: (0, a.jsx)(eh.A, { id: "entity-names.recently-release" })
        });
      });
      var ep = s(66332), eC = s.n(ep);
      let ej = (0, p.PA)((e2) => {
        let { track: t2 } = e2, { from: s2 } = (0, h.fyy)(), {
          settings: { isMobile: o2 }
        } = (0, h.Pjs)(), c2 = {
          contextData: { type: O.K.Various, meta: { id: t2.entityId }, from: s2 },
          queueParams: { index: 0, entityId: t2.id },
          loadContextMeta: true
        }, n2 = (0, h.Dx4)({ playContextParams: c2, entityId: t2.entityId }), d2 = (0, i.useCallback)(
          (e3) => (0, a.jsx)(_.q1, {
            isAvailable: t2.isAvailable,
            isDisliked: t2.isDisliked,
            coverUri: t2.coverUri,
            title: t2.title,
            className: (0, r.$)(E().cover, eC().cover),
            radius: "xs",
            ...e3
          }),
          [t2.coverUri, t2.isAvailable, t2.isDisliked, t2.title]
        );
        return (0, a.jsx)(M.CC, {
          className: (0, r.$)(E().block, eC().root),
          track: t2,
          meta: (0, a.jsx)(M.j7, { withArtistLink: !o2, track: t2 }),
          playButtonCellRender: d2,
          playButtonIconSize: "l",
          controls: (0, a.jsx)(M.QD, { track: t2, utmLink: c2.contextData.utmLink, likeIconSize: "xs" }),
          ...n2,
          ...(0, l.Am)(l.Kq.track.SEARCH_TRACK_CARD)
        });
      });
      var eA = s(5956), eP = s(6971), eb = s(46423), ek = s(10212), ey = s.n(ek);
      let ev = (0, p.PA)((e2) => {
        let { upcomingAlbum: t2 } = e2, { ref: s2, intersectionPropertyId: c2 } = (0, h.nMI)(), { user: l2 } = (0, h.Pjs)(), { formatMessage: n2, formatDate: d2 } = (0, o.A)(), m2 = (0, eb.PL)(t2), u2 = (0, H.L)(() => {
          let e3 = n2({ id: "entity-names.upcoming-album-name" }, { upcomingAlbumName: t2.title }), s3 = t2.isPresave ? n2({ id: "entity-names.has-your-like" }) : "";
          return "".concat(e3, " ").concat(s3);
        }), S2 = (0, i.useCallback)(
          (e3, s3) => {
            var r2;
            return (null == (r2 = t2.artists) ? void 0 : r2.length) ? (0, a.jsx)(w.iQ, { linkClassName: e3, captionClassName: s3, artists: t2.artists, lineClamp: 1 }) : null;
          },
          [t2.artists]
        );
        return (0, a.jsxs)(_.Cj, {
          ref: s2,
          "data-intersection-property-id": c2,
          className: (0, r.$)(E().block, _.$f.root, ey().root, ey().important),
          "aria-label": u2,
          children: [
            (0, a.jsxs)(eP.Paper, {
              className: ey().cover,
              radius: "xs",
              children: [
                (0, a.jsx)(_.BW, {
                  className: ey().coverImage,
                  src: t2.coverUri,
                  size: 100,
                  alt: n2({ id: "entity-names.upcoming-album-name" }, { upcomingAlbumName: t2.title }),
                  fit: "cover",
                  withAvatarReplace: true,
                  fallbackIconSize: "m",
                  fallbackIconVariant: "lock"
                }),
                t2.coverUri && (0, a.jsx)(eA.Icon, { className: ey().lockIcon, variant: "lock", size: "xs" })
              ]
            }),
            (0, a.jsx)(_.ro, {
              title: (0, a.jsx)(D.Caption, {
                className: (0, r.$)(_.$f.text, _.$f.titleText),
                size: "l",
                variant: "div",
                type: "text",
                children: t2.title
              }),
              description: (0, a.jsx)(D.Caption, {
                className: ey().releaseDate,
                variant: "div",
                type: "entity",
                size: "m",
                weight: "medium",
                lineClamp: 1,
                children: (0, a.jsx)(eh.A, {
                  id: "entity-names.upcoming-album-date",
                  values: { releaseDate: d2(t2.releaseDate, (0, h.sDH)()) }
                })
              }),
              artistsComponent: S2,
              getDescriptionTexts: t2.getDescriptionTexts,
              explicitMarkVariant: t2.explicitDisclaimer
            }),
            (0, a.jsx)(_.aQ, {
              fallback: (0, a.jsx)(_.cy, {
                size: "xs",
                iconSize: "xs",
                className: ey().likeButton,
                isLiked: t2.isPresave,
                onClick: m2,
                disabled: !l2.isAuthorized
              })
            })
          ]
        });
      });
      var eT = s(93064), eE = s(76866), eI = s(89016), eg = s.n(eI);
      let eR = (0, p.PA)((e2) => {
        var t2;
        let { vibe: s2 } = e2;
        return (0, a.jsx)(eE.H2, {
          className: (0, r.$)(eg().root, eg().important),
          coverClassName: (0, r.$)(eg().coverClassName, eg().important),
          playButtonIconSize: "l",
          vibe: s2,
          cover: (0, eT.wg)({ uri: s2.backgroundImageUrl, color: null == (t2 = s2.colors) ? void 0 : t2.average }),
          description: s2.description,
          agentVariant: eE.hl.LARGE
        });
      }), eN = (0, p.PA)((e2) => {
        let { results: t2, isShimmerVisible: s2, isShimmerActive: c2, blockPosition: n2, sendSearchFeedback: m2 } = e2, { formatMessage: u2 } = (0, o.A)(), { experiments: _2 } = (0, h.Pjs)(), S2 = _2.checkExperiment(h.zal.disableAllConcerts, "on"), x2 = (0, i.useCallback)(
          (e3, s3) => {
            switch (e3.type) {
              case d.r.ALBUM:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Album,
                    objectId: String(e3.data.id),
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(h.NYB.Provider, {
                      value: {
                        sendSearchFeedback: m2,
                        id: e3.data.id,
                        type: j.o.ALBUM,
                        blockPosition: n2,
                        position: s3
                      },
                      children: (0, a.jsx)(R, { album: e3.data })
                    })
                  },
                  e3.data.id
                );
              case d.r.PLAYLIST:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Playlist,
                    objectId: e3.data.id,
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(h.NYB.Provider, {
                      value: {
                        sendSearchFeedback: m2,
                        id: e3.data.id,
                        type: j.o.PLAYLIST,
                        blockPosition: n2,
                        position: s3
                      },
                      children: (0, a.jsx)(en, { playlist: e3.data })
                    })
                  },
                  e3.data.id
                );
              case d.r.RECENT_RELEASE:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Album,
                    objectId: String(e3.data.id),
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(h.NYB.Provider, {
                      value: {
                        sendSearchFeedback: m2,
                        id: e3.data.id,
                        type: j.o.ALBUM,
                        blockPosition: n2,
                        position: s3
                      },
                      children: (0, a.jsx)(ex, { album: e3.data })
                    })
                  },
                  e3.data.id
                );
              case d.r.WAVE:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Wave,
                    objectId: e3.data.stationId,
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(h.NYB.Provider, {
                      value: {
                        sendSearchFeedback: m2,
                        id: e3.data.stationId,
                        type: j.o.WAVE,
                        blockPosition: n2,
                        position: s3
                      },
                      children: (0, a.jsx)(eR, { vibe: e3.data })
                    })
                  },
                  e3.data.stationId
                );
              case d.r.ARTIST:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Artist,
                    objectId: e3.data.id,
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(h.NYB.Provider, {
                      value: {
                        sendSearchFeedback: m2,
                        id: e3.data.id,
                        type: j.o.ARTIST,
                        blockPosition: n2,
                        position: s3
                      },
                      children: (0, a.jsx)(L, { artist: e3.data })
                    })
                  },
                  e3.data.id
                );
              case d.r.UPCOMING:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.UpcomingAlbum,
                    objectId: String(e3.data.id),
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(ev, { upcomingAlbum: e3.data })
                  },
                  e3.data.id
                );
              case d.r.CONCERT:
                if (S2) return null;
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Concert,
                    objectId: e3.data.id,
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(Z, { concert: e3.data })
                  },
                  e3.data.id
                );
              case d.r.PODCAST:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Podcast,
                    objectId: String(e3.data.id),
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(h.NYB.Provider, {
                      value: {
                        sendSearchFeedback: m2,
                        id: e3.data.id,
                        type: j.o.ALBUM,
                        blockPosition: n2,
                        position: s3
                      },
                      children: (0, a.jsx)(et, { album: e3.data })
                    })
                  },
                  e3.data.id
                );
              case d.r.NON_MUSIC:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Audiobook,
                    objectId: String(e3.data.id),
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(et, { album: e3.data })
                  },
                  e3.data.id
                );
              case d.r.PODCAST_EPISODE:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.PodcastEpisode,
                    objectId: e3.data.id,
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(eu, { track: e3.data })
                  },
                  e3.data.id
                );
              case d.r.OVERVIEW:
                return (0, a.jsx)(ei, { data: e3.data }, e3.type);
              case d.r.TRACK:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Track,
                    objectId: e3.data.id,
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(h.NYB.Provider, {
                      value: {
                        sendSearchFeedback: m2,
                        id: e3.data.entityId,
                        type: j.o.TRACK,
                        blockPosition: n2,
                        position: s3
                      },
                      children: (0, a.jsx)(ej, { track: e3.data })
                    })
                  },
                  e3.data.id
                );
              case d.r.CLIP:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.Video,
                    objectId: String(e3.data.clipId),
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(h.NYB.Provider, {
                      value: {
                        sendSearchFeedback: m2,
                        id: e3.data.clipId,
                        type: j.o.CLIP,
                        blockPosition: n2,
                        position: s3
                      },
                      children: (0, a.jsx)(W, { clip: e3.data })
                    })
                  },
                  e3.data.clipId
                );
              case d.r.BOOK_CHAPTER:
                return (0, a.jsx)(
                  h.Bki,
                  {
                    objectType: C.ky.AudiobookChapter,
                    objectId: String(e3.data.id),
                    objectPosX: s3 + 1,
                    objectPosY: 1,
                    objectsCount: t2.length,
                    children: (0, a.jsx)(U, { track: e3.data })
                  },
                  e3.data.id
                );
              default:
                return null;
            }
          },
          [n2, S2, t2.length, m2]
        ), p2 = (0, i.useMemo)(
          () => t2.map((e3, t3) => x2(e3, t3)).filter((e3) => (0, i.isValidElement)(e3)),
          [x2, t2, t2.length]
        );
        return s2 ? (0, a.jsx)(b, { isShimmerActive: c2 }) : p2.length ? (0, a.jsx)(h.FoH, {
          blockId: h.hf$.SEARCH_BEST_RESULTS,
          blockType: h.hf$.SEARCH_BEST_RESULTS,
          blockPosX: 1,
          blockPosY: 1,
          objectsCount: p2.length,
          children: (0, a.jsx)("div", {
            className: (0, r.$)(y().root, { [y().root_withSingleResult]: 1 === p2.length }),
            role: "group",
            "aria-label": u2({ id: "search-results.best" }),
            ...(0, l.Am)(l.e8.search.SEARCH_BEST_RESULTS),
            children: p2
          })
        }) : null;
      });
      var eB = s(77710);
      let ef = (0, p.PA)((e2) => {
        let {
          forwardRef: t2,
          items: s2 = [],
          title: r2,
          sendSearchFeedback: i2,
          blockPosition: o2 = 0,
          containerClassName: l2,
          headerClassName: d2,
          className: m2,
          itemClassName: u2,
          isShimmerVisible: S2,
          isShimmerActive: x2,
          isClipBlock: p2,
          ...C2
        } = e2, { search: A2 } = (0, h.Pjs)(), P2 = (0, X.df)(), b2 = s2.filter((e3) => e3.type !== n.n.PODCAST_EPISODE);
        return A2.isResolved && 0 === b2.length || p2 && !P2 ? null : (0, a.jsx)(_.OY, {
          isShimmerVisible: S2,
          isShimmerActive: x2,
          className: m2,
          containerClassName: l2,
          headerClassName: d2,
          showHeaderShimmer: true,
          title: r2,
          ref: t2,
          ...(0, c.getDataAttrFromProps)(C2),
          itemClassName: u2,
          children: b2.map((e3, t3) => {
            switch (e3.type) {
              case n.n.ALBUM:
                return (0, a.jsx)(
                  h.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: i2,
                      id: e3.data.id,
                      type: j.o.ALBUM,
                      blockPosition: o2,
                      position: t3
                    },
                    children: (0, a.jsx)(v.aX, { album: e3.data, contentLinesCount: 3 })
                  },
                  e3.data.id
                );
              case n.n.ARTIST:
                return (0, a.jsx)(
                  h.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: i2,
                      id: e3.data.id,
                      type: j.o.ARTIST,
                      blockPosition: o2,
                      position: t3
                    },
                    children: (0, a.jsx)(N.ao, { artist: e3.data, contentLinesCount: 3 })
                  },
                  e3.data.id
                );
              case n.n.PLAYLIST:
                return (0, a.jsx)(
                  h.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: i2,
                      id: e3.data.id,
                      type: j.o.PLAYLIST,
                      blockPosition: o2,
                      position: t3
                    },
                    children: (0, a.jsx)(eo.B6, { playlist: e3.data, contentLinesCount: 3 })
                  },
                  e3.data.key
                );
              case n.n.UGC_TRACK:
              case n.n.TRACK:
                return (0, a.jsx)(
                  h.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: i2,
                      id: e3.data.albumId ? "".concat(e3.data.id, ":").concat(e3.data.albumId) : e3.data.id,
                      type: j.o.TRACK,
                      blockPosition: o2,
                      position: t3
                    },
                    children: (0, a.jsx)(M.wO, { track: e3.data, overrideContextType: eB.b.Search })
                  },
                  e3.data.id
                );
              case n.n.CLIP:
                return (0, a.jsx)(
                  h.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: i2,
                      id: e3.data.clipId,
                      type: j.o.WAVE,
                      blockPosition: o2,
                      position: t3
                    },
                    children: (0, a.jsx)(V.FC, { clip: e3.data })
                  },
                  e3.data.clipId
                );
              case n.n.PODCAST:
                return (0, a.jsx)(
                  h.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: i2,
                      id: e3.data.id,
                      type: j.o.PODCAST,
                      blockPosition: o2,
                      position: t3
                    },
                    children: (0, a.jsx)(v.aX, {
                      album: e3.data,
                      contentLinesCount: 3,
                      withLikesCount: true,
                      withAddition: false
                    })
                  },
                  e3.data.id
                );
              case n.n.WAVE:
                return (0, a.jsx)(
                  h.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: i2,
                      id: e3.data.stationId,
                      type: j.o.WAVE,
                      blockPosition: 0,
                      position: t3
                    },
                    children: (0, a.jsx)(eE.H2, {
                      vibe: e3.data,
                      cover: e3.data.cover,
                      description: e3.data.description,
                      agentVariant: eE.hl.SMALL
                    })
                  },
                  e3.data.stationId
                );
            }
          })
        });
      }), eL = (0, i.forwardRef)((e2, t2) => (0, a.jsx)(ef, { forwardRef: t2, ...e2 }));
      var eO = s(63305), eH = s.n(eO);
      let eD = (e2) => {
        let {
          forwardRef: t2,
          className: s2,
          results: p2,
          bestResults: C2,
          sendSearchFeedback: j2,
          searchCorrectedText: A2,
          isShimmerVisible: P2,
          isShimmerActive: b2,
          ...k2
        } = e2, { formatMessage: y2 } = (0, o.A)(), v2 = (0, i.useMemo)(() => {
          let e3 = {
            [n.n.ALL]: { message: y2({ id: "search-results.best" }), type: n.n.ALL, items: [] },
            [n.n.ARTIST]: { message: y2({ id: "search-results.artist" }), type: n.n.ARTIST, items: [] },
            [n.n.PODCAST]: {
              message: y2({ id: "search-results.podcasts-and-books" }),
              type: n.n.PODCAST,
              items: []
            },
            [n.n.ALBUM]: { message: y2({ id: "search-results.album" }), type: n.n.ALBUM, items: [] },
            [n.n.PLAYLIST]: { message: y2({ id: "search-results.playlist" }), type: n.n.PLAYLIST, items: [] },
            [n.n.CLIP]: { message: y2({ id: "search-results.clip" }), type: n.n.CLIP, items: [] }
          };
          p2.forEach((t4) => {
            var s3, a2;
            null == (s3 = e3[t4.type]) || s3.items.push(t4), null == (a2 = e3[n.n.ALL]) || a2.items.push(t4);
          });
          let t3 = {
            [n.n.ARTIST]: l.e8.search.SEARCH_MIXED_ARTIST,
            [n.n.PODCAST]: l.e8.search.SEARCH_MIXED_PODCAST,
            [n.n.ALBUM]: l.e8.search.SEARCH_MIXED_ALBUM,
            [n.n.PLAYLIST]: l.e8.search.SEARCH_MIXED_PLAYLIST,
            [n.n.CLIP]: l.e8.search.SEARCH_MIXED_CLIP,
            [d.r.PODCAST]: l.e8.search.SEARCH_MIXED_BEST_PODCAST,
            [d.r.OVERVIEW]: l.e8.search.SEARCH_MIXED_BEST_OVERVIEW,
            [d.r.PODCAST_EPISODE]: l.e8.search.SEARCH_MIXED_BEST_PODCAST_EPISODE,
            [d.r.NON_MUSIC]: l.e8.search.SEARCH_MIXED_BEST_NON_MUSIC
          };
          return Object.getOwnPropertyNames(e3).map((s3, r2) => {
            let o2 = e3[s3], c2 = o2.type === n.n.CLIP;
            if (o2.type === n.n.ALL) {
              let e4 = o2.items.map((e5, t4) => {
                let {
                  objectPosX: s4,
                  objectPosY: a2,
                  objectsCount: i2
                } = (0, h.$tp)({
                  index: t4,
                  count: o2.items.length,
                  itemsCountPerColumn: 3,
                  showedItemsCountInBlock: 6
                });
                return (0, S.G)({
                  item: e5,
                  index: t4,
                  sendSearchFeedback: j2,
                  blockPosition: r2,
                  objectPosX: s4,
                  objectPosY: a2,
                  objectsCount: i2
                });
              }).filter((e5) => (0, i.isValidElement)(e5));
              return (0, a.jsxs)(
                i.Fragment,
                {
                  children: [
                    (0, a.jsx)(eN, {
                      results: C2,
                      isShimmerVisible: P2,
                      isShimmerActive: b2,
                      blockPosition: r2,
                      sendSearchFeedback: j2
                    }),
                    (0, a.jsx)(h.FoH, {
                      blockId: h.hf$.SEARCH_OPEN_BEST_RESULTS,
                      blockType: h.hf$.SEARCH_OPEN_BEST_RESULTS,
                      blockPosX: 1,
                      blockPosY: 1,
                      objectsCount: e4.length,
                      children: (0, a.jsx)(x.k, {
                        containerClassName: eH().blockMixed,
                        className: eH().block,
                        maxColumns: 2,
                        itemsPerColumn: 3,
                        showControls: true,
                        "aria-label": y2({ id: "search-results.other-results" }),
                        isShimmerVisible: P2,
                        isShimmerActive: b2,
                        children: e4
                      })
                    })
                  ]
                },
                r2
              );
            }
            let d2 = t3[o2.type], m2 = d2 ? (0, l.Am)(d2) : {};
            return (0, a.jsx)(
              eL,
              {
                className: eH().block,
                headerClassName: eH().blockHeader,
                containerClassName: eH().blockCarousel,
                blockPosition: r2,
                items: o2.items,
                title: o2.message,
                sendSearchFeedback: j2,
                isShimmerVisible: P2,
                isShimmerActive: b2,
                isClipBlock: c2,
                ...m2
              },
              r2
            );
          });
        }, [y2, p2, j2, P2, b2, C2]);
        return (0, a.jsxs)(u.N, {
          className: (0, r.$)(eH().root, s2),
          containerClassName: eH().container,
          ref: t2,
          ...(0, c.getDataAttrFromProps)(k2),
          children: [
            (0, a.jsxs)("div", {
              className: eH().content,
              children: [
                A2 && (0, a.jsx)("div", { className: eH().correctedTextBlock, children: A2 }),
                (0, a.jsx)(h.hjC, {
                  tabId: m.$.TOP,
                  tabPos: 1,
                  isTabSelectedByDefault: true,
                  children: (0, a.jsx)("div", { className: eH().items, children: v2 })
                })
              ]
            }),
            (0, a.jsx)(_.A, { children: (0, a.jsx)(_.wi, { className: eH().footer }) })
          ]
        });
      }, eM = (0, i.forwardRef)((e2, t2) => (0, a.jsx)(eD, { forwardRef: t2, ...e2 }));
    },
    38598: (e) => {
      e.exports = {
        carouselBlock: "MixesCarousel_carouselBlock__ZpMU2",
        carouselHeader: "MixesCarousel_carouselHeader__6mMHX",
        mixItem: "MixesCarousel_mixItem__YNSsB"
      };
    },
    39577: (e) => {
      e.exports = {
        header: "SearchPodcastEpisodes_header__uqkmY",
        root: "SearchPodcastEpisodes_root__VjZhR",
        clearButton: "SearchPodcastEpisodes_clearButton__eeDVF",
        content: "SearchPodcastEpisodes_content__96WMv",
        podcastColumn: "SearchPodcastEpisodes_podcastColumn___K9Sr",
        important: "SearchPodcastEpisodes_important__c4dHK"
      };
    },
    40162: (e) => {
      e.exports = {
        header: "SearchPage_header__T2OUM",
        root: "SearchPage_root__TtwTi",
        root_showFilters: "SearchPage_root_showFilters__pb2o1",
        input: "SearchPage_input__7L7wS",
        content: "SearchPage_content__Ax9D6",
        scrollableContent: "SearchPage_scrollableContent__qdrWa",
        main: "SearchPage_main__FDQGD",
        carousel: "SearchPage_carousel__7jwGp",
        tabs: "SearchPage_tabs__tlwgh",
        tab: "SearchPage_tab__2yIDQ",
        tab_selected: "SearchPage_tab_selected__Z7lYv",
        compilations: "SearchPage_compilations__ZHEUr",
        footer: "SearchPage_footer__uQN_X",
        error: "SearchPage_error__WSxpu",
        skeletonStickyHeader: "SearchPage_skeletonStickyHeader__SQqeV",
        important: "SearchPage_important__z3aCa",
        skeletonContainer: "SearchPage_skeletonContainer__phbvK",
        mixes: "SearchPage_mixes__yusZB"
      };
    },
    40334: (e) => {
      e.exports = { block: "SearchBestResultsCommon_block__v11At", cover: "SearchBestResultsCommon_cover__ZHlYo" };
    },
    42320: (e, t, s) => {
      "use strict";
      s.d(t, {
        xo: () => U,
        tn: () => $.SearchCorrectedText,
        qz: () => V.SearchEmpty,
        ok: () => X.SearchEntitiesGrid,
        k1: () => n,
        _K: () => G.SearchHistoryBlock,
        jU: () => E,
        kp: () => z.SearchMixed,
        Jh: () => W.SearchPodcastList,
        uU: () => F.SearchTrackList,
        Gw: () => o.G,
        t9: () => c.useClearHistory
      }), s(54486);
      var a = s(94376);
      s(55616);
      var r = s(83909), i = s(21365), o = s(12200), c = s(96125), l = s(93064);
      let n = l.gK.model("SearchFilter", { id: l.gK.string, displayName: l.gK.string });
      var d = s(76421), m = s(51427), u = s(65779), h = s(985), _ = s(63695), S = s(77217), x = s(76866);
      let p = l.gK.model("SearchAlbum", { type: l.gK.literal(d.n.ALBUM), data: a.JC }), C = l.gK.model("SearchPlaylist", { type: l.gK.literal(d.n.PLAYLIST), data: r.IP }), j = l.gK.model("SearchArtist", { type: l.gK.literal(d.n.ARTIST), data: _.PK }), A = l.gK.model("SearchUgcTrack", { type: l.gK.literal(d.n.UGC_TRACK), data: i.kK }), P = l.gK.model("SearchTrack", { type: l.gK.literal(d.n.TRACK), data: i.vj }), b = l.gK.model("SearchVibe", { type: l.gK.literal(d.n.WAVE), data: x.Gh }), k = l.gK.model("SearchPodcast", { type: l.gK.literal(d.n.PODCAST), data: a.JC }), y = l.gK.model("SearchPodcastEpisode", { type: l.gK.literal(d.n.PODCAST_EPISODE), data: i.vj }), v = l.gK.model("SearchClip", { type: l.gK.literal(d.n.CLIP), data: u.kv }), T = l.gK.model("SearchConcert", { type: l.gK.literal(d.n.CONCERT), data: S.aR }), E = l.gK.union(p, C, j, P, A, b, k, y, v, T), I = l.gK.model("SearchBestVibe", { type: l.gK.literal(m.r.WAVE), data: x.Gh }), g = l.gK.model("SearchBestPlaylist", { type: l.gK.literal(m.r.PLAYLIST), data: r.IP }), R = l.gK.model("SearchBestArtist", { type: l.gK.literal(m.r.ARTIST), data: _.PK }), N = l.gK.model("SearchBestPresave", { type: l.gK.literal(m.r.UPCOMING), data: a.VH }), B = l.gK.model("SearchBestAlbum", { type: l.gK.literal(m.r.ALBUM), data: a.JC }), f = l.gK.model("SearchBestRecentRelease", { type: l.gK.literal(m.r.RECENT_RELEASE), data: a.JC }), L = l.gK.model("SearchBestConcert", { type: l.gK.literal(m.r.CONCERT), data: S.aR }), O = l.gK.model("SearchBestTrack", { type: l.gK.literal(m.r.TRACK), data: i.vj }), H = l.gK.model("SearchBestPodcast", { type: l.gK.literal(m.r.PODCAST), data: a.JC }), D = l.gK.model("SearchBestPodcastEpisode", { type: l.gK.literal(m.r.PODCAST_EPISODE), data: i.vj }), M = l.gK.model("SearchBestOverview", { type: l.gK.literal(m.r.OVERVIEW), data: h.kv }), w = l.gK.model("SearchBestNonMusic", { type: l.gK.literal(m.r.NON_MUSIC), data: a.JC }), K = l.gK.model("SearchBestClip", { type: l.gK.literal(m.r.CLIP), data: u.kv }), Y = l.gK.model("SearchBestBookChapter", { type: l.gK.literal(m.r.BOOK_CHAPTER), data: i.vj }), U = l.gK.union(B, f, I, R, L, O, H, D, M, w, N, g, K, Y);
      var $ = s(98045), V = s(83681), X = s(96194), G = s(55269), z = s(37536), W = s(66213), F = s(98006);
    },
    43874: (e, t, s) => {
      "use strict";
      s.d(t, { SearchHistoryPage: () => j });
      var a = s(54486), r = s(12186), i = s(28303), o = s(97396), c = s(61910), l = s(43426), n = s(47713), d = s(31500), m = s(77881), u = s(5956), h = s(56231), _ = s(97800), S = s(42320), x = s(74125), p = s(71378), C = s.n(p);
      let j = (0, i.PA)(() => {
        let {
          search: e2,
          user: t2,
          settings: { isMobile: s2 }
        } = (0, x.Pjs)(), { setContentScrollRef: i2 } = (0, x.gKY)(), { formatMessage: p2 } = (0, l.A)(), j2 = (0, x.W6M)(), A = (0, c.useRef)(false), P = (0, c.useRef)(null), b = (0, S.t9)(() => {
          A.current = true;
        }), k = e2.historyPage.items.length;
        t2.isAuthorized && (0, o.notFound)(), (0, c.useEffect)(() => {
          P.current && j2.canBack && P.current.focus();
        }, [j2.canBack]), (0, c.useEffect)(
          () => () => {
            (null == A ? void 0 : A.current) ? (e2.resetHistoryItems(), A.current = false) : e2.resetHistoryStateRequest();
          },
          [e2]
        );
        let y = (0, c.useMemo)(
          () => (0, r.A)(() => {
            null == j2 || j2.back();
          }, 200),
          [j2]
        ), v = (0, c.useMemo)(
          () => k ? (0, a.jsx)("div", {
            className: C().items,
            children: e2.historyPage.items.map((e3, t3) => (0, S.Gw)({ item: e3, index: t3, pageId: x._Q$.SEARCH })).filter((e3) => !!e3)
          }) : (0, a.jsx)(_.Caption, {
            className: C().emptyHistory,
            variant: "div",
            size: "m",
            type: "text",
            children: (0, a.jsx)(n.A, { id: "search.history-empty" })
          }),
          [e2.historyPage.items, k]
        );
        return e2.isHistoryReady && t2.account.data.uid && (0, c.use)(e2.getHistory({ userId: t2.account.data.uid })), (0, a.jsx)("div", {
          className: C().root,
          ...(0, d.Am)(d.Xk.search.SEARCH_HISTORY_PAGE),
          children: (0, a.jsxs)(h.N, {
            className: C().scrollContent,
            containerClassName: C().scrollContainer,
            ref: i2,
            children: [
              (0, a.jsxs)("div", {
                className: C().header,
                children: [
                  (0, a.jsxs)("div", {
                    className: C().title,
                    children: [
                      j2.canBack && (0, a.jsx)(m.$, {
                        ref: P,
                        "aria-label": p2({ id: "navigation.go-back" }),
                        radius: "round",
                        disabled: !j2.canBack,
                        size: "s",
                        icon: (0, a.jsx)(u.Icon, { size: "xxs", variant: "arrowLeft" }),
                        onClick: y
                      }),
                      (0, a.jsx)(_.Heading, {
                        variant: "h2",
                        size: s2 ? "m" : "xl",
                        children: (0, a.jsx)(n.A, { id: "search.history" })
                      })
                    ]
                  }),
                  (0, a.jsx)(m.$, {
                    "aria-label": p2({ id: "search.clear-history" }),
                    radius: "xxxl",
                    variant: "outline",
                    disabled: !k,
                    size: s2 ? "s" : "default",
                    onClick: b,
                    children: (0, a.jsx)(_.Caption, {
                      variant: "span",
                      size: "m",
                      type: "text",
                      children: (0, a.jsx)(n.A, { id: "search.clear-history" })
                    })
                  })
                ]
              }),
              !e2.isHistoryLoading && v
            ]
          })
        });
      });
    },
    49692: (e) => {
      e.exports = { root: "SearchBestResultsNonMusicBlock_root__YagzT" };
    },
    51427: (e, t, s) => {
      "use strict";
      var a;
      s.d(t, { r: () => a }), (function(e2) {
        e2.TRACK = "best_result_track", e2.ARTIST = "best_result_artist", e2.CONCERT = "best_result_concert", e2.RECENT_RELEASE = "best_result_recent_release", e2.ALBUM = "best_result_album", e2.WAVE = "best_result_wave", e2.ARTISTS_RELATED = "best_result_artists_related", e2.OVERVIEW = "best_result_overview", e2.PODCAST = "best_result_podcast", e2.PODCAST_EPISODE = "best_result_podcast_episode", e2.NON_MUSIC = "best_result_non_music", e2.CLIP = "best_result_clip", e2.UPCOMING = "best_result_upcoming", e2.PLAYLIST = "best_result_playlist", e2.BOOK_CHAPTER = "best_result_book_chapter";
      })(a || (a = {}));
    },
    54797: (e) => {
      e.exports = {
        root: "SearchEmpty_root__Yz53B",
        container: "SearchEmpty_container__6WP_o",
        content: "SearchEmpty_content__OdVMa",
        correctedTextBlock: "SearchEmpty_correctedTextBlock__wR4Hh",
        icon: "SearchEmpty_icon__NYKMM",
        title: "SearchEmpty_title__C77x5",
        subtitle: "SearchEmpty_subtitle__2TlGa",
        footer: "SearchEmpty_footer__WP03G"
      };
    },
    55269: (e, t, s) => {
      "use strict";
      s.d(t, { SearchHistoryBlock: () => A });
      var a = s(54486), r = s(28303), i = s(74125), o = s(61910), c = s(43426), l = s(12200), n = s(82265), d = s(86482), m = s.n(d);
      let u = (0, r.PA)(() => {
        let { search: e2, user: t2 } = (0, i.Pjs)(), { formatMessage: s2 } = (0, c.A)(), r2 = e2.historyPage.items;
        if ((0, o.useEffect)(
          () => () => {
            var t3;
            (null == (t3 = location) ? void 0 : t3.pathname) !== i.Zyd.searchHistory.href && e2.resetHistoryStateRequest();
          },
          [e2]
        ), e2.isHistoryReady && t2.account.data.uid && (0, o.use)(e2.getHistory({ userId: t2.account.data.uid })), 0 === r2.length)
          return null;
        let d2 = r2.map((e3, t3) => (0, l.G)({ item: e3, index: t3, pageId: i._Q$.SEARCH })).filter((e3) => (0, o.isValidElement)(e3));
        return (0, a.jsx)("section", {
          className: m().root,
          children: (0, a.jsx)(n.k, {
            headerClassName: m().header,
            containerClassName: m().content,
            isShimmerVisible: e2.isHistoryShimmerVisible,
            isShimmerActive: e2.isHistoryLoading,
            title: s2({ id: "search.history" }),
            viewAllAction: i.Zyd.searchHistory.href,
            maxColumns: 2,
            itemsPerColumn: 4,
            showControls: true,
            children: d2
          })
        });
      });
      var h = s(47713), _ = s(77881), S = s(97800), x = s(96125), p = s(2257), C = s.n(p);
      let j = (0, r.PA)(() => {
        let { search: e2, user: t2 } = (0, i.Pjs)(), { formatMessage: s2 } = (0, c.A)(), r2 = (0, x.useClearHistory)(e2.resetHistoryItems), d2 = e2.historyPage.items;
        if ((0, o.useEffect)(
          () => () => {
            var t3;
            (null == (t3 = location) ? void 0 : t3.pathname) !== i.Zyd.searchHistory.href && e2.resetHistoryStateRequest();
          },
          [e2]
        ), e2.isHistoryReady && t2.account.data.uid && (0, o.use)(e2.getHistory({ userId: t2.account.data.uid })), 0 === d2.length)
          return null;
        let m2 = d2.map((e3, t3) => (0, l.G)({ item: e3, index: t3, pageId: i._Q$.SEARCH })).filter((e3) => (0, o.isValidElement)(e3));
        return (0, a.jsxs)("div", {
          children: [
            (0, a.jsx)(n.k, {
              headerClassName: C().header,
              containerClassName: C().mixedEntitiesBlock,
              isShimmerVisible: e2.isHistoryShimmerVisible,
              isShimmerActive: e2.isHistoryLoading,
              title: s2({ id: "search.history" }),
              viewAllAction: i.Zyd.searchHistory.href,
              titleSize: "xs",
              children: m2
            }),
            (0, a.jsx)("div", {
              className: C().buttonContainer,
              children: (0, a.jsx)(_.$, {
                className: C().button,
                "aria-label": s2({ id: "search.clear-history" }),
                disabled: !d2.length,
                size: "default",
                radius: "xxxl",
                onClick: r2,
                children: (0, a.jsx)(S.Caption, {
                  variant: "span",
                  size: "m",
                  type: "text",
                  children: (0, a.jsx)(h.A, { id: "search.clear-history" })
                })
              })
            })
          ]
        });
      }), A = (0, r.PA)(() => {
        let {
          settings: { isMobile: e2 }
        } = (0, i.Pjs)();
        return e2 ? (0, a.jsx)(j, {}) : (0, a.jsx)(u, {});
      });
    },
    57329: (e) => {
      e.exports = {
        root: "MixedEntitiesBlock_root__Zs8l2",
        controls: "MixedEntitiesBlock_controls__mOhq7",
        item: "MixedEntitiesBlock_item__uRvxc",
        item_withMultipleColumns: "MixedEntitiesBlock_item_withMultipleColumns__ziUqI",
        column: "MixedEntitiesBlock_column__sHpUC"
      };
    },
    59214: (e) => {
      e.exports = {
        root: "SearchBestResultsPodcastEpisodeBlock_root__YHMZ5",
        cover: "SearchBestResultsPodcastEpisodeBlock_cover__QuzER",
        podcastMeta: "SearchBestResultsPodcastEpisodeBlock_podcastMeta__u2dSw",
        important: "SearchBestResultsPodcastEpisodeBlock_important__qJ_Ej",
        titleContainer: "SearchBestResultsPodcastEpisodeBlock_titleContainer__MNogD",
        text: "SearchBestResultsPodcastEpisodeBlock_text__uJpwJ",
        progress: "SearchBestResultsPodcastEpisodeBlock_progress__ftBpc"
      };
    },
    61433: (e) => {
      e.exports = {
        root: "SearchTrackList_root__pSSfZ",
        container: "SearchTrackList_container__Bww_R",
        shimmer: "SearchTrackList_shimmer__L9t1x",
        correctedTextBlock: "SearchTrackList_correctedTextBlock__w5t0t",
        items: "SearchTrackList_items__VucVX",
        footer: "SearchTrackList_footer__M70p4"
      };
    },
    63305: (e) => {
      e.exports = {
        root: "SearchMixed_root__RR4QT",
        container: "SearchMixed_container__KIfE1",
        correctedTextBlock: "SearchMixed_correctedTextBlock___1rfE",
        block: "SearchMixed_block__SasiH",
        blockCarousel: "SearchMixed_blockCarousel__IQjJA",
        blockHeader: "SearchMixed_blockHeader__L0FSh",
        blockMixed: "SearchMixed_blockMixed__udOYV",
        footer: "SearchMixed_footer__INQFP",
        item: "SearchMixed_item__aTIrG",
        important: "SearchMixed_important__1ncD8"
      };
    },
    66213: (e, t, s) => {
      "use strict";
      s.d(t, { SearchPodcastList: () => b });
      var a = s(54486), r = s(61910), i = s(31500), o = s(76421), c = s(27510), l = s(96194), n = s(50420), d = s(28303), m = s(43426), u = s(63585), h = s(84213), _ = s(21365), S = s(74125), x = s(80585), p = s(39577), C = s.n(p);
      let j = (0, d.PA)((e2) => {
        let { results: t2, sendSearchFeedback: s2, isShimmerVisible: o2, isShimmerActive: c2 } = e2, { from: l2 } = (0, S.fyy)(), { formatMessage: d2 } = (0, m.A)(), p2 = (0, r.useMemo)(
          () => t2.map((e3, t3) => {
            let r2 = e3.data.albumId ? "".concat(e3.data.id, ":").concat(e3.data.albumId) : e3.data.id;
            return (0, a.jsx)(
              S.NYB.Provider,
              {
                value: {
                  sendSearchFeedback: s2,
                  id: e3.data.id,
                  type: h.o.PODCAST_EPISODE,
                  blockPosition: 0,
                  position: t3
                },
                children: (0, a.jsx)(_.Kd, {
                  track: e3.data,
                  playContextParams: {
                    contextData: { type: u.K.Various, meta: { id: r2 }, from: l2 },
                    queueParams: { index: 0, entityId: e3.data.id },
                    loadContextMeta: true
                  },
                  withPodcastName: true
                })
              },
              r2
            );
          }),
          [t2, l2, s2]
        );
        return (0, a.jsx)(x.$2, {
          className: C().root,
          blockHeaderClassName: C().header,
          carouselClassName: C().content,
          carouselItemClassName: (0, n.$)(C().podcastColumn, C().important),
          isShimmerVisible: o2,
          isShimmerActive: c2,
          blockHeaderTitle: d2({ id: "search-results.podcast-episodes" }),
          maxColumnsCount: x.DI.ONE,
          itemsCountPerColumn: 4,
          shimmer: (0, a.jsx)(x.DS, { variant: S.Xjt.PLAYLIST, isActive: true }),
          ...(0, i.Am)(i.S7.CAROUSEL_WITH_COLUMNS_BLOCK),
          children: p2
        });
      }), A = (0, r.forwardRef)((e2, t2) => (0, a.jsx)(j, { forwardRef: t2, ...e2 })), P = (e2) => {
        let {
          forwardRef: t2,
          results: s2,
          sendSearchFeedback: r2,
          searchCorrectedText: n2,
          className: d2,
          isShimmerVisible: m2,
          isShimmerActive: u2
        } = e2, { podcasts: h2, podcastEpisodes: _2 } = ((e3) => {
          let t3 = [], s3 = [];
          return e3.forEach((e4) => {
            e4.type === o.n.PODCAST ? t3.push(e4) : s3.push(e4);
          }), { podcasts: t3, podcastEpisodes: s3 };
        })(s2), S2 = (0, c.L)(() => {
          if (_2.length)
            return (0, a.jsx)(A, { sendSearchFeedback: r2, results: _2, isShimmerVisible: m2, isShimmerActive: u2 });
        });
        return (0, a.jsx)(l.SearchEntitiesGrid, {
          ref: t2,
          className: d2,
          results: h2,
          filter: o.n.PODCAST,
          sendSearchFeedback: r2,
          searchCorrectedText: n2,
          isShimmerVisible: m2,
          isShimmerActive: u2,
          ...(0, i.Am)(i.Xk.search.SEARCH_PAGE_RESULTS_PODCAST),
          children: S2
        });
      }, b = (0, r.forwardRef)((e2, t2) => (0, a.jsx)(P, { forwardRef: t2, ...e2 }));
    },
    66332: (e) => {
      e.exports = {
        root: "SearchBestResultsTrackBlock_root__Qsh_f",
        cover: "SearchBestResultsTrackBlock_cover__aCixO"
      };
    },
    71378: (e) => {
      e.exports = {
        root: "SearchHistoryPage_root__Wbvyf",
        title: "SearchHistoryPage_title__gnJuo",
        header: "SearchHistoryPage_header__YdTG5",
        scrollContainer: "SearchHistoryPage_scrollContainer__ScAez",
        scrollContent: "SearchHistoryPage_scrollContent__5AXWC",
        content: "SearchHistoryPage_content__iPgVO",
        desktopItem: "SearchHistoryPage_desktopItem__Xv9C_",
        items: "SearchHistoryPage_items___okS8",
        emptyHistory: "SearchHistoryPage_emptyHistory__gzfUu"
      };
    },
    72344: (e, t, s) => {
      "use strict";
      s.d(t, { MixesGrid: () => _ });
      var a = s(54486), r = s(50420), i = s(28303), o = s(61910), c = s(47713), l = s(31500), n = s(97800), d = s(27906), m = s(80585), u = s(74146), h = s.n(u);
      let _ = (0, i.PA)((e2) => {
        let { isShimmerVisible: t2, isShimmerActive: s2, withTitle: i2, mixes: u2, shimmerCount: _2 = 5, className: S } = e2, x = (0, o.useMemo)(
          () => t2 ? (0, a.jsx)(m.eI, { isActive: s2, round: false, centered: false, withInfo: false, count: _2 }) : u2.map(
            (e3) => (0, a.jsx)(
              d.NZ,
              { title: e3.title, weblink: e3.weblink, covers: e3.covers, imagesLayoutType: e3.imagesLayoutType },
              e3.id
            )
          ),
          [s2, t2, u2, _2]
        );
        return (0, a.jsxs)("div", {
          ...(0, l.Am)(l.e8.mixes.MIXES_GRID_CONTAINER),
          children: [
            i2 && (0, a.jsx)(n.Heading, {
              className: h().mixesTitle,
              size: "s",
              weight: "bold",
              variant: "h3",
              ...(0, l.Am)(l.e8.mixes.MIXES_GRID_HEADER),
              children: (0, a.jsx)(c.A, { id: "entity-names.mixes" })
            }),
            (0, a.jsx)("div", { className: (0, r.$)(h().mixesGrid, S), children: x })
          ]
        });
      });
    },
    74146: (e) => {
      e.exports = { mixesTitle: "MixesGrid_mixesTitle__QawnL", mixesGrid: "MixesGrid_mixesGrid__uZQtt" };
    },
    76421: (e, t, s) => {
      "use strict";
      var a;
      s.d(t, { n: () => a }), (function(e2) {
        e2.ALL = "all", e2.TRACK = "track", e2.ALBUM = "album", e2.ARTIST = "artist", e2.PLAYLIST = "playlist", e2.WAVE = "wave", e2.GENRE = "genre", e2.USER = "user", e2.UGC_TRACK = "ugc_track", e2.PODCAST = "podcast", e2.PODCAST_EPISODE = "podcast_episode", e2.VIDEO = "video", e2.LYRICS = "lyrics", e2.CLIP = "clip", e2.BOOK = "book", e2.CONCERT = "concert";
      })(a || (a = {}));
    },
    78508: (e) => {
      e.exports = { cover: "SearchBestResultsClipBlock_cover___5Wwj" };
    },
    81268: (e) => {
      e.exports = {
        root: "SearchBestResultsBookChapterBlock_root__2JjcF",
        cover: "SearchBestResultsBookChapterBlock_cover__I2CYO"
      };
    },
    81531: (e, t, s) => {
      "use strict";
      s.d(t, { Z_: () => d.Mixes, nL: () => m.MixesGrid, YM: () => n });
      var a = s(93064), r = s(14287), i = s(35620), o = s(27906), c = s(74125), l = s(26433);
      let n = a.gK.compose(a.gK.model("Mixes", { items: a.gK.array(o.f), errorStatusCode: a.gK.maybeNull(a.gK.number) }), l.XT).views((e2) => ({
        get isLoading() {
          return e2.isNeededToLoad || e2.loadingState === c.GuX.PENDING;
        },
        get isNotFound() {
          let t2 = e2.isResolved && 0 === e2.items.length;
          return e2.errorStatusCode === r.X1.NOT_FOUND || t2;
        }
      })).actions((e2) => ({
        getMixes: (0, a.L3)(function* (t2) {
          let { landingResource: s2, modelActionsLogger: l2 } = (0, a._$)(e2);
          if (e2.loadingState !== c.GuX.PENDING)
            try {
              e2.loadingState = c.GuX.PENDING;
              let r2 = yield s2.getBlock({ source: { uri: "/landing/block/mixes", fullList: t2 }, type: i.t.MIXES });
              e2.items = { items: (0, a.wg)(r2.items.map((e3) => (0, o.Ju)(e3.data))) }.items, e2.loadingState = c.GuX.RESOLVE;
            } catch (t3) {
              l2.error(t3), t3 instanceof r.GX && (t3.statusCode === r.X1.NOT_FOUND || t3.statusCode === r.X1.BAD_REQUEST) && (e2.errorStatusCode = r.X1.NOT_FOUND), e2.loadingState !== c.GuX.IDLE && (e2.loadingState = c.GuX.REJECT);
            }
        })
      }));
      var d = s(32271), m = s(72344);
    },
    82265: (e, t, s) => {
      "use strict";
      s.d(t, { k: () => _ });
      var a = s(54486), r = s(50420), i = s(44282), o = s(61910), c = s(31500), l = s(81203), n = s(80585), d = s(36516), m = s(57329), u = s.n(m);
      let h = (e2) => {
        let {
          forwardRef: t2,
          title: s2,
          description: m2,
          viewAllAction: h2,
          coverUrl: _2,
          children: S,
          className: x,
          maxColumns: p = 2,
          itemsPerColumn: C = 3,
          containerClassName: j,
          headerClassName: A,
          titleSize: P,
          showControls: b,
          isShimmerVisible: k,
          isShimmerActive: y
        } = e2, v = (0, o.useRef)(null), T = (0, o.useId)(), { items: E, columnLength: I } = (0, o.useMemo)(() => {
          if (k)
            return {
              columnLength: p,
              items: Array.from(
                { length: p },
                (e4, t3) => (0, a.jsx)(
                  "div",
                  { className: u().column, children: (0, a.jsx)(d.V, { shimmersCount: 3, isShimmerActive: y }) },
                  t3
                )
              )
            };
          let e3 = (0, i.A)(S, C).slice(0, (null == S ? void 0 : S.length) ? Math.ceil(S.length / C) : p);
          return {
            items: e3.map((e4, t3) => (0, a.jsx)("div", { className: u().column, children: e4 }, t3)),
            columnLength: e3.length
          };
        }, [S, y, k, C, p]);
        return (0, a.jsxs)("section", {
          ref: t2,
          className: (0, r.$)(x, u().root),
          ...(0, c.Am)(c.e8.search.MIXED_ENTITIES_BLOCK),
          children: [
            (0, a.jsx)(n.Tw, {
              className: A,
              labeledForId: T,
              title: s2,
              description: m2,
              coverUrl: _2,
              viewAllActionLink: h2,
              titleSize: P,
              controls: b && (0, a.jsx)(n.X9, { className: u().controls, carouselRef: v }),
              withDescription: !!m2
            }),
            (0, a.jsx)(l.Carousel, {
              className: j,
              ref: v,
              itemClassName: (0, r.$)(u().item, { [u().item_withMultipleColumns]: I > 1 }),
              "aria-labelledby": T,
              role: "group",
              children: E
            })
          ]
        });
      }, _ = (0, o.forwardRef)((e2, t2) => (0, a.jsx)(h, { forwardRef: t2, ...e2 }));
    },
    82957: (e) => {
      e.exports = {
        root: "SearchBestResults_root__12Tlp",
        root_withSingleResult: "SearchBestResults_root_withSingleResult__qAMCB"
      };
    },
    83681: (e, t, s) => {
      "use strict";
      s.d(t, { SearchEmpty: () => S });
      var a = s(54486), r = s(50420), i = s(61910), o = s(43426), c = s(31500), l = s(5956), n = s(56231), d = s(97800), m = s(80585), u = s(54797), h = s.n(u);
      let _ = (e2) => {
        let { forwardRef: t2, className: s2, searchCorrectedText: i2 } = e2, { formatMessage: u2 } = (0, o.A)();
        return (0, a.jsxs)(n.N, {
          className: (0, r.$)(h().root, s2),
          containerClassName: h().container,
          ref: t2,
          children: [
            (0, a.jsxs)("div", {
              className: h().content,
              ...(0, c.Am)(c.e8.search.SEARCH_EMPTY_CONTAINER),
              children: [
                i2 && (0, a.jsx)("div", { className: h().correctedTextBlock, children: i2 }),
                (0, a.jsx)(l.Icon, {
                  className: h().icon,
                  variant: "search",
                  size: "xxl",
                  ...(0, c.Am)(c.e8.search.SEARCH_EMPTY_ICON)
                }),
                (0, a.jsx)(d.Heading, {
                  className: h().title,
                  size: "s",
                  weight: "bold",
                  variant: "h3",
                  ...(0, c.Am)(c.e8.search.SEARCH_EMPTY_HEADER),
                  children: u2({ id: "search-results.not-found-title" })
                }),
                (0, a.jsx)(d.Caption, {
                  className: h().subtitle,
                  variant: "div",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  ...(0, c.Am)(c.e8.search.SEARCH_EMPTY_DESCRIPTION),
                  children: u2({ id: "search-results.not-found-description" })
                })
              ]
            }),
            (0, a.jsx)(m.A, { children: (0, a.jsx)(m.wi, { className: h().footer }) })
          ]
        });
      }, S = (0, i.forwardRef)((e2, t2) => (0, a.jsx)(_, { forwardRef: t2, ...e2 }));
    },
    86482: (e) => {
      e.exports = {
        root: "SearchHistoryBlockDesktop_root__jKICZ",
        controls: "SearchHistoryBlockDesktop_controls__5JPBt",
        header: "SearchHistoryBlockDesktop_header__zOALK",
        clearButton: "SearchHistoryBlockDesktop_clearButton__kN4Nk",
        content: "SearchHistoryBlockDesktop_content__doQsC"
      };
    },
    87033: (e) => {
      e.exports = {
        root: "SearchColumnShimmer_root__PDf3Y",
        infoContainer: "SearchColumnShimmer_infoContainer__cQ8_H",
        textContainer: "SearchColumnShimmer_textContainer__IekgL",
        title: "SearchColumnShimmer_title__IorPg",
        description: "SearchColumnShimmer_description__nNupy",
        cover: "SearchColumnShimmer_cover__58jV8",
        action: "SearchColumnShimmer_action__JbJGl"
      };
    },
    89016: (e) => {
      e.exports = {
        root: "SearchBestResultsVibeBlock_root__KmJ3e",
        important: "SearchBestResultsVibeBlock_important__Zez1s",
        coverClassName: "SearchBestResultsVibeBlock_coverClassName__jv0_I"
      };
    },
    89961: (e) => {
      e.exports = {
        root: "SearchCorrectedText_root__ZM2f2",
        link: "SearchCorrectedText_link__eORMG",
        text: "SearchCorrectedText_text__HKgvL"
      };
    },
    90060: (e) => {
      e.exports = { root: "SearchBestResultsPlaylistBlock_root__HLU50" };
    },
    90777: (e, t, s) => {
      "use strict";
      s.d(t, { SearchNotFoundPage: () => l });
      var a = s(54486), r = s(28303), i = s(61910), o = s(42421), c = s(74125);
      let l = (0, r.PA)(() => {
        let { user: e2, search: t2 } = (0, c.Pjs)();
        return (0, i.useEffect)(
          () => () => {
            e2.isAuthorized && t2.landing.reset();
          },
          [e2.isAuthorized, t2.landing]
        ), (0, a.jsx)(o.M, {});
      });
    },
    96125: (e, t, s) => {
      "use strict";
      s.d(t, { useClearHistory: () => m });
      var a = s(54486), r = s(97396), i = s(61910), o = s(43426), c = s(47713), l = s(8817), n = s(74125), d = s(80585);
      let m = (e2) => {
        let { user: t2, search: s2 } = (0, n.Pjs)(), { formatMessage: m2 } = (0, o.A)(), { notify: u } = (0, n.lkh)(), h = (0, r.useRouter)();
        return (0, i.useEffect)(() => {
          s2.isEmptyHistory && h.push(n.Zyd.search.href);
        }, [s2.isEmptyHistory, h]), (0, l.c)(() => {
          try {
            t2.account.data.uid && s2.clearHistory({ userId: t2.account.data.uid }), u((0, a.jsx)(d.$W, { message: (0, a.jsx)(c.A, { id: "search.cleared-history" }) }), {
              containerId: n.uQT.INFO
            }), e2 && e2(), h.push(n.Zyd.search.href);
          } catch (e3) {
            u((0, a.jsx)(d.hT, { error: m2({ id: "error-messages.error-during-action" }) }), {
              containerId: n.uQT.ERROR
            });
          }
        });
      };
    },
    96194: (e, t, s) => {
      "use strict";
      s.d(t, { SearchEntitiesGrid: () => R });
      var a = s(54486), r = s(50420), i = s(61910), o = s(43350), c = s(15209), l = s(76421), n = s(84213), d = s(56231), m = s(94376), u = s(55616), h = s(65779), _ = s(83909), S = s(76866), x = s(74125), p = s(80585), C = s(34291), j = s(15099), A = s(36516), P = s(28303), b = s(9348), k = s(77217), y = s(98701), v = s.n(y);
      let T = (0, P.PA)((e2) => {
        let { concert: t2 } = e2, s2 = (0, i.useRef)(String((0, b.A)()));
        return (0, a.jsx)(k.VN, {
          artistId: null,
          viewUuid: s2.current,
          concert: t2,
          radius: "s",
          className: v().root,
          meta: (0, a.jsx)(k.wP, {}),
          shouldSendAnalyticsOnHide: true,
          shouldShowMask: true
        });
      });
      var E = s(14385), I = s.n(E);
      let g = (e2) => {
        let {
          forwardRef: t2,
          className: s2,
          results: P2,
          filter: b2,
          sendSearchFeedback: k2,
          searchCorrectedText: y2,
          children: v2,
          isShimmerVisible: E2,
          isShimmerActive: g2,
          isWideResults: R2,
          ...N
        } = e2, [B, f] = (0, i.useState)(0), L = (0, i.useMemo)(() => {
          if (E2)
            return b2 === l.n.WAVE ? Array.from({ length: 36 }, (e4, t3) => (0, a.jsx)(A.V, {}, t3)) : b2 === l.n.CONCERT ? Array.from(
              { length: 36 },
              (e4, t3) => (0, a.jsx)(p.WO, { isShimmerActive: g2, className: I().concertShimmer }, t3)
            ) : (0, a.jsx)(p.eI, {
              isActive: g2,
              itemClassName: I().block,
              round: b2 === l.n.ARTIST,
              centered: b2 === l.n.ARTIST,
              count: 36,
              shimmerClassName: b2 === l.n.CLIP && I().video
            });
          let e3 = ((e4, t3) => t3 === C.$.BOOK ? e4.filter((e5) => e5.type === l.n.PODCAST && e5.data.type === j._.AUDIOBOOK) : e4.filter((e5) => e5.type === t3))(P2, b2);
          return f(e3.length), e3.map((t3, s3) => {
            switch (t3.type) {
              case l.n.ALBUM:
                return (0, a.jsx)(
                  x.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: k2,
                      id: t3.data.id,
                      type: n.o.ALBUM,
                      blockPosition: 0,
                      position: s3
                    },
                    children: (0, a.jsx)(m.aX, { album: t3.data }, t3.data.id)
                  },
                  t3.data.id
                );
              case l.n.PLAYLIST:
                return (0, a.jsx)(
                  x.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: k2,
                      id: t3.data.id,
                      type: n.o.PLAYLIST,
                      blockPosition: 0,
                      position: s3
                    },
                    children: (0, a.jsx)(_.B6, { playlist: t3.data }, t3.data.key)
                  },
                  t3.data.id
                );
              case l.n.ARTIST:
                return (0, a.jsx)(
                  x.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: k2,
                      id: t3.data.id,
                      type: n.o.ARTIST,
                      blockPosition: 0,
                      position: s3
                    },
                    children: (0, a.jsx)(u.ao, { artist: t3.data }, t3.data.id)
                  },
                  t3.data.id
                );
              case l.n.PODCAST:
                return (0, a.jsx)(
                  x.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: k2,
                      id: t3.data.id,
                      type: n.o.PODCAST,
                      blockPosition: 0,
                      position: s3
                    },
                    children: (0, a.jsx)(
                      m.aX,
                      { album: t3.data, withLikesCount: true, withAddition: false },
                      t3.data.id
                    )
                  },
                  t3.data.id
                );
              case l.n.CLIP:
                return (0, a.jsx)(
                  x.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: k2,
                      id: t3.data.clipId,
                      type: n.o.CLIP,
                      blockPosition: 0,
                      position: s3
                    },
                    children: (0, a.jsx)(h.FC, { clip: t3.data }, t3.data.clipId)
                  },
                  t3.data.clipId
                );
              case l.n.WAVE:
                return (0, a.jsx)(
                  x.NYB.Provider,
                  {
                    value: {
                      sendSearchFeedback: k2,
                      id: t3.data.stationId,
                      type: n.o.WAVE,
                      blockPosition: 0,
                      position: s3
                    },
                    children: (0, a.jsx)(
                      S.H2,
                      {
                        agentVariant: S.hl.SMALL,
                        cover: t3.data.cover,
                        description: t3.data.description,
                        vibe: t3.data
                      },
                      t3.data.stationId
                    )
                  },
                  t3.data.stationId
                );
              case l.n.CONCERT:
                return (0, a.jsx)(x.FoH, {
                  blockId: x.UfI.SEARCH,
                  blockType: o.LA.Concerts,
                  blockPosX: 1,
                  blockPosY: 1,
                  objectsCount: e3.length,
                  children: (0, a.jsx)(
                    x.Bki,
                    {
                      objectType: o.ky.Concert,
                      objectId: String(t3.data.id),
                      objectPosX: s3 + 1,
                      objectPosY: 1,
                      objectsCount: e3.length,
                      children: (0, a.jsx)(T, { concert: t3.data })
                    },
                    t3.data.id
                  )
                });
              default:
                return null;
            }
          });
        }, [E2, P2, b2, g2, k2]);
        return (0, a.jsxs)(d.N, {
          className: (0, r.$)(I().root, s2),
          containerClassName: I().container,
          ref: t2,
          ...(0, c.getDataAttrFromProps)(N),
          children: [
            (0, a.jsxs)("div", {
              children: [
                y2 && (0, a.jsx)("div", { className: I().correctedTextBlock, children: y2 }),
                (0, a.jsx)("div", {
                  className: (0, r.$)(I().items, {
                    [I().video]: b2 === l.n.CLIP,
                    [I().items_withChildren]: B > 0 && !!v2,
                    [I().items_wideResults]: R2,
                    [I().items_concerts]: b2 === l.n.CONCERT
                  }),
                  children: L
                }),
                v2
              ]
            }),
            (0, a.jsx)(p.A, { children: (0, a.jsx)(p.wi, { className: I().footer }) })
          ]
        });
      }, R = (0, i.forwardRef)((e2, t2) => (0, a.jsx)(g, { forwardRef: t2, ...e2 }));
    },
    98006: (e, t, s) => {
      "use strict";
      s.d(t, { SearchTrackList: () => A });
      var a = s(54486), r = s(50420), i = s(61910), o = s(31500), c = s(63585), l = s(77710), n = s(84213), d = s(8817), m = s(56231), u = s(21365), h = s(74125), _ = s(80585), S = s(76421), x = s(61433), p = s.n(x);
      let C = (e2) => {
        let { isShimmerActive: t2 } = e2;
        return Array.from(
          { length: 36 },
          (e3, s2) => (0, a.jsx)(_.DS, { isActive: t2, className: p().shimmer, variant: h.Xjt.PLAYLIST }, s2)
        );
      }, j = (e2) => {
        let {
          forwardRef: t2,
          className: s2,
          results: x2,
          sendSearchFeedback: j2,
          searchCorrectedText: A2,
          isShimmerVisible: P,
          isShimmerActive: b
        } = e2, { from: k } = (0, h.fyy)(), y = (0, d.c)((e3) => ({
          contextData: { type: c.K.Various, meta: { id: e3.entityId }, from: k, overrideContextType: l.b.Search },
          queueParams: { index: 0, entityId: e3.id },
          loadContextMeta: true
        })), v = (0, i.useMemo)(
          () => P ? (0, a.jsx)(C, { isShimmerActive: b }) : x2.filter((e3) => e3.type === S.n.TRACK || e3.type === S.n.UGC_TRACK).map(
            (e3, t3) => (0, a.jsx)(
              h.NYB.Provider,
              {
                value: {
                  sendSearchFeedback: j2,
                  id: e3.data.entityId,
                  type: n.o.TRACK,
                  blockPosition: 0,
                  position: t3
                },
                children: (0, a.jsx)(u.Kt, { track: e3.data, playContextParams: y(e3.data) })
              },
              e3.data.id
            )
          ),
          [y, b, P, x2, j2]
        );
        return (0, a.jsxs)(m.N, {
          className: (0, r.$)(p().root, s2),
          containerClassName: p().container,
          ref: t2,
          ...(0, o.Am)(o.Xk.search.SEARCH_PAGE_RESULTS_TRACK),
          children: [
            (0, a.jsxs)("div", {
              className: p().content,
              children: [
                A2 && (0, a.jsx)("div", { className: p().correctedTextBlock, children: A2 }),
                (0, a.jsx)("div", { className: p().items, children: v })
              ]
            }),
            (0, a.jsx)(_.A, { children: (0, a.jsx)(_.wi, { className: p().footer }) })
          ]
        });
      }, A = (0, i.forwardRef)((e2, t2) => (0, a.jsx)(j, { forwardRef: t2, ...e2 }));
    },
    98045: (e, t, s) => {
      "use strict";
      s.d(t, { SearchCorrectedText: () => m });
      var a = s(54486), r = s(61910), i = s(47713), o = s(31500), c = s(77881), l = s(97800), n = s(89961), d = s.n(n);
      let m = (e2) => {
        let { onCorrectText: t2, searchCorrectedText: s2 } = e2, n2 = (0, r.useMemo)(
          () => ({
            text: (0, a.jsx)(c.$, {
              "aria-label": s2,
              variant: "text",
              radius: "xs",
              onClick: t2,
              ...(0, o.Am)(o.e8.search.SEARCH_CORRECTED_TEXT_BUTTON),
              children: (0, a.jsx)(l.Caption, {
                className: d().link,
                variant: "span",
                size: "m",
                type: "text",
                ...(0, o.Am)(o.e8.search.SEARCH_CORRECTED_TEXT_BUTTON_TEXT),
                children: s2
              })
            })
          }),
          [s2, t2]
        );
        return (0, a.jsx)("div", {
          className: d().root,
          ...(0, o.Am)(o.e8.search.SEARCH_CORRECTED_TEXT),
          children: (0, a.jsx)(l.Caption, {
            className: d().text,
            variant: "span",
            size: "m",
            type: "text",
            ...(0, o.Am)(o.e8.search.SEARCH_CORRECTED_TEXT_TEXT),
            children: (0, a.jsx)(i.A, { id: "search.corrected-text", values: n2 })
          })
        });
      };
    },
    98701: (e) => {
      e.exports = { root: "SearchConcert_root__1DJPQ" };
    }
  }
]);
