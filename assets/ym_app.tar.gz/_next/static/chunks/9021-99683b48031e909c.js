"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [9021],
  {
    79021: (e, t, r) => {
      r.d(t, { D: () => u });
      var s, n = r(94377), a = r(61910), i = {
        5881: (e2, t2, r2) => {
          function s2() {
            for (var e3, t3, r3 = 0, s3 = ""; r3 < arguments.length; )
              (e3 = arguments[r3++]) && (t3 = (function e4(t4) {
                var r4, s4, n3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) n3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (r4 = 0; r4 < t4.length; r4++) t4[r4] && (s4 = e4(t4[r4])) && (n3 && (n3 += " "), n3 += s4);
                  else for (r4 in t4) t4[r4] && (n3 && (n3 += " "), n3 += r4);
                return n3;
              })(e3)) && (s3 && (s3 += " "), s3 += t3);
            return s3;
          }
          r2.r(t2), r2.d(t2, { clsx: () => s2, default: () => n2 });
          let n2 = s2;
        },
        1920: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => s2 });
          let s2 = {
            contentContainer: "JjlbHZ4FaP9EAcR_1DxF",
            contentContainer_block: "iOlzvyUREgDkthkrx7Sf",
            flexIcon: "WsKeF73pWotx9W1tWdYY",
            root: "cpeagBA1_PblpJn8Xgtv",
            root_withoutBorder: "qU2apWBO1yyEK0lZ3lPO",
            root_radius_xs: "MmZbSs387gu2qrJ1lDWd",
            root_radius_s: "mlcrraysn7mW6xrBXSBF",
            root_radius_m: "dgV08FKVLZKFsucuiryn",
            root_radius_l: "S97_5dtzhpxo_amtfYRg",
            root_radius_xl: "nNBJnDHRlyLTniWosJhk",
            root_radius_xxxl: "zIMibMuH7wcqUoW7KH1B",
            root_radius_round: "uwk3hfWzB2VT7kE13SQk",
            root_size: "IlG7b1K0AD7E7AMx6F5p",
            root_size_default: "C_QGmfTz6UFX93vfPt6Z",
            root_size_xxxs: "eQt33MLDiQ6DRSuLaYEp",
            root_size_xxs: "oR11LfCBVqMbUJiAgknd",
            root_size_xs: "j1jXIVckFgZECecFzZMe",
            root_size_s: "WtFdWDF44egSVM_YiMUX",
            root_size_m: "Y2uqxoU7xa_AZ8FUCVOW",
            root_size_l: "SGYcNjvjmMsXeEVGUV2Z",
            root_icon_left: "kc5CjvU5hT9KEj0iTt3C",
            root_icon_right: "et24Jf7pT_X9Fvc7TznR",
            root_primary: "fXlFz1qMkliFUWOkHo8T",
            root_primary_default: "_eTRQi5ADZCUvUKMZqJU",
            ripple: "spMT3NcRD9Yb0ntNaNct",
            root_primary_outline: "fCUSh2B0Ye9kEvceE8zc",
            root_primary_text: "qlPp6CSQQEMVZPqtqLiQ",
            root_primary_withHover: "KZF6_4K1p_Y_GMIAxaAn",
            root_primary_withHover_default: "rWukOKAJh5Ga7JuIp62L",
            root_primary_withHover_outline: "fdwWCJKgUqml5wNqrRcN",
            root_primary_withHover_text: "IgYbZLnYjW0nMahgpkus",
            root_secondary: "_T4p_w41oaq6L4sztSdw",
            root_secondary_default: "iJVAJMgccD4vj4E4o068",
            root_secondary_outline: "pnM3iSP9keZOELI2oohr",
            root_secondary_text: "UDMYhpDjiAFT3xUx268O",
            root_secondary_withHover: "qUbrkhZIOVrvM0roV1QF",
            root_secondary_withHover_default: "nHWc2sto1C6Gm0Dpw_l0",
            root_secondary_withHover_outline: "i5WuBm5mfG0mflk_1jH_",
            root_secondary_withHover_text: "HbaqudSqu7Q3mv3zMPGr",
            root_plus: "ixLRsIJ2FvXO2k04n_QY",
            root_plus_default: "yRHwHzEGfDgRXGzYJqw2",
            root_plus_outline: "e777irPFmyQFFrURLF_U",
            root_plus_text: "vRqDhvmt3gt8TFp45_Zw",
            root_plus_withHover: "TZif6q3I2RwBEYXwK_iA",
            root_plus_withHover_default: "k3DhvmzpnM_Fb9oFdE4q",
            root_plus_withHover_outline: "RiDWYwGIxqbrUPR699DM",
            root_plus_withHover_text: "hC_mMCzWjkTn2j9xZzGc",
            root_accent: "jqD2jMT6n7F0WKyqwMsn",
            root_accent_default: "bDp0r9MtoYECZ8ObMoCh",
            root_accent_outline: "rXNyGp8NBAw2MUjACZNj",
            root_accent_text: "hmV4ERaXWAJc4uPLZL30",
            root_accent_withHover: "uKuxXu1N4TP5cWaEK5Ke",
            root_accent_withHover_default: "t_hequUaUgAMhFuxizLb",
            root_accent_withHover_outline: "Oy9sPFTxNTo1_E29U4aF",
            root_accent_withHover_text: "LcKRSd3DLoh7k60Oqox8",
            root_withActiveSpinner: "nAGvO87rLs15SJgft6Hh",
            block: "BbCxxIjBGupN28bq2lSP",
            icon: "J9wTKytjOWG73QMoN5WP",
            icon_position_left: "elJfazUBui03YWZgHCbW",
            icon_position_right: "RBoEbyJKP5rEtLsXM1ji",
            icon_withButtonSize: "cE17_kCWJgx8kzQEkeVr",
            spinnerContainer: "STbBDGqYjUEcLuNvhu9w"
          };
        },
        2964: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => s2 });
          let s2 = {
            root_size_xxxs: "Rkdd2vKC_3xa1eUdRdHP",
            root_size_xxs: "l3tE1hAMmBj2aoPPwU08",
            root_size_xs: "UwnL5AJBMMAp6NwMDdZk",
            root_size_s: "DzJFnuf7XgdkFh28JAsM",
            root_size_m: "o_v2ds2BaqtzAsRuCVjw",
            root_size_l: "YjRa1ZjM_lXFlrfS7jcu",
            root_size_xl: "Seq0GowcqQmiA9LdLP_g",
            root_size_xxl: "mfy69_BvBIamD0e22rCQ",
            root_size_xxxl: "JY1OniQewgW9iHgfllZS"
          };
        },
        9160: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => s2 });
          let s2 = {
            root: "kAYDswAvA1AJoAzRV4rY",
            root_disabled: "vkAwJpSGxne16yE82eHh",
            root_size_xxxs: "i690pcQGptnPbYcI77fh",
            root_size_xxs: "K2cOFeQVOaRzGAOv6gWL",
            input: "GRggPQ1rZgvcyCxPPgvw",
            root_variant_secondary: "o9HhnHzukPG4e94AXBNT",
            textShadowing: "ceR_9q_roxCLdCPR87Qw",
            actions: "XsBFSZAjR3ZRN8oqetex"
          };
        },
        8532: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { default: () => s2 });
          let s2 = {
            searchIcon: "LoJPNHBhYAkQh7hBQYIP",
            searchIcon_disabled: "U1fHaoo5ZnRY0W6P1cXz",
            searchContainer: "YBgyycmmzZchX_EgLcrA",
            searchInput: "QYgjNkDJ7XdqE28ipieh",
            reset: "sGZaYJkCxVIV1wkix81s",
            reset_show: "A0wDRuyRnXuI3ja3zx0E"
          };
        },
        4490: (e2, t2, r2) => {
          r2.r(t2), r2.d(t2, { DOWN: () => l2, LEFT: () => n2, RIGHT: () => a2, UP: () => i2, useSwipeable: () => d });
          var s2 = r2(810);
          let n2 = "Left", a2 = "Right", i2 = "Up", l2 = "Down", o2 = {
            delta: 10,
            preventScrollOnSwipe: false,
            rotationAngle: 0,
            trackMouse: false,
            trackTouch: true,
            swipeDuration: 1 / 0,
            touchEventOptions: { passive: true }
          }, c2 = { first: true, initial: [0, 0], start: 0, swiping: false, xy: [0, 0] }, u2 = "mousemove", f = "mouseup";
          function x(e3, t3) {
            if (0 === t3) return e3;
            let r3 = Math.PI / 180 * t3;
            return [e3[0] * Math.cos(r3) + e3[1] * Math.sin(r3), e3[1] * Math.cos(r3) - e3[0] * Math.sin(r3)];
          }
          function d(e3) {
            var t3, r3, d2;
            let _, { trackMouse: p } = e3, v = s2.useRef(Object.assign({}, c2)), g = s2.useRef(Object.assign({}, o2)), m = s2.useRef(Object.assign({}, g.current));
            for (_ in m.current = Object.assign({}, g.current), g.current = Object.assign(Object.assign({}, o2), e3), o2)
              void 0 === g.current[_] && (g.current[_] = o2[_]);
            let [k, E] = s2.useMemo(
              () => (function(e4, t4) {
                let r4 = (t5) => {
                  let r5 = "touches" in t5;
                  r5 && t5.touches.length > 1 || e4((e5, n3) => {
                    n3.trackMouse && !r5 && (document.addEventListener(u2, s3), document.addEventListener(f, _2));
                    let { clientX: a3, clientY: i3 } = r5 ? t5.touches[0] : t5, l3 = x([a3, i3], n3.rotationAngle);
                    return n3.onTouchStartOrOnMouseDown && n3.onTouchStartOrOnMouseDown({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), {
                      initial: l3.slice(),
                      xy: l3,
                      start: t5.timeStamp || 0
                    });
                  });
                }, s3 = (t5) => {
                  e4((e5, r5) => {
                    var s4, c3, u3, f2;
                    let d4 = "touches" in t5;
                    if (d4 && t5.touches.length > 1) return e5;
                    if (t5.timeStamp - e5.start > r5.swipeDuration)
                      return e5.swiping ? Object.assign(Object.assign({}, e5), { swiping: false }) : e5;
                    let { clientX: _3, clientY: p3 } = d4 ? t5.touches[0] : t5, [v3, g2] = x([_3, p3], r5.rotationAngle), m2 = v3 - e5.xy[0], k2 = g2 - e5.xy[1], E2 = Math.abs(m2), y = Math.abs(k2), b = (t5.timeStamp || 0) - e5.start, w = Math.sqrt(E2 * E2 + y * y) / (b || 1), O = [m2 / (b || 1), k2 / (b || 1)], R = (s4 = E2, c3 = y, u3 = m2, f2 = k2, s4 > c3 ? u3 > 0 ? a2 : n2 : f2 > 0 ? l2 : i2), j = "number" == typeof r5.delta ? r5.delta : r5.delta[R.toLowerCase()] || o2.delta;
                    if (E2 < j && y < j && !e5.swiping) return e5;
                    let h = {
                      absX: E2,
                      absY: y,
                      deltaX: m2,
                      deltaY: k2,
                      dir: R,
                      event: t5,
                      first: e5.first,
                      initial: e5.initial,
                      velocity: w,
                      vxvy: O
                    };
                    h.first && r5.onSwipeStart && r5.onSwipeStart(h), r5.onSwiping && r5.onSwiping(h);
                    let H = false;
                    return (r5.onSwiping || r5.onSwiped || r5["onSwiped".concat(R)]) && (H = true), H && r5.preventScrollOnSwipe && r5.trackTouch && t5.cancelable && t5.preventDefault(), Object.assign(Object.assign({}, e5), { first: false, eventData: h, swiping: true });
                  });
                }, d3 = (t5) => {
                  e4((e5, r5) => {
                    let s4;
                    if (e5.swiping && e5.eventData) {
                      if (t5.timeStamp - e5.start < r5.swipeDuration) {
                        s4 = Object.assign(Object.assign({}, e5.eventData), { event: t5 }), r5.onSwiped && r5.onSwiped(s4);
                        let n3 = r5["onSwiped".concat(s4.dir)];
                        n3 && n3(s4);
                      }
                    } else r5.onTap && r5.onTap({ event: t5 });
                    return r5.onTouchEndOrOnMouseUp && r5.onTouchEndOrOnMouseUp({ event: t5 }), Object.assign(Object.assign(Object.assign({}, e5), c2), { eventData: s4 });
                  });
                }, _2 = (e5) => {
                  document.removeEventListener(u2, s3), document.removeEventListener(f, _2), d3(e5);
                }, p2 = (e5, t5) => {
                  let n3 = () => {
                  };
                  if (e5 && e5.addEventListener) {
                    let a3 = Object.assign(Object.assign({}, o2.touchEventOptions), t5.touchEventOptions), i3 = [
                      ["touchstart", r4, a3],
                      [
                        "touchmove",
                        s3,
                        Object.assign(Object.assign({}, a3), t5.preventScrollOnSwipe ? { passive: false } : {})
                      ],
                      ["touchend", d3, a3]
                    ];
                    i3.forEach((t6) => {
                      let [r5, s4, n4] = t6;
                      return e5.addEventListener(r5, s4, n4);
                    }), n3 = () => i3.forEach((t6) => {
                      let [r5, s4] = t6;
                      return e5.removeEventListener(r5, s4);
                    });
                  }
                  return n3;
                }, v2 = {
                  ref: (t5) => {
                    null !== t5 && e4((e5, r5) => {
                      if (e5.el === t5) return e5;
                      let s4 = {};
                      return e5.el && e5.el !== t5 && e5.cleanUpTouch && (e5.cleanUpTouch(), s4.cleanUpTouch = void 0), r5.trackTouch && t5 && (s4.cleanUpTouch = p2(t5, r5)), Object.assign(Object.assign(Object.assign({}, e5), { el: t5 }), s4);
                    });
                  }
                };
                return t4.trackMouse && (v2.onMouseDown = r4), [v2, p2];
              })((e4) => v.current = e4(v.current, g.current), { trackMouse: p }),
              [p]
            );
            return t3 = v.current, r3 = g.current, d2 = m.current, v.current = r3.trackTouch && t3.el ? t3.cleanUpTouch ? r3.preventScrollOnSwipe !== d2.preventScrollOnSwipe || r3.touchEventOptions.passive !== d2.touchEventOptions.passive ? (t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: E(t3.el, r3) })) : t3 : Object.assign(Object.assign({}, t3), { cleanUpTouch: E(t3.el, r3) }) : (t3.cleanUpTouch && t3.cleanUpTouch(), Object.assign(Object.assign({}, t3), { cleanUpTouch: void 0 })), k;
          }
        },
        9097: (e2, t2) => {
          var r2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function s2(e3, t3, s3) {
            var n2 = null;
            if (void 0 !== s3 && (n2 = "" + s3), void 0 !== t3.key && (n2 = "" + t3.key), "key" in t3)
              for (var a2 in s3 = {}, t3) "key" !== a2 && (s3[a2] = t3[a2]);
            else s3 = t3;
            return { $$typeof: r2, type: e3, key: n2, ref: void 0 !== (t3 = s3.ref) ? t3 : null, props: s3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = s2, t2.jsxs = s2;
        },
        4377: (e2, t2, r2) => {
          e2.exports = r2(9097);
        },
        8442: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "addToPlaylist_xxs", xlinkHref: "/icons/sprite.svg#addToPlaylist_xxs" })
            ]);
          });
        },
        6644: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "add_l", xlinkHref: "/icons/sprite.svg#add_l" })
            ]);
          });
        },
        7319: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "add_xxs", xlinkHref: "/icons/sprite.svg#add_xxs" })
            ]);
          });
        },
        9351: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "adult_s", xlinkHref: "/icons/sprite.svg#adult_s" })
            ]);
          });
        },
        7171: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "adult_xs", xlinkHref: "/icons/sprite.svg#adult_xs" })
            ]);
          });
        },
        2586: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "adult_xxs", xlinkHref: "/icons/sprite.svg#adult_xxs" })
            ]);
          });
        },
        4656: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "adult_xxxs", xlinkHref: "/icons/sprite.svg#adult_xxxs" })
            ]);
          });
        },
        996: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "album_l", xlinkHref: "/icons/sprite.svg#album_l" })
            ]);
          });
        },
        2092: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "album_s", xlinkHref: "/icons/sprite.svg#album_s" })
            ]);
          });
        },
        6304: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "album_xl", xlinkHref: "/icons/sprite.svg#album_xl" })
            ]);
          });
        },
        9030: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "album_xs", xlinkHref: "/icons/sprite.svg#album_xs" })
            ]);
          });
        },
        5822: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "album_xxs", xlinkHref: "/icons/sprite.svg#album_xxs" })
            ]);
          });
        },
        9422: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "arrowDown_xs", xlinkHref: "/icons/sprite.svg#arrowDown_xs" })
            ]);
          });
        },
        5272: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "arrowDown_xxs", xlinkHref: "/icons/sprite.svg#arrowDown_xxs" })
            ]);
          });
        },
        1491: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "arrowLeft_xs", xlinkHref: "/icons/sprite.svg#arrowLeft_xs" })
            ]);
          });
        },
        4860: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "arrowLeft_xxs", xlinkHref: "/icons/sprite.svg#arrowLeft_xxs" })
            ]);
          });
        },
        2337: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "arrowRight_xs", xlinkHref: "/icons/sprite.svg#arrowRight_xs" })
            ]);
          });
        },
        8711: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "arrowRight_xxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxs" })
            ]);
          });
        },
        8170: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "arrowRight_xxxs", xlinkHref: "/icons/sprite.svg#arrowRight_xxxs" })
            ]);
          });
        },
        8109: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "artist_xxs", xlinkHref: "/icons/sprite.svg#artist_xxs" })
            ]);
          });
        },
        7341: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "attention_xxl", xlinkHref: "/icons/sprite.svg#attention_xxl" })
            ]);
          });
        },
        2435: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "attention_xxxl", xlinkHref: "/icons/sprite.svg#attention_xxxl" })
            ]);
          });
        },
        3918: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "bandlink", xlinkHref: "/icons/sprite.svg#bandlink" })
            ]);
          });
        },
        2571: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "booksLogo", xlinkHref: "/icons/sprite.svg#booksLogo" })
            ]);
          });
        },
        4904: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "bucket_xxs", xlinkHref: "/icons/sprite.svg#bucket_xxs" })
            ]);
          });
        },
        9202: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "cast_xs", xlinkHref: "/icons/sprite.svg#cast_xs" })
            ]);
          });
        },
        130: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "chain_xs", xlinkHref: "/icons/sprite.svg#chain_xs" })
            ]);
          });
        },
        5971: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "chain_xxs", xlinkHref: "/icons/sprite.svg#chain_xxs" })
            ]);
          });
        },
        3331: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "chartDown_xxs", xlinkHref: "/icons/sprite.svg#chartDown_xxs" })
            ]);
          });
        },
        9783: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "chartNew_xxs", xlinkHref: "/icons/sprite.svg#chartNew_xxs" })
            ]);
          });
        },
        8184: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "chartSame_xxs", xlinkHref: "/icons/sprite.svg#chartSame_xxs" })
            ]);
          });
        },
        4926: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "chartUp_xxs", xlinkHref: "/icons/sprite.svg#chartUp_xxs" })
            ]);
          });
        },
        9505: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "check_xxl", xlinkHref: "/icons/sprite.svg#check_xxl" })
            ]);
          });
        },
        3176: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "check_xxs", xlinkHref: "/icons/sprite.svg#check_xxs" })
            ]);
          });
        },
        5565: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "check_xxxs", xlinkHref: "/icons/sprite.svg#check_xxxs" })
            ]);
          });
        },
        9040: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "clip_xl", xlinkHref: "/icons/sprite.svg#clip_xl" })
            ]);
          });
        },
        4789: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "clip_xxs", xlinkHref: "/icons/sprite.svg#clip_xxs" })
            ]);
          });
        },
        7923: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "close_xs", xlinkHref: "/icons/sprite.svg#close_xs" })
            ]);
          });
        },
        8151: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "close_xxs", xlinkHref: "/icons/sprite.svg#close_xxs" })
            ]);
          });
        },
        8127: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "close_xxxs", xlinkHref: "/icons/sprite.svg#close_xxxs" })
            ]);
          });
        },
        8690: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "code_xxs", xlinkHref: "/icons/sprite.svg#code_xxs" })
            ]);
          });
        },
        3076: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "collections_m", xlinkHref: "/icons/sprite.svg#collections_m" })
            ]);
          });
        },
        2495: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "collections_selected_m",
                xlinkHref: "/icons/sprite.svg#collections_selected_m"
              })
            ]);
          });
        },
        1524: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "crown_xxs", xlinkHref: "/icons/sprite.svg#crown_xxs" })
            ]);
          });
        },
        1162: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "dislike_s", xlinkHref: "/icons/sprite.svg#dislike_s" })
            ]);
          });
        },
        3654: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "dislike_xs", xlinkHref: "/icons/sprite.svg#dislike_xs" })
            ]);
          });
        },
        2361: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "dislike_xxs", xlinkHref: "/icons/sprite.svg#dislike_xxs" })
            ]);
          });
        },
        6837: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "disliked_s", xlinkHref: "/icons/sprite.svg#disliked_s" })
            ]);
          });
        },
        6507: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "disliked_xs", xlinkHref: "/icons/sprite.svg#disliked_xs" })
            ]);
          });
        },
        3972: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "disliked_xxs", xlinkHref: "/icons/sprite.svg#disliked_xxs" })
            ]);
          });
        },
        8993: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "donation_xxxs", xlinkHref: "/icons/sprite.svg#donation_xxxs" })
            ]);
          });
        },
        7031: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "download_l", xlinkHref: "/icons/sprite.svg#download_l" })
            ]);
          });
        },
        9330: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "download_xxs", xlinkHref: "/icons/sprite.svg#download_xxs" })
            ]);
          });
        },
        7346: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "downloaded_xxs", xlinkHref: "/icons/sprite.svg#downloaded_xxs" })
            ]);
          });
        },
        2604: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "dragDots_xxs", xlinkHref: "/icons/sprite.svg#dragDots_xxs" })
            ]);
          });
        },
        6894: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "edit_xxs", xlinkHref: "/icons/sprite.svg#edit_xxs" })
            ]);
          });
        },
        2024: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "exclamation_s", xlinkHref: "/icons/sprite.svg#exclamation_s" })
            ]);
          });
        },
        3193: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "exclamation_xs", xlinkHref: "/icons/sprite.svg#exclamation_xs" })
            ]);
          });
        },
        6391: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "exclamation_xxs", xlinkHref: "/icons/sprite.svg#exclamation_xxs" })
            ]);
          });
        },
        2933: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "exclamation_xxxs", xlinkHref: "/icons/sprite.svg#exclamation_xxxs" })
            ]);
          });
        },
        776: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "explicit_s", xlinkHref: "/icons/sprite.svg#explicit_s" })
            ]);
          });
        },
        30: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "explicit_xs", xlinkHref: "/icons/sprite.svg#explicit_xs" })
            ]);
          });
        },
        9369: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "explicit_xxs", xlinkHref: "/icons/sprite.svg#explicit_xxs" })
            ]);
          });
        },
        1334: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "explicit_xxxs", xlinkHref: "/icons/sprite.svg#explicit_xxxs" })
            ]);
          });
        },
        226: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "eye_crossed_xxs", xlinkHref: "/icons/sprite.svg#eye_crossed_xxs" })
            ]);
          });
        },
        7802: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "filter_xs", xlinkHref: "/icons/sprite.svg#filter_xs" })
            ]);
          });
        },
        8130: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "filter_xxs", xlinkHref: "/icons/sprite.svg#filter_xxs" })
            ]);
          });
        },
        3738: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "fullscreen_xs", xlinkHref: "/icons/sprite.svg#fullscreen_xs" })
            ]);
          });
        },
        2161: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "googlePlay", xlinkHref: "/icons/sprite.svg#googlePlay" })
            ]);
          });
        },
        9509: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "history_m", xlinkHref: "/icons/sprite.svg#history_m" })
            ]);
          });
        },
        8987: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "home_m", xlinkHref: "/icons/sprite.svg#home_m" })
            ]);
          });
        },
        190: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "home_selected_m", xlinkHref: "/icons/sprite.svg#home_selected_m" })
            ]);
          });
        },
        5304: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "huaweiAppGallery", xlinkHref: "/icons/sprite.svg#huaweiAppGallery" })
            ]);
          });
        },
        5270: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "info_xxs", xlinkHref: "/icons/sprite.svg#info_xxs" })
            ]);
          });
        },
        843: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "kids_m", xlinkHref: "/icons/sprite.svg#kids_m" })
            ]);
          });
        },
        5122: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "kids_selected_m", xlinkHref: "/icons/sprite.svg#kids_selected_m" })
            ]);
          });
        },
        2646: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "kinopoiskEn", xlinkHref: "/icons/sprite.svg#kinopoiskEn" })
            ]);
          });
        },
        7500: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "kinopoiskRu", xlinkHref: "/icons/sprite.svg#kinopoiskRu" })
            ]);
          });
        },
        3560: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "lightning_xxs", xlinkHref: "/icons/sprite.svg#lightning_xxs" })
            ]);
          });
        },
        9838: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "likeVariant_xxs", xlinkHref: "/icons/sprite.svg#likeVariant_xxs" })
            ]);
          });
        },
        4793: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "like_l", xlinkHref: "/icons/sprite.svg#like_l" })
            ]);
          });
        },
        7405: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "like_m", xlinkHref: "/icons/sprite.svg#like_m" })
            ]);
          });
        },
        2340: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "like_xs", xlinkHref: "/icons/sprite.svg#like_xs" })
            ]);
          });
        },
        7513: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "like_xxs", xlinkHref: "/icons/sprite.svg#like_xxs" })
            ]);
          });
        },
        5720: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "likedVariant_s", xlinkHref: "/icons/sprite.svg#likedVariant_s" })
            ]);
          });
        },
        7399: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "likedVariant_xxs", xlinkHref: "/icons/sprite.svg#likedVariant_xxs" })
            ]);
          });
        },
        820: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "liked_m", xlinkHref: "/icons/sprite.svg#liked_m" })
            ]);
          });
        },
        2125: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "liked_xs", xlinkHref: "/icons/sprite.svg#liked_xs" })
            ]);
          });
        },
        9104: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "liked_xxs", xlinkHref: "/icons/sprite.svg#liked_xxs" })
            ]);
          });
        },
        5849: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "link_xxs", xlinkHref: "/icons/sprite.svg#link_xxs" })
            ]);
          });
        },
        1426: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "listen_xxxs", xlinkHref: "/icons/sprite.svg#listen_xxxs" })
            ]);
          });
        },
        4014: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "liteVersion_xs", xlinkHref: "/icons/sprite.svg#liteVersion_xs" })
            ]);
          });
        },
        5443: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "lock_m", xlinkHref: "/icons/sprite.svg#lock_m" })
            ]);
          });
        },
        896: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "lock_xs", xlinkHref: "/icons/sprite.svg#lock_xs" })
            ]);
          });
        },
        3613: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "lock_xxs", xlinkHref: "/icons/sprite.svg#lock_xxs" })
            ]);
          });
        },
        9372: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "lyrics_xxs", xlinkHref: "/icons/sprite.svg#lyrics_xxs" })
            ]);
          });
        },
        6104: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "macos", xlinkHref: "/icons/sprite.svg#macos" })
            ]);
          });
        },
        3709: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "macos_xxs", xlinkHref: "/icons/sprite.svg#macos_xxs" })
            ]);
          });
        },
        3685: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "menuArrow_xxs", xlinkHref: "/icons/sprite.svg#menuArrow_xxs" })
            ]);
          });
        },
        8782: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "more_m", xlinkHref: "/icons/sprite.svg#more_m" })
            ]);
          });
        },
        1829: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "more_xs", xlinkHref: "/icons/sprite.svg#more_xs" })
            ]);
          });
        },
        3302: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "more_xxs", xlinkHref: "/icons/sprite.svg#more_xxs" })
            ]);
          });
        },
        2502: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "musicLogo", xlinkHref: "/icons/sprite.svg#musicLogo" })
            ]);
          });
        },
        1754: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "musicLogoCenterEn", xlinkHref: "/icons/sprite.svg#musicLogoCenterEn" })
            ]);
          });
        },
        6615: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "musicLogoCenterRu", xlinkHref: "/icons/sprite.svg#musicLogoCenterRu" })
            ]);
          });
        },
        7942: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "musicLogoLeftEn", xlinkHref: "/icons/sprite.svg#musicLogoLeftEn" })
            ]);
          });
        },
        1498: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "musicLogoLeftRu", xlinkHref: "/icons/sprite.svg#musicLogoLeftRu" })
            ]);
          });
        },
        1893: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "navigationCollection_xs",
                xlinkHref: "/icons/sprite.svg#navigationCollection_xs"
              })
            ]);
          });
        },
        1563: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "navigationConcerts_xs",
                xlinkHref: "/icons/sprite.svg#navigationConcerts_xs"
              })
            ]);
          });
        },
        1578: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "navigationForYouAndTrends_xs",
                xlinkHref: "/icons/sprite.svg#navigationForYouAndTrends_xs"
              })
            ]);
          });
        },
        9348: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "navigationKids_xs", xlinkHref: "/icons/sprite.svg#navigationKids_xs" })
            ]);
          });
        },
        965: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "navigationMyVibe_xs",
                xlinkHref: "/icons/sprite.svg#navigationMyVibe_xs"
              })
            ]);
          });
        },
        3877: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "navigationNonMusic_xs",
                xlinkHref: "/icons/sprite.svg#navigationNonMusic_xs"
              })
            ]);
          });
        },
        9968: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "navigationPlus_xs", xlinkHref: "/icons/sprite.svg#navigationPlus_xs" })
            ]);
          });
        },
        3778: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "navigationSearch_xs",
                xlinkHref: "/icons/sprite.svg#navigationSearch_xs"
              })
            ]);
          });
        },
        1084: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "next_xs", xlinkHref: "/icons/sprite.svg#next_xs" })
            ]);
          });
        },
        4483: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "next_xxl", xlinkHref: "/icons/sprite.svg#next_xxl" })
            ]);
          });
        },
        811: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "next_xxs", xlinkHref: "/icons/sprite.svg#next_xxs" })
            ]);
          });
        },
        7252: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "non_music_m", xlinkHref: "/icons/sprite.svg#non_music_m" })
            ]);
          });
        },
        3013: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "non_music_selected_m",
                xlinkHref: "/icons/sprite.svg#non_music_selected_m"
              })
            ]);
          });
        },
        2774: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "note_s", xlinkHref: "/icons/sprite.svg#note_s" })
            ]);
          });
        },
        4298: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "note_xl", xlinkHref: "/icons/sprite.svg#note_xl" })
            ]);
          });
        },
        4254: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "note_xs", xlinkHref: "/icons/sprite.svg#note_xs" })
            ]);
          });
        },
        8499: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "offline_xxl", xlinkHref: "/icons/sprite.svg#offline_xxl" })
            ]);
          });
        },
        4997: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pauseVibe_s", xlinkHref: "/icons/sprite.svg#pauseVibe_s" })
            ]);
          });
        },
        7076: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pause_filled_l", xlinkHref: "/icons/sprite.svg#pause_filled_l" })
            ]);
          });
        },
        3792: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pause_filled_m", xlinkHref: "/icons/sprite.svg#pause_filled_m" })
            ]);
          });
        },
        5132: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pause_filled_xl", xlinkHref: "/icons/sprite.svg#pause_filled_xl" })
            ]);
          });
        },
        8131: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pause_filled_xs", xlinkHref: "/icons/sprite.svg#pause_filled_xs" })
            ]);
          });
        },
        705: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pause_filled_xxl", xlinkHref: "/icons/sprite.svg#pause_filled_xxl" })
            ]);
          });
        },
        5346: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pause_m", xlinkHref: "/icons/sprite.svg#pause_m" })
            ]);
          });
        },
        792: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pause_xs", xlinkHref: "/icons/sprite.svg#pause_xs" })
            ]);
          });
        },
        6122: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pause_xxs", xlinkHref: "/icons/sprite.svg#pause_xxs" })
            ]);
          });
        },
        5386: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pencil_xxs", xlinkHref: "/icons/sprite.svg#pencil_xxs" })
            ]);
          });
        },
        3146: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "picture_s", xlinkHref: "/icons/sprite.svg#picture_s" })
            ]);
          });
        },
        8868: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "picture_xl", xlinkHref: "/icons/sprite.svg#picture_xl" })
            ]);
          });
        },
        1125: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "picture_xs", xlinkHref: "/icons/sprite.svg#picture_xs" })
            ]);
          });
        },
        976: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pin_filled_xs", xlinkHref: "/icons/sprite.svg#pin_filled_xs" })
            ]);
          });
        },
        9434: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pin_filled_xxs", xlinkHref: "/icons/sprite.svg#pin_filled_xxs" })
            ]);
          });
        },
        9288: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pin_xs", xlinkHref: "/icons/sprite.svg#pin_xs" })
            ]);
          });
        },
        3201: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "pin_xxs", xlinkHref: "/icons/sprite.svg#pin_xxs" })
            ]);
          });
        },
        8112: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "playLast_xxs", xlinkHref: "/icons/sprite.svg#playLast_xxs" })
            ]);
          });
        },
        8044: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "playNext_xxs", xlinkHref: "/icons/sprite.svg#playNext_xxs" })
            ]);
          });
        },
        8303: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "playQueue_m", xlinkHref: "/icons/sprite.svg#playQueue_m" })
            ]);
          });
        },
        9863: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "playQueue_xs", xlinkHref: "/icons/sprite.svg#playQueue_xs" })
            ]);
          });
        },
        2084: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "playVibe_s", xlinkHref: "/icons/sprite.svg#playVibe_s" })
            ]);
          });
        },
        8582: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "play_filled_l", xlinkHref: "/icons/sprite.svg#play_filled_l" })
            ]);
          });
        },
        4777: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "play_filled_m", xlinkHref: "/icons/sprite.svg#play_filled_m" })
            ]);
          });
        },
        8779: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "play_filled_xl", xlinkHref: "/icons/sprite.svg#play_filled_xl" })
            ]);
          });
        },
        1945: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "play_filled_xs", xlinkHref: "/icons/sprite.svg#play_filled_xs" })
            ]);
          });
        },
        7402: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "play_filled_xxl", xlinkHref: "/icons/sprite.svg#play_filled_xxl" })
            ]);
          });
        },
        1351: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "play_m", xlinkHref: "/icons/sprite.svg#play_m" })
            ]);
          });
        },
        1874: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "play_xs", xlinkHref: "/icons/sprite.svg#play_xs" })
            ]);
          });
        },
        2026: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "play_xxs", xlinkHref: "/icons/sprite.svg#play_xxs" })
            ]);
          });
        },
        5378: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "play_xxxs", xlinkHref: "/icons/sprite.svg#play_xxxs" })
            ]);
          });
        },
        3751: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "playlist_s", xlinkHref: "/icons/sprite.svg#playlist_s" })
            ]);
          });
        },
        8503: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "playlist_xl", xlinkHref: "/icons/sprite.svg#playlist_xl" })
            ]);
          });
        },
        1580: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "playlist_xs", xlinkHref: "/icons/sprite.svg#playlist_xs" })
            ]);
          });
        },
        8861: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "plus", xlinkHref: "/icons/sprite.svg#plus" })
            ]);
          });
        },
        6809: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "plusBadge", xlinkHref: "/icons/sprite.svg#plusBadge" })
            ]);
          });
        },
        5266: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "plusColor", xlinkHref: "/icons/sprite.svg#plusColor" })
            ]);
          });
        },
        1179: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "plusOutlined", xlinkHref: "/icons/sprite.svg#plusOutlined" })
            ]);
          });
        },
        735: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "plusOutlined_m", xlinkHref: "/icons/sprite.svg#plusOutlined_m" })
            ]);
          });
        },
        2754: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "podcasts_xxs", xlinkHref: "/icons/sprite.svg#podcasts_xxs" })
            ]);
          });
        },
        4091: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "previous_xs", xlinkHref: "/icons/sprite.svg#previous_xs" })
            ]);
          });
        },
        1427: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "previous_xxl", xlinkHref: "/icons/sprite.svg#previous_xxl" })
            ]);
          });
        },
        5251: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "previous_xxs", xlinkHref: "/icons/sprite.svg#previous_xxs" })
            ]);
          });
        },
        895: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "repeat_one_xs", xlinkHref: "/icons/sprite.svg#repeat_one_xs" })
            ]);
          });
        },
        5632: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "repeat_one_xxs", xlinkHref: "/icons/sprite.svg#repeat_one_xxs" })
            ]);
          });
        },
        8090: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "repeat_xs", xlinkHref: "/icons/sprite.svg#repeat_xs" })
            ]);
          });
        },
        9370: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "repeat_xxs", xlinkHref: "/icons/sprite.svg#repeat_xxs" })
            ]);
          });
        },
        1001: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "reset_xxs", xlinkHref: "/icons/sprite.svg#reset_xxs" })
            ]);
          });
        },
        6579: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "reset_xxxs", xlinkHref: "/icons/sprite.svg#reset_xxxs" })
            ]);
          });
        },
        5910: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "rewindBackwards_xs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xs"
              })
            ]);
          });
        },
        893: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "rewindBackwards_xxs",
                xlinkHref: "/icons/sprite.svg#rewindBackwards_xxs"
              })
            ]);
          });
        },
        4892: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "rewindForward_xs", xlinkHref: "/icons/sprite.svg#rewindForward_xs" })
            ]);
          });
        },
        6331: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "rewindForward_xxs", xlinkHref: "/icons/sprite.svg#rewindForward_xxs" })
            ]);
          });
        },
        2176: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "ruble_m", xlinkHref: "/icons/sprite.svg#ruble_m" })
            ]);
          });
        },
        9876: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "ruble_xxs", xlinkHref: "/icons/sprite.svg#ruble_xxs" })
            ]);
          });
        },
        3935: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "ruble_xxxs", xlinkHref: "/icons/sprite.svg#ruble_xxxs" })
            ]);
          });
        },
        7643: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "search_l", xlinkHref: "/icons/sprite.svg#search_l" })
            ]);
          });
        },
        8235: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "search_m", xlinkHref: "/icons/sprite.svg#search_m" })
            ]);
          });
        },
        8915: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "search_selected_m", xlinkHref: "/icons/sprite.svg#search_selected_m" })
            ]);
          });
        },
        3366: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "search_xs", xlinkHref: "/icons/sprite.svg#search_xs" })
            ]);
          });
        },
        7934: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "search_xxl", xlinkHref: "/icons/sprite.svg#search_xxl" })
            ]);
          });
        },
        5034: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "settings_xs", xlinkHref: "/icons/sprite.svg#settings_xs" })
            ]);
          });
        },
        1758: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "settings_xxs", xlinkHref: "/icons/sprite.svg#settings_xxs" })
            ]);
          });
        },
        7196: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "share_xxs", xlinkHref: "/icons/sprite.svg#share_xxs" })
            ]);
          });
        },
        5792: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "shuffle_xs", xlinkHref: "/icons/sprite.svg#shuffle_xs" })
            ]);
          });
        },
        7951: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "shuffle_xxs", xlinkHref: "/icons/sprite.svg#shuffle_xxs" })
            ]);
          });
        },
        9545: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "site_xs", xlinkHref: "/icons/sprite.svg#site_xs" })
            ]);
          });
        },
        2037: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_1_25x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_m"
              })
            ]);
          });
        },
        3362: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_1_25x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_25x_centered_xs"
              })
            ]);
          });
        },
        9846: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "speed_1_25x_l", xlinkHref: "/icons/sprite.svg#speed_1_25x_l" })
            ]);
          });
        },
        5197: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_1_5x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_m"
              })
            ]);
          });
        },
        1079: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_1_5x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_5x_centered_xs"
              })
            ]);
          });
        },
        6275: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "speed_1_5x_l", xlinkHref: "/icons/sprite.svg#speed_1_5x_l" })
            ]);
          });
        },
        7026: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_1_75x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_m"
              })
            ]);
          });
        },
        8994: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_1_75x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1_75x_centered_xs"
              })
            ]);
          });
        },
        3702: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "speed_1_75x_l", xlinkHref: "/icons/sprite.svg#speed_1_75x_l" })
            ]);
          });
        },
        8664: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_1x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_m"
              })
            ]);
          });
        },
        51: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_1x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_1x_centered_xs"
              })
            ]);
          });
        },
        8550: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "speed_1x_l", xlinkHref: "/icons/sprite.svg#speed_1x_l" })
            ]);
          });
        },
        8619: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_2x_centered_m",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_m"
              })
            ]);
          });
        },
        5218: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", {
                key: "speed_2x_centered_xs",
                xlinkHref: "/icons/sprite.svg#speed_2x_centered_xs"
              })
            ]);
          });
        },
        857: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "speed_2x_l", xlinkHref: "/icons/sprite.svg#speed_2x_l" })
            ]);
          });
        },
        6130: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "syncLyrics_m", xlinkHref: "/icons/sprite.svg#syncLyrics_m" })
            ]);
          });
        },
        3049: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "syncLyrics_xs", xlinkHref: "/icons/sprite.svg#syncLyrics_xs" })
            ]);
          });
        },
        126: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "syncLyrics_xxs", xlinkHref: "/icons/sprite.svg#syncLyrics_xxs" })
            ]);
          });
        },
        6210: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "ticket_m", xlinkHref: "/icons/sprite.svg#ticket_m" })
            ]);
          });
        },
        5596: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "ticket_selected_m", xlinkHref: "/icons/sprite.svg#ticket_selected_m" })
            ]);
          });
        },
        380: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "trailer_xs", xlinkHref: "/icons/sprite.svg#trailer_xs" })
            ]);
          });
        },
        3112: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "trailer_xxs", xlinkHref: "/icons/sprite.svg#trailer_xxs" })
            ]);
          });
        },
        1045: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "unavailable_xl", xlinkHref: "/icons/sprite.svg#unavailable_xl" })
            ]);
          });
        },
        2834: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "unavailable_xs", xlinkHref: "/icons/sprite.svg#unavailable_xs" })
            ]);
          });
        },
        8819: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "unpin_xxs", xlinkHref: "/icons/sprite.svg#unpin_xxs" })
            ]);
          });
        },
        8772: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "upload_xxs", xlinkHref: "/icons/sprite.svg#upload_xxs" })
            ]);
          });
        },
        3522: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "users_xxxs", xlinkHref: "/icons/sprite.svg#users_xxxs" })
            ]);
          });
        },
        5695: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "vibe_xxs", xlinkHref: "/icons/sprite.svg#vibe_xxs" })
            ]);
          });
        },
        6174: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "volumeOff_xs", xlinkHref: "/icons/sprite.svg#volumeOff_xs" })
            ]);
          });
        },
        540: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "volume_xs", xlinkHref: "/icons/sprite.svg#volume_xs" })
            ]);
          });
        },
        6206: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "windows", xlinkHref: "/icons/sprite.svg#windows" })
            ]);
          });
        },
        7185: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "windows_xs", xlinkHref: "/icons/sprite.svg#windows_xs" })
            ]);
          });
        },
        9481: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "yandexBooksEn", xlinkHref: "/icons/sprite.svg#yandexBooksEn" })
            ]);
          });
        },
        7364: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "yandexBooksRu", xlinkHref: "/icons/sprite.svg#yandexBooksRu" })
            ]);
          });
        },
        8577: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "yandexPayEn", xlinkHref: "/icons/sprite.svg#yandexPayEn" })
            ]);
          });
        },
        5760: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "yandexPayRu", xlinkHref: "/icons/sprite.svg#yandexPayRu" })
            ]);
          });
        },
        5667: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "yandexPlusEn", xlinkHref: "/icons/sprite.svg#yandexPlusEn" })
            ]);
          });
        },
        2639: (e2, t2, r2) => {
          var s2 = r2(810);
          e2.exports = s2.forwardRef(function(e3, t3) {
            return s2.createElement("svg", Object.assign({}, e3, { ref: t3 }), [
              s2.createElement("use", { key: "yandexPlusRu", xlinkHref: "/icons/sprite.svg#yandexPlusRu" })
            ]);
          });
        },
        9110: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.usePopoverSwipeable = t2.useReturnValue = t2.useCallbackRef = t2.useDebouncedToggle = t2.useResize = t2.useIsomorphicEffect = t2.useForceUpdateRef = t2.useElementOffsetY = t2.getElementNameByDataAttribute = t2.createIntersectionObserver = t2.useIntersectionObserver = t2.useKeyboardNavigation = t2.useScroll = t2.useForwardRef = void 0;
          var s2 = r2(245);
          Object.defineProperty(t2, "useForwardRef", {
            enumerable: true,
            get: function() {
              return s2.useForwardRef;
            }
          });
          var n2 = r2(2067);
          Object.defineProperty(t2, "useScroll", {
            enumerable: true,
            get: function() {
              return n2.useScroll;
            }
          });
          var a2 = r2(5188);
          Object.defineProperty(t2, "useKeyboardNavigation", {
            enumerable: true,
            get: function() {
              return a2.useKeyboardNavigation;
            }
          });
          var i2 = r2(5663);
          Object.defineProperty(t2, "useIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.useIntersectionObserver;
            }
          }), Object.defineProperty(t2, "createIntersectionObserver", {
            enumerable: true,
            get: function() {
              return i2.createIntersectionObserver;
            }
          }), Object.defineProperty(t2, "getElementNameByDataAttribute", {
            enumerable: true,
            get: function() {
              return i2.getElementNameByDataAttribute;
            }
          });
          var l2 = r2(2101);
          Object.defineProperty(t2, "useElementOffsetY", {
            enumerable: true,
            get: function() {
              return l2.useElementOffsetY;
            }
          });
          var o2 = r2(2767);
          Object.defineProperty(t2, "useForceUpdateRef", {
            enumerable: true,
            get: function() {
              return o2.useForceUpdateRef;
            }
          });
          var c2 = r2(9019);
          Object.defineProperty(t2, "useIsomorphicEffect", {
            enumerable: true,
            get: function() {
              return c2.useIsomorphicEffect;
            }
          });
          var u2 = r2(2947);
          Object.defineProperty(t2, "useResize", {
            enumerable: true,
            get: function() {
              return u2.useResize;
            }
          });
          var f = r2(6699);
          Object.defineProperty(t2, "useDebouncedToggle", {
            enumerable: true,
            get: function() {
              return f.useDebouncedToggle;
            }
          });
          var x = r2(8691);
          Object.defineProperty(t2, "useCallbackRef", {
            enumerable: true,
            get: function() {
              return x.useCallbackRef;
            }
          });
          var d = r2(998);
          Object.defineProperty(t2, "useReturnValue", {
            enumerable: true,
            get: function() {
              return d.useReturnValue;
            }
          });
          var _ = r2(4395);
          Object.defineProperty(t2, "usePopoverSwipeable", {
            enumerable: true,
            get: function() {
              return _.usePopoverSwipeable;
            }
          });
          var p = r2(5969);
          Object.defineProperty(t2, "useDynamicText", {
            enumerable: true,
            get: function() {
              return p.useDynamicText;
            }
          });
        },
        8691: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useCallbackRef = void 0;
          let s2 = r2(810);
          t2.useCallbackRef = function(e3) {
            let t3 = (0, s2.useRef)({
              stableFn: function() {
                for (var e4 = arguments.length, r3 = Array(e4), s3 = 0; s3 < e4; s3++) r3[s3] = arguments[s3];
                return t3.current.callback(...r3);
              },
              callback: e3
            });
            return (0, s2.useInsertionEffect)(() => {
              t3.current.callback = e3;
            }), t3.current.stableFn;
          };
        },
        1381: (e2, t2, r2) => {
          var s2;
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useComponentSwipeable = t2.SwipeablePlacement = void 0;
          let n2 = r2(4490), a2 = r2(8691);
          !(function(e3) {
            e3.TOP = "top", e3.BOTTOM = "bottom", e3.RIGHT = "right", e3.LEFT = "left";
          })(s2 || (t2.SwipeablePlacement = s2 = {}));
          let i2 = (e3) => {
            let { ref: t3, deltaY: r3, deltaX: n3, placement: a3 } = e3;
            requestAnimationFrame(() => {
              t3.current && (t3.current.style.willChange = "transform", t3.current.style.transform = a3 === s2.TOP || a3 === s2.BOTTOM ? "translateY(".concat(r3 || 0, "px)") : "translateX(".concat(n3 || 0, "px)"));
            });
          }, l2 = (e3) => {
            requestAnimationFrame(() => {
              e3.current && (e3.current.style.transition = "none", e3.current.style.willChange = "", e3.current.style.transform = "");
            });
          };
          t2.useComponentSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: o2, disableSwipe: c2, placement: u2, threshold: f } = e3, x = (0, a2.useCallbackRef)(() => {
              o2 && (l2(t3), o2());
            }), d = (0, a2.useCallbackRef)((e4) => {
              c2 || ((e5) => {
                let { ref: t4, deltaY: r4, deltaX: n3, placement: a3 } = e5;
                switch (a3) {
                  case s2.TOP:
                    r4 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: n3, placement: a3 });
                    break;
                  case s2.RIGHT:
                    n3 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: n3, placement: a3 });
                    break;
                  case s2.LEFT:
                    n3 <= 0 && i2({ ref: t4, deltaY: r4, deltaX: n3, placement: a3 });
                    break;
                  default:
                    r4 >= 0 && i2({ ref: t4, deltaY: r4, deltaX: n3, placement: a3 });
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2 });
            }), _ = (0, a2.useCallbackRef)((e4) => {
              !c2 && (((e5) => {
                let { ref: t4, deltaY: r4, deltaX: n3, placement: a3, threshold: i3 = 25 } = e5;
                if (!t4.current) return false;
                let l3 = i3 / 100 * (a3 === s2.TOP || a3 === s2.BOTTOM ? t4.current.offsetHeight : t4.current.offsetWidth);
                switch (a3) {
                  case s2.TOP:
                    return r4 < 0 && Math.abs(r4) >= l3;
                  case s2.RIGHT:
                    return n3 > 0 && n3 >= l3;
                  case s2.LEFT:
                    return n3 < 0 && Math.abs(n3) >= l3;
                  default:
                    return r4 > 0 && r4 >= l3;
                }
              })({ ref: t3, deltaY: e4.deltaY, deltaX: e4.deltaX, placement: u2, threshold: f }) ? o2 && (l2(t3), o2()) : l2(t3));
            });
            return {
              handlers: (0, n2.useSwipeable)({ onSwiped: _, onSwiping: d, trackMouse: true, trackTouch: true, ...r3 }),
              onCloseCallback: x
            };
          };
        },
        6699: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let s2 = r2(352), n2 = r2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: r3, throttleTimeout: a2 } = e3, i2 = (0, n2.useRef)(null), [l2, o2] = (0, n2.useState)(!!r3), c2 = (0, n2.useMemo)(
              () => (0, s2.throttle)(() => {
                o2(!r3), i2.current && window.clearTimeout(i2.current), i2.current = window.setTimeout(() => {
                  o2(!!r3);
                }, t3);
              }, a2),
              [t3, r3, a2]
            ), u2 = (0, n2.useCallback)(() => {
              o2(!!r3), i2.current && window.clearTimeout(i2.current);
            }, [r3]);
            return (0, n2.useEffect)(
              () => () => {
                i2.current && window.clearTimeout(i2.current);
              },
              []
            ), { state: l2, handleDebouncedToggle: c2, reset: u2 };
          };
        },
        5969: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDynamicText = t2.findOptimalFontSize = void 0;
          let s2 = r2(810), n2 = (e3) => {
            e3.style.wordBreak = "keep-all", e3.style.overflowWrap = "normal", e3.style.maxHeight = "none", e3.style.height = "auto", e3.style.overflow = "visible", Array.from(e3.children).forEach((e4) => {
              e4 instanceof HTMLElement && n2(e4);
            });
          };
          t2.findOptimalFontSize = (e3) => {
            let {
              container: t3,
              containerWidth: r3,
              containerHeight: s3,
              minFontSize: a2,
              maxFontSize: i2,
              lineHeight: l2,
              maxLines: o2
            } = e3, c2 = ((e4, t4, r4) => {
              let s4 = e4.cloneNode(true);
              return s4.style.cssText = "\n        position: absolute !important;\n        visibility: hidden !important;\n        pointer-events: none !important;\n        width: ".concat(
                t4,
                "px !important;\n    "
              ), n2(s4), s4.style.setProperty("--dynamic-line-height", String(r4)), document.body.appendChild(s4), s4;
            })(t3, r3, l2);
            try {
              let e4 = a2, t4 = i2, n3 = a2;
              for (; e4 <= t4; ) {
                let a3 = Math.floor((e4 + t4) / 2);
                c2.style.setProperty("--dynamic-font-size", "".concat(a3, "px"));
                let i3 = Math.min(o2 * a3 * l2, s3), u2 = c2.scrollHeight <= i3, f = c2.scrollWidth <= r3 + 1;
                u2 && f ? (n3 = a3, e4 = a3 + 1) : t4 = a3 - 1;
              }
              return n3 - 1;
            } finally {
              c2.remove();
            }
          }, t2.useDynamicText = (e3, r3) => {
            (0, s2.useLayoutEffect)(() => {
              if (null === e3) return;
              e3.style.setProperty("--dynamic-line-height", String(r3.lineHeight));
              let s3 = () => {
                let { width: s4, height: n4 } = e3.getBoundingClientRect(), a3 = e3.childNodes.length > 0;
                if (0 === s4 || 0 === n4 || !a3) return;
                let i2 = (0, t2.findOptimalFontSize)({ container: e3, containerWidth: s4, containerHeight: n4, ...r3 });
                e3.style.setProperty("--dynamic-font-size", "".concat(i2, "px"));
              }, n3 = new ResizeObserver(s3), a2 = new MutationObserver(s3);
              return n3.observe(e3), a2.observe(e3, { childList: true, characterData: true, subtree: true }), document.fonts.ready.then(s3), s3(), () => {
                n3.disconnect(), a2.disconnect();
              };
            }, [e3, r3]);
          };
        },
        2101: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useElementOffsetY = void 0;
          let s2 = r2(810), n2 = r2(2067), a2 = r2(2767);
          t2.useElementOffsetY = (e3) => {
            let [t3, r3] = (0, a2.useForceUpdateRef)(), [i2, l2] = (0, s2.useState)(), o2 = (0, s2.useCallback)(() => {
              let e4 = null == t3 ? void 0 : t3.getBoundingClientRect();
              e4 && l2(e4.y);
            }, [t3]);
            return (0, s2.useLayoutEffect)(o2), (0, n2.useScroll)({ onScroll: o2, elementRef: e3 }), { forceUpdateRefCallback: r3, offsetY: i2 };
          };
        },
        2767: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForceUpdateRef = void 0;
          let s2 = r2(810);
          t2.useForceUpdateRef = () => {
            let [e3, t3] = (0, s2.useState)(null);
            return [
              e3,
              (0, s2.useCallback)((e4) => {
                t3((t4) => t4 !== e4 ? e4 : t4);
              }, [])
            ];
          };
        },
        245: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useForwardRef = void 0;
          let s2 = r2(810);
          t2.useForwardRef = function(e3, t3) {
            let r3 = (0, s2.useRef)(t3);
            return (0, s2.useEffect)(() => {
              e3 && ("function" == typeof e3 ? e3(r3.current) : e3.current = r3.current);
            }, [e3]), r3;
          };
        },
        5663: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIntersectionObserver = t2.createIntersectionObserver = t2.getElementNameByDataAttribute = t2.isInViewportNow = t2.defaultOptions = void 0;
          let s2 = r2(810), { innerWidth: n2 = 0, innerHeight: a2 = 0 } = window;
          function i2(e3) {
            let { top: t3, right: r3, bottom: s3, left: i3 } = e3.getBoundingClientRect();
            return (t3 >= 0 && t3 <= a2 || s3 >= 0 && s3 <= a2) && (i3 >= 0 && i3 <= n2 || r3 >= 0 && r3 <= n2);
          }
          function l2(e3) {
            var t3, r3;
            let s3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "data-intersection-property-id";
            return null != (r3 = null == e3 || null == (t3 = e3.getAttribute) ? void 0 : t3.call(e3, s3)) ? r3 : e3.attributes[0];
          }
          function o2(e3, t3) {
            let r3 = new IntersectionObserver((t4) => {
              t4.forEach((t5) => {
                e3(t5, r3);
              });
            }, t3);
            return r3;
          }
          t2.defaultOptions = { threshold: 0, preflightCheck: true }, t2.isInViewportNow = i2, t2.getElementNameByDataAttribute = l2, t2.createIntersectionObserver = o2, t2.useIntersectionObserver = function(e3, r3, n3) {
            let [{ freezeOnceVisible: a3, preflightCheck: c2, ...u2 }, f = false] = "boolean" == typeof r3 || void 0 === r3 ? [t2.defaultOptions, r3] : [{ ...t2.defaultOptions, ...r3 }, n3], [x, d] = (0, s2.useState)({}), _ = (0, s2.useRef)(/* @__PURE__ */ new Set()), p = (0, s2.useMemo)(
              () => f ? null : o2((e4) => {
                let t3 = l2(e4.target);
                if (t3 && p) {
                  if (_.current.has(t3)) return;
                  d((r4) => ({ ...r4, [t3]: { isIntersecting: e4.isIntersecting } })), a3 && e4.isIntersecting && (_.current.add(t3), p.unobserve(e4.target));
                }
              }, u2),
              [f]
            );
            return (0, s2.useLayoutEffect)(
              () => (p && !f && e3.forEach((e4) => {
                if (e4.current) {
                  let t3 = false;
                  if (c2 && (t3 = i2(e4.current))) {
                    let t4 = l2(e4.current);
                    d((e5) => ({ ...e5, [t4]: { isIntersecting: true } }));
                  }
                  t3 || p.observe(e4.current);
                }
              }), () => {
                p && p.disconnect();
              }),
              [f, p, e3.length]
            ), x;
          };
        },
        9019: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useIsomorphicEffect = void 0;
          let s2 = r2(810);
          t2.useIsomorphicEffect = "undefined" != typeof document ? s2.useLayoutEffect : s2.useEffect;
        },
        5188: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useKeyboardNavigation = void 0;
          let s2 = r2(810);
          function n2(e3, t3) {
            return e3.current ? Array.from(t3 ? e3.current.querySelectorAll(t3) : e3.current.children) : [];
          }
          t2.useKeyboardNavigation = function(e3) {
            let t3 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, { navigationItemsSelector: r3, activeAttributeName: a2 = "aria-selected" } = t3, i2 = (0, s2.useCallback)(
              (t4) => {
                let s3 = n2(e3, r3);
                if (!s3.length) return;
                let a3 = t4.target, i3 = s3.indexOf(a3);
                if (-1 === i3) return;
                let [l2] = s3, o2 = s3.at(-1), c2 = null;
                switch (t4.key) {
                  case "ArrowLeft":
                  case "ArrowUp":
                    c2 = s3[i3 - 1] || o2;
                    break;
                  case "ArrowRight":
                  case "ArrowDown":
                    c2 = s3[i3 + 1] || l2;
                    break;
                  case "Home":
                    c2 = l2;
                    break;
                  case "End":
                    c2 = o2;
                }
                null !== c2 && (c2.focus(), t4.preventDefault());
              },
              [r3, e3]
            );
            (0, s2.useEffect)(() => {
              let t4 = e3.current;
              return null == t4 || t4.addEventListener("keydown", i2), () => null == t4 ? void 0 : t4.removeEventListener("keydown", i2);
            }, [e3, i2]), (0, s2.useEffect)(() => {
              n2(e3, r3).forEach((e4) => {
                e4.hasAttribute(a2) && ("true" === e4.getAttribute(a2) ? e4.tabIndex = 0 : e4.tabIndex = -1);
              });
            });
          };
        },
        4395: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.usePopoverSwipeable = void 0;
          let s2 = r2(810), n2 = r2(1381);
          t2.usePopoverSwipeable = (e3) => {
            let { ref: t3, swipeableProps: r3 = {}, onClose: a2, disableSwipe: i2, placement: l2, threshold: o2 } = e3, c2 = (0, s2.useMemo)(() => {
              switch (l2) {
                case "top":
                case "top-end":
                case "top-start":
                  return n2.SwipeablePlacement.TOP;
                case "right":
                case "right-end":
                case "right-start":
                  return n2.SwipeablePlacement.RIGHT;
                case "left":
                case "left-end":
                case "left-start":
                  return n2.SwipeablePlacement.LEFT;
                default:
                  return n2.SwipeablePlacement.BOTTOM;
              }
            }, [l2]);
            return (0, n2.useComponentSwipeable)({
              ref: t3,
              swipeableProps: r3,
              onClose: a2,
              disableSwipe: i2,
              placement: c2,
              threshold: o2
            });
          };
        },
        2947: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useResize = void 0;
          let s2 = r2(810), n2 = r2(361);
          t2.useResize = (e3, t3) => {
            (0, s2.useEffect)(() => {
              let r3 = (0, n2.getElementFromRefOrElement)(t3);
              if (null === r3) return;
              let s3 = null != r3 ? r3 : document.documentElement, a2 = new ResizeObserver(e3);
              return a2.observe(s3), () => a2.disconnect();
            }, [t3, e3]);
          };
        },
        998: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useReturnValue = void 0, t2.useReturnValue = (e3) => e3();
        },
        2067: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useScroll = void 0;
          let s2 = r2(810), n2 = r2(361), a2 = r2(6699);
          t2.useScroll = (e3) => {
            let { onScroll: t3, listenIsScrolling: r3, elementRef: i2 } = e3, { state: l2, handleDebouncedToggle: o2 } = (0, a2.useDebouncedToggle)({
              delay: 1e3,
              throttleTimeout: 100
            }), c2 = (0, s2.useCallback)(() => {
              r3 && o2(), null == t3 || t3();
            }, [r3, o2, t3]);
            return (0, s2.useEffect)(() => {
              let e4 = (0, n2.getElementFromRefOrElement)(i2);
              if (null === e4) return;
              let t4 = null != e4 ? e4 : window, r4 = { capture: true, passive: true };
              return t4.addEventListener("scroll", c2, r4), () => t4.removeEventListener("scroll", c2, r4);
            }, [i2, c2]), l2;
          };
        },
        8796: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.createRipple = void 0, t2.createRipple = function(e3, t3, r2) {
            let s2 = null != r2 ? r2 : e3.currentTarget, n2 = document.createElement("span"), a2 = Math.max(s2.clientWidth, s2.clientHeight), i2 = a2 / 2, l2 = s2.getBoundingClientRect(), o2 = 0 === e3.clientX ? Math.round(l2.width / 2) : e3.clientX - l2.left, c2 = 0 === e3.clientY ? Math.round(l2.height / 2) : e3.clientY - l2.top;
            n2.style.width = "".concat(a2, "px"), n2.style.height = "".concat(a2, "px"), n2.style.left = 0 === e3.clientX ? "0px" : "".concat(o2 - i2, "px"), n2.style.top = "".concat(c2 - i2, "px"), n2.classList.add(t3);
            let u2 = s2.getElementsByClassName(t3)[0];
            u2 && u2.remove(), s2.insertBefore(n2, s2.firstChild);
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        8216: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = t2.createRipple = void 0;
          var s2 = r2(8796);
          Object.defineProperty(t2, "createRipple", {
            enumerable: true,
            get: function() {
              return s2.createRipple;
            }
          });
          var n2 = r2(361);
          Object.defineProperty(t2, "getElementFromRefOrElement", {
            enumerable: true,
            get: function() {
              return n2.getElementFromRefOrElement;
            }
          });
        },
        8119: function(e2, t2, r2) {
          var s2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          let n2 = r2(4377), a2 = r2(810), i2 = r2(5881), l2 = r2(8216), o2 = s2(r2(1920)), c2 = (e3) => {
            let {
              forwardRef: t3,
              isBlock: r3,
              iconPosition: s3 = "left",
              children: c3,
              className: u2,
              color: f = "secondary",
              flexIcon: x,
              icon: d,
              spinner: _,
              role: p,
              onClick: v,
              radius: g = "m",
              size: m,
              type: k = "button",
              variant: E = "default",
              withRipple: y = true,
              withHover: b = true,
              withBorder: w = false,
              disabled: O,
              iconClassName: R,
              contentContainerClassName: j,
              ...h
            } = e3, H = (0, a2.useId)(), P = !a2.Children.toArray(c3).filter(Boolean).length, M = "left" === s3, S = null, L = (0, a2.isValidElement)(_);
            if (d) {
              var C, T;
              S = (0, a2.cloneElement)(d, {
                className: (0, i2.clsx)(
                  o2.default.icon,
                  {
                    [o2.default["icon_position_".concat(s3)]]: s3 && !P,
                    [o2.default.icon_withButtonSize]: !(null == (C = d.props) ? void 0 : C.size)
                  },
                  null == (T = d.props) ? void 0 : T.className,
                  R
                ),
                key: H
              });
            }
            let D = (0, a2.useMemo)(
              () => L ? (0, n2.jsx)("div", { className: o2.default.spinnerContainer, children: _ }) : null,
              [L, _]
            ), F = (0, a2.useCallback)(
              (e4) => {
                L || (y && (0, l2.createRipple)(e4, o2.default.ripple), null == v || v(e4));
              },
              [L, v, y]
            );
            return (0, n2.jsx)("button", {
              ref: t3,
              className: (0, i2.clsx)(
                o2.default.root,
                o2.default["root_".concat(f, "_").concat(E)],
                o2.default["root_radius_".concat(g)],
                o2.default.root_size,
                {
                  [o2.default["root_".concat(f, "_withHover_").concat(E)]]: b && !O && !L,
                  [o2.default["root_size_".concat(m)]]: m,
                  [o2.default.root_withoutBorder]: !w,
                  [o2.default.root_withActiveSpinner]: L,
                  [o2.default.block]: r3,
                  [o2.default.flexIcon]: x,
                  [o2.default.iconOnly]: P,
                  [o2.default.root_icon_left]: d && !P && M,
                  [o2.default.root_icon_right]: d && !P && !M
                },
                u2
              ),
              type: k,
              role: p,
              onClick: F,
              ...h,
              disabled: O,
              "aria-live": L ? "polite" : "off",
              "aria-busy": L,
              children: d || L ? (0, n2.jsxs)("span", {
                className: (0, i2.clsx)(
                  o2.default.contentContainer,
                  { [o2.default.contentContainer_block]: r3 },
                  j
                ),
                children: [d && M && S, !P && c3, d && !M && S, D]
              }) : c3
            });
          };
          t2.Button = (0, a2.forwardRef)((e3, t3) => (0, n2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        5928: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          var s2 = r2(8119);
          Object.defineProperty(t2, "Button", {
            enumerable: true,
            get: function() {
              return s2.Button;
            }
          });
        },
        5189: function(e2, t2, r2) {
          var s2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = t2.IconComponent = void 0;
          let n2 = r2(4377), a2 = r2(810), i2 = r2(5881), l2 = r2(5151), o2 = s2(r2(2964));
          t2.IconComponent = (e3) => {
            let { "aria-label": t3, className: r3, focusable: s3 = false, variant: a3, size: c2, forwardRef: u2, ...f } = e3, x = c2 ? "".concat(a3, "_").concat(c2) : a3, d = l2.iconsCollection[x];
            return d ? (0, n2.jsx)(d, {
              className: (0, i2.clsx)(o2.default.root, r3, o2.default["root_size_".concat(c2)]),
              focusable: s3,
              "aria-label": t3,
              ...f,
              "aria-hidden": !t3,
              ref: u2
            }) : null;
          }, t2.Icon = (0, a2.forwardRef)((e3, r3) => (0, n2.jsx)(t2.IconComponent, { forwardRef: r3, ...e3 }));
        },
        5151: function(e2, t2, r2) {
          var s2 = this && this.__importDefault || function(e10) {
            return e10 && e10.__esModule ? e10 : { default: e10 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.iconsCollection = t2.iconsCollectionBySize = void 0;
          let n2 = s2(r2(4656)), a2 = s2(r2(8170)), i2 = s2(r2(5565)), l2 = s2(r2(8127)), o2 = s2(r2(8993)), c2 = s2(r2(2933)), u2 = s2(r2(1334)), f = s2(r2(1426)), x = s2(r2(5378)), d = s2(r2(6579)), _ = s2(r2(3935)), p = s2(r2(3522)), v = s2(r2(7319)), g = s2(r2(8442)), m = s2(r2(2586)), k = s2(r2(5822)), E = s2(r2(5272)), y = s2(r2(4860)), b = s2(r2(8711)), w = s2(r2(8109)), O = s2(r2(4904)), R = s2(r2(5971)), j = s2(r2(3331)), h = s2(r2(9783)), H = s2(r2(8184)), P = s2(r2(4926)), M = s2(r2(3176)), S = s2(r2(4789)), L = s2(r2(8151)), C = s2(r2(8690)), T = s2(r2(1524)), D = s2(r2(2361)), F = s2(r2(3972)), B = s2(r2(9330)), I = s2(r2(7346)), A = s2(r2(2604)), z = s2(r2(6894)), N = s2(r2(6391)), U = s2(r2(9369)), V = s2(r2(226)), Y = s2(r2(8130)), W = s2(r2(5270)), q = s2(r2(3560)), G = s2(r2(7513)), X = s2(r2(9838)), Q = s2(r2(9104)), Z = s2(r2(7399)), K = s2(r2(5849)), J = s2(r2(3613)), $ = s2(r2(9372)), ee = s2(r2(3709)), et = s2(r2(3685)), er = s2(r2(3302)), es = s2(r2(811)), en = s2(r2(6122)), ea = s2(r2(5386)), ei = s2(r2(3201)), el = s2(r2(9434)), eo = s2(r2(2026)), ec = s2(r2(8112)), eu = s2(r2(8044)), ef = s2(r2(2754)), ex = s2(r2(5251)), ed = s2(r2(9370)), e_ = s2(r2(5632)), ep = s2(r2(1001)), ev = s2(r2(893)), eg = s2(r2(6331)), em = s2(r2(9876)), ek = s2(r2(1758)), eE = s2(r2(7196)), ey = s2(r2(7951)), eb = s2(r2(126)), ew = s2(r2(3112)), eO = s2(r2(8819)), eR = s2(r2(8772)), ej = s2(r2(5695)), eh = s2(r2(7171)), eH = s2(r2(9030)), eP = s2(r2(9422)), eM = s2(r2(1491)), eS = s2(r2(2337)), eL = s2(r2(9202)), eC = s2(r2(130)), eT = s2(r2(7923)), eD = s2(r2(3654)), eF = s2(r2(6507)), eB = s2(r2(3193)), eI = s2(r2(30)), eA = s2(r2(7802)), ez = s2(r2(3738)), eN = s2(r2(2340)), eU = s2(r2(2125)), eV = s2(r2(4014)), eY = s2(r2(896)), eW = s2(r2(1829)), eq = s2(r2(1893)), eG = s2(r2(1563)), eX = s2(r2(1578)), eQ = s2(r2(9348)), eZ = s2(r2(965)), eK = s2(r2(3877)), eJ = s2(r2(9968)), e$ = s2(r2(3778)), e0 = s2(r2(1084)), e1 = s2(r2(4254)), e8 = s2(r2(792)), e22 = s2(r2(8131)), e9 = s2(r2(1125)), e3 = s2(r2(9288)), e5 = s2(r2(976)), e7 = s2(r2(1874)), e6 = s2(r2(9863)), e4 = s2(r2(1945)), te = s2(r2(1580)), tt = s2(r2(4091)), tr = s2(r2(8090)), ts = s2(r2(895)), tn = s2(r2(5910)), ta = s2(r2(4892)), ti = s2(r2(3366)), tl = s2(r2(5034)), to = s2(r2(5792)), tc = s2(r2(9545)), tu = s2(r2(3362)), tf = s2(r2(1079)), tx = s2(r2(8994)), td = s2(r2(51)), t_ = s2(r2(5218)), tp = s2(r2(3049)), tv = s2(r2(380)), tg = s2(r2(2834)), tm = s2(r2(540)), tk = s2(r2(6174)), tE = s2(r2(7185)), ty = s2(r2(9351)), tb = s2(r2(2092)), tw = s2(r2(1162)), tO = s2(r2(6837)), tR = s2(r2(2024)), tj = s2(r2(776)), th = s2(r2(5720)), tH = s2(r2(2774)), tP = s2(r2(4997)), tM = s2(r2(3146)), tS = s2(r2(2084)), tL = s2(r2(3751)), tC = s2(r2(3076)), tT = s2(r2(2495)), tD = s2(r2(9509)), tF = s2(r2(8987)), tB = s2(r2(190)), tI = s2(r2(843)), tA = s2(r2(5122)), tz = s2(r2(7405)), tN = s2(r2(820)), tU = s2(r2(5443)), tV = s2(r2(8782)), tY = s2(r2(7252)), tW = s2(r2(3013)), tq = s2(r2(5346)), tG = s2(r2(3792)), tX = s2(r2(1351)), tQ = s2(r2(8303)), tZ = s2(r2(4777)), tK = s2(r2(735)), tJ = s2(r2(2176)), t$ = s2(r2(8235)), t0 = s2(r2(8915)), t1 = s2(r2(2037)), t8 = s2(r2(5197)), t22 = s2(r2(7026)), t9 = s2(r2(8664)), t3 = s2(r2(8619)), t5 = s2(r2(6130)), t7 = s2(r2(6210)), t6 = s2(r2(5596)), t4 = s2(r2(6644)), re = s2(r2(996)), rt = s2(r2(7031)), rr = s2(r2(4793)), rs = s2(r2(7076)), rn = s2(r2(8582)), ra = s2(r2(7643)), ri = s2(r2(9846)), rl = s2(r2(6275)), ro = s2(r2(3702)), rc = s2(r2(8550)), ru = s2(r2(857)), rf = s2(r2(6304)), rx = s2(r2(9040)), rd = s2(r2(4298)), r_ = s2(r2(5132)), rp = s2(r2(8868)), rv = s2(r2(8779)), rg = s2(r2(8503)), rm = s2(r2(1045)), rk = s2(r2(7341)), rE = s2(r2(9505)), ry = s2(r2(4483)), rb = s2(r2(8499)), rw = s2(r2(705)), rO = s2(r2(7402)), rR = s2(r2(1427)), rj = s2(r2(7934)), rh = s2(r2(2435)), rH = s2(r2(3918)), rP = s2(r2(2571)), rM = s2(r2(2161)), rS = s2(r2(5304)), rL = s2(r2(2646)), rC = s2(r2(7500)), rT = s2(r2(6104)), rD = s2(r2(2502)), rF = s2(r2(1754)), rB = s2(r2(6615)), rI = s2(r2(7942)), rA = s2(r2(1498)), rz = s2(r2(8861)), rN = s2(r2(6809)), rU = s2(r2(5266)), rV = s2(r2(1179)), rY = s2(r2(6206)), rW = s2(r2(9481)), rq = s2(r2(7364)), rG = s2(r2(8577)), rX = s2(r2(5760)), rQ = s2(r2(5667)), rZ = s2(r2(2639));
          t2.iconsCollectionBySize = {
            xxxs: [
              "adult",
              "arrowRight",
              "check",
              "close",
              "donation",
              "exclamation",
              "explicit",
              "listen",
              "play",
              "reset",
              "ruble",
              "users"
            ],
            xxs: [
              "add",
              "addToPlaylist",
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "artist",
              "bucket",
              "chain",
              "chartDown",
              "chartNew",
              "chartSame",
              "chartUp",
              "check",
              "clip",
              "close",
              "code",
              "crown",
              "dislike",
              "disliked",
              "download",
              "downloaded",
              "dragDots",
              "edit",
              "exclamation",
              "explicit",
              "eye_crossed",
              "filter",
              "info",
              "lightning",
              "like",
              "likeVariant",
              "liked",
              "likedVariant",
              "link",
              "lock",
              "lyrics",
              "macos",
              "menuArrow",
              "more",
              "next",
              "pause",
              "pencil",
              "pin",
              "pin_filled",
              "play",
              "playLast",
              "playNext",
              "podcasts",
              "previous",
              "repeat",
              "repeat_one",
              "reset",
              "rewindBackwards",
              "rewindForward",
              "ruble",
              "settings",
              "share",
              "shuffle",
              "syncLyrics",
              "trailer",
              "unpin",
              "upload",
              "vibe"
            ],
            xs: [
              "adult",
              "album",
              "arrowDown",
              "arrowLeft",
              "arrowRight",
              "cast",
              "chain",
              "close",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "filter",
              "fullscreen",
              "like",
              "liked",
              "liteVersion",
              "lock",
              "more",
              "navigationCollection",
              "navigationConcerts",
              "navigationForYouAndTrends",
              "navigationKids",
              "navigationMyVibe",
              "navigationNonMusic",
              "navigationPlus",
              "navigationSearch",
              "next",
              "note",
              "pause",
              "pause_filled",
              "picture",
              "pin",
              "pin_filled",
              "play",
              "playQueue",
              "play_filled",
              "playlist",
              "previous",
              "repeat",
              "repeat_one",
              "rewindBackwards",
              "rewindForward",
              "search",
              "settings",
              "shuffle",
              "site",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "trailer",
              "unavailable",
              "volume",
              "volumeOff",
              "windows"
            ],
            s: [
              "adult",
              "album",
              "dislike",
              "disliked",
              "exclamation",
              "explicit",
              "likedVariant",
              "note",
              "pauseVibe",
              "picture",
              "playVibe",
              "playlist"
            ],
            m: [
              "collections",
              "collections_selected",
              "history",
              "home",
              "home_selected",
              "kids",
              "kids_selected",
              "like",
              "liked",
              "lock",
              "more",
              "non_music",
              "non_music_selected",
              "pause",
              "pause_filled",
              "play",
              "playQueue",
              "play_filled",
              "plusOutlined",
              "ruble",
              "search",
              "search_selected",
              "speed_1_25x_centered",
              "speed_1_5x_centered",
              "speed_1_75x_centered",
              "speed_1x_centered",
              "speed_2x_centered",
              "syncLyrics",
              "ticket",
              "ticket_selected"
            ],
            l: [
              "add",
              "album",
              "download",
              "like",
              "pause_filled",
              "play_filled",
              "search",
              "speed_1_25x",
              "speed_1_5x",
              "speed_1_75x",
              "speed_1x",
              "speed_2x"
            ],
            xl: ["album", "clip", "note", "pause_filled", "picture", "play_filled", "playlist", "unavailable"],
            xxl: ["attention", "check", "next", "offline", "pause_filled", "play_filled", "previous", "search"],
            xxxl: ["attention"],
            "": [
              "bandlink",
              "booksLogo",
              "googlePlay",
              "huaweiAppGallery",
              "kinopoiskEn",
              "kinopoiskRu",
              "macos",
              "musicLogo",
              "musicLogoCenterEn",
              "musicLogoCenterRu",
              "musicLogoLeftEn",
              "musicLogoLeftRu",
              "plus",
              "plusBadge",
              "plusColor",
              "plusOutlined",
              "windows",
              "yandexBooksEn",
              "yandexBooksRu",
              "yandexPayEn",
              "yandexPayRu",
              "yandexPlusEn",
              "yandexPlusRu"
            ]
          }, t2.iconsCollection = {
            adult_xxxs: n2.default,
            arrowRight_xxxs: a2.default,
            check_xxxs: i2.default,
            close_xxxs: l2.default,
            donation_xxxs: o2.default,
            exclamation_xxxs: c2.default,
            explicit_xxxs: u2.default,
            listen_xxxs: f.default,
            play_xxxs: x.default,
            reset_xxxs: d.default,
            ruble_xxxs: _.default,
            users_xxxs: p.default,
            add_xxs: v.default,
            addToPlaylist_xxs: g.default,
            adult_xxs: m.default,
            album_xxs: k.default,
            arrowDown_xxs: E.default,
            arrowLeft_xxs: y.default,
            arrowRight_xxs: b.default,
            artist_xxs: w.default,
            bucket_xxs: O.default,
            chain_xxs: R.default,
            chartDown_xxs: j.default,
            chartNew_xxs: h.default,
            chartSame_xxs: H.default,
            chartUp_xxs: P.default,
            check_xxs: M.default,
            clip_xxs: S.default,
            close_xxs: L.default,
            code_xxs: C.default,
            crown_xxs: T.default,
            dislike_xxs: D.default,
            disliked_xxs: F.default,
            download_xxs: B.default,
            downloaded_xxs: I.default,
            dragDots_xxs: A.default,
            edit_xxs: z.default,
            exclamation_xxs: N.default,
            explicit_xxs: U.default,
            eye_crossed_xxs: V.default,
            filter_xxs: Y.default,
            info_xxs: W.default,
            lightning_xxs: q.default,
            like_xxs: G.default,
            likeVariant_xxs: X.default,
            liked_xxs: Q.default,
            likedVariant_xxs: Z.default,
            link_xxs: K.default,
            lock_xxs: J.default,
            lyrics_xxs: $.default,
            macos_xxs: ee.default,
            menuArrow_xxs: et.default,
            more_xxs: er.default,
            next_xxs: es.default,
            pause_xxs: en.default,
            pencil_xxs: ea.default,
            pin_xxs: ei.default,
            pin_filled_xxs: el.default,
            play_xxs: eo.default,
            playLast_xxs: ec.default,
            playNext_xxs: eu.default,
            podcasts_xxs: ef.default,
            previous_xxs: ex.default,
            repeat_xxs: ed.default,
            repeat_one_xxs: e_.default,
            reset_xxs: ep.default,
            rewindBackwards_xxs: ev.default,
            rewindForward_xxs: eg.default,
            ruble_xxs: em.default,
            settings_xxs: ek.default,
            share_xxs: eE.default,
            shuffle_xxs: ey.default,
            syncLyrics_xxs: eb.default,
            trailer_xxs: ew.default,
            unpin_xxs: eO.default,
            upload_xxs: eR.default,
            vibe_xxs: ej.default,
            adult_xs: eh.default,
            album_xs: eH.default,
            arrowDown_xs: eP.default,
            arrowLeft_xs: eM.default,
            arrowRight_xs: eS.default,
            cast_xs: eL.default,
            chain_xs: eC.default,
            close_xs: eT.default,
            dislike_xs: eD.default,
            disliked_xs: eF.default,
            exclamation_xs: eB.default,
            explicit_xs: eI.default,
            filter_xs: eA.default,
            fullscreen_xs: ez.default,
            like_xs: eN.default,
            liked_xs: eU.default,
            liteVersion_xs: eV.default,
            lock_xs: eY.default,
            more_xs: eW.default,
            navigationCollection_xs: eq.default,
            navigationConcerts_xs: eG.default,
            navigationForYouAndTrends_xs: eX.default,
            navigationKids_xs: eQ.default,
            navigationMyVibe_xs: eZ.default,
            navigationNonMusic_xs: eK.default,
            navigationPlus_xs: eJ.default,
            navigationSearch_xs: e$.default,
            next_xs: e0.default,
            note_xs: e1.default,
            pause_xs: e8.default,
            pause_filled_xs: e22.default,
            picture_xs: e9.default,
            pin_xs: e3.default,
            pin_filled_xs: e5.default,
            play_xs: e7.default,
            playQueue_xs: e6.default,
            play_filled_xs: e4.default,
            playlist_xs: te.default,
            previous_xs: tt.default,
            repeat_xs: tr.default,
            repeat_one_xs: ts.default,
            rewindBackwards_xs: tn.default,
            rewindForward_xs: ta.default,
            search_xs: ti.default,
            settings_xs: tl.default,
            shuffle_xs: to.default,
            site_xs: tc.default,
            speed_1_25x_centered_xs: tu.default,
            speed_1_5x_centered_xs: tf.default,
            speed_1_75x_centered_xs: tx.default,
            speed_1x_centered_xs: td.default,
            speed_2x_centered_xs: t_.default,
            syncLyrics_xs: tp.default,
            trailer_xs: tv.default,
            unavailable_xs: tg.default,
            volume_xs: tm.default,
            volumeOff_xs: tk.default,
            windows_xs: tE.default,
            adult_s: ty.default,
            album_s: tb.default,
            dislike_s: tw.default,
            disliked_s: tO.default,
            exclamation_s: tR.default,
            explicit_s: tj.default,
            likedVariant_s: th.default,
            note_s: tH.default,
            pauseVibe_s: tP.default,
            picture_s: tM.default,
            playVibe_s: tS.default,
            playlist_s: tL.default,
            collections_m: tC.default,
            collections_selected_m: tT.default,
            history_m: tD.default,
            home_m: tF.default,
            home_selected_m: tB.default,
            kids_m: tI.default,
            kids_selected_m: tA.default,
            like_m: tz.default,
            liked_m: tN.default,
            lock_m: tU.default,
            more_m: tV.default,
            non_music_m: tY.default,
            non_music_selected_m: tW.default,
            pause_m: tq.default,
            pause_filled_m: tG.default,
            play_m: tX.default,
            playQueue_m: tQ.default,
            play_filled_m: tZ.default,
            plusOutlined_m: tK.default,
            ruble_m: tJ.default,
            search_m: t$.default,
            search_selected_m: t0.default,
            speed_1_25x_centered_m: t1.default,
            speed_1_5x_centered_m: t8.default,
            speed_1_75x_centered_m: t22.default,
            speed_1x_centered_m: t9.default,
            speed_2x_centered_m: t3.default,
            syncLyrics_m: t5.default,
            ticket_m: t7.default,
            ticket_selected_m: t6.default,
            add_l: t4.default,
            album_l: re.default,
            download_l: rt.default,
            like_l: rr.default,
            pause_filled_l: rs.default,
            play_filled_l: rn.default,
            search_l: ra.default,
            speed_1_25x_l: ri.default,
            speed_1_5x_l: rl.default,
            speed_1_75x_l: ro.default,
            speed_1x_l: rc.default,
            speed_2x_l: ru.default,
            album_xl: rf.default,
            clip_xl: rx.default,
            note_xl: rd.default,
            pause_filled_xl: r_.default,
            picture_xl: rp.default,
            play_filled_xl: rv.default,
            playlist_xl: rg.default,
            unavailable_xl: rm.default,
            attention_xxl: rk.default,
            check_xxl: rE.default,
            next_xxl: ry.default,
            offline_xxl: rb.default,
            pause_filled_xxl: rw.default,
            play_filled_xxl: rO.default,
            previous_xxl: rR.default,
            search_xxl: rj.default,
            attention_xxxl: rh.default,
            bandlink: rH.default,
            booksLogo: rP.default,
            googlePlay: rM.default,
            huaweiAppGallery: rS.default,
            kinopoiskEn: rL.default,
            kinopoiskRu: rC.default,
            macos: rT.default,
            musicLogo: rD.default,
            musicLogoCenterEn: rF.default,
            musicLogoCenterRu: rB.default,
            musicLogoLeftEn: rI.default,
            musicLogoLeftRu: rA.default,
            plus: rz.default,
            plusBadge: rN.default,
            plusColor: rU.default,
            plusOutlined: rV.default,
            windows: rY.default,
            yandexBooksEn: rW.default,
            yandexBooksRu: rq.default,
            yandexPayEn: rG.default,
            yandexPayRu: rX.default,
            yandexPlusEn: rQ.default,
            yandexPlusRu: rZ.default
          };
        },
        7066: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Icon = void 0;
          var s2 = r2(5189);
          Object.defineProperty(t2, "Icon", {
            enumerable: true,
            get: function() {
              return s2.Icon;
            }
          });
        },
        3642: function(e2, t2, r2) {
          var s2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Input = void 0;
          let n2 = r2(4377), a2 = r2(5881), i2 = r2(810), l2 = r2(9110), o2 = s2(r2(9160)), c2 = (e3) => {
            let {
              containerClassName: t3,
              inputClassName: r3,
              actionsClassName: s3,
              icon: c3 = null,
              actions: u2 = null,
              disabled: f,
              forwardRef: x,
              value: d,
              size: _ = "xxxs",
              variant: p = "primary",
              ...v
            } = e3, g = (0, l2.useForwardRef)(x, null), m = (0, i2.useCallback)(() => {
              var e4;
              null == (e4 = g.current) || e4.focus();
            }, [g]);
            return (0, n2.jsxs)("div", {
              className: (0, a2.clsx)(
                o2.default.root,
                {
                  [o2.default.root_disabled]: f,
                  [o2.default["root_size_".concat(_)]]: _,
                  [o2.default["root_variant_".concat(p)]]: p
                },
                t3
              ),
              onClick: m,
              children: [
                c3,
                (0, n2.jsx)("input", {
                  className: (0, a2.clsx)(o2.default.input, r3, { [o2.default.textShadowing]: v.readOnly }),
                  ref: g,
                  value: d,
                  disabled: f,
                  ...v
                }),
                (0, n2.jsx)("div", { className: (0, a2.clsx)(o2.default.actions, s3), children: u2 })
              ]
            });
          };
          t2.Input = (0, i2.forwardRef)((e3, t3) => (0, n2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        3126: (e2, t2, r2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Input = void 0;
          var s2 = r2(3642);
          Object.defineProperty(t2, "Input", {
            enumerable: true,
            get: function() {
              return s2.Input;
            }
          });
        },
        3906: function(e2, t2, r2) {
          var s2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.SearchInput = void 0;
          let n2 = r2(4377), a2 = r2(5881), i2 = r2(810), l2 = r2(352), o2 = r2(3126), c2 = r2(7066), u2 = r2(5928), f = s2(r2(8532));
          t2.SearchInput = (e3) => {
            let {
              onChange: t3,
              placeholder: r3,
              initialValue: s3 = "",
              correctedValue: x,
              size: d = "xxxs",
              resetButtonAriaLabel: _ = "",
              disabled: p,
              autoFocus: v,
              shouldPreventAutoFocusScroll: g,
              onResetClick: m,
              className: k,
              innerInputProps: E,
              searchIconProps: y,
              resetButtonProps: b
            } = e3, [w, O] = (0, i2.useState)(s3), [R, j] = (0, i2.useState)(!!s3), h = (0, i2.useRef)(null), H = (0, i2.useMemo)(() => (0, l2.debounce)(t3, 500), [t3]);
            (0, i2.useEffect)(() => {
              if (v) {
                var e4;
                null == (e4 = h.current) || e4.focus({ preventScroll: g });
              }
            }, [v, g]);
            let P = (0, i2.useCallback)(
              (e4) => {
                let r4 = e4.length > 0;
                O(e4), H(e4), r4 ? (H(e4), j(true)) : (t3(e4), j(false));
              },
              [H, t3]
            ), M = (0, i2.useCallback)(
              (e4) => {
                P(e4.target.value);
              },
              [P]
            );
            (0, i2.useEffect)(() => {
              if (x) {
                var e4;
                P(x), null == (e4 = h.current) || e4.focus();
              }
            }, [P, x]);
            let S = (0, i2.useCallback)(() => {
              var e4;
              O(""), t3(""), j(false), null == m || m(), null == (e4 = h.current) || e4.focus();
            }, [t3, m]), L = (0, i2.useMemo)(
              () => (0, n2.jsx)(c2.Icon, {
                variant: "search",
                size: "xs",
                className: (0, a2.clsx)(f.default.searchIcon, { [f.default.searchIcon_disabled]: p }),
                ...y
              }),
              [p, y]
            ), C = (0, i2.useMemo)(
              () => (0, n2.jsx)(u2.Button, {
                radius: "round",
                className: (0, a2.clsx)(f.default.reset, { [f.default.reset_show]: R }),
                "aria-label": _,
                size: d,
                disabled: p,
                onClick: S,
                icon: (0, n2.jsx)(c2.Icon, { size: "xxs", variant: "close", color: "gray" }),
                ...b
              }),
              [R, _, d, p, S, b]
            );
            return (0, n2.jsx)(o2.Input, {
              ref: h,
              type: "search",
              containerClassName: (0, a2.clsx)(f.default.searchContainer, k),
              inputClassName: f.default.searchInput,
              icon: L,
              actions: C,
              onChange: M,
              value: w,
              size: d,
              disabled: p,
              placeholder: r3,
              ...E
            });
          };
        },
        352: (e2) => {
          e2.exports = n;
        },
        810: (e2) => {
          e2.exports = s || (s = r.t(a, 2));
        }
      }, l = {};
      function o(e2) {
        var t2 = l[e2];
        if (void 0 !== t2) return t2.exports;
        var r2 = l[e2] = { exports: {} };
        return i[e2].call(r2.exports, r2, r2.exports, o), r2.exports;
      }
      o.d = (e2, t2) => {
        for (var r2 in t2) o.o(t2, r2) && !o.o(e2, r2) && Object.defineProperty(e2, r2, { enumerable: true, get: t2[r2] });
      }, o.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), o.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var c = {};
      (() => {
        Object.defineProperty(c, "X", { value: true }), c.M = void 0;
        var e2 = o(3906);
        Object.defineProperty(c, "M", {
          enumerable: true,
          get: function() {
            return e2.SearchInput;
          }
        });
      })();
      var u = c.M;
      c.X;
    }
  }
]);
