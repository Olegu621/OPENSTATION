"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [9539],
  {
    9539: (e, t, r) => {
      r.d(t, { createClientContainer: () => ek });
      var n = r(89885), i = r(74338), s = r(9348), g = r(15209), o = r(21220), l = r(58900), u = r(79850), a = r(84690), c = r(34965), m = r(18258), d = r(36211), p = r(5892), A = r(40080), w = r(65099), U = r(81658), f = r(79817), h = r(88660), x = r(52962), R = r(96992), G = r(48448), E = r(93076), H = r(36788), L = r(35566), P = r(64659), _ = r(63988), T = r(37934), W = r(79329), B = r(12774), X = r(24252), v = r(29372), I = r(10582), y = r(13696), k = r(78226), b = r(94150), q = r(92103), C = r(3463), D = r(24120), M = r(55948), S = r(80535), N = r(38689), Z = r(50218), V = r(34720), Q = r(54280), $ = r(99676), K = r(86420), O = r(33716), j = r(30508), z = r(95198), Y = r(10560), F = r(74922), J = r(16068), ee = r(41778), et = r(29449), er = r(3327), en = r(87716), ei = r(42132), es = r(81760), eg = r(54924), eo = r(2936), el = r(40168), eu = r(12460), ea = r(98313), ec = r(25289), em = r(24269), ed = r(65630), ep = r(77508), eA = r(74875), ew = r(62901), eU = r(27493), ef = r(12979), eh = r(558), ex = r(96559);
      class eR {
        onChangeLanguage(e2) {
          if ("string" == typeof this.token && this.token.length > 0) {
            let t2 = "https://yandex.".concat(this.tld, "/portal/set/lang/"), r2 = encodeURIComponent(window.location.href), n2 = "".concat(t2, "?intl=").concat(e2, "&retpath=").concat(r2, "&sk=").concat(this.token);
            window.location.assign(n2);
          } else window.location.reload();
        }
        constructor(e2, t2) {
          (0, ex._)(this, "tld", void 0), (0, ex._)(this, "token", void 0), this.tld = e2, this.token = t2;
        }
      }
      var eG = r(59433), eE = r(90579), eH = r(37343), eL = r(90461), eP = r(78171), e_ = r(45628), eT = r(67454);
      let eW = /^application\/json(;\s?charset=\S+)?$/;
      class eB {
        async afterResponse(e2) {
          try {
            if (!e2.headers["content-range"] && e2.headers["content-type"] && eW.test(e2.headers["content-type"])) {
              let t2 = await e2.clone().json();
              if (((e3) => {
                if (e3 && "object" == typeof e3 && "type" in e3 && "captcha" === e3.type) {
                  let { captcha: t3 } = e3;
                  if (t3 && t3["captcha-page"]) return true;
                }
                return false;
              })(t2)) {
                let { captcha: e3 } = t2;
                window.location.replace(e3["captcha-page"]);
              }
            }
          } catch (e3) {
            e3 instanceof Error && this.logger.error(e3);
          }
          return e2;
        }
        beforeRequest(e2) {
          let t2 = window.location.href;
          ((e3) => {
            let t3;
            try {
              let r2 = e3.map((e4) => {
                let t4 = new URL(e4);
                return "".concat(t4.protocol).concat(t4.hostname.split(".").slice(-2).join("."));
              });
              t3 = r2.every((e4) => e4 === r2[0]);
            } catch (e4) {
              t3 = false;
            }
            return t3;
          })([t2, e2.url]) && (e2.headers.set("X-Requested-With", "XMLHttpRequest"), e2.headers.set("X-Retpath-Y", t2));
        }
        get afterResponseHook() {
          return this.afterResponse.bind(this);
        }
        get beforeRequestHook() {
          return this.beforeRequest.bind(this);
        }
        constructor(e2) {
          (0, ex._)(this, "logger", void 0), this.logger = e2;
        }
      }
      var eX = r(65098), ev = r(88246), eI = r(13871), ey = r(6556);
      async function ek(e2) {
        let {
          tld: t2,
          env: r2,
          serverDetectedLocale: ex2,
          changeLanguageToken: eW2,
          browserName: ek2,
          browserVersion: eb,
          executionContextStore: eq
        } = e2, eC = (0, ey.J)(await (0, ef.z)(r2)), eD = await (0, eU.B)(r2);
        return new l.Dt().registerMany({
          [eT.SX]: (0, l.Gr)(() => r2),
          [eT.tw]: (0, l.Gr)(() => eC),
          [eT.P0]: (0, l.Gr)(() => new o.q(eD)),
          [eT.Zi]: (0, l.Gr)(() => new eh.Y(eq))
        }).register(
          eT.WA,
          (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.Zi);
            return new e_.V(t3);
          })
        ).registerMany({
          [eT.Zf]: (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.P0).get(ew.qV);
            return new m.r({
              maxLogLevel: c.cm.DEBUG,
              secureFields: eH.x,
              disableLogToConsole: !t3,
              additionalData: {
                get puid() {
                  return e3.get(eT.WA).getPassportUid();
                }
              }
            });
          }),
          [eT.TK]: (0, l.Gr)(
            (e3) => new ((0, eE.b)(m.r))({
              maxLogLevel: c.cm.DEBUG,
              secureFields: eH.x,
              disableLogToConsole: "development" !== e3.get(eT.SX),
              additionalData: {
                get puid() {
                  return e3.get(eT.WA).getPassportUid();
                }
              }
            })
          ),
          [eT.oo]: (0, l.Gr)(() => new ea.V8()),
          [eT.DP]: (0, l.Gr)(() => new ea.V8()),
          [eT.U2]: (0, l.Gr)(() => new ea.si()),
          [eT.vH]: (0, l.Gr)(() => new ea.fW()),
          [eT.y$]: (0, l.Gr)(
            () => new eu.Mz({ config: { useEntitiesStorage: false, useFileStorage: false, useResponseCacheStorage: false } })
          ),
          [eT.Xc]: (0, l.Gr)((e3) => {
            let r3 = e3.get(eT.oo), n2 = e3.get(eT.Zf), { i18n: i2 } = e3.get(eT.tw), s2 = new Date(Date.now() + 24 * i2.cookieExpirationDays * 36e5);
            return new eG.E({
              serverDetectedLocale: ex2,
              logger: n2,
              changeLanguageHandler: new eR(t2, eW2),
              storage: {
                get: () => r3.get(eL.c.SavedUserLanguage, false),
                set(e4) {
                  r3.set(
                    eL.c.SavedUserLanguage,
                    e4,
                    { path: "/", domain: window.location.hostname, expires: s2, secure: true },
                    false
                  );
                }
              }
            });
          }),
          [eT.Hm]: (0, l.P9)(
            () => function() {
              let e3 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
              return new a.Q(e3);
            }
          ),
          [eT.gu]: (0, l.P9)(
            () => function() {
              let e3 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
              return new u.S(e3);
            }
          )
        }).registerMany({
          [eT.QG]: (0, l.Gr)((e3) => new ep.b(e3.get(eT.DP), e3.get(eT.tw), e3.get(eT.Xc).getLanguage(), e3.get(eT.WA))),
          [eT.OP]: (0, l.P9)(
            (e3) => function() {
              var t3, r3, n2, i2, s2, g2;
              let o2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, l2 = arguments.length > 1 ? arguments[1] : void 0, u2 = e3.get(eT.Zf), {
                resources: { musicExternalApi: a2 }
              } = e3.get(eT.tw), c2 = new eH.N(u2), m2 = new eB(u2);
              return o2.timeout = a2.defaultTimeout, o2.hooks = {
                afterResponse: [
                  m2.afterResponseHook,
                  ...(null == o2 || null == (t3 = o2.hooks) ? void 0 : t3.afterResponse) || []
                ],
                afterTimeout: [
                  c2.beforeErrorHook,
                  ...(null == o2 || null == (r3 = o2.hooks) ? void 0 : r3.afterTimeout) || []
                ],
                beforeError: [
                  c2.beforeErrorHook,
                  ...(null == o2 || null == (n2 = o2.hooks) ? void 0 : n2.beforeError) || []
                ],
                beforeRequest: [
                  ev.x,
                  m2.beforeRequestHook,
                  ...(null == o2 || null == (i2 = o2.hooks) ? void 0 : i2.beforeRequest) || []
                ],
                beforeRetry: [
                  eI.i,
                  c2.beforeRetryHook,
                  ...(null == o2 || null == (s2 = o2.hooks) ? void 0 : s2.beforeRetry) || []
                ],
                onRequestDone: [...(null == o2 || null == (g2 = o2.hooks) ? void 0 : g2.onRequestDone) || []]
              }, l2(o2);
            }
          )
        }).registerMany({
          [eT.A4]: (0, l.P9)(
            (e3) => function() {
              var r3;
              let n2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : e3.get(eT.OP), s2 = e3.get(eT.QG), { resources: o2 } = e3.get(eT.tw), l2 = i2({ credentials: "include" }, e3.get(eT.Hm)), { prefixUrl: u2, timeouts: a2, retryPolicyConfig: c2 } = o2.musicExternalApi, m2 = e3.get(eT.Xc).getLanguage(), d2 = new p.Q(l2, {
                prefixUrl: (0, g.getTldHost)(u2, t2, eP.B),
                retryPolicyConfig: c2,
                timeouts: a2.accountResource,
                params: {
                  common: {
                    client: (0, ed._)(),
                    language: m2,
                    get multiAuthUserId() {
                      return e3.get(eT.WA).getPassportUid();
                    }
                  }
                }
              });
              return n2.hooks = {
                beforeError: [
                  (0, eA.o)(s2, d2),
                  ...(null == n2 || null == (r3 = n2.hooks) ? void 0 : r3.beforeError) || []
                ]
              }, i2(n2, e3.get(eT.Hm));
            }
          ),
          [eT.KH]: (0, l.P9)(
            (e3) => function() {
              var t3, r3, n2, i2, s2, g2;
              let o2 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, l2 = e3.get(eT.Hm), u2 = e3.get(eT.Zf), {
                resources: { musicExternalApi: a2 }
              } = e3.get(eT.tw), c2 = new eH.N(u2);
              return o2.timeout = a2.defaultTimeout, o2.hooks = {
                afterResponse: [...(null == o2 || null == (t3 = o2.hooks) ? void 0 : t3.afterResponse) || []],
                afterTimeout: [
                  c2.beforeErrorHook,
                  ...(null == o2 || null == (r3 = o2.hooks) ? void 0 : r3.afterTimeout) || []
                ],
                beforeError: [
                  c2.beforeErrorHook,
                  ...(null == o2 || null == (n2 = o2.hooks) ? void 0 : n2.beforeError) || []
                ],
                beforeRequest: [ev.x, ...(null == o2 || null == (i2 = o2.hooks) ? void 0 : i2.beforeRequest) || []],
                beforeRetry: [
                  eI.i,
                  c2.beforeRetryHook,
                  ...(null == o2 || null == (s2 = o2.hooks) ? void 0 : s2.beforeRetry) || []
                ],
                onRequestDone: [...(null == o2 || null == (g2 = o2.hooks) ? void 0 : g2.onRequestDone) || []]
              }, l2(o2);
            }
          )
        }).register(
          eT.CR,
          (0, l.P9)(
            (e3) => function() {
              let t3 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
              return e3.get(eT.A4)(t3, e3.get(eT.gu));
            }
          )
        ).registerMany({
          [eT.$I]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new p.Q(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.accountResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT._1]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new A.d(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.usersResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.V3]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new w.G(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.landingResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.Lb]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new U.H(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.landing3Resource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.tz]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new f.B(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.landingResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.$8]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new h.w(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.libraryResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.Oo]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new x.L(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.tracksResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.$5]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new R._(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.availabilityResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.qT]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new G.v(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.getFileInfoResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.X4]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new E.a(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.topResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.O9]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new H.b(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.artistsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.E]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new L.V(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.slidesResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.wH]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new P.c(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.redAlertResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.ok]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new _.Z(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.rotorResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.yq]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new T.p(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.searchResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.NN]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new W.v(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.searchResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.qN]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new B.T(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.playlistResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.ro]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new X.e(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.playlistsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.nM]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new v.o(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.pinResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.Ut]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new I.$(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.metatagsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.K1]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new y.p(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.tagResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.eu]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new k.D(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.feedResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.aE]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new b.l(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.pinsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.ki]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new q.I(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.musicHistoryResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.c9]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new C.s(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.dynamicPagesResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.en]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new D.B(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.chartResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.jQ]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new M._(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.clipsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.cZ]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new S.c(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.lyricViewsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.Zl]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new N.D(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.nonMusicResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.CN]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new Z.N(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.donationResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.JM]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new V.c(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.streamsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.P1]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new Q.S(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.loaderResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.re]: (0, l.Gr)((e3) => {
            let { resources: t3 } = e3.get(eT.tw), { timeouts: r3, retryPolicyConfig: n2 } = t3.musicExternalApi, i2 = e3.get(eT.Xc).getLanguage(), s2 = e3.get(eT.KH)({ credentials: "omit" });
            return new $.s(s2, {
              prefixUrl: "",
              retryPolicyConfig: n2,
              timeouts: r3.prefixlessResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: i2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.Lk]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new K.g(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.filtersResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.he]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "omit" });
            return new O.K(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.offersResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.uM]: (0, l.Gr)((e3) => {
            var r3;
            let { acqOffers: i2, rumSettings: s2 } = e3.get(eT.tw), { brand: g2, service: o2, environment: l2, appVersion: u2 } = i2, { platform: a2, page: c2 } = s2, m2 = e3.get(eT.QG), d2 = e3.get(eT.Xc).getLanguage(), p2 = e3.get(eT.A4), A2 = m2.token || null, w2 = p2({ credentials: A2 ? "omit" : "include" }), { request_id: U2, puid: f2 } = null != (r3 = e3.get(eT.Zi).getStore()) ? r3 : {};
            return new n.mZ({
              brand: g2,
              service: o2,
              environment: l2,
              appVersion: u2,
              etld: "yandex.".concat(t2),
              platform: "Web",
              lang: d2,
              oAuthToken: A2,
              authMethod: A2 ? "oauth" : "default",
              requester: (0, eX.n)(w2),
              puid: (null == f2 ? void 0 : f2.toString()) || null,
              rumOptions: { platform: a2, page: c2, requestId: U2 }
            });
          }),
          [eT.$$]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new j.E(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.offersResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.sv]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new z.L(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.collectionResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.gd]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new Y.z(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.adsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.Ez]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new F.l(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.personalResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.N1]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new J.H(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.disclaimersResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.u2]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new ee.J(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.familyResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.TD]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new et.L(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.childrenLandingResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.wK]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new er.u(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.landingBlocksResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.dh]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new en.q(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.promoResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.LC]: (0, l.Gr)((e3) => {
            let { resources: t3, player: r3 } = e3.get(eT.tw), { timeouts: n2, retryPolicyConfig: i2 } = t3.musicExternalApi, s2 = e3.get(eT.CR)({ credentials: "include" });
            return new ei.g(s2, {
              prefixUrl: r3.telemetry.telemetryUrl,
              retryPolicyConfig: i2,
              timeouts: n2.telemetryResouce,
              params: { common: { client: (0, ed._)() } }
            });
          }),
          [eT.W5]: (0, l.Gr)((e3) => {
            let { resources: t3, player: r3 } = e3.get(eT.tw), { retryPolicyConfig: n2 } = t3.musicExternalApi, i2 = e3.get(eT.CR)({ credentials: "include" });
            return new es.N(i2, {
              prefixUrl: r3.telemetry.rumUrl,
              retryPolicyConfig: n2,
              params: { common: { client: (0, ed._)() } }
            });
          }),
          [eT.EN]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new eg._(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.afterTrackResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.PL]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new eo.w(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.labelsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.DT]: (0, l.Gr)((e3) => {
            let { resources: r3 } = e3.get(eT.tw), { prefixUrl: n2, timeouts: i2, retryPolicyConfig: s2 } = r3.musicExternalApi, o2 = e3.get(eT.Xc).getLanguage(), l2 = e3.get(eT.A4)({ credentials: "include" });
            return new el.O(l2, {
              prefixUrl: (0, g.getTldHost)(n2, t2, eP.B),
              retryPolicyConfig: s2,
              timeouts: i2.concertsResource,
              params: {
                common: {
                  client: (0, ed._)(),
                  language: o2,
                  get multiAuthUserId() {
                    return e3.get(eT.WA).getPassportUid();
                  }
                }
              }
            });
          }),
          [eT.vg]: (0, l.Gr)(() => (0, ec.a)())
        }).registerMany({
          [eT.UB]: (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.vg);
            return new d.B(t3);
          }),
          [eT.Tq]: (0, l.Gr)((e3) => {
            var t3;
            let r3 = e3.get(eT.W5);
            return (null == (t3 = window.Ya) ? void 0 : t3.Rum) ? new d.G((0, em.y)(), r3, window.Ya.Rum) : null;
          })
        }).register(
          eT.by,
          (0, l.Gr)((e3) => {
            let t3 = e3.get(eT.oo), r3 = e3.get(eT.Zf), n2 = (0, s.A)(), g2 = {
              info: {
                app_name: ek2 || "Browser",
                app_version: eb || "",
                title: "Browser ".concat(ek2),
                device_id: n2,
                type: i.bq.WEB
              },
              volumeGranularity: 20,
              get defaultVolume() {
                var o2;
                return null != (o2 = t3.get(eL.c.YmPlayerVolume)) ? o2 : void 0;
              }
            }, l2 = e3.get(eT.WA).getPassportUid(), u2 = e3.get(eT.QG);
            return new i.Jd({
              logger: r3,
              deviceConfig: g2,
              multiAuthUserId: l2,
              oauth: u2.token,
              ynisonConnectionConfig: eC.ynisonConnectionConfig,
              variables: { isShadow: true }
            });
          })
        );
      }
    }
  }
]);
