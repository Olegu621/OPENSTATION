(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [9618],
  {
    29406: (e) => {
      e.exports = {
        root: "SplashScreen_root__3jzFk",
        root_dark: "SplashScreen_root_dark__0OcZj",
        root_light: "SplashScreen_root_light__XAJTf",
        root_hidden: "SplashScreen_root_hidden__BO7tp",
        "fade-out": "SplashScreen_fade-out__uNMY4",
        video: "SplashScreen_video__wFSy5"
      };
    },
    39618: (e, o, r) => {
      "use strict";
      r.r(o), r.d(o, { default: () => u });
      var s = r(54486), t = r(50420), n = r(61910), a = r(62443), _ = r(98313), l = r(74125), c = r(29406), d = r.n(c), i = r(49124);
      let u = (e2) => {
        let { children: o2 } = e2, { state: r2, toggleTrue: c2 } = (0, a.e)(false), { state: u2, toggleTrue: h } = (0, a.e)(false), { getThemeFromStorage: p } = (0, l.QDo)(new _.si()), S = (0, n.useMemo)(() => {
          var e3;
          return null != (e3 = p()) ? e3 : (0, l.VDQ)();
        }, [p]), v = (0, n.useCallback)(
          (e3) => {
            let o3 = i.env.ASSET_PREFIX || "";
            return "".concat(o3, "/media/splash_screen/splash_screen_").concat(S, ".").concat(e3);
          },
          [S]
        ), m = (0, n.useMemo)(() => ({ isVisible: !r2 }), [r2]);
        return (0, s.jsxs)(l.nlO.Provider, {
          value: m,
          children: [
            !r2 && (0, s.jsx)("div", {
              className: (0, t.$)(d().root, d()["root_".concat(S)], { [d().root_hidden]: u2 }),
              onAnimationEnd: c2,
              children: (0, s.jsxs)("video", {
                className: d().video,
                autoPlay: true,
                muted: true,
                playsInline: true,
                onEnded: h,
                onError: c2,
                children: [
                  (0, s.jsx)("source", { src: v("webm"), type: "video/webm" }),
                  (0, s.jsx)("source", { src: v("mp4"), type: "video/mp4" })
                ]
              })
            }),
            o2
          ]
        });
      };
    }
  }
]);
