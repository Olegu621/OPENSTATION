(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [9618, 9753],
  {
    4561: (e, t, i) => {
      Promise.resolve().then(i.bind(i, 91165)), Promise.resolve().then(i.bind(i, 98944)), Promise.resolve().then(i.bind(i, 14342)), Promise.resolve().then(i.bind(i, 62662)), Promise.resolve().then(i.bind(i, 42520)), Promise.resolve().then(i.bind(i, 19781)), Promise.resolve().then(i.bind(i, 22329)), Promise.resolve().then(i.bind(i, 73488)), Promise.resolve().then(i.bind(i, 88495)), Promise.resolve().then(i.bind(i, 5594)), Promise.resolve().then(i.bind(i, 53376)), Promise.resolve().then(i.bind(i, 39618)), Promise.resolve().then(i.bind(i, 18259)), Promise.resolve().then(i.t.bind(i, 96598, 23)), Promise.resolve().then(i.bind(i, 46965)), Promise.resolve().then(i.bind(i, 8394)), Promise.resolve().then(i.bind(i, 3192)), Promise.resolve().then(i.bind(i, 7286)), Promise.resolve().then(i.bind(i, 60305)), Promise.resolve().then(i.bind(i, 47203)), Promise.resolve().then(i.bind(i, 34286)), Promise.resolve().then(i.bind(i, 224)), Promise.resolve().then(i.bind(i, 24449)), Promise.resolve().then(i.bind(i, 79893)), Promise.resolve().then(i.bind(i, 81789)), Promise.resolve().then(i.bind(i, 87466)), Promise.resolve().then(i.bind(i, 39034)), Promise.resolve().then(i.bind(i, 17917)), Promise.resolve().then(i.bind(i, 11337)), Promise.resolve().then(i.bind(i, 19683)), Promise.resolve().then(i.bind(i, 53779)), Promise.resolve().then(i.bind(i, 12359)), Promise.resolve().then(i.bind(i, 88564)), Promise.resolve().then(i.bind(i, 95639)), Promise.resolve().then(i.bind(i, 57630)), Promise.resolve().then(i.bind(i, 25342)), Promise.resolve().then(i.bind(i, 34028)), Promise.resolve().then(i.bind(i, 99564)), Promise.resolve().then(i.bind(i, 95348)), Promise.resolve().then(i.bind(i, 52347)), Promise.resolve().then(i.bind(i, 61015)), Promise.resolve().then(i.bind(i, 1771)), Promise.resolve().then(i.bind(i, 80043)), Promise.resolve().then(i.bind(i, 12235)), Promise.resolve().then(i.bind(i, 8941)), Promise.resolve().then(i.bind(i, 38433)), Promise.resolve().then(i.bind(i, 8732)), Promise.resolve().then(i.bind(i, 43369)), Promise.resolve().then(i.bind(i, 47564)), Promise.resolve().then(i.bind(i, 41017)), Promise.resolve().then(i.bind(i, 27252)), Promise.resolve().then(i.bind(i, 65286)), Promise.resolve().then(i.bind(i, 45198)), Promise.resolve().then(i.bind(i, 46814)), Promise.resolve().then(i.bind(i, 92508)), Promise.resolve().then(i.bind(i, 40126)), Promise.resolve().then(i.bind(i, 83726)), Promise.resolve().then(i.bind(i, 90410)), Promise.resolve().then(i.bind(i, 13246)), Promise.resolve().then(i.bind(i, 26040)), Promise.resolve().then(i.bind(i, 92446)), Promise.resolve().then(i.bind(i, 42593)), Promise.resolve().then(i.bind(i, 70570)), Promise.resolve().then(i.bind(i, 88416)), Promise.resolve().then(i.bind(i, 24174)), Promise.resolve().then(i.bind(i, 78458)), Promise.resolve().then(i.bind(i, 59457)), Promise.resolve().then(i.bind(i, 6690)), Promise.resolve().then(i.bind(i, 88370)), Promise.resolve().then(i.bind(i, 66904)), Promise.resolve().then(i.bind(i, 39937)), Promise.resolve().then(i.bind(i, 33019)), Promise.resolve().then(i.bind(i, 38808)), Promise.resolve().then(i.bind(i, 58094)), Promise.resolve().then(i.bind(i, 78009)), Promise.resolve().then(i.bind(i, 33427)), Promise.resolve().then(i.bind(i, 30878)), Promise.resolve().then(i.bind(i, 53115)), Promise.resolve().then(i.bind(i, 52398)), Promise.resolve().then(i.bind(i, 82327)), Promise.resolve().then(i.bind(i, 17012)), Promise.resolve().then(i.bind(i, 9275)), Promise.resolve().then(i.bind(i, 17658)), Promise.resolve().then(i.bind(i, 36578)), Promise.resolve().then(i.bind(i, 66989)), Promise.resolve().then(i.bind(i, 58863)), Promise.resolve().then(i.bind(i, 60899)), Promise.resolve().then(i.bind(i, 59437)), Promise.resolve().then(i.bind(i, 43367)), Promise.resolve().then(i.bind(i, 66446)), Promise.resolve().then(i.bind(i, 86840)), Promise.resolve().then(i.bind(i, 75181)), Promise.resolve().then(i.bind(i, 99538)), Promise.resolve().then(i.bind(i, 45252)), Promise.resolve().then(i.bind(i, 59226)), Promise.resolve().then(i.bind(i, 75961)), Promise.resolve().then(i.bind(i, 33964)), Promise.resolve().then(i.bind(i, 33967)), Promise.resolve().then(i.bind(i, 64410)), Promise.resolve().then(i.bind(i, 91350)), Promise.resolve().then(i.bind(i, 4500)), Promise.resolve().then(i.bind(i, 55846)), Promise.resolve().then(i.bind(i, 65689)), Promise.resolve().then(i.bind(i, 99386)), Promise.resolve().then(i.bind(i, 5222)), Promise.resolve().then(i.bind(i, 60440)), Promise.resolve().then(i.bind(i, 37271)), Promise.resolve().then(i.bind(i, 66688)), Promise.resolve().then(i.bind(i, 76472)), Promise.resolve().then(i.bind(i, 65034));
    },
    5693: (e, t, i) => {
      "use strict";
      var s;
      i.d(t, { R: () => s }), (function(e2) {
        e2.Music = "music", e2.DownloadedMusic = "downloadedMusic", e2.VibeTrack = "vibeTrack", e2.Generative = "generative", e2.Unknown = "unknown", e2.SmartPreview = "smartPreview", e2.Clip = "clip", e2.Radio = "fm_radio";
      })(s || (s = {}));
    },
    12744: (e) => {
      e.exports = {
        root: "Slider_root__T7EOX",
        root_visible: "Slider_root_visible__b3Kqx",
        fade: "Slider_fade__V7FGV",
        container: "Slider_container__tZ0VH"
      };
    },
    16605: (e) => {
      e.exports = {
        root: "SliderControls_root__v_ofj",
        control: "SliderControls_control__E3joM",
        top: "SliderControls_top__HN5gZ"
      };
    },
    27820: (e) => {
      e.exports = {
        root: "SlidesPage_root__URM_B",
        header: "SlidesPage_header__pnBx9",
        slidesResult: "SlidesPage_slidesResult__neqIE",
        counterActiveItem: "SlidesPage_counterActiveItem__Y_K9I",
        counterItem: "SlidesPage_counterItem__3CqZW",
        button: "SlidesPage_button__s9V8y",
        volumeButton: "SlidesPage_volumeButton__HfFCM",
        desktopBackButton: "SlidesPage_desktopBackButton__ae1Uj",
        mobileBackButton: "SlidesPage_mobileBackButton__MwOgB"
      };
    },
    29406: (e) => {
      e.exports = {
        root: "SplashScreen_root__3jzFk",
        root_dark: "SplashScreen_root_dark__0OcZj",
        root_light: "SplashScreen_root_light__XAJTf",
        root_hidden: "SplashScreen_root_hidden__BO7tp",
        "fade-out": "SplashScreen_fade-out__uNMY4",
        video: "SplashScreen_video__wFSy5"
      };
    },
    31144: (e) => {
      e.exports = { root: "Slide_root__x5JEM", root_isActive: "Slide_root_isActive__CKUSv" };
    },
    31905: (e, t, i) => {
      "use strict";
      var s;
      i.d(t, { L: () => s }), (function(e2) {
        e2.PUBLIC = "public", e2.PRIVATE = "private";
      })(s || (s = {}));
    },
    39618: (e, t, i) => {
      "use strict";
      i.r(t), i.d(t, { default: () => c });
      var s = i(54486), n = i(50420), o = i(61910), r = i(62443), a = i(98313), l = i(74125), d = i(29406), u = i.n(d), h = i(49124);
      let c = (e2) => {
        let { children: t2 } = e2, { state: i2, toggleTrue: d2 } = (0, r.e)(false), { state: c2, toggleTrue: m } = (0, r.e)(false), { getThemeFromStorage: v } = (0, l.QDo)(new a.si()), p = (0, o.useMemo)(() => {
          var e3;
          return null != (e3 = v()) ? e3 : (0, l.VDQ)();
        }, [v]), b = (0, o.useCallback)(
          (e3) => {
            let t3 = h.env.ASSET_PREFIX || "";
            return "".concat(t3, "/media/splash_screen/splash_screen_").concat(p, ".").concat(e3);
          },
          [p]
        ), P = (0, o.useMemo)(() => ({ isVisible: !i2 }), [i2]);
        return (0, s.jsxs)(l.nlO.Provider, {
          value: P,
          children: [
            !i2 && (0, s.jsx)("div", {
              className: (0, n.$)(u().root, u()["root_".concat(p)], { [u().root_hidden]: c2 }),
              onAnimationEnd: d2,
              children: (0, s.jsxs)("video", {
                className: u().video,
                autoPlay: true,
                muted: true,
                playsInline: true,
                onEnded: m,
                onError: d2,
                children: [
                  (0, s.jsx)("source", { src: b("webm"), type: "video/webm" }),
                  (0, s.jsx)("source", { src: b("mp4"), type: "video/mp4" })
                ]
              })
            }),
            t2
          ]
        });
      };
    },
    42520: (e, t, i) => {
      "use strict";
      let s;
      i.d(t, { useMetrika: () => r });
      var n = i(61910), o = i(80506);
      let r = () => {
        let e2 = (s || (s = (0, o.a)()), s), t2 = (0, n.useSyncExternalStore)(e2.isLoaded.onChange, () => e2.isLoaded.value);
        return (0, n.useMemo)(() => ({ ...e2, isLoaded: t2 }), [t2]);
      };
    },
    46965: (e, t, i) => {
      "use strict";
      i.d(t, { SlidesPage: () => M });
      var s = i(54486), n = i(50420), o = i(28303), r = i(97396), a = i(61910), l = i(43426), d = i(47713), u = i(43350), h = i(31500), c = i(8817), m = i(77881), v = i(5956), p = i(39610), b = i(97800), P = i(89461), S = i(91657), g = i(36553), f = i(62443), _ = i(74125), x = i(16605), V = i.n(x);
      let E = (e2) => {
        let { isFirstSlide: t2, isLastSlide: i2, style: n2 } = e2, o2 = (0, g.Mn)(), { formatMessage: r2 } = (0, l.A)(), d2 = (0, a.useCallback)(() => {
          o2.slidePrev();
        }, [o2]), u2 = (0, a.useCallback)(() => {
          o2.slideNext();
        }, [o2]);
        return (0, s.jsxs)("div", {
          className: V().root,
          style: n2,
          children: [
            (0, s.jsx)(m.$, {
              variant: "outline",
              iconClassName: V().top,
              size: "m",
              radius: "round",
              onClick: d2,
              disabled: t2,
              icon: (0, s.jsx)(v.Icon, { variant: "arrowDown", size: "xxs" }, "prevIcon"),
              withRipple: false,
              "aria-label": r2({ id: "slider.prev-slide" }),
              className: V().control
            }),
            (0, s.jsx)(m.$, {
              variant: "outline",
              size: "m",
              radius: "round",
              onClick: u2,
              disabled: i2,
              icon: (0, s.jsx)(v.Icon, { variant: "arrowDown", size: "xxs" }, "nextIcon"),
              withRipple: false,
              "aria-label": r2({ id: "slider.next-slide" }),
              className: V().control
            })
          ]
        });
      };
      var I = i(63585), k = i(77710), y = i(6971), w = i(92830), A = i(31144), j = i.n(A);
      let C = (e2) => {
        var t2;
        let { slide: i2, isVisible: o2 } = e2, { ref: r2, intersectionPropertyId: l2 } = (0, _.nMI)(), d2 = (0, _.eGp)(), { from: u2 } = (0, _.fyy)({ pageId: _._Q$.TRAILER_OF_THE_YEAR, blockId: _.UfI.DEFAULT }), h2 = (0, _.brA)(), { isActive: c2 } = (0, g.JO)(), m2 = null == d2 ? void 0 : d2.getState(_.V_r.TRAILER).queueState.entityList.value, v2 = (0, a.useMemo)(
          () => i2.entitiesData && m2 && i2.entitiesData.every((e3, t3) => {
            var i3;
            return e3.meta.id === (null == (i3 = m2[t3]) ? void 0 : i3.entity.data.meta.id);
          }),
          [i2.entitiesData, m2]
        ), p2 = o2 && i2.hasTrailer && (!v2 || (null == d2 ? void 0 : d2.getState(_.V_r.TRAILER).playerState.status.value) !== P.MT.PLAYING), b2 = p2 && (null == d2 || null == (t2 = d2.getState(_.V_r.TRAILER).currentContext.value) ? void 0 : t2.data.meta.id) === i2.id;
        return (0, a.useEffect)(() => {
          if (b2)
            return void d2.restartContext(
              { playAfterRestart: true, queueParams: { index: 0 }, entitiesData: i2.entitiesData },
              _.V_r.TRAILER
            ).then(() => {
              h2(true);
            });
          p2 && (null == d2 || d2.playContext(
            {
              contextData: {
                type: I.K.Various,
                overrideContextType: k.b.Other,
                trailer: true,
                meta: { id: i2.id },
                from: u2
              },
              queueParams: { index: 0 },
              entitiesData: i2.entitiesData,
              loadContextMeta: false
            },
            _.V_r.TRAILER
          ).then(() => {
            h2(true);
          }));
        }, [u2, h2, p2, b2, i2.entitiesData, i2.id, d2]), (0, s.jsx)(y.Paper, {
          className: (0, n.$)(j().root, { [j().root_isActive]: c2 }),
          radius: "l",
          tabIndex: 0,
          "data-intersection-property-id": l2,
          ref: r2,
          children: (0, s.jsx)(w.AR, { slide: i2, isActive: c2 })
        });
      };
      var T = i(12744), F = i.n(T);
      let L = (0, o.PA)((e2) => {
        let { items: t2 } = e2, {
          settings: { isMobile: i2 },
          slides: o2
        } = (0, _.Pjs)(), { formatMessage: r2 } = (0, l.A)(), { state: d2, toggleTrue: h2 } = (0, f.e)(false), c2 = (0, g.Mn)(), m2 = (0, _.fBs)(), v2 = (0, a.useRef)(false), [p2, b2] = (0, a.useState)(true), [P2, x2] = (0, a.useState)(false);
        (0, a.useEffect)(
          () => (h2(), () => {
            null == c2 || c2.slideTo(0), o2.setActiveSlide(0);
          }),
          [h2, c2, o2]
        ), (0, a.useEffect)(() => {
          o2.isLoaded && !v2.current && (m2(), v2.current = true);
        }, [o2.isLoaded, m2]);
        let V2 = (0, a.useCallback)(
          (e3) => {
            b2(e3.isBeginning), x2(e3.isEnd), o2.setActiveSlide(e3.activeIndex);
          },
          [o2]
        );
        return (0, s.jsx)("div", {
          className: (0, n.$)(F().root, { [F().root_visible]: d2 }),
          children: (0, s.jsxs)(g.RC, {
            direction: "vertical",
            centeredSlides: !i2,
            slidesPerView: "auto",
            spaceBetween: 16,
            className: F().container,
            keyboard: { enabled: true },
            modules: [S.s3, S.Jq, S.FJ],
            onActiveIndexChange: V2,
            a11y: { enabled: true, containerMessage: r2({ id: "page.results-of-the-year" }) },
            mousewheel: { thresholdDelta: 30, thresholdTime: 500 },
            children: [
              t2.map((e3, i3) => {
                var n2, r3;
                return (0, s.jsx)(
                  g.qr,
                  {
                    children: (0, s.jsx)(_.FoH, {
                      blockPosX: 1,
                      blockPosY: i3 + 1,
                      blockType: null == (n2 = e3.content) ? void 0 : n2.type,
                      blockId: e3.id,
                      mainObjectId: o2.mainObjectId,
                      mainObjectType: u.ky.Slide,
                      children: (0, s.jsx)(_.Bki, {
                        objectType: u.ky.SlideContent,
                        objectId: "",
                        objectPosX: (null != (r3 = e3.carouselIndex) ? r3 : 0) + 1,
                        objectPosY: 1,
                        objectsCount: t2.length,
                        children: (0, s.jsx)(C, { isVisible: o2.activeSlide === i3, slide: e3 })
                      })
                    })
                  },
                  e3.id
                );
              }),
              (0, s.jsx)(E, { isFirstSlide: p2, isLastSlide: P2 })
            ]
          })
        });
      });
      var N = i(27820), R = i.n(N);
      function D(e2, t2) {
        return (e2 === _.GuX.RESOLVE || e2 === _.GuX.REJECT) && 0 === t2.length;
      }
      let M = (0, o.PA)((e2) => {
        var t2;
        let { slidesConsumer: i2, artistId: o2, podcastId: S2, campaignId: g2 } = e2, { formatMessage: f2 } = (0, l.A)(), { slides: x2, experiments: V2, sonataState: E2, settings: I2 } = (0, _.Pjs)(), k2 = (0, _.eGp)(), y2 = V2.checkExperiment(_.zal.WebNextSlidesPage, "on"), A2 = !(null == (t2 = I2.browserInfo) ? void 0 : t2.isMobile) || !I2.browserInfo.isTouch, j2 = null == k2 ? void 0 : k2.getState(_.V_r.TRAILER), C2 = (0, c.c)((e3) => {
          null == k2 || k2.setExponentVolume(e3, _.V_r.TRAILER);
        });
        (0, a.useEffect)(() => {
          C2(1), x2.setIsMuted(false);
        }, [C2, x2, k2]);
        let { canBack: T2, moveBack: F2 } = (0, _.JD0)(_.Zyd.main.href), N2 = (0, _.ZpR)(_.Zyd.main.href);
        (0, a.useEffect)(
          () => () => {
            x2.resetUser(), x2.resetArtist(), x2.resetPodcast(), x2.resetSpecial(), x2.resetKids(), null == k2 || k2.pause(_.V_r.TRAILER);
          },
          [x2, k2]
        ), y2 || (0, r.notFound)();
        let M2 = (0, _.zxo)(x2.mainObjectId);
        (0, a.useEffect)(() => {
          E2.status === P.MT.PLAYING && (null == k2 || k2.togglePause());
        }, [k2, E2.status]), (0, a.useEffect)(
          () => (M2(true), () => {
            M2(false);
          }),
          [M2]
        );
        let z = (0, a.useMemo)(() => {
          switch (i2) {
            case w.z6.USER:
              return x2.userItems;
            case w.z6.ARTIST:
              return x2.artistItems;
            case w.z6.PODCAST:
              return x2.podcastItems;
            case w.z6.SPECIAL:
              return x2.specialItems;
            case w.z6.KIDS:
              return x2.kidsItems;
          }
        }, [x2.artistItems, x2.kidsItems, x2.podcastItems, x2.specialItems, x2.userItems, i2]);
        (0, a.useEffect)(() => {
          if (y2)
            switch (i2) {
              case w.z6.USER:
                D(x2.userSlidesLoadingState, z) && (0, r.notFound)();
                break;
              case w.z6.ARTIST:
                D(x2.artistSlidesLoadingState, z) && (0, r.notFound)();
                break;
              case w.z6.PODCAST:
                D(x2.podcastSlidesLoadingState, z) && (0, r.notFound)();
                break;
              case w.z6.SPECIAL:
                D(x2.specialSlidesLoadingState, z) && (0, r.notFound)();
                break;
              case w.z6.KIDS:
                D(x2.kidsSlidesLoadingState, z) && (0, r.notFound)();
            }
          else (0, r.notFound)();
        }, [
          V2,
          y2,
          z,
          z.length,
          x2.artistSlidesLoadingState,
          x2.podcastSlidesLoadingState,
          x2.userSlidesLoadingState,
          x2.specialSlidesLoadingState,
          i2,
          x2.kidsSlidesLoadingState
        ]), (0, _.NBO)(true);
        let O = (0, a.useMemo)(() => {
          var e3;
          let t3, i3 = null == (e3 = z[x2.activeSlide]) ? void 0 : e3.slideColor;
          if (i3) {
            let { r: e4, g: s2, b: n2 } = (0, _.E2N)(i3);
            t3 = "rgba(".concat(e4, ", ").concat(s2, ", ").concat(n2, ", 0.5)");
          }
          return { "--card-color-enabled_variant": i3, "--card-color-enabled": t3, "--logo-color": i3 };
        }, [z, z.length, x2.activeSlide]), B = (0, a.useCallback)(() => {
          x2.toggleMute(), (null == j2 ? void 0 : j2.playerState.exponentVolume.value) !== 0 ? C2(0) : C2(1);
        }, [C2, x2, null == j2 ? void 0 : j2.playerState.exponentVolume.value]), G = (0, c.c)(() => {
          T2 ? F2() : N2();
        }), U = x2.isMuted ? "volumeOff" : "volume", Y = f2(x2.isMuted ? { id: "player-actions.volume-off" } : { id: "player-actions.volume-on" });
        switch (i2) {
          case w.z6.USER:
            x2.userSlidesLoadingState === _.GuX.IDLE && (0, a.use)(x2.getUserSlides());
            break;
          case w.z6.ARTIST:
            o2 && x2.artistSlidesLoadingState === _.GuX.IDLE && (0, a.use)(x2.getArtistSlides({ artistId: o2 }));
            break;
          case w.z6.PODCAST:
            S2 && x2.podcastSlidesLoadingState === _.GuX.IDLE && (0, a.use)(x2.getPodcastSlides({ podcastId: Number(S2) }));
            break;
          case w.z6.SPECIAL:
            g2 && x2.specialSlidesLoadingState === _.GuX.IDLE && (0, a.use)(x2.getSpecialSlides({ campaignId: g2 }));
            break;
          case w.z6.KIDS:
            x2.kidsSlidesLoadingState === _.GuX.IDLE && (0, a.use)(x2.getKidsSlides());
        }
        return (0, s.jsx)(_.jPc, {
          children: (0, s.jsx)(_.nVz, {
            pageId: _._Q$.SLIDES_SCREEN,
            children: (0, s.jsxs)("div", {
              className: R().root,
              style: O,
              ...(0, h.Am)(h.Xk.slides.SLIDES_PAGE),
              children: [
                (0, s.jsx)(p.q, {
                  children: (0, s.jsx)(b.Heading, {
                    variant: "h1",
                    children: (0, s.jsx)(d.A, { id: "page.results-of-the-year" })
                  })
                }),
                (0, s.jsxs)("header", {
                  className: R().header,
                  children: [
                    (null == z ? void 0 : z.length) > 0 && (0, s.jsxs)("div", {
                      className: R().slidesResult,
                      children: [
                        (0, s.jsx)(b.Caption, {
                          variant: "span",
                          className: R().counterActiveItem,
                          type: "text",
                          size: "l",
                          weight: "medium",
                          children: Number(x2.activeSlide) + 1
                        }),
                        (0, s.jsx)(b.Caption, {
                          variant: "span",
                          type: "text",
                          size: "l",
                          weight: "medium",
                          className: R().counterItem,
                          children: "/"
                        }),
                        (0, s.jsx)(b.Caption, {
                          variant: "span",
                          type: "text",
                          size: "l",
                          weight: "medium",
                          className: R().counterItem,
                          children: null == z ? void 0 : z.length
                        })
                      ]
                    }),
                    A2 && (0, s.jsx)(m.$, {
                      "aria-label": Y,
                      variant: "text",
                      radius: "round",
                      size: "xxxs",
                      icon: (0, s.jsx)(v.Icon, { size: "xs", className: R().icon, variant: U }),
                      onClick: B,
                      className: (0, n.$)(R().button, R().volumeButton),
                      withRipple: false
                    }),
                    (0, s.jsx)(m.$, {
                      "aria-label": f2({ id: "navigation.go-back" }),
                      radius: "round",
                      size: "xs",
                      icon: (0, s.jsx)(v.Icon, { size: "xs", variant: "close" }, "handleBackIcon"),
                      onClick: G,
                      className: (0, n.$)(R().button, R().desktopBackButton),
                      role: "link"
                    }),
                    (0, s.jsx)(m.$, {
                      variant: "text",
                      "aria-label": f2({ id: "navigation.go-back" }),
                      radius: "round",
                      size: "xs",
                      icon: (0, s.jsx)(v.Icon, { size: "xs", variant: "arrowLeft" }, "handleBackIcon"),
                      onClick: G,
                      className: (0, n.$)(R().button, R().mobileBackButton),
                      role: "link"
                    })
                  ]
                }),
                (0, s.jsx)(_.FoH, {
                  mainObjectType: u.ky.Slide,
                  mainObjectId: x2.mainObjectId,
                  blockType: u.ky.Slide,
                  blockId: x2.mainObjectId,
                  blockPosX: 1,
                  blockPosY: 1,
                  objectsCount: z.length,
                  children: (0, s.jsx)(L, { items: z })
                })
              ]
            })
          })
        });
      });
    },
    70837: (e, t, i) => {
      "use strict";
      i.d(t, { T: () => n });
      var s = function() {
        return (s = Object.assign || function(e2) {
          for (var t2, i2 = 1, s2 = arguments.length; i2 < s2; i2++)
            for (var n2 in t2 = arguments[i2]) Object.prototype.hasOwnProperty.call(t2, n2) && (e2[n2] = t2[n2]);
          return e2;
        }).apply(this, arguments);
      }, n = (function() {
        function e2(e3, t2, i2) {
          var n2 = this;
          this.endVal = t2, this.options = i2, this.version = "2.8.1", this.defaults = {
            startVal: 0,
            decimalPlaces: 0,
            duration: 2,
            useEasing: true,
            useGrouping: true,
            useIndianSeparators: false,
            smartEasingThreshold: 999,
            smartEasingAmount: 333,
            separator: ",",
            decimal: ".",
            prefix: "",
            suffix: "",
            enableScrollSpy: false,
            scrollSpyDelay: 200,
            scrollSpyOnce: false
          }, this.finalEndVal = null, this.useEasing = true, this.countDown = false, this.error = "", this.startVal = 0, this.paused = true, this.once = false, this.count = function(e4) {
            n2.startTime || (n2.startTime = e4);
            var t3 = e4 - n2.startTime;
            n2.remaining = n2.duration - t3, n2.useEasing ? n2.countDown ? n2.frameVal = n2.startVal - n2.easingFn(t3, 0, n2.startVal - n2.endVal, n2.duration) : n2.frameVal = n2.easingFn(t3, n2.startVal, n2.endVal - n2.startVal, n2.duration) : n2.frameVal = n2.startVal + (n2.endVal - n2.startVal) * (t3 / n2.duration);
            var i3 = n2.countDown ? n2.frameVal < n2.endVal : n2.frameVal > n2.endVal;
            n2.frameVal = i3 ? n2.endVal : n2.frameVal, n2.frameVal = Number(n2.frameVal.toFixed(n2.options.decimalPlaces)), n2.printValue(n2.frameVal), t3 < n2.duration ? n2.rAF = requestAnimationFrame(n2.count) : null !== n2.finalEndVal ? n2.update(n2.finalEndVal) : n2.options.onCompleteCallback && n2.options.onCompleteCallback();
          }, this.formatNumber = function(e4) {
            var t3, i3, s2, o = (Math.abs(e4).toFixed(n2.options.decimalPlaces) + "").split(".");
            if (t3 = o[0], i3 = o.length > 1 ? n2.options.decimal + o[1] : "", n2.options.useGrouping) {
              s2 = "";
              for (var r = 3, a = 0, l = 0, d = t3.length; l < d; ++l)
                n2.options.useIndianSeparators && 4 === l && (r = 2, a = 1), 0 !== l && a % r == 0 && (s2 = n2.options.separator + s2), a++, s2 = t3[d - l - 1] + s2;
              t3 = s2;
            }
            return n2.options.numerals && n2.options.numerals.length && (t3 = t3.replace(/[0-9]/g, function(e5) {
              return n2.options.numerals[+e5];
            }), i3 = i3.replace(/[0-9]/g, function(e5) {
              return n2.options.numerals[+e5];
            })), (e4 < 0 ? "-" : "") + n2.options.prefix + t3 + i3 + n2.options.suffix;
          }, this.easeOutExpo = function(e4, t3, i3, s2) {
            return i3 * (1 - Math.pow(2, -10 * e4 / s2)) * 1024 / 1023 + t3;
          }, this.options = s(s({}, this.defaults), i2), this.formattingFn = this.options.formattingFn ? this.options.formattingFn : this.formatNumber, this.easingFn = this.options.easingFn ? this.options.easingFn : this.easeOutExpo, this.startVal = this.validateValue(this.options.startVal), this.frameVal = this.startVal, this.endVal = this.validateValue(t2), this.options.decimalPlaces = Math.max(this.options.decimalPlaces), this.resetDuration(), this.options.separator = String(this.options.separator), this.useEasing = this.options.useEasing, "" === this.options.separator && (this.options.useGrouping = false), this.el = "string" == typeof e3 ? document.getElementById(e3) : e3, this.el ? this.printValue(this.startVal) : this.error = "[CountUp] target is null or undefined", "undefined" != typeof window && this.options.enableScrollSpy && (this.error ? console.error(this.error, e3) : (window.onScrollFns = window.onScrollFns || [], window.onScrollFns.push(function() {
            return n2.handleScroll(n2);
          }), window.onscroll = function() {
            window.onScrollFns.forEach(function(e4) {
              return e4();
            });
          }, this.handleScroll(this)));
        }
        return e2.prototype.handleScroll = function(e3) {
          if (e3 && window && !e3.once) {
            var t2 = window.innerHeight + window.scrollY, i2 = e3.el.getBoundingClientRect(), s2 = i2.top + window.pageYOffset, n2 = i2.top + i2.height + window.pageYOffset;
            n2 < t2 && n2 > window.scrollY && e3.paused ? (e3.paused = false, setTimeout(function() {
              return e3.start();
            }, e3.options.scrollSpyDelay), e3.options.scrollSpyOnce && (e3.once = true)) : (window.scrollY > n2 || s2 > t2) && !e3.paused && e3.reset();
          }
        }, e2.prototype.determineDirectionAndSmartEasing = function() {
          var e3 = this.finalEndVal ? this.finalEndVal : this.endVal;
          if (this.countDown = this.startVal > e3, Math.abs(e3 - this.startVal) > this.options.smartEasingThreshold && this.options.useEasing) {
            this.finalEndVal = e3;
            var t2 = this.countDown ? 1 : -1;
            this.endVal = e3 + t2 * this.options.smartEasingAmount, this.duration = this.duration / 2;
          } else this.endVal = e3, this.finalEndVal = null;
          null !== this.finalEndVal ? this.useEasing = false : this.useEasing = this.options.useEasing;
        }, e2.prototype.start = function(e3) {
          this.error || (this.options.onStartCallback && this.options.onStartCallback(), e3 && (this.options.onCompleteCallback = e3), this.duration > 0 ? (this.determineDirectionAndSmartEasing(), this.paused = false, this.rAF = requestAnimationFrame(this.count)) : this.printValue(this.endVal));
        }, e2.prototype.pauseResume = function() {
          this.paused ? (this.startTime = null, this.duration = this.remaining, this.startVal = this.frameVal, this.determineDirectionAndSmartEasing(), this.rAF = requestAnimationFrame(this.count)) : cancelAnimationFrame(this.rAF), this.paused = !this.paused;
        }, e2.prototype.reset = function() {
          cancelAnimationFrame(this.rAF), this.paused = true, this.resetDuration(), this.startVal = this.validateValue(this.options.startVal), this.frameVal = this.startVal, this.printValue(this.startVal);
        }, e2.prototype.update = function(e3) {
          cancelAnimationFrame(this.rAF), this.startTime = null, this.endVal = this.validateValue(e3), this.endVal !== this.frameVal && (this.startVal = this.frameVal, null == this.finalEndVal && this.resetDuration(), this.finalEndVal = null, this.determineDirectionAndSmartEasing(), this.rAF = requestAnimationFrame(this.count));
        }, e2.prototype.printValue = function(e3) {
          var t2;
          if (this.el) {
            var i2 = this.formattingFn(e3);
            (null == (t2 = this.options.plugin) ? void 0 : t2.render) ? this.options.plugin.render(this.el, i2) : "INPUT" === this.el.tagName ? this.el.value = i2 : "text" === this.el.tagName || "tspan" === this.el.tagName ? this.el.textContent = i2 : this.el.innerHTML = i2;
          }
        }, e2.prototype.ensureNumber = function(e3) {
          return "number" == typeof e3 && !isNaN(e3);
        }, e2.prototype.validateValue = function(e3) {
          var t2 = Number(e3);
          return this.ensureNumber(t2) ? t2 : (this.error = "[CountUp] invalid start or end value: ".concat(e3), null);
        }, e2.prototype.resetDuration = function() {
          this.startTime = null, this.duration = 1e3 * Number(this.options.duration), this.remaining = this.duration;
        }, e2;
      })();
    },
    77710: (e, t, i) => {
      "use strict";
      var s;
      i.d(t, { b: () => s }), (function(e2) {
        e2.Album = "album", e2.Artist = "artist", e2.Playlist = "playlist", e2.Radio = "fm_radio", e2.Other = "other", e2.Search = "search";
      })(s || (s = {}));
    },
    80506: (e, t, i) => {
      "use strict";
      i.d(t, { a: () => n });
      var s = i(87965);
      let n = () => {
        let e2 = null, t2 = new s.cJ(false), i2 = [];
        return {
          isLoaded: t2,
          init: (s2) => {
            var n2, o;
            if (void 0 !== (null == (n2 = window.Ya) ? void 0 : n2.Metrika2) && !t2.value)
              try {
                e2 = new window.Ya.Metrika2({ ...s2 }), t2.value = true, o = e2, i2.forEach((e3) => {
                  e3(o);
                }), i2.length = 0;
              } catch (e3) {
                ("string" == typeof e3 || e3 instanceof Error) && s2.logger.error(e3);
              }
          },
          count: function(t3) {
            let s2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "counter";
            e2 ? e2.params({ [s2]: t3 }) : i2.push((e3) => {
              e3.params({ [s2]: t3 });
            });
          },
          hit: (t3) => {
            e2 ? e2.hit(t3) : i2.push((e3) => {
              e3.hit(t3);
            });
          },
          reachGoal: (t3, s2) => {
            if (!e2) return void i2.push((e3) => e3.reachGoal(t3, s2));
            e2.reachGoal(t3, s2);
          }
        };
      };
    },
    96598: (e) => {
      e.exports = { root: "SlidesNotFoundPage_root__bmv9K", important: "SlidesNotFoundPage_important__VELWc" };
    }
  }
]);
