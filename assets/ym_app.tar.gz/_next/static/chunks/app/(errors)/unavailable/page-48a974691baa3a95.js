(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7312],
  {
    14817: (t, n, e) => {
      Promise.resolve().then(e.bind(e, 75312));
    },
    63708: (t) => {
      t.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    75312: (t, n, e) => {
      "use strict";
      e.d(n, { SomethingWentWrong: () => W });
      var o = e(54486), i = e(50420), a = e(28303), r = e(61910), s = e(43426), _ = e(47713), l = e(77881), g = e(5956), c = e(97800), h = e(74125), m = e(80585), d = e(63708), p = e.n(d);
      let W = (0, a.PA)((t2) => {
        let { className: n2, withBackwardControl: e2 = true } = t2, { formatMessage: a2 } = (0, s.A)(), d2 = a2({ id: "error-messages.something-went-wrong" });
        (0, h.CgZ)(d2);
        let { sendRefreshEvent: W2 } = (0, h.cYT)(), x = (0, r.useCallback)(() => {
          W2(), window.location.href = h.Zyd.main.href;
        }, [W2]), { contentRef: k } = (0, h.gKY)();
        return (0, o.jsxs)("div", {
          className: (0, i.$)(p().root, n2),
          children: [
            e2 && (0, o.jsx)(m.Lh, {
              withBackwardFallback: "/",
              className: (0, i.$)(p().navigation, { [p().navigation_desktop]: !k }),
              withForwardControl: false
            }),
            (0, o.jsxs)("div", {
              className: (0, i.$)(p().content, { [p().content_shrink]: !e2 }),
              children: [
                (0, o.jsx)(g.Icon, { className: p().icon, variant: "attention", size: "xxl" }),
                (0, o.jsx)(c.Heading, {
                  className: (0, i.$)(p().title, p().important),
                  variant: "h3",
                  size: "xs",
                  children: d2
                }),
                (0, o.jsxs)(c.Caption, {
                  className: (0, i.$)(p().text, p().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, o.jsx)(_.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, o.jsx)(l.$, {
                  onClick: x,
                  className: p().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, o.jsxs)(c.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, o.jsx)(_.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    }
  },
  (t) => {
    t.O(
      0,
      [2685, 7956, 5355, 1023, 2036, 1311, 7764, 6706, 5148, 3005, 4125, 585, 5843, 3290, 7358],
      () => t(t.s = 14817)
    ), _N_E = t.O();
  }
]);
