(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [8434],
  {
    26580: (e, t, r) => {
      Promise.resolve().then(r.bind(r, 30446));
    },
    30446: (e, t, r) => {
      "use strict";
      r.r(t), r.d(t, { default: () => l });
      var a = r(54486), o = r(97396), n = r(61910), s = r(36748), i = r(74125);
      let l = () => {
        let e2 = (0, o.useSearchParams)().get("albumId");
        return e2 && (0, i.LLJ)(e2) || (0, o.notFound)(), (0, a.jsx)(n.Suspense, { children: (0, a.jsx)(s.l$, { albumId: e2 }) });
      };
    },
    31622: (e, t, r) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return l;
        }
      });
      let a = r(54486), o = r(61910), n = r(91165);
      function s(e2) {
        return { default: e2 && "default" in e2 ? e2.default : e2 };
      }
      r(98944);
      let i = { loader: () => Promise.resolve(s(() => null)), loading: null, ssr: true }, l = function(e2) {
        let t2 = { ...i, ...e2 }, r2 = (0, o.lazy)(() => t2.loader().then(s)), l2 = t2.loading;
        function u(e3) {
          let s2 = l2 ? (0, a.jsx)(l2, { isLoading: true, pastDelay: true, error: null }) : null, i2 = !t2.ssr || !!t2.loading, u2 = i2 ? o.Suspense : o.Fragment, d = t2.ssr ? (0, a.jsxs)(a.Fragment, { children: [null, (0, a.jsx)(r2, { ...e3 })] }) : (0, a.jsx)(n.BailoutToCSR, { reason: "next/dynamic", children: (0, a.jsx)(r2, { ...e3 }) });
          return (0, a.jsx)(u2, { ...i2 ? { fallback: s2 } : {}, children: d });
        }
        return u.displayName = "LoadableComponent", u;
      };
    },
    36446: (e, t, r) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return o;
        }
      });
      let a = r(45221)._(r(31622));
      function o(e2, t2) {
        var r2;
        let o2 = {};
        "function" == typeof e2 && (o2.loader = e2);
        let n = { ...o2, ...t2 };
        return (0, a.default)({ ...n, modules: null == (r2 = n.loadableGenerated) ? void 0 : r2.modules });
      }
      ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", { value: true }), Object.assign(t.default, t), e.exports = t.default);
    },
    42421: (e, t, r) => {
      "use strict";
      r.d(t, { M: () => a.NotFound });
      var a = r(65034);
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    57249: (e, t, r) => {
      "use strict";
      e.exports = r.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    65034: (e, t, r) => {
      "use strict";
      r.d(t, { NotFound: () => p });
      var a = r(54486), o = r(50420), n = r(28303), s = r(47713), i = r(77881), l = r(5956), u = r(97800), d = r(74125), c = r(80585), m = r(61910), f = r(46215), _ = r.n(f);
      let p = (0, n.PA)((e2) => {
        let { className: t2, title: r2, description: n2, iconVariant: f2 = "musicLogo", iconClassName: p2, iconSize: v } = e2, { contentRef: N } = (0, d.gKY)(), b = (0, d.ZpR)(d.Zyd.main.href);
        (0, d.LZB)();
        let { handleNavigateToMain: x } = (0, d.D5F)(b);
        return (0, d.NBO)(true), !(function() {
          let { location: e3 } = (0, d.Pjs)();
          (0, m.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, a.jsxs)("div", {
          className: (0, o.$)(_().root, { [_().root_desktop]: !N }, t2),
          children: [
            (0, a.jsx)(c.Lh, { withBackwardFallback: "/", className: _().navigation, withForwardControl: false }),
            (0, a.jsxs)("div", {
              className: _().content,
              children: [
                (0, a.jsx)(l.Icon, { className: (0, o.$)(_().icon, p2), variant: f2, size: v }),
                (0, a.jsx)(u.Heading, {
                  className: (0, o.$)(_().title, _().important),
                  variant: "h3",
                  size: "xs",
                  children: r2 || (0, a.jsx)(s.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, a.jsx)(u.Caption, {
                  className: (0, o.$)(_().text, _().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: n2 || (0, a.jsx)(s.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, a.jsx)(i.$, {
                  onClick: x,
                  className: _().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, a.jsx)(u.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, a.jsx)(s.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    83645: (e, t, r) => {
      "use strict";
      r.d(t, { default: () => o.a });
      var a = r(36446), o = r.n(a);
    },
    91165: (e, t, r) => {
      "use strict";
      function a(e2) {
        let { reason: t2, children: r2 } = e2;
        return r2;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return a;
        }
      }), r(39201);
    },
    97151: (e, t, r) => {
      "use strict";
      r.d(t, { XU: () => c });
      var a, o, n = r(41500), s = r(61910), i = r(43426);
      !(function(e2) {
        e2.formatDate = "FormattedDate", e2.formatTime = "FormattedTime", e2.formatNumber = "FormattedNumber", e2.formatList = "FormattedList", e2.formatDisplayName = "FormattedDisplayName";
      })(a || (a = {})), (function(e2) {
        e2.formatDate = "FormattedDateParts", e2.formatTime = "FormattedTimeParts", e2.formatNumber = "FormattedNumberParts", e2.formatList = "FormattedListParts";
      })(o || (o = {}));
      var l = function(e2) {
        var t2 = (0, i.A)(), r2 = e2.value, a2 = e2.children, o2 = (0, n.__rest)(e2, ["value", "children"]);
        return a2(t2.formatNumberToParts(r2, o2));
      };
      function u(e2) {
        var t2 = function(t3) {
          var r2 = (0, i.A)(), a2 = t3.value, o2 = t3.children, s2 = (0, n.__rest)(t3, ["value", "children"]), l2 = "string" == typeof a2 ? new Date(a2 || 0) : a2;
          return o2("formatDate" === e2 ? r2.formatDateToParts(l2, s2) : r2.formatTimeToParts(l2, s2));
        };
        return t2.displayName = o[e2], t2;
      }
      function d(e2) {
        var t2 = function(t3) {
          var r2 = (0, i.A)(), a2 = t3.value, o2 = t3.children, l2 = (0, n.__rest)(t3, ["value", "children"]), u2 = r2[e2](a2, l2);
          if ("function" == typeof o2) return o2(u2);
          var d2 = r2.textComponent || s.Fragment;
          return s.createElement(d2, null, u2);
        };
        return t2.displayName = a[e2], t2;
      }
      l.displayName = "FormattedNumberParts", l.displayName = "FormattedNumberParts";
      var c = d("formatDate");
      d("formatTime"), d("formatNumber"), d("formatList"), d("formatDisplayName"), u("formatDate"), u("formatTime");
    },
    98944: (e, t, r) => {
      "use strict";
      function a(e2) {
        let { moduleIds: t2 } = e2;
        return null;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return a;
        }
      }), r(54486), r(92803), r(14367), r(32038);
    }
  },
  (e) => {
    e.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1546,
        5081,
        6552,
        6952,
        2193,
        2116,
        3146,
        1426,
        1604,
        1311,
        7764,
        6706,
        7724,
        5201,
        5148,
        3005,
        3916,
        4885,
        6266,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        1365,
        8629,
        7858,
        5164,
        4542,
        2353,
        5284,
        2460,
        7363,
        4367,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 26580)
    ), _N_E = e.O();
  }
]);
