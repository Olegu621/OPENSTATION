(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3042],
  {
    31622: (t, e, n) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "default", {
        enumerable: true,
        get: function() {
          return l;
        }
      });
      let r = n(54486), o = n(61910), a = n(91165);
      function i(t2) {
        return { default: t2 && "default" in t2 ? t2.default : t2 };
      }
      n(98944);
      let s = { loader: () => Promise.resolve(i(() => null)), loading: null, ssr: true }, l = function(t2) {
        let e2 = { ...s, ...t2 }, n2 = (0, o.lazy)(() => e2.loader().then(i)), l2 = e2.loading;
        function d(t3) {
          let i2 = l2 ? (0, r.jsx)(l2, { isLoading: true, pastDelay: true, error: null }) : null, s2 = !e2.ssr || !!e2.loading, d2 = s2 ? o.Suspense : o.Fragment, u = e2.ssr ? (0, r.jsxs)(r.Fragment, { children: [null, (0, r.jsx)(n2, { ...t3 })] }) : (0, r.jsx)(a.BailoutToCSR, { reason: "next/dynamic", children: (0, r.jsx)(n2, { ...t3 }) });
          return (0, r.jsx)(d2, { ...s2 ? { fallback: i2 } : {}, children: u });
        }
        return d.displayName = "LoadableComponent", d;
      };
    },
    36446: (t, e, n) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "default", {
        enumerable: true,
        get: function() {
          return o;
        }
      });
      let r = n(45221)._(n(31622));
      function o(t2, e2) {
        var n2;
        let o2 = {};
        "function" == typeof t2 && (o2.loader = t2);
        let a = { ...o2, ...e2 };
        return (0, r.default)({ ...a, modules: null == (n2 = a.loadableGenerated) ? void 0 : n2.modules });
      }
      ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", { value: true }), Object.assign(e.default, e), t.exports = e.default);
    },
    42421: (t, e, n) => {
      "use strict";
      n.d(e, { M: () => r.NotFound });
      var r = n(65034);
    },
    46215: (t) => {
      t.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    57249: (t, e, n) => {
      "use strict";
      t.exports = n.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    63708: (t) => {
      t.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65034: (t, e, n) => {
      "use strict";
      n.d(e, { NotFound: () => p });
      var r = n(54486), o = n(50420), a = n(28303), i = n(47713), s = n(77881), l = n(5956), d = n(97800), u = n(74125), c = n(80585), m = n(61910), _ = n(46215), f = n.n(_);
      let p = (0, a.PA)((t2) => {
        let { className: e2, title: n2, description: a2, iconVariant: _2 = "musicLogo", iconClassName: p2, iconSize: g } = t2, { contentRef: h } = (0, u.gKY)(), x = (0, u.ZpR)(u.Zyd.main.href);
        (0, u.LZB)();
        let { handleNavigateToMain: v } = (0, u.D5F)(x);
        return (0, u.NBO)(true), !(function() {
          let { location: t3 } = (0, u.Pjs)();
          (0, m.useEffect)(
            () => (t3.setNotFound(true), () => {
              t3.setNotFound(false);
            }),
            [t3]
          );
        })(), (0, r.jsxs)("div", {
          className: (0, o.$)(f().root, { [f().root_desktop]: !h }, e2),
          children: [
            (0, r.jsx)(c.Lh, { withBackwardFallback: "/", className: f().navigation, withForwardControl: false }),
            (0, r.jsxs)("div", {
              className: f().content,
              children: [
                (0, r.jsx)(l.Icon, { className: (0, o.$)(f().icon, p2), variant: _2, size: g }),
                (0, r.jsx)(d.Heading, {
                  className: (0, o.$)(f().title, f().important),
                  variant: "h3",
                  size: "xs",
                  children: n2 || (0, r.jsx)(i.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, r.jsx)(d.Caption, {
                  className: (0, o.$)(f().text, f().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: a2 || (0, r.jsx)(i.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, r.jsx)(s.$, {
                  onClick: v,
                  className: f().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, r.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, r.jsx)(i.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    68094: (t, e, n) => {
      "use strict";
      n.r(e), n.d(e, { default: () => s });
      var r = n(54486), o = n(97396), a = n(50211), i = n(74125);
      let s = () => {
        let t2 = (0, o.useSearchParams)().get("artistId");
        return t2 && (0, i.LLJ)(t2) || (0, o.notFound)(), (0, r.jsx)(a.cC, { artistId: t2 });
      };
    },
    75312: (t, e, n) => {
      "use strict";
      n.d(e, { SomethingWentWrong: () => g });
      var r = n(54486), o = n(50420), a = n(28303), i = n(61910), s = n(43426), l = n(47713), d = n(77881), u = n(5956), c = n(97800), m = n(74125), _ = n(80585), f = n(63708), p = n.n(f);
      let g = (0, a.PA)((t2) => {
        let { className: e2, withBackwardControl: n2 = true } = t2, { formatMessage: a2 } = (0, s.A)(), f2 = a2({ id: "error-messages.something-went-wrong" });
        (0, m.CgZ)(f2);
        let { sendRefreshEvent: g2 } = (0, m.cYT)(), h = (0, i.useCallback)(() => {
          g2(), window.location.href = m.Zyd.main.href;
        }, [g2]), { contentRef: x } = (0, m.gKY)();
        return (0, r.jsxs)("div", {
          className: (0, o.$)(p().root, e2),
          children: [
            n2 && (0, r.jsx)(_.Lh, {
              withBackwardFallback: "/",
              className: (0, o.$)(p().navigation, { [p().navigation_desktop]: !x }),
              withForwardControl: false
            }),
            (0, r.jsxs)("div", {
              className: (0, o.$)(p().content, { [p().content_shrink]: !n2 }),
              children: [
                (0, r.jsx)(u.Icon, { className: p().icon, variant: "attention", size: "xxl" }),
                (0, r.jsx)(c.Heading, {
                  className: (0, o.$)(p().title, p().important),
                  variant: "h3",
                  size: "xs",
                  children: f2
                }),
                (0, r.jsxs)(c.Caption, {
                  className: (0, o.$)(p().text, p().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, r.jsx)(l.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, r.jsx)(d.$, {
                  onClick: h,
                  className: p().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, r.jsxs)(c.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, r.jsx)(l.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    82644: (t, e, n) => {
      "use strict";
      n.d(e, { w: () => r.SomethingWentWrong });
      var r = n(75312);
    },
    83645: (t, e, n) => {
      "use strict";
      n.d(e, { default: () => o.a });
      var r = n(36446), o = n.n(r);
    },
    91165: (t, e, n) => {
      "use strict";
      function r(t2) {
        let { reason: e2, children: n2 } = t2;
        return n2;
      }
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return r;
        }
      }), n(39201);
    },
    97151: (t, e, n) => {
      "use strict";
      n.d(e, { XU: () => c });
      var r, o, a = n(41500), i = n(61910), s = n(43426);
      !(function(t2) {
        t2.formatDate = "FormattedDate", t2.formatTime = "FormattedTime", t2.formatNumber = "FormattedNumber", t2.formatList = "FormattedList", t2.formatDisplayName = "FormattedDisplayName";
      })(r || (r = {})), (function(t2) {
        t2.formatDate = "FormattedDateParts", t2.formatTime = "FormattedTimeParts", t2.formatNumber = "FormattedNumberParts", t2.formatList = "FormattedListParts";
      })(o || (o = {}));
      var l = function(t2) {
        var e2 = (0, s.A)(), n2 = t2.value, r2 = t2.children, o2 = (0, a.__rest)(t2, ["value", "children"]);
        return r2(e2.formatNumberToParts(n2, o2));
      };
      function d(t2) {
        var e2 = function(e3) {
          var n2 = (0, s.A)(), r2 = e3.value, o2 = e3.children, i2 = (0, a.__rest)(e3, ["value", "children"]), l2 = "string" == typeof r2 ? new Date(r2 || 0) : r2;
          return o2("formatDate" === t2 ? n2.formatDateToParts(l2, i2) : n2.formatTimeToParts(l2, i2));
        };
        return e2.displayName = o[t2], e2;
      }
      function u(t2) {
        var e2 = function(e3) {
          var n2 = (0, s.A)(), r2 = e3.value, o2 = e3.children, l2 = (0, a.__rest)(e3, ["value", "children"]), d2 = n2[t2](r2, l2);
          if ("function" == typeof o2) return o2(d2);
          var u2 = n2.textComponent || i.Fragment;
          return i.createElement(u2, null, d2);
        };
        return e2.displayName = r[t2], e2;
      }
      l.displayName = "FormattedNumberParts", l.displayName = "FormattedNumberParts";
      var c = u("formatDate");
      u("formatTime"), u("formatNumber"), u("formatList"), u("formatDisplayName"), d("formatDate"), d("formatTime");
    },
    98618: (t, e, n) => {
      Promise.resolve().then(n.bind(n, 68094));
    },
    98944: (t, e, n) => {
      "use strict";
      function r(t2) {
        let { moduleIds: e2 } = t2;
        return null;
      }
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return r;
        }
      }), n(54486), n(92803), n(14367), n(32038);
    }
  },
  (t) => {
    t.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1546,
        5081,
        6552,
        6952,
        2193,
        2036,
        2116,
        3146,
        1426,
        1604,
        1311,
        7764,
        6706,
        7724,
        5201,
        5148,
        3005,
        3916,
        4885,
        6266,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        1365,
        8629,
        7858,
        5164,
        4542,
        2353,
        2460,
        5550,
        211,
        5843,
        3290,
        7358
      ],
      () => t(t.s = 98618)
    ), _N_E = t.O();
  }
]);
