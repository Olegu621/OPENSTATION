(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [7779],
  {
    31622: (e, t, n) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return l;
        }
      });
      let o = n(54486), r = n(61910), s = n(91165);
      function a(e2) {
        return { default: e2 && "default" in e2 ? e2.default : e2 };
      }
      n(98944);
      let i = { loader: () => Promise.resolve(a(() => null)), loading: null, ssr: true }, l = function(e2) {
        let t2 = { ...i, ...e2 }, n2 = (0, r.lazy)(() => t2.loader().then(a)), l2 = t2.loading;
        function c(e3) {
          let a2 = l2 ? (0, o.jsx)(l2, { isLoading: true, pastDelay: true, error: null }) : null, i2 = !t2.ssr || !!t2.loading, c2 = i2 ? r.Suspense : r.Fragment, d = t2.ssr ? (0, o.jsxs)(o.Fragment, { children: [null, (0, o.jsx)(n2, { ...e3 })] }) : (0, o.jsx)(s.BailoutToCSR, { reason: "next/dynamic", children: (0, o.jsx)(n2, { ...e3 }) });
          return (0, o.jsx)(c2, { ...i2 ? { fallback: a2 } : {}, children: d });
        }
        return c.displayName = "LoadableComponent", c;
      };
    },
    35462: (e) => {
      e.exports = {
        root: "TopConcertsCarousel_root__opMbb",
        controls: "TopConcertsCarousel_controls__c92PW",
        header: "TopConcertsCarousel_header__3h3Zn",
        carousel: "TopConcertsCarousel_carousel__uMke6",
        item: "TopConcertsCarousel_item__fz8lR",
        important: "TopConcertsCarousel_important__ZcT6Z"
      };
    },
    36446: (e, t, n) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return r;
        }
      });
      let o = n(45221)._(n(31622));
      function r(e2, t2) {
        var n2;
        let r2 = {};
        "function" == typeof e2 && (r2.loader = e2);
        let s = { ...r2, ...t2 };
        return (0, o.default)({ ...s, modules: null == (n2 = s.loadableGenerated) ? void 0 : n2.modules });
      }
      ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", { value: true }), Object.assign(t.default, t), e.exports = t.default);
    },
    42421: (e, t, n) => {
      "use strict";
      n.d(t, { M: () => o.NotFound });
      var o = n(65034);
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    48249: (e, t, n) => {
      "use strict";
      n.d(t, { km: () => _, h4: () => $, cw: () => d, k_: () => V });
      var o = n(74125), r = n(93064), s = n(4542), a = n(77217), i = n(26433);
      let l = (e2, t2, n2) => -1 === n2 ? e2.slice(t2) : e2.slice(t2, t2 + n2), c = r.gK.compose(
        r.gK.model("ConcertsPageConfig", {
          topOffset: r.gK.optional(r.gK.number, 0),
          topLimit: r.gK.optional(r.gK.number, 3),
          feedOffset: r.gK.optional(r.gK.number, 3),
          feedLimit: r.gK.optional(r.gK.number, -1)
        }),
        i.XT
      ).actions((e2) => ({
        getData: (0, r.L3)(function* () {
          let { concertsResource: t2, modelActionsLogger: n2 } = (0, r._$)(e2);
          if (!e2.isLoading)
            try {
              e2.loadingState = o.GuX.PENDING;
              let {
                config: { feed: n3, top: r2 }
              } = yield t2.getTabConfig({});
              e2.feedLimit = n3.limit, e2.feedOffset = n3.offset, e2.topLimit = r2.limit, e2.topOffset = r2.offset, e2.loadingState = o.GuX.RESOLVE;
            } catch (t3) {
              n2.error(t3), e2.loadingState = o.GuX.REJECT;
            }
        }),
        reset() {
          e2.loadingState = o.GuX.IDLE, e2.feedLimit = -1, e2.feedOffset = 3, e2.topLimit = 3, e2.topOffset = 0;
        }
      })), d = r.gK.compose(
        r.gK.model("ConcertsPage", {
          config: c,
          landing: s.Ju,
          topConcerts: r.gK.maybeNull(r.gK.array(a.aR)),
          feedConcerts: r.gK.maybeNull(r.gK.array(a.aR))
        }),
        i.XT,
        i.pl
      ).views((e2) => ({
        get isShimmerVisible() {
          return e2.isNeededToLoad || e2.isLoading || e2.isRejected;
        },
        get isShimmerActive() {
          return e2.isLoading;
        }
      })).actions((e2) => ({
        getData: (0, r.L3)(function* () {
          let { concertsResource: t2, modelActionsLogger: n2 } = (0, r._$)(e2);
          if (!e2.config.isLoading && !e2.isLoading)
            try {
              e2.loadingState = o.GuX.PENDING, yield e2.config.getData();
              let { items: n3 } = yield t2.getFeed({}), { feedConcerts: s2, topConcerts: i2 } = ((e3, t3) => {
                let { topLimit: n4, topOffset: o2, feedLimit: r2, feedOffset: s3 } = e3;
                return { topConcerts: l(t3, o2, n4), feedConcerts: l(t3, s3, r2) };
              })(
                e2.config,
                n3.map((e3) => (0, a.HN)(e3))
              );
              e2.feedConcerts = (0, r.wg)(s2), e2.topConcerts = (0, r.wg)(i2), e2.loadingState = o.GuX.RESOLVE;
            } catch (t3) {
              n2.error(t3), e2.loadingState = o.GuX.REJECT;
            }
        }),
        reset() {
          e2.config.reset(), e2.landing.reset(), e2.loadingState = o.GuX.IDLE, e2.destroyItems([e2.topConcerts, e2.feedConcerts]);
        }
      }));
      var u = n(54486), m = n(28303), f = n(61910), g = n(42421);
      let _ = (0, m.PA)(() => {
        let { concerts: e2 } = (0, o.Pjs)();
        return (0, f.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), (0, u.jsx)(g.M, {});
      });
      var h = n(97396), p = n(43426), x = n(47713), b = n(9348), j = n(43350), C = n(31500), v = n(6024), N = n(56231), y = n(97800), P = n(8817), k = n(67648), T = n(77516), F = n(80585), S = n(63118), w = n.n(S);
      let A = (0, m.PA)(() => {
        let e2 = (0, f.useId)(), { concerts: t2 } = (0, o.Pjs)(), { formatMessage: n2 } = (0, p.A)(), [r2, s2] = (0, k.d)(), i2 = (0, o.fBs)(), l2 = (0, f.useRef)(false), c2 = (0, P.c)(() => {
          var e3;
          return !t2.isShimmerVisible && (null == (e3 = t2.feedConcerts) ? void 0 : e3.length) ? t2.feedConcerts.length : 50;
        }), {
          virtualizer: d2,
          rowResizeObserver: m2,
          columnCount: g2,
          indices: _2
        } = (0, T.LW)({
          count: c2(),
          rowGap: 32,
          columnGap: 16,
          getEstimateRowSize: () => 371,
          minColumnCount: 2,
          minColumnWidth: 170,
          maxColumnWidth: 227,
          containerRef: r2
        }), h2 = { "--feed-concerts-height": "".concat(d2.getTotalSize(), "px"), "--feed-concerts-column-count": g2 }, x2 = (0, f.useCallback)(
          (e3) => {
            var n3, r3, s3;
            let i3 = null == (n3 = t2.feedConcerts) ? void 0 : n3[e3];
            return !i3 || t2.isShimmerVisible ? (0, u.jsx)(a.LY, { isActive: t2.isShimmerActive }) : (0, u.jsx)(o.Bki, {
              objectType: j.ky.Concert,
              objectId: i3.id,
              objectPosX: e3 % g2 + 1,
              objectPosY: Math.floor(e3 / g2) + 1,
              objectsCount: null != (s3 = null == (r3 = t2.feedConcerts) ? void 0 : r3.length) ? s3 : 0,
              children: (0, u.jsx)(a.Qb, { concert: i3 })
            });
          },
          [g2, t2.feedConcerts, t2.isShimmerActive, t2.isShimmerVisible]
        );
        return (0, f.useEffect)(() => {
          t2.isResolved && !l2.current && (i2(), l2.current = true);
        }, [t2.isResolved, i2]), (0, u.jsxs)("div", {
          className: w().root,
          ...(0, C.Am)(C.e8.concerts.CONCERTS_FEED),
          children: [
            (0, u.jsx)(F.Tw, {
              className: w().header,
              labeledForId: e2,
              title: n2({ id: "concerts.all-concerts" }),
              headingVariant: "h2"
            }),
            (0, u.jsx)("div", {
              "aria-labelledby": e2,
              ref: s2,
              style: h2,
              className: w().container,
              children: d2.getVirtualItems().map(
                (e3) => (0, u.jsx)(
                  T.Ux,
                  {
                    className: w().row,
                    columnClassName: w().column,
                    virtualItem: e3,
                    resizeObserver: m2,
                    indices: _2,
                    renderItemByIndex: x2,
                    scrollMargin: d2.options.scrollMargin
                  },
                  e3.key
                )
              )
            })
          ]
        });
      });
      var E = n(50420), L = n(81203), O = n(35462), R = n.n(O);
      let W = (e2) => {
        let { children: t2 } = e2, n2 = (0, f.useId)(), o2 = (0, f.useRef)(null), { formatMessage: r2 } = (0, p.A)();
        return (0, u.jsxs)("div", {
          className: R().root,
          ...(0, C.Am)(C.e8.concerts.CONCERTS_TOP),
          children: [
            (0, u.jsx)(F.Tw, {
              className: R().header,
              labeledForId: n2,
              title: r2({ id: "concerts.top-for-you" }),
              controls: (0, u.jsx)(F.X9, { className: R().controls, carouselRef: o2 }),
              headingVariant: "h2"
            }),
            (0, u.jsx)(L.Carousel, {
              className: R().carousel,
              ref: o2,
              itemClassName: (0, E.$)(R().item, R().important),
              "aria-labelledby": n2,
              children: t2
            })
          ]
        });
      }, I = (e2) => Array.from({ length: 10 }, (t2, n2) => (0, u.jsx)(a.LY, { isActive: e2, withPriceButton: true }, n2)), D = (0, m.PA)(() => {
        let { concerts: e2 } = (0, o.Pjs)(), t2 = (0, o.fBs)(), n2 = (0, f.useRef)(false), r2 = (0, f.useMemo)(() => {
          var t3;
          return (null == (t3 = e2.topConcerts) ? void 0 : t3.length) && !e2.isShimmerVisible ? e2.topConcerts.map((t4, n3) => {
            var r3, s2;
            return (0, u.jsx)(
              o.Bki,
              {
                objectType: j.ky.Concert,
                objectId: t4.id,
                objectPosX: n3 + 1,
                objectPosY: 1,
                objectsCount: null != (s2 = null == (r3 = e2.topConcerts) ? void 0 : r3.length) ? s2 : 0,
                children: (0, u.jsx)(a.Qb, { withMask: false, withPriceButton: true, concert: t4 })
              },
              t4.getKey(n3)
            );
          }) : I(e2.isShimmerActive);
        }, [e2.isShimmerActive, e2.isShimmerVisible, e2.topConcerts]);
        return (0, f.useEffect)(() => {
          e2.isResolved && !n2.current && (t2(), n2.current = true);
        }, [e2.isResolved, t2]), e2.isNeededToLoad && (0, f.use)(e2.getData()), (0, u.jsx)(W, { children: r2 });
      }), z = () => (0, u.jsx)(f.Suspense, { fallback: (0, u.jsx)(W, { children: I(true) }), children: (0, u.jsx)(D, {}) });
      var G = n(82644), K = n(33276), B = n(62395), X = n(77343), M = n.n(X);
      let $ = (0, m.PA)(() => {
        var e2, t2, n2, r2, a2, i2, l2, c2, d2;
        let { formatMessage: m2 } = (0, p.A)(), { setContentScrollRef: g2, contentScrollRef: _2 } = (0, o.gKY)(), { concerts: k2, experiments: T2, user: S2 } = (0, o.Pjs)(), w2 = (() => {
          let e3 = (0, B.st)(), t3 = (0, o.UlF)(), { hash: n3 } = (0, B.gf)();
          return (0, P.c)((o2, r3) => {
            if (!e3) return;
            let s2 = {
              hash: n3,
              pageId: j.QT.ConcertsLandingScreen,
              pageStyle: j.QL.Fullscreen,
              pagePlacement: j.c4.Fullscreen,
              viewUuid: r3
            }, a3 = (0, j.Fx)({ params: s2, logger: t3, context: "useSendEventOnConcertsOpenedOrClosed" });
            a3 && (o2 ? (0, j.Fn)(e3.evgenInstance, a3) : (0, j.PO)(e3.evgenInstance, a3));
          });
        })(), E2 = (0, f.useRef)(String((0, b.A)())), L2 = null != (i2 = null == (e2 = k2.landing.meta) ? void 0 : e2.selectedTabIndex) ? i2 : 0, O2 = null != (l2 = null == (n2 = k2.landing.tabs.data) || null == (t2 = n2[L2]) ? void 0 : t2.blocks.length) ? l2 : 0;
        return ((!T2.checkExperiment(o.zal.WebNextConcertsTab, "on") || T2.checkExperiment(o.zal.disableAllConcerts, "on")) && (0, h.notFound)(), S2.hasPlus || (0, h.redirect)(o.Zyd.main.href), (0, f.useEffect)(
          () => () => {
            k2.reset();
          },
          [k2]
        ), (0, f.useEffect)(() => {
          let e3 = E2.current;
          return w2(true, e3), () => {
            w2(false, e3);
          };
        }, [w2]), (0, o.Jzs)(k2.landing.isResolved), (() => {
          let e3 = (0, f.useRef)(1), { concerts: t3 } = (0, o.Pjs)(), { notify: n3 } = (0, o.lkh)(), { formatMessage: r3 } = (0, p.A)();
          (0, f.useEffect)(() => {
            e3 && (t3.isRejected && n3((0, u.jsx)(F.hT, { error: r3({ id: "concerts.feed-error" }) }), { containerId: o.uQT.ERROR }), e3.current--);
          }, [t3.isRejected, r3, n3]);
        })(), k2.landing.isNeededToLoad && (0, f.use)(
          k2.landing.getSkeleton({ id: v.p.CONCERTS, showWizard: S2.settings.showWizard }, { preloadBlocksCount: 2 })
        ), k2.landing.isRejected) ? (0, u.jsx)(G.w, {}) : (0, u.jsx)(o.nVz, {
          pageId: o._Q$.CONCERTS,
          children: (0, u.jsxs)(K.hO, {
            scrollElement: _2,
            outerTitle: m2({ id: "entity-names.concerts" }),
            children: [
              (0, u.jsx)(F.Y9, {
                variant: F.Vw.TEXT,
                showControls: false,
                children: (0, u.jsx)(y.Heading, {
                  variant: "h1",
                  weight: "bold",
                  size: "xl",
                  children: (0, u.jsx)(x.A, { id: "entity-names.concerts" })
                })
              }),
              (0, u.jsxs)(N.N, {
                ref: g2,
                className: M().root,
                containerClassName: M().container,
                ...(0, C.Am)(C.Xk.concerts.CONCERTS_PAGE),
                children: [
                  (0, u.jsx)(o.jPc, {
                    children: (0, u.jsx)(o.hjC, {
                      tabId: "",
                      tabPos: 0,
                      isTabSelectedByDefault: false,
                      children: (0, u.jsx)(o.FoH, {
                        blockId: j.LA.ConcertTabHeader,
                        blockType: j.LA.ConcertTabHeader,
                        blockPosX: 1,
                        blockPosY: 1,
                        objectsCount: null != (c2 = null == (r2 = k2.topConcerts) ? void 0 : r2.length) ? c2 : 0,
                        children: (0, u.jsx)(z, {})
                      })
                    })
                  }),
                  (0, u.jsx)(o.MZP, {
                    offsetBlockPosY: 1,
                    children: (0, u.jsx)(s.EA, {
                      landing: k2.landing,
                      errorComponent: (0, u.jsx)(G.w, { withBackwardControl: false })
                    })
                  }),
                  (0, u.jsx)(o.jPc, {
                    children: (0, u.jsx)(o.hjC, {
                      tabId: "",
                      tabPos: 0,
                      isTabSelectedByDefault: false,
                      children: (0, u.jsx)(o.FoH, {
                        blockId: j.LA.ConcertTabFeed,
                        blockType: j.LA.ConcertTabFeed,
                        blockPosX: 1,
                        blockPosY: O2 + 2,
                        objectsCount: null != (d2 = null == (a2 = k2.feedConcerts) ? void 0 : a2.length) ? d2 : 0,
                        children: (0, u.jsx)(A, {})
                      })
                    })
                  }),
                  (0, u.jsx)(F.A, { children: (0, u.jsx)(F.wi, { className: M().footer }) })
                ]
              })
            ]
          })
        });
      }), V = () => (0, u.jsx)(F.JR, {
        style: { position: "absolute", background: "var(--ym-background-color-primary-enabled-content)" }
      });
    },
    52655: (e, t, n) => {
      "use strict";
      n.r(t), n.d(t, { default: () => s });
      var o = n(54486), r = n(48249);
      let s = () => (0, o.jsx)(r.km, {});
    },
    57249: (e, t, n) => {
      "use strict";
      e.exports = n.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    63118: (e) => {
      e.exports = {
        root: "FeedConcerts_root__W7OGN",
        header: "FeedConcerts_header__Ht1xd",
        container: "FeedConcerts_container__CONvW",
        column: "FeedConcerts_column__FpMgx",
        row: "FeedConcerts_row__HEdtn"
      };
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65034: (e, t, n) => {
      "use strict";
      n.d(t, { NotFound: () => _ });
      var o = n(54486), r = n(50420), s = n(28303), a = n(47713), i = n(77881), l = n(5956), c = n(97800), d = n(74125), u = n(80585), m = n(61910), f = n(46215), g = n.n(f);
      let _ = (0, s.PA)((e2) => {
        let { className: t2, title: n2, description: s2, iconVariant: f2 = "musicLogo", iconClassName: _2, iconSize: h } = e2, { contentRef: p } = (0, d.gKY)(), x = (0, d.ZpR)(d.Zyd.main.href);
        (0, d.LZB)();
        let { handleNavigateToMain: b } = (0, d.D5F)(x);
        return (0, d.NBO)(true), !(function() {
          let { location: e3 } = (0, d.Pjs)();
          (0, m.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, o.jsxs)("div", {
          className: (0, r.$)(g().root, { [g().root_desktop]: !p }, t2),
          children: [
            (0, o.jsx)(u.Lh, { withBackwardFallback: "/", className: g().navigation, withForwardControl: false }),
            (0, o.jsxs)("div", {
              className: g().content,
              children: [
                (0, o.jsx)(l.Icon, { className: (0, r.$)(g().icon, _2), variant: f2, size: h }),
                (0, o.jsx)(c.Heading, {
                  className: (0, r.$)(g().title, g().important),
                  variant: "h3",
                  size: "xs",
                  children: n2 || (0, o.jsx)(a.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, o.jsx)(c.Caption, {
                  className: (0, r.$)(g().text, g().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: s2 || (0, o.jsx)(a.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, o.jsx)(i.$, {
                  onClick: b,
                  className: g().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, o.jsx)(c.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, o.jsx)(a.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    75312: (e, t, n) => {
      "use strict";
      n.d(t, { SomethingWentWrong: () => h });
      var o = n(54486), r = n(50420), s = n(28303), a = n(61910), i = n(43426), l = n(47713), c = n(77881), d = n(5956), u = n(97800), m = n(74125), f = n(80585), g = n(63708), _ = n.n(g);
      let h = (0, s.PA)((e2) => {
        let { className: t2, withBackwardControl: n2 = true } = e2, { formatMessage: s2 } = (0, i.A)(), g2 = s2({ id: "error-messages.something-went-wrong" });
        (0, m.CgZ)(g2);
        let { sendRefreshEvent: h2 } = (0, m.cYT)(), p = (0, a.useCallback)(() => {
          h2(), window.location.href = m.Zyd.main.href;
        }, [h2]), { contentRef: x } = (0, m.gKY)();
        return (0, o.jsxs)("div", {
          className: (0, r.$)(_().root, t2),
          children: [
            n2 && (0, o.jsx)(f.Lh, {
              withBackwardFallback: "/",
              className: (0, r.$)(_().navigation, { [_().navigation_desktop]: !x }),
              withForwardControl: false
            }),
            (0, o.jsxs)("div", {
              className: (0, r.$)(_().content, { [_().content_shrink]: !n2 }),
              children: [
                (0, o.jsx)(d.Icon, { className: _().icon, variant: "attention", size: "xxl" }),
                (0, o.jsx)(u.Heading, {
                  className: (0, r.$)(_().title, _().important),
                  variant: "h3",
                  size: "xs",
                  children: g2
                }),
                (0, o.jsxs)(u.Caption, {
                  className: (0, r.$)(_().text, _().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, o.jsx)(l.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, o.jsx)(c.$, {
                  onClick: p,
                  className: _().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, o.jsxs)(u.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, o.jsx)(l.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    77343: (e) => {
      e.exports = {
        root: "ConcertsPage_root__olabl",
        container: "ConcertsPage_container__qS7xA",
        footer: "ConcertsPage_footer__GYRwF"
      };
    },
    82644: (e, t, n) => {
      "use strict";
      n.d(t, { w: () => o.SomethingWentWrong });
      var o = n(75312);
    },
    83645: (e, t, n) => {
      "use strict";
      n.d(t, { default: () => r.a });
      var o = n(36446), r = n.n(o);
    },
    91165: (e, t, n) => {
      "use strict";
      function o(e2) {
        let { reason: t2, children: n2 } = e2;
        return n2;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return o;
        }
      }), n(39201);
    },
    97063: (e, t, n) => {
      Promise.resolve().then(n.bind(n, 52655));
    },
    97151: (e, t, n) => {
      "use strict";
      n.d(t, { XU: () => u });
      var o, r, s = n(41500), a = n(61910), i = n(43426);
      !(function(e2) {
        e2.formatDate = "FormattedDate", e2.formatTime = "FormattedTime", e2.formatNumber = "FormattedNumber", e2.formatList = "FormattedList", e2.formatDisplayName = "FormattedDisplayName";
      })(o || (o = {})), (function(e2) {
        e2.formatDate = "FormattedDateParts", e2.formatTime = "FormattedTimeParts", e2.formatNumber = "FormattedNumberParts", e2.formatList = "FormattedListParts";
      })(r || (r = {}));
      var l = function(e2) {
        var t2 = (0, i.A)(), n2 = e2.value, o2 = e2.children, r2 = (0, s.__rest)(e2, ["value", "children"]);
        return o2(t2.formatNumberToParts(n2, r2));
      };
      function c(e2) {
        var t2 = function(t3) {
          var n2 = (0, i.A)(), o2 = t3.value, r2 = t3.children, a2 = (0, s.__rest)(t3, ["value", "children"]), l2 = "string" == typeof o2 ? new Date(o2 || 0) : o2;
          return r2("formatDate" === e2 ? n2.formatDateToParts(l2, a2) : n2.formatTimeToParts(l2, a2));
        };
        return t2.displayName = r[e2], t2;
      }
      function d(e2) {
        var t2 = function(t3) {
          var n2 = (0, i.A)(), o2 = t3.value, r2 = t3.children, l2 = (0, s.__rest)(t3, ["value", "children"]), c2 = n2[e2](o2, l2);
          if ("function" == typeof r2) return r2(c2);
          var d2 = n2.textComponent || a.Fragment;
          return a.createElement(d2, null, c2);
        };
        return t2.displayName = o[e2], t2;
      }
      l.displayName = "FormattedNumberParts", l.displayName = "FormattedNumberParts";
      var u = d("formatDate");
      d("formatTime"), d("formatNumber"), d("formatList"), d("formatDisplayName"), c("formatDate"), c("formatTime");
    },
    98944: (e, t, n) => {
      "use strict";
      function o(e2) {
        let { moduleIds: t2 } = e2;
        return null;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return o;
        }
      }), n(54486), n(92803), n(14367), n(32038);
    }
  },
  (e) => {
    e.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1546,
        5081,
        6552,
        6952,
        2193,
        2116,
        2036,
        1311,
        7764,
        6706,
        7724,
        5201,
        5148,
        3005,
        3916,
        4885,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        1365,
        8629,
        7858,
        5164,
        4542,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 97063)
    ), _N_E = e.O();
  }
]);
