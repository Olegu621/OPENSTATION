(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6360],
  {
    31622: (t, e, r) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "default", {
        enumerable: true,
        get: function() {
          return l;
        }
      });
      let a = r(54486), o = r(61910), n = r(91165);
      function s(t2) {
        return { default: t2 && "default" in t2 ? t2.default : t2 };
      }
      r(98944);
      let i = { loader: () => Promise.resolve(s(() => null)), loading: null, ssr: true }, l = function(t2) {
        let e2 = { ...i, ...t2 }, r2 = (0, o.lazy)(() => e2.loader().then(s)), l2 = e2.loading;
        function u(t3) {
          let s2 = l2 ? (0, a.jsx)(l2, { isLoading: true, pastDelay: true, error: null }) : null, i2 = !e2.ssr || !!e2.loading, u2 = i2 ? o.Suspense : o.Fragment, d = e2.ssr ? (0, a.jsxs)(a.Fragment, { children: [null, (0, a.jsx)(r2, { ...t3 })] }) : (0, a.jsx)(n.BailoutToCSR, { reason: "next/dynamic", children: (0, a.jsx)(r2, { ...t3 }) });
          return (0, a.jsx)(u2, { ...i2 ? { fallback: s2 } : {}, children: d });
        }
        return u.displayName = "LoadableComponent", u;
      };
    },
    35173: (t, e, r) => {
      "use strict";
      r.d(e, { EntitiesNotFoundPage: () => l });
      var a = r(54486), o = r(28303), n = r(61910), s = r(42421), i = r(74125);
      let l = (0, o.PA)(() => {
        let { landingBlockEntities: t2 } = (0, i.Pjs)();
        return (0, n.useEffect)(
          () => () => {
            t2.reset();
          },
          [t2]
        ), (0, a.jsx)(s.M, {});
      });
    },
    36446: (t, e, r) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "default", {
        enumerable: true,
        get: function() {
          return o;
        }
      });
      let a = r(45221)._(r(31622));
      function o(t2, e2) {
        var r2;
        let o2 = {};
        "function" == typeof t2 && (o2.loader = t2);
        let n = { ...o2, ...e2 };
        return (0, a.default)({ ...n, modules: null == (r2 = n.loadableGenerated) ? void 0 : r2.modules });
      }
      ("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", { value: true }), Object.assign(e.default, e), t.exports = e.default);
    },
    42421: (t, e, r) => {
      "use strict";
      r.d(e, { M: () => a.NotFound });
      var a = r(65034);
    },
    46215: (t) => {
      t.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    57249: (t, e, r) => {
      "use strict";
      t.exports = r.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    65034: (t, e, r) => {
      "use strict";
      r.d(e, { NotFound: () => p });
      var a = r(54486), o = r(50420), n = r(28303), s = r(47713), i = r(77881), l = r(5956), u = r(97800), d = r(74125), c = r(80585), m = r(61910), f = r(46215), _ = r.n(f);
      let p = (0, n.PA)((t2) => {
        let { className: e2, title: r2, description: n2, iconVariant: f2 = "musicLogo", iconClassName: p2, iconSize: N } = t2, { contentRef: b } = (0, d.gKY)(), v = (0, d.ZpR)(d.Zyd.main.href);
        (0, d.LZB)();
        let { handleNavigateToMain: x } = (0, d.D5F)(v);
        return (0, d.NBO)(true), !(function() {
          let { location: t3 } = (0, d.Pjs)();
          (0, m.useEffect)(
            () => (t3.setNotFound(true), () => {
              t3.setNotFound(false);
            }),
            [t3]
          );
        })(), (0, a.jsxs)("div", {
          className: (0, o.$)(_().root, { [_().root_desktop]: !b }, e2),
          children: [
            (0, a.jsx)(c.Lh, { withBackwardFallback: "/", className: _().navigation, withForwardControl: false }),
            (0, a.jsxs)("div", {
              className: _().content,
              children: [
                (0, a.jsx)(l.Icon, { className: (0, o.$)(_().icon, p2), variant: f2, size: N }),
                (0, a.jsx)(u.Heading, {
                  className: (0, o.$)(_().title, _().important),
                  variant: "h3",
                  size: "xs",
                  children: r2 || (0, a.jsx)(s.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, a.jsx)(u.Caption, {
                  className: (0, o.$)(_().text, _().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: n2 || (0, a.jsx)(s.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, a.jsx)(i.$, {
                  onClick: x,
                  className: _().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, a.jsx)(u.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, a.jsx)(s.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    65351: (t, e, r) => {
      "use strict";
      r.d(e, { EntitiesPage: () => c });
      var a = r(54486), o = r(28303), n = r(97396), s = r(61910), i = r(4542), l = r(74125), u = r(35620);
      let d = {
        "new-releases": u.t.NEW_RELEASES,
        "editorial-new-releases": u.t.EDITORIAL_NEW_RELEASES,
        "personal-artists": u.t.PERSONAL_ARTISTS,
        "new-stars-artists": u.t.NEW_STARS_ARTISTS,
        "editorial-artists": u.t.EDITORIAL_ARTISTS,
        "new-playlists": u.t.NEW_PLAYLISTS,
        "editorial-compilation": u.t.EDITORIAL_COMPILATION,
        "non-music-editorial-compilation": u.t.EDITORIAL_COMPILATION,
        "chart-albums": u.t.CHART_ALBUMS,
        "mixes-grid": u.t.MIXES_GRID,
        "mixes-music": u.t.MIXES_MUSIC
      }, c = (0, o.PA)((t2) => {
        let { blockType: e2, blockId: r2 } = t2, { landingBlockEntities: o2 } = (0, l.Pjs)();
        (0, s.useEffect)(
          () => () => {
            o2.reset();
          },
          [o2, e2, r2]
        ), (0, l.Jzs)(o2.loadingState === l.GuX.RESOLVE);
        let u2 = d[e2];
        return (o2.isNotFound || !u2) && (0, n.notFound)(), (0, a.jsx)(l.nVz, {
          pageId: l._Q$.ENTITIES,
          children: (0, a.jsx)(l.FoH, {
            blockId: "".concat(l.hf$.DISCOVERY_BLOCK, "-").concat(r2),
            blockIdForFrom: "".concat(l.hf$.DISCOVERY_BLOCK, "-").concat(r2),
            blockPosX: 1,
            blockPosY: 1,
            blockType: u2,
            objectsCount: o2.items.length,
            children: (0, a.jsx)(i.bX, { blockType: u2, blockId: r2 })
          })
        });
      });
    },
    81721: (t, e, r) => {
      "use strict";
      r.r(e), r.d(e, { default: () => s });
      var a = r(54486), o = r(97396);
      r(35173);
      var n = r(65351);
      let s = () => {
        let t2 = (0, o.useSearchParams)(), e2 = t2.get("blockType"), r2 = t2.get("blockId");
        return e2 && r2 || (0, o.notFound)(), (0, a.jsx)(n.EntitiesPage, { blockType: e2, blockId: r2 });
      };
    },
    83645: (t, e, r) => {
      "use strict";
      r.d(e, { default: () => o.a });
      var a = r(36446), o = r.n(a);
    },
    91165: (t, e, r) => {
      "use strict";
      function a(t2) {
        let { reason: e2, children: r2 } = t2;
        return r2;
      }
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return a;
        }
      }), r(39201);
    },
    97151: (t, e, r) => {
      "use strict";
      r.d(e, { XU: () => c });
      var a, o, n = r(41500), s = r(61910), i = r(43426);
      !(function(t2) {
        t2.formatDate = "FormattedDate", t2.formatTime = "FormattedTime", t2.formatNumber = "FormattedNumber", t2.formatList = "FormattedList", t2.formatDisplayName = "FormattedDisplayName";
      })(a || (a = {})), (function(t2) {
        t2.formatDate = "FormattedDateParts", t2.formatTime = "FormattedTimeParts", t2.formatNumber = "FormattedNumberParts", t2.formatList = "FormattedListParts";
      })(o || (o = {}));
      var l = function(t2) {
        var e2 = (0, i.A)(), r2 = t2.value, a2 = t2.children, o2 = (0, n.__rest)(t2, ["value", "children"]);
        return a2(e2.formatNumberToParts(r2, o2));
      };
      function u(t2) {
        var e2 = function(e3) {
          var r2 = (0, i.A)(), a2 = e3.value, o2 = e3.children, s2 = (0, n.__rest)(e3, ["value", "children"]), l2 = "string" == typeof a2 ? new Date(a2 || 0) : a2;
          return o2("formatDate" === t2 ? r2.formatDateToParts(l2, s2) : r2.formatTimeToParts(l2, s2));
        };
        return e2.displayName = o[t2], e2;
      }
      function d(t2) {
        var e2 = function(e3) {
          var r2 = (0, i.A)(), a2 = e3.value, o2 = e3.children, l2 = (0, n.__rest)(e3, ["value", "children"]), u2 = r2[t2](a2, l2);
          if ("function" == typeof o2) return o2(u2);
          var d2 = r2.textComponent || s.Fragment;
          return s.createElement(d2, null, u2);
        };
        return e2.displayName = a[t2], e2;
      }
      l.displayName = "FormattedNumberParts", l.displayName = "FormattedNumberParts";
      var c = d("formatDate");
      d("formatTime"), d("formatNumber"), d("formatList"), d("formatDisplayName"), u("formatDate"), u("formatTime");
    },
    98944: (t, e, r) => {
      "use strict";
      function a(t2) {
        let { moduleIds: e2 } = t2;
        return null;
      }
      Object.defineProperty(e, "__esModule", { value: true }), Object.defineProperty(e, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return a;
        }
      }), r(54486), r(92803), r(14367), r(32038);
    },
    99774: (t, e, r) => {
      Promise.resolve().then(r.bind(r, 81721));
    }
  },
  (t) => {
    t.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        2116,
        1546,
        5081,
        6552,
        6952,
        2193,
        1311,
        7764,
        6706,
        7724,
        5201,
        5148,
        3005,
        3916,
        4885,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        1365,
        8629,
        7858,
        5164,
        4542,
        5843,
        3290,
        7358
      ],
      () => t(t.s = 99774)
    ), _N_E = t.O();
  }
]);
