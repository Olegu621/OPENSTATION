(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [5063],
  {
    1019: (e, t, a) => {
      "use strict";
      a.d(t, { KidsEditorialAlbumsPage: () => y });
      var i = a(54486), n = a(50420), o = a(28303), s = a(97396), r = a(61910), l = a(43426), d = a(31500), u = a(8817), g = a(27510), c = a(97800), m = a(82644), _ = a(94376), p = a(33276), h = a(74125), N = a(80585), f = a(22603), x = a.n(f);
      let y = (0, o.PA)((e2) => {
        var t2, a2, o2, f2;
        let { id: y2 } = e2, {
          kids: { kidsEditorialAlbumSubpage: P },
          settings: { isMobile: j }
        } = (0, h.Pjs)(), S = (0, h.W6M)(), { contentScrollRef: E, setContentScrollRef: v } = (0, h.gKY)(), { formatMessage: b } = (0, l.A)(), C = (0, u.c)((e3) => {
          P.getAlbums({ page: e3, pageSize: 20 });
        });
        P.isNotFound && (0, s.notFound)(), (0, r.useEffect)(
          () => () => {
            P.reset();
          },
          [P]
        );
        let L = (0, g.L)(() => ({
          Footer: () => (0, i.jsx)(N.A, { children: (0, i.jsx)(N.wi, { className: x().footer }) })
        }));
        if ((0, h.Jzs)(P.isResolved), (0, h.XcE)(P.pagesLoader, C), P.isNeededToLoad && (0, r.use)(P.getData({ id: y2, page: 0, pageSize: 20 })), P.isSomethingWrong)
          return (0, i.jsx)(m.w, {});
        let D = P.isLoading ? 20 : null != (o2 = null == (a2 = P.pagesLoader) || null == (t2 = a2.pager) ? void 0 : t2.total) ? o2 : 0;
        return (0, i.jsx)(h.nVz, {
          pageId: h._Q$.KIDS_EDITORIAL_ALBUMS,
          children: (0, i.jsx)(p.hO, {
            scrollElement: E,
            outerTitle: P.title,
            children: (0, i.jsxs)("div", {
              className: x().root,
              ...(0, d.Am)(d.Xk.kids.KIDS_EDITORIAL_ALBUMS),
              children: [
                (0, i.jsx)(N.Y9, {
                  variant: N.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: S.canBack,
                  children: (0, i.jsx)(c.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: P.title
                  })
                }),
                (0, i.jsx)(N.$$, {
                  context: { listAriaLabel: b({ id: "mixes.albums-list" }, { genreName: P.title || "" }) },
                  className: (0, n.$)(x().scrollContainer, x().important),
                  customComponents: L,
                  itemContentCallback: (e3) => {
                    let t3 = P.albums[e3], a3 = b(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: b({ id: "entity-names.album" }) }
                    );
                    return t3 ? (0, i.jsx)(_.aX, { withLikesCount: true, album: t3, contentLinesCount: 3 }, t3.id) : (0, i.jsx)(N.Vt, { isActive: true, "aria-label": a3 });
                  },
                  totalCount: D,
                  onGetDataByPage: C,
                  pageSize: 20,
                  totalRequests: null != (f2 = P.pagesLoader.requestsCount) ? f2 : 0,
                  listClassName: x().content,
                  itemClassName: x().item,
                  handleRef: v,
                  isMobileLayout: j,
                  useWindowScroll: j
                })
              ]
            })
          })
        });
      });
    },
    13127: (e, t, a) => {
      "use strict";
      a.d(t, {
        jM: () => m.KidsCategoryPage,
        u3: () => _.KidsEditorialAlbumsPage,
        bU: () => p.KidsEditorialPlaylistsPage,
        GY: () => c
      });
      var i = a(74125), n = a(93064), o = a(14287), s = a(46423), r = a(26433);
      let l = n.gK.compose(
        n.gK.model("KidsEditorialAlbumPage", {
          errorStatusCode: n.gK.maybeNull(n.gK.number),
          title: n.gK.maybeNull(n.gK.string),
          albumsData: n.gK.array(n.gK.model({ id: n.gK.number })),
          pagesLoader: (0, r.Ij)(s.GI)
        }),
        r.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === i.GuX.PENDING;
          },
          get isNotFound() {
            let t3 = e2.errorStatusCode === o.X1.NOT_FOUND || e2.errorStatusCode === o.X1.BAD_REQUEST, a2 = e2.pagesLoader.isEmpty;
            return e2.isRejected && t3 || a2;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          },
          get albums() {
            var a2;
            return null != (a2 = e2.pagesLoader.items) ? a2 : [];
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          getAlbums: (0, n.L3)(function* (t3) {
            let { page: a2 = 0, pageSize: r2 = 20 } = t3, { albumResource: l2, modelActionsLogger: d2 } = (0, n._$)(e2);
            if (e2.loadingState === i.GuX.RESOLVE && e2.pagesLoader.isPageNeedToLoad(a2)) {
              e2.pagesLoader.setPageState(a2, i.GuX.PENDING);
              try {
                let t4 = a2 * r2, i2 = e2.albumsData.slice(t4, t4 + r2).map((e3) => e3.id), n2 = yield l2.getAlbums({ albumIds: i2 }), o2 = { page: a2, perPage: r2, total: e2.albumsData.length }, d3 = n2.map(s.e7);
                e2.pagesLoader.setItems(d3, { page: a2, pager: o2 });
              } catch (t4) {
                d2.error(t4), e2.pagesLoader.setItems(null, { responseStatus: i.FlZ.ERROR, page: a2 }), t4 instanceof o.GX && (t4.statusCode === o.X1.NOT_FOUND || t4.statusCode === o.X1.BAD_REQUEST) && (e2.errorStatusCode = o.X1.NOT_FOUND), e2.loadingState !== i.GuX.IDLE && (e2.loadingState = i.GuX.REJECT);
              }
            }
          }),
          getData: (0, n.L3)(function* (a2) {
            let { id: s2, page: r2 = 0, pageSize: l2 = 20 } = a2, { childrenLandingResource: d2, modelActionsLogger: u2 } = (0, n._$)(e2);
            if (e2.loadingState !== i.GuX.PENDING)
              try {
                var g2;
                e2.loadingState = i.GuX.PENDING;
                let a3 = yield d2.getEditorialAlbum({ id: s2 });
                e2.title = a3.title, e2.albumsData = (0, n.wg)((null != (g2 = a3.entities) ? g2 : []).map((e3) => ({ id: e3 }))), e2.loadingState !== i.GuX.IDLE && (e2.loadingState = i.GuX.RESOLVE), yield t2.getAlbums({ page: r2, pageSize: l2 });
              } catch (t3) {
                u2.error(t3), t3 instanceof o.GX && (t3.statusCode === o.X1.NOT_FOUND || t3.statusCode === o.X1.BAD_REQUEST) && (e2.errorStatusCode = o.X1.NOT_FOUND), e2.loadingState !== i.GuX.IDLE && (e2.loadingState = i.GuX.REJECT);
              }
          }),
          reset() {
            e2.loadingState = i.GuX.IDLE, e2.title = null, e2.pagesLoader.reset(), e2.albumsData = (0, n.wg)([]), e2.errorStatusCode = null;
          }
        };
        return t2;
      });
      var d = a(13611);
      let u = n.gK.compose(
        n.gK.model("KidsEditorialPlaylistPage", {
          errorStatusCode: n.gK.maybeNull(n.gK.number),
          title: n.gK.maybeNull(n.gK.string),
          playlistsData: n.gK.array(n.gK.model({ uid: n.gK.number, kind: n.gK.number })),
          pagesLoader: (0, r.Ij)(d.$o)
        }),
        r.XT
      ).views((e2) => {
        let t2 = {
          get isLoading() {
            return e2.isNeededToLoad || e2.loadingState === i.GuX.PENDING;
          },
          get isNotFound() {
            let t3 = e2.errorStatusCode === o.X1.NOT_FOUND || e2.errorStatusCode === o.X1.BAD_REQUEST, a2 = e2.pagesLoader.isEmpty;
            return e2.isRejected && t3 || a2;
          },
          get isSomethingWrong() {
            return e2.isRejected && !t2.isNotFound;
          },
          get playlists() {
            var a2;
            return null != (a2 = e2.pagesLoader.items) ? a2 : [];
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          getPlaylists: (0, n.L3)(function* (t3) {
            let { page: a2 = 0, pageSize: s2 = 20 } = t3, { playlistsResource: r2, modelActionsLogger: l2 } = (0, n._$)(e2);
            if (e2.loadingState === i.GuX.RESOLVE && e2.pagesLoader.isPageNeedToLoad(a2)) {
              e2.pagesLoader.setPageState(a2, i.GuX.PENDING);
              try {
                let t4 = a2 * s2, i2 = e2.playlistsData.slice(t4, t4 + s2), n2 = yield r2.getPlaylists({
                  playlistIds: i2.map((e3) => "".concat(e3.uid, ":").concat(e3.kind)),
                  resumeStream: false
                }), o2 = { page: a2, perPage: s2, total: e2.playlistsData.length }, l3 = n2.playlists.map(d.jX);
                e2.pagesLoader.setItems(l3, { page: a2, pager: o2 });
              } catch (t4) {
                l2.error(t4), e2.pagesLoader.setItems(null, { responseStatus: i.FlZ.ERROR, page: a2 }), t4 instanceof o.GX && (t4.statusCode === o.X1.NOT_FOUND || t4.statusCode === o.X1.BAD_REQUEST) && (e2.errorStatusCode = o.X1.NOT_FOUND), e2.loadingState !== i.GuX.IDLE && (e2.loadingState = i.GuX.REJECT);
              }
            }
          }),
          getData: (0, n.L3)(function* (a2) {
            let { id: s2, page: r2 = 0, pageSize: l2 = 20 } = a2, { childrenLandingResource: d2, modelActionsLogger: u2 } = (0, n._$)(e2);
            if (e2.loadingState !== i.GuX.PENDING)
              try {
                var g2;
                e2.loadingState = i.GuX.PENDING;
                let a3 = yield d2.getEditorialPlaylist({ id: s2 });
                e2.title = a3.title, e2.playlistsData = (0, n.wg)(
                  (null != (g2 = a3.entities) ? g2 : []).map((e3) => ({ uid: e3.uid, kind: e3.kind }))
                ), e2.loadingState !== i.GuX.IDLE && (e2.loadingState = i.GuX.RESOLVE), yield t2.getPlaylists({ page: r2, pageSize: l2 });
              } catch (t3) {
                u2.error(t3), t3 instanceof o.GX && (t3.statusCode === o.X1.NOT_FOUND || t3.statusCode === o.X1.BAD_REQUEST) && (e2.errorStatusCode = o.X1.NOT_FOUND), e2.loadingState !== i.GuX.IDLE && (e2.loadingState = i.GuX.REJECT);
              }
          }),
          reset() {
            e2.loadingState = i.GuX.IDLE, e2.title = null, e2.pagesLoader.reset(), e2.playlistsData = (0, n.wg)([]), e2.errorStatusCode = null;
          }
        };
        return t2;
      });
      var g = a(4542);
      let c = n.gK.model("KidsPage", { landing: g.Ju, kidsEditorialPlaylistSubpage: u, kidsEditorialAlbumSubpage: l });
      var m = a(25945), _ = a(1019), p = a(49841);
      a(67923), a(75669);
    },
    22603: (e) => {
      e.exports = {
        root: "KidsEditorialAlbumsPage_root__7rHF8",
        scrollContainer: "KidsEditorialAlbumsPage_scrollContainer__nQVlt",
        important: "KidsEditorialAlbumsPage_important__hmmxn",
        footer: "KidsEditorialAlbumsPage_footer__6rwU1",
        item: "KidsEditorialAlbumsPage_item__Wc243",
        content: "KidsEditorialAlbumsPage_content__u3zcW"
      };
    },
    24993: (e) => {
      e.exports = {
        root: "KidsEditorialPlaylistsPage_root__HeHqc",
        scrollContainer: "KidsEditorialPlaylistsPage_scrollContainer__Hy6HY",
        important: "KidsEditorialPlaylistsPage_important__283cd",
        footer: "KidsEditorialPlaylistsPage_footer___UaP5",
        item: "KidsEditorialPlaylistsPage_item__0wBk2",
        content: "KidsEditorialPlaylistsPage_content__6wWkP"
      };
    },
    25945: (e, t, a) => {
      "use strict";
      a.d(t, { KidsCategoryPage: () => j });
      var i = a(54486), n = a(50420), o = a(28303), s = a(97396), r = a(61910), l = a(31500), d = a(56231), u = a(97800), g = a(4542), c = a(82644), m = a(33276), _ = a(74125), p = a(80585), h = a(44193), N = a.n(h), f = a(27510), x = a(91582), y = a.n(x);
      let P = (0, o.PA)(() => {
        let { experiments: e2 } = (0, _.Pjs)(), t2 = e2.checkExperiment(_.zal.WebNextWaveAgentExperiment, "on"), a2 = (0, f.L)(
          () => t2 ? (0, i.jsx)(p.OY, { isShimmerVisible: true, isShimmerActive: true, isShimmerCentered: true }) : (0, i.jsx)(g.Rj, { isActive: true, length: 4 })
        );
        return (0, i.jsxs)("div", {
          className: y().root,
          children: [
            (0, i.jsx)("div", { children: a2 }),
            (0, i.jsx)(p.OY, { isShimmerVisible: true, isShimmerActive: true }),
            (0, i.jsx)(p.OY, { isShimmerVisible: true, isShimmerActive: true })
          ]
        });
      }), j = (0, o.PA)((e2) => {
        let { categoryId: t2 } = e2, { kids: a2 } = (0, _.Pjs)(), { contentScrollRef: o2, setContentScrollRef: h2 } = (0, _.gKY)(), f2 = (0, _.W6M)();
        (0, r.useEffect)(() => () => a2.landing.reset(), [a2.landing]), (0, _.Jzs)(a2.landing.isResolved), a2.landing.isLoadedAndEmpty && (0, s.notFound)();
        let x2 = (0, g._9)(a2.landing), y2 = (0, r.useMemo)(
          () => a2.landing.isLoading || a2.landing.isNeededToLoad ? (0, i.jsx)(P, {}) : (0, i.jsx)(g.EA, {
            landing: a2.landing,
            errorComponent: (0, i.jsx)(c.w, { className: N().error, withBackwardControl: false })
          }),
          [a2.landing.loadingState, a2.landing]
        );
        return a2.landing.isNeededToLoad && (0, r.use)(a2.landing.getChildrenSkeleton({ categoryId: t2 })), (0, i.jsx)(_.nVz, {
          pageId: _._Q$.KIDS_CATEGORY,
          children: (0, i.jsxs)(m.hO, {
            scrollElement: o2,
            outerTitle: a2.landing.title,
            children: [
              (0, i.jsx)(p.Y9, {
                variant: p.Vw.TEXT,
                withForwardControl: false,
                withBackwardControl: f2.canBack,
                children: (0, i.jsx)("div", {
                  className: N().header,
                  children: (0, i.jsx)(u.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    children: a2.landing.title
                  })
                })
              }),
              (0, i.jsxs)(d.N, {
                className: N().root,
                containerClassName: N().content,
                ref: h2,
                ...(0, l.Am)(l.Xk.kids.KIDS_CATEGORY_PAGE),
                children: [
                  (0, i.jsx)("div", {
                    className: (0, n.$)(N().landing, { [N().landing_onlyWizard]: x2 }),
                    children: y2
                  }),
                  (0, i.jsx)(p.A, { children: (0, i.jsx)(p.wi, { className: N().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    27005: (e) => {
      e.exports = {
        root: "KidsPage_root__yycsJ",
        content: "KidsPage_content__08pPR",
        header: "KidsPage_header__2Gk2l",
        landing: "KidsPage_landing__3QZZj",
        landing_onlyWizard: "KidsPage_landing_onlyWizard__xKyDo",
        footer: "KidsPage_footer__p7SVD",
        error: "KidsPage_error__qa7Qo"
      };
    },
    31622: (e, t, a) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return l;
        }
      });
      let i = a(54486), n = a(61910), o = a(91165);
      function s(e2) {
        return { default: e2 && "default" in e2 ? e2.default : e2 };
      }
      a(98944);
      let r = { loader: () => Promise.resolve(s(() => null)), loading: null, ssr: true }, l = function(e2) {
        let t2 = { ...r, ...e2 }, a2 = (0, n.lazy)(() => t2.loader().then(s)), l2 = t2.loading;
        function d(e3) {
          let s2 = l2 ? (0, i.jsx)(l2, { isLoading: true, pastDelay: true, error: null }) : null, r2 = !t2.ssr || !!t2.loading, d2 = r2 ? n.Suspense : n.Fragment, u = t2.ssr ? (0, i.jsxs)(i.Fragment, { children: [null, (0, i.jsx)(a2, { ...e3 })] }) : (0, i.jsx)(o.BailoutToCSR, { reason: "next/dynamic", children: (0, i.jsx)(a2, { ...e3 }) });
          return (0, i.jsx)(d2, { ...r2 ? { fallback: s2 } : {}, children: u });
        }
        return d.displayName = "LoadableComponent", d;
      };
    },
    36446: (e, t, a) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return n;
        }
      });
      let i = a(45221)._(a(31622));
      function n(e2, t2) {
        var a2;
        let n2 = {};
        "function" == typeof e2 && (n2.loader = e2);
        let o = { ...n2, ...t2 };
        return (0, i.default)({ ...o, modules: null == (a2 = o.loadableGenerated) ? void 0 : a2.modules });
      }
      ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", { value: true }), Object.assign(t.default, t), e.exports = t.default);
    },
    42421: (e, t, a) => {
      "use strict";
      a.d(t, { M: () => i.NotFound });
      var i = a(65034);
    },
    44193: (e) => {
      e.exports = {
        root: "KidsCategoryPage_root__bk7_R",
        content: "KidsCategoryPage_content__LN0NB",
        header: "KidsCategoryPage_header__Agys3",
        landing: "KidsCategoryPage_landing__aSDYw",
        landing_onlyWizard: "KidsCategoryPage_landing_onlyWizard__3EC9N",
        footer: "KidsCategoryPage_footer__BQhqi",
        error: "KidsCategoryPage_error__tSXF7"
      };
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    49841: (e, t, a) => {
      "use strict";
      a.d(t, { KidsEditorialPlaylistsPage: () => y });
      var i = a(54486), n = a(50420), o = a(28303), s = a(97396), r = a(61910), l = a(43426), d = a(31500), u = a(8817), g = a(27510), c = a(97800), m = a(82644), _ = a(33276), p = a(83909), h = a(74125), N = a(80585), f = a(24993), x = a.n(f);
      let y = (0, o.PA)((e2) => {
        var t2, a2, o2;
        let { id: f2 } = e2, {
          kids: { kidsEditorialPlaylistSubpage: y2 },
          settings: { isMobile: P }
        } = (0, h.Pjs)(), j = (0, h.W6M)(), { contentScrollRef: S, setContentScrollRef: E } = (0, h.gKY)(), { formatMessage: v } = (0, l.A)(), b = (0, u.c)((e3) => {
          y2.getPlaylists({ page: e3, pageSize: 20 });
        });
        y2.isNotFound && (0, s.notFound)(), (0, r.useEffect)(
          () => () => {
            y2.reset();
          },
          [y2]
        );
        let C = (0, g.L)(() => ({
          Footer: () => (0, i.jsx)(N.A, { children: (0, i.jsx)(N.wi, { className: x().footer }) })
        }));
        if ((0, h.Jzs)(y2.isResolved), (0, h.XcE)(y2.pagesLoader, b), y2.isNeededToLoad && (0, r.use)(y2.getData({ id: f2, page: 0, pageSize: 20 })), y2.isSomethingWrong)
          return (0, i.jsx)(m.w, {});
        let L = y2.isLoading ? 20 : null != (a2 = null == (t2 = y2.pagesLoader.pager) ? void 0 : t2.total) ? a2 : 0;
        return (0, i.jsx)(h.nVz, {
          pageId: h._Q$.KIDS_EDITORIAL_PLAYLISTS,
          children: (0, i.jsx)(_.hO, {
            scrollElement: S,
            outerTitle: y2.title,
            children: (0, i.jsxs)("div", {
              className: x().root,
              ...(0, d.Am)(d.Xk.kids.KIDS_EDITORIAL_PLAYLISTS),
              children: [
                (0, i.jsx)(N.Y9, {
                  variant: N.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: j.canBack,
                  children: (0, i.jsx)(c.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: y2.title
                  })
                }),
                (0, i.jsx)(N.$$, {
                  context: { listAriaLabel: v({ id: "mixes.playlists-list" }, { genreName: y2.title || "" }) },
                  className: (0, n.$)(x().scrollContainer, x().important),
                  customComponents: C,
                  itemContentCallback: (e3) => {
                    let t3 = y2.playlists[e3], a3 = v(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: v({ id: "entity-names.playlist" }) }
                    );
                    return t3 ? (0, i.jsx)(p.B6, { playlist: t3, contentLinesCount: 3 }, t3.key) : (0, i.jsx)(N.Vt, { isActive: true, "aria-label": a3 });
                  },
                  totalCount: L,
                  onGetDataByPage: b,
                  pageSize: 20,
                  totalRequests: null != (o2 = y2.pagesLoader.requestsCount) ? o2 : 0,
                  listClassName: x().content,
                  itemClassName: x().item,
                  handleRef: E,
                  isMobileLayout: P,
                  useWindowScroll: P
                })
              ]
            })
          })
        });
      });
    },
    57249: (e, t, a) => {
      "use strict";
      e.exports = a.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    62295: (e, t, a) => {
      Promise.resolve().then(a.bind(a, 82527));
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65034: (e, t, a) => {
      "use strict";
      a.d(t, { NotFound: () => p });
      var i = a(54486), n = a(50420), o = a(28303), s = a(47713), r = a(77881), l = a(5956), d = a(97800), u = a(74125), g = a(80585), c = a(61910), m = a(46215), _ = a.n(m);
      let p = (0, o.PA)((e2) => {
        let { className: t2, title: a2, description: o2, iconVariant: m2 = "musicLogo", iconClassName: p2, iconSize: h } = e2, { contentRef: N } = (0, u.gKY)(), f = (0, u.ZpR)(u.Zyd.main.href);
        (0, u.LZB)();
        let { handleNavigateToMain: x } = (0, u.D5F)(f);
        return (0, u.NBO)(true), !(function() {
          let { location: e3 } = (0, u.Pjs)();
          (0, c.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, i.jsxs)("div", {
          className: (0, n.$)(_().root, { [_().root_desktop]: !N }, t2),
          children: [
            (0, i.jsx)(g.Lh, { withBackwardFallback: "/", className: _().navigation, withForwardControl: false }),
            (0, i.jsxs)("div", {
              className: _().content,
              children: [
                (0, i.jsx)(l.Icon, { className: (0, n.$)(_().icon, p2), variant: m2, size: h }),
                (0, i.jsx)(d.Heading, {
                  className: (0, n.$)(_().title, _().important),
                  variant: "h3",
                  size: "xs",
                  children: a2 || (0, i.jsx)(s.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, i.jsx)(d.Caption, {
                  className: (0, n.$)(_().text, _().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: o2 || (0, i.jsx)(s.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, i.jsx)(r.$, {
                  onClick: x,
                  className: _().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, i.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, i.jsx)(s.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    67923: (e, t, a) => {
      "use strict";
      a.d(t, { KidsNotFoundPage: () => l });
      var i = a(54486), n = a(28303), o = a(61910), s = a(42421), r = a(74125);
      let l = (0, n.PA)(() => {
        let { kids: e2 } = (0, r.Pjs)();
        return (0, o.useEffect)(
          () => () => {
            e2.landing.reset();
          },
          [e2.landing]
        ), (0, i.jsx)(s.M, {});
      });
    },
    75312: (e, t, a) => {
      "use strict";
      a.d(t, { SomethingWentWrong: () => h });
      var i = a(54486), n = a(50420), o = a(28303), s = a(61910), r = a(43426), l = a(47713), d = a(77881), u = a(5956), g = a(97800), c = a(74125), m = a(80585), _ = a(63708), p = a.n(_);
      let h = (0, o.PA)((e2) => {
        let { className: t2, withBackwardControl: a2 = true } = e2, { formatMessage: o2 } = (0, r.A)(), _2 = o2({ id: "error-messages.something-went-wrong" });
        (0, c.CgZ)(_2);
        let { sendRefreshEvent: h2 } = (0, c.cYT)(), N = (0, s.useCallback)(() => {
          h2(), window.location.href = c.Zyd.main.href;
        }, [h2]), { contentRef: f } = (0, c.gKY)();
        return (0, i.jsxs)("div", {
          className: (0, n.$)(p().root, t2),
          children: [
            a2 && (0, i.jsx)(m.Lh, {
              withBackwardFallback: "/",
              className: (0, n.$)(p().navigation, { [p().navigation_desktop]: !f }),
              withForwardControl: false
            }),
            (0, i.jsxs)("div", {
              className: (0, n.$)(p().content, { [p().content_shrink]: !a2 }),
              children: [
                (0, i.jsx)(u.Icon, { className: p().icon, variant: "attention", size: "xxl" }),
                (0, i.jsx)(g.Heading, {
                  className: (0, n.$)(p().title, p().important),
                  variant: "h3",
                  size: "xs",
                  children: _2
                }),
                (0, i.jsxs)(g.Caption, {
                  className: (0, n.$)(p().text, p().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, i.jsx)(l.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, i.jsx)(d.$, {
                  onClick: N,
                  className: p().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, i.jsxs)(g.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, i.jsx)(l.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    75669: (e, t, a) => {
      "use strict";
      a.d(t, { KidsPage: () => y });
      var i = a(54486), n = a(50420), o = a(28303), s = a(61910), r = a(43426), l = a(47713), d = a(31500), u = a(6024), g = a(56231), c = a(97800), m = a(4542), _ = a(82644), p = a(33276), h = a(74125), N = a(80585), f = a(27005), x = a.n(f);
      let y = (0, o.PA)(() => {
        let { kids: e2, user: t2 } = (0, h.Pjs)(), { formatMessage: a2 } = (0, r.A)(), { contentScrollRef: o2, setContentScrollRef: f2 } = (0, h.gKY)();
        (0, s.useEffect)(() => () => e2.landing.reset(), [e2.landing]), (0, h.Jzs)(e2.landing.isResolved);
        let y2 = (0, m._9)(e2.landing);
        return e2.landing.isNeededToLoad && (0, s.use)(
          e2.landing.getSkeleton({ id: u.p.KIDS, showWizard: t2.settings.showWizard }, { preloadBlocksCount: 2 })
        ), (0, i.jsx)(h.nVz, {
          pageId: h._Q$.KIDS,
          children: (0, i.jsxs)(p.hO, {
            scrollElement: o2,
            outerTitle: a2({ id: "kids.for-kids" }),
            children: [
              (0, i.jsx)(N.Y9, {
                variant: N.Vw.TEXT,
                showControls: false,
                children: (0, i.jsx)("div", {
                  className: x().header,
                  children: (0, i.jsx)(c.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xl",
                    children: (0, i.jsx)(l.A, { id: "kids.for-kids" })
                  })
                })
              }),
              (0, i.jsxs)(g.N, {
                className: x().root,
                containerClassName: x().content,
                ref: f2,
                ...(0, d.Am)(d.Xk.kids.KIDS_PAGE),
                children: [
                  (0, i.jsx)("div", {
                    className: (0, n.$)(x().landing, { [x().landing_onlyWizard]: y2 }),
                    children: (0, i.jsx)(m.EA, {
                      landing: e2.landing,
                      errorComponent: (0, i.jsx)(_.w, { className: x().error, withBackwardControl: false })
                    })
                  }),
                  (0, i.jsx)(N.A, { children: (0, i.jsx)(N.wi, { className: x().footer }) })
                ]
              })
            ]
          })
        });
      });
    },
    82527: (e, t, a) => {
      "use strict";
      a.r(t), a.d(t, { default: () => s });
      var i = a(54486), n = a(97396), o = a(13127);
      let s = () => {
        let e2 = (0, n.useSearchParams)().get("id");
        return e2 || (0, n.notFound)(), (0, i.jsx)(o.bU, { id: e2 });
      };
    },
    82644: (e, t, a) => {
      "use strict";
      a.d(t, { w: () => i.SomethingWentWrong });
      var i = a(75312);
    },
    83645: (e, t, a) => {
      "use strict";
      a.d(t, { default: () => n.a });
      var i = a(36446), n = a.n(i);
    },
    91165: (e, t, a) => {
      "use strict";
      function i(e2) {
        let { reason: t2, children: a2 } = e2;
        return a2;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return i;
        }
      }), a(39201);
    },
    91582: (e) => {
      e.exports = { root: "KidsCategoryPageShimmer_root__0V_bC" };
    },
    97151: (e, t, a) => {
      "use strict";
      a.d(t, { XU: () => g });
      var i, n, o = a(41500), s = a(61910), r = a(43426);
      !(function(e2) {
        e2.formatDate = "FormattedDate", e2.formatTime = "FormattedTime", e2.formatNumber = "FormattedNumber", e2.formatList = "FormattedList", e2.formatDisplayName = "FormattedDisplayName";
      })(i || (i = {})), (function(e2) {
        e2.formatDate = "FormattedDateParts", e2.formatTime = "FormattedTimeParts", e2.formatNumber = "FormattedNumberParts", e2.formatList = "FormattedListParts";
      })(n || (n = {}));
      var l = function(e2) {
        var t2 = (0, r.A)(), a2 = e2.value, i2 = e2.children, n2 = (0, o.__rest)(e2, ["value", "children"]);
        return i2(t2.formatNumberToParts(a2, n2));
      };
      function d(e2) {
        var t2 = function(t3) {
          var a2 = (0, r.A)(), i2 = t3.value, n2 = t3.children, s2 = (0, o.__rest)(t3, ["value", "children"]), l2 = "string" == typeof i2 ? new Date(i2 || 0) : i2;
          return n2("formatDate" === e2 ? a2.formatDateToParts(l2, s2) : a2.formatTimeToParts(l2, s2));
        };
        return t2.displayName = n[e2], t2;
      }
      function u(e2) {
        var t2 = function(t3) {
          var a2 = (0, r.A)(), i2 = t3.value, n2 = t3.children, l2 = (0, o.__rest)(t3, ["value", "children"]), d2 = a2[e2](i2, l2);
          if ("function" == typeof n2) return n2(d2);
          var u2 = a2.textComponent || s.Fragment;
          return s.createElement(u2, null, d2);
        };
        return t2.displayName = i[e2], t2;
      }
      l.displayName = "FormattedNumberParts", l.displayName = "FormattedNumberParts";
      var g = u("formatDate");
      u("formatTime"), u("formatNumber"), u("formatList"), u("formatDisplayName"), d("formatDate"), d("formatTime");
    },
    98944: (e, t, a) => {
      "use strict";
      function i(e2) {
        let { moduleIds: t2 } = e2;
        return null;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return i;
        }
      }), a(54486), a(92803), a(14367), a(32038);
    }
  },
  (e) => {
    e.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1546,
        5081,
        6552,
        6952,
        2193,
        2036,
        2116,
        1311,
        7764,
        6706,
        7724,
        5201,
        5148,
        3005,
        3916,
        4885,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        1365,
        8629,
        7858,
        5164,
        4542,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 62295)
    ), _N_E = e.O();
  }
]);
