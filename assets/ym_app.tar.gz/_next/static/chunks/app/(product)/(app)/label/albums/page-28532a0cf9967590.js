(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3008],
  {
    2405: (t, o, e) => {
      "use strict";
      e.d(o, { SortDropdown: () => v });
      var n = e(54486), s = e(28303), r = e(61910), a = e(47713), i = e(31500), l = e(11405), c = e(8817), d = e(77881), _ = e(71656), x = e(5956), m = e(97800), g = e(74125), u = e(90229), h = e(46353), p = e.n(h);
      let N = {
        [l.g.RATING]: (0, n.jsx)(a.A, { id: "sort.sort-by-rating" }),
        [l.g.YEAR]: (0, n.jsx)(a.A, { id: "sort.sort-by-year" })
      }, v = (0, s.PA)((t2) => {
        var o2;
        let { sortModel: e2, onSort: s2 } = t2, {
          settings: { isMobile: h2 }
        } = (0, g.Pjs)(), v2 = (0, c.c)((t3) => {
          (0, u.W)(t3.id) && e2.sortBy !== t3.id && (e2.setSortBy(t3.id), s2());
        }), j = (0, r.useMemo)(
          () => h2 ? (0, n.jsx)(d.$, {
            radius: "xxxl",
            className: p().button,
            icon: (0, n.jsx)(x.Icon, { variant: "filter", size: "xs" })
          }) : (0, n.jsxs)(d.$, {
            radius: "xxxl",
            className: p().button,
            ...(0, i.Am)(i.Kq.sort.SORT_DROPDOWN_BUTTON),
            children: [
              (0, n.jsx)(m.Caption, {
                variant: "span",
                size: "m",
                weight: "medium",
                ...(0, i.Am)(i.Kq.sort.SORT_DROPDOWN_BUTTON_CAPTION),
                children: e2.sortBy ? N[e2.sortBy] : (0, n.jsx)(a.A, { id: "sort.select-filter" })
              }),
              (0, n.jsx)(x.Icon, {
                size: "xxs",
                variant: "arrowDown",
                ...(0, i.Am)(i.Kq.sort.SORT_DROPDOWN_BUTTON_ICON)
              })
            ]
          }),
          [h2, e2.sortBy]
        );
        return (0, n.jsx)(_.ms, {
          placement: h2 ? "bottom" : "top",
          isMobile: h2,
          strategy: "fixed",
          className: p().root,
          onSelect: v2,
          reference: j,
          offsetOptions: { mainAxis: 10, crossAxis: -50 },
          defaultValue: null != (o2 = e2.sortBy) ? o2 : l.g.YEAR,
          containerClassName: p().container,
          header: h2 ? (0, n.jsx)("div", { className: p().header }) : void 0,
          ...(0, i.Am)(i.Kq.sort.SORT_DROPDOWN),
          children: Object.values(l.g).map(
            (t3) => (0, n.jsx)(_.c$, { id: t3, label: N[t3], ...(0, i.Am)(i.Kq.sort.SORT_DROPDOWN_ITEM) }, t3)
          )
        });
      });
    },
    40188: (t, o, e) => {
      "use strict";
      e.d(o, { useSort: () => i });
      var n = e(61910), s = e(11405), r = e(74125), a = e(90229);
      let i = (t2) => {
        let { sortModel: o2 } = t2, e2 = (0, r.XJ9)();
        (0, n.useLayoutEffect)(() => {
          let t3 = new URL(window.location.href).searchParams.get(r.K3F.SORT);
          t3 && (0, a.W)(t3) ? o2.setSortBy(t3) : o2.setSortBy(s.g.YEAR);
        }, [o2]), (0, n.useEffect)(() => {
          if (o2.sortBy) {
            let t3 = (0, r.bJ)(r.K3F.SORT, o2.sortBy);
            t3 && e2(t3);
          }
        }, [e2, o2.sortBy]);
      };
    },
    42421: (t, o, e) => {
      "use strict";
      e.d(o, { M: () => n.NotFound });
      var n = e(65034);
    },
    46215: (t) => {
      t.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    46353: (t) => {
      t.exports = {
        root: "SortDropdown_root__d1JmQ",
        button: "SortDropdown_button__SjTI7",
        header: "SortDropdown_header__kj8yV",
        container: "SortDropdown_container__dyVF_"
      };
    },
    61288: (t, o, e) => {
      "use strict";
      var n;
      e.d(o, { x: () => n }), (function(t2) {
        t2.ASC = "asc", t2.DESC = "desc";
      })(n || (n = {}));
    },
    62516: (t, o, e) => {
      Promise.resolve().then(e.bind(e, 64948));
    },
    63708: (t) => {
      t.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    64948: (t, o, e) => {
      "use strict";
      e.r(o), e.d(o, { default: () => i });
      var n = e(54486), s = e(97396), r = e(14726), a = e(74125);
      let i = () => {
        let t2 = (0, s.useSearchParams)().get("labelId");
        return t2 && (0, a.LLJ)(t2) || (0, s.notFound)(), (0, n.jsx)(r.oM, { labelId: t2 });
      };
    },
    65034: (t, o, e) => {
      "use strict";
      e.d(o, { NotFound: () => u });
      var n = e(54486), s = e(50420), r = e(28303), a = e(47713), i = e(77881), l = e(5956), c = e(97800), d = e(74125), _ = e(80585), x = e(61910), m = e(46215), g = e.n(m);
      let u = (0, r.PA)((t2) => {
        let { className: o2, title: e2, description: r2, iconVariant: m2 = "musicLogo", iconClassName: u2, iconSize: h } = t2, { contentRef: p } = (0, d.gKY)(), N = (0, d.ZpR)(d.Zyd.main.href);
        (0, d.LZB)();
        let { handleNavigateToMain: v } = (0, d.D5F)(N);
        return (0, d.NBO)(true), !(function() {
          let { location: t3 } = (0, d.Pjs)();
          (0, x.useEffect)(
            () => (t3.setNotFound(true), () => {
              t3.setNotFound(false);
            }),
            [t3]
          );
        })(), (0, n.jsxs)("div", {
          className: (0, s.$)(g().root, { [g().root_desktop]: !p }, o2),
          children: [
            (0, n.jsx)(_.Lh, { withBackwardFallback: "/", className: g().navigation, withForwardControl: false }),
            (0, n.jsxs)("div", {
              className: g().content,
              children: [
                (0, n.jsx)(l.Icon, { className: (0, s.$)(g().icon, u2), variant: m2, size: h }),
                (0, n.jsx)(c.Heading, {
                  className: (0, s.$)(g().title, g().important),
                  variant: "h3",
                  size: "xs",
                  children: e2 || (0, n.jsx)(a.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, n.jsx)(c.Caption, {
                  className: (0, s.$)(g().text, g().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: r2 || (0, n.jsx)(a.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, n.jsx)(i.$, {
                  onClick: v,
                  className: g().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, n.jsx)(c.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, n.jsx)(a.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    75312: (t, o, e) => {
      "use strict";
      e.d(o, { SomethingWentWrong: () => h });
      var n = e(54486), s = e(50420), r = e(28303), a = e(61910), i = e(43426), l = e(47713), c = e(77881), d = e(5956), _ = e(97800), x = e(74125), m = e(80585), g = e(63708), u = e.n(g);
      let h = (0, r.PA)((t2) => {
        let { className: o2, withBackwardControl: e2 = true } = t2, { formatMessage: r2 } = (0, i.A)(), g2 = r2({ id: "error-messages.something-went-wrong" });
        (0, x.CgZ)(g2);
        let { sendRefreshEvent: h2 } = (0, x.cYT)(), p = (0, a.useCallback)(() => {
          h2(), window.location.href = x.Zyd.main.href;
        }, [h2]), { contentRef: N } = (0, x.gKY)();
        return (0, n.jsxs)("div", {
          className: (0, s.$)(u().root, o2),
          children: [
            e2 && (0, n.jsx)(m.Lh, {
              withBackwardFallback: "/",
              className: (0, s.$)(u().navigation, { [u().navigation_desktop]: !N }),
              withForwardControl: false
            }),
            (0, n.jsxs)("div", {
              className: (0, s.$)(u().content, { [u().content_shrink]: !e2 }),
              children: [
                (0, n.jsx)(d.Icon, { className: u().icon, variant: "attention", size: "xxl" }),
                (0, n.jsx)(_.Heading, {
                  className: (0, s.$)(u().title, u().important),
                  variant: "h3",
                  size: "xs",
                  children: g2
                }),
                (0, n.jsxs)(_.Caption, {
                  className: (0, s.$)(u().text, u().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, n.jsx)(l.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, n.jsx)(c.$, {
                  onClick: p,
                  className: u().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, n.jsxs)(_.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, n.jsx)(l.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    82644: (t, o, e) => {
      "use strict";
      e.d(o, { w: () => n.SomethingWentWrong });
      var n = e(75312);
    },
    90229: (t, o, e) => {
      "use strict";
      e.d(o, { W: () => s });
      var n = e(11405);
      let s = (t2) => !!t2 && (t2 === n.g.RATING || t2 === n.g.YEAR);
    }
  },
  (t) => {
    t.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1546,
        5081,
        2036,
        2116,
        3146,
        6952,
        1426,
        1604,
        1311,
        7764,
        6706,
        5148,
        3005,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4826,
        8629,
        2353,
        1656,
        4726,
        5843,
        3290,
        7358
      ],
      () => t(t.s = 62516)
    ), _N_E = t.O();
  }
]);
