(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2626],
  {
    5807: (e, t, n) => {
      "use strict";
      n.d(t, { LandingPage: () => h });
      var r = n(54486), a = n(28303), o = n(61910), i = n(31500), s = n(56231), l = n(97800), d = n(4542), c = n(82644), u = n(33276), m = n(74125), _ = n(80585), g = n(58141), f = n.n(g);
      let h = (0, a.PA)((e2) => {
        let { skeleton: t2 } = e2, { landing: n2 } = (0, m.Pjs)(), a2 = (0, m.W6M)(), { contentScrollRef: g2, setContentScrollRef: h2 } = (0, m.gKY)();
        return ((0, o.useEffect)(() => () => n2.reset(), [n2]), (0, m.Jzs)(n2.isResolved), n2.isNeededToLoad && (0, o.use)(n2.getSkeleton({ id: t2, showWizard: false }, { preloadBlocksCount: 2 })), n2.isRejected) ? (0, r.jsx)(c.w, {}) : (0, r.jsx)(m.nVz, {
          pageId: m._Q$.LANDING,
          children: (0, r.jsx)(m.lSq, {
            skeleton: t2,
            children: (0, r.jsx)(u.hO, {
              scrollElement: g2,
              headerThreshold: 134,
              children: (0, r.jsxs)(s.N, {
                className: f().root,
                containerClassName: f().content,
                ref: h2,
                ...(0, i.Am)(i.Xk.landing.LANDING_PAGE),
                children: [
                  (0, r.jsxs)("div", {
                    className: f().header,
                    children: [
                      a2.canBack && (0, r.jsx)(_.Lh, { withForwardControl: false, withBackwardControl: a2.canBack }),
                      (0, r.jsx)(l.Heading, {
                        variant: "h1",
                        weight: "bold",
                        size: "xl",
                        className: f().title,
                        ...(0, i.Am)(i.Xk.landing.LANDING_PAGE_HEADER),
                        children: n2.title
                      })
                    ]
                  }),
                  (0, r.jsx)("div", {
                    className: f().landing,
                    children: (0, r.jsx)(d.EA, {
                      landing: n2,
                      errorComponent: (0, r.jsx)(c.w, { className: f().error, withBackwardControl: false })
                    })
                  }),
                  (0, r.jsx)(_.A, { children: (0, r.jsx)(_.wi, { className: f().footer }) })
                ]
              })
            })
          })
        });
      });
    },
    10372: (e, t, n) => {
      Promise.resolve().then(n.bind(n, 55339));
    },
    27895: (e, t, n) => {
      "use strict";
      n.d(t, { LandingNotFoundPage: () => l });
      var r = n(54486), a = n(28303), o = n(61910), i = n(42421), s = n(74125);
      let l = (0, a.PA)(() => {
        let { landing: e2 } = (0, s.Pjs)();
        return (0, o.useEffect)(
          () => () => {
            e2.reset();
          },
          [e2]
        ), (0, r.jsx)(i.M, {});
      });
    },
    31622: (e, t, n) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return l;
        }
      });
      let r = n(54486), a = n(61910), o = n(91165);
      function i(e2) {
        return { default: e2 && "default" in e2 ? e2.default : e2 };
      }
      n(98944);
      let s = { loader: () => Promise.resolve(i(() => null)), loading: null, ssr: true }, l = function(e2) {
        let t2 = { ...s, ...e2 }, n2 = (0, a.lazy)(() => t2.loader().then(i)), l2 = t2.loading;
        function d(e3) {
          let i2 = l2 ? (0, r.jsx)(l2, { isLoading: true, pastDelay: true, error: null }) : null, s2 = !t2.ssr || !!t2.loading, d2 = s2 ? a.Suspense : a.Fragment, c = t2.ssr ? (0, r.jsxs)(r.Fragment, { children: [null, (0, r.jsx)(n2, { ...e3 })] }) : (0, r.jsx)(o.BailoutToCSR, { reason: "next/dynamic", children: (0, r.jsx)(n2, { ...e3 }) });
          return (0, r.jsx)(d2, { ...s2 ? { fallback: i2 } : {}, children: c });
        }
        return d.displayName = "LoadableComponent", d;
      };
    },
    36446: (e, t, n) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return a;
        }
      });
      let r = n(45221)._(n(31622));
      function a(e2, t2) {
        var n2;
        let a2 = {};
        "function" == typeof e2 && (a2.loader = e2);
        let o = { ...a2, ...t2 };
        return (0, r.default)({ ...o, modules: null == (n2 = o.loadableGenerated) ? void 0 : n2.modules });
      }
      ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", { value: true }), Object.assign(t.default, t), e.exports = t.default);
    },
    42421: (e, t, n) => {
      "use strict";
      n.d(t, { M: () => r.NotFound });
      var r = n(65034);
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    55339: (e, t, n) => {
      "use strict";
      n.r(t), n.d(t, { default: () => i });
      var r = n(54486), a = n(97396);
      n(27895);
      var o = n(5807);
      let i = () => {
        let e2 = (0, a.useSearchParams)(), t2 = e2.get("skeleton");
        return t2 || (0, a.notFound)(), (0, r.jsx)(o.LandingPage, { skeleton: t2 }, e2.toString());
      };
    },
    57249: (e, t, n) => {
      "use strict";
      e.exports = n.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    58141: (e) => {
      e.exports = {
        content: "LandingPage_content__ovHlJ",
        root: "LandingPage_root__B2lPp",
        header: "LandingPage_header__TiraG",
        title: "LandingPage_title__gsIx4",
        footer: "LandingPage_footer__K9y8K",
        error: "LandingPage_error__mEsH2"
      };
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65034: (e, t, n) => {
      "use strict";
      n.d(t, { NotFound: () => f });
      var r = n(54486), a = n(50420), o = n(28303), i = n(47713), s = n(77881), l = n(5956), d = n(97800), c = n(74125), u = n(80585), m = n(61910), _ = n(46215), g = n.n(_);
      let f = (0, o.PA)((e2) => {
        let { className: t2, title: n2, description: o2, iconVariant: _2 = "musicLogo", iconClassName: f2, iconSize: h } = e2, { contentRef: p } = (0, c.gKY)(), x = (0, c.ZpR)(c.Zyd.main.href);
        (0, c.LZB)();
        let { handleNavigateToMain: N } = (0, c.D5F)(x);
        return (0, c.NBO)(true), !(function() {
          let { location: e3 } = (0, c.Pjs)();
          (0, m.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, r.jsxs)("div", {
          className: (0, a.$)(g().root, { [g().root_desktop]: !p }, t2),
          children: [
            (0, r.jsx)(u.Lh, { withBackwardFallback: "/", className: g().navigation, withForwardControl: false }),
            (0, r.jsxs)("div", {
              className: g().content,
              children: [
                (0, r.jsx)(l.Icon, { className: (0, a.$)(g().icon, f2), variant: _2, size: h }),
                (0, r.jsx)(d.Heading, {
                  className: (0, a.$)(g().title, g().important),
                  variant: "h3",
                  size: "xs",
                  children: n2 || (0, r.jsx)(i.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, r.jsx)(d.Caption, {
                  className: (0, a.$)(g().text, g().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: o2 || (0, r.jsx)(i.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, r.jsx)(s.$, {
                  onClick: N,
                  className: g().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, r.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, r.jsx)(i.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    75312: (e, t, n) => {
      "use strict";
      n.d(t, { SomethingWentWrong: () => h });
      var r = n(54486), a = n(50420), o = n(28303), i = n(61910), s = n(43426), l = n(47713), d = n(77881), c = n(5956), u = n(97800), m = n(74125), _ = n(80585), g = n(63708), f = n.n(g);
      let h = (0, o.PA)((e2) => {
        let { className: t2, withBackwardControl: n2 = true } = e2, { formatMessage: o2 } = (0, s.A)(), g2 = o2({ id: "error-messages.something-went-wrong" });
        (0, m.CgZ)(g2);
        let { sendRefreshEvent: h2 } = (0, m.cYT)(), p = (0, i.useCallback)(() => {
          h2(), window.location.href = m.Zyd.main.href;
        }, [h2]), { contentRef: x } = (0, m.gKY)();
        return (0, r.jsxs)("div", {
          className: (0, a.$)(f().root, t2),
          children: [
            n2 && (0, r.jsx)(_.Lh, {
              withBackwardFallback: "/",
              className: (0, a.$)(f().navigation, { [f().navigation_desktop]: !x }),
              withForwardControl: false
            }),
            (0, r.jsxs)("div", {
              className: (0, a.$)(f().content, { [f().content_shrink]: !n2 }),
              children: [
                (0, r.jsx)(c.Icon, { className: f().icon, variant: "attention", size: "xxl" }),
                (0, r.jsx)(u.Heading, {
                  className: (0, a.$)(f().title, f().important),
                  variant: "h3",
                  size: "xs",
                  children: g2
                }),
                (0, r.jsxs)(u.Caption, {
                  className: (0, a.$)(f().text, f().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, r.jsx)(l.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, r.jsx)(d.$, {
                  onClick: p,
                  className: f().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, r.jsxs)(u.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, r.jsx)(l.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    82644: (e, t, n) => {
      "use strict";
      n.d(t, { w: () => r.SomethingWentWrong });
      var r = n(75312);
    },
    83645: (e, t, n) => {
      "use strict";
      n.d(t, { default: () => a.a });
      var r = n(36446), a = n.n(r);
    },
    91165: (e, t, n) => {
      "use strict";
      function r(e2) {
        let { reason: t2, children: n2 } = e2;
        return n2;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return r;
        }
      }), n(39201);
    },
    97151: (e, t, n) => {
      "use strict";
      n.d(t, { XU: () => u });
      var r, a, o = n(41500), i = n(61910), s = n(43426);
      !(function(e2) {
        e2.formatDate = "FormattedDate", e2.formatTime = "FormattedTime", e2.formatNumber = "FormattedNumber", e2.formatList = "FormattedList", e2.formatDisplayName = "FormattedDisplayName";
      })(r || (r = {})), (function(e2) {
        e2.formatDate = "FormattedDateParts", e2.formatTime = "FormattedTimeParts", e2.formatNumber = "FormattedNumberParts", e2.formatList = "FormattedListParts";
      })(a || (a = {}));
      var l = function(e2) {
        var t2 = (0, s.A)(), n2 = e2.value, r2 = e2.children, a2 = (0, o.__rest)(e2, ["value", "children"]);
        return r2(t2.formatNumberToParts(n2, a2));
      };
      function d(e2) {
        var t2 = function(t3) {
          var n2 = (0, s.A)(), r2 = t3.value, a2 = t3.children, i2 = (0, o.__rest)(t3, ["value", "children"]), l2 = "string" == typeof r2 ? new Date(r2 || 0) : r2;
          return a2("formatDate" === e2 ? n2.formatDateToParts(l2, i2) : n2.formatTimeToParts(l2, i2));
        };
        return t2.displayName = a[e2], t2;
      }
      function c(e2) {
        var t2 = function(t3) {
          var n2 = (0, s.A)(), r2 = t3.value, a2 = t3.children, l2 = (0, o.__rest)(t3, ["value", "children"]), d2 = n2[e2](r2, l2);
          if ("function" == typeof a2) return a2(d2);
          var c2 = n2.textComponent || i.Fragment;
          return i.createElement(c2, null, d2);
        };
        return t2.displayName = r[e2], t2;
      }
      l.displayName = "FormattedNumberParts", l.displayName = "FormattedNumberParts";
      var u = c("formatDate");
      c("formatTime"), c("formatNumber"), c("formatList"), c("formatDisplayName"), d("formatDate"), d("formatTime");
    },
    98944: (e, t, n) => {
      "use strict";
      function r(e2) {
        let { moduleIds: t2 } = e2;
        return null;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return r;
        }
      }), n(54486), n(92803), n(14367), n(32038);
    }
  },
  (e) => {
    e.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        2116,
        1546,
        5081,
        6552,
        6952,
        2193,
        2036,
        484,
        1311,
        7764,
        6706,
        7724,
        5201,
        5148,
        3005,
        3916,
        4885,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        1365,
        8629,
        7858,
        5164,
        4542,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 10372)
    ), _N_E = e.O();
  }
]);
