(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1287, 9618],
  {
    2608: (e, r, t) => {
      "use strict";
      t.d(r, { b: () => s });
      var i = t(15099), n = t(80585);
      let s = (e2) => {
        switch (e2.type) {
          case i._.PODCAST:
            return n.cp.PODCAST;
          case i._.AUDIOBOOK:
            return n.cp.AUDIOBOOK;
          case i._.FAIRY_TALE:
            return n.cp.FAIRY_TALE;
          default:
            return n.cp.ALBUM;
        }
      };
    },
    9567: (e, r, t) => {
      "use strict";
      t.d(r, { MyMusicDownloadedTracksPage: () => E });
      var i = t(54486), n = t(50420), s = t(28303), o = t(61910), a = t(43426), l = t(31500), d = t(63585), m = t(8817), u = t(89511), c = t(82644), v = t(33276), h = t(21365), b = t(74125), P = t(80585), g = t(76310), _ = t.n(g), p = t(47713), y = t(5956), f = t(97800), k = t(14114), A = t.n(k);
      let T = (0, s.PA)(() => {
        var e2;
        let {
          myMusic: { downloadedTracks: r2 }
        } = (0, b.Pjs)(), t2 = (0, i.jsx)(f.Caption, { variant: "span", size: "s", weight: "medium", "aria-hidden": true, children: "•" }), n2 = [];
        (null == (e2 = r2.tracks) ? void 0 : e2.length) && n2.push(
          (0, i.jsx)(f.Caption, {
            variant: "span",
            size: "s",
            weight: "medium",
            lineClamp: 1,
            children: (0, i.jsx)(p.A, { id: "entity-names.tracks-count", values: { value: r2.tracks.length } })
          })
        );
        let s2 = Math.floor(r2.tracksDurationInMinutes / 60), a2 = Math.floor(r2.tracksDurationInMinutes % 60);
        return (s2 || a2) && (n2.push(t2), n2.push(
          (0, i.jsx)(f.Caption, {
            variant: "span",
            size: "s",
            weight: "medium",
            children: (0, i.jsx)(p.A, { id: "time.hours-minutes", values: { hours: s2, minutes: a2 } })
          })
        )), (0, i.jsx)("div", { className: A().root, children: n2.map((e3, r3) => (0, o.cloneElement)(e3, { key: r3 })) });
      });
      var x = t(12962), C = t.n(x);
      let w = (0, s.PA)(() => {
        let { isScrolling: e2 } = (0, o.useContext)(P.B9), r2 = (0, b.W6M)(), {
          myMusic: { downloadedTracks: t2 },
          settings: { isMobile: n2 },
          slam: s2
        } = (0, b.Pjs)(), { from: a2 } = (0, b.fyy)({ pageId: b._Q$.OWN_TRACKS, blockId: b.UfI.TRACK_LIST }), l2 = (0, b.PT7)(), u2 = (0, b.brA)(), { isPlaying: c2, togglePlay: v2 } = (0, b.Dx4)({
          playContextParams: {
            contextData: { type: d.K.Various, meta: { id: b._Q$.DOWNLOADS_TRACKS }, from: a2 },
            entitiesData: t2.entitiesData,
            loadContextMeta: false
          }
        }), h2 = (0, m.c)(() => {
          l2() || (v2(), u2(!c2));
        });
        return (0, i.jsx)("header", {
          className: C().root,
          "aria-hidden": e2,
          children: (0, i.jsxs)("div", {
            className: C().container,
            children: [
              !s2.isOfflineModeEnabled && r2.canBack && (0, i.jsx)(P.Lh, {
                withForwardControl: false,
                withBackwardControl: r2.canBack,
                shouldFocusOnMount: !e2,
                buttonSize: "xxs"
              }),
              (0, i.jsxs)("div", {
                className: C().titleContainer,
                children: [
                  (0, i.jsx)(f.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xs",
                    lineClamp: 1,
                    className: C().title,
                    children: (0, i.jsx)(p.A, { id: "offline.downloaded-tracks" })
                  }),
                  (0, i.jsx)(T, {})
                ]
              }),
              !t2.isEmpty && (0, i.jsx)(P.DM, {
                withRipple: true,
                buttonVariant: "default",
                radius: "xxxl",
                size: "s",
                color: "primary",
                iconSize: "xxs",
                isPlaying: c2,
                onClick: h2,
                className: C().playButton,
                ariaHidden: e2,
                tabIndex: e2 ? -1 : 0,
                children: !n2 && (0, i.jsx)(p.A, { id: "player-actions.listen" })
              })
            ]
          })
        });
      });
      var O = t(61336), D = t.n(O);
      let M = (0, s.PA)(
        () => (0, i.jsxs)(i.Fragment, {
          children: [
            (0, i.jsx)(w, {}),
            (0, i.jsxs)("div", {
              className: D().root,
              children: [
                (0, i.jsx)(y.Icon, { className: D().icon, size: "l", variant: "download" }),
                (0, i.jsx)(f.Heading, {
                  className: D().title,
                  variant: "div",
                  size: "xs",
                  children: (0, i.jsx)(p.A, { id: "offline.downloaded-empty" })
                }),
                (0, i.jsx)(f.Caption, {
                  className: D().text,
                  variant: "span",
                  type: "controls",
                  size: "l",
                  weight: "normal",
                  children: (0, i.jsx)(p.A, { id: "offline.download-for-offline" })
                })
              ]
            })
          ]
        })
      ), S = (0, s.PA)(() => {
        let { isScrolling: e2 } = (0, o.useContext)(P.B9), r2 = (0, b.W6M)(), {
          myMusic: { downloadedTracks: t2 },
          settings: { isMobile: s2 },
          slam: a2
        } = (0, b.Pjs)(), { from: l2 } = (0, b.fyy)({ pageId: b._Q$.OWN_TRACKS, blockId: b.UfI.TRACK_LIST }), u2 = (0, b.brA)(), c2 = (0, b.PT7)(), { isPlaying: v2, togglePlay: h2 } = (0, b.Dx4)({
          playContextParams: {
            contextData: { type: d.K.Various, meta: { id: b._Q$.DOWNLOADS_TRACKS }, from: l2 },
            entitiesData: t2.entitiesData,
            loadContextMeta: false
          }
        }), g2 = (0, m.c)(() => {
          c2() || (h2(), u2(!v2));
        });
        return (0, i.jsx)(P.Y9, {
          variant: P.Vw.COMPOSITE,
          "aria-hidden": !e2,
          stickyChild: (0, i.jsxs)("div", {
            className: C().container,
            children: [
              !a2.isOfflineModeEnabled && r2.canBack && (0, i.jsx)(P.Lh, {
                withForwardControl: false,
                withBackwardControl: r2.canBack,
                shouldFocusOnMount: false,
                buttonSize: "xxs"
              }),
              (0, i.jsx)(f.Heading, {
                variant: "h1",
                weight: "bold",
                size: "xs",
                lineClamp: 1,
                className: C().stickyTitle,
                children: (0, i.jsx)(p.A, { id: "offline.downloaded-tracks" })
              }),
              !t2.isEmpty && (0, i.jsx)(P.DM, {
                withRipple: true,
                buttonVariant: "default",
                radius: "xxxl",
                size: "s",
                color: "primary",
                iconSize: "xxs",
                isPlaying: v2,
                onClick: g2,
                className: (0, n.$)(C().playButton, { [C().stickyPlayButton]: !s2 }),
                ariaHidden: !e2,
                tabIndex: e2 ? 0 : -1,
                children: !s2 && (0, i.jsx)(p.A, { id: "player-actions.listen" })
              })
            ]
          }),
          stickyClassName: (0, n.$)(C().stickyHeader, C().important),
          staticClassName: (0, n.$)(C().staticHeader, C().important)
        });
      }), E = (0, s.PA)(() => {
        var e2;
        let r2 = (0, b.jRO)(), { contentScrollRef: t2, setContentScrollRef: s2 } = (0, b.gKY)(), { formatMessage: g2 } = (0, a.A)(), {
          myMusic: { downloadedTracks: p2 }
        } = (0, b.Pjs)(), { from: y2 } = (0, b.fyy)({ pageId: b._Q$.OWN_TRACKS, blockId: b.UfI.TRACK_LIST }), f2 = (0, b.wZZ)(), k2 = (0, m.c)(() => {
          r2.tracksController && p2.getData(r2.tracksController);
        });
        (0, u.L)(k2), (0, o.useEffect)(() => {
          p2.isNeededToLoad && k2();
        }, [p2.isNeededToLoad, k2]), (0, o.useEffect)(
          () => () => {
            p2.reset();
          },
          [p2]
        ), (0, b.Jzs)(p2.isResolved);
        let A2 = (0, o.useMemo)(
          () => ({
            Header: () => (0, i.jsx)(w, {}),
            Footer: () => (0, i.jsx)(P.A, { children: (0, i.jsx)(P.wi, { className: _().footer }) })
          }),
          []
        );
        if (p2.loadingState === b.GuX.REJECT) return (0, i.jsx)(c.w, {});
        if (p2.isEmpty) return (0, i.jsx)(M, {});
        let T2 = (null == (e2 = p2.items) ? void 0 : e2.length) || 10;
        return (0, i.jsx)(b.nVz, {
          pageId: b._Q$.DOWNLOADS_TRACKS,
          children: (0, i.jsx)(v.hO, {
            scrollElement: t2,
            children: (0, i.jsxs)("div", {
              className: _().pageContainer,
              children: [
                (0, i.jsx)(S, {}),
                (0, i.jsx)(P.$$, {
                  context: { listAriaLabel: g2({ id: "offline.downloaded-track-list" }) },
                  className: (0, n.$)(_().root, _().important),
                  listClassName: _().content,
                  customComponents: A2,
                  totalCount: T2,
                  itemContentCallback: (e3) => {
                    var r3;
                    let t3 = null == (r3 = p2.items) ? void 0 : r3[e3];
                    return t3 ? (0, i.jsx)(
                      h.Kt,
                      {
                        track: t3,
                        playContextParams: f2(t3.id, {
                          contextData: { type: d.K.Various, meta: { id: b._Q$.DOWNLOADS_TRACKS }, from: y2 },
                          entitiesData: p2.entitiesData,
                          queueParams: { index: e3, entityId: t3.id },
                          loadContextMeta: false
                        })
                      },
                      t3.id
                    ) : (0, i.jsx)(P.DS, { isActive: true, className: _().trackShimmer, variant: b.Xjt.PLAYLIST });
                  },
                  debounceDurationInMs: 300,
                  initialItemCount: T2,
                  handleRef: s2,
                  shouldTriggerRangeChangedOn: [T2],
                  testId: l.Xk.myMusic.MY_MUSIC_DOWNLOADED_TRACKS_PAGE
                })
              ]
            })
          })
        });
      });
    },
    12962: (e) => {
      e.exports = {
        root: "MyMusicDownloadedTracksPageHeader_root__2vfuc",
        container: "MyMusicDownloadedTracksPageHeader_container__hQ_wt",
        title: "MyMusicDownloadedTracksPageHeader_title__Ncn5X",
        stickyTitle: "MyMusicDownloadedTracksPageHeader_stickyTitle__Efl0U",
        playButton: "MyMusicDownloadedTracksPageHeader_playButton__seWgC",
        stickyPlayButton: "MyMusicDownloadedTracksPageHeader_stickyPlayButton__JVicd",
        titleContainer: "MyMusicDownloadedTracksPageHeader_titleContainer__rLAkS",
        staticHeader: "MyMusicDownloadedTracksPageHeader_staticHeader__LSVC8",
        important: "MyMusicDownloadedTracksPageHeader_important__JIubq",
        stickyHeader: "MyMusicDownloadedTracksPageHeader_stickyHeader__MuQh4"
      };
    },
    14114: (e) => {
      e.exports = { root: "MyMusicDownloadedTracksInfo_root__yIYHx" };
    },
    21390: (e, r, t) => {
      "use strict";
      t.d(r, { L: () => m });
      var i, n = t(94377), s = t(61910), o = {
        6699: (e2, r2, t2) => {
          Object.defineProperty(r2, "__esModule", { value: true }), r2.useDebouncedToggle = void 0;
          let i2 = t2(352), n2 = t2(810);
          r2.useDebouncedToggle = (e3) => {
            let { delay: r3, initialState: t3, throttleTimeout: s2 } = e3, o2 = (0, n2.useRef)(null), [a2, l2] = (0, n2.useState)(!!t3), d2 = (0, n2.useMemo)(
              () => (0, i2.throttle)(() => {
                l2(!t3), o2.current && window.clearTimeout(o2.current), o2.current = window.setTimeout(() => {
                  l2(!!t3);
                }, r3);
              }, s2),
              [r3, t3, s2]
            ), m2 = (0, n2.useCallback)(() => {
              l2(!!t3), o2.current && window.clearTimeout(o2.current);
            }, [t3]);
            return (0, n2.useEffect)(
              () => () => {
                o2.current && window.clearTimeout(o2.current);
              },
              []
            ), { state: a2, handleDebouncedToggle: d2, reset: m2 };
          };
        },
        361: (e2, r2) => {
          Object.defineProperty(r2, "__esModule", { value: true }), r2.getElementFromRefOrElement = void 0, r2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        352: (e2) => {
          e2.exports = n;
        },
        810: (e2) => {
          e2.exports = i || (i = t.t(s, 2));
        }
      }, a = {};
      function l(e2) {
        var r2 = a[e2];
        if (void 0 !== r2) return r2.exports;
        var t2 = a[e2] = { exports: {} };
        return o[e2](t2, t2.exports, l), t2.exports;
      }
      var d = {};
      (() => {
        Object.defineProperty(d, "__esModule", { value: true }), d.useScroll = void 0;
        let e2 = l(810), r2 = l(361), t2 = l(6699);
        d.useScroll = (i2) => {
          let { onScroll: n2, listenIsScrolling: s2, elementRef: o2 } = i2, { state: a2, handleDebouncedToggle: l2 } = (0, t2.useDebouncedToggle)({ delay: 1e3, throttleTimeout: 100 }), d2 = (0, e2.useCallback)(() => {
            s2 && l2(), null == n2 || n2();
          }, [s2, l2, n2]);
          return (0, e2.useEffect)(() => {
            let e3 = (0, r2.getElementFromRefOrElement)(o2);
            if (null === e3) return;
            let t3 = null != e3 ? e3 : window, i3 = { capture: true, passive: true };
            return t3.addEventListener("scroll", d2, i3), () => t3.removeEventListener("scroll", d2, i3);
          }, [o2, d2]), a2;
        };
      })(), d.__esModule;
      var m = d.useScroll;
    },
    25751: (e, r, t) => {
      "use strict";
      t.d(r, { useDownloadedTracks: () => l });
      var i = t(61910), n = t(12460), s = t(8817), o = t(74125);
      let a = [n.DT.IDLE, n.DT.DOWNLOADED], l = (e2) => {
        var r2;
        let t2 = (0, o.jRO)(), l2 = (0, s.c)((r3) => {
          let { state: t3 } = r3;
          a.includes(t3.loadingState) && e2();
        });
        (0, i.useEffect)(() => {
          var r3, i2;
          return null == (r3 = t2.store) || r3.tracks.events.on(n.je.STATE_CHANGED, e2), null == (i2 = t2.store) || i2.tracks.events.on(n.je.ENTITY_CHANGED, l2), () => {
            var r4, i3;
            null == (r4 = t2.store) || r4.tracks.events.off(n.je.STATE_CHANGED, e2), null == (i3 = t2.store) || i3.tracks.events.off(n.je.ENTITY_CHANGED, l2);
          };
        }, [e2, l2, null == (r2 = t2.store) ? void 0 : r2.tracks.events]);
      };
    },
    28795: (e, r, t) => {
      "use strict";
      t.d(r, { Chart: () => h });
      var i = t(54486), n = t(50420), s = t(28303), o = t(61910), a = t(43426), l = t(31500), d = t(60423), m = t(5956), u = t(97800), c = t(49423), v = t.n(c);
      let h = (0, s.PA)((e2) => {
        let {
          progress: r2,
          withIcon: t2,
          withCrownIcon: s2,
          position: c2,
          weight: h2 = "normal",
          isDisliked: b,
          isDisabled: P,
          className: g,
          positionClassName: _
        } = e2, { formatMessage: p } = (0, a.A)(), y = r2 || t2, f = (0, o.useMemo)(() => {
          if (s2) return "crown";
          switch (r2) {
            case d._.UP:
              return "chartUp";
            case d._.DOWN:
              return "chartDown";
            case d._.NEW:
              return "chartNew";
            default:
              return "chartSame";
          }
        }, [r2, s2]), k = (0, o.useMemo)(() => {
          switch (r2) {
            case d._.UP:
              return p({ id: "entity-names.chart-up" });
            case d._.DOWN:
              return p({ id: "entity-names.chart-down" });
            case d._.NEW:
              return p({ id: "entity-names.chart-new" });
            default:
              return p({ id: "entity-names.chart-same" });
          }
        }, [p, r2]), A = s2 ? "crown" : r2;
        return (0, i.jsxs)("div", {
          className: (0, n.$)(v().root, g),
          ...(0, l.Am)(l.OA.chart.CHART_PROGRESS),
          children: [
            (0, i.jsx)(u.Caption, {
              variant: "div",
              weight: h2,
              type: "entity",
              size: "m",
              className: (0, n.$)(v().position, _, { [v().position_disliked]: b, [v().position_disabled]: P }),
              ...(0, l.Am)(l.OA.chart.CHART_PROGRESS_POSITION),
              children: c2
            }),
            y && (0, i.jsx)(m.Icon, {
              variant: f,
              size: "xxs",
              "aria-label": k,
              className: (0, n.$)(v().progress, v()["progress_".concat(A)], {
                [v().progress_disliked]: b,
                [v().progress_disabled]: P
              }),
              ...(0, l.Am)(l.OA.chart.CHART_PROGRESS_ICON)
            })
          ]
        });
      });
    },
    29406: (e) => {
      e.exports = {
        root: "SplashScreen_root__3jzFk",
        root_dark: "SplashScreen_root_dark__0OcZj",
        root_light: "SplashScreen_root_light__XAJTf",
        root_hidden: "SplashScreen_root_hidden__BO7tp",
        "fade-out": "SplashScreen_fade-out__uNMY4",
        video: "SplashScreen_video__wFSy5"
      };
    },
    30662: (e, r, t) => {
      "use strict";
      t.d(r, { useAlbumAnalyticsAppScreenName: () => o });
      var i = t(61910), n = t(43350), s = t(15099);
      let o = (e2) => (0, i.useMemo)(() => {
        switch (e2) {
          case s._.PODCAST:
            return n.QT.PodcastScreen;
          case s._.AUDIOBOOK:
            return n.QT.AudiobookScreen;
          default:
            return n.QT.AlbumScreen;
        }
      }, [e2]);
    },
    31757: (e, r, t) => {
      "use strict";
      t.d(r, { useAlbumDisclaimer: () => n });
      var i = t(74125);
      let n = (e2) => {
        let { album: r2, callback: t2, shouldHistoryBack: n2 } = e2;
        return (0, i.lVe)({
          entity: r2,
          callback: t2,
          modalBehavior: void 0 === n2 ? void 0 : { shouldHistoryBack: n2 },
          preventDefaultWhenSafe: true
        });
      };
    },
    33276: (e, r, t) => {
      "use strict";
      t.d(r, { hO: () => c, jr: () => v, jp: () => h, QZ: () => n }), t(77607);
      var i = t(61910);
      let n = (e2, r2, t2) => {
        let n2 = null != t2 && t2;
        return {
          topColorStyle: (0, i.useMemo)(() => {
            if (void 0 === r2) return;
            let t3 = n2 ? 93 : 17, i2 = r2 - t3;
            return {
              "--average-color-background": e2,
              transform: "translateY(".concat(r2 >= t3 ? 0 : i2, "px)"),
              opacity: 1
            };
          }, [r2, n2, e2]),
          headerStyle: (0, i.useMemo)(() => ({ "--average-color-background": e2 }), [e2])
        };
      };
      var s = t(54486), o = t(1365), a = t(28303), l = t(21390), d = t(74125), m = t(80585);
      let u = (e2) => {
        let { element: r2, scrollTop: t2, isMobile: i2 } = e2, n2 = 0.6 * r2.clientHeight;
        return t2 + (i2 ? 60 : 76) >= r2.offsetTop + n2;
      }, c = (0, a.PA)((e2) => {
        let {
          children: r2,
          scrollElement: t2,
          outerTitle: n2 = "",
          headerElement: a2,
          headerThreshold: c2,
          shouldHideHeader: v2
        } = e2, [h2, b] = (0, i.useState)(n2), [P, g] = (0, i.useState)(null), [_, p] = (0, i.useState)(null), [y, f] = (0, i.useState)(null), [k, A] = (0, i.useState)(false), [T, x] = (0, i.useState)(false), [C, w] = (0, i.useState)(false), [O, D] = (0, i.useState)(false), {
          settings: { isMobile: M }
        } = (0, d.Pjs)();
        (0, i.useLayoutEffect)(() => {
          b(n2);
        }, [n2]);
        let S = (0, i.useCallback)(() => {
          let e3 = null != c2 ? c2 : 10, r3 = a2 ? Number(a2.offsetTop) - e3 : e3;
          r3 < 0 && (r3 = 0);
          let i2 = (e4) => {
            w(e4 > r3), v2 && D(e4 > 30), (null == P ? void 0 : P.current) && A(u({ element: null == P ? void 0 : P.current, scrollTop: e4, isMobile: M })), (null == _ ? void 0 : _.current) && x(u({ element: null == _ ? void 0 : _.current, scrollTop: e4, isMobile: M }));
          };
          M ? i2(window.scrollY) : t2 && i2(t2.scrollTop);
        }, [c2, a2, M, v2, P, _, t2]);
        (0, i.useEffect)(() => {
          M ? 0 === window.scrollY && w(false) : t2 && 0 !== t2.scrollTop || w(false);
        }, [t2, null == t2 ? void 0 : t2.scrollTop, M]);
        let E = (0, i.useMemo)(
          () => M ? { onScroll: (0, o.A)(S, 200) } : { onScroll: (0, o.A)(S, 200), elementRef: t2 },
          [S, t2, M]
        );
        (0, l.L)(E);
        let j = (0, i.useMemo)(
          () => ({
            title: h2,
            setTitle: b,
            titleElement: P,
            scrollElement: M ? null : t2,
            setTitleElement: g,
            childElement: _,
            setChildElement: p,
            child: y,
            setChild: f,
            isScrolledChild: T,
            isScrolledTitle: k,
            isScrolling: C,
            isHeaderHidden: O
          }),
          [h2, k, P, t2, C, M, y, _, T, O]
        );
        return (0, s.jsx)(m.B9.Provider, { value: j, children: r2 });
      }), v = (e2) => {
        let { children: r2, child: t2, className: n2 } = e2, { setChildElement: o2, setChild: a2 } = (0, i.useContext)(m.B9), l2 = (0, i.useRef)(null);
        return (0, i.useEffect)(() => {
          (null == l2 ? void 0 : l2.current) && o2(l2), t2 && a2(t2);
        }, [l2, t2, o2, a2]), (0, i.useEffect)(
          () => () => {
            a2(null);
          },
          [a2]
        ), (0, s.jsx)("div", { ref: l2, className: n2, children: r2 });
      }, h = (e2) => {
        let { children: r2, title: t2, className: n2 } = e2, { setTitleElement: o2, setTitle: a2 } = (0, i.useContext)(m.B9), l2 = (0, i.useRef)(null);
        return (0, i.useEffect)(() => {
          (null == l2 ? void 0 : l2.current) && o2(l2), t2 && a2(t2);
        }, [l2, t2, o2, a2]), (0, i.useEffect)(
          () => () => {
            a2("");
          },
          [a2]
        ), (0, s.jsx)("div", { ref: l2, className: n2, children: r2 });
      };
    },
    38868: (e, r, t) => {
      "use strict";
      t.d(r, { useOnPinClick: () => c });
      var i = t(54486), n = t(63930), s = t(61910), o = t(43426), a = t(74125), l = t(80585), d = t(28303), m = t(2608);
      let u = (0, d.PA)((e2) => {
        let { album: r2, closeToast: t2 } = e2, n2 = (0, m.b)(r2);
        return (0, i.jsx)(l.k4, {
          closeToast: t2,
          entityVariant: n2,
          coverUri: r2.coverUri,
          entityUrl: r2.url,
          entityTitle: r2.title,
          isPinned: r2.isPinned,
          radius: "s"
        });
      }), c = (e2) => {
        let { user: r2 } = (0, a.Pjs)(), { notify: t2 } = (0, a.lkh)(), { formatMessage: d2 } = (0, o.A)(), [m2, c2] = (0, s.useState)(false);
        return (0, s.useCallback)(async () => {
          if (!r2.isAuthorized)
            return void t2((0, i.jsx)(l.hT, { error: d2({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: a.uQT.ERROR
            });
          if (m2) return;
          let s2 = { ...(0, n.HO)(e2), url: e2.url, isPinned: !e2.isPinned };
          c2(true);
          let o2 = await e2.togglePin();
          c2(false), o2 ? t2((0, i.jsx)(u, { album: s2 }), { containerId: a.uQT.INFO }) : t2((0, i.jsx)(l.hT, { error: d2({ id: "error-messages.error-during-action" }) }), {
            containerId: a.uQT.ERROR
          });
        }, [e2, d2, t2, m2, r2.isAuthorized]);
      };
    },
    39618: (e, r, t) => {
      "use strict";
      t.r(r), t.d(r, { default: () => c });
      var i = t(54486), n = t(50420), s = t(61910), o = t(62443), a = t(98313), l = t(74125), d = t(29406), m = t.n(d), u = t(49124);
      let c = (e2) => {
        let { children: r2 } = e2, { state: t2, toggleTrue: d2 } = (0, o.e)(false), { state: c2, toggleTrue: v } = (0, o.e)(false), { getThemeFromStorage: h } = (0, l.QDo)(new a.si()), b = (0, s.useMemo)(() => {
          var e3;
          return null != (e3 = h()) ? e3 : (0, l.VDQ)();
        }, [h]), P = (0, s.useCallback)(
          (e3) => {
            let r3 = u.env.ASSET_PREFIX || "";
            return "".concat(r3, "/media/splash_screen/splash_screen_").concat(b, ".").concat(e3);
          },
          [b]
        ), g = (0, s.useMemo)(() => ({ isVisible: !t2 }), [t2]);
        return (0, i.jsxs)(l.nlO.Provider, {
          value: g,
          children: [
            !t2 && (0, i.jsx)("div", {
              className: (0, n.$)(m().root, m()["root_".concat(b)], { [m().root_hidden]: c2 }),
              onAnimationEnd: d2,
              children: (0, i.jsxs)("video", {
                className: m().video,
                autoPlay: true,
                muted: true,
                playsInline: true,
                onEnded: v,
                onError: d2,
                children: [
                  (0, i.jsx)("source", { src: P("webm"), type: "video/webm" }),
                  (0, i.jsx)("source", { src: P("mp4"), type: "video/mp4" })
                ]
              })
            }),
            r2
          ]
        });
      };
    },
    42140: (e, r, t) => {
      "use strict";
      t.d(r, { t1: () => a.Chart, Iz: () => o, ws: () => n });
      var i = t(93064);
      let n = (e2) => (0, i.wg)({ position: e2.position, progress: e2.progress });
      var s = t(60423);
      let o = i.gK.model("Chart", {
        position: i.gK.maybe(i.gK.number),
        progress: i.gK.maybe(i.gK.enumeration(Object.values(s._)))
      });
      var a = t(28795);
    },
    42520: (e, r, t) => {
      "use strict";
      let i;
      t.d(r, { useMetrika: () => o });
      var n = t(61910), s = t(80506);
      let o = () => {
        let e2 = (i || (i = (0, s.a)()), i), r2 = (0, n.useSyncExternalStore)(e2.isLoaded.onChange, () => e2.isLoaded.value);
        return (0, n.useMemo)(() => ({ ...e2, isLoaded: r2 }), [r2]);
      };
    },
    46423: (e, r, t) => {
      "use strict";
      t.d(r, {
        cr: () => m.AlbumEntityNameConsumer,
        GI: () => A,
        oM: () => x,
        rU: () => a,
        e7: () => s,
        G_: () => o,
        Rl: () => l.useAlbumAnalyticsAppScreenName,
        cp: () => d.useAlbumDisclaimer,
        r_: () => m.useAlbumEntityName,
        Ek: () => u.useMarkAlbumListenedClick,
        $1: () => c.useNavigateToAlbumCPA,
        KX: () => v.useOnLikeClick,
        A7: () => h.useOnPinClick,
        PL: () => b.useOnPresaveClick,
        c5: () => P.useOnPromoLandingLikeClick
      });
      var i = t(93064), n = t(74125);
      let s = (e2) => {
        let r2 = (0, n.mxW)(e2.trailer);
        return (0, i.wg)({
          id: e2.id,
          title: e2.title,
          coverUri: e2.coverUri,
          type: e2.type,
          year: e2.year,
          version: e2.version,
          genre: e2.genre,
          likesCount: e2.likesCount,
          averageColor: (0, n.QBb)(e2.derivedColors),
          isAvailable: !!e2.available,
          trackPosition: e2.trackPosition,
          disclaimers: e2.disclaimers,
          trackCount: e2.trackCount,
          availableForPremiumUsers: e2.availableForPremiumUsers,
          availableForOptions: e2.availableForOptions || [],
          bestAlbumTracks: e2.bests,
          durationSec: e2.durationSec,
          trailer: r2,
          listeningFinished: !!e2.listeningFinished
        });
      }, o = (e2) => {
        let r2 = false;
        e2.presaveDate ? r2 = true : e2.presaved && (r2 = e2.presaved);
        let { disclaimers: t2 } = (0, n.fyr)(e2);
        return (0, i.wg)({
          id: e2.id,
          disclaimers: t2,
          isPresave: r2,
          title: e2.title,
          type: e2.type,
          coverUri: e2.coverUri,
          releaseDate: e2.releaseDate
        });
      };
      var a = (function(e2) {
        return e2.TRACK = "track", e2.TEXT = "text", e2;
      })({}), l = t(30662), d = t(31757), m = t(51672), u = t(63449), c = t(65134), v = t(96819), h = t(38868), b = t(77163), P = t(96025), g = t(15099), _ = t(93729), p = t(60049), y = t(77534), f = t(26433);
      let k = i.gK.model("TrackPosition", { volume: i.gK.number, index: i.gK.number }), A = i.gK.compose(
        i.gK.model({
          id: i.gK.number,
          title: i.gK.string,
          type: i.gK.maybe(i.gK.enumeration(Object.values(g._))),
          coverUri: i.gK.maybe(i.gK.string),
          averageColor: i.gK.maybe(i.gK.string),
          year: i.gK.maybe(i.gK.number),
          version: i.gK.maybe(i.gK.string),
          isAvailable: i.gK.optional(i.gK.boolean, true),
          availableForOptions: i.gK.maybe(i.gK.array(i.gK.enumeration(Object.values(_.E)))),
          availableForPremiumUsers: i.gK.maybe(i.gK.boolean),
          bookmateOptionRequired: i.gK.maybe(i.gK.boolean),
          genre: i.gK.maybe(i.gK.string),
          trackPosition: i.gK.maybe(k),
          disclaimers: i.gK.maybe(i.gK.array(i.gK.string)),
          trackCount: i.gK.maybe(i.gK.number),
          bestAlbumTracks: i.gK.maybe(i.gK.array(i.gK.number)),
          trailer: i.gK.maybe(f.aQ),
          durationSec: i.gK.maybe(i.gK.number),
          listeningFinished: i.gK.maybe(i.gK.boolean),
          releaseDate: i.gK.maybe(i.gK.string)
        }),
        f.tP,
        f.Ec
      ).views((e2) => {
        let r2 = {
          get url() {
            let { href: r3 } = (0, n.uvd)("/album/:albumId", { params: { albumId: e2.id } });
            return r3;
          },
          get isLiked() {
            if (!(0, i._n)(e2)) return false;
            let { library: r3 } = (0, i.Zn)(e2);
            return null == r3 ? void 0 : r3.isAlbumLiked(e2.id);
          },
          get pinId() {
            return "".concat(p._.ALBUM_ITEM).concat(e2.id);
          },
          get seeds() {
            return ["album:".concat(e2.id)];
          },
          get isAlbum() {
            return e2.type === g._.ALBUM || e2.type === g._.SINGLE;
          },
          get isPodcast() {
            return e2.type === g._.PODCAST;
          },
          get isAudiobook() {
            return e2.type === g._.AUDIOBOOK;
          },
          get isFairyTale() {
            return e2.type === g._.FAIRY_TALE;
          },
          get isNonMusic() {
            if (!(0, i._n)(e2)) return false;
            return r2.isPodcast || r2.isAudiobook || r2.isFairyTale;
          },
          get isPinned() {
            if (!(0, i._n)(e2)) return false;
            let { pinsCollection: r3 } = (0, i.Zn)(e2);
            return r3.isPinned(this.pinId);
          },
          get isLegalRejected() {
            if (!(0, i._n)(e2)) return false;
            return e2.getIsLegalRejected(e2.isAvailable);
          },
          get isUnsafeLegal() {
            if (!(0, i._n)(e2)) return false;
            return e2.getIsUnsafeLegal(e2.isAvailable);
          },
          get isAvailableOnlyForPlus() {
            var t2;
            return !e2.isAvailable && (e2.availableForPremiumUsers || !!(null == (t2 = e2.availableForOptions) ? void 0 : t2.includes(_.E.BOOKMATE)));
          },
          get shouldShowBooksBadge() {
            var s2;
            return !!(e2.bookmateOptionRequired || !e2.availableForPremiumUsers && (null == (s2 = e2.availableForOptions) ? void 0 : s2.includes(_.E.BOOKMATE)));
          },
          getDisclaimerEntityRef: (t2) => ({
            entityType: null != t2 ? t2 : r2.isPodcast ? n.nPY.PODCAST : n.nPY.ALBUM,
            entityId: e2.id
          })
        };
        return r2;
      }).actions((e2) => ({
        toggleLike: (0, i.L3)(function* () {
          if (!(0, i._n)(e2)) return;
          let { library: r2, user: t2 } = (0, i.Zn)(e2);
          if (t2.isAuthorized) {
            let n2 = yield r2.toggleAlbumLike({ entityId: e2.id, userId: t2.account.data.uid });
            return (0, i._n)(e2) && n2 === y.f.OK && (e2.isLiked ? e2.likePending() : e2.unlikePending()), n2;
          }
        }),
        togglePin: (0, i.L3)(function* () {
          if (!(0, i._n)(e2)) return;
          let { pinsCollection: r2, user: t2 } = (0, i.Zn)(e2);
          if (t2.isAuthorized) return yield r2.toggleAlbumPin({ id: e2.id }, e2.pinId);
        }),
        getKey: (r2) => "".concat(r2, "_").concat(e2.id),
        updateFinished: (r2) => {
          e2.listeningFinished = r2;
        }
      })).named("BaseAlbum");
      var T = t(71020);
      let x = i.gK.compose(
        i.gK.model("BaseUpcomingAlbum", {
          id: i.gK.number,
          isPresave: i.gK.boolean,
          title: i.gK.maybe(i.gK.string),
          type: i.gK.maybe(i.gK.enumeration(Object.values(g._))),
          coverUri: i.gK.maybe(i.gK.string),
          releaseDate: i.gK.maybe(i.gK.string)
        }),
        f.Ec
      ).actions((e2) => {
        let r2 = {
          presaveAlbum: (0, i.L3)(function* (r3) {
            let { usersResource: t2, modelActionsLogger: n2 } = (0, i._$)(e2);
            try {
              e2.isPresave = true;
              let i2 = yield t2.presaveAlbum(r3);
              return i2 === T.J.ERROR && (e2.isPresave = false), i2;
            } catch (r4) {
              return e2.isPresave = false, n2.error(r4), T.J.ERROR;
            }
          }),
          removePresaveAlbum: (0, i.L3)(function* (r3) {
            let { usersResource: t2, modelActionsLogger: n2 } = (0, i._$)(e2);
            try {
              e2.isPresave = false;
              let i2 = yield t2.removePresaveAlbum(r3);
              return i2 === T.J.ERROR && (e2.isPresave = true), i2;
            } catch (r4) {
              return e2.isPresave = true, n2.error(r4), T.J.ERROR;
            }
          }),
          toggleLike: (0, i.L3)(function* () {
            let t2;
            if (!(0, i._n)(e2)) return;
            let { user: n2 } = (0, i.Zn)(e2);
            if (n2.account.data.uid)
              return t2 = e2.isPresave ? yield r2.removePresaveAlbum({ albumId: e2.id, userId: n2.account.data.uid }) : yield r2.presaveAlbum({ albumId: e2.id, userId: n2.account.data.uid, likeAfterRelease: true }), !(0, i._n)(e2), t2;
          }),
          getKey: (r3) => "".concat(r3, "_").concat(e2.id)
        };
        return r2;
      });
    },
    49423: (e) => {
      e.exports = {
        card_root: "HorizontalCardContainer_root__YoAAP",
        root: "Chart_root__ODed_",
        position: "Chart_position__7UNY9",
        position_disliked: "Chart_position_disliked__HzjC7",
        position_disabled: "Chart_position_disabled__poZzD",
        progress: "Chart_progress__sGj4s",
        progress_up: "Chart_progress_up__y083c",
        progress_same: "Chart_progress_same__Cnbdb",
        progress_down: "Chart_progress_down__lv_ae",
        progress_crown: "Chart_progress_crown__o__Zm",
        progress_new: "Chart_progress_new__7DobI",
        progress_disliked: "Chart_progress_disliked__maVAk",
        progress_disabled: "Chart_progress_disabled__JoFqG"
      };
    },
    51672: (e, r, t) => {
      "use strict";
      t.d(r, { AlbumEntityNameConsumer: () => o, useAlbumEntityName: () => a });
      var i = t(61910), n = t(43426), s = t(15099), o = (function(e2) {
        return e2.PIN = "pin", e2;
      })({});
      let a = (e2, r2) => {
        let { formatMessage: t2 } = (0, n.A)();
        return (0, i.useMemo)(() => {
          switch (e2) {
            case s._.SINGLE:
              return t2({ id: "entity-names.single" });
            case s._.PODCAST:
              return t2({ id: "entity-names.podcast" });
            case s._.AUDIOBOOK:
              if ("pin" === r2) return t2({ id: "entity-names.book" });
              return t2({ id: "entity-names.audio" });
            case s._.FAIRY_TALE:
              return t2({ id: "entity-names.fairy-tale" });
            default:
              return t2({ id: "entity-names.album" });
          }
        }, [e2, t2, r2]);
      };
    },
    60423: (e, r, t) => {
      "use strict";
      var i;
      t.d(r, { _: () => i }), (function(e2) {
        e2.UP = "up", e2.DOWN = "down", e2.SAME = "same", e2.NEW = "new";
      })(i || (i = {}));
    },
    61336: (e) => {
      e.exports = {
        root: "MyMusicDownloadedTracksPageEmpty_root__LAXpY",
        icon: "MyMusicDownloadedTracksPageEmpty_icon__PDhk2",
        title: "MyMusicDownloadedTracksPageEmpty_title__g2w5R",
        text: "MyMusicDownloadedTracksPageEmpty_text__8RJFg"
      };
    },
    63449: (e, r, t) => {
      "use strict";
      t.d(r, { useMarkAlbumListenedClick: () => d });
      var i = t(54486), n = t(61910), s = t(43426), o = t(58623), a = t(74125), l = t(80585);
      let d = () => {
        let { user: e2, album: r2, fullscreenPlayer: t2 } = (0, a.Pjs)(), { notify: d2 } = (0, a.lkh)(), { formatMessage: m } = (0, s.A)();
        return (0, n.useCallback)(async () => {
          var n2, s2;
          if (!r2) return;
          let u = t2.modal.isOpened ? a.uQT.FULLSCREEN_ERROR : a.uQT.ERROR;
          return e2.isAuthorized ? await r2.setListeningFinishedStatus() !== o.T.OK ? void d2((0, i.jsx)(l.hT, { error: m({ id: "error-messages.error-during-action" }) }), { containerId: u }) : void (null == (s2 = r2.meta) || s2.updateFinished(!(null == (n2 = r2.meta) ? void 0 : n2.listeningFinished))) : void d2((0, i.jsx)(l.hT, { error: m({ id: "authorization-messages.need-to-authorizate" }) }), {
            containerId: u
          });
        }, [m, d2, r2, e2.isAuthorized, t2.modal.isOpened]);
      };
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65134: (e, r, t) => {
      "use strict";
      t.d(r, { useNavigateToAlbumCPA: () => s });
      var i = t(8817), n = t(74125);
      let s = (e2) => {
        let { albumId: r2, albumUrl: t2, callback: s2 } = e2, { getAlbumUrlWithSavedClid: o, checkIsCurrentAlbumPage: a } = (0, n.IQF)(), l = (0, n.pqZ)();
        return (0, i.c)((e3) => {
          if (!r2 || !t2) {
            null == s2 || s2(e3);
            return;
          }
          if (a(r2)) {
            null == e3 || e3.preventDefault(), l(o(r2, t2));
            return;
          }
          null == s2 || s2(e3);
        });
      };
    },
    71020: (e, r, t) => {
      "use strict";
      var i;
      t.d(r, { J: () => i }), (function(e2) {
        e2.OK = "ok", e2.ERROR = "error";
      })(i || (i = {}));
    },
    74261: (e, r, t) => {
      Promise.resolve().then(t.bind(t, 91165)), Promise.resolve().then(t.bind(t, 98944)), Promise.resolve().then(t.bind(t, 58360)), Promise.resolve().then(t.bind(t, 14342)), Promise.resolve().then(t.bind(t, 62662)), Promise.resolve().then(t.bind(t, 6971)), Promise.resolve().then(t.bind(t, 22674)), Promise.resolve().then(t.bind(t, 51321)), Promise.resolve().then(t.bind(t, 97800)), Promise.resolve().then(t.bind(t, 42520)), Promise.resolve().then(t.bind(t, 19781)), Promise.resolve().then(t.bind(t, 22329)), Promise.resolve().then(t.bind(t, 73488)), Promise.resolve().then(t.bind(t, 88495)), Promise.resolve().then(t.bind(t, 5594)), Promise.resolve().then(t.bind(t, 53376)), Promise.resolve().then(t.bind(t, 39618)), Promise.resolve().then(t.bind(t, 30662)), Promise.resolve().then(t.bind(t, 31757)), Promise.resolve().then(t.bind(t, 51672)), Promise.resolve().then(t.bind(t, 63449)), Promise.resolve().then(t.bind(t, 65134)), Promise.resolve().then(t.bind(t, 96819)), Promise.resolve().then(t.bind(t, 38868)), Promise.resolve().then(t.bind(t, 77163)), Promise.resolve().then(t.bind(t, 96025)), Promise.resolve().then(t.bind(t, 51887)), Promise.resolve().then(t.bind(t, 25577)), Promise.resolve().then(t.bind(t, 65327)), Promise.resolve().then(t.bind(t, 3119)), Promise.resolve().then(t.bind(t, 74808)), Promise.resolve().then(t.bind(t, 92088)), Promise.resolve().then(t.bind(t, 83154)), Promise.resolve().then(t.bind(t, 14476)), Promise.resolve().then(t.bind(t, 88332)), Promise.resolve().then(t.bind(t, 16855)), Promise.resolve().then(t.bind(t, 28795)), Promise.resolve().then(t.bind(t, 93099)), Promise.resolve().then(t.bind(t, 15640)), Promise.resolve().then(t.bind(t, 82885)), Promise.resolve().then(t.bind(t, 99733)), Promise.resolve().then(t.bind(t, 18355)), Promise.resolve().then(t.bind(t, 42691)), Promise.resolve().then(t.bind(t, 37235)), Promise.resolve().then(t.bind(t, 3781)), Promise.resolve().then(t.bind(t, 33829)), Promise.resolve().then(t.bind(t, 39906)), Promise.resolve().then(t.bind(t, 50119)), Promise.resolve().then(t.bind(t, 21179)), Promise.resolve().then(t.bind(t, 7912)), Promise.resolve().then(t.bind(t, 50193)), Promise.resolve().then(t.bind(t, 83399)), Promise.resolve().then(t.bind(t, 11450)), Promise.resolve().then(t.bind(t, 62345)), Promise.resolve().then(t.bind(t, 37408)), Promise.resolve().then(t.bind(t, 48392)), Promise.resolve().then(t.bind(t, 42488)), Promise.resolve().then(t.bind(t, 5207)), Promise.resolve().then(t.bind(t, 48284)), Promise.resolve().then(t.bind(t, 69151)), Promise.resolve().then(t.bind(t, 8871)), Promise.resolve().then(t.bind(t, 86062)), Promise.resolve().then(t.bind(t, 47937)), Promise.resolve().then(t.bind(t, 76130)), Promise.resolve().then(t.bind(t, 76858)), Promise.resolve().then(t.bind(t, 54586)), Promise.resolve().then(t.bind(t, 12938)), Promise.resolve().then(t.bind(t, 62065)), Promise.resolve().then(t.bind(t, 39194)), Promise.resolve().then(t.bind(t, 97778)), Promise.resolve().then(t.bind(t, 23728)), Promise.resolve().then(t.bind(t, 9821)), Promise.resolve().then(t.bind(t, 13868)), Promise.resolve().then(t.bind(t, 43616)), Promise.resolve().then(t.bind(t, 92810)), Promise.resolve().then(t.bind(t, 79971)), Promise.resolve().then(t.bind(t, 61920)), Promise.resolve().then(t.bind(t, 93549)), Promise.resolve().then(t.bind(t, 4242)), Promise.resolve().then(t.bind(t, 79045)), Promise.resolve().then(t.bind(t, 72850)), Promise.resolve().then(t.bind(t, 26853)), Promise.resolve().then(t.bind(t, 85905)), Promise.resolve().then(t.bind(t, 9567)), Promise.resolve().then(t.bind(t, 8394)), Promise.resolve().then(t.bind(t, 3192)), Promise.resolve().then(t.bind(t, 7286)), Promise.resolve().then(t.bind(t, 60305)), Promise.resolve().then(t.bind(t, 47203)), Promise.resolve().then(t.bind(t, 34286)), Promise.resolve().then(t.bind(t, 224)), Promise.resolve().then(t.bind(t, 24449)), Promise.resolve().then(t.bind(t, 79893)), Promise.resolve().then(t.bind(t, 81789)), Promise.resolve().then(t.bind(t, 87466)), Promise.resolve().then(t.bind(t, 39034)), Promise.resolve().then(t.bind(t, 17917)), Promise.resolve().then(t.bind(t, 11337)), Promise.resolve().then(t.bind(t, 19683)), Promise.resolve().then(t.bind(t, 53779)), Promise.resolve().then(t.bind(t, 12359)), Promise.resolve().then(t.bind(t, 88564)), Promise.resolve().then(t.bind(t, 95639)), Promise.resolve().then(t.bind(t, 57630)), Promise.resolve().then(t.bind(t, 25342)), Promise.resolve().then(t.bind(t, 34028)), Promise.resolve().then(t.bind(t, 99564)), Promise.resolve().then(t.bind(t, 95348)), Promise.resolve().then(t.bind(t, 52347)), Promise.resolve().then(t.bind(t, 61015)), Promise.resolve().then(t.bind(t, 1771)), Promise.resolve().then(t.bind(t, 80043)), Promise.resolve().then(t.bind(t, 12235)), Promise.resolve().then(t.bind(t, 8941)), Promise.resolve().then(t.bind(t, 38433)), Promise.resolve().then(t.bind(t, 8732)), Promise.resolve().then(t.bind(t, 43369)), Promise.resolve().then(t.bind(t, 47564)), Promise.resolve().then(t.bind(t, 41017)), Promise.resolve().then(t.bind(t, 27252)), Promise.resolve().then(t.bind(t, 65286)), Promise.resolve().then(t.bind(t, 45198)), Promise.resolve().then(t.bind(t, 46814)), Promise.resolve().then(t.bind(t, 92508)), Promise.resolve().then(t.bind(t, 40126)), Promise.resolve().then(t.bind(t, 83726)), Promise.resolve().then(t.bind(t, 90410)), Promise.resolve().then(t.bind(t, 13246)), Promise.resolve().then(t.bind(t, 26040)), Promise.resolve().then(t.bind(t, 92446)), Promise.resolve().then(t.bind(t, 42593)), Promise.resolve().then(t.bind(t, 70570)), Promise.resolve().then(t.bind(t, 88416)), Promise.resolve().then(t.bind(t, 24174)), Promise.resolve().then(t.bind(t, 78458)), Promise.resolve().then(t.bind(t, 59457)), Promise.resolve().then(t.bind(t, 6690)), Promise.resolve().then(t.bind(t, 88370)), Promise.resolve().then(t.bind(t, 66904)), Promise.resolve().then(t.bind(t, 39937)), Promise.resolve().then(t.bind(t, 33019)), Promise.resolve().then(t.bind(t, 38808)), Promise.resolve().then(t.bind(t, 58094)), Promise.resolve().then(t.bind(t, 78009)), Promise.resolve().then(t.bind(t, 33427)), Promise.resolve().then(t.bind(t, 30878)), Promise.resolve().then(t.bind(t, 53115)), Promise.resolve().then(t.bind(t, 52398)), Promise.resolve().then(t.bind(t, 82327)), Promise.resolve().then(t.bind(t, 17012)), Promise.resolve().then(t.bind(t, 9275)), Promise.resolve().then(t.bind(t, 17658)), Promise.resolve().then(t.bind(t, 36578)), Promise.resolve().then(t.bind(t, 66989)), Promise.resolve().then(t.bind(t, 58863)), Promise.resolve().then(t.bind(t, 60899)), Promise.resolve().then(t.bind(t, 59437)), Promise.resolve().then(t.bind(t, 43367)), Promise.resolve().then(t.bind(t, 66446)), Promise.resolve().then(t.bind(t, 86840)), Promise.resolve().then(t.bind(t, 75181)), Promise.resolve().then(t.bind(t, 99538)), Promise.resolve().then(t.bind(t, 45252)), Promise.resolve().then(t.bind(t, 59226)), Promise.resolve().then(t.bind(t, 75961)), Promise.resolve().then(t.bind(t, 33964)), Promise.resolve().then(t.bind(t, 33967)), Promise.resolve().then(t.bind(t, 64410)), Promise.resolve().then(t.bind(t, 91350)), Promise.resolve().then(t.bind(t, 4500)), Promise.resolve().then(t.bind(t, 55846)), Promise.resolve().then(t.bind(t, 65689)), Promise.resolve().then(t.bind(t, 99386)), Promise.resolve().then(t.bind(t, 5222)), Promise.resolve().then(t.bind(t, 60440)), Promise.resolve().then(t.bind(t, 37271)), Promise.resolve().then(t.bind(t, 66688)), Promise.resolve().then(t.bind(t, 76472)), Promise.resolve().then(t.bind(t, 41682)), Promise.resolve().then(t.bind(t, 77666)), Promise.resolve().then(t.bind(t, 8765)), Promise.resolve().then(t.bind(t, 48670)), Promise.resolve().then(t.bind(t, 22096)), Promise.resolve().then(t.bind(t, 33655)), Promise.resolve().then(t.bind(t, 27754)), Promise.resolve().then(t.bind(t, 47347)), Promise.resolve().then(t.bind(t, 45591)), Promise.resolve().then(t.bind(t, 52862)), Promise.resolve().then(t.bind(t, 79326)), Promise.resolve().then(t.bind(t, 73922)), Promise.resolve().then(t.bind(t, 10790)), Promise.resolve().then(t.bind(t, 78684)), Promise.resolve().then(t.bind(t, 76877)), Promise.resolve().then(t.bind(t, 61176)), Promise.resolve().then(t.bind(t, 62108)), Promise.resolve().then(t.bind(t, 75053)), Promise.resolve().then(t.bind(t, 23035)), Promise.resolve().then(t.bind(t, 82315)), Promise.resolve().then(t.bind(t, 60673)), Promise.resolve().then(t.bind(t, 5048)), Promise.resolve().then(t.bind(t, 50215)), Promise.resolve().then(t.bind(t, 78308)), Promise.resolve().then(t.bind(t, 10084)), Promise.resolve().then(t.bind(t, 58681)), Promise.resolve().then(t.bind(t, 18658)), Promise.resolve().then(t.bind(t, 6323)), Promise.resolve().then(t.bind(t, 78817)), Promise.resolve().then(t.bind(t, 7230)), Promise.resolve().then(t.bind(t, 38378)), Promise.resolve().then(t.bind(t, 35609)), Promise.resolve().then(t.bind(t, 18606)), Promise.resolve().then(t.bind(t, 68014)), Promise.resolve().then(t.bind(t, 12126)), Promise.resolve().then(t.bind(t, 52742)), Promise.resolve().then(t.bind(t, 68098)), Promise.resolve().then(t.bind(t, 89190)), Promise.resolve().then(t.bind(t, 3270)), Promise.resolve().then(t.bind(t, 1220)), Promise.resolve().then(t.bind(t, 96584)), Promise.resolve().then(t.bind(t, 54598)), Promise.resolve().then(t.bind(t, 14196)), Promise.resolve().then(t.bind(t, 20576)), Promise.resolve().then(t.bind(t, 29070)), Promise.resolve().then(t.bind(t, 35203)), Promise.resolve().then(t.bind(t, 39450)), Promise.resolve().then(t.bind(t, 77607)), Promise.resolve().then(t.bind(t, 7430)), Promise.resolve().then(t.bind(t, 24786)), Promise.resolve().then(t.bind(t, 24036)), Promise.resolve().then(t.bind(t, 34932)), Promise.resolve().then(t.bind(t, 56204)), Promise.resolve().then(t.bind(t, 75450)), Promise.resolve().then(t.bind(t, 60608)), Promise.resolve().then(t.bind(t, 33648)), Promise.resolve().then(t.bind(t, 43548)), Promise.resolve().then(t.bind(t, 69672)), Promise.resolve().then(t.bind(t, 50711)), Promise.resolve().then(t.bind(t, 5185)), Promise.resolve().then(t.bind(t, 90555)), Promise.resolve().then(t.bind(t, 5602)), Promise.resolve().then(t.bind(t, 12390)), Promise.resolve().then(t.bind(t, 58376)), Promise.resolve().then(t.bind(t, 24491)), Promise.resolve().then(t.bind(t, 61993)), Promise.resolve().then(t.bind(t, 38644)), Promise.resolve().then(t.bind(t, 93668)), Promise.resolve().then(t.bind(t, 85949)), Promise.resolve().then(t.bind(t, 17519)), Promise.resolve().then(t.bind(t, 62010)), Promise.resolve().then(t.bind(t, 16372)), Promise.resolve().then(t.bind(t, 64434)), Promise.resolve().then(t.bind(t, 33158)), Promise.resolve().then(t.bind(t, 27314)), Promise.resolve().then(t.bind(t, 93206)), Promise.resolve().then(t.bind(t, 37226)), Promise.resolve().then(t.bind(t, 13811)), Promise.resolve().then(t.bind(t, 45645)), Promise.resolve().then(t.bind(t, 24126)), Promise.resolve().then(t.bind(t, 20406)), Promise.resolve().then(t.bind(t, 21940)), Promise.resolve().then(t.bind(t, 26086)), Promise.resolve().then(t.bind(t, 96838)), Promise.resolve().then(t.bind(t, 10358)), Promise.resolve().then(t.bind(t, 23143)), Promise.resolve().then(t.bind(t, 51828)), Promise.resolve().then(t.bind(t, 51725)), Promise.resolve().then(t.bind(t, 23834)), Promise.resolve().then(t.bind(t, 88343)), Promise.resolve().then(t.bind(t, 24624)), Promise.resolve().then(t.bind(t, 25751)), Promise.resolve().then(t.bind(t, 65034));
    },
    75312: (e, r, t) => {
      "use strict";
      t.d(r, { SomethingWentWrong: () => P });
      var i = t(54486), n = t(50420), s = t(28303), o = t(61910), a = t(43426), l = t(47713), d = t(77881), m = t(5956), u = t(97800), c = t(74125), v = t(80585), h = t(63708), b = t.n(h);
      let P = (0, s.PA)((e2) => {
        let { className: r2, withBackwardControl: t2 = true } = e2, { formatMessage: s2 } = (0, a.A)(), h2 = s2({ id: "error-messages.something-went-wrong" });
        (0, c.CgZ)(h2);
        let { sendRefreshEvent: P2 } = (0, c.cYT)(), g = (0, o.useCallback)(() => {
          P2(), window.location.href = c.Zyd.main.href;
        }, [P2]), { contentRef: _ } = (0, c.gKY)();
        return (0, i.jsxs)("div", {
          className: (0, n.$)(b().root, r2),
          children: [
            t2 && (0, i.jsx)(v.Lh, {
              withBackwardFallback: "/",
              className: (0, n.$)(b().navigation, { [b().navigation_desktop]: !_ }),
              withForwardControl: false
            }),
            (0, i.jsxs)("div", {
              className: (0, n.$)(b().content, { [b().content_shrink]: !t2 }),
              children: [
                (0, i.jsx)(m.Icon, { className: b().icon, variant: "attention", size: "xxl" }),
                (0, i.jsx)(u.Heading, {
                  className: (0, n.$)(b().title, b().important),
                  variant: "h3",
                  size: "xs",
                  children: h2
                }),
                (0, i.jsxs)(u.Caption, {
                  className: (0, n.$)(b().text, b().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, i.jsx)(l.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, i.jsx)(d.$, {
                  onClick: g,
                  className: b().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, i.jsxs)(u.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, i.jsx)(l.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    76310: (e) => {
      e.exports = {
        root: "MyMusicDownloadedTracksPage_root__hZZwz",
        important: "MyMusicDownloadedTracksPage_important__QP_t0",
        pageContainer: "MyMusicDownloadedTracksPage_pageContainer__qu3hF",
        footer: "MyMusicDownloadedTracksPage_footer__KI5OP",
        content: "MyMusicDownloadedTracksPage_content__Iz1WY",
        trackShimmer: "MyMusicDownloadedTracksPage_trackShimmer__MZgW3"
      };
    },
    77163: (e, r, t) => {
      "use strict";
      t.d(r, { useOnPresaveClick: () => u });
      var i = t(54486), n = t(63930), s = t(61910), o = t(43426), a = t(71020), l = t(74125), d = t(80585);
      let m = (e2) => {
        let { upcomingAlbum: r2, closeToast: t2 } = e2;
        return (0, i.jsx)(d.Pv, {
          closeToast: t2,
          albumTitle: r2.title,
          coverUri: r2.coverUri,
          entityTitle: r2.title,
          isPresave: r2.isPresave
        });
      }, u = (e2) => {
        let { user: r2 } = (0, l.Pjs)(), { notify: t2 } = (0, l.lkh)(), [u2, c] = (0, s.useState)(false), { formatMessage: v } = (0, o.A)();
        return (0, s.useCallback)(async () => {
          if (!r2.isAuthorized)
            return void t2((0, i.jsx)(d.hT, { error: v({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: l.uQT.ERROR
            });
          if (u2) return;
          let s2 = { ...(0, n.HO)(e2), isPresave: !e2.isPresave };
          c(true);
          let o2 = await e2.toggleLike();
          c(false), o2 === a.J.OK ? t2((0, i.jsx)(m, { upcomingAlbum: s2 }), { containerId: l.uQT.INFO }) : t2((0, i.jsx)(d.hT, { error: v({ id: "error-messages.error-during-action" }) }), {
            containerId: l.uQT.ERROR
          });
        }, [r2.isAuthorized, u2, e2, t2, v]);
      };
    },
    80506: (e, r, t) => {
      "use strict";
      t.d(r, { a: () => n });
      var i = t(87965);
      let n = () => {
        let e2 = null, r2 = new i.cJ(false), t2 = [];
        return {
          isLoaded: r2,
          init: (i2) => {
            var n2, s;
            if (void 0 !== (null == (n2 = window.Ya) ? void 0 : n2.Metrika2) && !r2.value)
              try {
                e2 = new window.Ya.Metrika2({ ...i2 }), r2.value = true, s = e2, t2.forEach((e3) => {
                  e3(s);
                }), t2.length = 0;
              } catch (e3) {
                ("string" == typeof e3 || e3 instanceof Error) && i2.logger.error(e3);
              }
          },
          count: function(r3) {
            let i2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "counter";
            e2 ? e2.params({ [i2]: r3 }) : t2.push((e3) => {
              e3.params({ [i2]: r3 });
            });
          },
          hit: (r3) => {
            e2 ? e2.hit(r3) : t2.push((e3) => {
              e3.hit(r3);
            });
          },
          reachGoal: (r3, i2) => {
            if (!e2) return void t2.push((e3) => e3.reachGoal(r3, i2));
            e2.reachGoal(r3, i2);
          }
        };
      };
    },
    82644: (e, r, t) => {
      "use strict";
      t.d(r, { w: () => i.SomethingWentWrong });
      var i = t(75312);
    },
    89511: (e, r, t) => {
      "use strict";
      t.d(r, { b: () => d, L: () => i.useDownloadedTracks });
      var i = t(25751), n = t(93064), s = t(5693), o = t(21365), a = t(74125), l = t(26433);
      let d = n.gK.compose(
        n.gK.model("DownloadedTracks", {
          items: n.gK.maybeNull(n.gK.array(o.vj)),
          tracks: n.gK.maybeNull(n.gK.frozen())
        }),
        l.XT
      ).views((e2) => ({
        get tracksDurationInMinutes() {
          var r2, t2;
          return (null != (t2 = null == (r2 = e2.tracks) ? void 0 : r2.reduce((e3, r3) => r3.durationMs ? e3 + r3.durationMs : e3, 0)) ? t2 : 0) / 1e3 / 60;
        },
        get entitiesData() {
          if (!e2.tracks) return [];
          return e2.tracks.map((e3) => ({ type: s.R.DownloadedMusic, meta: e3 }));
        },
        get isEmpty() {
          var i2;
          return e2.isResolved && (null == (i2 = e2.items) ? void 0 : i2.length) === 0;
        }
      })).actions((e2) => ({
        getData: (0, n.L3)(function* (r2, t2) {
          let { modelActionsLogger: i2 } = (0, n._$)(e2);
          if (e2.loadingState !== a.GuX.PENDING)
            try {
              e2.loadingState = a.GuX.PENDING;
              let i3 = yield r2.getTracks(t2);
              e2.tracks = i3, e2.items = (0, n.wg)(i3.map((e3) => (0, o.vU)(e3))), e2.loadingState !== a.GuX.IDLE && (e2.loadingState = a.GuX.RESOLVE);
            } catch (r3) {
              i2.error(r3), e2.loadingState !== a.GuX.IDLE && (e2.loadingState = a.GuX.REJECT);
            }
        }),
        reset() {
          e2.items = null, e2.tracks = null, e2.loadingState = a.GuX.IDLE;
        }
      }));
    },
    93729: (e, r, t) => {
      "use strict";
      var i;
      t.d(r, { E: () => i }), (function(e2) {
        e2.KIDS = "kids", e2.BOOKMATE = "bookmate";
      })(i || (i = {}));
    },
    94490: (e, r, t) => {
      "use strict";
      t.d(r, { f: () => h });
      var i = t(54486), n = t(63930), s = t(61910), o = t(43426), a = t(77534), l = t(8817), d = t(74125), m = t(80585), u = t(28303), c = t(2608);
      let v = (0, u.PA)((e2) => {
        let { album: r2, closeToast: t2, withLink: n2 } = e2, s2 = (0, c.b)(r2);
        return (0, i.jsx)(m.OM, {
          closeToast: t2,
          entityVariant: s2,
          coverUri: r2.coverUri,
          entityUrl: r2.url,
          collectionUrl: "/collection",
          entityTitle: r2.title,
          isLiked: r2.isLiked,
          withLink: n2
        });
      }), h = () => {
        let { notify: e2 } = (0, d.lkh)(), [r2, t2] = (0, s.useState)(false), { formatMessage: u2 } = (0, o.A)();
        return (0, l.c)(async (s2) => {
          let { album: o2, withLink: l2 = true, withNotification: c2 = true } = s2;
          if (r2) return;
          let h2 = { ...(0, n.HO)(o2), url: o2.url, isLiked: !o2.isLiked };
          t2(true);
          let b = await o2.toggleLike();
          t2(false), c2 && (b === a.f.OK ? e2((0, i.jsx)(v, { withLink: l2, album: h2 }), { containerId: d.uQT.INFO }) : e2((0, i.jsx)(m.hT, { error: u2({ id: "error-messages.error-during-action" }) }), {
            containerId: d.uQT.ERROR
          }));
        });
      };
    },
    96025: (e, r, t) => {
      "use strict";
      t.d(r, { useOnPromoLandingLikeClick: () => l });
      var i = t(97396), n = t(34132), s = t(8817), o = t(74125), a = t(94490);
      let l = (e2) => {
        let {
          user: r2,
          modals: { promoLandingBuySubscriptionModal: t2, crackdownModal: l2 },
          settings: { isMobile: d },
          paywall: m,
          albumCPA: { isPlusCPAEnabled: u },
          promolanding: c
        } = (0, o.Pjs)(), { isFreemium: v } = (0, o.XCI)(), h = (0, a.f)(), { pageAlbumId: b } = (0, o.THB)(), P = (0, i.useSearchParams)();
        return (0, s.c)(async () => {
          if (u({ pageAlbumId: b, albumId: null == e2 ? void 0 : e2.id, isNonMusic: null == e2 ? void 0 : e2.isNonMusic }))
            return void m.openModal();
          if ((!v || (null == e2 ? void 0 : e2.isLiked) || (d ? t2.open() : l2.open()), r2.isAuthorized) && e2) {
            if (!e2.isLiked) {
              var i2, s2;
              c.sendLikeFeedback({
                reaction: n.g.LIKE,
                yclid: null != (i2 = P.get(o.K3F.YCLID)) ? i2 : "",
                campaignId: null != (s2 = P.get(o.K3F.UTM_CAMPAIGN)) ? s2 : ""
              });
            }
            return h({ album: e2, withLink: false, withNotification: r2.hasPlus });
          }
        });
      };
    },
    96819: (e, r, t) => {
      "use strict";
      t.d(r, { useOnLikeClick: () => d });
      var i = t(54486), n = t(43426), s = t(8817), o = t(74125), a = t(80585), l = t(94490);
      let d = (e2) => {
        let {
          user: r2,
          paywall: t2,
          albumCPA: { isPlusCPAEnabled: d2 }
        } = (0, o.Pjs)(), { formatMessage: m } = (0, n.A)(), { notify: u } = (0, o.lkh)(), c = (0, l.f)(), { pageAlbumId: v } = (0, o.THB)();
        return (0, s.c)(async () => {
          if (e2)
            return d2({ pageAlbumId: v, albumId: e2.id, isNonMusic: e2.isNonMusic }) ? void t2.openModal() : r2.isAuthorized ? c({ album: e2 }) : void u((0, i.jsx)(a.hT, { error: m({ id: "authorization-messages.need-to-authorizate" }) }), {
              containerId: o.uQT.ERROR
            });
        });
      };
    },
    97151: (e, r, t) => {
      "use strict";
      t.d(r, { XU: () => u });
      var i, n, s = t(41500), o = t(61910), a = t(43426);
      !(function(e2) {
        e2.formatDate = "FormattedDate", e2.formatTime = "FormattedTime", e2.formatNumber = "FormattedNumber", e2.formatList = "FormattedList", e2.formatDisplayName = "FormattedDisplayName";
      })(i || (i = {})), (function(e2) {
        e2.formatDate = "FormattedDateParts", e2.formatTime = "FormattedTimeParts", e2.formatNumber = "FormattedNumberParts", e2.formatList = "FormattedListParts";
      })(n || (n = {}));
      var l = function(e2) {
        var r2 = (0, a.A)(), t2 = e2.value, i2 = e2.children, n2 = (0, s.__rest)(e2, ["value", "children"]);
        return i2(r2.formatNumberToParts(t2, n2));
      };
      function d(e2) {
        var r2 = function(r3) {
          var t2 = (0, a.A)(), i2 = r3.value, n2 = r3.children, o2 = (0, s.__rest)(r3, ["value", "children"]), l2 = "string" == typeof i2 ? new Date(i2 || 0) : i2;
          return n2("formatDate" === e2 ? t2.formatDateToParts(l2, o2) : t2.formatTimeToParts(l2, o2));
        };
        return r2.displayName = n[e2], r2;
      }
      function m(e2) {
        var r2 = function(r3) {
          var t2 = (0, a.A)(), i2 = r3.value, n2 = r3.children, l2 = (0, s.__rest)(r3, ["value", "children"]), d2 = t2[e2](i2, l2);
          if ("function" == typeof n2) return n2(d2);
          var m2 = t2.textComponent || o.Fragment;
          return o.createElement(m2, null, d2);
        };
        return r2.displayName = i[e2], r2;
      }
      l.displayName = "FormattedNumberParts", l.displayName = "FormattedNumberParts";
      var u = m("formatDate");
      m("formatTime"), m("formatNumber"), m("formatList"), m("formatDisplayName"), d("formatDate"), d("formatTime");
    }
  },
  (e) => {
    e.O(
      0,
      [
        7956,
        2685,
        5355,
        1023,
        4354,
        9577,
        2116,
        1546,
        2036,
        1311,
        7764,
        6706,
        7724,
        5148,
        3005,
        3916,
        5973,
        6266,
        722,
        4125,
        585,
        6433,
        4561,
        6231,
        4460,
        1365,
        5284,
        1752,
        2460,
        3205,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 74261)
    ), _N_E = e.O();
  }
]);
