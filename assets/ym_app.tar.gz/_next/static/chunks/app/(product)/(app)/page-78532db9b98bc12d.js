(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2966],
  {
    9567: (e, n, r) => {
      "use strict";
      r.d(n, { MyMusicDownloadedTracksPage: () => A });
      var i = r(54486), o = r(50420), s = r(28303), t = r(61910), l = r(43426), d = r(31500), a = r(63585), m = r(8817), h = r(89511), v = r(82644), P = r(33276), b = r(21365), c = r(74125), u = r(80585), _ = r(76310), f = r.n(_), g = r(47713), p = r(5956), y = r(97800), x = r(14114), k = r.n(x);
      let D = (0, s.PA)(() => {
        var e2;
        let {
          myMusic: { downloadedTracks: n2 }
        } = (0, c.Pjs)(), r2 = (0, i.jsx)(y.Caption, { variant: "span", size: "s", weight: "medium", "aria-hidden": true, children: "•" }), o2 = [];
        (null == (e2 = n2.tracks) ? void 0 : e2.length) && o2.push(
          (0, i.jsx)(y.Caption, {
            variant: "span",
            size: "s",
            weight: "medium",
            lineClamp: 1,
            children: (0, i.jsx)(g.A, { id: "entity-names.tracks-count", values: { value: n2.tracks.length } })
          })
        );
        let s2 = Math.floor(n2.tracksDurationInMinutes / 60), l2 = Math.floor(n2.tracksDurationInMinutes % 60);
        return (s2 || l2) && (o2.push(r2), o2.push(
          (0, i.jsx)(y.Caption, {
            variant: "span",
            size: "s",
            weight: "medium",
            children: (0, i.jsx)(g.A, { id: "time.hours-minutes", values: { hours: s2, minutes: l2 } })
          })
        )), (0, i.jsx)("div", { className: k().root, children: o2.map((e3, n3) => (0, t.cloneElement)(e3, { key: n3 })) });
      });
      var M = r(12962), j = r.n(M);
      let w = (0, s.PA)(() => {
        let { isScrolling: e2 } = (0, t.useContext)(u.B9), n2 = (0, c.W6M)(), {
          myMusic: { downloadedTracks: r2 },
          settings: { isMobile: o2 },
          slam: s2
        } = (0, c.Pjs)(), { from: l2 } = (0, c.fyy)({ pageId: c._Q$.OWN_TRACKS, blockId: c.UfI.TRACK_LIST }), d2 = (0, c.PT7)(), h2 = (0, c.brA)(), { isPlaying: v2, togglePlay: P2 } = (0, c.Dx4)({
          playContextParams: {
            contextData: { type: a.K.Various, meta: { id: c._Q$.DOWNLOADS_TRACKS }, from: l2 },
            entitiesData: r2.entitiesData,
            loadContextMeta: false
          }
        }), b2 = (0, m.c)(() => {
          d2() || (P2(), h2(!v2));
        });
        return (0, i.jsx)("header", {
          className: j().root,
          "aria-hidden": e2,
          children: (0, i.jsxs)("div", {
            className: j().container,
            children: [
              !s2.isOfflineModeEnabled && n2.canBack && (0, i.jsx)(u.Lh, {
                withForwardControl: false,
                withBackwardControl: n2.canBack,
                shouldFocusOnMount: !e2,
                buttonSize: "xxs"
              }),
              (0, i.jsxs)("div", {
                className: j().titleContainer,
                children: [
                  (0, i.jsx)(y.Heading, {
                    variant: "h1",
                    weight: "bold",
                    size: "xs",
                    lineClamp: 1,
                    className: j().title,
                    children: (0, i.jsx)(g.A, { id: "offline.downloaded-tracks" })
                  }),
                  (0, i.jsx)(D, {})
                ]
              }),
              !r2.isEmpty && (0, i.jsx)(u.DM, {
                withRipple: true,
                buttonVariant: "default",
                radius: "xxxl",
                size: "s",
                color: "primary",
                iconSize: "xxs",
                isPlaying: v2,
                onClick: b2,
                className: j().playButton,
                ariaHidden: e2,
                tabIndex: e2 ? -1 : 0,
                children: !o2 && (0, i.jsx)(g.A, { id: "player-actions.listen" })
              })
            ]
          })
        });
      });
      var T = r(61336), C = r.n(T);
      let N = (0, s.PA)(
        () => (0, i.jsxs)(i.Fragment, {
          children: [
            (0, i.jsx)(w, {}),
            (0, i.jsxs)("div", {
              className: C().root,
              children: [
                (0, i.jsx)(p.Icon, { className: C().icon, size: "l", variant: "download" }),
                (0, i.jsx)(y.Heading, {
                  className: C().title,
                  variant: "div",
                  size: "xs",
                  children: (0, i.jsx)(g.A, { id: "offline.downloaded-empty" })
                }),
                (0, i.jsx)(y.Caption, {
                  className: C().text,
                  variant: "span",
                  type: "controls",
                  size: "l",
                  weight: "normal",
                  children: (0, i.jsx)(g.A, { id: "offline.download-for-offline" })
                })
              ]
            })
          ]
        })
      ), S = (0, s.PA)(() => {
        let { isScrolling: e2 } = (0, t.useContext)(u.B9), n2 = (0, c.W6M)(), {
          myMusic: { downloadedTracks: r2 },
          settings: { isMobile: s2 },
          slam: l2
        } = (0, c.Pjs)(), { from: d2 } = (0, c.fyy)({ pageId: c._Q$.OWN_TRACKS, blockId: c.UfI.TRACK_LIST }), h2 = (0, c.brA)(), v2 = (0, c.PT7)(), { isPlaying: P2, togglePlay: b2 } = (0, c.Dx4)({
          playContextParams: {
            contextData: { type: a.K.Various, meta: { id: c._Q$.DOWNLOADS_TRACKS }, from: d2 },
            entitiesData: r2.entitiesData,
            loadContextMeta: false
          }
        }), _2 = (0, m.c)(() => {
          v2() || (b2(), h2(!P2));
        });
        return (0, i.jsx)(u.Y9, {
          variant: u.Vw.COMPOSITE,
          "aria-hidden": !e2,
          stickyChild: (0, i.jsxs)("div", {
            className: j().container,
            children: [
              !l2.isOfflineModeEnabled && n2.canBack && (0, i.jsx)(u.Lh, {
                withForwardControl: false,
                withBackwardControl: n2.canBack,
                shouldFocusOnMount: false,
                buttonSize: "xxs"
              }),
              (0, i.jsx)(y.Heading, {
                variant: "h1",
                weight: "bold",
                size: "xs",
                lineClamp: 1,
                className: j().stickyTitle,
                children: (0, i.jsx)(g.A, { id: "offline.downloaded-tracks" })
              }),
              !r2.isEmpty && (0, i.jsx)(u.DM, {
                withRipple: true,
                buttonVariant: "default",
                radius: "xxxl",
                size: "s",
                color: "primary",
                iconSize: "xxs",
                isPlaying: P2,
                onClick: _2,
                className: (0, o.$)(j().playButton, { [j().stickyPlayButton]: !s2 }),
                ariaHidden: !e2,
                tabIndex: e2 ? 0 : -1,
                children: !s2 && (0, i.jsx)(g.A, { id: "player-actions.listen" })
              })
            ]
          }),
          stickyClassName: (0, o.$)(j().stickyHeader, j().important),
          staticClassName: (0, o.$)(j().staticHeader, j().important)
        });
      }), A = (0, s.PA)(() => {
        var e2;
        let n2 = (0, c.jRO)(), { contentScrollRef: r2, setContentScrollRef: s2 } = (0, c.gKY)(), { formatMessage: _2 } = (0, l.A)(), {
          myMusic: { downloadedTracks: g2 }
        } = (0, c.Pjs)(), { from: p2 } = (0, c.fyy)({ pageId: c._Q$.OWN_TRACKS, blockId: c.UfI.TRACK_LIST }), y2 = (0, c.wZZ)(), x2 = (0, m.c)(() => {
          n2.tracksController && g2.getData(n2.tracksController);
        });
        (0, h.L)(x2), (0, t.useEffect)(() => {
          g2.isNeededToLoad && x2();
        }, [g2.isNeededToLoad, x2]), (0, t.useEffect)(
          () => () => {
            g2.reset();
          },
          [g2]
        ), (0, c.Jzs)(g2.isResolved);
        let k2 = (0, t.useMemo)(
          () => ({
            Header: () => (0, i.jsx)(w, {}),
            Footer: () => (0, i.jsx)(u.A, { children: (0, i.jsx)(u.wi, { className: f().footer }) })
          }),
          []
        );
        if (g2.loadingState === c.GuX.REJECT) return (0, i.jsx)(v.w, {});
        if (g2.isEmpty) return (0, i.jsx)(N, {});
        let D2 = (null == (e2 = g2.items) ? void 0 : e2.length) || 10;
        return (0, i.jsx)(c.nVz, {
          pageId: c._Q$.DOWNLOADS_TRACKS,
          children: (0, i.jsx)(P.hO, {
            scrollElement: r2,
            children: (0, i.jsxs)("div", {
              className: f().pageContainer,
              children: [
                (0, i.jsx)(S, {}),
                (0, i.jsx)(u.$$, {
                  context: { listAriaLabel: _2({ id: "offline.downloaded-track-list" }) },
                  className: (0, o.$)(f().root, f().important),
                  listClassName: f().content,
                  customComponents: k2,
                  totalCount: D2,
                  itemContentCallback: (e3) => {
                    var n3;
                    let r3 = null == (n3 = g2.items) ? void 0 : n3[e3];
                    return r3 ? (0, i.jsx)(
                      b.Kt,
                      {
                        track: r3,
                        playContextParams: y2(r3.id, {
                          contextData: { type: a.K.Various, meta: { id: c._Q$.DOWNLOADS_TRACKS }, from: p2 },
                          entitiesData: g2.entitiesData,
                          queueParams: { index: e3, entityId: r3.id },
                          loadContextMeta: false
                        })
                      },
                      r3.id
                    ) : (0, i.jsx)(u.DS, { isActive: true, className: f().trackShimmer, variant: c.Xjt.PLAYLIST });
                  },
                  debounceDurationInMs: 300,
                  initialItemCount: D2,
                  handleRef: s2,
                  shouldTriggerRangeChangedOn: [D2],
                  testId: d.Xk.myMusic.MY_MUSIC_DOWNLOADED_TRACKS_PAGE
                })
              ]
            })
          })
        });
      });
    },
    12962: (e) => {
      e.exports = {
        root: "MyMusicDownloadedTracksPageHeader_root__2vfuc",
        container: "MyMusicDownloadedTracksPageHeader_container__hQ_wt",
        title: "MyMusicDownloadedTracksPageHeader_title__Ncn5X",
        stickyTitle: "MyMusicDownloadedTracksPageHeader_stickyTitle__Efl0U",
        playButton: "MyMusicDownloadedTracksPageHeader_playButton__seWgC",
        stickyPlayButton: "MyMusicDownloadedTracksPageHeader_stickyPlayButton__JVicd",
        titleContainer: "MyMusicDownloadedTracksPageHeader_titleContainer__rLAkS",
        staticHeader: "MyMusicDownloadedTracksPageHeader_staticHeader__LSVC8",
        important: "MyMusicDownloadedTracksPageHeader_important__JIubq",
        stickyHeader: "MyMusicDownloadedTracksPageHeader_stickyHeader__MuQh4"
      };
    },
    14114: (e) => {
      e.exports = { root: "MyMusicDownloadedTracksInfo_root__yIYHx" };
    },
    25751: (e, n, r) => {
      "use strict";
      r.d(n, { useDownloadedTracks: () => d });
      var i = r(61910), o = r(12460), s = r(8817), t = r(74125);
      let l = [o.DT.IDLE, o.DT.DOWNLOADED], d = (e2) => {
        var n2;
        let r2 = (0, t.jRO)(), d2 = (0, s.c)((n3) => {
          let { state: r3 } = n3;
          l.includes(r3.loadingState) && e2();
        });
        (0, i.useEffect)(() => {
          var n3, i2;
          return null == (n3 = r2.store) || n3.tracks.events.on(o.je.STATE_CHANGED, e2), null == (i2 = r2.store) || i2.tracks.events.on(o.je.ENTITY_CHANGED, d2), () => {
            var n4, i3;
            null == (n4 = r2.store) || n4.tracks.events.off(o.je.STATE_CHANGED, e2), null == (i3 = r2.store) || i3.tracks.events.off(o.je.ENTITY_CHANGED, d2);
          };
        }, [e2, d2, null == (n2 = r2.store) ? void 0 : n2.tracks.events]);
      };
    },
    31622: (e, n, r) => {
      "use strict";
      Object.defineProperty(n, "__esModule", { value: true }), Object.defineProperty(n, "default", {
        enumerable: true,
        get: function() {
          return d;
        }
      });
      let i = r(54486), o = r(61910), s = r(91165);
      function t(e2) {
        return { default: e2 && "default" in e2 ? e2.default : e2 };
      }
      r(98944);
      let l = { loader: () => Promise.resolve(t(() => null)), loading: null, ssr: true }, d = function(e2) {
        let n2 = { ...l, ...e2 }, r2 = (0, o.lazy)(() => n2.loader().then(t)), d2 = n2.loading;
        function a(e3) {
          let t2 = d2 ? (0, i.jsx)(d2, { isLoading: true, pastDelay: true, error: null }) : null, l2 = !n2.ssr || !!n2.loading, a2 = l2 ? o.Suspense : o.Fragment, m = n2.ssr ? (0, i.jsxs)(i.Fragment, { children: [null, (0, i.jsx)(r2, { ...e3 })] }) : (0, i.jsx)(s.BailoutToCSR, { reason: "next/dynamic", children: (0, i.jsx)(r2, { ...e3 }) });
          return (0, i.jsx)(a2, { ...l2 ? { fallback: t2 } : {}, children: m });
        }
        return a.displayName = "LoadableComponent", a;
      };
    },
    34582: (e, n, r) => {
      Promise.resolve().then(r.bind(r, 81203)), Promise.resolve().then(r.bind(r, 5956)), Promise.resolve().then(r.bind(r, 58360)), Promise.resolve().then(r.bind(r, 14342)), Promise.resolve().then(r.bind(r, 62662)), Promise.resolve().then(r.bind(r, 6971)), Promise.resolve().then(r.bind(r, 22674)), Promise.resolve().then(r.bind(r, 51321)), Promise.resolve().then(r.bind(r, 97800)), Promise.resolve().then(r.bind(r, 42520)), Promise.resolve().then(r.bind(r, 30662)), Promise.resolve().then(r.bind(r, 31757)), Promise.resolve().then(r.bind(r, 51672)), Promise.resolve().then(r.bind(r, 63449)), Promise.resolve().then(r.bind(r, 65134)), Promise.resolve().then(r.bind(r, 96819)), Promise.resolve().then(r.bind(r, 38868)), Promise.resolve().then(r.bind(r, 77163)), Promise.resolve().then(r.bind(r, 96025)), Promise.resolve().then(r.bind(r, 51887)), Promise.resolve().then(r.bind(r, 25577)), Promise.resolve().then(r.bind(r, 65327)), Promise.resolve().then(r.bind(r, 3119)), Promise.resolve().then(r.bind(r, 74808)), Promise.resolve().then(r.bind(r, 92088)), Promise.resolve().then(r.bind(r, 83154)), Promise.resolve().then(r.bind(r, 14476)), Promise.resolve().then(r.bind(r, 88332)), Promise.resolve().then(r.bind(r, 16855)), Promise.resolve().then(r.bind(r, 28795)), Promise.resolve().then(r.bind(r, 64782)), Promise.resolve().then(r.bind(r, 59839)), Promise.resolve().then(r.bind(r, 60339)), Promise.resolve().then(r.bind(r, 58435)), Promise.resolve().then(r.bind(r, 60272)), Promise.resolve().then(r.bind(r, 39206)), Promise.resolve().then(r.bind(r, 42061)), Promise.resolve().then(r.bind(r, 31820)), Promise.resolve().then(r.bind(r, 10351)), Promise.resolve().then(r.t.bind(r, 61484, 23)), Promise.resolve().then(r.bind(r, 87184)), Promise.resolve().then(r.bind(r, 32949)), Promise.resolve().then(r.bind(r, 27654)), Promise.resolve().then(r.bind(r, 83952)), Promise.resolve().then(r.t.bind(r, 20065, 23)), Promise.resolve().then(r.bind(r, 81217)), Promise.resolve().then(r.bind(r, 56689)), Promise.resolve().then(r.bind(r, 73219)), Promise.resolve().then(r.bind(r, 25045)), Promise.resolve().then(r.bind(r, 29468)), Promise.resolve().then(r.bind(r, 69573)), Promise.resolve().then(r.bind(r, 64409)), Promise.resolve().then(r.bind(r, 27574)), Promise.resolve().then(r.bind(r, 15091)), Promise.resolve().then(r.bind(r, 93099)), Promise.resolve().then(r.bind(r, 15640)), Promise.resolve().then(r.bind(r, 82885)), Promise.resolve().then(r.bind(r, 99733)), Promise.resolve().then(r.bind(r, 18355)), Promise.resolve().then(r.bind(r, 42691)), Promise.resolve().then(r.bind(r, 37235)), Promise.resolve().then(r.bind(r, 3781)), Promise.resolve().then(r.bind(r, 33829)), Promise.resolve().then(r.bind(r, 39906)), Promise.resolve().then(r.bind(r, 50119)), Promise.resolve().then(r.bind(r, 21179)), Promise.resolve().then(r.bind(r, 7912)), Promise.resolve().then(r.bind(r, 50193)), Promise.resolve().then(r.bind(r, 83399)), Promise.resolve().then(r.bind(r, 11450)), Promise.resolve().then(r.bind(r, 62345)), Promise.resolve().then(r.bind(r, 37408)), Promise.resolve().then(r.bind(r, 48392)), Promise.resolve().then(r.bind(r, 42488)), Promise.resolve().then(r.bind(r, 5207)), Promise.resolve().then(r.bind(r, 20875)), Promise.resolve().then(r.bind(r, 5065)), Promise.resolve().then(r.bind(r, 29443)), Promise.resolve().then(r.bind(r, 29717)), Promise.resolve().then(r.bind(r, 55639)), Promise.resolve().then(r.t.bind(r, 46121, 23)), Promise.resolve().then(r.bind(r, 69536)), Promise.resolve().then(r.bind(r, 11472)), Promise.resolve().then(r.bind(r, 2438)), Promise.resolve().then(r.bind(r, 46540)), Promise.resolve().then(r.bind(r, 26923)), Promise.resolve().then(r.bind(r, 23504)), Promise.resolve().then(r.bind(r, 99182)), Promise.resolve().then(r.bind(r, 83580)), Promise.resolve().then(r.bind(r, 19633)), Promise.resolve().then(r.bind(r, 84883)), Promise.resolve().then(r.bind(r, 57923)), Promise.resolve().then(r.t.bind(r, 37863, 23)), Promise.resolve().then(r.bind(r, 22017)), Promise.resolve().then(r.bind(r, 50795)), Promise.resolve().then(r.bind(r, 32159)), Promise.resolve().then(r.bind(r, 70901)), Promise.resolve().then(r.bind(r, 18139)), Promise.resolve().then(r.bind(r, 31135)), Promise.resolve().then(r.bind(r, 74627)), Promise.resolve().then(r.t.bind(r, 3809, 23)), Promise.resolve().then(r.bind(r, 30623)), Promise.resolve().then(r.bind(r, 5631)), Promise.resolve().then(r.bind(r, 9283)), Promise.resolve().then(r.bind(r, 72467)), Promise.resolve().then(r.bind(r, 66894)), Promise.resolve().then(r.bind(r, 45318)), Promise.resolve().then(r.bind(r, 3283)), Promise.resolve().then(r.bind(r, 48284)), Promise.resolve().then(r.bind(r, 69151)), Promise.resolve().then(r.bind(r, 8871)), Promise.resolve().then(r.bind(r, 86062)), Promise.resolve().then(r.bind(r, 47937)), Promise.resolve().then(r.bind(r, 76130)), Promise.resolve().then(r.bind(r, 76858)), Promise.resolve().then(r.bind(r, 54586)), Promise.resolve().then(r.bind(r, 12938)), Promise.resolve().then(r.bind(r, 62065)), Promise.resolve().then(r.bind(r, 39194)), Promise.resolve().then(r.bind(r, 97778)), Promise.resolve().then(r.bind(r, 23728)), Promise.resolve().then(r.bind(r, 9821)), Promise.resolve().then(r.bind(r, 13868)), Promise.resolve().then(r.bind(r, 43616)), Promise.resolve().then(r.bind(r, 92810)), Promise.resolve().then(r.bind(r, 79971)), Promise.resolve().then(r.bind(r, 61920)), Promise.resolve().then(r.bind(r, 93549)), Promise.resolve().then(r.bind(r, 4242)), Promise.resolve().then(r.bind(r, 79045)), Promise.resolve().then(r.bind(r, 72850)), Promise.resolve().then(r.bind(r, 26853)), Promise.resolve().then(r.bind(r, 85905)), Promise.resolve().then(r.bind(r, 94540)), Promise.resolve().then(r.bind(r, 9567)), Promise.resolve().then(r.bind(r, 8394)), Promise.resolve().then(r.bind(r, 3192)), Promise.resolve().then(r.bind(r, 7286)), Promise.resolve().then(r.bind(r, 60305)), Promise.resolve().then(r.bind(r, 47203)), Promise.resolve().then(r.bind(r, 34286)), Promise.resolve().then(r.bind(r, 224)), Promise.resolve().then(r.bind(r, 24449)), Promise.resolve().then(r.bind(r, 79893)), Promise.resolve().then(r.bind(r, 81789)), Promise.resolve().then(r.bind(r, 87466)), Promise.resolve().then(r.bind(r, 39034)), Promise.resolve().then(r.bind(r, 17917)), Promise.resolve().then(r.bind(r, 11337)), Promise.resolve().then(r.bind(r, 19683)), Promise.resolve().then(r.bind(r, 53779)), Promise.resolve().then(r.bind(r, 12359)), Promise.resolve().then(r.bind(r, 88564)), Promise.resolve().then(r.bind(r, 95639)), Promise.resolve().then(r.bind(r, 57630)), Promise.resolve().then(r.bind(r, 25342)), Promise.resolve().then(r.bind(r, 34028)), Promise.resolve().then(r.bind(r, 99564)), Promise.resolve().then(r.bind(r, 95348)), Promise.resolve().then(r.bind(r, 52347)), Promise.resolve().then(r.bind(r, 61015)), Promise.resolve().then(r.bind(r, 1771)), Promise.resolve().then(r.bind(r, 80043)), Promise.resolve().then(r.bind(r, 12235)), Promise.resolve().then(r.bind(r, 8941)), Promise.resolve().then(r.bind(r, 38433)), Promise.resolve().then(r.bind(r, 8732)), Promise.resolve().then(r.bind(r, 43369)), Promise.resolve().then(r.bind(r, 47564)), Promise.resolve().then(r.bind(r, 41017)), Promise.resolve().then(r.bind(r, 27252)), Promise.resolve().then(r.bind(r, 65286)), Promise.resolve().then(r.bind(r, 45198)), Promise.resolve().then(r.bind(r, 46814)), Promise.resolve().then(r.bind(r, 92508)), Promise.resolve().then(r.bind(r, 40126)), Promise.resolve().then(r.bind(r, 83726)), Promise.resolve().then(r.bind(r, 90410)), Promise.resolve().then(r.bind(r, 13246)), Promise.resolve().then(r.bind(r, 26040)), Promise.resolve().then(r.bind(r, 92446)), Promise.resolve().then(r.bind(r, 42593)), Promise.resolve().then(r.bind(r, 70570)), Promise.resolve().then(r.bind(r, 88416)), Promise.resolve().then(r.bind(r, 24174)), Promise.resolve().then(r.bind(r, 78458)), Promise.resolve().then(r.bind(r, 59457)), Promise.resolve().then(r.bind(r, 6690)), Promise.resolve().then(r.bind(r, 88370)), Promise.resolve().then(r.bind(r, 66904)), Promise.resolve().then(r.bind(r, 39937)), Promise.resolve().then(r.bind(r, 33019)), Promise.resolve().then(r.bind(r, 38808)), Promise.resolve().then(r.bind(r, 58094)), Promise.resolve().then(r.bind(r, 78009)), Promise.resolve().then(r.bind(r, 33427)), Promise.resolve().then(r.bind(r, 30878)), Promise.resolve().then(r.bind(r, 53115)), Promise.resolve().then(r.bind(r, 52398)), Promise.resolve().then(r.bind(r, 82327)), Promise.resolve().then(r.bind(r, 17012)), Promise.resolve().then(r.bind(r, 9275)), Promise.resolve().then(r.bind(r, 17658)), Promise.resolve().then(r.bind(r, 36578)), Promise.resolve().then(r.bind(r, 66989)), Promise.resolve().then(r.bind(r, 58863)), Promise.resolve().then(r.bind(r, 60899)), Promise.resolve().then(r.bind(r, 59437)), Promise.resolve().then(r.bind(r, 43367)), Promise.resolve().then(r.bind(r, 66446)), Promise.resolve().then(r.bind(r, 86840)), Promise.resolve().then(r.bind(r, 75181)), Promise.resolve().then(r.bind(r, 99538)), Promise.resolve().then(r.bind(r, 45252)), Promise.resolve().then(r.bind(r, 59226)), Promise.resolve().then(r.bind(r, 75961)), Promise.resolve().then(r.bind(r, 33964)), Promise.resolve().then(r.bind(r, 33967)), Promise.resolve().then(r.bind(r, 64410)), Promise.resolve().then(r.bind(r, 91350)), Promise.resolve().then(r.bind(r, 4500)), Promise.resolve().then(r.bind(r, 55846)), Promise.resolve().then(r.bind(r, 65689)), Promise.resolve().then(r.bind(r, 99386)), Promise.resolve().then(r.bind(r, 5222)), Promise.resolve().then(r.bind(r, 60440)), Promise.resolve().then(r.bind(r, 37271)), Promise.resolve().then(r.bind(r, 66688)), Promise.resolve().then(r.bind(r, 76472)), Promise.resolve().then(r.bind(r, 41682)), Promise.resolve().then(r.bind(r, 77666)), Promise.resolve().then(r.bind(r, 8765)), Promise.resolve().then(r.bind(r, 48670)), Promise.resolve().then(r.bind(r, 22096)), Promise.resolve().then(r.bind(r, 33655)), Promise.resolve().then(r.bind(r, 27754)), Promise.resolve().then(r.bind(r, 47347)), Promise.resolve().then(r.bind(r, 45591)), Promise.resolve().then(r.bind(r, 52862)), Promise.resolve().then(r.bind(r, 79326)), Promise.resolve().then(r.bind(r, 73922)), Promise.resolve().then(r.bind(r, 10790)), Promise.resolve().then(r.bind(r, 78684)), Promise.resolve().then(r.bind(r, 76877)), Promise.resolve().then(r.bind(r, 61176)), Promise.resolve().then(r.bind(r, 62108)), Promise.resolve().then(r.bind(r, 75053)), Promise.resolve().then(r.bind(r, 23035)), Promise.resolve().then(r.bind(r, 82315)), Promise.resolve().then(r.bind(r, 60673)), Promise.resolve().then(r.bind(r, 5048)), Promise.resolve().then(r.bind(r, 50215)), Promise.resolve().then(r.bind(r, 78308)), Promise.resolve().then(r.bind(r, 10084)), Promise.resolve().then(r.bind(r, 58681)), Promise.resolve().then(r.bind(r, 18658)), Promise.resolve().then(r.bind(r, 6323)), Promise.resolve().then(r.bind(r, 78817)), Promise.resolve().then(r.bind(r, 7230)), Promise.resolve().then(r.bind(r, 38378)), Promise.resolve().then(r.bind(r, 35609)), Promise.resolve().then(r.bind(r, 18606)), Promise.resolve().then(r.bind(r, 68014)), Promise.resolve().then(r.bind(r, 12126)), Promise.resolve().then(r.bind(r, 52742)), Promise.resolve().then(r.bind(r, 68098)), Promise.resolve().then(r.bind(r, 89190)), Promise.resolve().then(r.bind(r, 3270)), Promise.resolve().then(r.bind(r, 1220)), Promise.resolve().then(r.bind(r, 96584)), Promise.resolve().then(r.bind(r, 54598)), Promise.resolve().then(r.bind(r, 14196)), Promise.resolve().then(r.bind(r, 20576)), Promise.resolve().then(r.bind(r, 29070)), Promise.resolve().then(r.bind(r, 35203)), Promise.resolve().then(r.bind(r, 39450)), Promise.resolve().then(r.bind(r, 77607)), Promise.resolve().then(r.bind(r, 7430)), Promise.resolve().then(r.bind(r, 24786)), Promise.resolve().then(r.bind(r, 24036)), Promise.resolve().then(r.bind(r, 34932)), Promise.resolve().then(r.bind(r, 56204)), Promise.resolve().then(r.bind(r, 75450)), Promise.resolve().then(r.bind(r, 60608)), Promise.resolve().then(r.bind(r, 33648)), Promise.resolve().then(r.bind(r, 43548)), Promise.resolve().then(r.bind(r, 69672)), Promise.resolve().then(r.bind(r, 50711)), Promise.resolve().then(r.bind(r, 5185)), Promise.resolve().then(r.bind(r, 90555)), Promise.resolve().then(r.bind(r, 5602)), Promise.resolve().then(r.bind(r, 12390)), Promise.resolve().then(r.bind(r, 58376)), Promise.resolve().then(r.bind(r, 24491)), Promise.resolve().then(r.bind(r, 61993)), Promise.resolve().then(r.bind(r, 38644)), Promise.resolve().then(r.bind(r, 93668)), Promise.resolve().then(r.bind(r, 85949)), Promise.resolve().then(r.bind(r, 17519)), Promise.resolve().then(r.bind(r, 62010)), Promise.resolve().then(r.bind(r, 16372)), Promise.resolve().then(r.bind(r, 64434)), Promise.resolve().then(r.bind(r, 33158)), Promise.resolve().then(r.bind(r, 27314)), Promise.resolve().then(r.bind(r, 93206)), Promise.resolve().then(r.bind(r, 37226)), Promise.resolve().then(r.bind(r, 13811)), Promise.resolve().then(r.bind(r, 45645)), Promise.resolve().then(r.bind(r, 24126)), Promise.resolve().then(r.bind(r, 20406)), Promise.resolve().then(r.bind(r, 21940)), Promise.resolve().then(r.bind(r, 26086)), Promise.resolve().then(r.bind(r, 96838)), Promise.resolve().then(r.bind(r, 10358)), Promise.resolve().then(r.bind(r, 23143)), Promise.resolve().then(r.bind(r, 51828)), Promise.resolve().then(r.bind(r, 51725)), Promise.resolve().then(r.bind(r, 23834)), Promise.resolve().then(r.bind(r, 88343)), Promise.resolve().then(r.bind(r, 24624)), Promise.resolve().then(r.bind(r, 25751)), Promise.resolve().then(r.bind(r, 14170)), Promise.resolve().then(r.bind(r, 62277)), Promise.resolve().then(r.bind(r, 84359)), Promise.resolve().then(r.bind(r, 25743)), Promise.resolve().then(r.bind(r, 4111)), Promise.resolve().then(r.bind(r, 20773)), Promise.resolve().then(r.t.bind(r, 90372, 23));
    },
    36446: (e, n, r) => {
      "use strict";
      Object.defineProperty(n, "__esModule", { value: true }), Object.defineProperty(n, "default", {
        enumerable: true,
        get: function() {
          return o;
        }
      });
      let i = r(45221)._(r(31622));
      function o(e2, n2) {
        var r2;
        let o2 = {};
        "function" == typeof e2 && (o2.loader = e2);
        let s = { ...o2, ...n2 };
        return (0, i.default)({ ...s, modules: null == (r2 = s.loadableGenerated) ? void 0 : r2.modules });
      }
      ("function" == typeof n.default || "object" == typeof n.default && null !== n.default) && void 0 === n.default.__esModule && (Object.defineProperty(n.default, "__esModule", { value: true }), Object.assign(n.default, n), e.exports = n.default);
    },
    42520: (e, n, r) => {
      "use strict";
      let i;
      r.d(n, { useMetrika: () => t });
      var o = r(61910), s = r(80506);
      let t = () => {
        let e2 = (i || (i = (0, s.a)()), i), n2 = (0, o.useSyncExternalStore)(e2.isLoaded.onChange, () => e2.isLoaded.value);
        return (0, o.useMemo)(() => ({ ...e2, isLoaded: n2 }), [n2]);
      };
    },
    57249: (e, n, r) => {
      "use strict";
      e.exports = r.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    61336: (e) => {
      e.exports = {
        root: "MyMusicDownloadedTracksPageEmpty_root__LAXpY",
        icon: "MyMusicDownloadedTracksPageEmpty_icon__PDhk2",
        title: "MyMusicDownloadedTracksPageEmpty_title__g2w5R",
        text: "MyMusicDownloadedTracksPageEmpty_text__8RJFg"
      };
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    75312: (e, n, r) => {
      "use strict";
      r.d(n, { SomethingWentWrong: () => u });
      var i = r(54486), o = r(50420), s = r(28303), t = r(61910), l = r(43426), d = r(47713), a = r(77881), m = r(5956), h = r(97800), v = r(74125), P = r(80585), b = r(63708), c = r.n(b);
      let u = (0, s.PA)((e2) => {
        let { className: n2, withBackwardControl: r2 = true } = e2, { formatMessage: s2 } = (0, l.A)(), b2 = s2({ id: "error-messages.something-went-wrong" });
        (0, v.CgZ)(b2);
        let { sendRefreshEvent: u2 } = (0, v.cYT)(), _ = (0, t.useCallback)(() => {
          u2(), window.location.href = v.Zyd.main.href;
        }, [u2]), { contentRef: f } = (0, v.gKY)();
        return (0, i.jsxs)("div", {
          className: (0, o.$)(c().root, n2),
          children: [
            r2 && (0, i.jsx)(P.Lh, {
              withBackwardFallback: "/",
              className: (0, o.$)(c().navigation, { [c().navigation_desktop]: !f }),
              withForwardControl: false
            }),
            (0, i.jsxs)("div", {
              className: (0, o.$)(c().content, { [c().content_shrink]: !r2 }),
              children: [
                (0, i.jsx)(m.Icon, { className: c().icon, variant: "attention", size: "xxl" }),
                (0, i.jsx)(h.Heading, {
                  className: (0, o.$)(c().title, c().important),
                  variant: "h3",
                  size: "xs",
                  children: b2
                }),
                (0, i.jsxs)(h.Caption, {
                  className: (0, o.$)(c().text, c().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, i.jsx)(d.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, i.jsx)(a.$, {
                  onClick: _,
                  className: c().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, i.jsxs)(h.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, i.jsx)(d.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    76310: (e) => {
      e.exports = {
        root: "MyMusicDownloadedTracksPage_root__hZZwz",
        important: "MyMusicDownloadedTracksPage_important__QP_t0",
        pageContainer: "MyMusicDownloadedTracksPage_pageContainer__qu3hF",
        footer: "MyMusicDownloadedTracksPage_footer__KI5OP",
        content: "MyMusicDownloadedTracksPage_content__Iz1WY",
        trackShimmer: "MyMusicDownloadedTracksPage_trackShimmer__MZgW3"
      };
    },
    80506: (e, n, r) => {
      "use strict";
      r.d(n, { a: () => o });
      var i = r(87965);
      let o = () => {
        let e2 = null, n2 = new i.cJ(false), r2 = [];
        return {
          isLoaded: n2,
          init: (i2) => {
            var o2, s;
            if (void 0 !== (null == (o2 = window.Ya) ? void 0 : o2.Metrika2) && !n2.value)
              try {
                e2 = new window.Ya.Metrika2({ ...i2 }), n2.value = true, s = e2, r2.forEach((e3) => {
                  e3(s);
                }), r2.length = 0;
              } catch (e3) {
                ("string" == typeof e3 || e3 instanceof Error) && i2.logger.error(e3);
              }
          },
          count: function(n3) {
            let i2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "counter";
            e2 ? e2.params({ [i2]: n3 }) : r2.push((e3) => {
              e3.params({ [i2]: n3 });
            });
          },
          hit: (n3) => {
            e2 ? e2.hit(n3) : r2.push((e3) => {
              e3.hit(n3);
            });
          },
          reachGoal: (n3, i2) => {
            if (!e2) return void r2.push((e3) => e3.reachGoal(n3, i2));
            e2.reachGoal(n3, i2);
          }
        };
      };
    },
    82644: (e, n, r) => {
      "use strict";
      r.d(n, { w: () => i.SomethingWentWrong });
      var i = r(75312);
    },
    83645: (e, n, r) => {
      "use strict";
      r.d(n, { default: () => o.a });
      var i = r(36446), o = r.n(i);
    },
    89511: (e, n, r) => {
      "use strict";
      r.d(n, { b: () => a, L: () => i.useDownloadedTracks });
      var i = r(25751), o = r(93064), s = r(5693), t = r(21365), l = r(74125), d = r(26433);
      let a = o.gK.compose(
        o.gK.model("DownloadedTracks", {
          items: o.gK.maybeNull(o.gK.array(t.vj)),
          tracks: o.gK.maybeNull(o.gK.frozen())
        }),
        d.XT
      ).views((e2) => ({
        get tracksDurationInMinutes() {
          var n2, r2;
          return (null != (r2 = null == (n2 = e2.tracks) ? void 0 : n2.reduce((e3, n3) => n3.durationMs ? e3 + n3.durationMs : e3, 0)) ? r2 : 0) / 1e3 / 60;
        },
        get entitiesData() {
          if (!e2.tracks) return [];
          return e2.tracks.map((e3) => ({ type: s.R.DownloadedMusic, meta: e3 }));
        },
        get isEmpty() {
          var i2;
          return e2.isResolved && (null == (i2 = e2.items) ? void 0 : i2.length) === 0;
        }
      })).actions((e2) => ({
        getData: (0, o.L3)(function* (n2, r2) {
          let { modelActionsLogger: i2 } = (0, o._$)(e2);
          if (e2.loadingState !== l.GuX.PENDING)
            try {
              e2.loadingState = l.GuX.PENDING;
              let i3 = yield n2.getTracks(r2);
              e2.tracks = i3, e2.items = (0, o.wg)(i3.map((e3) => (0, t.vU)(e3))), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.RESOLVE);
            } catch (n3) {
              i2.error(n3), e2.loadingState !== l.GuX.IDLE && (e2.loadingState = l.GuX.REJECT);
            }
        }),
        reset() {
          e2.items = null, e2.tracks = null, e2.loadingState = l.GuX.IDLE;
        }
      }));
    },
    91165: (e, n, r) => {
      "use strict";
      function i(e2) {
        let { reason: n2, children: r2 } = e2;
        return r2;
      }
      Object.defineProperty(n, "__esModule", { value: true }), Object.defineProperty(n, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return i;
        }
      }), r(39201);
    },
    97151: (e, n, r) => {
      "use strict";
      r.d(n, { XU: () => h });
      var i, o, s = r(41500), t = r(61910), l = r(43426);
      !(function(e2) {
        e2.formatDate = "FormattedDate", e2.formatTime = "FormattedTime", e2.formatNumber = "FormattedNumber", e2.formatList = "FormattedList", e2.formatDisplayName = "FormattedDisplayName";
      })(i || (i = {})), (function(e2) {
        e2.formatDate = "FormattedDateParts", e2.formatTime = "FormattedTimeParts", e2.formatNumber = "FormattedNumberParts", e2.formatList = "FormattedListParts";
      })(o || (o = {}));
      var d = function(e2) {
        var n2 = (0, l.A)(), r2 = e2.value, i2 = e2.children, o2 = (0, s.__rest)(e2, ["value", "children"]);
        return i2(n2.formatNumberToParts(r2, o2));
      };
      function a(e2) {
        var n2 = function(n3) {
          var r2 = (0, l.A)(), i2 = n3.value, o2 = n3.children, t2 = (0, s.__rest)(n3, ["value", "children"]), d2 = "string" == typeof i2 ? new Date(i2 || 0) : i2;
          return o2("formatDate" === e2 ? r2.formatDateToParts(d2, t2) : r2.formatTimeToParts(d2, t2));
        };
        return n2.displayName = o[e2], n2;
      }
      function m(e2) {
        var n2 = function(n3) {
          var r2 = (0, l.A)(), i2 = n3.value, o2 = n3.children, d2 = (0, s.__rest)(n3, ["value", "children"]), a2 = r2[e2](i2, d2);
          if ("function" == typeof o2) return o2(a2);
          var m2 = r2.textComponent || t.Fragment;
          return t.createElement(m2, null, a2);
        };
        return n2.displayName = i[e2], n2;
      }
      d.displayName = "FormattedNumberParts", d.displayName = "FormattedNumberParts";
      var h = m("formatDate");
      m("formatTime"), m("formatNumber"), m("formatList"), m("formatDisplayName"), a("formatDate"), a("formatTime");
    },
    98944: (e, n, r) => {
      "use strict";
      function i(e2) {
        let { moduleIds: n2 } = e2;
        return null;
      }
      Object.defineProperty(n, "__esModule", { value: true }), Object.defineProperty(n, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return i;
        }
      }), r(54486), r(92803), r(14367), r(32038);
    }
  },
  (e) => {
    e.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1546,
        6952,
        6552,
        5081,
        2193,
        2036,
        2116,
        5352,
        1311,
        7764,
        6706,
        7724,
        5201,
        5148,
        3005,
        3916,
        4885,
        6266,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        1365,
        8629,
        7858,
        5164,
        4542,
        2460,
        4540,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 34582)
    ), _N_E = e.O();
  }
]);
