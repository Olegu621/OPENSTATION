(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [8209],
  {
    12733: (t, e, a) => {
      "use strict";
      a.r(e), a.d(e, { default: () => l });
      var s = a(54486), i = a(97396), o = a(39507);
      let l = () => {
        let t2 = (0, i.useSearchParams)().get("playlistId");
        return t2 || (0, i.notFound)(), (0, s.jsx)(o.uA, { params: { playlistId: t2 } });
      };
    },
    39507: (t, e, a) => {
      "use strict";
      a.d(e, { uA: () => n.PlaylistPersonalPage, Hj: () => r });
      var s = a(93064), i = a(14287), o = a(74125), l = a(26433);
      let r = s.gK.compose(
        s.gK.model("PlaylistPersonalPage", {
          errorStatusCode: s.gK.maybeNull(s.gK.number),
          playlistUuid: s.gK.maybe(s.gK.string),
          isReady: s.gK.optional(s.gK.boolean, false),
          dummyCoverUrl: s.gK.maybe(s.gK.string),
          dummyDescription: s.gK.maybe(s.gK.string),
          title: s.gK.maybe(s.gK.string)
        }),
        l.XT
      ).views((t2) => ({
        getUrl(e2) {
          if (!t2.playlistUuid) return "";
          let { href: a2 } = (0, o.uvd)("/playlists/:playlistUuid", {
            params: { playlistUuid: t2.playlistUuid },
            query: e2
          });
          return a2;
        },
        get url() {
          if (!t2.playlistUuid) return "";
          let { href: e2 } = (0, o.uvd)("/playlists/:playlistUuid", { params: { playlistUuid: t2.playlistUuid } });
          return e2;
        },
        get isNotFound() {
          let e2 = t2.errorStatusCode === i.X1.NOT_FOUND || t2.errorStatusCode === i.X1.BAD_REQUEST;
          return t2.loadingState === o.GuX.REJECT && e2;
        }
      })).actions((t2) => ({
        getPlaylistPersonalDetails: (0, s.L3)(function* (e2) {
          if (!(0, s._n)(t2)) return;
          let { playlistsResource: a2, modelActionsLogger: l2 } = (0, s._$)(t2);
          if (t2.loadingState !== o.GuX.PENDING)
            try {
              var r2, n2;
              t2.loadingState = o.GuX.PENDING;
              let s2 = yield a2.getPlaylistPersonal({ playlistId: e2 });
              if ((null == (r2 = s2.error) ? void 0 : r2.name) === "no-such-playlist") {
                t2.errorStatusCode = i.X1.NOT_FOUND, t2.loadingState = o.GuX.REJECT;
                return;
              }
              t2.isReady = s2.ready, t2.playlistUuid = s2.data.playlistUuid, t2.dummyCoverUrl = null == (n2 = s2.data.dummyCover) ? void 0 : n2.uri, t2.dummyDescription = s2.data.dummyDescription, t2.title = s2.data.title, t2.loadingState !== o.GuX.IDLE && (t2.loadingState = o.GuX.RESOLVE);
            } catch (e3) {
              l2.error(e3), e3 instanceof i.GX && (e3.statusCode === i.X1.NOT_FOUND || e3.statusCode === i.X1.BAD_REQUEST) && (t2.errorStatusCode = i.X1.NOT_FOUND), t2.loadingState !== o.GuX.IDLE && (t2.loadingState = o.GuX.REJECT);
            }
        }),
        reset() {
          t2.loadingState = o.GuX.IDLE, t2.errorStatusCode = null, t2.isReady = false, t2.playlistUuid = void 0, t2.dummyCoverUrl = void 0, t2.dummyDescription = void 0, t2.title = void 0;
        }
      }));
      a(95657), a(54486), a(42421);
      var n = a(65381);
    },
    41197: (t, e, a) => {
      Promise.resolve().then(a.bind(a, 12733));
    },
    42421: (t, e, a) => {
      "use strict";
      a.d(e, { M: () => s.NotFound });
      var s = a(65034);
    },
    46215: (t) => {
      t.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    65034: (t, e, a) => {
      "use strict";
      a.d(e, { NotFound: () => p });
      var s = a(54486), i = a(50420), o = a(28303), l = a(47713), r = a(77881), n = a(5956), d = a(97800), u = a(74125), m = a(80585), c = a(61910), y = a(46215), _ = a.n(y);
      let p = (0, o.PA)((t2) => {
        let { className: e2, title: a2, description: o2, iconVariant: y2 = "musicLogo", iconClassName: p2, iconSize: g } = t2, { contentRef: P } = (0, u.gKY)(), N = (0, u.ZpR)(u.Zyd.main.href);
        (0, u.LZB)();
        let { handleNavigateToMain: v } = (0, u.D5F)(N);
        return (0, u.NBO)(true), !(function() {
          let { location: t3 } = (0, u.Pjs)();
          (0, c.useEffect)(
            () => (t3.setNotFound(true), () => {
              t3.setNotFound(false);
            }),
            [t3]
          );
        })(), (0, s.jsxs)("div", {
          className: (0, i.$)(_().root, { [_().root_desktop]: !P }, e2),
          children: [
            (0, s.jsx)(m.Lh, { withBackwardFallback: "/", className: _().navigation, withForwardControl: false }),
            (0, s.jsxs)("div", {
              className: _().content,
              children: [
                (0, s.jsx)(n.Icon, { className: (0, i.$)(_().icon, p2), variant: y2, size: g }),
                (0, s.jsx)(d.Heading, {
                  className: (0, i.$)(_().title, _().important),
                  variant: "h3",
                  size: "xs",
                  children: a2 || (0, s.jsx)(l.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, s.jsx)(d.Caption, {
                  className: (0, i.$)(_().text, _().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: o2 || (0, s.jsx)(l.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, s.jsx)(r.$, {
                  onClick: v,
                  className: _().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, s.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, s.jsx)(l.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    65381: (t, e, a) => {
      "use strict";
      a.d(e, { PlaylistPersonalPage: () => d });
      var s = a(54486), i = a(28303), o = a(97396), l = a(61910), r = a(74125), n = a(95657);
      let d = (0, i.PA)((t2) => {
        let { params: e2, searchParams: a2 } = t2, { playlistPersonal: i2 } = (0, r.Pjs)(), d2 = i2.getUrl(a2);
        if ((0, l.useEffect)(() => {
          i2.isNeededToLoad && i2.getPlaylistPersonalDetails(e2.playlistId);
        }, [i2.isNeededToLoad, e2.playlistId, i2]), (0, l.useEffect)(
          () => () => {
            i2.reset();
          },
          [i2]
        ), (0, r.Jzs)(i2.isResolved), (i2.isNotFound || i2.isRejected) && (0, o.notFound)(), i2.isResolved && !i2.isReady)
          return i2.dummyDescription || (0, o.notFound)(), (0, s.jsx)(n.PlaylistPersonalDummyPage, {});
        i2.isResolved && i2.isReady && (0, o.redirect)(d2);
      });
    },
    88187: (t) => {
      t.exports = {
        root: "PlaylistPersonalDummyPage_root__tGxHG",
        cover: "PlaylistPersonalDummyPage_cover__XcCD1",
        title: "PlaylistPersonalDummyPage_title__ZSf9O",
        important: "PlaylistPersonalDummyPage_important__uEHGe",
        text: "PlaylistPersonalDummyPage_text__ci30d"
      };
    },
    95657: (t, e, a) => {
      "use strict";
      a.d(e, { PlaylistPersonalDummyPage: () => m });
      var s = a(54486), i = a(50420), o = a(28303), l = a(97800), r = a(74125), n = a(80585), d = a(88187), u = a.n(d);
      let m = (0, o.PA)(() => {
        let {
          playlistPersonal: { dummyCoverUrl: t2, dummyDescription: e2, title: a2 }
        } = (0, r.Pjs)();
        return (0, s.jsxs)("div", {
          className: u().root,
          children: [
            (0, s.jsx)(n.Y9, {}),
            (0, s.jsx)(n.BW, {
              src: t2,
              size: 200,
              fit: "cover",
              withAvatarReplace: true,
              "aria-hidden": true,
              className: u().cover
            }),
            a2 && (0, s.jsx)(l.Heading, {
              className: (0, i.$)(u().title, u().important),
              variant: "h1",
              size: "xs",
              children: a2
            }),
            e2 && (0, s.jsx)(l.Caption, {
              className: (0, i.$)(u().text, u().important),
              variant: "span",
              type: "text",
              size: "l",
              weight: "normal",
              children: e2
            })
          ]
        });
      });
    }
  },
  (t) => {
    t.O(
      0,
      [2685, 7956, 5355, 1023, 2116, 1311, 7764, 6706, 5148, 3005, 4125, 585, 6433, 5843, 3290, 7358],
      () => t(t.s = 41197)
    ), _N_E = t.O();
  }
]);
