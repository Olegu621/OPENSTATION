(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4004],
  {
    12393: (e) => {
      e.exports = { root: "PostArtists_root__Zxmjq", content: "PostArtists_content__JzGOH" };
    },
    23404: (e) => {
      e.exports = {
        root: "PostPage_root__Orhf7",
        scrollableContainer: "PostPage_scrollableContainer__iV9Bo",
        scrollContainer: "PostPage_scrollContainer__zrIrH",
        important: "PostPage_important__qUlED",
        container: "PostPage_container__orSfz",
        shimmerTitle: "PostPage_shimmerTitle__EeFCD"
      };
    },
    23615: (e, o, n) => {
      "use strict";
      var s;
      n.d(o, { Q: () => s }), (function(e2) {
        e2.ALBUMS = "albums", e2.ARTISTS = "artists", e2.PLAYLISTS = "playlists";
      })(s || (s = {}));
    },
    30827: (e) => {
      e.exports = { root: "PostAlbums_root__u2a1q", content: "PostAlbums_content__uMSez" };
    },
    42421: (e, o, n) => {
      "use strict";
      n.d(o, { M: () => s.NotFound });
      var s = n(65034);
    },
    42520: (e, o, n) => {
      "use strict";
      let s;
      n.d(o, { useMetrika: () => t });
      var r = n(61910), i = n(80506);
      let t = () => {
        let e2 = (s || (s = (0, i.a)()), s), o2 = (0, r.useSyncExternalStore)(e2.isLoaded.onChange, () => e2.isLoaded.value);
        return (0, r.useMemo)(() => ({ ...e2, isLoaded: o2 }), [o2]);
      };
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    50757: (e) => {
      e.exports = { root: "PostPlaylists_root__3tea0", content: "PostPlaylists_content__2fXI5" };
    },
    51892: (e) => {
      e.exports = {
        root: "PostShimmer_root__MlLkY",
        top: "PostShimmer_top__ySpmZ",
        bottom: "PostShimmer_bottom__ajW_P"
      };
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65034: (e, o, n) => {
      "use strict";
      n.d(o, { NotFound: () => c });
      var s = n(54486), r = n(50420), i = n(28303), t = n(47713), l = n(77881), d = n(5956), m = n(97800), h = n(74125), v = n(80585), a = n(61910), P = n(46215), b = n.n(P);
      let c = (0, i.PA)((e2) => {
        let { className: o2, title: n2, description: i2, iconVariant: P2 = "musicLogo", iconClassName: c2, iconSize: _ } = e2, { contentRef: u } = (0, h.gKY)(), p = (0, h.ZpR)(h.Zyd.main.href);
        (0, h.LZB)();
        let { handleNavigateToMain: x } = (0, h.D5F)(p);
        return (0, h.NBO)(true), !(function() {
          let { location: e3 } = (0, h.Pjs)();
          (0, a.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, s.jsxs)("div", {
          className: (0, r.$)(b().root, { [b().root_desktop]: !u }, o2),
          children: [
            (0, s.jsx)(v.Lh, { withBackwardFallback: "/", className: b().navigation, withForwardControl: false }),
            (0, s.jsxs)("div", {
              className: b().content,
              children: [
                (0, s.jsx)(d.Icon, { className: (0, r.$)(b().icon, c2), variant: P2, size: _ }),
                (0, s.jsx)(m.Heading, {
                  className: (0, r.$)(b().title, b().important),
                  variant: "h3",
                  size: "xs",
                  children: n2 || (0, s.jsx)(t.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, s.jsx)(m.Caption, {
                  className: (0, r.$)(b().text, b().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: i2 || (0, s.jsx)(t.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, s.jsx)(l.$, {
                  onClick: x,
                  className: b().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, s.jsx)(m.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, s.jsx)(t.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    69443: (e, o, n) => {
      Promise.resolve().then(n.bind(n, 58360)), Promise.resolve().then(n.bind(n, 14342)), Promise.resolve().then(n.bind(n, 62662)), Promise.resolve().then(n.bind(n, 6971)), Promise.resolve().then(n.bind(n, 22674)), Promise.resolve().then(n.bind(n, 51321)), Promise.resolve().then(n.bind(n, 97800)), Promise.resolve().then(n.bind(n, 42520)), Promise.resolve().then(n.bind(n, 30662)), Promise.resolve().then(n.bind(n, 31757)), Promise.resolve().then(n.bind(n, 51672)), Promise.resolve().then(n.bind(n, 63449)), Promise.resolve().then(n.bind(n, 65134)), Promise.resolve().then(n.bind(n, 96819)), Promise.resolve().then(n.bind(n, 38868)), Promise.resolve().then(n.bind(n, 77163)), Promise.resolve().then(n.bind(n, 96025)), Promise.resolve().then(n.bind(n, 51887)), Promise.resolve().then(n.bind(n, 25577)), Promise.resolve().then(n.bind(n, 65327)), Promise.resolve().then(n.bind(n, 3119)), Promise.resolve().then(n.bind(n, 74808)), Promise.resolve().then(n.bind(n, 92088)), Promise.resolve().then(n.bind(n, 83154)), Promise.resolve().then(n.bind(n, 14476)), Promise.resolve().then(n.bind(n, 88332)), Promise.resolve().then(n.bind(n, 16855)), Promise.resolve().then(n.bind(n, 28795)), Promise.resolve().then(n.bind(n, 93099)), Promise.resolve().then(n.bind(n, 15640)), Promise.resolve().then(n.bind(n, 82885)), Promise.resolve().then(n.bind(n, 99733)), Promise.resolve().then(n.bind(n, 18355)), Promise.resolve().then(n.bind(n, 42691)), Promise.resolve().then(n.bind(n, 37235)), Promise.resolve().then(n.bind(n, 3781)), Promise.resolve().then(n.bind(n, 33829)), Promise.resolve().then(n.bind(n, 39906)), Promise.resolve().then(n.bind(n, 50119)), Promise.resolve().then(n.bind(n, 21179)), Promise.resolve().then(n.bind(n, 7912)), Promise.resolve().then(n.bind(n, 50193)), Promise.resolve().then(n.bind(n, 83399)), Promise.resolve().then(n.bind(n, 11450)), Promise.resolve().then(n.bind(n, 62345)), Promise.resolve().then(n.bind(n, 37408)), Promise.resolve().then(n.bind(n, 48392)), Promise.resolve().then(n.bind(n, 42488)), Promise.resolve().then(n.bind(n, 5207)), Promise.resolve().then(n.bind(n, 69536)), Promise.resolve().then(n.bind(n, 11472)), Promise.resolve().then(n.bind(n, 2438)), Promise.resolve().then(n.bind(n, 46540)), Promise.resolve().then(n.bind(n, 72467)), Promise.resolve().then(n.bind(n, 66894)), Promise.resolve().then(n.bind(n, 45318)), Promise.resolve().then(n.bind(n, 3283)), Promise.resolve().then(n.bind(n, 77026)), Promise.resolve().then(n.bind(n, 93685)), Promise.resolve().then(n.bind(n, 8394)), Promise.resolve().then(n.bind(n, 3192)), Promise.resolve().then(n.bind(n, 7286)), Promise.resolve().then(n.bind(n, 60305)), Promise.resolve().then(n.bind(n, 47203)), Promise.resolve().then(n.bind(n, 34286)), Promise.resolve().then(n.bind(n, 224)), Promise.resolve().then(n.bind(n, 24449)), Promise.resolve().then(n.bind(n, 79893)), Promise.resolve().then(n.bind(n, 81789)), Promise.resolve().then(n.bind(n, 87466)), Promise.resolve().then(n.bind(n, 39034)), Promise.resolve().then(n.bind(n, 17917)), Promise.resolve().then(n.bind(n, 11337)), Promise.resolve().then(n.bind(n, 19683)), Promise.resolve().then(n.bind(n, 53779)), Promise.resolve().then(n.bind(n, 12359)), Promise.resolve().then(n.bind(n, 88564)), Promise.resolve().then(n.bind(n, 95639)), Promise.resolve().then(n.bind(n, 57630)), Promise.resolve().then(n.bind(n, 25342)), Promise.resolve().then(n.bind(n, 34028)), Promise.resolve().then(n.bind(n, 99564)), Promise.resolve().then(n.bind(n, 95348)), Promise.resolve().then(n.bind(n, 52347)), Promise.resolve().then(n.bind(n, 61015)), Promise.resolve().then(n.bind(n, 1771)), Promise.resolve().then(n.bind(n, 80043)), Promise.resolve().then(n.bind(n, 12235)), Promise.resolve().then(n.bind(n, 8941)), Promise.resolve().then(n.bind(n, 38433)), Promise.resolve().then(n.bind(n, 8732)), Promise.resolve().then(n.bind(n, 43369)), Promise.resolve().then(n.bind(n, 47564)), Promise.resolve().then(n.bind(n, 41017)), Promise.resolve().then(n.bind(n, 27252)), Promise.resolve().then(n.bind(n, 65286)), Promise.resolve().then(n.bind(n, 45198)), Promise.resolve().then(n.bind(n, 46814)), Promise.resolve().then(n.bind(n, 92508)), Promise.resolve().then(n.bind(n, 40126)), Promise.resolve().then(n.bind(n, 83726)), Promise.resolve().then(n.bind(n, 90410)), Promise.resolve().then(n.bind(n, 13246)), Promise.resolve().then(n.bind(n, 26040)), Promise.resolve().then(n.bind(n, 92446)), Promise.resolve().then(n.bind(n, 42593)), Promise.resolve().then(n.bind(n, 70570)), Promise.resolve().then(n.bind(n, 88416)), Promise.resolve().then(n.bind(n, 24174)), Promise.resolve().then(n.bind(n, 78458)), Promise.resolve().then(n.bind(n, 59457)), Promise.resolve().then(n.bind(n, 6690)), Promise.resolve().then(n.bind(n, 88370)), Promise.resolve().then(n.bind(n, 66904)), Promise.resolve().then(n.bind(n, 39937)), Promise.resolve().then(n.bind(n, 33019)), Promise.resolve().then(n.bind(n, 38808)), Promise.resolve().then(n.bind(n, 58094)), Promise.resolve().then(n.bind(n, 78009)), Promise.resolve().then(n.bind(n, 33427)), Promise.resolve().then(n.bind(n, 30878)), Promise.resolve().then(n.bind(n, 53115)), Promise.resolve().then(n.bind(n, 52398)), Promise.resolve().then(n.bind(n, 82327)), Promise.resolve().then(n.bind(n, 17012)), Promise.resolve().then(n.bind(n, 9275)), Promise.resolve().then(n.bind(n, 17658)), Promise.resolve().then(n.bind(n, 36578)), Promise.resolve().then(n.bind(n, 66989)), Promise.resolve().then(n.bind(n, 58863)), Promise.resolve().then(n.bind(n, 60899)), Promise.resolve().then(n.bind(n, 59437)), Promise.resolve().then(n.bind(n, 43367)), Promise.resolve().then(n.bind(n, 66446)), Promise.resolve().then(n.bind(n, 86840)), Promise.resolve().then(n.bind(n, 75181)), Promise.resolve().then(n.bind(n, 99538)), Promise.resolve().then(n.bind(n, 45252)), Promise.resolve().then(n.bind(n, 59226)), Promise.resolve().then(n.bind(n, 75961)), Promise.resolve().then(n.bind(n, 33964)), Promise.resolve().then(n.bind(n, 33967)), Promise.resolve().then(n.bind(n, 64410)), Promise.resolve().then(n.bind(n, 91350)), Promise.resolve().then(n.bind(n, 4500)), Promise.resolve().then(n.bind(n, 55846)), Promise.resolve().then(n.bind(n, 65689)), Promise.resolve().then(n.bind(n, 99386)), Promise.resolve().then(n.bind(n, 5222)), Promise.resolve().then(n.bind(n, 60440)), Promise.resolve().then(n.bind(n, 37271)), Promise.resolve().then(n.bind(n, 66688)), Promise.resolve().then(n.bind(n, 76472)), Promise.resolve().then(n.bind(n, 41682)), Promise.resolve().then(n.bind(n, 77666)), Promise.resolve().then(n.bind(n, 8765)), Promise.resolve().then(n.bind(n, 48670)), Promise.resolve().then(n.bind(n, 22096)), Promise.resolve().then(n.bind(n, 33655)), Promise.resolve().then(n.bind(n, 27754)), Promise.resolve().then(n.bind(n, 47347)), Promise.resolve().then(n.bind(n, 45591)), Promise.resolve().then(n.bind(n, 52862)), Promise.resolve().then(n.bind(n, 79326)), Promise.resolve().then(n.bind(n, 73922)), Promise.resolve().then(n.bind(n, 10790)), Promise.resolve().then(n.bind(n, 78684)), Promise.resolve().then(n.bind(n, 76877)), Promise.resolve().then(n.bind(n, 61176)), Promise.resolve().then(n.bind(n, 62108)), Promise.resolve().then(n.bind(n, 75053)), Promise.resolve().then(n.bind(n, 23035)), Promise.resolve().then(n.bind(n, 82315)), Promise.resolve().then(n.bind(n, 60673)), Promise.resolve().then(n.bind(n, 5048)), Promise.resolve().then(n.bind(n, 50215)), Promise.resolve().then(n.bind(n, 78308)), Promise.resolve().then(n.bind(n, 10084)), Promise.resolve().then(n.bind(n, 58681)), Promise.resolve().then(n.bind(n, 18658)), Promise.resolve().then(n.bind(n, 6323)), Promise.resolve().then(n.bind(n, 78817)), Promise.resolve().then(n.bind(n, 7230)), Promise.resolve().then(n.bind(n, 38378)), Promise.resolve().then(n.bind(n, 35609)), Promise.resolve().then(n.bind(n, 18606)), Promise.resolve().then(n.bind(n, 68014)), Promise.resolve().then(n.bind(n, 12126)), Promise.resolve().then(n.bind(n, 52742)), Promise.resolve().then(n.bind(n, 68098)), Promise.resolve().then(n.bind(n, 89190)), Promise.resolve().then(n.bind(n, 3270)), Promise.resolve().then(n.bind(n, 1220)), Promise.resolve().then(n.bind(n, 96584)), Promise.resolve().then(n.bind(n, 54598)), Promise.resolve().then(n.bind(n, 14196)), Promise.resolve().then(n.bind(n, 20576)), Promise.resolve().then(n.bind(n, 29070)), Promise.resolve().then(n.bind(n, 35203)), Promise.resolve().then(n.bind(n, 39450)), Promise.resolve().then(n.bind(n, 77607)), Promise.resolve().then(n.bind(n, 7430)), Promise.resolve().then(n.bind(n, 24786)), Promise.resolve().then(n.bind(n, 24036)), Promise.resolve().then(n.bind(n, 34932)), Promise.resolve().then(n.bind(n, 56204)), Promise.resolve().then(n.bind(n, 75450)), Promise.resolve().then(n.bind(n, 60608)), Promise.resolve().then(n.bind(n, 33648)), Promise.resolve().then(n.bind(n, 43548)), Promise.resolve().then(n.bind(n, 69672)), Promise.resolve().then(n.bind(n, 50711)), Promise.resolve().then(n.bind(n, 5185)), Promise.resolve().then(n.bind(n, 90555)), Promise.resolve().then(n.bind(n, 5602)), Promise.resolve().then(n.bind(n, 12390)), Promise.resolve().then(n.bind(n, 58376)), Promise.resolve().then(n.bind(n, 24491)), Promise.resolve().then(n.bind(n, 61993)), Promise.resolve().then(n.bind(n, 38644)), Promise.resolve().then(n.bind(n, 93668)), Promise.resolve().then(n.bind(n, 85949)), Promise.resolve().then(n.bind(n, 17519)), Promise.resolve().then(n.bind(n, 62010)), Promise.resolve().then(n.bind(n, 16372)), Promise.resolve().then(n.bind(n, 64434)), Promise.resolve().then(n.bind(n, 33158)), Promise.resolve().then(n.bind(n, 27314)), Promise.resolve().then(n.bind(n, 93206)), Promise.resolve().then(n.bind(n, 37226)), Promise.resolve().then(n.bind(n, 13811)), Promise.resolve().then(n.bind(n, 45645)), Promise.resolve().then(n.bind(n, 24126)), Promise.resolve().then(n.bind(n, 20406)), Promise.resolve().then(n.bind(n, 21940)), Promise.resolve().then(n.bind(n, 26086)), Promise.resolve().then(n.bind(n, 96838)), Promise.resolve().then(n.bind(n, 10358)), Promise.resolve().then(n.bind(n, 23143)), Promise.resolve().then(n.bind(n, 51828)), Promise.resolve().then(n.bind(n, 51725)), Promise.resolve().then(n.bind(n, 23834)), Promise.resolve().then(n.bind(n, 88343)), Promise.resolve().then(n.bind(n, 24624));
    },
    75312: (e, o, n) => {
      "use strict";
      n.d(o, { SomethingWentWrong: () => _ });
      var s = n(54486), r = n(50420), i = n(28303), t = n(61910), l = n(43426), d = n(47713), m = n(77881), h = n(5956), v = n(97800), a = n(74125), P = n(80585), b = n(63708), c = n.n(b);
      let _ = (0, i.PA)((e2) => {
        let { className: o2, withBackwardControl: n2 = true } = e2, { formatMessage: i2 } = (0, l.A)(), b2 = i2({ id: "error-messages.something-went-wrong" });
        (0, a.CgZ)(b2);
        let { sendRefreshEvent: _2 } = (0, a.cYT)(), u = (0, t.useCallback)(() => {
          _2(), window.location.href = a.Zyd.main.href;
        }, [_2]), { contentRef: p } = (0, a.gKY)();
        return (0, s.jsxs)("div", {
          className: (0, r.$)(c().root, o2),
          children: [
            n2 && (0, s.jsx)(P.Lh, {
              withBackwardFallback: "/",
              className: (0, r.$)(c().navigation, { [c().navigation_desktop]: !p }),
              withForwardControl: false
            }),
            (0, s.jsxs)("div", {
              className: (0, r.$)(c().content, { [c().content_shrink]: !n2 }),
              children: [
                (0, s.jsx)(h.Icon, { className: c().icon, variant: "attention", size: "xxl" }),
                (0, s.jsx)(v.Heading, {
                  className: (0, r.$)(c().title, c().important),
                  variant: "h3",
                  size: "xs",
                  children: b2
                }),
                (0, s.jsxs)(v.Caption, {
                  className: (0, r.$)(c().text, c().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, s.jsx)(d.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, s.jsx)(m.$, {
                  onClick: u,
                  className: c().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, s.jsxs)(v.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, s.jsx)(d.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    77026: (e, o, n) => {
      "use strict";
      n.d(o, { PostNotFoundPage: () => t });
      var s = n(54486), r = n(28303), i = n(42421);
      let t = (0, r.PA)(() => (0, s.jsx)(i.M, {}));
    },
    80506: (e, o, n) => {
      "use strict";
      n.d(o, { a: () => r });
      var s = n(87965);
      let r = () => {
        let e2 = null, o2 = new s.cJ(false), n2 = [];
        return {
          isLoaded: o2,
          init: (s2) => {
            var r2, i;
            if (void 0 !== (null == (r2 = window.Ya) ? void 0 : r2.Metrika2) && !o2.value)
              try {
                e2 = new window.Ya.Metrika2({ ...s2 }), o2.value = true, i = e2, n2.forEach((e3) => {
                  e3(i);
                }), n2.length = 0;
              } catch (e3) {
                ("string" == typeof e3 || e3 instanceof Error) && s2.logger.error(e3);
              }
          },
          count: function(o3) {
            let s2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "counter";
            e2 ? e2.params({ [s2]: o3 }) : n2.push((e3) => {
              e3.params({ [s2]: o3 });
            });
          },
          hit: (o3) => {
            e2 ? e2.hit(o3) : n2.push((e3) => {
              e3.hit(o3);
            });
          },
          reachGoal: (o3, s2) => {
            if (!e2) return void n2.push((e3) => e3.reachGoal(o3, s2));
            e2.reachGoal(o3, s2);
          }
        };
      };
    },
    82644: (e, o, n) => {
      "use strict";
      n.d(o, { w: () => s.SomethingWentWrong });
      var s = n(75312);
    },
    93685: (e, o, n) => {
      "use strict";
      n.d(o, { PostPage: () => z });
      var s = n(54486), r = n(50420), i = n(28303), t = n(97396), l = n(61910), d = n(23615), m = n(56231), h = n(22674), v = n(97800), a = n(82644), P = n(33276), b = n(74125), c = n(80585), _ = n(51892), u = n.n(_);
      let p = () => (0, s.jsxs)("div", {
        className: u().root,
        children: [
          (0, s.jsx)(h.Shimmer, { radius: "l", className: u().top }),
          (0, s.jsx)(h.Shimmer, { radius: "l", className: u().bottom })
        ]
      });
      var x = n(23404), g = n.n(x), j = n(94376), N = n(30827), S = n.n(N);
      let k = (0, i.PA)((e2) => {
        let { albums: o2 = [] } = e2;
        return (0, s.jsx)("div", {
          className: S().root,
          children: (0, s.jsx)("div", {
            className: S().content,
            "aria-labelledby": "post-page-header",
            tabIndex: 0,
            children: o2.map((e3) => (0, s.jsx)(j.aX, { className: S().item, album: e3, contentLinesCount: 3 }, e3.id))
          })
        });
      });
      var w = n(55616), W = n(12393), y = n.n(W);
      let C = (0, i.PA)((e2) => {
        let { artists: o2 = [] } = e2;
        return (0, s.jsx)("div", {
          className: y().root,
          children: (0, s.jsx)("div", {
            className: y().content,
            "aria-labelledby": "post-page-header",
            tabIndex: 0,
            children: o2.map((e3) => (0, s.jsx)(w.ao, { className: y().item, artist: e3, contentLinesCount: 3 }, e3.id))
          })
        });
      });
      var f = n(83909), F = n(50757), A = n.n(F);
      let L = (0, i.PA)((e2) => {
        let { playlists: o2 = [] } = e2;
        return (0, s.jsx)("div", {
          className: A().root,
          children: (0, s.jsx)("div", {
            className: A().content,
            "aria-labelledby": "post-page-header",
            tabIndex: 0,
            children: o2.map(
              (e3) => (0, s.jsx)(f.B6, { className: A().item, playlist: e3, contentLinesCount: 3 }, e3.id)
            )
          })
        });
      }), z = (0, i.PA)((e2) => {
        let { promoId: o2 } = e2, { post: n2 } = (0, b.Pjs)(), i2 = (0, b.W6M)(), { contentScrollRef: _2, setContentScrollRef: u2 } = (0, b.gKY)();
        (0, l.useEffect)(
          () => () => {
            n2.reset();
          },
          [n2]
        ), n2.isNotFound && (0, t.notFound)(), (0, b.Jzs)(n2.isResolved);
        let x2 = (0, l.useMemo)(() => {
          if (n2.isLoading) return (0, s.jsx)(p, {});
          switch (n2.promotionType) {
            case d.Q.ARTISTS:
              return (0, s.jsx)(C, { artists: n2.artists });
            case d.Q.ALBUMS:
              return (0, s.jsx)(k, { albums: n2.albums });
            case d.Q.PLAYLISTS:
              return (0, s.jsx)(L, { playlists: n2.playlists });
            default:
              (0, t.notFound)();
          }
        }, [n2.albums, n2.artists, n2.isLoading, n2.playlists, n2.promotionType]);
        return (o2 && n2.isNeededToLoad && (0, l.use)(n2.getData({ promoId: o2 })), n2.isSomethingWrong) ? (0, s.jsx)(a.w, {}) : (0, s.jsx)(b.nVz, {
          pageId: b._Q$.POST,
          children: (0, s.jsx)(P.hO, {
            scrollElement: _2,
            outerTitle: n2.title || void 0,
            children: (0, s.jsxs)("div", {
              className: g().root,
              children: [
                (0, s.jsx)(c.Y9, {
                  variant: c.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: i2.canBack,
                  children: n2.title ? (0, s.jsx)(v.Heading, {
                    id: "post-header",
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: n2.title
                  }) : (0, s.jsx)(h.Shimmer, { className: g().shimmerTitle, radius: "l" })
                }),
                (0, s.jsx)(m.N, {
                  containerClassName: (0, r.$)(g().scrollContainer, g().important),
                  className: g().scrollableContainer,
                  ref: u2,
                  children: (0, s.jsx)("div", { className: g().container, children: x2 })
                })
              ]
            })
          })
        });
      });
    }
  },
  (e) => {
    e.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1546,
        5081,
        2116,
        2036,
        1311,
        7764,
        6706,
        5148,
        3005,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        3909,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 69443)
    ), _N_E = e.O();
  }
]);
