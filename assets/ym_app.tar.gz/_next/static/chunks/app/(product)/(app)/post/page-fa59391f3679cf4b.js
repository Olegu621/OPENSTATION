(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [3069],
  {
    12393: (t) => {
      t.exports = { root: "PostArtists_root__Zxmjq", content: "PostArtists_content__JzGOH" };
    },
    23404: (t) => {
      t.exports = {
        root: "PostPage_root__Orhf7",
        scrollableContainer: "PostPage_scrollableContainer__iV9Bo",
        scrollContainer: "PostPage_scrollContainer__zrIrH",
        important: "PostPage_important__qUlED",
        container: "PostPage_container__orSfz",
        shimmerTitle: "PostPage_shimmerTitle__EeFCD"
      };
    },
    23615: (t, e, o) => {
      "use strict";
      var s;
      o.d(e, { Q: () => s }), (function(t2) {
        t2.ALBUMS = "albums", t2.ARTISTS = "artists", t2.PLAYLISTS = "playlists";
      })(s || (s = {}));
    },
    30827: (t) => {
      t.exports = { root: "PostAlbums_root__u2a1q", content: "PostAlbums_content__uMSez" };
    },
    41545: (t, e, o) => {
      Promise.resolve().then(o.bind(o, 64021));
    },
    42421: (t, e, o) => {
      "use strict";
      o.d(e, { M: () => s.NotFound });
      var s = o(65034);
    },
    46215: (t) => {
      t.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    48625: (t, e, o) => {
      "use strict";
      o.d(e, { EX: () => g.PostPage, VQ: () => _ });
      var s = o(93064), a = o(14287), n = o(23615), r = o(94376), i = o(83909), l = o(63695), d = o(13611), c = o(74125), m = o(26433);
      let _ = s.gK.compose(
        s.gK.model("PostPage", {
          errorStatusCode: s.gK.maybe(s.gK.number),
          title: s.gK.maybeNull(s.gK.string),
          promotionType: s.gK.maybeNull(s.gK.enumeration(Object.values(n.Q))),
          artists: s.gK.maybe(s.gK.array(l.PK)),
          albums: s.gK.maybe(s.gK.array(r.JC)),
          playlists: s.gK.maybe(s.gK.array(i.IP))
        }),
        m.XT
      ).views((t2) => {
        let e2 = {
          get isLoading() {
            return t2.isNeededToLoad || t2.loadingState === c.GuX.PENDING;
          },
          get isNotFound() {
            let e3 = t2.errorStatusCode === a.X1.NOT_FOUND || t2.errorStatusCode === a.X1.BAD_REQUEST;
            return t2.isRejected && e3;
          },
          get isSomethingWrong() {
            return t2.isRejected && !e2.isNotFound;
          }
        };
        return e2;
      }).actions((t2) => ({
        getData: (0, s.L3)(function* (e2) {
          let { promoId: o2 } = e2, { feedResource: n2, modelActionsLogger: i2 } = (0, s._$)(t2);
          if (t2.loadingState !== c.GuX.PENDING)
            try {
              t2.loadingState = c.GuX.PENDING;
              let e3 = yield n2.getPromotionsById({ promoId: o2 });
              t2.title = e3.title, t2.promotionType = e3.promotionType, e3.artists && e3.artists.length > 0 && (t2.artists = (0, s.wg)(e3.artists.map(l.dM))), e3.albums && e3.albums.length > 0 && (t2.albums = (0, s.wg)(e3.albums.map(r.pp))), e3.playlists && e3.playlists.length > 0 && (t2.playlists = (0, s.wg)(
                e3.playlists.map((t3) => {
                  let { playlist: e4 } = t3;
                  return (0, d.jX)(e4);
                })
              )), t2.loadingState !== c.GuX.IDLE && (t2.loadingState = c.GuX.RESOLVE);
            } catch (e3) {
              i2.error(e3), e3 instanceof a.GX && (e3.statusCode === a.X1.NOT_FOUND || e3.statusCode === a.X1.BAD_REQUEST) && (t2.errorStatusCode = a.X1.NOT_FOUND), t2.loadingState !== c.GuX.IDLE && (t2.loadingState = c.GuX.REJECT);
            }
        }),
        reset() {
          t2.loadingState = c.GuX.IDLE, t2.title = null, t2.artists = (0, s.wg)([]), t2.albums = (0, s.wg)([]);
        }
      }));
      o(77026);
      var g = o(93685);
    },
    50757: (t) => {
      t.exports = { root: "PostPlaylists_root__3tea0", content: "PostPlaylists_content__2fXI5" };
    },
    51892: (t) => {
      t.exports = {
        root: "PostShimmer_root__MlLkY",
        top: "PostShimmer_top__ySpmZ",
        bottom: "PostShimmer_bottom__ajW_P"
      };
    },
    63708: (t) => {
      t.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    64021: (t, e, o) => {
      "use strict";
      o.r(e), o.d(e, { default: () => i });
      var s = o(54486), a = o(97396), n = o(61910), r = o(48625);
      let i = () => {
        let t2 = (0, a.useSearchParams)().get("promoId");
        return t2 || (0, a.notFound)(), (0, s.jsx)(n.Suspense, { children: (0, s.jsx)(r.EX, { promoId: t2 }) });
      };
    },
    65034: (t, e, o) => {
      "use strict";
      o.d(e, { NotFound: () => p });
      var s = o(54486), a = o(50420), n = o(28303), r = o(47713), i = o(77881), l = o(5956), d = o(97800), c = o(74125), m = o(80585), _ = o(61910), g = o(46215), u = o.n(g);
      let p = (0, n.PA)((t2) => {
        let { className: e2, title: o2, description: n2, iconVariant: g2 = "musicLogo", iconClassName: p2, iconSize: h } = t2, { contentRef: x } = (0, c.gKY)(), N = (0, c.ZpR)(c.Zyd.main.href);
        (0, c.LZB)();
        let { handleNavigateToMain: j } = (0, c.D5F)(N);
        return (0, c.NBO)(true), !(function() {
          let { location: t3 } = (0, c.Pjs)();
          (0, _.useEffect)(
            () => (t3.setNotFound(true), () => {
              t3.setNotFound(false);
            }),
            [t3]
          );
        })(), (0, s.jsxs)("div", {
          className: (0, a.$)(u().root, { [u().root_desktop]: !x }, e2),
          children: [
            (0, s.jsx)(m.Lh, { withBackwardFallback: "/", className: u().navigation, withForwardControl: false }),
            (0, s.jsxs)("div", {
              className: u().content,
              children: [
                (0, s.jsx)(l.Icon, { className: (0, a.$)(u().icon, p2), variant: g2, size: h }),
                (0, s.jsx)(d.Heading, {
                  className: (0, a.$)(u().title, u().important),
                  variant: "h3",
                  size: "xs",
                  children: o2 || (0, s.jsx)(r.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, s.jsx)(d.Caption, {
                  className: (0, a.$)(u().text, u().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: n2 || (0, s.jsx)(r.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, s.jsx)(i.$, {
                  onClick: j,
                  className: u().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, s.jsx)(d.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, s.jsx)(r.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    75312: (t, e, o) => {
      "use strict";
      o.d(e, { SomethingWentWrong: () => h });
      var s = o(54486), a = o(50420), n = o(28303), r = o(61910), i = o(43426), l = o(47713), d = o(77881), c = o(5956), m = o(97800), _ = o(74125), g = o(80585), u = o(63708), p = o.n(u);
      let h = (0, n.PA)((t2) => {
        let { className: e2, withBackwardControl: o2 = true } = t2, { formatMessage: n2 } = (0, i.A)(), u2 = n2({ id: "error-messages.something-went-wrong" });
        (0, _.CgZ)(u2);
        let { sendRefreshEvent: h2 } = (0, _.cYT)(), x = (0, r.useCallback)(() => {
          h2(), window.location.href = _.Zyd.main.href;
        }, [h2]), { contentRef: N } = (0, _.gKY)();
        return (0, s.jsxs)("div", {
          className: (0, a.$)(p().root, e2),
          children: [
            o2 && (0, s.jsx)(g.Lh, {
              withBackwardFallback: "/",
              className: (0, a.$)(p().navigation, { [p().navigation_desktop]: !N }),
              withForwardControl: false
            }),
            (0, s.jsxs)("div", {
              className: (0, a.$)(p().content, { [p().content_shrink]: !o2 }),
              children: [
                (0, s.jsx)(c.Icon, { className: p().icon, variant: "attention", size: "xxl" }),
                (0, s.jsx)(m.Heading, {
                  className: (0, a.$)(p().title, p().important),
                  variant: "h3",
                  size: "xs",
                  children: u2
                }),
                (0, s.jsxs)(m.Caption, {
                  className: (0, a.$)(p().text, p().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, s.jsx)(l.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, s.jsx)(d.$, {
                  onClick: x,
                  className: p().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, s.jsxs)(m.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, s.jsx)(l.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    77026: (t, e, o) => {
      "use strict";
      o.d(e, { PostNotFoundPage: () => r });
      var s = o(54486), a = o(28303), n = o(42421);
      let r = (0, a.PA)(() => (0, s.jsx)(n.M, {}));
    },
    82644: (t, e, o) => {
      "use strict";
      o.d(e, { w: () => s.SomethingWentWrong });
      var s = o(75312);
    },
    93685: (t, e, o) => {
      "use strict";
      o.d(e, { PostPage: () => L });
      var s = o(54486), a = o(50420), n = o(28303), r = o(97396), i = o(61910), l = o(23615), d = o(56231), c = o(22674), m = o(97800), _ = o(82644), g = o(33276), u = o(74125), p = o(80585), h = o(51892), x = o.n(h);
      let N = () => (0, s.jsxs)("div", {
        className: x().root,
        children: [
          (0, s.jsx)(c.Shimmer, { radius: "l", className: x().top }),
          (0, s.jsx)(c.Shimmer, { radius: "l", className: x().bottom })
        ]
      });
      var j = o(23404), b = o.n(j), v = o(94376), P = o(30827), S = o.n(P);
      let y = (0, n.PA)((t2) => {
        let { albums: e2 = [] } = t2;
        return (0, s.jsx)("div", {
          className: S().root,
          children: (0, s.jsx)("div", {
            className: S().content,
            "aria-labelledby": "post-page-header",
            tabIndex: 0,
            children: e2.map((t3) => (0, s.jsx)(v.aX, { className: S().item, album: t3, contentLinesCount: 3 }, t3.id))
          })
        });
      });
      var C = o(55616), W = o(12393), w = o.n(W);
      let F = (0, n.PA)((t2) => {
        let { artists: e2 = [] } = t2;
        return (0, s.jsx)("div", {
          className: w().root,
          children: (0, s.jsx)("div", {
            className: w().content,
            "aria-labelledby": "post-page-header",
            tabIndex: 0,
            children: e2.map((t3) => (0, s.jsx)(C.ao, { className: w().item, artist: t3, contentLinesCount: 3 }, t3.id))
          })
        });
      });
      var k = o(83909), T = o(50757), E = o.n(T);
      let A = (0, n.PA)((t2) => {
        let { playlists: e2 = [] } = t2;
        return (0, s.jsx)("div", {
          className: E().root,
          children: (0, s.jsx)("div", {
            className: E().content,
            "aria-labelledby": "post-page-header",
            tabIndex: 0,
            children: e2.map(
              (t3) => (0, s.jsx)(k.B6, { className: E().item, playlist: t3, contentLinesCount: 3 }, t3.id)
            )
          })
        });
      }), L = (0, n.PA)((t2) => {
        let { promoId: e2 } = t2, { post: o2 } = (0, u.Pjs)(), n2 = (0, u.W6M)(), { contentScrollRef: h2, setContentScrollRef: x2 } = (0, u.gKY)();
        (0, i.useEffect)(
          () => () => {
            o2.reset();
          },
          [o2]
        ), o2.isNotFound && (0, r.notFound)(), (0, u.Jzs)(o2.isResolved);
        let j2 = (0, i.useMemo)(() => {
          if (o2.isLoading) return (0, s.jsx)(N, {});
          switch (o2.promotionType) {
            case l.Q.ARTISTS:
              return (0, s.jsx)(F, { artists: o2.artists });
            case l.Q.ALBUMS:
              return (0, s.jsx)(y, { albums: o2.albums });
            case l.Q.PLAYLISTS:
              return (0, s.jsx)(A, { playlists: o2.playlists });
            default:
              (0, r.notFound)();
          }
        }, [o2.albums, o2.artists, o2.isLoading, o2.playlists, o2.promotionType]);
        return (e2 && o2.isNeededToLoad && (0, i.use)(o2.getData({ promoId: e2 })), o2.isSomethingWrong) ? (0, s.jsx)(_.w, {}) : (0, s.jsx)(u.nVz, {
          pageId: u._Q$.POST,
          children: (0, s.jsx)(g.hO, {
            scrollElement: h2,
            outerTitle: o2.title || void 0,
            children: (0, s.jsxs)("div", {
              className: b().root,
              children: [
                (0, s.jsx)(p.Y9, {
                  variant: p.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: n2.canBack,
                  children: o2.title ? (0, s.jsx)(m.Heading, {
                    id: "post-header",
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: o2.title
                  }) : (0, s.jsx)(c.Shimmer, { className: b().shimmerTitle, radius: "l" })
                }),
                (0, s.jsx)(d.N, {
                  containerClassName: (0, a.$)(b().scrollContainer, b().important),
                  className: b().scrollableContainer,
                  ref: x2,
                  children: (0, s.jsx)("div", { className: b().container, children: j2 })
                })
              ]
            })
          })
        });
      });
    }
  },
  (t) => {
    t.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1546,
        5081,
        2116,
        2036,
        1311,
        7764,
        6706,
        5148,
        3005,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        3909,
        5843,
        3290,
        7358
      ],
      () => t(t.s = 41545)
    ), _N_E = t.O();
  }
]);
