(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4398],
  {
    7032: (e, t, o) => {
      "use strict";
      o.d(t, { m: () => d });
      var n = o(54486), i = o(50420), l = o(15209), r = o(39610), s = o(97800), a = o(18433), c = o.n(a);
      let d = (e2) => {
        let { title: t2, children: o2, restrictionsClassName: a2, ...d2 } = e2;
        return (0, n.jsxs)("section", {
          className: c().root,
          ...(0, l.getDataAttrFromProps)(d2),
          children: [
            t2 && (0, n.jsxs)(n.Fragment, {
              children: [
                (0, n.jsx)(s.Caption, {
                  variant: "span",
                  type: "text",
                  size: "m",
                  weight: "medium",
                  "aria-hidden": true,
                  children: t2
                }),
                (0, n.jsx)(r.q, { children: (0, n.jsx)(s.Heading, { variant: "h4", children: t2 }) })
              ]
            }),
            (0, n.jsx)("div", { className: (0, i.$)(c().restrictions, a2), children: o2 })
          ]
        });
      };
    },
    13384: (e) => {
      e.exports = {
        root: "CustomPlayerThumbSelector_root__DQT1f",
        title: "CustomPlayerThumbSelector_title__9Eai2",
        thumbsContainer: "CustomPlayerThumbSelector_thumbsContainer__ywFZ1",
        button: "CustomPlayerThumbSelector_button__JXiFX",
        button_selected: "CustomPlayerThumbSelector_button_selected__5_mwm",
        thumbContent: "CustomPlayerThumbSelector_thumbContent__lAM5O",
        thumbContent_custom: "CustomPlayerThumbSelector_thumbContent_custom__ZcoKb",
        thumbLine: "CustomPlayerThumbSelector_thumbLine__Iv4PY",
        thumbDefault: "CustomPlayerThumbSelector_thumbDefault__3RlO1",
        thumbName: "CustomPlayerThumbSelector_thumbName__SCX2s"
      };
    },
    18433: (e) => {
      e.exports = { root: "RestrictionBlock_root__qzBtp", restrictions: "RestrictionBlock_restrictions__6V1zc" };
    },
    20426: (e) => {
      e.exports = {
        icon: "SettingsListLinkItem_icon__p4P_V",
        root: "SettingsListLinkItem_root__rTPC9",
        container: "SettingsListLinkItem_container__k7bhS",
        linkText: "SettingsListLinkItem_linkText__0PHlQ",
        title: "SettingsListLinkItem_title__duJnL",
        description: "SettingsListLinkItem_description__xWeAD"
      };
    },
    21390: (e, t, o) => {
      "use strict";
      o.d(t, { L: () => d });
      var n, i = o(94377), l = o(61910), r = {
        6699: (e2, t2, o2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let n2 = o2(352), i2 = o2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: o3, throttleTimeout: l2 } = e3, r2 = (0, i2.useRef)(null), [s2, a2] = (0, i2.useState)(!!o3), c2 = (0, i2.useMemo)(
              () => (0, n2.throttle)(() => {
                a2(!o3), r2.current && window.clearTimeout(r2.current), r2.current = window.setTimeout(() => {
                  a2(!!o3);
                }, t3);
              }, l2),
              [t3, o3, l2]
            ), d2 = (0, i2.useCallback)(() => {
              a2(!!o3), r2.current && window.clearTimeout(r2.current);
            }, [o3]);
            return (0, i2.useEffect)(
              () => () => {
                r2.current && window.clearTimeout(r2.current);
              },
              []
            ), { state: s2, handleDebouncedToggle: c2, reset: d2 };
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        352: (e2) => {
          e2.exports = i;
        },
        810: (e2) => {
          e2.exports = n || (n = o.t(l, 2));
        }
      }, s = {};
      function a(e2) {
        var t2 = s[e2];
        if (void 0 !== t2) return t2.exports;
        var o2 = s[e2] = { exports: {} };
        return r[e2](o2, o2.exports, a), o2.exports;
      }
      var c = {};
      (() => {
        Object.defineProperty(c, "__esModule", { value: true }), c.useScroll = void 0;
        let e2 = a(810), t2 = a(361), o2 = a(6699);
        c.useScroll = (n2) => {
          let { onScroll: i2, listenIsScrolling: l2, elementRef: r2 } = n2, { state: s2, handleDebouncedToggle: a2 } = (0, o2.useDebouncedToggle)({ delay: 1e3, throttleTimeout: 100 }), c2 = (0, e2.useCallback)(() => {
            l2 && a2(), null == i2 || i2();
          }, [l2, a2, i2]);
          return (0, e2.useEffect)(() => {
            let e3 = (0, t2.getElementFromRefOrElement)(r2);
            if (null === e3) return;
            let o3 = null != e3 ? e3 : window, n3 = { capture: true, passive: true };
            return o3.addEventListener("scroll", c2, n3), () => o3.removeEventListener("scroll", c2, n3);
          }, [r2, c2]), s2;
        };
      })(), c.__esModule;
      var d = c.useScroll;
    },
    27540: (e) => {
      e.exports = {
        root: "AboutAppModal_root__yBvgU",
        modalHeader: "AboutAppModal_modalHeader__q1NPj",
        modalContent: "AboutAppModal_modalContent__SHO_X",
        list: "AboutAppModal_list__HfB82",
        link: "AboutAppModal_link__i3P3P",
        explicitText: "AboutAppModal_explicitText__29HUD",
        companyText: "AboutAppModal_companyText__yroW0",
        versionText: "AboutAppModal_versionText__iFb8L"
      };
    },
    31622: (e, t, o) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return a;
        }
      });
      let n = o(54486), i = o(61910), l = o(91165);
      function r(e2) {
        return { default: e2 && "default" in e2 ? e2.default : e2 };
      }
      o(98944);
      let s = { loader: () => Promise.resolve(r(() => null)), loading: null, ssr: true }, a = function(e2) {
        let t2 = { ...s, ...e2 }, o2 = (0, i.lazy)(() => t2.loader().then(r)), a2 = t2.loading;
        function c(e3) {
          let r2 = a2 ? (0, n.jsx)(a2, { isLoading: true, pastDelay: true, error: null }) : null, s2 = !t2.ssr || !!t2.loading, c2 = s2 ? i.Suspense : i.Fragment, d = t2.ssr ? (0, n.jsxs)(n.Fragment, { children: [null, (0, n.jsx)(o2, { ...e3 })] }) : (0, n.jsx)(l.BailoutToCSR, { reason: "next/dynamic", children: (0, n.jsx)(o2, { ...e3 }) });
          return (0, n.jsx)(c2, { ...s2 ? { fallback: r2 } : {}, children: d });
        }
        return c.displayName = "LoadableComponent", c;
      };
    },
    33276: (e, t, o) => {
      "use strict";
      o.d(t, { hO: () => m, jr: () => _, jp: () => p, QZ: () => i }), o(77607);
      var n = o(61910);
      let i = (e2, t2, o2) => {
        let i2 = null != o2 && o2;
        return {
          topColorStyle: (0, n.useMemo)(() => {
            if (void 0 === t2) return;
            let o3 = i2 ? 93 : 17, n2 = t2 - o3;
            return {
              "--average-color-background": e2,
              transform: "translateY(".concat(t2 >= o3 ? 0 : n2, "px)"),
              opacity: 1
            };
          }, [t2, i2, e2]),
          headerStyle: (0, n.useMemo)(() => ({ "--average-color-background": e2 }), [e2])
        };
      };
      var l = o(54486), r = o(1365), s = o(28303), a = o(21390), c = o(74125), d = o(80585);
      let u = (e2) => {
        let { element: t2, scrollTop: o2, isMobile: n2 } = e2, i2 = 0.6 * t2.clientHeight;
        return o2 + (n2 ? 60 : 76) >= t2.offsetTop + i2;
      }, m = (0, s.PA)((e2) => {
        let {
          children: t2,
          scrollElement: o2,
          outerTitle: i2 = "",
          headerElement: s2,
          headerThreshold: m2,
          shouldHideHeader: _2
        } = e2, [p2, h] = (0, n.useState)(i2), [f, x] = (0, n.useState)(null), [v, g] = (0, n.useState)(null), [b, j] = (0, n.useState)(null), [C, y] = (0, n.useState)(false), [N, S] = (0, n.useState)(false), [k, M] = (0, n.useState)(false), [w, T] = (0, n.useState)(false), {
          settings: { isMobile: E }
        } = (0, c.Pjs)();
        (0, n.useLayoutEffect)(() => {
          h(i2);
        }, [i2]);
        let P = (0, n.useCallback)(() => {
          let e3 = null != m2 ? m2 : 10, t3 = s2 ? Number(s2.offsetTop) - e3 : e3;
          t3 < 0 && (t3 = 0);
          let n2 = (e4) => {
            M(e4 > t3), _2 && T(e4 > 30), (null == f ? void 0 : f.current) && y(u({ element: null == f ? void 0 : f.current, scrollTop: e4, isMobile: E })), (null == v ? void 0 : v.current) && S(u({ element: null == v ? void 0 : v.current, scrollTop: e4, isMobile: E }));
          };
          E ? n2(window.scrollY) : o2 && n2(o2.scrollTop);
        }, [m2, s2, E, _2, f, v, o2]);
        (0, n.useEffect)(() => {
          E ? 0 === window.scrollY && M(false) : o2 && 0 !== o2.scrollTop || M(false);
        }, [o2, null == o2 ? void 0 : o2.scrollTop, E]);
        let A = (0, n.useMemo)(
          () => E ? { onScroll: (0, r.A)(P, 200) } : { onScroll: (0, r.A)(P, 200), elementRef: o2 },
          [P, o2, E]
        );
        (0, a.L)(A);
        let O = (0, n.useMemo)(
          () => ({
            title: p2,
            setTitle: h,
            titleElement: f,
            scrollElement: E ? null : o2,
            setTitleElement: x,
            childElement: v,
            setChildElement: g,
            child: b,
            setChild: j,
            isScrolledChild: N,
            isScrolledTitle: C,
            isScrolling: k,
            isHeaderHidden: w
          }),
          [p2, C, f, o2, k, E, b, v, N, w]
        );
        return (0, l.jsx)(d.B9.Provider, { value: O, children: t2 });
      }), _ = (e2) => {
        let { children: t2, child: o2, className: i2 } = e2, { setChildElement: r2, setChild: s2 } = (0, n.useContext)(d.B9), a2 = (0, n.useRef)(null);
        return (0, n.useEffect)(() => {
          (null == a2 ? void 0 : a2.current) && r2(a2), o2 && s2(o2);
        }, [a2, o2, r2, s2]), (0, n.useEffect)(
          () => () => {
            s2(null);
          },
          [s2]
        ), (0, l.jsx)("div", { ref: a2, className: i2, children: t2 });
      }, p = (e2) => {
        let { children: t2, title: o2, className: i2 } = e2, { setTitleElement: r2, setTitle: s2 } = (0, n.useContext)(d.B9), a2 = (0, n.useRef)(null);
        return (0, n.useEffect)(() => {
          (null == a2 ? void 0 : a2.current) && r2(a2), o2 && s2(o2);
        }, [a2, o2, r2, s2]), (0, n.useEffect)(
          () => () => {
            s2("");
          },
          [s2]
        ), (0, l.jsx)("div", { ref: a2, className: i2, children: t2 });
      };
    },
    36246: (e) => {
      e.exports = {
        root: "SettingsPage_root__BB4lC",
        scrollableContainer: "SettingsPage_scrollableContainer__qD32i",
        container: "SettingsPage_container__bIwea",
        content: "SettingsPage_content__cR6Ra",
        footer: "SettingsPage_footer__QIqyx"
      };
    },
    36446: (e, t, o) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return i;
        }
      });
      let n = o(45221)._(o(31622));
      function i(e2, t2) {
        var o2;
        let i2 = {};
        "function" == typeof e2 && (i2.loader = e2);
        let l = { ...i2, ...t2 };
        return (0, n.default)({ ...l, modules: null == (o2 = l.loadableGenerated) ? void 0 : o2.modules });
      }
      ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", { value: true }), Object.assign(t.default, t), e.exports = t.default);
    },
    51734: (e) => {
      e.exports = {
        root: "SettingsListToggleItem_root__yEEYT",
        textContainer: "SettingsListToggleItem_textContainer__tRjyt",
        title: "SettingsListToggleItem_title__Xz8_Q",
        description: "SettingsListToggleItem_description__JBOzV"
      };
    },
    57249: (e, t, o) => {
      "use strict";
      e.exports = o.p + "static/media/dotlottie-player.98f80c6ff3eca5ba.wasm";
    },
    58980: (e) => {
      e.exports = { root: "Settings_root__FVVrn", item: "Settings_item__Ksa9h" };
    },
    61609: (e, t, o) => {
      "use strict";
      o.d(t, { l: () => c });
      var n, i = o(61910), l = {
        5881: (e2, t2, o2) => {
          function n2() {
            for (var e3, t3, o3 = 0, n3 = ""; o3 < arguments.length; )
              (e3 = arguments[o3++]) && (t3 = (function e4(t4) {
                var o4, n4, i3 = "";
                if ("string" == typeof t4 || "number" == typeof t4) i3 += t4;
                else if ("object" == typeof t4)
                  if (Array.isArray(t4))
                    for (o4 = 0; o4 < t4.length; o4++) t4[o4] && (n4 = e4(t4[o4])) && (i3 && (i3 += " "), i3 += n4);
                  else for (o4 in t4) t4[o4] && (i3 && (i3 += " "), i3 += o4);
                return i3;
              })(e3)) && (n3 && (n3 += " "), n3 += t3);
            return n3;
          }
          o2.r(t2), o2.d(t2, { clsx: () => n2, default: () => i2 });
          let i2 = n2;
        },
        1920: (e2, t2, o2) => {
          o2.r(t2), o2.d(t2, { default: () => n2 });
          let n2 = {
            contentContainer: "JjlbHZ4FaP9EAcR_1DxF",
            contentContainer_block: "iOlzvyUREgDkthkrx7Sf",
            flexIcon: "WsKeF73pWotx9W1tWdYY",
            root: "cpeagBA1_PblpJn8Xgtv",
            root_withoutBorder: "qU2apWBO1yyEK0lZ3lPO",
            root_radius_xs: "MmZbSs387gu2qrJ1lDWd",
            root_radius_s: "mlcrraysn7mW6xrBXSBF",
            root_radius_m: "dgV08FKVLZKFsucuiryn",
            root_radius_l: "S97_5dtzhpxo_amtfYRg",
            root_radius_xl: "nNBJnDHRlyLTniWosJhk",
            root_radius_xxxl: "zIMibMuH7wcqUoW7KH1B",
            root_radius_round: "uwk3hfWzB2VT7kE13SQk",
            root_size: "IlG7b1K0AD7E7AMx6F5p",
            root_size_default: "C_QGmfTz6UFX93vfPt6Z",
            root_size_xxxs: "eQt33MLDiQ6DRSuLaYEp",
            root_size_xxs: "oR11LfCBVqMbUJiAgknd",
            root_size_xs: "j1jXIVckFgZECecFzZMe",
            root_size_s: "WtFdWDF44egSVM_YiMUX",
            root_size_m: "Y2uqxoU7xa_AZ8FUCVOW",
            root_size_l: "SGYcNjvjmMsXeEVGUV2Z",
            root_icon_left: "kc5CjvU5hT9KEj0iTt3C",
            root_icon_right: "et24Jf7pT_X9Fvc7TznR",
            root_primary: "fXlFz1qMkliFUWOkHo8T",
            root_primary_default: "_eTRQi5ADZCUvUKMZqJU",
            ripple: "spMT3NcRD9Yb0ntNaNct",
            root_primary_outline: "fCUSh2B0Ye9kEvceE8zc",
            root_primary_text: "qlPp6CSQQEMVZPqtqLiQ",
            root_primary_withHover: "KZF6_4K1p_Y_GMIAxaAn",
            root_primary_withHover_default: "rWukOKAJh5Ga7JuIp62L",
            root_primary_withHover_outline: "fdwWCJKgUqml5wNqrRcN",
            root_primary_withHover_text: "IgYbZLnYjW0nMahgpkus",
            root_secondary: "_T4p_w41oaq6L4sztSdw",
            root_secondary_default: "iJVAJMgccD4vj4E4o068",
            root_secondary_outline: "pnM3iSP9keZOELI2oohr",
            root_secondary_text: "UDMYhpDjiAFT3xUx268O",
            root_secondary_withHover: "qUbrkhZIOVrvM0roV1QF",
            root_secondary_withHover_default: "nHWc2sto1C6Gm0Dpw_l0",
            root_secondary_withHover_outline: "i5WuBm5mfG0mflk_1jH_",
            root_secondary_withHover_text: "HbaqudSqu7Q3mv3zMPGr",
            root_plus: "ixLRsIJ2FvXO2k04n_QY",
            root_plus_default: "yRHwHzEGfDgRXGzYJqw2",
            root_plus_outline: "e777irPFmyQFFrURLF_U",
            root_plus_text: "vRqDhvmt3gt8TFp45_Zw",
            root_plus_withHover: "TZif6q3I2RwBEYXwK_iA",
            root_plus_withHover_default: "k3DhvmzpnM_Fb9oFdE4q",
            root_plus_withHover_outline: "RiDWYwGIxqbrUPR699DM",
            root_plus_withHover_text: "hC_mMCzWjkTn2j9xZzGc",
            root_accent: "jqD2jMT6n7F0WKyqwMsn",
            root_accent_default: "bDp0r9MtoYECZ8ObMoCh",
            root_accent_outline: "rXNyGp8NBAw2MUjACZNj",
            root_accent_text: "hmV4ERaXWAJc4uPLZL30",
            root_accent_withHover: "uKuxXu1N4TP5cWaEK5Ke",
            root_accent_withHover_default: "t_hequUaUgAMhFuxizLb",
            root_accent_withHover_outline: "Oy9sPFTxNTo1_E29U4aF",
            root_accent_withHover_text: "LcKRSd3DLoh7k60Oqox8",
            root_withActiveSpinner: "nAGvO87rLs15SJgft6Hh",
            block: "BbCxxIjBGupN28bq2lSP",
            icon: "J9wTKytjOWG73QMoN5WP",
            icon_position_left: "elJfazUBui03YWZgHCbW",
            icon_position_right: "RBoEbyJKP5rEtLsXM1ji",
            icon_withButtonSize: "cE17_kCWJgx8kzQEkeVr",
            spinnerContainer: "STbBDGqYjUEcLuNvhu9w"
          };
        },
        5682: (e2, t2, o2) => {
          o2.r(t2), o2.d(t2, { default: () => n2 });
          let n2 = {
            root: "rqUESGQ8jp3tbDawOzuG",
            root_checked: "GJh5PwV9GyFuKhlG6pQz",
            icon: "aw9IoPC0GuAC7Hmf825u",
            icon_checked: "KC8t9NStVmQ1_VY54KH4"
          };
        },
        9097: (e2, t2) => {
          var o2 = /* @__PURE__ */ Symbol.for("react.transitional.element");
          function n2(e3, t3, n3) {
            var i2 = null;
            if (void 0 !== n3 && (i2 = "" + n3), void 0 !== t3.key && (i2 = "" + t3.key), "key" in t3)
              for (var l2 in n3 = {}, t3) "key" !== l2 && (n3[l2] = t3[l2]);
            else n3 = t3;
            return { $$typeof: o2, type: e3, key: i2, ref: void 0 !== (t3 = n3.ref) ? t3 : null, props: n3 };
          }
          t2.Fragment = /* @__PURE__ */ Symbol.for("react.fragment"), t2.jsx = n2, t2.jsxs = n2;
        },
        4377: (e2, t2, o2) => {
          e2.exports = o2(9097);
        },
        8796: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.createRipple = void 0, t2.createRipple = function(e3, t3, o2) {
            let n2 = null != o2 ? o2 : e3.currentTarget, i2 = document.createElement("span"), l2 = Math.max(n2.clientWidth, n2.clientHeight), r2 = l2 / 2, s2 = n2.getBoundingClientRect(), a2 = 0 === e3.clientX ? Math.round(s2.width / 2) : e3.clientX - s2.left, c2 = 0 === e3.clientY ? Math.round(s2.height / 2) : e3.clientY - s2.top;
            i2.style.width = "".concat(l2, "px"), i2.style.height = "".concat(l2, "px"), i2.style.left = 0 === e3.clientX ? "0px" : "".concat(a2 - r2, "px"), i2.style.top = "".concat(c2 - r2, "px"), i2.classList.add(t3);
            let d = n2.getElementsByClassName(t3)[0];
            d && d.remove(), n2.insertBefore(i2, n2.firstChild);
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        8216: (e2, t2, o2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = t2.createRipple = void 0;
          var n2 = o2(8796);
          Object.defineProperty(t2, "createRipple", {
            enumerable: true,
            get: function() {
              return n2.createRipple;
            }
          });
          var i2 = o2(361);
          Object.defineProperty(t2, "getElementFromRefOrElement", {
            enumerable: true,
            get: function() {
              return i2.getElementFromRefOrElement;
            }
          });
        },
        8119: function(e2, t2, o2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          let i2 = o2(4377), l2 = o2(810), r2 = o2(5881), s2 = o2(8216), a2 = n2(o2(1920)), c2 = (e3) => {
            let {
              forwardRef: t3,
              isBlock: o3,
              iconPosition: n3 = "left",
              children: c3,
              className: d,
              color: u = "secondary",
              flexIcon: m,
              icon: _,
              spinner: p,
              role: h,
              onClick: f,
              radius: x = "m",
              size: v,
              type: g = "button",
              variant: b = "default",
              withRipple: j = true,
              withHover: C = true,
              withBorder: y = false,
              disabled: N,
              iconClassName: S,
              contentContainerClassName: k,
              ...M
            } = e3, w = (0, l2.useId)(), T = !l2.Children.toArray(c3).filter(Boolean).length, E = "left" === n3, P = null, A = (0, l2.isValidElement)(p);
            if (_) {
              var O, z;
              P = (0, l2.cloneElement)(_, {
                className: (0, r2.clsx)(
                  a2.default.icon,
                  {
                    [a2.default["icon_position_".concat(n3)]]: n3 && !T,
                    [a2.default.icon_withButtonSize]: !(null == (O = _.props) ? void 0 : O.size)
                  },
                  null == (z = _.props) ? void 0 : z.className,
                  S
                ),
                key: w
              });
            }
            let L = (0, l2.useMemo)(
              () => A ? (0, i2.jsx)("div", { className: a2.default.spinnerContainer, children: p }) : null,
              [A, p]
            ), R = (0, l2.useCallback)(
              (e4) => {
                A || (j && (0, s2.createRipple)(e4, a2.default.ripple), null == f || f(e4));
              },
              [A, f, j]
            );
            return (0, i2.jsx)("button", {
              ref: t3,
              className: (0, r2.clsx)(
                a2.default.root,
                a2.default["root_".concat(u, "_").concat(b)],
                a2.default["root_radius_".concat(x)],
                a2.default.root_size,
                {
                  [a2.default["root_".concat(u, "_withHover_").concat(b)]]: C && !N && !A,
                  [a2.default["root_size_".concat(v)]]: v,
                  [a2.default.root_withoutBorder]: !y,
                  [a2.default.root_withActiveSpinner]: A,
                  [a2.default.block]: o3,
                  [a2.default.flexIcon]: m,
                  [a2.default.iconOnly]: T,
                  [a2.default.root_icon_left]: _ && !T && E,
                  [a2.default.root_icon_right]: _ && !T && !E
                },
                d
              ),
              type: g,
              role: h,
              onClick: R,
              ...M,
              disabled: N,
              "aria-live": A ? "polite" : "off",
              "aria-busy": A,
              children: _ || A ? (0, i2.jsxs)("span", {
                className: (0, r2.clsx)(
                  a2.default.contentContainer,
                  { [a2.default.contentContainer_block]: o3 },
                  k
                ),
                children: [_ && E && P, !T && c3, _ && !E && P, L]
              }) : c3
            });
          };
          t2.Button = (0, l2.forwardRef)((e3, t3) => (0, i2.jsx)(c2, { forwardRef: t3, ...e3 }));
        },
        5928: (e2, t2, o2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Button = void 0;
          var n2 = o2(8119);
          Object.defineProperty(t2, "Button", {
            enumerable: true,
            get: function() {
              return n2.Button;
            }
          });
        },
        7459: function(e2, t2, o2) {
          var n2 = this && this.__importDefault || function(e3) {
            return e3 && e3.__esModule ? e3 : { default: e3 };
          };
          Object.defineProperty(t2, "__esModule", { value: true }), t2.Toggle = void 0;
          let i2 = o2(4377), l2 = o2(5881), r2 = o2(810), s2 = o2(5928), a2 = n2(o2(5682)), c2 = (e3) => {
            let { isChecked: t3 } = e3;
            return (0, i2.jsx)("div", { className: (0, l2.clsx)(a2.default.icon, { [a2.default.icon_checked]: t3 }) });
          };
          t2.Toggle = (e3) => {
            let { className: t3, isChecked: o3 = false, onChange: n3, "aria-label": d, "aria-describedby": u, ...m } = e3, [_, p] = (0, r2.useState)(o3), h = (0, r2.useCallback)(() => {
              let e4 = !_;
              p(e4), null == n3 || n3(e4);
            }, [_, n3]);
            return (0, r2.useEffect)(() => {
              p(o3);
            }, [o3]), (0, i2.jsx)(s2.Button, {
              className: (0, l2.clsx)(a2.default.root, { [a2.default.root_checked]: _ }, t3),
              radius: "xxxl",
              variant: "default",
              icon: (0, i2.jsx)(c2, { isChecked: _ }),
              withRipple: false,
              onClick: h,
              role: "switch",
              "aria-checked": _,
              "aria-label": d,
              "aria-describedby": u,
              ...m,
              color: _ ? "primary" : "secondary"
            });
          };
        },
        810: (e2) => {
          e2.exports = n || (n = o.t(i, 2));
        }
      }, r = {};
      function s(e2) {
        var t2 = r[e2];
        if (void 0 !== t2) return t2.exports;
        var o2 = r[e2] = { exports: {} };
        return l[e2].call(o2.exports, o2, o2.exports, s), o2.exports;
      }
      s.d = (e2, t2) => {
        for (var o2 in t2) s.o(t2, o2) && !s.o(e2, o2) && Object.defineProperty(e2, o2, { enumerable: true, get: t2[o2] });
      }, s.o = (e2, t2) => Object.prototype.hasOwnProperty.call(e2, t2), s.r = (e2) => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e2, "__esModule", { value: true });
      };
      var a = {};
      (() => {
        Object.defineProperty(a, "X", { value: true }), a.Z = void 0;
        var e2 = s(7459);
        Object.defineProperty(a, "Z", {
          enumerable: true,
          get: function() {
            return e2.Toggle;
          }
        });
      })();
      var c = a.Z;
      a.X;
    },
    64984: (e) => {
      e.exports = {
        root: "ClearMemoryModal_root__gKdij",
        modalHeader: "ClearMemoryModal_modalHeader__veasf",
        modalContent: "ClearMemoryModal_modalContent__b7yHr",
        image: "ClearMemoryModal_image__evvTq",
        description: "ClearMemoryModal_description__ue94L",
        message: "ClearMemoryModal_message__mYQpM"
      };
    },
    65178: (e) => {
      e.exports = {
        icon: "SettingsListButtonItem_icon__WULZ1",
        root: "SettingsListButtonItem_root__3dtV2",
        important: "SettingsListButtonItem_important__AcEon",
        contentContainer: "SettingsListButtonItem_contentContainer__jqoKg",
        content: "SettingsListButtonItem_content___Opuo",
        title: "SettingsListButtonItem_title__npCza",
        description: "SettingsListButtonItem_description__g8_Ba"
      };
    },
    65760: (e, t, o) => {
      "use strict";
      o.d(t, { SettingsPage: () => ei });
      var n = o(54486), i = o(28303), l = o(43426), r = o(47713), s = o(31500), a = o(56231), c = o(97800), d = o(59672), u = o(7032), m = o(74125), _ = o(13384), p = o.n(_), h = o(38974), f = o(57249), x = o(50420), v = o(83645), g = o(61910), b = o(8817), j = o(77881), C = o(49124);
      let y = v.default.default(
        () => Promise.resolve().then(o.bind(o, 38974)).then((e2) => e2.DotLottieWorkerReact),
        { ssr: false }
      );
      {
        let e2 = C.env.USE_CDN_FOR_STATIC ? "https://yastatic-net.ru/s3/music-frontend-static/music/vundefined" : window.location.origin;
        (0, h.setWasmUrl)(new URL(f, e2).href);
      }
      let N = (e2) => {
        let { thumbType: t2 } = e2, [o2, i2] = (0, g.useState)(null);
        return ((0, g.useEffect)(() => {
          let e3 = d.zf[t2];
          e3 && e3().then((e4) => {
            (0, d.Jy)(e4) ? i2(e4) : i2("".concat(window.location.origin).concat(e4));
          });
        }, [t2]), o2) ? (0, n.jsx)(y, { src: o2 }) : null;
      }, S = (0, i.PA)((e2) => {
        let { thumbId: t2, isDefault: o2 = false } = e2, { settings: i2, user: s2, paywall: a2 } = (0, m.Pjs)(), { formatMessage: u2 } = (0, l.A)(), [_2, h2] = (0, g.useState)(false);
        (0, g.useEffect)(() => {
          h2(true);
        }, []);
        let f2 = (0, b.c)((e3) => {
          if (e3.preventDefault(), !s2.hasPlus && t2 !== i2.selectedThumbId) return void a2.openModal();
          i2.setCustomPlayerThumb(t2);
        }), v2 = !!_2 && i2.selectedThumbId === t2;
        if (o2)
          return (0, n.jsxs)(j.$, {
            className: (0, x.$)(p().button, { [p().button_selected]: v2 }),
            radius: "xl",
            onClick: f2,
            withRipple: false,
            "aria-pressed": v2,
            children: [
              (0, n.jsxs)("div", {
                className: p().thumbContent,
                children: [
                  (0, n.jsx)("div", { className: p().thumbLine }),
                  (0, n.jsx)("div", { className: p().thumbDefault })
                ]
              }),
              (0, n.jsx)(c.Caption, {
                variant: "span",
                type: "controls",
                size: "m",
                weight: "medium",
                className: p().thumbName,
                lineClamp: 1,
                children: (0, n.jsx)(r.A, { id: "branded-player.default" })
              })
            ]
          });
        let C2 = (0, d.rI)(u2).get(t2);
        if (!C2) return;
        let y2 = { "--thumb-height": "".concat(C2.thumb.height, "px") };
        return (0, n.jsxs)(j.$, {
          className: (0, x.$)(p().button, { [p().button_selected]: v2 }),
          radius: "xl",
          onClick: f2,
          withRipple: false,
          "aria-pressed": v2,
          children: [
            (0, n.jsx)("div", {
              style: y2,
              className: (0, x.$)(p().thumbContent, p().thumbContent_custom),
              children: (0, n.jsx)(N, { thumbType: t2 })
            }),
            (0, n.jsx)(c.Caption, {
              className: p().thumbName,
              variant: "div",
              size: "m",
              weight: "normal",
              lineClamp: 1,
              children: C2.name
            })
          ]
        });
      }), k = (0, i.PA)(() => {
        let { formatMessage: e2 } = (0, l.A)(), t2 = Array.from((0, d.rI)(e2).keys());
        return (0, n.jsxs)("div", {
          className: p().root,
          children: [
            (0, n.jsx)(c.Caption, {
              className: p().title,
              variant: "div",
              size: "l",
              weight: "bold",
              lineClamp: 1,
              children: (0, n.jsx)(r.A, { id: "branded-player.player-type" })
            }),
            (0, n.jsxs)(u.m, {
              restrictionsClassName: p().thumbsContainer,
              children: [
                (0, n.jsx)(S, { thumbId: m.TZj.DEFAULT, isDefault: true }),
                t2.map((e3) => (0, n.jsx)(S, { thumbId: e3 }, e3))
              ]
            })
          ]
        });
      });
      var M = o(40320), w = o(80585), T = o(32692), E = o(27540), P = o.n(E);
      let A = (0, i.PA)(() => {
        let { formatMessage: e2 } = (0, l.A)(), {
          location: t2,
          modals: { aboutAppModal: o2 }
        } = (0, m.Pjs)(), i2 = (0, m.HFS)(), s2 = (0, m.d79)(), { language: a2 } = (0, m.h6b)();
        return (0, n.jsxs)(T.a, {
          className: P().root,
          headerClassName: P().modalHeader,
          contentClassName: P().modalContent,
          title: e2({ id: "settings.about-app" }),
          open: o2.isOpened,
          onOpenChange: o2.onOpenChange,
          onClose: o2.close,
          size: "fitContent",
          placement: "center",
          overlayColor: "full",
          labelClose: e2({ id: "interface-actions.close" }),
          children: [
            (0, n.jsxs)("ul", {
              className: P().list,
              children: [
                (0, n.jsx)("li", {
                  className: P().item,
                  children: (0, n.jsx)(w.N_, {
                    className: P().link,
                    target: "_blank",
                    href: "https://yandex.".concat(t2.tld, "/support/music/performers-and-copyright-holders.html?lang=").concat(a2),
                    children: (0, n.jsx)(c.Caption, {
                      type: "controls",
                      variant: "span",
                      size: "l",
                      weight: "medium",
                      children: (0, n.jsx)(r.A, { id: "footer.links-copyright-holders" })
                    })
                  })
                }),
                (0, n.jsx)("li", {
                  className: P().item,
                  children: (0, n.jsx)(w.N_, {
                    className: P().link,
                    target: "_blank",
                    href: "https://yandex.".concat(t2.tld, "/legal/music_mobile_agreement?lang=").concat(a2),
                    children: (0, n.jsx)(c.Caption, {
                      type: "controls",
                      variant: "span",
                      size: "l",
                      weight: "medium",
                      children: (0, n.jsx)(r.A, { id: "footer.links-terms" })
                    })
                  })
                }),
                (0, n.jsx)("li", {
                  className: P().item,
                  children: (0, n.jsx)(w.N_, {
                    className: P().link,
                    target: "_blank",
                    href: "https://music.yandex.".concat(t2.tld, "/legal/recommendations/ru/#music"),
                    children: (0, n.jsx)(c.Caption, {
                      type: "controls",
                      variant: "span",
                      size: "l",
                      weight: "medium",
                      children: (0, n.jsx)(r.A, { id: "footer.links-recommendation-rules" })
                    })
                  })
                }),
                (0, n.jsx)("li", {
                  className: P().item,
                  children: (0, n.jsx)(w.N_, {
                    className: P().link,
                    target: "_blank",
                    href: "https://yandex.".concat(t2.tld, "/support/music/index.html?lang=").concat(a2),
                    children: (0, n.jsx)(c.Caption, {
                      type: "controls",
                      variant: "span",
                      size: "l",
                      weight: "medium",
                      children: (0, n.jsx)(r.A, { id: "footer.links-help" })
                    })
                  })
                })
              ]
            }),
            (0, n.jsx)(c.Caption, {
              className: P().explicitText,
              type: "controls",
              variant: "div",
              size: "xs",
              weight: "medium",
              dangerouslySetInnerHTML: { __html: e2({ id: "about-app.explicit-content" }) }
            }),
            (0, n.jsx)(c.Caption, {
              className: P().companyText,
              type: "controls",
              variant: "div",
              size: "xs",
              children: (0, n.jsx)(r.A, { id: "about-app.app-name" })
            }),
            (0, n.jsx)(c.Caption, {
              className: P().versionText,
              type: "controls",
              variant: "div",
              size: "xs",
              children: e2({ id: "desktop.app-version-short" }, { version: i2 })
            }),
            (0, n.jsx)(c.Caption, {
              className: P().versionText,
              type: "controls",
              variant: "div",
              size: "xs",
              children: e2({ id: "desktop.app-revision" }, { revision: s2 })
            })
          ]
        });
      });
      var O = o(58360), z = o(64984), L = o.n(z);
      let R = { src: "/_next/static/media/clearMemory.33a5df30.png" }, I = (0, i.PA)(() => {
        let { formatMessage: e2 } = (0, l.A)(), {
          modals: { clearMemoryModal: t2 }
        } = (0, m.Pjs)(), { notify: o2 } = (0, m.lkh)(), i2 = (0, m.jRO)(), s2 = (0, g.useCallback)(() => {
          i2.clearAll().then(() => {
            t2.close(), o2(
              (0, n.jsx)(w.$W, {
                message: (0, n.jsx)(c.Caption, {
                  className: L().message,
                  variant: "div",
                  type: "controls",
                  size: "m",
                  children: (0, n.jsx)(r.A, { id: "offline.memory-cleared" })
                })
              }),
              { containerId: m.uQT.INFO }
            );
          });
        }, [t2, o2, i2]);
        return (0, n.jsxs)(T.a, {
          className: L().root,
          headerClassName: L().modalHeader,
          contentClassName: L().modalContent,
          open: t2.isOpened,
          onOpenChange: t2.onOpenChange,
          onClose: t2.close,
          size: "fitContent",
          placement: "center",
          labelClose: e2({ id: "interface-actions.close" }),
          children: [
            (0, n.jsx)(O.Image, { src: R.src, className: L().image, fit: "contain", "aria-hidden": true }),
            (0, n.jsx)(c.Caption, {
              className: L().description,
              type: "text",
              variant: "div",
              size: "l",
              weight: "normal",
              children: (0, n.jsx)(r.A, { id: "offline.clear-memory-description" })
            }),
            (0, n.jsx)(j.$, {
              color: "primary",
              radius: "xxxl",
              size: "default",
              onClick: s2,
              children: (0, n.jsx)(r.A, { id: "interface-actions.clear" })
            })
          ]
        });
      });
      var F = o(5956), B = o(65178), H = o.n(B);
      let D = (e2) => {
        let { title: t2, description: o2, onClick: i2, descriptionProps: l2, ...r2 } = e2;
        return (0, n.jsx)(j.$, {
          className: (0, x.$)(H().root, H().important),
          contentContainerClassName: H().contentContainer,
          icon: (0, n.jsx)(F.Icon, { className: H().icon, size: "xs", variant: "arrowRight" }),
          iconPosition: "right",
          onClick: i2,
          isBlock: true,
          withRipple: false,
          withHover: false,
          variant: "text",
          size: "xs",
          ...r2,
          children: (0, n.jsxs)("div", {
            className: H().content,
            children: [
              (0, n.jsx)(c.Caption, {
                className: H().title,
                variant: "div",
                size: "l",
                weight: "bold",
                lineClamp: 1,
                children: t2
              }),
              o2 && (0, n.jsx)(c.Caption, {
                variant: "div",
                type: "text",
                size: "xs",
                weight: "medium",
                className: H().description,
                ...l2,
                children: o2
              })
            ]
          })
        });
      };
      var W = o(20426), U = o.n(W);
      let q = (e2) => {
        let { link: t2, title: o2, description: i2, target: l2 } = e2;
        return (0, n.jsxs)(w.N_, {
          className: U().root,
          containerClassName: U().container,
          textClassName: U().linkText,
          icon: (0, n.jsx)(F.Icon, { className: U().icon, size: "xs", variant: "arrowRight" }),
          iconPosition: "right",
          href: t2,
          ...l2 ? { target: l2 } : {},
          children: [
            (0, n.jsx)(c.Caption, {
              className: U().title,
              variant: "div",
              size: "l",
              weight: "bold",
              lineClamp: 1,
              children: o2
            }),
            i2 && (0, n.jsx)(c.Caption, {
              variant: "div",
              type: "text",
              size: "xs",
              weight: "medium",
              className: U().description,
              children: i2
            })
          ]
        });
      };
      var Z = o(61609), Y = o(51734), V = o.n(Y);
      let G = (e2) => {
        let { title: t2, onChange: o2, isChecked: i2, description: l2, dataTestId: r2 } = e2, s2 = (0, g.useId)();
        return (0, n.jsxs)("div", {
          className: V().root,
          children: [
            (0, n.jsxs)("div", {
              className: V().textContainer,
              children: [
                (0, n.jsx)(c.Caption, {
                  className: V().title,
                  id: s2,
                  variant: "div",
                  size: "l",
                  weight: "bold",
                  lineClamp: 1,
                  "aria-hidden": true,
                  children: t2
                }),
                l2 && (0, n.jsx)(c.Caption, {
                  variant: "div",
                  type: "text",
                  size: "xs",
                  weight: "medium",
                  className: V().description,
                  children: l2
                })
              ]
            }),
            (0, n.jsx)(Z.l, { isChecked: i2, "aria-describedby": s2, onChange: o2, ...r2 })
          ]
        });
      };
      var Q = o(98190), K = o.n(Q);
      let J = (0, i.PA)(() => {
        let {
          modals: { shortcutsModal: e2 }
        } = (0, m.Pjs)(), { formatMessage: t2 } = (0, l.A)(), o2 = (0, g.useMemo)(() => {
          let e3 = (0, n.jsx)(
            c.Caption,
            {
              className: K().text,
              variant: "div",
              type: "text",
              size: "xs",
              weight: "normal",
              children: (0, n.jsx)(r.A, { id: "shortcuts.or" })
            },
            "or"
          );
          return m.bNV.map((t3) => {
            let { shortcutsAction: o3, formattedMessage: i2 } = t3, l2 = m.MHd[o3].map(
              (e4, t4) => (0, n.jsx)(
                "div",
                {
                  className: K().button,
                  children: (0, n.jsx)(c.Caption, {
                    variant: "div",
                    type: "text",
                    size: "xs",
                    weight: "normal",
                    children: e4
                  })
                },
                t4
              )
            );
            return l2.length > 1 && l2.splice(1, 0, e3), (0, n.jsx)(
              "li",
              {
                children: (0, n.jsxs)("div", {
                  className: K().content,
                  children: [
                    (0, n.jsx)(c.Caption, {
                      className: K().text,
                      variant: "div",
                      type: "text",
                      size: "xs",
                      weight: "normal",
                      children: i2
                    }),
                    (0, n.jsx)("div", { className: K().buttons, children: l2 })
                  ]
                })
              },
              o3
            );
          });
        }, []);
        return (0, n.jsx)(T.a, {
          className: K().root,
          headerClassName: K().modalHeader,
          contentClassName: K().modalContent,
          title: t2({ id: "settings.shortcuts" }),
          open: e2.isOpened,
          onOpenChange: e2.onOpenChange,
          onClose: e2.close,
          size: "fitContent",
          placement: "center",
          overlayColor: "full",
          labelClose: t2({ id: "interface-actions.close" }),
          children: (0, n.jsx)("ul", { className: K().list, children: o2 })
        });
      });
      var X = o(58980), $ = o.n(X);
      let ee = (0, i.PA)(() => {
        let e2 = (0, m.HFS)(), t2 = (0, m.NFA)().get(m.ooW), {
          modals: { shortcutsModal: o2, aboutAppModal: i2, clearMemoryModal: r2 },
          experiments: a2,
          wizard: c2,
          user: d2,
          slam: u2,
          settings: _2,
          sonataState: p2
        } = (0, m.Pjs)(), h2 = (0, M.Sq)(), { notify: f2 } = (0, m.lkh)(), { formatMessage: x2 } = (0, l.A)(), v2 = (() => {
          let e3 = (0, m.NFA)().get(m.twC), t3 = (0, m._lF)(e3.oldWebHost), { language: o3 } = (0, m.h6b)();
          return "https://".concat(t3, "/newimport?lang=").concat(o3);
        })(), b2 = (0, m.gQL)(), j2 = h2.isAvailable && !_2.isMobile, C2 = a2.checkExperiment(m.zal.WebNextCrossMediaPlayer, "on"), y2 = d2.hasPlus, N2 = a2.checkExperiment(m.zal.WebNextLiteVersion, "on") && _2.isLiteVersionModeAvailableForToggle && true, S2 = a2.checkExperiment(m.zal.WebNextCustomThumb, "on") && !_2.isMobile, T2 = h2.isEnabled ? x2({ id: "equalizer.enabled" }) : x2({ id: "equalizer.disabled" }), E2 = (0, g.useMemo)(() => x2({ id: "desktop.app-version-short" }, { version: e2 }), [true, x2, e2]), P2 = (0, g.useCallback)(
          async (e3) => {
            await d2.setSettings({ isChildModeEnabled: e3 }) === m.FlZ.ERROR && f2((0, n.jsx)(w.hT, { error: x2({ id: "settings.failed-to-change-child-mode" }) }), {
              containerId: m.uQT.ERROR
            });
          },
          [d2, x2, f2]
        ), O2 = (0, g.useCallback)(
          (e3) => {
            u2.setOfflineMode(e3);
          },
          [u2]
        ), z2 = (0, g.useCallback)(() => {
          r2.open();
        }, [r2]), L2 = (0, g.useCallback)(
          (e3) => {
            if (e3) return void _2.setLiteVersionMode(m.wv5.ENABLED, true);
            _2.setLiteVersionMode(m.wv5.DISABLED, true);
          },
          [_2]
        );
        (0, g.useLayoutEffect)(() => {
          let e3 = t2.get(m.cYZ.CrossFadeMode);
          "boolean" == typeof e3 && p2.setCrossFadeMode(e3);
        }, [p2, t2]);
        let R2 = (0, g.useCallback)(
          (e3) => {
            p2.setCrossFadeMode(e3), b2 && (b2.isCrossfadeEnabled.value = e3);
          },
          [p2, b2]
        );
        return (0, n.jsxs)("ul", {
          className: $().root,
          ...(0, s.Am)(s.e8.settings.SETTINGS_LIST),
          children: [
            y2 && (0, n.jsx)("li", {
              className: $().item,
              children: (0, n.jsx)(G, {
                title: x2({ id: "offline.offline-mode" }),
                description: x2({ id: "offline.offline-mode-description" }),
                onChange: O2,
                isChecked: u2.isOfflineModeEnabled
              })
            }),
            y2 && (0, n.jsxs)("li", {
              className: $().item,
              children: [(0, n.jsx)(D, { title: x2({ id: "offline.clear-memory" }), onClick: z2 }), (0, n.jsx)(I, {})]
            }),
            N2 && (0, n.jsx)("li", {
              className: $().item,
              children: (0, n.jsx)(G, {
                title: x2({ id: "lite-version.title" }),
                description: x2({ id: "lite-version.description" }),
                onChange: L2,
                isChecked: _2.isLiteVersionModeEnabled
              })
            }),
            j2 && (0, n.jsxs)("li", {
              className: $().item,
              children: [
                (0, n.jsx)(D, {
                  title: x2({ id: "equalizer.title" }),
                  description: T2,
                  onClick: h2.modal.open,
                  descriptionProps: (0, s.Am)(s.e8.settings.SETTINGS_EQUALIZER_BUTTON_DESCRIPTION),
                  ...(0, s.Am)(s.e8.settings.SETTINGS_EQUALIZER_BUTTON)
                }),
                (0, n.jsx)(M.MZ, {})
              ]
            }),
            C2 && (0, n.jsx)("li", {
              className: $().item,
              children: (0, n.jsx)(G, {
                title: x2({ id: "settings.crossfade" }),
                onChange: R2,
                isChecked: p2.isCrossFadeEnabled
              })
            }),
            (0, n.jsx)(w.aQ, {
              fallback: (0, n.jsx)("li", {
                className: $().item,
                children: (0, n.jsx)(D, {
                  title: x2({ id: "settings.preferences" }),
                  description: x2({ id: "settings.preferences-description" }),
                  onClick: c2.modal.open
                })
              })
            }),
            (0, n.jsx)(w.aQ, {
              fallback: (0, n.jsx)("li", {
                className: $().item,
                children: (0, n.jsx)(q, {
                  title: x2({ id: "settings.import-media" }),
                  description: x2({ id: "settings.import-media-description" }),
                  link: v2
                })
              })
            }),
            (0, n.jsx)(w.aQ, {
              fallback: !a2.checkExperiment(m.zal.WebNextDisableKids, "on") && (0, n.jsx)("li", {
                className: $().item,
                children: (0, n.jsx)(G, {
                  title: x2({ id: "settings.show-child-section" }),
                  onChange: P2,
                  isChecked: d2.settings.isChildModeEnabled,
                  dataTestId: (0, s.Am)(s.e8.settings.SETTINGS_KIDS_BUTTON)
                })
              })
            }),
            (0, n.jsxs)("li", {
              className: $().item,
              children: [(0, n.jsx)(D, { title: x2({ id: "settings.shortcuts" }), onClick: o2.open }), (0, n.jsx)(J, {})]
            }),
            S2 && (0, n.jsx)("li", { className: $().item, children: (0, n.jsx)(k, {}) }),
            E2 && (0, n.jsxs)("li", {
              className: $().item,
              children: [
                (0, n.jsx)(D, { title: x2({ id: "settings.about-app" }), description: E2, onClick: i2.open }),
                (0, n.jsx)(A, {})
              ]
            })
          ]
        });
      });
      var et = o(33276), eo = o(36246), en = o.n(eo);
      let ei = (0, i.PA)(() => {
        let { formatMessage: e2 } = (0, l.A)(), { contentScrollRef: t2, setContentScrollRef: o2 } = (0, m.gKY)(), i2 = (0, m.W6M)();
        return (0, n.jsxs)(et.hO, {
          scrollElement: t2,
          outerTitle: e2({ id: "page.settings" }),
          children: [
            (0, n.jsx)(w.Y9, {
              variant: w.Vw.TEXT,
              withForwardControl: false,
              withBackwardControl: i2.canBack,
              children: (0, n.jsx)(c.Heading, {
                variant: "h2",
                weight: "bold",
                size: "xl",
                lineClamp: 1,
                children: (0, n.jsx)(r.A, { id: "page.settings" })
              })
            }),
            (0, n.jsx)(a.N, {
              ref: o2,
              className: en().root,
              containerClassName: en().scrollableContainer,
              ...(0, s.Am)(s.Xk.settings.SETTINGS_PAGE),
              children: (0, n.jsxs)("div", {
                className: en().container,
                children: [
                  (0, n.jsx)("div", { className: en().content, children: (0, n.jsx)(ee, {}) }),
                  (0, n.jsx)(w.A, { children: (0, n.jsx)(w.wi, { className: en().footer }) })
                ]
              })
            })
          ]
        });
      });
    },
    83645: (e, t, o) => {
      "use strict";
      o.d(t, { default: () => i.a });
      var n = o(36446), i = o.n(n);
    },
    87290: (e, t, o) => {
      Promise.resolve().then(o.bind(o, 65760));
    },
    91165: (e, t, o) => {
      "use strict";
      function n(e2) {
        let { reason: t2, children: o2 } = e2;
        return o2;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "BailoutToCSR", {
        enumerable: true,
        get: function() {
          return n;
        }
      }), o(39201);
    },
    98190: (e) => {
      e.exports = {
        root: "ShortcutsModal_root__ro7m4",
        modalHeader: "ShortcutsModal_modalHeader__IYJ9m",
        modalContent: "ShortcutsModal_modalContent__SCpYX",
        list: "ShortcutsModal_list__eS4ox",
        text: "ShortcutsModal_text__5JJ0j",
        content: "ShortcutsModal_content__Li9Ip",
        buttons: "ShortcutsModal_buttons__o_xlC",
        button: "ShortcutsModal_button__cTIee"
      };
    },
    98944: (e, t, o) => {
      "use strict";
      function n(e2) {
        let { moduleIds: t2 } = e2;
        return null;
      }
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "PreloadChunks", {
        enumerable: true,
        get: function() {
          return n;
        }
      }), o(54486), o(92803), o(14367), o(32038);
    }
  },
  (e) => {
    e.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1579,
        1311,
        7764,
        6706,
        5201,
        5148,
        3005,
        4125,
        585,
        6433,
        6231,
        1656,
        3143,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 87290)
    ), _N_E = e.O();
  }
]);
