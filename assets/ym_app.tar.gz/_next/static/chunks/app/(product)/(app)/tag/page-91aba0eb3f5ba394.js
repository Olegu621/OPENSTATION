(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4905],
  {
    9089: (e, t, n) => {
      "use strict";
      n.d(t, { oN: () => u.TagPage, vV: () => i });
      var o = n(93064), a = n(14287), r = n(13611), s = n(74125), l = n(26433);
      let i = o.gK.model("TagPage", {
        title: o.gK.maybe(o.gK.string),
        errorStatusCode: o.gK.maybeNull(o.gK.number),
        tagLoadingState: o.gK.enumeration(Object.values(s.GuX)),
        playlistsData: o.gK.array(o.gK.model({ uid: o.gK.number, kind: o.gK.number })),
        pagesLoader: (0, l.Ij)(r.$o)
      }).views((e2) => {
        let t2 = {
          get isNeededToLoad() {
            return e2.tagLoadingState === s.GuX.IDLE;
          },
          get isResolved() {
            return e2.tagLoadingState === s.GuX.RESOLVE;
          },
          get isNotFound() {
            let t3 = e2.pagesLoader.isEmpty;
            return e2.tagLoadingState === s.GuX.REJECT && (e2.errorStatusCode === a.X1.NOT_FOUND || e2.errorStatusCode === a.X1.BAD_REQUEST) || t3;
          },
          get isSomethingWrong() {
            return e2.tagLoadingState === s.GuX.REJECT && !t2.isNotFound;
          },
          get playlists() {
            var n2;
            return null != (n2 = e2.pagesLoader.items) ? n2 : [];
          }
        };
        return t2;
      }).actions((e2) => {
        let t2 = {
          getPlaylists: (0, o.L3)(function* (t3) {
            let { page: n2 = 0, pageSize: l2 = 20 } = t3, { playlistsResource: i2, modelActionsLogger: u2 } = (0, o._$)(e2);
            if (e2.tagLoadingState === s.GuX.RESOLVE && e2.pagesLoader.isPageNeedToLoad(n2))
              try {
                e2.pagesLoader.setPageState(n2, s.GuX.PENDING);
                let t4 = n2 * l2, o2 = e2.playlistsData.slice(t4, t4 + l2), a2 = yield i2.getPlaylists({
                  playlistIds: o2.map((e3) => "".concat(e3.uid, ":").concat(e3.kind)),
                  resumeStream: false
                }), u3 = { page: n2, perPage: l2, total: e2.playlistsData.length }, d = a2.playlists.map(r.jX);
                e2.pagesLoader.setItems(d, { page: n2, pager: u3 });
              } catch (t4) {
                u2.error(t4), e2.pagesLoader.setItems(null, { responseStatus: s.FlZ.ERROR, page: n2 }), t4 instanceof a.GX && (t4.statusCode === a.X1.NOT_FOUND || t4.statusCode === a.X1.BAD_REQUEST) && (e2.errorStatusCode = a.X1.NOT_FOUND);
              }
          }),
          reset() {
            e2.pagesLoader.reset(), e2.tagLoadingState = s.GuX.IDLE, e2.title = void 0, e2.playlistsData = (0, o.wg)([]), e2.errorStatusCode = null;
          },
          getTag: (0, o.L3)(function* (n2) {
            let { id: r2, page: l2 = 0, pageSize: i2 = 20 } = n2, { tagResource: u2, modelActionsLogger: d } = (0, o._$)(e2);
            if (e2.tagLoadingState !== s.GuX.PENDING)
              try {
                var c;
                e2.tagLoadingState = s.GuX.PENDING;
                let n3 = yield u2.getPlaylistIds({ id: r2 });
                e2.title = null == (c = n3.tag) ? void 0 : c.name, e2.playlistsData = (0, o.wg)(n3.ids.map((e3) => ({ uid: e3.uid, kind: e3.kind }))), e2.tagLoadingState !== s.GuX.IDLE && (e2.tagLoadingState = s.GuX.RESOLVE), yield t2.getPlaylists({ page: l2, pageSize: i2 });
              } catch (t3) {
                d.error(t3), t3 instanceof a.GX && (t3.statusCode === a.X1.NOT_FOUND || t3.statusCode === a.X1.BAD_REQUEST) && (e2.errorStatusCode = a.X1.NOT_FOUND), e2.tagLoadingState !== s.GuX.IDLE && (e2.tagLoadingState = s.GuX.REJECT);
              }
          })
        };
        return t2;
      });
      n(94716);
      var u = n(56440);
    },
    21390: (e, t, n) => {
      "use strict";
      n.d(t, { L: () => d });
      var o, a = n(94377), r = n(61910), s = {
        6699: (e2, t2, n2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.useDebouncedToggle = void 0;
          let o2 = n2(352), a2 = n2(810);
          t2.useDebouncedToggle = (e3) => {
            let { delay: t3, initialState: n3, throttleTimeout: r2 } = e3, s2 = (0, a2.useRef)(null), [l2, i2] = (0, a2.useState)(!!n3), u2 = (0, a2.useMemo)(
              () => (0, o2.throttle)(() => {
                i2(!n3), s2.current && window.clearTimeout(s2.current), s2.current = window.setTimeout(() => {
                  i2(!!n3);
                }, t3);
              }, r2),
              [t3, n3, r2]
            ), d2 = (0, a2.useCallback)(() => {
              i2(!!n3), s2.current && window.clearTimeout(s2.current);
            }, [n3]);
            return (0, a2.useEffect)(
              () => () => {
                s2.current && window.clearTimeout(s2.current);
              },
              []
            ), { state: l2, handleDebouncedToggle: u2, reset: d2 };
          };
        },
        361: (e2, t2) => {
          Object.defineProperty(t2, "__esModule", { value: true }), t2.getElementFromRefOrElement = void 0, t2.getElementFromRefOrElement = (e3) => {
            if (void 0 !== e3) {
              if (null === e3 || e3 instanceof HTMLElement) return e3;
              if (null === e3.current || e3.current instanceof HTMLElement) return e3.current;
            }
          };
        },
        352: (e2) => {
          e2.exports = a;
        },
        810: (e2) => {
          e2.exports = o || (o = n.t(r, 2));
        }
      }, l = {};
      function i(e2) {
        var t2 = l[e2];
        if (void 0 !== t2) return t2.exports;
        var n2 = l[e2] = { exports: {} };
        return s[e2](n2, n2.exports, i), n2.exports;
      }
      var u = {};
      (() => {
        Object.defineProperty(u, "__esModule", { value: true }), u.useScroll = void 0;
        let e2 = i(810), t2 = i(361), n2 = i(6699);
        u.useScroll = (o2) => {
          let { onScroll: a2, listenIsScrolling: r2, elementRef: s2 } = o2, { state: l2, handleDebouncedToggle: i2 } = (0, n2.useDebouncedToggle)({ delay: 1e3, throttleTimeout: 100 }), u2 = (0, e2.useCallback)(() => {
            r2 && i2(), null == a2 || a2();
          }, [r2, i2, a2]);
          return (0, e2.useEffect)(() => {
            let e3 = (0, t2.getElementFromRefOrElement)(s2);
            if (null === e3) return;
            let n3 = null != e3 ? e3 : window, o3 = { capture: true, passive: true };
            return n3.addEventListener("scroll", u2, o3), () => n3.removeEventListener("scroll", u2, o3);
          }, [s2, u2]), l2;
        };
      })(), u.__esModule;
      var d = u.useScroll;
    },
    25522: (e) => {
      e.exports = {
        root: "TagPage_root__EWN9A",
        scrollContainer: "TagPage_scrollContainer__lvG_1",
        important: "TagPage_important__Jq37E",
        content: "TagPage_content__rUC_l",
        footer: "TagPage_footer__W0mZr",
        item: "TagPage_item__X_lW7"
      };
    },
    33276: (e, t, n) => {
      "use strict";
      n.d(t, { hO: () => g, jr: () => m, jp: () => _, QZ: () => a }), n(77607);
      var o = n(61910);
      let a = (e2, t2, n2) => {
        let a2 = null != n2 && n2;
        return {
          topColorStyle: (0, o.useMemo)(() => {
            if (void 0 === t2) return;
            let n3 = a2 ? 93 : 17, o2 = t2 - n3;
            return {
              "--average-color-background": e2,
              transform: "translateY(".concat(t2 >= n3 ? 0 : o2, "px)"),
              opacity: 1
            };
          }, [t2, a2, e2]),
          headerStyle: (0, o.useMemo)(() => ({ "--average-color-background": e2 }), [e2])
        };
      };
      var r = n(54486), s = n(1365), l = n(28303), i = n(21390), u = n(74125), d = n(80585);
      let c = (e2) => {
        let { element: t2, scrollTop: n2, isMobile: o2 } = e2, a2 = 0.6 * t2.clientHeight;
        return n2 + (o2 ? 60 : 76) >= t2.offsetTop + a2;
      }, g = (0, l.PA)((e2) => {
        let {
          children: t2,
          scrollElement: n2,
          outerTitle: a2 = "",
          headerElement: l2,
          headerThreshold: g2,
          shouldHideHeader: m2
        } = e2, [_2, p] = (0, o.useState)(a2), [v, x] = (0, o.useState)(null), [h, N] = (0, o.useState)(null), [f, S] = (0, o.useState)(null), [E, L] = (0, o.useState)(false), [y, j] = (0, o.useState)(false), [C, T] = (0, o.useState)(false), [w, b] = (0, o.useState)(false), {
          settings: { isMobile: k }
        } = (0, u.Pjs)();
        (0, o.useLayoutEffect)(() => {
          p(a2);
        }, [a2]);
        let F = (0, o.useCallback)(() => {
          let e3 = null != g2 ? g2 : 10, t3 = l2 ? Number(l2.offsetTop) - e3 : e3;
          t3 < 0 && (t3 = 0);
          let o2 = (e4) => {
            T(e4 > t3), m2 && b(e4 > 30), (null == v ? void 0 : v.current) && L(c({ element: null == v ? void 0 : v.current, scrollTop: e4, isMobile: k })), (null == h ? void 0 : h.current) && j(c({ element: null == h ? void 0 : h.current, scrollTop: e4, isMobile: k }));
          };
          k ? o2(window.scrollY) : n2 && o2(n2.scrollTop);
        }, [g2, l2, k, m2, v, h, n2]);
        (0, o.useEffect)(() => {
          k ? 0 === window.scrollY && T(false) : n2 && 0 !== n2.scrollTop || T(false);
        }, [n2, null == n2 ? void 0 : n2.scrollTop, k]);
        let P = (0, o.useMemo)(
          () => k ? { onScroll: (0, s.A)(F, 200) } : { onScroll: (0, s.A)(F, 200), elementRef: n2 },
          [F, n2, k]
        );
        (0, i.L)(P);
        let W = (0, o.useMemo)(
          () => ({
            title: _2,
            setTitle: p,
            titleElement: v,
            scrollElement: k ? null : n2,
            setTitleElement: x,
            childElement: h,
            setChildElement: N,
            child: f,
            setChild: S,
            isScrolledChild: y,
            isScrolledTitle: E,
            isScrolling: C,
            isHeaderHidden: w
          }),
          [_2, E, v, n2, C, k, f, h, y, w]
        );
        return (0, r.jsx)(d.B9.Provider, { value: W, children: t2 });
      }), m = (e2) => {
        let { children: t2, child: n2, className: a2 } = e2, { setChildElement: s2, setChild: l2 } = (0, o.useContext)(d.B9), i2 = (0, o.useRef)(null);
        return (0, o.useEffect)(() => {
          (null == i2 ? void 0 : i2.current) && s2(i2), n2 && l2(n2);
        }, [i2, n2, s2, l2]), (0, o.useEffect)(
          () => () => {
            l2(null);
          },
          [l2]
        ), (0, r.jsx)("div", { ref: i2, className: a2, children: t2 });
      }, _ = (e2) => {
        let { children: t2, title: n2, className: a2 } = e2, { setTitleElement: s2, setTitle: l2 } = (0, o.useContext)(d.B9), i2 = (0, o.useRef)(null);
        return (0, o.useEffect)(() => {
          (null == i2 ? void 0 : i2.current) && s2(i2), n2 && l2(n2);
        }, [i2, n2, s2, l2]), (0, o.useEffect)(
          () => () => {
            l2("");
          },
          [l2]
        ), (0, r.jsx)("div", { ref: i2, className: a2, children: t2 });
      };
    },
    42421: (e, t, n) => {
      "use strict";
      n.d(t, { M: () => o.NotFound });
      var o = n(65034);
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    47601: (e, t, n) => {
      "use strict";
      n.r(t), n.d(t, { default: () => s });
      var o = n(54486), a = n(97396), r = n(9089);
      let s = () => {
        let e2 = (0, a.useSearchParams)().get("tagId");
        return e2 || (0, a.notFound)(), (0, o.jsx)(r.oN, { tagId: e2 });
      };
    },
    48597: (e, t, n) => {
      Promise.resolve().then(n.bind(n, 47601));
    },
    56440: (e, t, n) => {
      "use strict";
      n.d(t, { TagPage: () => x });
      var o = n(54486), a = n(50420), r = n(28303), s = n(97396), l = n(61910), i = n(43426), u = n(97800), d = n(82644), c = n(33276), g = n(83909), m = n(74125), _ = n(80585), p = n(25522), v = n.n(p);
      let x = (0, r.PA)((e2) => {
        var t2, n2, r2;
        let { tagId: p2 } = e2, {
          tag: x2,
          settings: { isMobile: h }
        } = (0, m.Pjs)(), { formatMessage: N } = (0, i.A)(), { contentScrollRef: f, setContentScrollRef: S } = (0, m.gKY)(), E = (0, m.W6M)();
        p2 || (0, s.notFound)();
        let L = (0, l.useCallback)(
          (e3) => {
            x2.getPlaylists({ page: e3, pageSize: 20 });
          },
          [x2]
        );
        x2.isNotFound && (0, s.notFound)(), (0, l.useEffect)(
          () => () => {
            x2.reset();
          },
          [x2]
        );
        let y = (0, l.useMemo)(
          () => ({ Footer: () => (0, o.jsx)(_.A, { children: (0, o.jsx)(_.wi, { className: v().footer }) }) }),
          []
        );
        return ((0, m.Jzs)(x2.isResolved), (0, m.XcE)(x2.pagesLoader, L), x2.isNeededToLoad && (0, l.use)(x2.getTag({ id: p2, page: 0, pageSize: 20 })), x2.isSomethingWrong) ? (0, o.jsx)(d.w, {}) : (0, o.jsx)(m.nVz, {
          pageId: m._Q$.TAG,
          children: (0, o.jsx)(c.hO, {
            scrollElement: f,
            outerTitle: x2.title,
            children: (0, o.jsxs)("div", {
              className: v().root,
              children: [
                (0, o.jsx)(_.Y9, {
                  variant: _.Vw.TEXT,
                  withForwardControl: false,
                  withBackwardControl: E.canBack,
                  children: (0, o.jsx)(u.Heading, {
                    variant: "h2",
                    weight: "bold",
                    size: "xl",
                    lineClamp: 1,
                    children: x2.title
                  })
                }),
                (0, o.jsx)(_.$$, {
                  className: (0, a.$)(v().scrollContainer, v().important),
                  customComponents: y,
                  itemContentCallback: (e3) => {
                    let t3 = x2.playlists[e3], n3 = N(
                      { id: "loading-messages.entity-is-loading" },
                      { entityName: N({ id: "entity-names.playlist" }) }
                    );
                    return t3 ? (0, o.jsx)(g.B6, { playlist: t3, contentLinesCount: 3 }, t3.key) : (0, o.jsx)(_.Vt, { "aria-label": n3 });
                  },
                  totalCount: null != (n2 = null == x2 || null == (t2 = x2.pagesLoader.pager) ? void 0 : t2.total) ? n2 : 0,
                  onGetDataByPage: L,
                  pageSize: 20,
                  totalRequests: null != (r2 = null == x2 ? void 0 : x2.pagesLoader.requestsCount) ? r2 : 0,
                  listClassName: v().content,
                  itemClassName: v().item,
                  handleRef: S,
                  context: { listAriaLabel: N({ id: "mixes.albums-list" }, { genreName: x2.title || "" }) },
                  isMobileLayout: h,
                  useWindowScroll: h
                })
              ]
            })
          })
        });
      });
    },
    63708: (e) => {
      e.exports = {
        root: "SomethingWentWrong_root__d77VJ",
        content: "SomethingWentWrong_content__8_YkJ",
        content_shrink: "SomethingWentWrong_content_shrink__GOR_7",
        navigation: "SomethingWentWrong_navigation__a8eMG",
        navigation_desktop: "SomethingWentWrong_navigation_desktop__WGGBX",
        icon: "SomethingWentWrong_icon__f15_y",
        title: "SomethingWentWrong_title__Kn89B",
        important: "SomethingWentWrong_important__namIb",
        text: "SomethingWentWrong_text__KEfGc",
        button: "SomethingWentWrong_button__dmh7t"
      };
    },
    65034: (e, t, n) => {
      "use strict";
      n.d(t, { NotFound: () => p });
      var o = n(54486), a = n(50420), r = n(28303), s = n(47713), l = n(77881), i = n(5956), u = n(97800), d = n(74125), c = n(80585), g = n(61910), m = n(46215), _ = n.n(m);
      let p = (0, r.PA)((e2) => {
        let { className: t2, title: n2, description: r2, iconVariant: m2 = "musicLogo", iconClassName: p2, iconSize: v } = e2, { contentRef: x } = (0, d.gKY)(), h = (0, d.ZpR)(d.Zyd.main.href);
        (0, d.LZB)();
        let { handleNavigateToMain: N } = (0, d.D5F)(h);
        return (0, d.NBO)(true), !(function() {
          let { location: e3 } = (0, d.Pjs)();
          (0, g.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, o.jsxs)("div", {
          className: (0, a.$)(_().root, { [_().root_desktop]: !x }, t2),
          children: [
            (0, o.jsx)(c.Lh, { withBackwardFallback: "/", className: _().navigation, withForwardControl: false }),
            (0, o.jsxs)("div", {
              className: _().content,
              children: [
                (0, o.jsx)(i.Icon, { className: (0, a.$)(_().icon, p2), variant: m2, size: v }),
                (0, o.jsx)(u.Heading, {
                  className: (0, a.$)(_().title, _().important),
                  variant: "h3",
                  size: "xs",
                  children: n2 || (0, o.jsx)(s.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, o.jsx)(u.Caption, {
                  className: (0, a.$)(_().text, _().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: r2 || (0, o.jsx)(s.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, o.jsx)(l.$, {
                  onClick: N,
                  className: _().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, o.jsx)(u.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, o.jsx)(s.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    66534: (e, t, n) => {
      "use strict";
      var o;
      n.d(t, { U: () => o }), (function(e2) {
        e2.UNKNOWN = "unknown", e2.MALE = "male", e2.FEMALE = "female";
      })(o || (o = {}));
    },
    75312: (e, t, n) => {
      "use strict";
      n.d(t, { SomethingWentWrong: () => v });
      var o = n(54486), a = n(50420), r = n(28303), s = n(61910), l = n(43426), i = n(47713), u = n(77881), d = n(5956), c = n(97800), g = n(74125), m = n(80585), _ = n(63708), p = n.n(_);
      let v = (0, r.PA)((e2) => {
        let { className: t2, withBackwardControl: n2 = true } = e2, { formatMessage: r2 } = (0, l.A)(), _2 = r2({ id: "error-messages.something-went-wrong" });
        (0, g.CgZ)(_2);
        let { sendRefreshEvent: v2 } = (0, g.cYT)(), x = (0, s.useCallback)(() => {
          v2(), window.location.href = g.Zyd.main.href;
        }, [v2]), { contentRef: h } = (0, g.gKY)();
        return (0, o.jsxs)("div", {
          className: (0, a.$)(p().root, t2),
          children: [
            n2 && (0, o.jsx)(m.Lh, {
              withBackwardFallback: "/",
              className: (0, a.$)(p().navigation, { [p().navigation_desktop]: !h }),
              withForwardControl: false
            }),
            (0, o.jsxs)("div", {
              className: (0, a.$)(p().content, { [p().content_shrink]: !n2 }),
              children: [
                (0, o.jsx)(d.Icon, { className: p().icon, variant: "attention", size: "xxl" }),
                (0, o.jsx)(c.Heading, {
                  className: (0, a.$)(p().title, p().important),
                  variant: "h3",
                  size: "xs",
                  children: _2
                }),
                (0, o.jsxs)(c.Caption, {
                  className: (0, a.$)(p().text, p().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: [false, (0, o.jsx)(i.A, { id: "page-error.try-to-restart-app" })]
                }),
                (0, o.jsx)(u.$, {
                  onClick: x,
                  className: p().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, o.jsxs)(c.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: [false, (0, o.jsx)(i.A, { id: "page-error.restart-app-button" })]
                  })
                })
              ]
            })
          ]
        });
      });
    },
    82644: (e, t, n) => {
      "use strict";
      n.d(t, { w: () => o.SomethingWentWrong });
      var o = n(75312);
    },
    94716: (e, t, n) => {
      "use strict";
      n.d(t, { TagNotFoundPage: () => s });
      var o = n(54486), a = n(28303), r = n(42421);
      let s = (0, a.PA)(() => (0, o.jsx)(r.M, {}));
    }
  },
  (e) => {
    e.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        1546,
        2116,
        2036,
        8335,
        1311,
        7764,
        6706,
        5148,
        3005,
        4125,
        585,
        6433,
        4561,
        4460,
        3909,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 48597)
    ), _N_E = e.O();
  }
]);
