(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2717],
  {
    46215: (o) => {
      o.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    62804: (o, t, e) => {
      Promise.resolve().then(e.bind(e, 19741)), Promise.resolve().then(e.bind(e, 607)), Promise.resolve().then(e.bind(e, 10209)), Promise.resolve().then(e.bind(e, 37491)), Promise.resolve().then(e.bind(e, 10877)), Promise.resolve().then(e.bind(e, 46865)), Promise.resolve().then(e.bind(e, 65034));
    },
    65034: (o, t, e) => {
      "use strict";
      e.d(t, { NotFound: () => x });
      var n = e(54486), s = e(50420), i = e(28303), a = e(47713), r = e(77881), d = e(5956), l = e(97800), _ = e(74125), c = e(80585), u = e(61910), p = e(46215), m = e.n(p);
      let x = (0, i.PA)((o2) => {
        let { className: t2, title: e2, description: i2, iconVariant: p2 = "musicLogo", iconClassName: x2, iconSize: N } = o2, { contentRef: h } = (0, _.gKY)(), v = (0, _.ZpR)(_.Zyd.main.href);
        (0, _.LZB)();
        let { handleNavigateToMain: F } = (0, _.D5F)(v);
        return (0, _.NBO)(true), !(function() {
          let { location: o3 } = (0, _.Pjs)();
          (0, u.useEffect)(
            () => (o3.setNotFound(true), () => {
              o3.setNotFound(false);
            }),
            [o3]
          );
        })(), (0, n.jsxs)("div", {
          className: (0, s.$)(m().root, { [m().root_desktop]: !h }, t2),
          children: [
            (0, n.jsx)(c.Lh, { withBackwardFallback: "/", className: m().navigation, withForwardControl: false }),
            (0, n.jsxs)("div", {
              className: m().content,
              children: [
                (0, n.jsx)(d.Icon, { className: (0, s.$)(m().icon, x2), variant: p2, size: N }),
                (0, n.jsx)(l.Heading, {
                  className: (0, s.$)(m().title, m().important),
                  variant: "h3",
                  size: "xs",
                  children: e2 || (0, n.jsx)(a.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, n.jsx)(l.Caption, {
                  className: (0, s.$)(m().text, m().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: i2 || (0, n.jsx)(a.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, n.jsx)(r.$, {
                  onClick: F,
                  className: m().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, n.jsx)(l.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, n.jsx)(a.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    }
  },
  (o) => {
    o.O(
      0,
      [
        2685,
        5355,
        1546,
        7956,
        1023,
        5081,
        8335,
        3146,
        6952,
        1426,
        1604,
        2116,
        87,
        9577,
        6552,
        1469,
        5017,
        2036,
        8536,
        1311,
        7764,
        6706,
        7724,
        5201,
        5148,
        3005,
        3916,
        5973,
        3773,
        4125,
        585,
        6433,
        4561,
        1995,
        4460,
        4826,
        1365,
        8629,
        7858,
        5164,
        2353,
        5284,
        1656,
        1752,
        3143,
        4790,
        671,
        5843,
        3290,
        7358
      ],
      () => o(o.s = 62804)
    ), _N_E = o.O();
  }
]);
