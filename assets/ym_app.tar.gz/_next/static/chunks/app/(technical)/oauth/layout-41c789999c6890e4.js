(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6808],
  {
    9493: (e, s, o) => {
      Promise.resolve().then(o.bind(o, 58360)), Promise.resolve().then(o.bind(o, 14342)), Promise.resolve().then(o.bind(o, 62662)), Promise.resolve().then(o.bind(o, 6971)), Promise.resolve().then(o.bind(o, 22674)), Promise.resolve().then(o.bind(o, 51321)), Promise.resolve().then(o.bind(o, 97800)), Promise.resolve().then(o.bind(o, 42520)), Promise.resolve().then(o.bind(o, 81713)), Promise.resolve().then(o.bind(o, 58699)), Promise.resolve().then(o.bind(o, 40493)), Promise.resolve().then(o.bind(o, 89381)), Promise.resolve().then(o.bind(o, 97691)), Promise.resolve().then(o.bind(o, 96269)), Promise.resolve().then(o.bind(o, 58055)), Promise.resolve().then(o.bind(o, 80616)), Promise.resolve().then(o.bind(o, 80986)), Promise.resolve().then(o.bind(o, 61777)), Promise.resolve().then(o.t.bind(o, 90809, 23)), Promise.resolve().then(o.bind(o, 43751)), Promise.resolve().then(o.bind(o, 29910)), Promise.resolve().then(o.bind(o, 97249)), Promise.resolve().then(o.bind(o, 36138)), Promise.resolve().then(o.bind(o, 31669)), Promise.resolve().then(o.bind(o, 16173)), Promise.resolve().then(o.bind(o, 15782)), Promise.resolve().then(o.bind(o, 3070)), Promise.resolve().then(o.bind(o, 6923)), Promise.resolve().then(o.bind(o, 46562)), Promise.resolve().then(o.bind(o, 79882)), Promise.resolve().then(o.bind(o, 33461)), Promise.resolve().then(o.bind(o, 36298)), Promise.resolve().then(o.bind(o, 4968)), Promise.resolve().then(o.bind(o, 71267)), Promise.resolve().then(o.bind(o, 62803)), Promise.resolve().then(o.bind(o, 53714)), Promise.resolve().then(o.bind(o, 65445)), Promise.resolve().then(o.bind(o, 41076)), Promise.resolve().then(o.bind(o, 93099)), Promise.resolve().then(o.bind(o, 15640)), Promise.resolve().then(o.bind(o, 82885)), Promise.resolve().then(o.bind(o, 99733)), Promise.resolve().then(o.bind(o, 18355)), Promise.resolve().then(o.bind(o, 42691)), Promise.resolve().then(o.bind(o, 37235)), Promise.resolve().then(o.bind(o, 3781)), Promise.resolve().then(o.bind(o, 33829)), Promise.resolve().then(o.bind(o, 39906)), Promise.resolve().then(o.bind(o, 50119)), Promise.resolve().then(o.bind(o, 21179)), Promise.resolve().then(o.bind(o, 7912)), Promise.resolve().then(o.bind(o, 50193)), Promise.resolve().then(o.bind(o, 83399)), Promise.resolve().then(o.bind(o, 11450)), Promise.resolve().then(o.bind(o, 62345)), Promise.resolve().then(o.bind(o, 37408)), Promise.resolve().then(o.bind(o, 48392)), Promise.resolve().then(o.bind(o, 42488)), Promise.resolve().then(o.bind(o, 5207)), Promise.resolve().then(o.bind(o, 85827)), Promise.resolve().then(o.bind(o, 8394)), Promise.resolve().then(o.bind(o, 3192)), Promise.resolve().then(o.bind(o, 7286)), Promise.resolve().then(o.bind(o, 60305)), Promise.resolve().then(o.bind(o, 47203)), Promise.resolve().then(o.bind(o, 34286)), Promise.resolve().then(o.bind(o, 224)), Promise.resolve().then(o.bind(o, 24449)), Promise.resolve().then(o.bind(o, 79893)), Promise.resolve().then(o.bind(o, 81789)), Promise.resolve().then(o.bind(o, 87466)), Promise.resolve().then(o.bind(o, 39034)), Promise.resolve().then(o.bind(o, 17917)), Promise.resolve().then(o.bind(o, 11337)), Promise.resolve().then(o.bind(o, 19683)), Promise.resolve().then(o.bind(o, 53779)), Promise.resolve().then(o.bind(o, 12359)), Promise.resolve().then(o.bind(o, 88564)), Promise.resolve().then(o.bind(o, 95639)), Promise.resolve().then(o.bind(o, 57630)), Promise.resolve().then(o.bind(o, 25342)), Promise.resolve().then(o.bind(o, 34028)), Promise.resolve().then(o.bind(o, 99564)), Promise.resolve().then(o.bind(o, 95348)), Promise.resolve().then(o.bind(o, 52347)), Promise.resolve().then(o.bind(o, 61015)), Promise.resolve().then(o.bind(o, 1771)), Promise.resolve().then(o.bind(o, 80043)), Promise.resolve().then(o.bind(o, 12235)), Promise.resolve().then(o.bind(o, 8941)), Promise.resolve().then(o.bind(o, 38433)), Promise.resolve().then(o.bind(o, 8732)), Promise.resolve().then(o.bind(o, 43369)), Promise.resolve().then(o.bind(o, 47564)), Promise.resolve().then(o.bind(o, 41017)), Promise.resolve().then(o.bind(o, 27252)), Promise.resolve().then(o.bind(o, 65286)), Promise.resolve().then(o.bind(o, 45198)), Promise.resolve().then(o.bind(o, 46814)), Promise.resolve().then(o.bind(o, 92508)), Promise.resolve().then(o.bind(o, 40126)), Promise.resolve().then(o.bind(o, 83726)), Promise.resolve().then(o.bind(o, 90410)), Promise.resolve().then(o.bind(o, 13246)), Promise.resolve().then(o.bind(o, 26040)), Promise.resolve().then(o.bind(o, 92446)), Promise.resolve().then(o.bind(o, 42593)), Promise.resolve().then(o.bind(o, 70570)), Promise.resolve().then(o.bind(o, 88416)), Promise.resolve().then(o.bind(o, 24174)), Promise.resolve().then(o.bind(o, 78458)), Promise.resolve().then(o.bind(o, 59457)), Promise.resolve().then(o.bind(o, 6690)), Promise.resolve().then(o.bind(o, 88370)), Promise.resolve().then(o.bind(o, 66904)), Promise.resolve().then(o.bind(o, 39937)), Promise.resolve().then(o.bind(o, 33019)), Promise.resolve().then(o.bind(o, 38808)), Promise.resolve().then(o.bind(o, 58094)), Promise.resolve().then(o.bind(o, 78009)), Promise.resolve().then(o.bind(o, 33427)), Promise.resolve().then(o.bind(o, 30878)), Promise.resolve().then(o.bind(o, 53115)), Promise.resolve().then(o.bind(o, 52398)), Promise.resolve().then(o.bind(o, 82327)), Promise.resolve().then(o.bind(o, 17012)), Promise.resolve().then(o.bind(o, 9275)), Promise.resolve().then(o.bind(o, 17658)), Promise.resolve().then(o.bind(o, 36578)), Promise.resolve().then(o.bind(o, 66989)), Promise.resolve().then(o.bind(o, 58863)), Promise.resolve().then(o.bind(o, 60899)), Promise.resolve().then(o.bind(o, 59437)), Promise.resolve().then(o.bind(o, 43367)), Promise.resolve().then(o.bind(o, 66446)), Promise.resolve().then(o.bind(o, 86840)), Promise.resolve().then(o.bind(o, 75181)), Promise.resolve().then(o.bind(o, 99538)), Promise.resolve().then(o.bind(o, 45252)), Promise.resolve().then(o.bind(o, 59226)), Promise.resolve().then(o.bind(o, 75961)), Promise.resolve().then(o.bind(o, 33964)), Promise.resolve().then(o.bind(o, 33967)), Promise.resolve().then(o.bind(o, 64410)), Promise.resolve().then(o.bind(o, 91350)), Promise.resolve().then(o.bind(o, 4500)), Promise.resolve().then(o.bind(o, 55846)), Promise.resolve().then(o.bind(o, 65689)), Promise.resolve().then(o.bind(o, 99386)), Promise.resolve().then(o.bind(o, 5222)), Promise.resolve().then(o.bind(o, 60440)), Promise.resolve().then(o.bind(o, 37271)), Promise.resolve().then(o.bind(o, 66688)), Promise.resolve().then(o.bind(o, 76472)), Promise.resolve().then(o.bind(o, 41682)), Promise.resolve().then(o.bind(o, 77666)), Promise.resolve().then(o.bind(o, 8765)), Promise.resolve().then(o.bind(o, 48670)), Promise.resolve().then(o.bind(o, 22096)), Promise.resolve().then(o.bind(o, 33655)), Promise.resolve().then(o.bind(o, 27754)), Promise.resolve().then(o.bind(o, 47347)), Promise.resolve().then(o.bind(o, 45591)), Promise.resolve().then(o.bind(o, 52862)), Promise.resolve().then(o.bind(o, 79326)), Promise.resolve().then(o.bind(o, 73922)), Promise.resolve().then(o.bind(o, 10790)), Promise.resolve().then(o.bind(o, 78684)), Promise.resolve().then(o.bind(o, 76877)), Promise.resolve().then(o.bind(o, 61176)), Promise.resolve().then(o.bind(o, 62108)), Promise.resolve().then(o.t.bind(o, 66154, 23)), Promise.resolve().then(o.t.bind(o, 1131, 23)), Promise.resolve().then(o.t.bind(o, 65250, 23)), Promise.resolve().then(o.t.bind(o, 91786, 23)), Promise.resolve().then(o.bind(o, 75053)), Promise.resolve().then(o.bind(o, 23035)), Promise.resolve().then(o.bind(o, 82315)), Promise.resolve().then(o.bind(o, 60673)), Promise.resolve().then(o.bind(o, 5048)), Promise.resolve().then(o.bind(o, 50215)), Promise.resolve().then(o.bind(o, 78308)), Promise.resolve().then(o.bind(o, 10084)), Promise.resolve().then(o.bind(o, 58681)), Promise.resolve().then(o.bind(o, 18658)), Promise.resolve().then(o.bind(o, 6323)), Promise.resolve().then(o.bind(o, 78817)), Promise.resolve().then(o.bind(o, 7230)), Promise.resolve().then(o.bind(o, 38378)), Promise.resolve().then(o.bind(o, 35609)), Promise.resolve().then(o.bind(o, 18606)), Promise.resolve().then(o.bind(o, 68014)), Promise.resolve().then(o.bind(o, 12126)), Promise.resolve().then(o.bind(o, 52742)), Promise.resolve().then(o.bind(o, 68098)), Promise.resolve().then(o.bind(o, 89190)), Promise.resolve().then(o.bind(o, 3270)), Promise.resolve().then(o.bind(o, 1220)), Promise.resolve().then(o.bind(o, 96584)), Promise.resolve().then(o.bind(o, 54598)), Promise.resolve().then(o.bind(o, 14196)), Promise.resolve().then(o.bind(o, 20576)), Promise.resolve().then(o.t.bind(o, 5866, 23)), Promise.resolve().then(o.bind(o, 29070)), Promise.resolve().then(o.bind(o, 35203)), Promise.resolve().then(o.bind(o, 39450)), Promise.resolve().then(o.bind(o, 77607)), Promise.resolve().then(o.bind(o, 7430)), Promise.resolve().then(o.bind(o, 24786)), Promise.resolve().then(o.bind(o, 24036)), Promise.resolve().then(o.bind(o, 34932)), Promise.resolve().then(o.bind(o, 56204)), Promise.resolve().then(o.t.bind(o, 71262, 23)), Promise.resolve().then(o.t.bind(o, 86318, 23)), Promise.resolve().then(o.bind(o, 75450)), Promise.resolve().then(o.bind(o, 60608)), Promise.resolve().then(o.bind(o, 33648)), Promise.resolve().then(o.bind(o, 43548)), Promise.resolve().then(o.bind(o, 69672)), Promise.resolve().then(o.bind(o, 50711)), Promise.resolve().then(o.bind(o, 5185)), Promise.resolve().then(o.bind(o, 90555)), Promise.resolve().then(o.bind(o, 5602)), Promise.resolve().then(o.bind(o, 12390)), Promise.resolve().then(o.bind(o, 58376)), Promise.resolve().then(o.bind(o, 24491)), Promise.resolve().then(o.bind(o, 61993)), Promise.resolve().then(o.bind(o, 38644)), Promise.resolve().then(o.bind(o, 93668)), Promise.resolve().then(o.bind(o, 85949)), Promise.resolve().then(o.bind(o, 17519)), Promise.resolve().then(o.bind(o, 62010)), Promise.resolve().then(o.bind(o, 16372)), Promise.resolve().then(o.bind(o, 64434)), Promise.resolve().then(o.bind(o, 33158)), Promise.resolve().then(o.bind(o, 27314)), Promise.resolve().then(o.bind(o, 93206)), Promise.resolve().then(o.bind(o, 37226)), Promise.resolve().then(o.t.bind(o, 1810, 23)), Promise.resolve().then(o.t.bind(o, 69191, 23)), Promise.resolve().then(o.t.bind(o, 48384, 23)), Promise.resolve().then(o.t.bind(o, 83690, 23)), Promise.resolve().then(o.t.bind(o, 63886, 23)), Promise.resolve().then(o.bind(o, 13811)), Promise.resolve().then(o.bind(o, 45645)), Promise.resolve().then(o.bind(o, 24126)), Promise.resolve().then(o.bind(o, 20406)), Promise.resolve().then(o.bind(o, 21940)), Promise.resolve().then(o.t.bind(o, 99882, 23)), Promise.resolve().then(o.t.bind(o, 25582, 23)), Promise.resolve().then(o.bind(o, 26086)), Promise.resolve().then(o.t.bind(o, 18608, 23)), Promise.resolve().then(o.bind(o, 96838)), Promise.resolve().then(o.bind(o, 10358)), Promise.resolve().then(o.bind(o, 23143)), Promise.resolve().then(o.bind(o, 51828)), Promise.resolve().then(o.bind(o, 51725)), Promise.resolve().then(o.bind(o, 23834)), Promise.resolve().then(o.bind(o, 88343)), Promise.resolve().then(o.bind(o, 24624)), Promise.resolve().then(o.bind(o, 75312));
    },
    15778: (e, s, o) => {
      "use strict";
      o.d(s, { useRefreshTracksAvailability: () => t });
      var n = o(61910), r = o(74125);
      let t = () => {
        let e2 = (0, r.jRO)(), s2 = (0, n.useCallback)(() => {
          e2.tracksController && e2.tracksController.refreshTracksAvailability().then(() => {
            var e3;
            null == (e3 = window.desktopEvents) || e3.send(r.EE.TRACKS_AVAILABILITY_UPDATED);
          });
        }, [e2.tracksController]);
        (0, n.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(r.EE.REFRESH_TRACKS_AVAILABILITY, s2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(r.EE.REFRESH_TRACKS_AVAILABILITY, s2);
          };
        }, [s2]);
      };
    },
    15855: (e, s, o) => {
      "use strict";
      o.d(s, { useProbabilityBucket: () => t });
      var n = o(61910), r = o(74125);
      let t = () => {
        let e2 = (0, r.NFA)().get(r.vgk), s2 = (0, n.useCallback)(
          (s3, o2) => {
            o2 && e2.count(o2, "probabilityBucket");
          },
          [e2]
        );
        (0, n.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(r.EE.PROBABILITY_BUCKET, s2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(r.EE.PROBABILITY_BUCKET, s2);
          };
        }, [s2]);
      };
    },
    24783: (e, s, o) => {
      "use strict";
      o.d(s, { LO: () => t, N5: () => i, vZ: () => r });
      var n = o(74125);
      let r = () => {
        var e2;
        null == (e2 = window.desktopEvents) || e2.send(n.EE.WINDOW_MINIMIZE);
      }, t = () => {
        var e2;
        null == (e2 = window.desktopEvents) || e2.send(n.EE.WINDOW_MAXIMIZE);
      }, i = () => {
        var e2;
        null == (e2 = window.desktopEvents) || e2.send(n.EE.WINDOW_CLOSE);
      };
    },
    40493: (e, s, o) => {
      "use strict";
      o.d(s, { ClientConfigInitializer: () => n }), o(54486);
      let n = (e2) => {
        let { env: s2, nonce: o2 } = e2;
        return null;
      };
    },
    45631: (e) => {
      e.exports = {
        root: "ReleaseNotesModal_root__RSw1p",
        modalOverlay: "ReleaseNotesModal_modalOverlay__GYUgU",
        modalHeader: "ReleaseNotesModal_modalHeader__gp9SA",
        modalContent: "ReleaseNotesModal_modalContent__g8OTu",
        scrollableContent: "ReleaseNotesModal_scrollableContent__zGdbH",
        important: "ReleaseNotesModal_important__u8yP4",
        notes: "ReleaseNotesModal_notes__bVAoa",
        date: "ReleaseNotesModal_date__s3_ux",
        description: "ReleaseNotesModal_description__B_yLI",
        paragraph: "ReleaseNotesModal_paragraph___laDJ",
        note: "ReleaseNotesModal_note__S9E6z",
        version: "ReleaseNotesModal_version__4Mcd5",
        item: "ReleaseNotesModal_item___CYml",
        code: "ReleaseNotesModal_code__Yv3QD"
      };
    },
    46215: (e) => {
      e.exports = {
        root: "NotFound_root__47ZX6",
        root_desktop: "NotFound_root_desktop___QqSb",
        navigation: "NotFound_navigation__q8rIW",
        content: "NotFound_content__3kry_",
        icon: "NotFound_icon___Wa9y",
        title: "NotFound_title__akG_o",
        important: "NotFound_important__z1LWl",
        text: "NotFound_text__oxDZv",
        button: "NotFound_button__jF4uH"
      };
    },
    47770: (e, s, o) => {
      "use strict";
      o.d(s, { useApplicationUpdate: () => P });
      var n = o(54486), r = o(61910), t = o(43426), i = o(74125), l = o(50420), d = o(77881), a = o(97800), v = o(80585), h = o(79413), m = o.n(h);
      let b = (e2) => {
        let { version: s2, formatMessage: o2, closeToast: t2 } = e2, h2 = (0, r.useCallback)(() => {
          var e3;
          null == (e3 = window.desktopEvents) || e3.send(i.EE.INSTALL_UPDATE), null == t2 || t2();
        }, [t2]), b2 = (0, r.useMemo)(
          () => (0, n.jsxs)("div", {
            className: m().message,
            children: [
              (0, n.jsx)(a.Caption, {
                className: m().text,
                variant: "div",
                type: "controls",
                size: "m",
                children: o2({ id: "desktop.on-update-available" }, { version: s2 })
              }),
              (0, n.jsx)(d.$, {
                className: m().button,
                onClick: h2,
                variant: "default",
                color: "secondary",
                size: "xs",
                radius: "xxxl",
                children: (0, n.jsx)(a.Caption, {
                  variant: "div",
                  type: "controls",
                  size: "m",
                  children: o2({ id: "desktop.update" })
                })
              })
            ]
          }),
          [o2, h2, s2]
        );
        return (0, n.jsx)(v.$W, { className: (0, l.$)(m().root, m().important), message: b2 });
      }, P = () => {
        let { formatMessage: e2 } = (0, t.A)(), { notify: s2 } = (0, i.lkh)(), o2 = (0, r.useRef)(""), l2 = (0, r.useCallback)(
          (r2, t2) => {
            o2.current !== t2 && (o2.current = t2, s2((0, n.jsx)(b, { formatMessage: e2, version: t2 }), { containerId: i.uQT.IMPORTANT }));
          },
          [e2, o2, s2]
        );
        (0, r.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(i.EE.UPDATE_AVAILABLE, l2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(i.EE.UPDATE_AVAILABLE, l2);
          };
        }, [l2]);
      };
    },
    49475: (e) => {
      e.exports = {
        root: "TitleBar_root__QjdOZ",
        button: "TitleBar_button__9MptL",
        button_withSecondaryColor: "TitleBar_button_withSecondaryColor__oIkuo",
        icon: "TitleBar_icon__8Wji9",
        icon_withSecondaryColor: "TitleBar_icon_withSecondaryColor__vuw6G",
        closeButton: "TitleBar_closeButton__Epxh7"
      };
    },
    53466: (e, s, o) => {
      "use strict";
      o.d(s, { useReleaseNotes: () => t });
      var n = o(61910), r = o(74125);
      let t = () => {
        let [e2, s2] = (0, n.useState)(false), {
          releaseNotes: { setTranslationsReleaseNotes: o2, isReady: t2, modal: i, setSortedDescReleaseNotesKeys: l }
        } = (0, r.Pjs)(), d = (0, n.useCallback)(
          (e3, n2) => {
            let { needToShowReleaseNotes: r2, sortedDescReleaseNotesKeys: t3, translationsReleaseNotes: i2 } = n2;
            o2(i2), l(t3), r2 && s2(true);
          },
          [l, o2]
        );
        (0, n.useEffect)(() => {
          e2 && t2 && (i.open(), s2(false));
        }, [t2, i, e2]), (0, n.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(r.EE.LOAD_RELEASE_NOTES, d), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(r.EE.LOAD_RELEASE_NOTES, d);
          };
        }, [d]);
      };
    },
    61337: (e, s, o) => {
      "use strict";
      o.d(s, { useRefreshApplicationData: () => i });
      var n = o(61910), r = o(6024), t = o(74125);
      let i = () => {
        let { library: e2, collection: s2, experiments: o2, main: i2, user: l } = (0, t.Pjs)(), d = (0, n.useCallback)(() => {
          o2.getData(), e2.getData(), i2.landing.isLoaded && i2.landing.getSkeleton(
            { id: r.p.WEB_MAIN, showWizard: l.settings.showWizard },
            { preloadBlocksCount: 2 }
          ), s2.landing.isLoaded && s2.landing.getSkeleton(
            { id: r.p.WEB_COLLECTION, showWizard: l.settings.showWizard },
            { preloadBlocksCount: 2 }
          );
        }, [s2.landing, o2, e2, i2.landing, l.settings.showWizard]);
        (0, n.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(t.EE.REFRESH_APPLICATION_DATA, d), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(t.EE.REFRESH_APPLICATION_DATA, d);
          };
        }, [d]);
      };
    },
    65034: (e, s, o) => {
      "use strict";
      o.d(s, { NotFound: () => c });
      var n = o(54486), r = o(50420), t = o(28303), i = o(47713), l = o(77881), d = o(5956), a = o(97800), v = o(74125), h = o(80585), m = o(61910), b = o(46215), P = o.n(b);
      let c = (0, t.PA)((e2) => {
        let { className: s2, title: o2, description: t2, iconVariant: b2 = "musicLogo", iconClassName: c2, iconSize: u } = e2, { contentRef: _ } = (0, v.gKY)(), E = (0, v.ZpR)(v.Zyd.main.href);
        (0, v.LZB)();
        let { handleNavigateToMain: C } = (0, v.D5F)(E);
        return (0, v.NBO)(true), !(function() {
          let { location: e3 } = (0, v.Pjs)();
          (0, m.useEffect)(
            () => (e3.setNotFound(true), () => {
              e3.setNotFound(false);
            }),
            [e3]
          );
        })(), (0, n.jsxs)("div", {
          className: (0, r.$)(P().root, { [P().root_desktop]: !_ }, s2),
          children: [
            (0, n.jsx)(h.Lh, { withBackwardFallback: "/", className: P().navigation, withForwardControl: false }),
            (0, n.jsxs)("div", {
              className: P().content,
              children: [
                (0, n.jsx)(d.Icon, { className: (0, r.$)(P().icon, c2), variant: b2, size: u }),
                (0, n.jsx)(a.Heading, {
                  className: (0, r.$)(P().title, P().important),
                  variant: "h3",
                  size: "xs",
                  children: o2 || (0, n.jsx)(i.A, { id: "page-error.page-does-not-exist" })
                }),
                (0, n.jsx)(a.Caption, {
                  className: (0, r.$)(P().text, P().important),
                  variant: "span",
                  type: "text",
                  size: "l",
                  weight: "normal",
                  children: t2 || (0, n.jsx)(i.A, { id: "page-error.page-does-not-exist-description" })
                }),
                (0, n.jsx)(l.$, {
                  onClick: C,
                  className: P().button,
                  role: "link",
                  color: "secondary",
                  size: "l",
                  radius: "xxxl",
                  children: (0, n.jsx)(a.Caption, {
                    type: "controls",
                    variant: "span",
                    size: "m",
                    children: (0, n.jsx)(i.A, { id: "navigation.page-main" })
                  })
                })
              ]
            })
          ]
        });
      });
    },
    66164: (e, s, o) => {
      "use strict";
      o.d(s, { useRefreshRepositoryMeta: () => t });
      var n = o(61910), r = o(74125);
      let t = () => {
        let e2 = (0, r.jRO)(), s2 = (0, n.useCallback)(() => {
          e2.tracksController && e2.tracksController.refreshTracksMeta().then(() => {
            var e3;
            null == (e3 = window.desktopEvents) || e3.send(r.EE.REPOSITORY_META_UPDATED);
          });
        }, [e2.tracksController]);
        (0, n.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(r.EE.REFRESH_REPOSITORY_META, s2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(r.EE.REFRESH_REPOSITORY_META, s2);
          };
        }, [s2]);
      };
    },
    68317: (e, s, o) => {
      "use strict";
      o.d(s, {
        qw: () => w.ReleaseNotesModal,
        _o: () => p,
        cq: () => N.TitleBar,
        CA: () => n,
        M4: () => t,
        _E: () => i,
        LD: () => l.useApplicationDeeplinks,
        P4: () => d.useApplicationUpdate,
        Fn: () => a.useLaunch,
        H: () => v.usePlayerAction,
        t4: () => h.useProbabilityBucket,
        bk: () => m.useRefreshApplicationData,
        eP: () => b.useRefreshRepositoryMeta,
        sb: () => P.useRefreshTracksAvailability,
        sq: () => c.useReleaseNotes,
        OM: () => u.useSendPlayerState
      });
      let n = () => {
        document.addEventListener("auxclick", (e2) => e2.preventDefault()), document.addEventListener("click", (e2) => {
          (e2.ctrlKey || e2.metaKey || e2.shiftKey) && e2.preventDefault();
        });
      };
      var r = o(74125);
      let t = (e2) => {
        var s2;
        null == (s2 = window.desktopEvents) || s2.send(r.EE.APPLICATION_READY, e2);
      }, i = (e2) => {
        let s2 = e2 === r.Sxu.Light ? "#FFFFFF" : "#000000";
        window.desktopEvents.send(r.EE.APPLICATION_THEME, s2);
      };
      o(24783);
      var l = o(99175), d = o(47770), a = o(71117), v = o(89473), h = o(15855), m = o(61337), b = o(66164), P = o(15778), c = o(53466), u = o(96798), _ = o(93064), E = o(26433);
      let C = _.gK.model("TranslationsModel", { data: _.gK.frozen() }), p = _.gK.model("ReleaseNotes", {
        modal: E.qt,
        translations: _.gK.maybeNull(C),
        sortedDescReleaseNotesKeys: _.gK.maybeNull(_.gK.array(_.gK.string))
      }).views((e2) => ({
        get isReady() {
          var s2;
          return !!((null == (s2 = e2.translations) ? void 0 : s2.data) && "object" == typeof e2.translations.data && Object.keys(e2.translations.data).length > 0);
        }
      })).actions((e2) => ({
        setSortedDescReleaseNotesKeys: (s2) => {
          e2.sortedDescReleaseNotesKeys = (0, _.wg)(s2);
        },
        setTranslationsReleaseNotes: (s2) => {
          s2 && (e2.translations = C.create({ data: s2 }));
        }
      }));
      var w = o(81733), N = o(83573);
    },
    71117: (e, s, o) => {
      "use strict";
      o.d(s, { useLaunch: () => t });
      var n = o(61910), r = o(74125);
      let t = () => {
        let e2 = (0, r.NFA)().get(r.vgk), s2 = (0, n.useCallback)(() => {
          let s3 = (0, r.HFS)();
          s3 && e2.count(s3, "installsCount");
        }, [e2]);
        (0, n.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(r.EE.FIRST_LAUNCH, s2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(r.EE.FIRST_LAUNCH, s2);
          };
        }, [s2]);
      };
    },
    79413: (e) => {
      e.exports = {
        root: "NotificationUpdate_root__hpSQi",
        important: "NotificationUpdate_important___0WHj",
        text: "NotificationUpdate_text__YylYD",
        button: "NotificationUpdate_button__F3O16",
        message: "NotificationUpdate_message__rLYpW"
      };
    },
    81733: (e, s, o) => {
      "use strict";
      o.d(s, { ReleaseNotesModal: () => u });
      var n = o(54486), r = o(50420), t = o(28303), i = o(43426), l = o(50722), d = o(47713), a = o(32692), v = o(56231), h = o(97800), m = o(74125), b = o(45631), P = o.n(b);
      let c = {
        ul: (e2) => (0, n.jsx)("ul", { className: P().description, children: e2 }),
        li: (e2) => (0, n.jsx)("li", { className: P().item, children: e2 }),
        code: (e2) => (0, n.jsx)("code", { className: P().code, children: e2 }),
        date: (e2) => (0, n.jsx)("span", { className: P().date, children: e2 }),
        p: (e2) => (0, n.jsx)("p", { className: P().paragraph, children: e2 }),
        br: (0, n.jsx)("br", {})
      }, u = (0, t.PA)(() => {
        let {
          releaseNotes: { translations: e2, sortedDescReleaseNotesKeys: s2, modal: o2 }
        } = (0, m.Pjs)(), { formatMessage: t2 } = (0, i.A)(), { language: b2, defaultLanguage: u2 } = (0, m.h6b)(), _ = (0, m.Crf)();
        return (0, n.jsx)(a.a, {
          title: t2({ id: "desktop.release-notes-modal-title" }),
          open: o2.isOpened,
          onOpenChange: o2.onOpenChange,
          onClose: o2.close,
          size: "fitContent",
          placement: "center",
          overlayClassName: P().modalOverlay,
          overlayColor: "full",
          labelClose: t2({ id: "interface-actions.close" }),
          className: P().root,
          headerClassName: P().modalHeader,
          contentClassName: P().modalContent,
          children: (0, n.jsx)(l.A, {
            onError: _,
            defaultLocale: u2,
            locale: b2,
            messages: null == e2 ? void 0 : e2.data,
            children: (0, n.jsx)(v.N, {
              className: (0, r.$)(P().scrollableContent, P().important),
              containerClassName: (0, r.$)(P().notes, P().important),
              children: null == s2 ? void 0 : s2.map(
                (e3) => (0, n.jsxs)(
                  "div",
                  {
                    className: P().note,
                    children: [
                      (0, n.jsx)(h.Heading, {
                        variant: "h4",
                        className: (0, r.$)(P().version, P().important),
                        children: (0, m.Grs)(e3)
                      }),
                      (0, n.jsx)(d.A, { id: e3, values: c })
                    ]
                  },
                  e3
                )
              )
            })
          })
        });
      });
    },
    83573: (e, s, o) => {
      "use strict";
      o.d(s, { TitleBar: () => b });
      var n = o(54486), r = o(50420), t = o(28303), i = o(61910), l = o(43426), d = o(74125), a = o(24783), v = o(49475), h = o.n(v);
      let m = (e2) => {
        let { children: s2, className: o2, onClick: t2, ariaLabel: i2, withSecondaryColor: l2 } = e2;
        return (0, n.jsx)("button", {
          type: "button",
          className: (0, r.$)(h().button, { [h().button_withSecondaryColor]: l2 }, o2),
          onClick: t2,
          "aria-label": i2,
          children: s2
        });
      }, b = (0, t.PA)((e2) => {
        let { withSecondaryColor: s2 } = e2, { settings: o2 } = (0, d.Pjs)(), t2 = o2.isWindowsApplication || o2.isLinuxApplication, { formatMessage: v2 } = (0, l.A)(), b2 = (0, i.useCallback)(() => {
          (0, a.vZ)();
        }, []), P = (0, i.useCallback)(() => {
          (0, a.LO)();
        }, []), c = (0, i.useCallback)(() => {
          (0, a.N5)();
        }, []);
        return (0, n.jsx)("div", {
          className: h().root,
          onDoubleClick: P,
          children: t2 && (0, n.jsxs)(n.Fragment, {
            children: [
              (0, n.jsx)(m, {
                onClick: b2,
                ariaLabel: v2({ id: "windows-menu.roll-up" }),
                withSecondaryColor: s2,
                children: (0, n.jsx)("svg", {
                  width: "10",
                  height: "1",
                  viewBox: "0 0 10 1",
                  xmlns: "http://www.w3.org/2000/svg",
                  className: (0, r.$)(h().icon, { [h().icon_withSecondaryColor]: s2 }),
                  children: (0, n.jsx)("path", {
                    d: "M0.498047 1C0.429688 1 0.364583 0.986979 0.302734 0.960938C0.244141 0.934896 0.192057 0.899089 0.146484 0.853516C0.100911 0.807943 0.0651042 0.755859 0.0390625 0.697266C0.0130208 0.635417 0 0.570312 0 0.501953C0 0.433594 0.0130208 0.370117 0.0390625 0.311523C0.0651042 0.249674 0.100911 0.195964 0.146484 0.150391C0.192057 0.101562 0.244141 0.0641276 0.302734 0.0380859C0.364583 0.0120443 0.429688 -0.000976562 0.498047 -0.000976562H9.50195C9.57031 -0.000976562 9.63379 0.0120443 9.69238 0.0380859C9.75423 0.0641276 9.80794 0.101562 9.85352 0.150391C9.89909 0.195964 9.9349 0.249674 9.96094 0.311523C9.98698 0.370117 10 0.433594 10 0.501953C10 0.570312 9.98698 0.635417 9.96094 0.697266C9.9349 0.755859 9.89909 0.807943 9.85352 0.853516C9.80794 0.899089 9.75423 0.934896 9.69238 0.960938C9.63379 0.986979 9.57031 1 9.50195 1H0.498047Z",
                    fill: "currentColor"
                  })
                })
              }),
              (0, n.jsx)(m, {
                onClick: P,
                ariaLabel: v2({ id: "windows-menu.unwrap" }),
                withSecondaryColor: s2,
                children: (0, n.jsx)("svg", {
                  width: "10",
                  height: "10",
                  viewBox: "0 0 10 10",
                  xmlns: "http://www.w3.org/2000/svg",
                  className: (0, r.$)(h().icon, { [h().icon_withSecondaryColor]: s2 }),
                  children: (0, n.jsx)("path", {
                    d: "M1.47461 10C1.2793 10 1.09212 9.96094 0.913086 9.88281C0.734049 9.80143 0.576172 9.69401 0.439453 9.56055C0.30599 9.42383 0.198568 9.26595 0.117188 9.08691C0.0390625 8.90788 0 8.7207 0 8.52539V1.47461C0 1.2793 0.0390625 1.09212 0.117188 0.913086C0.198568 0.734049 0.30599 0.577799 0.439453 0.444336C0.576172 0.307617 0.734049 0.200195 0.913086 0.12207C1.09212 0.0406901 1.2793 0 1.47461 0H8.52539C8.7207 0 8.90788 0.0406901 9.08691 0.12207C9.26595 0.200195 9.4222 0.307617 9.55566 0.444336C9.69238 0.577799 9.7998 0.734049 9.87793 0.913086C9.95931 1.09212 10 1.2793 10 1.47461V8.52539C10 8.7207 9.95931 8.90788 9.87793 9.08691C9.7998 9.26595 9.69238 9.42383 9.55566 9.56055C9.4222 9.69401 9.26595 9.80143 9.08691 9.88281C8.90788 9.96094 8.7207 10 8.52539 10H1.47461ZM8.50098 8.99902C8.56934 8.99902 8.63281 8.986 8.69141 8.95996C8.75326 8.93392 8.80697 8.89811 8.85254 8.85254C8.89811 8.80697 8.93392 8.75488 8.95996 8.69629C8.986 8.63444 8.99902 8.56934 8.99902 8.50098V1.49902C8.99902 1.43066 8.986 1.36719 8.95996 1.30859C8.93392 1.24674 8.89811 1.19303 8.85254 1.14746C8.80697 1.10189 8.75326 1.06608 8.69141 1.04004C8.63281 1.014 8.56934 1.00098 8.50098 1.00098H1.49902C1.43066 1.00098 1.36556 1.014 1.30371 1.04004C1.24512 1.06608 1.19303 1.10189 1.14746 1.14746C1.10189 1.19303 1.06608 1.24674 1.04004 1.30859C1.014 1.36719 1.00098 1.43066 1.00098 1.49902V8.50098C1.00098 8.56934 1.014 8.63444 1.04004 8.69629C1.06608 8.75488 1.10189 8.80697 1.14746 8.85254C1.19303 8.89811 1.24512 8.93392 1.30371 8.95996C1.36556 8.986 1.43066 8.99902 1.49902 8.99902H8.50098Z",
                    fill: "currentColor"
                  })
                })
              }),
              (0, n.jsx)(m, {
                className: h().closeButton,
                onClick: c,
                ariaLabel: v2({ id: "windows-menu.close" }),
                children: (0, n.jsx)("svg", {
                  width: "10",
                  height: "10",
                  viewBox: "0 0 10 10",
                  xmlns: "http://www.w3.org/2000/svg",
                  className: (0, r.$)(h().icon, { [h().icon_withSecondaryColor]: s2 }),
                  children: (0, n.jsx)("path", {
                    d: "M5 5.70801L0.854492 9.85352C0.756836 9.95117 0.639648 10 0.50293 10C0.359701 10 0.239258 9.9528 0.141602 9.8584C0.0472005 9.76074 0 9.6403 0 9.49707C0 9.36035 0.0488281 9.24316 0.146484 9.14551L4.29199 5L0.146484 0.854492C0.0488281 0.756836 0 0.638021 0 0.498047C0 0.429688 0.0130208 0.364583 0.0390625 0.302734C0.0651042 0.240885 0.100911 0.188802 0.146484 0.146484C0.192057 0.100911 0.245768 0.0651042 0.307617 0.0390625C0.369466 0.0130208 0.43457 0 0.50293 0C0.639648 0 0.756836 0.0488281 0.854492 0.146484L5 4.29199L9.14551 0.146484C9.24316 0.0488281 9.36198 0 9.50195 0C9.57031 0 9.63379 0.0130208 9.69238 0.0390625C9.75423 0.0651042 9.80794 0.100911 9.85352 0.146484C9.89909 0.192057 9.9349 0.245768 9.96094 0.307617C9.98698 0.366211 10 0.429688 10 0.498047C10 0.638021 9.95117 0.756836 9.85352 0.854492L5.70801 5L9.85352 9.14551C9.95117 9.24316 10 9.36035 10 9.49707C10 9.56543 9.98698 9.63053 9.96094 9.69238C9.9349 9.75423 9.89909 9.80794 9.85352 9.85352C9.8112 9.89909 9.75911 9.9349 9.69727 9.96094C9.63542 9.98698 9.57031 10 9.50195 10C9.36198 10 9.24316 9.95117 9.14551 9.85352L5 5.70801Z",
                    fill: "currentColor"
                  })
                })
              })
            ]
          })
        });
      });
    },
    89473: (e, s, o) => {
      "use strict";
      o.d(s, { usePlayerAction: () => i });
      var n = o(61910), r = o(74125), t = (function(e2) {
        return e2.PLAY = "PLAY", e2.PAUSE = "PAUSE", e2.MOVE_BACKWARD = "MOVE_BACKWARD", e2.MOVE_FORWARD = "MOVE_FORWARD", e2;
      })(t || {});
      let i = (e2) => {
        let s2 = (0, n.useCallback)(
          (s3, o2) => {
            switch (o2) {
              case "PLAY":
              case "PAUSE":
                null == e2 || e2.togglePause();
                break;
              case "MOVE_BACKWARD":
                null == e2 || e2.moveBackward();
                break;
              case "MOVE_FORWARD":
                null == e2 || e2.moveForward();
            }
          },
          [e2]
        );
        (0, n.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(r.EE.PLAYER_ACTION, s2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(r.EE.PLAYER_ACTION, s2);
          };
        }, [s2]);
      };
    },
    96798: (e, s, o) => {
      "use strict";
      o.d(s, { useSendPlayerState: () => l });
      var n = o(61910), r = o(8817), t = o(89461), i = o(74125);
      let l = (e2) => {
        let { sonata: s2 } = e2, o2 = (0, r.c)((e3) => {
          var s3;
          let { isPlaying: o3, canMoveBackward: n2, canMoveForward: r2 } = e3;
          null == (s3 = window.desktopEvents) || s3.send(i.EE.PLAYER_STATE, { isPlaying: o3, canMoveBackward: n2, canMoveForward: r2 });
        });
        (0, n.useEffect)(() => {
          let e3, n2, r2 = null == s2 ? void 0 : s2.state.playerState.status.onChange((e4) => {
            e4 && o2({ isPlaying: e4 === t.MT.PLAYING });
          }), i2 = null == s2 ? void 0 : s2.state.currentContext.onChange(() => {
            var r3, t2;
            null == e3 || e3(), null == n2 || n2(), e3 = null == s2 || null == (r3 = s2.state.currentContext.value) ? void 0 : r3.availableActions.moveBackward.onChange((e4) => {
              o2({ canMoveBackward: !!e4 });
            }), n2 = null == s2 || null == (t2 = s2.state.currentContext.value) ? void 0 : t2.availableActions.moveForward.onChange((e4) => {
              o2({ canMoveForward: !!e4 });
            });
          });
          return () => {
            null == r2 || r2(), null == i2 || i2(), null == n2 || n2(), null == n2 || n2();
          };
        }, [o2, null == s2 ? void 0 : s2.state.currentContext, null == s2 ? void 0 : s2.state.playerState.status]);
      };
    },
    99175: (e, s, o) => {
      "use strict";
      o.d(s, { useApplicationDeeplinks: () => d });
      var n = o(97396), r = o(61910), t = o(8817), i = o(74125);
      let l = [
        [
          /^\/home\/([^/?]+)(\?.*)?$/,
          (e2) => {
            let s2 = e2.match(/^\/home\/([^/?]+)(\?.*)?$/);
            if (!s2) return e2;
            let o2 = s2[1], n2 = s2[2] || "";
            if (!o2) return e2;
            let r2 = new URLSearchParams(n2.startsWith("?") ? n2.substring(1) : "");
            return r2.set("tab", o2), "/?".concat(r2.toString());
          }
        ],
        [/^\/home$/, () => i.Zyd.main.href],
        [/^\/users\/(.*)\/playlists$/, () => i.Zyd.collection.href],
        [/^\/users\/(.*)\/artists$/, () => i.Zyd.collection.href],
        [/^\/users\/(.*)\/albums$/, () => i.Zyd.collection.href],
        [/^\/users\/(.*)\/tracks$/, () => i.Zyd.collection.href],
        [/^\/users\/(.*)\/podcasts$/, () => i.Zyd.collection.href],
        [/^\/users\/(.*)\/kids$/, () => i.Zyd.collection.href],
        [/^\/users\/(.*)\/history$/, () => i.Zyd.musicHistory.href],
        [
          /^\/play-vibe/,
          (e2) => {
            let s2 = new URLSearchParams(e2.split("?")[1]);
            s2.set(i.K3F.DEEPLINK, i.vEM.PLAY_VIBE);
            let o2 = new URLSearchParams(window.location.search), n2 = (0, i.$cg)(o2, s2);
            return "landing" === s2.get(i.K3F.SCREEN) ? "/?".concat(n2.toString()) : "".concat(window.location.pathname, "?").concat(n2.toString());
          }
        ]
      ], d = () => {
        let e2 = (0, n.useRouter)(), s2 = (0, t.c)((s3, o2) => {
          for (let [s4, n3] of l) if (s4.test(o2)) return void e2.push(n3(o2));
          let { href: n2 } = (0, i.uvd)(null != o2 ? o2 : i.Zyd.main.href);
          e2.push(n2);
        });
        (0, r.useEffect)(() => {
          var e3;
          return null == (e3 = window.desktopEvents) || e3.on(i.EE.OPEN_DEEPLINK, s2), () => {
            var e4;
            null == (e4 = window.desktopEvents) || e4.off(i.EE.OPEN_DEEPLINK, s2);
          };
        }, [s2]);
      };
    }
  },
  (e) => {
    e.O(
      0,
      [
        2685,
        7956,
        5355,
        1023,
        4354,
        9577,
        1546,
        1469,
        6552,
        5017,
        5081,
        6952,
        2193,
        2116,
        2036,
        1604,
        3146,
        1426,
        7080,
        4841,
        6683,
        1909,
        87,
        343,
        5352,
        8335,
        8536,
        4463,
        1311,
        7764,
        6706,
        7724,
        5201,
        5148,
        3005,
        3916,
        5973,
        6266,
        3773,
        8627,
        4125,
        585,
        6433,
        4561,
        1995,
        6231,
        4460,
        4826,
        1365,
        8629,
        7858,
        5164,
        4542,
        2353,
        5284,
        1656,
        1752,
        2460,
        5288,
        5550,
        2830,
        211,
        3143,
        4790,
        9021,
        7363,
        1872,
        1022,
        7870,
        4726,
        8983,
        558,
        4540,
        2521,
        4367,
        2481,
        1308,
        5843,
        3290,
        7358
      ],
      () => e(e.s = 9493)
    ), _N_E = e.O();
  }
]);
