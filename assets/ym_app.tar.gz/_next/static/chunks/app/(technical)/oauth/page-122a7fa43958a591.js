(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [2975],
  {
    68946: (e, t, r) => {
      Promise.resolve().then(r.bind(r, 72169));
    },
    72169: (e, t, r) => {
      "use strict";
      r.d(t, { OAuthPage: () => u });
      var a = r(54486), o = r(56258), s = r(28303), n = r(97396);
      let i = (e2, t2) => t2.some((t3) => t3 instanceof RegExp ? t3.test(e2) : t3 === e2), l = /* @__PURE__ */ new Set(["https:", "http:", "file:"]);
      var c = r(61910), h = r(15209), p = r(74125), m = r(80585);
      let u = (0, s.PA)(() => {
        let e2 = (0, p.NFA)(), t2 = e2.get(p.QGx), r2 = e2.get(p.Zft), s2 = e2.get(p.ooW), u2 = (0, n.useSearchParams)(), { location: d } = (0, p.Pjs)(), f = u2.get("redirectUri") || "", y = (function(e3, t3) {
          if ("string" != typeof (t3 = {
            defaultProtocol: "http",
            normalizeProtocol: true,
            forceHttp: false,
            forceHttps: false,
            stripAuthentication: true,
            stripHash: false,
            stripTextFragment: true,
            stripWWW: true,
            removeQueryParameters: [/^utm_\w+/i],
            removeTrailingSlash: true,
            removeSingleSlash: true,
            removeDirectoryIndex: false,
            removeExplicitPort: false,
            sortQueryParameters: true,
            ...t3
          }).defaultProtocol || t3.defaultProtocol.endsWith(":") || (t3.defaultProtocol = `${t3.defaultProtocol}:`), e3 = e3.trim(), /^data:/i.test(e3))
            return ((e4, { stripHash: t4 }) => {
              var _a, _b;
              let r4 = /^data:(?<type>[^,]*?),(?<data>[^#]*?)(?:#(?<hash>.*))?$/.exec(e4);
              if (!r4) throw Error(`Invalid URL: ${e4}`);
              let { type: a3, data: o3, hash: s3 } = r4.groups, n2 = a3.split(";");
              s3 = t4 ? "" : s3;
              let i2 = false;
              "base64" === n2[n2.length - 1] && (n2.pop(), i2 = true);
              let l2 = (_b = (_a = n2.shift()) == null ? void 0 : _a.toLowerCase()) != null ? _b : "", c2 = [
                ...n2.map((e5) => {
                  let [t5, r5 = ""] = e5.split("=").map((e6) => e6.trim());
                  return "charset" === t5 && "us-ascii" === (r5 = r5.toLowerCase()) ? "" : `${t5}${r5 ? `=${r5}` : ""}`;
                }).filter(Boolean)
              ];
              return i2 && c2.push("base64"), (c2.length > 0 || l2 && "text/plain" !== l2) && c2.unshift(l2), `data:${c2.join(";")},${i2 ? o3.trim() : o3}${s3 ? `#${s3}` : ""}`;
            })(e3, t3);
          if (((e4) => {
            try {
              let { protocol: t4 } = new URL(e4);
              return t4.endsWith(":") && !t4.includes(".") && !l.has(t4);
            } catch {
              return false;
            }
          })(e3))
            return e3;
          let r3 = e3.startsWith("//");
          !r3 && /^\.*\//.test(e3) || (e3 = e3.replace(/^(?!(?:\w+:)?\/\/)|^\/\//, t3.defaultProtocol));
          let a2 = new URL(e3);
          if (t3.forceHttp && t3.forceHttps)
            throw Error("The `forceHttp` and `forceHttps` options cannot be used together");
          if (t3.forceHttp && "https:" === a2.protocol && (a2.protocol = "http:"), t3.forceHttps && "http:" === a2.protocol && (a2.protocol = "https:"), t3.stripAuthentication && (a2.username = "", a2.password = ""), t3.stripHash ? a2.hash = "" : t3.stripTextFragment && (a2.hash = a2.hash.replace(/#?:~:text.*?$/i, "")), a2.pathname) {
            let e4 = /\b[a-z][a-z\d+\-.]{1,50}:\/\//g, t4 = 0, r4 = "";
            for (; ; ) {
              let o3 = e4.exec(a2.pathname);
              if (!o3) break;
              let s3 = o3[0], n2 = o3.index;
              r4 += a2.pathname.slice(t4, n2).replace(/\/{2,}/g, "/"), r4 += s3, t4 = n2 + s3.length;
            }
            r4 += a2.pathname.slice(t4, a2.pathname.length).replace(/\/{2,}/g, "/"), a2.pathname = r4;
          }
          if (a2.pathname)
            try {
              a2.pathname = decodeURI(a2.pathname).replace(/\\/g, "%5C");
            } catch {
            }
          if (true === t3.removeDirectoryIndex && (t3.removeDirectoryIndex = [/^index\.[a-z]+$/]), Array.isArray(t3.removeDirectoryIndex) && t3.removeDirectoryIndex.length > 0) {
            let e4 = a2.pathname.split("/");
            i(e4[e4.length - 1], t3.removeDirectoryIndex) && (a2.pathname = (e4 = e4.slice(0, -1)).slice(1).join("/") + "/");
          }
          if (a2.hostname && (a2.hostname = a2.hostname.replace(/\.$/, ""), t3.stripWWW && /^www\.(?!www\.)[a-z\-\d]{1,63}\.[a-z.\-\d]{2,63}$/.test(a2.hostname) && (a2.hostname = a2.hostname.replace(/^www\./, ""))), Array.isArray(t3.removeQueryParameters))
            for (let e4 of [...a2.searchParams.keys()]) i(e4, t3.removeQueryParameters) && a2.searchParams.delete(e4);
          if (Array.isArray(t3.keepQueryParameters) || true !== t3.removeQueryParameters || (a2.search = ""), Array.isArray(t3.keepQueryParameters) && t3.keepQueryParameters.length > 0)
            for (let e4 of [...a2.searchParams.keys()]) i(e4, t3.keepQueryParameters) || a2.searchParams.delete(e4);
          if (t3.sortQueryParameters) {
            a2.searchParams.sort();
            try {
              a2.search = decodeURIComponent(a2.search);
            } catch {
            }
          }
          t3.removeTrailingSlash && (a2.pathname = a2.pathname.replace(/\/$/, "")), t3.removeExplicitPort && a2.port && (a2.port = "");
          let o2 = e3;
          return e3 = a2.toString(), t3.removeSingleSlash || "/" !== a2.pathname || o2.endsWith("/") || "" !== a2.hash || (e3 = e3.replace(/\/$/, "")), (t3.removeTrailingSlash || "/" === a2.pathname) && "" === a2.hash && t3.removeSingleSlash && (e3 = e3.replace(/\/$/, "")), r3 && !t3.normalizeProtocol && (e3 = e3.replace(/^http:\/\//, "//")), t3.stripProtocol && (e3 = e3.replace(/^(?:https?:)?\/\//, "")), e3;
        })("".concat(d.origin, "/").concat(f));
        return (0, c.useEffect)(() => {
          s2.remove(p.cYZ.YmUid);
          let e3 = window.location.hash;
          window.location.hash = "";
          try {
            if (e3.length) {
              let r3 = ((e4) => (e4.startsWith("#") && (e4 = e4.slice(1)), e4.split("&").reduce((e5, t3) => {
                let [r4 = "", a3 = ""] = t3.split("=");
                return e5[r4] = a3, e5;
              }, {})))(e3);
              if (r3.expires_in && r3.access_token && r3.state) {
                var a2;
                null == (a2 = t2.setToken) || a2.call(t2, { expiresIn: parseInt(r3.expires_in, 10), token: r3.access_token, state: r3.state });
              } else
                throw new o.t("No OAuth-token in URL returned by OAuth-service", { code: "E_OAUTH_PAGE_NO_TOKEN" });
            }
          } catch (t3) {
            let e4 = new o.t("Error on OAuth page", { code: "E_OAUTH_PAGE", cause: (0, h.createObjectFromError)(t3) });
            r2.error(e4);
          }
          (0, n.redirect)(y);
        }, [y, t2, r2, e2, s2]), (0, a.jsx)(m.JR, {});
      });
    }
  },
  (e) => {
    e.O(
      0,
      [2685, 7956, 5355, 1023, 1311, 7764, 6706, 5148, 3005, 4125, 585, 5843, 3290, 7358],
      () => e(e.s = 68946)
    ), _N_E = e.O();
  }
]);
