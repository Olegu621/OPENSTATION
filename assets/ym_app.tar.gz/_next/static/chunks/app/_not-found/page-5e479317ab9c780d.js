(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [9492],
  {
    32526: (e, t, l) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "HTTPAccessErrorFallback", {
        enumerable: true,
        get: function() {
          return o;
        }
      });
      let r = l(54486), n = l(96129);
      function o(e2) {
        let { status: t2, message: l2 } = e2;
        return (0, r.jsxs)(r.Fragment, {
          children: [
            (0, r.jsx)("title", { children: t2 + ": " + l2 }),
            (0, r.jsx)("div", {
              style: n.styles.error,
              children: (0, r.jsxs)("div", {
                children: [
                  (0, r.jsx)("style", {
                    dangerouslySetInnerHTML: {
                      __html: "body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"
                    }
                  }),
                  (0, r.jsx)("h1", { className: "next-error-h1", style: n.styles.h1, children: t2 }),
                  (0, r.jsx)("div", {
                    style: n.styles.desc,
                    children: (0, r.jsx)("h2", { style: n.styles.h2, children: l2 })
                  })
                ]
              })
            })
          ]
        });
      }
      ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", { value: true }), Object.assign(t.default, t), e.exports = t.default);
    },
    58392: (e, t, l) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "default", {
        enumerable: true,
        get: function() {
          return o;
        }
      });
      let r = l(54486), n = l(32526), o = function() {
        return (0, r.jsx)("html", {
          children: (0, r.jsx)("body", {
            children: (0, r.jsx)(n.HTTPAccessErrorFallback, {
              status: 404,
              message: "This page could not be found."
            })
          })
        });
      };
      ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", { value: true }), Object.assign(t.default, t), e.exports = t.default);
    },
    75358: (e, t, l) => {
      (window.__NEXT_P = window.__NEXT_P || []).push([
        "/_not-found/page",
        function() {
          return l(58392);
        }
      ]);
    },
    96129: (e, t) => {
      "use strict";
      Object.defineProperty(t, "__esModule", { value: true }), Object.defineProperty(t, "styles", {
        enumerable: true,
        get: function() {
          return l;
        }
      });
      let l = {
        error: {
          fontFamily: 'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',
          height: "100vh",
          textAlign: "center",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center"
        },
        desc: { display: "inline-block" },
        h1: {
          display: "inline-block",
          margin: "0 20px 0 0",
          padding: "0 23px 0 0",
          fontSize: 24,
          fontWeight: 500,
          verticalAlign: "top",
          lineHeight: "49px"
        },
        h2: { fontSize: 14, fontWeight: 400, lineHeight: "49px", margin: 0 }
      };
      ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", { value: true }), Object.assign(t.default, t), e.exports = t.default);
    }
  },
  (e) => {
    e.O(0, [5843, 3290, 7358], () => e(e.s = 75358)), _N_E = e.O();
  }
]);
