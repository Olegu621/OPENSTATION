(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [4219],
  {
    18258: (e, o, s) => {
      "use strict";
      s.d(o, { r: () => n });
      var t = s(96559), r = s(86622), i = s(91927);
      class n extends i.q {
        info(e2, o2) {
          this.maxLogLevel >= r.c.INFO && this.logToConsole(r.c.INFO, e2, o2);
        }
        debug(e2, o2) {
          this.maxLogLevel >= r.c.DEBUG && this.logToConsole(r.c.DEBUG, e2, o2);
        }
        trace(e2, o2) {
          this.maxLogLevel >= r.c.TRACE && this.logToConsole(r.c.TRACE, e2, o2);
        }
        warn(e2, o2) {
          this.maxLogLevel >= r.c.WARNING && this.logToConsole(r.c.WARNING, e2, o2), this.sendToErrorBooster(r.c.WARNING, e2, o2);
        }
        error(e2, o2) {
          this.maxLogLevel >= r.c.ERROR && this.logToConsole(r.c.ERROR, e2, o2), this.sendToErrorBooster(r.c.ERROR, e2, o2);
        }
        log(e2, o2) {
          this.logToConsole(r.c.INFO, e2, o2);
        }
        logToConsole(e2, o2, s2) {
          if (this.disableLogToConsole) return;
          let t2 = r.Q[e2];
          console[t2](...this.formatMessage(e2, o2, s2));
        }
        sendToErrorBooster(e2, o2, s2) {
          window.Ya.Rum.logError({
            message: o2,
            level: e2,
            additional: { data: s2 ? this.obfuscateData({ ...this.additionalData, ...s2 }) : {} }
          });
        }
        constructor(e2) {
          super(e2), (0, t._)(this, "disableLogToConsole", void 0), this.disableLogToConsole = e2.disableLogToConsole;
        }
      }
    },
    34965: (e, o, s) => {
      "use strict";
      s.d(o, { cm: () => t.c });
      var t = s(86622);
      s(91927);
    },
    46175: (e, o) => {
      (e.exports = function(e2, o2, t, r) {
        return JSON.stringify(e2, s(o2, r), t);
      }).getSerialize = s;
      function s(e2, o2) {
        var s2 = [], t = [];
        return null == o2 && (o2 = function(e3, o3) {
          return s2[0] === o3 ? "[Circular ~]" : "[Circular ~." + t.slice(0, s2.indexOf(o3)).join(".") + "]";
        }), function(r, i) {
          if (s2.length > 0) {
            var n = s2.indexOf(this);
            ~n ? s2.splice(n + 1) : s2.push(this), ~n ? t.splice(n, 1 / 0, r) : t.push(r), ~s2.indexOf(i) && (i = o2.call(this, r, i));
          } else s2.push(i);
          return null == e2 ? i : e2.call(this, r, i);
        };
      }
    },
    66919: (e, o, s) => {
      "use strict";
      s.r(o), s.d(o, { default: () => d });
      var t = s(54486), r = s(61910), i = s(34965), n = s(18258), l = s(74125);
      s(67270);
      var a = s(49124);
      let c = new n.r({ maxLogLevel: i.cm.DEBUG, secureFields: l.xWh, disableLogToConsole: true });
      function d(e2) {
        let { error: o2 } = e2, s2 = a.env.ASSET_PREFIX || "";
        return (0, r.useEffect)(() => {
          c.error("[Desktop application fatal error] ".concat(o2.message), { additional: o2, type: "error-boundary" });
        }, [o2]), (0, t.jsxs)("html", {
          children: [
            (0, t.jsxs)("head", {
              children: [
                (0, t.jsx)("link", {
                  rel: "preload",
                  as: "font",
                  href: "".concat(s2, "/fonts/YSText-Regular.woff2"),
                  type: "font/woff2",
                  crossOrigin: ""
                }),
                (0, t.jsx)("link", {
                  rel: "preload",
                  as: "font",
                  href: "".concat(s2, "/fonts/YSText-Medium.woff2"),
                  type: "font/woff2",
                  crossOrigin: ""
                }),
                (0, t.jsx)("link", {
                  rel: "preload",
                  as: "font",
                  href: "".concat(s2, "/fonts/YSText-Bold.woff2"),
                  type: "font/woff2",
                  crossOrigin: ""
                }),
                (0, t.jsx)("link", {
                  rel: "preload",
                  as: "font",
                  href: "".concat(s2, "/fonts/YSMusic-HeadlineBold.woff2"),
                  type: "font/woff2",
                  crossOrigin: ""
                }),
                (0, t.jsx)("link", { rel: "stylesheet", href: "".concat(s2, "/styles/fonts.css") })
              ]
            }),
            (0, t.jsx)("body", {
              className: "ym-font-music",
              children: (0, t.jsx)("div", {
                style: {
                  display: "grid",
                  placeItems: "center",
                  height: "100dvh",
                  textAlign: "center",
                  margin: "0.5rem"
                },
                children: "«Application error: a client-side exception has occurred (see the browser console for more information)»"
              })
            })
          ]
        });
      }
    },
    67270: () => {
    },
    81873: (e, o, s) => {
      Promise.resolve().then(s.bind(s, 66919));
    },
    86622: (e, o, s) => {
      "use strict";
      var t;
      s.d(o, { Q: () => r, c: () => t }), (function(e2) {
        e2[e2.ERROR = 10] = "ERROR", e2[e2.WARNING = 20] = "WARNING", e2[e2.INFO = 30] = "INFO", e2[e2.DEBUG = 40] = "DEBUG", e2[e2.TRACE = 50] = "TRACE";
      })(t || (t = {}));
      let r = { [t.ERROR]: "error", [t.WARNING]: "warn", [t.INFO]: "info", [t.DEBUG]: "debug", [t.TRACE]: "trace" };
    },
    91927: (e, o, s) => {
      "use strict";
      s.d(o, { q: () => c });
      var t = s(96559), r = s(46175), i = s(59955), n = s(21863), l = s(98388);
      let a = () => "SECRET";
      class c {
        formatMessage(e2, o2) {
          let s2, t2 = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, i2 = arguments.length > 3 ? arguments[3] : void 0, n2 = String(o2 instanceof Error && o2.stack ? o2.stack : o2), a2 = (0, l.A)({ ...this.additionalData, ...t2 });
          return (Object.keys(a2).length && (s2 = this.obfuscateData(a2)), i2) ? "".concat(n2, " ").concat(r(s2)) : [n2, s2];
        }
        obfuscateData(e2) {
          var o2;
          if (null == (o2 = this.secureFields) ? void 0 : o2.length)
            for (let o3 of this.secureFields) void 0 !== (0, i.A)(e2, o3) && (0, n.A)(e2, o3, a());
          return e2;
        }
        constructor({ additionalData: e2, maxLogLevel: o2, secureFields: s2 }) {
          (0, t._)(this, "maxLogLevel", void 0), (0, t._)(this, "secureFields", void 0), (0, t._)(this, "additionalData", void 0), this.maxLogLevel = o2, this.secureFields = s2, this.additionalData = e2;
        }
      }
    }
  },
  (e) => {
    e.O(0, [2685, 7229, 6374, 2025, 1311, 7764, 6706, 5148, 4125, 5843, 3290, 7358], () => e(e.s = 81873)), _N_E = e.O();
  }
]);
