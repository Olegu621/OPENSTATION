"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [1311],
  {
    93064: (e, t, r) => {
      r.d(t, {
        L3: () => ez,
        Nh: () => P,
        Yo: () => S,
        Zn: () => j,
        _$: () => T,
        _n: () => A,
        dV: () => O,
        gK: () => tT,
        o8: () => _,
        wg: () => E,
        zr: () => I
      });
      var n, i, a, o, l, u, c, s, p = r(63930), f = r(49124);
      !(function(e10) {
        e10.afterCreate = "afterCreate", e10.afterAttach = "afterAttach", e10.afterCreationFinalization = "afterCreationFinalization", e10.beforeDetach = "beforeDetach", e10.beforeDestroy = "beforeDestroy";
      })(n || (n = {}));
      var b = function(e10, t2) {
        return (b = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(e11, t3) {
          e11.__proto__ = t3;
        } || function(e11, t3) {
          for (var r2 in t3) Object.prototype.hasOwnProperty.call(t3, r2) && (e11[r2] = t3[r2]);
        })(e10, t2);
      };
      function h(e10, t2) {
        if ("function" != typeof t2 && null !== t2)
          throw TypeError("Class extends value " + String(t2) + " is not a constructor or null");
        function r2() {
          this.constructor = e10;
        }
        b(e10, t2), e10.prototype = null === t2 ? Object.create(t2) : (r2.prototype = t2.prototype, new r2());
      }
      var d = function() {
        return (d = Object.assign || function(e10) {
          for (var t2, r2 = 1, n2 = arguments.length; r2 < n2; r2++)
            for (var i2 in t2 = arguments[r2]) Object.prototype.hasOwnProperty.call(t2, i2) && (e10[i2] = t2[i2]);
          return e10;
        }).apply(this, arguments);
      };
      function y(e10) {
        var t2 = "function" == typeof Symbol && Symbol.iterator, r2 = t2 && e10[t2], n2 = 0;
        if (r2) return r2.call(e10);
        if (e10 && "number" == typeof e10.length)
          return {
            next: function() {
              return e10 && n2 >= e10.length && (e10 = void 0), { value: e10 && e10[n2++], done: !e10 };
            }
          };
        throw TypeError(t2 ? "Object is not iterable." : "Symbol.iterator is not defined.");
      }
      function v(e10, t2) {
        var r2 = "function" == typeof Symbol && e10[Symbol.iterator];
        if (!r2) return e10;
        var n2, i2, a2 = r2.call(e10), o2 = [];
        try {
          for (; (void 0 === t2 || t2-- > 0) && !(n2 = a2.next()).done; ) o2.push(n2.value);
        } catch (e11) {
          i2 = { error: e11 };
        } finally {
          try {
            n2 && !n2.done && (r2 = a2.return) && r2.call(a2);
          } finally {
            if (i2) throw i2.error;
          }
        }
        return o2;
      }
      function g(e10, t2, r2) {
        if (r2 || 2 == arguments.length)
          for (var n2, i2 = 0, a2 = t2.length; i2 < a2; i2++)
            !n2 && i2 in t2 || (n2 || (n2 = Array.prototype.slice.call(t2, 0, i2)), n2[i2] = t2[i2]);
        return e10.concat(n2 || Array.prototype.slice.call(t2));
      }
      function m(e10) {
        return ei(e10, 1), ea(e10).type;
      }
      function w(e10, t2) {
        ei(e10, 1), eV(
          t2,
          function(e11) {
            return "object" == typeof e11;
          },
          "object or array",
          2
        ), ea(e10).applyPatches(ev(t2));
      }
      function P(e10, t2) {
        return ei(e10, 1), ea(e10).applySnapshot(t2);
      }
      function O(e10, t2) {
        void 0 === t2 && (t2 = true), ei(e10, 1);
        var r2 = ea(e10);
        return t2 ? r2.snapshot : eP(r2.type.getSnapshot(r2, false));
      }
      function j(e10) {
        return ei(e10, 1), ea(e10).root.storedValue;
      }
      function _(e10, t2) {
        void 0 === t2 && (t2 = true), ei(e10, 1);
        var r2 = ea(e10);
        return r2.type.create(r2.snapshot, true === t2 ? r2.root.environment : false === t2 ? void 0 : t2);
      }
      function S(e10) {
        return ei(e10, 1), ea(e10).detach(), e10;
      }
      function I(e10) {
        ei(e10, 1);
        var t2 = ea(e10);
        t2.isRoot ? t2.die() : t2.parent.removeChild(t2.subpath);
      }
      function A(e10) {
        return ei(e10, 1), ea(e10).observableIsAlive;
      }
      function T(e10) {
        ei(e10, 1);
        var t2 = ea(e10), r2 = t2.root.environment;
        if (!r2) throw new eb("Failed to find the environment of ".concat(t2, " ").concat(t2.path));
        return r2;
      }
      function E(e10) {
        return e10;
      }
      "function" == typeof SuppressedError && SuppressedError;
      var C = (function() {
        function e10(e11, t2, r2, n2) {
          Object.defineProperty(this, "type", { enumerable: true, configurable: true, writable: true, value: e11 }), Object.defineProperty(this, "environment", { enumerable: true, configurable: true, writable: true, value: n2 }), Object.defineProperty(this, "_escapedSubpath", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "_subpath", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "_subpathUponDeath", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "_pathUponDeath", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "storedValue", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "aliveAtom", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "_state", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: c.INITIALIZING
          }), Object.defineProperty(this, "_hookSubscribers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "_parent", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "pathAtom", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), this.environment = n2, this.baseSetParent(t2, r2);
        }
        return Object.defineProperty(e10.prototype, "subpath", {
          get: function() {
            return this._subpath;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "subpathUponDeath", {
          get: function() {
            return this._subpathUponDeath;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "pathUponDeath", {
          get: function() {
            return this._pathUponDeath;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "value", {
          get: function() {
            return this.type.getValue(this);
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "state", {
          get: function() {
            return this._state;
          },
          set: function(e11) {
            var t2 = this.isAlive;
            this._state = e11;
            var r2 = this.isAlive;
            this.aliveAtom && t2 !== r2 && this.aliveAtom.reportChanged();
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "fireInternalHook", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this._hookSubscribers && this._hookSubscribers.emit(e11, this, e11);
          }
        }), Object.defineProperty(e10.prototype, "registerHook", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            return this._hookSubscribers || (this._hookSubscribers = new eA()), this._hookSubscribers.register(e11, t2);
          }
        }), Object.defineProperty(e10.prototype, "parent", {
          get: function() {
            return this._parent;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "getReconciliationType", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.type;
          }
        }), Object.defineProperty(e10.prototype, "baseSetParent", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            this._parent = e11, this._subpath = t2, this._escapedSubpath = void 0, this.pathAtom && this.pathAtom.reportChanged();
          }
        }), Object.defineProperty(e10.prototype, "path", {
          get: function() {
            return this.getEscapedPath(true);
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "getEscapedPath", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return (e11 && (this.pathAtom || (this.pathAtom = (0, p.MN)("path")), this.pathAtom.reportObserved()), this.parent) ? (void 0 === this._escapedSubpath && (this._escapedSubpath = this._subpath ? eR(this._subpath) : ""), this.parent.getEscapedPath(e11) + "/" + this._escapedSubpath) : "";
          }
        }), Object.defineProperty(e10.prototype, "isRoot", {
          get: function() {
            return null === this.parent;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "isAlive", {
          get: function() {
            return this.state !== c.DEAD;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "isDetaching", {
          get: function() {
            return this.state === c.DETACHING;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "observableIsAlive", {
          get: function() {
            return this.aliveAtom || (this.aliveAtom = (0, p.MN)("alive")), this.aliveAtom.reportObserved(), this.isAlive;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "baseFinalizeCreation", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            0;
            if (this.state === c.CREATED) {
              if (this.parent) {
                if (this.parent.state !== c.FINALIZED) return;
                this.fireHook(n.afterAttach);
              }
              this.state = c.FINALIZED, e11 && e11();
            }
          }
        }), Object.defineProperty(e10.prototype, "baseFinalizeDeath", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this._hookSubscribers && this._hookSubscribers.clearAll(), this._subpathUponDeath = this._subpath, this._pathUponDeath = this.getEscapedPath(false), this.baseSetParent(null, ""), this.state = c.DEAD;
          }
        }), Object.defineProperty(e10.prototype, "baseAboutToDie", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.fireHook(n.beforeDestroy);
          }
        }), e10;
      })(), N = (function(e10) {
        function t2(t3, r2, n2, i2, a2) {
          var o2 = e10.call(this, t3, r2, n2, i2) || this;
          try {
            o2.storedValue = t3.createNewInstance(a2);
          } catch (e11) {
            throw o2.state = c.DEAD, e11;
          }
          return o2.state = c.CREATED, o2.finalizeCreation(), o2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "root", {
          get: function() {
            if (!this.parent) throw new eb("This scalar node is not part of a tree");
            return this.parent.root;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "setParent", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this.parent !== e11, n2 = this.subpath !== t3;
            if (r2 || n2) {
              0;
              this.environment = void 0, this.baseSetParent(this.parent, t3);
            }
          }
        }), Object.defineProperty(t2.prototype, "snapshot", {
          get: function() {
            return eP(this.getSnapshot());
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.type.getSnapshot(this);
          }
        }), Object.defineProperty(t2.prototype, "toString", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = (this.isAlive ? this.path : this.pathUponDeath) || "<root>";
            return "".concat(this.type.name, "@").concat(e11).concat(this.isAlive ? "" : " [dead]");
          }
        }), Object.defineProperty(t2.prototype, "die", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.isAlive && this.state !== c.DETACHING && (this.aboutToDie(), this.finalizeDeath());
          }
        }), Object.defineProperty(t2.prototype, "finalizeCreation", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.baseFinalizeCreation();
          }
        }), Object.defineProperty(t2.prototype, "aboutToDie", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.baseAboutToDie();
          }
        }), Object.defineProperty(t2.prototype, "finalizeDeath", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.baseFinalizeDeath();
          }
        }), Object.defineProperty(t2.prototype, "fireHook", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this.fireInternalHook(e11);
          }
        }), t2;
      })(C);
      N.prototype.die = (0, p.XI)(N.prototype.die);
      var V = 1;
      !(function(e10) {
        e10[e10.UNINITIALIZED = 0] = "UNINITIALIZED", e10[e10.CREATING = 1] = "CREATING", e10[e10.CREATED = 2] = "CREATED";
      })(i || (i = {})), (function(e10) {
        e10.Dispose = "dispose", e10.Patch = "patch", e10.Snapshot = "snapshot";
      })(a || (a = {}));
      var D = {
        onError: function(e10) {
          throw e10;
        }
      }, x = (function(e10) {
        function t2(t3, r2, n2, a2, o2) {
          var l2 = e10.call(this, t3, r2, n2, a2) || this;
          if (Object.defineProperty(l2, "nodeId", { enumerable: true, configurable: true, writable: true, value: ++V }), Object.defineProperty(l2, "identifierAttribute", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "identifier", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(l2, "unnormalizedIdentifier", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "identifierCache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "isProtectionEnabled", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: true
          }), Object.defineProperty(l2, "middlewares", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "hasSnapshotPostProcessor", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
          }), Object.defineProperty(l2, "_applyPatches", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "_applySnapshot", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "_autoUnbox", { enumerable: true, configurable: true, writable: true, value: true }), Object.defineProperty(l2, "_isRunningAction", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
          }), Object.defineProperty(l2, "_hasSnapshotReaction", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
          }), Object.defineProperty(l2, "_observableInstanceState", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: i.UNINITIALIZED
          }), Object.defineProperty(l2, "_childNodes", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "_initialSnapshot", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "_cachedInitialSnapshot", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "_cachedInitialSnapshotCreated", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: false
          }), Object.defineProperty(l2, "_snapshotComputed", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "_snapshotUponDeath", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(l2, "_internalEvents", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), l2._snapshotComputed = (0, p.EW)(function() {
            return eP(l2.getSnapshot());
          }), l2.unbox = l2.unbox.bind(l2), l2._initialSnapshot = eP(o2), l2.identifierAttribute = t3.identifierAttribute, r2 || (l2.identifierCache = new ee()), l2._childNodes = t3.initializeChildNodes(l2, l2._initialSnapshot), l2.identifier = null, l2.unnormalizedIdentifier = null, l2.identifierAttribute && l2._initialSnapshot) {
            var u2 = l2._initialSnapshot[l2.identifierAttribute];
            if (void 0 === u2) {
              var c2 = l2._childNodes[l2.identifierAttribute];
              c2 && (u2 = c2.value);
            }
            if ("string" != typeof u2 && "number" != typeof u2)
              throw new eb(
                "Instance identifier '".concat(l2.identifierAttribute, "' for type '").concat(l2.type.name, "' must be a string or a number")
              );
            l2.identifier = "" + u2, l2.unnormalizedIdentifier = u2;
          }
          return r2 ? r2.root.identifierCache.addNodeToCache(l2) : l2.identifierCache.addNodeToCache(l2), l2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "applyPatches", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this.createObservableInstanceIfNeeded(), this._applyPatches(e11);
          }
        }), Object.defineProperty(t2.prototype, "applySnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this.createObservableInstanceIfNeeded(), this._applySnapshot(e11);
          }
        }), Object.defineProperty(t2.prototype, "createObservableInstanceIfNeeded", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            void 0 === e11 && (e11 = true), this._observableInstanceState === i.UNINITIALIZED && this.createObservableInstance(e11);
          }
        }), Object.defineProperty(t2.prototype, "createObservableInstance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            void 0 === e11 && (e11 = true), 0;
            this._observableInstanceState = i.CREATING;
            for (var t3, r2, a2, o2, l2 = [], u2 = this.parent; u2 && u2._observableInstanceState === i.UNINITIALIZED; )
              l2.unshift(u2), u2 = u2.parent;
            try {
              for (var s2 = y(l2), p2 = s2.next(); !p2.done; p2 = s2.next()) {
                var f2 = p2.value;
                f2.createObservableInstanceIfNeeded(false);
              }
            } catch (e12) {
              t3 = { error: e12 };
            } finally {
              try {
                p2 && !p2.done && (r2 = s2.return) && r2.call(s2);
              } finally {
                if (t3) throw t3.error;
              }
            }
            var b2 = this.type;
            try {
              this.storedValue = b2.createNewInstance(this._childNodes), this.preboot(), this._isRunningAction = true, b2.finalizeNewInstance(this, this.storedValue);
            } catch (e12) {
              throw this.state = c.DEAD, e12;
            } finally {
              this._isRunningAction = false;
            }
            if (this._observableInstanceState = i.CREATED, this._snapshotComputed.trackAndCompute(), this.isRoot && this._addSnapshotReaction(), this._childNodes = ep, this.state = c.CREATED, e11) {
              this.fireHook(n.afterCreate), this.finalizeCreation();
              try {
                for (var h2 = y(l2.reverse()), d2 = h2.next(); !d2.done; d2 = h2.next()) {
                  var f2 = d2.value;
                  f2.fireHook(n.afterCreate), f2.finalizeCreation();
                }
              } catch (e12) {
                a2 = { error: e12 };
              } finally {
                try {
                  d2 && !d2.done && (o2 = h2.return) && o2.call(h2);
                } finally {
                  if (a2) throw a2.error;
                }
              }
            }
          }
        }), Object.defineProperty(t2.prototype, "root", {
          get: function() {
            var e11 = this.parent;
            return e11 ? e11.root : this;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "clearParent", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            if (this.parent) {
              this.fireHook(n.beforeDetach);
              var e11 = this.state;
              this.state = c.DETACHING;
              var t3 = this.root, r2 = t3.environment, i2 = t3.identifierCache.splitCache(this);
              try {
                this.parent.removeChild(this.subpath), this.baseSetParent(null, ""), this.environment = r2, this.identifierCache = i2;
              } finally {
                this.state = e11;
              }
            }
          }
        }), Object.defineProperty(t2.prototype, "setParent", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = e11 !== this.parent, i2 = t3 !== this.subpath;
            if (r2 || i2) {
              0;
              r2 ? (this.environment = void 0, e11.root.identifierCache.mergeCache(this), this.baseSetParent(e11, t3), this.fireHook(n.afterAttach)) : i2 && this.baseSetParent(this.parent, t3);
            }
          }
        }), Object.defineProperty(t2.prototype, "fireHook", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this;
            this.fireInternalHook(e11);
            var r2 = this.storedValue && "object" == typeof this.storedValue && this.storedValue[e11];
            "function" == typeof r2 && (p._t ? (0, p._t)(function() {
              r2.apply(t3.storedValue);
            }) : r2.apply(this.storedValue));
          }
        }), Object.defineProperty(t2.prototype, "snapshot", {
          get: function() {
            return this.hasSnapshotPostProcessor && this.createObservableInstanceIfNeeded(), this._snapshotComputed.get();
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.isAlive ? this._observableInstanceState === i.CREATED ? this._getActualSnapshot() : this._getCachedInitialSnapshot() : this._snapshotUponDeath;
          }
        }), Object.defineProperty(t2.prototype, "_getActualSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.type.getSnapshot(this);
          }
        }), Object.defineProperty(t2.prototype, "_getCachedInitialSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            if (!this._cachedInitialSnapshotCreated) {
              var e11 = this.type, t3 = this._childNodes, r2 = this._initialSnapshot;
              this._cachedInitialSnapshot = e11.processInitialSnapshot(t3, r2), this._cachedInitialSnapshotCreated = true;
            }
            return this._cachedInitialSnapshot;
          }
        }), Object.defineProperty(t2.prototype, "isRunningAction", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return !!this._isRunningAction || !this.isRoot && this.parent.isRunningAction();
          }
        }), Object.defineProperty(t2.prototype, "assertAlive", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (!this.isAlive) {
              var t3 = this._getAssertAliveError(e11);
              eN(t3);
            }
          }
        }), Object.defineProperty(t2.prototype, "_getAssertAliveError", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this.getEscapedPath(false) || this.pathUponDeath || "", r2 = e11.subpath && eR(e11.subpath) || "", n2 = e11.actionContext || u;
            n2 && "action" !== n2.type && n2.parentActionEvent && (n2 = n2.parentActionEvent);
            var i2 = "";
            if (n2 && null != n2.name) {
              var a2, o2 = n2 && n2.context && (ei(a2 = n2.context, 1), ea(a2).path) || t3;
              i2 = "".concat(o2, ".").concat(n2.name, "()");
            }
            return "You are trying to read or write to an object that is no longer part of a state tree. (Object type: '".concat(this.type.name, "', Path upon death: '").concat(t3, "', Subpath: '").concat(r2, "', Action: '").concat(
              i2,
              "'). Either detach nodes first, or don't use objects after removing / replacing them in the tree."
            );
          }
        }), Object.defineProperty(t2.prototype, "getChildNode", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this.assertAlive({ subpath: e11 }), this._autoUnbox = false;
            try {
              return this._observableInstanceState === i.CREATED ? this.type.getChildNode(this, e11) : this._childNodes[e11];
            } finally {
              this._autoUnbox = true;
            }
          }
        }), Object.defineProperty(t2.prototype, "getChildren", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.assertAlive(ep), this._autoUnbox = false;
            try {
              return this._observableInstanceState === i.CREATED ? this.type.getChildren(this) : eu(this._childNodes);
            } finally {
              this._autoUnbox = true;
            }
          }
        }), Object.defineProperty(t2.prototype, "getChildType", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this.type.getChildType(e11);
          }
        }), Object.defineProperty(t2.prototype, "isProtected", {
          get: function() {
            return this.root.isProtectionEnabled;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "assertWritable", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (this.assertAlive(e11), !this.isRunningAction() && this.isProtected)
              throw new eb(
                "Cannot modify '".concat(
                  this,
                  "', the object is protected and can only be modified by using an action."
                )
              );
          }
        }), Object.defineProperty(t2.prototype, "removeChild", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this.type.removeChild(this, e11);
          }
        }), Object.defineProperty(t2.prototype, "unbox", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11 ? (this.assertAlive({ subpath: e11.subpath || e11.subpathUponDeath }), this._autoUnbox ? e11.value : e11) : e11;
          }
        }), Object.defineProperty(t2.prototype, "toString", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = (this.isAlive ? this.path : this.pathUponDeath) || "<root>", t3 = this.identifier ? "(id: ".concat(this.identifier, ")") : "";
            return "".concat(this.type.name, "@").concat(e11).concat(t3).concat(this.isAlive ? "" : " [dead]");
          }
        }), Object.defineProperty(t2.prototype, "finalizeCreation", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = this;
            this.baseFinalizeCreation(function() {
              var t3, r2;
              try {
                for (var i2 = y(e11.getChildren()), a2 = i2.next(); !a2.done; a2 = i2.next()) a2.value.finalizeCreation();
              } catch (e12) {
                t3 = { error: e12 };
              } finally {
                try {
                  a2 && !a2.done && (r2 = i2.return) && r2.call(i2);
                } finally {
                  if (t3) throw t3.error;
                }
              }
              e11.fireInternalHook(n.afterCreationFinalization);
            });
          }
        }), Object.defineProperty(t2.prototype, "detach", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            if (!this.isAlive) throw new eb("Error while detaching, node is not alive.");
            this.clearParent();
          }
        }), Object.defineProperty(t2.prototype, "preboot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = this;
            this._applyPatches = G(this.storedValue, "@APPLY_PATCHES", function(t3) {
              t3.forEach(function(t4) {
                if (!t4.path) return void e11.type.applySnapshot(e11, t4.value);
                var r2 = (function(e12) {
                  var t5 = e12.split("/").map(eF);
                  if (!("" === e12 || "." === e12 || ".." === e12 || eE(e12, "/") || eE(e12, "./") || eE(e12, "../")))
                    throw new eb("a json path must be either rooted, empty or relative, but got '".concat(e12, "'"));
                  return "" === t5[0] && t5.shift(), t5;
                })(t4.path);
                (function(e12, t5, r3) {
                  void 0 === r3 && (r3 = true);
                  var n2 = e12;
                  try {
                    for (var i2 = 0; i2 < t5.length; i2++) {
                      var a2 = t5[i2];
                      if (".." === a2) {
                        if (n2 = n2.parent) continue;
                      } else if ("." === a2) continue;
                      else if (n2) {
                        if (n2 instanceof N) {
                          var o2 = n2.value;
                          en(o2) && (n2 = ea(o2));
                        }
                        if (n2 instanceof x && n2.getChildType(a2) && (n2 = n2.getChildNode(a2))) continue;
                      }
                      throw new eb(
                        "Could not resolve '".concat(a2, "' in path '").concat(eH(t5.slice(0, i2)) || "/", "' while resolving '").concat(eH(t5), "'")
                      );
                    }
                  } catch (e13) {
                    if (!r3) return;
                    throw e13;
                  }
                  return n2;
                })(e11, r2.slice(0, -1)).applyPatchLocally(r2[r2.length - 1], t4);
              });
            }), this._applySnapshot = G(this.storedValue, "@APPLY_SNAPSHOT", function(t3) {
              if (t3 !== e11.snapshot) return e11.type.applySnapshot(e11, t3);
            }), eS(this.storedValue, "$treenode", this), eS(this.storedValue, "toJSON", el);
          }
        }), Object.defineProperty(t2.prototype, "die", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.isAlive && this.state !== c.DETACHING && (this.aboutToDie(), this.finalizeDeath());
          }
        }), Object.defineProperty(t2.prototype, "aboutToDie", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this._observableInstanceState !== i.UNINITIALIZED && (this.getChildren().forEach(function(e11) {
              e11.aboutToDie();
            }), this.baseAboutToDie(), this._internalEventsEmit(a.Dispose), this._internalEventsClear(a.Dispose));
          }
        }), Object.defineProperty(t2.prototype, "finalizeDeath", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.getChildren().forEach(function(e12) {
              e12.finalizeDeath();
            }), this.root.identifierCache.notifyDied(this);
            var e11 = this.snapshot;
            this._snapshotUponDeath = e11, this._internalEventsClearAll(), this.baseFinalizeDeath();
          }
        }), Object.defineProperty(t2.prototype, "onSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this._addSnapshotReaction(), this._internalEventsRegister(a.Snapshot, e11);
          }
        }), Object.defineProperty(t2.prototype, "emitSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this._internalEventsEmit(a.Snapshot, e11);
          }
        }), Object.defineProperty(t2.prototype, "onPatch", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this._internalEventsRegister(a.Patch, e11);
          }
        }), Object.defineProperty(t2.prototype, "emitPatch", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            if (this._internalEventsHasSubscribers(a.Patch)) {
              var r2 = t3.path.substr(this.path.length) + (e11.path ? "/" + e11.path : ""), n2 = v(
                (function(e12) {
                  if (!("oldValue" in e12)) throw new eb("Patches without `oldValue` field cannot be inversed");
                  return [
                    (function(e13) {
                      switch (e13.op) {
                        case "add":
                          return { op: "add", path: e13.path, value: e13.value };
                        case "remove":
                          return { op: "remove", path: e13.path };
                        case "replace":
                          return { op: "replace", path: e13.path, value: e13.value };
                      }
                    })(e12),
                    (function(e13) {
                      switch (e13.op) {
                        case "add":
                          return { op: "remove", path: e13.path };
                        case "remove":
                          return { op: "add", path: e13.path, value: e13.oldValue };
                        case "replace":
                          return { op: "replace", path: e13.path, value: e13.oldValue };
                      }
                    })(e12)
                  ];
                })(
                  (function(e12) {
                    for (var t4 = [], r3 = 1; r3 < arguments.length; r3++) t4[r3 - 1] = arguments[r3];
                    for (var n3 = 0; n3 < t4.length; n3++) {
                      var i3 = t4[n3];
                      for (var a2 in i3) e12[a2] = i3[a2];
                    }
                    return e12;
                  })({}, e11, { path: r2 })
                ),
                2
              ), i2 = n2[0], o2 = n2[1];
              this._internalEventsEmit(a.Patch, i2, o2);
            }
            this.parent && this.parent.emitPatch(e11, t3);
          }
        }), Object.defineProperty(t2.prototype, "hasDisposer", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this._internalEventsHas(a.Dispose, e11);
          }
        }), Object.defineProperty(t2.prototype, "addDisposer", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (!this.hasDisposer(e11)) return void this._internalEventsRegister(a.Dispose, e11, true);
            throw new eb("cannot add a disposer when it is already registered for execution");
          }
        }), Object.defineProperty(t2.prototype, "removeDisposer", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (!this._internalEventsHas(a.Dispose, e11))
              throw new eb("cannot remove a disposer which was never registered for execution");
            this._internalEventsUnregister(a.Dispose, e11);
          }
        }), Object.defineProperty(t2.prototype, "removeMiddleware", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (this.middlewares) {
              var t3 = this.middlewares.indexOf(e11);
              t3 >= 0 && this.middlewares.splice(t3, 1);
            }
          }
        }), Object.defineProperty(t2.prototype, "addMiddleWare", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this;
            void 0 === t3 && (t3 = true);
            var n2 = { handler: e11, includeHooks: t3 };
            return this.middlewares ? this.middlewares.push(n2) : this.middlewares = [n2], function() {
              r2.removeMiddleware(n2);
            };
          }
        }), Object.defineProperty(t2.prototype, "applyPatchLocally", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            this.assertWritable({ subpath: e11 }), this.createObservableInstanceIfNeeded(), this.type.applyPatchLocally(this, e11, t3);
          }
        }), Object.defineProperty(t2.prototype, "_addSnapshotReaction", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = this;
            if (!this._hasSnapshotReaction) {
              var t3 = (0, p.mJ)(
                function() {
                  return e11.snapshot;
                },
                function(t4) {
                  return e11.emitSnapshot(t4);
                },
                D
              );
              this.addDisposer(t3), this._hasSnapshotReaction = true;
            }
          }
        }), Object.defineProperty(t2.prototype, "_internalEventsHasSubscribers", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return !!this._internalEvents && this._internalEvents.hasSubscribers(e11);
          }
        }), Object.defineProperty(t2.prototype, "_internalEventsRegister", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2) {
            return void 0 === r2 && (r2 = false), this._internalEvents || (this._internalEvents = new eA()), this._internalEvents.register(e11, t3, r2);
          }
        }), Object.defineProperty(t2.prototype, "_internalEventsHas", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return !!this._internalEvents && this._internalEvents.has(e11, t3);
          }
        }), Object.defineProperty(t2.prototype, "_internalEventsUnregister", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            this._internalEvents && this._internalEvents.unregister(e11, t3);
          }
        }), Object.defineProperty(t2.prototype, "_internalEventsEmit", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            for (var t3, r2 = [], n2 = 1; n2 < arguments.length; n2++) r2[n2 - 1] = arguments[n2];
            this._internalEvents && (t3 = this._internalEvents).emit.apply(t3, g([e11], v(r2), false));
          }
        }), Object.defineProperty(t2.prototype, "_internalEventsClear", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this._internalEvents && this._internalEvents.clear(e11);
          }
        }), Object.defineProperty(t2.prototype, "_internalEventsClearAll", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this._internalEvents && this._internalEvents.clearAll();
          }
        }), t2;
      })(C);
      x.prototype.createObservableInstance = (0, p.XI)(x.prototype.createObservableInstance), x.prototype.detach = (0, p.XI)(x.prototype.detach), x.prototype.die = (0, p.XI)(x.prototype.die), (function(e10) {
        e10[e10.String = 1] = "String", e10[e10.Number = 2] = "Number", e10[e10.Boolean = 4] = "Boolean", e10[e10.Date = 8] = "Date", e10[e10.Literal = 16] = "Literal", e10[e10.Array = 32] = "Array", e10[e10.Map = 64] = "Map", e10[e10.Object = 128] = "Object", e10[e10.Frozen = 256] = "Frozen", e10[e10.Optional = 512] = "Optional", e10[e10.Reference = 1024] = "Reference", e10[e10.Identifier = 2048] = "Identifier", e10[e10.Late = 4096] = "Late", e10[e10.Refinement = 8192] = "Refinement", e10[e10.Union = 16384] = "Union", e10[e10.Null = 32768] = "Null", e10[e10.Undefined = 65536] = "Undefined", e10[e10.Integer = 131072] = "Integer", e10[e10.Custom = 262144] = "Custom", e10[e10.SnapshotProcessor = 524288] = "SnapshotProcessor", e10[e10.Lazy = 1048576] = "Lazy", e10[e10.Finite = 2097152] = "Finite", e10[e10.Float = 4194304] = "Float";
      })(l || (l = {}));
      var k = "cannotDetermine", z = /* @__PURE__ */ Symbol("$type"), R = (function() {
        function e10(e11) {
          Object.defineProperty(this, o, { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "C", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "S", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "T", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "N", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "isType", { enumerable: true, configurable: true, writable: true, value: true }), Object.defineProperty(this, "name", { enumerable: true, configurable: true, writable: true, value: void 0 }), this.name = e11;
        }
        return Object.defineProperty(e10.prototype, "create", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            return q(this, e11), this.instantiate(null, "", t2, e11).value;
          }
        }), Object.defineProperty(e10.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            throw new eb("unimplemented method");
          }
        }), Object.defineProperty(e10.prototype, "isAssignableFrom", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11 === this;
          }
        }), Object.defineProperty(e10.prototype, "validate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            if (eo(e11)) {
              var r2 = m(e11);
              return this.isAssignableFrom(r2) ? es : J(t2, e11);
            }
            return this.isValidSnapshot(e11, t2);
          }
        }), Object.defineProperty(e10.prototype, "is", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return 0 === this.validate(e11, [{ path: "", type: this }]).length;
          }
        }), Object.defineProperty(e10.prototype, "Type", {
          get: function() {
            throw new eb(
              "Factory.Type should not be actually called. It is just a Type signature that can be used at compile time with Typescript, by using `typeof type.Type`"
            );
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "TypeWithoutSTN", {
          get: function() {
            throw new eb(
              "Factory.TypeWithoutSTN should not be actually called. It is just a Type signature that can be used at compile time with Typescript, by using `typeof type.TypeWithoutSTN`"
            );
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "SnapshotType", {
          get: function() {
            throw new eb(
              "Factory.SnapshotType should not be actually called. It is just a Type signature that can be used at compile time with Typescript, by using `typeof type.SnapshotType`"
            );
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "CreationType", {
          get: function() {
            throw new eb(
              "Factory.CreationType should not be actually called. It is just a Type signature that can be used at compile time with Typescript, by using `typeof type.CreationType`"
            );
          },
          enumerable: false,
          configurable: true
        }), e10;
      })();
      o = z, R.prototype.create = (0, p.XI)(R.prototype.create);
      var F = (function(e10) {
        function t2(t3) {
          var r2 = e10.call(this, t3) || this;
          return Object.defineProperty(r2, "identifierAttribute", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), r2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "create", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3, r2) {
            return void 0 === t3 && (t3 = this.getDefaultSnapshot()), e10.prototype.create.call(this, t3, r2);
          }
        }), Object.defineProperty(t2.prototype, "getValue", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11.createObservableInstanceIfNeeded(), e11.storedValue;
          }
        }), Object.defineProperty(t2.prototype, "isMatchingSnapshotId", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return !e11.identifierAttribute || e11.identifier === "" + t3[e11.identifierAttribute];
          }
        }), Object.defineProperty(t2.prototype, "tryToReconcileNode", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return !e11.isDetaching && (!!(e11.snapshot === t3 || en(t3) && ea(t3) === e11) || !!(e11.type === this && em(t3) && !en(t3) && this.isMatchingSnapshotId(e11, t3)) && (e11.applySnapshot(t3), true));
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            if (this.tryToReconcileNode(e11, t3)) return e11.setParent(r2, n2), e11;
            if (e11.die(), en(t3) && this.isAssignableFrom(m(t3))) {
              var i2 = ea(t3);
              return i2.setParent(r2, n2), i2;
            }
            return this.instantiate(r2, n2, void 0, t3);
          }
        }), Object.defineProperty(t2.prototype, "getSubTypes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return null;
          }
        }), t2;
      })(R);
      F.prototype.create = (0, p.XI)(F.prototype.create);
      var H = (function(e10) {
        function t2() {
          return null !== e10 && e10.apply(this, arguments) || this;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "createNewInstance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11;
          }
        }), Object.defineProperty(t2.prototype, "getValue", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11.storedValue;
          }
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11.storedValue;
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            if (!e11.isDetaching && e11.type === this && e11.storedValue === t3) return e11;
            var i2 = this.instantiate(r2, n2, void 0, t3);
            return e11.die(), i2;
          }
        }), Object.defineProperty(t2.prototype, "getSubTypes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return null;
          }
        }), t2;
      })(R);
      function M(e10) {
        return "object" == typeof e10 && e10 && true === e10.isType;
      }
      function L(e10, t2) {
        eV(e10, M, "mobx-state-tree type", t2);
      }
      !(function() {
        function e10(e11, t2) {
          Object.defineProperty(this, "hooks", { enumerable: true, configurable: true, writable: true, value: e11 }), Object.defineProperty(this, "call", { enumerable: true, configurable: true, writable: true, value: t2 }), Object.defineProperty(this, "flowsPending", { enumerable: true, configurable: true, writable: true, value: 0 }), Object.defineProperty(this, "running", { enumerable: true, configurable: true, writable: true, value: true }), e11 && e11.onStart(t2);
        }
        Object.defineProperty(e10.prototype, "finish", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this.running && (this.running = false, this.hooks && this.hooks.onFinish(this.call, e11));
          }
        }), Object.defineProperty(e10.prototype, "incFlowsPending", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.flowsPending++;
          }
        }), Object.defineProperty(e10.prototype, "decFlowsPending", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.flowsPending--;
          }
        }), Object.defineProperty(e10.prototype, "hasFlowsPending", {
          get: function() {
            return this.flowsPending > 0;
          },
          enumerable: false,
          configurable: true
        });
      })();
      var U = 1;
      function Z(e10, t2) {
        var r2 = ea(e10.context);
        "action" === e10.type && r2.assertAlive({ actionContext: e10 });
        var i2 = r2._isRunningAction;
        r2._isRunningAction = true;
        var a2 = u;
        u = e10;
        try {
          var o2 = r2, l2 = e10, c2 = t2, s2 = new $(o2, c2);
          if (s2.isEmpty) return (0, p.XI)(c2).apply(null, l2.args);
          var f2 = null;
          return (function e11(t3) {
            var r3 = s2.getNextMiddleware(), i3 = r3 && r3.handler;
            if (!i3) return (0, p.XI)(c2).apply(null, t3.args);
            if (!r3.includeHooks && n[t3.name]) return e11(t3);
            var a3 = false, o3 = false;
            if (i3(
              t3,
              function(t4, r4) {
                a3 = true, f2 = e11(t4), r4 && (f2 = r4(f2));
              },
              function(e12) {
                o3 = true, f2 = e12;
              }
            ), /* @__PURE__ */ (function() {
              return false;
            })())
              if (a3 || o3) {
                if (a3 && o3) {
                  var l3 = ea(t3.tree);
                  throw new eb(
                    "The next() and abort() callback within the middleware ".concat(i3.name, ' for the action: "').concat(t3.name, '" on the node: ').concat(l3.type.name, " were invoked.")
                  );
                }
              } else {
                var l3 = ea(t3.tree);
                throw new eb(
                  "Neither the next() nor the abort() callback within the middleware ".concat(i3.name, ' for the action: "').concat(t3.name, '" on the node: ').concat(l3.type.name, " was invoked.")
                );
              }
            return f2;
          })(l2);
        } finally {
          u = a2, r2._isRunningAction = i2;
        }
      }
      function W(e10) {
        if (e10) return "action" === e10.type ? e10 : e10.parentActionEvent;
      }
      function G(e10, t2, r2) {
        var n2 = function() {
          var n3 = U++, i2 = u, a2 = W(i2);
          return Z(
            {
              type: "action",
              name: t2,
              id: n3,
              args: eT(arguments),
              context: e10,
              tree: j(e10),
              rootId: i2 ? i2.rootId : n3,
              parentId: i2 ? i2.id : 0,
              allParentIds: i2 ? g(g([], v(i2.allParentIds), false), [i2.id], false) : [],
              parentEvent: i2,
              parentActionEvent: a2
            },
            r2
          );
        };
        return n2._isMSTAction = true, n2._isFlowAction = r2._isFlowAction, n2;
      }
      var $ = (function() {
        function e10(e11, t2) {
          Object.defineProperty(this, "arrayIndex", { enumerable: true, configurable: true, writable: true, value: 0 }), Object.defineProperty(this, "inArrayIndex", { enumerable: true, configurable: true, writable: true, value: 0 }), Object.defineProperty(this, "middlewares", { enumerable: true, configurable: true, writable: true, value: [] }), t2.$mst_middleware && this.middlewares.push(t2.$mst_middleware);
          for (var r2 = e11; r2; ) r2.middlewares && this.middlewares.push(r2.middlewares), r2 = r2.parent;
        }
        return Object.defineProperty(e10.prototype, "isEmpty", {
          get: function() {
            return this.middlewares.length <= 0;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "getNextMiddleware", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = this.middlewares[this.arrayIndex];
            if (e11) {
              var t2 = e11[this.inArrayIndex++];
              return t2 || (this.arrayIndex++, this.inArrayIndex = 0, this.getNextMiddleware());
            }
          }
        }), e10;
      })();
      function X(e10) {
        return "function" == typeof e10 ? "<function".concat(e10.name ? " " + e10.name : "", ">") : en(e10) ? "<".concat(e10, ">") : "`".concat(
          (function(e11) {
            try {
              return JSON.stringify(e11);
            } catch (e12) {
              return "<Unserializable: ".concat(e12, ">");
            }
          })(e10),
          "`"
        );
      }
      function Y(e10) {
        var t2, r2 = e10.value, n2 = e10.context[e10.context.length - 1].type, i2 = e10.context.map(function(e11) {
          return e11.path;
        }).filter(function(e11) {
          return e11.length > 0;
        }).join("/"), a2 = i2.length > 0 ? 'at path "/'.concat(i2, '" ') : "", o2 = en(r2) ? "value of type ".concat(ea(r2).type.name, ":") : ew(r2) ? "value" : "snapshot", u2 = n2 && en(r2) && n2.is(ea(r2).snapshot);
        return "".concat(a2).concat(o2, " ").concat(X(r2), " is not assignable ").concat(n2 ? "to type: `".concat(n2.name, "`") : "") + (e10.message ? " (".concat(e10.message, ")") : "") + (n2 ? M(t2 = n2) && (t2.flags & (l.String | l.Number | l.Integer | l.Boolean | l.Date)) > 0 || ew(r2) ? "." : ", expected an instance of `".concat(n2.name, "` or a snapshot like `").concat(n2.describe(), "` instead.") + (u2 ? " (Note that a snapshot of the provided value is compatible with the targeted type)" : "") : ".");
      }
      function B(e10, t2, r2) {
        return e10.concat([{ path: t2, type: r2 }]);
      }
      function J(e10, t2, r2) {
        return [{ context: e10, value: t2, message: r2 }];
      }
      function K(e10) {
        return e10.reduce(function(e11, t2) {
          return e11.concat(t2);
        }, []);
      }
      function q(e10, t2) {
        (/* @__PURE__ */ (function() {
          return false;
        })() || void 0 !== f && f.env && "true" === f.env.ENABLE_TYPE_CHECK) && (function(e11, t3) {
          var r2 = e11.validate(t3, [{ path: "", type: e11 }]);
          if (r2.length > 0)
            throw new eb(
              (function(e12, t4, r3) {
                if (0 !== r3.length) {
                  var n2;
                  return "Error while converting ".concat(
                    (n2 = X(t4)).length < 280 ? n2 : "".concat(n2.substring(0, 272), "......").concat(n2.substring(n2.length - 8)),
                    " to `"
                  ).concat(e12.name, "`:\n\n    ") + r3.map(Y).join("\n    ");
                }
              })(e11, t3, r2)
            );
        })(e10, t2);
      }
      var Q = 0, ee = (function() {
        function e10() {
          Object.defineProperty(this, "cacheId", { enumerable: true, configurable: true, writable: true, value: Q++ }), Object.defineProperty(this, "cache", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: p.sH.map()
          }), Object.defineProperty(this, "lastCacheModificationPerId", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: p.sH.map()
          });
        }
        return Object.defineProperty(e10.prototype, "updateLastCacheModificationPerId", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t2 = this.lastCacheModificationPerId.get(e11);
            this.lastCacheModificationPerId.set(e11, void 0 === t2 ? 1 : t2 + 1);
          }
        }), Object.defineProperty(e10.prototype, "getLastCacheModificationPerId", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t2 = this.lastCacheModificationPerId.get(e11) || 0;
            return "".concat(this.cacheId, "-").concat(t2);
          }
        }), Object.defineProperty(e10.prototype, "addNodeToCache", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            if (void 0 === t2 && (t2 = true), e11.identifierAttribute) {
              var r2 = e11.identifier;
              this.cache.has(r2) || this.cache.set(r2, p.sH.array([], ef));
              var n2 = this.cache.get(r2);
              if (-1 !== n2.indexOf(e11)) throw new eb("Already registered");
              n2.push(e11), t2 && this.updateLastCacheModificationPerId(r2);
            }
          }
        }), Object.defineProperty(e10.prototype, "mergeCache", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t2 = this;
            (0, p.zu)(e11.identifierCache.cache).forEach(function(e12) {
              return e12.forEach(function(e13) {
                t2.addNodeToCache(e13);
              });
            });
          }
        }), Object.defineProperty(e10.prototype, "notifyDied", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (e11.identifierAttribute) {
              var t2 = e11.identifier, r2 = this.cache.get(t2);
              r2 && (r2.remove(e11), r2.length || this.cache.delete(t2), this.updateLastCacheModificationPerId(e11.identifier));
            }
          }
        }), Object.defineProperty(e10.prototype, "splitCache", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t2) {
            var r2 = this, n2 = new e10(), i2 = t2.path + "/";
            return (0, p.jO)(this.cache).forEach(function(e11) {
              for (var a2 = v(e11, 2), o2 = a2[0], l2 = a2[1], u2 = false, c2 = l2.length - 1; c2 >= 0; c2--) {
                var s2 = l2[c2];
                (s2 === t2 || 0 === s2.path.indexOf(i2)) && (n2.addNodeToCache(s2, false), l2.splice(c2, 1), l2.length || r2.cache.delete(o2), u2 = true);
              }
              u2 && r2.updateLastCacheModificationPerId(o2);
            }), n2;
          }
        }), Object.defineProperty(e10.prototype, "has", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            var r2 = this.cache.get(t2);
            return !!r2 && r2.some(function(t3) {
              return e11.isAssignableFrom(t3.type);
            });
          }
        }), Object.defineProperty(e10.prototype, "resolve", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            var r2 = this.cache.get(t2);
            if (!r2) return null;
            var n2 = r2.filter(function(t3) {
              return e11.isAssignableFrom(t3.type);
            });
            switch (n2.length) {
              case 0:
                return null;
              case 1:
                return n2[0];
              default:
                throw new eb(
                  "Cannot resolve a reference to type '".concat(e11.name, "' with id: '").concat(t2, "' unambigously, there are multiple candidates: ").concat(
                    n2.map(function(e12) {
                      return e12.path;
                    }).join(", ")
                  )
                );
            }
          }
        }), e10;
      })();
      function et(e10, t2, r2, n2, i2) {
        var a2 = eo(i2);
        if (a2) {
          if (a2.parent)
            throw new eb(
              "Cannot add an object to a state tree if it is already part of the same or another state tree. Tried to assign an object to '".concat(t2 ? t2.path : "", "/").concat(r2, "', but it lives already at '").concat(a2.path, "'")
            );
          return t2 && a2.setParent(t2, r2), a2;
        }
        return new x(e10, t2, r2, n2, i2);
      }
      function er(e10, t2, r2, n2, i2) {
        return new N(e10, t2, r2, n2, i2);
      }
      function en(e10) {
        return !!(e10 && e10.$treenode);
      }
      function ei(e10, t2) {
        eV(e10, en, "mobx-state-tree node", t2);
      }
      function ea(e10) {
        if (!en(e10)) throw new eb("Value ".concat(e10, " is no MST Node"));
        return e10.$treenode;
      }
      function eo(e10) {
        return e10 && e10.$treenode || null;
      }
      function el() {
        return ea(this).snapshot;
      }
      function eu(e10) {
        if (!e10) return es;
        var t2 = Object.keys(e10);
        if (!t2.length) return es;
        var r2 = Array(t2.length);
        return t2.forEach(function(t3, n2) {
          r2[n2] = e10[t3];
        }), r2;
      }
      !(function(e10) {
        e10[e10.INITIALIZING = 0] = "INITIALIZING", e10[e10.CREATED = 1] = "CREATED", e10[e10.FINALIZED = 2] = "FINALIZED", e10[e10.DETACHING = 3] = "DETACHING", e10[e10.DEAD = 4] = "DEAD";
      })(c || (c = {}));
      var ec = Object.toString(), es = Object.freeze([]), ep = Object.freeze({}), ef = (0, p.sG)().useProxies ? { deep: false } : { deep: false, proxy: false };
      Object.freeze(ef);
      var eb = (function(e10) {
        function t2(t3) {
          return void 0 === t3 && (t3 = "Illegal state"), e10.call(this, "[mobx-state-tree] ".concat(t3)) || this;
        }
        return h(t2, e10), t2;
      })(Error);
      function eh(e10) {
        return e10;
      }
      var ed = Number.isInteger;
      function ey(e10) {
        return Array.isArray(e10) || (0, p.Fq)(e10);
      }
      function ev(e10) {
        return e10 ? ey(e10) ? e10 : [e10] : es;
      }
      function eg(e10) {
        if (null === e10 || "object" != typeof e10) return false;
        var t2, r2 = Object.getPrototypeOf(e10);
        return null == r2 || (null == (t2 = r2.constructor) ? void 0 : t2.toString()) === ec;
      }
      function em(e10) {
        return null !== e10 && "object" == typeof e10 && !(e10 instanceof Date) && !(e10 instanceof RegExp);
      }
      function ew(e10, t2) {
        return void 0 === t2 && (t2 = true), null == e10 || "string" == typeof e10 || "number" == typeof e10 || "boolean" == typeof e10 || t2 && e10 instanceof Date;
      }
      function eP(e10) {
        return e10;
      }
      function eO(e10) {
        return e10;
      }
      function ej(e10) {
        return "function" != typeof e10;
      }
      function e_(e10, t2, r2) {
        (0, p.OB)(e10) ? (0, p.n8)(e10, t2, r2) : Object.defineProperty(e10, t2, r2);
      }
      function eS(e10, t2, r2) {
        e_(e10, t2, { enumerable: false, writable: false, configurable: true, value: r2 });
      }
      var eI = (function() {
        function e10() {
          Object.defineProperty(this, "handlers", { enumerable: true, configurable: true, writable: true, value: [] });
        }
        return Object.defineProperty(e10.prototype, "hasSubscribers", {
          get: function() {
            return this.handlers.length > 0;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(e10.prototype, "register", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            var r2 = this;
            return void 0 === t2 && (t2 = false), t2 ? this.handlers.unshift(e11) : this.handlers.push(e11), function() {
              r2.unregister(e11);
            };
          }
        }), Object.defineProperty(e10.prototype, "has", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this.handlers.indexOf(e11) >= 0;
          }
        }), Object.defineProperty(e10.prototype, "unregister", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t2 = this.handlers.indexOf(e11);
            t2 >= 0 && this.handlers.splice(t2, 1);
          }
        }), Object.defineProperty(e10.prototype, "clear", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.handlers.length = 0;
          }
        }), Object.defineProperty(e10.prototype, "emit", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            for (var e11 = [], t2 = 0; t2 < arguments.length; t2++) e11[t2] = arguments[t2];
            this.handlers.slice().forEach(function(t3) {
              return t3.apply(void 0, g([], v(e11), false));
            });
          }
        }), e10;
      })(), eA = (function() {
        function e10() {
          Object.defineProperty(this, "eventHandlers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          });
        }
        return Object.defineProperty(e10.prototype, "hasSubscribers", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t2 = this.eventHandlers && this.eventHandlers[e11];
            return !!t2 && t2.hasSubscribers;
          }
        }), Object.defineProperty(e10.prototype, "register", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2, r2) {
            void 0 === r2 && (r2 = false), this.eventHandlers || (this.eventHandlers = {});
            var n2 = this.eventHandlers[e11];
            return n2 || (n2 = this.eventHandlers[e11] = new eI()), n2.register(t2, r2);
          }
        }), Object.defineProperty(e10.prototype, "has", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            var r2 = this.eventHandlers && this.eventHandlers[e11];
            return !!r2 && r2.has(t2);
          }
        }), Object.defineProperty(e10.prototype, "unregister", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t2) {
            var r2 = this.eventHandlers && this.eventHandlers[e11];
            r2 && r2.unregister(t2);
          }
        }), Object.defineProperty(e10.prototype, "clear", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            this.eventHandlers && delete this.eventHandlers[e11];
          }
        }), Object.defineProperty(e10.prototype, "clearAll", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            this.eventHandlers = void 0;
          }
        }), Object.defineProperty(e10.prototype, "emit", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            for (var t2 = [], r2 = 1; r2 < arguments.length; r2++) t2[r2 - 1] = arguments[r2];
            var n2 = this.eventHandlers && this.eventHandlers[e11];
            n2 && n2.emit.apply(n2, g([], v(t2), false));
          }
        }), e10;
      })();
      function eT(e10) {
        for (var t2 = Array(e10.length), r2 = 0; r2 < e10.length; r2++) t2[r2] = e10[r2];
        return t2;
      }
      function eE(e10, t2) {
        return 0 === e10.indexOf(t2);
      }
      var eC = function(e10, t2) {
      };
      function eN(e10) {
        console.warn(Error("[mobx-state-tree] ".concat(e10)));
      }
      function eV(e10, t2, r2, n2) {
      }
      function eD(e10, t2) {
        eV(
          e10,
          function(e11) {
            return "function" == typeof e11;
          },
          "function",
          t2
        );
      }
      function ex(e10, t2, r2) {
        void 0 === r2 && (r2 = true), eV(
          e10,
          function(e11) {
            return "string" == typeof e11;
          },
          "string",
          t2
        ), r2 || eV(
          e10,
          function(e11) {
            return "" !== e11;
          },
          "not empty string",
          t2
        );
      }
      function ek(e10) {
        "function" == typeof queueMicrotask ? queueMicrotask(e10) : "function" == typeof setImmediate ? setImmediate(e10) : setTimeout(e10, 1);
      }
      function ez(e10) {
        var t2, r2, n2;
        return t2 = e10.name, r2 = e10, (n2 = function() {
          var e11 = U++, i2 = u;
          if (!i2) throw new eb("a mst flow must always have a parent context");
          var a2 = W(i2);
          if (!a2) throw new eb("a mst flow must always have a parent action context");
          var o2 = {
            name: t2,
            id: e11,
            tree: i2.tree,
            context: i2.context,
            parentId: i2.id,
            allParentIds: g(g([], v(i2.allParentIds), false), [i2.id], false),
            rootId: i2.rootId,
            parentEvent: i2,
            parentActionEvent: a2
          }, l2 = arguments;
          function c2(e12, t3, r3) {
            return e12.$mst_middleware = n2.$mst_middleware, Z(d(d({}, o2), { type: t3, args: [r3] }), e12);
          }
          return new Promise(function(e12, t3) {
            var i3, a3 = function() {
              i3 = r2.apply(null, arguments), u2(void 0);
            };
            function u2(e13) {
              var r3;
              try {
                var n3 = c2(
                  function(e14) {
                    r3 = i3.next(e14);
                  },
                  "flow_resume",
                  e13
                );
                n3 instanceof Error && (r3 = i3.throw(n3));
              } catch (e14) {
                ek(function() {
                  c2(
                    function(r4) {
                      t3(e14);
                    },
                    "flow_throw",
                    e14
                  );
                });
                return;
              }
              p2(r3);
            }
            function s2(e13) {
              var r3;
              try {
                c2(
                  function(e14) {
                    r3 = i3.throw(e14);
                  },
                  "flow_resume_error",
                  e13
                );
              } catch (e14) {
                ek(function() {
                  c2(
                    function(r4) {
                      t3(e14);
                    },
                    "flow_throw",
                    e14
                  );
                });
                return;
              }
              p2(r3);
            }
            function p2(t4) {
              if (t4.done)
                return void ek(function() {
                  c2(
                    function(t5) {
                      e12(t5);
                    },
                    "flow_return",
                    t4.value
                  );
                });
              if (!t4.value || "function" != typeof t4.value.then)
                throw new eb("Only promises can be yielded to `async`, got: " + t4);
              return t4.value.then(u2, s2);
            }
            a3.$mst_middleware = n2.$mst_middleware, Z(d(d({}, o2), { type: "flow_spawn", args: eT(l2) }), a3);
          });
        })._isFlowAction = true, n2;
      }
      function eR(e10) {
        return true == ("number" == typeof e10) ? "" + e10 : -1 === e10.indexOf("/") && -1 === e10.indexOf("~") ? e10 : e10.replace(/~/g, "~0").replace(/\//g, "~1");
      }
      function eF(e10) {
        return e10.replace(/~1/g, "/").replace(/~0/g, "~");
      }
      function eH(e10) {
        if (0 === e10.length) return "";
        var t2 = function(e11) {
          return e11.map(eR).join("/");
        };
        return "." === e10[0] || ".." === e10[0] ? t2(e10) : "/" + t2(e10);
      }
      eC.ids = {};
      var eM = /* @__PURE__ */ Symbol("$preProcessorFailed"), eL = (function(e10) {
        function t2(t3, r2, n2) {
          var i2 = e10.call(this, n2 || t3.name) || this;
          return Object.defineProperty(i2, "_subtype", { enumerable: true, configurable: true, writable: true, value: t3 }), Object.defineProperty(i2, "_processors", { enumerable: true, configurable: true, writable: true, value: r2 }), i2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "flags", {
          get: function() {
            return this._subtype.flags | l.SnapshotProcessor;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return "snapshotProcessor(".concat(this._subtype.describe(), ")");
          }
        }), Object.defineProperty(t2.prototype, "preProcessSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this._processors.preProcessor ? this._processors.preProcessor.call(null, e11) : e11;
          }
        }), Object.defineProperty(t2.prototype, "preProcessSnapshotSafe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            try {
              return this.preProcessSnapshot(e11);
            } catch (e12) {
              return eM;
            }
          }
        }), Object.defineProperty(t2.prototype, "postProcessSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return this._processors.postProcessor ? this._processors.postProcessor.call(null, e11, t3.storedValue) : e11;
          }
        }), Object.defineProperty(t2.prototype, "_fixNode", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3, r2 = this;
            (function(e12, t4) {
              for (var r3, n3, i2 = [], a2 = 2; a2 < arguments.length; a2++) i2[a2 - 2] = arguments[a2];
              try {
                for (var o2 = y(i2), l2 = o2.next(); !l2.done; l2 = o2.next()) {
                  var u2 = l2.value;
                  e12[u2] = t4[u2].bind(t4);
                }
              } catch (e13) {
                r3 = { error: e13 };
              } finally {
                try {
                  l2 && !l2.done && (n3 = o2.return) && n3.call(o2);
                } finally {
                  if (r3) throw r3.error;
                }
              }
            })(e11.type, this, "create"), e11 instanceof x && (e11.hasSnapshotPostProcessor = !!this._processors.postProcessor);
            var n2 = e11.getSnapshot;
            e11.getSnapshot = function() {
              return r2.postProcessSnapshot(n2.call(e11), e11);
            }, M(t3 = this._subtype) && (t3.flags & l.Union) > 0 || (e11.getReconciliationType = function() {
              return r2;
            });
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = en(n2) ? n2 : this.preProcessSnapshot(n2), a2 = this._subtype.instantiate(e11, t3, r2, i2);
            return this._fixNode(a2), a2;
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = this._subtype.reconcile(e11, en(t3) ? t3 : this.preProcessSnapshot(t3), r2, n2);
            return i2 !== e11 && this._fixNode(i2), i2;
          }
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            void 0 === t3 && (t3 = true);
            var r2 = this._subtype.getSnapshot(e11);
            return t3 ? this.postProcessSnapshot(r2, e11) : r2;
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this.preProcessSnapshotSafe(e11);
            return r2 === eM ? J(t3, e11, "Failed to preprocess value") : this._subtype.validate(r2, t3);
          }
        }), Object.defineProperty(t2.prototype, "getSubTypes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this._subtype;
          }
        }), Object.defineProperty(t2.prototype, "is", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = M(e11) ? this._subtype : en(e11) ? e11 : this.preProcessSnapshotSafe(e11);
            return t3 !== eM && 0 === this._subtype.validate(t3, [{ path: "", type: this._subtype }]).length;
          }
        }), Object.defineProperty(t2.prototype, "isAssignableFrom", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this._subtype.isAssignableFrom(e11);
          }
        }), Object.defineProperty(t2.prototype, "isMatchingSnapshotId", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            if (!(this._subtype instanceof F)) return false;
            var r2 = this.preProcessSnapshot(t3);
            return this._subtype.isMatchingSnapshotId(e11, r2);
          }
        }), t2;
      })(R), eU = "Map.put can only be used to store complex values that have an identifier type attribute";
      !(function(e10) {
        e10[e10.UNKNOWN = 0] = "UNKNOWN", e10[e10.YES = 1] = "YES", e10[e10.NO = 2] = "NO";
      })(s || (s = {}));
      var eZ = (function(e10) {
        function t2(t3, r2) {
          return e10.call(this, t3, p.sH.ref.enhancer, r2) || this;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "get", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3) {
            return e10.prototype.get.call(this, "" + t3);
          }
        }), Object.defineProperty(t2.prototype, "has", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3) {
            return e10.prototype.has.call(this, "" + t3);
          }
        }), Object.defineProperty(t2.prototype, "delete", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3) {
            return e10.prototype.delete.call(this, "" + t3);
          }
        }), Object.defineProperty(t2.prototype, "set", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3, r2) {
            return e10.prototype.set.call(this, "" + t3, r2);
          }
        }), Object.defineProperty(t2.prototype, "put", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (!e11) throw new eb("Map.put cannot be used to set empty values");
            if (en(e11)) {
              var t3 = ea(e11);
              if (null === t3.identifier) throw new eb(eU);
              return this.set(t3.identifier, e11), e11;
            }
            if (em(e11)) {
              var r2 = ea(this), n2 = r2.type;
              if (n2.identifierMode !== s.YES) throw new eb(eU);
              var i2 = e11[n2.mapIdentifierAttribute];
              if (!tI(i2)) {
                var a2 = this.put(n2.getChildType().create(e11, r2.environment));
                return this.put(O(a2));
              }
              var o2 = "" + i2;
              return this.set(o2, e11), this.get(o2);
            }
            throw new eb("Map.put can only be used to store complex values");
          }
        }), t2;
      })(p.Es), eW = (function(e10) {
        function t2(t3, r2, n2) {
          void 0 === n2 && (n2 = []);
          var i2 = e10.call(this, t3) || this;
          return Object.defineProperty(i2, "_subType", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(i2, "identifierMode", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: s.UNKNOWN
          }), Object.defineProperty(i2, "mapIdentifierAttribute", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(i2, "flags", { enumerable: true, configurable: true, writable: true, value: l.Map }), Object.defineProperty(i2, "hookInitializers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
          }), i2._determineIdentifierMode(), i2.hookInitializers = n2, i2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "hooks", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var r2 = this.hookInitializers.length > 0 ? this.hookInitializers.concat(e11) : [e11];
            return new t2(this.name, this._subType, r2);
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return this._determineIdentifierMode(), et(this, e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "_determineIdentifierMode", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            if (this.identifierMode === s.UNKNOWN) {
              var e11 = [];
              if ((function e12(t4, r2) {
                var n2, i2, a2 = t4.getSubTypes();
                if (a2 === k) return false;
                if (a2) {
                  var o2 = ev(a2);
                  try {
                    for (var l2 = y(o2), u2 = l2.next(); !u2.done; u2 = l2.next()) {
                      var c2 = u2.value;
                      if (!e12(c2, r2)) return false;
                    }
                  } catch (e13) {
                    n2 = { error: e13 };
                  } finally {
                    try {
                      u2 && !u2.done && (i2 = l2.return) && i2.call(l2);
                    } finally {
                      if (n2) throw n2.error;
                    }
                  }
                }
                return t4 instanceof eQ && r2.push(t4), true;
              })(this._subType, e11)) {
                var t3 = e11.reduce(
                  function(e12, t4) {
                    if (!t4.identifierAttribute) return e12;
                    if (e12 && e12 !== t4.identifierAttribute)
                      throw new eb(
                        "The objects in a map should all have the same identifier attribute, expected '".concat(e12, "', but child of type '").concat(t4.name, "' declared attribute '").concat(t4.identifierAttribute, "' as identifier")
                      );
                    return t4.identifierAttribute;
                  },
                  void 0
                );
                t3 ? (this.identifierMode = s.YES, this.mapIdentifierAttribute = t3) : this.identifierMode = s.NO;
              }
            }
          }
        }), Object.defineProperty(t2.prototype, "initializeChildNodes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            void 0 === t3 && (t3 = {});
            var r2 = e11.type._subType, n2 = {};
            return Object.keys(t3).forEach(function(i2) {
              n2[i2] = r2.instantiate(e11, i2, void 0, t3[i2]);
            }), n2;
          }
        }), Object.defineProperty(t2.prototype, "createNewInstance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return new eZ(e11, this.name);
          }
        }), Object.defineProperty(t2.prototype, "finalizeNewInstance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            (0, p.pA)(t3, e11.unbox), e11.type.hookInitializers.forEach(function(e12) {
              var r2 = e12(t3);
              Object.keys(r2).forEach(function(e13) {
                var n2 = r2[e13], i2 = G(t3, e13, n2);
                eS(t3, e13, i2);
              });
            }), (0, p.Zc)(t3, this.willChange), (0, p.lB)(t3, this.didChange);
          }
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.name;
          }
        }), Object.defineProperty(t2.prototype, "getChildren", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return (0, p.zu)(e11.storedValue);
          }
        }), Object.defineProperty(t2.prototype, "getChildNode", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = e11.storedValue.get("" + t3);
            if (!r2) throw new eb("Not a child " + t3);
            return r2;
          }
        }), Object.defineProperty(t2.prototype, "willChange", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = ea(e11.object), r2 = e11.name;
            t3.assertWritable({ subpath: r2 });
            var n2 = t3.type, i2 = n2._subType;
            switch (e11.type) {
              case "update":
                var a2 = e11.newValue;
                if (a2 === e11.object.get(r2)) return null;
                q(i2, a2), e11.newValue = i2.reconcile(t3.getChildNode(r2), e11.newValue, t3, r2), n2.processIdentifier(r2, e11.newValue);
                break;
              case "add":
                q(i2, e11.newValue), e11.newValue = i2.instantiate(t3, r2, void 0, e11.newValue), n2.processIdentifier(r2, e11.newValue);
            }
            return e11;
          }
        }), Object.defineProperty(t2.prototype, "processIdentifier", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            if (this.identifierMode === s.YES && t3 instanceof x) {
              var r2 = t3.identifier;
              if (r2 !== e11)
                throw new eb(
                  "A map of objects containing an identifier should always store the object under their own identifier. Trying to store key '".concat(r2, "', but expected: '").concat(e11, "'")
                );
            }
          }
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = {};
            return e11.getChildren().forEach(function(e12) {
              t3[e12.subpath] = e12.snapshot;
            }), t3;
          }
        }), Object.defineProperty(t2.prototype, "processInitialSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = {};
            return Object.keys(e11).forEach(function(r2) {
              t3[r2] = e11[r2].getSnapshot();
            }), t3;
          }
        }), Object.defineProperty(t2.prototype, "didChange", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = ea(e11.object);
            switch (e11.type) {
              case "update":
                return void t3.emitPatch(
                  {
                    op: "replace",
                    path: eR(e11.name),
                    value: e11.newValue.snapshot,
                    oldValue: e11.oldValue ? e11.oldValue.snapshot : void 0
                  },
                  t3
                );
              case "add":
                return void t3.emitPatch(
                  { op: "add", path: eR(e11.name), value: e11.newValue.snapshot, oldValue: void 0 },
                  t3
                );
              case "delete":
                var r2 = e11.oldValue.snapshot;
                return e11.oldValue.die(), void t3.emitPatch({ op: "remove", path: eR(e11.name), oldValue: r2 }, t3);
            }
          }
        }), Object.defineProperty(t2.prototype, "applyPatchLocally", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2) {
            var n2 = e11.storedValue;
            switch (r2.op) {
              case "add":
              case "replace":
                n2.set(t3, r2.value);
                break;
              case "remove":
                n2.delete(t3);
            }
          }
        }), Object.defineProperty(t2.prototype, "applySnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            q(this, t3);
            var r2 = e11.storedValue, n2 = {};
            if (Array.from(r2.keys()).forEach(function(e12) {
              n2[e12] = false;
            }), t3)
              for (var i2 in t3) r2.set(i2, t3[i2]), n2["" + i2] = true;
            Object.keys(n2).forEach(function(e12) {
              false === n2[e12] && r2.delete(e12);
            });
          }
        }), Object.defineProperty(t2.prototype, "getChildType", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this._subType;
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this;
            return eg(e11) ? K(
              Object.keys(e11).map(function(n2) {
                return r2._subType.validate(e11[n2], B(t3, n2, r2._subType));
              })
            ) : J(t3, e11, "Value is not a plain object");
          }
        }), Object.defineProperty(t2.prototype, "getDefaultSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return ep;
          }
        }), Object.defineProperty(t2.prototype, "removeChild", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            e11.storedValue.delete(t3);
          }
        }), t2;
      })(F);
      eW.prototype.applySnapshot = (0, p.XI)(eW.prototype.applySnapshot);
      var eG = (function(e10) {
        function t2(t3, r2, n2) {
          void 0 === n2 && (n2 = []);
          var i2 = e10.call(this, t3) || this;
          return Object.defineProperty(i2, "_subType", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(i2, "flags", { enumerable: true, configurable: true, writable: true, value: l.Array }), Object.defineProperty(i2, "hookInitializers", { enumerable: true, configurable: true, writable: true, value: [] }), i2.hookInitializers = n2, i2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "hooks", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var r2 = this.hookInitializers.length > 0 ? this.hookInitializers.concat(e11) : [e11];
            return new t2(this.name, this._subType, r2);
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return et(this, e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "initializeChildNodes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            void 0 === t3 && (t3 = []);
            var r2 = e11.type._subType, n2 = {};
            return t3.forEach(function(t4, i2) {
              var a2 = "" + i2;
              n2[a2] = r2.instantiate(e11, a2, void 0, t4);
            }), n2;
          }
        }), Object.defineProperty(t2.prototype, "createNewInstance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = d(d({}, ef), { name: this.name });
            return p.sH.array(eu(e11), t3);
          }
        }), Object.defineProperty(t2.prototype, "finalizeNewInstance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            (0, p.Mr)(t3).dehancer = e11.unbox, e11.type.hookInitializers.forEach(function(e12) {
              var r2 = e12(t3);
              Object.keys(r2).forEach(function(e13) {
                var n2 = r2[e13], i2 = G(t3, e13, n2);
                eS(t3, e13, i2);
              });
            }), (0, p.Zc)(t3, this.willChange), (0, p.lB)(t3, this.didChange);
          }
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.name;
          }
        }), Object.defineProperty(t2.prototype, "getChildren", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11.storedValue.slice();
          }
        }), Object.defineProperty(t2.prototype, "getChildNode", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = Number(t3);
            if (r2 < e11.storedValue.length) return e11.storedValue[r2];
            throw new eb("Not a child: " + t3);
          }
        }), Object.defineProperty(t2.prototype, "willChange", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = ea(e11.object);
            t3.assertWritable({ subpath: "" + e11.index });
            var r2 = t3.type._subType, n2 = t3.getChildren();
            switch (e11.type) {
              case "update":
                if (e11.newValue === e11.object[e11.index]) return null;
                var i2 = e$(t3, r2, [n2[e11.index]], [e11.newValue], [e11.index]);
                if (!i2) return null;
                e11.newValue = i2[0];
                break;
              case "splice":
                var a2 = e11.index, o2 = e11.removedCount, l2 = e11.added, u2 = e$(
                  t3,
                  r2,
                  n2.slice(a2, a2 + o2),
                  l2,
                  l2.map(function(e12, t4) {
                    return a2 + t4;
                  })
                );
                if (!u2) return null;
                e11.added = u2;
                for (var c2 = a2 + o2; c2 < n2.length; c2++) n2[c2].setParent(t3, "" + (c2 + l2.length - o2));
            }
            return e11;
          }
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11.getChildren().map(function(e12) {
              return e12.snapshot;
            });
          }
        }), Object.defineProperty(t2.prototype, "processInitialSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = [];
            return Object.keys(e11).forEach(function(r2) {
              t3.push(e11[r2].getSnapshot());
            }), t3;
          }
        }), Object.defineProperty(t2.prototype, "didChange", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = ea(e11.object);
            switch (e11.type) {
              case "update":
                return void t3.emitPatch(
                  {
                    op: "replace",
                    path: "" + e11.index,
                    value: e11.newValue.snapshot,
                    oldValue: e11.oldValue ? e11.oldValue.snapshot : void 0
                  },
                  t3
                );
              case "splice":
                if (e11.removedCount && e11.addedCount === e11.object.length)
                  return void t3.emitPatch(
                    {
                      op: "replace",
                      path: "",
                      value: t3.snapshot,
                      oldValue: e11.removed.map(function(e12) {
                        return e12.snapshot;
                      })
                    },
                    t3
                  );
                for (var r2 = e11.removedCount - 1; r2 >= 0; r2--)
                  t3.emitPatch({ op: "remove", path: "" + (e11.index + r2), oldValue: e11.removed[r2].snapshot }, t3);
                for (var r2 = 0; r2 < e11.addedCount; r2++)
                  t3.emitPatch(
                    { op: "add", path: "" + (e11.index + r2), value: e11.added[r2].snapshot, oldValue: void 0 },
                    t3
                  );
                return;
            }
          }
        }), Object.defineProperty(t2.prototype, "applyPatchLocally", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2) {
            var n2 = e11.storedValue, i2 = "-" === t3 ? n2.length : Number(t3);
            switch (r2.op) {
              case "replace":
                n2[i2] = r2.value;
                break;
              case "add":
                n2.splice(i2, 0, r2.value);
                break;
              case "remove":
                n2.splice(i2, 1);
            }
          }
        }), Object.defineProperty(t2.prototype, "applySnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            q(this, t3), e11.storedValue.replace(t3);
          }
        }), Object.defineProperty(t2.prototype, "getChildType", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this._subType;
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this;
            return ey(e11) ? K(
              e11.map(function(e12, n2) {
                return r2._subType.validate(e12, B(t3, "" + n2, r2._subType));
              })
            ) : J(t3, e11, "Value is not an array");
          }
        }), Object.defineProperty(t2.prototype, "getDefaultSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return es;
          }
        }), Object.defineProperty(t2.prototype, "removeChild", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            e11.storedValue.splice(Number(t3), 1);
          }
        }), t2;
      })(F);
      function e$(e10, t2, r2, n2, i2) {
        for (var a2 = true, o2 = 0; ; o2++) {
          var l2, u2 = o2 <= n2.length - 1, c2 = r2[o2], s2 = u2 ? n2[o2] : void 0, p2 = "" + i2[o2];
          if (((l2 = s2) instanceof N || l2 instanceof x) && (s2 = s2.storedValue), c2 || u2)
            if (u2)
              if (c2)
                if (eY(c2, s2)) r2[o2] = eX(t2, e10, p2, s2, c2);
                else {
                  for (var f2 = void 0, b2 = o2; b2 < r2.length; b2++)
                    if (eY(r2[b2], s2)) {
                      f2 = r2.splice(b2, 1)[0];
                      break;
                    }
                  a2 = false;
                  var h2 = eX(t2, e10, p2, s2, f2);
                  r2.splice(o2, 0, h2);
                }
              else {
                if (en(s2) && ea(s2).parent === e10)
                  throw new eb(
                    "Cannot add an object to a state tree if it is already part of the same or another state tree. Tried to assign an object to '".concat(e10.path, "/").concat(p2, "', but it lives already at '").concat(ea(s2).path, "'")
                  );
                a2 = false;
                var h2 = eX(t2, e10, p2, s2);
                r2.splice(o2, 0, h2);
              }
            else a2 = false, r2.splice(o2, 1), c2 instanceof x && c2.createObservableInstanceIfNeeded(), c2.die(), o2--;
          else break;
        }
        return a2 ? null : r2;
      }
      function eX(e10, t2, r2, n2, i2) {
        q(e10, n2);
        var a2 = (function() {
          if (en(n2)) {
            var a3 = ea(n2);
            if (a3.assertAlive(ep), null !== a3.parent && a3.parent === t2) return a3.setParent(t2, r2), a3;
          }
          return i2 ? e10.reconcile(i2, n2, t2, r2) : e10.instantiate(t2, r2, void 0, n2);
        })();
        return i2 && i2 !== a2 && (i2 instanceof x && i2.createObservableInstanceIfNeeded(), i2.die()), a2;
      }
      function eY(e10, t2) {
        if (!e10.isAlive) return false;
        if (en(t2)) {
          var r2 = ea(t2);
          return r2.isAlive && r2 === e10;
        }
        if (e10.snapshot === t2) return true;
        if (!(e10 instanceof x)) return false;
        var n2 = e10.getReconciliationType();
        return null !== e10.identifier && e10.identifierAttribute && eg(t2) && n2.is(t2) && n2.isMatchingSnapshotId(e10, t2);
      }
      eG.prototype.applySnapshot = (0, p.XI)(eG.prototype.applySnapshot);
      var eB = "preProcessSnapshot", eJ = "postProcessSnapshot";
      function eK() {
        return ea(this).toString();
      }
      var eq = { name: "AnonymousModel", properties: {}, initializers: es }, eQ = (function(e10) {
        function t2(t3) {
          var r2, i2, a2, o2 = e10.call(this, t3.name || eq.name) || this;
          return Object.defineProperty(o2, "flags", { enumerable: true, configurable: true, writable: true, value: l.Object }), Object.defineProperty(o2, "initializers", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(o2, "properties", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(o2, "preProcessor", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(o2, "postProcessor", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(o2, "propertyNames", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(o2, "named", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: function(e11) {
              return o2.cloneAndEnhance({ name: e11 });
            }
          }), Object.defineProperty(o2, "props", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: function(e11) {
              return o2.cloneAndEnhance({ properties: e11 });
            }
          }), Object.defineProperty(o2, "preProcessSnapshot", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: function(e11) {
              var t4 = o2.preProcessor;
              return t4 ? o2.cloneAndEnhance({
                preProcessor: function(r3) {
                  return t4(e11(r3));
                }
              }) : o2.cloneAndEnhance({ preProcessor: e11 });
            }
          }), Object.defineProperty(o2, "postProcessSnapshot", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: function(e11) {
              var t4 = o2.postProcessor;
              return t4 ? o2.cloneAndEnhance({
                postProcessor: function(r3) {
                  return e11(t4(r3));
                }
              }) : o2.cloneAndEnhance({ postProcessor: e11 });
            }
          }), Object.assign(o2, eq, t3), i2 = Object.keys(r2 = o2.properties), a2 = /* @__PURE__ */ new Set(), i2.forEach(function(e11) {
            if (a2.has(e11))
              throw new eb("".concat(e11, " is declared twice in the model. Model should not contain the same keys"));
            a2.add(e11);
          }), o2.properties = i2.reduce(
            function(e11, t4) {
              if (t4 in n)
                throw new eb(
                  "Hook '".concat(t4, "' was defined as property. Hooks should be defined as part of the actions")
                );
              var i3 = Object.getOwnPropertyDescriptor(r2, t4);
              if ("get" in i3) throw new eb("Getters are not supported as properties. Please use views instead");
              var a3 = i3.value;
              if (null == a3)
                throw new eb(
                  "The default value of an attribute cannot be null or undefined as the type cannot be inferred. Did you mean `types.maybe(someType)`?"
                );
              if (ew(a3))
                e11[t4] = to(
                  (function(e12) {
                    switch (typeof e12) {
                      case "string":
                        return e1;
                      case "number":
                        return e2;
                      case "boolean":
                        return e6;
                      case "object":
                        if (e12 instanceof Date) return e9;
                    }
                    throw new eb("Cannot determine primitive type from value " + e12);
                  })(a3),
                  a3
                );
              else if (a3 instanceof eW) e11[t4] = to(a3, {});
              else if (a3 instanceof eG) e11[t4] = to(a3, []);
              else if (M(a3)) ;
              else if (1)
                if (1)
                  throw new eb(
                    "Invalid type definition for property '".concat(t4, "', cannot infer a type from a value like '").concat(a3, "' (").concat(typeof a3, ")")
                  );
                else
                  throw new eb(
                    "Invalid type definition for property '".concat(
                      t4,
                      "', it looks like you passed an object. Try passing another model type or a types.frozen."
                    )
                  );
              else
                throw new eb(
                  "Invalid type definition for property '".concat(
                    t4,
                    "', it looks like you passed a function. Did you forget to invoke it, or did you intend to declare a view / action?"
                  )
                );
              return e11;
            },
            d({}, r2)
          ), eP(o2.properties), o2.propertyNames = Object.keys(o2.properties), o2.identifierAttribute = o2._getIdentifierAttribute(), o2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "_getIdentifierAttribute", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = void 0;
            return this.forAllProps(function(t3, r2) {
              if (r2.flags & l.Identifier) {
                if (e11)
                  throw new eb(
                    "Cannot define property '".concat(t3, "' as object identifier, property '").concat(e11, "' is already defined as identifier property")
                  );
                e11 = t3;
              }
            }), e11;
          }
        }), Object.defineProperty(t2.prototype, "cloneAndEnhance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return new t2({
              name: e11.name || this.name,
              properties: Object.assign({}, this.properties, e11.properties),
              initializers: this.initializers.concat(e11.initializers || []),
              preProcessor: e11.preProcessor || this.preProcessor,
              postProcessor: e11.postProcessor || this.postProcessor
            });
          }
        }), Object.defineProperty(t2.prototype, "actions", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this;
            return this.cloneAndEnhance({
              initializers: [
                function(r2) {
                  return t3.instantiateActions(r2, e11(r2)), r2;
                }
              ]
            });
          }
        }), Object.defineProperty(t2.prototype, "instantiateActions", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this;
            if (!eg(t3)) throw new eb("actions initializer should return a plain object containing actions");
            Object.getOwnPropertyNames(t3).forEach(function(i2) {
              if (i2 in r2.properties)
                throw new eb("'".concat(i2, "' is a property and cannot be declared as an action"));
              if (i2 === eB)
                throw new eb(
                  "Cannot define action '".concat(
                    eB,
                    "', it should be defined using 'type.preProcessSnapshot(fn)' instead"
                  )
                );
              if (i2 === eJ)
                throw new eb(
                  "Cannot define action '".concat(
                    eJ,
                    "', it should be defined using 'type.postProcessSnapshot(fn)' instead"
                  )
                );
              var a2 = t3[i2], o2 = e11[i2];
              if (i2 in n && o2) {
                var l2 = a2;
                a2 = function() {
                  o2.apply(null, arguments), l2.apply(null, arguments);
                };
              }
              var u2 = a2.$mst_middleware, c2 = a2.bind(t3);
              c2._isFlowAction = a2._isFlowAction || false, c2.$mst_middleware = u2;
              var s2 = G(e11, i2, c2);
              t3[i2] = s2, eS(e11, i2, s2);
            });
          }
        }), Object.defineProperty(t2.prototype, "volatile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this;
            if ("function" != typeof e11)
              throw new eb(
                "You passed an ".concat(typeof e11, " to volatile state as an argument, when function is expected")
              );
            return this.cloneAndEnhance({
              initializers: [
                function(r2) {
                  return t3.instantiateVolatileState(r2, e11(r2)), r2;
                }
              ]
            });
          }
        }), Object.defineProperty(t2.prototype, "instantiateVolatileState", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this;
            if (!eg(t3)) throw new eb("volatile state initializer should return a plain object containing state");
            Object.getOwnPropertyNames(t3).forEach(function(n2) {
              if (n2 in r2.properties)
                throw new eb("'".concat(n2, "' is a property and cannot be declared as volatile state"));
              (0, p.hZ)(e11, n2, t3[n2]);
            });
          }
        }), Object.defineProperty(t2.prototype, "extend", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this;
            return this.cloneAndEnhance({
              initializers: [
                function(r2) {
                  var n2 = e11(r2), i2 = n2.actions, a2 = n2.views, o2 = n2.state, l2 = (function(e12, t4) {
                    var r3 = {};
                    for (var n3 in e12)
                      Object.prototype.hasOwnProperty.call(e12, n3) && 0 > t4.indexOf(n3) && (r3[n3] = e12[n3]);
                    if (null != e12 && "function" == typeof Object.getOwnPropertySymbols)
                      for (var i3 = 0, n3 = Object.getOwnPropertySymbols(e12); i3 < n3.length; i3++)
                        0 > t4.indexOf(n3[i3]) && Object.prototype.propertyIsEnumerable.call(e12, n3[i3]) && (r3[n3[i3]] = e12[n3[i3]]);
                    return r3;
                  })(n2, ["actions", "views", "state"]);
                  for (var u2 in l2)
                    throw new eb(
                      "The `extend` function should return an object with a subset of the fields 'actions', 'views' and 'state'. Found invalid key '".concat(
                        u2,
                        "'"
                      )
                    );
                  return o2 && t3.instantiateVolatileState(r2, o2), a2 && t3.instantiateViews(r2, a2), i2 && t3.instantiateActions(r2, i2), r2;
                }
              ]
            });
          }
        }), Object.defineProperty(t2.prototype, "views", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this;
            return this.cloneAndEnhance({
              initializers: [
                function(r2) {
                  return t3.instantiateViews(r2, e11(r2)), r2;
                }
              ]
            });
          }
        }), Object.defineProperty(t2.prototype, "instantiateViews", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this;
            if (!eg(t3)) throw new eb("views initializer should return a plain object containing views");
            Object.getOwnPropertyNames(t3).forEach(function(n2) {
              if (n2 in r2.properties)
                throw new eb("'".concat(n2, "' is a property and cannot be declared as a view"));
              var i2, a2 = Object.getOwnPropertyDescriptor(t3, n2);
              if ("get" in a2) (0, p.n8)(e11, n2, a2), (0, p.Gn)(e11, ((i2 = {})[n2] = p.EW, i2));
              else if ("function" == typeof a2.value) eS(e11, n2, a2.value);
              else throw new eb("A view member should either be a function or getter based property");
            });
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return et(this, e11, t3, r2, en(n2) ? n2 : this.applySnapshotPreProcessor(n2));
          }
        }), Object.defineProperty(t2.prototype, "initializeChildNodes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            void 0 === t3 && (t3 = {});
            var r2 = e11.type, n2 = {};
            return r2.forAllProps(function(r3, i2) {
              n2[r3] = i2.instantiate(e11, r3, void 0, t3[r3]);
            }), n2;
          }
        }), Object.defineProperty(t2.prototype, "createNewInstance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = d(d({}, ef), { name: this.name });
            return p.sH.object(e11, ep, t3);
          }
        }), Object.defineProperty(t2.prototype, "finalizeNewInstance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            eS(t3, "toString", eK), this.forAllProps(function(r2) {
              (0, p.pA)(t3, r2, e11.unbox);
            }), this.initializers.reduce(function(e12, t4) {
              return t4(e12);
            }, t3), (0, p.Zc)(t3, this.willChange), (0, p.lB)(t3, this.didChange);
          }
        }), Object.defineProperty(t2.prototype, "willChange", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = ea(e11.object), r2 = e11.name;
            t3.assertWritable({ subpath: r2 });
            var n2 = t3.type.properties[r2];
            return n2 && (q(n2, e11.newValue), e11.newValue = n2.reconcile(t3.getChildNode(r2), e11.newValue, t3, r2)), e11;
          }
        }), Object.defineProperty(t2.prototype, "didChange", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = ea(e11.object);
            if (t3.type.properties[e11.name]) {
              var r2 = e11.oldValue ? e11.oldValue.snapshot : void 0;
              t3.emitPatch({ op: "replace", path: eR(e11.name), value: e11.newValue.snapshot, oldValue: r2 }, t3);
            }
          }
        }), Object.defineProperty(t2.prototype, "getChildren", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this, r2 = [];
            return this.forAllProps(function(n2) {
              r2.push(t3.getChildNode(e11, n2));
            }), r2;
          }
        }), Object.defineProperty(t2.prototype, "getChildNode", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            if (!(t3 in this.properties)) throw new eb("Not a value property: " + t3);
            var r2, n2 = (0, p.Mr)(e11.storedValue, t3), i2 = null == (r2 = n2.raw) ? void 0 : r2.call(n2);
            if (!i2) throw new eb("Node not available for property " + t3);
            return i2;
          }
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this;
            void 0 === t3 && (t3 = true);
            var n2 = {};
            return (this.forAllProps(function(t4, i2) {
              (0, p.go)(e11.storedValue, t4).reportObserved(), n2[t4] = r2.getChildNode(e11, t4).snapshot;
            }), t3) ? this.applySnapshotPostProcessor(n2) : n2;
          }
        }), Object.defineProperty(t2.prototype, "processInitialSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = {};
            return Object.keys(e11).forEach(function(r2) {
              t3[r2] = e11[r2].getSnapshot();
            }), this.applySnapshotPostProcessor(t3);
          }
        }), Object.defineProperty(t2.prototype, "applyPatchLocally", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2) {
            if ("replace" !== r2.op && "add" !== r2.op)
              throw new eb("object does not support operation ".concat(r2.op));
            e11.storedValue[t3] = r2.value;
          }
        }), Object.defineProperty(t2.prototype, "applySnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            q(this, t3);
            var r2 = this.applySnapshotPreProcessor(t3);
            this.forAllProps(function(t4) {
              e11.storedValue[t4] = r2[t4];
            });
          }
        }), Object.defineProperty(t2.prototype, "applySnapshotPreProcessor", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this.preProcessor;
            return t3 ? t3.call(null, e11) : e11;
          }
        }), Object.defineProperty(t2.prototype, "applySnapshotPostProcessor", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this.postProcessor;
            return t3 ? t3.call(null, e11) : e11;
          }
        }), Object.defineProperty(t2.prototype, "getChildType", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return ex(e11, 1), this.properties[e11];
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this, n2 = this.applySnapshotPreProcessor(e11);
            return eg(n2) ? K(
              this.propertyNames.map(function(e12) {
                return r2.properties[e12].validate(n2[e12], B(t3, e12, r2.properties[e12]));
              })
            ) : J(t3, n2, "Value is not a plain object");
          }
        }), Object.defineProperty(t2.prototype, "forAllProps", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this;
            this.propertyNames.forEach(function(r2) {
              return e11(r2, t3.properties[r2]);
            });
          }
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = this;
            return "{ " + this.propertyNames.map(function(t3) {
              return t3 + ": " + e11.properties[t3].describe();
            }).join("; ") + " }";
          }
        }), Object.defineProperty(t2.prototype, "getDefaultSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return ep;
          }
        }), Object.defineProperty(t2.prototype, "removeChild", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            e11.storedValue[t3] = void 0;
          }
        }), t2;
      })(F);
      eQ.prototype.applySnapshot = (0, p.XI)(eQ.prototype.applySnapshot);
      var e0 = (function(e10) {
        function t2(t3, r2, n2, i2) {
          void 0 === i2 && (i2 = eh);
          var a2 = e10.call(this, t3) || this;
          return Object.defineProperty(a2, "flags", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(a2, "checker", { enumerable: true, configurable: true, writable: true, value: n2 }), Object.defineProperty(a2, "initializer", { enumerable: true, configurable: true, writable: true, value: i2 }), a2.flags = r2, a2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.name;
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return er(this, e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "createNewInstance", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this.initializer(e11);
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            if (ew(e11) && this.checker(e11)) return es;
            var r2 = "Date" === this.name ? "Date or a unix milliseconds timestamp" : this.name;
            return J(t3, e11, "Value is not a ".concat(r2));
          }
        }), t2;
      })(H), e1 = new e0("string", l.String, function(e10) {
        return "string" == typeof e10;
      }), e2 = new e0("number", l.Number, function(e10) {
        return "number" == typeof e10;
      }), e4 = new e0("integer", l.Integer, function(e10) {
        return ed(e10);
      }), e3 = new e0("float", l.Float, function(e10) {
        return Number(e10) === e10 && e10 % 1 != 0;
      }), e8 = new e0("finite", l.Finite, function(e10) {
        return Number.isFinite(e10);
      }), e6 = new e0("boolean", l.Boolean, function(e10) {
        return "boolean" == typeof e10;
      }), e5 = new e0("null", l.Null, function(e10) {
        return null === e10;
      }), e7 = new e0("undefined", l.Undefined, function(e10) {
        return void 0 === e10;
      }), e9 = new e0(
        "Date",
        l.Date,
        function(e10) {
          return "number" == typeof e10 || e10 instanceof Date;
        },
        function(e10) {
          return e10 instanceof Date ? e10 : new Date(e10);
        }
      );
      e9.getSnapshot = function(e10) {
        return e10.storedValue.getTime();
      };
      var te = (function(e10) {
        function t2(t3) {
          var r2 = e10.call(this, JSON.stringify(t3)) || this;
          return Object.defineProperty(r2, "value", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(r2, "flags", { enumerable: true, configurable: true, writable: true, value: l.Literal }), r2.value = t3, r2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return er(this, e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return JSON.stringify(this.value);
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return ew(e11) && e11 === this.value ? es : J(t3, e11, "Value is not a literal ".concat(JSON.stringify(this.value)));
          }
        }), t2;
      })(H);
      function tt(e10) {
        return eV(e10, ew, "primitive", 1), new te(e10);
      }
      var tr = (function(e10) {
        function t2(t3, r2, n2, i2) {
          var a2 = e10.call(this, t3) || this;
          return Object.defineProperty(a2, "_subtype", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(a2, "_predicate", { enumerable: true, configurable: true, writable: true, value: n2 }), Object.defineProperty(a2, "_message", { enumerable: true, configurable: true, writable: true, value: i2 }), a2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "flags", {
          get: function() {
            return this._subtype.flags | l.Refinement;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.name;
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return this._subtype.instantiate(e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "isAssignableFrom", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this._subtype.isAssignableFrom(e11);
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this._subtype.validate(e11, t3);
            if (r2.length > 0) return r2;
            var n2 = en(e11) ? ea(e11).snapshot : e11;
            return this._predicate(n2) ? es : J(t3, e11, this._message(e11));
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return this._subtype.reconcile(e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "getSubTypes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this._subtype;
          }
        }), t2;
      })(R), tn = (function(e10) {
        function t2(t3, r2, n2) {
          var i2 = e10.call(this, t3) || this;
          return Object.defineProperty(i2, "_types", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(i2, "_dispatcher", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(i2, "_eager", { enumerable: true, configurable: true, writable: true, value: true }), i2._dispatcher = (n2 = d({ eager: true, dispatcher: void 0 }, n2)).dispatcher, n2.eager || (i2._eager = false), i2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "flags", {
          get: function() {
            var e11 = l.Union;
            return this._types.forEach(function(t3) {
              e11 |= t3.flags;
            }), e11;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "isAssignableFrom", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this._types.some(function(t3) {
              return t3.isAssignableFrom(e11);
            });
          }
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return "(" + this._types.map(function(e11) {
              return e11.describe();
            }).join(" | ") + ")";
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = this.determineType(n2, void 0);
            if (!i2) throw new eb("No matching type for union " + this.describe());
            return i2.instantiate(e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = this.determineType(t3, e11.getReconciliationType());
            if (!i2) throw new eb("No matching type for union " + this.describe());
            return i2.reconcile(e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "determineType", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return this._dispatcher ? this._dispatcher(e11) : t3 ? t3.is(e11) ? t3 : this._types.filter(function(e12) {
              return e12 !== t3;
            }).find(function(t4) {
              return t4.is(e11);
            }) : this._types.find(function(t4) {
              return t4.is(e11);
            });
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            if (this._dispatcher) return this._dispatcher(e11).validate(e11, t3);
            for (var r2 = [], n2 = 0, i2 = 0; i2 < this._types.length; i2++) {
              var a2 = this._types[i2].validate(e11, t3);
              if (0 === a2.length)
                if (this._eager) return es;
                else n2++;
              else r2.push(a2);
            }
            return 1 === n2 ? es : J(t3, e11, "No type is applicable for the union").concat(K(r2));
          }
        }), Object.defineProperty(t2.prototype, "getSubTypes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this._types;
          }
        }), t2;
      })(R);
      function ti(e10) {
        for (var t2 = [], r2 = 1; r2 < arguments.length; r2++) t2[r2 - 1] = arguments[r2];
        var n2 = M(e10) ? void 0 : e10, i2 = M(e10) ? g([e10], v(t2), false) : t2;
        return new tn(
          "(" + i2.map(function(e11) {
            return e11.name;
          }).join(" | ") + ")",
          i2,
          n2
        );
      }
      var ta = (function(e10) {
        function t2(t3, r2, n2) {
          var i2 = e10.call(this, t3.name) || this;
          return Object.defineProperty(i2, "_subtype", { enumerable: true, configurable: true, writable: true, value: t3 }), Object.defineProperty(i2, "_defaultValue", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(i2, "optionalValues", { enumerable: true, configurable: true, writable: true, value: n2 }), i2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "flags", {
          get: function() {
            return this._subtype.flags | l.Optional;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this._subtype.describe() + "?";
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            if (this.optionalValues.indexOf(n2) >= 0) {
              var i2 = this.getDefaultInstanceOrSnapshot();
              return this._subtype.instantiate(e11, t3, r2, i2);
            }
            return this._subtype.instantiate(e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return this._subtype.reconcile(
              e11,
              0 > this.optionalValues.indexOf(t3) && this._subtype.is(t3) ? t3 : this.getDefaultInstanceOrSnapshot(),
              r2,
              n2
            );
          }
        }), Object.defineProperty(t2.prototype, "getDefaultInstanceOrSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = "function" == typeof this._defaultValue ? this._defaultValue() : this._defaultValue;
            return "function" == typeof this._defaultValue && q(this, e11), e11;
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return this.optionalValues.indexOf(e11) >= 0 ? es : this._subtype.validate(e11, t3);
          }
        }), Object.defineProperty(t2.prototype, "isAssignableFrom", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this._subtype.isAssignableFrom(e11);
          }
        }), Object.defineProperty(t2.prototype, "getSubTypes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this._subtype;
          }
        }), t2;
      })(R);
      function to(e10, t2, r2) {
        if ("function" != typeof t2 && en(t2))
          throw new eb(
            "default value cannot be an instance, pass a snapshot or a function that creates an instance/snapshot instead"
          );
        return L(e10, 1), new ta(e10, t2, r2 || tl);
      }
      var tl = [void 0], tu = to(e7, void 0), tc = to(e5, null);
      function ts(e10) {
        return L(e10, 1), ti(e10, tu);
      }
      var tp = (function(e10) {
        function t2(t3, r2) {
          var n2 = e10.call(this, t3) || this;
          return Object.defineProperty(n2, "_definition", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(n2, "_subType", { enumerable: true, configurable: true, writable: true, value: void 0 }), n2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "flags", {
          get: function() {
            return (this._subType ? this._subType.flags : 0) | l.Late;
          },
          enumerable: false,
          configurable: true
        }), Object.defineProperty(t2.prototype, "getSubType", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (!this._subType) {
              var t3 = void 0;
              try {
                t3 = this._definition();
              } catch (e12) {
                if (e12 instanceof ReferenceError) t3 = void 0;
                else throw e12;
              }
              if (e11 && void 0 === t3)
                throw new eb("Late type seems to be used too early, the definition (still) returns undefined");
              t3 && (this._subType = t3);
            }
            return this._subType;
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return this.getSubType(true).instantiate(e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return this.getSubType(true).reconcile(e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            var e11 = this.getSubType(false);
            return e11 ? e11.name : "<uknown late type>";
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this.getSubType(false);
            return r2 ? r2.validate(e11, t3) : es;
          }
        }), Object.defineProperty(t2.prototype, "isAssignableFrom", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t3 = this.getSubType(false);
            return !!t3 && t3.isAssignableFrom(e11);
          }
        }), Object.defineProperty(t2.prototype, "getSubTypes", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.getSubType(false) || k;
          }
        }), t2;
      })(R), tf = (function(e10) {
        function t2(t3, r2) {
          var n2 = e10.call(this, t3) || this;
          return Object.defineProperty(n2, "options", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(n2, "flags", { enumerable: true, configurable: true, writable: true, value: l.Lazy }), Object.defineProperty(n2, "loadedType", { enumerable: true, configurable: true, writable: true, value: null }), Object.defineProperty(n2, "pendingNodeList", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: p.sH.array()
          }), (0, p.z7)(
            function() {
              return n2.pendingNodeList.length > 0 && n2.pendingNodeList.some(function(e11) {
                return e11.isAlive && n2.options.shouldLoadPredicate(e11.parent ? e11.parent.value : null);
              });
            },
            function() {
              n2.options.loadType().then(
                (0, p.XI)(function(e11) {
                  n2.loadedType = e11, n2.pendingNodeList.forEach(function(e12) {
                    e12.parent && n2.loadedType && e12.parent.applyPatches([{ op: "replace", path: "/".concat(e12.subpath), value: e12.snapshot }]);
                  });
                })
              );
            }
          ), n2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return "<lazy ".concat(this.name, ">");
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = this;
            if (this.loadedType) return this.loadedType.instantiate(e11, t3, r2, n2);
            var a2 = er(this, e11, t3, r2, eO(n2));
            return this.pendingNodeList.push(a2), (0, p.z7)(
              function() {
                return !a2.isAlive;
              },
              function() {
                return i2.pendingNodeList.splice(i2.pendingNodeList.indexOf(a2), 1);
              }
            ), a2;
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return this.loadedType ? this.loadedType.validate(e11, t3) : ej(e11) ? es : J(t3, e11, "Value is not serializable and cannot be lazy");
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(t3, r2, n2, i2) {
            return this.loadedType ? (t3.die(), this.loadedType.instantiate(n2, i2, n2.environment, r2)) : e10.prototype.reconcile.call(this, t3, r2, n2, i2);
          }
        }), t2;
      })(H), tb = (function(e10) {
        function t2(t3) {
          var r2 = e10.call(this, t3 ? "frozen(".concat(t3.name, ")") : "frozen") || this;
          return Object.defineProperty(r2, "subType", { enumerable: true, configurable: true, writable: true, value: t3 }), Object.defineProperty(r2, "flags", { enumerable: true, configurable: true, writable: true, value: l.Frozen }), r2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return "<any immutable value>";
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            return er(this, e11, t3, r2, eO(n2));
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return ej(e11) ? this.subType ? this.subType.validate(e11, t3) : es : J(t3, e11, "Value is not serializable and cannot be frozen");
          }
        }), t2;
      })(H), th = new tb(), td = (function() {
        function e10(e11, t2) {
          if (Object.defineProperty(this, "targetType", { enumerable: true, configurable: true, writable: true, value: t2 }), Object.defineProperty(this, "identifier", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), Object.defineProperty(this, "node", { enumerable: true, configurable: true, writable: true, value: void 0 }), Object.defineProperty(this, "resolvedReference", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
          }), tI(e11))
            this.identifier = e11;
          else if (en(e11)) {
            var r2 = ea(e11);
            if (!r2.identifierAttribute)
              throw new eb("Can only store references with a defined identifier attribute.");
            var n2 = r2.unnormalizedIdentifier;
            if (null == n2) throw new eb("Can only store references to tree nodes with a defined identifier.");
            this.identifier = n2;
          } else throw new eb("Can only store references to tree nodes or identifiers, got: '".concat(e11, "'"));
        }
        return Object.defineProperty(e10.prototype, "updateResolvedReference", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            var t2 = "" + this.identifier, r2 = e11.root, n2 = r2.identifierCache.getLastCacheModificationPerId(t2);
            if (!this.resolvedReference || this.resolvedReference.lastCacheModification !== n2) {
              var i2 = this.targetType, a2 = r2.identifierCache.resolve(i2, t2);
              if (!a2)
                throw new ty(
                  "[mobx-state-tree] Failed to resolve reference '".concat(this.identifier, "' to type '").concat(this.targetType.name, "' (from node: ").concat(e11.path, ")")
                );
              this.resolvedReference = { node: a2, lastCacheModification: n2 };
            }
          }
        }), Object.defineProperty(e10.prototype, "resolvedValue", {
          get: function() {
            return this.updateResolvedReference(this.node), this.resolvedReference.node.value;
          },
          enumerable: false,
          configurable: true
        }), e10;
      })(), ty = (function(e10) {
        function t2(r2) {
          var n2 = e10.call(this, r2) || this;
          return Object.setPrototypeOf(n2, t2.prototype), n2;
        }
        return h(t2, e10), t2;
      })(Error), tv = (function(e10) {
        function t2(t3, r2) {
          var n2 = e10.call(this, "reference(".concat(t3.name, ")")) || this;
          return Object.defineProperty(n2, "targetType", { enumerable: true, configurable: true, writable: true, value: t3 }), Object.defineProperty(n2, "onInvalidated", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(n2, "flags", { enumerable: true, configurable: true, writable: true, value: l.Reference }), n2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.name;
          }
        }), Object.defineProperty(t2.prototype, "isAssignableFrom", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this.targetType.isAssignableFrom(e11);
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return tI(e11) ? es : J(t3, e11, "Value is not a valid identifier, which is a string or a number");
          }
        }), Object.defineProperty(t2.prototype, "fireInvalidated", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = t3.parent;
            if (i2 && i2.isAlive) {
              var a2 = i2.storedValue;
              a2 && this.onInvalidated({
                cause: e11,
                parent: a2,
                invalidTarget: n2 ? n2.storedValue : void 0,
                invalidId: r2,
                replaceRef: function(e12) {
                  w(t3.root.storedValue, { op: "replace", value: e12, path: t3.path });
                },
                removeRef: function() {
                  var e12;
                  M(e12 = i2.type) && (e12.flags & l.Object) > 0 ? this.replaceRef(void 0) : w(t3.root.storedValue, { op: "remove", path: t3.path });
                }
              });
            }
          }
        }), Object.defineProperty(t2.prototype, "addTargetNodeWatcher", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            var r2 = this, i2 = this.getValue(e11);
            if (i2) {
              var a2 = ea(i2), o2 = function(i3, o3) {
                var l3 = (function(e12) {
                  switch (e12) {
                    case n.beforeDestroy:
                      return "destroy";
                    case n.beforeDetach:
                      return "detach";
                    default:
                      return;
                  }
                })(o3);
                l3 && r2.fireInvalidated(l3, e11, t3, a2);
              }, l2 = a2.registerHook(n.beforeDetach, o2), u2 = a2.registerHook(n.beforeDestroy, o2);
              return function() {
                l2(), u2();
              };
            }
          }
        }), Object.defineProperty(t2.prototype, "watchTargetNodeForInvalidations", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2) {
            var i2, a2 = this;
            if (this.onInvalidated) {
              e11.registerHook(n.beforeDestroy, function() {
                i2 && i2();
              });
              var o2 = function(n2) {
                i2 && i2();
                var o3 = e11.parent, l2 = o3 && o3.storedValue;
                o3 && o3.isAlive && l2 && ((r2 ? !!r2.get(t3, l2) : e11.root.identifierCache.has(a2.targetType, "" + t3)) ? i2 = a2.addTargetNodeWatcher(e11, t3) : n2 || a2.fireInvalidated("invalidSnapshotReference", e11, t3, null));
              };
              e11.state === c.FINALIZED ? o2(true) : (e11.isRoot || e11.root.registerHook(n.afterCreationFinalization, function() {
                e11.parent && e11.parent.createObservableInstanceIfNeeded();
              }), e11.registerHook(n.afterAttach, function() {
                o2(false);
              }));
            }
          }
        }), t2;
      })(H), tg = (function(e10) {
        function t2(t3, r2) {
          return e10.call(this, t3, r2) || this;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "getValue", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (e11.isAlive) return e11.storedValue.resolvedValue;
          }
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11.storedValue.identifier;
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = en(n2) ? (ei(n2, 1), ea(n2).identifier) : n2, a2 = new td(n2, this.targetType), o2 = er(this, e11, t3, r2, a2);
            return a2.node = o2, this.watchTargetNodeForInvalidations(o2, i2, void 0), o2;
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            if (!e11.isDetaching && e11.type === this) {
              var i2 = en(t3), a2 = e11.storedValue;
              if (!i2 && a2.identifier === t3 || i2 && a2.resolvedValue === t3) return e11.setParent(r2, n2), e11;
            }
            var o2 = this.instantiate(r2, n2, void 0, t3);
            return e11.die(), o2;
          }
        }), t2;
      })(tv), tm = (function(e10) {
        function t2(t3, r2, n2) {
          var i2 = e10.call(this, t3, n2) || this;
          return Object.defineProperty(i2, "options", { enumerable: true, configurable: true, writable: true, value: r2 }), i2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "getValue", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            if (e11.isAlive) return this.options.get(e11.storedValue, e11.parent ? e11.parent.storedValue : null);
          }
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11.storedValue;
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = en(n2) ? this.options.set(n2, e11 ? e11.storedValue : null) : n2, a2 = er(this, e11, t3, r2, i2);
            return this.watchTargetNodeForInvalidations(a2, i2, this.options), a2;
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = en(t3) ? this.options.set(t3, e11 ? e11.storedValue : null) : t3;
            if (!e11.isDetaching && e11.type === this && e11.storedValue === i2) return e11.setParent(r2, n2), e11;
            var a2 = this.instantiate(r2, n2, void 0, i2);
            return e11.die(), a2;
          }
        }), t2;
      })(tv);
      function tw(e10, t2) {
        L(e10, 1);
        var r2 = t2 || void 0, n2 = t2 ? t2.onInvalidated : void 0;
        return r2 && (r2.get || r2.set) ? new tm(e10, { get: r2.get, set: r2.set }, n2) : new tg(e10, n2);
      }
      var tP = (function(e10) {
        function t2(t3, r2) {
          var n2 = e10.call(this, t3) || this;
          return Object.defineProperty(n2, "validType", { enumerable: true, configurable: true, writable: true, value: r2 }), Object.defineProperty(n2, "flags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: l.Identifier
          }), n2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            if (!e11 || !(e11.type instanceof eQ))
              throw new eb("Identifier types can only be instantiated as direct child of a model type");
            return er(this, e11, t3, r2, n2);
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            if (e11.storedValue !== t3)
              throw new eb(
                "Tried to change identifier from '".concat(e11.storedValue, "' to '").concat(t3, "'. Changing identifiers is not allowed.")
              );
            return e11.setParent(r2, n2), e11;
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            return typeof e11 !== this.validType ? J(t3, e11, "Value is not a valid ".concat(this.describe(), ", expected a ").concat(this.validType)) : es;
          }
        }), t2;
      })(H), tO = (function(e10) {
        function t2() {
          var t3 = e10.call(this, "identifier", "string") || this;
          return Object.defineProperty(t3, "flags", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: l.Identifier
          }), t3;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return "identifier";
          }
        }), t2;
      })(tP), tj = (function(e10) {
        function t2() {
          return e10.call(this, "identifierNumber", "number") || this;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return e11.storedValue;
          }
        }), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return "identifierNumber";
          }
        }), t2;
      })(tP), t_ = new tO(), tS = new tj();
      function tI(e10) {
        return "string" == typeof e10 || "number" == typeof e10;
      }
      var tA = (function(e10) {
        function t2(t3) {
          var r2 = e10.call(this, t3.name) || this;
          return Object.defineProperty(r2, "options", { enumerable: true, configurable: true, writable: true, value: t3 }), Object.defineProperty(r2, "flags", { enumerable: true, configurable: true, writable: true, value: l.Custom }), r2;
        }
        return h(t2, e10), Object.defineProperty(t2.prototype, "describe", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function() {
            return this.name;
          }
        }), Object.defineProperty(t2.prototype, "isValidSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3) {
            if (this.options.isTargetType(e11)) return es;
            var r2 = this.options.getValidationMessage(e11);
            return r2 ? J(t3, e11, "Invalid value for type '".concat(this.name, "': ").concat(r2)) : es;
          }
        }), Object.defineProperty(t2.prototype, "getSnapshot", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11) {
            return this.options.toSnapshot(e11.storedValue);
          }
        }), Object.defineProperty(t2.prototype, "instantiate", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = this.options.isTargetType(n2) ? n2 : this.options.fromSnapshot(n2, e11 && e11.root.environment);
            return er(this, e11, t3, r2, i2);
          }
        }), Object.defineProperty(t2.prototype, "reconcile", {
          enumerable: false,
          configurable: true,
          writable: true,
          value: function(e11, t3, r2, n2) {
            var i2 = !this.options.isTargetType(t3);
            if (!e11.isDetaching && e11.type === this && (i2 ? t3 === e11.snapshot : t3 === e11.storedValue))
              return e11.setParent(r2, n2), e11;
            var a2 = i2 ? this.options.fromSnapshot(t3, r2.root.environment) : t3, o2 = this.instantiate(r2, n2, void 0, a2);
            return e11.die(), o2;
          }
        }), t2;
      })(H), tT = {
        enumeration: function(e10, t2) {
          var r2 = ti.apply(
            void 0,
            g(
              [],
              v(
                ("string" == typeof e10 ? t2 : e10).map(function(e11) {
                  return tt("" + e11);
                })
              ),
              false
            )
          );
          return "string" == typeof e10 && (r2.name = e10), r2;
        },
        model: function() {
          for (var e10 = [], t2 = 0; t2 < arguments.length; t2++) e10[t2] = arguments[t2];
          return new eQ({
            name: "string" == typeof e10[0] ? e10.shift() : "AnonymousModel",
            properties: e10.shift() || {}
          });
        },
        compose: function() {
          for (var e10 = [], t2 = 0; t2 < arguments.length; t2++) e10[t2] = arguments[t2];
          var r2 = "string" == typeof e10[0], n2 = r2 ? e10[0] : "AnonymousModel";
          return r2 && e10.shift(), e10.reduce(function(e11, t3) {
            return e11.cloneAndEnhance({
              name: e11.name + "_" + t3.name,
              properties: t3.properties,
              initializers: t3.initializers,
              preProcessor: function(r3) {
                return t3.applySnapshotPreProcessor(e11.applySnapshotPreProcessor(r3));
              },
              postProcessor: function(r3) {
                return t3.applySnapshotPostProcessor(e11.applySnapshotPostProcessor(r3));
              }
            });
          }).named(n2);
        },
        custom: function(e10) {
          return new tA(e10);
        },
        reference: tw,
        safeReference: function(e10, t2) {
          var r2 = tw(
            e10,
            d(d({}, t2), {
              onInvalidated: function(e11) {
                t2 && t2.onInvalidated && t2.onInvalidated(e11), e11.removeRef();
              }
            })
          );
          return t2 && false === t2.acceptsUndefined ? r2 : ts(r2);
        },
        union: ti,
        optional: to,
        literal: tt,
        maybe: ts,
        maybeNull: function(e10) {
          return L(e10, 1), ti(e10, tc);
        },
        refinement: function() {
          for (var e10 = [], t2 = 0; t2 < arguments.length; t2++) e10[t2] = arguments[t2];
          var r2 = "string" == typeof e10[0] ? e10.shift() : M(e10[0]) ? e10[0].name : null, n2 = e10[0], i2 = e10[1], a2 = e10[2] ? e10[2] : function(e11) {
            return "Value does not respect the refinement predicate";
          };
          return L(n2, [1, 2]), ex(r2, 1), eD(i2, [2, 3]), eD(a2, [3, 4]), new tr(r2, n2, i2, a2);
        },
        string: e1,
        boolean: e6,
        number: e2,
        integer: e4,
        float: e3,
        finite: e8,
        Date: e9,
        map: function(e10) {
          return new eW("Map<string, ".concat(e10.name, ">"), e10);
        },
        array: function(e10) {
          return L(e10, 1), new eG("".concat(e10.name, "[]"), e10);
        },
        frozen: function(e10) {
          return 0 == arguments.length ? th : M(e10) ? new tb(e10) : to(th, e10);
        },
        identifier: t_,
        identifierNumber: tS,
        late: function(e10, t2) {
          var r2 = "string" == typeof e10 ? e10 : "late(".concat(e10.toString(), ")"), n2 = "string" == typeof e10 ? t2 : e10;
          return new tp(r2, n2);
        },
        lazy: function(e10, t2) {
          return new tf(e10, t2);
        },
        undefined: e7,
        null: e5,
        snapshotProcessor: function(e10, t2, r2) {
          return L(e10, 1), new eL(e10, t2, r2);
        }
      };
    }
  }
]);
