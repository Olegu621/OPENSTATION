!(function(n) {
  if (!n.Ya || !Ya.Rum) throw new Error("Rum: interface is not defined");
  var e = Ya.Rum;
  e.getSetting = function(n2) {
    var t = e._settings[n2];
    return null === t ? null : t || "";
  };
})("undefined" != typeof self ? self : window);
!(function(e, r) {
  var n = {
    client: ["690.2354", 1e3, 100, 0],
    uncaught: ["690.2361", 100, 10, 0],
    external: ["690.2854", 100, 10, 0],
    script: ["690.2609", 100, 10, 0]
  }, t = {};
  r.ERROR_LEVEL = { INFO: "info", DEBUG: "debug", WARN: "warn", ERROR: "error", FATAL: "fatal" }, r._errorSettings = {
    clck: "https://yandex.ru/clck/click",
    beacon: true,
    project: "unknown",
    page: "",
    env: "",
    experiments: [],
    additional: {},
    platform: "",
    region: "",
    dc: "",
    host: "",
    service: "",
    level: "",
    version: "",
    yandexuid: "",
    loggedin: false,
    coordinates_gp: "",
    referrer: true,
    preventError: false,
    unhandledRejection: false,
    traceUnhandledRejection: false,
    uncaughtException: true,
    debug: false,
    limits: {},
    silent: {},
    filters: {},
    pageMaxAge: 864e6,
    initTimestamp: +/* @__PURE__ */ new Date()
  };
  var o = false;
  function a(e2, r2) {
    for (var n2 in r2) r2.hasOwnProperty(n2) && (e2[n2] = r2[n2]);
    return e2;
  }
  function i(e2) {
    return "boolean" == typeof e2 && (e2 = +e2), "number" == typeof e2 ? e2 + "" : null;
  }
  r.initErrors = function(n2) {
    var t2 = a(r._errorSettings, n2);
    o || (t2.uncaughtException && (function() {
      var n3 = r._errorSettings;
      if (e.addEventListener)
        e.addEventListener("error", s), n3.resourceFails && e.addEventListener("error", l, true), "Promise" in e && n3.unhandledRejection && e.addEventListener("unhandledrejection", function(e2) {
          var n4, t4, o2 = e2.reason, a2 = {};
          o2 && (o2.stack && o2.message ? (n4 = o2.message, t4 = o2.stack) : (n4 = String(o2), t4 = r._parseTraceablePromiseStack(e2.promise), "[object Event]" === n4 ? n4 = "event.type: " + o2.type : "[object Object]" === n4 && (a2.unhandledObject = o2)), o2.target && o2.target.src && (a2.src = o2.target.src), s({ message: "Unhandled rejection: " + n4, stack: t4, additional: a2 }));
        });
      else {
        var t3 = e.onerror;
        e.onerror = function(e2, r2, n4, o2, a2) {
          s({ error: a2 || new Error(e2 || "Empty error"), message: e2, lineno: n4, colno: o2, filename: r2 }), t3 && t3.apply(this, arguments);
        };
      }
    })(), t2.unhandledRejection && t2.traceUnhandledRejection && r._traceUnhandledRejection && r._traceUnhandledRejection(), o = true);
  }, r.updateErrors = function(e2) {
    a(r._errorSettings, e2);
  }, r.updateAdditional = function(e2) {
    r._errorSettings.additional = a(r._errorSettings.additional || {}, e2);
  }, r._handleError = function(e2, o2, i2) {
    var s2, l2, c = r._errorSettings;
    if (c.preventError && e2.preventDefault && e2.preventDefault(), o2) s2 = e2, l2 = "client";
    else {
      s2 = r._normalizeError(e2), l2 = s2.type;
      var d = c.onError;
      "function" == typeof d && d(s2);
      var u = c.transform;
      if ("function" == typeof u && (s2 = u(s2)), !s2) return;
      s2.settings && (i2 = s2.settings);
    }
    var g = +/* @__PURE__ */ new Date(), f = c.initTimestamp, p = c.pageMaxAge;
    if (!(-1 !== p && f && f + p < g)) {
      var m = n[l2][1];
      "number" == typeof c.limits[l2] && (m = c.limits[l2]);
      var v = n[l2][2];
      "number" == typeof c.silent[l2] && (v = c.silent[l2]);
      var h = n[l2][3];
      if (h < m || -1 === m) {
        s2.path = n[l2][0];
        var E = r._getErrorData(
          s2,
          { silent: h < v || -1 === v ? "no" : "yes", isCustom: Boolean(o2) },
          a(a({}, c), i2)
        ), _ = function(e3) {
          t[s2.message] = false, r._sendError(e3.path, e3.vars), n[l2][3]++;
        }.bind(this, E);
        if (void 0 === c.throttleSend) _();
        else {
          if (t[s2.message]) return;
          t[s2.message] = true, setTimeout(_, c.throttleSend);
        }
      }
    }
  }, r._getReferrer = function(r2) {
    var n2 = r2.referrer, t2 = typeof n2;
    return "function" === t2 ? n2() : "string" === t2 && n2 ? n2 : false !== n2 && e.location ? e.location.href : void 0;
  }, r.getErrorSetting = function(e2) {
    return r._errorSettings[e2];
  }, r._buildExperiments = function(e2) {
    return e2 instanceof Array ? e2.join(";") : "";
  }, r._buildAdditional = function(e2, r2) {
    var n2 = "";
    try {
      var t2 = a(a({}, e2), r2);
      0 !== Object.keys(t2).length && (n2 = JSON.stringify(t2));
    } catch (e3) {
    }
    return n2;
  }, r._getErrorData = function(n2, t2, o2) {
    t2 = t2 || {};
    var a2 = r._buildExperiments(o2.experiments), s2 = r._buildAdditional(o2.additional, n2.additional), l2 = {
      "-stack": n2.stack,
      "-url": n2.file,
      "-line": n2.line,
      "-col": n2.col,
      "-block": n2.block,
      "-method": n2.method,
      "-msg": n2.message,
      "-env": o2.env,
      "-external": n2.external,
      "-externalCustom": n2.externalCustom,
      "-project": o2.project,
      "-service": n2.service || o2.service,
      "-page": n2.page || o2.page,
      "-platform": o2.platform,
      "-level": n2.level,
      "-experiments": a2,
      "-version": o2.version,
      "-region": o2.region,
      "-dc": o2.dc,
      "-host": o2.host,
      "-yandexuid": o2.yandexuid,
      "-loggedin": o2.loggedin,
      "-coordinates_gp": n2.coordinates_gp || o2.coordinates_gp,
      "-referrer": r._getReferrer(o2),
      "-source": n2.source,
      "-sourceMethod": n2.sourceMethod,
      "-type": t2.isCustom ? n2.type : "",
      "-additional": s2,
      "-adb": i(Ya.blocker) || i(o2.blocker),
      "-cdn": e.YaStaticRegion,
      "-ua": navigator.userAgent,
      "-silent": t2.silent,
      "-ts": +/* @__PURE__ */ new Date(),
      "-init-ts": o2.initTimestamp
    };
    return o2.debug && e.console && console[console[n2.level] ? n2.level : "error"]("[error-counter] " + n2.message, l2, n2.stack), { path: n2.path, vars: l2 };
  }, r._baseNormalizeError = function(e2) {
    var r2 = (e2 = e2 || {}).error, n2 = e2.filename || e2.fileName || "", t2 = r2 && r2.stack || e2.stack || "", o2 = e2.message || "", a2 = r2 && r2.additional || e2.additional;
    return {
      file: n2,
      line: e2.lineno || e2.lineNumber,
      col: e2.colno || e2.colNumber,
      stack: t2,
      message: o2,
      additional: a2
    };
  }, r._normalizeError = function(e2) {
    var n2 = r._baseNormalizeError(e2), t2 = "uncaught", o2 = r._isExternalError(n2.file, n2.message, n2.stack), a2 = "", i2 = "";
    return o2.hasExternal ? (t2 = "external", a2 = o2.common, i2 = o2.custom) : /^Script error\.?$/.test(n2.message) && (t2 = "script"), n2.external = a2, n2.externalCustom = i2, n2.type = t2, n2;
  }, r._createVarsString = function(e2) {
    var r2 = [];
    for (var n2 in e2)
      e2.hasOwnProperty(n2) && (e2[n2] || 0 === e2[n2]) && r2.push(n2 + "=" + encodeURIComponent(e2[n2]).replace(/\*/g, "%2A"));
    return r2.join(",");
  }, r._sendError = function(e2, n2) {
    r.send(null, e2, r._createVarsString(n2), null, null, null, null);
  };
  var s = function(e2) {
    r._handleError(e2, false);
  }, l = function(e2) {
    var n2 = e2.target;
    if (n2) {
      var t2 = n2.srcset || n2.src;
      if (t2 || (t2 = n2.href), t2) {
        var o2 = n2.tagName || "UNKNOWN";
        r.logError({ message: o2 + " load error", additional: { src: t2 } });
      }
    }
  };
  r._parseTraceablePromiseStack = function() {
  };
})("undefined" != typeof self ? self : window, Ya.Rum);
!(function(e) {
  var r = {
    url: {
      0: /(miscellaneous|extension)_bindings/,
      1: /^chrome:/,
      2: /kaspersky-labs\.com\//,
      3: /^(?:moz|chrome|safari)-extension:\/\//,
      4: /^file:/,
      5: /^resource:\/\//,
      6: /webnetc\.top/,
      7: /local\.adguard\.com/
    },
    message: {
      0: /__adgRemoveDirect/,
      1: /Content Security Policy/,
      2: /vid_mate_check/,
      3: /ucapi/,
      4: /Access is denied/i,
      5: /^Uncaught SecurityError/i,
      6: /__ybro/,
      7: /__show__deepen/,
      8: /ntp is not defined/,
      9: /Cannot set property 'install' of undefined/,
      10: /NS_ERROR/,
      11: /Error loading script/,
      12: /^TypeError: undefined is not a function$/,
      13: /__firefox__\.(?:favicons|metadata|reader|searchQueryForField|searchLoginField)/
    },
    stack: { 0: /(?:moz|chrome|safari)-extension:\/\//, 1: /adguard.*\.user\.js/i }
  };
  function n(e2, r2) {
    if (e2 && r2) {
      var n2 = [];
      for (var o2 in r2)
        if (r2.hasOwnProperty(o2)) {
          var i = r2[o2];
          "string" == typeof i && (i = new RegExp(i)), i instanceof RegExp && i.test(e2) && n2.push(o2);
        }
      return n2.join("_");
    }
  }
  function o(e2, o2) {
    var i, a = [];
    for (var t in r) r.hasOwnProperty(t) && (i = n(e2[t], o2[t])) && a.push(t + "~" + i);
    return a.join(";");
  }
  e._isExternalError = function(n2, i, a) {
    var t = e._errorSettings.filters || {}, s = { url: (n2 || "") + "", message: (i || "") + "", stack: (a || "") + "" }, c = o(s, r), u = o(s, t);
    return { common: c, custom: u, hasExternal: !(!c && !u) };
  };
})(Ya.Rum);
!(function() {
  "use strict";
  var e;
  (e = Ya.Rum).logError = function(r, o, s) {
    r = r || {}, "string" != typeof o && void 0 !== o || ((o = new Error(o)).justCreated = true);
    var a = r.message || "", t = e._baseNormalizeError(o);
    t.message && !r.ignoreErrorMessage && (a && (a += "; "), a += t.message), t.message = a || "Empty error";
    for (var g = [
      "service",
      "source",
      "type",
      "block",
      "additional",
      "level",
      "page",
      "method",
      "sourceMethod",
      "coordinates_gp"
    ], i = 0; i < g.length; i++) {
      var n = g[i];
      r[n] ? t[n] = r[n] : o && o[n] && (t[n] = o[n]);
    }
    e._handleError(t, true, s);
  };
})();
!(function() {
  "use strict";
  var e;
  (e = Ya.Rum).logEventString = function(n, t, r) {
    return e._logEvent("string", n, t, r);
  }, e.logEventFloat = function(n, t, r) {
    return e._logEvent("float", n, t, r);
  }, e.logEventInteger = function(n, t, r) {
    return e._logEvent("integer", n, t, r);
  }, e._logEvent = function(n, t, r, i) {
    i = i || {};
    var l = e._errorSettings, o = e._buildAdditional(l.additional, i.additional), a = e._buildExperiments(l.experiments), g = {
      "-env": l.env,
      "-project": l.project,
      "-service": i.service || l.service,
      "-page": i.page || l.page,
      "-platform": l.platform,
      "-experiments": a,
      "-version": l.version,
      "-yandexuid": l.yandexuid,
      "-loggedin": l.loggedin,
      "-referrer": e._getReferrer(l),
      "-additional": o,
      "-ts": +/* @__PURE__ */ new Date(),
      "-type": n,
      "-name": t,
      "-value": r
    };
    return e.send(null, "690.32", e._createVarsString(g), null, null, null, ["table=rum_events"]);
  };
})();
function initErrorBooster({
  project,
  page,
  regionId,
  platform,
  environment,
  version,
  unhandledRejection,
  uncaughtException,
  resourceFails
}) {
  Ya.Rum.initErrors({
    project: `'${project}'`,
    page,
    region: regionId,
    ...platform ? { "-platform": platform } : {},
    env: environment,
    version,
    unhandledRejection,
    uncaughtException,
    resourceFails
  });
}
