!(function(e) {
  if (e.Ya = e.Ya || {}, Ya.Rum) throw new Error("Rum: interface is already defined");
  var t = e.performance, n = t && t.timing && t.timing.navigationStart || Ya.startPageLoad || +/* @__PURE__ */ new Date(), i = e.requestAnimationFrame, s = function() {
  }, r = Ya.Rum = {
    _defTimes: [],
    _defRes: [],
    _countersToExposeAsEvents: ["2325", "2616.85.1928", "react.inited"],
    enabled: !!t,
    version: "6.1.24",
    vsStart: document.visibilityState,
    vsChanged: false,
    vsChangeTime: 1 / 0,
    _deltaMarks: {},
    _markListeners: {},
    _onComplete: [],
    _onInit: [],
    _unsubscribers: [],
    _eventLisneters: {},
    _settings: {},
    _vars: {},
    init: function(e2, t2) {
      r._settings = e2, r._vars = t2;
    },
    getTime: t && t.now ? function() {
      return t.now();
    } : Date.now ? function() {
      return Date.now() - n;
    } : function() {
      return /* @__PURE__ */ new Date() - n;
    },
    time: function(e2) {
      r._deltaMarks[e2] = [r.getTime()];
    },
    timeEnd: function(e2, t2) {
      var n2 = r._deltaMarks[e2];
      n2 && 0 !== n2.length && n2.push(r.getTime(), t2);
    },
    sendTimeMark: function(e2, t2, n2, i2) {
      void 0 === t2 && (t2 = r.getTime()), r.emit({ metricName: "defTimes", data: [e2, t2, i2] }), r.mark(e2, t2);
    },
    sendDelta: function(e2, t2, n2, i2) {
      var s2, a2 = r._deltaMarks;
      a2[e2] || void 0 === t2 || (s2 = i2 && i2.originalEndTime ? i2.originalEndTime : r.getTime(), a2[e2] = [s2 - t2, s2, n2]);
    },
    sendResTiming: function(e2, t2) {
      r.emit({ metricName: "defRes", data: [e2, t2] });
    },
    sendRaf: function(e2) {
      var t2 = r.getSetting("forcePaintTimeSending");
      if (i && (t2 || r.isTimeAfterPageShow(r.getTime()))) {
        var n2 = "2616." + e2;
        i(function() {
          r.getSetting("sendFirstRaf") && r.sendTimeMark(n2 + ".205"), i(function() {
            r.sendTimeMark(n2 + ".1928");
          });
        });
      }
    },
    isVisibilityChanged: function() {
      return r.vsStart && ("visible" !== r.vsStart || r.vsChanged);
    },
    isTimeAfterPageShow: function(e2) {
      return "visible" === r.vsStart || r.vsChangeTime < e2;
    },
    mark: t && t.mark ? function(e2, n2) {
      t.mark(e2 + (n2 ? ": " + n2 : ""));
    } : function() {
    },
    getSetting: function(e2) {
      var t2 = r._settings[e2];
      return null === t2 ? null : t2 || "";
    },
    on: function(e2, t2) {
      if ("function" == typeof t2)
        return (r._markListeners[e2] = r._markListeners[e2] || []).push(t2), function() {
          if (r._markListeners[e2]) {
            var n2 = r._markListeners[e2].indexOf(t2);
            n2 > -1 && r._markListeners[e2].splice(n2, 1);
          }
        };
    },
    noop: s,
    sendTrafficData: s,
    finalizeLayoutShiftScore: s,
    finalizeLargestContentfulPaint: s,
    getLCPAdditionalParams: s,
    getCLSAdditionalParams: s,
    getINPAdditionalParams: s,
    getImageGoodnessAdditionalParams: s,
    _eventListeners: {},
    _eventsBuffer: {},
    subscribe: function(e2, t2) {
      if (!r.getSetting("noEvents"))
        return this._eventLisneters[e2] = this._eventLisneters[e2] || /* @__PURE__ */ new Set(), this._eventLisneters[e2].add(t2), function() {
          this.unsubscribe(e2, t2);
        }.bind(this);
    },
    unsubscribe: function(e2, t2) {
      this._eventLisneters[e2].delete(t2);
    },
    emit: function(e2) {
      if (!r.getSetting("noEvents")) {
        var t2 = r.getSetting("eventsLimits") && r.getSetting("eventsLimits")[e2.metricName] || 20;
        this._eventLisneters[e2.metricName] && this._eventLisneters[e2.metricName].forEach(function(t3) {
          t3(e2);
        }), this._eventsBuffer[e2.metricName] = this._eventsBuffer[e2.metricName] || [], this._eventsBuffer[e2.metricName].push(e2), this._eventsBuffer[e2.metricName].length > t2 && (this._eventsBuffer[e2.metricName].length = Math.floor(t2 / 2));
      }
    },
    getBufferedEvents: function(e2) {
      var t2 = this._eventsBuffer, n2 = {};
      return Object.keys(t2).forEach(function(i2) {
        -1 !== e2.indexOf(i2) && (n2[i2] = t2[i2]);
      }), n2;
    },
    clearEvents: function(e2) {
      this._eventsBuffer[e2] && (this._eventsBuffer[e2].length = 0);
    }
  };
  function a() {
    Ya.Rum.vsChanged = true, Ya.Rum.vsChangeTime = r.getTime(), removeEventListener("visibilitychange", a);
  }
  addEventListener("visibilitychange", a), r._onVisibilityChange = a;
})(window);
!(function() {
  var e, t, n, i = Ya.Rum, o = 42, r = 4e4, g = 15, a = [], s = i.getSetting("countersInitialDelay") || 0;
  if (s) {
    let c2 = function() {
      removeEventListener("visibilitychange", u2), clearTimeout(l), s = 0, h();
    }, u2 = function() {
      document.hidden && c2();
    };
    var c = c2, u = u2;
    var l;
    l = setTimeout(c2, s), addEventListener("visibilitychange", u2);
  }
  function h() {
    if (t && a.length) {
      for (var n2 = 0, i2 = 0, s2 = 0; i2 < a.length && s2 <= r && n2 < o; i2++) (s2 += (i2 ? 2 : 0) + a[i2].length) <= r && n2++;
      var l2 = a.splice(0, n2);
      f(t, l2.join("\r\n")), a.length && (e = setTimeout(h, g));
    } else a.length = 0;
  }
  function f(e2, t2) {
    if (!(navigator.sendBeacon && n && navigator.sendBeacon(e2, t2))) {
      var o2 = Boolean(i.getSetting("sendCookie")), r2 = new XMLHttpRequest();
      r2.open("POST", e2), r2.withCredentials = o2, r2.send(t2);
    }
  }
  i.send = function(l2, c2, u2, f2, d, v, m, S) {
    t = i.getSetting("clck"), n = i.getSetting("beacon"), o = i.getSetting("maxBatchCounters") || o, r = i.getSetting("maxBatchLength") || r, g = i.getSetting("countersBatchTimeout") || g, (function(t2, n2, i2, l3, c3, u3, f3) {
      clearTimeout(e);
      var d2 = [
        t2 ? "/reqid=" + t2 : "",
        n2 ? "/" + n2.join("/") : "",
        i2 ? "/path=" + i2 : "",
        l3 ? "/events=" + l3 : "",
        c3 ? "/slots=" + c3.join(";") : "",
        u3 ? "/experiments=" + u3.join(";") : "",
        f3 ? "/vars=" + f3 : "",
        "/cts=" + (/* @__PURE__ */ new Date()).getTime(),
        "",
        "/*"
      ].join("");
      d2.length > r ? "undefined" != typeof console && console.error && console.error("Counter length " + d2.length + " is more than allowed " + r, d2) : (a.push(d2), s || ((function() {
        if (a.length >= o) return true;
        for (var e2 = 0, t3 = 0; t3 < a.length; t3++) if ((e2 += (t3 ? 2 : 0) + a[t3].length) >= r) return true;
        return false;
      })() ? h() : e = setTimeout(h, g)));
    })(i.getSetting("reqid"), m, c2, d, i.getSetting("slots"), i.getSetting("experiments"), u2);
  };
})();
!(function() {
  if (window.PerformanceLongTaskTiming) {
    let r2 = function() {
      var r3 = Ya.Rum._tti = {
        events: [],
        loafEvents: n ? [] : void 0,
        eventsAfterTTI: [],
        fired: false,
        observer: new PerformanceObserver(function(t2) {
          var o = t2.getEntriesByType("longtask"), s = t2.getEntriesByType("long-animation-frame");
          r3.events = e(r3.events, o), n && (r3.loafEvents = e(r3.loafEvents, s)), r3.fired && (r3.eventsAfterTTI = e(r3.eventsAfterTTI, o));
        })
      };
      r3.observer.observe({ entryTypes: t }), Ya.Rum._unsubscribers && Ya.Rum._unsubscribers.push(function() {
        r3.observer.disconnect();
      });
    };
    var r = r2;
    var e = function(e2, n2) {
      return (e2 = e2.concat(n2)).length > 300 && (e2 = e2.slice(e2.length - 300)), e2;
    }, n = "undefined" != typeof PerformanceLongAnimationFrameTiming, t = n ? ["longtask", "long-animation-frame"] : ["longtask"];
    r2(), Ya.Rum._onInit.push(r2);
  }
})();
Ya.Rum.observeDOMNode = window.IntersectionObserver ? function(e, i, n) {
  var t = this, o = Ya.Rum.getSetting("forcePaintTimeSending");
  !(function r() {
    if (o || !t.isVisibilityChanged()) {
      var s = "string" == typeof i ? document.querySelector(i) : i;
      s ? new IntersectionObserver(function(i2, n2) {
        !o && t.isVisibilityChanged() || (Ya.Rum.sendTimeMark(e), n2.unobserve(s));
      }, n).observe(s) : setTimeout(r, 100);
    }
  })();
} : function() {
};
!(function(e) {
  var t = window.requestAnimationFrame, a = console;
  if (!e) throw new Error("Rum: interface is not included");
  if (e.enabled) {
    e.sendAnimationSpeed = function(a2, i2, r2) {
      if (t) {
        var n2 = [], s2 = e.getTime(), o = e.getTime();
        !(function d() {
          t(function() {
            var t2 = e.getTime();
            n2.push(t2 - o), o = t2, t2 - s2 < i2 ? d() : (e.sendDelta(
              a2 + ".avg",
              (function(e2) {
                for (var t3 = e2.length, a3 = 0, i3 = 0; i3 < t3; i3++) a3 += e2[i3];
                return a3 / t3;
              })(n2),
              r2
            ), e.sendDelta(
              a2 + ".mdn",
              (function(e2) {
                var t3 = e2.sort(function(e3, t4) {
                  return e3 - t4;
                }), a3 = e2.length >> 1;
                return t3.length % 2 ? t3[a3] : (t3[a3 - 1] + t3[a3]) / 2;
              })(n2),
              r2
            ));
          });
        })();
      }
    };
    var i = {}, r = {};
    e.spa = {
      makeSpaSubPage: function(t2, a2, n2, s2, o) {
        a2 = a2 || { finishDataLoadingMetric: true, startDataRenderingMetric: true, finishDataRenderingMetric: true }, n2 = n2 || false, (s2 = s2 || false) && e.completeSession();
        var d = e.makeSubPage((n2 ? "block" : "page") + "." + t2);
        return o && Object.keys(o).forEach(function(e2) {
          d[e2] = o[e2];
        }), r[t2] = { spaMetricsOptions: a2 }, i[t2] = d, d;
      },
      startStubRendering: function(s2, o) {
        o = false !== o;
        var d = i[s2], g = r[s2];
        if (d && g)
          if (g.stubRenderingStartTime)
            a.error("startStubRendering have been called repeatedly for subpage " + s2 + ".");
          else {
            var p = e.getTime();
            g.stubRenderingStartTime = p, g.spaMetricsOptions && g.spaMetricsOptions.startStubRenderingMetric && e.sendDelta("stub.render.start", p - Number(d[689.2322]), d), o && t && t(function() {
              n(s2);
            });
          }
        else a.error("No subpage " + s2 + ".");
      },
      finishStubRendering: n,
      startDataLoading: function(t2) {
        var n2 = i[t2], s2 = r[t2];
        if (n2 && s2)
          if (s2.dataLoadingStartTime) a.error("startDataLoading have been called repeatedly for subpage " + t2 + ".");
          else {
            var o = e.getTime();
            s2.dataLoadingStartTime = o, s2.spaMetricsOptions && s2.spaMetricsOptions.startDataLoadingMetric && e.sendDelta("data.load.start", o - Number(n2[689.2322]), n2);
          }
        else a.error("No subpage " + t2 + ".");
      },
      finishDataLoading: function(t2, n2) {
        n2 = n2 || false;
        var s2 = i[t2], o = r[t2];
        if (s2 && o)
          if (o.dataLoadingFinishTime) a.error("finishDataLoading have been called repeatedly for subpage " + t2 + ".");
          else {
            var d = e.getTime();
            o.dataLoadingFinishTime = d, !o.dataLoadingStartTime && o.spaMetricsOptions && o.spaMetricsOptions.startDataLoadingMetric && a.error("No dataLoadingStartTime for subpage " + t2 + "."), o.spaMetricsOptions && o.spaMetricsOptions.finishDataLoadingMetric && e.sendDelta(
              "data.load.finish." + (n2 ? "cache" : "network"),
              d - (o.dataLoadingStartTime || Number(s2[689.2322])),
              s2
            );
          }
        else a.error("No subpage " + t2 + ".");
      },
      startDataRendering: function(n2, o, d, g) {
        o = o || "", d = false !== d, g = "number" == typeof g ? g : 1e3;
        var p = i[n2], u = r[n2];
        if (p && u)
          if (u.dataLoadingFinishTime)
            if (u.dataRenderingStartTime)
              a.error("startDataRendering have been called repeatedly for subpage " + n2 + ".");
            else {
              var c = e.getTime();
              u.dataRenderingStartTime = c, u.spaMetricsOptions && u.spaMetricsOptions.startDataRenderingMetric && e.sendDelta("data.render.start" + (o ? "." + o : ""), c - u.dataLoadingFinishTime, p), d && t && t(function() {
                s(n2, o, g);
              });
            }
          else a.error("No dataLoadingFinishTime for subpage " + n2 + ".");
        else a.error("No subpage " + n2 + ".");
      },
      finishDataRendering: s,
      getLastSpaSubPage: function(e2) {
        return i[e2] || (a.error("No subpage " + e2 + "."), null);
      },
      setLogger: function(e2) {
        a = e2;
      }
    };
  }
  function n(t2) {
    var n2 = i[t2], s2 = r[t2];
    if (n2 && s2)
      if (s2.stubRenderingFinishTime) a.error("finishStubRendering have been called repeatedly for subpage " + t2 + ".");
      else {
        var o = e.getTime();
        s2.stubRenderingFinishTime = o, !s2.stubRenderingStartTime && s2.spaMetricsOptions && s2.spaMetricsOptions.startStubRenderingMetric && a.error("No stubRenderingStartTime for subpage " + t2 + "."), s2.spaMetricsOptions && s2.spaMetricsOptions.finishStubRenderingMetric && e.sendDelta("stub.render.finish", o - (s2.stubRenderingStartTime || Number(n2[689.2322])), n2);
      }
    else a.error("No subpage " + t2 + ".");
  }
  function s(t2, n2, s2) {
    n2 = n2 || "", s2 = "number" == typeof s2 ? s2 : 1e3;
    var o = i[t2], d = r[t2];
    if (o && d)
      if (d.dataRenderingStartTime)
        if (d.dataRenderingFinishTime)
          a.error("finishDataRendering have been called repeatedly for subpage " + t2 + ".");
        else {
          var g = e.getTime();
          d.dataRenderingFinishTime = g, d.spaMetricsOptions && d.spaMetricsOptions.finishDataRenderingMetric && e.sendDelta("data.render.finish" + (n2 ? "." + n2 : ""), g - d.dataRenderingStartTime, o), d.spaMetricsOptions && d.spaMetricsOptions.animationSpeedMetric && e.sendAnimationSpeed && e.sendAnimationSpeed("data.render" + (n2 ? "." + n2 : "") + ".animation", s2, o);
        }
      else a.error("No dataRenderingStartTime for subpage " + t2 + ".");
    else a.error("No subpage " + t2 + ".");
  }
})(Ya.Rum);
function initRum({
  environment,
  heroElement,
  page,
  platform,
  project,
  regionId,
  requestId,
  rumId,
  sendClientUa,
  service,
  testIds,
  version
}) {
  const slots = testIds == null ? void 0 : testIds.join("','");
  Ya.Rum.init(
    {
      beacon: !!navigator.sendBeacon,
      clck: "https://yandex.ru/clck/click",
      ...slots ? { slots } : {},
      reqid: requestId,
      sendClientUa
    },
    {
      rum_id: rumId,
      "-region": regionId,
      "-project": `'${project}'`,
      ...platform ? { "-platform": platform } : {},
      ...service ? { "-service": service } : {},
      "-env": environment,
      "-page": page,
      "-version": version
    }
  );
  !(function() {
    var e = Ya.Rum, n = !window.BigInt || !("PerformanceObserver" in window);
    function t(n2) {
      e._unsubscribers.push(n2);
    }
    function i(e2, i2, o2) {
      if (!n) {
        var a2 = o2 || {};
        if (e2) {
          a2.type = e2, a2.hasOwnProperty("buffered") || (a2.buffered = true);
          var s2 = new PerformanceObserver(function(e3, n2) {
            return i2(e3.getEntries(), n2);
          });
          return r(function() {
            try {
              s2.observe(a2);
            } catch (e3) {
              return void console.error(e3.message);
            }
            t(function() {
              s2.disconnect();
            });
          }, 0), s2;
        }
        throw new Error("PO without type field is forbidden");
      }
    }
    function r(e2, n2) {
      var i2 = setTimeout(e2, n2);
      return t(function() {
        clearInterval(i2);
      }), i2;
    }
    function o(e2, n2, i2) {
      addEventListener(e2, n2, i2), t(function() {
        removeEventListener(e2, n2, i2);
      });
    }
    function a(e2, n2, t2) {
      o("visibilitychange", function i2() {
        if ("hidden" === document.visibilityState) {
          try {
            t2 || (removeEventListener("visibilitychange", i2), e2.disconnect());
          } catch (e3) {
          }
          n2();
        }
      }), o("beforeunload", n2);
    }
    function s(e2, n2) {
      return "string" == typeof e2 ? encodeURIComponent(e2) : Math.round(1e3 * (e2 - (n2 || 0))) / 1e3;
    }
    function c(e2) {
      if (!e2) return "";
      var n2 = (e2.tagName || "").toLowerCase(), t2 = e2.className && void 0 !== e2.className.baseVal ? e2.className.baseVal : e2.className;
      return n2 + (t2 ? (" " + t2).replace(/\s+/g, ".") : "");
    }
    function u(e2) {
      function n2() {
        removeEventListener("DOMContentLoaded", n2), removeEventListener("load", n2), e2();
      }
      "loading" === document.readyState ? (o("DOMContentLoaded", n2), o("load", n2)) : e2();
    }
    function d(n2) {
      e._onComplete.push(n2);
    }
    function f() {
      return e._periodicTasks;
    }
    function l() {
      var n2 = e._vars;
      return Object.keys(n2).map(function(e2) {
        return e2 + "=" + encodeURIComponent(n2[e2]).replace(/\*/g, "%2A");
      });
    }
    var m = {
      connectEnd: 2116,
      connectStart: 2114,
      decodedBodySize: 2886,
      domComplete: 2124,
      domContentLoadedEventEnd: 2131,
      domContentLoadedEventStart: 2123,
      domInteractive: 2770,
      domLoading: 2769,
      domainLookupEnd: 2113,
      domainLookupStart: 2112,
      duration: 2136,
      encodedBodySize: 2887,
      entryType: 2888,
      fetchStart: 2111,
      initiatorType: 2889,
      loadEventEnd: 2126,
      loadEventStart: 2125,
      nextHopProtocol: 2890,
      redirectCount: 1385,
      redirectEnd: 2110,
      redirectStart: 2109,
      requestStart: 2117,
      responseEnd: 2120,
      responseStart: 2119,
      secureConnectionStart: 2115,
      startTime: 2322,
      transferSize: 2323,
      type: 76,
      unloadEventEnd: 2128,
      unloadEventStart: 2127,
      workerStart: 2137
    };
    function v(n2, t2) {
      Object.keys(m).forEach(function(e2) {
        if (e2 in t2) {
          var i2 = t2[e2];
          (i2 || 0 === i2) && n2.push(m[e2] + "=" + s(i2));
        }
      }), n2.push("".concat(625, "=").concat(e.version));
    }
    var g, p, h, y, S, T = e.getSetting("savedDeltasLimit") || 0, b = document.createElement("link"), w = window.performance || {}, E = "function" == typeof w.getEntriesByType, C = 0;
    function k(n2, t2, i2, r2, o2) {
      void 0 === t2 && (t2 = e.getTime()), void 0 !== i2 && true !== i2 || e.mark(n2, t2);
      var a2 = L(n2);
      if (a2.push("207=" + s(t2)), _(a2, r2)) {
        O("690.2096.207", a2, o2 && o2.force), g[n2] = g[n2] || [], g[n2].push(t2);
        var c2 = e._markListeners[n2];
        c2 && c2.length && c2.forEach(function(e2) {
          e2(t2);
        }), e.emit({ metricName: n2, value: t2, params: r2 });
      }
    }
    function L(n2) {
      return S.concat([
        e.isVisibilityChanged() ? "-vsChanged=1" : "",
        "1701=" + n2,
        e.ajaxStart && "1201.2154=" + s(e.ajaxStart),
        e.ajaxComplete && "1201.2052=" + s(e.ajaxComplete)
      ]);
    }
    function P() {
      y = l(), e.getSetting("sendClientUa") && y.push("1042=" + encodeURIComponent(navigator.userAgent));
    }
    function M() {
      var e2 = window.performance && window.performance.timing && window.performance.timing.navigationStart;
      S = y.concat(["143.2129=" + e2]);
    }
    function _(e2, n2) {
      if (n2) {
        if (n2.isCanceled && n2.isCanceled()) return false;
        var t2 = e2.reduce(function(e3, n3, t3) {
          return "string" == typeof n3 && (e3[n3.split("=")[0]] = t3), e3;
        }, {});
        Object.keys(n2).forEach(function(i2) {
          if ("function" != typeof n2[i2]) {
            var r2 = t2[i2], o2 = i2 + "=" + n2[i2];
            void 0 === r2 ? e2.push(o2) : e2[r2] = o2;
          }
        });
      }
      return true;
    }
    function O(n2, t2, i2) {
      var r2 = encodeURIComponent(window.YaStaticRegion || "unknown");
      t2.push("-cdn=" + r2);
      var o2 = t2.filter(Boolean).join(",");
      e.send(null, n2, o2, void 0, void 0, void 0, void 0, i2);
    }
    function I(e2, n2, t2) {
      O(e2, z().concat(n2), t2);
    }
    function N(n2, t2) {
      var i2 = h[n2];
      i2 && 0 !== i2.length && (i2.push(e.getTime(), t2), R(n2));
    }
    function R(n2, t2, i2, r2) {
      var o2, a2, c2, u2 = h[n2];
      if (void 0 !== t2 ? o2 = (a2 = r2 && r2.originalEndTime ? r2.originalEndTime : e.getTime()) - t2 : u2 && (o2 = u2[0], a2 = u2[1], c2 = u2[2]), void 0 !== o2 && void 0 !== a2) {
        var d2 = L(n2);
        d2.push("207.2154=" + s(o2), "207.1428=" + s(a2), "2877=" + s(a2 - o2)), _(d2, i2) && _(d2, c2) && (O("690.2096.2877", d2, r2 && r2.force), C < T && (p[n2] = p[n2] || [], p[n2].push(a2 - o2), C++), e.emit({ metricName: n2, value: a2 - o2, params: { start: o2, end: a2 } }), delete h[n2]);
      }
    }
    function x(e2, n2) {
      if (!E) return n2(null);
      b.href = e2;
      var t2 = 0, i2 = 100, o2 = b.href;
      r(function e3() {
        var a2 = w.getEntriesByName(o2);
        if (a2.length) return n2(a2);
        t2++ < 3 ? (r(e3, i2), i2 += i2) : n2(null);
      }, 0);
    }
    function A(e2, n2, t2) {
      x(n2, function(i2) {
        i2 && j(e2, i2[i2.length - 1], n2, t2);
      });
    }
    function j(n2, t2, i2, r2) {
      var o2 = L(n2);
      e.getSetting("sendUrlInResTiming") && o2.push("13=" + encodeURIComponent(i2)), v(o2, t2), _(o2, r2), O("690.2096.2044", o2);
    }
    function z() {
      return y;
    }
    var B = {
      bluetooth: 2064,
      cellular: 2065,
      ethernet: 2066,
      none: 1229,
      wifi: 2067,
      wimax: 2068,
      other: 861,
      unknown: 836,
      0: 836,
      1: 2066,
      2: 2067,
      3: 2070,
      4: 2071,
      5: 2768
    }, V = navigator.connection;
    function U(e2) {
      if (V) {
        var n2 = B[V.type];
        e2.push(
          "2437=" + (n2 || 2771),
          void 0 !== V.downlinkMax && "2439=" + V.downlinkMax,
          V.effectiveType && "2870=" + V.effectiveType,
          void 0 !== V.rtt && "rtt=" + V.rtt,
          void 0 !== V.downlink && "dwl=" + V.downlink,
          !n2 && "rawType=" + V.type
        );
      }
    }
    var D, F, W, H, J, Q, Y, q, G = false, $ = 1 / 0, K = 1 / 0, X = Boolean(
      window.PerformanceObserver && window.PerformanceObserver.supportedEntryTypes && -1 !== window.PerformanceObserver.supportedEntryTypes.indexOf("layout-shift")
    ) ? 0 : null;
    function Z() {
      J > F && (F = J, W = H, e.emit({ metricName: "cls-debug", value: F, params: { clsEntries: W, target: ee(W) } }));
    }
    function ee(e2) {
      var n2;
      if (!e2) return null;
      var t2 = null;
      if ((n2 = e2.reduce(function(e3, n3) {
        return e3 && e3.value > n3.value ? e3 : n3;
      })) && n2.sources && n2.sources.length) {
        for (var i2 = 0; i2 < n2.sources.length; i2++) {
          var r2 = n2.sources[i2];
          if (r2.node && 1 === r2.node.nodeType) {
            t2 = r2;
            break;
          }
        }
        t2 = t2 || n2.sources[0];
      }
      return t2;
    }
    function ne(e2) {
      null == F && (F = 0);
      for (var n2 = 0; n2 < e2.length; n2++) {
        var t2 = e2[n2];
        t2.hadRecentInput || (J && t2.startTime - H[H.length - 1].startTime < $ && t2.startTime - H[0].startTime < K ? (J += t2.value, H.push(t2)) : (Z(), J = t2.value, H = [t2]));
      }
      Z();
    }
    function te() {
      F = X, D = void 0, W = null, H = null, J = null, G = false;
    }
    function ie(n2) {
      if (null != F && !G) {
        var t2 = Math.round(1e6 * F) / 1e6;
        if (D !== t2) {
          D = t2, e.getSetting("enableContinuousCollection") || (G = true);
          var i2 = ee(W), r2 = ["s=" + t2];
          r2.push("target=" + c(i2 && i2.node));
          var o2 = e.getCLSAdditionalParams(i2);
          o2 && _(r2, o2), I("690.2096.4004", r2, n2), e.emit({ metricName: "cls-debug", value: F, params: { clsEntries: H, target: i2, isFinalized: G } });
        }
      }
    }
    function re(n2) {
      var t2 = n2[n2.length - 1];
      if (Q = e.correctTime(t2.renderTime || t2.loadTime), Y = t2, e.emit({ metricName: "largest-contentful-paint-debug", value: Q, params: { entry: t2 } }), !q) {
        var i2 = Q;
        e.whenActivated(function() {
          return k("largest-loading-elem-paint", i2);
        }), q = true;
      }
    }
    function oe(n2) {
      if (null != Q) {
        var t2 = e.getLCPAdditionalParams(Y);
        k("largest-contentful-paint", Q, false, t2, n2 && { force: true }), e.emit({
          metricName: "largest-contentful-paint-debug",
          value: Q,
          params: { additionalParams: t2, entry: Y, isFinalized: true }
        }), Q = null, Y = null;
      }
    }
    e.getLCPAdditionalParams === e.noop && (e.getLCPAdditionalParams = function(n2) {
      var t2 = {}, i2 = n2.element;
      if (i2) {
        t2["-className"] = e.getSelector(i2), t2["-tagName"] = i2.tagName.toLowerCase();
        var r2 = i2.getBoundingClientRect();
        t2["-width"] = r2.width, t2["-height"] = r2.height;
      }
      return n2.size && (t2["-size"] = n2.size), t2;
    });
    var ae = { "first-paint": 2793, "first-contentful-paint": 2794 }, se = Object.keys(ae).length, ce = {}, ue = window.performance || {}, de = "function" == typeof ue.getEntriesByType, fe = 0;
    function le() {
      if (de && (e.getSetting("forcePaintTimeSending") || !e.isVisibilityChanged()))
        for (var n2 = ue.getEntriesByType("paint"), t2 = function() {
          var t3 = n2[i2], r2 = ae[t3.name];
          if (r2 && !ce[t3.name]) {
            ce[t3.name] = true, fe++;
            var o2 = "1926." + r2;
            e.whenActivated(function() {
              return k(o2, e.correctTime(t3.startTime));
            });
          }
        }, i2 = 0; i2 < n2.length; i2++)
          t2();
    }
    function me() {
      return e._tti.events || [];
    }
    function ve() {
      return e._tti.loafEvents;
    }
    function ge() {
      return e._tti;
    }
    function pe(n2) {
      return n2 ? n2 === e.getPageUrl() ? "<page>" : n2.replace(/\?.*$/, "") : n2;
    }
    function he(n2, t2, i2) {
      if (ge()) {
        var r2 = e.getTime(), o2 = "undefined" != typeof PerformanceLongAnimationFrameTiming && e.getSetting("sendLongAnimationFrames");
        ye(function(a2) {
          var c2, u2 = { 2796.2797: Se(me(), t2), 689.2322: s(r2) };
          if (o2) {
            var d2 = (function(e2) {
              var n3 = ve();
              if (n3)
                return e2 ? n3.filter(function(n4) {
                  return n4.startTime + n4.duration >= e2;
                }) : n3;
            })(t2);
            d2 && (u2["loaf.2797"] = Se(d2, void 0, { useName: false }), 1 === e.getSetting("longAnimationFramesMode") && (u2["-additional"] = encodeURIComponent(JSON.stringify({ loaf: (c2 = d2, c2.map(Te)) }))));
          }
          i2 && Object.keys(i2).forEach(function(e2) {
            u2[e2] = i2[e2];
          }), k(n2 || "2795", a2, true, u2, { force: Boolean(o2) }), e._tti.fired = true;
        }, t2);
      }
    }
    function ye(n2, t2) {
      var i2 = (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}).mode, o2 = void 0 === i2 ? 1 : i2;
      ge() && (t2 || (t2 = e.getTime()), (function i3() {
        var a2, s2 = t2, c2 = e.getTime(), u2 = 1 === o2 ? me() : ve() || [], d2 = u2.length;
        0 !== d2 && (a2 = u2[d2 - 1], s2 = Math.max(s2, Math.floor(a2.startTime + a2.duration))), c2 - s2 >= 3e3 ? n2(s2) : r(i3, 1e3);
      })());
    }
    function Se(e2, n2) {
      var t2 = (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}).useName, i2 = void 0 === t2 || t2;
      return n2 = n2 || 0, (e2 = e2 || []).filter(function(e3) {
        return n2 - e3.startTime <= 50;
      }).map(function(e3) {
        var n3 = Math.floor(e3.startTime), t3 = Math.floor(n3 + e3.duration);
        return i2 ? (e3.name ? e3.name.split("-").map(function(e4) {
          return e4[0];
        }).join("") : "u") + "-" + n3 + "-" + t3 : n3 + "-" + t3;
      }).join(".");
    }
    function Te(e2) {
      var n2 = e2.blockingDuration, t2 = e2.duration, i2 = e2.firstUIEventTimestamp, r2 = e2.renderStart, o2 = e2.scripts, a2 = e2.startTime, s2 = e2.styleAndLayoutStart;
      return [Math.round(a2), Math.round(t2), o2.map(we), Math.round(n2), Math.round(i2), Math.round(r2), Math.round(s2)];
    }
    function be(e2) {
      return {
        "user-callback": 1,
        "event-listener": 2,
        "resolve-promise": 3,
        "reject-promise": 4,
        "classic-script": 5,
        "module-script": 6
      }[e2] || 0;
    }
    function we(e2) {
      var n2 = e2.invoker, t2 = e2.sourceURL, i2 = e2.sourceFunctionName, r2 = e2.sourceCharPosition, o2 = e2.startTime, a2 = e2.duration, s2 = e2.windowAttribution, c2 = e2.executionStart, u2 = e2.forcedStyleAndLayoutDuration, d2 = e2.pauseDuration, f2 = e2.invokerType;
      return [pe(n2), pe(t2), i2, r2, Math.round(o2), Math.round(a2), s2, Math.round(c2), Math.round(u2), Math.round(d2), be(f2)];
    }
    var Ee = document.createElement("a"), Ce = 0, ke = {};
    function Le(e2) {
      var n2 = e2.transferSize;
      if (null != n2) {
        Ee.href = e2.name;
        var t2 = Ee.pathname;
        if (0 !== t2.indexOf("/clck")) {
          var i2 = t2.lastIndexOf("."), r2 = "";
          return -1 !== i2 && t2.lastIndexOf("/") < i2 && t2.length - i2 <= 5 && (r2 = t2.slice(i2 + 1)), { size: n2, domain: Ee.hostname, extension: r2 };
        }
      }
    }
    function Pe() {
      var n2 = e.getSetting("maxTrafficCounters") || 250;
      if (Ce >= n2) return false;
      for (var t2 = Object.keys(ke), i2 = "", r2 = 0; r2 < t2.length; r2++) {
        var o2 = t2[r2], a2 = ke[o2];
        i2 += encodeURIComponent(o2) + "!" + a2.count + "!" + a2.size + ";";
      }
      return i2.length && (Ce++, I("690.2096.361", ["d=" + i2, "t=" + s(e.getTime())])), ke = {}, Ce < n2;
    }
    d(Pe);
    var Me = { visible: 1, hidden: 2, prerender: 3 }, _e = window.performance || {}, Oe = _e.navigation || {}, Ie = _e.timing || {}, Ne = Ie.navigationStart;
    function Re() {
      var n2 = Ie.domContentLoadedEventStart, t2 = Ie.domContentLoadedEventEnd;
      if (0 !== n2 || 0 !== t2) {
        var i2 = 0 === Ie.responseStart ? Ne : Ie.responseStart, o2 = 0 === Ie.domainLookupStart ? Ne : Ie.domainLookupStart, a2 = [
          "2129=" + Ne,
          "1036=" + (o2 - Ne),
          "1037=" + (Ie.domainLookupEnd - Ie.domainLookupStart),
          "1038=" + (Ie.connectEnd - Ie.connectStart),
          Ie.secureConnectionStart && "1383=" + (Ie.connectEnd - Ie.secureConnectionStart),
          "1039=" + (Ie.responseStart - Ie.connectEnd),
          "1040=" + (Ie.responseEnd - i2),
          "1040.906=" + (Ie.responseEnd - o2),
          "1310.2084=" + (Ie.domLoading - i2),
          "1310.2085=" + (Ie.domInteractive - i2),
          "1310.1309=" + (t2 - n2),
          "1310.1007=" + (n2 - i2),
          navigator.deviceMemory && "3140=" + navigator.deviceMemory,
          navigator.hardwareConcurrency && "3141=" + navigator.hardwareConcurrency
        ];
        Object.keys(m).forEach(function(e2) {
          e2 in Ie && Ie[e2] && a2.push(m[e2] + "=" + s(Ie[e2], Ne));
        }), e.vsStart ? (a2.push("1484=" + (Me[e.vsStart] || 2771)), e.vsChanged && a2.push("1484.719=1")) : a2.push("1484=" + Me.visible), Oe && (Oe.redirectCount && a2.push("1384.1385=" + Oe.redirectCount), 1 !== Oe.type && 2 !== Oe.type || a2.push("770.76=" + Oe.type)), U(a2), I("690.1033", a2);
      } else r(Re, 50);
    }
    var xe = window.performance || {}, Ae = "function" == typeof xe.getEntriesByType;
    if (!e) throw new Error("Rum: interface is not included");
    if (e.enabled) {
      let je2 = function() {
        g = {}, p = {}, C = 0, h = e._deltaMarks, P(), M(), e.ajaxStart = 0, e.ajaxComplete = 0, u(Be2);
      }, ze2 = function() {
        var n2;
        e.sendTimeMark = k, e.sendResTiming = A, e.sendTiming = j, e.timeEnd = N;
        var t2 = (e.getBufferedEvents(["defRes"]).defRes || []).map(function(e2) {
          return e2.data;
        });
        for (n2 = 0; n2 < t2.length; n2++) A(t2[n2][0], t2[n2][1]);
        e.clearEvents("defRes");
        var i2 = (e.getBufferedEvents(["defTimes"]).defTimes || []).map(function(e2) {
          return e2.data;
        });
        for (n2 = 0; n2 < i2.length; n2++) k(i2[n2][0], i2[n2][1], false, i2[n2][2]);
        e.clearEvents("defTimes"), Object.keys(h).forEach(function(e2) {
          R(e2);
        });
      }, Be2 = function() {
        var n2 = window.performance && window.performance.timing && window.performance.timing.navigationStart, t2 = e.getSetting("skipTiming"), a2 = e.getSetting("techParamsByVisible");
        if (n2) {
          if (a2) {
            var s2 = function() {
              "visible" !== e.vsStart ? "visible" === document.visibilityState && (e.vsStart = "visible", removeEventListener("visibilitychange", s2), Re()) : removeEventListener("visibilitychange", s2);
            };
            addEventListener("visibilitychange", s2);
          }
          r(function() {
            ze2(), (!t2 && !a2 || a2 && "visible" === e.vsStart) && Re(), e.getSetting("disableFCP") || (le(), fe < se && i(
              "paint",
              function(e2, n3) {
                le(), n3 && fe >= se && n3.disconnect();
              },
              { buffered: true }
            )), e.getSetting("sendAutoElementTiming") && (!window.PerformanceObserver || !e.getSetting("forcePaintTimeSending") && e.isVisibilityChanged() || i("element", function(e2) {
              for (var n3 = 0; n3 < e2.length; n3++) {
                var t3 = e2[n3];
                k("element-timing." + t3.identifier, t3.startTime);
              }
            })), o("pageshow", De2), he(), "complete" === document.readyState ? Ve2({ skipTimingApi: t2 }) : o("load", Ve2.bind(void 0, { skipTimingApi: t2 }));
          }, 0);
        }
      }, Ve2 = function(n2) {
        var r2, s2;
        e.getSetting("disableOnLoadTasks") || (removeEventListener("load", Ve2), n2.skipTimingApi || (function() {
          if (Ae) {
            var n3 = xe.getEntriesByType("navigation")[0];
            if (n3) {
              var t2 = [];
              v(t2, n3), U(t2);
              var i2 = xe.getEntriesByName("yndxNavigationSource")[0];
              i2 && t2.push("2091.186=" + i2.value);
              var r3 = xe.getEntriesByName("yndxNavigationToken", "yndxEntry")[0];
              if (r3 && t2.push("2091.3649=" + r3.value), e.getSetting("sendConfidence") && n3.confidence) {
                var o2 = { confidence: n3.confidence };
                t2.push("-additional=".concat(encodeURIComponent(JSON.stringify(o2))));
              }
              I("690.2096.2892", t2);
            }
          }
        })(), (s2 = e.getSetting("periodicStatsIntervalMs")) || null === s2 || (s2 = 15e3), s2 && (r2 = setInterval(Fe2, s2), t(function() {
          clearInterval(r2);
        }), Ue = r2), o("beforeunload", Fe2), (function() {
          if (window.PerformanceObserver) {
            ke = {}, Ce = 0;
            var e2 = function(e3) {
              !(function(e4) {
                if (e4 && e4.length)
                  for (var n3 = ke, t2 = 0; t2 < e4.length; t2++) {
                    var i2 = Le(e4[t2]);
                    if (i2) {
                      var r3 = i2.domain + "-" + i2.extension, o2 = n3[r3] = n3[r3] || { count: 0, size: 0 };
                      o2.count++, o2.size += i2.size;
                    }
                  }
              })(e3);
            };
            i("resource", e2), i("navigation", e2), f().push(Pe);
          }
        })(), e.getSetting("disableFID") || i(
          "first-input",
          function(n3, t2) {
            var i2 = n3[0];
            if (i2) {
              var r3 = i2.processingStart, o2 = { duration: i2.duration, js: i2.processingEnd - r3, name: i2.name };
              i2.target && (o2.target = c(i2.target));
              var a2 = r3 - i2.startTime;
              R("first-input", a2, o2), e.emit({ metricName: "first-input-debug", value: a2, params: { entry: i2, additionalParams: o2 } }), t2.disconnect();
            }
          },
          { buffered: true }
        ), e.getSetting("disableCLS") || window.PerformanceObserver && (d(ie), d(te), F = X, W = null, H = null, J = null, $ = e.getSetting("clsWindowGap") || $, K = e.getSetting("clsWindowSize") || K, a(
          i("layout-shift", ne),
          function() {
            return ie(true);
          },
          true
        )), e.getSetting("disableLCP") || !window.PerformanceObserver || !e.getSetting("forcePaintTimeSending") && e.isVisibilityChanged() || (d(function() {
          e.whenActivated(oe);
        }), Q = null, Y = null, q = false, a(
          i("largest-contentful-paint", re),
          function() {
            e.whenActivated(function() {
              oe(true);
            });
          },
          false
        )));
      }, De2 = function(e2) {
        e2.persisted && k("bfcache");
      }, Fe2 = function() {
        var e2 = false;
        f().forEach(function(n2) {
          n2() && (e2 = true);
        }), e2 || clearInterval(Ue);
      };
      var je = je2, ze = ze2, Be = Be2, Ve = Ve2, De = De2, Fe = Fe2;
      var Ue;
      d(ze2), e.destroy = function(n2) {
        var t2 = e._unsubscribers;
        n2.shouldComplete && e.completeSession(true), e._onComplete = [];
        for (var i2 = 0; i2 < t2.length; i2++) t2[i2]();
        removeEventListener("visibilitychange", e._onVisibilityChange), e._unsubscribers = [], e._periodicTasks = [], e._markListeners = {}, e._deltaMarks = {};
      }, e.restart = function(n2, t2, i2) {
        e.destroy({ shouldComplete: i2 }), e.init(n2, t2), addEventListener("visibilitychange", e._onVisibilityChange), je2(), (function() {
          for (var n3 = 0; n3 < e._onInit.length; n3++) e._onInit[n3]();
        })();
      }, e.setVars = function(n2) {
        Object.keys(n2).forEach(function(t2) {
          e._vars[t2] = n2[t2];
        }), P(), M();
      }, e.completeSession = function(n2) {
        for (var t2 = e._onComplete, i2 = 0; i2 < t2.length; i2++) t2[i2](n2);
      }, je2(), e._periodicTasks = [], e.sendHeroElement = function(e2) {
        k("2876", e2);
      }, e.getPageUrl = function() {
        return window.location.href;
      }, e._subpages = {}, e.makeSubPage = function(n2, t2) {
        var i2 = e._subpages[n2];
        e._subpages[n2] = void 0 === i2 ? i2 = 0 : ++i2;
        var r2 = false;
        return {
          689.2322: s(void 0 !== t2 ? t2 : e.getTime()),
          2924: n2,
          2925: i2,
          isCanceled: function() {
            return r2;
          },
          cancel: function() {
            r2 = true;
          }
        };
      }, e.getTimeMarks = function() {
        return g;
      }, e.getDeltas = function() {
        return p;
      }, e.getVarsList = l, e.getResourceTimings = x, e.pushConnectionTypeTo = U, e.pushTimingTo = v, e.normalize = s, e.sendCounter = O, e.sendDelta = R, e.onReady = u, e.getSelector = c, e.getSetting("disableCLS") || (e.finalizeLayoutShiftScore = ie), e.getSetting("disableLCP") || (e.finalizeLargestContentfulPaint = oe), e.sendTrafficData = Pe, e._getCommonVars = z, e._addListener = o, e._observe = i, e._timeout = r, e.sendTTI = he, e._getLongtasksStringValue = Se, e.onQuietWindow = ye, e.sendBFCacheTimeMark = De2, e.correctTime || (e.correctTime = function(e2) {
        return e2;
      }), e.whenActivated || (e.whenActivated = function(e2) {
        return e2();
      });
    } else
      e.getSetting = function() {
        return "";
      }, e.getVarsList = function() {
        return [];
      }, e.getResourceTimings = e.completeSession = e.pushConnectionTypeTo = e.pushTimingTo = e.normalize = e.sendCounter = e.destroy = e.restart = e.setVars = e.completeSession = e.sendDelta = e.sendTimeMark = e.sendResTiming = e.sendTiming = e.sendTTI = e.makeSubPage = e.sendHeroElement = e.onReady = e.onQuietWindow = function() {
      };
  })();
  Ya.Rum.observeDOMNode("2876", heroElement);
}
