var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __privateWrapper = (obj, member, setter, getter) => ({
  set _(value) {
    __privateSet(obj, member, value, setter);
  },
  get _() {
    return __privateGet(obj, member, getter);
  }
});
(function() {
  var _a, _b, _e2, _t, _c, _e3, _t2, _n, _d, _e4, _t3, _n2, _e5, _e6, _f, _e7, _t4, _n3, _o2, _r, _s, _i2, _Cj_instances, a_fn, _g, _e8, _t5, _n4, _o3, _r2, _s2, _i3, _a2, _m2, _d2, _h2, _c2, _u2, _l, _p2, _Tj_instances, f_fn, g_fn, v_fn, y_fn, b_fn, w_fn, S_fn, x_fn, __fn, _h3, _e9, _t6, _n5, _o4, _Nj_instances, r_fn, _i4, _e10, _t7, _n6, _j2, _e11, _k2, _e12, _t8, _n7, _o5, _r3, _s3, _i5, _a3, _l2;
  function jT(e, t) {
    for (var r = 0; r < t.length; r++) {
      const a = t[r];
      if (typeof a != "string" && !Array.isArray(a)) {
        for (const s in a) if (s !== "default" && !(s in e)) {
          const l = Object.getOwnPropertyDescriptor(a, s);
          l && Object.defineProperty(e, s, l.get ? l : { enumerable: true, get: () => a[s] });
        }
      }
    }
    return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }));
  }
  const Ac = [], ks = [], Gh = window.fetch;
  navigator.sendBeacon = function(...e) {
    return true;
  };
  (function() {
    const e = document.head.appendChild;
    document.head.appendChild = function(t) {
      if (t instanceof HTMLScriptElement) {
        const r = t.src || "";
        if (r.includes("https://yandex.ru/ads/system/adsdk.js") || r.includes("https://mc.yandex.ru/metrika/tag.js")) return console.log("Заблокирована попытка добавить Yandex скрипт:", r), true;
      }
      return e.call(this, t);
    };
  })();
  function kT() {
    window.fetch = function(...e) {
      var t = [...e][0];
      if (t && t.url && (t.url.includes("log.strm.yandex.ru") || t.url.includes("api.music.yandex.net/dynamic-pages/trigger/polling"))) return new Promise((r) => r(new Response()));
      if (t && t.url && t.url.startsWith("https://api.music.yandex.net")) return PT(...e);
      try {
        return Gh(...e);
      } catch {
      }
    };
  }
  const PT = async function(...e) {
    let [t, r] = e;
    if (console.log(`[YandexApiFetch] new request: ${t.url}`, t.headers), Ac.find((l) => t.url.includes(l.url))) {
      for (var a = 0; a < Ac.length; a++) if (t.url.includes(Ac[a].url)) {
        var s = await Ac[a].handler(t);
        s && (e.resource = s, t = s);
      }
    }
    if (ks.find((l) => t.url.includes(l.url))) {
      const f = await (await Gh(t)).clone().json();
      let p = f;
      for (var a = 0; a < ks.length; a++) t.url.includes(ks[a].url) && (p = await ks[a].handler({ url: t.url, data: p }));
      return p ? new Response(JSON.stringify(p)) : new Response(JSON.stringify(f));
    }
    return Gh(t);
  }, Zr = function(e, t) {
    ks.push({ url: e, handler: t });
  };
  function cS(e, t) {
    return function() {
      return e.apply(t, arguments);
    };
  }
  const { toString: LT } = Object.prototype, { getPrototypeOf: Hp } = Object, { iterator: Eu, toStringTag: uS } = Symbol, Au = /* @__PURE__ */ ((e) => (t) => {
    const r = LT.call(t);
    return e[r] || (e[r] = r.slice(8, -1).toLowerCase());
  })(/* @__PURE__ */ Object.create(null)), Zn = (e) => (e = e.toLowerCase(), (t) => Au(t) === e), Cu = (e) => (t) => typeof t === e, { isArray: _i } = Array, yi = Cu("undefined");
  function el(e) {
    return e !== null && !yi(e) && e.constructor !== null && !yi(e.constructor) && on(e.constructor.isBuffer) && e.constructor.isBuffer(e);
  }
  const fS = Zn("ArrayBuffer");
  function UT(e) {
    let t;
    return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? t = ArrayBuffer.isView(e) : t = e && e.buffer && fS(e.buffer), t;
  }
  const BT = Cu("string"), on = Cu("function"), dS = Cu("number"), tl = (e) => e !== null && typeof e == "object", IT = (e) => e === true || e === false, Vc = (e) => {
    if (Au(e) !== "object") return false;
    const t = Hp(e);
    return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(uS in e) && !(Eu in e);
  }, HT = (e) => {
    if (!tl(e) || el(e)) return false;
    try {
      return Object.keys(e).length === 0 && Object.getPrototypeOf(e) === Object.prototype;
    } catch {
      return false;
    }
  }, $T = Zn("Date"), VT = Zn("File"), ZT = Zn("Blob"), FT = Zn("FileList"), qT = (e) => tl(e) && on(e.pipe), YT = (e) => {
    let t;
    return e && (typeof FormData == "function" && e instanceof FormData || on(e.append) && ((t = Au(e)) === "formdata" || t === "object" && on(e.toString) && e.toString() === "[object FormData]"));
  }, XT = Zn("URLSearchParams"), [QT, GT, KT, JT] = ["ReadableStream", "Request", "Response", "Headers"].map(Zn), WT = (e) => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
  function nl(e, t, { allOwnKeys: r = false } = {}) {
    if (e === null || typeof e > "u") return;
    let a, s;
    if (typeof e != "object" && (e = [e]), _i(e)) for (a = 0, s = e.length; a < s; a++) t.call(null, e[a], a, e);
    else {
      if (el(e)) return;
      const l = r ? Object.getOwnPropertyNames(e) : Object.keys(e), u = l.length;
      let f;
      for (a = 0; a < u; a++) f = l[a], t.call(null, e[f], f, e);
    }
  }
  function hS(e, t) {
    if (el(e)) return null;
    t = t.toLowerCase();
    const r = Object.keys(e);
    let a = r.length, s;
    for (; a-- > 0; ) if (s = r[a], t === s.toLowerCase()) return s;
    return null;
  }
  const oa = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global, pS = (e) => !yi(e) && e !== oa;
  function Kh() {
    const { caseless: e, skipUndefined: t } = pS(this) && this || {}, r = {}, a = (s, l) => {
      if (l === "__proto__" || l === "constructor" || l === "prototype") return;
      const u = e && hS(r, l) || l;
      Vc(r[u]) && Vc(s) ? r[u] = Kh(r[u], s) : Vc(s) ? r[u] = Kh({}, s) : _i(s) ? r[u] = s.slice() : (!t || !yi(s)) && (r[u] = s);
    };
    for (let s = 0, l = arguments.length; s < l; s++) arguments[s] && nl(arguments[s], a);
    return r;
  }
  const e2 = (e, t, r, { allOwnKeys: a } = {}) => (nl(t, (s, l) => {
    r && on(s) ? Object.defineProperty(e, l, { value: cS(s, r), writable: true, enumerable: true, configurable: true }) : Object.defineProperty(e, l, { value: s, writable: true, enumerable: true, configurable: true });
  }, { allOwnKeys: a }), e), t2 = (e) => (e.charCodeAt(0) === 65279 && (e = e.slice(1)), e), n2 = (e, t, r, a) => {
    e.prototype = Object.create(t.prototype, a), Object.defineProperty(e.prototype, "constructor", { value: e, writable: true, enumerable: false, configurable: true }), Object.defineProperty(e, "super", { value: t.prototype }), r && Object.assign(e.prototype, r);
  }, r2 = (e, t, r, a) => {
    let s, l, u;
    const f = {};
    if (t = t || {}, e == null) return t;
    do {
      for (s = Object.getOwnPropertyNames(e), l = s.length; l-- > 0; ) u = s[l], (!a || a(u, e, t)) && !f[u] && (t[u] = e[u], f[u] = true);
      e = r !== false && Hp(e);
    } while (e && (!r || r(e, t)) && e !== Object.prototype);
    return t;
  }, o2 = (e, t, r) => {
    e = String(e), (r === void 0 || r > e.length) && (r = e.length), r -= t.length;
    const a = e.indexOf(t, r);
    return a !== -1 && a === r;
  }, a2 = (e) => {
    if (!e) return null;
    if (_i(e)) return e;
    let t = e.length;
    if (!dS(t)) return null;
    const r = new Array(t);
    for (; t-- > 0; ) r[t] = e[t];
    return r;
  }, i2 = /* @__PURE__ */ ((e) => (t) => e && t instanceof e)(typeof Uint8Array < "u" && Hp(Uint8Array)), s2 = (e, t) => {
    const a = (e && e[Eu]).call(e);
    let s;
    for (; (s = a.next()) && !s.done; ) {
      const l = s.value;
      t.call(e, l[0], l[1]);
    }
  }, l2 = (e, t) => {
    let r;
    const a = [];
    for (; (r = e.exec(t)) !== null; ) a.push(r);
    return a;
  }, c2 = Zn("HTMLFormElement"), u2 = (e) => e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(r, a, s) {
    return a.toUpperCase() + s;
  }), Bb = (({ hasOwnProperty: e }) => (t, r) => e.call(t, r))(Object.prototype), f2 = Zn("RegExp"), mS = (e, t) => {
    const r = Object.getOwnPropertyDescriptors(e), a = {};
    nl(r, (s, l) => {
      let u;
      (u = t(s, l, e)) !== false && (a[l] = u || s);
    }), Object.defineProperties(e, a);
  }, d2 = (e) => {
    mS(e, (t, r) => {
      if (on(e) && ["arguments", "caller", "callee"].indexOf(r) !== -1) return false;
      const a = e[r];
      if (on(a)) {
        if (t.enumerable = false, "writable" in t) {
          t.writable = false;
          return;
        }
        t.set || (t.set = () => {
          throw Error("Can not rewrite read-only method '" + r + "'");
        });
      }
    });
  }, h2 = (e, t) => {
    const r = {}, a = (s) => {
      s.forEach((l) => {
        r[l] = true;
      });
    };
    return _i(e) ? a(e) : a(String(e).split(t)), r;
  }, p2 = () => {
  }, m2 = (e, t) => e != null && Number.isFinite(e = +e) ? e : t;
  function g2(e) {
    return !!(e && on(e.append) && e[uS] === "FormData" && e[Eu]);
  }
  const v2 = (e) => {
    const t = new Array(10), r = (a, s) => {
      if (tl(a)) {
        if (t.indexOf(a) >= 0) return;
        if (el(a)) return a;
        if (!("toJSON" in a)) {
          t[s] = a;
          const l = _i(a) ? [] : {};
          return nl(a, (u, f) => {
            const p = r(u, s + 1);
            !yi(p) && (l[f] = p);
          }), t[s] = void 0, l;
        }
      }
      return a;
    };
    return r(e, 0);
  }, y2 = Zn("AsyncFunction"), b2 = (e) => e && (tl(e) || on(e)) && on(e.then) && on(e.catch), gS = ((e, t) => e ? setImmediate : t ? ((r, a) => (oa.addEventListener("message", ({ source: s, data: l }) => {
    s === oa && l === r && a.length && a.shift()();
  }, false), (s) => {
    a.push(s), oa.postMessage(r, "*");
  }))(`axios@${Math.random()}`, []) : (r) => setTimeout(r))(typeof setImmediate == "function", on(oa.postMessage)), w2 = typeof queueMicrotask < "u" ? queueMicrotask.bind(oa) : typeof process < "u" && process.nextTick || gS, S2 = (e) => e != null && on(e[Eu]), q = { isArray: _i, isArrayBuffer: fS, isBuffer: el, isFormData: YT, isArrayBufferView: UT, isString: BT, isNumber: dS, isBoolean: IT, isObject: tl, isPlainObject: Vc, isEmptyObject: HT, isReadableStream: QT, isRequest: GT, isResponse: KT, isHeaders: JT, isUndefined: yi, isDate: $T, isFile: VT, isBlob: ZT, isRegExp: f2, isFunction: on, isStream: qT, isURLSearchParams: XT, isTypedArray: i2, isFileList: FT, forEach: nl, merge: Kh, extend: e2, trim: WT, stripBOM: t2, inherits: n2, toFlatObject: r2, kindOf: Au, kindOfTest: Zn, endsWith: o2, toArray: a2, forEachEntry: s2, matchAll: l2, isHTMLForm: c2, hasOwnProperty: Bb, hasOwnProp: Bb, reduceDescriptors: mS, freezeMethods: d2, toObjectSet: h2, toCamelCase: u2, noop: p2, toFiniteNumber: m2, findKey: hS, global: oa, isContextDefined: pS, isSpecCompliantForm: g2, toJSONObject: v2, isAsyncFn: y2, isThenable: b2, setImmediate: gS, asap: w2, isIterable: S2 };
  let _e = class vS extends Error {
    static from(t, r, a, s, l, u) {
      const f = new vS(t.message, r || t.code, a, s, l);
      return f.cause = t, f.name = t.name, u && Object.assign(f, u), f;
    }
    constructor(t, r, a, s, l) {
      super(t), this.name = "AxiosError", this.isAxiosError = true, r && (this.code = r), a && (this.config = a), s && (this.request = s), l && (this.response = l, this.status = l.status);
    }
    toJSON() {
      return { message: this.message, name: this.name, description: this.description, number: this.number, fileName: this.fileName, lineNumber: this.lineNumber, columnNumber: this.columnNumber, stack: this.stack, config: q.toJSONObject(this.config), code: this.code, status: this.status };
    }
  };
  _e.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
  _e.ERR_BAD_OPTION = "ERR_BAD_OPTION";
  _e.ECONNABORTED = "ECONNABORTED";
  _e.ETIMEDOUT = "ETIMEDOUT";
  _e.ERR_NETWORK = "ERR_NETWORK";
  _e.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
  _e.ERR_DEPRECATED = "ERR_DEPRECATED";
  _e.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
  _e.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
  _e.ERR_CANCELED = "ERR_CANCELED";
  _e.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
  _e.ERR_INVALID_URL = "ERR_INVALID_URL";
  const x2 = null;
  function Jh(e) {
    return q.isPlainObject(e) || q.isArray(e);
  }
  function yS(e) {
    return q.endsWith(e, "[]") ? e.slice(0, -2) : e;
  }
  function Ib(e, t, r) {
    return e ? e.concat(t).map(function(s, l) {
      return s = yS(s), !r && l ? "[" + s + "]" : s;
    }).join(r ? "." : "") : t;
  }
  function _2(e) {
    return q.isArray(e) && !e.some(Jh);
  }
  const E2 = q.toFlatObject(q, {}, null, function(t) {
    return /^is[A-Z]/.test(t);
  });
  function Tu(e, t, r) {
    if (!q.isObject(e)) throw new TypeError("target must be an object");
    t = t || new FormData(), r = q.toFlatObject(r, { metaTokens: true, dots: false, indexes: false }, false, function(E, C) {
      return !q.isUndefined(C[E]);
    });
    const a = r.metaTokens, s = r.visitor || v, l = r.dots, u = r.indexes, p = (r.Blob || typeof Blob < "u" && Blob) && q.isSpecCompliantForm(t);
    if (!q.isFunction(s)) throw new TypeError("visitor must be a function");
    function m(x) {
      if (x === null) return "";
      if (q.isDate(x)) return x.toISOString();
      if (q.isBoolean(x)) return x.toString();
      if (!p && q.isBlob(x)) throw new _e("Blob is not supported. Use a Buffer instead.");
      return q.isArrayBuffer(x) || q.isTypedArray(x) ? p && typeof Blob == "function" ? new Blob([x]) : Buffer.from(x) : x;
    }
    function v(x, E, C) {
      let T = x;
      if (x && !C && typeof x == "object") {
        if (q.endsWith(E, "{}")) E = a ? E : E.slice(0, -2), x = JSON.stringify(x);
        else if (q.isArray(x) && _2(x) || (q.isFileList(x) || q.endsWith(E, "[]")) && (T = q.toArray(x))) return E = yS(E), T.forEach(function(O, D) {
          !(q.isUndefined(O) || O === null) && t.append(u === true ? Ib([E], D, l) : u === null ? E : E + "[]", m(O));
        }), false;
      }
      return Jh(x) ? true : (t.append(Ib(C, E, l), m(x)), false);
    }
    const g = [], S = Object.assign(E2, { defaultVisitor: v, convertValue: m, isVisitable: Jh });
    function _(x, E) {
      if (!q.isUndefined(x)) {
        if (g.indexOf(x) !== -1) throw Error("Circular reference detected in " + E.join("."));
        g.push(x), q.forEach(x, function(T, R) {
          (!(q.isUndefined(T) || T === null) && s.call(t, T, q.isString(R) ? R.trim() : R, E, S)) === true && _(T, E ? E.concat(R) : [R]);
        }), g.pop();
      }
    }
    if (!q.isObject(e)) throw new TypeError("data must be an object");
    return _(e), t;
  }
  function Hb(e) {
    const t = { "!": "%21", "'": "%27", "(": "%28", ")": "%29", "~": "%7E", "%20": "+", "%00": "\0" };
    return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g, function(a) {
      return t[a];
    });
  }
  function $p(e, t) {
    this._pairs = [], e && Tu(e, this, t);
  }
  const bS = $p.prototype;
  bS.append = function(t, r) {
    this._pairs.push([t, r]);
  };
  bS.toString = function(t) {
    const r = t ? function(a) {
      return t.call(this, a, Hb);
    } : Hb;
    return this._pairs.map(function(s) {
      return r(s[0]) + "=" + r(s[1]);
    }, "").join("&");
  };
  function A2(e) {
    return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
  }
  function wS(e, t, r) {
    if (!t) return e;
    const a = r && r.encode || A2, s = q.isFunction(r) ? { serialize: r } : r, l = s && s.serialize;
    let u;
    if (l ? u = l(t, s) : u = q.isURLSearchParams(t) ? t.toString() : new $p(t, s).toString(a), u) {
      const f = e.indexOf("#");
      f !== -1 && (e = e.slice(0, f)), e += (e.indexOf("?") === -1 ? "?" : "&") + u;
    }
    return e;
  }
  class $b {
    constructor() {
      this.handlers = [];
    }
    use(t, r, a) {
      return this.handlers.push({ fulfilled: t, rejected: r, synchronous: a ? a.synchronous : false, runWhen: a ? a.runWhen : null }), this.handlers.length - 1;
    }
    eject(t) {
      this.handlers[t] && (this.handlers[t] = null);
    }
    clear() {
      this.handlers && (this.handlers = []);
    }
    forEach(t) {
      q.forEach(this.handlers, function(a) {
        a !== null && t(a);
      });
    }
  }
  const Vp = { silentJSONParsing: true, forcedJSONParsing: true, clarifyTimeoutError: false, legacyInterceptorReqResOrdering: true }, C2 = typeof URLSearchParams < "u" ? URLSearchParams : $p, T2 = typeof FormData < "u" ? FormData : null, O2 = typeof Blob < "u" ? Blob : null, R2 = { isBrowser: true, classes: { URLSearchParams: C2, FormData: T2, Blob: O2 }, protocols: ["http", "https", "file", "blob", "url", "data"] }, Zp = typeof window < "u" && typeof document < "u", Wh = typeof navigator == "object" && navigator || void 0, M2 = Zp && (!Wh || ["ReactNative", "NativeScript", "NS"].indexOf(Wh.product) < 0), N2 = typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope && typeof self.importScripts == "function", z2 = Zp && window.location.href || "http://localhost", D2 = Object.freeze(Object.defineProperty({ __proto__: null, hasBrowserEnv: Zp, hasStandardBrowserEnv: M2, hasStandardBrowserWebWorkerEnv: N2, navigator: Wh, origin: z2 }, Symbol.toStringTag, { value: "Module" })), Bt = { ...D2, ...R2 };
  function j2(e, t) {
    return Tu(e, new Bt.classes.URLSearchParams(), { visitor: function(r, a, s, l) {
      return Bt.isNode && q.isBuffer(r) ? (this.append(a, r.toString("base64")), false) : l.defaultVisitor.apply(this, arguments);
    }, ...t });
  }
  function k2(e) {
    return q.matchAll(/\w+|\[(\w*)]/g, e).map((t) => t[0] === "[]" ? "" : t[1] || t[0]);
  }
  function P2(e) {
    const t = {}, r = Object.keys(e);
    let a;
    const s = r.length;
    let l;
    for (a = 0; a < s; a++) l = r[a], t[l] = e[l];
    return t;
  }
  function SS(e) {
    function t(r, a, s, l) {
      let u = r[l++];
      if (u === "__proto__") return true;
      const f = Number.isFinite(+u), p = l >= r.length;
      return u = !u && q.isArray(s) ? s.length : u, p ? (q.hasOwnProp(s, u) ? s[u] = [s[u], a] : s[u] = a, !f) : ((!s[u] || !q.isObject(s[u])) && (s[u] = []), t(r, a, s[u], l) && q.isArray(s[u]) && (s[u] = P2(s[u])), !f);
    }
    if (q.isFormData(e) && q.isFunction(e.entries)) {
      const r = {};
      return q.forEachEntry(e, (a, s) => {
        t(k2(a), s, r, 0);
      }), r;
    }
    return null;
  }
  function L2(e, t, r) {
    if (q.isString(e)) try {
      return (t || JSON.parse)(e), q.trim(e);
    } catch (a) {
      if (a.name !== "SyntaxError") throw a;
    }
    return (r || JSON.stringify)(e);
  }
  const rl = { transitional: Vp, adapter: ["xhr", "http", "fetch"], transformRequest: [function(t, r) {
    const a = r.getContentType() || "", s = a.indexOf("application/json") > -1, l = q.isObject(t);
    if (l && q.isHTMLForm(t) && (t = new FormData(t)), q.isFormData(t)) return s ? JSON.stringify(SS(t)) : t;
    if (q.isArrayBuffer(t) || q.isBuffer(t) || q.isStream(t) || q.isFile(t) || q.isBlob(t) || q.isReadableStream(t)) return t;
    if (q.isArrayBufferView(t)) return t.buffer;
    if (q.isURLSearchParams(t)) return r.setContentType("application/x-www-form-urlencoded;charset=utf-8", false), t.toString();
    let f;
    if (l) {
      if (a.indexOf("application/x-www-form-urlencoded") > -1) return j2(t, this.formSerializer).toString();
      if ((f = q.isFileList(t)) || a.indexOf("multipart/form-data") > -1) {
        const p = this.env && this.env.FormData;
        return Tu(f ? { "files[]": t } : t, p && new p(), this.formSerializer);
      }
    }
    return l || s ? (r.setContentType("application/json", false), L2(t)) : t;
  }], transformResponse: [function(t) {
    const r = this.transitional || rl.transitional, a = r && r.forcedJSONParsing, s = this.responseType === "json";
    if (q.isResponse(t) || q.isReadableStream(t)) return t;
    if (t && q.isString(t) && (a && !this.responseType || s)) {
      const u = !(r && r.silentJSONParsing) && s;
      try {
        return JSON.parse(t, this.parseReviver);
      } catch (f) {
        if (u) throw f.name === "SyntaxError" ? _e.from(f, _e.ERR_BAD_RESPONSE, this, null, this.response) : f;
      }
    }
    return t;
  }], timeout: 0, xsrfCookieName: "XSRF-TOKEN", xsrfHeaderName: "X-XSRF-TOKEN", maxContentLength: -1, maxBodyLength: -1, env: { FormData: Bt.classes.FormData, Blob: Bt.classes.Blob }, validateStatus: function(t) {
    return t >= 200 && t < 300;
  }, headers: { common: { Accept: "application/json, text/plain, */*", "Content-Type": void 0 } } };
  q.forEach(["delete", "get", "head", "post", "put", "patch"], (e) => {
    rl.headers[e] = {};
  });
  const U2 = q.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]), B2 = (e) => {
    const t = {};
    let r, a, s;
    return e && e.split(`
`).forEach(function(u) {
      s = u.indexOf(":"), r = u.substring(0, s).trim().toLowerCase(), a = u.substring(s + 1).trim(), !(!r || t[r] && U2[r]) && (r === "set-cookie" ? t[r] ? t[r].push(a) : t[r] = [a] : t[r] = t[r] ? t[r] + ", " + a : a);
    }), t;
  }, Vb = /* @__PURE__ */ Symbol("internals");
  function Ts(e) {
    return e && String(e).trim().toLowerCase();
  }
  function Zc(e) {
    return e === false || e == null ? e : q.isArray(e) ? e.map(Zc) : String(e);
  }
  function I2(e) {
    const t = /* @__PURE__ */ Object.create(null), r = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let a;
    for (; a = r.exec(e); ) t[a[1]] = a[2];
    return t;
  }
  const H2 = (e) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim());
  function bh(e, t, r, a, s) {
    if (q.isFunction(a)) return a.call(this, t, r);
    if (s && (t = r), !!q.isString(t)) {
      if (q.isString(a)) return t.indexOf(a) !== -1;
      if (q.isRegExp(a)) return a.test(t);
    }
  }
  function $2(e) {
    return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (t, r, a) => r.toUpperCase() + a);
  }
  function V2(e, t) {
    const r = q.toCamelCase(" " + t);
    ["get", "set", "has"].forEach((a) => {
      Object.defineProperty(e, a + r, { value: function(s, l, u) {
        return this[a].call(this, t, s, l, u);
      }, configurable: true });
    });
  }
  let an = class {
    constructor(t) {
      t && this.set(t);
    }
    set(t, r, a) {
      const s = this;
      function l(f, p, m) {
        const v = Ts(p);
        if (!v) throw new Error("header name must be a non-empty string");
        const g = q.findKey(s, v);
        (!g || s[g] === void 0 || m === true || m === void 0 && s[g] !== false) && (s[g || p] = Zc(f));
      }
      const u = (f, p) => q.forEach(f, (m, v) => l(m, v, p));
      if (q.isPlainObject(t) || t instanceof this.constructor) u(t, r);
      else if (q.isString(t) && (t = t.trim()) && !H2(t)) u(B2(t), r);
      else if (q.isObject(t) && q.isIterable(t)) {
        let f = {}, p, m;
        for (const v of t) {
          if (!q.isArray(v)) throw TypeError("Object iterator must return a key-value pair");
          f[m = v[0]] = (p = f[m]) ? q.isArray(p) ? [...p, v[1]] : [p, v[1]] : v[1];
        }
        u(f, r);
      } else t != null && l(r, t, a);
      return this;
    }
    get(t, r) {
      if (t = Ts(t), t) {
        const a = q.findKey(this, t);
        if (a) {
          const s = this[a];
          if (!r) return s;
          if (r === true) return I2(s);
          if (q.isFunction(r)) return r.call(this, s, a);
          if (q.isRegExp(r)) return r.exec(s);
          throw new TypeError("parser must be boolean|regexp|function");
        }
      }
    }
    has(t, r) {
      if (t = Ts(t), t) {
        const a = q.findKey(this, t);
        return !!(a && this[a] !== void 0 && (!r || bh(this, this[a], a, r)));
      }
      return false;
    }
    delete(t, r) {
      const a = this;
      let s = false;
      function l(u) {
        if (u = Ts(u), u) {
          const f = q.findKey(a, u);
          f && (!r || bh(a, a[f], f, r)) && (delete a[f], s = true);
        }
      }
      return q.isArray(t) ? t.forEach(l) : l(t), s;
    }
    clear(t) {
      const r = Object.keys(this);
      let a = r.length, s = false;
      for (; a--; ) {
        const l = r[a];
        (!t || bh(this, this[l], l, t, true)) && (delete this[l], s = true);
      }
      return s;
    }
    normalize(t) {
      const r = this, a = {};
      return q.forEach(this, (s, l) => {
        const u = q.findKey(a, l);
        if (u) {
          r[u] = Zc(s), delete r[l];
          return;
        }
        const f = t ? $2(l) : String(l).trim();
        f !== l && delete r[l], r[f] = Zc(s), a[f] = true;
      }), this;
    }
    concat(...t) {
      return this.constructor.concat(this, ...t);
    }
    toJSON(t) {
      const r = /* @__PURE__ */ Object.create(null);
      return q.forEach(this, (a, s) => {
        a != null && a !== false && (r[s] = t && q.isArray(a) ? a.join(", ") : a);
      }), r;
    }
    [Symbol.iterator]() {
      return Object.entries(this.toJSON())[Symbol.iterator]();
    }
    toString() {
      return Object.entries(this.toJSON()).map(([t, r]) => t + ": " + r).join(`
`);
    }
    getSetCookie() {
      return this.get("set-cookie") || [];
    }
    get [Symbol.toStringTag]() {
      return "AxiosHeaders";
    }
    static from(t) {
      return t instanceof this ? t : new this(t);
    }
    static concat(t, ...r) {
      const a = new this(t);
      return r.forEach((s) => a.set(s)), a;
    }
    static accessor(t) {
      const a = (this[Vb] = this[Vb] = { accessors: {} }).accessors, s = this.prototype;
      function l(u) {
        const f = Ts(u);
        a[f] || (V2(s, u), a[f] = true);
      }
      return q.isArray(t) ? t.forEach(l) : l(t), this;
    }
  };
  an.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
  q.reduceDescriptors(an.prototype, ({ value: e }, t) => {
    let r = t[0].toUpperCase() + t.slice(1);
    return { get: () => e, set(a) {
      this[r] = a;
    } };
  });
  q.freezeMethods(an);
  function wh(e, t) {
    const r = this || rl, a = t || r, s = an.from(a.headers);
    let l = a.data;
    return q.forEach(e, function(f) {
      l = f.call(r, l, s.normalize(), t ? t.status : void 0);
    }), s.normalize(), l;
  }
  function xS(e) {
    return !!(e && e.__CANCEL__);
  }
  let ol = class extends _e {
    constructor(t, r, a) {
      super(t != null ? t : "canceled", _e.ERR_CANCELED, r, a), this.name = "CanceledError", this.__CANCEL__ = true;
    }
  };
  function _S(e, t, r) {
    const a = r.config.validateStatus;
    !r.status || !a || a(r.status) ? e(r) : t(new _e("Request failed with status code " + r.status, [_e.ERR_BAD_REQUEST, _e.ERR_BAD_RESPONSE][Math.floor(r.status / 100) - 4], r.config, r.request, r));
  }
  function Z2(e) {
    const t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
    return t && t[1] || "";
  }
  function F2(e, t) {
    e = e || 10;
    const r = new Array(e), a = new Array(e);
    let s = 0, l = 0, u;
    return t = t !== void 0 ? t : 1e3, function(p) {
      const m = Date.now(), v = a[l];
      u || (u = m), r[s] = p, a[s] = m;
      let g = l, S = 0;
      for (; g !== s; ) S += r[g++], g = g % e;
      if (s = (s + 1) % e, s === l && (l = (l + 1) % e), m - u < t) return;
      const _ = v && m - v;
      return _ ? Math.round(S * 1e3 / _) : void 0;
    };
  }
  function q2(e, t) {
    let r = 0, a = 1e3 / t, s, l;
    const u = (m, v = Date.now()) => {
      r = v, s = null, l && (clearTimeout(l), l = null), e(...m);
    };
    return [(...m) => {
      const v = Date.now(), g = v - r;
      g >= a ? u(m, v) : (s = m, l || (l = setTimeout(() => {
        l = null, u(s);
      }, a - g)));
    }, () => s && u(s)];
  }
  const Jc = (e, t, r = 3) => {
    let a = 0;
    const s = F2(50, 250);
    return q2((l) => {
      const u = l.loaded, f = l.lengthComputable ? l.total : void 0, p = u - a, m = s(p), v = u <= f;
      a = u;
      const g = { loaded: u, total: f, progress: f ? u / f : void 0, bytes: p, rate: m || void 0, estimated: m && f && v ? (f - u) / m : void 0, event: l, lengthComputable: f != null, [t ? "download" : "upload"]: true };
      e(g);
    }, r);
  }, Zb = (e, t) => {
    const r = e != null;
    return [(a) => t[0]({ lengthComputable: r, total: e, loaded: a }), t[1]];
  }, Fb = (e) => (...t) => q.asap(() => e(...t)), Y2 = Bt.hasStandardBrowserEnv ? /* @__PURE__ */ ((e, t) => (r) => (r = new URL(r, Bt.origin), e.protocol === r.protocol && e.host === r.host && (t || e.port === r.port)))(new URL(Bt.origin), Bt.navigator && /(msie|trident)/i.test(Bt.navigator.userAgent)) : () => true, X2 = Bt.hasStandardBrowserEnv ? { write(e, t, r, a, s, l, u) {
    if (typeof document > "u") return;
    const f = [`${e}=${encodeURIComponent(t)}`];
    q.isNumber(r) && f.push(`expires=${new Date(r).toUTCString()}`), q.isString(a) && f.push(`path=${a}`), q.isString(s) && f.push(`domain=${s}`), l === true && f.push("secure"), q.isString(u) && f.push(`SameSite=${u}`), document.cookie = f.join("; ");
  }, read(e) {
    if (typeof document > "u") return null;
    const t = document.cookie.match(new RegExp("(?:^|; )" + e + "=([^;]*)"));
    return t ? decodeURIComponent(t[1]) : null;
  }, remove(e) {
    this.write(e, "", Date.now() - 864e5, "/");
  } } : { write() {
  }, read() {
    return null;
  }, remove() {
  } };
  function Q2(e) {
    return typeof e != "string" ? false : /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e);
  }
  function G2(e, t) {
    return t ? e.replace(/\/?\/$/, "") + "/" + t.replace(/^\/+/, "") : e;
  }
  function ES(e, t, r) {
    let a = !Q2(t);
    return e && (a || r == false) ? G2(e, t) : t;
  }
  const qb = (e) => e instanceof an ? { ...e } : e;
  function la(e, t) {
    t = t || {};
    const r = {};
    function a(m, v, g, S) {
      return q.isPlainObject(m) && q.isPlainObject(v) ? q.merge.call({ caseless: S }, m, v) : q.isPlainObject(v) ? q.merge({}, v) : q.isArray(v) ? v.slice() : v;
    }
    function s(m, v, g, S) {
      if (q.isUndefined(v)) {
        if (!q.isUndefined(m)) return a(void 0, m, g, S);
      } else return a(m, v, g, S);
    }
    function l(m, v) {
      if (!q.isUndefined(v)) return a(void 0, v);
    }
    function u(m, v) {
      if (q.isUndefined(v)) {
        if (!q.isUndefined(m)) return a(void 0, m);
      } else return a(void 0, v);
    }
    function f(m, v, g) {
      if (g in t) return a(m, v);
      if (g in e) return a(void 0, m);
    }
    const p = { url: l, method: l, data: l, baseURL: u, transformRequest: u, transformResponse: u, paramsSerializer: u, timeout: u, timeoutMessage: u, withCredentials: u, withXSRFToken: u, adapter: u, responseType: u, xsrfCookieName: u, xsrfHeaderName: u, onUploadProgress: u, onDownloadProgress: u, decompress: u, maxContentLength: u, maxBodyLength: u, beforeRedirect: u, transport: u, httpAgent: u, httpsAgent: u, cancelToken: u, socketPath: u, responseEncoding: u, validateStatus: f, headers: (m, v, g) => s(qb(m), qb(v), g, true) };
    return q.forEach(Object.keys({ ...e, ...t }), function(v) {
      if (v === "__proto__" || v === "constructor" || v === "prototype") return;
      const g = q.hasOwnProp(p, v) ? p[v] : s, S = g(e[v], t[v], v);
      q.isUndefined(S) && g !== f || (r[v] = S);
    }), r;
  }
  const AS = (e) => {
    const t = la({}, e);
    let { data: r, withXSRFToken: a, xsrfHeaderName: s, xsrfCookieName: l, headers: u, auth: f } = t;
    if (t.headers = u = an.from(u), t.url = wS(ES(t.baseURL, t.url, t.allowAbsoluteUrls), e.params, e.paramsSerializer), f && u.set("Authorization", "Basic " + btoa((f.username || "") + ":" + (f.password ? unescape(encodeURIComponent(f.password)) : ""))), q.isFormData(r)) {
      if (Bt.hasStandardBrowserEnv || Bt.hasStandardBrowserWebWorkerEnv) u.setContentType(void 0);
      else if (q.isFunction(r.getHeaders)) {
        const p = r.getHeaders(), m = ["content-type", "content-length"];
        Object.entries(p).forEach(([v, g]) => {
          m.includes(v.toLowerCase()) && u.set(v, g);
        });
      }
    }
    if (Bt.hasStandardBrowserEnv && (a && q.isFunction(a) && (a = a(t)), a || a !== false && Y2(t.url))) {
      const p = s && l && X2.read(l);
      p && u.set(s, p);
    }
    return t;
  }, K2 = typeof XMLHttpRequest < "u", J2 = K2 && function(e) {
    return new Promise(function(r, a) {
      const s = AS(e);
      let l = s.data;
      const u = an.from(s.headers).normalize();
      let { responseType: f, onUploadProgress: p, onDownloadProgress: m } = s, v, g, S, _, x;
      function E() {
        _ && _(), x && x(), s.cancelToken && s.cancelToken.unsubscribe(v), s.signal && s.signal.removeEventListener("abort", v);
      }
      let C = new XMLHttpRequest();
      C.open(s.method.toUpperCase(), s.url, true), C.timeout = s.timeout;
      function T() {
        if (!C) return;
        const O = an.from("getAllResponseHeaders" in C && C.getAllResponseHeaders()), P = { data: !f || f === "text" || f === "json" ? C.responseText : C.response, status: C.status, statusText: C.statusText, headers: O, config: e, request: C };
        _S(function(k) {
          r(k), E();
        }, function(k) {
          a(k), E();
        }, P), C = null;
      }
      "onloadend" in C ? C.onloadend = T : C.onreadystatechange = function() {
        !C || C.readyState !== 4 || C.status === 0 && !(C.responseURL && C.responseURL.indexOf("file:") === 0) || setTimeout(T);
      }, C.onabort = function() {
        C && (a(new _e("Request aborted", _e.ECONNABORTED, e, C)), C = null);
      }, C.onerror = function(D) {
        const P = D && D.message ? D.message : "Network Error", L = new _e(P, _e.ERR_NETWORK, e, C);
        L.event = D || null, a(L), C = null;
      }, C.ontimeout = function() {
        let D = s.timeout ? "timeout of " + s.timeout + "ms exceeded" : "timeout exceeded";
        const P = s.transitional || Vp;
        s.timeoutErrorMessage && (D = s.timeoutErrorMessage), a(new _e(D, P.clarifyTimeoutError ? _e.ETIMEDOUT : _e.ECONNABORTED, e, C)), C = null;
      }, l === void 0 && u.setContentType(null), "setRequestHeader" in C && q.forEach(u.toJSON(), function(D, P) {
        C.setRequestHeader(P, D);
      }), q.isUndefined(s.withCredentials) || (C.withCredentials = !!s.withCredentials), f && f !== "json" && (C.responseType = s.responseType), m && ([S, x] = Jc(m, true), C.addEventListener("progress", S)), p && C.upload && ([g, _] = Jc(p), C.upload.addEventListener("progress", g), C.upload.addEventListener("loadend", _)), (s.cancelToken || s.signal) && (v = (O) => {
        C && (a(!O || O.type ? new ol(null, e, C) : O), C.abort(), C = null);
      }, s.cancelToken && s.cancelToken.subscribe(v), s.signal && (s.signal.aborted ? v() : s.signal.addEventListener("abort", v)));
      const R = Z2(s.url);
      if (R && Bt.protocols.indexOf(R) === -1) {
        a(new _e("Unsupported protocol " + R + ":", _e.ERR_BAD_REQUEST, e));
        return;
      }
      C.send(l || null);
    });
  }, W2 = (e, t) => {
    const { length: r } = e = e ? e.filter(Boolean) : [];
    if (t || r) {
      let a = new AbortController(), s;
      const l = function(m) {
        if (!s) {
          s = true, f();
          const v = m instanceof Error ? m : this.reason;
          a.abort(v instanceof _e ? v : new ol(v instanceof Error ? v.message : v));
        }
      };
      let u = t && setTimeout(() => {
        u = null, l(new _e(`timeout of ${t}ms exceeded`, _e.ETIMEDOUT));
      }, t);
      const f = () => {
        e && (u && clearTimeout(u), u = null, e.forEach((m) => {
          m.unsubscribe ? m.unsubscribe(l) : m.removeEventListener("abort", l);
        }), e = null);
      };
      e.forEach((m) => m.addEventListener("abort", l));
      const { signal: p } = a;
      return p.unsubscribe = () => q.asap(f), p;
    }
  }, eO = function* (e, t) {
    let r = e.byteLength;
    if (r < t) {
      yield e;
      return;
    }
    let a = 0, s;
    for (; a < r; ) s = a + t, yield e.slice(a, s), a = s;
  }, tO = async function* (e, t) {
    for await (const r of nO(e)) yield* eO(r, t);
  }, nO = async function* (e) {
    if (e[Symbol.asyncIterator]) {
      yield* e;
      return;
    }
    const t = e.getReader();
    try {
      for (; ; ) {
        const { done: r, value: a } = await t.read();
        if (r) break;
        yield a;
      }
    } finally {
      await t.cancel();
    }
  }, Yb = (e, t, r, a) => {
    const s = tO(e, t);
    let l = 0, u, f = (p) => {
      u || (u = true, a && a(p));
    };
    return new ReadableStream({ async pull(p) {
      try {
        const { done: m, value: v } = await s.next();
        if (m) {
          f(), p.close();
          return;
        }
        let g = v.byteLength;
        if (r) {
          let S = l += g;
          r(S);
        }
        p.enqueue(new Uint8Array(v));
      } catch (m) {
        throw f(m), m;
      }
    }, cancel(p) {
      return f(p), s.return();
    } }, { highWaterMark: 2 });
  }, Xb = 64 * 1024, { isFunction: Cc } = q, rO = (({ Request: e, Response: t }) => ({ Request: e, Response: t }))(q.global), { ReadableStream: Qb, TextEncoder: Gb } = q.global, Kb = (e, ...t) => {
    try {
      return !!e(...t);
    } catch {
      return false;
    }
  }, oO = (e) => {
    e = q.merge.call({ skipUndefined: true }, rO, e);
    const { fetch: t, Request: r, Response: a } = e, s = t ? Cc(t) : typeof fetch == "function", l = Cc(r), u = Cc(a);
    if (!s) return false;
    const f = s && Cc(Qb), p = s && (typeof Gb == "function" ? /* @__PURE__ */ ((x) => (E) => x.encode(E))(new Gb()) : async (x) => new Uint8Array(await new r(x).arrayBuffer())), m = l && f && Kb(() => {
      let x = false;
      const E = new r(Bt.origin, { body: new Qb(), method: "POST", get duplex() {
        return x = true, "half";
      } }).headers.has("Content-Type");
      return x && !E;
    }), v = u && f && Kb(() => q.isReadableStream(new a("").body)), g = { stream: v && ((x) => x.body) };
    s && ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((x) => {
      !g[x] && (g[x] = (E, C) => {
        let T = E && E[x];
        if (T) return T.call(E);
        throw new _e(`Response type '${x}' is not supported`, _e.ERR_NOT_SUPPORT, C);
      });
    });
    const S = async (x) => {
      if (x == null) return 0;
      if (q.isBlob(x)) return x.size;
      if (q.isSpecCompliantForm(x)) return (await new r(Bt.origin, { method: "POST", body: x }).arrayBuffer()).byteLength;
      if (q.isArrayBufferView(x) || q.isArrayBuffer(x)) return x.byteLength;
      if (q.isURLSearchParams(x) && (x = x + ""), q.isString(x)) return (await p(x)).byteLength;
    }, _ = async (x, E) => {
      const C = q.toFiniteNumber(x.getContentLength());
      return C != null ? C : S(E);
    };
    return async (x) => {
      let { url: E, method: C, data: T, signal: R, cancelToken: O, timeout: D, onDownloadProgress: P, onUploadProgress: L, responseType: k, headers: $, withCredentials: re = "same-origin", fetchOptions: G } = AS(x), ae = t || fetch;
      k = k ? (k + "").toLowerCase() : "text";
      let se = W2([R, O && O.toAbortSignal()], D), le = null;
      const ue = se && se.unsubscribe && (() => {
        se.unsubscribe();
      });
      let oe;
      try {
        if (L && m && C !== "get" && C !== "head" && (oe = await _($, T)) !== 0) {
          let M = new r(E, { method: "POST", body: T, duplex: "half" }), F;
          if (q.isFormData(T) && (F = M.headers.get("content-type")) && $.setContentType(F), M.body) {
            const [X, J] = Zb(oe, Jc(Fb(L)));
            T = Yb(M.body, Xb, X, J);
          }
        }
        q.isString(re) || (re = re ? "include" : "omit");
        const N = l && "credentials" in r.prototype, Z = { ...G, signal: se, method: C.toUpperCase(), headers: $.normalize().toJSON(), body: T, duplex: "half", credentials: N ? re : void 0 };
        le = l && new r(E, Z);
        let B = await (l ? ae(le, G) : ae(E, Z));
        const ce = v && (k === "stream" || k === "response");
        if (v && (P || ce && ue)) {
          const M = {};
          ["status", "statusText", "headers"].forEach((ie) => {
            M[ie] = B[ie];
          });
          const F = q.toFiniteNumber(B.headers.get("content-length")), [X, J] = P && Zb(F, Jc(Fb(P), true)) || [];
          B = new a(Yb(B.body, Xb, X, () => {
            J && J(), ue && ue();
          }), M);
        }
        k = k || "text";
        let me = await g[q.findKey(g, k) || "text"](B, x);
        return !ce && ue && ue(), await new Promise((M, F) => {
          _S(M, F, { data: me, headers: an.from(B.headers), status: B.status, statusText: B.statusText, config: x, request: le });
        });
      } catch (N) {
        throw ue && ue(), N && N.name === "TypeError" && /Load failed|fetch/i.test(N.message) ? Object.assign(new _e("Network Error", _e.ERR_NETWORK, x, le, N && N.response), { cause: N.cause || N }) : _e.from(N, N && N.code, x, le, N && N.response);
      }
    };
  }, aO = /* @__PURE__ */ new Map(), CS = (e) => {
    let t = e && e.env || {};
    const { fetch: r, Request: a, Response: s } = t, l = [a, s, r];
    let u = l.length, f = u, p, m, v = aO;
    for (; f--; ) p = l[f], m = v.get(p), m === void 0 && v.set(p, m = f ? /* @__PURE__ */ new Map() : oO(t)), v = m;
    return m;
  };
  CS();
  const Fp = { http: x2, xhr: J2, fetch: { get: CS } };
  q.forEach(Fp, (e, t) => {
    if (e) {
      try {
        Object.defineProperty(e, "name", { value: t });
      } catch {
      }
      Object.defineProperty(e, "adapterName", { value: t });
    }
  });
  const Jb = (e) => `- ${e}`, iO = (e) => q.isFunction(e) || e === null || e === false;
  function sO(e, t) {
    e = q.isArray(e) ? e : [e];
    const { length: r } = e;
    let a, s;
    const l = {};
    for (let u = 0; u < r; u++) {
      a = e[u];
      let f;
      if (s = a, !iO(a) && (s = Fp[(f = String(a)).toLowerCase()], s === void 0)) throw new _e(`Unknown adapter '${f}'`);
      if (s && (q.isFunction(s) || (s = s.get(t)))) break;
      l[f || "#" + u] = s;
    }
    if (!s) {
      const u = Object.entries(l).map(([p, m]) => `adapter ${p} ` + (m === false ? "is not supported by the environment" : "is not available in the build"));
      let f = r ? u.length > 1 ? `since :
` + u.map(Jb).join(`
`) : " " + Jb(u[0]) : "as no adapter specified";
      throw new _e("There is no suitable adapter to dispatch the request " + f, "ERR_NOT_SUPPORT");
    }
    return s;
  }
  const TS = { getAdapter: sO, adapters: Fp };
  function Sh(e) {
    if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted) throw new ol(null, e);
  }
  function Wb(e) {
    return Sh(e), e.headers = an.from(e.headers), e.data = wh.call(e, e.transformRequest), ["post", "put", "patch"].indexOf(e.method) !== -1 && e.headers.setContentType("application/x-www-form-urlencoded", false), TS.getAdapter(e.adapter || rl.adapter, e)(e).then(function(a) {
      return Sh(e), a.data = wh.call(e, e.transformResponse, a), a.headers = an.from(a.headers), a;
    }, function(a) {
      return xS(a) || (Sh(e), a && a.response && (a.response.data = wh.call(e, e.transformResponse, a.response), a.response.headers = an.from(a.response.headers))), Promise.reject(a);
    });
  }
  const OS = "1.13.5", Ou = {};
  ["object", "boolean", "number", "function", "string", "symbol"].forEach((e, t) => {
    Ou[e] = function(a) {
      return typeof a === e || "a" + (t < 1 ? "n " : " ") + e;
    };
  });
  const e0 = {};
  Ou.transitional = function(t, r, a) {
    function s(l, u) {
      return "[Axios v" + OS + "] Transitional option '" + l + "'" + u + (a ? ". " + a : "");
    }
    return (l, u, f) => {
      if (t === false) throw new _e(s(u, " has been removed" + (r ? " in " + r : "")), _e.ERR_DEPRECATED);
      return r && !e0[u] && (e0[u] = true, console.warn(s(u, " has been deprecated since v" + r + " and will be removed in the near future"))), t ? t(l, u, f) : true;
    };
  };
  Ou.spelling = function(t) {
    return (r, a) => (console.warn(`${a} is likely a misspelling of ${t}`), true);
  };
  function lO(e, t, r) {
    if (typeof e != "object") throw new _e("options must be an object", _e.ERR_BAD_OPTION_VALUE);
    const a = Object.keys(e);
    let s = a.length;
    for (; s-- > 0; ) {
      const l = a[s], u = t[l];
      if (u) {
        const f = e[l], p = f === void 0 || u(f, l, e);
        if (p !== true) throw new _e("option " + l + " must be " + p, _e.ERR_BAD_OPTION_VALUE);
        continue;
      }
      if (r !== true) throw new _e("Unknown option " + l, _e.ERR_BAD_OPTION);
    }
  }
  const Fc = { assertOptions: lO, validators: Ou }, Mn = Fc.validators;
  let ia = class {
    constructor(t) {
      this.defaults = t || {}, this.interceptors = { request: new $b(), response: new $b() };
    }
    async request(t, r) {
      try {
        return await this._request(t, r);
      } catch (a) {
        if (a instanceof Error) {
          let s = {};
          Error.captureStackTrace ? Error.captureStackTrace(s) : s = new Error();
          const l = s.stack ? s.stack.replace(/^.+\n/, "") : "";
          try {
            a.stack ? l && !String(a.stack).endsWith(l.replace(/^.+\n.+\n/, "")) && (a.stack += `
` + l) : a.stack = l;
          } catch {
          }
        }
        throw a;
      }
    }
    _request(t, r) {
      typeof t == "string" ? (r = r || {}, r.url = t) : r = t || {}, r = la(this.defaults, r);
      const { transitional: a, paramsSerializer: s, headers: l } = r;
      a !== void 0 && Fc.assertOptions(a, { silentJSONParsing: Mn.transitional(Mn.boolean), forcedJSONParsing: Mn.transitional(Mn.boolean), clarifyTimeoutError: Mn.transitional(Mn.boolean), legacyInterceptorReqResOrdering: Mn.transitional(Mn.boolean) }, false), s != null && (q.isFunction(s) ? r.paramsSerializer = { serialize: s } : Fc.assertOptions(s, { encode: Mn.function, serialize: Mn.function }, true)), r.allowAbsoluteUrls !== void 0 || (this.defaults.allowAbsoluteUrls !== void 0 ? r.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls : r.allowAbsoluteUrls = true), Fc.assertOptions(r, { baseUrl: Mn.spelling("baseURL"), withXsrfToken: Mn.spelling("withXSRFToken") }, true), r.method = (r.method || this.defaults.method || "get").toLowerCase();
      let u = l && q.merge(l.common, l[r.method]);
      l && q.forEach(["delete", "get", "head", "post", "put", "patch", "common"], (x) => {
        delete l[x];
      }), r.headers = an.concat(u, l);
      const f = [];
      let p = true;
      this.interceptors.request.forEach(function(E) {
        if (typeof E.runWhen == "function" && E.runWhen(r) === false) return;
        p = p && E.synchronous;
        const C = r.transitional || Vp;
        C && C.legacyInterceptorReqResOrdering ? f.unshift(E.fulfilled, E.rejected) : f.push(E.fulfilled, E.rejected);
      });
      const m = [];
      this.interceptors.response.forEach(function(E) {
        m.push(E.fulfilled, E.rejected);
      });
      let v, g = 0, S;
      if (!p) {
        const x = [Wb.bind(this), void 0];
        for (x.unshift(...f), x.push(...m), S = x.length, v = Promise.resolve(r); g < S; ) v = v.then(x[g++], x[g++]);
        return v;
      }
      S = f.length;
      let _ = r;
      for (; g < S; ) {
        const x = f[g++], E = f[g++];
        try {
          _ = x(_);
        } catch (C) {
          E.call(this, C);
          break;
        }
      }
      try {
        v = Wb.call(this, _);
      } catch (x) {
        return Promise.reject(x);
      }
      for (g = 0, S = m.length; g < S; ) v = v.then(m[g++], m[g++]);
      return v;
    }
    getUri(t) {
      t = la(this.defaults, t);
      const r = ES(t.baseURL, t.url, t.allowAbsoluteUrls);
      return wS(r, t.params, t.paramsSerializer);
    }
  };
  q.forEach(["delete", "get", "head", "options"], function(t) {
    ia.prototype[t] = function(r, a) {
      return this.request(la(a || {}, { method: t, url: r, data: (a || {}).data }));
    };
  });
  q.forEach(["post", "put", "patch"], function(t) {
    function r(a) {
      return function(l, u, f) {
        return this.request(la(f || {}, { method: t, headers: a ? { "Content-Type": "multipart/form-data" } : {}, url: l, data: u }));
      };
    }
    ia.prototype[t] = r(), ia.prototype[t + "Form"] = r(true);
  });
  let cO = class RS {
    constructor(t) {
      if (typeof t != "function") throw new TypeError("executor must be a function.");
      let r;
      this.promise = new Promise(function(l) {
        r = l;
      });
      const a = this;
      this.promise.then((s) => {
        if (!a._listeners) return;
        let l = a._listeners.length;
        for (; l-- > 0; ) a._listeners[l](s);
        a._listeners = null;
      }), this.promise.then = (s) => {
        let l;
        const u = new Promise((f) => {
          a.subscribe(f), l = f;
        }).then(s);
        return u.cancel = function() {
          a.unsubscribe(l);
        }, u;
      }, t(function(l, u, f) {
        a.reason || (a.reason = new ol(l, u, f), r(a.reason));
      });
    }
    throwIfRequested() {
      if (this.reason) throw this.reason;
    }
    subscribe(t) {
      if (this.reason) {
        t(this.reason);
        return;
      }
      this._listeners ? this._listeners.push(t) : this._listeners = [t];
    }
    unsubscribe(t) {
      if (!this._listeners) return;
      const r = this._listeners.indexOf(t);
      r !== -1 && this._listeners.splice(r, 1);
    }
    toAbortSignal() {
      const t = new AbortController(), r = (a) => {
        t.abort(a);
      };
      return this.subscribe(r), t.signal.unsubscribe = () => this.unsubscribe(r), t.signal;
    }
    static source() {
      let t;
      return { token: new RS(function(s) {
        t = s;
      }), cancel: t };
    }
  };
  function uO(e) {
    return function(r) {
      return e.apply(null, r);
    };
  }
  function fO(e) {
    return q.isObject(e) && e.isAxiosError === true;
  }
  const ep = { Continue: 100, SwitchingProtocols: 101, Processing: 102, EarlyHints: 103, Ok: 200, Created: 201, Accepted: 202, NonAuthoritativeInformation: 203, NoContent: 204, ResetContent: 205, PartialContent: 206, MultiStatus: 207, AlreadyReported: 208, ImUsed: 226, MultipleChoices: 300, MovedPermanently: 301, Found: 302, SeeOther: 303, NotModified: 304, UseProxy: 305, Unused: 306, TemporaryRedirect: 307, PermanentRedirect: 308, BadRequest: 400, Unauthorized: 401, PaymentRequired: 402, Forbidden: 403, NotFound: 404, MethodNotAllowed: 405, NotAcceptable: 406, ProxyAuthenticationRequired: 407, RequestTimeout: 408, Conflict: 409, Gone: 410, LengthRequired: 411, PreconditionFailed: 412, PayloadTooLarge: 413, UriTooLong: 414, UnsupportedMediaType: 415, RangeNotSatisfiable: 416, ExpectationFailed: 417, ImATeapot: 418, MisdirectedRequest: 421, UnprocessableEntity: 422, Locked: 423, FailedDependency: 424, TooEarly: 425, UpgradeRequired: 426, PreconditionRequired: 428, TooManyRequests: 429, RequestHeaderFieldsTooLarge: 431, UnavailableForLegalReasons: 451, InternalServerError: 500, NotImplemented: 501, BadGateway: 502, ServiceUnavailable: 503, GatewayTimeout: 504, HttpVersionNotSupported: 505, VariantAlsoNegotiates: 506, InsufficientStorage: 507, LoopDetected: 508, NotExtended: 510, NetworkAuthenticationRequired: 511, WebServerIsDown: 521, ConnectionTimedOut: 522, OriginIsUnreachable: 523, TimeoutOccurred: 524, SslHandshakeFailed: 525, InvalidSslCertificate: 526 };
  Object.entries(ep).forEach(([e, t]) => {
    ep[t] = e;
  });
  function MS(e) {
    const t = new ia(e), r = cS(ia.prototype.request, t);
    return q.extend(r, ia.prototype, t, { allOwnKeys: true }), q.extend(r, t, null, { allOwnKeys: true }), r.create = function(s) {
      return MS(la(e, s));
    }, r;
  }
  const rt = MS(rl);
  rt.Axios = ia;
  rt.CanceledError = ol;
  rt.CancelToken = cO;
  rt.isCancel = xS;
  rt.VERSION = OS;
  rt.toFormData = Tu;
  rt.AxiosError = _e;
  rt.Cancel = rt.CanceledError;
  rt.all = function(t) {
    return Promise.all(t);
  };
  rt.spread = uO;
  rt.isAxiosError = fO;
  rt.mergeConfig = la;
  rt.AxiosHeaders = an;
  rt.formToJSON = (e) => SS(q.isHTMLForm(e) ? new FormData(e) : e);
  rt.getAdapter = TS.getAdapter;
  rt.HttpStatusCode = ep;
  rt.default = rt;
  const { Axios: dI, AxiosError: hI, CanceledError: pI, isCancel: mI, CancelToken: gI, VERSION: vI, all: yI, Cancel: bI, isAxiosError: wI, spread: SI, toFormData: xI, AxiosHeaders: _I, HttpStatusCode: EI, formToJSON: AI, getAdapter: CI, mergeConfig: TI } = rt, dO = { withStackTrace: false }, NS = (e, t, r = dO) => {
    const a = t.isOk() ? { type: "Ok", value: t.value } : { type: "Err", value: t.error }, s = r.withStackTrace ? new Error().stack : void 0;
    return { data: a, message: e, stack: s };
  };
  function na(e, t, r, a) {
    function s(l) {
      return l instanceof r ? l : new r(function(u) {
        u(l);
      });
    }
    return new (r || (r = Promise))(function(l, u) {
      function f(v) {
        try {
          m(a.next(v));
        } catch (g) {
          u(g);
        }
      }
      function p(v) {
        try {
          m(a.throw(v));
        } catch (g) {
          u(g);
        }
      }
      function m(v) {
        v.done ? l(v.value) : s(v.value).then(f, p);
      }
      m((a = a.apply(e, [])).next());
    });
  }
  function t0(e) {
    var t = typeof Symbol == "function" && Symbol.iterator, r = t && e[t], a = 0;
    if (r) return r.call(e);
    if (e && typeof e.length == "number") return { next: function() {
      return e && a >= e.length && (e = void 0), { value: e && e[a++], done: !e };
    } };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
  }
  function ar(e) {
    return this instanceof ar ? (this.v = e, this) : new ar(e);
  }
  function n0(e, t, r) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var a = r.apply(e, t || []), s, l = [];
    return s = Object.create((typeof AsyncIterator == "function" ? AsyncIterator : Object).prototype), f("next"), f("throw"), f("return", u), s[Symbol.asyncIterator] = function() {
      return this;
    }, s;
    function u(_) {
      return function(x) {
        return Promise.resolve(x).then(_, g);
      };
    }
    function f(_, x) {
      a[_] && (s[_] = function(E) {
        return new Promise(function(C, T) {
          l.push([_, E, C, T]) > 1 || p(_, E);
        });
      }, x && (s[_] = x(s[_])));
    }
    function p(_, x) {
      try {
        m(a[_](x));
      } catch (E) {
        S(l[0][3], E);
      }
    }
    function m(_) {
      _.value instanceof ar ? Promise.resolve(_.value.v).then(v, g) : S(l[0][2], _);
    }
    function v(_) {
      p("next", _);
    }
    function g(_) {
      p("throw", _);
    }
    function S(_, x) {
      _(x), l.shift(), l.length && p(l[0][0], l[0][1]);
    }
  }
  function hO(e) {
    var t, r;
    return t = {}, a("next"), a("throw", function(s) {
      throw s;
    }), a("return"), t[Symbol.iterator] = function() {
      return this;
    }, t;
    function a(s, l) {
      t[s] = e[s] ? function(u) {
        return (r = !r) ? { value: ar(e[s](u)), done: false } : l ? l(u) : u;
      } : l;
    }
  }
  function pO(e) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var t = e[Symbol.asyncIterator], r;
    return t ? t.call(e) : (e = typeof t0 == "function" ? t0(e) : e[Symbol.iterator](), r = {}, a("next"), a("throw"), a("return"), r[Symbol.asyncIterator] = function() {
      return this;
    }, r);
    function a(l) {
      r[l] = e[l] && function(u) {
        return new Promise(function(f, p) {
          u = e[l](u), s(f, p, u.done, u.value);
        });
      };
    }
    function s(l, u, f, p) {
      Promise.resolve(p).then(function(m) {
        l({ value: m, done: f });
      }, u);
    }
  }
  class Ut {
    constructor(t) {
      this._promise = t;
    }
    static fromSafePromise(t) {
      const r = t.then((a) => new rr(a));
      return new Ut(r);
    }
    static fromPromise(t, r) {
      const a = t.then((s) => new rr(s)).catch((s) => new In(r(s)));
      return new Ut(a);
    }
    static fromThrowable(t, r) {
      return (...a) => new Ut(na(this, void 0, void 0, function* () {
        try {
          return new rr(yield t(...a));
        } catch (s) {
          return new In(r ? r(s) : s);
        }
      }));
    }
    static combine(t) {
      return mO(t);
    }
    static combineWithAllErrors(t) {
      return gO(t);
    }
    map(t) {
      return new Ut(this._promise.then((r) => na(this, void 0, void 0, function* () {
        return r.isErr() ? new In(r.error) : new rr(yield t(r.value));
      })));
    }
    andThrough(t) {
      return new Ut(this._promise.then((r) => na(this, void 0, void 0, function* () {
        if (r.isErr()) return new In(r.error);
        const a = yield t(r.value);
        return a.isErr() ? new In(a.error) : new rr(r.value);
      })));
    }
    andTee(t) {
      return new Ut(this._promise.then((r) => na(this, void 0, void 0, function* () {
        if (r.isErr()) return new In(r.error);
        try {
          yield t(r.value);
        } catch {
        }
        return new rr(r.value);
      })));
    }
    orTee(t) {
      return new Ut(this._promise.then((r) => na(this, void 0, void 0, function* () {
        if (r.isOk()) return new rr(r.value);
        try {
          yield t(r.error);
        } catch {
        }
        return new In(r.error);
      })));
    }
    mapErr(t) {
      return new Ut(this._promise.then((r) => na(this, void 0, void 0, function* () {
        return r.isOk() ? new rr(r.value) : new In(yield t(r.error));
      })));
    }
    andThen(t) {
      return new Ut(this._promise.then((r) => {
        if (r.isErr()) return new In(r.error);
        const a = t(r.value);
        return a instanceof Ut ? a._promise : a;
      }));
    }
    orElse(t) {
      return new Ut(this._promise.then((r) => na(this, void 0, void 0, function* () {
        return r.isErr() ? t(r.error) : new rr(r.value);
      })));
    }
    match(t, r) {
      return this._promise.then((a) => a.match(t, r));
    }
    unwrapOr(t) {
      return this._promise.then((r) => r.unwrapOr(t));
    }
    safeUnwrap() {
      return n0(this, arguments, function* () {
        return yield ar(yield ar(yield* hO(pO(yield ar(this._promise.then((r) => r.safeUnwrap()))))));
      });
    }
    then(t, r) {
      return this._promise.then(t, r);
    }
    [Symbol.asyncIterator]() {
      return n0(this, arguments, function* () {
        const r = yield ar(this._promise);
        return r.isErr() && (yield yield ar(qc(r.error))), yield ar(r.value);
      });
    }
  }
  function qc(e) {
    return new Ut(Promise.resolve(new In(e)));
  }
  const zS = (e) => {
    let t = it([]);
    for (const r of e) if (r.isErr()) {
      t = Se(r.error);
      break;
    } else t.map((a) => a.push(r.value));
    return t;
  }, mO = (e) => Ut.fromSafePromise(Promise.all(e)).andThen(zS), DS = (e) => {
    let t = it([]);
    for (const r of e) r.isErr() && t.isErr() ? t.error.push(r.error) : r.isErr() && t.isOk() ? t = Se([r.error]) : r.isOk() && t.isOk() && t.value.push(r.value);
    return t;
  }, gO = (e) => Ut.fromSafePromise(Promise.all(e)).andThen(DS);
  var tp;
  (function(e) {
    function t(s, l) {
      return (...u) => {
        try {
          const f = s(...u);
          return it(f);
        } catch (f) {
          return Se(l ? l(f) : f);
        }
      };
    }
    e.fromThrowable = t;
    function r(s) {
      return zS(s);
    }
    e.combine = r;
    function a(s) {
      return DS(s);
    }
    e.combineWithAllErrors = a;
  })(tp || (tp = {}));
  function it(e) {
    return new rr(e);
  }
  function Se(e) {
    return new In(e);
  }
  class rr {
    constructor(t) {
      this.value = t;
    }
    isOk() {
      return true;
    }
    isErr() {
      return !this.isOk();
    }
    map(t) {
      return it(t(this.value));
    }
    mapErr(t) {
      return it(this.value);
    }
    andThen(t) {
      return t(this.value);
    }
    andThrough(t) {
      return t(this.value).map((r) => this.value);
    }
    andTee(t) {
      try {
        t(this.value);
      } catch {
      }
      return it(this.value);
    }
    orTee(t) {
      return it(this.value);
    }
    orElse(t) {
      return it(this.value);
    }
    asyncAndThen(t) {
      return t(this.value);
    }
    asyncAndThrough(t) {
      return t(this.value).map(() => this.value);
    }
    asyncMap(t) {
      return Ut.fromSafePromise(t(this.value));
    }
    unwrapOr(t) {
      return this.value;
    }
    match(t, r) {
      return t(this.value);
    }
    safeUnwrap() {
      const t = this.value;
      return (function* () {
        return t;
      })();
    }
    _unsafeUnwrap(t) {
      return this.value;
    }
    _unsafeUnwrapErr(t) {
      throw NS("Called `_unsafeUnwrapErr` on an Ok", this, t);
    }
    *[Symbol.iterator]() {
      return this.value;
    }
  }
  class In {
    constructor(t) {
      this.error = t;
    }
    isOk() {
      return false;
    }
    isErr() {
      return !this.isOk();
    }
    map(t) {
      return Se(this.error);
    }
    mapErr(t) {
      return Se(t(this.error));
    }
    andThrough(t) {
      return Se(this.error);
    }
    andTee(t) {
      return Se(this.error);
    }
    orTee(t) {
      try {
        t(this.error);
      } catch {
      }
      return Se(this.error);
    }
    andThen(t) {
      return Se(this.error);
    }
    orElse(t) {
      return t(this.error);
    }
    asyncAndThen(t) {
      return qc(this.error);
    }
    asyncAndThrough(t) {
      return qc(this.error);
    }
    asyncMap(t) {
      return qc(this.error);
    }
    unwrapOr(t) {
      return t;
    }
    match(t, r) {
      return r(this.error);
    }
    safeUnwrap() {
      const t = this.error;
      return (function* () {
        throw yield Se(t), new Error("Do not use this generator out of `safeTry`");
      })();
    }
    _unsafeUnwrap(t) {
      throw NS("Called `_unsafeUnwrap` on an Err", this, t);
    }
    _unsafeUnwrapErr(t) {
      return this.error;
    }
    *[Symbol.iterator]() {
      const t = this;
      return yield t, t;
    }
  }
  tp.fromThrowable;
  function te(e, t, r) {
    var _a4;
    function a(f, p) {
      if (f._zod || Object.defineProperty(f, "_zod", { value: { def: p, constr: u, traits: /* @__PURE__ */ new Set() }, enumerable: false }), f._zod.traits.has(e)) return;
      f._zod.traits.add(e), t(f, p);
      const m = u.prototype, v = Object.keys(m);
      for (let g = 0; g < v.length; g++) {
        const S = v[g];
        S in f || (f[S] = m[S].bind(f));
      }
    }
    const s = (_a4 = r == null ? void 0 : r.Parent) != null ? _a4 : Object;
    class l extends s {
    }
    Object.defineProperty(l, "name", { value: e });
    function u(f) {
      var _a5;
      var p;
      const m = (r == null ? void 0 : r.Parent) ? new l() : this;
      a(m, f), (_a5 = (p = m._zod).deferred) != null ? _a5 : p.deferred = [];
      for (const v of m._zod.deferred) v();
      return m;
    }
    return Object.defineProperty(u, "init", { value: a }), Object.defineProperty(u, Symbol.hasInstance, { value: (f) => {
      var _a5, _b2;
      return (r == null ? void 0 : r.Parent) && f instanceof r.Parent ? true : (_b2 = (_a5 = f == null ? void 0 : f._zod) == null ? void 0 : _a5.traits) == null ? void 0 : _b2.has(e);
    } }), Object.defineProperty(u, "name", { value: e }), u;
  }
  class di extends Error {
    constructor() {
      super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
    }
  }
  class jS extends Error {
    constructor(t) {
      super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
    }
  }
  const kS = {};
  function ca(e) {
    return kS;
  }
  function PS(e) {
    const t = Object.values(e).filter((a) => typeof a == "number");
    return Object.entries(e).filter(([a, s]) => t.indexOf(+a) === -1).map(([a, s]) => s);
  }
  function np(e, t) {
    return typeof t == "bigint" ? t.toString() : t;
  }
  function qp(e) {
    return { get value() {
      {
        const t = e();
        return Object.defineProperty(this, "value", { value: t }), t;
      }
    } };
  }
  function Yp(e) {
    return e == null;
  }
  function Xp(e) {
    const t = e.startsWith("^") ? 1 : 0, r = e.endsWith("$") ? e.length - 1 : e.length;
    return e.slice(t, r);
  }
  function vO(e, t) {
    const r = (e.toString().split(".")[1] || "").length, a = t.toString();
    let s = (a.split(".")[1] || "").length;
    if (s === 0 && /\d?e-\d?/.test(a)) {
      const p = a.match(/\d?e-(\d?)/);
      (p == null ? void 0 : p[1]) && (s = Number.parseInt(p[1]));
    }
    const l = r > s ? r : s, u = Number.parseInt(e.toFixed(l).replace(".", "")), f = Number.parseInt(t.toFixed(l).replace(".", ""));
    return u % f / 10 ** l;
  }
  const r0 = /* @__PURE__ */ Symbol("evaluating");
  function Ye(e, t, r) {
    let a;
    Object.defineProperty(e, t, { get() {
      if (a !== r0) return a === void 0 && (a = r0, a = r()), a;
    }, set(s) {
      Object.defineProperty(e, t, { value: s });
    }, configurable: true });
  }
  function ga(e, t, r) {
    Object.defineProperty(e, t, { value: r, writable: true, enumerable: true, configurable: true });
  }
  function Mo(...e) {
    const t = {};
    for (const r of e) {
      const a = Object.getOwnPropertyDescriptors(r);
      Object.assign(t, a);
    }
    return Object.defineProperties({}, t);
  }
  function o0(e) {
    return JSON.stringify(e);
  }
  function yO(e) {
    return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
  }
  const LS = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
  };
  function Wc(e) {
    return typeof e == "object" && e !== null && !Array.isArray(e);
  }
  const bO = qp(() => {
    var _a4;
    if (typeof navigator < "u" && ((_a4 = navigator == null ? void 0 : navigator.userAgent) == null ? void 0 : _a4.includes("Cloudflare"))) return false;
    try {
      const e = Function;
      return new e(""), true;
    } catch {
      return false;
    }
  });
  function Vs(e) {
    if (Wc(e) === false) return false;
    const t = e.constructor;
    if (t === void 0 || typeof t != "function") return true;
    const r = t.prototype;
    return !(Wc(r) === false || Object.prototype.hasOwnProperty.call(r, "isPrototypeOf") === false);
  }
  function US(e) {
    return Vs(e) ? { ...e } : Array.isArray(e) ? [...e] : e;
  }
  const wO = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
  function Ru(e) {
    return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function No(e, t, r) {
    const a = new e._zod.constr(t != null ? t : e._zod.def);
    return (!t || (r == null ? void 0 : r.parent)) && (a._zod.parent = e), a;
  }
  function be(e) {
    const t = e;
    if (!t) return {};
    if (typeof t == "string") return { error: () => t };
    if ((t == null ? void 0 : t.message) !== void 0) {
      if ((t == null ? void 0 : t.error) !== void 0) throw new Error("Cannot specify both `message` and `error` params");
      t.error = t.message;
    }
    return delete t.message, typeof t.error == "string" ? { ...t, error: () => t.error } : t;
  }
  function SO(e) {
    return Object.keys(e).filter((t) => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional");
  }
  const xO = { safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER], int32: [-2147483648, 2147483647], uint32: [0, 4294967295], float32: [-34028234663852886e22, 34028234663852886e22], float64: [-Number.MAX_VALUE, Number.MAX_VALUE] };
  function _O(e, t) {
    const r = e._zod.def, a = r.checks;
    if (a && a.length > 0) throw new Error(".pick() cannot be used on object schemas containing refinements");
    const l = Mo(e._zod.def, { get shape() {
      const u = {};
      for (const f in t) {
        if (!(f in r.shape)) throw new Error(`Unrecognized key: "${f}"`);
        t[f] && (u[f] = r.shape[f]);
      }
      return ga(this, "shape", u), u;
    }, checks: [] });
    return No(e, l);
  }
  function EO(e, t) {
    const r = e._zod.def, a = r.checks;
    if (a && a.length > 0) throw new Error(".omit() cannot be used on object schemas containing refinements");
    const l = Mo(e._zod.def, { get shape() {
      const u = { ...e._zod.def.shape };
      for (const f in t) {
        if (!(f in r.shape)) throw new Error(`Unrecognized key: "${f}"`);
        t[f] && delete u[f];
      }
      return ga(this, "shape", u), u;
    }, checks: [] });
    return No(e, l);
  }
  function AO(e, t) {
    if (!Vs(t)) throw new Error("Invalid input to extend: expected a plain object");
    const r = e._zod.def.checks;
    if (r && r.length > 0) {
      const l = e._zod.def.shape;
      for (const u in t) if (Object.getOwnPropertyDescriptor(l, u) !== void 0) throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
    }
    const s = Mo(e._zod.def, { get shape() {
      const l = { ...e._zod.def.shape, ...t };
      return ga(this, "shape", l), l;
    } });
    return No(e, s);
  }
  function CO(e, t) {
    if (!Vs(t)) throw new Error("Invalid input to safeExtend: expected a plain object");
    const r = Mo(e._zod.def, { get shape() {
      const a = { ...e._zod.def.shape, ...t };
      return ga(this, "shape", a), a;
    } });
    return No(e, r);
  }
  function TO(e, t) {
    const r = Mo(e._zod.def, { get shape() {
      const a = { ...e._zod.def.shape, ...t._zod.def.shape };
      return ga(this, "shape", a), a;
    }, get catchall() {
      return t._zod.def.catchall;
    }, checks: [] });
    return No(e, r);
  }
  function OO(e, t, r) {
    const s = t._zod.def.checks;
    if (s && s.length > 0) throw new Error(".partial() cannot be used on object schemas containing refinements");
    const u = Mo(t._zod.def, { get shape() {
      const f = t._zod.def.shape, p = { ...f };
      if (r) for (const m in r) {
        if (!(m in f)) throw new Error(`Unrecognized key: "${m}"`);
        r[m] && (p[m] = e ? new e({ type: "optional", innerType: f[m] }) : f[m]);
      }
      else for (const m in f) p[m] = e ? new e({ type: "optional", innerType: f[m] }) : f[m];
      return ga(this, "shape", p), p;
    }, checks: [] });
    return No(t, u);
  }
  function RO(e, t, r) {
    const a = Mo(t._zod.def, { get shape() {
      const s = t._zod.def.shape, l = { ...s };
      if (r) for (const u in r) {
        if (!(u in l)) throw new Error(`Unrecognized key: "${u}"`);
        r[u] && (l[u] = new e({ type: "nonoptional", innerType: s[u] }));
      }
      else for (const u in s) l[u] = new e({ type: "nonoptional", innerType: s[u] });
      return ga(this, "shape", l), l;
    } });
    return No(t, a);
  }
  function ui(e, t = 0) {
    var _a4;
    if (e.aborted === true) return true;
    for (let r = t; r < e.issues.length; r++) if (((_a4 = e.issues[r]) == null ? void 0 : _a4.continue) !== true) return true;
    return false;
  }
  function BS(e, t) {
    return t.map((r) => {
      var _a4;
      var a;
      return (_a4 = (a = r).path) != null ? _a4 : a.path = [], r.path.unshift(e), r;
    });
  }
  function Tc(e) {
    return typeof e == "string" ? e : e == null ? void 0 : e.message;
  }
  function ua(e, t, r) {
    var _a4, _b2, _c3, _d3, _e13, _f2, _g2, _h4, _i6, _j3, _k3;
    const a = { ...e, path: (_a4 = e.path) != null ? _a4 : [] };
    if (!e.message) {
      const s = (_k3 = (_j3 = (_h4 = (_f2 = Tc((_d3 = (_c3 = (_b2 = e.inst) == null ? void 0 : _b2._zod.def) == null ? void 0 : _c3.error) == null ? void 0 : _d3.call(_c3, e))) != null ? _f2 : Tc((_e13 = t == null ? void 0 : t.error) == null ? void 0 : _e13.call(t, e))) != null ? _h4 : Tc((_g2 = r.customError) == null ? void 0 : _g2.call(r, e))) != null ? _j3 : Tc((_i6 = r.localeError) == null ? void 0 : _i6.call(r, e))) != null ? _k3 : "Invalid input";
      a.message = s;
    }
    return delete a.inst, delete a.continue, (t == null ? void 0 : t.reportInput) || delete a.input, a;
  }
  function Qp(e) {
    return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
  }
  function Zs(...e) {
    const [t, r, a] = e;
    return typeof t == "string" ? { message: t, code: "custom", input: r, inst: a } : { ...t };
  }
  const IS = (e, t) => {
    e.name = "$ZodError", Object.defineProperty(e, "_zod", { value: e._zod, enumerable: false }), Object.defineProperty(e, "issues", { value: t, enumerable: false }), e.message = JSON.stringify(t, np, 2), Object.defineProperty(e, "toString", { value: () => e.message, enumerable: false });
  }, HS = te("$ZodError", IS), $S = te("$ZodError", IS, { Parent: Error });
  function MO(e, t = (r) => r.message) {
    const r = {}, a = [];
    for (const s of e.issues) s.path.length > 0 ? (r[s.path[0]] = r[s.path[0]] || [], r[s.path[0]].push(t(s))) : a.push(t(s));
    return { formErrors: a, fieldErrors: r };
  }
  function NO(e, t = (r) => r.message) {
    const r = { _errors: [] }, a = (s) => {
      for (const l of s.issues) if (l.code === "invalid_union" && l.errors.length) l.errors.map((u) => a({ issues: u }));
      else if (l.code === "invalid_key") a({ issues: l.issues });
      else if (l.code === "invalid_element") a({ issues: l.issues });
      else if (l.path.length === 0) r._errors.push(t(l));
      else {
        let u = r, f = 0;
        for (; f < l.path.length; ) {
          const p = l.path[f];
          f === l.path.length - 1 ? (u[p] = u[p] || { _errors: [] }, u[p]._errors.push(t(l))) : u[p] = u[p] || { _errors: [] }, u = u[p], f++;
        }
      }
    };
    return a(e), r;
  }
  const Gp = (e) => (t, r, a, s) => {
    var _a4;
    const l = a ? Object.assign(a, { async: false }) : { async: false }, u = t._zod.run({ value: r, issues: [] }, l);
    if (u instanceof Promise) throw new di();
    if (u.issues.length) {
      const f = new ((_a4 = s == null ? void 0 : s.Err) != null ? _a4 : e)(u.issues.map((p) => ua(p, l, ca())));
      throw LS(f, s == null ? void 0 : s.callee), f;
    }
    return u.value;
  }, Kp = (e) => async (t, r, a, s) => {
    var _a4;
    const l = a ? Object.assign(a, { async: true }) : { async: true };
    let u = t._zod.run({ value: r, issues: [] }, l);
    if (u instanceof Promise && (u = await u), u.issues.length) {
      const f = new ((_a4 = s == null ? void 0 : s.Err) != null ? _a4 : e)(u.issues.map((p) => ua(p, l, ca())));
      throw LS(f, s == null ? void 0 : s.callee), f;
    }
    return u.value;
  }, Mu = (e) => (t, r, a) => {
    const s = a ? { ...a, async: false } : { async: false }, l = t._zod.run({ value: r, issues: [] }, s);
    if (l instanceof Promise) throw new di();
    return l.issues.length ? { success: false, error: new (e != null ? e : HS)(l.issues.map((u) => ua(u, s, ca()))) } : { success: true, data: l.value };
  }, zO = Mu($S), Nu = (e) => async (t, r, a) => {
    const s = a ? Object.assign(a, { async: true }) : { async: true };
    let l = t._zod.run({ value: r, issues: [] }, s);
    return l instanceof Promise && (l = await l), l.issues.length ? { success: false, error: new e(l.issues.map((u) => ua(u, s, ca()))) } : { success: true, data: l.value };
  }, DO = Nu($S), jO = (e) => (t, r, a) => {
    const s = a ? Object.assign(a, { direction: "backward" }) : { direction: "backward" };
    return Gp(e)(t, r, s);
  }, kO = (e) => (t, r, a) => Gp(e)(t, r, a), PO = (e) => async (t, r, a) => {
    const s = a ? Object.assign(a, { direction: "backward" }) : { direction: "backward" };
    return Kp(e)(t, r, s);
  }, LO = (e) => async (t, r, a) => Kp(e)(t, r, a), UO = (e) => (t, r, a) => {
    const s = a ? Object.assign(a, { direction: "backward" }) : { direction: "backward" };
    return Mu(e)(t, r, s);
  }, BO = (e) => (t, r, a) => Mu(e)(t, r, a), IO = (e) => async (t, r, a) => {
    const s = a ? Object.assign(a, { direction: "backward" }) : { direction: "backward" };
    return Nu(e)(t, r, s);
  }, HO = (e) => async (t, r, a) => Nu(e)(t, r, a), $O = /^[cC][^\s-]{8,}$/, VO = /^[0-9a-z]+$/, ZO = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, FO = /^[0-9a-vA-V]{20}$/, qO = /^[A-Za-z0-9]{27}$/, YO = /^[a-zA-Z0-9_-]{21}$/, XO = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, QO = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, a0 = (e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, GO = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, KO = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
  function JO() {
    return new RegExp(KO, "u");
  }
  const WO = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, eR = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, tR = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, nR = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, rR = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, VS = /^[A-Za-z0-9_-]*$/, oR = /^\+[1-9]\d{6,14}$/, ZS = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", aR = new RegExp(`^${ZS}$`);
  function FS(e) {
    const t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
    return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
  }
  function iR(e) {
    return new RegExp(`^${FS(e)}$`);
  }
  function sR(e) {
    const t = FS({ precision: e.precision }), r = ["Z"];
    e.local && r.push(""), e.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
    const a = `${t}(?:${r.join("|")})`;
    return new RegExp(`^${ZS}T(?:${a})$`);
  }
  const lR = (e) => {
    var _a4, _b2;
    const t = e ? `[\\s\\S]{${(_a4 = e == null ? void 0 : e.minimum) != null ? _a4 : 0},${(_b2 = e == null ? void 0 : e.maximum) != null ? _b2 : ""}}` : "[\\s\\S]*";
    return new RegExp(`^${t}$`);
  }, cR = /^-?\d+$/, uR = /^-?\d+(?:\.\d+)?$/, fR = /^(?:true|false)$/i, dR = /^[^A-Z]*$/, hR = /^[^a-z]*$/, sn = te("$ZodCheck", (e, t) => {
    var _a4, _b2;
    var r;
    (_a4 = e._zod) != null ? _a4 : e._zod = {}, e._zod.def = t, (_b2 = (r = e._zod).onattach) != null ? _b2 : r.onattach = [];
  }), qS = { number: "number", bigint: "bigint", object: "date" }, YS = te("$ZodCheckLessThan", (e, t) => {
    sn.init(e, t);
    const r = qS[typeof t.value];
    e._zod.onattach.push((a) => {
      var _a4;
      const s = a._zod.bag, l = (_a4 = t.inclusive ? s.maximum : s.exclusiveMaximum) != null ? _a4 : Number.POSITIVE_INFINITY;
      t.value < l && (t.inclusive ? s.maximum = t.value : s.exclusiveMaximum = t.value);
    }), e._zod.check = (a) => {
      (t.inclusive ? a.value <= t.value : a.value < t.value) || a.issues.push({ origin: r, code: "too_big", maximum: typeof t.value == "object" ? t.value.getTime() : t.value, input: a.value, inclusive: t.inclusive, inst: e, continue: !t.abort });
    };
  }), XS = te("$ZodCheckGreaterThan", (e, t) => {
    sn.init(e, t);
    const r = qS[typeof t.value];
    e._zod.onattach.push((a) => {
      var _a4;
      const s = a._zod.bag, l = (_a4 = t.inclusive ? s.minimum : s.exclusiveMinimum) != null ? _a4 : Number.NEGATIVE_INFINITY;
      t.value > l && (t.inclusive ? s.minimum = t.value : s.exclusiveMinimum = t.value);
    }), e._zod.check = (a) => {
      (t.inclusive ? a.value >= t.value : a.value > t.value) || a.issues.push({ origin: r, code: "too_small", minimum: typeof t.value == "object" ? t.value.getTime() : t.value, input: a.value, inclusive: t.inclusive, inst: e, continue: !t.abort });
    };
  }), pR = te("$ZodCheckMultipleOf", (e, t) => {
    sn.init(e, t), e._zod.onattach.push((r) => {
      var _a4;
      var a;
      (_a4 = (a = r._zod.bag).multipleOf) != null ? _a4 : a.multipleOf = t.value;
    }), e._zod.check = (r) => {
      if (typeof r.value != typeof t.value) throw new Error("Cannot mix number and bigint in multiple_of check.");
      (typeof r.value == "bigint" ? r.value % t.value === BigInt(0) : vO(r.value, t.value) === 0) || r.issues.push({ origin: typeof r.value, code: "not_multiple_of", divisor: t.value, input: r.value, inst: e, continue: !t.abort });
    };
  }), mR = te("$ZodCheckNumberFormat", (e, t) => {
    var _a4;
    sn.init(e, t), t.format = t.format || "float64";
    const r = (_a4 = t.format) == null ? void 0 : _a4.includes("int"), a = r ? "int" : "number", [s, l] = xO[t.format];
    e._zod.onattach.push((u) => {
      const f = u._zod.bag;
      f.format = t.format, f.minimum = s, f.maximum = l, r && (f.pattern = cR);
    }), e._zod.check = (u) => {
      const f = u.value;
      if (r) {
        if (!Number.isInteger(f)) {
          u.issues.push({ expected: a, format: t.format, code: "invalid_type", continue: false, input: f, inst: e });
          return;
        }
        if (!Number.isSafeInteger(f)) {
          f > 0 ? u.issues.push({ input: f, code: "too_big", maximum: Number.MAX_SAFE_INTEGER, note: "Integers must be within the safe integer range.", inst: e, origin: a, inclusive: true, continue: !t.abort }) : u.issues.push({ input: f, code: "too_small", minimum: Number.MIN_SAFE_INTEGER, note: "Integers must be within the safe integer range.", inst: e, origin: a, inclusive: true, continue: !t.abort });
          return;
        }
      }
      f < s && u.issues.push({ origin: "number", input: f, code: "too_small", minimum: s, inclusive: true, inst: e, continue: !t.abort }), f > l && u.issues.push({ origin: "number", input: f, code: "too_big", maximum: l, inclusive: true, inst: e, continue: !t.abort });
    };
  }), gR = te("$ZodCheckMaxLength", (e, t) => {
    var _a4;
    var r;
    sn.init(e, t), (_a4 = (r = e._zod.def).when) != null ? _a4 : r.when = (a) => {
      const s = a.value;
      return !Yp(s) && s.length !== void 0;
    }, e._zod.onattach.push((a) => {
      var _a5;
      const s = (_a5 = a._zod.bag.maximum) != null ? _a5 : Number.POSITIVE_INFINITY;
      t.maximum < s && (a._zod.bag.maximum = t.maximum);
    }), e._zod.check = (a) => {
      const s = a.value;
      if (s.length <= t.maximum) return;
      const u = Qp(s);
      a.issues.push({ origin: u, code: "too_big", maximum: t.maximum, inclusive: true, input: s, inst: e, continue: !t.abort });
    };
  }), vR = te("$ZodCheckMinLength", (e, t) => {
    var _a4;
    var r;
    sn.init(e, t), (_a4 = (r = e._zod.def).when) != null ? _a4 : r.when = (a) => {
      const s = a.value;
      return !Yp(s) && s.length !== void 0;
    }, e._zod.onattach.push((a) => {
      var _a5;
      const s = (_a5 = a._zod.bag.minimum) != null ? _a5 : Number.NEGATIVE_INFINITY;
      t.minimum > s && (a._zod.bag.minimum = t.minimum);
    }), e._zod.check = (a) => {
      const s = a.value;
      if (s.length >= t.minimum) return;
      const u = Qp(s);
      a.issues.push({ origin: u, code: "too_small", minimum: t.minimum, inclusive: true, input: s, inst: e, continue: !t.abort });
    };
  }), yR = te("$ZodCheckLengthEquals", (e, t) => {
    var _a4;
    var r;
    sn.init(e, t), (_a4 = (r = e._zod.def).when) != null ? _a4 : r.when = (a) => {
      const s = a.value;
      return !Yp(s) && s.length !== void 0;
    }, e._zod.onattach.push((a) => {
      const s = a._zod.bag;
      s.minimum = t.length, s.maximum = t.length, s.length = t.length;
    }), e._zod.check = (a) => {
      const s = a.value, l = s.length;
      if (l === t.length) return;
      const u = Qp(s), f = l > t.length;
      a.issues.push({ origin: u, ...f ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length }, inclusive: true, exact: true, input: a.value, inst: e, continue: !t.abort });
    };
  }), zu = te("$ZodCheckStringFormat", (e, t) => {
    var _a4, _b2;
    var r, a;
    sn.init(e, t), e._zod.onattach.push((s) => {
      var _a5;
      const l = s._zod.bag;
      l.format = t.format, t.pattern && ((_a5 = l.patterns) != null ? _a5 : l.patterns = /* @__PURE__ */ new Set(), l.patterns.add(t.pattern));
    }), t.pattern ? (_a4 = (r = e._zod).check) != null ? _a4 : r.check = (s) => {
      t.pattern.lastIndex = 0, !t.pattern.test(s.value) && s.issues.push({ origin: "string", code: "invalid_format", format: t.format, input: s.value, ...t.pattern ? { pattern: t.pattern.toString() } : {}, inst: e, continue: !t.abort });
    } : (_b2 = (a = e._zod).check) != null ? _b2 : a.check = () => {
    };
  }), bR = te("$ZodCheckRegex", (e, t) => {
    zu.init(e, t), e._zod.check = (r) => {
      t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({ origin: "string", code: "invalid_format", format: "regex", input: r.value, pattern: t.pattern.toString(), inst: e, continue: !t.abort });
    };
  }), wR = te("$ZodCheckLowerCase", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = dR, zu.init(e, t);
  }), SR = te("$ZodCheckUpperCase", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = hR, zu.init(e, t);
  }), xR = te("$ZodCheckIncludes", (e, t) => {
    sn.init(e, t);
    const r = Ru(t.includes), a = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${r}` : r);
    t.pattern = a, e._zod.onattach.push((s) => {
      var _a4;
      const l = s._zod.bag;
      (_a4 = l.patterns) != null ? _a4 : l.patterns = /* @__PURE__ */ new Set(), l.patterns.add(a);
    }), e._zod.check = (s) => {
      s.value.includes(t.includes, t.position) || s.issues.push({ origin: "string", code: "invalid_format", format: "includes", includes: t.includes, input: s.value, inst: e, continue: !t.abort });
    };
  }), _R = te("$ZodCheckStartsWith", (e, t) => {
    var _a4;
    sn.init(e, t);
    const r = new RegExp(`^${Ru(t.prefix)}.*`);
    (_a4 = t.pattern) != null ? _a4 : t.pattern = r, e._zod.onattach.push((a) => {
      var _a5;
      const s = a._zod.bag;
      (_a5 = s.patterns) != null ? _a5 : s.patterns = /* @__PURE__ */ new Set(), s.patterns.add(r);
    }), e._zod.check = (a) => {
      a.value.startsWith(t.prefix) || a.issues.push({ origin: "string", code: "invalid_format", format: "starts_with", prefix: t.prefix, input: a.value, inst: e, continue: !t.abort });
    };
  }), ER = te("$ZodCheckEndsWith", (e, t) => {
    var _a4;
    sn.init(e, t);
    const r = new RegExp(`.*${Ru(t.suffix)}$`);
    (_a4 = t.pattern) != null ? _a4 : t.pattern = r, e._zod.onattach.push((a) => {
      var _a5;
      const s = a._zod.bag;
      (_a5 = s.patterns) != null ? _a5 : s.patterns = /* @__PURE__ */ new Set(), s.patterns.add(r);
    }), e._zod.check = (a) => {
      a.value.endsWith(t.suffix) || a.issues.push({ origin: "string", code: "invalid_format", format: "ends_with", suffix: t.suffix, input: a.value, inst: e, continue: !t.abort });
    };
  }), AR = te("$ZodCheckOverwrite", (e, t) => {
    sn.init(e, t), e._zod.check = (r) => {
      r.value = t.tx(r.value);
    };
  });
  class CR {
    constructor(t = []) {
      this.content = [], this.indent = 0, this && (this.args = t);
    }
    indented(t) {
      this.indent += 1, t(this), this.indent -= 1;
    }
    write(t) {
      if (typeof t == "function") {
        t(this, { execution: "sync" }), t(this, { execution: "async" });
        return;
      }
      const a = t.split(`
`).filter((u) => u), s = Math.min(...a.map((u) => u.length - u.trimStart().length)), l = a.map((u) => u.slice(s)).map((u) => " ".repeat(this.indent * 2) + u);
      for (const u of l) this.content.push(u);
    }
    compile() {
      var _a4;
      const t = Function, r = this == null ? void 0 : this.args, s = [...((_a4 = this == null ? void 0 : this.content) != null ? _a4 : [""]).map((l) => `  ${l}`)];
      return new t(...r, s.join(`
`));
    }
  }
  const TR = { major: 4, minor: 3, patch: 6 }, dt = te("$ZodType", (e, t) => {
    var _a4, _b2, _c3;
    var r;
    e != null ? e : e = {}, e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = TR;
    const a = [...(_a4 = e._zod.def.checks) != null ? _a4 : []];
    e._zod.traits.has("$ZodCheck") && a.unshift(e);
    for (const s of a) for (const l of s._zod.onattach) l(e);
    if (a.length === 0) (_b2 = (r = e._zod).deferred) != null ? _b2 : r.deferred = [], (_c3 = e._zod.deferred) == null ? void 0 : _c3.push(() => {
      e._zod.run = e._zod.parse;
    });
    else {
      const s = (u, f, p) => {
        let m = ui(u), v;
        for (const g of f) {
          if (g._zod.def.when) {
            if (!g._zod.def.when(u)) continue;
          } else if (m) continue;
          const S = u.issues.length, _ = g._zod.check(u);
          if (_ instanceof Promise && (p == null ? void 0 : p.async) === false) throw new di();
          if (v || _ instanceof Promise) v = (v != null ? v : Promise.resolve()).then(async () => {
            await _, u.issues.length !== S && (m || (m = ui(u, S)));
          });
          else {
            if (u.issues.length === S) continue;
            m || (m = ui(u, S));
          }
        }
        return v ? v.then(() => u) : u;
      }, l = (u, f, p) => {
        if (ui(u)) return u.aborted = true, u;
        const m = s(f, a, p);
        if (m instanceof Promise) {
          if (p.async === false) throw new di();
          return m.then((v) => e._zod.parse(v, p));
        }
        return e._zod.parse(m, p);
      };
      e._zod.run = (u, f) => {
        if (f.skipChecks) return e._zod.parse(u, f);
        if (f.direction === "backward") {
          const m = e._zod.parse({ value: u.value, issues: [] }, { ...f, skipChecks: true });
          return m instanceof Promise ? m.then((v) => l(v, u, f)) : l(m, u, f);
        }
        const p = e._zod.parse(u, f);
        if (p instanceof Promise) {
          if (f.async === false) throw new di();
          return p.then((m) => s(m, a, f));
        }
        return s(p, a, f);
      };
    }
    Ye(e, "~standard", () => ({ validate: (s) => {
      var _a5;
      try {
        const l = zO(e, s);
        return l.success ? { value: l.data } : { issues: (_a5 = l.error) == null ? void 0 : _a5.issues };
      } catch {
        return DO(e, s).then((u) => {
          var _a6;
          return u.success ? { value: u.data } : { issues: (_a6 = u.error) == null ? void 0 : _a6.issues };
        });
      }
    }, vendor: "zod", version: 1 }));
  }), Jp = te("$ZodString", (e, t) => {
    var _a4, _b2, _c3;
    dt.init(e, t), e._zod.pattern = (_c3 = [...(_b2 = (_a4 = e == null ? void 0 : e._zod.bag) == null ? void 0 : _a4.patterns) != null ? _b2 : []].pop()) != null ? _c3 : lR(e._zod.bag), e._zod.parse = (r, a) => {
      if (t.coerce) try {
        r.value = String(r.value);
      } catch {
      }
      return typeof r.value == "string" || r.issues.push({ expected: "string", code: "invalid_type", input: r.value, inst: e }), r;
    };
  }), ot = te("$ZodStringFormat", (e, t) => {
    zu.init(e, t), Jp.init(e, t);
  }), OR = te("$ZodGUID", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = QO, ot.init(e, t);
  }), RR = te("$ZodUUID", (e, t) => {
    var _a4, _b2;
    if (t.version) {
      const a = { v1: 1, v2: 2, v3: 3, v4: 4, v5: 5, v6: 6, v7: 7, v8: 8 }[t.version];
      if (a === void 0) throw new Error(`Invalid UUID version: "${t.version}"`);
      (_a4 = t.pattern) != null ? _a4 : t.pattern = a0(a);
    } else (_b2 = t.pattern) != null ? _b2 : t.pattern = a0();
    ot.init(e, t);
  }), MR = te("$ZodEmail", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = GO, ot.init(e, t);
  }), NR = te("$ZodURL", (e, t) => {
    ot.init(e, t), e._zod.check = (r) => {
      try {
        const a = r.value.trim(), s = new URL(a);
        t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(s.hostname) || r.issues.push({ code: "invalid_format", format: "url", note: "Invalid hostname", pattern: t.hostname.source, input: r.value, inst: e, continue: !t.abort })), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(s.protocol.endsWith(":") ? s.protocol.slice(0, -1) : s.protocol) || r.issues.push({ code: "invalid_format", format: "url", note: "Invalid protocol", pattern: t.protocol.source, input: r.value, inst: e, continue: !t.abort })), t.normalize ? r.value = s.href : r.value = a;
        return;
      } catch {
        r.issues.push({ code: "invalid_format", format: "url", input: r.value, inst: e, continue: !t.abort });
      }
    };
  }), zR = te("$ZodEmoji", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = JO(), ot.init(e, t);
  }), DR = te("$ZodNanoID", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = YO, ot.init(e, t);
  }), jR = te("$ZodCUID", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = $O, ot.init(e, t);
  }), kR = te("$ZodCUID2", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = VO, ot.init(e, t);
  }), PR = te("$ZodULID", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = ZO, ot.init(e, t);
  }), LR = te("$ZodXID", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = FO, ot.init(e, t);
  }), UR = te("$ZodKSUID", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = qO, ot.init(e, t);
  }), BR = te("$ZodISODateTime", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = sR(t), ot.init(e, t);
  }), IR = te("$ZodISODate", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = aR, ot.init(e, t);
  }), HR = te("$ZodISOTime", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = iR(t), ot.init(e, t);
  }), $R = te("$ZodISODuration", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = XO, ot.init(e, t);
  }), VR = te("$ZodIPv4", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = WO, ot.init(e, t), e._zod.bag.format = "ipv4";
  }), ZR = te("$ZodIPv6", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = eR, ot.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (r) => {
      try {
        new URL(`http://[${r.value}]`);
      } catch {
        r.issues.push({ code: "invalid_format", format: "ipv6", input: r.value, inst: e, continue: !t.abort });
      }
    };
  }), FR = te("$ZodCIDRv4", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = tR, ot.init(e, t);
  }), qR = te("$ZodCIDRv6", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = nR, ot.init(e, t), e._zod.check = (r) => {
      const a = r.value.split("/");
      try {
        if (a.length !== 2) throw new Error();
        const [s, l] = a;
        if (!l) throw new Error();
        const u = Number(l);
        if (`${u}` !== l) throw new Error();
        if (u < 0 || u > 128) throw new Error();
        new URL(`http://[${s}]`);
      } catch {
        r.issues.push({ code: "invalid_format", format: "cidrv6", input: r.value, inst: e, continue: !t.abort });
      }
    };
  });
  function QS(e) {
    if (e === "") return true;
    if (e.length % 4 !== 0) return false;
    try {
      return atob(e), true;
    } catch {
      return false;
    }
  }
  const YR = te("$ZodBase64", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = rR, ot.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (r) => {
      QS(r.value) || r.issues.push({ code: "invalid_format", format: "base64", input: r.value, inst: e, continue: !t.abort });
    };
  });
  function XR(e) {
    if (!VS.test(e)) return false;
    const t = e.replace(/[-_]/g, (a) => a === "-" ? "+" : "/"), r = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
    return QS(r);
  }
  const QR = te("$ZodBase64URL", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = VS, ot.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (r) => {
      XR(r.value) || r.issues.push({ code: "invalid_format", format: "base64url", input: r.value, inst: e, continue: !t.abort });
    };
  }), GR = te("$ZodE164", (e, t) => {
    var _a4;
    (_a4 = t.pattern) != null ? _a4 : t.pattern = oR, ot.init(e, t);
  });
  function KR(e, t = null) {
    try {
      const r = e.split(".");
      if (r.length !== 3) return false;
      const [a] = r;
      if (!a) return false;
      const s = JSON.parse(atob(a));
      return !("typ" in s && (s == null ? void 0 : s.typ) !== "JWT" || !s.alg || t && (!("alg" in s) || s.alg !== t));
    } catch {
      return false;
    }
  }
  const JR = te("$ZodJWT", (e, t) => {
    ot.init(e, t), e._zod.check = (r) => {
      KR(r.value, t.alg) || r.issues.push({ code: "invalid_format", format: "jwt", input: r.value, inst: e, continue: !t.abort });
    };
  }), GS = te("$ZodNumber", (e, t) => {
    var _a4;
    dt.init(e, t), e._zod.pattern = (_a4 = e._zod.bag.pattern) != null ? _a4 : uR, e._zod.parse = (r, a) => {
      if (t.coerce) try {
        r.value = Number(r.value);
      } catch {
      }
      const s = r.value;
      if (typeof s == "number" && !Number.isNaN(s) && Number.isFinite(s)) return r;
      const l = typeof s == "number" ? Number.isNaN(s) ? "NaN" : Number.isFinite(s) ? void 0 : "Infinity" : void 0;
      return r.issues.push({ expected: "number", code: "invalid_type", input: s, inst: e, ...l ? { received: l } : {} }), r;
    };
  }), WR = te("$ZodNumberFormat", (e, t) => {
    mR.init(e, t), GS.init(e, t);
  }), eM = te("$ZodBoolean", (e, t) => {
    dt.init(e, t), e._zod.pattern = fR, e._zod.parse = (r, a) => {
      if (t.coerce) try {
        r.value = !!r.value;
      } catch {
      }
      const s = r.value;
      return typeof s == "boolean" || r.issues.push({ expected: "boolean", code: "invalid_type", input: s, inst: e }), r;
    };
  }), tM = te("$ZodUnknown", (e, t) => {
    dt.init(e, t), e._zod.parse = (r) => r;
  }), nM = te("$ZodNever", (e, t) => {
    dt.init(e, t), e._zod.parse = (r, a) => (r.issues.push({ expected: "never", code: "invalid_type", input: r.value, inst: e }), r);
  });
  function i0(e, t, r) {
    e.issues.length && t.issues.push(...BS(r, e.issues)), t.value[r] = e.value;
  }
  const rM = te("$ZodArray", (e, t) => {
    dt.init(e, t), e._zod.parse = (r, a) => {
      const s = r.value;
      if (!Array.isArray(s)) return r.issues.push({ expected: "array", code: "invalid_type", input: s, inst: e }), r;
      r.value = Array(s.length);
      const l = [];
      for (let u = 0; u < s.length; u++) {
        const f = s[u], p = t.element._zod.run({ value: f, issues: [] }, a);
        p instanceof Promise ? l.push(p.then((m) => i0(m, r, u))) : i0(p, r, u);
      }
      return l.length ? Promise.all(l).then(() => r) : r;
    };
  });
  function eu(e, t, r, a, s) {
    if (e.issues.length) {
      if (s && !(r in a)) return;
      t.issues.push(...BS(r, e.issues));
    }
    e.value === void 0 ? r in a && (t.value[r] = void 0) : t.value[r] = e.value;
  }
  function KS(e) {
    var _a4, _b2, _c3, _d3;
    const t = Object.keys(e.shape);
    for (const a of t) if (!((_d3 = (_c3 = (_b2 = (_a4 = e.shape) == null ? void 0 : _a4[a]) == null ? void 0 : _b2._zod) == null ? void 0 : _c3.traits) == null ? void 0 : _d3.has("$ZodType"))) throw new Error(`Invalid element at key "${a}": expected a Zod schema`);
    const r = SO(e.shape);
    return { ...e, keys: t, keySet: new Set(t), numKeys: t.length, optionalKeys: new Set(r) };
  }
  function JS(e, t, r, a, s, l) {
    const u = [], f = s.keySet, p = s.catchall._zod, m = p.def.type, v = p.optout === "optional";
    for (const g in t) {
      if (f.has(g)) continue;
      if (m === "never") {
        u.push(g);
        continue;
      }
      const S = p.run({ value: t[g], issues: [] }, a);
      S instanceof Promise ? e.push(S.then((_) => eu(_, r, g, t, v))) : eu(S, r, g, t, v);
    }
    return u.length && r.issues.push({ code: "unrecognized_keys", keys: u, input: t, inst: l }), e.length ? Promise.all(e).then(() => r) : r;
  }
  const oM = te("$ZodObject", (e, t) => {
    var _a4;
    if (dt.init(e, t), !((_a4 = Object.getOwnPropertyDescriptor(t, "shape")) == null ? void 0 : _a4.get)) {
      const f = t.shape;
      Object.defineProperty(t, "shape", { get: () => {
        const p = { ...f };
        return Object.defineProperty(t, "shape", { value: p }), p;
      } });
    }
    const a = qp(() => KS(t));
    Ye(e._zod, "propValues", () => {
      var _a5;
      const f = t.shape, p = {};
      for (const m in f) {
        const v = f[m]._zod;
        if (v.values) {
          (_a5 = p[m]) != null ? _a5 : p[m] = /* @__PURE__ */ new Set();
          for (const g of v.values) p[m].add(g);
        }
      }
      return p;
    });
    const s = Wc, l = t.catchall;
    let u;
    e._zod.parse = (f, p) => {
      u != null ? u : u = a.value;
      const m = f.value;
      if (!s(m)) return f.issues.push({ expected: "object", code: "invalid_type", input: m, inst: e }), f;
      f.value = {};
      const v = [], g = u.shape;
      for (const S of u.keys) {
        const _ = g[S], x = _._zod.optout === "optional", E = _._zod.run({ value: m[S], issues: [] }, p);
        E instanceof Promise ? v.push(E.then((C) => eu(C, f, S, m, x))) : eu(E, f, S, m, x);
      }
      return l ? JS(v, m, f, p, a.value, e) : v.length ? Promise.all(v).then(() => f) : f;
    };
  }), aM = te("$ZodObjectJIT", (e, t) => {
    oM.init(e, t);
    const r = e._zod.parse, a = qp(() => KS(t)), s = (S) => {
      var _a4, _b2;
      const _ = new CR(["shape", "payload", "ctx"]), x = a.value, E = (O) => {
        const D = o0(O);
        return `shape[${D}]._zod.run({ value: input[${D}], issues: [] }, ctx)`;
      };
      _.write("const input = payload.value;");
      const C = /* @__PURE__ */ Object.create(null);
      let T = 0;
      for (const O of x.keys) C[O] = `key_${T++}`;
      _.write("const newResult = {};");
      for (const O of x.keys) {
        const D = C[O], P = o0(O), k = ((_b2 = (_a4 = S[O]) == null ? void 0 : _a4._zod) == null ? void 0 : _b2.optout) === "optional";
        _.write(`const ${D} = ${E(O)};`), k ? _.write(`
        if (${D}.issues.length) {
          if (${P} in input) {
            payload.issues = payload.issues.concat(${D}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${P}, ...iss.path] : [${P}]
            })));
          }
        }
        
        if (${D}.value === undefined) {
          if (${P} in input) {
            newResult[${P}] = undefined;
          }
        } else {
          newResult[${P}] = ${D}.value;
        }
        
      `) : _.write(`
        if (${D}.issues.length) {
          payload.issues = payload.issues.concat(${D}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${P}, ...iss.path] : [${P}]
          })));
        }
        
        if (${D}.value === undefined) {
          if (${P} in input) {
            newResult[${P}] = undefined;
          }
        } else {
          newResult[${P}] = ${D}.value;
        }
        
      `);
      }
      _.write("payload.value = newResult;"), _.write("return payload;");
      const R = _.compile();
      return (O, D) => R(S, O, D);
    };
    let l;
    const u = Wc, f = !kS.jitless, m = f && bO.value, v = t.catchall;
    let g;
    e._zod.parse = (S, _) => {
      g != null ? g : g = a.value;
      const x = S.value;
      return u(x) ? f && m && (_ == null ? void 0 : _.async) === false && _.jitless !== true ? (l || (l = s(t.shape)), S = l(S, _), v ? JS([], x, S, _, g, e) : S) : r(S, _) : (S.issues.push({ expected: "object", code: "invalid_type", input: x, inst: e }), S);
    };
  });
  function s0(e, t, r, a) {
    for (const l of e) if (l.issues.length === 0) return t.value = l.value, t;
    const s = e.filter((l) => !ui(l));
    return s.length === 1 ? (t.value = s[0].value, s[0]) : (t.issues.push({ code: "invalid_union", input: t.value, inst: r, errors: e.map((l) => l.issues.map((u) => ua(u, a, ca()))) }), t);
  }
  const iM = te("$ZodUnion", (e, t) => {
    dt.init(e, t), Ye(e._zod, "optin", () => t.options.some((s) => s._zod.optin === "optional") ? "optional" : void 0), Ye(e._zod, "optout", () => t.options.some((s) => s._zod.optout === "optional") ? "optional" : void 0), Ye(e._zod, "values", () => {
      if (t.options.every((s) => s._zod.values)) return new Set(t.options.flatMap((s) => Array.from(s._zod.values)));
    }), Ye(e._zod, "pattern", () => {
      if (t.options.every((s) => s._zod.pattern)) {
        const s = t.options.map((l) => l._zod.pattern);
        return new RegExp(`^(${s.map((l) => Xp(l.source)).join("|")})$`);
      }
    });
    const r = t.options.length === 1, a = t.options[0]._zod.run;
    e._zod.parse = (s, l) => {
      if (r) return a(s, l);
      let u = false;
      const f = [];
      for (const p of t.options) {
        const m = p._zod.run({ value: s.value, issues: [] }, l);
        if (m instanceof Promise) f.push(m), u = true;
        else {
          if (m.issues.length === 0) return m;
          f.push(m);
        }
      }
      return u ? Promise.all(f).then((p) => s0(p, s, e, l)) : s0(f, s, e, l);
    };
  }), sM = te("$ZodIntersection", (e, t) => {
    dt.init(e, t), e._zod.parse = (r, a) => {
      const s = r.value, l = t.left._zod.run({ value: s, issues: [] }, a), u = t.right._zod.run({ value: s, issues: [] }, a);
      return l instanceof Promise || u instanceof Promise ? Promise.all([l, u]).then(([p, m]) => l0(r, p, m)) : l0(r, l, u);
    };
  });
  function rp(e, t) {
    if (e === t) return { valid: true, data: e };
    if (e instanceof Date && t instanceof Date && +e == +t) return { valid: true, data: e };
    if (Vs(e) && Vs(t)) {
      const r = Object.keys(t), a = Object.keys(e).filter((l) => r.indexOf(l) !== -1), s = { ...e, ...t };
      for (const l of a) {
        const u = rp(e[l], t[l]);
        if (!u.valid) return { valid: false, mergeErrorPath: [l, ...u.mergeErrorPath] };
        s[l] = u.data;
      }
      return { valid: true, data: s };
    }
    if (Array.isArray(e) && Array.isArray(t)) {
      if (e.length !== t.length) return { valid: false, mergeErrorPath: [] };
      const r = [];
      for (let a = 0; a < e.length; a++) {
        const s = e[a], l = t[a], u = rp(s, l);
        if (!u.valid) return { valid: false, mergeErrorPath: [a, ...u.mergeErrorPath] };
        r.push(u.data);
      }
      return { valid: true, data: r };
    }
    return { valid: false, mergeErrorPath: [] };
  }
  function l0(e, t, r) {
    const a = /* @__PURE__ */ new Map();
    let s;
    for (const f of t.issues) if (f.code === "unrecognized_keys") {
      s != null ? s : s = f;
      for (const p of f.keys) a.has(p) || a.set(p, {}), a.get(p).l = true;
    } else e.issues.push(f);
    for (const f of r.issues) if (f.code === "unrecognized_keys") for (const p of f.keys) a.has(p) || a.set(p, {}), a.get(p).r = true;
    else e.issues.push(f);
    const l = [...a].filter(([, f]) => f.l && f.r).map(([f]) => f);
    if (l.length && s && e.issues.push({ ...s, keys: l }), ui(e)) return e;
    const u = rp(t.value, r.value);
    if (!u.valid) throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(u.mergeErrorPath)}`);
    return e.value = u.data, e;
  }
  const lM = te("$ZodEnum", (e, t) => {
    dt.init(e, t);
    const r = PS(t.entries), a = new Set(r);
    e._zod.values = a, e._zod.pattern = new RegExp(`^(${r.filter((s) => wO.has(typeof s)).map((s) => typeof s == "string" ? Ru(s) : s.toString()).join("|")})$`), e._zod.parse = (s, l) => {
      const u = s.value;
      return a.has(u) || s.issues.push({ code: "invalid_value", values: r, input: u, inst: e }), s;
    };
  }), cM = te("$ZodTransform", (e, t) => {
    dt.init(e, t), e._zod.parse = (r, a) => {
      if (a.direction === "backward") throw new jS(e.constructor.name);
      const s = t.transform(r.value, r);
      if (a.async) return (s instanceof Promise ? s : Promise.resolve(s)).then((u) => (r.value = u, r));
      if (s instanceof Promise) throw new di();
      return r.value = s, r;
    };
  });
  function c0(e, t) {
    return e.issues.length && t === void 0 ? { issues: [], value: void 0 } : e;
  }
  const WS = te("$ZodOptional", (e, t) => {
    dt.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", Ye(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, void 0]) : void 0), Ye(e._zod, "pattern", () => {
      const r = t.innerType._zod.pattern;
      return r ? new RegExp(`^(${Xp(r.source)})?$`) : void 0;
    }), e._zod.parse = (r, a) => {
      if (t.innerType._zod.optin === "optional") {
        const s = t.innerType._zod.run(r, a);
        return s instanceof Promise ? s.then((l) => c0(l, r.value)) : c0(s, r.value);
      }
      return r.value === void 0 ? r : t.innerType._zod.run(r, a);
    };
  }), uM = te("$ZodExactOptional", (e, t) => {
    WS.init(e, t), Ye(e._zod, "values", () => t.innerType._zod.values), Ye(e._zod, "pattern", () => t.innerType._zod.pattern), e._zod.parse = (r, a) => t.innerType._zod.run(r, a);
  }), fM = te("$ZodNullable", (e, t) => {
    dt.init(e, t), Ye(e._zod, "optin", () => t.innerType._zod.optin), Ye(e._zod, "optout", () => t.innerType._zod.optout), Ye(e._zod, "pattern", () => {
      const r = t.innerType._zod.pattern;
      return r ? new RegExp(`^(${Xp(r.source)}|null)$`) : void 0;
    }), Ye(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (r, a) => r.value === null ? r : t.innerType._zod.run(r, a);
  }), dM = te("$ZodDefault", (e, t) => {
    dt.init(e, t), e._zod.optin = "optional", Ye(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, a) => {
      if (a.direction === "backward") return t.innerType._zod.run(r, a);
      if (r.value === void 0) return r.value = t.defaultValue, r;
      const s = t.innerType._zod.run(r, a);
      return s instanceof Promise ? s.then((l) => u0(l, t)) : u0(s, t);
    };
  });
  function u0(e, t) {
    return e.value === void 0 && (e.value = t.defaultValue), e;
  }
  const hM = te("$ZodPrefault", (e, t) => {
    dt.init(e, t), e._zod.optin = "optional", Ye(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, a) => (a.direction === "backward" || r.value === void 0 && (r.value = t.defaultValue), t.innerType._zod.run(r, a));
  }), pM = te("$ZodNonOptional", (e, t) => {
    dt.init(e, t), Ye(e._zod, "values", () => {
      const r = t.innerType._zod.values;
      return r ? new Set([...r].filter((a) => a !== void 0)) : void 0;
    }), e._zod.parse = (r, a) => {
      const s = t.innerType._zod.run(r, a);
      return s instanceof Promise ? s.then((l) => f0(l, e)) : f0(s, e);
    };
  });
  function f0(e, t) {
    return !e.issues.length && e.value === void 0 && e.issues.push({ code: "invalid_type", expected: "nonoptional", input: e.value, inst: t }), e;
  }
  const mM = te("$ZodCatch", (e, t) => {
    dt.init(e, t), Ye(e._zod, "optin", () => t.innerType._zod.optin), Ye(e._zod, "optout", () => t.innerType._zod.optout), Ye(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, a) => {
      if (a.direction === "backward") return t.innerType._zod.run(r, a);
      const s = t.innerType._zod.run(r, a);
      return s instanceof Promise ? s.then((l) => (r.value = l.value, l.issues.length && (r.value = t.catchValue({ ...r, error: { issues: l.issues.map((u) => ua(u, a, ca())) }, input: r.value }), r.issues = []), r)) : (r.value = s.value, s.issues.length && (r.value = t.catchValue({ ...r, error: { issues: s.issues.map((l) => ua(l, a, ca())) }, input: r.value }), r.issues = []), r);
    };
  }), gM = te("$ZodPipe", (e, t) => {
    dt.init(e, t), Ye(e._zod, "values", () => t.in._zod.values), Ye(e._zod, "optin", () => t.in._zod.optin), Ye(e._zod, "optout", () => t.out._zod.optout), Ye(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (r, a) => {
      if (a.direction === "backward") {
        const l = t.out._zod.run(r, a);
        return l instanceof Promise ? l.then((u) => Oc(u, t.in, a)) : Oc(l, t.in, a);
      }
      const s = t.in._zod.run(r, a);
      return s instanceof Promise ? s.then((l) => Oc(l, t.out, a)) : Oc(s, t.out, a);
    };
  });
  function Oc(e, t, r) {
    return e.issues.length ? (e.aborted = true, e) : t._zod.run({ value: e.value, issues: e.issues }, r);
  }
  const vM = te("$ZodReadonly", (e, t) => {
    dt.init(e, t), Ye(e._zod, "propValues", () => t.innerType._zod.propValues), Ye(e._zod, "values", () => t.innerType._zod.values), Ye(e._zod, "optin", () => {
      var _a4, _b2;
      return (_b2 = (_a4 = t.innerType) == null ? void 0 : _a4._zod) == null ? void 0 : _b2.optin;
    }), Ye(e._zod, "optout", () => {
      var _a4, _b2;
      return (_b2 = (_a4 = t.innerType) == null ? void 0 : _a4._zod) == null ? void 0 : _b2.optout;
    }), e._zod.parse = (r, a) => {
      if (a.direction === "backward") return t.innerType._zod.run(r, a);
      const s = t.innerType._zod.run(r, a);
      return s instanceof Promise ? s.then(d0) : d0(s);
    };
  });
  function d0(e) {
    return e.value = Object.freeze(e.value), e;
  }
  const yM = te("$ZodCustom", (e, t) => {
    sn.init(e, t), dt.init(e, t), e._zod.parse = (r, a) => r, e._zod.check = (r) => {
      const a = r.value, s = t.fn(a);
      if (s instanceof Promise) return s.then((l) => h0(l, r, a, e));
      h0(s, r, a, e);
    };
  });
  function h0(e, t, r, a) {
    var _a4;
    if (!e) {
      const s = { code: "custom", input: r, inst: a, path: [...(_a4 = a._zod.def.path) != null ? _a4 : []], continue: !a._zod.def.abort };
      a._zod.def.params && (s.params = a._zod.def.params), t.issues.push(Zs(s));
    }
  }
  var p0;
  class bM {
    constructor() {
      this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
    }
    add(t, ...r) {
      const a = r[0];
      return this._map.set(t, a), a && typeof a == "object" && "id" in a && this._idmap.set(a.id, t), this;
    }
    clear() {
      return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
    }
    remove(t) {
      const r = this._map.get(t);
      return r && typeof r == "object" && "id" in r && this._idmap.delete(r.id), this._map.delete(t), this;
    }
    get(t) {
      var _a4;
      const r = t._zod.parent;
      if (r) {
        const a = { ...(_a4 = this.get(r)) != null ? _a4 : {} };
        delete a.id;
        const s = { ...a, ...this._map.get(t) };
        return Object.keys(s).length ? s : void 0;
      }
      return this._map.get(t);
    }
    has(t) {
      return this._map.has(t);
    }
  }
  function wM() {
    return new bM();
  }
  (_a = (p0 = globalThis).__zod_globalRegistry) != null ? _a : p0.__zod_globalRegistry = wM();
  const Ps = globalThis.__zod_globalRegistry;
  function SM(e, t) {
    return new e({ type: "string", ...be(t) });
  }
  function xM(e, t) {
    return new e({ type: "string", format: "email", check: "string_format", abort: false, ...be(t) });
  }
  function m0(e, t) {
    return new e({ type: "string", format: "guid", check: "string_format", abort: false, ...be(t) });
  }
  function _M(e, t) {
    return new e({ type: "string", format: "uuid", check: "string_format", abort: false, ...be(t) });
  }
  function EM(e, t) {
    return new e({ type: "string", format: "uuid", check: "string_format", abort: false, version: "v4", ...be(t) });
  }
  function AM(e, t) {
    return new e({ type: "string", format: "uuid", check: "string_format", abort: false, version: "v6", ...be(t) });
  }
  function CM(e, t) {
    return new e({ type: "string", format: "uuid", check: "string_format", abort: false, version: "v7", ...be(t) });
  }
  function TM(e, t) {
    return new e({ type: "string", format: "url", check: "string_format", abort: false, ...be(t) });
  }
  function OM(e, t) {
    return new e({ type: "string", format: "emoji", check: "string_format", abort: false, ...be(t) });
  }
  function RM(e, t) {
    return new e({ type: "string", format: "nanoid", check: "string_format", abort: false, ...be(t) });
  }
  function MM(e, t) {
    return new e({ type: "string", format: "cuid", check: "string_format", abort: false, ...be(t) });
  }
  function NM(e, t) {
    return new e({ type: "string", format: "cuid2", check: "string_format", abort: false, ...be(t) });
  }
  function zM(e, t) {
    return new e({ type: "string", format: "ulid", check: "string_format", abort: false, ...be(t) });
  }
  function DM(e, t) {
    return new e({ type: "string", format: "xid", check: "string_format", abort: false, ...be(t) });
  }
  function jM(e, t) {
    return new e({ type: "string", format: "ksuid", check: "string_format", abort: false, ...be(t) });
  }
  function kM(e, t) {
    return new e({ type: "string", format: "ipv4", check: "string_format", abort: false, ...be(t) });
  }
  function PM(e, t) {
    return new e({ type: "string", format: "ipv6", check: "string_format", abort: false, ...be(t) });
  }
  function LM(e, t) {
    return new e({ type: "string", format: "cidrv4", check: "string_format", abort: false, ...be(t) });
  }
  function UM(e, t) {
    return new e({ type: "string", format: "cidrv6", check: "string_format", abort: false, ...be(t) });
  }
  function BM(e, t) {
    return new e({ type: "string", format: "base64", check: "string_format", abort: false, ...be(t) });
  }
  function IM(e, t) {
    return new e({ type: "string", format: "base64url", check: "string_format", abort: false, ...be(t) });
  }
  function HM(e, t) {
    return new e({ type: "string", format: "e164", check: "string_format", abort: false, ...be(t) });
  }
  function $M(e, t) {
    return new e({ type: "string", format: "jwt", check: "string_format", abort: false, ...be(t) });
  }
  function VM(e, t) {
    return new e({ type: "string", format: "datetime", check: "string_format", offset: false, local: false, precision: null, ...be(t) });
  }
  function ZM(e, t) {
    return new e({ type: "string", format: "date", check: "string_format", ...be(t) });
  }
  function FM(e, t) {
    return new e({ type: "string", format: "time", check: "string_format", precision: null, ...be(t) });
  }
  function qM(e, t) {
    return new e({ type: "string", format: "duration", check: "string_format", ...be(t) });
  }
  function YM(e, t) {
    return new e({ type: "number", checks: [], ...be(t) });
  }
  function XM(e, t) {
    return new e({ type: "number", check: "number_format", abort: false, format: "safeint", ...be(t) });
  }
  function QM(e, t) {
    return new e({ type: "boolean", ...be(t) });
  }
  function GM(e) {
    return new e({ type: "unknown" });
  }
  function KM(e, t) {
    return new e({ type: "never", ...be(t) });
  }
  function g0(e, t) {
    return new YS({ check: "less_than", ...be(t), value: e, inclusive: false });
  }
  function xh(e, t) {
    return new YS({ check: "less_than", ...be(t), value: e, inclusive: true });
  }
  function v0(e, t) {
    return new XS({ check: "greater_than", ...be(t), value: e, inclusive: false });
  }
  function _h(e, t) {
    return new XS({ check: "greater_than", ...be(t), value: e, inclusive: true });
  }
  function y0(e, t) {
    return new pR({ check: "multiple_of", ...be(t), value: e });
  }
  function ex(e, t) {
    return new gR({ check: "max_length", ...be(t), maximum: e });
  }
  function tu(e, t) {
    return new vR({ check: "min_length", ...be(t), minimum: e });
  }
  function tx(e, t) {
    return new yR({ check: "length_equals", ...be(t), length: e });
  }
  function JM(e, t) {
    return new bR({ check: "string_format", format: "regex", ...be(t), pattern: e });
  }
  function WM(e) {
    return new wR({ check: "string_format", format: "lowercase", ...be(e) });
  }
  function eN(e) {
    return new SR({ check: "string_format", format: "uppercase", ...be(e) });
  }
  function tN(e, t) {
    return new xR({ check: "string_format", format: "includes", ...be(t), includes: e });
  }
  function nN(e, t) {
    return new _R({ check: "string_format", format: "starts_with", ...be(t), prefix: e });
  }
  function rN(e, t) {
    return new ER({ check: "string_format", format: "ends_with", ...be(t), suffix: e });
  }
  function Ei(e) {
    return new AR({ check: "overwrite", tx: e });
  }
  function oN(e) {
    return Ei((t) => t.normalize(e));
  }
  function aN() {
    return Ei((e) => e.trim());
  }
  function iN() {
    return Ei((e) => e.toLowerCase());
  }
  function sN() {
    return Ei((e) => e.toUpperCase());
  }
  function lN() {
    return Ei((e) => yO(e));
  }
  function cN(e, t, r) {
    return new e({ type: "array", element: t, ...be(r) });
  }
  function uN(e, t, r) {
    return new e({ type: "custom", check: "custom", fn: t, ...be(r) });
  }
  function fN(e) {
    const t = dN((r) => (r.addIssue = (a) => {
      var _a4, _b2, _c3, _d3;
      if (typeof a == "string") r.issues.push(Zs(a, r.value, t._zod.def));
      else {
        const s = a;
        s.fatal && (s.continue = false), (_a4 = s.code) != null ? _a4 : s.code = "custom", (_b2 = s.input) != null ? _b2 : s.input = r.value, (_c3 = s.inst) != null ? _c3 : s.inst = t, (_d3 = s.continue) != null ? _d3 : s.continue = !t._zod.def.abort, r.issues.push(Zs(s));
      }
    }, e(r.value, r)));
    return t;
  }
  function dN(e, t) {
    const r = new sn({ check: "custom", ...be(t) });
    return r._zod.check = e, r;
  }
  function nx(e) {
    var _a4, _b2, _c3, _d3, _e13, _f2, _g2, _h4, _i6;
    let t = (_a4 = e == null ? void 0 : e.target) != null ? _a4 : "draft-2020-12";
    return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), { processors: (_b2 = e.processors) != null ? _b2 : {}, metadataRegistry: (_c3 = e == null ? void 0 : e.metadata) != null ? _c3 : Ps, target: t, unrepresentable: (_d3 = e == null ? void 0 : e.unrepresentable) != null ? _d3 : "throw", override: (_e13 = e == null ? void 0 : e.override) != null ? _e13 : (() => {
    }), io: (_f2 = e == null ? void 0 : e.io) != null ? _f2 : "output", counter: 0, seen: /* @__PURE__ */ new Map(), cycles: (_g2 = e == null ? void 0 : e.cycles) != null ? _g2 : "ref", reused: (_h4 = e == null ? void 0 : e.reused) != null ? _h4 : "inline", external: (_i6 = e == null ? void 0 : e.external) != null ? _i6 : void 0 };
  }
  function jt(e, t, r = { path: [], schemaPath: [] }) {
    var _a4, _b2, _c3;
    var a;
    const s = e._zod.def, l = t.seen.get(e);
    if (l) return l.count++, r.schemaPath.includes(e) && (l.cycle = r.path), l.schema;
    const u = { schema: {}, count: 1, cycle: void 0, path: r.path };
    t.seen.set(e, u);
    const f = (_b2 = (_a4 = e._zod).toJSONSchema) == null ? void 0 : _b2.call(_a4);
    if (f) u.schema = f;
    else {
      const v = { ...r, schemaPath: [...r.schemaPath, e], path: r.path };
      if (e._zod.processJSONSchema) e._zod.processJSONSchema(t, u.schema, v);
      else {
        const S = u.schema, _ = t.processors[s.type];
        if (!_) throw new Error(`[toJSONSchema]: Non-representable type encountered: ${s.type}`);
        _(e, t, S, v);
      }
      const g = e._zod.parent;
      g && (u.ref || (u.ref = g), jt(g, t, v), t.seen.get(g).isParent = true);
    }
    const p = t.metadataRegistry.get(e);
    return p && Object.assign(u.schema, p), t.io === "input" && Zt(e) && (delete u.schema.examples, delete u.schema.default), t.io === "input" && u.schema._prefault && ((_c3 = (a = u.schema).default) != null ? _c3 : a.default = u.schema._prefault), delete u.schema._prefault, t.seen.get(e).schema;
  }
  function rx(e, t) {
    var _a4, _b2, _c3, _d3;
    const r = e.seen.get(t);
    if (!r) throw new Error("Unprocessed schema. This is a bug in Zod.");
    const a = /* @__PURE__ */ new Map();
    for (const u of e.seen.entries()) {
      const f = (_a4 = e.metadataRegistry.get(u[0])) == null ? void 0 : _a4.id;
      if (f) {
        const p = a.get(f);
        if (p && p !== u[0]) throw new Error(`Duplicate schema id "${f}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
        a.set(f, u[0]);
      }
    }
    const s = (u) => {
      var _a5, _b3, _c4, _d4, _e13;
      const f = e.target === "draft-2020-12" ? "$defs" : "definitions";
      if (e.external) {
        const g = (_a5 = e.external.registry.get(u[0])) == null ? void 0 : _a5.id, S = (_b3 = e.external.uri) != null ? _b3 : ((x) => x);
        if (g) return { ref: S(g) };
        const _ = (_d4 = (_c4 = u[1].defId) != null ? _c4 : u[1].schema.id) != null ? _d4 : `schema${e.counter++}`;
        return u[1].defId = _, { defId: _, ref: `${S("__shared")}#/${f}/${_}` };
      }
      if (u[1] === r) return { ref: "#" };
      const m = `#/${f}/`, v = (_e13 = u[1].schema.id) != null ? _e13 : `__schema${e.counter++}`;
      return { defId: v, ref: m + v };
    }, l = (u) => {
      if (u[1].schema.$ref) return;
      const f = u[1], { ref: p, defId: m } = s(u);
      f.def = { ...f.schema }, m && (f.defId = m);
      const v = f.schema;
      for (const g in v) delete v[g];
      v.$ref = p;
    };
    if (e.cycles === "throw") for (const u of e.seen.entries()) {
      const f = u[1];
      if (f.cycle) throw new Error(`Cycle detected: #/${(_b2 = f.cycle) == null ? void 0 : _b2.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
    for (const u of e.seen.entries()) {
      const f = u[1];
      if (t === u[0]) {
        l(u);
        continue;
      }
      if (e.external) {
        const m = (_c3 = e.external.registry.get(u[0])) == null ? void 0 : _c3.id;
        if (t !== u[0] && m) {
          l(u);
          continue;
        }
      }
      if ((_d3 = e.metadataRegistry.get(u[0])) == null ? void 0 : _d3.id) {
        l(u);
        continue;
      }
      if (f.cycle) {
        l(u);
        continue;
      }
      if (f.count > 1 && e.reused === "ref") {
        l(u);
        continue;
      }
    }
  }
  function ox(e, t) {
    var _a4, _b2, _c3, _d3, _e13;
    const r = e.seen.get(t);
    if (!r) throw new Error("Unprocessed schema. This is a bug in Zod.");
    const a = (u) => {
      var _a5, _b3, _c4;
      const f = e.seen.get(u);
      if (f.ref === null) return;
      const p = (_a5 = f.def) != null ? _a5 : f.schema, m = { ...p }, v = f.ref;
      if (f.ref = null, v) {
        a(v);
        const S = e.seen.get(v), _ = S.schema;
        if (_.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (p.allOf = (_b3 = p.allOf) != null ? _b3 : [], p.allOf.push(_)) : Object.assign(p, _), Object.assign(p, m), u._zod.parent === v) for (const E in p) E === "$ref" || E === "allOf" || E in m || delete p[E];
        if (_.$ref && S.def) for (const E in p) E === "$ref" || E === "allOf" || E in S.def && JSON.stringify(p[E]) === JSON.stringify(S.def[E]) && delete p[E];
      }
      const g = u._zod.parent;
      if (g && g !== v) {
        a(g);
        const S = e.seen.get(g);
        if ((S == null ? void 0 : S.schema.$ref) && (p.$ref = S.schema.$ref, S.def)) for (const _ in p) _ === "$ref" || _ === "allOf" || _ in S.def && JSON.stringify(p[_]) === JSON.stringify(S.def[_]) && delete p[_];
      }
      e.override({ zodSchema: u, jsonSchema: p, path: (_c4 = f.path) != null ? _c4 : [] });
    };
    for (const u of [...e.seen.entries()].reverse()) a(u[0]);
    const s = {};
    if (e.target === "draft-2020-12" ? s.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? s.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? s.$schema = "http://json-schema.org/draft-04/schema#" : e.target, (_a4 = e.external) == null ? void 0 : _a4.uri) {
      const u = (_b2 = e.external.registry.get(t)) == null ? void 0 : _b2.id;
      if (!u) throw new Error("Schema is missing an `id` property");
      s.$id = e.external.uri(u);
    }
    Object.assign(s, (_c3 = r.def) != null ? _c3 : r.schema);
    const l = (_e13 = (_d3 = e.external) == null ? void 0 : _d3.defs) != null ? _e13 : {};
    for (const u of e.seen.entries()) {
      const f = u[1];
      f.def && f.defId && (l[f.defId] = f.def);
    }
    e.external || Object.keys(l).length > 0 && (e.target === "draft-2020-12" ? s.$defs = l : s.definitions = l);
    try {
      const u = JSON.parse(JSON.stringify(s));
      return Object.defineProperty(u, "~standard", { value: { ...t["~standard"], jsonSchema: { input: nu(t, "input", e.processors), output: nu(t, "output", e.processors) } }, enumerable: false, writable: false }), u;
    } catch {
      throw new Error("Error converting schema to JSON.");
    }
  }
  function Zt(e, t) {
    const r = t != null ? t : { seen: /* @__PURE__ */ new Set() };
    if (r.seen.has(e)) return false;
    r.seen.add(e);
    const a = e._zod.def;
    if (a.type === "transform") return true;
    if (a.type === "array") return Zt(a.element, r);
    if (a.type === "set") return Zt(a.valueType, r);
    if (a.type === "lazy") return Zt(a.getter(), r);
    if (a.type === "promise" || a.type === "optional" || a.type === "nonoptional" || a.type === "nullable" || a.type === "readonly" || a.type === "default" || a.type === "prefault") return Zt(a.innerType, r);
    if (a.type === "intersection") return Zt(a.left, r) || Zt(a.right, r);
    if (a.type === "record" || a.type === "map") return Zt(a.keyType, r) || Zt(a.valueType, r);
    if (a.type === "pipe") return Zt(a.in, r) || Zt(a.out, r);
    if (a.type === "object") {
      for (const s in a.shape) if (Zt(a.shape[s], r)) return true;
      return false;
    }
    if (a.type === "union") {
      for (const s of a.options) if (Zt(s, r)) return true;
      return false;
    }
    if (a.type === "tuple") {
      for (const s of a.items) if (Zt(s, r)) return true;
      return !!(a.rest && Zt(a.rest, r));
    }
    return false;
  }
  const hN = (e, t = {}) => (r) => {
    const a = nx({ ...r, processors: t });
    return jt(e, a), rx(a, e), ox(a, e);
  }, nu = (e, t, r = {}) => (a) => {
    const { libraryOptions: s, target: l } = a != null ? a : {}, u = nx({ ...s != null ? s : {}, target: l, io: t, processors: r });
    return jt(e, u), rx(u, e), ox(u, e);
  }, pN = { guid: "uuid", url: "uri", datetime: "date-time", json_string: "json-string", regex: "" }, mN = (e, t, r, a) => {
    var _a4;
    const s = r;
    s.type = "string";
    const { minimum: l, maximum: u, format: f, patterns: p, contentEncoding: m } = e._zod.bag;
    if (typeof l == "number" && (s.minLength = l), typeof u == "number" && (s.maxLength = u), f && (s.format = (_a4 = pN[f]) != null ? _a4 : f, s.format === "" && delete s.format, f === "time" && delete s.format), m && (s.contentEncoding = m), p && p.size > 0) {
      const v = [...p];
      v.length === 1 ? s.pattern = v[0].source : v.length > 1 && (s.allOf = [...v.map((g) => ({ ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {}, pattern: g.source }))]);
    }
  }, gN = (e, t, r, a) => {
    const s = r, { minimum: l, maximum: u, format: f, multipleOf: p, exclusiveMaximum: m, exclusiveMinimum: v } = e._zod.bag;
    typeof f == "string" && f.includes("int") ? s.type = "integer" : s.type = "number", typeof v == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (s.minimum = v, s.exclusiveMinimum = true) : s.exclusiveMinimum = v), typeof l == "number" && (s.minimum = l, typeof v == "number" && t.target !== "draft-04" && (v >= l ? delete s.minimum : delete s.exclusiveMinimum)), typeof m == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (s.maximum = m, s.exclusiveMaximum = true) : s.exclusiveMaximum = m), typeof u == "number" && (s.maximum = u, typeof m == "number" && t.target !== "draft-04" && (m <= u ? delete s.maximum : delete s.exclusiveMaximum)), typeof p == "number" && (s.multipleOf = p);
  }, vN = (e, t, r, a) => {
    r.type = "boolean";
  }, yN = (e, t, r, a) => {
    r.not = {};
  }, bN = (e, t, r, a) => {
  }, wN = (e, t, r, a) => {
    const s = e._zod.def, l = PS(s.entries);
    l.every((u) => typeof u == "number") && (r.type = "number"), l.every((u) => typeof u == "string") && (r.type = "string"), r.enum = l;
  }, SN = (e, t, r, a) => {
    if (t.unrepresentable === "throw") throw new Error("Custom types cannot be represented in JSON Schema");
  }, xN = (e, t, r, a) => {
    if (t.unrepresentable === "throw") throw new Error("Transforms cannot be represented in JSON Schema");
  }, _N = (e, t, r, a) => {
    const s = r, l = e._zod.def, { minimum: u, maximum: f } = e._zod.bag;
    typeof u == "number" && (s.minItems = u), typeof f == "number" && (s.maxItems = f), s.type = "array", s.items = jt(l.element, t, { ...a, path: [...a.path, "items"] });
  }, EN = (e, t, r, a) => {
    var _a4;
    const s = r, l = e._zod.def;
    s.type = "object", s.properties = {};
    const u = l.shape;
    for (const m in u) s.properties[m] = jt(u[m], t, { ...a, path: [...a.path, "properties", m] });
    const f = new Set(Object.keys(u)), p = new Set([...f].filter((m) => {
      const v = l.shape[m]._zod;
      return t.io === "input" ? v.optin === void 0 : v.optout === void 0;
    }));
    p.size > 0 && (s.required = Array.from(p)), ((_a4 = l.catchall) == null ? void 0 : _a4._zod.def.type) === "never" ? s.additionalProperties = false : l.catchall ? l.catchall && (s.additionalProperties = jt(l.catchall, t, { ...a, path: [...a.path, "additionalProperties"] })) : t.io === "output" && (s.additionalProperties = false);
  }, AN = (e, t, r, a) => {
    const s = e._zod.def, l = s.inclusive === false, u = s.options.map((f, p) => jt(f, t, { ...a, path: [...a.path, l ? "oneOf" : "anyOf", p] }));
    l ? r.oneOf = u : r.anyOf = u;
  }, CN = (e, t, r, a) => {
    const s = e._zod.def, l = jt(s.left, t, { ...a, path: [...a.path, "allOf", 0] }), u = jt(s.right, t, { ...a, path: [...a.path, "allOf", 1] }), f = (m) => "allOf" in m && Object.keys(m).length === 1, p = [...f(l) ? l.allOf : [l], ...f(u) ? u.allOf : [u]];
    r.allOf = p;
  }, TN = (e, t, r, a) => {
    const s = e._zod.def, l = jt(s.innerType, t, a), u = t.seen.get(e);
    t.target === "openapi-3.0" ? (u.ref = s.innerType, r.nullable = true) : r.anyOf = [l, { type: "null" }];
  }, ON = (e, t, r, a) => {
    const s = e._zod.def;
    jt(s.innerType, t, a);
    const l = t.seen.get(e);
    l.ref = s.innerType;
  }, RN = (e, t, r, a) => {
    const s = e._zod.def;
    jt(s.innerType, t, a);
    const l = t.seen.get(e);
    l.ref = s.innerType, r.default = JSON.parse(JSON.stringify(s.defaultValue));
  }, MN = (e, t, r, a) => {
    const s = e._zod.def;
    jt(s.innerType, t, a);
    const l = t.seen.get(e);
    l.ref = s.innerType, t.io === "input" && (r._prefault = JSON.parse(JSON.stringify(s.defaultValue)));
  }, NN = (e, t, r, a) => {
    const s = e._zod.def;
    jt(s.innerType, t, a);
    const l = t.seen.get(e);
    l.ref = s.innerType;
    let u;
    try {
      u = s.catchValue(void 0);
    } catch {
      throw new Error("Dynamic catch values are not supported in JSON Schema");
    }
    r.default = u;
  }, zN = (e, t, r, a) => {
    const s = e._zod.def, l = t.io === "input" ? s.in._zod.def.type === "transform" ? s.out : s.in : s.out;
    jt(l, t, a);
    const u = t.seen.get(e);
    u.ref = l;
  }, DN = (e, t, r, a) => {
    const s = e._zod.def;
    jt(s.innerType, t, a);
    const l = t.seen.get(e);
    l.ref = s.innerType, r.readOnly = true;
  }, ax = (e, t, r, a) => {
    const s = e._zod.def;
    jt(s.innerType, t, a);
    const l = t.seen.get(e);
    l.ref = s.innerType;
  }, jN = te("ZodISODateTime", (e, t) => {
    BR.init(e, t), st.init(e, t);
  });
  function kN(e) {
    return VM(jN, e);
  }
  const PN = te("ZodISODate", (e, t) => {
    IR.init(e, t), st.init(e, t);
  });
  function LN(e) {
    return ZM(PN, e);
  }
  const UN = te("ZodISOTime", (e, t) => {
    HR.init(e, t), st.init(e, t);
  });
  function BN(e) {
    return FM(UN, e);
  }
  const IN = te("ZodISODuration", (e, t) => {
    $R.init(e, t), st.init(e, t);
  });
  function HN(e) {
    return qM(IN, e);
  }
  const $N = (e, t) => {
    HS.init(e, t), e.name = "ZodError", Object.defineProperties(e, { format: { value: (r) => NO(e, r) }, flatten: { value: (r) => MO(e, r) }, addIssue: { value: (r) => {
      e.issues.push(r), e.message = JSON.stringify(e.issues, np, 2);
    } }, addIssues: { value: (r) => {
      e.issues.push(...r), e.message = JSON.stringify(e.issues, np, 2);
    } }, isEmpty: { get() {
      return e.issues.length === 0;
    } } });
  }, zn = te("ZodError", $N, { Parent: Error }), VN = Gp(zn), ZN = Kp(zn), FN = Mu(zn), qN = Nu(zn), YN = jO(zn), XN = kO(zn), QN = PO(zn), GN = LO(zn), KN = UO(zn), JN = BO(zn), WN = IO(zn), ez = HO(zn), ht = te("ZodType", (e, t) => (dt.init(e, t), Object.assign(e["~standard"], { jsonSchema: { input: nu(e, "input"), output: nu(e, "output") } }), e.toJSONSchema = hN(e, {}), e.def = t, e.type = t.type, Object.defineProperty(e, "_def", { value: t }), e.check = (...r) => {
    var _a4;
    return e.clone(Mo(t, { checks: [...(_a4 = t.checks) != null ? _a4 : [], ...r.map((a) => typeof a == "function" ? { _zod: { check: a, def: { check: "custom" }, onattach: [] } } : a)] }), { parent: true });
  }, e.with = e.check, e.clone = (r, a) => No(e, r, a), e.brand = () => e, e.register = ((r, a) => (r.add(e, a), e)), e.parse = (r, a) => VN(e, r, a, { callee: e.parse }), e.safeParse = (r, a) => FN(e, r, a), e.parseAsync = async (r, a) => ZN(e, r, a, { callee: e.parseAsync }), e.safeParseAsync = async (r, a) => qN(e, r, a), e.spa = e.safeParseAsync, e.encode = (r, a) => YN(e, r, a), e.decode = (r, a) => XN(e, r, a), e.encodeAsync = async (r, a) => QN(e, r, a), e.decodeAsync = async (r, a) => GN(e, r, a), e.safeEncode = (r, a) => KN(e, r, a), e.safeDecode = (r, a) => JN(e, r, a), e.safeEncodeAsync = async (r, a) => WN(e, r, a), e.safeDecodeAsync = async (r, a) => ez(e, r, a), e.refine = (r, a) => e.check(Yz(r, a)), e.superRefine = (r) => e.check(Xz(r)), e.overwrite = (r) => e.check(Ei(r)), e.optional = () => _0(e), e.exactOptional = () => jz(e), e.nullable = () => E0(e), e.nullish = () => _0(E0(e)), e.nonoptional = (r) => Iz(e, r), e.array = () => op(e), e.or = (r) => Tz([e, r]), e.and = (r) => Rz(e, r), e.transform = (r) => A0(e, zz(r)), e.default = (r) => Lz(e, r), e.prefault = (r) => Bz(e, r), e.catch = (r) => $z(e, r), e.pipe = (r) => A0(e, r), e.readonly = () => Fz(e), e.describe = (r) => {
    const a = e.clone();
    return Ps.add(a, { description: r }), a;
  }, Object.defineProperty(e, "description", { get() {
    var _a4;
    return (_a4 = Ps.get(e)) == null ? void 0 : _a4.description;
  }, configurable: true }), e.meta = (...r) => {
    if (r.length === 0) return Ps.get(e);
    const a = e.clone();
    return Ps.add(a, r[0]), a;
  }, e.isOptional = () => e.safeParse(void 0).success, e.isNullable = () => e.safeParse(null).success, e.apply = (r) => r(e), e)), ix = te("_ZodString", (e, t) => {
    var _a4, _b2, _c3;
    Jp.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (a, s, l) => mN(e, a, s);
    const r = e._zod.bag;
    e.format = (_a4 = r.format) != null ? _a4 : null, e.minLength = (_b2 = r.minimum) != null ? _b2 : null, e.maxLength = (_c3 = r.maximum) != null ? _c3 : null, e.regex = (...a) => e.check(JM(...a)), e.includes = (...a) => e.check(tN(...a)), e.startsWith = (...a) => e.check(nN(...a)), e.endsWith = (...a) => e.check(rN(...a)), e.min = (...a) => e.check(tu(...a)), e.max = (...a) => e.check(ex(...a)), e.length = (...a) => e.check(tx(...a)), e.nonempty = (...a) => e.check(tu(1, ...a)), e.lowercase = (a) => e.check(WM(a)), e.uppercase = (a) => e.check(eN(a)), e.trim = () => e.check(aN()), e.normalize = (...a) => e.check(oN(...a)), e.toLowerCase = () => e.check(iN()), e.toUpperCase = () => e.check(sN()), e.slugify = () => e.check(lN());
  }), tz = te("ZodString", (e, t) => {
    Jp.init(e, t), ix.init(e, t), e.email = (r) => e.check(xM(nz, r)), e.url = (r) => e.check(TM(rz, r)), e.jwt = (r) => e.check($M(yz, r)), e.emoji = (r) => e.check(OM(oz, r)), e.guid = (r) => e.check(m0(b0, r)), e.uuid = (r) => e.check(_M(Rc, r)), e.uuidv4 = (r) => e.check(EM(Rc, r)), e.uuidv6 = (r) => e.check(AM(Rc, r)), e.uuidv7 = (r) => e.check(CM(Rc, r)), e.nanoid = (r) => e.check(RM(az, r)), e.guid = (r) => e.check(m0(b0, r)), e.cuid = (r) => e.check(MM(iz, r)), e.cuid2 = (r) => e.check(NM(sz, r)), e.ulid = (r) => e.check(zM(lz, r)), e.base64 = (r) => e.check(BM(mz, r)), e.base64url = (r) => e.check(IM(gz, r)), e.xid = (r) => e.check(DM(cz, r)), e.ksuid = (r) => e.check(jM(uz, r)), e.ipv4 = (r) => e.check(kM(fz, r)), e.ipv6 = (r) => e.check(PM(dz, r)), e.cidrv4 = (r) => e.check(LM(hz, r)), e.cidrv6 = (r) => e.check(UM(pz, r)), e.e164 = (r) => e.check(HM(vz, r)), e.datetime = (r) => e.check(kN(r)), e.date = (r) => e.check(LN(r)), e.time = (r) => e.check(BN(r)), e.duration = (r) => e.check(HN(r));
  });
  function wo(e) {
    return SM(tz, e);
  }
  const st = te("ZodStringFormat", (e, t) => {
    ot.init(e, t), ix.init(e, t);
  }), nz = te("ZodEmail", (e, t) => {
    MR.init(e, t), st.init(e, t);
  }), b0 = te("ZodGUID", (e, t) => {
    OR.init(e, t), st.init(e, t);
  }), Rc = te("ZodUUID", (e, t) => {
    RR.init(e, t), st.init(e, t);
  }), rz = te("ZodURL", (e, t) => {
    NR.init(e, t), st.init(e, t);
  }), oz = te("ZodEmoji", (e, t) => {
    zR.init(e, t), st.init(e, t);
  }), az = te("ZodNanoID", (e, t) => {
    DR.init(e, t), st.init(e, t);
  }), iz = te("ZodCUID", (e, t) => {
    jR.init(e, t), st.init(e, t);
  }), sz = te("ZodCUID2", (e, t) => {
    kR.init(e, t), st.init(e, t);
  }), lz = te("ZodULID", (e, t) => {
    PR.init(e, t), st.init(e, t);
  }), cz = te("ZodXID", (e, t) => {
    LR.init(e, t), st.init(e, t);
  }), uz = te("ZodKSUID", (e, t) => {
    UR.init(e, t), st.init(e, t);
  }), fz = te("ZodIPv4", (e, t) => {
    VR.init(e, t), st.init(e, t);
  }), dz = te("ZodIPv6", (e, t) => {
    ZR.init(e, t), st.init(e, t);
  }), hz = te("ZodCIDRv4", (e, t) => {
    FR.init(e, t), st.init(e, t);
  }), pz = te("ZodCIDRv6", (e, t) => {
    qR.init(e, t), st.init(e, t);
  }), mz = te("ZodBase64", (e, t) => {
    YR.init(e, t), st.init(e, t);
  }), gz = te("ZodBase64URL", (e, t) => {
    QR.init(e, t), st.init(e, t);
  }), vz = te("ZodE164", (e, t) => {
    GR.init(e, t), st.init(e, t);
  }), yz = te("ZodJWT", (e, t) => {
    JR.init(e, t), st.init(e, t);
  }), sx = te("ZodNumber", (e, t) => {
    var _a4, _b2, _c3, _d3, _e13, _f2, _g2, _h4, _i6;
    GS.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (a, s, l) => gN(e, a, s), e.gt = (a, s) => e.check(v0(a, s)), e.gte = (a, s) => e.check(_h(a, s)), e.min = (a, s) => e.check(_h(a, s)), e.lt = (a, s) => e.check(g0(a, s)), e.lte = (a, s) => e.check(xh(a, s)), e.max = (a, s) => e.check(xh(a, s)), e.int = (a) => e.check(w0(a)), e.safe = (a) => e.check(w0(a)), e.positive = (a) => e.check(v0(0, a)), e.nonnegative = (a) => e.check(_h(0, a)), e.negative = (a) => e.check(g0(0, a)), e.nonpositive = (a) => e.check(xh(0, a)), e.multipleOf = (a, s) => e.check(y0(a, s)), e.step = (a, s) => e.check(y0(a, s)), e.finite = () => e;
    const r = e._zod.bag;
    e.minValue = (_c3 = Math.max((_a4 = r.minimum) != null ? _a4 : Number.NEGATIVE_INFINITY, (_b2 = r.exclusiveMinimum) != null ? _b2 : Number.NEGATIVE_INFINITY)) != null ? _c3 : null, e.maxValue = (_f2 = Math.min((_d3 = r.maximum) != null ? _d3 : Number.POSITIVE_INFINITY, (_e13 = r.exclusiveMaximum) != null ? _e13 : Number.POSITIVE_INFINITY)) != null ? _f2 : null, e.isInt = ((_g2 = r.format) != null ? _g2 : "").includes("int") || Number.isSafeInteger((_h4 = r.multipleOf) != null ? _h4 : 0.5), e.isFinite = true, e.format = (_i6 = r.format) != null ? _i6 : null;
  });
  function Os(e) {
    return YM(sx, e);
  }
  const bz = te("ZodNumberFormat", (e, t) => {
    WR.init(e, t), sx.init(e, t);
  });
  function w0(e) {
    return XM(bz, e);
  }
  const wz = te("ZodBoolean", (e, t) => {
    eM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => vN(e, r, a);
  });
  function S0(e) {
    return QM(wz, e);
  }
  const Sz = te("ZodUnknown", (e, t) => {
    tM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => bN();
  });
  function x0() {
    return GM(Sz);
  }
  const xz = te("ZodNever", (e, t) => {
    nM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => yN(e, r, a);
  });
  function _z(e) {
    return KM(xz, e);
  }
  const Ez = te("ZodArray", (e, t) => {
    rM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => _N(e, r, a, s), e.element = t.element, e.min = (r, a) => e.check(tu(r, a)), e.nonempty = (r) => e.check(tu(1, r)), e.max = (r, a) => e.check(ex(r, a)), e.length = (r, a) => e.check(tx(r, a)), e.unwrap = () => e.element;
  });
  function op(e, t) {
    return cN(Ez, e, t);
  }
  const Az = te("ZodObject", (e, t) => {
    aM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => EN(e, r, a, s), Ye(e, "shape", () => t.shape), e.keyof = () => Mz(Object.keys(e._zod.def.shape)), e.catchall = (r) => e.clone({ ...e._zod.def, catchall: r }), e.passthrough = () => e.clone({ ...e._zod.def, catchall: x0() }), e.loose = () => e.clone({ ...e._zod.def, catchall: x0() }), e.strict = () => e.clone({ ...e._zod.def, catchall: _z() }), e.strip = () => e.clone({ ...e._zod.def, catchall: void 0 }), e.extend = (r) => AO(e, r), e.safeExtend = (r) => CO(e, r), e.merge = (r) => TO(e, r), e.pick = (r) => _O(e, r), e.omit = (r) => EO(e, r), e.partial = (...r) => OO(lx, e, r[0]), e.required = (...r) => RO(cx, e, r[0]);
  });
  function Eh(e, t) {
    const r = { type: "object", shape: e != null ? e : {}, ...be(t) };
    return new Az(r);
  }
  const Cz = te("ZodUnion", (e, t) => {
    iM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => AN(e, r, a, s), e.options = t.options;
  });
  function Tz(e, t) {
    return new Cz({ type: "union", options: e, ...be(t) });
  }
  const Oz = te("ZodIntersection", (e, t) => {
    sM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => CN(e, r, a, s);
  });
  function Rz(e, t) {
    return new Oz({ type: "intersection", left: e, right: t });
  }
  const ap = te("ZodEnum", (e, t) => {
    lM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (a, s, l) => wN(e, a, s), e.enum = t.entries, e.options = Object.values(t.entries);
    const r = new Set(Object.keys(t.entries));
    e.extract = (a, s) => {
      const l = {};
      for (const u of a) if (r.has(u)) l[u] = t.entries[u];
      else throw new Error(`Key ${u} not found in enum`);
      return new ap({ ...t, checks: [], ...be(s), entries: l });
    }, e.exclude = (a, s) => {
      const l = { ...t.entries };
      for (const u of a) if (r.has(u)) delete l[u];
      else throw new Error(`Key ${u} not found in enum`);
      return new ap({ ...t, checks: [], ...be(s), entries: l });
    };
  });
  function Mz(e, t) {
    const r = Array.isArray(e) ? Object.fromEntries(e.map((a) => [a, a])) : e;
    return new ap({ type: "enum", entries: r, ...be(t) });
  }
  const Nz = te("ZodTransform", (e, t) => {
    cM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => xN(e, r), e._zod.parse = (r, a) => {
      if (a.direction === "backward") throw new jS(e.constructor.name);
      r.addIssue = (l) => {
        var _a4, _b2, _c3;
        if (typeof l == "string") r.issues.push(Zs(l, r.value, t));
        else {
          const u = l;
          u.fatal && (u.continue = false), (_a4 = u.code) != null ? _a4 : u.code = "custom", (_b2 = u.input) != null ? _b2 : u.input = r.value, (_c3 = u.inst) != null ? _c3 : u.inst = e, r.issues.push(Zs(u));
        }
      };
      const s = t.transform(r.value, r);
      return s instanceof Promise ? s.then((l) => (r.value = l, r)) : (r.value = s, r);
    };
  });
  function zz(e) {
    return new Nz({ type: "transform", transform: e });
  }
  const lx = te("ZodOptional", (e, t) => {
    WS.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => ax(e, r, a, s), e.unwrap = () => e._zod.def.innerType;
  });
  function _0(e) {
    return new lx({ type: "optional", innerType: e });
  }
  const Dz = te("ZodExactOptional", (e, t) => {
    uM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => ax(e, r, a, s), e.unwrap = () => e._zod.def.innerType;
  });
  function jz(e) {
    return new Dz({ type: "optional", innerType: e });
  }
  const kz = te("ZodNullable", (e, t) => {
    fM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => TN(e, r, a, s), e.unwrap = () => e._zod.def.innerType;
  });
  function E0(e) {
    return new kz({ type: "nullable", innerType: e });
  }
  const Pz = te("ZodDefault", (e, t) => {
    dM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => RN(e, r, a, s), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
  });
  function Lz(e, t) {
    return new Pz({ type: "default", innerType: e, get defaultValue() {
      return typeof t == "function" ? t() : US(t);
    } });
  }
  const Uz = te("ZodPrefault", (e, t) => {
    hM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => MN(e, r, a, s), e.unwrap = () => e._zod.def.innerType;
  });
  function Bz(e, t) {
    return new Uz({ type: "prefault", innerType: e, get defaultValue() {
      return typeof t == "function" ? t() : US(t);
    } });
  }
  const cx = te("ZodNonOptional", (e, t) => {
    pM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => ON(e, r, a, s), e.unwrap = () => e._zod.def.innerType;
  });
  function Iz(e, t) {
    return new cx({ type: "nonoptional", innerType: e, ...be(t) });
  }
  const Hz = te("ZodCatch", (e, t) => {
    mM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => NN(e, r, a, s), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
  });
  function $z(e, t) {
    return new Hz({ type: "catch", innerType: e, catchValue: typeof t == "function" ? t : () => t });
  }
  const Vz = te("ZodPipe", (e, t) => {
    gM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => zN(e, r, a, s), e.in = t.in, e.out = t.out;
  });
  function A0(e, t) {
    return new Vz({ type: "pipe", in: e, out: t });
  }
  const Zz = te("ZodReadonly", (e, t) => {
    vM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => DN(e, r, a, s), e.unwrap = () => e._zod.def.innerType;
  });
  function Fz(e) {
    return new Zz({ type: "readonly", innerType: e });
  }
  const qz = te("ZodCustom", (e, t) => {
    yM.init(e, t), ht.init(e, t), e._zod.processJSONSchema = (r, a, s) => SN(e, r);
  });
  function Yz(e, t = {}) {
    return uN(qz, e, t);
  }
  function Xz(e) {
    return fN(e);
  }
  const Qz = "kzqU4XhfCaY6B6JTHODeq5", ux = localStorage.oauth ? "OAuth " + JSON.parse(localStorage.oauth).value : null;
  var hi = ((e) => (e.LOSSLESS = "lossless", e.NQ = "nq", e.LQ = "lq", e))(hi || {});
  const Wp = { "X-Yandex-Music-Client": "YandexMusicDesktopAppWindows/" + window.VERSION, "X-Yandex-Music-Frontend": "new", "X-Yandex-Music-Without-Invocation-Info": "1", Authorization: ux }, hr = rt.create({ baseURL: "https://api.music.yandex.net", headers: Wp, validateStatus: () => true });
  async function Gz(e) {
    try {
      const { secretKey: t, data: r } = e, a = new TextEncoder(), s = a.encode(t), l = await crypto.subtle.importKey("raw", s, { name: "HMAC", hash: { name: "SHA-256" } }, true, ["sign", "verify"]), u = a.encode(r), f = await crypto.subtle.sign("HMAC", l, u), p = btoa(String.fromCharCode(...new Uint8Array(f))).slice(0, -1);
      return it(p);
    } catch (t) {
      return Se(`Failed to generate HMAC signature: ${t}`);
    }
  }
  async function fx(e, t) {
    try {
      const r = Math.floor(Date.now() / 1e3), a = ["flac", "aac", "he-aac", "mp3", "flac-mp4", "aac-mp4", "he-aac-mp4"], s = "encraw", l = await Gz({ data: `${r}${e}${t}${a.join("")}${s}`, secretKey: Qz });
      if (l.isErr()) return Se(l.error);
      for (let u = 0; u < 10; u++) {
        const f = await hr.get(`/get-file-info?ts=${r}&trackId=${e}&quality=${t}&codecs=${encodeURIComponent(a.join(","))}&transports=${s}&sign=${encodeURIComponent(l.value)}`);
        if (f.status !== 200) return Se(`HTTP ${f.status}: ${f.statusText}`);
        if (f.data.downloadInfo.trackId !== e) {
          console.warn("[downloader] Track id mismatch :", f.data.downloadInfo.trackId, e), await new Promise((p) => setTimeout(p, 150));
          continue;
        }
        return it(f.data.downloadInfo);
      }
      return Se("Failed to get track URL: too many requests");
    } catch (r) {
      return Se(`Failed to get track URL: ${r}`);
    }
  }
  async function Kz(e) {
    var _a4;
    try {
      const t = await hr.get(`/albums/${e}/with-tracks?resumeStream=false&richTracks=false&withListeningFinished=false`);
      if (t.status !== 200) return Se(`HTTP ${t.status}: ${t.statusText}`);
      if (!((_a4 = t.data) == null ? void 0 : _a4.volumes)) return Se("Invalid response format: missing volumes");
      const r = t.data.volumes.flatMap((a) => a.map((s) => s.id));
      return it(r);
    } catch (t) {
      return Se(`Failed to get album tracks: ${t}`);
    }
  }
  async function dx(e) {
    var _a4;
    try {
      const t = await hr.get(`/playlist/${e}?resumeStream=false&richTracks=false`);
      if (t.status !== 200) return Se(`HTTP ${t.status}: ${t.statusText}`);
      if (!((_a4 = t.data) == null ? void 0 : _a4.tracks)) return Se("Invalid response format: missing tracks");
      const r = t.data.tracks.map((a) => a.id);
      return it(r);
    } catch (t) {
      return Se(`Failed to get playlist tracks: ${t}`);
    }
  }
  async function Jz(e) {
    try {
      const t = await hr.get(`/artists/${e}/track-ids?`);
      if (t.status !== 200) return Se(`HTTP ${t.status}: ${t.statusText}`);
      if (!t.data || !Array.isArray(t.data)) return Se("Invalid response format: missing tracks");
      const r = t.data;
      return it(r);
    } catch (t) {
      return Se(`Failed to get playlist tracks: ${t}`);
    }
  }
  async function hx(e, t = false) {
    try {
      const r = e.join(","), a = await hr.get(`/tracks?trackIds=${r}&removeDuplicates=false&withProgress=true`, { headers: { ...Wp, Authorization: t ? void 0 : ux } });
      return a.status !== 200 ? Se(`HTTP ${a.status}: ${a.statusText}`) : Array.isArray(a.data) ? it(a.data) : Se("Invalid response format: expected array");
    } catch (r) {
      return Se(`Failed to get tracks info: ${r}`);
    }
  }
  async function Wz(e, t) {
    try {
      const r = await hr.post(`/users/${e}/likes/tracks/add?trackId=${t}`, {}, { headers: { ...Wp, "Content-Type": "application/json" } });
      return r.status !== 200 && r.status !== 201 ? Se(`HTTP ${r.status}: ${r.statusText}`) : it(r.data);
    } catch (r) {
      return Se(`Failed to add track to likes: ${r}`);
    }
  }
  async function eD() {
    try {
      const e = await hr.get("/account/about");
      return e.status !== 200 ? Se(`HTTP ${e.status}: ${e.statusText}`) : e.data ? it(e.data) : Se("Invalid response format: missing data");
    } catch (e) {
      return Se(`Failed to get account info: ${e}`);
    }
  }
  async function tD() {
    try {
      const e = await hr.get("/landing-blocks/likes-and-history");
      return e.status !== 200 ? Se(`HTTP ${e.status}: ${e.statusText}`) : e.data ? it(e.data) : Se("Invalid response format: missing data");
    } catch (e) {
      return Se(`Failed to get likes and history: ${e}`);
    }
  }
  async function nD(e, t) {
    try {
      const r = await hr.post(`/account/settings?${e}=${t}`);
      return r.status !== 200 ? Se(`HTTP ${r.status}: ${r.statusText}`) : it(r.data);
    } catch (r) {
      return Se(`Failed to update account settings: ${r}`);
    }
  }
  async function rD() {
    try {
      const e = await hr.get("/account/experiments/details");
      return e.status !== 200 ? Se(`HTTP ${e.status}: ${e.statusText}`) : it(e.data);
    } catch (e) {
      return Se(`Failed to get account experiments: ${e}`);
    }
  }
  async function C0(e) {
    const t = "967Pn4)N3&R_GBg5$b('";
    try {
      const r = /* @__PURE__ */ new Date(), a = r.getFullYear().toString(), s = (r.getMonth() + 1).toString().padStart(2, "0"), l = r.getDate().toString().padStart(2, "0"), u = a[3] + s + l, f = e + u, p = new TextEncoder(), m = p.encode(t), v = p.encode(f), g = await crypto.subtle.importKey("raw", m, { name: "HMAC", hash: "SHA-1" }, false, ["sign"]), S = await crypto.subtle.sign("HMAC", g, v), _ = new Uint8Array(S), x = btoa(String.fromCharCode(..._)), E = encodeURIComponent(x), C = e.includes("?") ? "&" : "?";
      return it(`${e}${C}signature=${E}&signature_protocol=sha1`);
    } catch (r) {
      return Se(r);
    }
  }
  const oD = new Int32Array(4);
  let px = (_b = class {
    constructor() {
      __publicField(this, "_dataLength", 0);
      __publicField(this, "_bufferLength", 0);
      __publicField(this, "_state", new Int32Array(4));
      __publicField(this, "_buffer", new ArrayBuffer(68));
      __publicField(this, "_buffer8");
      __publicField(this, "_buffer32");
      this._buffer8 = new Uint8Array(this._buffer, 0, 68), this._buffer32 = new Uint32Array(this._buffer, 0, 17), this.start();
    }
    static hashStr(t, r = false) {
      return this.onePassHasher.start().appendStr(t).end(r);
    }
    static hashAsciiStr(t, r = false) {
      return this.onePassHasher.start().appendAsciiStr(t).end(r);
    }
    static _hex(t) {
      const r = _b.hexChars, a = _b.hexOut;
      let s, l, u, f;
      for (f = 0; f < 4; f += 1) for (l = f * 8, s = t[f], u = 0; u < 8; u += 2) a[l + 1 + u] = r.charAt(s & 15), s >>>= 4, a[l + 0 + u] = r.charAt(s & 15), s >>>= 4;
      return a.join("");
    }
    static _md5cycle(t, r) {
      let a = t[0], s = t[1], l = t[2], u = t[3];
      a += (s & l | ~s & u) + r[0] - 680876936 | 0, a = (a << 7 | a >>> 25) + s | 0, u += (a & s | ~a & l) + r[1] - 389564586 | 0, u = (u << 12 | u >>> 20) + a | 0, l += (u & a | ~u & s) + r[2] + 606105819 | 0, l = (l << 17 | l >>> 15) + u | 0, s += (l & u | ~l & a) + r[3] - 1044525330 | 0, s = (s << 22 | s >>> 10) + l | 0, a += (s & l | ~s & u) + r[4] - 176418897 | 0, a = (a << 7 | a >>> 25) + s | 0, u += (a & s | ~a & l) + r[5] + 1200080426 | 0, u = (u << 12 | u >>> 20) + a | 0, l += (u & a | ~u & s) + r[6] - 1473231341 | 0, l = (l << 17 | l >>> 15) + u | 0, s += (l & u | ~l & a) + r[7] - 45705983 | 0, s = (s << 22 | s >>> 10) + l | 0, a += (s & l | ~s & u) + r[8] + 1770035416 | 0, a = (a << 7 | a >>> 25) + s | 0, u += (a & s | ~a & l) + r[9] - 1958414417 | 0, u = (u << 12 | u >>> 20) + a | 0, l += (u & a | ~u & s) + r[10] - 42063 | 0, l = (l << 17 | l >>> 15) + u | 0, s += (l & u | ~l & a) + r[11] - 1990404162 | 0, s = (s << 22 | s >>> 10) + l | 0, a += (s & l | ~s & u) + r[12] + 1804603682 | 0, a = (a << 7 | a >>> 25) + s | 0, u += (a & s | ~a & l) + r[13] - 40341101 | 0, u = (u << 12 | u >>> 20) + a | 0, l += (u & a | ~u & s) + r[14] - 1502002290 | 0, l = (l << 17 | l >>> 15) + u | 0, s += (l & u | ~l & a) + r[15] + 1236535329 | 0, s = (s << 22 | s >>> 10) + l | 0, a += (s & u | l & ~u) + r[1] - 165796510 | 0, a = (a << 5 | a >>> 27) + s | 0, u += (a & l | s & ~l) + r[6] - 1069501632 | 0, u = (u << 9 | u >>> 23) + a | 0, l += (u & s | a & ~s) + r[11] + 643717713 | 0, l = (l << 14 | l >>> 18) + u | 0, s += (l & a | u & ~a) + r[0] - 373897302 | 0, s = (s << 20 | s >>> 12) + l | 0, a += (s & u | l & ~u) + r[5] - 701558691 | 0, a = (a << 5 | a >>> 27) + s | 0, u += (a & l | s & ~l) + r[10] + 38016083 | 0, u = (u << 9 | u >>> 23) + a | 0, l += (u & s | a & ~s) + r[15] - 660478335 | 0, l = (l << 14 | l >>> 18) + u | 0, s += (l & a | u & ~a) + r[4] - 405537848 | 0, s = (s << 20 | s >>> 12) + l | 0, a += (s & u | l & ~u) + r[9] + 568446438 | 0, a = (a << 5 | a >>> 27) + s | 0, u += (a & l | s & ~l) + r[14] - 1019803690 | 0, u = (u << 9 | u >>> 23) + a | 0, l += (u & s | a & ~s) + r[3] - 187363961 | 0, l = (l << 14 | l >>> 18) + u | 0, s += (l & a | u & ~a) + r[8] + 1163531501 | 0, s = (s << 20 | s >>> 12) + l | 0, a += (s & u | l & ~u) + r[13] - 1444681467 | 0, a = (a << 5 | a >>> 27) + s | 0, u += (a & l | s & ~l) + r[2] - 51403784 | 0, u = (u << 9 | u >>> 23) + a | 0, l += (u & s | a & ~s) + r[7] + 1735328473 | 0, l = (l << 14 | l >>> 18) + u | 0, s += (l & a | u & ~a) + r[12] - 1926607734 | 0, s = (s << 20 | s >>> 12) + l | 0, a += (s ^ l ^ u) + r[5] - 378558 | 0, a = (a << 4 | a >>> 28) + s | 0, u += (a ^ s ^ l) + r[8] - 2022574463 | 0, u = (u << 11 | u >>> 21) + a | 0, l += (u ^ a ^ s) + r[11] + 1839030562 | 0, l = (l << 16 | l >>> 16) + u | 0, s += (l ^ u ^ a) + r[14] - 35309556 | 0, s = (s << 23 | s >>> 9) + l | 0, a += (s ^ l ^ u) + r[1] - 1530992060 | 0, a = (a << 4 | a >>> 28) + s | 0, u += (a ^ s ^ l) + r[4] + 1272893353 | 0, u = (u << 11 | u >>> 21) + a | 0, l += (u ^ a ^ s) + r[7] - 155497632 | 0, l = (l << 16 | l >>> 16) + u | 0, s += (l ^ u ^ a) + r[10] - 1094730640 | 0, s = (s << 23 | s >>> 9) + l | 0, a += (s ^ l ^ u) + r[13] + 681279174 | 0, a = (a << 4 | a >>> 28) + s | 0, u += (a ^ s ^ l) + r[0] - 358537222 | 0, u = (u << 11 | u >>> 21) + a | 0, l += (u ^ a ^ s) + r[3] - 722521979 | 0, l = (l << 16 | l >>> 16) + u | 0, s += (l ^ u ^ a) + r[6] + 76029189 | 0, s = (s << 23 | s >>> 9) + l | 0, a += (s ^ l ^ u) + r[9] - 640364487 | 0, a = (a << 4 | a >>> 28) + s | 0, u += (a ^ s ^ l) + r[12] - 421815835 | 0, u = (u << 11 | u >>> 21) + a | 0, l += (u ^ a ^ s) + r[15] + 530742520 | 0, l = (l << 16 | l >>> 16) + u | 0, s += (l ^ u ^ a) + r[2] - 995338651 | 0, s = (s << 23 | s >>> 9) + l | 0, a += (l ^ (s | ~u)) + r[0] - 198630844 | 0, a = (a << 6 | a >>> 26) + s | 0, u += (s ^ (a | ~l)) + r[7] + 1126891415 | 0, u = (u << 10 | u >>> 22) + a | 0, l += (a ^ (u | ~s)) + r[14] - 1416354905 | 0, l = (l << 15 | l >>> 17) + u | 0, s += (u ^ (l | ~a)) + r[5] - 57434055 | 0, s = (s << 21 | s >>> 11) + l | 0, a += (l ^ (s | ~u)) + r[12] + 1700485571 | 0, a = (a << 6 | a >>> 26) + s | 0, u += (s ^ (a | ~l)) + r[3] - 1894986606 | 0, u = (u << 10 | u >>> 22) + a | 0, l += (a ^ (u | ~s)) + r[10] - 1051523 | 0, l = (l << 15 | l >>> 17) + u | 0, s += (u ^ (l | ~a)) + r[1] - 2054922799 | 0, s = (s << 21 | s >>> 11) + l | 0, a += (l ^ (s | ~u)) + r[8] + 1873313359 | 0, a = (a << 6 | a >>> 26) + s | 0, u += (s ^ (a | ~l)) + r[15] - 30611744 | 0, u = (u << 10 | u >>> 22) + a | 0, l += (a ^ (u | ~s)) + r[6] - 1560198380 | 0, l = (l << 15 | l >>> 17) + u | 0, s += (u ^ (l | ~a)) + r[13] + 1309151649 | 0, s = (s << 21 | s >>> 11) + l | 0, a += (l ^ (s | ~u)) + r[4] - 145523070 | 0, a = (a << 6 | a >>> 26) + s | 0, u += (s ^ (a | ~l)) + r[11] - 1120210379 | 0, u = (u << 10 | u >>> 22) + a | 0, l += (a ^ (u | ~s)) + r[2] + 718787259 | 0, l = (l << 15 | l >>> 17) + u | 0, s += (u ^ (l | ~a)) + r[9] - 343485551 | 0, s = (s << 21 | s >>> 11) + l | 0, t[0] = a + t[0] | 0, t[1] = s + t[1] | 0, t[2] = l + t[2] | 0, t[3] = u + t[3] | 0;
    }
    start() {
      return this._dataLength = 0, this._bufferLength = 0, this._state.set(_b.stateIdentity), this;
    }
    appendStr(t) {
      const r = this._buffer8, a = this._buffer32;
      let s = this._bufferLength, l, u;
      for (u = 0; u < t.length; u += 1) {
        if (l = t.charCodeAt(u), l < 128) r[s++] = l;
        else if (l < 2048) r[s++] = (l >>> 6) + 192, r[s++] = l & 63 | 128;
        else if (l < 55296 || l > 56319) r[s++] = (l >>> 12) + 224, r[s++] = l >>> 6 & 63 | 128, r[s++] = l & 63 | 128;
        else {
          if (l = (l - 55296) * 1024 + (t.charCodeAt(++u) - 56320) + 65536, l > 1114111) throw new Error("Unicode standard supports code points up to U+10FFFF");
          r[s++] = (l >>> 18) + 240, r[s++] = l >>> 12 & 63 | 128, r[s++] = l >>> 6 & 63 | 128, r[s++] = l & 63 | 128;
        }
        s >= 64 && (this._dataLength += 64, _b._md5cycle(this._state, a), s -= 64, a[0] = a[16]);
      }
      return this._bufferLength = s, this;
    }
    appendAsciiStr(t) {
      const r = this._buffer8, a = this._buffer32;
      let s = this._bufferLength, l, u = 0;
      for (; ; ) {
        for (l = Math.min(t.length - u, 64 - s); l--; ) r[s++] = t.charCodeAt(u++);
        if (s < 64) break;
        this._dataLength += 64, _b._md5cycle(this._state, a), s = 0;
      }
      return this._bufferLength = s, this;
    }
    appendByteArray(t) {
      const r = this._buffer8, a = this._buffer32;
      let s = this._bufferLength, l, u = 0;
      for (; ; ) {
        for (l = Math.min(t.length - u, 64 - s); l--; ) r[s++] = t[u++];
        if (s < 64) break;
        this._dataLength += 64, _b._md5cycle(this._state, a), s = 0;
      }
      return this._bufferLength = s, this;
    }
    getState() {
      const t = this._state;
      return { buffer: String.fromCharCode.apply(null, Array.from(this._buffer8)), buflen: this._bufferLength, length: this._dataLength, state: [t[0], t[1], t[2], t[3]] };
    }
    setState(t) {
      const r = t.buffer, a = t.state, s = this._state;
      let l;
      for (this._dataLength = t.length, this._bufferLength = t.buflen, s[0] = a[0], s[1] = a[1], s[2] = a[2], s[3] = a[3], l = 0; l < r.length; l += 1) this._buffer8[l] = r.charCodeAt(l);
    }
    end(t = false) {
      const r = this._bufferLength, a = this._buffer8, s = this._buffer32, l = (r >> 2) + 1;
      this._dataLength += r;
      const u = this._dataLength * 8;
      if (a[r] = 128, a[r + 1] = a[r + 2] = a[r + 3] = 0, s.set(_b.buffer32Identity.subarray(l), l), r > 55 && (_b._md5cycle(this._state, s), s.set(_b.buffer32Identity)), u <= 4294967295) s[14] = u;
      else {
        const f = u.toString(16).match(/(.*?)(.{0,8})$/);
        if (f === null) return t ? oD : "";
        const p = parseInt(f[2], 16), m = parseInt(f[1], 16) || 0;
        s[14] = p, s[15] = m;
      }
      return _b._md5cycle(this._state, s), t ? this._state : _b._hex(this._state);
    }
  }, __publicField(_b, "stateIdentity", new Int32Array([1732584193, -271733879, -1732584194, 271733878])), __publicField(_b, "buffer32Identity", new Int32Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])), __publicField(_b, "hexChars", "0123456789abcdef"), __publicField(_b, "hexOut", []), __publicField(_b, "onePassHasher", new _b()), _b);
  if (px.hashStr("hello") !== "5d41402abc4b2a76b9719d911017c592") throw new Error("Md5 self test failed.");
  const Ah = "https://apic.musixmatch.com/ws/1.1/", T0 = { app_id: "android-player-v1.0", country: "ru", format: "json" };
  class aD {
    constructor(t = {}) {
      __publicField(this, "client");
      __publicField(this, "usertoken");
      __publicField(this, "cookie");
      var _a4, _b2;
      this.usertoken = (_a4 = t.usertoken) != null ? _a4 : "250721b994519ea801e6582aeb61c797d5cecb501ed93b6c22e42d", this.cookie = (_b2 = t.cookie) != null ? _b2 : `x-mxm-token-guid=${Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join("")}; mxm-encrypted-token=; x-mxm-user-id=mxm:${px.hashStr(Math.random().toString())}`, this.client = rt.create({ baseURL: Ah, headers: { "Accept-Encoding": "gzip", "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_I005DA Build/PI)", "x-mxm-endpoint": "default" } });
    }
    async getAllMetaRequest(t, r, a) {
      try {
        const s = { ...T0, usertoken: this.usertoken, q_track: t, q_artist: r, tags: "scrobbling,notifications", f_subtitle_length_max_deviation: "1", subtitle_format: "dfxp", page_size: "1", optional_calls: "track.richsync,crowd.track.actions", scrobbling_package: "ru.yandex.music", language_iso_code: "1", part: "lyrics_crowd,user,lyrics_vote,lyrics_poll,track_lyrics_translation_status,lyrics_verified_by,labels,track_structure" };
        a !== void 0 && Object.assign(s, { f_subtitle_length: a.toString(), q_duration: a.toString() });
        const u = `macro.subtitles.get?${new URLSearchParams(s).toString()}`, f = await C0(u);
        if (f.isErr()) return Se(f.error.message);
        const p = { method: "GET", url: `${Ah}${f.value}`, headers: { "accept-encoding": "gzip", "x-mxm-endpoint": "background", Cookie: this.cookie } };
        return it(p);
      } catch (s) {
        return Se(s.message);
      }
    }
    async getAllMeta(t, r, a) {
      try {
        const s = { ...T0, usertoken: this.usertoken, q_track: t, q_artist: r, tags: "scrobbling,notifications", f_subtitle_length_max_deviation: "1", subtitle_format: "dfxp", page_size: "1", optional_calls: "track.richsync,crowd.track.actions", scrobbling_package: "ru.yandex.music", language_iso_code: "1", part: "lyrics_crowd,user,lyrics_vote,lyrics_poll,track_lyrics_translation_status,lyrics_verified_by,labels,track_structure" };
        a !== void 0 && Object.assign(s, { f_subtitle_length: a.toString(), q_duration: a.toString() });
        const u = `macro.subtitles.get?${new URLSearchParams(s).toString()}`, f = await C0(u);
        if (f.isErr()) return Se(f.error.message);
        const p = await rt.get(`${Ah}${f.value}`, { headers: { "accept-encoding": "gzip", Cookie: this.cookie } });
        return p.data.message.header.status_code !== 200 ? Se(p.data.message.body) : it(p.data.message.body);
      } catch (s) {
        return Se(s.message);
      }
    }
  }
  new aD();
  function em(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
  }
  var Ch = { exports: {} }, Ce = {};
  var O0;
  function iD() {
    if (O0) return Ce;
    O0 = 1;
    var e = /* @__PURE__ */ Symbol.for("react.transitional.element"), t = /* @__PURE__ */ Symbol.for("react.portal"), r = /* @__PURE__ */ Symbol.for("react.fragment"), a = /* @__PURE__ */ Symbol.for("react.strict_mode"), s = /* @__PURE__ */ Symbol.for("react.profiler"), l = /* @__PURE__ */ Symbol.for("react.consumer"), u = /* @__PURE__ */ Symbol.for("react.context"), f = /* @__PURE__ */ Symbol.for("react.forward_ref"), p = /* @__PURE__ */ Symbol.for("react.suspense"), m = /* @__PURE__ */ Symbol.for("react.memo"), v = /* @__PURE__ */ Symbol.for("react.lazy"), g = /* @__PURE__ */ Symbol.for("react.activity"), S = Symbol.iterator;
    function _(M) {
      return M === null || typeof M != "object" ? null : (M = S && M[S] || M["@@iterator"], typeof M == "function" ? M : null);
    }
    var x = { isMounted: function() {
      return false;
    }, enqueueForceUpdate: function() {
    }, enqueueReplaceState: function() {
    }, enqueueSetState: function() {
    } }, E = Object.assign, C = {};
    function T(M, F, X) {
      this.props = M, this.context = F, this.refs = C, this.updater = X || x;
    }
    T.prototype.isReactComponent = {}, T.prototype.setState = function(M, F) {
      if (typeof M != "object" && typeof M != "function" && M != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, M, F, "setState");
    }, T.prototype.forceUpdate = function(M) {
      this.updater.enqueueForceUpdate(this, M, "forceUpdate");
    };
    function R() {
    }
    R.prototype = T.prototype;
    function O(M, F, X) {
      this.props = M, this.context = F, this.refs = C, this.updater = X || x;
    }
    var D = O.prototype = new R();
    D.constructor = O, E(D, T.prototype), D.isPureReactComponent = true;
    var P = Array.isArray;
    function L() {
    }
    var k = { H: null, A: null, T: null, S: null }, $ = Object.prototype.hasOwnProperty;
    function re(M, F, X) {
      var J = X.ref;
      return { $$typeof: e, type: M, key: F, ref: J !== void 0 ? J : null, props: X };
    }
    function G(M, F) {
      return re(M.type, F, M.props);
    }
    function ae(M) {
      return typeof M == "object" && M !== null && M.$$typeof === e;
    }
    function se(M) {
      var F = { "=": "=0", ":": "=2" };
      return "$" + M.replace(/[=:]/g, function(X) {
        return F[X];
      });
    }
    var le = /\/+/g;
    function ue(M, F) {
      return typeof M == "object" && M !== null && M.key != null ? se("" + M.key) : F.toString(36);
    }
    function oe(M) {
      switch (M.status) {
        case "fulfilled":
          return M.value;
        case "rejected":
          throw M.reason;
        default:
          switch (typeof M.status == "string" ? M.then(L, L) : (M.status = "pending", M.then(function(F) {
            M.status === "pending" && (M.status = "fulfilled", M.value = F);
          }, function(F) {
            M.status === "pending" && (M.status = "rejected", M.reason = F);
          })), M.status) {
            case "fulfilled":
              return M.value;
            case "rejected":
              throw M.reason;
          }
      }
      throw M;
    }
    function N(M, F, X, J, ie) {
      var ge = typeof M;
      (ge === "undefined" || ge === "boolean") && (M = null);
      var ne = false;
      if (M === null) ne = true;
      else switch (ge) {
        case "bigint":
        case "string":
        case "number":
          ne = true;
          break;
        case "object":
          switch (M.$$typeof) {
            case e:
            case t:
              ne = true;
              break;
            case v:
              return ne = M._init, N(ne(M._payload), F, X, J, ie);
          }
      }
      if (ne) return ie = ie(M), ne = J === "" ? "." + ue(M, 0) : J, P(ie) ? (X = "", ne != null && (X = ne.replace(le, "$&/") + "/"), N(ie, F, X, "", function(Re) {
        return Re;
      })) : ie != null && (ae(ie) && (ie = G(ie, X + (ie.key == null || M && M.key === ie.key ? "" : ("" + ie.key).replace(le, "$&/") + "/") + ne)), F.push(ie)), 1;
      ne = 0;
      var fe = J === "" ? "." : J + ":";
      if (P(M)) for (var xe = 0; xe < M.length; xe++) J = M[xe], ge = fe + ue(J, xe), ne += N(J, F, X, ge, ie);
      else if (xe = _(M), typeof xe == "function") for (M = xe.call(M), xe = 0; !(J = M.next()).done; ) J = J.value, ge = fe + ue(J, xe++), ne += N(J, F, X, ge, ie);
      else if (ge === "object") {
        if (typeof M.then == "function") return N(oe(M), F, X, J, ie);
        throw F = String(M), Error("Objects are not valid as a React child (found: " + (F === "[object Object]" ? "object with keys {" + Object.keys(M).join(", ") + "}" : F) + "). If you meant to render a collection of children, use an array instead.");
      }
      return ne;
    }
    function Z(M, F, X) {
      if (M == null) return M;
      var J = [], ie = 0;
      return N(M, J, "", "", function(ge) {
        return F.call(X, ge, ie++);
      }), J;
    }
    function B(M) {
      if (M._status === -1) {
        var F = M._result;
        F = F(), F.then(function(X) {
          (M._status === 0 || M._status === -1) && (M._status = 1, M._result = X);
        }, function(X) {
          (M._status === 0 || M._status === -1) && (M._status = 2, M._result = X);
        }), M._status === -1 && (M._status = 0, M._result = F);
      }
      if (M._status === 1) return M._result.default;
      throw M._result;
    }
    var ce = typeof reportError == "function" ? reportError : function(M) {
      if (typeof window == "object" && typeof window.ErrorEvent == "function") {
        var F = new window.ErrorEvent("error", { bubbles: true, cancelable: true, message: typeof M == "object" && M !== null && typeof M.message == "string" ? String(M.message) : String(M), error: M });
        if (!window.dispatchEvent(F)) return;
      } else if (typeof process == "object" && typeof process.emit == "function") {
        process.emit("uncaughtException", M);
        return;
      }
      console.error(M);
    }, me = { map: Z, forEach: function(M, F, X) {
      Z(M, function() {
        F.apply(this, arguments);
      }, X);
    }, count: function(M) {
      var F = 0;
      return Z(M, function() {
        F++;
      }), F;
    }, toArray: function(M) {
      return Z(M, function(F) {
        return F;
      }) || [];
    }, only: function(M) {
      if (!ae(M)) throw Error("React.Children.only expected to receive a single React element child.");
      return M;
    } };
    return Ce.Activity = g, Ce.Children = me, Ce.Component = T, Ce.Fragment = r, Ce.Profiler = s, Ce.PureComponent = O, Ce.StrictMode = a, Ce.Suspense = p, Ce.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = k, Ce.__COMPILER_RUNTIME = { __proto__: null, c: function(M) {
      return k.H.useMemoCache(M);
    } }, Ce.cache = function(M) {
      return function() {
        return M.apply(null, arguments);
      };
    }, Ce.cacheSignal = function() {
      return null;
    }, Ce.cloneElement = function(M, F, X) {
      if (M == null) throw Error("The argument must be a React element, but you passed " + M + ".");
      var J = E({}, M.props), ie = M.key;
      if (F != null) for (ge in F.key !== void 0 && (ie = "" + F.key), F) !$.call(F, ge) || ge === "key" || ge === "__self" || ge === "__source" || ge === "ref" && F.ref === void 0 || (J[ge] = F[ge]);
      var ge = arguments.length - 2;
      if (ge === 1) J.children = X;
      else if (1 < ge) {
        for (var ne = Array(ge), fe = 0; fe < ge; fe++) ne[fe] = arguments[fe + 2];
        J.children = ne;
      }
      return re(M.type, ie, J);
    }, Ce.createContext = function(M) {
      return M = { $$typeof: u, _currentValue: M, _currentValue2: M, _threadCount: 0, Provider: null, Consumer: null }, M.Provider = M, M.Consumer = { $$typeof: l, _context: M }, M;
    }, Ce.createElement = function(M, F, X) {
      var J, ie = {}, ge = null;
      if (F != null) for (J in F.key !== void 0 && (ge = "" + F.key), F) $.call(F, J) && J !== "key" && J !== "__self" && J !== "__source" && (ie[J] = F[J]);
      var ne = arguments.length - 2;
      if (ne === 1) ie.children = X;
      else if (1 < ne) {
        for (var fe = Array(ne), xe = 0; xe < ne; xe++) fe[xe] = arguments[xe + 2];
        ie.children = fe;
      }
      if (M && M.defaultProps) for (J in ne = M.defaultProps, ne) ie[J] === void 0 && (ie[J] = ne[J]);
      return re(M, ge, ie);
    }, Ce.createRef = function() {
      return { current: null };
    }, Ce.forwardRef = function(M) {
      return { $$typeof: f, render: M };
    }, Ce.isValidElement = ae, Ce.lazy = function(M) {
      return { $$typeof: v, _payload: { _status: -1, _result: M }, _init: B };
    }, Ce.memo = function(M, F) {
      return { $$typeof: m, type: M, compare: F === void 0 ? null : F };
    }, Ce.startTransition = function(M) {
      var F = k.T, X = {};
      k.T = X;
      try {
        var J = M(), ie = k.S;
        ie !== null && ie(X, J), typeof J == "object" && J !== null && typeof J.then == "function" && J.then(L, ce);
      } catch (ge) {
        ce(ge);
      } finally {
        F !== null && X.types !== null && (F.types = X.types), k.T = F;
      }
    }, Ce.unstable_useCacheRefresh = function() {
      return k.H.useCacheRefresh();
    }, Ce.use = function(M) {
      return k.H.use(M);
    }, Ce.useActionState = function(M, F, X) {
      return k.H.useActionState(M, F, X);
    }, Ce.useCallback = function(M, F) {
      return k.H.useCallback(M, F);
    }, Ce.useContext = function(M) {
      return k.H.useContext(M);
    }, Ce.useDebugValue = function() {
    }, Ce.useDeferredValue = function(M, F) {
      return k.H.useDeferredValue(M, F);
    }, Ce.useEffect = function(M, F) {
      return k.H.useEffect(M, F);
    }, Ce.useEffectEvent = function(M) {
      return k.H.useEffectEvent(M);
    }, Ce.useId = function() {
      return k.H.useId();
    }, Ce.useImperativeHandle = function(M, F, X) {
      return k.H.useImperativeHandle(M, F, X);
    }, Ce.useInsertionEffect = function(M, F) {
      return k.H.useInsertionEffect(M, F);
    }, Ce.useLayoutEffect = function(M, F) {
      return k.H.useLayoutEffect(M, F);
    }, Ce.useMemo = function(M, F) {
      return k.H.useMemo(M, F);
    }, Ce.useOptimistic = function(M, F) {
      return k.H.useOptimistic(M, F);
    }, Ce.useReducer = function(M, F, X) {
      return k.H.useReducer(M, F, X);
    }, Ce.useRef = function(M) {
      return k.H.useRef(M);
    }, Ce.useState = function(M) {
      return k.H.useState(M);
    }, Ce.useSyncExternalStore = function(M, F, X) {
      return k.H.useSyncExternalStore(M, F, X);
    }, Ce.useTransition = function() {
      return k.H.useTransition();
    }, Ce.version = "19.2.4", Ce;
  }
  var R0;
  function tm() {
    return R0 || (R0 = 1, Ch.exports = iD()), Ch.exports;
  }
  var y = tm();
  const W = em(y), nm = jT({ __proto__: null, default: W }, [y]);
  var Th = { exports: {} }, Lt = {};
  var M0;
  function sD() {
    if (M0) return Lt;
    M0 = 1;
    var e = tm();
    function t(p) {
      var m = "https://react.dev/errors/" + p;
      if (1 < arguments.length) {
        m += "?args[]=" + encodeURIComponent(arguments[1]);
        for (var v = 2; v < arguments.length; v++) m += "&args[]=" + encodeURIComponent(arguments[v]);
      }
      return "Minified React error #" + p + "; visit " + m + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    function r() {
    }
    var a = { d: { f: r, r: function() {
      throw Error(t(522));
    }, D: r, C: r, L: r, m: r, X: r, S: r, M: r }, p: 0, findDOMNode: null }, s = /* @__PURE__ */ Symbol.for("react.portal");
    function l(p, m, v) {
      var g = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
      return { $$typeof: s, key: g == null ? null : "" + g, children: p, containerInfo: m, implementation: v };
    }
    var u = e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
    function f(p, m) {
      if (p === "font") return "";
      if (typeof m == "string") return m === "use-credentials" ? m : "";
    }
    return Lt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = a, Lt.createPortal = function(p, m) {
      var v = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!m || m.nodeType !== 1 && m.nodeType !== 9 && m.nodeType !== 11) throw Error(t(299));
      return l(p, m, null, v);
    }, Lt.flushSync = function(p) {
      var m = u.T, v = a.p;
      try {
        if (u.T = null, a.p = 2, p) return p();
      } finally {
        u.T = m, a.p = v, a.d.f();
      }
    }, Lt.preconnect = function(p, m) {
      typeof p == "string" && (m ? (m = m.crossOrigin, m = typeof m == "string" ? m === "use-credentials" ? m : "" : void 0) : m = null, a.d.C(p, m));
    }, Lt.prefetchDNS = function(p) {
      typeof p == "string" && a.d.D(p);
    }, Lt.preinit = function(p, m) {
      if (typeof p == "string" && m && typeof m.as == "string") {
        var v = m.as, g = f(v, m.crossOrigin), S = typeof m.integrity == "string" ? m.integrity : void 0, _ = typeof m.fetchPriority == "string" ? m.fetchPriority : void 0;
        v === "style" ? a.d.S(p, typeof m.precedence == "string" ? m.precedence : void 0, { crossOrigin: g, integrity: S, fetchPriority: _ }) : v === "script" && a.d.X(p, { crossOrigin: g, integrity: S, fetchPriority: _, nonce: typeof m.nonce == "string" ? m.nonce : void 0 });
      }
    }, Lt.preinitModule = function(p, m) {
      if (typeof p == "string") if (typeof m == "object" && m !== null) {
        if (m.as == null || m.as === "script") {
          var v = f(m.as, m.crossOrigin);
          a.d.M(p, { crossOrigin: v, integrity: typeof m.integrity == "string" ? m.integrity : void 0, nonce: typeof m.nonce == "string" ? m.nonce : void 0 });
        }
      } else m == null && a.d.M(p);
    }, Lt.preload = function(p, m) {
      if (typeof p == "string" && typeof m == "object" && m !== null && typeof m.as == "string") {
        var v = m.as, g = f(v, m.crossOrigin);
        a.d.L(p, v, { crossOrigin: g, integrity: typeof m.integrity == "string" ? m.integrity : void 0, nonce: typeof m.nonce == "string" ? m.nonce : void 0, type: typeof m.type == "string" ? m.type : void 0, fetchPriority: typeof m.fetchPriority == "string" ? m.fetchPriority : void 0, referrerPolicy: typeof m.referrerPolicy == "string" ? m.referrerPolicy : void 0, imageSrcSet: typeof m.imageSrcSet == "string" ? m.imageSrcSet : void 0, imageSizes: typeof m.imageSizes == "string" ? m.imageSizes : void 0, media: typeof m.media == "string" ? m.media : void 0 });
      }
    }, Lt.preloadModule = function(p, m) {
      if (typeof p == "string") if (m) {
        var v = f(m.as, m.crossOrigin);
        a.d.m(p, { as: typeof m.as == "string" && m.as !== "script" ? m.as : void 0, crossOrigin: v, integrity: typeof m.integrity == "string" ? m.integrity : void 0 });
      } else a.d.m(p);
    }, Lt.requestFormReset = function(p) {
      a.d.r(p);
    }, Lt.unstable_batchedUpdates = function(p, m) {
      return p(m);
    }, Lt.useFormState = function(p, m, v) {
      return u.H.useFormState(p, m, v);
    }, Lt.useFormStatus = function() {
      return u.H.useHostTransitionStatus();
    }, Lt.version = "19.2.4", Lt;
  }
  var N0;
  function mx() {
    if (N0) return Th.exports;
    N0 = 1;
    function e() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e);
      } catch (t) {
        console.error(t);
      }
    }
    return e(), Th.exports = sD(), Th.exports;
  }
  var Ai = mx();
  const gx = em(Ai);
  function lD(e) {
    if (typeof document > "u") return;
    let t = document.head || document.getElementsByTagName("head")[0], r = document.createElement("style");
    r.type = "text/css", t.appendChild(r), r.styleSheet ? r.styleSheet.cssText = e : r.appendChild(document.createTextNode(e));
  }
  const cD = (e) => {
    switch (e) {
      case "success":
        return dD;
      case "info":
        return pD;
      case "warning":
        return hD;
      case "error":
        return mD;
      default:
        return null;
    }
  }, uD = Array(12).fill(0), fD = ({ visible: e, className: t }) => W.createElement("div", { className: ["sonner-loading-wrapper", t].filter(Boolean).join(" "), "data-visible": e }, W.createElement("div", { className: "sonner-spinner" }, uD.map((r, a) => W.createElement("div", { className: "sonner-loading-bar", key: `spinner-bar-${a}` })))), dD = W.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 20 20", fill: "currentColor", height: "20", width: "20" }, W.createElement("path", { fillRule: "evenodd", d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z", clipRule: "evenodd" })), hD = W.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 24 24", fill: "currentColor", height: "20", width: "20" }, W.createElement("path", { fillRule: "evenodd", d: "M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z", clipRule: "evenodd" })), pD = W.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 20 20", fill: "currentColor", height: "20", width: "20" }, W.createElement("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z", clipRule: "evenodd" })), mD = W.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 20 20", fill: "currentColor", height: "20", width: "20" }, W.createElement("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z", clipRule: "evenodd" })), gD = W.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "12", height: "12", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" }, W.createElement("line", { x1: "18", y1: "6", x2: "6", y2: "18" }), W.createElement("line", { x1: "6", y1: "6", x2: "18", y2: "18" })), vD = () => {
    const [e, t] = W.useState(document.hidden);
    return W.useEffect(() => {
      const r = () => {
        t(document.hidden);
      };
      return document.addEventListener("visibilitychange", r), () => window.removeEventListener("visibilitychange", r);
    }, []), e;
  };
  let ip = 1;
  class yD {
    constructor() {
      this.subscribe = (t) => (this.subscribers.push(t), () => {
        const r = this.subscribers.indexOf(t);
        this.subscribers.splice(r, 1);
      }), this.publish = (t) => {
        this.subscribers.forEach((r) => r(t));
      }, this.addToast = (t) => {
        this.publish(t), this.toasts = [...this.toasts, t];
      }, this.create = (t) => {
        var r;
        const { message: a, ...s } = t, l = typeof (t == null ? void 0 : t.id) == "number" || ((r = t.id) == null ? void 0 : r.length) > 0 ? t.id : ip++, u = this.toasts.find((p) => p.id === l), f = t.dismissible === void 0 ? true : t.dismissible;
        return this.dismissedToasts.has(l) && this.dismissedToasts.delete(l), u ? this.toasts = this.toasts.map((p) => p.id === l ? (this.publish({ ...p, ...t, id: l, title: a }), { ...p, ...t, id: l, dismissible: f, title: a }) : p) : this.addToast({ title: a, ...s, dismissible: f, id: l }), l;
      }, this.dismiss = (t) => (t ? (this.dismissedToasts.add(t), requestAnimationFrame(() => this.subscribers.forEach((r) => r({ id: t, dismiss: true })))) : this.toasts.forEach((r) => {
        this.subscribers.forEach((a) => a({ id: r.id, dismiss: true }));
      }), t), this.message = (t, r) => this.create({ ...r, message: t }), this.error = (t, r) => this.create({ ...r, message: t, type: "error" }), this.success = (t, r) => this.create({ ...r, type: "success", message: t }), this.info = (t, r) => this.create({ ...r, type: "info", message: t }), this.warning = (t, r) => this.create({ ...r, type: "warning", message: t }), this.loading = (t, r) => this.create({ ...r, type: "loading", message: t }), this.promise = (t, r) => {
        if (!r) return;
        let a;
        r.loading !== void 0 && (a = this.create({ ...r, promise: t, type: "loading", message: r.loading, description: typeof r.description != "function" ? r.description : void 0 }));
        const s = Promise.resolve(t instanceof Function ? t() : t);
        let l = a !== void 0, u;
        const f = s.then(async (m) => {
          if (u = ["resolve", m], W.isValidElement(m)) l = false, this.create({ id: a, type: "default", message: m });
          else if (wD(m) && !m.ok) {
            l = false;
            const g = typeof r.error == "function" ? await r.error(`HTTP error! status: ${m.status}`) : r.error, S = typeof r.description == "function" ? await r.description(`HTTP error! status: ${m.status}`) : r.description, x = typeof g == "object" && !W.isValidElement(g) ? g : { message: g };
            this.create({ id: a, type: "error", description: S, ...x });
          } else if (m instanceof Error) {
            l = false;
            const g = typeof r.error == "function" ? await r.error(m) : r.error, S = typeof r.description == "function" ? await r.description(m) : r.description, x = typeof g == "object" && !W.isValidElement(g) ? g : { message: g };
            this.create({ id: a, type: "error", description: S, ...x });
          } else if (r.success !== void 0) {
            l = false;
            const g = typeof r.success == "function" ? await r.success(m) : r.success, S = typeof r.description == "function" ? await r.description(m) : r.description, x = typeof g == "object" && !W.isValidElement(g) ? g : { message: g };
            this.create({ id: a, type: "success", description: S, ...x });
          }
        }).catch(async (m) => {
          if (u = ["reject", m], r.error !== void 0) {
            l = false;
            const v = typeof r.error == "function" ? await r.error(m) : r.error, g = typeof r.description == "function" ? await r.description(m) : r.description, _ = typeof v == "object" && !W.isValidElement(v) ? v : { message: v };
            this.create({ id: a, type: "error", description: g, ..._ });
          }
        }).finally(() => {
          l && (this.dismiss(a), a = void 0), r.finally == null || r.finally.call(r);
        }), p = () => new Promise((m, v) => f.then(() => u[0] === "reject" ? v(u[1]) : m(u[1])).catch(v));
        return typeof a != "string" && typeof a != "number" ? { unwrap: p } : Object.assign(a, { unwrap: p });
      }, this.custom = (t, r) => {
        const a = (r == null ? void 0 : r.id) || ip++;
        return this.create({ jsx: t(a), id: a, ...r }), a;
      }, this.getActiveToasts = () => this.toasts.filter((t) => !this.dismissedToasts.has(t.id)), this.subscribers = [], this.toasts = [], this.dismissedToasts = /* @__PURE__ */ new Set();
    }
  }
  const tn = new yD(), bD = (e, t) => {
    const r = (t == null ? void 0 : t.id) || ip++;
    return tn.addToast({ title: e, ...t, id: r }), r;
  }, wD = (e) => e && typeof e == "object" && "ok" in e && typeof e.ok == "boolean" && "status" in e && typeof e.status == "number", SD = bD, xD = () => tn.toasts, _D = () => tn.getActiveToasts(), Ve = Object.assign(SD, { success: tn.success, info: tn.info, warning: tn.warning, error: tn.error, custom: tn.custom, message: tn.message, promise: tn.promise, dismiss: tn.dismiss, loading: tn.loading }, { getHistory: xD, getToasts: _D });
  lD("[data-sonner-toaster][dir=ltr],html[dir=ltr]{--toast-icon-margin-start:-3px;--toast-icon-margin-end:4px;--toast-svg-margin-start:-1px;--toast-svg-margin-end:0px;--toast-button-margin-start:auto;--toast-button-margin-end:0;--toast-close-button-start:0;--toast-close-button-end:unset;--toast-close-button-transform:translate(-35%, -35%)}[data-sonner-toaster][dir=rtl],html[dir=rtl]{--toast-icon-margin-start:4px;--toast-icon-margin-end:-3px;--toast-svg-margin-start:0px;--toast-svg-margin-end:-1px;--toast-button-margin-start:0;--toast-button-margin-end:auto;--toast-close-button-start:unset;--toast-close-button-end:0;--toast-close-button-transform:translate(35%, -35%)}[data-sonner-toaster]{position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1:hsl(0, 0%, 99%);--gray2:hsl(0, 0%, 97.3%);--gray3:hsl(0, 0%, 95.1%);--gray4:hsl(0, 0%, 93%);--gray5:hsl(0, 0%, 90.9%);--gray6:hsl(0, 0%, 88.7%);--gray7:hsl(0, 0%, 85.8%);--gray8:hsl(0, 0%, 78%);--gray9:hsl(0, 0%, 56.1%);--gray10:hsl(0, 0%, 52.3%);--gray11:hsl(0, 0%, 43.5%);--gray12:hsl(0, 0%, 9%);--border-radius:8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:0;z-index:999999999;transition:transform .4s ease}@media (hover:none) and (pointer:coarse){[data-sonner-toaster][data-lifted=true]{transform:none}}[data-sonner-toaster][data-x-position=right]{right:var(--offset-right)}[data-sonner-toaster][data-x-position=left]{left:var(--offset-left)}[data-sonner-toaster][data-x-position=center]{left:50%;transform:translateX(-50%)}[data-sonner-toaster][data-y-position=top]{top:var(--offset-top)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--offset-bottom)}[data-sonner-toast]{--y:translateY(100%);--lift-amount:calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:0;overflow-wrap:anywhere}[data-sonner-toast][data-styled=true]{padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px rgba(0,0,0,.1);width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}[data-sonner-toast]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-y-position=top]{top:0;--y:translateY(-100%);--lift:1;--lift-amount:calc(1 * var(--gap))}[data-sonner-toast][data-y-position=bottom]{bottom:0;--y:translateY(100%);--lift:-1;--lift-amount:calc(var(--lift) * var(--gap))}[data-sonner-toast][data-styled=true] [data-description]{font-weight:400;line-height:1.4;color:#3f3f3f}[data-rich-colors=true][data-sonner-toast][data-styled=true] [data-description]{color:inherit}[data-sonner-toaster][data-sonner-theme=dark] [data-description]{color:#e8e8e8}[data-sonner-toast][data-styled=true] [data-title]{font-weight:500;line-height:1.5;color:inherit}[data-sonner-toast][data-styled=true] [data-icon]{display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}[data-sonner-toast][data-promise=true] [data-icon]>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}[data-sonner-toast][data-styled=true] [data-icon]>*{flex-shrink:0}[data-sonner-toast][data-styled=true] [data-icon] svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}[data-sonner-toast][data-styled=true] [data-content]{display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;font-weight:500;cursor:pointer;outline:0;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}[data-sonner-toast][data-styled=true] [data-button]:focus-visible{box-shadow:0 0 0 2px rgba(0,0,0,.4)}[data-sonner-toast][data-styled=true] [data-button]:first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}[data-sonner-toast][data-styled=true] [data-cancel]{color:var(--normal-text);background:rgba(0,0,0,.08)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-styled=true] [data-cancel]{background:rgba(255,255,255,.3)}[data-sonner-toast][data-styled=true] [data-close-button]{position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);background:var(--normal-bg);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast][data-styled=true] [data-close-button]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-styled=true] [data-disabled=true]{cursor:not-allowed}[data-sonner-toast][data-styled=true]:hover [data-close-button]:hover{background:var(--gray2);border-color:var(--gray5)}[data-sonner-toast][data-swiping=true]::before{content:'';position:absolute;left:-100%;right:-100%;height:100%;z-index:-1}[data-sonner-toast][data-y-position=top][data-swiping=true]::before{bottom:50%;transform:scaleY(3) translateY(50%)}[data-sonner-toast][data-y-position=bottom][data-swiping=true]::before{top:50%;transform:scaleY(3) translateY(-50%)}[data-sonner-toast][data-swiping=false][data-removed=true]::before{content:'';position:absolute;inset:0;transform:scaleY(2)}[data-sonner-toast][data-expanded=true]::after{content:'';position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}[data-sonner-toast][data-mounted=true]{--y:translateY(0);opacity:1}[data-sonner-toast][data-expanded=false][data-front=false]{--scale:var(--toasts-before) * 0.05 + 1;--y:translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}[data-sonner-toast]>*{transition:opacity .4s}[data-sonner-toast][data-x-position=right]{right:0}[data-sonner-toast][data-x-position=left]{left:0}[data-sonner-toast][data-expanded=false][data-front=false][data-styled=true]>*{opacity:0}[data-sonner-toast][data-visible=false]{opacity:0;pointer-events:none}[data-sonner-toast][data-mounted=true][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}[data-sonner-toast][data-removed=true][data-front=true][data-swipe-out=false]{--y:translateY(calc(var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=false]{--y:translateY(40%);opacity:0;transition:transform .5s,opacity .2s}[data-sonner-toast][data-removed=true][data-front=false]::before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y,0)) translateX(var(--swipe-amount-x,0));transition:none}[data-sonner-toast][data-swiped=true]{user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width:600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-sonner-theme=light]{--normal-bg:#fff;--normal-border:var(--gray4);--normal-text:var(--gray12);--success-bg:hsl(143, 85%, 96%);--success-border:hsl(145, 92%, 87%);--success-text:hsl(140, 100%, 27%);--info-bg:hsl(208, 100%, 97%);--info-border:hsl(221, 91%, 93%);--info-text:hsl(210, 92%, 45%);--warning-bg:hsl(49, 100%, 97%);--warning-border:hsl(49, 91%, 84%);--warning-text:hsl(31, 92%, 45%);--error-bg:hsl(359, 100%, 97%);--error-border:hsl(359, 100%, 94%);--error-text:hsl(360, 100%, 45%)}[data-sonner-toaster][data-sonner-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg:#000;--normal-border:hsl(0, 0%, 20%);--normal-text:var(--gray1)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg:#fff;--normal-border:var(--gray3);--normal-text:var(--gray12)}[data-sonner-toaster][data-sonner-theme=dark]{--normal-bg:#000;--normal-bg-hover:hsl(0, 0%, 12%);--normal-border:hsl(0, 0%, 20%);--normal-border-hover:hsl(0, 0%, 25%);--normal-text:var(--gray1);--success-bg:hsl(150, 100%, 6%);--success-border:hsl(147, 100%, 12%);--success-text:hsl(150, 86%, 65%);--info-bg:hsl(215, 100%, 6%);--info-border:hsl(223, 43%, 17%);--info-text:hsl(216, 87%, 65%);--warning-bg:hsl(64, 100%, 6%);--warning-border:hsl(60, 100%, 9%);--warning-text:hsl(46, 87%, 65%);--error-bg:hsl(358, 76%, 10%);--error-border:hsl(357, 89%, 16%);--error-text:hsl(358, 100%, 81%)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size:16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:first-child{animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}100%{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}100%{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}100%{opacity:.15}}@media (prefers-reduced-motion){.sonner-loading-bar,[data-sonner-toast],[data-sonner-toast]>*{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}");
  function Mc(e) {
    return e.label !== void 0;
  }
  const ED = 3, AD = "24px", CD = "16px", z0 = 4e3, TD = 356, OD = 14, RD = 45, MD = 200;
  function nr(...e) {
    return e.filter(Boolean).join(" ");
  }
  function ND(e) {
    const [t, r] = e.split("-"), a = [];
    return t && a.push(t), r && a.push(r), a;
  }
  const zD = (e) => {
    var t, r, a, s, l, u, f, p, m;
    const { invert: v, toast: g, unstyled: S, interacting: _, setHeights: x, visibleToasts: E, heights: C, index: T, toasts: R, expanded: O, removeToast: D, defaultRichColors: P, closeButton: L, style: k, cancelButtonStyle: $, actionButtonStyle: re, className: G = "", descriptionClassName: ae = "", duration: se, position: le, gap: ue, expandByDefault: oe, classNames: N, icons: Z, closeButtonAriaLabel: B = "Close toast" } = e, [ce, me] = W.useState(null), [M, F] = W.useState(null), [X, J] = W.useState(false), [ie, ge] = W.useState(false), [ne, fe] = W.useState(false), [xe, Re] = W.useState(false), [De, Le] = W.useState(false), [Ct, yt] = W.useState(0), [vr, Qn] = W.useState(0), jn = W.useRef(g.duration || se || z0), Di = W.useRef(null), ln = W.useRef(null), ji = T === 0, ki = T + 1 <= E, It = g.type, qr = g.dismissible !== false, Ht = g.className || "", sf = g.descriptionClassName || "", jo = W.useMemo(() => C.findIndex((Ae) => Ae.toastId === g.id) || 0, [C, g.id]), fl = W.useMemo(() => {
      var Ae;
      return (Ae = g.closeButton) != null ? Ae : L;
    }, [g.closeButton, L]), ko = W.useMemo(() => g.duration || se || z0, [g.duration, se]), Pi = W.useRef(0), yr = W.useRef(0), dl = W.useRef(0), Yr = W.useRef(null), [Po, $t] = le.split("-"), kn = W.useMemo(() => C.reduce((Ae, tt, St) => St >= jo ? Ae : Ae + tt.height, 0), [C, jo]), kt = vD(), lf = g.invert || v, Li = It === "loading";
    yr.current = W.useMemo(() => jo * ue + kn, [jo, kn]), W.useEffect(() => {
      jn.current = ko;
    }, [ko]), W.useEffect(() => {
      J(true);
    }, []), W.useEffect(() => {
      const Ae = ln.current;
      if (Ae) {
        const tt = Ae.getBoundingClientRect().height;
        return Qn(tt), x((St) => [{ toastId: g.id, height: tt, position: g.position }, ...St]), () => x((St) => St.filter((Pt) => Pt.toastId !== g.id));
      }
    }, [x, g.id]), W.useLayoutEffect(() => {
      if (!X) return;
      const Ae = ln.current, tt = Ae.style.height;
      Ae.style.height = "auto";
      const St = Ae.getBoundingClientRect().height;
      Ae.style.height = tt, Qn(St), x((Pt) => Pt.find((at) => at.toastId === g.id) ? Pt.map((at) => at.toastId === g.id ? { ...at, height: St } : at) : [{ toastId: g.id, height: St, position: g.position }, ...Pt]);
    }, [X, g.title, g.description, x, g.id, g.jsx, g.action, g.cancel]);
    const Gn = W.useCallback(() => {
      ge(true), yt(yr.current), x((Ae) => Ae.filter((tt) => tt.toastId !== g.id)), setTimeout(() => {
        D(g);
      }, MD);
    }, [g, D, x, yr]);
    W.useEffect(() => {
      if (g.promise && It === "loading" || g.duration === 1 / 0 || g.type === "loading") return;
      let Ae;
      return O || _ || kt ? (() => {
        if (dl.current < Pi.current) {
          const Pt = (/* @__PURE__ */ new Date()).getTime() - Pi.current;
          jn.current = jn.current - Pt;
        }
        dl.current = (/* @__PURE__ */ new Date()).getTime();
      })() : (() => {
        jn.current !== 1 / 0 && (Pi.current = (/* @__PURE__ */ new Date()).getTime(), Ae = setTimeout(() => {
          g.onAutoClose == null || g.onAutoClose.call(g, g), Gn();
        }, jn.current));
      })(), () => clearTimeout(Ae);
    }, [O, _, g, It, kt, Gn]), W.useEffect(() => {
      g.delete && (Gn(), g.onDismiss == null || g.onDismiss.call(g, g));
    }, [Gn, g.delete]);
    function va() {
      var Ae;
      if (Z == null ? void 0 : Z.loading) {
        var tt;
        return W.createElement("div", { className: nr(N == null ? void 0 : N.loader, g == null || (tt = g.classNames) == null ? void 0 : tt.loader, "sonner-loader"), "data-visible": It === "loading" }, Z.loading);
      }
      return W.createElement(fD, { className: nr(N == null ? void 0 : N.loader, g == null || (Ae = g.classNames) == null ? void 0 : Ae.loader), visible: It === "loading" });
    }
    const ya = g.icon || (Z == null ? void 0 : Z[It]) || cD(It);
    var Lo, Kn;
    return W.createElement("li", { tabIndex: 0, ref: ln, className: nr(G, Ht, N == null ? void 0 : N.toast, g == null || (t = g.classNames) == null ? void 0 : t.toast, N == null ? void 0 : N.default, N == null ? void 0 : N[It], g == null || (r = g.classNames) == null ? void 0 : r[It]), "data-sonner-toast": "", "data-rich-colors": (Lo = g.richColors) != null ? Lo : P, "data-styled": !(g.jsx || g.unstyled || S), "data-mounted": X, "data-promise": !!g.promise, "data-swiped": De, "data-removed": ie, "data-visible": ki, "data-y-position": Po, "data-x-position": $t, "data-index": T, "data-front": ji, "data-swiping": ne, "data-dismissible": qr, "data-type": It, "data-invert": lf, "data-swipe-out": xe, "data-swipe-direction": M, "data-expanded": !!(O || oe && X), "data-testid": g.testId, style: { "--index": T, "--toasts-before": T, "--z-index": R.length - T, "--offset": `${ie ? Ct : yr.current}px`, "--initial-height": oe ? "auto" : `${vr}px`, ...k, ...g.style }, onDragEnd: () => {
      fe(false), me(null), Yr.current = null;
    }, onPointerDown: (Ae) => {
      Ae.button !== 2 && (Li || !qr || (Di.current = /* @__PURE__ */ new Date(), yt(yr.current), Ae.target.setPointerCapture(Ae.pointerId), Ae.target.tagName !== "BUTTON" && (fe(true), Yr.current = { x: Ae.clientX, y: Ae.clientY })));
    }, onPointerUp: () => {
      var Ae, tt, St;
      if (xe || !qr) return;
      Yr.current = null;
      const Pt = Number(((Ae = ln.current) == null ? void 0 : Ae.style.getPropertyValue("--swipe-amount-x").replace("px", "")) || 0), Xr = Number(((tt = ln.current) == null ? void 0 : tt.style.getPropertyValue("--swipe-amount-y").replace("px", "")) || 0), at = (/* @__PURE__ */ new Date()).getTime() - ((St = Di.current) == null ? void 0 : St.getTime()), Ft = ce === "x" ? Pt : Xr, Uo = Math.abs(Ft) / at;
      if (Math.abs(Ft) >= RD || Uo > 0.11) {
        yt(yr.current), g.onDismiss == null || g.onDismiss.call(g, g), F(ce === "x" ? Pt > 0 ? "right" : "left" : Xr > 0 ? "down" : "up"), Gn(), Re(true);
        return;
      } else {
        var qt, Yt;
        (qt = ln.current) == null || qt.style.setProperty("--swipe-amount-x", "0px"), (Yt = ln.current) == null || Yt.style.setProperty("--swipe-amount-y", "0px");
      }
      Le(false), fe(false), me(null);
    }, onPointerMove: (Ae) => {
      var tt, St, Pt;
      if (!Yr.current || !qr || ((tt = window.getSelection()) == null ? void 0 : tt.toString().length) > 0) return;
      const at = Ae.clientY - Yr.current.y, Ft = Ae.clientX - Yr.current.x;
      var Uo;
      const qt = (Uo = e.swipeDirections) != null ? Uo : ND(le);
      !ce && (Math.abs(Ft) > 1 || Math.abs(at) > 1) && me(Math.abs(Ft) > Math.abs(at) ? "x" : "y");
      let Yt = { x: 0, y: 0 };
      const ba = (Pn) => 1 / (1.5 + Math.abs(Pn) / 20);
      if (ce === "y") {
        if (qt.includes("top") || qt.includes("bottom")) if (qt.includes("top") && at < 0 || qt.includes("bottom") && at > 0) Yt.y = at;
        else {
          const Pn = at * ba(at);
          Yt.y = Math.abs(Pn) < Math.abs(at) ? Pn : at;
        }
      } else if (ce === "x" && (qt.includes("left") || qt.includes("right"))) if (qt.includes("left") && Ft < 0 || qt.includes("right") && Ft > 0) Yt.x = Ft;
      else {
        const Pn = Ft * ba(Ft);
        Yt.x = Math.abs(Pn) < Math.abs(Ft) ? Pn : Ft;
      }
      (Math.abs(Yt.x) > 0 || Math.abs(Yt.y) > 0) && Le(true), (St = ln.current) == null || St.style.setProperty("--swipe-amount-x", `${Yt.x}px`), (Pt = ln.current) == null || Pt.style.setProperty("--swipe-amount-y", `${Yt.y}px`);
    } }, fl && !g.jsx && It !== "loading" ? W.createElement("button", { "aria-label": B, "data-disabled": Li, "data-close-button": true, onClick: Li || !qr ? () => {
    } : () => {
      Gn(), g.onDismiss == null || g.onDismiss.call(g, g);
    }, className: nr(N == null ? void 0 : N.closeButton, g == null || (a = g.classNames) == null ? void 0 : a.closeButton) }, (Kn = Z == null ? void 0 : Z.close) != null ? Kn : gD) : null, (It || g.icon || g.promise) && g.icon !== null && ((Z == null ? void 0 : Z[It]) !== null || g.icon) ? W.createElement("div", { "data-icon": "", className: nr(N == null ? void 0 : N.icon, g == null || (s = g.classNames) == null ? void 0 : s.icon) }, g.promise || g.type === "loading" && !g.icon ? g.icon || va() : null, g.type !== "loading" ? ya : null) : null, W.createElement("div", { "data-content": "", className: nr(N == null ? void 0 : N.content, g == null || (l = g.classNames) == null ? void 0 : l.content) }, W.createElement("div", { "data-title": "", className: nr(N == null ? void 0 : N.title, g == null || (u = g.classNames) == null ? void 0 : u.title) }, g.jsx ? g.jsx : typeof g.title == "function" ? g.title() : g.title), g.description ? W.createElement("div", { "data-description": "", className: nr(ae, sf, N == null ? void 0 : N.description, g == null || (f = g.classNames) == null ? void 0 : f.description) }, typeof g.description == "function" ? g.description() : g.description) : null), W.isValidElement(g.cancel) ? g.cancel : g.cancel && Mc(g.cancel) ? W.createElement("button", { "data-button": true, "data-cancel": true, style: g.cancelButtonStyle || $, onClick: (Ae) => {
      Mc(g.cancel) && qr && (g.cancel.onClick == null || g.cancel.onClick.call(g.cancel, Ae), Gn());
    }, className: nr(N == null ? void 0 : N.cancelButton, g == null || (p = g.classNames) == null ? void 0 : p.cancelButton) }, g.cancel.label) : null, W.isValidElement(g.action) ? g.action : g.action && Mc(g.action) ? W.createElement("button", { "data-button": true, "data-action": true, style: g.actionButtonStyle || re, onClick: (Ae) => {
      Mc(g.action) && (g.action.onClick == null || g.action.onClick.call(g.action, Ae), !Ae.defaultPrevented && Gn());
    }, className: nr(N == null ? void 0 : N.actionButton, g == null || (m = g.classNames) == null ? void 0 : m.actionButton) }, g.action.label) : null);
  };
  function D0() {
    if (typeof window > "u" || typeof document > "u") return "ltr";
    const e = document.documentElement.getAttribute("dir");
    return e === "auto" || !e ? window.getComputedStyle(document.documentElement).direction : e;
  }
  function DD(e, t) {
    const r = {};
    return [e, t].forEach((a, s) => {
      const l = s === 1, u = l ? "--mobile-offset" : "--offset", f = l ? CD : AD;
      function p(m) {
        ["top", "right", "bottom", "left"].forEach((v) => {
          r[`${u}-${v}`] = typeof m == "number" ? `${m}px` : m;
        });
      }
      typeof a == "number" || typeof a == "string" ? p(a) : typeof a == "object" ? ["top", "right", "bottom", "left"].forEach((m) => {
        a[m] === void 0 ? r[`${u}-${m}`] = f : r[`${u}-${m}`] = typeof a[m] == "number" ? `${a[m]}px` : a[m];
      }) : p(f);
    }), r;
  }
  const jD = W.forwardRef(function(t, r) {
    const { id: a, invert: s, position: l = "bottom-right", hotkey: u = ["altKey", "KeyT"], expand: f, closeButton: p, className: m, offset: v, mobileOffset: g, theme: S = "light", richColors: _, duration: x, style: E, visibleToasts: C = ED, toastOptions: T, dir: R = D0(), gap: O = OD, icons: D, containerAriaLabel: P = "Notifications" } = t, [L, k] = W.useState([]), $ = W.useMemo(() => a ? L.filter((X) => X.toasterId === a) : L.filter((X) => !X.toasterId), [L, a]), re = W.useMemo(() => Array.from(new Set([l].concat($.filter((X) => X.position).map((X) => X.position)))), [$, l]), [G, ae] = W.useState([]), [se, le] = W.useState(false), [ue, oe] = W.useState(false), [N, Z] = W.useState(S !== "system" ? S : typeof window < "u" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"), B = W.useRef(null), ce = u.join("+").replace(/Key/g, "").replace(/Digit/g, ""), me = W.useRef(null), M = W.useRef(false), F = W.useCallback((X) => {
      k((J) => {
        var ie;
        return (ie = J.find((ge) => ge.id === X.id)) != null && ie.delete || tn.dismiss(X.id), J.filter(({ id: ge }) => ge !== X.id);
      });
    }, []);
    return W.useEffect(() => tn.subscribe((X) => {
      if (X.dismiss) {
        requestAnimationFrame(() => {
          k((J) => J.map((ie) => ie.id === X.id ? { ...ie, delete: true } : ie));
        });
        return;
      }
      setTimeout(() => {
        gx.flushSync(() => {
          k((J) => {
            const ie = J.findIndex((ge) => ge.id === X.id);
            return ie !== -1 ? [...J.slice(0, ie), { ...J[ie], ...X }, ...J.slice(ie + 1)] : [X, ...J];
          });
        });
      });
    }), [L]), W.useEffect(() => {
      if (S !== "system") {
        Z(S);
        return;
      }
      if (S === "system" && (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? Z("dark") : Z("light")), typeof window > "u") return;
      const X = window.matchMedia("(prefers-color-scheme: dark)");
      try {
        X.addEventListener("change", ({ matches: J }) => {
          Z(J ? "dark" : "light");
        });
      } catch {
        X.addListener(({ matches: ie }) => {
          try {
            Z(ie ? "dark" : "light");
          } catch (ge) {
            console.error(ge);
          }
        });
      }
    }, [S]), W.useEffect(() => {
      L.length <= 1 && le(false);
    }, [L]), W.useEffect(() => {
      const X = (J) => {
        var ie;
        if (u.every((fe) => J[fe] || J.code === fe)) {
          var ne;
          le(true), (ne = B.current) == null || ne.focus();
        }
        J.code === "Escape" && (document.activeElement === B.current || (ie = B.current) != null && ie.contains(document.activeElement)) && le(false);
      };
      return document.addEventListener("keydown", X), () => document.removeEventListener("keydown", X);
    }, [u]), W.useEffect(() => {
      if (B.current) return () => {
        me.current && (me.current.focus({ preventScroll: true }), me.current = null, M.current = false);
      };
    }, [B.current]), W.createElement("section", { ref: r, "aria-label": `${P} ${ce}`, tabIndex: -1, "aria-live": "polite", "aria-relevant": "additions text", "aria-atomic": "false", suppressHydrationWarning: true }, re.map((X, J) => {
      var ie;
      const [ge, ne] = X.split("-");
      return $.length ? W.createElement("ol", { key: X, dir: R === "auto" ? D0() : R, tabIndex: -1, ref: B, className: m, "data-sonner-toaster": true, "data-sonner-theme": N, "data-y-position": ge, "data-x-position": ne, style: { "--front-toast-height": `${((ie = G[0]) == null ? void 0 : ie.height) || 0}px`, "--width": `${TD}px`, "--gap": `${O}px`, ...E, ...DD(v, g) }, onBlur: (fe) => {
        M.current && !fe.currentTarget.contains(fe.relatedTarget) && (M.current = false, me.current && (me.current.focus({ preventScroll: true }), me.current = null));
      }, onFocus: (fe) => {
        fe.target instanceof HTMLElement && fe.target.dataset.dismissible === "false" || M.current || (M.current = true, me.current = fe.relatedTarget);
      }, onMouseEnter: () => le(true), onMouseMove: () => le(true), onMouseLeave: () => {
        ue || le(false);
      }, onDragEnd: () => le(false), onPointerDown: (fe) => {
        fe.target instanceof HTMLElement && fe.target.dataset.dismissible === "false" || oe(true);
      }, onPointerUp: () => oe(false) }, $.filter((fe) => !fe.position && J === 0 || fe.position === X).map((fe, xe) => {
        var Re, De;
        return W.createElement(zD, { key: fe.id, icons: D, index: xe, toast: fe, defaultRichColors: _, duration: (Re = T == null ? void 0 : T.duration) != null ? Re : x, className: T == null ? void 0 : T.className, descriptionClassName: T == null ? void 0 : T.descriptionClassName, invert: s, visibleToasts: C, closeButton: (De = T == null ? void 0 : T.closeButton) != null ? De : p, interacting: ue, position: X, style: T == null ? void 0 : T.style, unstyled: T == null ? void 0 : T.unstyled, classNames: T == null ? void 0 : T.classNames, cancelButtonStyle: T == null ? void 0 : T.cancelButtonStyle, actionButtonStyle: T == null ? void 0 : T.actionButtonStyle, closeButtonAriaLabel: T == null ? void 0 : T.closeButtonAriaLabel, removeToast: F, toasts: $.filter((Le) => Le.position == fe.position), heights: G.filter((Le) => Le.position == fe.position), setHeights: ae, expandByDefault: f, gap: O, expanded: se, swipeDirections: t.swipeDirections });
      })) : null;
    }));
  }), cr = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__, Ir = globalThis, Hs = "10.38.0";
  function al() {
    return rm(Ir), Ir;
  }
  function rm(e) {
    const t = e.__SENTRY__ = e.__SENTRY__ || {};
    return t.version = t.version || Hs, t[Hs] = t[Hs] || {};
  }
  function il(e, t, r = Ir) {
    const a = r.__SENTRY__ = r.__SENTRY__ || {}, s = a[Hs] = a[Hs] || {};
    return s[e] || (s[e] = t());
  }
  const kD = "Sentry Logger ", j0 = {};
  function PD(e) {
    if (!("console" in Ir)) return e();
    const t = Ir.console, r = {}, a = Object.keys(j0);
    a.forEach((s) => {
      const l = j0[s];
      r[s] = t[s], t[s] = l;
    });
    try {
      return e();
    } finally {
      a.forEach((s) => {
        t[s] = r[s];
      });
    }
  }
  function LD() {
    am().enabled = true;
  }
  function UD() {
    am().enabled = false;
  }
  function vx() {
    return am().enabled;
  }
  function BD(...e) {
    om("log", ...e);
  }
  function ID(...e) {
    om("warn", ...e);
  }
  function HD(...e) {
    om("error", ...e);
  }
  function om(e, ...t) {
    cr && vx() && PD(() => {
      Ir.console[e](`${kD}[${e}]:`, ...t);
    });
  }
  function am() {
    return cr ? il("loggerSettings", () => ({ enabled: false })) : { enabled: false };
  }
  const _o = { enable: LD, disable: UD, isEnabled: vx, log: BD, warn: ID, error: HD }, $D = Object.prototype.toString;
  function yx(e, t) {
    return $D.call(e) === `[object ${t}]`;
  }
  function VD(e) {
    return yx(e, "String");
  }
  function ZD(e) {
    return yx(e, "Object");
  }
  function FD(e) {
    return !!((e == null ? void 0 : e.then) && typeof e.then == "function");
  }
  function qD(e, t, r) {
    try {
      Object.defineProperty(e, t, { value: r, writable: true, configurable: true });
    } catch {
      cr && _o.log(`Failed to add non-enumerable property "${t}" to object`, e);
    }
  }
  let oi;
  function Du(e) {
    if (oi !== void 0) return oi ? oi(e) : e();
    const t = /* @__PURE__ */ Symbol.for("__SENTRY_SAFE_RANDOM_ID_WRAPPER__"), r = Ir;
    return t in r && typeof r[t] == "function" ? (oi = r[t], oi(e)) : (oi = null, e());
  }
  function sp() {
    return Du(() => Math.random());
  }
  function YD() {
    return Du(() => Date.now());
  }
  function XD(e, t = 0) {
    return typeof e != "string" || t === 0 || e.length <= t ? e : `${e.slice(0, t)}...`;
  }
  function QD() {
    const e = Ir;
    return e.crypto || e.msCrypto;
  }
  let Oh;
  function GD() {
    return sp() * 16;
  }
  function pi(e = QD()) {
    try {
      if (e == null ? void 0 : e.randomUUID) return Du(() => e.randomUUID()).replace(/-/g, "");
    } catch {
    }
    return Oh || (Oh = "10000000100040008000" + 1e11), Oh.replace(/[018]/g, (t) => (t ^ (GD() & 15) >> t / 4).toString(16));
  }
  const bx = 1e3;
  function wx() {
    return YD() / bx;
  }
  function KD() {
    const { performance: e } = Ir;
    if (!(e == null ? void 0 : e.now) || !e.timeOrigin) return wx;
    const t = e.timeOrigin;
    return () => (t + Du(() => e.now())) / bx;
  }
  let k0;
  function im() {
    return (k0 != null ? k0 : k0 = KD())();
  }
  function JD(e, t = {}) {
    if (t.user && (!e.ipAddress && t.user.ip_address && (e.ipAddress = t.user.ip_address), !e.did && !t.did && (e.did = t.user.id || t.user.email || t.user.username)), e.timestamp = t.timestamp || im(), t.abnormal_mechanism && (e.abnormal_mechanism = t.abnormal_mechanism), t.ignoreDuration && (e.ignoreDuration = t.ignoreDuration), t.sid && (e.sid = t.sid.length === 32 ? t.sid : pi()), t.init !== void 0 && (e.init = t.init), !e.did && t.did && (e.did = `${t.did}`), typeof t.started == "number" && (e.started = t.started), e.ignoreDuration) e.duration = void 0;
    else if (typeof t.duration == "number") e.duration = t.duration;
    else {
      const r = e.timestamp - e.started;
      e.duration = r >= 0 ? r : 0;
    }
    t.release && (e.release = t.release), t.environment && (e.environment = t.environment), !e.ipAddress && t.ipAddress && (e.ipAddress = t.ipAddress), !e.userAgent && t.userAgent && (e.userAgent = t.userAgent), typeof t.errors == "number" && (e.errors = t.errors), t.status && (e.status = t.status);
  }
  function ju(e, t, r = 2) {
    if (!t || typeof t != "object" || r <= 0) return t;
    if (e && Object.keys(t).length === 0) return e;
    const a = { ...e };
    for (const s in t) Object.prototype.hasOwnProperty.call(t, s) && (a[s] = ju(a[s], t[s], r - 1));
    return a;
  }
  function P0() {
    return pi();
  }
  function Sx() {
    return pi().substring(16);
  }
  const lp = "_sentrySpan";
  function L0(e, t) {
    t ? qD(e, lp, t) : delete e[lp];
  }
  function ru(e) {
    return e[lp];
  }
  const WD = 100;
  class To {
    constructor() {
      this._notifyingListeners = false, this._scopeListeners = [], this._eventProcessors = [], this._breadcrumbs = [], this._attachments = [], this._user = {}, this._tags = {}, this._attributes = {}, this._extra = {}, this._contexts = {}, this._sdkProcessingMetadata = {}, this._propagationContext = { traceId: P0(), sampleRand: sp() };
    }
    clone() {
      const t = new To();
      return t._breadcrumbs = [...this._breadcrumbs], t._tags = { ...this._tags }, t._attributes = { ...this._attributes }, t._extra = { ...this._extra }, t._contexts = { ...this._contexts }, this._contexts.flags && (t._contexts.flags = { values: [...this._contexts.flags.values] }), t._user = this._user, t._level = this._level, t._session = this._session, t._transactionName = this._transactionName, t._fingerprint = this._fingerprint, t._eventProcessors = [...this._eventProcessors], t._attachments = [...this._attachments], t._sdkProcessingMetadata = { ...this._sdkProcessingMetadata }, t._propagationContext = { ...this._propagationContext }, t._client = this._client, t._lastEventId = this._lastEventId, t._conversationId = this._conversationId, L0(t, ru(this)), t;
    }
    setClient(t) {
      this._client = t;
    }
    setLastEventId(t) {
      this._lastEventId = t;
    }
    getClient() {
      return this._client;
    }
    lastEventId() {
      return this._lastEventId;
    }
    addScopeListener(t) {
      this._scopeListeners.push(t);
    }
    addEventProcessor(t) {
      return this._eventProcessors.push(t), this;
    }
    setUser(t) {
      return this._user = t || { email: void 0, id: void 0, ip_address: void 0, username: void 0 }, this._session && JD(this._session, { user: t }), this._notifyScopeListeners(), this;
    }
    getUser() {
      return this._user;
    }
    setConversationId(t) {
      return this._conversationId = t || void 0, this._notifyScopeListeners(), this;
    }
    setTags(t) {
      return this._tags = { ...this._tags, ...t }, this._notifyScopeListeners(), this;
    }
    setTag(t, r) {
      return this.setTags({ [t]: r });
    }
    setAttributes(t) {
      return this._attributes = { ...this._attributes, ...t }, this._notifyScopeListeners(), this;
    }
    setAttribute(t, r) {
      return this.setAttributes({ [t]: r });
    }
    removeAttribute(t) {
      return t in this._attributes && (delete this._attributes[t], this._notifyScopeListeners()), this;
    }
    setExtras(t) {
      return this._extra = { ...this._extra, ...t }, this._notifyScopeListeners(), this;
    }
    setExtra(t, r) {
      return this._extra = { ...this._extra, [t]: r }, this._notifyScopeListeners(), this;
    }
    setFingerprint(t) {
      return this._fingerprint = t, this._notifyScopeListeners(), this;
    }
    setLevel(t) {
      return this._level = t, this._notifyScopeListeners(), this;
    }
    setTransactionName(t) {
      return this._transactionName = t, this._notifyScopeListeners(), this;
    }
    setContext(t, r) {
      return r === null ? delete this._contexts[t] : this._contexts[t] = r, this._notifyScopeListeners(), this;
    }
    setSession(t) {
      return t ? this._session = t : delete this._session, this._notifyScopeListeners(), this;
    }
    getSession() {
      return this._session;
    }
    update(t) {
      if (!t) return this;
      const r = typeof t == "function" ? t(this) : t, a = r instanceof To ? r.getScopeData() : ZD(r) ? t : void 0, { tags: s, attributes: l, extra: u, user: f, contexts: p, level: m, fingerprint: v = [], propagationContext: g, conversationId: S } = a || {};
      return this._tags = { ...this._tags, ...s }, this._attributes = { ...this._attributes, ...l }, this._extra = { ...this._extra, ...u }, this._contexts = { ...this._contexts, ...p }, f && Object.keys(f).length && (this._user = f), m && (this._level = m), v.length && (this._fingerprint = v), g && (this._propagationContext = g), S && (this._conversationId = S), this;
    }
    clear() {
      return this._breadcrumbs = [], this._tags = {}, this._attributes = {}, this._extra = {}, this._user = {}, this._contexts = {}, this._level = void 0, this._transactionName = void 0, this._fingerprint = void 0, this._session = void 0, this._conversationId = void 0, L0(this, void 0), this._attachments = [], this.setPropagationContext({ traceId: P0(), sampleRand: sp() }), this._notifyScopeListeners(), this;
    }
    addBreadcrumb(t, r) {
      var _a4;
      const a = typeof r == "number" ? r : WD;
      if (a <= 0) return this;
      const s = { timestamp: wx(), ...t, message: t.message ? XD(t.message, 2048) : t.message };
      return this._breadcrumbs.push(s), this._breadcrumbs.length > a && (this._breadcrumbs = this._breadcrumbs.slice(-a), (_a4 = this._client) == null ? void 0 : _a4.recordDroppedEvent("buffer_overflow", "log_item")), this._notifyScopeListeners(), this;
    }
    getLastBreadcrumb() {
      return this._breadcrumbs[this._breadcrumbs.length - 1];
    }
    clearBreadcrumbs() {
      return this._breadcrumbs = [], this._notifyScopeListeners(), this;
    }
    addAttachment(t) {
      return this._attachments.push(t), this;
    }
    clearAttachments() {
      return this._attachments = [], this;
    }
    getScopeData() {
      return { breadcrumbs: this._breadcrumbs, attachments: this._attachments, contexts: this._contexts, tags: this._tags, attributes: this._attributes, extra: this._extra, user: this._user, level: this._level, fingerprint: this._fingerprint || [], eventProcessors: this._eventProcessors, propagationContext: this._propagationContext, sdkProcessingMetadata: this._sdkProcessingMetadata, transactionName: this._transactionName, span: ru(this), conversationId: this._conversationId };
    }
    setSDKProcessingMetadata(t) {
      return this._sdkProcessingMetadata = ju(this._sdkProcessingMetadata, t, 2), this;
    }
    setPropagationContext(t) {
      return this._propagationContext = t, this;
    }
    getPropagationContext() {
      return this._propagationContext;
    }
    captureException(t, r) {
      const a = (r == null ? void 0 : r.event_id) || pi();
      if (!this._client) return cr && _o.warn("No client configured on scope - will not capture exception!"), a;
      const s = new Error("Sentry syntheticException");
      return this._client.captureException(t, { originalException: t, syntheticException: s, ...r, event_id: a }, this), a;
    }
    captureMessage(t, r, a) {
      var _a4;
      const s = (a == null ? void 0 : a.event_id) || pi();
      if (!this._client) return cr && _o.warn("No client configured on scope - will not capture message!"), s;
      const l = (_a4 = a == null ? void 0 : a.syntheticException) != null ? _a4 : new Error(t);
      return this._client.captureMessage(t, r, { originalException: t, syntheticException: l, ...a, event_id: s }, this), s;
    }
    captureEvent(t, r) {
      const a = (r == null ? void 0 : r.event_id) || pi();
      return this._client ? (this._client.captureEvent(t, { ...r, event_id: a }, this), a) : (cr && _o.warn("No client configured on scope - will not capture event!"), a);
    }
    _notifyScopeListeners() {
      this._notifyingListeners || (this._notifyingListeners = true, this._scopeListeners.forEach((t) => {
        t(this);
      }), this._notifyingListeners = false);
    }
  }
  function e4() {
    return il("defaultCurrentScope", () => new To());
  }
  function t4() {
    return il("defaultIsolationScope", () => new To());
  }
  class n4 {
    constructor(t, r) {
      let a;
      t ? a = t : a = new To();
      let s;
      r ? s = r : s = new To(), this._stack = [{ scope: a }], this._isolationScope = s;
    }
    withScope(t) {
      const r = this._pushScope();
      let a;
      try {
        a = t(r);
      } catch (s) {
        throw this._popScope(), s;
      }
      return FD(a) ? a.then((s) => (this._popScope(), s), (s) => {
        throw this._popScope(), s;
      }) : (this._popScope(), a);
    }
    getClient() {
      return this.getStackTop().client;
    }
    getScope() {
      return this.getStackTop().scope;
    }
    getIsolationScope() {
      return this._isolationScope;
    }
    getStackTop() {
      return this._stack[this._stack.length - 1];
    }
    _pushScope() {
      const t = this.getScope().clone();
      return this._stack.push({ client: this.getClient(), scope: t }), t;
    }
    _popScope() {
      return this._stack.length <= 1 ? false : !!this._stack.pop();
    }
  }
  function bi() {
    const e = al(), t = rm(e);
    return t.stack = t.stack || new n4(e4(), t4());
  }
  function r4(e) {
    return bi().withScope(e);
  }
  function o4(e, t) {
    const r = bi();
    return r.withScope(() => (r.getStackTop().scope = e, t(e)));
  }
  function U0(e) {
    return bi().withScope(() => e(bi().getIsolationScope()));
  }
  function a4() {
    return { withIsolationScope: U0, withScope: r4, withSetScope: o4, withSetIsolationScope: (e, t) => U0(t), getCurrentScope: () => bi().getScope(), getIsolationScope: () => bi().getIsolationScope() };
  }
  function ku(e) {
    const t = rm(e);
    return t.acs ? t.acs : a4();
  }
  function Pu() {
    const e = al();
    return ku(e).getCurrentScope();
  }
  function xx() {
    const e = al();
    return ku(e).getIsolationScope();
  }
  function i4() {
    return il("globalScope", () => new To());
  }
  function s4(...e) {
    const t = al(), r = ku(t);
    if (e.length === 2) {
      const [a, s] = e;
      return a ? r.withSetScope(a, s) : r.withScope(s);
    }
    return r.withScope(e[0]);
  }
  function sm() {
    return Pu().getClient();
  }
  function l4(e) {
    const t = e.getPropagationContext(), { traceId: r, parentSpanId: a, propagationSpanId: s } = t, l = { trace_id: r, span_id: s || Sx() };
    return a && (l.parent_span_id = a), l;
  }
  const c4 = "sentry.source", u4 = "sentry.sample_rate", f4 = "sentry.previous_trace_sample_rate", d4 = "sentry.op", h4 = "sentry.origin", p4 = 0, m4 = 1, g4 = "_sentryScope", v4 = "_sentryIsolationScope";
  function y4(e) {
    if (e) {
      if (typeof e == "object" && "deref" in e && typeof e.deref == "function") try {
        return e.deref();
      } catch {
        return;
      }
      return e;
    }
  }
  function _x(e) {
    const t = e;
    return { scope: t[g4], isolationScope: y4(t[v4]) };
  }
  const b4 = "sentry-", w4 = /^sentry-/;
  function S4(e) {
    const t = x4(e);
    if (!t) return;
    const r = Object.entries(t).reduce((a, [s, l]) => {
      if (s.match(w4)) {
        const u = s.slice(b4.length);
        a[u] = l;
      }
      return a;
    }, {});
    if (Object.keys(r).length > 0) return r;
  }
  function x4(e) {
    if (!(!e || !VD(e) && !Array.isArray(e))) return Array.isArray(e) ? e.reduce((t, r) => {
      const a = B0(r);
      return Object.entries(a).forEach(([s, l]) => {
        t[s] = l;
      }), t;
    }, {}) : B0(e);
  }
  function B0(e) {
    return e.split(",").map((t) => {
      const r = t.indexOf("=");
      if (r === -1) return [];
      const a = t.slice(0, r), s = t.slice(r + 1);
      return [a, s].map((l) => {
        try {
          return decodeURIComponent(l.trim());
        } catch {
          return;
        }
      });
    }).reduce((t, [r, a]) => (r && a && (t[r] = a), t), {});
  }
  const _4 = /^o(\d+)\./;
  function E4(e, t = false) {
    const { host: r, path: a, pass: s, port: l, projectId: u, protocol: f, publicKey: p } = e;
    return `${f}://${p}${t && s ? `:${s}` : ""}@${r}${l ? `:${l}` : ""}/${a && `${a}/`}${u}`;
  }
  function A4(e) {
    var _a4;
    return (_a4 = e.match(_4)) == null ? void 0 : _a4[1];
  }
  function C4(e) {
    const t = e.getOptions(), { host: r } = e.getDsn() || {};
    let a;
    return t.orgId ? a = String(t.orgId) : r && (a = A4(r)), a;
  }
  const Ex = 1;
  function T4(e) {
    const { spanId: t, traceId: r, isRemote: a } = e.spanContext(), s = a ? t : Ax(e).parent_span_id, l = _x(e).scope, u = a ? (l == null ? void 0 : l.getPropagationContext().propagationSpanId) || Sx() : t;
    return { parent_span_id: s, span_id: u, trace_id: r };
  }
  function O4(e) {
    if (e && e.length > 0) return e.map(({ context: { spanId: t, traceId: r, traceFlags: a, ...s }, attributes: l }) => ({ span_id: t, trace_id: r, sampled: a === Ex, attributes: l, ...s }));
  }
  function I0(e) {
    return typeof e == "number" ? H0(e) : Array.isArray(e) ? e[0] + e[1] / 1e9 : e instanceof Date ? H0(e.getTime()) : im();
  }
  function H0(e) {
    return e > 9999999999 ? e / 1e3 : e;
  }
  function Ax(e) {
    var _a4;
    if (M4(e)) return e.getSpanJSON();
    const { spanId: t, traceId: r } = e.spanContext();
    if (R4(e)) {
      const { attributes: a, startTime: s, name: l, endTime: u, status: f, links: p } = e, m = "parentSpanId" in e ? e.parentSpanId : "parentSpanContext" in e ? (_a4 = e.parentSpanContext) == null ? void 0 : _a4.spanId : void 0;
      return { span_id: t, trace_id: r, data: a, description: l, parent_span_id: m, start_timestamp: I0(s), timestamp: I0(u) || void 0, status: z4(f), op: a[d4], origin: a[h4], links: O4(p) };
    }
    return { span_id: t, trace_id: r, start_timestamp: 0, data: {} };
  }
  function R4(e) {
    const t = e;
    return !!t.attributes && !!t.startTime && !!t.name && !!t.endTime && !!t.status;
  }
  function M4(e) {
    return typeof e.getSpanJSON == "function";
  }
  function N4(e) {
    const { traceFlags: t } = e.spanContext();
    return t === Ex;
  }
  function z4(e) {
    if (!(!e || e.code === p4)) return e.code === m4 ? "ok" : e.message || "internal_error";
  }
  const D4 = "_sentryRootSpan";
  function j4(e) {
    return e[D4] || e;
  }
  function k4() {
    const e = al(), t = ku(e);
    return t.getActiveSpan ? t.getActiveSpan() : ru(Pu());
  }
  function P4(e) {
    var _a4;
    if (typeof __SENTRY_TRACING__ == "boolean" && !__SENTRY_TRACING__) return false;
    const t = (_a4 = sm()) == null ? void 0 : _a4.getOptions();
    return !!t && (t.tracesSampleRate != null || !!t.tracesSampler);
  }
  const L4 = "production", U4 = "_frozenDsc";
  function Cx(e, t) {
    const r = t.getOptions(), { publicKey: a } = t.getDsn() || {}, s = { environment: r.environment || L4, release: r.release, public_key: a, trace_id: e, org_id: C4(t) };
    return t.emit("createDsc", s), s;
  }
  function B4(e, t) {
    const r = t.getPropagationContext();
    return r.dsc || Cx(r.traceId, e);
  }
  function I4(e) {
    var _a4, _b2, _c3, _d3;
    const t = sm();
    if (!t) return {};
    const r = j4(e), a = Ax(r), s = a.data, l = r.spanContext().traceState, u = (_b2 = (_a4 = l == null ? void 0 : l.get("sentry.sample_rate")) != null ? _a4 : s[u4]) != null ? _b2 : s[f4];
    function f(x) {
      return (typeof u == "number" || typeof u == "string") && (x.sample_rate = `${u}`), x;
    }
    const p = r[U4];
    if (p) return f(p);
    const m = l == null ? void 0 : l.get("sentry.dsc"), v = m && S4(m);
    if (v) return f(v);
    const g = Cx(e.spanContext().traceId, t), S = s[c4], _ = a.description;
    return S !== "url" && _ && (g.transaction = _), P4() && (g.sampled = String(N4(r)), g.sample_rand = (_d3 = l == null ? void 0 : l.get("sentry.sample_rand")) != null ? _d3 : (_c3 = _x(r).scope) == null ? void 0 : _c3.getPropagationContext().sampleRand.toString()), f(g), t.emit("createDsc", g, r), g;
  }
  function H4(e, t = []) {
    return [e, t];
  }
  function $0(e, t) {
    const { extra: r, tags: a, attributes: s, user: l, contexts: u, level: f, sdkProcessingMetadata: p, breadcrumbs: m, fingerprint: v, eventProcessors: g, attachments: S, propagationContext: _, transactionName: x, span: E } = t;
    Rs(e, "extra", r), Rs(e, "tags", a), Rs(e, "attributes", s), Rs(e, "user", l), Rs(e, "contexts", u), e.sdkProcessingMetadata = ju(e.sdkProcessingMetadata, p, 2), f && (e.level = f), x && (e.transactionName = x), E && (e.span = E), m.length && (e.breadcrumbs = [...e.breadcrumbs, ...m]), v.length && (e.fingerprint = [...e.fingerprint, ...v]), g.length && (e.eventProcessors = [...e.eventProcessors, ...g]), S.length && (e.attachments = [...e.attachments, ...S]), e.propagationContext = { ...e.propagationContext, ..._ };
  }
  function Rs(e, t, r) {
    e[t] = ju(e[t], r, 1);
  }
  function $4(e, t) {
    const r = i4().getScopeData();
    return e && $0(r, e.getScopeData()), t && $0(r, t.getScopeData()), r;
  }
  function V4(e, t) {
    const r = typeof t == "string" ? t : void 0, a = typeof t != "string" ? { captureContext: t } : void 0;
    return Pu().captureMessage(e, r, a);
  }
  function Z4(e) {
    xx().setUser(e);
  }
  function F4(e) {
    return typeof e == "object" && e != null && !Array.isArray(e) && Object.keys(e).includes("value");
  }
  function q4(e, t) {
    var _a4;
    const { value: r, unit: a } = F4(e) ? e : { value: e, unit: void 0 }, s = Y4(r), l = a && typeof a == "string" ? { unit: a } : {};
    if (s) return { ...s, ...l };
    if (!t || t === "skip-undefined" && r === void 0) return;
    let u = "";
    try {
      u = (_a4 = JSON.stringify(r)) != null ? _a4 : "";
    } catch {
    }
    return { value: u, type: "string", ...l };
  }
  function V0(e, t = false) {
    const r = {};
    for (const [a, s] of Object.entries(e != null ? e : {})) {
      const l = q4(s, t);
      l && (r[a] = l);
    }
    return r;
  }
  function Y4(e) {
    const t = typeof e == "string" ? "string" : typeof e == "boolean" ? "boolean" : typeof e == "number" && !Number.isNaN(e) ? Number.isInteger(e) ? "integer" : "double" : null;
    if (t) return { value: e, type: t };
  }
  function X4(e, t) {
    return t ? s4(t, () => {
      const r = k4(), a = r ? T4(r) : l4(t);
      return [r ? I4(r) : B4(e, t), a];
    }) : [void 0, void 0];
  }
  function Q4(e) {
    return [{ type: "trace_metric", item_count: e.length, content_type: "application/vnd.sentry.items.trace-metric+json" }, { items: e }];
  }
  function G4(e, t, r, a) {
    const s = {};
    return (t == null ? void 0 : t.sdk) && (s.sdk = { name: t.sdk.name, version: t.sdk.version }), r && a && (s.dsn = E4(a)), H4(s, [Q4(e)]);
  }
  const K4 = 1e3;
  function Lr(e, t, r, a = true) {
    r && (a || !(t in e)) && (e[t] = r);
  }
  function J4(e, t) {
    const r = lm(), a = Tx(e);
    a === void 0 ? r.set(e, [t]) : a.length >= K4 ? (nj(e, a), r.set(e, [t])) : r.set(e, [...a, t]);
  }
  function W4(e, t, r) {
    var _a4, _b2;
    const { release: a, environment: s } = t.getOptions(), l = { ...e.attributes };
    Lr(l, "user.id", r.id, false), Lr(l, "user.email", r.email, false), Lr(l, "user.name", r.username, false), Lr(l, "sentry.release", a), Lr(l, "sentry.environment", s);
    const { name: u, version: f } = (_b2 = (_a4 = t.getSdkMetadata()) == null ? void 0 : _a4.sdk) != null ? _b2 : {};
    Lr(l, "sentry.sdk.name", u), Lr(l, "sentry.sdk.version", f);
    const p = t.getIntegrationByName("Replay"), m = p == null ? void 0 : p.getReplayId(true);
    return Lr(l, "sentry.replay_id", m), m && (p == null ? void 0 : p.getRecordingMode()) === "buffer" && Lr(l, "sentry._internal.replay_is_buffering", true), { ...e, attributes: l };
  }
  function ej(e, t, r, a) {
    const [, s] = X4(t, r), l = ru(r), u = l ? l.spanContext().traceId : s == null ? void 0 : s.trace_id, f = l ? l.spanContext().spanId : void 0;
    return { timestamp: im(), trace_id: u != null ? u : "", span_id: f, name: e.name, type: e.type, unit: e.unit, value: e.value, attributes: { ...V0(a), ...V0(e.attributes, "skip-undefined") } };
  }
  function tj(e, t) {
    var _a4, _b2, _c3;
    const r = Pu(), a = (_a4 = t == null ? void 0 : t.captureSerializedMetric) != null ? _a4 : J4, s = (_b2 = r == null ? void 0 : r.getClient()) != null ? _b2 : sm();
    if (!s) {
      cr && _o.warn("No client available to capture metric.");
      return;
    }
    const { _experiments: l, enableMetrics: u, beforeSendMetric: f } = s.getOptions();
    if (!((_c3 = u != null ? u : l == null ? void 0 : l.enableMetrics) != null ? _c3 : true)) {
      cr && _o.warn("metrics option not enabled, metric will not be captured.");
      return;
    }
    const { user: m, attributes: v } = $4(xx(), r), g = W4(e, s, m);
    s.emit("processMetric", g);
    const S = f || (l == null ? void 0 : l.beforeSendMetric), _ = S ? S(g) : g;
    if (!_) {
      cr && _o.log("`beforeSendMetric` returned `null`, will not send metric.");
      return;
    }
    const x = ej(_, s, r, v);
    cr && _o.log("[Metric]", x), a(s, x), s.emit("afterCaptureMetric", _);
  }
  function nj(e, t) {
    var _a4;
    const r = (_a4 = t != null ? t : Tx(e)) != null ? _a4 : [];
    if (r.length === 0) return;
    const a = e.getOptions(), s = G4(r, a._metadata, a.tunnel, e.getDsn());
    lm().set(e, []), e.emit("flushMetrics"), e.sendEnvelope(s);
  }
  function Tx(e) {
    return lm().get(e);
  }
  function lm() {
    return il("clientToMetricBufferMap", () => /* @__PURE__ */ new WeakMap());
  }
  function rj(e, t, r, a) {
    tj({ type: e, name: t, value: r, unit: a == null ? void 0 : a.unit, attributes: a == null ? void 0 : a.attributes }, {});
  }
  function oj(e, t = 1, r) {
    rj("counter", e, t, r);
  }
  Zr("api.music.yandex.net/account/about", async function(e) {
    const t = e.data;
    return t.hasPlus = true, Z4({ id: t.uid, username: t.login }), console.log("[PlusUnlocker] Change hasPlus value:", t), t;
  });
  Zr("/editorial-promotion", async function(e) {
    return console.log("[PlusUnlocker] Remove promotions:", e.data), { promotions: [] };
  });
  Zr("/proxy/plus-red-alert/v1/alerts", async function(e) {
    return console.log("[PlusUnlocker] Remove plus-red-alert:", e.data), { alerts: [] };
  });
  Zr("api.music.yandex.net/get-file-info", async function(e) {
    const t = e.url, r = e.data, a = new URLSearchParams(t).get("trackId");
    if (!a || r.downloadInfo.trackId === a) return r;
    {
      const s = await fx(a, r.downloadInfo.quality);
      return s.isErr() ? (console.error("[PlusUnlocker] Error getting track url for ad bypass :", s.error), r) : (console.log(`[PlusUnlocker] Ad bypassed for track ${a}`, s.value), { downloadInfo: s.value });
    }
  });
  Zr("api.music.yandex.net", async (e) => {
    function t(f, p, m = []) {
      f && typeof f == "object" && (Array.isArray(f) ? f.forEach((v, g) => t(v, p, [...m, g])) : (p(f, m), Object.values(f).forEach((v) => t(v, p, m))));
    }
    const r = e.data, a = [];
    if (t(r, (f) => {
      f && "id" in f && "realId" in f && "coverUri" in f && "ogImage" in f && f.type === "music" && a.push(f.id);
    }), a.length === 0) return r;
    const s = await hx(a, true);
    if (s.isErr()) return console.error("[PlusUnlocker] Error getting new images:", s.error), r;
    const l = s.value, u = new Map(l.map((f) => [f.id, f]));
    return t(r, (f) => {
      if (f && "id" in f && "realId" in f && "coverUri" in f && "ogImage" in f) {
        const p = u.get(f.id);
        if (!p) return;
        f.coverUri = p.coverUri, f.ogImage = p.ogImage;
      }
    }), console.log("[PlusUnlocker] Ads in image bypassed for tracks", a, r), r;
  });
  Zr("/donation", async function(e) {
    return console.log("[PlusUnlocker] Remove donations", e), { donations: [] };
  });
  Zr("/concerts", async function(e) {
    if ((await window.xlamModz.getStorageValue("custom-themes/hideMenuItems") || []).includes("concerts")) return console.log("[PlusUnlocker] Remove concerts", e), { concerts: [] };
  });
  Zr("/rotor/session/", async function(e) {
    const t = e.url, r = e.data;
    if (t.includes("feedback")) return r;
    const a = r.sequence, s = a.every((l) => l.track && l.track.title === "Промокод Upgrade");
    return r.sequence = a.filter((l) => l.track && l.track.title !== "Промокод Upgrade"), console.log("[PlusUnlocker] Remove all ads from session:", r), s && Ve.error("Моя Волна больше не работает", { description: "Яндекс выдал вашему аккаунту теневой бан. Вы все еще сможете слушать треки в плейлистах и через поиск, но для получения рекомендаций нужно будет создать новый аккаунт и перенести треки туда, такая функция есть в моде.", icon: null }), r;
  });
  var Rh = { exports: {} }, Ms = {};
  var Z0;
  function aj() {
    if (Z0) return Ms;
    Z0 = 1;
    var e = /* @__PURE__ */ Symbol.for("react.transitional.element"), t = /* @__PURE__ */ Symbol.for("react.fragment");
    function r(a, s, l) {
      var u = null;
      if (l !== void 0 && (u = "" + l), s.key !== void 0 && (u = "" + s.key), "key" in s) {
        l = {};
        for (var f in s) f !== "key" && (l[f] = s[f]);
      } else l = s;
      return s = l.ref, { $$typeof: e, type: a, key: u, ref: s !== void 0 ? s : null, props: l };
    }
    return Ms.Fragment = t, Ms.jsx = r, Ms.jsxs = r, Ms;
  }
  var F0;
  function ij() {
    return F0 || (F0 = 1, Rh.exports = aj()), Rh.exports;
  }
  var b = ij(), Mh = { exports: {} }, Ns = {}, Nh = { exports: {} }, zh = {};
  var q0;
  function sj() {
    return q0 || (q0 = 1, (function(e) {
      function t(N, Z) {
        var B = N.length;
        N.push(Z);
        e: for (; 0 < B; ) {
          var ce = B - 1 >>> 1, me = N[ce];
          if (0 < s(me, Z)) N[ce] = Z, N[B] = me, B = ce;
          else break e;
        }
      }
      function r(N) {
        return N.length === 0 ? null : N[0];
      }
      function a(N) {
        if (N.length === 0) return null;
        var Z = N[0], B = N.pop();
        if (B !== Z) {
          N[0] = B;
          e: for (var ce = 0, me = N.length, M = me >>> 1; ce < M; ) {
            var F = 2 * (ce + 1) - 1, X = N[F], J = F + 1, ie = N[J];
            if (0 > s(X, B)) J < me && 0 > s(ie, X) ? (N[ce] = ie, N[J] = B, ce = J) : (N[ce] = X, N[F] = B, ce = F);
            else if (J < me && 0 > s(ie, B)) N[ce] = ie, N[J] = B, ce = J;
            else break e;
          }
        }
        return Z;
      }
      function s(N, Z) {
        var B = N.sortIndex - Z.sortIndex;
        return B !== 0 ? B : N.id - Z.id;
      }
      if (e.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
        var l = performance;
        e.unstable_now = function() {
          return l.now();
        };
      } else {
        var u = Date, f = u.now();
        e.unstable_now = function() {
          return u.now() - f;
        };
      }
      var p = [], m = [], v = 1, g = null, S = 3, _ = false, x = false, E = false, C = false, T = typeof setTimeout == "function" ? setTimeout : null, R = typeof clearTimeout == "function" ? clearTimeout : null, O = typeof setImmediate < "u" ? setImmediate : null;
      function D(N) {
        for (var Z = r(m); Z !== null; ) {
          if (Z.callback === null) a(m);
          else if (Z.startTime <= N) a(m), Z.sortIndex = Z.expirationTime, t(p, Z);
          else break;
          Z = r(m);
        }
      }
      function P(N) {
        if (E = false, D(N), !x) if (r(p) !== null) x = true, L || (L = true, se());
        else {
          var Z = r(m);
          Z !== null && oe(P, Z.startTime - N);
        }
      }
      var L = false, k = -1, $ = 5, re = -1;
      function G() {
        return C ? true : !(e.unstable_now() - re < $);
      }
      function ae() {
        if (C = false, L) {
          var N = e.unstable_now();
          re = N;
          var Z = true;
          try {
            e: {
              x = false, E && (E = false, R(k), k = -1), _ = true;
              var B = S;
              try {
                t: {
                  for (D(N), g = r(p); g !== null && !(g.expirationTime > N && G()); ) {
                    var ce = g.callback;
                    if (typeof ce == "function") {
                      g.callback = null, S = g.priorityLevel;
                      var me = ce(g.expirationTime <= N);
                      if (N = e.unstable_now(), typeof me == "function") {
                        g.callback = me, D(N), Z = true;
                        break t;
                      }
                      g === r(p) && a(p), D(N);
                    } else a(p);
                    g = r(p);
                  }
                  if (g !== null) Z = true;
                  else {
                    var M = r(m);
                    M !== null && oe(P, M.startTime - N), Z = false;
                  }
                }
                break e;
              } finally {
                g = null, S = B, _ = false;
              }
              Z = void 0;
            }
          } finally {
            Z ? se() : L = false;
          }
        }
      }
      var se;
      if (typeof O == "function") se = function() {
        O(ae);
      };
      else if (typeof MessageChannel < "u") {
        var le = new MessageChannel(), ue = le.port2;
        le.port1.onmessage = ae, se = function() {
          ue.postMessage(null);
        };
      } else se = function() {
        T(ae, 0);
      };
      function oe(N, Z) {
        k = T(function() {
          N(e.unstable_now());
        }, Z);
      }
      e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(N) {
        N.callback = null;
      }, e.unstable_forceFrameRate = function(N) {
        0 > N || 125 < N ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : $ = 0 < N ? Math.floor(1e3 / N) : 5;
      }, e.unstable_getCurrentPriorityLevel = function() {
        return S;
      }, e.unstable_next = function(N) {
        switch (S) {
          case 1:
          case 2:
          case 3:
            var Z = 3;
            break;
          default:
            Z = S;
        }
        var B = S;
        S = Z;
        try {
          return N();
        } finally {
          S = B;
        }
      }, e.unstable_requestPaint = function() {
        C = true;
      }, e.unstable_runWithPriority = function(N, Z) {
        switch (N) {
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            break;
          default:
            N = 3;
        }
        var B = S;
        S = N;
        try {
          return Z();
        } finally {
          S = B;
        }
      }, e.unstable_scheduleCallback = function(N, Z, B) {
        var ce = e.unstable_now();
        switch (typeof B == "object" && B !== null ? (B = B.delay, B = typeof B == "number" && 0 < B ? ce + B : ce) : B = ce, N) {
          case 1:
            var me = -1;
            break;
          case 2:
            me = 250;
            break;
          case 5:
            me = 1073741823;
            break;
          case 4:
            me = 1e4;
            break;
          default:
            me = 5e3;
        }
        return me = B + me, N = { id: v++, callback: Z, priorityLevel: N, startTime: B, expirationTime: me, sortIndex: -1 }, B > ce ? (N.sortIndex = B, t(m, N), r(p) === null && N === r(m) && (E ? (R(k), k = -1) : E = true, oe(P, B - ce))) : (N.sortIndex = me, t(p, N), x || _ || (x = true, L || (L = true, se()))), N;
      }, e.unstable_shouldYield = G, e.unstable_wrapCallback = function(N) {
        var Z = S;
        return function() {
          var B = S;
          S = Z;
          try {
            return N.apply(this, arguments);
          } finally {
            S = B;
          }
        };
      };
    })(zh)), zh;
  }
  var Y0;
  function lj() {
    return Y0 || (Y0 = 1, Nh.exports = sj()), Nh.exports;
  }
  var X0;
  function cj() {
    if (X0) return Ns;
    X0 = 1;
    var e = lj(), t = tm(), r = mx();
    function a(n) {
      var o = "https://react.dev/errors/" + n;
      if (1 < arguments.length) {
        o += "?args[]=" + encodeURIComponent(arguments[1]);
        for (var i = 2; i < arguments.length; i++) o += "&args[]=" + encodeURIComponent(arguments[i]);
      }
      return "Minified React error #" + n + "; visit " + o + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    function s(n) {
      return !(!n || n.nodeType !== 1 && n.nodeType !== 9 && n.nodeType !== 11);
    }
    function l(n) {
      var o = n, i = n;
      if (n.alternate) for (; o.return; ) o = o.return;
      else {
        n = o;
        do
          o = n, (o.flags & 4098) !== 0 && (i = o.return), n = o.return;
        while (n);
      }
      return o.tag === 3 ? i : null;
    }
    function u(n) {
      if (n.tag === 13) {
        var o = n.memoizedState;
        if (o === null && (n = n.alternate, n !== null && (o = n.memoizedState)), o !== null) return o.dehydrated;
      }
      return null;
    }
    function f(n) {
      if (n.tag === 31) {
        var o = n.memoizedState;
        if (o === null && (n = n.alternate, n !== null && (o = n.memoizedState)), o !== null) return o.dehydrated;
      }
      return null;
    }
    function p(n) {
      if (l(n) !== n) throw Error(a(188));
    }
    function m(n) {
      var o = n.alternate;
      if (!o) {
        if (o = l(n), o === null) throw Error(a(188));
        return o !== n ? null : n;
      }
      for (var i = n, c = o; ; ) {
        var d = i.return;
        if (d === null) break;
        var h = d.alternate;
        if (h === null) {
          if (c = d.return, c !== null) {
            i = c;
            continue;
          }
          break;
        }
        if (d.child === h.child) {
          for (h = d.child; h; ) {
            if (h === i) return p(d), n;
            if (h === c) return p(d), o;
            h = h.sibling;
          }
          throw Error(a(188));
        }
        if (i.return !== c.return) i = d, c = h;
        else {
          for (var w = false, A = d.child; A; ) {
            if (A === i) {
              w = true, i = d, c = h;
              break;
            }
            if (A === c) {
              w = true, c = d, i = h;
              break;
            }
            A = A.sibling;
          }
          if (!w) {
            for (A = h.child; A; ) {
              if (A === i) {
                w = true, i = h, c = d;
                break;
              }
              if (A === c) {
                w = true, c = h, i = d;
                break;
              }
              A = A.sibling;
            }
            if (!w) throw Error(a(189));
          }
        }
        if (i.alternate !== c) throw Error(a(190));
      }
      if (i.tag !== 3) throw Error(a(188));
      return i.stateNode.current === i ? n : o;
    }
    function v(n) {
      var o = n.tag;
      if (o === 5 || o === 26 || o === 27 || o === 6) return n;
      for (n = n.child; n !== null; ) {
        if (o = v(n), o !== null) return o;
        n = n.sibling;
      }
      return null;
    }
    var g = Object.assign, S = /* @__PURE__ */ Symbol.for("react.element"), _ = /* @__PURE__ */ Symbol.for("react.transitional.element"), x = /* @__PURE__ */ Symbol.for("react.portal"), E = /* @__PURE__ */ Symbol.for("react.fragment"), C = /* @__PURE__ */ Symbol.for("react.strict_mode"), T = /* @__PURE__ */ Symbol.for("react.profiler"), R = /* @__PURE__ */ Symbol.for("react.consumer"), O = /* @__PURE__ */ Symbol.for("react.context"), D = /* @__PURE__ */ Symbol.for("react.forward_ref"), P = /* @__PURE__ */ Symbol.for("react.suspense"), L = /* @__PURE__ */ Symbol.for("react.suspense_list"), k = /* @__PURE__ */ Symbol.for("react.memo"), $ = /* @__PURE__ */ Symbol.for("react.lazy"), re = /* @__PURE__ */ Symbol.for("react.activity"), G = /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel"), ae = Symbol.iterator;
    function se(n) {
      return n === null || typeof n != "object" ? null : (n = ae && n[ae] || n["@@iterator"], typeof n == "function" ? n : null);
    }
    var le = /* @__PURE__ */ Symbol.for("react.client.reference");
    function ue(n) {
      if (n == null) return null;
      if (typeof n == "function") return n.$$typeof === le ? null : n.displayName || n.name || null;
      if (typeof n == "string") return n;
      switch (n) {
        case E:
          return "Fragment";
        case T:
          return "Profiler";
        case C:
          return "StrictMode";
        case P:
          return "Suspense";
        case L:
          return "SuspenseList";
        case re:
          return "Activity";
      }
      if (typeof n == "object") switch (n.$$typeof) {
        case x:
          return "Portal";
        case O:
          return n.displayName || "Context";
        case R:
          return (n._context.displayName || "Context") + ".Consumer";
        case D:
          var o = n.render;
          return n = n.displayName, n || (n = o.displayName || o.name || "", n = n !== "" ? "ForwardRef(" + n + ")" : "ForwardRef"), n;
        case k:
          return o = n.displayName || null, o !== null ? o : ue(n.type) || "Memo";
        case $:
          o = n._payload, n = n._init;
          try {
            return ue(n(o));
          } catch {
          }
      }
      return null;
    }
    var oe = Array.isArray, N = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, Z = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, B = { pending: false, data: null, method: null, action: null }, ce = [], me = -1;
    function M(n) {
      return { current: n };
    }
    function F(n) {
      0 > me || (n.current = ce[me], ce[me] = null, me--);
    }
    function X(n, o) {
      me++, ce[me] = n.current, n.current = o;
    }
    var J = M(null), ie = M(null), ge = M(null), ne = M(null);
    function fe(n, o) {
      switch (X(ge, o), X(ie, n), X(J, null), o.nodeType) {
        case 9:
        case 11:
          n = (n = o.documentElement) && (n = n.namespaceURI) ? lb(n) : 0;
          break;
        default:
          if (n = o.tagName, o = o.namespaceURI) o = lb(o), n = cb(o, n);
          else switch (n) {
            case "svg":
              n = 1;
              break;
            case "math":
              n = 2;
              break;
            default:
              n = 0;
          }
      }
      F(J), X(J, n);
    }
    function xe() {
      F(J), F(ie), F(ge);
    }
    function Re(n) {
      n.memoizedState !== null && X(ne, n);
      var o = J.current, i = cb(o, n.type);
      o !== i && (X(ie, n), X(J, i));
    }
    function De(n) {
      ie.current === n && (F(J), F(ie)), ne.current === n && (F(ne), _s4._currentValue = B);
    }
    var Le, Ct;
    function yt(n) {
      if (Le === void 0) try {
        throw Error();
      } catch (i) {
        var o = i.stack.trim().match(/\n( *(at )?)/);
        Le = o && o[1] || "", Ct = -1 < i.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < i.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
      return `
` + Le + n + Ct;
    }
    var vr = false;
    function Qn(n, o) {
      if (!n || vr) return "";
      vr = true;
      var i = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        var c = { DetermineComponentFrameRoot: function() {
          try {
            if (o) {
              var ee = function() {
                throw Error();
              };
              if (Object.defineProperty(ee.prototype, "props", { set: function() {
                throw Error();
              } }), typeof Reflect == "object" && Reflect.construct) {
                try {
                  Reflect.construct(ee, []);
                } catch (Y) {
                  var V = Y;
                }
                Reflect.construct(n, [], ee);
              } else {
                try {
                  ee.call();
                } catch (Y) {
                  V = Y;
                }
                n.call(ee.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (Y) {
                V = Y;
              }
              (ee = n()) && typeof ee.catch == "function" && ee.catch(function() {
              });
            }
          } catch (Y) {
            if (Y && V && typeof Y.stack == "string") return [Y.stack, V.stack];
          }
          return [null, null];
        } };
        c.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
        var d = Object.getOwnPropertyDescriptor(c.DetermineComponentFrameRoot, "name");
        d && d.configurable && Object.defineProperty(c.DetermineComponentFrameRoot, "name", { value: "DetermineComponentFrameRoot" });
        var h = c.DetermineComponentFrameRoot(), w = h[0], A = h[1];
        if (w && A) {
          var z = w.split(`
`), H = A.split(`
`);
          for (d = c = 0; c < z.length && !z[c].includes("DetermineComponentFrameRoot"); ) c++;
          for (; d < H.length && !H[d].includes("DetermineComponentFrameRoot"); ) d++;
          if (c === z.length || d === H.length) for (c = z.length - 1, d = H.length - 1; 1 <= c && 0 <= d && z[c] !== H[d]; ) d--;
          for (; 1 <= c && 0 <= d; c--, d--) if (z[c] !== H[d]) {
            if (c !== 1 || d !== 1) do
              if (c--, d--, 0 > d || z[c] !== H[d]) {
                var Q = `
` + z[c].replace(" at new ", " at ");
                return n.displayName && Q.includes("<anonymous>") && (Q = Q.replace("<anonymous>", n.displayName)), Q;
              }
            while (1 <= c && 0 <= d);
            break;
          }
        }
      } finally {
        vr = false, Error.prepareStackTrace = i;
      }
      return (i = n ? n.displayName || n.name : "") ? yt(i) : "";
    }
    function jn(n, o) {
      switch (n.tag) {
        case 26:
        case 27:
        case 5:
          return yt(n.type);
        case 16:
          return yt("Lazy");
        case 13:
          return n.child !== o && o !== null ? yt("Suspense Fallback") : yt("Suspense");
        case 19:
          return yt("SuspenseList");
        case 0:
        case 15:
          return Qn(n.type, false);
        case 11:
          return Qn(n.type.render, false);
        case 1:
          return Qn(n.type, true);
        case 31:
          return yt("Activity");
        default:
          return "";
      }
    }
    function Di(n) {
      try {
        var o = "", i = null;
        do
          o += jn(n, i), i = n, n = n.return;
        while (n);
        return o;
      } catch (c) {
        return `
Error generating stack: ` + c.message + `
` + c.stack;
      }
    }
    var ln = Object.prototype.hasOwnProperty, ji = e.unstable_scheduleCallback, ki = e.unstable_cancelCallback, It = e.unstable_shouldYield, qr = e.unstable_requestPaint, Ht = e.unstable_now, sf = e.unstable_getCurrentPriorityLevel, jo = e.unstable_ImmediatePriority, fl = e.unstable_UserBlockingPriority, ko = e.unstable_NormalPriority, Pi = e.unstable_LowPriority, yr = e.unstable_IdlePriority, dl = e.log, Yr = e.unstable_setDisableYieldValue, Po = null, $t = null;
    function kn(n) {
      if (typeof dl == "function" && Yr(n), $t && typeof $t.setStrictMode == "function") try {
        $t.setStrictMode(Po, n);
      } catch {
      }
    }
    var kt = Math.clz32 ? Math.clz32 : Gn, lf = Math.log, Li = Math.LN2;
    function Gn(n) {
      return n >>>= 0, n === 0 ? 32 : 31 - (lf(n) / Li | 0) | 0;
    }
    var va = 256, ya = 262144, Lo = 4194304;
    function Kn(n) {
      var o = n & 42;
      if (o !== 0) return o;
      switch (n & -n) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
          return 64;
        case 128:
          return 128;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
          return n & 261888;
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return n & 3932160;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return n & 62914560;
        case 67108864:
          return 67108864;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 0;
        default:
          return n;
      }
    }
    function Ae(n, o, i) {
      var c = n.pendingLanes;
      if (c === 0) return 0;
      var d = 0, h = n.suspendedLanes, w = n.pingedLanes;
      n = n.warmLanes;
      var A = c & 134217727;
      return A !== 0 ? (c = A & ~h, c !== 0 ? d = Kn(c) : (w &= A, w !== 0 ? d = Kn(w) : i || (i = A & ~n, i !== 0 && (d = Kn(i))))) : (A = c & ~h, A !== 0 ? d = Kn(A) : w !== 0 ? d = Kn(w) : i || (i = c & ~n, i !== 0 && (d = Kn(i)))), d === 0 ? 0 : o !== 0 && o !== d && (o & h) === 0 && (h = d & -d, i = o & -o, h >= i || h === 32 && (i & 4194048) !== 0) ? o : d;
    }
    function tt(n, o) {
      return (n.pendingLanes & ~(n.suspendedLanes & ~n.pingedLanes) & o) === 0;
    }
    function St(n, o) {
      switch (n) {
        case 1:
        case 2:
        case 4:
        case 8:
        case 64:
          return o + 250;
        case 16:
        case 32:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return o + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return -1;
        case 67108864:
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function Pt() {
      var n = Lo;
      return Lo <<= 1, (Lo & 62914560) === 0 && (Lo = 4194304), n;
    }
    function Xr(n) {
      for (var o = [], i = 0; 31 > i; i++) o.push(n);
      return o;
    }
    function at(n, o) {
      n.pendingLanes |= o, o !== 268435456 && (n.suspendedLanes = 0, n.pingedLanes = 0, n.warmLanes = 0);
    }
    function Ft(n, o, i, c, d, h) {
      var w = n.pendingLanes;
      n.pendingLanes = i, n.suspendedLanes = 0, n.pingedLanes = 0, n.warmLanes = 0, n.expiredLanes &= i, n.entangledLanes &= i, n.errorRecoveryDisabledLanes &= i, n.shellSuspendCounter = 0;
      var A = n.entanglements, z = n.expirationTimes, H = n.hiddenUpdates;
      for (i = w & ~i; 0 < i; ) {
        var Q = 31 - kt(i), ee = 1 << Q;
        A[Q] = 0, z[Q] = -1;
        var V = H[Q];
        if (V !== null) for (H[Q] = null, Q = 0; Q < V.length; Q++) {
          var Y = V[Q];
          Y !== null && (Y.lane &= -536870913);
        }
        i &= ~ee;
      }
      c !== 0 && Uo(n, c, 0), h !== 0 && d === 0 && n.tag !== 0 && (n.suspendedLanes |= h & ~(w & ~o));
    }
    function Uo(n, o, i) {
      n.pendingLanes |= o, n.suspendedLanes &= ~o;
      var c = 31 - kt(o);
      n.entangledLanes |= o, n.entanglements[c] = n.entanglements[c] | 1073741824 | i & 261930;
    }
    function qt(n, o) {
      var i = n.entangledLanes |= o;
      for (n = n.entanglements; i; ) {
        var c = 31 - kt(i), d = 1 << c;
        d & o | n[c] & o && (n[c] |= o), i &= ~d;
      }
    }
    function Yt(n, o) {
      var i = o & -o;
      return i = (i & 42) !== 0 ? 1 : ba(i), (i & (n.suspendedLanes | o)) !== 0 ? 0 : i;
    }
    function ba(n) {
      switch (n) {
        case 2:
          n = 1;
          break;
        case 8:
          n = 4;
          break;
        case 32:
          n = 16;
          break;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          n = 128;
          break;
        case 268435456:
          n = 134217728;
          break;
        default:
          n = 0;
      }
      return n;
    }
    function Pn(n) {
      return n &= -n, 2 < n ? 8 < n ? (n & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
    }
    function cf() {
      var n = Z.p;
      return n !== 0 ? n : (n = window.event, n === void 0 ? 32 : zb(n.type));
    }
    function Xm(n, o) {
      var i = Z.p;
      try {
        return Z.p = n, o();
      } finally {
        Z.p = i;
      }
    }
    var Qr = Math.random().toString(36).slice(2), Tt = "__reactFiber$" + Qr, Xt = "__reactProps$" + Qr, wa = "__reactContainer$" + Qr, uf = "__reactEvents$" + Qr, _A = "__reactListeners$" + Qr, EA = "__reactHandles$" + Qr, Qm = "__reactResources$" + Qr, Ui = "__reactMarker$" + Qr;
    function ff(n) {
      delete n[Tt], delete n[Xt], delete n[uf], delete n[_A], delete n[EA];
    }
    function Sa(n) {
      var o = n[Tt];
      if (o) return o;
      for (var i = n.parentNode; i; ) {
        if (o = i[wa] || i[Tt]) {
          if (i = o.alternate, o.child !== null || i !== null && i.child !== null) for (n = gb(n); n !== null; ) {
            if (i = n[Tt]) return i;
            n = gb(n);
          }
          return o;
        }
        n = i, i = n.parentNode;
      }
      return null;
    }
    function xa(n) {
      if (n = n[Tt] || n[wa]) {
        var o = n.tag;
        if (o === 5 || o === 6 || o === 13 || o === 31 || o === 26 || o === 27 || o === 3) return n;
      }
      return null;
    }
    function Bi(n) {
      var o = n.tag;
      if (o === 5 || o === 26 || o === 27 || o === 6) return n.stateNode;
      throw Error(a(33));
    }
    function _a4(n) {
      var o = n[Qm];
      return o || (o = n[Qm] = { hoistableStyles: /* @__PURE__ */ new Map(), hoistableScripts: /* @__PURE__ */ new Map() }), o;
    }
    function xt(n) {
      n[Ui] = true;
    }
    var Gm = /* @__PURE__ */ new Set(), Km = {};
    function Bo(n, o) {
      Ea(n, o), Ea(n + "Capture", o);
    }
    function Ea(n, o) {
      for (Km[n] = o, n = 0; n < o.length; n++) Gm.add(o[n]);
    }
    var AA = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), Jm = {}, Wm = {};
    function CA(n) {
      return ln.call(Wm, n) ? true : ln.call(Jm, n) ? false : AA.test(n) ? Wm[n] = true : (Jm[n] = true, false);
    }
    function hl(n, o, i) {
      if (CA(o)) if (i === null) n.removeAttribute(o);
      else {
        switch (typeof i) {
          case "undefined":
          case "function":
          case "symbol":
            n.removeAttribute(o);
            return;
          case "boolean":
            var c = o.toLowerCase().slice(0, 5);
            if (c !== "data-" && c !== "aria-") {
              n.removeAttribute(o);
              return;
            }
        }
        n.setAttribute(o, "" + i);
      }
    }
    function pl(n, o, i) {
      if (i === null) n.removeAttribute(o);
      else {
        switch (typeof i) {
          case "undefined":
          case "function":
          case "symbol":
          case "boolean":
            n.removeAttribute(o);
            return;
        }
        n.setAttribute(o, "" + i);
      }
    }
    function br(n, o, i, c) {
      if (c === null) n.removeAttribute(i);
      else {
        switch (typeof c) {
          case "undefined":
          case "function":
          case "symbol":
          case "boolean":
            n.removeAttribute(i);
            return;
        }
        n.setAttributeNS(o, i, "" + c);
      }
    }
    function wn(n) {
      switch (typeof n) {
        case "bigint":
        case "boolean":
        case "number":
        case "string":
        case "undefined":
          return n;
        case "object":
          return n;
        default:
          return "";
      }
    }
    function eg(n) {
      var o = n.type;
      return (n = n.nodeName) && n.toLowerCase() === "input" && (o === "checkbox" || o === "radio");
    }
    function TA(n, o, i) {
      var c = Object.getOwnPropertyDescriptor(n.constructor.prototype, o);
      if (!n.hasOwnProperty(o) && typeof c < "u" && typeof c.get == "function" && typeof c.set == "function") {
        var d = c.get, h = c.set;
        return Object.defineProperty(n, o, { configurable: true, get: function() {
          return d.call(this);
        }, set: function(w) {
          i = "" + w, h.call(this, w);
        } }), Object.defineProperty(n, o, { enumerable: c.enumerable }), { getValue: function() {
          return i;
        }, setValue: function(w) {
          i = "" + w;
        }, stopTracking: function() {
          n._valueTracker = null, delete n[o];
        } };
      }
    }
    function df(n) {
      if (!n._valueTracker) {
        var o = eg(n) ? "checked" : "value";
        n._valueTracker = TA(n, o, "" + n[o]);
      }
    }
    function tg(n) {
      if (!n) return false;
      var o = n._valueTracker;
      if (!o) return true;
      var i = o.getValue(), c = "";
      return n && (c = eg(n) ? n.checked ? "true" : "false" : n.value), n = c, n !== i ? (o.setValue(n), true) : false;
    }
    function ml(n) {
      if (n = n || (typeof document < "u" ? document : void 0), typeof n > "u") return null;
      try {
        return n.activeElement || n.body;
      } catch {
        return n.body;
      }
    }
    var OA = /[\n"\\]/g;
    function Sn(n) {
      return n.replace(OA, function(o) {
        return "\\" + o.charCodeAt(0).toString(16) + " ";
      });
    }
    function hf(n, o, i, c, d, h, w, A) {
      n.name = "", w != null && typeof w != "function" && typeof w != "symbol" && typeof w != "boolean" ? n.type = w : n.removeAttribute("type"), o != null ? w === "number" ? (o === 0 && n.value === "" || n.value != o) && (n.value = "" + wn(o)) : n.value !== "" + wn(o) && (n.value = "" + wn(o)) : w !== "submit" && w !== "reset" || n.removeAttribute("value"), o != null ? pf(n, w, wn(o)) : i != null ? pf(n, w, wn(i)) : c != null && n.removeAttribute("value"), d == null && h != null && (n.defaultChecked = !!h), d != null && (n.checked = d && typeof d != "function" && typeof d != "symbol"), A != null && typeof A != "function" && typeof A != "symbol" && typeof A != "boolean" ? n.name = "" + wn(A) : n.removeAttribute("name");
    }
    function ng(n, o, i, c, d, h, w, A) {
      if (h != null && typeof h != "function" && typeof h != "symbol" && typeof h != "boolean" && (n.type = h), o != null || i != null) {
        if (!(h !== "submit" && h !== "reset" || o != null)) {
          df(n);
          return;
        }
        i = i != null ? "" + wn(i) : "", o = o != null ? "" + wn(o) : i, A || o === n.value || (n.value = o), n.defaultValue = o;
      }
      c = c != null ? c : d, c = typeof c != "function" && typeof c != "symbol" && !!c, n.checked = A ? n.checked : !!c, n.defaultChecked = !!c, w != null && typeof w != "function" && typeof w != "symbol" && typeof w != "boolean" && (n.name = w), df(n);
    }
    function pf(n, o, i) {
      o === "number" && ml(n.ownerDocument) === n || n.defaultValue === "" + i || (n.defaultValue = "" + i);
    }
    function Aa(n, o, i, c) {
      if (n = n.options, o) {
        o = {};
        for (var d = 0; d < i.length; d++) o["$" + i[d]] = true;
        for (i = 0; i < n.length; i++) d = o.hasOwnProperty("$" + n[i].value), n[i].selected !== d && (n[i].selected = d), d && c && (n[i].defaultSelected = true);
      } else {
        for (i = "" + wn(i), o = null, d = 0; d < n.length; d++) {
          if (n[d].value === i) {
            n[d].selected = true, c && (n[d].defaultSelected = true);
            return;
          }
          o !== null || n[d].disabled || (o = n[d]);
        }
        o !== null && (o.selected = true);
      }
    }
    function rg(n, o, i) {
      if (o != null && (o = "" + wn(o), o !== n.value && (n.value = o), i == null)) {
        n.defaultValue !== o && (n.defaultValue = o);
        return;
      }
      n.defaultValue = i != null ? "" + wn(i) : "";
    }
    function og(n, o, i, c) {
      if (o == null) {
        if (c != null) {
          if (i != null) throw Error(a(92));
          if (oe(c)) {
            if (1 < c.length) throw Error(a(93));
            c = c[0];
          }
          i = c;
        }
        i == null && (i = ""), o = i;
      }
      i = wn(o), n.defaultValue = i, c = n.textContent, c === i && c !== "" && c !== null && (n.value = c), df(n);
    }
    function Ca(n, o) {
      if (o) {
        var i = n.firstChild;
        if (i && i === n.lastChild && i.nodeType === 3) {
          i.nodeValue = o;
          return;
        }
      }
      n.textContent = o;
    }
    var RA = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));
    function ag(n, o, i) {
      var c = o.indexOf("--") === 0;
      i == null || typeof i == "boolean" || i === "" ? c ? n.setProperty(o, "") : o === "float" ? n.cssFloat = "" : n[o] = "" : c ? n.setProperty(o, i) : typeof i != "number" || i === 0 || RA.has(o) ? o === "float" ? n.cssFloat = i : n[o] = ("" + i).trim() : n[o] = i + "px";
    }
    function ig(n, o, i) {
      if (o != null && typeof o != "object") throw Error(a(62));
      if (n = n.style, i != null) {
        for (var c in i) !i.hasOwnProperty(c) || o != null && o.hasOwnProperty(c) || (c.indexOf("--") === 0 ? n.setProperty(c, "") : c === "float" ? n.cssFloat = "" : n[c] = "");
        for (var d in o) c = o[d], o.hasOwnProperty(d) && i[d] !== c && ag(n, d, c);
      } else for (var h in o) o.hasOwnProperty(h) && ag(n, h, o[h]);
    }
    function mf(n) {
      if (n.indexOf("-") === -1) return false;
      switch (n) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
          return false;
        default:
          return true;
      }
    }
    var MA = /* @__PURE__ */ new Map([["acceptCharset", "accept-charset"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"], ["crossOrigin", "crossorigin"], ["accentHeight", "accent-height"], ["alignmentBaseline", "alignment-baseline"], ["arabicForm", "arabic-form"], ["baselineShift", "baseline-shift"], ["capHeight", "cap-height"], ["clipPath", "clip-path"], ["clipRule", "clip-rule"], ["colorInterpolation", "color-interpolation"], ["colorInterpolationFilters", "color-interpolation-filters"], ["colorProfile", "color-profile"], ["colorRendering", "color-rendering"], ["dominantBaseline", "dominant-baseline"], ["enableBackground", "enable-background"], ["fillOpacity", "fill-opacity"], ["fillRule", "fill-rule"], ["floodColor", "flood-color"], ["floodOpacity", "flood-opacity"], ["fontFamily", "font-family"], ["fontSize", "font-size"], ["fontSizeAdjust", "font-size-adjust"], ["fontStretch", "font-stretch"], ["fontStyle", "font-style"], ["fontVariant", "font-variant"], ["fontWeight", "font-weight"], ["glyphName", "glyph-name"], ["glyphOrientationHorizontal", "glyph-orientation-horizontal"], ["glyphOrientationVertical", "glyph-orientation-vertical"], ["horizAdvX", "horiz-adv-x"], ["horizOriginX", "horiz-origin-x"], ["imageRendering", "image-rendering"], ["letterSpacing", "letter-spacing"], ["lightingColor", "lighting-color"], ["markerEnd", "marker-end"], ["markerMid", "marker-mid"], ["markerStart", "marker-start"], ["overlinePosition", "overline-position"], ["overlineThickness", "overline-thickness"], ["paintOrder", "paint-order"], ["panose-1", "panose-1"], ["pointerEvents", "pointer-events"], ["renderingIntent", "rendering-intent"], ["shapeRendering", "shape-rendering"], ["stopColor", "stop-color"], ["stopOpacity", "stop-opacity"], ["strikethroughPosition", "strikethrough-position"], ["strikethroughThickness", "strikethrough-thickness"], ["strokeDasharray", "stroke-dasharray"], ["strokeDashoffset", "stroke-dashoffset"], ["strokeLinecap", "stroke-linecap"], ["strokeLinejoin", "stroke-linejoin"], ["strokeMiterlimit", "stroke-miterlimit"], ["strokeOpacity", "stroke-opacity"], ["strokeWidth", "stroke-width"], ["textAnchor", "text-anchor"], ["textDecoration", "text-decoration"], ["textRendering", "text-rendering"], ["transformOrigin", "transform-origin"], ["underlinePosition", "underline-position"], ["underlineThickness", "underline-thickness"], ["unicodeBidi", "unicode-bidi"], ["unicodeRange", "unicode-range"], ["unitsPerEm", "units-per-em"], ["vAlphabetic", "v-alphabetic"], ["vHanging", "v-hanging"], ["vIdeographic", "v-ideographic"], ["vMathematical", "v-mathematical"], ["vectorEffect", "vector-effect"], ["vertAdvY", "vert-adv-y"], ["vertOriginX", "vert-origin-x"], ["vertOriginY", "vert-origin-y"], ["wordSpacing", "word-spacing"], ["writingMode", "writing-mode"], ["xmlnsXlink", "xmlns:xlink"], ["xHeight", "x-height"]]), NA = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
    function gl(n) {
      return NA.test("" + n) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : n;
    }
    function wr() {
    }
    var gf = null;
    function vf(n) {
      return n = n.target || n.srcElement || window, n.correspondingUseElement && (n = n.correspondingUseElement), n.nodeType === 3 ? n.parentNode : n;
    }
    var Ta = null, Oa = null;
    function sg(n) {
      var o = xa(n);
      if (o && (n = o.stateNode)) {
        var i = n[Xt] || null;
        e: switch (n = o.stateNode, o.type) {
          case "input":
            if (hf(n, i.value, i.defaultValue, i.defaultValue, i.checked, i.defaultChecked, i.type, i.name), o = i.name, i.type === "radio" && o != null) {
              for (i = n; i.parentNode; ) i = i.parentNode;
              for (i = i.querySelectorAll('input[name="' + Sn("" + o) + '"][type="radio"]'), o = 0; o < i.length; o++) {
                var c = i[o];
                if (c !== n && c.form === n.form) {
                  var d = c[Xt] || null;
                  if (!d) throw Error(a(90));
                  hf(c, d.value, d.defaultValue, d.defaultValue, d.checked, d.defaultChecked, d.type, d.name);
                }
              }
              for (o = 0; o < i.length; o++) c = i[o], c.form === n.form && tg(c);
            }
            break e;
          case "textarea":
            rg(n, i.value, i.defaultValue);
            break e;
          case "select":
            o = i.value, o != null && Aa(n, !!i.multiple, o, false);
        }
      }
    }
    var yf = false;
    function lg(n, o, i) {
      if (yf) return n(o, i);
      yf = true;
      try {
        var c = n(o);
        return c;
      } finally {
        if (yf = false, (Ta !== null || Oa !== null) && (rc(), Ta && (o = Ta, n = Oa, Oa = Ta = null, sg(o), n))) for (o = 0; o < n.length; o++) sg(n[o]);
      }
    }
    function Ii(n, o) {
      var i = n.stateNode;
      if (i === null) return null;
      var c = i[Xt] || null;
      if (c === null) return null;
      i = c[o];
      e: switch (o) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          (c = !c.disabled) || (n = n.type, c = !(n === "button" || n === "input" || n === "select" || n === "textarea")), n = !c;
          break e;
        default:
          n = false;
      }
      if (n) return null;
      if (i && typeof i != "function") throw Error(a(231, o, typeof i));
      return i;
    }
    var Sr = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), bf = false;
    if (Sr) try {
      var Hi = {};
      Object.defineProperty(Hi, "passive", { get: function() {
        bf = true;
      } }), window.addEventListener("test", Hi, Hi), window.removeEventListener("test", Hi, Hi);
    } catch {
      bf = false;
    }
    var Gr = null, wf = null, vl = null;
    function cg() {
      if (vl) return vl;
      var n, o = wf, i = o.length, c, d = "value" in Gr ? Gr.value : Gr.textContent, h = d.length;
      for (n = 0; n < i && o[n] === d[n]; n++) ;
      var w = i - n;
      for (c = 1; c <= w && o[i - c] === d[h - c]; c++) ;
      return vl = d.slice(n, 1 < c ? 1 - c : void 0);
    }
    function yl(n) {
      var o = n.keyCode;
      return "charCode" in n ? (n = n.charCode, n === 0 && o === 13 && (n = 13)) : n = o, n === 10 && (n = 13), 32 <= n || n === 13 ? n : 0;
    }
    function bl() {
      return true;
    }
    function ug() {
      return false;
    }
    function Qt(n) {
      function o(i, c, d, h, w) {
        this._reactName = i, this._targetInst = d, this.type = c, this.nativeEvent = h, this.target = w, this.currentTarget = null;
        for (var A in n) n.hasOwnProperty(A) && (i = n[A], this[A] = i ? i(h) : h[A]);
        return this.isDefaultPrevented = (h.defaultPrevented != null ? h.defaultPrevented : h.returnValue === false) ? bl : ug, this.isPropagationStopped = ug, this;
      }
      return g(o.prototype, { preventDefault: function() {
        this.defaultPrevented = true;
        var i = this.nativeEvent;
        i && (i.preventDefault ? i.preventDefault() : typeof i.returnValue != "unknown" && (i.returnValue = false), this.isDefaultPrevented = bl);
      }, stopPropagation: function() {
        var i = this.nativeEvent;
        i && (i.stopPropagation ? i.stopPropagation() : typeof i.cancelBubble != "unknown" && (i.cancelBubble = true), this.isPropagationStopped = bl);
      }, persist: function() {
      }, isPersistent: bl }), o;
    }
    var Io = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(n) {
      return n.timeStamp || Date.now();
    }, defaultPrevented: 0, isTrusted: 0 }, wl = Qt(Io), $i = g({}, Io, { view: 0, detail: 0 }), zA = Qt($i), Sf, xf, Vi, Sl = g({}, $i, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: Ef, button: 0, buttons: 0, relatedTarget: function(n) {
      return n.relatedTarget === void 0 ? n.fromElement === n.srcElement ? n.toElement : n.fromElement : n.relatedTarget;
    }, movementX: function(n) {
      return "movementX" in n ? n.movementX : (n !== Vi && (Vi && n.type === "mousemove" ? (Sf = n.screenX - Vi.screenX, xf = n.screenY - Vi.screenY) : xf = Sf = 0, Vi = n), Sf);
    }, movementY: function(n) {
      return "movementY" in n ? n.movementY : xf;
    } }), fg = Qt(Sl), DA = g({}, Sl, { dataTransfer: 0 }), jA = Qt(DA), kA = g({}, $i, { relatedTarget: 0 }), _f2 = Qt(kA), PA = g({}, Io, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), LA = Qt(PA), UA = g({}, Io, { clipboardData: function(n) {
      return "clipboardData" in n ? n.clipboardData : window.clipboardData;
    } }), BA = Qt(UA), IA = g({}, Io, { data: 0 }), dg = Qt(IA), HA = { Esc: "Escape", Spacebar: " ", Left: "ArrowLeft", Up: "ArrowUp", Right: "ArrowRight", Down: "ArrowDown", Del: "Delete", Win: "OS", Menu: "ContextMenu", Apps: "ContextMenu", Scroll: "ScrollLock", MozPrintableKey: "Unidentified" }, $A = { 8: "Backspace", 9: "Tab", 12: "Clear", 13: "Enter", 16: "Shift", 17: "Control", 18: "Alt", 19: "Pause", 20: "CapsLock", 27: "Escape", 32: " ", 33: "PageUp", 34: "PageDown", 35: "End", 36: "Home", 37: "ArrowLeft", 38: "ArrowUp", 39: "ArrowRight", 40: "ArrowDown", 45: "Insert", 46: "Delete", 112: "F1", 113: "F2", 114: "F3", 115: "F4", 116: "F5", 117: "F6", 118: "F7", 119: "F8", 120: "F9", 121: "F10", 122: "F11", 123: "F12", 144: "NumLock", 145: "ScrollLock", 224: "Meta" }, VA = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
    function ZA(n) {
      var o = this.nativeEvent;
      return o.getModifierState ? o.getModifierState(n) : (n = VA[n]) ? !!o[n] : false;
    }
    function Ef() {
      return ZA;
    }
    var FA = g({}, $i, { key: function(n) {
      if (n.key) {
        var o = HA[n.key] || n.key;
        if (o !== "Unidentified") return o;
      }
      return n.type === "keypress" ? (n = yl(n), n === 13 ? "Enter" : String.fromCharCode(n)) : n.type === "keydown" || n.type === "keyup" ? $A[n.keyCode] || "Unidentified" : "";
    }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: Ef, charCode: function(n) {
      return n.type === "keypress" ? yl(n) : 0;
    }, keyCode: function(n) {
      return n.type === "keydown" || n.type === "keyup" ? n.keyCode : 0;
    }, which: function(n) {
      return n.type === "keypress" ? yl(n) : n.type === "keydown" || n.type === "keyup" ? n.keyCode : 0;
    } }), qA = Qt(FA), YA = g({}, Sl, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), hg = Qt(YA), XA = g({}, $i, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: Ef }), QA = Qt(XA), GA = g({}, Io, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), KA = Qt(GA), JA = g({}, Sl, { deltaX: function(n) {
      return "deltaX" in n ? n.deltaX : "wheelDeltaX" in n ? -n.wheelDeltaX : 0;
    }, deltaY: function(n) {
      return "deltaY" in n ? n.deltaY : "wheelDeltaY" in n ? -n.wheelDeltaY : "wheelDelta" in n ? -n.wheelDelta : 0;
    }, deltaZ: 0, deltaMode: 0 }), WA = Qt(JA), eC = g({}, Io, { newState: 0, oldState: 0 }), tC = Qt(eC), nC = [9, 13, 27, 32], Af = Sr && "CompositionEvent" in window, Zi = null;
    Sr && "documentMode" in document && (Zi = document.documentMode);
    var rC = Sr && "TextEvent" in window && !Zi, pg = Sr && (!Af || Zi && 8 < Zi && 11 >= Zi), mg = " ", gg = false;
    function vg(n, o) {
      switch (n) {
        case "keyup":
          return nC.indexOf(o.keyCode) !== -1;
        case "keydown":
          return o.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
          return true;
        default:
          return false;
      }
    }
    function yg(n) {
      return n = n.detail, typeof n == "object" && "data" in n ? n.data : null;
    }
    var Ra = false;
    function oC(n, o) {
      switch (n) {
        case "compositionend":
          return yg(o);
        case "keypress":
          return o.which !== 32 ? null : (gg = true, mg);
        case "textInput":
          return n = o.data, n === mg && gg ? null : n;
        default:
          return null;
      }
    }
    function aC(n, o) {
      if (Ra) return n === "compositionend" || !Af && vg(n, o) ? (n = cg(), vl = wf = Gr = null, Ra = false, n) : null;
      switch (n) {
        case "paste":
          return null;
        case "keypress":
          if (!(o.ctrlKey || o.altKey || o.metaKey) || o.ctrlKey && o.altKey) {
            if (o.char && 1 < o.char.length) return o.char;
            if (o.which) return String.fromCharCode(o.which);
          }
          return null;
        case "compositionend":
          return pg && o.locale !== "ko" ? null : o.data;
        default:
          return null;
      }
    }
    var iC = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
    function bg(n) {
      var o = n && n.nodeName && n.nodeName.toLowerCase();
      return o === "input" ? !!iC[n.type] : o === "textarea";
    }
    function wg(n, o, i, c) {
      Ta ? Oa ? Oa.push(c) : Oa = [c] : Ta = c, o = uc(o, "onChange"), 0 < o.length && (i = new wl("onChange", "change", null, i, c), n.push({ event: i, listeners: o }));
    }
    var Fi = null, qi = null;
    function sC(n) {
      nb(n, 0);
    }
    function xl(n) {
      var o = Bi(n);
      if (tg(o)) return n;
    }
    function Sg(n, o) {
      if (n === "change") return o;
    }
    var xg = false;
    if (Sr) {
      var Cf;
      if (Sr) {
        var Tf = "oninput" in document;
        if (!Tf) {
          var _g2 = document.createElement("div");
          _g2.setAttribute("oninput", "return;"), Tf = typeof _g2.oninput == "function";
        }
        Cf = Tf;
      } else Cf = false;
      xg = Cf && (!document.documentMode || 9 < document.documentMode);
    }
    function Eg() {
      Fi && (Fi.detachEvent("onpropertychange", Ag), qi = Fi = null);
    }
    function Ag(n) {
      if (n.propertyName === "value" && xl(qi)) {
        var o = [];
        wg(o, qi, n, vf(n)), lg(sC, o);
      }
    }
    function lC(n, o, i) {
      n === "focusin" ? (Eg(), Fi = o, qi = i, Fi.attachEvent("onpropertychange", Ag)) : n === "focusout" && Eg();
    }
    function cC(n) {
      if (n === "selectionchange" || n === "keyup" || n === "keydown") return xl(qi);
    }
    function uC(n, o) {
      if (n === "click") return xl(o);
    }
    function fC(n, o) {
      if (n === "input" || n === "change") return xl(o);
    }
    function dC(n, o) {
      return n === o && (n !== 0 || 1 / n === 1 / o) || n !== n && o !== o;
    }
    var cn = typeof Object.is == "function" ? Object.is : dC;
    function Yi(n, o) {
      if (cn(n, o)) return true;
      if (typeof n != "object" || n === null || typeof o != "object" || o === null) return false;
      var i = Object.keys(n), c = Object.keys(o);
      if (i.length !== c.length) return false;
      for (c = 0; c < i.length; c++) {
        var d = i[c];
        if (!ln.call(o, d) || !cn(n[d], o[d])) return false;
      }
      return true;
    }
    function Cg(n) {
      for (; n && n.firstChild; ) n = n.firstChild;
      return n;
    }
    function Tg(n, o) {
      var i = Cg(n);
      n = 0;
      for (var c; i; ) {
        if (i.nodeType === 3) {
          if (c = n + i.textContent.length, n <= o && c >= o) return { node: i, offset: o - n };
          n = c;
        }
        e: {
          for (; i; ) {
            if (i.nextSibling) {
              i = i.nextSibling;
              break e;
            }
            i = i.parentNode;
          }
          i = void 0;
        }
        i = Cg(i);
      }
    }
    function Og(n, o) {
      return n && o ? n === o ? true : n && n.nodeType === 3 ? false : o && o.nodeType === 3 ? Og(n, o.parentNode) : "contains" in n ? n.contains(o) : n.compareDocumentPosition ? !!(n.compareDocumentPosition(o) & 16) : false : false;
    }
    function Rg(n) {
      n = n != null && n.ownerDocument != null && n.ownerDocument.defaultView != null ? n.ownerDocument.defaultView : window;
      for (var o = ml(n.document); o instanceof n.HTMLIFrameElement; ) {
        try {
          var i = typeof o.contentWindow.location.href == "string";
        } catch {
          i = false;
        }
        if (i) n = o.contentWindow;
        else break;
        o = ml(n.document);
      }
      return o;
    }
    function Of(n) {
      var o = n && n.nodeName && n.nodeName.toLowerCase();
      return o && (o === "input" && (n.type === "text" || n.type === "search" || n.type === "tel" || n.type === "url" || n.type === "password") || o === "textarea" || n.contentEditable === "true");
    }
    var hC = Sr && "documentMode" in document && 11 >= document.documentMode, Ma = null, Rf = null, Xi = null, Mf = false;
    function Mg(n, o, i) {
      var c = i.window === i ? i.document : i.nodeType === 9 ? i : i.ownerDocument;
      Mf || Ma == null || Ma !== ml(c) || (c = Ma, "selectionStart" in c && Of(c) ? c = { start: c.selectionStart, end: c.selectionEnd } : (c = (c.ownerDocument && c.ownerDocument.defaultView || window).getSelection(), c = { anchorNode: c.anchorNode, anchorOffset: c.anchorOffset, focusNode: c.focusNode, focusOffset: c.focusOffset }), Xi && Yi(Xi, c) || (Xi = c, c = uc(Rf, "onSelect"), 0 < c.length && (o = new wl("onSelect", "select", null, o, i), n.push({ event: o, listeners: c }), o.target = Ma)));
    }
    function Ho(n, o) {
      var i = {};
      return i[n.toLowerCase()] = o.toLowerCase(), i["Webkit" + n] = "webkit" + o, i["Moz" + n] = "moz" + o, i;
    }
    var Na = { animationend: Ho("Animation", "AnimationEnd"), animationiteration: Ho("Animation", "AnimationIteration"), animationstart: Ho("Animation", "AnimationStart"), transitionrun: Ho("Transition", "TransitionRun"), transitionstart: Ho("Transition", "TransitionStart"), transitioncancel: Ho("Transition", "TransitionCancel"), transitionend: Ho("Transition", "TransitionEnd") }, Nf = {}, Ng = {};
    Sr && (Ng = document.createElement("div").style, "AnimationEvent" in window || (delete Na.animationend.animation, delete Na.animationiteration.animation, delete Na.animationstart.animation), "TransitionEvent" in window || delete Na.transitionend.transition);
    function $o(n) {
      if (Nf[n]) return Nf[n];
      if (!Na[n]) return n;
      var o = Na[n], i;
      for (i in o) if (o.hasOwnProperty(i) && i in Ng) return Nf[n] = o[i];
      return n;
    }
    var zg = $o("animationend"), Dg = $o("animationiteration"), jg = $o("animationstart"), pC = $o("transitionrun"), mC = $o("transitionstart"), gC = $o("transitioncancel"), kg = $o("transitionend"), Pg = /* @__PURE__ */ new Map(), zf = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
    zf.push("scrollEnd");
    function Ln(n, o) {
      Pg.set(n, o), Bo(o, [n]);
    }
    var _l3 = typeof reportError == "function" ? reportError : function(n) {
      if (typeof window == "object" && typeof window.ErrorEvent == "function") {
        var o = new window.ErrorEvent("error", { bubbles: true, cancelable: true, message: typeof n == "object" && n !== null && typeof n.message == "string" ? String(n.message) : String(n), error: n });
        if (!window.dispatchEvent(o)) return;
      } else if (typeof process == "object" && typeof process.emit == "function") {
        process.emit("uncaughtException", n);
        return;
      }
      console.error(n);
    }, xn = [], za = 0, Df = 0;
    function El() {
      for (var n = za, o = Df = za = 0; o < n; ) {
        var i = xn[o];
        xn[o++] = null;
        var c = xn[o];
        xn[o++] = null;
        var d = xn[o];
        xn[o++] = null;
        var h = xn[o];
        if (xn[o++] = null, c !== null && d !== null) {
          var w = c.pending;
          w === null ? d.next = d : (d.next = w.next, w.next = d), c.pending = d;
        }
        h !== 0 && Lg(i, d, h);
      }
    }
    function Al(n, o, i, c) {
      xn[za++] = n, xn[za++] = o, xn[za++] = i, xn[za++] = c, Df |= c, n.lanes |= c, n = n.alternate, n !== null && (n.lanes |= c);
    }
    function jf(n, o, i, c) {
      return Al(n, o, i, c), Cl(n);
    }
    function Vo(n, o) {
      return Al(n, null, null, o), Cl(n);
    }
    function Lg(n, o, i) {
      n.lanes |= i;
      var c = n.alternate;
      c !== null && (c.lanes |= i);
      for (var d = false, h = n.return; h !== null; ) h.childLanes |= i, c = h.alternate, c !== null && (c.childLanes |= i), h.tag === 22 && (n = h.stateNode, n === null || n._visibility & 1 || (d = true)), n = h, h = h.return;
      return n.tag === 3 ? (h = n.stateNode, d && o !== null && (d = 31 - kt(i), n = h.hiddenUpdates, c = n[d], c === null ? n[d] = [o] : c.push(o), o.lane = i | 536870912), h) : null;
    }
    function Cl(n) {
      if (50 < gs) throw gs = 0, Vd = null, Error(a(185));
      for (var o = n.return; o !== null; ) n = o, o = n.return;
      return n.tag === 3 ? n.stateNode : null;
    }
    var Da = {};
    function vC(n, o, i, c) {
      this.tag = n, this.key = i, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = o, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = c, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
    }
    function un(n, o, i, c) {
      return new vC(n, o, i, c);
    }
    function kf(n) {
      return n = n.prototype, !(!n || !n.isReactComponent);
    }
    function xr(n, o) {
      var i = n.alternate;
      return i === null ? (i = un(n.tag, o, n.key, n.mode), i.elementType = n.elementType, i.type = n.type, i.stateNode = n.stateNode, i.alternate = n, n.alternate = i) : (i.pendingProps = o, i.type = n.type, i.flags = 0, i.subtreeFlags = 0, i.deletions = null), i.flags = n.flags & 65011712, i.childLanes = n.childLanes, i.lanes = n.lanes, i.child = n.child, i.memoizedProps = n.memoizedProps, i.memoizedState = n.memoizedState, i.updateQueue = n.updateQueue, o = n.dependencies, i.dependencies = o === null ? null : { lanes: o.lanes, firstContext: o.firstContext }, i.sibling = n.sibling, i.index = n.index, i.ref = n.ref, i.refCleanup = n.refCleanup, i;
    }
    function Ug(n, o) {
      n.flags &= 65011714;
      var i = n.alternate;
      return i === null ? (n.childLanes = 0, n.lanes = o, n.child = null, n.subtreeFlags = 0, n.memoizedProps = null, n.memoizedState = null, n.updateQueue = null, n.dependencies = null, n.stateNode = null) : (n.childLanes = i.childLanes, n.lanes = i.lanes, n.child = i.child, n.subtreeFlags = 0, n.deletions = null, n.memoizedProps = i.memoizedProps, n.memoizedState = i.memoizedState, n.updateQueue = i.updateQueue, n.type = i.type, o = i.dependencies, n.dependencies = o === null ? null : { lanes: o.lanes, firstContext: o.firstContext }), n;
    }
    function Tl(n, o, i, c, d, h) {
      var w = 0;
      if (c = n, typeof n == "function") kf(n) && (w = 1);
      else if (typeof n == "string") w = xT(n, i, J.current) ? 26 : n === "html" || n === "head" || n === "body" ? 27 : 5;
      else e: switch (n) {
        case re:
          return n = un(31, i, o, d), n.elementType = re, n.lanes = h, n;
        case E:
          return Zo(i.children, d, h, o);
        case C:
          w = 8, d |= 24;
          break;
        case T:
          return n = un(12, i, o, d | 2), n.elementType = T, n.lanes = h, n;
        case P:
          return n = un(13, i, o, d), n.elementType = P, n.lanes = h, n;
        case L:
          return n = un(19, i, o, d), n.elementType = L, n.lanes = h, n;
        default:
          if (typeof n == "object" && n !== null) switch (n.$$typeof) {
            case O:
              w = 10;
              break e;
            case R:
              w = 9;
              break e;
            case D:
              w = 11;
              break e;
            case k:
              w = 14;
              break e;
            case $:
              w = 16, c = null;
              break e;
          }
          w = 29, i = Error(a(130, n === null ? "null" : typeof n, "")), c = null;
      }
      return o = un(w, i, o, d), o.elementType = n, o.type = c, o.lanes = h, o;
    }
    function Zo(n, o, i, c) {
      return n = un(7, n, c, o), n.lanes = i, n;
    }
    function Pf(n, o, i) {
      return n = un(6, n, null, o), n.lanes = i, n;
    }
    function Bg(n) {
      var o = un(18, null, null, 0);
      return o.stateNode = n, o;
    }
    function Lf(n, o, i) {
      return o = un(4, n.children !== null ? n.children : [], n.key, o), o.lanes = i, o.stateNode = { containerInfo: n.containerInfo, pendingChildren: null, implementation: n.implementation }, o;
    }
    var Ig = /* @__PURE__ */ new WeakMap();
    function _n8(n, o) {
      if (typeof n == "object" && n !== null) {
        var i = Ig.get(n);
        return i !== void 0 ? i : (o = { value: n, source: o, stack: Di(o) }, Ig.set(n, o), o);
      }
      return { value: n, source: o, stack: Di(o) };
    }
    var ja = [], ka = 0, Ol = null, Qi = 0, En = [], An = 0, Kr = null, Jn = 1, Wn = "";
    function _r4(n, o) {
      ja[ka++] = Qi, ja[ka++] = Ol, Ol = n, Qi = o;
    }
    function Hg(n, o, i) {
      En[An++] = Jn, En[An++] = Wn, En[An++] = Kr, Kr = n;
      var c = Jn;
      n = Wn;
      var d = 32 - kt(c) - 1;
      c &= ~(1 << d), i += 1;
      var h = 32 - kt(o) + d;
      if (30 < h) {
        var w = d - d % 5;
        h = (c & (1 << w) - 1).toString(32), c >>= w, d -= w, Jn = 1 << 32 - kt(o) + d | i << d | c, Wn = h + n;
      } else Jn = 1 << h | i << d | c, Wn = n;
    }
    function Uf(n) {
      n.return !== null && (_r4(n, 1), Hg(n, 1, 0));
    }
    function Bf(n) {
      for (; n === Ol; ) Ol = ja[--ka], ja[ka] = null, Qi = ja[--ka], ja[ka] = null;
      for (; n === Kr; ) Kr = En[--An], En[An] = null, Wn = En[--An], En[An] = null, Jn = En[--An], En[An] = null;
    }
    function $g(n, o) {
      En[An++] = Jn, En[An++] = Wn, En[An++] = Kr, Jn = o.id, Wn = o.overflow, Kr = n;
    }
    var Ot = null, Je = null, Ie = false, Jr = null, Cn = false, If = Error(a(519));
    function Wr(n) {
      var o = Error(a(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML", ""));
      throw Gi(_n8(o, n)), If;
    }
    function Vg(n) {
      var o = n.stateNode, i = n.type, c = n.memoizedProps;
      switch (o[Tt] = n, o[Xt] = c, i) {
        case "dialog":
          ke("cancel", o), ke("close", o);
          break;
        case "iframe":
        case "object":
        case "embed":
          ke("load", o);
          break;
        case "video":
        case "audio":
          for (i = 0; i < ys.length; i++) ke(ys[i], o);
          break;
        case "source":
          ke("error", o);
          break;
        case "img":
        case "image":
        case "link":
          ke("error", o), ke("load", o);
          break;
        case "details":
          ke("toggle", o);
          break;
        case "input":
          ke("invalid", o), ng(o, c.value, c.defaultValue, c.checked, c.defaultChecked, c.type, c.name, true);
          break;
        case "select":
          ke("invalid", o);
          break;
        case "textarea":
          ke("invalid", o), og(o, c.value, c.defaultValue, c.children);
      }
      i = c.children, typeof i != "string" && typeof i != "number" && typeof i != "bigint" || o.textContent === "" + i || c.suppressHydrationWarning === true || ib(o.textContent, i) ? (c.popover != null && (ke("beforetoggle", o), ke("toggle", o)), c.onScroll != null && ke("scroll", o), c.onScrollEnd != null && ke("scrollend", o), c.onClick != null && (o.onclick = wr), o = true) : o = false, o || Wr(n, true);
    }
    function Zg(n) {
      for (Ot = n.return; Ot; ) switch (Ot.tag) {
        case 5:
        case 31:
        case 13:
          Cn = false;
          return;
        case 27:
        case 3:
          Cn = true;
          return;
        default:
          Ot = Ot.return;
      }
    }
    function Pa(n) {
      if (n !== Ot) return false;
      if (!Ie) return Zg(n), Ie = true, false;
      var o = n.tag, i;
      if ((i = o !== 3 && o !== 27) && ((i = o === 5) && (i = n.type, i = !(i !== "form" && i !== "button") || oh(n.type, n.memoizedProps)), i = !i), i && Je && Wr(n), Zg(n), o === 13) {
        if (n = n.memoizedState, n = n !== null ? n.dehydrated : null, !n) throw Error(a(317));
        Je = mb(n);
      } else if (o === 31) {
        if (n = n.memoizedState, n = n !== null ? n.dehydrated : null, !n) throw Error(a(317));
        Je = mb(n);
      } else o === 27 ? (o = Je, po(n.type) ? (n = ch, ch = null, Je = n) : Je = o) : Je = Ot ? On(n.stateNode.nextSibling) : null;
      return true;
    }
    function Fo() {
      Je = Ot = null, Ie = false;
    }
    function Hf() {
      var n = Jr;
      return n !== null && (Wt === null ? Wt = n : Wt.push.apply(Wt, n), Jr = null), n;
    }
    function Gi(n) {
      Jr === null ? Jr = [n] : Jr.push(n);
    }
    var $f = M(null), qo = null, Er = null;
    function eo(n, o, i) {
      X($f, o._currentValue), o._currentValue = i;
    }
    function Ar(n) {
      n._currentValue = $f.current, F($f);
    }
    function Vf(n, o, i) {
      for (; n !== null; ) {
        var c = n.alternate;
        if ((n.childLanes & o) !== o ? (n.childLanes |= o, c !== null && (c.childLanes |= o)) : c !== null && (c.childLanes & o) !== o && (c.childLanes |= o), n === i) break;
        n = n.return;
      }
    }
    function Zf(n, o, i, c) {
      var d = n.child;
      for (d !== null && (d.return = n); d !== null; ) {
        var h = d.dependencies;
        if (h !== null) {
          var w = d.child;
          h = h.firstContext;
          e: for (; h !== null; ) {
            var A = h;
            h = d;
            for (var z = 0; z < o.length; z++) if (A.context === o[z]) {
              h.lanes |= i, A = h.alternate, A !== null && (A.lanes |= i), Vf(h.return, i, n), c || (w = null);
              break e;
            }
            h = A.next;
          }
        } else if (d.tag === 18) {
          if (w = d.return, w === null) throw Error(a(341));
          w.lanes |= i, h = w.alternate, h !== null && (h.lanes |= i), Vf(w, i, n), w = null;
        } else w = d.child;
        if (w !== null) w.return = d;
        else for (w = d; w !== null; ) {
          if (w === n) {
            w = null;
            break;
          }
          if (d = w.sibling, d !== null) {
            d.return = w.return, w = d;
            break;
          }
          w = w.return;
        }
        d = w;
      }
    }
    function La(n, o, i, c) {
      n = null;
      for (var d = o, h = false; d !== null; ) {
        if (!h) {
          if ((d.flags & 524288) !== 0) h = true;
          else if ((d.flags & 262144) !== 0) break;
        }
        if (d.tag === 10) {
          var w = d.alternate;
          if (w === null) throw Error(a(387));
          if (w = w.memoizedProps, w !== null) {
            var A = d.type;
            cn(d.pendingProps.value, w.value) || (n !== null ? n.push(A) : n = [A]);
          }
        } else if (d === ne.current) {
          if (w = d.alternate, w === null) throw Error(a(387));
          w.memoizedState.memoizedState !== d.memoizedState.memoizedState && (n !== null ? n.push(_s4) : n = [_s4]);
        }
        d = d.return;
      }
      n !== null && Zf(o, n, i, c), o.flags |= 262144;
    }
    function Rl(n) {
      for (n = n.firstContext; n !== null; ) {
        if (!cn(n.context._currentValue, n.memoizedValue)) return true;
        n = n.next;
      }
      return false;
    }
    function Yo(n) {
      qo = n, Er = null, n = n.dependencies, n !== null && (n.firstContext = null);
    }
    function Rt(n) {
      return Fg(qo, n);
    }
    function Ml(n, o) {
      return qo === null && Yo(n), Fg(n, o);
    }
    function Fg(n, o) {
      var i = o._currentValue;
      if (o = { context: o, memoizedValue: i, next: null }, Er === null) {
        if (n === null) throw Error(a(308));
        Er = o, n.dependencies = { lanes: 0, firstContext: o }, n.flags |= 524288;
      } else Er = Er.next = o;
      return i;
    }
    var yC = typeof AbortController < "u" ? AbortController : function() {
      var n = [], o = this.signal = { aborted: false, addEventListener: function(i, c) {
        n.push(c);
      } };
      this.abort = function() {
        o.aborted = true, n.forEach(function(i) {
          return i();
        });
      };
    }, bC = e.unstable_scheduleCallback, wC = e.unstable_NormalPriority, pt = { $$typeof: O, Consumer: null, Provider: null, _currentValue: null, _currentValue2: null, _threadCount: 0 };
    function Ff() {
      return { controller: new yC(), data: /* @__PURE__ */ new Map(), refCount: 0 };
    }
    function Ki(n) {
      n.refCount--, n.refCount === 0 && bC(wC, function() {
        n.controller.abort();
      });
    }
    var Ji = null, qf = 0, Ua = 0, Ba = null;
    function SC(n, o) {
      if (Ji === null) {
        var i = Ji = [];
        qf = 0, Ua = Qd(), Ba = { status: "pending", value: void 0, then: function(c) {
          i.push(c);
        } };
      }
      return qf++, o.then(qg, qg), o;
    }
    function qg() {
      if (--qf === 0 && Ji !== null) {
        Ba !== null && (Ba.status = "fulfilled");
        var n = Ji;
        Ji = null, Ua = 0, Ba = null;
        for (var o = 0; o < n.length; o++) (0, n[o])();
      }
    }
    function xC(n, o) {
      var i = [], c = { status: "pending", value: null, reason: null, then: function(d) {
        i.push(d);
      } };
      return n.then(function() {
        c.status = "fulfilled", c.value = o;
        for (var d = 0; d < i.length; d++) (0, i[d])(o);
      }, function(d) {
        for (c.status = "rejected", c.reason = d, d = 0; d < i.length; d++) (0, i[d])(void 0);
      }), c;
    }
    var Yg = N.S;
    N.S = function(n, o) {
      My = Ht(), typeof o == "object" && o !== null && typeof o.then == "function" && SC(n, o), Yg !== null && Yg(n, o);
    };
    var Xo = M(null);
    function Yf() {
      var n = Xo.current;
      return n !== null ? n : Ke.pooledCache;
    }
    function Nl(n, o) {
      o === null ? X(Xo, Xo.current) : X(Xo, o.pool);
    }
    function Xg() {
      var n = Yf();
      return n === null ? null : { parent: pt._currentValue, pool: n };
    }
    var Ia = Error(a(460)), Xf = Error(a(474)), zl = Error(a(542)), Dl = { then: function() {
    } };
    function Qg(n) {
      return n = n.status, n === "fulfilled" || n === "rejected";
    }
    function Gg(n, o, i) {
      switch (i = n[i], i === void 0 ? n.push(o) : i !== o && (o.then(wr, wr), o = i), o.status) {
        case "fulfilled":
          return o.value;
        case "rejected":
          throw n = o.reason, Jg(n), n;
        default:
          if (typeof o.status == "string") o.then(wr, wr);
          else {
            if (n = Ke, n !== null && 100 < n.shellSuspendCounter) throw Error(a(482));
            n = o, n.status = "pending", n.then(function(c) {
              if (o.status === "pending") {
                var d = o;
                d.status = "fulfilled", d.value = c;
              }
            }, function(c) {
              if (o.status === "pending") {
                var d = o;
                d.status = "rejected", d.reason = c;
              }
            });
          }
          switch (o.status) {
            case "fulfilled":
              return o.value;
            case "rejected":
              throw n = o.reason, Jg(n), n;
          }
          throw Go = o, Ia;
      }
    }
    function Qo(n) {
      try {
        var o = n._init;
        return o(n._payload);
      } catch (i) {
        throw i !== null && typeof i == "object" && typeof i.then == "function" ? (Go = i, Ia) : i;
      }
    }
    var Go = null;
    function Kg() {
      if (Go === null) throw Error(a(459));
      var n = Go;
      return Go = null, n;
    }
    function Jg(n) {
      if (n === Ia || n === zl) throw Error(a(483));
    }
    var Ha = null, Wi = 0;
    function jl(n) {
      var o = Wi;
      return Wi += 1, Ha === null && (Ha = []), Gg(Ha, n, o);
    }
    function es(n, o) {
      o = o.props.ref, n.ref = o !== void 0 ? o : null;
    }
    function kl(n, o) {
      throw o.$$typeof === S ? Error(a(525)) : (n = Object.prototype.toString.call(o), Error(a(31, n === "[object Object]" ? "object with keys {" + Object.keys(o).join(", ") + "}" : n)));
    }
    function Wg(n) {
      function o(U, j) {
        if (n) {
          var I = U.deletions;
          I === null ? (U.deletions = [j], U.flags |= 16) : I.push(j);
        }
      }
      function i(U, j) {
        if (!n) return null;
        for (; j !== null; ) o(U, j), j = j.sibling;
        return null;
      }
      function c(U) {
        for (var j = /* @__PURE__ */ new Map(); U !== null; ) U.key !== null ? j.set(U.key, U) : j.set(U.index, U), U = U.sibling;
        return j;
      }
      function d(U, j) {
        return U = xr(U, j), U.index = 0, U.sibling = null, U;
      }
      function h(U, j, I) {
        return U.index = I, n ? (I = U.alternate, I !== null ? (I = I.index, I < j ? (U.flags |= 67108866, j) : I) : (U.flags |= 67108866, j)) : (U.flags |= 1048576, j);
      }
      function w(U) {
        return n && U.alternate === null && (U.flags |= 67108866), U;
      }
      function A(U, j, I, K) {
        return j === null || j.tag !== 6 ? (j = Pf(I, U.mode, K), j.return = U, j) : (j = d(j, I), j.return = U, j);
      }
      function z(U, j, I, K) {
        var ye = I.type;
        return ye === E ? Q(U, j, I.props.children, K, I.key) : j !== null && (j.elementType === ye || typeof ye == "object" && ye !== null && ye.$$typeof === $ && Qo(ye) === j.type) ? (j = d(j, I.props), es(j, I), j.return = U, j) : (j = Tl(I.type, I.key, I.props, null, U.mode, K), es(j, I), j.return = U, j);
      }
      function H(U, j, I, K) {
        return j === null || j.tag !== 4 || j.stateNode.containerInfo !== I.containerInfo || j.stateNode.implementation !== I.implementation ? (j = Lf(I, U.mode, K), j.return = U, j) : (j = d(j, I.children || []), j.return = U, j);
      }
      function Q(U, j, I, K, ye) {
        return j === null || j.tag !== 7 ? (j = Zo(I, U.mode, K, ye), j.return = U, j) : (j = d(j, I), j.return = U, j);
      }
      function ee(U, j, I) {
        if (typeof j == "string" && j !== "" || typeof j == "number" || typeof j == "bigint") return j = Pf("" + j, U.mode, I), j.return = U, j;
        if (typeof j == "object" && j !== null) {
          switch (j.$$typeof) {
            case _:
              return I = Tl(j.type, j.key, j.props, null, U.mode, I), es(I, j), I.return = U, I;
            case x:
              return j = Lf(j, U.mode, I), j.return = U, j;
            case $:
              return j = Qo(j), ee(U, j, I);
          }
          if (oe(j) || se(j)) return j = Zo(j, U.mode, I, null), j.return = U, j;
          if (typeof j.then == "function") return ee(U, jl(j), I);
          if (j.$$typeof === O) return ee(U, Ml(U, j), I);
          kl(U, j);
        }
        return null;
      }
      function V(U, j, I, K) {
        var ye = j !== null ? j.key : null;
        if (typeof I == "string" && I !== "" || typeof I == "number" || typeof I == "bigint") return ye !== null ? null : A(U, j, "" + I, K);
        if (typeof I == "object" && I !== null) {
          switch (I.$$typeof) {
            case _:
              return I.key === ye ? z(U, j, I, K) : null;
            case x:
              return I.key === ye ? H(U, j, I, K) : null;
            case $:
              return I = Qo(I), V(U, j, I, K);
          }
          if (oe(I) || se(I)) return ye !== null ? null : Q(U, j, I, K, null);
          if (typeof I.then == "function") return V(U, j, jl(I), K);
          if (I.$$typeof === O) return V(U, j, Ml(U, I), K);
          kl(U, I);
        }
        return null;
      }
      function Y(U, j, I, K, ye) {
        if (typeof K == "string" && K !== "" || typeof K == "number" || typeof K == "bigint") return U = U.get(I) || null, A(j, U, "" + K, ye);
        if (typeof K == "object" && K !== null) {
          switch (K.$$typeof) {
            case _:
              return U = U.get(K.key === null ? I : K.key) || null, z(j, U, K, ye);
            case x:
              return U = U.get(K.key === null ? I : K.key) || null, H(j, U, K, ye);
            case $:
              return K = Qo(K), Y(U, j, I, K, ye);
          }
          if (oe(K) || se(K)) return U = U.get(I) || null, Q(j, U, K, ye, null);
          if (typeof K.then == "function") return Y(U, j, I, jl(K), ye);
          if (K.$$typeof === O) return Y(U, j, I, Ml(j, K), ye);
          kl(j, K);
        }
        return null;
      }
      function de(U, j, I, K) {
        for (var ye = null, He = null, ve = j, Me = j = 0, Be = null; ve !== null && Me < I.length; Me++) {
          ve.index > Me ? (Be = ve, ve = null) : Be = ve.sibling;
          var $e = V(U, ve, I[Me], K);
          if ($e === null) {
            ve === null && (ve = Be);
            break;
          }
          n && ve && $e.alternate === null && o(U, ve), j = h($e, j, Me), He === null ? ye = $e : He.sibling = $e, He = $e, ve = Be;
        }
        if (Me === I.length) return i(U, ve), Ie && _r4(U, Me), ye;
        if (ve === null) {
          for (; Me < I.length; Me++) ve = ee(U, I[Me], K), ve !== null && (j = h(ve, j, Me), He === null ? ye = ve : He.sibling = ve, He = ve);
          return Ie && _r4(U, Me), ye;
        }
        for (ve = c(ve); Me < I.length; Me++) Be = Y(ve, U, Me, I[Me], K), Be !== null && (n && Be.alternate !== null && ve.delete(Be.key === null ? Me : Be.key), j = h(Be, j, Me), He === null ? ye = Be : He.sibling = Be, He = Be);
        return n && ve.forEach(function(bo) {
          return o(U, bo);
        }), Ie && _r4(U, Me), ye;
      }
      function we(U, j, I, K) {
        if (I == null) throw Error(a(151));
        for (var ye = null, He = null, ve = j, Me = j = 0, Be = null, $e = I.next(); ve !== null && !$e.done; Me++, $e = I.next()) {
          ve.index > Me ? (Be = ve, ve = null) : Be = ve.sibling;
          var bo = V(U, ve, $e.value, K);
          if (bo === null) {
            ve === null && (ve = Be);
            break;
          }
          n && ve && bo.alternate === null && o(U, ve), j = h(bo, j, Me), He === null ? ye = bo : He.sibling = bo, He = bo, ve = Be;
        }
        if ($e.done) return i(U, ve), Ie && _r4(U, Me), ye;
        if (ve === null) {
          for (; !$e.done; Me++, $e = I.next()) $e = ee(U, $e.value, K), $e !== null && (j = h($e, j, Me), He === null ? ye = $e : He.sibling = $e, He = $e);
          return Ie && _r4(U, Me), ye;
        }
        for (ve = c(ve); !$e.done; Me++, $e = I.next()) $e = Y(ve, U, Me, $e.value, K), $e !== null && (n && $e.alternate !== null && ve.delete($e.key === null ? Me : $e.key), j = h($e, j, Me), He === null ? ye = $e : He.sibling = $e, He = $e);
        return n && ve.forEach(function(DT) {
          return o(U, DT);
        }), Ie && _r4(U, Me), ye;
      }
      function Ge(U, j, I, K) {
        if (typeof I == "object" && I !== null && I.type === E && I.key === null && (I = I.props.children), typeof I == "object" && I !== null) {
          switch (I.$$typeof) {
            case _:
              e: {
                for (var ye = I.key; j !== null; ) {
                  if (j.key === ye) {
                    if (ye = I.type, ye === E) {
                      if (j.tag === 7) {
                        i(U, j.sibling), K = d(j, I.props.children), K.return = U, U = K;
                        break e;
                      }
                    } else if (j.elementType === ye || typeof ye == "object" && ye !== null && ye.$$typeof === $ && Qo(ye) === j.type) {
                      i(U, j.sibling), K = d(j, I.props), es(K, I), K.return = U, U = K;
                      break e;
                    }
                    i(U, j);
                    break;
                  } else o(U, j);
                  j = j.sibling;
                }
                I.type === E ? (K = Zo(I.props.children, U.mode, K, I.key), K.return = U, U = K) : (K = Tl(I.type, I.key, I.props, null, U.mode, K), es(K, I), K.return = U, U = K);
              }
              return w(U);
            case x:
              e: {
                for (ye = I.key; j !== null; ) {
                  if (j.key === ye) if (j.tag === 4 && j.stateNode.containerInfo === I.containerInfo && j.stateNode.implementation === I.implementation) {
                    i(U, j.sibling), K = d(j, I.children || []), K.return = U, U = K;
                    break e;
                  } else {
                    i(U, j);
                    break;
                  }
                  else o(U, j);
                  j = j.sibling;
                }
                K = Lf(I, U.mode, K), K.return = U, U = K;
              }
              return w(U);
            case $:
              return I = Qo(I), Ge(U, j, I, K);
          }
          if (oe(I)) return de(U, j, I, K);
          if (se(I)) {
            if (ye = se(I), typeof ye != "function") throw Error(a(150));
            return I = ye.call(I), we(U, j, I, K);
          }
          if (typeof I.then == "function") return Ge(U, j, jl(I), K);
          if (I.$$typeof === O) return Ge(U, j, Ml(U, I), K);
          kl(U, I);
        }
        return typeof I == "string" && I !== "" || typeof I == "number" || typeof I == "bigint" ? (I = "" + I, j !== null && j.tag === 6 ? (i(U, j.sibling), K = d(j, I), K.return = U, U = K) : (i(U, j), K = Pf(I, U.mode, K), K.return = U, U = K), w(U)) : i(U, j);
      }
      return function(U, j, I, K) {
        try {
          Wi = 0;
          var ye = Ge(U, j, I, K);
          return Ha = null, ye;
        } catch (ve) {
          if (ve === Ia || ve === zl) throw ve;
          var He = un(29, ve, null, U.mode);
          return He.lanes = K, He.return = U, He;
        } finally {
        }
      };
    }
    var Ko = Wg(true), ev = Wg(false), to = false;
    function Qf(n) {
      n.updateQueue = { baseState: n.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, lanes: 0, hiddenCallbacks: null }, callbacks: null };
    }
    function Gf(n, o) {
      n = n.updateQueue, o.updateQueue === n && (o.updateQueue = { baseState: n.baseState, firstBaseUpdate: n.firstBaseUpdate, lastBaseUpdate: n.lastBaseUpdate, shared: n.shared, callbacks: null });
    }
    function no(n) {
      return { lane: n, tag: 0, payload: null, callback: null, next: null };
    }
    function ro(n, o, i) {
      var c = n.updateQueue;
      if (c === null) return null;
      if (c = c.shared, (Ze & 2) !== 0) {
        var d = c.pending;
        return d === null ? o.next = o : (o.next = d.next, d.next = o), c.pending = o, o = Cl(n), Lg(n, null, i), o;
      }
      return Al(n, c, o, i), Cl(n);
    }
    function ts(n, o, i) {
      if (o = o.updateQueue, o !== null && (o = o.shared, (i & 4194048) !== 0)) {
        var c = o.lanes;
        c &= n.pendingLanes, i |= c, o.lanes = i, qt(n, i);
      }
    }
    function Kf(n, o) {
      var i = n.updateQueue, c = n.alternate;
      if (c !== null && (c = c.updateQueue, i === c)) {
        var d = null, h = null;
        if (i = i.firstBaseUpdate, i !== null) {
          do {
            var w = { lane: i.lane, tag: i.tag, payload: i.payload, callback: null, next: null };
            h === null ? d = h = w : h = h.next = w, i = i.next;
          } while (i !== null);
          h === null ? d = h = o : h = h.next = o;
        } else d = h = o;
        i = { baseState: c.baseState, firstBaseUpdate: d, lastBaseUpdate: h, shared: c.shared, callbacks: c.callbacks }, n.updateQueue = i;
        return;
      }
      n = i.lastBaseUpdate, n === null ? i.firstBaseUpdate = o : n.next = o, i.lastBaseUpdate = o;
    }
    var Jf = false;
    function ns() {
      if (Jf) {
        var n = Ba;
        if (n !== null) throw n;
      }
    }
    function rs(n, o, i, c) {
      Jf = false;
      var d = n.updateQueue;
      to = false;
      var h = d.firstBaseUpdate, w = d.lastBaseUpdate, A = d.shared.pending;
      if (A !== null) {
        d.shared.pending = null;
        var z = A, H = z.next;
        z.next = null, w === null ? h = H : w.next = H, w = z;
        var Q = n.alternate;
        Q !== null && (Q = Q.updateQueue, A = Q.lastBaseUpdate, A !== w && (A === null ? Q.firstBaseUpdate = H : A.next = H, Q.lastBaseUpdate = z));
      }
      if (h !== null) {
        var ee = d.baseState;
        w = 0, Q = H = z = null, A = h;
        do {
          var V = A.lane & -536870913, Y = V !== A.lane;
          if (Y ? (Ue & V) === V : (c & V) === V) {
            V !== 0 && V === Ua && (Jf = true), Q !== null && (Q = Q.next = { lane: 0, tag: A.tag, payload: A.payload, callback: null, next: null });
            e: {
              var de = n, we = A;
              V = o;
              var Ge = i;
              switch (we.tag) {
                case 1:
                  if (de = we.payload, typeof de == "function") {
                    ee = de.call(Ge, ee, V);
                    break e;
                  }
                  ee = de;
                  break e;
                case 3:
                  de.flags = de.flags & -65537 | 128;
                case 0:
                  if (de = we.payload, V = typeof de == "function" ? de.call(Ge, ee, V) : de, V == null) break e;
                  ee = g({}, ee, V);
                  break e;
                case 2:
                  to = true;
              }
            }
            V = A.callback, V !== null && (n.flags |= 64, Y && (n.flags |= 8192), Y = d.callbacks, Y === null ? d.callbacks = [V] : Y.push(V));
          } else Y = { lane: V, tag: A.tag, payload: A.payload, callback: A.callback, next: null }, Q === null ? (H = Q = Y, z = ee) : Q = Q.next = Y, w |= V;
          if (A = A.next, A === null) {
            if (A = d.shared.pending, A === null) break;
            Y = A, A = Y.next, Y.next = null, d.lastBaseUpdate = Y, d.shared.pending = null;
          }
        } while (true);
        Q === null && (z = ee), d.baseState = z, d.firstBaseUpdate = H, d.lastBaseUpdate = Q, h === null && (d.shared.lanes = 0), lo |= w, n.lanes = w, n.memoizedState = ee;
      }
    }
    function tv(n, o) {
      if (typeof n != "function") throw Error(a(191, n));
      n.call(o);
    }
    function nv(n, o) {
      var i = n.callbacks;
      if (i !== null) for (n.callbacks = null, n = 0; n < i.length; n++) tv(i[n], o);
    }
    var $a = M(null), Pl = M(0);
    function rv(n, o) {
      n = jr, X(Pl, n), X($a, o), jr = n | o.baseLanes;
    }
    function Wf() {
      X(Pl, jr), X($a, $a.current);
    }
    function ed() {
      jr = Pl.current, F($a), F(Pl);
    }
    var fn = M(null), Tn = null;
    function oo(n) {
      var o = n.alternate;
      X(ut, ut.current & 1), X(fn, n), Tn === null && (o === null || $a.current !== null || o.memoizedState !== null) && (Tn = n);
    }
    function td(n) {
      X(ut, ut.current), X(fn, n), Tn === null && (Tn = n);
    }
    function ov(n) {
      n.tag === 22 ? (X(ut, ut.current), X(fn, n), Tn === null && (Tn = n)) : ao();
    }
    function ao() {
      X(ut, ut.current), X(fn, fn.current);
    }
    function dn(n) {
      F(fn), Tn === n && (Tn = null), F(ut);
    }
    var ut = M(0);
    function Ll(n) {
      for (var o = n; o !== null; ) {
        if (o.tag === 13) {
          var i = o.memoizedState;
          if (i !== null && (i = i.dehydrated, i === null || sh(i) || lh(i))) return o;
        } else if (o.tag === 19 && (o.memoizedProps.revealOrder === "forwards" || o.memoizedProps.revealOrder === "backwards" || o.memoizedProps.revealOrder === "unstable_legacy-backwards" || o.memoizedProps.revealOrder === "together")) {
          if ((o.flags & 128) !== 0) return o;
        } else if (o.child !== null) {
          o.child.return = o, o = o.child;
          continue;
        }
        if (o === n) break;
        for (; o.sibling === null; ) {
          if (o.return === null || o.return === n) return null;
          o = o.return;
        }
        o.sibling.return = o.return, o = o.sibling;
      }
      return null;
    }
    var Cr = 0, Oe = null, Xe = null, mt = null, Ul = false, Va = false, Jo = false, Bl = 0, os = 0, Za = null, _C = 0;
    function lt() {
      throw Error(a(321));
    }
    function nd(n, o) {
      if (o === null) return false;
      for (var i = 0; i < o.length && i < n.length; i++) if (!cn(n[i], o[i])) return false;
      return true;
    }
    function rd(n, o, i, c, d, h) {
      return Cr = h, Oe = o, o.memoizedState = null, o.updateQueue = null, o.lanes = 0, N.H = n === null || n.memoizedState === null ? Hv : yd, Jo = false, h = i(c, d), Jo = false, Va && (h = iv(o, i, c, d)), av(n), h;
    }
    function av(n) {
      N.H = ss;
      var o = Xe !== null && Xe.next !== null;
      if (Cr = 0, mt = Xe = Oe = null, Ul = false, os = 0, Za = null, o) throw Error(a(300));
      n === null || gt || (n = n.dependencies, n !== null && Rl(n) && (gt = true));
    }
    function iv(n, o, i, c) {
      Oe = n;
      var d = 0;
      do {
        if (Va && (Za = null), os = 0, Va = false, 25 <= d) throw Error(a(301));
        if (d += 1, mt = Xe = null, n.updateQueue != null) {
          var h = n.updateQueue;
          h.lastEffect = null, h.events = null, h.stores = null, h.memoCache != null && (h.memoCache.index = 0);
        }
        N.H = $v, h = o(i, c);
      } while (Va);
      return h;
    }
    function EC() {
      var n = N.H, o = n.useState()[0];
      return o = typeof o.then == "function" ? as(o) : o, n = n.useState()[0], (Xe !== null ? Xe.memoizedState : null) !== n && (Oe.flags |= 1024), o;
    }
    function od() {
      var n = Bl !== 0;
      return Bl = 0, n;
    }
    function ad(n, o, i) {
      o.updateQueue = n.updateQueue, o.flags &= -2053, n.lanes &= ~i;
    }
    function id(n) {
      if (Ul) {
        for (n = n.memoizedState; n !== null; ) {
          var o = n.queue;
          o !== null && (o.pending = null), n = n.next;
        }
        Ul = false;
      }
      Cr = 0, mt = Xe = Oe = null, Va = false, os = Bl = 0, Za = null;
    }
    function Vt() {
      var n = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
      return mt === null ? Oe.memoizedState = mt = n : mt = mt.next = n, mt;
    }
    function ft() {
      if (Xe === null) {
        var n = Oe.alternate;
        n = n !== null ? n.memoizedState : null;
      } else n = Xe.next;
      var o = mt === null ? Oe.memoizedState : mt.next;
      if (o !== null) mt = o, Xe = n;
      else {
        if (n === null) throw Oe.alternate === null ? Error(a(467)) : Error(a(310));
        Xe = n, n = { memoizedState: Xe.memoizedState, baseState: Xe.baseState, baseQueue: Xe.baseQueue, queue: Xe.queue, next: null }, mt === null ? Oe.memoizedState = mt = n : mt = mt.next = n;
      }
      return mt;
    }
    function Il() {
      return { lastEffect: null, events: null, stores: null, memoCache: null };
    }
    function as(n) {
      var o = os;
      return os += 1, Za === null && (Za = []), n = Gg(Za, n, o), o = Oe, (mt === null ? o.memoizedState : mt.next) === null && (o = o.alternate, N.H = o === null || o.memoizedState === null ? Hv : yd), n;
    }
    function Hl(n) {
      if (n !== null && typeof n == "object") {
        if (typeof n.then == "function") return as(n);
        if (n.$$typeof === O) return Rt(n);
      }
      throw Error(a(438, String(n)));
    }
    function sd(n) {
      var o = null, i = Oe.updateQueue;
      if (i !== null && (o = i.memoCache), o == null) {
        var c = Oe.alternate;
        c !== null && (c = c.updateQueue, c !== null && (c = c.memoCache, c != null && (o = { data: c.data.map(function(d) {
          return d.slice();
        }), index: 0 })));
      }
      if (o == null && (o = { data: [], index: 0 }), i === null && (i = Il(), Oe.updateQueue = i), i.memoCache = o, i = o.data[o.index], i === void 0) for (i = o.data[o.index] = Array(n), c = 0; c < n; c++) i[c] = G;
      return o.index++, i;
    }
    function Tr(n, o) {
      return typeof o == "function" ? o(n) : o;
    }
    function $l(n) {
      var o = ft();
      return ld(o, Xe, n);
    }
    function ld(n, o, i) {
      var c = n.queue;
      if (c === null) throw Error(a(311));
      c.lastRenderedReducer = i;
      var d = n.baseQueue, h = c.pending;
      if (h !== null) {
        if (d !== null) {
          var w = d.next;
          d.next = h.next, h.next = w;
        }
        o.baseQueue = d = h, c.pending = null;
      }
      if (h = n.baseState, d === null) n.memoizedState = h;
      else {
        o = d.next;
        var A = w = null, z = null, H = o, Q = false;
        do {
          var ee = H.lane & -536870913;
          if (ee !== H.lane ? (Ue & ee) === ee : (Cr & ee) === ee) {
            var V = H.revertLane;
            if (V === 0) z !== null && (z = z.next = { lane: 0, revertLane: 0, gesture: null, action: H.action, hasEagerState: H.hasEagerState, eagerState: H.eagerState, next: null }), ee === Ua && (Q = true);
            else if ((Cr & V) === V) {
              H = H.next, V === Ua && (Q = true);
              continue;
            } else ee = { lane: 0, revertLane: H.revertLane, gesture: null, action: H.action, hasEagerState: H.hasEagerState, eagerState: H.eagerState, next: null }, z === null ? (A = z = ee, w = h) : z = z.next = ee, Oe.lanes |= V, lo |= V;
            ee = H.action, Jo && i(h, ee), h = H.hasEagerState ? H.eagerState : i(h, ee);
          } else V = { lane: ee, revertLane: H.revertLane, gesture: H.gesture, action: H.action, hasEagerState: H.hasEagerState, eagerState: H.eagerState, next: null }, z === null ? (A = z = V, w = h) : z = z.next = V, Oe.lanes |= ee, lo |= ee;
          H = H.next;
        } while (H !== null && H !== o);
        if (z === null ? w = h : z.next = A, !cn(h, n.memoizedState) && (gt = true, Q && (i = Ba, i !== null))) throw i;
        n.memoizedState = h, n.baseState = w, n.baseQueue = z, c.lastRenderedState = h;
      }
      return d === null && (c.lanes = 0), [n.memoizedState, c.dispatch];
    }
    function cd(n) {
      var o = ft(), i = o.queue;
      if (i === null) throw Error(a(311));
      i.lastRenderedReducer = n;
      var c = i.dispatch, d = i.pending, h = o.memoizedState;
      if (d !== null) {
        i.pending = null;
        var w = d = d.next;
        do
          h = n(h, w.action), w = w.next;
        while (w !== d);
        cn(h, o.memoizedState) || (gt = true), o.memoizedState = h, o.baseQueue === null && (o.baseState = h), i.lastRenderedState = h;
      }
      return [h, c];
    }
    function sv(n, o, i) {
      var c = Oe, d = ft(), h = Ie;
      if (h) {
        if (i === void 0) throw Error(a(407));
        i = i();
      } else i = o();
      var w = !cn((Xe || d).memoizedState, i);
      if (w && (d.memoizedState = i, gt = true), d = d.queue, dd(uv.bind(null, c, d, n), [n]), d.getSnapshot !== o || w || mt !== null && mt.memoizedState.tag & 1) {
        if (c.flags |= 2048, Fa(9, { destroy: void 0 }, cv.bind(null, c, d, i, o), null), Ke === null) throw Error(a(349));
        h || (Cr & 127) !== 0 || lv(c, o, i);
      }
      return i;
    }
    function lv(n, o, i) {
      n.flags |= 16384, n = { getSnapshot: o, value: i }, o = Oe.updateQueue, o === null ? (o = Il(), Oe.updateQueue = o, o.stores = [n]) : (i = o.stores, i === null ? o.stores = [n] : i.push(n));
    }
    function cv(n, o, i, c) {
      o.value = i, o.getSnapshot = c, fv(o) && dv(n);
    }
    function uv(n, o, i) {
      return i(function() {
        fv(o) && dv(n);
      });
    }
    function fv(n) {
      var o = n.getSnapshot;
      n = n.value;
      try {
        var i = o();
        return !cn(n, i);
      } catch {
        return true;
      }
    }
    function dv(n) {
      var o = Vo(n, 2);
      o !== null && en(o, n, 2);
    }
    function ud(n) {
      var o = Vt();
      if (typeof n == "function") {
        var i = n;
        if (n = i(), Jo) {
          kn(true);
          try {
            i();
          } finally {
            kn(false);
          }
        }
      }
      return o.memoizedState = o.baseState = n, o.queue = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: Tr, lastRenderedState: n }, o;
    }
    function hv(n, o, i, c) {
      return n.baseState = i, ld(n, Xe, typeof c == "function" ? c : Tr);
    }
    function AC(n, o, i, c, d) {
      if (Fl(n)) throw Error(a(485));
      if (n = o.action, n !== null) {
        var h = { payload: d, action: n, next: null, isTransition: true, status: "pending", value: null, reason: null, listeners: [], then: function(w) {
          h.listeners.push(w);
        } };
        N.T !== null ? i(true) : h.isTransition = false, c(h), i = o.pending, i === null ? (h.next = o.pending = h, pv(o, h)) : (h.next = i.next, o.pending = i.next = h);
      }
    }
    function pv(n, o) {
      var i = o.action, c = o.payload, d = n.state;
      if (o.isTransition) {
        var h = N.T, w = {};
        N.T = w;
        try {
          var A = i(d, c), z = N.S;
          z !== null && z(w, A), mv(n, o, A);
        } catch (H) {
          fd(n, o, H);
        } finally {
          h !== null && w.types !== null && (h.types = w.types), N.T = h;
        }
      } else try {
        h = i(d, c), mv(n, o, h);
      } catch (H) {
        fd(n, o, H);
      }
    }
    function mv(n, o, i) {
      i !== null && typeof i == "object" && typeof i.then == "function" ? i.then(function(c) {
        gv(n, o, c);
      }, function(c) {
        return fd(n, o, c);
      }) : gv(n, o, i);
    }
    function gv(n, o, i) {
      o.status = "fulfilled", o.value = i, vv(o), n.state = i, o = n.pending, o !== null && (i = o.next, i === o ? n.pending = null : (i = i.next, o.next = i, pv(n, i)));
    }
    function fd(n, o, i) {
      var c = n.pending;
      if (n.pending = null, c !== null) {
        c = c.next;
        do
          o.status = "rejected", o.reason = i, vv(o), o = o.next;
        while (o !== c);
      }
      n.action = null;
    }
    function vv(n) {
      n = n.listeners;
      for (var o = 0; o < n.length; o++) (0, n[o])();
    }
    function yv(n, o) {
      return o;
    }
    function bv(n, o) {
      if (Ie) {
        var i = Ke.formState;
        if (i !== null) {
          e: {
            var c = Oe;
            if (Ie) {
              if (Je) {
                t: {
                  for (var d = Je, h = Cn; d.nodeType !== 8; ) {
                    if (!h) {
                      d = null;
                      break t;
                    }
                    if (d = On(d.nextSibling), d === null) {
                      d = null;
                      break t;
                    }
                  }
                  h = d.data, d = h === "F!" || h === "F" ? d : null;
                }
                if (d) {
                  Je = On(d.nextSibling), c = d.data === "F!";
                  break e;
                }
              }
              Wr(c);
            }
            c = false;
          }
          c && (o = i[0]);
        }
      }
      return i = Vt(), i.memoizedState = i.baseState = o, c = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: yv, lastRenderedState: o }, i.queue = c, i = Uv.bind(null, Oe, c), c.dispatch = i, c = ud(false), h = vd.bind(null, Oe, false, c.queue), c = Vt(), d = { state: o, dispatch: null, action: n, pending: null }, c.queue = d, i = AC.bind(null, Oe, d, h, i), d.dispatch = i, c.memoizedState = n, [o, i, false];
    }
    function wv(n) {
      var o = ft();
      return Sv(o, Xe, n);
    }
    function Sv(n, o, i) {
      if (o = ld(n, o, yv)[0], n = $l(Tr)[0], typeof o == "object" && o !== null && typeof o.then == "function") try {
        var c = as(o);
      } catch (w) {
        throw w === Ia ? zl : w;
      }
      else c = o;
      o = ft();
      var d = o.queue, h = d.dispatch;
      return i !== o.memoizedState && (Oe.flags |= 2048, Fa(9, { destroy: void 0 }, CC.bind(null, d, i), null)), [c, h, n];
    }
    function CC(n, o) {
      n.action = o;
    }
    function xv(n) {
      var o = ft(), i = Xe;
      if (i !== null) return Sv(o, i, n);
      ft(), o = o.memoizedState, i = ft();
      var c = i.queue.dispatch;
      return i.memoizedState = n, [o, c, false];
    }
    function Fa(n, o, i, c) {
      return n = { tag: n, create: i, deps: c, inst: o, next: null }, o = Oe.updateQueue, o === null && (o = Il(), Oe.updateQueue = o), i = o.lastEffect, i === null ? o.lastEffect = n.next = n : (c = i.next, i.next = n, n.next = c, o.lastEffect = n), n;
    }
    function _v() {
      return ft().memoizedState;
    }
    function Vl(n, o, i, c) {
      var d = Vt();
      Oe.flags |= n, d.memoizedState = Fa(1 | o, { destroy: void 0 }, i, c === void 0 ? null : c);
    }
    function Zl(n, o, i, c) {
      var d = ft();
      c = c === void 0 ? null : c;
      var h = d.memoizedState.inst;
      Xe !== null && c !== null && nd(c, Xe.memoizedState.deps) ? d.memoizedState = Fa(o, h, i, c) : (Oe.flags |= n, d.memoizedState = Fa(1 | o, h, i, c));
    }
    function Ev(n, o) {
      Vl(8390656, 8, n, o);
    }
    function dd(n, o) {
      Zl(2048, 8, n, o);
    }
    function TC(n) {
      Oe.flags |= 4;
      var o = Oe.updateQueue;
      if (o === null) o = Il(), Oe.updateQueue = o, o.events = [n];
      else {
        var i = o.events;
        i === null ? o.events = [n] : i.push(n);
      }
    }
    function Av(n) {
      var o = ft().memoizedState;
      return TC({ ref: o, nextImpl: n }), function() {
        if ((Ze & 2) !== 0) throw Error(a(440));
        return o.impl.apply(void 0, arguments);
      };
    }
    function Cv(n, o) {
      return Zl(4, 2, n, o);
    }
    function Tv(n, o) {
      return Zl(4, 4, n, o);
    }
    function Ov(n, o) {
      if (typeof o == "function") {
        n = n();
        var i = o(n);
        return function() {
          typeof i == "function" ? i() : o(null);
        };
      }
      if (o != null) return n = n(), o.current = n, function() {
        o.current = null;
      };
    }
    function Rv(n, o, i) {
      i = i != null ? i.concat([n]) : null, Zl(4, 4, Ov.bind(null, o, n), i);
    }
    function hd() {
    }
    function Mv(n, o) {
      var i = ft();
      o = o === void 0 ? null : o;
      var c = i.memoizedState;
      return o !== null && nd(o, c[1]) ? c[0] : (i.memoizedState = [n, o], n);
    }
    function Nv(n, o) {
      var i = ft();
      o = o === void 0 ? null : o;
      var c = i.memoizedState;
      if (o !== null && nd(o, c[1])) return c[0];
      if (c = n(), Jo) {
        kn(true);
        try {
          n();
        } finally {
          kn(false);
        }
      }
      return i.memoizedState = [c, o], c;
    }
    function pd(n, o, i) {
      return i === void 0 || (Cr & 1073741824) !== 0 && (Ue & 261930) === 0 ? n.memoizedState = o : (n.memoizedState = i, n = zy(), Oe.lanes |= n, lo |= n, i);
    }
    function zv(n, o, i, c) {
      return cn(i, o) ? i : $a.current !== null ? (n = pd(n, i, c), cn(n, o) || (gt = true), n) : (Cr & 42) === 0 || (Cr & 1073741824) !== 0 && (Ue & 261930) === 0 ? (gt = true, n.memoizedState = i) : (n = zy(), Oe.lanes |= n, lo |= n, o);
    }
    function Dv(n, o, i, c, d) {
      var h = Z.p;
      Z.p = h !== 0 && 8 > h ? h : 8;
      var w = N.T, A = {};
      N.T = A, vd(n, false, o, i);
      try {
        var z = d(), H = N.S;
        if (H !== null && H(A, z), z !== null && typeof z == "object" && typeof z.then == "function") {
          var Q = xC(z, c);
          is(n, o, Q, mn(n));
        } else is(n, o, c, mn(n));
      } catch (ee) {
        is(n, o, { then: function() {
        }, status: "rejected", reason: ee }, mn());
      } finally {
        Z.p = h, w !== null && A.types !== null && (w.types = A.types), N.T = w;
      }
    }
    function OC() {
    }
    function md(n, o, i, c) {
      if (n.tag !== 5) throw Error(a(476));
      var d = jv(n).queue;
      Dv(n, d, o, B, i === null ? OC : function() {
        return kv(n), i(c);
      });
    }
    function jv(n) {
      var o = n.memoizedState;
      if (o !== null) return o;
      o = { memoizedState: B, baseState: B, baseQueue: null, queue: { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: Tr, lastRenderedState: B }, next: null };
      var i = {};
      return o.next = { memoizedState: i, baseState: i, baseQueue: null, queue: { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: Tr, lastRenderedState: i }, next: null }, n.memoizedState = o, n = n.alternate, n !== null && (n.memoizedState = o), o;
    }
    function kv(n) {
      var o = jv(n);
      o.next === null && (o = n.alternate.memoizedState), is(n, o.next.queue, {}, mn());
    }
    function gd() {
      return Rt(_s4);
    }
    function Pv() {
      return ft().memoizedState;
    }
    function Lv() {
      return ft().memoizedState;
    }
    function RC(n) {
      for (var o = n.return; o !== null; ) {
        switch (o.tag) {
          case 24:
          case 3:
            var i = mn();
            n = no(i);
            var c = ro(o, n, i);
            c !== null && (en(c, o, i), ts(c, o, i)), o = { cache: Ff() }, n.payload = o;
            return;
        }
        o = o.return;
      }
    }
    function MC(n, o, i) {
      var c = mn();
      i = { lane: c, revertLane: 0, gesture: null, action: i, hasEagerState: false, eagerState: null, next: null }, Fl(n) ? Bv(o, i) : (i = jf(n, o, i, c), i !== null && (en(i, n, c), Iv(i, o, c)));
    }
    function Uv(n, o, i) {
      var c = mn();
      is(n, o, i, c);
    }
    function is(n, o, i, c) {
      var d = { lane: c, revertLane: 0, gesture: null, action: i, hasEagerState: false, eagerState: null, next: null };
      if (Fl(n)) Bv(o, d);
      else {
        var h = n.alternate;
        if (n.lanes === 0 && (h === null || h.lanes === 0) && (h = o.lastRenderedReducer, h !== null)) try {
          var w = o.lastRenderedState, A = h(w, i);
          if (d.hasEagerState = true, d.eagerState = A, cn(A, w)) return Al(n, o, d, 0), Ke === null && El(), false;
        } catch {
        } finally {
        }
        if (i = jf(n, o, d, c), i !== null) return en(i, n, c), Iv(i, o, c), true;
      }
      return false;
    }
    function vd(n, o, i, c) {
      if (c = { lane: 2, revertLane: Qd(), gesture: null, action: c, hasEagerState: false, eagerState: null, next: null }, Fl(n)) {
        if (o) throw Error(a(479));
      } else o = jf(n, i, c, 2), o !== null && en(o, n, 2);
    }
    function Fl(n) {
      var o = n.alternate;
      return n === Oe || o !== null && o === Oe;
    }
    function Bv(n, o) {
      Va = Ul = true;
      var i = n.pending;
      i === null ? o.next = o : (o.next = i.next, i.next = o), n.pending = o;
    }
    function Iv(n, o, i) {
      if ((i & 4194048) !== 0) {
        var c = o.lanes;
        c &= n.pendingLanes, i |= c, o.lanes = i, qt(n, i);
      }
    }
    var ss = { readContext: Rt, use: Hl, useCallback: lt, useContext: lt, useEffect: lt, useImperativeHandle: lt, useLayoutEffect: lt, useInsertionEffect: lt, useMemo: lt, useReducer: lt, useRef: lt, useState: lt, useDebugValue: lt, useDeferredValue: lt, useTransition: lt, useSyncExternalStore: lt, useId: lt, useHostTransitionStatus: lt, useFormState: lt, useActionState: lt, useOptimistic: lt, useMemoCache: lt, useCacheRefresh: lt };
    ss.useEffectEvent = lt;
    var Hv = { readContext: Rt, use: Hl, useCallback: function(n, o) {
      return Vt().memoizedState = [n, o === void 0 ? null : o], n;
    }, useContext: Rt, useEffect: Ev, useImperativeHandle: function(n, o, i) {
      i = i != null ? i.concat([n]) : null, Vl(4194308, 4, Ov.bind(null, o, n), i);
    }, useLayoutEffect: function(n, o) {
      return Vl(4194308, 4, n, o);
    }, useInsertionEffect: function(n, o) {
      Vl(4, 2, n, o);
    }, useMemo: function(n, o) {
      var i = Vt();
      o = o === void 0 ? null : o;
      var c = n();
      if (Jo) {
        kn(true);
        try {
          n();
        } finally {
          kn(false);
        }
      }
      return i.memoizedState = [c, o], c;
    }, useReducer: function(n, o, i) {
      var c = Vt();
      if (i !== void 0) {
        var d = i(o);
        if (Jo) {
          kn(true);
          try {
            i(o);
          } finally {
            kn(false);
          }
        }
      } else d = o;
      return c.memoizedState = c.baseState = d, n = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: n, lastRenderedState: d }, c.queue = n, n = n.dispatch = MC.bind(null, Oe, n), [c.memoizedState, n];
    }, useRef: function(n) {
      var o = Vt();
      return n = { current: n }, o.memoizedState = n;
    }, useState: function(n) {
      n = ud(n);
      var o = n.queue, i = Uv.bind(null, Oe, o);
      return o.dispatch = i, [n.memoizedState, i];
    }, useDebugValue: hd, useDeferredValue: function(n, o) {
      var i = Vt();
      return pd(i, n, o);
    }, useTransition: function() {
      var n = ud(false);
      return n = Dv.bind(null, Oe, n.queue, true, false), Vt().memoizedState = n, [false, n];
    }, useSyncExternalStore: function(n, o, i) {
      var c = Oe, d = Vt();
      if (Ie) {
        if (i === void 0) throw Error(a(407));
        i = i();
      } else {
        if (i = o(), Ke === null) throw Error(a(349));
        (Ue & 127) !== 0 || lv(c, o, i);
      }
      d.memoizedState = i;
      var h = { value: i, getSnapshot: o };
      return d.queue = h, Ev(uv.bind(null, c, h, n), [n]), c.flags |= 2048, Fa(9, { destroy: void 0 }, cv.bind(null, c, h, i, o), null), i;
    }, useId: function() {
      var n = Vt(), o = Ke.identifierPrefix;
      if (Ie) {
        var i = Wn, c = Jn;
        i = (c & ~(1 << 32 - kt(c) - 1)).toString(32) + i, o = "_" + o + "R_" + i, i = Bl++, 0 < i && (o += "H" + i.toString(32)), o += "_";
      } else i = _C++, o = "_" + o + "r_" + i.toString(32) + "_";
      return n.memoizedState = o;
    }, useHostTransitionStatus: gd, useFormState: bv, useActionState: bv, useOptimistic: function(n) {
      var o = Vt();
      o.memoizedState = o.baseState = n;
      var i = { pending: null, lanes: 0, dispatch: null, lastRenderedReducer: null, lastRenderedState: null };
      return o.queue = i, o = vd.bind(null, Oe, true, i), i.dispatch = o, [n, o];
    }, useMemoCache: sd, useCacheRefresh: function() {
      return Vt().memoizedState = RC.bind(null, Oe);
    }, useEffectEvent: function(n) {
      var o = Vt(), i = { impl: n };
      return o.memoizedState = i, function() {
        if ((Ze & 2) !== 0) throw Error(a(440));
        return i.impl.apply(void 0, arguments);
      };
    } }, yd = { readContext: Rt, use: Hl, useCallback: Mv, useContext: Rt, useEffect: dd, useImperativeHandle: Rv, useInsertionEffect: Cv, useLayoutEffect: Tv, useMemo: Nv, useReducer: $l, useRef: _v, useState: function() {
      return $l(Tr);
    }, useDebugValue: hd, useDeferredValue: function(n, o) {
      var i = ft();
      return zv(i, Xe.memoizedState, n, o);
    }, useTransition: function() {
      var n = $l(Tr)[0], o = ft().memoizedState;
      return [typeof n == "boolean" ? n : as(n), o];
    }, useSyncExternalStore: sv, useId: Pv, useHostTransitionStatus: gd, useFormState: wv, useActionState: wv, useOptimistic: function(n, o) {
      var i = ft();
      return hv(i, Xe, n, o);
    }, useMemoCache: sd, useCacheRefresh: Lv };
    yd.useEffectEvent = Av;
    var $v = { readContext: Rt, use: Hl, useCallback: Mv, useContext: Rt, useEffect: dd, useImperativeHandle: Rv, useInsertionEffect: Cv, useLayoutEffect: Tv, useMemo: Nv, useReducer: cd, useRef: _v, useState: function() {
      return cd(Tr);
    }, useDebugValue: hd, useDeferredValue: function(n, o) {
      var i = ft();
      return Xe === null ? pd(i, n, o) : zv(i, Xe.memoizedState, n, o);
    }, useTransition: function() {
      var n = cd(Tr)[0], o = ft().memoizedState;
      return [typeof n == "boolean" ? n : as(n), o];
    }, useSyncExternalStore: sv, useId: Pv, useHostTransitionStatus: gd, useFormState: xv, useActionState: xv, useOptimistic: function(n, o) {
      var i = ft();
      return Xe !== null ? hv(i, Xe, n, o) : (i.baseState = n, [n, i.queue.dispatch]);
    }, useMemoCache: sd, useCacheRefresh: Lv };
    $v.useEffectEvent = Av;
    function bd(n, o, i, c) {
      o = n.memoizedState, i = i(c, o), i = i == null ? o : g({}, o, i), n.memoizedState = i, n.lanes === 0 && (n.updateQueue.baseState = i);
    }
    var wd = { enqueueSetState: function(n, o, i) {
      n = n._reactInternals;
      var c = mn(), d = no(c);
      d.payload = o, i != null && (d.callback = i), o = ro(n, d, c), o !== null && (en(o, n, c), ts(o, n, c));
    }, enqueueReplaceState: function(n, o, i) {
      n = n._reactInternals;
      var c = mn(), d = no(c);
      d.tag = 1, d.payload = o, i != null && (d.callback = i), o = ro(n, d, c), o !== null && (en(o, n, c), ts(o, n, c));
    }, enqueueForceUpdate: function(n, o) {
      n = n._reactInternals;
      var i = mn(), c = no(i);
      c.tag = 2, o != null && (c.callback = o), o = ro(n, c, i), o !== null && (en(o, n, i), ts(o, n, i));
    } };
    function Vv(n, o, i, c, d, h, w) {
      return n = n.stateNode, typeof n.shouldComponentUpdate == "function" ? n.shouldComponentUpdate(c, h, w) : o.prototype && o.prototype.isPureReactComponent ? !Yi(i, c) || !Yi(d, h) : true;
    }
    function Zv(n, o, i, c) {
      n = o.state, typeof o.componentWillReceiveProps == "function" && o.componentWillReceiveProps(i, c), typeof o.UNSAFE_componentWillReceiveProps == "function" && o.UNSAFE_componentWillReceiveProps(i, c), o.state !== n && wd.enqueueReplaceState(o, o.state, null);
    }
    function Wo(n, o) {
      var i = o;
      if ("ref" in o) {
        i = {};
        for (var c in o) c !== "ref" && (i[c] = o[c]);
      }
      if (n = n.defaultProps) {
        i === o && (i = g({}, i));
        for (var d in n) i[d] === void 0 && (i[d] = n[d]);
      }
      return i;
    }
    function Fv(n) {
      _l3(n);
    }
    function qv(n) {
      console.error(n);
    }
    function Yv(n) {
      _l3(n);
    }
    function ql(n, o) {
      try {
        var i = n.onUncaughtError;
        i(o.value, { componentStack: o.stack });
      } catch (c) {
        setTimeout(function() {
          throw c;
        });
      }
    }
    function Xv(n, o, i) {
      try {
        var c = n.onCaughtError;
        c(i.value, { componentStack: i.stack, errorBoundary: o.tag === 1 ? o.stateNode : null });
      } catch (d) {
        setTimeout(function() {
          throw d;
        });
      }
    }
    function Sd(n, o, i) {
      return i = no(i), i.tag = 3, i.payload = { element: null }, i.callback = function() {
        ql(n, o);
      }, i;
    }
    function Qv(n) {
      return n = no(n), n.tag = 3, n;
    }
    function Gv(n, o, i, c) {
      var d = i.type.getDerivedStateFromError;
      if (typeof d == "function") {
        var h = c.value;
        n.payload = function() {
          return d(h);
        }, n.callback = function() {
          Xv(o, i, c);
        };
      }
      var w = i.stateNode;
      w !== null && typeof w.componentDidCatch == "function" && (n.callback = function() {
        Xv(o, i, c), typeof d != "function" && (co === null ? co = /* @__PURE__ */ new Set([this]) : co.add(this));
        var A = c.stack;
        this.componentDidCatch(c.value, { componentStack: A !== null ? A : "" });
      });
    }
    function NC(n, o, i, c, d) {
      if (i.flags |= 32768, c !== null && typeof c == "object" && typeof c.then == "function") {
        if (o = i.alternate, o !== null && La(o, i, d, true), i = fn.current, i !== null) {
          switch (i.tag) {
            case 31:
            case 13:
              return Tn === null ? oc() : i.alternate === null && ct === 0 && (ct = 3), i.flags &= -257, i.flags |= 65536, i.lanes = d, c === Dl ? i.flags |= 16384 : (o = i.updateQueue, o === null ? i.updateQueue = /* @__PURE__ */ new Set([c]) : o.add(c), qd(n, c, d)), false;
            case 22:
              return i.flags |= 65536, c === Dl ? i.flags |= 16384 : (o = i.updateQueue, o === null ? (o = { transitions: null, markerInstances: null, retryQueue: /* @__PURE__ */ new Set([c]) }, i.updateQueue = o) : (i = o.retryQueue, i === null ? o.retryQueue = /* @__PURE__ */ new Set([c]) : i.add(c)), qd(n, c, d)), false;
          }
          throw Error(a(435, i.tag));
        }
        return qd(n, c, d), oc(), false;
      }
      if (Ie) return o = fn.current, o !== null ? ((o.flags & 65536) === 0 && (o.flags |= 256), o.flags |= 65536, o.lanes = d, c !== If && (n = Error(a(422), { cause: c }), Gi(_n8(n, i)))) : (c !== If && (o = Error(a(423), { cause: c }), Gi(_n8(o, i))), n = n.current.alternate, n.flags |= 65536, d &= -d, n.lanes |= d, c = _n8(c, i), d = Sd(n.stateNode, c, d), Kf(n, d), ct !== 4 && (ct = 2)), false;
      var h = Error(a(520), { cause: c });
      if (h = _n8(h, i), ms === null ? ms = [h] : ms.push(h), ct !== 4 && (ct = 2), o === null) return true;
      c = _n8(c, i), i = o;
      do {
        switch (i.tag) {
          case 3:
            return i.flags |= 65536, n = d & -d, i.lanes |= n, n = Sd(i.stateNode, c, n), Kf(i, n), false;
          case 1:
            if (o = i.type, h = i.stateNode, (i.flags & 128) === 0 && (typeof o.getDerivedStateFromError == "function" || h !== null && typeof h.componentDidCatch == "function" && (co === null || !co.has(h)))) return i.flags |= 65536, d &= -d, i.lanes |= d, d = Qv(d), Gv(d, n, i, c), Kf(i, d), false;
        }
        i = i.return;
      } while (i !== null);
      return false;
    }
    var xd = Error(a(461)), gt = false;
    function Mt(n, o, i, c) {
      o.child = n === null ? ev(o, null, i, c) : Ko(o, n.child, i, c);
    }
    function Kv(n, o, i, c, d) {
      i = i.render;
      var h = o.ref;
      if ("ref" in c) {
        var w = {};
        for (var A in c) A !== "ref" && (w[A] = c[A]);
      } else w = c;
      return Yo(o), c = rd(n, o, i, w, h, d), A = od(), n !== null && !gt ? (ad(n, o, d), Or(n, o, d)) : (Ie && A && Uf(o), o.flags |= 1, Mt(n, o, c, d), o.child);
    }
    function Jv(n, o, i, c, d) {
      if (n === null) {
        var h = i.type;
        return typeof h == "function" && !kf(h) && h.defaultProps === void 0 && i.compare === null ? (o.tag = 15, o.type = h, Wv(n, o, h, c, d)) : (n = Tl(i.type, null, c, o, o.mode, d), n.ref = o.ref, n.return = o, o.child = n);
      }
      if (h = n.child, !Md(n, d)) {
        var w = h.memoizedProps;
        if (i = i.compare, i = i !== null ? i : Yi, i(w, c) && n.ref === o.ref) return Or(n, o, d);
      }
      return o.flags |= 1, n = xr(h, c), n.ref = o.ref, n.return = o, o.child = n;
    }
    function Wv(n, o, i, c, d) {
      if (n !== null) {
        var h = n.memoizedProps;
        if (Yi(h, c) && n.ref === o.ref) if (gt = false, o.pendingProps = c = h, Md(n, d)) (n.flags & 131072) !== 0 && (gt = true);
        else return o.lanes = n.lanes, Or(n, o, d);
      }
      return _d3(n, o, i, c, d);
    }
    function ey(n, o, i, c) {
      var d = c.children, h = n !== null ? n.memoizedState : null;
      if (n === null && o.stateNode === null && (o.stateNode = { _visibility: 1, _pendingMarkers: null, _retryCache: null, _transitions: null }), c.mode === "hidden") {
        if ((o.flags & 128) !== 0) {
          if (h = h !== null ? h.baseLanes | i : i, n !== null) {
            for (c = o.child = n.child, d = 0; c !== null; ) d = d | c.lanes | c.childLanes, c = c.sibling;
            c = d & ~h;
          } else c = 0, o.child = null;
          return ty(n, o, h, i, c);
        }
        if ((i & 536870912) !== 0) o.memoizedState = { baseLanes: 0, cachePool: null }, n !== null && Nl(o, h !== null ? h.cachePool : null), h !== null ? rv(o, h) : Wf(), ov(o);
        else return c = o.lanes = 536870912, ty(n, o, h !== null ? h.baseLanes | i : i, i, c);
      } else h !== null ? (Nl(o, h.cachePool), rv(o, h), ao(), o.memoizedState = null) : (n !== null && Nl(o, null), Wf(), ao());
      return Mt(n, o, d, i), o.child;
    }
    function ls(n, o) {
      return n !== null && n.tag === 22 || o.stateNode !== null || (o.stateNode = { _visibility: 1, _pendingMarkers: null, _retryCache: null, _transitions: null }), o.sibling;
    }
    function ty(n, o, i, c, d) {
      var h = Yf();
      return h = h === null ? null : { parent: pt._currentValue, pool: h }, o.memoizedState = { baseLanes: i, cachePool: h }, n !== null && Nl(o, null), Wf(), ov(o), n !== null && La(n, o, c, true), o.childLanes = d, null;
    }
    function Yl(n, o) {
      return o = Ql({ mode: o.mode, children: o.children }, n.mode), o.ref = n.ref, n.child = o, o.return = n, o;
    }
    function ny(n, o, i) {
      return Ko(o, n.child, null, i), n = Yl(o, o.pendingProps), n.flags |= 2, dn(o), o.memoizedState = null, n;
    }
    function zC(n, o, i) {
      var c = o.pendingProps, d = (o.flags & 128) !== 0;
      if (o.flags &= -129, n === null) {
        if (Ie) {
          if (c.mode === "hidden") return n = Yl(o, c), o.lanes = 536870912, ls(null, n);
          if (td(o), (n = Je) ? (n = pb(n, Cn), n = n !== null && n.data === "&" ? n : null, n !== null && (o.memoizedState = { dehydrated: n, treeContext: Kr !== null ? { id: Jn, overflow: Wn } : null, retryLane: 536870912, hydrationErrors: null }, i = Bg(n), i.return = o, o.child = i, Ot = o, Je = null)) : n = null, n === null) throw Wr(o);
          return o.lanes = 536870912, null;
        }
        return Yl(o, c);
      }
      var h = n.memoizedState;
      if (h !== null) {
        var w = h.dehydrated;
        if (td(o), d) if (o.flags & 256) o.flags &= -257, o = ny(n, o, i);
        else if (o.memoizedState !== null) o.child = n.child, o.flags |= 128, o = null;
        else throw Error(a(558));
        else if (gt || La(n, o, i, false), d = (i & n.childLanes) !== 0, gt || d) {
          if (c = Ke, c !== null && (w = Yt(c, i), w !== 0 && w !== h.retryLane)) throw h.retryLane = w, Vo(n, w), en(c, n, w), xd;
          oc(), o = ny(n, o, i);
        } else n = h.treeContext, Je = On(w.nextSibling), Ot = o, Ie = true, Jr = null, Cn = false, n !== null && $g(o, n), o = Yl(o, c), o.flags |= 4096;
        return o;
      }
      return n = xr(n.child, { mode: c.mode, children: c.children }), n.ref = o.ref, o.child = n, n.return = o, n;
    }
    function Xl(n, o) {
      var i = o.ref;
      if (i === null) n !== null && n.ref !== null && (o.flags |= 4194816);
      else {
        if (typeof i != "function" && typeof i != "object") throw Error(a(284));
        (n === null || n.ref !== i) && (o.flags |= 4194816);
      }
    }
    function _d3(n, o, i, c, d) {
      return Yo(o), i = rd(n, o, i, c, void 0, d), c = od(), n !== null && !gt ? (ad(n, o, d), Or(n, o, d)) : (Ie && c && Uf(o), o.flags |= 1, Mt(n, o, i, d), o.child);
    }
    function ry(n, o, i, c, d, h) {
      return Yo(o), o.updateQueue = null, i = iv(o, c, i, d), av(n), c = od(), n !== null && !gt ? (ad(n, o, h), Or(n, o, h)) : (Ie && c && Uf(o), o.flags |= 1, Mt(n, o, i, h), o.child);
    }
    function oy(n, o, i, c, d) {
      if (Yo(o), o.stateNode === null) {
        var h = Da, w = i.contextType;
        typeof w == "object" && w !== null && (h = Rt(w)), h = new i(c, h), o.memoizedState = h.state !== null && h.state !== void 0 ? h.state : null, h.updater = wd, o.stateNode = h, h._reactInternals = o, h = o.stateNode, h.props = c, h.state = o.memoizedState, h.refs = {}, Qf(o), w = i.contextType, h.context = typeof w == "object" && w !== null ? Rt(w) : Da, h.state = o.memoizedState, w = i.getDerivedStateFromProps, typeof w == "function" && (bd(o, i, w, c), h.state = o.memoizedState), typeof i.getDerivedStateFromProps == "function" || typeof h.getSnapshotBeforeUpdate == "function" || typeof h.UNSAFE_componentWillMount != "function" && typeof h.componentWillMount != "function" || (w = h.state, typeof h.componentWillMount == "function" && h.componentWillMount(), typeof h.UNSAFE_componentWillMount == "function" && h.UNSAFE_componentWillMount(), w !== h.state && wd.enqueueReplaceState(h, h.state, null), rs(o, c, h, d), ns(), h.state = o.memoizedState), typeof h.componentDidMount == "function" && (o.flags |= 4194308), c = true;
      } else if (n === null) {
        h = o.stateNode;
        var A = o.memoizedProps, z = Wo(i, A);
        h.props = z;
        var H = h.context, Q = i.contextType;
        w = Da, typeof Q == "object" && Q !== null && (w = Rt(Q));
        var ee = i.getDerivedStateFromProps;
        Q = typeof ee == "function" || typeof h.getSnapshotBeforeUpdate == "function", A = o.pendingProps !== A, Q || typeof h.UNSAFE_componentWillReceiveProps != "function" && typeof h.componentWillReceiveProps != "function" || (A || H !== w) && Zv(o, h, c, w), to = false;
        var V = o.memoizedState;
        h.state = V, rs(o, c, h, d), ns(), H = o.memoizedState, A || V !== H || to ? (typeof ee == "function" && (bd(o, i, ee, c), H = o.memoizedState), (z = to || Vv(o, i, z, c, V, H, w)) ? (Q || typeof h.UNSAFE_componentWillMount != "function" && typeof h.componentWillMount != "function" || (typeof h.componentWillMount == "function" && h.componentWillMount(), typeof h.UNSAFE_componentWillMount == "function" && h.UNSAFE_componentWillMount()), typeof h.componentDidMount == "function" && (o.flags |= 4194308)) : (typeof h.componentDidMount == "function" && (o.flags |= 4194308), o.memoizedProps = c, o.memoizedState = H), h.props = c, h.state = H, h.context = w, c = z) : (typeof h.componentDidMount == "function" && (o.flags |= 4194308), c = false);
      } else {
        h = o.stateNode, Gf(n, o), w = o.memoizedProps, Q = Wo(i, w), h.props = Q, ee = o.pendingProps, V = h.context, H = i.contextType, z = Da, typeof H == "object" && H !== null && (z = Rt(H)), A = i.getDerivedStateFromProps, (H = typeof A == "function" || typeof h.getSnapshotBeforeUpdate == "function") || typeof h.UNSAFE_componentWillReceiveProps != "function" && typeof h.componentWillReceiveProps != "function" || (w !== ee || V !== z) && Zv(o, h, c, z), to = false, V = o.memoizedState, h.state = V, rs(o, c, h, d), ns();
        var Y = o.memoizedState;
        w !== ee || V !== Y || to || n !== null && n.dependencies !== null && Rl(n.dependencies) ? (typeof A == "function" && (bd(o, i, A, c), Y = o.memoizedState), (Q = to || Vv(o, i, Q, c, V, Y, z) || n !== null && n.dependencies !== null && Rl(n.dependencies)) ? (H || typeof h.UNSAFE_componentWillUpdate != "function" && typeof h.componentWillUpdate != "function" || (typeof h.componentWillUpdate == "function" && h.componentWillUpdate(c, Y, z), typeof h.UNSAFE_componentWillUpdate == "function" && h.UNSAFE_componentWillUpdate(c, Y, z)), typeof h.componentDidUpdate == "function" && (o.flags |= 4), typeof h.getSnapshotBeforeUpdate == "function" && (o.flags |= 1024)) : (typeof h.componentDidUpdate != "function" || w === n.memoizedProps && V === n.memoizedState || (o.flags |= 4), typeof h.getSnapshotBeforeUpdate != "function" || w === n.memoizedProps && V === n.memoizedState || (o.flags |= 1024), o.memoizedProps = c, o.memoizedState = Y), h.props = c, h.state = Y, h.context = z, c = Q) : (typeof h.componentDidUpdate != "function" || w === n.memoizedProps && V === n.memoizedState || (o.flags |= 4), typeof h.getSnapshotBeforeUpdate != "function" || w === n.memoizedProps && V === n.memoizedState || (o.flags |= 1024), c = false);
      }
      return h = c, Xl(n, o), c = (o.flags & 128) !== 0, h || c ? (h = o.stateNode, i = c && typeof i.getDerivedStateFromError != "function" ? null : h.render(), o.flags |= 1, n !== null && c ? (o.child = Ko(o, n.child, null, d), o.child = Ko(o, null, i, d)) : Mt(n, o, i, d), o.memoizedState = h.state, n = o.child) : n = Or(n, o, d), n;
    }
    function ay(n, o, i, c) {
      return Fo(), o.flags |= 256, Mt(n, o, i, c), o.child;
    }
    var Ed = { dehydrated: null, treeContext: null, retryLane: 0, hydrationErrors: null };
    function Ad(n) {
      return { baseLanes: n, cachePool: Xg() };
    }
    function Cd(n, o, i) {
      return n = n !== null ? n.childLanes & ~i : 0, o && (n |= pn), n;
    }
    function iy(n, o, i) {
      var c = o.pendingProps, d = false, h = (o.flags & 128) !== 0, w;
      if ((w = h) || (w = n !== null && n.memoizedState === null ? false : (ut.current & 2) !== 0), w && (d = true, o.flags &= -129), w = (o.flags & 32) !== 0, o.flags &= -33, n === null) {
        if (Ie) {
          if (d ? oo(o) : ao(), (n = Je) ? (n = pb(n, Cn), n = n !== null && n.data !== "&" ? n : null, n !== null && (o.memoizedState = { dehydrated: n, treeContext: Kr !== null ? { id: Jn, overflow: Wn } : null, retryLane: 536870912, hydrationErrors: null }, i = Bg(n), i.return = o, o.child = i, Ot = o, Je = null)) : n = null, n === null) throw Wr(o);
          return lh(n) ? o.lanes = 32 : o.lanes = 536870912, null;
        }
        var A = c.children;
        return c = c.fallback, d ? (ao(), d = o.mode, A = Ql({ mode: "hidden", children: A }, d), c = Zo(c, d, i, null), A.return = o, c.return = o, A.sibling = c, o.child = A, c = o.child, c.memoizedState = Ad(i), c.childLanes = Cd(n, w, i), o.memoizedState = Ed, ls(null, c)) : (oo(o), Td(o, A));
      }
      var z = n.memoizedState;
      if (z !== null && (A = z.dehydrated, A !== null)) {
        if (h) o.flags & 256 ? (oo(o), o.flags &= -257, o = Od(n, o, i)) : o.memoizedState !== null ? (ao(), o.child = n.child, o.flags |= 128, o = null) : (ao(), A = c.fallback, d = o.mode, c = Ql({ mode: "visible", children: c.children }, d), A = Zo(A, d, i, null), A.flags |= 2, c.return = o, A.return = o, c.sibling = A, o.child = c, Ko(o, n.child, null, i), c = o.child, c.memoizedState = Ad(i), c.childLanes = Cd(n, w, i), o.memoizedState = Ed, o = ls(null, c));
        else if (oo(o), lh(A)) {
          if (w = A.nextSibling && A.nextSibling.dataset, w) var H = w.dgst;
          w = H, c = Error(a(419)), c.stack = "", c.digest = w, Gi({ value: c, source: null, stack: null }), o = Od(n, o, i);
        } else if (gt || La(n, o, i, false), w = (i & n.childLanes) !== 0, gt || w) {
          if (w = Ke, w !== null && (c = Yt(w, i), c !== 0 && c !== z.retryLane)) throw z.retryLane = c, Vo(n, c), en(w, n, c), xd;
          sh(A) || oc(), o = Od(n, o, i);
        } else sh(A) ? (o.flags |= 192, o.child = n.child, o = null) : (n = z.treeContext, Je = On(A.nextSibling), Ot = o, Ie = true, Jr = null, Cn = false, n !== null && $g(o, n), o = Td(o, c.children), o.flags |= 4096);
        return o;
      }
      return d ? (ao(), A = c.fallback, d = o.mode, z = n.child, H = z.sibling, c = xr(z, { mode: "hidden", children: c.children }), c.subtreeFlags = z.subtreeFlags & 65011712, H !== null ? A = xr(H, A) : (A = Zo(A, d, i, null), A.flags |= 2), A.return = o, c.return = o, c.sibling = A, o.child = c, ls(null, c), c = o.child, A = n.child.memoizedState, A === null ? A = Ad(i) : (d = A.cachePool, d !== null ? (z = pt._currentValue, d = d.parent !== z ? { parent: z, pool: z } : d) : d = Xg(), A = { baseLanes: A.baseLanes | i, cachePool: d }), c.memoizedState = A, c.childLanes = Cd(n, w, i), o.memoizedState = Ed, ls(n.child, c)) : (oo(o), i = n.child, n = i.sibling, i = xr(i, { mode: "visible", children: c.children }), i.return = o, i.sibling = null, n !== null && (w = o.deletions, w === null ? (o.deletions = [n], o.flags |= 16) : w.push(n)), o.child = i, o.memoizedState = null, i);
    }
    function Td(n, o) {
      return o = Ql({ mode: "visible", children: o }, n.mode), o.return = n, n.child = o;
    }
    function Ql(n, o) {
      return n = un(22, n, null, o), n.lanes = 0, n;
    }
    function Od(n, o, i) {
      return Ko(o, n.child, null, i), n = Td(o, o.pendingProps.children), n.flags |= 2, o.memoizedState = null, n;
    }
    function sy(n, o, i) {
      n.lanes |= o;
      var c = n.alternate;
      c !== null && (c.lanes |= o), Vf(n.return, o, i);
    }
    function Rd(n, o, i, c, d, h) {
      var w = n.memoizedState;
      w === null ? n.memoizedState = { isBackwards: o, rendering: null, renderingStartTime: 0, last: c, tail: i, tailMode: d, treeForkCount: h } : (w.isBackwards = o, w.rendering = null, w.renderingStartTime = 0, w.last = c, w.tail = i, w.tailMode = d, w.treeForkCount = h);
    }
    function ly(n, o, i) {
      var c = o.pendingProps, d = c.revealOrder, h = c.tail;
      c = c.children;
      var w = ut.current, A = (w & 2) !== 0;
      if (A ? (w = w & 1 | 2, o.flags |= 128) : w &= 1, X(ut, w), Mt(n, o, c, i), c = Ie ? Qi : 0, !A && n !== null && (n.flags & 128) !== 0) e: for (n = o.child; n !== null; ) {
        if (n.tag === 13) n.memoizedState !== null && sy(n, i, o);
        else if (n.tag === 19) sy(n, i, o);
        else if (n.child !== null) {
          n.child.return = n, n = n.child;
          continue;
        }
        if (n === o) break e;
        for (; n.sibling === null; ) {
          if (n.return === null || n.return === o) break e;
          n = n.return;
        }
        n.sibling.return = n.return, n = n.sibling;
      }
      switch (d) {
        case "forwards":
          for (i = o.child, d = null; i !== null; ) n = i.alternate, n !== null && Ll(n) === null && (d = i), i = i.sibling;
          i = d, i === null ? (d = o.child, o.child = null) : (d = i.sibling, i.sibling = null), Rd(o, false, d, i, h, c);
          break;
        case "backwards":
        case "unstable_legacy-backwards":
          for (i = null, d = o.child, o.child = null; d !== null; ) {
            if (n = d.alternate, n !== null && Ll(n) === null) {
              o.child = d;
              break;
            }
            n = d.sibling, d.sibling = i, i = d, d = n;
          }
          Rd(o, true, i, null, h, c);
          break;
        case "together":
          Rd(o, false, null, null, void 0, c);
          break;
        default:
          o.memoizedState = null;
      }
      return o.child;
    }
    function Or(n, o, i) {
      if (n !== null && (o.dependencies = n.dependencies), lo |= o.lanes, (i & o.childLanes) === 0) if (n !== null) {
        if (La(n, o, i, false), (i & o.childLanes) === 0) return null;
      } else return null;
      if (n !== null && o.child !== n.child) throw Error(a(153));
      if (o.child !== null) {
        for (n = o.child, i = xr(n, n.pendingProps), o.child = i, i.return = o; n.sibling !== null; ) n = n.sibling, i = i.sibling = xr(n, n.pendingProps), i.return = o;
        i.sibling = null;
      }
      return o.child;
    }
    function Md(n, o) {
      return (n.lanes & o) !== 0 ? true : (n = n.dependencies, !!(n !== null && Rl(n)));
    }
    function DC(n, o, i) {
      switch (o.tag) {
        case 3:
          fe(o, o.stateNode.containerInfo), eo(o, pt, n.memoizedState.cache), Fo();
          break;
        case 27:
        case 5:
          Re(o);
          break;
        case 4:
          fe(o, o.stateNode.containerInfo);
          break;
        case 10:
          eo(o, o.type, o.memoizedProps.value);
          break;
        case 31:
          if (o.memoizedState !== null) return o.flags |= 128, td(o), null;
          break;
        case 13:
          var c = o.memoizedState;
          if (c !== null) return c.dehydrated !== null ? (oo(o), o.flags |= 128, null) : (i & o.child.childLanes) !== 0 ? iy(n, o, i) : (oo(o), n = Or(n, o, i), n !== null ? n.sibling : null);
          oo(o);
          break;
        case 19:
          var d = (n.flags & 128) !== 0;
          if (c = (i & o.childLanes) !== 0, c || (La(n, o, i, false), c = (i & o.childLanes) !== 0), d) {
            if (c) return ly(n, o, i);
            o.flags |= 128;
          }
          if (d = o.memoizedState, d !== null && (d.rendering = null, d.tail = null, d.lastEffect = null), X(ut, ut.current), c) break;
          return null;
        case 22:
          return o.lanes = 0, ey(n, o, i, o.pendingProps);
        case 24:
          eo(o, pt, n.memoizedState.cache);
      }
      return Or(n, o, i);
    }
    function cy(n, o, i) {
      if (n !== null) if (n.memoizedProps !== o.pendingProps) gt = true;
      else {
        if (!Md(n, i) && (o.flags & 128) === 0) return gt = false, DC(n, o, i);
        gt = (n.flags & 131072) !== 0;
      }
      else gt = false, Ie && (o.flags & 1048576) !== 0 && Hg(o, Qi, o.index);
      switch (o.lanes = 0, o.tag) {
        case 16:
          e: {
            var c = o.pendingProps;
            if (n = Qo(o.elementType), o.type = n, typeof n == "function") kf(n) ? (c = Wo(n, c), o.tag = 1, o = oy(null, o, n, c, i)) : (o.tag = 0, o = _d3(null, o, n, c, i));
            else {
              if (n != null) {
                var d = n.$$typeof;
                if (d === D) {
                  o.tag = 11, o = Kv(null, o, n, c, i);
                  break e;
                } else if (d === k) {
                  o.tag = 14, o = Jv(null, o, n, c, i);
                  break e;
                }
              }
              throw o = ue(n) || n, Error(a(306, o, ""));
            }
          }
          return o;
        case 0:
          return _d3(n, o, o.type, o.pendingProps, i);
        case 1:
          return c = o.type, d = Wo(c, o.pendingProps), oy(n, o, c, d, i);
        case 3:
          e: {
            if (fe(o, o.stateNode.containerInfo), n === null) throw Error(a(387));
            c = o.pendingProps;
            var h = o.memoizedState;
            d = h.element, Gf(n, o), rs(o, c, null, i);
            var w = o.memoizedState;
            if (c = w.cache, eo(o, pt, c), c !== h.cache && Zf(o, [pt], i, true), ns(), c = w.element, h.isDehydrated) if (h = { element: c, isDehydrated: false, cache: w.cache }, o.updateQueue.baseState = h, o.memoizedState = h, o.flags & 256) {
              o = ay(n, o, c, i);
              break e;
            } else if (c !== d) {
              d = _n8(Error(a(424)), o), Gi(d), o = ay(n, o, c, i);
              break e;
            } else {
              switch (n = o.stateNode.containerInfo, n.nodeType) {
                case 9:
                  n = n.body;
                  break;
                default:
                  n = n.nodeName === "HTML" ? n.ownerDocument.body : n;
              }
              for (Je = On(n.firstChild), Ot = o, Ie = true, Jr = null, Cn = true, i = ev(o, null, c, i), o.child = i; i; ) i.flags = i.flags & -3 | 4096, i = i.sibling;
            }
            else {
              if (Fo(), c === d) {
                o = Or(n, o, i);
                break e;
              }
              Mt(n, o, c, i);
            }
            o = o.child;
          }
          return o;
        case 26:
          return Xl(n, o), n === null ? (i = wb(o.type, null, o.pendingProps, null)) ? o.memoizedState = i : Ie || (i = o.type, n = o.pendingProps, c = fc(ge.current).createElement(i), c[Tt] = o, c[Xt] = n, Nt(c, i, n), xt(c), o.stateNode = c) : o.memoizedState = wb(o.type, n.memoizedProps, o.pendingProps, n.memoizedState), null;
        case 27:
          return Re(o), n === null && Ie && (c = o.stateNode = vb(o.type, o.pendingProps, ge.current), Ot = o, Cn = true, d = Je, po(o.type) ? (ch = d, Je = On(c.firstChild)) : Je = d), Mt(n, o, o.pendingProps.children, i), Xl(n, o), n === null && (o.flags |= 4194304), o.child;
        case 5:
          return n === null && Ie && ((d = c = Je) && (c = cT(c, o.type, o.pendingProps, Cn), c !== null ? (o.stateNode = c, Ot = o, Je = On(c.firstChild), Cn = false, d = true) : d = false), d || Wr(o)), Re(o), d = o.type, h = o.pendingProps, w = n !== null ? n.memoizedProps : null, c = h.children, oh(d, h) ? c = null : w !== null && oh(d, w) && (o.flags |= 32), o.memoizedState !== null && (d = rd(n, o, EC, null, null, i), _s4._currentValue = d), Xl(n, o), Mt(n, o, c, i), o.child;
        case 6:
          return n === null && Ie && ((n = i = Je) && (i = uT(i, o.pendingProps, Cn), i !== null ? (o.stateNode = i, Ot = o, Je = null, n = true) : n = false), n || Wr(o)), null;
        case 13:
          return iy(n, o, i);
        case 4:
          return fe(o, o.stateNode.containerInfo), c = o.pendingProps, n === null ? o.child = Ko(o, null, c, i) : Mt(n, o, c, i), o.child;
        case 11:
          return Kv(n, o, o.type, o.pendingProps, i);
        case 7:
          return Mt(n, o, o.pendingProps, i), o.child;
        case 8:
          return Mt(n, o, o.pendingProps.children, i), o.child;
        case 12:
          return Mt(n, o, o.pendingProps.children, i), o.child;
        case 10:
          return c = o.pendingProps, eo(o, o.type, c.value), Mt(n, o, c.children, i), o.child;
        case 9:
          return d = o.type._context, c = o.pendingProps.children, Yo(o), d = Rt(d), c = c(d), o.flags |= 1, Mt(n, o, c, i), o.child;
        case 14:
          return Jv(n, o, o.type, o.pendingProps, i);
        case 15:
          return Wv(n, o, o.type, o.pendingProps, i);
        case 19:
          return ly(n, o, i);
        case 31:
          return zC(n, o, i);
        case 22:
          return ey(n, o, i, o.pendingProps);
        case 24:
          return Yo(o), c = Rt(pt), n === null ? (d = Yf(), d === null && (d = Ke, h = Ff(), d.pooledCache = h, h.refCount++, h !== null && (d.pooledCacheLanes |= i), d = h), o.memoizedState = { parent: c, cache: d }, Qf(o), eo(o, pt, d)) : ((n.lanes & i) !== 0 && (Gf(n, o), rs(o, null, null, i), ns()), d = n.memoizedState, h = o.memoizedState, d.parent !== c ? (d = { parent: c, cache: c }, o.memoizedState = d, o.lanes === 0 && (o.memoizedState = o.updateQueue.baseState = d), eo(o, pt, c)) : (c = h.cache, eo(o, pt, c), c !== d.cache && Zf(o, [pt], i, true))), Mt(n, o, o.pendingProps.children, i), o.child;
        case 29:
          throw o.pendingProps;
      }
      throw Error(a(156, o.tag));
    }
    function Rr(n) {
      n.flags |= 4;
    }
    function Nd(n, o, i, c, d) {
      if ((o = (n.mode & 32) !== 0) && (o = false), o) {
        if (n.flags |= 16777216, (d & 335544128) === d) if (n.stateNode.complete) n.flags |= 8192;
        else if (Py()) n.flags |= 8192;
        else throw Go = Dl, Xf;
      } else n.flags &= -16777217;
    }
    function uy(n, o) {
      if (o.type !== "stylesheet" || (o.state.loading & 4) !== 0) n.flags &= -16777217;
      else if (n.flags |= 16777216, !Ab(o)) if (Py()) n.flags |= 8192;
      else throw Go = Dl, Xf;
    }
    function Gl(n, o) {
      o !== null && (n.flags |= 4), n.flags & 16384 && (o = n.tag !== 22 ? Pt() : 536870912, n.lanes |= o, Qa |= o);
    }
    function cs(n, o) {
      if (!Ie) switch (n.tailMode) {
        case "hidden":
          o = n.tail;
          for (var i = null; o !== null; ) o.alternate !== null && (i = o), o = o.sibling;
          i === null ? n.tail = null : i.sibling = null;
          break;
        case "collapsed":
          i = n.tail;
          for (var c = null; i !== null; ) i.alternate !== null && (c = i), i = i.sibling;
          c === null ? o || n.tail === null ? n.tail = null : n.tail.sibling = null : c.sibling = null;
      }
    }
    function We(n) {
      var o = n.alternate !== null && n.alternate.child === n.child, i = 0, c = 0;
      if (o) for (var d = n.child; d !== null; ) i |= d.lanes | d.childLanes, c |= d.subtreeFlags & 65011712, c |= d.flags & 65011712, d.return = n, d = d.sibling;
      else for (d = n.child; d !== null; ) i |= d.lanes | d.childLanes, c |= d.subtreeFlags, c |= d.flags, d.return = n, d = d.sibling;
      return n.subtreeFlags |= c, n.childLanes = i, o;
    }
    function jC(n, o, i) {
      var c = o.pendingProps;
      switch (Bf(o), o.tag) {
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return We(o), null;
        case 1:
          return We(o), null;
        case 3:
          return i = o.stateNode, c = null, n !== null && (c = n.memoizedState.cache), o.memoizedState.cache !== c && (o.flags |= 2048), Ar(pt), xe(), i.pendingContext && (i.context = i.pendingContext, i.pendingContext = null), (n === null || n.child === null) && (Pa(o) ? Rr(o) : n === null || n.memoizedState.isDehydrated && (o.flags & 256) === 0 || (o.flags |= 1024, Hf())), We(o), null;
        case 26:
          var d = o.type, h = o.memoizedState;
          return n === null ? (Rr(o), h !== null ? (We(o), uy(o, h)) : (We(o), Nd(o, d, null, c, i))) : h ? h !== n.memoizedState ? (Rr(o), We(o), uy(o, h)) : (We(o), o.flags &= -16777217) : (n = n.memoizedProps, n !== c && Rr(o), We(o), Nd(o, d, n, c, i)), null;
        case 27:
          if (De(o), i = ge.current, d = o.type, n !== null && o.stateNode != null) n.memoizedProps !== c && Rr(o);
          else {
            if (!c) {
              if (o.stateNode === null) throw Error(a(166));
              return We(o), null;
            }
            n = J.current, Pa(o) ? Vg(o) : (n = vb(d, c, i), o.stateNode = n, Rr(o));
          }
          return We(o), null;
        case 5:
          if (De(o), d = o.type, n !== null && o.stateNode != null) n.memoizedProps !== c && Rr(o);
          else {
            if (!c) {
              if (o.stateNode === null) throw Error(a(166));
              return We(o), null;
            }
            if (h = J.current, Pa(o)) Vg(o);
            else {
              var w = fc(ge.current);
              switch (h) {
                case 1:
                  h = w.createElementNS("http://www.w3.org/2000/svg", d);
                  break;
                case 2:
                  h = w.createElementNS("http://www.w3.org/1998/Math/MathML", d);
                  break;
                default:
                  switch (d) {
                    case "svg":
                      h = w.createElementNS("http://www.w3.org/2000/svg", d);
                      break;
                    case "math":
                      h = w.createElementNS("http://www.w3.org/1998/Math/MathML", d);
                      break;
                    case "script":
                      h = w.createElement("div"), h.innerHTML = "<script><\/script>", h = h.removeChild(h.firstChild);
                      break;
                    case "select":
                      h = typeof c.is == "string" ? w.createElement("select", { is: c.is }) : w.createElement("select"), c.multiple ? h.multiple = true : c.size && (h.size = c.size);
                      break;
                    default:
                      h = typeof c.is == "string" ? w.createElement(d, { is: c.is }) : w.createElement(d);
                  }
              }
              h[Tt] = o, h[Xt] = c;
              e: for (w = o.child; w !== null; ) {
                if (w.tag === 5 || w.tag === 6) h.appendChild(w.stateNode);
                else if (w.tag !== 4 && w.tag !== 27 && w.child !== null) {
                  w.child.return = w, w = w.child;
                  continue;
                }
                if (w === o) break e;
                for (; w.sibling === null; ) {
                  if (w.return === null || w.return === o) break e;
                  w = w.return;
                }
                w.sibling.return = w.return, w = w.sibling;
              }
              o.stateNode = h;
              e: switch (Nt(h, d, c), d) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  c = !!c.autoFocus;
                  break e;
                case "img":
                  c = true;
                  break e;
                default:
                  c = false;
              }
              c && Rr(o);
            }
          }
          return We(o), Nd(o, o.type, n === null ? null : n.memoizedProps, o.pendingProps, i), null;
        case 6:
          if (n && o.stateNode != null) n.memoizedProps !== c && Rr(o);
          else {
            if (typeof c != "string" && o.stateNode === null) throw Error(a(166));
            if (n = ge.current, Pa(o)) {
              if (n = o.stateNode, i = o.memoizedProps, c = null, d = Ot, d !== null) switch (d.tag) {
                case 27:
                case 5:
                  c = d.memoizedProps;
              }
              n[Tt] = o, n = !!(n.nodeValue === i || c !== null && c.suppressHydrationWarning === true || ib(n.nodeValue, i)), n || Wr(o, true);
            } else n = fc(n).createTextNode(c), n[Tt] = o, o.stateNode = n;
          }
          return We(o), null;
        case 31:
          if (i = o.memoizedState, n === null || n.memoizedState !== null) {
            if (c = Pa(o), i !== null) {
              if (n === null) {
                if (!c) throw Error(a(318));
                if (n = o.memoizedState, n = n !== null ? n.dehydrated : null, !n) throw Error(a(557));
                n[Tt] = o;
              } else Fo(), (o.flags & 128) === 0 && (o.memoizedState = null), o.flags |= 4;
              We(o), n = false;
            } else i = Hf(), n !== null && n.memoizedState !== null && (n.memoizedState.hydrationErrors = i), n = true;
            if (!n) return o.flags & 256 ? (dn(o), o) : (dn(o), null);
            if ((o.flags & 128) !== 0) throw Error(a(558));
          }
          return We(o), null;
        case 13:
          if (c = o.memoizedState, n === null || n.memoizedState !== null && n.memoizedState.dehydrated !== null) {
            if (d = Pa(o), c !== null && c.dehydrated !== null) {
              if (n === null) {
                if (!d) throw Error(a(318));
                if (d = o.memoizedState, d = d !== null ? d.dehydrated : null, !d) throw Error(a(317));
                d[Tt] = o;
              } else Fo(), (o.flags & 128) === 0 && (o.memoizedState = null), o.flags |= 4;
              We(o), d = false;
            } else d = Hf(), n !== null && n.memoizedState !== null && (n.memoizedState.hydrationErrors = d), d = true;
            if (!d) return o.flags & 256 ? (dn(o), o) : (dn(o), null);
          }
          return dn(o), (o.flags & 128) !== 0 ? (o.lanes = i, o) : (i = c !== null, n = n !== null && n.memoizedState !== null, i && (c = o.child, d = null, c.alternate !== null && c.alternate.memoizedState !== null && c.alternate.memoizedState.cachePool !== null && (d = c.alternate.memoizedState.cachePool.pool), h = null, c.memoizedState !== null && c.memoizedState.cachePool !== null && (h = c.memoizedState.cachePool.pool), h !== d && (c.flags |= 2048)), i !== n && i && (o.child.flags |= 8192), Gl(o, o.updateQueue), We(o), null);
        case 4:
          return xe(), n === null && Wd(o.stateNode.containerInfo), We(o), null;
        case 10:
          return Ar(o.type), We(o), null;
        case 19:
          if (F(ut), c = o.memoizedState, c === null) return We(o), null;
          if (d = (o.flags & 128) !== 0, h = c.rendering, h === null) if (d) cs(c, false);
          else {
            if (ct !== 0 || n !== null && (n.flags & 128) !== 0) for (n = o.child; n !== null; ) {
              if (h = Ll(n), h !== null) {
                for (o.flags |= 128, cs(c, false), n = h.updateQueue, o.updateQueue = n, Gl(o, n), o.subtreeFlags = 0, n = i, i = o.child; i !== null; ) Ug(i, n), i = i.sibling;
                return X(ut, ut.current & 1 | 2), Ie && _r4(o, c.treeForkCount), o.child;
              }
              n = n.sibling;
            }
            c.tail !== null && Ht() > tc && (o.flags |= 128, d = true, cs(c, false), o.lanes = 4194304);
          }
          else {
            if (!d) if (n = Ll(h), n !== null) {
              if (o.flags |= 128, d = true, n = n.updateQueue, o.updateQueue = n, Gl(o, n), cs(c, true), c.tail === null && c.tailMode === "hidden" && !h.alternate && !Ie) return We(o), null;
            } else 2 * Ht() - c.renderingStartTime > tc && i !== 536870912 && (o.flags |= 128, d = true, cs(c, false), o.lanes = 4194304);
            c.isBackwards ? (h.sibling = o.child, o.child = h) : (n = c.last, n !== null ? n.sibling = h : o.child = h, c.last = h);
          }
          return c.tail !== null ? (n = c.tail, c.rendering = n, c.tail = n.sibling, c.renderingStartTime = Ht(), n.sibling = null, i = ut.current, X(ut, d ? i & 1 | 2 : i & 1), Ie && _r4(o, c.treeForkCount), n) : (We(o), null);
        case 22:
        case 23:
          return dn(o), ed(), c = o.memoizedState !== null, n !== null ? n.memoizedState !== null !== c && (o.flags |= 8192) : c && (o.flags |= 8192), c ? (i & 536870912) !== 0 && (o.flags & 128) === 0 && (We(o), o.subtreeFlags & 6 && (o.flags |= 8192)) : We(o), i = o.updateQueue, i !== null && Gl(o, i.retryQueue), i = null, n !== null && n.memoizedState !== null && n.memoizedState.cachePool !== null && (i = n.memoizedState.cachePool.pool), c = null, o.memoizedState !== null && o.memoizedState.cachePool !== null && (c = o.memoizedState.cachePool.pool), c !== i && (o.flags |= 2048), n !== null && F(Xo), null;
        case 24:
          return i = null, n !== null && (i = n.memoizedState.cache), o.memoizedState.cache !== i && (o.flags |= 2048), Ar(pt), We(o), null;
        case 25:
          return null;
        case 30:
          return null;
      }
      throw Error(a(156, o.tag));
    }
    function kC(n, o) {
      switch (Bf(o), o.tag) {
        case 1:
          return n = o.flags, n & 65536 ? (o.flags = n & -65537 | 128, o) : null;
        case 3:
          return Ar(pt), xe(), n = o.flags, (n & 65536) !== 0 && (n & 128) === 0 ? (o.flags = n & -65537 | 128, o) : null;
        case 26:
        case 27:
        case 5:
          return De(o), null;
        case 31:
          if (o.memoizedState !== null) {
            if (dn(o), o.alternate === null) throw Error(a(340));
            Fo();
          }
          return n = o.flags, n & 65536 ? (o.flags = n & -65537 | 128, o) : null;
        case 13:
          if (dn(o), n = o.memoizedState, n !== null && n.dehydrated !== null) {
            if (o.alternate === null) throw Error(a(340));
            Fo();
          }
          return n = o.flags, n & 65536 ? (o.flags = n & -65537 | 128, o) : null;
        case 19:
          return F(ut), null;
        case 4:
          return xe(), null;
        case 10:
          return Ar(o.type), null;
        case 22:
        case 23:
          return dn(o), ed(), n !== null && F(Xo), n = o.flags, n & 65536 ? (o.flags = n & -65537 | 128, o) : null;
        case 24:
          return Ar(pt), null;
        case 25:
          return null;
        default:
          return null;
      }
    }
    function fy(n, o) {
      switch (Bf(o), o.tag) {
        case 3:
          Ar(pt), xe();
          break;
        case 26:
        case 27:
        case 5:
          De(o);
          break;
        case 4:
          xe();
          break;
        case 31:
          o.memoizedState !== null && dn(o);
          break;
        case 13:
          dn(o);
          break;
        case 19:
          F(ut);
          break;
        case 10:
          Ar(o.type);
          break;
        case 22:
        case 23:
          dn(o), ed(), n !== null && F(Xo);
          break;
        case 24:
          Ar(pt);
      }
    }
    function us(n, o) {
      try {
        var i = o.updateQueue, c = i !== null ? i.lastEffect : null;
        if (c !== null) {
          var d = c.next;
          i = d;
          do {
            if ((i.tag & n) === n) {
              c = void 0;
              var h = i.create, w = i.inst;
              c = h(), w.destroy = c;
            }
            i = i.next;
          } while (i !== d);
        }
      } catch (A) {
        qe(o, o.return, A);
      }
    }
    function io(n, o, i) {
      try {
        var c = o.updateQueue, d = c !== null ? c.lastEffect : null;
        if (d !== null) {
          var h = d.next;
          c = h;
          do {
            if ((c.tag & n) === n) {
              var w = c.inst, A = w.destroy;
              if (A !== void 0) {
                w.destroy = void 0, d = o;
                var z = i, H = A;
                try {
                  H();
                } catch (Q) {
                  qe(d, z, Q);
                }
              }
            }
            c = c.next;
          } while (c !== h);
        }
      } catch (Q) {
        qe(o, o.return, Q);
      }
    }
    function dy(n) {
      var o = n.updateQueue;
      if (o !== null) {
        var i = n.stateNode;
        try {
          nv(o, i);
        } catch (c) {
          qe(n, n.return, c);
        }
      }
    }
    function hy(n, o, i) {
      i.props = Wo(n.type, n.memoizedProps), i.state = n.memoizedState;
      try {
        i.componentWillUnmount();
      } catch (c) {
        qe(n, o, c);
      }
    }
    function fs(n, o) {
      try {
        var i = n.ref;
        if (i !== null) {
          switch (n.tag) {
            case 26:
            case 27:
            case 5:
              var c = n.stateNode;
              break;
            case 30:
              c = n.stateNode;
              break;
            default:
              c = n.stateNode;
          }
          typeof i == "function" ? n.refCleanup = i(c) : i.current = c;
        }
      } catch (d) {
        qe(n, o, d);
      }
    }
    function er(n, o) {
      var i = n.ref, c = n.refCleanup;
      if (i !== null) if (typeof c == "function") try {
        c();
      } catch (d) {
        qe(n, o, d);
      } finally {
        n.refCleanup = null, n = n.alternate, n != null && (n.refCleanup = null);
      }
      else if (typeof i == "function") try {
        i(null);
      } catch (d) {
        qe(n, o, d);
      }
      else i.current = null;
    }
    function py(n) {
      var o = n.type, i = n.memoizedProps, c = n.stateNode;
      try {
        e: switch (o) {
          case "button":
          case "input":
          case "select":
          case "textarea":
            i.autoFocus && c.focus();
            break e;
          case "img":
            i.src ? c.src = i.src : i.srcSet && (c.srcset = i.srcSet);
        }
      } catch (d) {
        qe(n, n.return, d);
      }
    }
    function zd(n, o, i) {
      try {
        var c = n.stateNode;
        rT(c, n.type, i, o), c[Xt] = o;
      } catch (d) {
        qe(n, n.return, d);
      }
    }
    function my(n) {
      return n.tag === 5 || n.tag === 3 || n.tag === 26 || n.tag === 27 && po(n.type) || n.tag === 4;
    }
    function Dd(n) {
      e: for (; ; ) {
        for (; n.sibling === null; ) {
          if (n.return === null || my(n.return)) return null;
          n = n.return;
        }
        for (n.sibling.return = n.return, n = n.sibling; n.tag !== 5 && n.tag !== 6 && n.tag !== 18; ) {
          if (n.tag === 27 && po(n.type) || n.flags & 2 || n.child === null || n.tag === 4) continue e;
          n.child.return = n, n = n.child;
        }
        if (!(n.flags & 2)) return n.stateNode;
      }
    }
    function jd(n, o, i) {
      var c = n.tag;
      if (c === 5 || c === 6) n = n.stateNode, o ? (i.nodeType === 9 ? i.body : i.nodeName === "HTML" ? i.ownerDocument.body : i).insertBefore(n, o) : (o = i.nodeType === 9 ? i.body : i.nodeName === "HTML" ? i.ownerDocument.body : i, o.appendChild(n), i = i._reactRootContainer, i != null || o.onclick !== null || (o.onclick = wr));
      else if (c !== 4 && (c === 27 && po(n.type) && (i = n.stateNode, o = null), n = n.child, n !== null)) for (jd(n, o, i), n = n.sibling; n !== null; ) jd(n, o, i), n = n.sibling;
    }
    function Kl(n, o, i) {
      var c = n.tag;
      if (c === 5 || c === 6) n = n.stateNode, o ? i.insertBefore(n, o) : i.appendChild(n);
      else if (c !== 4 && (c === 27 && po(n.type) && (i = n.stateNode), n = n.child, n !== null)) for (Kl(n, o, i), n = n.sibling; n !== null; ) Kl(n, o, i), n = n.sibling;
    }
    function gy(n) {
      var o = n.stateNode, i = n.memoizedProps;
      try {
        for (var c = n.type, d = o.attributes; d.length; ) o.removeAttributeNode(d[0]);
        Nt(o, c, i), o[Tt] = n, o[Xt] = i;
      } catch (h) {
        qe(n, n.return, h);
      }
    }
    var Mr = false, vt = false, kd = false, vy = typeof WeakSet == "function" ? WeakSet : Set, _t9 = null;
    function PC(n, o) {
      if (n = n.containerInfo, nh = yc, n = Rg(n), Of(n)) {
        if ("selectionStart" in n) var i = { start: n.selectionStart, end: n.selectionEnd };
        else e: {
          i = (i = n.ownerDocument) && i.defaultView || window;
          var c = i.getSelection && i.getSelection();
          if (c && c.rangeCount !== 0) {
            i = c.anchorNode;
            var d = c.anchorOffset, h = c.focusNode;
            c = c.focusOffset;
            try {
              i.nodeType, h.nodeType;
            } catch {
              i = null;
              break e;
            }
            var w = 0, A = -1, z = -1, H = 0, Q = 0, ee = n, V = null;
            t: for (; ; ) {
              for (var Y; ee !== i || d !== 0 && ee.nodeType !== 3 || (A = w + d), ee !== h || c !== 0 && ee.nodeType !== 3 || (z = w + c), ee.nodeType === 3 && (w += ee.nodeValue.length), (Y = ee.firstChild) !== null; ) V = ee, ee = Y;
              for (; ; ) {
                if (ee === n) break t;
                if (V === i && ++H === d && (A = w), V === h && ++Q === c && (z = w), (Y = ee.nextSibling) !== null) break;
                ee = V, V = ee.parentNode;
              }
              ee = Y;
            }
            i = A === -1 || z === -1 ? null : { start: A, end: z };
          } else i = null;
        }
        i = i || { start: 0, end: 0 };
      } else i = null;
      for (rh = { focusedElem: n, selectionRange: i }, yc = false, _t9 = o; _t9 !== null; ) if (o = _t9, n = o.child, (o.subtreeFlags & 1028) !== 0 && n !== null) n.return = o, _t9 = n;
      else for (; _t9 !== null; ) {
        switch (o = _t9, h = o.alternate, n = o.flags, o.tag) {
          case 0:
            if ((n & 4) !== 0 && (n = o.updateQueue, n = n !== null ? n.events : null, n !== null)) for (i = 0; i < n.length; i++) d = n[i], d.ref.impl = d.nextImpl;
            break;
          case 11:
          case 15:
            break;
          case 1:
            if ((n & 1024) !== 0 && h !== null) {
              n = void 0, i = o, d = h.memoizedProps, h = h.memoizedState, c = i.stateNode;
              try {
                var de = Wo(i.type, d);
                n = c.getSnapshotBeforeUpdate(de, h), c.__reactInternalSnapshotBeforeUpdate = n;
              } catch (we) {
                qe(i, i.return, we);
              }
            }
            break;
          case 3:
            if ((n & 1024) !== 0) {
              if (n = o.stateNode.containerInfo, i = n.nodeType, i === 9) ih(n);
              else if (i === 1) switch (n.nodeName) {
                case "HEAD":
                case "HTML":
                case "BODY":
                  ih(n);
                  break;
                default:
                  n.textContent = "";
              }
            }
            break;
          case 5:
          case 26:
          case 27:
          case 6:
          case 4:
          case 17:
            break;
          default:
            if ((n & 1024) !== 0) throw Error(a(163));
        }
        if (n = o.sibling, n !== null) {
          n.return = o.return, _t9 = n;
          break;
        }
        _t9 = o.return;
      }
    }
    function yy(n, o, i) {
      var c = i.flags;
      switch (i.tag) {
        case 0:
        case 11:
        case 15:
          zr(n, i), c & 4 && us(5, i);
          break;
        case 1:
          if (zr(n, i), c & 4) if (n = i.stateNode, o === null) try {
            n.componentDidMount();
          } catch (w) {
            qe(i, i.return, w);
          }
          else {
            var d = Wo(i.type, o.memoizedProps);
            o = o.memoizedState;
            try {
              n.componentDidUpdate(d, o, n.__reactInternalSnapshotBeforeUpdate);
            } catch (w) {
              qe(i, i.return, w);
            }
          }
          c & 64 && dy(i), c & 512 && fs(i, i.return);
          break;
        case 3:
          if (zr(n, i), c & 64 && (n = i.updateQueue, n !== null)) {
            if (o = null, i.child !== null) switch (i.child.tag) {
              case 27:
              case 5:
                o = i.child.stateNode;
                break;
              case 1:
                o = i.child.stateNode;
            }
            try {
              nv(n, o);
            } catch (w) {
              qe(i, i.return, w);
            }
          }
          break;
        case 27:
          o === null && c & 4 && gy(i);
        case 26:
        case 5:
          zr(n, i), o === null && c & 4 && py(i), c & 512 && fs(i, i.return);
          break;
        case 12:
          zr(n, i);
          break;
        case 31:
          zr(n, i), c & 4 && Sy(n, i);
          break;
        case 13:
          zr(n, i), c & 4 && xy(n, i), c & 64 && (n = i.memoizedState, n !== null && (n = n.dehydrated, n !== null && (i = FC.bind(null, i), fT(n, i))));
          break;
        case 22:
          if (c = i.memoizedState !== null || Mr, !c) {
            o = o !== null && o.memoizedState !== null || vt, d = Mr;
            var h = vt;
            Mr = c, (vt = o) && !h ? Dr(n, i, (i.subtreeFlags & 8772) !== 0) : zr(n, i), Mr = d, vt = h;
          }
          break;
        case 30:
          break;
        default:
          zr(n, i);
      }
    }
    function by(n) {
      var o = n.alternate;
      o !== null && (n.alternate = null, by(o)), n.child = null, n.deletions = null, n.sibling = null, n.tag === 5 && (o = n.stateNode, o !== null && ff(o)), n.stateNode = null, n.return = null, n.dependencies = null, n.memoizedProps = null, n.memoizedState = null, n.pendingProps = null, n.stateNode = null, n.updateQueue = null;
    }
    var nt = null, Gt = false;
    function Nr(n, o, i) {
      for (i = i.child; i !== null; ) wy(n, o, i), i = i.sibling;
    }
    function wy(n, o, i) {
      if ($t && typeof $t.onCommitFiberUnmount == "function") try {
        $t.onCommitFiberUnmount(Po, i);
      } catch {
      }
      switch (i.tag) {
        case 26:
          vt || er(i, o), Nr(n, o, i), i.memoizedState ? i.memoizedState.count-- : i.stateNode && (i = i.stateNode, i.parentNode.removeChild(i));
          break;
        case 27:
          vt || er(i, o);
          var c = nt, d = Gt;
          po(i.type) && (nt = i.stateNode, Gt = false), Nr(n, o, i), ws(i.stateNode), nt = c, Gt = d;
          break;
        case 5:
          vt || er(i, o);
        case 6:
          if (c = nt, d = Gt, nt = null, Nr(n, o, i), nt = c, Gt = d, nt !== null) if (Gt) try {
            (nt.nodeType === 9 ? nt.body : nt.nodeName === "HTML" ? nt.ownerDocument.body : nt).removeChild(i.stateNode);
          } catch (h) {
            qe(i, o, h);
          }
          else try {
            nt.removeChild(i.stateNode);
          } catch (h) {
            qe(i, o, h);
          }
          break;
        case 18:
          nt !== null && (Gt ? (n = nt, db(n.nodeType === 9 ? n.body : n.nodeName === "HTML" ? n.ownerDocument.body : n, i.stateNode), ri(n)) : db(nt, i.stateNode));
          break;
        case 4:
          c = nt, d = Gt, nt = i.stateNode.containerInfo, Gt = true, Nr(n, o, i), nt = c, Gt = d;
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          io(2, i, o), vt || io(4, i, o), Nr(n, o, i);
          break;
        case 1:
          vt || (er(i, o), c = i.stateNode, typeof c.componentWillUnmount == "function" && hy(i, o, c)), Nr(n, o, i);
          break;
        case 21:
          Nr(n, o, i);
          break;
        case 22:
          vt = (c = vt) || i.memoizedState !== null, Nr(n, o, i), vt = c;
          break;
        default:
          Nr(n, o, i);
      }
    }
    function Sy(n, o) {
      if (o.memoizedState === null && (n = o.alternate, n !== null && (n = n.memoizedState, n !== null))) {
        n = n.dehydrated;
        try {
          ri(n);
        } catch (i) {
          qe(o, o.return, i);
        }
      }
    }
    function xy(n, o) {
      if (o.memoizedState === null && (n = o.alternate, n !== null && (n = n.memoizedState, n !== null && (n = n.dehydrated, n !== null)))) try {
        ri(n);
      } catch (i) {
        qe(o, o.return, i);
      }
    }
    function LC(n) {
      switch (n.tag) {
        case 31:
        case 13:
        case 19:
          var o = n.stateNode;
          return o === null && (o = n.stateNode = new vy()), o;
        case 22:
          return n = n.stateNode, o = n._retryCache, o === null && (o = n._retryCache = new vy()), o;
        default:
          throw Error(a(435, n.tag));
      }
    }
    function Jl(n, o) {
      var i = LC(n);
      o.forEach(function(c) {
        if (!i.has(c)) {
          i.add(c);
          var d = qC.bind(null, n, c);
          c.then(d, d);
        }
      });
    }
    function Kt(n, o) {
      var i = o.deletions;
      if (i !== null) for (var c = 0; c < i.length; c++) {
        var d = i[c], h = n, w = o, A = w;
        e: for (; A !== null; ) {
          switch (A.tag) {
            case 27:
              if (po(A.type)) {
                nt = A.stateNode, Gt = false;
                break e;
              }
              break;
            case 5:
              nt = A.stateNode, Gt = false;
              break e;
            case 3:
            case 4:
              nt = A.stateNode.containerInfo, Gt = true;
              break e;
          }
          A = A.return;
        }
        if (nt === null) throw Error(a(160));
        wy(h, w, d), nt = null, Gt = false, h = d.alternate, h !== null && (h.return = null), d.return = null;
      }
      if (o.subtreeFlags & 13886) for (o = o.child; o !== null; ) _y(o, n), o = o.sibling;
    }
    var Un = null;
    function _y(n, o) {
      var i = n.alternate, c = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          Kt(o, n), Jt(n), c & 4 && (io(3, n, n.return), us(3, n), io(5, n, n.return));
          break;
        case 1:
          Kt(o, n), Jt(n), c & 512 && (vt || i === null || er(i, i.return)), c & 64 && Mr && (n = n.updateQueue, n !== null && (c = n.callbacks, c !== null && (i = n.shared.hiddenCallbacks, n.shared.hiddenCallbacks = i === null ? c : i.concat(c))));
          break;
        case 26:
          var d = Un;
          if (Kt(o, n), Jt(n), c & 512 && (vt || i === null || er(i, i.return)), c & 4) {
            var h = i !== null ? i.memoizedState : null;
            if (c = n.memoizedState, i === null) if (c === null) if (n.stateNode === null) {
              e: {
                c = n.type, i = n.memoizedProps, d = d.ownerDocument || d;
                t: switch (c) {
                  case "title":
                    h = d.getElementsByTagName("title")[0], (!h || h[Ui] || h[Tt] || h.namespaceURI === "http://www.w3.org/2000/svg" || h.hasAttribute("itemprop")) && (h = d.createElement(c), d.head.insertBefore(h, d.querySelector("head > title"))), Nt(h, c, i), h[Tt] = n, xt(h), c = h;
                    break e;
                  case "link":
                    var w = _b2("link", "href", d).get(c + (i.href || ""));
                    if (w) {
                      for (var A = 0; A < w.length; A++) if (h = w[A], h.getAttribute("href") === (i.href == null || i.href === "" ? null : i.href) && h.getAttribute("rel") === (i.rel == null ? null : i.rel) && h.getAttribute("title") === (i.title == null ? null : i.title) && h.getAttribute("crossorigin") === (i.crossOrigin == null ? null : i.crossOrigin)) {
                        w.splice(A, 1);
                        break t;
                      }
                    }
                    h = d.createElement(c), Nt(h, c, i), d.head.appendChild(h);
                    break;
                  case "meta":
                    if (w = _b2("meta", "content", d).get(c + (i.content || ""))) {
                      for (A = 0; A < w.length; A++) if (h = w[A], h.getAttribute("content") === (i.content == null ? null : "" + i.content) && h.getAttribute("name") === (i.name == null ? null : i.name) && h.getAttribute("property") === (i.property == null ? null : i.property) && h.getAttribute("http-equiv") === (i.httpEquiv == null ? null : i.httpEquiv) && h.getAttribute("charset") === (i.charSet == null ? null : i.charSet)) {
                        w.splice(A, 1);
                        break t;
                      }
                    }
                    h = d.createElement(c), Nt(h, c, i), d.head.appendChild(h);
                    break;
                  default:
                    throw Error(a(468, c));
                }
                h[Tt] = n, xt(h), c = h;
              }
              n.stateNode = c;
            } else Eb(d, n.type, n.stateNode);
            else n.stateNode = xb(d, c, n.memoizedProps);
            else h !== c ? (h === null ? i.stateNode !== null && (i = i.stateNode, i.parentNode.removeChild(i)) : h.count--, c === null ? Eb(d, n.type, n.stateNode) : xb(d, c, n.memoizedProps)) : c === null && n.stateNode !== null && zd(n, n.memoizedProps, i.memoizedProps);
          }
          break;
        case 27:
          Kt(o, n), Jt(n), c & 512 && (vt || i === null || er(i, i.return)), i !== null && c & 4 && zd(n, n.memoizedProps, i.memoizedProps);
          break;
        case 5:
          if (Kt(o, n), Jt(n), c & 512 && (vt || i === null || er(i, i.return)), n.flags & 32) {
            d = n.stateNode;
            try {
              Ca(d, "");
            } catch (de) {
              qe(n, n.return, de);
            }
          }
          c & 4 && n.stateNode != null && (d = n.memoizedProps, zd(n, d, i !== null ? i.memoizedProps : d)), c & 1024 && (kd = true);
          break;
        case 6:
          if (Kt(o, n), Jt(n), c & 4) {
            if (n.stateNode === null) throw Error(a(162));
            c = n.memoizedProps, i = n.stateNode;
            try {
              i.nodeValue = c;
            } catch (de) {
              qe(n, n.return, de);
            }
          }
          break;
        case 3:
          if (pc = null, d = Un, Un = dc(o.containerInfo), Kt(o, n), Un = d, Jt(n), c & 4 && i !== null && i.memoizedState.isDehydrated) try {
            ri(o.containerInfo);
          } catch (de) {
            qe(n, n.return, de);
          }
          kd && (kd = false, Ey(n));
          break;
        case 4:
          c = Un, Un = dc(n.stateNode.containerInfo), Kt(o, n), Jt(n), Un = c;
          break;
        case 12:
          Kt(o, n), Jt(n);
          break;
        case 31:
          Kt(o, n), Jt(n), c & 4 && (c = n.updateQueue, c !== null && (n.updateQueue = null, Jl(n, c)));
          break;
        case 13:
          Kt(o, n), Jt(n), n.child.flags & 8192 && n.memoizedState !== null != (i !== null && i.memoizedState !== null) && (ec = Ht()), c & 4 && (c = n.updateQueue, c !== null && (n.updateQueue = null, Jl(n, c)));
          break;
        case 22:
          d = n.memoizedState !== null;
          var z = i !== null && i.memoizedState !== null, H = Mr, Q = vt;
          if (Mr = H || d, vt = Q || z, Kt(o, n), vt = Q, Mr = H, Jt(n), c & 8192) e: for (o = n.stateNode, o._visibility = d ? o._visibility & -2 : o._visibility | 1, d && (i === null || z || Mr || vt || ea(n)), i = null, o = n; ; ) {
            if (o.tag === 5 || o.tag === 26) {
              if (i === null) {
                z = i = o;
                try {
                  if (h = z.stateNode, d) w = h.style, typeof w.setProperty == "function" ? w.setProperty("display", "none", "important") : w.display = "none";
                  else {
                    A = z.stateNode;
                    var ee = z.memoizedProps.style, V = ee != null && ee.hasOwnProperty("display") ? ee.display : null;
                    A.style.display = V == null || typeof V == "boolean" ? "" : ("" + V).trim();
                  }
                } catch (de) {
                  qe(z, z.return, de);
                }
              }
            } else if (o.tag === 6) {
              if (i === null) {
                z = o;
                try {
                  z.stateNode.nodeValue = d ? "" : z.memoizedProps;
                } catch (de) {
                  qe(z, z.return, de);
                }
              }
            } else if (o.tag === 18) {
              if (i === null) {
                z = o;
                try {
                  var Y = z.stateNode;
                  d ? hb(Y, true) : hb(z.stateNode, false);
                } catch (de) {
                  qe(z, z.return, de);
                }
              }
            } else if ((o.tag !== 22 && o.tag !== 23 || o.memoizedState === null || o === n) && o.child !== null) {
              o.child.return = o, o = o.child;
              continue;
            }
            if (o === n) break e;
            for (; o.sibling === null; ) {
              if (o.return === null || o.return === n) break e;
              i === o && (i = null), o = o.return;
            }
            i === o && (i = null), o.sibling.return = o.return, o = o.sibling;
          }
          c & 4 && (c = n.updateQueue, c !== null && (i = c.retryQueue, i !== null && (c.retryQueue = null, Jl(n, i))));
          break;
        case 19:
          Kt(o, n), Jt(n), c & 4 && (c = n.updateQueue, c !== null && (n.updateQueue = null, Jl(n, c)));
          break;
        case 30:
          break;
        case 21:
          break;
        default:
          Kt(o, n), Jt(n);
      }
    }
    function Jt(n) {
      var o = n.flags;
      if (o & 2) {
        try {
          for (var i, c = n.return; c !== null; ) {
            if (my(c)) {
              i = c;
              break;
            }
            c = c.return;
          }
          if (i == null) throw Error(a(160));
          switch (i.tag) {
            case 27:
              var d = i.stateNode, h = Dd(n);
              Kl(n, h, d);
              break;
            case 5:
              var w = i.stateNode;
              i.flags & 32 && (Ca(w, ""), i.flags &= -33);
              var A = Dd(n);
              Kl(n, A, w);
              break;
            case 3:
            case 4:
              var z = i.stateNode.containerInfo, H = Dd(n);
              jd(n, H, z);
              break;
            default:
              throw Error(a(161));
          }
        } catch (Q) {
          qe(n, n.return, Q);
        }
        n.flags &= -3;
      }
      o & 4096 && (n.flags &= -4097);
    }
    function Ey(n) {
      if (n.subtreeFlags & 1024) for (n = n.child; n !== null; ) {
        var o = n;
        Ey(o), o.tag === 5 && o.flags & 1024 && o.stateNode.reset(), n = n.sibling;
      }
    }
    function zr(n, o) {
      if (o.subtreeFlags & 8772) for (o = o.child; o !== null; ) yy(n, o.alternate, o), o = o.sibling;
    }
    function ea(n) {
      for (n = n.child; n !== null; ) {
        var o = n;
        switch (o.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            io(4, o, o.return), ea(o);
            break;
          case 1:
            er(o, o.return);
            var i = o.stateNode;
            typeof i.componentWillUnmount == "function" && hy(o, o.return, i), ea(o);
            break;
          case 27:
            ws(o.stateNode);
          case 26:
          case 5:
            er(o, o.return), ea(o);
            break;
          case 22:
            o.memoizedState === null && ea(o);
            break;
          case 30:
            ea(o);
            break;
          default:
            ea(o);
        }
        n = n.sibling;
      }
    }
    function Dr(n, o, i) {
      for (i = i && (o.subtreeFlags & 8772) !== 0, o = o.child; o !== null; ) {
        var c = o.alternate, d = n, h = o, w = h.flags;
        switch (h.tag) {
          case 0:
          case 11:
          case 15:
            Dr(d, h, i), us(4, h);
            break;
          case 1:
            if (Dr(d, h, i), c = h, d = c.stateNode, typeof d.componentDidMount == "function") try {
              d.componentDidMount();
            } catch (H) {
              qe(c, c.return, H);
            }
            if (c = h, d = c.updateQueue, d !== null) {
              var A = c.stateNode;
              try {
                var z = d.shared.hiddenCallbacks;
                if (z !== null) for (d.shared.hiddenCallbacks = null, d = 0; d < z.length; d++) tv(z[d], A);
              } catch (H) {
                qe(c, c.return, H);
              }
            }
            i && w & 64 && dy(h), fs(h, h.return);
            break;
          case 27:
            gy(h);
          case 26:
          case 5:
            Dr(d, h, i), i && c === null && w & 4 && py(h), fs(h, h.return);
            break;
          case 12:
            Dr(d, h, i);
            break;
          case 31:
            Dr(d, h, i), i && w & 4 && Sy(d, h);
            break;
          case 13:
            Dr(d, h, i), i && w & 4 && xy(d, h);
            break;
          case 22:
            h.memoizedState === null && Dr(d, h, i), fs(h, h.return);
            break;
          case 30:
            break;
          default:
            Dr(d, h, i);
        }
        o = o.sibling;
      }
    }
    function Pd(n, o) {
      var i = null;
      n !== null && n.memoizedState !== null && n.memoizedState.cachePool !== null && (i = n.memoizedState.cachePool.pool), n = null, o.memoizedState !== null && o.memoizedState.cachePool !== null && (n = o.memoizedState.cachePool.pool), n !== i && (n != null && n.refCount++, i != null && Ki(i));
    }
    function Ld(n, o) {
      n = null, o.alternate !== null && (n = o.alternate.memoizedState.cache), o = o.memoizedState.cache, o !== n && (o.refCount++, n != null && Ki(n));
    }
    function Bn(n, o, i, c) {
      if (o.subtreeFlags & 10256) for (o = o.child; o !== null; ) Ay(n, o, i, c), o = o.sibling;
    }
    function Ay(n, o, i, c) {
      var d = o.flags;
      switch (o.tag) {
        case 0:
        case 11:
        case 15:
          Bn(n, o, i, c), d & 2048 && us(9, o);
          break;
        case 1:
          Bn(n, o, i, c);
          break;
        case 3:
          Bn(n, o, i, c), d & 2048 && (n = null, o.alternate !== null && (n = o.alternate.memoizedState.cache), o = o.memoizedState.cache, o !== n && (o.refCount++, n != null && Ki(n)));
          break;
        case 12:
          if (d & 2048) {
            Bn(n, o, i, c), n = o.stateNode;
            try {
              var h = o.memoizedProps, w = h.id, A = h.onPostCommit;
              typeof A == "function" && A(w, o.alternate === null ? "mount" : "update", n.passiveEffectDuration, -0);
            } catch (z) {
              qe(o, o.return, z);
            }
          } else Bn(n, o, i, c);
          break;
        case 31:
          Bn(n, o, i, c);
          break;
        case 13:
          Bn(n, o, i, c);
          break;
        case 23:
          break;
        case 22:
          h = o.stateNode, w = o.alternate, o.memoizedState !== null ? h._visibility & 2 ? Bn(n, o, i, c) : ds(n, o) : h._visibility & 2 ? Bn(n, o, i, c) : (h._visibility |= 2, qa(n, o, i, c, (o.subtreeFlags & 10256) !== 0 || false)), d & 2048 && Pd(w, o);
          break;
        case 24:
          Bn(n, o, i, c), d & 2048 && Ld(o.alternate, o);
          break;
        default:
          Bn(n, o, i, c);
      }
    }
    function qa(n, o, i, c, d) {
      for (d = d && ((o.subtreeFlags & 10256) !== 0 || false), o = o.child; o !== null; ) {
        var h = n, w = o, A = i, z = c, H = w.flags;
        switch (w.tag) {
          case 0:
          case 11:
          case 15:
            qa(h, w, A, z, d), us(8, w);
            break;
          case 23:
            break;
          case 22:
            var Q = w.stateNode;
            w.memoizedState !== null ? Q._visibility & 2 ? qa(h, w, A, z, d) : ds(h, w) : (Q._visibility |= 2, qa(h, w, A, z, d)), d && H & 2048 && Pd(w.alternate, w);
            break;
          case 24:
            qa(h, w, A, z, d), d && H & 2048 && Ld(w.alternate, w);
            break;
          default:
            qa(h, w, A, z, d);
        }
        o = o.sibling;
      }
    }
    function ds(n, o) {
      if (o.subtreeFlags & 10256) for (o = o.child; o !== null; ) {
        var i = n, c = o, d = c.flags;
        switch (c.tag) {
          case 22:
            ds(i, c), d & 2048 && Pd(c.alternate, c);
            break;
          case 24:
            ds(i, c), d & 2048 && Ld(c.alternate, c);
            break;
          default:
            ds(i, c);
        }
        o = o.sibling;
      }
    }
    var hs = 8192;
    function Ya(n, o, i) {
      if (n.subtreeFlags & hs) for (n = n.child; n !== null; ) Cy(n, o, i), n = n.sibling;
    }
    function Cy(n, o, i) {
      switch (n.tag) {
        case 26:
          Ya(n, o, i), n.flags & hs && n.memoizedState !== null && _T(i, Un, n.memoizedState, n.memoizedProps);
          break;
        case 5:
          Ya(n, o, i);
          break;
        case 3:
        case 4:
          var c = Un;
          Un = dc(n.stateNode.containerInfo), Ya(n, o, i), Un = c;
          break;
        case 22:
          n.memoizedState === null && (c = n.alternate, c !== null && c.memoizedState !== null ? (c = hs, hs = 16777216, Ya(n, o, i), hs = c) : Ya(n, o, i));
          break;
        default:
          Ya(n, o, i);
      }
    }
    function Ty(n) {
      var o = n.alternate;
      if (o !== null && (n = o.child, n !== null)) {
        o.child = null;
        do
          o = n.sibling, n.sibling = null, n = o;
        while (n !== null);
      }
    }
    function ps(n) {
      var o = n.deletions;
      if ((n.flags & 16) !== 0) {
        if (o !== null) for (var i = 0; i < o.length; i++) {
          var c = o[i];
          _t9 = c, Ry(c, n);
        }
        Ty(n);
      }
      if (n.subtreeFlags & 10256) for (n = n.child; n !== null; ) Oy(n), n = n.sibling;
    }
    function Oy(n) {
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          ps(n), n.flags & 2048 && io(9, n, n.return);
          break;
        case 3:
          ps(n);
          break;
        case 12:
          ps(n);
          break;
        case 22:
          var o = n.stateNode;
          n.memoizedState !== null && o._visibility & 2 && (n.return === null || n.return.tag !== 13) ? (o._visibility &= -3, Wl(n)) : ps(n);
          break;
        default:
          ps(n);
      }
    }
    function Wl(n) {
      var o = n.deletions;
      if ((n.flags & 16) !== 0) {
        if (o !== null) for (var i = 0; i < o.length; i++) {
          var c = o[i];
          _t9 = c, Ry(c, n);
        }
        Ty(n);
      }
      for (n = n.child; n !== null; ) {
        switch (o = n, o.tag) {
          case 0:
          case 11:
          case 15:
            io(8, o, o.return), Wl(o);
            break;
          case 22:
            i = o.stateNode, i._visibility & 2 && (i._visibility &= -3, Wl(o));
            break;
          default:
            Wl(o);
        }
        n = n.sibling;
      }
    }
    function Ry(n, o) {
      for (; _t9 !== null; ) {
        var i = _t9;
        switch (i.tag) {
          case 0:
          case 11:
          case 15:
            io(8, i, o);
            break;
          case 23:
          case 22:
            if (i.memoizedState !== null && i.memoizedState.cachePool !== null) {
              var c = i.memoizedState.cachePool.pool;
              c != null && c.refCount++;
            }
            break;
          case 24:
            Ki(i.memoizedState.cache);
        }
        if (c = i.child, c !== null) c.return = i, _t9 = c;
        else e: for (i = n; _t9 !== null; ) {
          c = _t9;
          var d = c.sibling, h = c.return;
          if (by(c), c === i) {
            _t9 = null;
            break e;
          }
          if (d !== null) {
            d.return = h, _t9 = d;
            break e;
          }
          _t9 = h;
        }
      }
    }
    var UC = { getCacheForType: function(n) {
      var o = Rt(pt), i = o.data.get(n);
      return i === void 0 && (i = n(), o.data.set(n, i)), i;
    }, cacheSignal: function() {
      return Rt(pt).controller.signal;
    } }, BC = typeof WeakMap == "function" ? WeakMap : Map, Ze = 0, Ke = null, je = null, Ue = 0, Fe = 0, hn = null, so = false, Xa = false, Ud = false, jr = 0, ct = 0, lo = 0, ta = 0, Bd = 0, pn = 0, Qa = 0, ms = null, Wt = null, Id = false, ec = 0, My = 0, tc = 1 / 0, nc = null, co = null, bt = 0, uo = null, Ga = null, kr = 0, Hd = 0, $d = null, Ny = null, gs = 0, Vd = null;
    function mn() {
      return (Ze & 2) !== 0 && Ue !== 0 ? Ue & -Ue : N.T !== null ? Qd() : cf();
    }
    function zy() {
      if (pn === 0) if ((Ue & 536870912) === 0 || Ie) {
        var n = ya;
        ya <<= 1, (ya & 3932160) === 0 && (ya = 262144), pn = n;
      } else pn = 536870912;
      return n = fn.current, n !== null && (n.flags |= 32), pn;
    }
    function en(n, o, i) {
      (n === Ke && (Fe === 2 || Fe === 9) || n.cancelPendingCommit !== null) && (Ka(n, 0), fo(n, Ue, pn, false)), at(n, i), ((Ze & 2) === 0 || n !== Ke) && (n === Ke && ((Ze & 2) === 0 && (ta |= i), ct === 4 && fo(n, Ue, pn, false)), tr(n));
    }
    function Dy(n, o, i) {
      if ((Ze & 6) !== 0) throw Error(a(327));
      var c = !i && (o & 127) === 0 && (o & n.expiredLanes) === 0 || tt(n, o), d = c ? $C(n, o) : Fd(n, o, true), h = c;
      do {
        if (d === 0) {
          Xa && !c && fo(n, o, 0, false);
          break;
        } else {
          if (i = n.current.alternate, h && !IC(i)) {
            d = Fd(n, o, false), h = false;
            continue;
          }
          if (d === 2) {
            if (h = o, n.errorRecoveryDisabledLanes & h) var w = 0;
            else w = n.pendingLanes & -536870913, w = w !== 0 ? w : w & 536870912 ? 536870912 : 0;
            if (w !== 0) {
              o = w;
              e: {
                var A = n;
                d = ms;
                var z = A.current.memoizedState.isDehydrated;
                if (z && (Ka(A, w).flags |= 256), w = Fd(A, w, false), w !== 2) {
                  if (Ud && !z) {
                    A.errorRecoveryDisabledLanes |= h, ta |= h, d = 4;
                    break e;
                  }
                  h = Wt, Wt = d, h !== null && (Wt === null ? Wt = h : Wt.push.apply(Wt, h));
                }
                d = w;
              }
              if (h = false, d !== 2) continue;
            }
          }
          if (d === 1) {
            Ka(n, 0), fo(n, o, 0, true);
            break;
          }
          e: {
            switch (c = n, h = d, h) {
              case 0:
              case 1:
                throw Error(a(345));
              case 4:
                if ((o & 4194048) !== o) break;
              case 6:
                fo(c, o, pn, !so);
                break e;
              case 2:
                Wt = null;
                break;
              case 3:
              case 5:
                break;
              default:
                throw Error(a(329));
            }
            if ((o & 62914560) === o && (d = ec + 300 - Ht(), 10 < d)) {
              if (fo(c, o, pn, !so), Ae(c, 0, true) !== 0) break e;
              kr = o, c.timeoutHandle = ub(jy.bind(null, c, i, Wt, nc, Id, o, pn, ta, Qa, so, h, "Throttled", -0, 0), d);
              break e;
            }
            jy(c, i, Wt, nc, Id, o, pn, ta, Qa, so, h, null, -0, 0);
          }
        }
        break;
      } while (true);
      tr(n);
    }
    function jy(n, o, i, c, d, h, w, A, z, H, Q, ee, V, Y) {
      if (n.timeoutHandle = -1, ee = o.subtreeFlags, ee & 8192 || (ee & 16785408) === 16785408) {
        ee = { stylesheets: null, count: 0, imgCount: 0, imgBytes: 0, suspenseyImages: [], waitingForImages: true, waitingForViewTransition: false, unsuspend: wr }, Cy(o, h, ee);
        var de = (h & 62914560) === h ? ec - Ht() : (h & 4194048) === h ? My - Ht() : 0;
        if (de = ET(ee, de), de !== null) {
          kr = h, n.cancelPendingCommit = de($y.bind(null, n, o, h, i, c, d, w, A, z, Q, ee, null, V, Y)), fo(n, h, w, !H);
          return;
        }
      }
      $y(n, o, h, i, c, d, w, A, z);
    }
    function IC(n) {
      for (var o = n; ; ) {
        var i = o.tag;
        if ((i === 0 || i === 11 || i === 15) && o.flags & 16384 && (i = o.updateQueue, i !== null && (i = i.stores, i !== null))) for (var c = 0; c < i.length; c++) {
          var d = i[c], h = d.getSnapshot;
          d = d.value;
          try {
            if (!cn(h(), d)) return false;
          } catch {
            return false;
          }
        }
        if (i = o.child, o.subtreeFlags & 16384 && i !== null) i.return = o, o = i;
        else {
          if (o === n) break;
          for (; o.sibling === null; ) {
            if (o.return === null || o.return === n) return true;
            o = o.return;
          }
          o.sibling.return = o.return, o = o.sibling;
        }
      }
      return true;
    }
    function fo(n, o, i, c) {
      o &= ~Bd, o &= ~ta, n.suspendedLanes |= o, n.pingedLanes &= ~o, c && (n.warmLanes |= o), c = n.expirationTimes;
      for (var d = o; 0 < d; ) {
        var h = 31 - kt(d), w = 1 << h;
        c[h] = -1, d &= ~w;
      }
      i !== 0 && Uo(n, i, o);
    }
    function rc() {
      return (Ze & 6) === 0 ? (vs(0), false) : true;
    }
    function Zd() {
      if (je !== null) {
        if (Fe === 0) var n = je.return;
        else n = je, Er = qo = null, id(n), Ha = null, Wi = 0, n = je;
        for (; n !== null; ) fy(n.alternate, n), n = n.return;
        je = null;
      }
    }
    function Ka(n, o) {
      var i = n.timeoutHandle;
      i !== -1 && (n.timeoutHandle = -1, iT(i)), i = n.cancelPendingCommit, i !== null && (n.cancelPendingCommit = null, i()), kr = 0, Zd(), Ke = n, je = i = xr(n.current, null), Ue = o, Fe = 0, hn = null, so = false, Xa = tt(n, o), Ud = false, Qa = pn = Bd = ta = lo = ct = 0, Wt = ms = null, Id = false, (o & 8) !== 0 && (o |= o & 32);
      var c = n.entangledLanes;
      if (c !== 0) for (n = n.entanglements, c &= o; 0 < c; ) {
        var d = 31 - kt(c), h = 1 << d;
        o |= n[d], c &= ~h;
      }
      return jr = o, El(), i;
    }
    function ky(n, o) {
      Oe = null, N.H = ss, o === Ia || o === zl ? (o = Kg(), Fe = 3) : o === Xf ? (o = Kg(), Fe = 4) : Fe = o === xd ? 8 : o !== null && typeof o == "object" && typeof o.then == "function" ? 6 : 1, hn = o, je === null && (ct = 1, ql(n, _n8(o, n.current)));
    }
    function Py() {
      var n = fn.current;
      return n === null ? true : (Ue & 4194048) === Ue ? Tn === null : (Ue & 62914560) === Ue || (Ue & 536870912) !== 0 ? n === Tn : false;
    }
    function Ly() {
      var n = N.H;
      return N.H = ss, n === null ? ss : n;
    }
    function Uy() {
      var n = N.A;
      return N.A = UC, n;
    }
    function oc() {
      ct = 4, so || (Ue & 4194048) !== Ue && fn.current !== null || (Xa = true), (lo & 134217727) === 0 && (ta & 134217727) === 0 || Ke === null || fo(Ke, Ue, pn, false);
    }
    function Fd(n, o, i) {
      var c = Ze;
      Ze |= 2;
      var d = Ly(), h = Uy();
      (Ke !== n || Ue !== o) && (nc = null, Ka(n, o)), o = false;
      var w = ct;
      e: do
        try {
          if (Fe !== 0 && je !== null) {
            var A = je, z = hn;
            switch (Fe) {
              case 8:
                Zd(), w = 6;
                break e;
              case 3:
              case 2:
              case 9:
              case 6:
                fn.current === null && (o = true);
                var H = Fe;
                if (Fe = 0, hn = null, Ja(n, A, z, H), i && Xa) {
                  w = 0;
                  break e;
                }
                break;
              default:
                H = Fe, Fe = 0, hn = null, Ja(n, A, z, H);
            }
          }
          HC(), w = ct;
          break;
        } catch (Q) {
          ky(n, Q);
        }
      while (true);
      return o && n.shellSuspendCounter++, Er = qo = null, Ze = c, N.H = d, N.A = h, je === null && (Ke = null, Ue = 0, El()), w;
    }
    function HC() {
      for (; je !== null; ) By(je);
    }
    function $C(n, o) {
      var i = Ze;
      Ze |= 2;
      var c = Ly(), d = Uy();
      Ke !== n || Ue !== o ? (nc = null, tc = Ht() + 500, Ka(n, o)) : Xa = tt(n, o);
      e: do
        try {
          if (Fe !== 0 && je !== null) {
            o = je;
            var h = hn;
            t: switch (Fe) {
              case 1:
                Fe = 0, hn = null, Ja(n, o, h, 1);
                break;
              case 2:
              case 9:
                if (Qg(h)) {
                  Fe = 0, hn = null, Iy(o);
                  break;
                }
                o = function() {
                  Fe !== 2 && Fe !== 9 || Ke !== n || (Fe = 7), tr(n);
                }, h.then(o, o);
                break e;
              case 3:
                Fe = 7;
                break e;
              case 4:
                Fe = 5;
                break e;
              case 7:
                Qg(h) ? (Fe = 0, hn = null, Iy(o)) : (Fe = 0, hn = null, Ja(n, o, h, 7));
                break;
              case 5:
                var w = null;
                switch (je.tag) {
                  case 26:
                    w = je.memoizedState;
                  case 5:
                  case 27:
                    var A = je;
                    if (w ? Ab(w) : A.stateNode.complete) {
                      Fe = 0, hn = null;
                      var z = A.sibling;
                      if (z !== null) je = z;
                      else {
                        var H = A.return;
                        H !== null ? (je = H, ac(H)) : je = null;
                      }
                      break t;
                    }
                }
                Fe = 0, hn = null, Ja(n, o, h, 5);
                break;
              case 6:
                Fe = 0, hn = null, Ja(n, o, h, 6);
                break;
              case 8:
                Zd(), ct = 6;
                break e;
              default:
                throw Error(a(462));
            }
          }
          VC();
          break;
        } catch (Q) {
          ky(n, Q);
        }
      while (true);
      return Er = qo = null, N.H = c, N.A = d, Ze = i, je !== null ? 0 : (Ke = null, Ue = 0, El(), ct);
    }
    function VC() {
      for (; je !== null && !It(); ) By(je);
    }
    function By(n) {
      var o = cy(n.alternate, n, jr);
      n.memoizedProps = n.pendingProps, o === null ? ac(n) : je = o;
    }
    function Iy(n) {
      var o = n, i = o.alternate;
      switch (o.tag) {
        case 15:
        case 0:
          o = ry(i, o, o.pendingProps, o.type, void 0, Ue);
          break;
        case 11:
          o = ry(i, o, o.pendingProps, o.type.render, o.ref, Ue);
          break;
        case 5:
          id(o);
        default:
          fy(i, o), o = je = Ug(o, jr), o = cy(i, o, jr);
      }
      n.memoizedProps = n.pendingProps, o === null ? ac(n) : je = o;
    }
    function Ja(n, o, i, c) {
      Er = qo = null, id(o), Ha = null, Wi = 0;
      var d = o.return;
      try {
        if (NC(n, d, o, i, Ue)) {
          ct = 1, ql(n, _n8(i, n.current)), je = null;
          return;
        }
      } catch (h) {
        if (d !== null) throw je = d, h;
        ct = 1, ql(n, _n8(i, n.current)), je = null;
        return;
      }
      o.flags & 32768 ? (Ie || c === 1 ? n = true : Xa || (Ue & 536870912) !== 0 ? n = false : (so = n = true, (c === 2 || c === 9 || c === 3 || c === 6) && (c = fn.current, c !== null && c.tag === 13 && (c.flags |= 16384))), Hy(o, n)) : ac(o);
    }
    function ac(n) {
      var o = n;
      do {
        if ((o.flags & 32768) !== 0) {
          Hy(o, so);
          return;
        }
        n = o.return;
        var i = jC(o.alternate, o, jr);
        if (i !== null) {
          je = i;
          return;
        }
        if (o = o.sibling, o !== null) {
          je = o;
          return;
        }
        je = o = n;
      } while (o !== null);
      ct === 0 && (ct = 5);
    }
    function Hy(n, o) {
      do {
        var i = kC(n.alternate, n);
        if (i !== null) {
          i.flags &= 32767, je = i;
          return;
        }
        if (i = n.return, i !== null && (i.flags |= 32768, i.subtreeFlags = 0, i.deletions = null), !o && (n = n.sibling, n !== null)) {
          je = n;
          return;
        }
        je = n = i;
      } while (n !== null);
      ct = 6, je = null;
    }
    function $y(n, o, i, c, d, h, w, A, z) {
      n.cancelPendingCommit = null;
      do
        ic();
      while (bt !== 0);
      if ((Ze & 6) !== 0) throw Error(a(327));
      if (o !== null) {
        if (o === n.current) throw Error(a(177));
        if (h = o.lanes | o.childLanes, h |= Df, Ft(n, i, h, w, A, z), n === Ke && (je = Ke = null, Ue = 0), Ga = o, uo = n, kr = i, Hd = h, $d = d, Ny = c, (o.subtreeFlags & 10256) !== 0 || (o.flags & 10256) !== 0 ? (n.callbackNode = null, n.callbackPriority = 0, YC(ko, function() {
          return Yy(), null;
        })) : (n.callbackNode = null, n.callbackPriority = 0), c = (o.flags & 13878) !== 0, (o.subtreeFlags & 13878) !== 0 || c) {
          c = N.T, N.T = null, d = Z.p, Z.p = 2, w = Ze, Ze |= 4;
          try {
            PC(n, o, i);
          } finally {
            Ze = w, Z.p = d, N.T = c;
          }
        }
        bt = 1, Vy(), Zy(), Fy();
      }
    }
    function Vy() {
      if (bt === 1) {
        bt = 0;
        var n = uo, o = Ga, i = (o.flags & 13878) !== 0;
        if ((o.subtreeFlags & 13878) !== 0 || i) {
          i = N.T, N.T = null;
          var c = Z.p;
          Z.p = 2;
          var d = Ze;
          Ze |= 4;
          try {
            _y(o, n);
            var h = rh, w = Rg(n.containerInfo), A = h.focusedElem, z = h.selectionRange;
            if (w !== A && A && A.ownerDocument && Og(A.ownerDocument.documentElement, A)) {
              if (z !== null && Of(A)) {
                var H = z.start, Q = z.end;
                if (Q === void 0 && (Q = H), "selectionStart" in A) A.selectionStart = H, A.selectionEnd = Math.min(Q, A.value.length);
                else {
                  var ee = A.ownerDocument || document, V = ee && ee.defaultView || window;
                  if (V.getSelection) {
                    var Y = V.getSelection(), de = A.textContent.length, we = Math.min(z.start, de), Ge = z.end === void 0 ? we : Math.min(z.end, de);
                    !Y.extend && we > Ge && (w = Ge, Ge = we, we = w);
                    var U = Tg(A, we), j = Tg(A, Ge);
                    if (U && j && (Y.rangeCount !== 1 || Y.anchorNode !== U.node || Y.anchorOffset !== U.offset || Y.focusNode !== j.node || Y.focusOffset !== j.offset)) {
                      var I = ee.createRange();
                      I.setStart(U.node, U.offset), Y.removeAllRanges(), we > Ge ? (Y.addRange(I), Y.extend(j.node, j.offset)) : (I.setEnd(j.node, j.offset), Y.addRange(I));
                    }
                  }
                }
              }
              for (ee = [], Y = A; Y = Y.parentNode; ) Y.nodeType === 1 && ee.push({ element: Y, left: Y.scrollLeft, top: Y.scrollTop });
              for (typeof A.focus == "function" && A.focus(), A = 0; A < ee.length; A++) {
                var K = ee[A];
                K.element.scrollLeft = K.left, K.element.scrollTop = K.top;
              }
            }
            yc = !!nh, rh = nh = null;
          } finally {
            Ze = d, Z.p = c, N.T = i;
          }
        }
        n.current = o, bt = 2;
      }
    }
    function Zy() {
      if (bt === 2) {
        bt = 0;
        var n = uo, o = Ga, i = (o.flags & 8772) !== 0;
        if ((o.subtreeFlags & 8772) !== 0 || i) {
          i = N.T, N.T = null;
          var c = Z.p;
          Z.p = 2;
          var d = Ze;
          Ze |= 4;
          try {
            yy(n, o.alternate, o);
          } finally {
            Ze = d, Z.p = c, N.T = i;
          }
        }
        bt = 3;
      }
    }
    function Fy() {
      if (bt === 4 || bt === 3) {
        bt = 0, qr();
        var n = uo, o = Ga, i = kr, c = Ny;
        (o.subtreeFlags & 10256) !== 0 || (o.flags & 10256) !== 0 ? bt = 5 : (bt = 0, Ga = uo = null, qy(n, n.pendingLanes));
        var d = n.pendingLanes;
        if (d === 0 && (co = null), Pn(i), o = o.stateNode, $t && typeof $t.onCommitFiberRoot == "function") try {
          $t.onCommitFiberRoot(Po, o, void 0, (o.current.flags & 128) === 128);
        } catch {
        }
        if (c !== null) {
          o = N.T, d = Z.p, Z.p = 2, N.T = null;
          try {
            for (var h = n.onRecoverableError, w = 0; w < c.length; w++) {
              var A = c[w];
              h(A.value, { componentStack: A.stack });
            }
          } finally {
            N.T = o, Z.p = d;
          }
        }
        (kr & 3) !== 0 && ic(), tr(n), d = n.pendingLanes, (i & 261930) !== 0 && (d & 42) !== 0 ? n === Vd ? gs++ : (gs = 0, Vd = n) : gs = 0, vs(0);
      }
    }
    function qy(n, o) {
      (n.pooledCacheLanes &= o) === 0 && (o = n.pooledCache, o != null && (n.pooledCache = null, Ki(o)));
    }
    function ic() {
      return Vy(), Zy(), Fy(), Yy();
    }
    function Yy() {
      if (bt !== 5) return false;
      var n = uo, o = Hd;
      Hd = 0;
      var i = Pn(kr), c = N.T, d = Z.p;
      try {
        Z.p = 32 > i ? 32 : i, N.T = null, i = $d, $d = null;
        var h = uo, w = kr;
        if (bt = 0, Ga = uo = null, kr = 0, (Ze & 6) !== 0) throw Error(a(331));
        var A = Ze;
        if (Ze |= 4, Oy(h.current), Ay(h, h.current, w, i), Ze = A, vs(0, false), $t && typeof $t.onPostCommitFiberRoot == "function") try {
          $t.onPostCommitFiberRoot(Po, h);
        } catch {
        }
        return true;
      } finally {
        Z.p = d, N.T = c, qy(n, o);
      }
    }
    function Xy(n, o, i) {
      o = _n8(i, o), o = Sd(n.stateNode, o, 2), n = ro(n, o, 2), n !== null && (at(n, 2), tr(n));
    }
    function qe(n, o, i) {
      if (n.tag === 3) Xy(n, n, i);
      else for (; o !== null; ) {
        if (o.tag === 3) {
          Xy(o, n, i);
          break;
        } else if (o.tag === 1) {
          var c = o.stateNode;
          if (typeof o.type.getDerivedStateFromError == "function" || typeof c.componentDidCatch == "function" && (co === null || !co.has(c))) {
            n = _n8(i, n), i = Qv(2), c = ro(o, i, 2), c !== null && (Gv(i, c, o, n), at(c, 2), tr(c));
            break;
          }
        }
        o = o.return;
      }
    }
    function qd(n, o, i) {
      var c = n.pingCache;
      if (c === null) {
        c = n.pingCache = new BC();
        var d = /* @__PURE__ */ new Set();
        c.set(o, d);
      } else d = c.get(o), d === void 0 && (d = /* @__PURE__ */ new Set(), c.set(o, d));
      d.has(i) || (Ud = true, d.add(i), n = ZC.bind(null, n, o, i), o.then(n, n));
    }
    function ZC(n, o, i) {
      var c = n.pingCache;
      c !== null && c.delete(o), n.pingedLanes |= n.suspendedLanes & i, n.warmLanes &= ~i, Ke === n && (Ue & i) === i && (ct === 4 || ct === 3 && (Ue & 62914560) === Ue && 300 > Ht() - ec ? (Ze & 2) === 0 && Ka(n, 0) : Bd |= i, Qa === Ue && (Qa = 0)), tr(n);
    }
    function Qy(n, o) {
      o === 0 && (o = Pt()), n = Vo(n, o), n !== null && (at(n, o), tr(n));
    }
    function FC(n) {
      var o = n.memoizedState, i = 0;
      o !== null && (i = o.retryLane), Qy(n, i);
    }
    function qC(n, o) {
      var i = 0;
      switch (n.tag) {
        case 31:
        case 13:
          var c = n.stateNode, d = n.memoizedState;
          d !== null && (i = d.retryLane);
          break;
        case 19:
          c = n.stateNode;
          break;
        case 22:
          c = n.stateNode._retryCache;
          break;
        default:
          throw Error(a(314));
      }
      c !== null && c.delete(o), Qy(n, i);
    }
    function YC(n, o) {
      return ji(n, o);
    }
    var sc = null, Wa = null, Yd = false, lc = false, Xd = false, ho = 0;
    function tr(n) {
      n !== Wa && n.next === null && (Wa === null ? sc = Wa = n : Wa = Wa.next = n), lc = true, Yd || (Yd = true, QC());
    }
    function vs(n, o) {
      if (!Xd && lc) {
        Xd = true;
        do
          for (var i = false, c = sc; c !== null; ) {
            if (n !== 0) {
              var d = c.pendingLanes;
              if (d === 0) var h = 0;
              else {
                var w = c.suspendedLanes, A = c.pingedLanes;
                h = (1 << 31 - kt(42 | n) + 1) - 1, h &= d & ~(w & ~A), h = h & 201326741 ? h & 201326741 | 1 : h ? h | 2 : 0;
              }
              h !== 0 && (i = true, Wy(c, h));
            } else h = Ue, h = Ae(c, c === Ke ? h : 0, c.cancelPendingCommit !== null || c.timeoutHandle !== -1), (h & 3) === 0 || tt(c, h) || (i = true, Wy(c, h));
            c = c.next;
          }
        while (i);
        Xd = false;
      }
    }
    function XC() {
      Gy();
    }
    function Gy() {
      lc = Yd = false;
      var n = 0;
      ho !== 0 && aT() && (n = ho);
      for (var o = Ht(), i = null, c = sc; c !== null; ) {
        var d = c.next, h = Ky(c, o);
        h === 0 ? (c.next = null, i === null ? sc = d : i.next = d, d === null && (Wa = i)) : (i = c, (n !== 0 || (h & 3) !== 0) && (lc = true)), c = d;
      }
      bt !== 0 && bt !== 5 || vs(n), ho !== 0 && (ho = 0);
    }
    function Ky(n, o) {
      for (var i = n.suspendedLanes, c = n.pingedLanes, d = n.expirationTimes, h = n.pendingLanes & -62914561; 0 < h; ) {
        var w = 31 - kt(h), A = 1 << w, z = d[w];
        z === -1 ? ((A & i) === 0 || (A & c) !== 0) && (d[w] = St(A, o)) : z <= o && (n.expiredLanes |= A), h &= ~A;
      }
      if (o = Ke, i = Ue, i = Ae(n, n === o ? i : 0, n.cancelPendingCommit !== null || n.timeoutHandle !== -1), c = n.callbackNode, i === 0 || n === o && (Fe === 2 || Fe === 9) || n.cancelPendingCommit !== null) return c !== null && c !== null && ki(c), n.callbackNode = null, n.callbackPriority = 0;
      if ((i & 3) === 0 || tt(n, i)) {
        if (o = i & -i, o === n.callbackPriority) return o;
        switch (c !== null && ki(c), Pn(i)) {
          case 2:
          case 8:
            i = fl;
            break;
          case 32:
            i = ko;
            break;
          case 268435456:
            i = yr;
            break;
          default:
            i = ko;
        }
        return c = Jy.bind(null, n), i = ji(i, c), n.callbackPriority = o, n.callbackNode = i, o;
      }
      return c !== null && c !== null && ki(c), n.callbackPriority = 2, n.callbackNode = null, 2;
    }
    function Jy(n, o) {
      if (bt !== 0 && bt !== 5) return n.callbackNode = null, n.callbackPriority = 0, null;
      var i = n.callbackNode;
      if (ic() && n.callbackNode !== i) return null;
      var c = Ue;
      return c = Ae(n, n === Ke ? c : 0, n.cancelPendingCommit !== null || n.timeoutHandle !== -1), c === 0 ? null : (Dy(n, c, o), Ky(n, Ht()), n.callbackNode != null && n.callbackNode === i ? Jy.bind(null, n) : null);
    }
    function Wy(n, o) {
      if (ic()) return null;
      Dy(n, o, true);
    }
    function QC() {
      sT(function() {
        (Ze & 6) !== 0 ? ji(jo, XC) : Gy();
      });
    }
    function Qd() {
      if (ho === 0) {
        var n = Ua;
        n === 0 && (n = va, va <<= 1, (va & 261888) === 0 && (va = 256)), ho = n;
      }
      return ho;
    }
    function eb(n) {
      return n == null || typeof n == "symbol" || typeof n == "boolean" ? null : typeof n == "function" ? n : gl("" + n);
    }
    function tb(n, o) {
      var i = o.ownerDocument.createElement("input");
      return i.name = o.name, i.value = o.value, n.id && i.setAttribute("form", n.id), o.parentNode.insertBefore(i, o), n = new FormData(n), i.parentNode.removeChild(i), n;
    }
    function GC(n, o, i, c, d) {
      if (o === "submit" && i && i.stateNode === d) {
        var h = eb((d[Xt] || null).action), w = c.submitter;
        w && (o = (o = w[Xt] || null) ? eb(o.formAction) : w.getAttribute("formAction"), o !== null && (h = o, w = null));
        var A = new wl("action", "action", null, c, d);
        n.push({ event: A, listeners: [{ instance: null, listener: function() {
          if (c.defaultPrevented) {
            if (ho !== 0) {
              var z = w ? tb(d, w) : new FormData(d);
              md(i, { pending: true, data: z, method: d.method, action: h }, null, z);
            }
          } else typeof h == "function" && (A.preventDefault(), z = w ? tb(d, w) : new FormData(d), md(i, { pending: true, data: z, method: d.method, action: h }, h, z));
        }, currentTarget: d }] });
      }
    }
    for (var Gd = 0; Gd < zf.length; Gd++) {
      var Kd = zf[Gd], KC = Kd.toLowerCase(), JC = Kd[0].toUpperCase() + Kd.slice(1);
      Ln(KC, "on" + JC);
    }
    Ln(zg, "onAnimationEnd"), Ln(Dg, "onAnimationIteration"), Ln(jg, "onAnimationStart"), Ln("dblclick", "onDoubleClick"), Ln("focusin", "onFocus"), Ln("focusout", "onBlur"), Ln(pC, "onTransitionRun"), Ln(mC, "onTransitionStart"), Ln(gC, "onTransitionCancel"), Ln(kg, "onTransitionEnd"), Ea("onMouseEnter", ["mouseout", "mouseover"]), Ea("onMouseLeave", ["mouseout", "mouseover"]), Ea("onPointerEnter", ["pointerout", "pointerover"]), Ea("onPointerLeave", ["pointerout", "pointerover"]), Bo("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), Bo("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), Bo("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), Bo("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), Bo("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), Bo("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var ys = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), WC = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(ys));
    function nb(n, o) {
      o = (o & 4) !== 0;
      for (var i = 0; i < n.length; i++) {
        var c = n[i], d = c.event;
        c = c.listeners;
        e: {
          var h = void 0;
          if (o) for (var w = c.length - 1; 0 <= w; w--) {
            var A = c[w], z = A.instance, H = A.currentTarget;
            if (A = A.listener, z !== h && d.isPropagationStopped()) break e;
            h = A, d.currentTarget = H;
            try {
              h(d);
            } catch (Q) {
              _l3(Q);
            }
            d.currentTarget = null, h = z;
          }
          else for (w = 0; w < c.length; w++) {
            if (A = c[w], z = A.instance, H = A.currentTarget, A = A.listener, z !== h && d.isPropagationStopped()) break e;
            h = A, d.currentTarget = H;
            try {
              h(d);
            } catch (Q) {
              _l3(Q);
            }
            d.currentTarget = null, h = z;
          }
        }
      }
    }
    function ke(n, o) {
      var i = o[uf];
      i === void 0 && (i = o[uf] = /* @__PURE__ */ new Set());
      var c = n + "__bubble";
      i.has(c) || (rb(o, n, 2, false), i.add(c));
    }
    function Jd(n, o, i) {
      var c = 0;
      o && (c |= 4), rb(i, n, c, o);
    }
    var cc = "_reactListening" + Math.random().toString(36).slice(2);
    function Wd(n) {
      if (!n[cc]) {
        n[cc] = true, Gm.forEach(function(i) {
          i !== "selectionchange" && (WC.has(i) || Jd(i, false, n), Jd(i, true, n));
        });
        var o = n.nodeType === 9 ? n : n.ownerDocument;
        o === null || o[cc] || (o[cc] = true, Jd("selectionchange", false, o));
      }
    }
    function rb(n, o, i, c) {
      switch (zb(o)) {
        case 2:
          var d = TT;
          break;
        case 8:
          d = OT;
          break;
        default:
          d = ph;
      }
      i = d.bind(null, o, i, n), d = void 0, !bf || o !== "touchstart" && o !== "touchmove" && o !== "wheel" || (d = true), c ? d !== void 0 ? n.addEventListener(o, i, { capture: true, passive: d }) : n.addEventListener(o, i, true) : d !== void 0 ? n.addEventListener(o, i, { passive: d }) : n.addEventListener(o, i, false);
    }
    function eh(n, o, i, c, d) {
      var h = c;
      if ((o & 1) === 0 && (o & 2) === 0 && c !== null) e: for (; ; ) {
        if (c === null) return;
        var w = c.tag;
        if (w === 3 || w === 4) {
          var A = c.stateNode.containerInfo;
          if (A === d) break;
          if (w === 4) for (w = c.return; w !== null; ) {
            var z = w.tag;
            if ((z === 3 || z === 4) && w.stateNode.containerInfo === d) return;
            w = w.return;
          }
          for (; A !== null; ) {
            if (w = Sa(A), w === null) return;
            if (z = w.tag, z === 5 || z === 6 || z === 26 || z === 27) {
              c = h = w;
              continue e;
            }
            A = A.parentNode;
          }
        }
        c = c.return;
      }
      lg(function() {
        var H = h, Q = vf(i), ee = [];
        e: {
          var V = Pg.get(n);
          if (V !== void 0) {
            var Y = wl, de = n;
            switch (n) {
              case "keypress":
                if (yl(i) === 0) break e;
              case "keydown":
              case "keyup":
                Y = qA;
                break;
              case "focusin":
                de = "focus", Y = _f2;
                break;
              case "focusout":
                de = "blur", Y = _f2;
                break;
              case "beforeblur":
              case "afterblur":
                Y = _f2;
                break;
              case "click":
                if (i.button === 2) break e;
              case "auxclick":
              case "dblclick":
              case "mousedown":
              case "mousemove":
              case "mouseup":
              case "mouseout":
              case "mouseover":
              case "contextmenu":
                Y = fg;
                break;
              case "drag":
              case "dragend":
              case "dragenter":
              case "dragexit":
              case "dragleave":
              case "dragover":
              case "dragstart":
              case "drop":
                Y = jA;
                break;
              case "touchcancel":
              case "touchend":
              case "touchmove":
              case "touchstart":
                Y = QA;
                break;
              case zg:
              case Dg:
              case jg:
                Y = LA;
                break;
              case kg:
                Y = KA;
                break;
              case "scroll":
              case "scrollend":
                Y = zA;
                break;
              case "wheel":
                Y = WA;
                break;
              case "copy":
              case "cut":
              case "paste":
                Y = BA;
                break;
              case "gotpointercapture":
              case "lostpointercapture":
              case "pointercancel":
              case "pointerdown":
              case "pointermove":
              case "pointerout":
              case "pointerover":
              case "pointerup":
                Y = hg;
                break;
              case "toggle":
              case "beforetoggle":
                Y = tC;
            }
            var we = (o & 4) !== 0, Ge = !we && (n === "scroll" || n === "scrollend"), U = we ? V !== null ? V + "Capture" : null : V;
            we = [];
            for (var j = H, I; j !== null; ) {
              var K = j;
              if (I = K.stateNode, K = K.tag, K !== 5 && K !== 26 && K !== 27 || I === null || U === null || (K = Ii(j, U), K != null && we.push(bs(j, K, I))), Ge) break;
              j = j.return;
            }
            0 < we.length && (V = new Y(V, de, null, i, Q), ee.push({ event: V, listeners: we }));
          }
        }
        if ((o & 7) === 0) {
          e: {
            if (V = n === "mouseover" || n === "pointerover", Y = n === "mouseout" || n === "pointerout", V && i !== gf && (de = i.relatedTarget || i.fromElement) && (Sa(de) || de[wa])) break e;
            if ((Y || V) && (V = Q.window === Q ? Q : (V = Q.ownerDocument) ? V.defaultView || V.parentWindow : window, Y ? (de = i.relatedTarget || i.toElement, Y = H, de = de ? Sa(de) : null, de !== null && (Ge = l(de), we = de.tag, de !== Ge || we !== 5 && we !== 27 && we !== 6) && (de = null)) : (Y = null, de = H), Y !== de)) {
              if (we = fg, K = "onMouseLeave", U = "onMouseEnter", j = "mouse", (n === "pointerout" || n === "pointerover") && (we = hg, K = "onPointerLeave", U = "onPointerEnter", j = "pointer"), Ge = Y == null ? V : Bi(Y), I = de == null ? V : Bi(de), V = new we(K, j + "leave", Y, i, Q), V.target = Ge, V.relatedTarget = I, K = null, Sa(Q) === H && (we = new we(U, j + "enter", de, i, Q), we.target = I, we.relatedTarget = Ge, K = we), Ge = K, Y && de) t: {
                for (we = eT, U = Y, j = de, I = 0, K = U; K; K = we(K)) I++;
                K = 0;
                for (var ye = j; ye; ye = we(ye)) K++;
                for (; 0 < I - K; ) U = we(U), I--;
                for (; 0 < K - I; ) j = we(j), K--;
                for (; I--; ) {
                  if (U === j || j !== null && U === j.alternate) {
                    we = U;
                    break t;
                  }
                  U = we(U), j = we(j);
                }
                we = null;
              }
              else we = null;
              Y !== null && ob(ee, V, Y, we, false), de !== null && Ge !== null && ob(ee, Ge, de, we, true);
            }
          }
          e: {
            if (V = H ? Bi(H) : window, Y = V.nodeName && V.nodeName.toLowerCase(), Y === "select" || Y === "input" && V.type === "file") var He = Sg;
            else if (bg(V)) if (xg) He = fC;
            else {
              He = cC;
              var ve = lC;
            }
            else Y = V.nodeName, !Y || Y.toLowerCase() !== "input" || V.type !== "checkbox" && V.type !== "radio" ? H && mf(H.elementType) && (He = Sg) : He = uC;
            if (He && (He = He(n, H))) {
              wg(ee, He, i, Q);
              break e;
            }
            ve && ve(n, V, H), n === "focusout" && H && V.type === "number" && H.memoizedProps.value != null && pf(V, "number", V.value);
          }
          switch (ve = H ? Bi(H) : window, n) {
            case "focusin":
              (bg(ve) || ve.contentEditable === "true") && (Ma = ve, Rf = H, Xi = null);
              break;
            case "focusout":
              Xi = Rf = Ma = null;
              break;
            case "mousedown":
              Mf = true;
              break;
            case "contextmenu":
            case "mouseup":
            case "dragend":
              Mf = false, Mg(ee, i, Q);
              break;
            case "selectionchange":
              if (hC) break;
            case "keydown":
            case "keyup":
              Mg(ee, i, Q);
          }
          var Me;
          if (Af) e: {
            switch (n) {
              case "compositionstart":
                var Be = "onCompositionStart";
                break e;
              case "compositionend":
                Be = "onCompositionEnd";
                break e;
              case "compositionupdate":
                Be = "onCompositionUpdate";
                break e;
            }
            Be = void 0;
          }
          else Ra ? vg(n, i) && (Be = "onCompositionEnd") : n === "keydown" && i.keyCode === 229 && (Be = "onCompositionStart");
          Be && (pg && i.locale !== "ko" && (Ra || Be !== "onCompositionStart" ? Be === "onCompositionEnd" && Ra && (Me = cg()) : (Gr = Q, wf = "value" in Gr ? Gr.value : Gr.textContent, Ra = true)), ve = uc(H, Be), 0 < ve.length && (Be = new dg(Be, n, null, i, Q), ee.push({ event: Be, listeners: ve }), Me ? Be.data = Me : (Me = yg(i), Me !== null && (Be.data = Me)))), (Me = rC ? oC(n, i) : aC(n, i)) && (Be = uc(H, "onBeforeInput"), 0 < Be.length && (ve = new dg("onBeforeInput", "beforeinput", null, i, Q), ee.push({ event: ve, listeners: Be }), ve.data = Me)), GC(ee, n, H, i, Q);
        }
        nb(ee, o);
      });
    }
    function bs(n, o, i) {
      return { instance: n, listener: o, currentTarget: i };
    }
    function uc(n, o) {
      for (var i = o + "Capture", c = []; n !== null; ) {
        var d = n, h = d.stateNode;
        if (d = d.tag, d !== 5 && d !== 26 && d !== 27 || h === null || (d = Ii(n, i), d != null && c.unshift(bs(n, d, h)), d = Ii(n, o), d != null && c.push(bs(n, d, h))), n.tag === 3) return c;
        n = n.return;
      }
      return [];
    }
    function eT(n) {
      if (n === null) return null;
      do
        n = n.return;
      while (n && n.tag !== 5 && n.tag !== 27);
      return n || null;
    }
    function ob(n, o, i, c, d) {
      for (var h = o._reactName, w = []; i !== null && i !== c; ) {
        var A = i, z = A.alternate, H = A.stateNode;
        if (A = A.tag, z !== null && z === c) break;
        A !== 5 && A !== 26 && A !== 27 || H === null || (z = H, d ? (H = Ii(i, h), H != null && w.unshift(bs(i, H, z))) : d || (H = Ii(i, h), H != null && w.push(bs(i, H, z)))), i = i.return;
      }
      w.length !== 0 && n.push({ event: o, listeners: w });
    }
    var tT = /\r\n?/g, nT = /\u0000|\uFFFD/g;
    function ab(n) {
      return (typeof n == "string" ? n : "" + n).replace(tT, `
`).replace(nT, "");
    }
    function ib(n, o) {
      return o = ab(o), ab(n) === o;
    }
    function Qe(n, o, i, c, d, h) {
      switch (i) {
        case "children":
          typeof c == "string" ? o === "body" || o === "textarea" && c === "" || Ca(n, c) : (typeof c == "number" || typeof c == "bigint") && o !== "body" && Ca(n, "" + c);
          break;
        case "className":
          pl(n, "class", c);
          break;
        case "tabIndex":
          pl(n, "tabindex", c);
          break;
        case "dir":
        case "role":
        case "viewBox":
        case "width":
        case "height":
          pl(n, i, c);
          break;
        case "style":
          ig(n, c, h);
          break;
        case "data":
          if (o !== "object") {
            pl(n, "data", c);
            break;
          }
        case "src":
        case "href":
          if (c === "" && (o !== "a" || i !== "href")) {
            n.removeAttribute(i);
            break;
          }
          if (c == null || typeof c == "function" || typeof c == "symbol" || typeof c == "boolean") {
            n.removeAttribute(i);
            break;
          }
          c = gl("" + c), n.setAttribute(i, c);
          break;
        case "action":
        case "formAction":
          if (typeof c == "function") {
            n.setAttribute(i, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
            break;
          } else typeof h == "function" && (i === "formAction" ? (o !== "input" && Qe(n, o, "name", d.name, d, null), Qe(n, o, "formEncType", d.formEncType, d, null), Qe(n, o, "formMethod", d.formMethod, d, null), Qe(n, o, "formTarget", d.formTarget, d, null)) : (Qe(n, o, "encType", d.encType, d, null), Qe(n, o, "method", d.method, d, null), Qe(n, o, "target", d.target, d, null)));
          if (c == null || typeof c == "symbol" || typeof c == "boolean") {
            n.removeAttribute(i);
            break;
          }
          c = gl("" + c), n.setAttribute(i, c);
          break;
        case "onClick":
          c != null && (n.onclick = wr);
          break;
        case "onScroll":
          c != null && ke("scroll", n);
          break;
        case "onScrollEnd":
          c != null && ke("scrollend", n);
          break;
        case "dangerouslySetInnerHTML":
          if (c != null) {
            if (typeof c != "object" || !("__html" in c)) throw Error(a(61));
            if (i = c.__html, i != null) {
              if (d.children != null) throw Error(a(60));
              n.innerHTML = i;
            }
          }
          break;
        case "multiple":
          n.multiple = c && typeof c != "function" && typeof c != "symbol";
          break;
        case "muted":
          n.muted = c && typeof c != "function" && typeof c != "symbol";
          break;
        case "suppressContentEditableWarning":
        case "suppressHydrationWarning":
        case "defaultValue":
        case "defaultChecked":
        case "innerHTML":
        case "ref":
          break;
        case "autoFocus":
          break;
        case "xlinkHref":
          if (c == null || typeof c == "function" || typeof c == "boolean" || typeof c == "symbol") {
            n.removeAttribute("xlink:href");
            break;
          }
          i = gl("" + c), n.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", i);
          break;
        case "contentEditable":
        case "spellCheck":
        case "draggable":
        case "value":
        case "autoReverse":
        case "externalResourcesRequired":
        case "focusable":
        case "preserveAlpha":
          c != null && typeof c != "function" && typeof c != "symbol" ? n.setAttribute(i, "" + c) : n.removeAttribute(i);
          break;
        case "inert":
        case "allowFullScreen":
        case "async":
        case "autoPlay":
        case "controls":
        case "default":
        case "defer":
        case "disabled":
        case "disablePictureInPicture":
        case "disableRemotePlayback":
        case "formNoValidate":
        case "hidden":
        case "loop":
        case "noModule":
        case "noValidate":
        case "open":
        case "playsInline":
        case "readOnly":
        case "required":
        case "reversed":
        case "scoped":
        case "seamless":
        case "itemScope":
          c && typeof c != "function" && typeof c != "symbol" ? n.setAttribute(i, "") : n.removeAttribute(i);
          break;
        case "capture":
        case "download":
          c === true ? n.setAttribute(i, "") : c !== false && c != null && typeof c != "function" && typeof c != "symbol" ? n.setAttribute(i, c) : n.removeAttribute(i);
          break;
        case "cols":
        case "rows":
        case "size":
        case "span":
          c != null && typeof c != "function" && typeof c != "symbol" && !isNaN(c) && 1 <= c ? n.setAttribute(i, c) : n.removeAttribute(i);
          break;
        case "rowSpan":
        case "start":
          c == null || typeof c == "function" || typeof c == "symbol" || isNaN(c) ? n.removeAttribute(i) : n.setAttribute(i, c);
          break;
        case "popover":
          ke("beforetoggle", n), ke("toggle", n), hl(n, "popover", c);
          break;
        case "xlinkActuate":
          br(n, "http://www.w3.org/1999/xlink", "xlink:actuate", c);
          break;
        case "xlinkArcrole":
          br(n, "http://www.w3.org/1999/xlink", "xlink:arcrole", c);
          break;
        case "xlinkRole":
          br(n, "http://www.w3.org/1999/xlink", "xlink:role", c);
          break;
        case "xlinkShow":
          br(n, "http://www.w3.org/1999/xlink", "xlink:show", c);
          break;
        case "xlinkTitle":
          br(n, "http://www.w3.org/1999/xlink", "xlink:title", c);
          break;
        case "xlinkType":
          br(n, "http://www.w3.org/1999/xlink", "xlink:type", c);
          break;
        case "xmlBase":
          br(n, "http://www.w3.org/XML/1998/namespace", "xml:base", c);
          break;
        case "xmlLang":
          br(n, "http://www.w3.org/XML/1998/namespace", "xml:lang", c);
          break;
        case "xmlSpace":
          br(n, "http://www.w3.org/XML/1998/namespace", "xml:space", c);
          break;
        case "is":
          hl(n, "is", c);
          break;
        case "innerText":
        case "textContent":
          break;
        default:
          (!(2 < i.length) || i[0] !== "o" && i[0] !== "O" || i[1] !== "n" && i[1] !== "N") && (i = MA.get(i) || i, hl(n, i, c));
      }
    }
    function th(n, o, i, c, d, h) {
      switch (i) {
        case "style":
          ig(n, c, h);
          break;
        case "dangerouslySetInnerHTML":
          if (c != null) {
            if (typeof c != "object" || !("__html" in c)) throw Error(a(61));
            if (i = c.__html, i != null) {
              if (d.children != null) throw Error(a(60));
              n.innerHTML = i;
            }
          }
          break;
        case "children":
          typeof c == "string" ? Ca(n, c) : (typeof c == "number" || typeof c == "bigint") && Ca(n, "" + c);
          break;
        case "onScroll":
          c != null && ke("scroll", n);
          break;
        case "onScrollEnd":
          c != null && ke("scrollend", n);
          break;
        case "onClick":
          c != null && (n.onclick = wr);
          break;
        case "suppressContentEditableWarning":
        case "suppressHydrationWarning":
        case "innerHTML":
        case "ref":
          break;
        case "innerText":
        case "textContent":
          break;
        default:
          if (!Km.hasOwnProperty(i)) e: {
            if (i[0] === "o" && i[1] === "n" && (d = i.endsWith("Capture"), o = i.slice(2, d ? i.length - 7 : void 0), h = n[Xt] || null, h = h != null ? h[i] : null, typeof h == "function" && n.removeEventListener(o, h, d), typeof c == "function")) {
              typeof h != "function" && h !== null && (i in n ? n[i] = null : n.hasAttribute(i) && n.removeAttribute(i)), n.addEventListener(o, c, d);
              break e;
            }
            i in n ? n[i] = c : c === true ? n.setAttribute(i, "") : hl(n, i, c);
          }
      }
    }
    function Nt(n, o, i) {
      switch (o) {
        case "div":
        case "span":
        case "svg":
        case "path":
        case "a":
        case "g":
        case "p":
        case "li":
          break;
        case "img":
          ke("error", n), ke("load", n);
          var c = false, d = false, h;
          for (h in i) if (i.hasOwnProperty(h)) {
            var w = i[h];
            if (w != null) switch (h) {
              case "src":
                c = true;
                break;
              case "srcSet":
                d = true;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(a(137, o));
              default:
                Qe(n, o, h, w, i, null);
            }
          }
          d && Qe(n, o, "srcSet", i.srcSet, i, null), c && Qe(n, o, "src", i.src, i, null);
          return;
        case "input":
          ke("invalid", n);
          var A = h = w = d = null, z = null, H = null;
          for (c in i) if (i.hasOwnProperty(c)) {
            var Q = i[c];
            if (Q != null) switch (c) {
              case "name":
                d = Q;
                break;
              case "type":
                w = Q;
                break;
              case "checked":
                z = Q;
                break;
              case "defaultChecked":
                H = Q;
                break;
              case "value":
                h = Q;
                break;
              case "defaultValue":
                A = Q;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (Q != null) throw Error(a(137, o));
                break;
              default:
                Qe(n, o, c, Q, i, null);
            }
          }
          ng(n, h, A, z, H, w, d, false);
          return;
        case "select":
          ke("invalid", n), c = w = h = null;
          for (d in i) if (i.hasOwnProperty(d) && (A = i[d], A != null)) switch (d) {
            case "value":
              h = A;
              break;
            case "defaultValue":
              w = A;
              break;
            case "multiple":
              c = A;
            default:
              Qe(n, o, d, A, i, null);
          }
          o = h, i = w, n.multiple = !!c, o != null ? Aa(n, !!c, o, false) : i != null && Aa(n, !!c, i, true);
          return;
        case "textarea":
          ke("invalid", n), h = d = c = null;
          for (w in i) if (i.hasOwnProperty(w) && (A = i[w], A != null)) switch (w) {
            case "value":
              c = A;
              break;
            case "defaultValue":
              d = A;
              break;
            case "children":
              h = A;
              break;
            case "dangerouslySetInnerHTML":
              if (A != null) throw Error(a(91));
              break;
            default:
              Qe(n, o, w, A, i, null);
          }
          og(n, c, d, h);
          return;
        case "option":
          for (z in i) if (i.hasOwnProperty(z) && (c = i[z], c != null)) switch (z) {
            case "selected":
              n.selected = c && typeof c != "function" && typeof c != "symbol";
              break;
            default:
              Qe(n, o, z, c, i, null);
          }
          return;
        case "dialog":
          ke("beforetoggle", n), ke("toggle", n), ke("cancel", n), ke("close", n);
          break;
        case "iframe":
        case "object":
          ke("load", n);
          break;
        case "video":
        case "audio":
          for (c = 0; c < ys.length; c++) ke(ys[c], n);
          break;
        case "image":
          ke("error", n), ke("load", n);
          break;
        case "details":
          ke("toggle", n);
          break;
        case "embed":
        case "source":
        case "link":
          ke("error", n), ke("load", n);
        case "area":
        case "base":
        case "br":
        case "col":
        case "hr":
        case "keygen":
        case "meta":
        case "param":
        case "track":
        case "wbr":
        case "menuitem":
          for (H in i) if (i.hasOwnProperty(H) && (c = i[H], c != null)) switch (H) {
            case "children":
            case "dangerouslySetInnerHTML":
              throw Error(a(137, o));
            default:
              Qe(n, o, H, c, i, null);
          }
          return;
        default:
          if (mf(o)) {
            for (Q in i) i.hasOwnProperty(Q) && (c = i[Q], c !== void 0 && th(n, o, Q, c, i, void 0));
            return;
          }
      }
      for (A in i) i.hasOwnProperty(A) && (c = i[A], c != null && Qe(n, o, A, c, i, null));
    }
    function rT(n, o, i, c) {
      switch (o) {
        case "div":
        case "span":
        case "svg":
        case "path":
        case "a":
        case "g":
        case "p":
        case "li":
          break;
        case "input":
          var d = null, h = null, w = null, A = null, z = null, H = null, Q = null;
          for (Y in i) {
            var ee = i[Y];
            if (i.hasOwnProperty(Y) && ee != null) switch (Y) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                z = ee;
              default:
                c.hasOwnProperty(Y) || Qe(n, o, Y, null, c, ee);
            }
          }
          for (var V in c) {
            var Y = c[V];
            if (ee = i[V], c.hasOwnProperty(V) && (Y != null || ee != null)) switch (V) {
              case "type":
                h = Y;
                break;
              case "name":
                d = Y;
                break;
              case "checked":
                H = Y;
                break;
              case "defaultChecked":
                Q = Y;
                break;
              case "value":
                w = Y;
                break;
              case "defaultValue":
                A = Y;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (Y != null) throw Error(a(137, o));
                break;
              default:
                Y !== ee && Qe(n, o, V, Y, c, ee);
            }
          }
          hf(n, w, A, z, H, Q, h, d);
          return;
        case "select":
          Y = w = A = V = null;
          for (h in i) if (z = i[h], i.hasOwnProperty(h) && z != null) switch (h) {
            case "value":
              break;
            case "multiple":
              Y = z;
            default:
              c.hasOwnProperty(h) || Qe(n, o, h, null, c, z);
          }
          for (d in c) if (h = c[d], z = i[d], c.hasOwnProperty(d) && (h != null || z != null)) switch (d) {
            case "value":
              V = h;
              break;
            case "defaultValue":
              A = h;
              break;
            case "multiple":
              w = h;
            default:
              h !== z && Qe(n, o, d, h, c, z);
          }
          o = A, i = w, c = Y, V != null ? Aa(n, !!i, V, false) : !!c != !!i && (o != null ? Aa(n, !!i, o, true) : Aa(n, !!i, i ? [] : "", false));
          return;
        case "textarea":
          Y = V = null;
          for (A in i) if (d = i[A], i.hasOwnProperty(A) && d != null && !c.hasOwnProperty(A)) switch (A) {
            case "value":
              break;
            case "children":
              break;
            default:
              Qe(n, o, A, null, c, d);
          }
          for (w in c) if (d = c[w], h = i[w], c.hasOwnProperty(w) && (d != null || h != null)) switch (w) {
            case "value":
              V = d;
              break;
            case "defaultValue":
              Y = d;
              break;
            case "children":
              break;
            case "dangerouslySetInnerHTML":
              if (d != null) throw Error(a(91));
              break;
            default:
              d !== h && Qe(n, o, w, d, c, h);
          }
          rg(n, V, Y);
          return;
        case "option":
          for (var de in i) if (V = i[de], i.hasOwnProperty(de) && V != null && !c.hasOwnProperty(de)) switch (de) {
            case "selected":
              n.selected = false;
              break;
            default:
              Qe(n, o, de, null, c, V);
          }
          for (z in c) if (V = c[z], Y = i[z], c.hasOwnProperty(z) && V !== Y && (V != null || Y != null)) switch (z) {
            case "selected":
              n.selected = V && typeof V != "function" && typeof V != "symbol";
              break;
            default:
              Qe(n, o, z, V, c, Y);
          }
          return;
        case "img":
        case "link":
        case "area":
        case "base":
        case "br":
        case "col":
        case "embed":
        case "hr":
        case "keygen":
        case "meta":
        case "param":
        case "source":
        case "track":
        case "wbr":
        case "menuitem":
          for (var we in i) V = i[we], i.hasOwnProperty(we) && V != null && !c.hasOwnProperty(we) && Qe(n, o, we, null, c, V);
          for (H in c) if (V = c[H], Y = i[H], c.hasOwnProperty(H) && V !== Y && (V != null || Y != null)) switch (H) {
            case "children":
            case "dangerouslySetInnerHTML":
              if (V != null) throw Error(a(137, o));
              break;
            default:
              Qe(n, o, H, V, c, Y);
          }
          return;
        default:
          if (mf(o)) {
            for (var Ge in i) V = i[Ge], i.hasOwnProperty(Ge) && V !== void 0 && !c.hasOwnProperty(Ge) && th(n, o, Ge, void 0, c, V);
            for (Q in c) V = c[Q], Y = i[Q], !c.hasOwnProperty(Q) || V === Y || V === void 0 && Y === void 0 || th(n, o, Q, V, c, Y);
            return;
          }
      }
      for (var U in i) V = i[U], i.hasOwnProperty(U) && V != null && !c.hasOwnProperty(U) && Qe(n, o, U, null, c, V);
      for (ee in c) V = c[ee], Y = i[ee], !c.hasOwnProperty(ee) || V === Y || V == null && Y == null || Qe(n, o, ee, V, c, Y);
    }
    function sb(n) {
      switch (n) {
        case "css":
        case "script":
        case "font":
        case "img":
        case "image":
        case "input":
        case "link":
          return true;
        default:
          return false;
      }
    }
    function oT() {
      if (typeof performance.getEntriesByType == "function") {
        for (var n = 0, o = 0, i = performance.getEntriesByType("resource"), c = 0; c < i.length; c++) {
          var d = i[c], h = d.transferSize, w = d.initiatorType, A = d.duration;
          if (h && A && sb(w)) {
            for (w = 0, A = d.responseEnd, c += 1; c < i.length; c++) {
              var z = i[c], H = z.startTime;
              if (H > A) break;
              var Q = z.transferSize, ee = z.initiatorType;
              Q && sb(ee) && (z = z.responseEnd, w += Q * (z < A ? 1 : (A - H) / (z - H)));
            }
            if (--c, o += 8 * (h + w) / (d.duration / 1e3), n++, 10 < n) break;
          }
        }
        if (0 < n) return o / n / 1e6;
      }
      return navigator.connection && (n = navigator.connection.downlink, typeof n == "number") ? n : 5;
    }
    var nh = null, rh = null;
    function fc(n) {
      return n.nodeType === 9 ? n : n.ownerDocument;
    }
    function lb(n) {
      switch (n) {
        case "http://www.w3.org/2000/svg":
          return 1;
        case "http://www.w3.org/1998/Math/MathML":
          return 2;
        default:
          return 0;
      }
    }
    function cb(n, o) {
      if (n === 0) switch (o) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
      return n === 1 && o === "foreignObject" ? 0 : n;
    }
    function oh(n, o) {
      return n === "textarea" || n === "noscript" || typeof o.children == "string" || typeof o.children == "number" || typeof o.children == "bigint" || typeof o.dangerouslySetInnerHTML == "object" && o.dangerouslySetInnerHTML !== null && o.dangerouslySetInnerHTML.__html != null;
    }
    var ah = null;
    function aT() {
      var n = window.event;
      return n && n.type === "popstate" ? n === ah ? false : (ah = n, true) : (ah = null, false);
    }
    var ub = typeof setTimeout == "function" ? setTimeout : void 0, iT = typeof clearTimeout == "function" ? clearTimeout : void 0, fb = typeof Promise == "function" ? Promise : void 0, sT = typeof queueMicrotask == "function" ? queueMicrotask : typeof fb < "u" ? function(n) {
      return fb.resolve(null).then(n).catch(lT);
    } : ub;
    function lT(n) {
      setTimeout(function() {
        throw n;
      });
    }
    function po(n) {
      return n === "head";
    }
    function db(n, o) {
      var i = o, c = 0;
      do {
        var d = i.nextSibling;
        if (n.removeChild(i), d && d.nodeType === 8) if (i = d.data, i === "/$" || i === "/&") {
          if (c === 0) {
            n.removeChild(d), ri(o);
            return;
          }
          c--;
        } else if (i === "$" || i === "$?" || i === "$~" || i === "$!" || i === "&") c++;
        else if (i === "html") ws(n.ownerDocument.documentElement);
        else if (i === "head") {
          i = n.ownerDocument.head, ws(i);
          for (var h = i.firstChild; h; ) {
            var w = h.nextSibling, A = h.nodeName;
            h[Ui] || A === "SCRIPT" || A === "STYLE" || A === "LINK" && h.rel.toLowerCase() === "stylesheet" || i.removeChild(h), h = w;
          }
        } else i === "body" && ws(n.ownerDocument.body);
        i = d;
      } while (i);
      ri(o);
    }
    function hb(n, o) {
      var i = n;
      n = 0;
      do {
        var c = i.nextSibling;
        if (i.nodeType === 1 ? o ? (i._stashedDisplay = i.style.display, i.style.display = "none") : (i.style.display = i._stashedDisplay || "", i.getAttribute("style") === "" && i.removeAttribute("style")) : i.nodeType === 3 && (o ? (i._stashedText = i.nodeValue, i.nodeValue = "") : i.nodeValue = i._stashedText || ""), c && c.nodeType === 8) if (i = c.data, i === "/$") {
          if (n === 0) break;
          n--;
        } else i !== "$" && i !== "$?" && i !== "$~" && i !== "$!" || n++;
        i = c;
      } while (i);
    }
    function ih(n) {
      var o = n.firstChild;
      for (o && o.nodeType === 10 && (o = o.nextSibling); o; ) {
        var i = o;
        switch (o = o.nextSibling, i.nodeName) {
          case "HTML":
          case "HEAD":
          case "BODY":
            ih(i), ff(i);
            continue;
          case "SCRIPT":
          case "STYLE":
            continue;
          case "LINK":
            if (i.rel.toLowerCase() === "stylesheet") continue;
        }
        n.removeChild(i);
      }
    }
    function cT(n, o, i, c) {
      for (; n.nodeType === 1; ) {
        var d = i;
        if (n.nodeName.toLowerCase() !== o.toLowerCase()) {
          if (!c && (n.nodeName !== "INPUT" || n.type !== "hidden")) break;
        } else if (c) {
          if (!n[Ui]) switch (o) {
            case "meta":
              if (!n.hasAttribute("itemprop")) break;
              return n;
            case "link":
              if (h = n.getAttribute("rel"), h === "stylesheet" && n.hasAttribute("data-precedence")) break;
              if (h !== d.rel || n.getAttribute("href") !== (d.href == null || d.href === "" ? null : d.href) || n.getAttribute("crossorigin") !== (d.crossOrigin == null ? null : d.crossOrigin) || n.getAttribute("title") !== (d.title == null ? null : d.title)) break;
              return n;
            case "style":
              if (n.hasAttribute("data-precedence")) break;
              return n;
            case "script":
              if (h = n.getAttribute("src"), (h !== (d.src == null ? null : d.src) || n.getAttribute("type") !== (d.type == null ? null : d.type) || n.getAttribute("crossorigin") !== (d.crossOrigin == null ? null : d.crossOrigin)) && h && n.hasAttribute("async") && !n.hasAttribute("itemprop")) break;
              return n;
            default:
              return n;
          }
        } else if (o === "input" && n.type === "hidden") {
          var h = d.name == null ? null : "" + d.name;
          if (d.type === "hidden" && n.getAttribute("name") === h) return n;
        } else return n;
        if (n = On(n.nextSibling), n === null) break;
      }
      return null;
    }
    function uT(n, o, i) {
      if (o === "") return null;
      for (; n.nodeType !== 3; ) if ((n.nodeType !== 1 || n.nodeName !== "INPUT" || n.type !== "hidden") && !i || (n = On(n.nextSibling), n === null)) return null;
      return n;
    }
    function pb(n, o) {
      for (; n.nodeType !== 8; ) if ((n.nodeType !== 1 || n.nodeName !== "INPUT" || n.type !== "hidden") && !o || (n = On(n.nextSibling), n === null)) return null;
      return n;
    }
    function sh(n) {
      return n.data === "$?" || n.data === "$~";
    }
    function lh(n) {
      return n.data === "$!" || n.data === "$?" && n.ownerDocument.readyState !== "loading";
    }
    function fT(n, o) {
      var i = n.ownerDocument;
      if (n.data === "$~") n._reactRetry = o;
      else if (n.data !== "$?" || i.readyState !== "loading") o();
      else {
        var c = function() {
          o(), i.removeEventListener("DOMContentLoaded", c);
        };
        i.addEventListener("DOMContentLoaded", c), n._reactRetry = c;
      }
    }
    function On(n) {
      for (; n != null; n = n.nextSibling) {
        var o = n.nodeType;
        if (o === 1 || o === 3) break;
        if (o === 8) {
          if (o = n.data, o === "$" || o === "$!" || o === "$?" || o === "$~" || o === "&" || o === "F!" || o === "F") break;
          if (o === "/$" || o === "/&") return null;
        }
      }
      return n;
    }
    var ch = null;
    function mb(n) {
      n = n.nextSibling;
      for (var o = 0; n; ) {
        if (n.nodeType === 8) {
          var i = n.data;
          if (i === "/$" || i === "/&") {
            if (o === 0) return On(n.nextSibling);
            o--;
          } else i !== "$" && i !== "$!" && i !== "$?" && i !== "$~" && i !== "&" || o++;
        }
        n = n.nextSibling;
      }
      return null;
    }
    function gb(n) {
      n = n.previousSibling;
      for (var o = 0; n; ) {
        if (n.nodeType === 8) {
          var i = n.data;
          if (i === "$" || i === "$!" || i === "$?" || i === "$~" || i === "&") {
            if (o === 0) return n;
            o--;
          } else i !== "/$" && i !== "/&" || o++;
        }
        n = n.previousSibling;
      }
      return null;
    }
    function vb(n, o, i) {
      switch (o = fc(i), n) {
        case "html":
          if (n = o.documentElement, !n) throw Error(a(452));
          return n;
        case "head":
          if (n = o.head, !n) throw Error(a(453));
          return n;
        case "body":
          if (n = o.body, !n) throw Error(a(454));
          return n;
        default:
          throw Error(a(451));
      }
    }
    function ws(n) {
      for (var o = n.attributes; o.length; ) n.removeAttributeNode(o[0]);
      ff(n);
    }
    var Rn = /* @__PURE__ */ new Map(), yb = /* @__PURE__ */ new Set();
    function dc(n) {
      return typeof n.getRootNode == "function" ? n.getRootNode() : n.nodeType === 9 ? n : n.ownerDocument;
    }
    var Pr = Z.d;
    Z.d = { f: dT, r: hT, D: pT, C: mT, L: gT, m: vT, X: bT, S: yT, M: wT };
    function dT() {
      var n = Pr.f(), o = rc();
      return n || o;
    }
    function hT(n) {
      var o = xa(n);
      o !== null && o.tag === 5 && o.type === "form" ? kv(o) : Pr.r(n);
    }
    var ei = typeof document > "u" ? null : document;
    function bb(n, o, i) {
      var c = ei;
      if (c && typeof o == "string" && o) {
        var d = Sn(o);
        d = 'link[rel="' + n + '"][href="' + d + '"]', typeof i == "string" && (d += '[crossorigin="' + i + '"]'), yb.has(d) || (yb.add(d), n = { rel: n, crossOrigin: i, href: o }, c.querySelector(d) === null && (o = c.createElement("link"), Nt(o, "link", n), xt(o), c.head.appendChild(o)));
      }
    }
    function pT(n) {
      Pr.D(n), bb("dns-prefetch", n, null);
    }
    function mT(n, o) {
      Pr.C(n, o), bb("preconnect", n, o);
    }
    function gT(n, o, i) {
      Pr.L(n, o, i);
      var c = ei;
      if (c && n && o) {
        var d = 'link[rel="preload"][as="' + Sn(o) + '"]';
        o === "image" && i && i.imageSrcSet ? (d += '[imagesrcset="' + Sn(i.imageSrcSet) + '"]', typeof i.imageSizes == "string" && (d += '[imagesizes="' + Sn(i.imageSizes) + '"]')) : d += '[href="' + Sn(n) + '"]';
        var h = d;
        switch (o) {
          case "style":
            h = ti(n);
            break;
          case "script":
            h = ni(n);
        }
        Rn.has(h) || (n = g({ rel: "preload", href: o === "image" && i && i.imageSrcSet ? void 0 : n, as: o }, i), Rn.set(h, n), c.querySelector(d) !== null || o === "style" && c.querySelector(Ss(h)) || o === "script" && c.querySelector(xs(h)) || (o = c.createElement("link"), Nt(o, "link", n), xt(o), c.head.appendChild(o)));
      }
    }
    function vT(n, o) {
      Pr.m(n, o);
      var i = ei;
      if (i && n) {
        var c = o && typeof o.as == "string" ? o.as : "script", d = 'link[rel="modulepreload"][as="' + Sn(c) + '"][href="' + Sn(n) + '"]', h = d;
        switch (c) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            h = ni(n);
        }
        if (!Rn.has(h) && (n = g({ rel: "modulepreload", href: n }, o), Rn.set(h, n), i.querySelector(d) === null)) {
          switch (c) {
            case "audioworklet":
            case "paintworklet":
            case "serviceworker":
            case "sharedworker":
            case "worker":
            case "script":
              if (i.querySelector(xs(h))) return;
          }
          c = i.createElement("link"), Nt(c, "link", n), xt(c), i.head.appendChild(c);
        }
      }
    }
    function yT(n, o, i) {
      Pr.S(n, o, i);
      var c = ei;
      if (c && n) {
        var d = _a4(c).hoistableStyles, h = ti(n);
        o = o || "default";
        var w = d.get(h);
        if (!w) {
          var A = { loading: 0, preload: null };
          if (w = c.querySelector(Ss(h))) A.loading = 5;
          else {
            n = g({ rel: "stylesheet", href: n, "data-precedence": o }, i), (i = Rn.get(h)) && uh(n, i);
            var z = w = c.createElement("link");
            xt(z), Nt(z, "link", n), z._p = new Promise(function(H, Q) {
              z.onload = H, z.onerror = Q;
            }), z.addEventListener("load", function() {
              A.loading |= 1;
            }), z.addEventListener("error", function() {
              A.loading |= 2;
            }), A.loading |= 4, hc(w, o, c);
          }
          w = { type: "stylesheet", instance: w, count: 1, state: A }, d.set(h, w);
        }
      }
    }
    function bT(n, o) {
      Pr.X(n, o);
      var i = ei;
      if (i && n) {
        var c = _a4(i).hoistableScripts, d = ni(n), h = c.get(d);
        h || (h = i.querySelector(xs(d)), h || (n = g({ src: n, async: true }, o), (o = Rn.get(d)) && fh(n, o), h = i.createElement("script"), xt(h), Nt(h, "link", n), i.head.appendChild(h)), h = { type: "script", instance: h, count: 1, state: null }, c.set(d, h));
      }
    }
    function wT(n, o) {
      Pr.M(n, o);
      var i = ei;
      if (i && n) {
        var c = _a4(i).hoistableScripts, d = ni(n), h = c.get(d);
        h || (h = i.querySelector(xs(d)), h || (n = g({ src: n, async: true, type: "module" }, o), (o = Rn.get(d)) && fh(n, o), h = i.createElement("script"), xt(h), Nt(h, "link", n), i.head.appendChild(h)), h = { type: "script", instance: h, count: 1, state: null }, c.set(d, h));
      }
    }
    function wb(n, o, i, c) {
      var d = (d = ge.current) ? dc(d) : null;
      if (!d) throw Error(a(446));
      switch (n) {
        case "meta":
        case "title":
          return null;
        case "style":
          return typeof i.precedence == "string" && typeof i.href == "string" ? (o = ti(i.href), i = _a4(d).hoistableStyles, c = i.get(o), c || (c = { type: "style", instance: null, count: 0, state: null }, i.set(o, c)), c) : { type: "void", instance: null, count: 0, state: null };
        case "link":
          if (i.rel === "stylesheet" && typeof i.href == "string" && typeof i.precedence == "string") {
            n = ti(i.href);
            var h = _a4(d).hoistableStyles, w = h.get(n);
            if (w || (d = d.ownerDocument || d, w = { type: "stylesheet", instance: null, count: 0, state: { loading: 0, preload: null } }, h.set(n, w), (h = d.querySelector(Ss(n))) && !h._p && (w.instance = h, w.state.loading = 5), Rn.has(n) || (i = { rel: "preload", as: "style", href: i.href, crossOrigin: i.crossOrigin, integrity: i.integrity, media: i.media, hrefLang: i.hrefLang, referrerPolicy: i.referrerPolicy }, Rn.set(n, i), h || ST(d, n, i, w.state))), o && c === null) throw Error(a(528, ""));
            return w;
          }
          if (o && c !== null) throw Error(a(529, ""));
          return null;
        case "script":
          return o = i.async, i = i.src, typeof i == "string" && o && typeof o != "function" && typeof o != "symbol" ? (o = ni(i), i = _a4(d).hoistableScripts, c = i.get(o), c || (c = { type: "script", instance: null, count: 0, state: null }, i.set(o, c)), c) : { type: "void", instance: null, count: 0, state: null };
        default:
          throw Error(a(444, n));
      }
    }
    function ti(n) {
      return 'href="' + Sn(n) + '"';
    }
    function Ss(n) {
      return 'link[rel="stylesheet"][' + n + "]";
    }
    function Sb(n) {
      return g({}, n, { "data-precedence": n.precedence, precedence: null });
    }
    function ST(n, o, i, c) {
      n.querySelector('link[rel="preload"][as="style"][' + o + "]") ? c.loading = 1 : (o = n.createElement("link"), c.preload = o, o.addEventListener("load", function() {
        return c.loading |= 1;
      }), o.addEventListener("error", function() {
        return c.loading |= 2;
      }), Nt(o, "link", i), xt(o), n.head.appendChild(o));
    }
    function ni(n) {
      return '[src="' + Sn(n) + '"]';
    }
    function xs(n) {
      return "script[async]" + n;
    }
    function xb(n, o, i) {
      if (o.count++, o.instance === null) switch (o.type) {
        case "style":
          var c = n.querySelector('style[data-href~="' + Sn(i.href) + '"]');
          if (c) return o.instance = c, xt(c), c;
          var d = g({}, i, { "data-href": i.href, "data-precedence": i.precedence, href: null, precedence: null });
          return c = (n.ownerDocument || n).createElement("style"), xt(c), Nt(c, "style", d), hc(c, i.precedence, n), o.instance = c;
        case "stylesheet":
          d = ti(i.href);
          var h = n.querySelector(Ss(d));
          if (h) return o.state.loading |= 4, o.instance = h, xt(h), h;
          c = Sb(i), (d = Rn.get(d)) && uh(c, d), h = (n.ownerDocument || n).createElement("link"), xt(h);
          var w = h;
          return w._p = new Promise(function(A, z) {
            w.onload = A, w.onerror = z;
          }), Nt(h, "link", c), o.state.loading |= 4, hc(h, i.precedence, n), o.instance = h;
        case "script":
          return h = ni(i.src), (d = n.querySelector(xs(h))) ? (o.instance = d, xt(d), d) : (c = i, (d = Rn.get(h)) && (c = g({}, i), fh(c, d)), n = n.ownerDocument || n, d = n.createElement("script"), xt(d), Nt(d, "link", c), n.head.appendChild(d), o.instance = d);
        case "void":
          return null;
        default:
          throw Error(a(443, o.type));
      }
      else o.type === "stylesheet" && (o.state.loading & 4) === 0 && (c = o.instance, o.state.loading |= 4, hc(c, i.precedence, n));
      return o.instance;
    }
    function hc(n, o, i) {
      for (var c = i.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), d = c.length ? c[c.length - 1] : null, h = d, w = 0; w < c.length; w++) {
        var A = c[w];
        if (A.dataset.precedence === o) h = A;
        else if (h !== d) break;
      }
      h ? h.parentNode.insertBefore(n, h.nextSibling) : (o = i.nodeType === 9 ? i.head : i, o.insertBefore(n, o.firstChild));
    }
    function uh(n, o) {
      n.crossOrigin == null && (n.crossOrigin = o.crossOrigin), n.referrerPolicy == null && (n.referrerPolicy = o.referrerPolicy), n.title == null && (n.title = o.title);
    }
    function fh(n, o) {
      n.crossOrigin == null && (n.crossOrigin = o.crossOrigin), n.referrerPolicy == null && (n.referrerPolicy = o.referrerPolicy), n.integrity == null && (n.integrity = o.integrity);
    }
    var pc = null;
    function _b2(n, o, i) {
      if (pc === null) {
        var c = /* @__PURE__ */ new Map(), d = pc = /* @__PURE__ */ new Map();
        d.set(i, c);
      } else d = pc, c = d.get(i), c || (c = /* @__PURE__ */ new Map(), d.set(i, c));
      if (c.has(n)) return c;
      for (c.set(n, null), i = i.getElementsByTagName(n), d = 0; d < i.length; d++) {
        var h = i[d];
        if (!(h[Ui] || h[Tt] || n === "link" && h.getAttribute("rel") === "stylesheet") && h.namespaceURI !== "http://www.w3.org/2000/svg") {
          var w = h.getAttribute(o) || "";
          w = n + w;
          var A = c.get(w);
          A ? A.push(h) : c.set(w, [h]);
        }
      }
      return c;
    }
    function Eb(n, o, i) {
      n = n.ownerDocument || n, n.head.insertBefore(i, o === "title" ? n.querySelector("head > title") : null);
    }
    function xT(n, o, i) {
      if (i === 1 || o.itemProp != null) return false;
      switch (n) {
        case "meta":
        case "title":
          return true;
        case "style":
          if (typeof o.precedence != "string" || typeof o.href != "string" || o.href === "") break;
          return true;
        case "link":
          if (typeof o.rel != "string" || typeof o.href != "string" || o.href === "" || o.onLoad || o.onError) break;
          switch (o.rel) {
            case "stylesheet":
              return n = o.disabled, typeof o.precedence == "string" && n == null;
            default:
              return true;
          }
        case "script":
          if (o.async && typeof o.async != "function" && typeof o.async != "symbol" && !o.onLoad && !o.onError && o.src && typeof o.src == "string") return true;
      }
      return false;
    }
    function Ab(n) {
      return !(n.type === "stylesheet" && (n.state.loading & 3) === 0);
    }
    function _T(n, o, i, c) {
      if (i.type === "stylesheet" && (typeof c.media != "string" || matchMedia(c.media).matches !== false) && (i.state.loading & 4) === 0) {
        if (i.instance === null) {
          var d = ti(c.href), h = o.querySelector(Ss(d));
          if (h) {
            o = h._p, o !== null && typeof o == "object" && typeof o.then == "function" && (n.count++, n = mc.bind(n), o.then(n, n)), i.state.loading |= 4, i.instance = h, xt(h);
            return;
          }
          h = o.ownerDocument || o, c = Sb(c), (d = Rn.get(d)) && uh(c, d), h = h.createElement("link"), xt(h);
          var w = h;
          w._p = new Promise(function(A, z) {
            w.onload = A, w.onerror = z;
          }), Nt(h, "link", c), i.instance = h;
        }
        n.stylesheets === null && (n.stylesheets = /* @__PURE__ */ new Map()), n.stylesheets.set(i, o), (o = i.state.preload) && (i.state.loading & 3) === 0 && (n.count++, i = mc.bind(n), o.addEventListener("load", i), o.addEventListener("error", i));
      }
    }
    var dh = 0;
    function ET(n, o) {
      return n.stylesheets && n.count === 0 && vc(n, n.stylesheets), 0 < n.count || 0 < n.imgCount ? function(i) {
        var c = setTimeout(function() {
          if (n.stylesheets && vc(n, n.stylesheets), n.unsuspend) {
            var h = n.unsuspend;
            n.unsuspend = null, h();
          }
        }, 6e4 + o);
        0 < n.imgBytes && dh === 0 && (dh = 62500 * oT());
        var d = setTimeout(function() {
          if (n.waitingForImages = false, n.count === 0 && (n.stylesheets && vc(n, n.stylesheets), n.unsuspend)) {
            var h = n.unsuspend;
            n.unsuspend = null, h();
          }
        }, (n.imgBytes > dh ? 50 : 800) + o);
        return n.unsuspend = i, function() {
          n.unsuspend = null, clearTimeout(c), clearTimeout(d);
        };
      } : null;
    }
    function mc() {
      if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
        if (this.stylesheets) vc(this, this.stylesheets);
        else if (this.unsuspend) {
          var n = this.unsuspend;
          this.unsuspend = null, n();
        }
      }
    }
    var gc = null;
    function vc(n, o) {
      n.stylesheets = null, n.unsuspend !== null && (n.count++, gc = /* @__PURE__ */ new Map(), o.forEach(AT, n), gc = null, mc.call(n));
    }
    function AT(n, o) {
      if (!(o.state.loading & 4)) {
        var i = gc.get(n);
        if (i) var c = i.get(null);
        else {
          i = /* @__PURE__ */ new Map(), gc.set(n, i);
          for (var d = n.querySelectorAll("link[data-precedence],style[data-precedence]"), h = 0; h < d.length; h++) {
            var w = d[h];
            (w.nodeName === "LINK" || w.getAttribute("media") !== "not all") && (i.set(w.dataset.precedence, w), c = w);
          }
          c && i.set(null, c);
        }
        d = o.instance, w = d.getAttribute("data-precedence"), h = i.get(w) || c, h === c && i.set(null, d), i.set(w, d), this.count++, c = mc.bind(this), d.addEventListener("load", c), d.addEventListener("error", c), h ? h.parentNode.insertBefore(d, h.nextSibling) : (n = n.nodeType === 9 ? n.head : n, n.insertBefore(d, n.firstChild)), o.state.loading |= 4;
      }
    }
    var _s4 = { $$typeof: O, Provider: null, Consumer: null, _currentValue: B, _currentValue2: B, _threadCount: 0 };
    function CT(n, o, i, c, d, h, w, A, z) {
      this.tag = 1, this.containerInfo = n, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = Xr(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Xr(0), this.hiddenUpdates = Xr(null), this.identifierPrefix = c, this.onUncaughtError = d, this.onCaughtError = h, this.onRecoverableError = w, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = z, this.incompleteTransitions = /* @__PURE__ */ new Map();
    }
    function Cb(n, o, i, c, d, h, w, A, z, H, Q, ee) {
      return n = new CT(n, o, i, w, z, H, Q, ee, A), o = 1, h === true && (o |= 24), h = un(3, null, null, o), n.current = h, h.stateNode = n, o = Ff(), o.refCount++, n.pooledCache = o, o.refCount++, h.memoizedState = { element: c, isDehydrated: i, cache: o }, Qf(h), n;
    }
    function Tb(n) {
      return n ? (n = Da, n) : Da;
    }
    function Ob(n, o, i, c, d, h) {
      d = Tb(d), c.context === null ? c.context = d : c.pendingContext = d, c = no(o), c.payload = { element: i }, h = h === void 0 ? null : h, h !== null && (c.callback = h), i = ro(n, c, o), i !== null && (en(i, n, o), ts(i, n, o));
    }
    function Rb(n, o) {
      if (n = n.memoizedState, n !== null && n.dehydrated !== null) {
        var i = n.retryLane;
        n.retryLane = i !== 0 && i < o ? i : o;
      }
    }
    function hh(n, o) {
      Rb(n, o), (n = n.alternate) && Rb(n, o);
    }
    function Mb(n) {
      if (n.tag === 13 || n.tag === 31) {
        var o = Vo(n, 67108864);
        o !== null && en(o, n, 67108864), hh(n, 67108864);
      }
    }
    function Nb(n) {
      if (n.tag === 13 || n.tag === 31) {
        var o = mn();
        o = ba(o);
        var i = Vo(n, o);
        i !== null && en(i, n, o), hh(n, o);
      }
    }
    var yc = true;
    function TT(n, o, i, c) {
      var d = N.T;
      N.T = null;
      var h = Z.p;
      try {
        Z.p = 2, ph(n, o, i, c);
      } finally {
        Z.p = h, N.T = d;
      }
    }
    function OT(n, o, i, c) {
      var d = N.T;
      N.T = null;
      var h = Z.p;
      try {
        Z.p = 8, ph(n, o, i, c);
      } finally {
        Z.p = h, N.T = d;
      }
    }
    function ph(n, o, i, c) {
      if (yc) {
        var d = mh(c);
        if (d === null) eh(n, o, c, bc, i), Db(n, c);
        else if (MT(d, n, o, i, c)) c.stopPropagation();
        else if (Db(n, c), o & 4 && -1 < RT.indexOf(n)) {
          for (; d !== null; ) {
            var h = xa(d);
            if (h !== null) switch (h.tag) {
              case 3:
                if (h = h.stateNode, h.current.memoizedState.isDehydrated) {
                  var w = Kn(h.pendingLanes);
                  if (w !== 0) {
                    var A = h;
                    for (A.pendingLanes |= 2, A.entangledLanes |= 2; w; ) {
                      var z = 1 << 31 - kt(w);
                      A.entanglements[1] |= z, w &= ~z;
                    }
                    tr(h), (Ze & 6) === 0 && (tc = Ht() + 500, vs(0));
                  }
                }
                break;
              case 31:
              case 13:
                A = Vo(h, 2), A !== null && en(A, h, 2), rc(), hh(h, 2);
            }
            if (h = mh(c), h === null && eh(n, o, c, bc, i), h === d) break;
            d = h;
          }
          d !== null && c.stopPropagation();
        } else eh(n, o, c, null, i);
      }
    }
    function mh(n) {
      return n = vf(n), gh(n);
    }
    var bc = null;
    function gh(n) {
      if (bc = null, n = Sa(n), n !== null) {
        var o = l(n);
        if (o === null) n = null;
        else {
          var i = o.tag;
          if (i === 13) {
            if (n = u(o), n !== null) return n;
            n = null;
          } else if (i === 31) {
            if (n = f(o), n !== null) return n;
            n = null;
          } else if (i === 3) {
            if (o.stateNode.current.memoizedState.isDehydrated) return o.tag === 3 ? o.stateNode.containerInfo : null;
            n = null;
          } else o !== n && (n = null);
        }
      }
      return bc = n, null;
    }
    function zb(n) {
      switch (n) {
        case "beforetoggle":
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "toggle":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
          return 2;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
          return 8;
        case "message":
          switch (sf()) {
            case jo:
              return 2;
            case fl:
              return 8;
            case ko:
            case Pi:
              return 32;
            case yr:
              return 268435456;
            default:
              return 32;
          }
        default:
          return 32;
      }
    }
    var vh = false, mo = null, go = null, vo = null, Es = /* @__PURE__ */ new Map(), As = /* @__PURE__ */ new Map(), yo = [], RT = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");
    function Db(n, o) {
      switch (n) {
        case "focusin":
        case "focusout":
          mo = null;
          break;
        case "dragenter":
        case "dragleave":
          go = null;
          break;
        case "mouseover":
        case "mouseout":
          vo = null;
          break;
        case "pointerover":
        case "pointerout":
          Es.delete(o.pointerId);
          break;
        case "gotpointercapture":
        case "lostpointercapture":
          As.delete(o.pointerId);
      }
    }
    function Cs(n, o, i, c, d, h) {
      return n === null || n.nativeEvent !== h ? (n = { blockedOn: o, domEventName: i, eventSystemFlags: c, nativeEvent: h, targetContainers: [d] }, o !== null && (o = xa(o), o !== null && Mb(o)), n) : (n.eventSystemFlags |= c, o = n.targetContainers, d !== null && o.indexOf(d) === -1 && o.push(d), n);
    }
    function MT(n, o, i, c, d) {
      switch (o) {
        case "focusin":
          return mo = Cs(mo, n, o, i, c, d), true;
        case "dragenter":
          return go = Cs(go, n, o, i, c, d), true;
        case "mouseover":
          return vo = Cs(vo, n, o, i, c, d), true;
        case "pointerover":
          var h = d.pointerId;
          return Es.set(h, Cs(Es.get(h) || null, n, o, i, c, d)), true;
        case "gotpointercapture":
          return h = d.pointerId, As.set(h, Cs(As.get(h) || null, n, o, i, c, d)), true;
      }
      return false;
    }
    function jb(n) {
      var o = Sa(n.target);
      if (o !== null) {
        var i = l(o);
        if (i !== null) {
          if (o = i.tag, o === 13) {
            if (o = u(i), o !== null) {
              n.blockedOn = o, Xm(n.priority, function() {
                Nb(i);
              });
              return;
            }
          } else if (o === 31) {
            if (o = f(i), o !== null) {
              n.blockedOn = o, Xm(n.priority, function() {
                Nb(i);
              });
              return;
            }
          } else if (o === 3 && i.stateNode.current.memoizedState.isDehydrated) {
            n.blockedOn = i.tag === 3 ? i.stateNode.containerInfo : null;
            return;
          }
        }
      }
      n.blockedOn = null;
    }
    function wc(n) {
      if (n.blockedOn !== null) return false;
      for (var o = n.targetContainers; 0 < o.length; ) {
        var i = mh(n.nativeEvent);
        if (i === null) {
          i = n.nativeEvent;
          var c = new i.constructor(i.type, i);
          gf = c, i.target.dispatchEvent(c), gf = null;
        } else return o = xa(i), o !== null && Mb(o), n.blockedOn = i, false;
        o.shift();
      }
      return true;
    }
    function kb(n, o, i) {
      wc(n) && i.delete(o);
    }
    function NT() {
      vh = false, mo !== null && wc(mo) && (mo = null), go !== null && wc(go) && (go = null), vo !== null && wc(vo) && (vo = null), Es.forEach(kb), As.forEach(kb);
    }
    function Sc(n, o) {
      n.blockedOn === o && (n.blockedOn = null, vh || (vh = true, e.unstable_scheduleCallback(e.unstable_NormalPriority, NT)));
    }
    var xc = null;
    function Pb(n) {
      xc !== n && (xc = n, e.unstable_scheduleCallback(e.unstable_NormalPriority, function() {
        xc === n && (xc = null);
        for (var o = 0; o < n.length; o += 3) {
          var i = n[o], c = n[o + 1], d = n[o + 2];
          if (typeof c != "function") {
            if (gh(c || i) === null) continue;
            break;
          }
          var h = xa(i);
          h !== null && (n.splice(o, 3), o -= 3, md(h, { pending: true, data: d, method: i.method, action: c }, c, d));
        }
      }));
    }
    function ri(n) {
      function o(z) {
        return Sc(z, n);
      }
      mo !== null && Sc(mo, n), go !== null && Sc(go, n), vo !== null && Sc(vo, n), Es.forEach(o), As.forEach(o);
      for (var i = 0; i < yo.length; i++) {
        var c = yo[i];
        c.blockedOn === n && (c.blockedOn = null);
      }
      for (; 0 < yo.length && (i = yo[0], i.blockedOn === null); ) jb(i), i.blockedOn === null && yo.shift();
      if (i = (n.ownerDocument || n).$$reactFormReplay, i != null) for (c = 0; c < i.length; c += 3) {
        var d = i[c], h = i[c + 1], w = d[Xt] || null;
        if (typeof h == "function") w || Pb(i);
        else if (w) {
          var A = null;
          if (h && h.hasAttribute("formAction")) {
            if (d = h, w = h[Xt] || null) A = w.formAction;
            else if (gh(d) !== null) continue;
          } else A = w.action;
          typeof A == "function" ? i[c + 1] = A : (i.splice(c, 3), c -= 3), Pb(i);
        }
      }
    }
    function Lb() {
      function n(h) {
        h.canIntercept && h.info === "react-transition" && h.intercept({ handler: function() {
          return new Promise(function(w) {
            return d = w;
          });
        }, focusReset: "manual", scroll: "manual" });
      }
      function o() {
        d !== null && (d(), d = null), c || setTimeout(i, 20);
      }
      function i() {
        if (!c && !navigation.transition) {
          var h = navigation.currentEntry;
          h && h.url != null && navigation.navigate(h.url, { state: h.getState(), info: "react-transition", history: "replace" });
        }
      }
      if (typeof navigation == "object") {
        var c = false, d = null;
        return navigation.addEventListener("navigate", n), navigation.addEventListener("navigatesuccess", o), navigation.addEventListener("navigateerror", o), setTimeout(i, 100), function() {
          c = true, navigation.removeEventListener("navigate", n), navigation.removeEventListener("navigatesuccess", o), navigation.removeEventListener("navigateerror", o), d !== null && (d(), d = null);
        };
      }
    }
    function yh(n) {
      this._internalRoot = n;
    }
    _c3.prototype.render = yh.prototype.render = function(n) {
      var o = this._internalRoot;
      if (o === null) throw Error(a(409));
      var i = o.current, c = mn();
      Ob(i, c, n, o, null, null);
    }, _c3.prototype.unmount = yh.prototype.unmount = function() {
      var n = this._internalRoot;
      if (n !== null) {
        this._internalRoot = null;
        var o = n.containerInfo;
        Ob(n.current, 2, null, n, null, null), rc(), o[wa] = null;
      }
    };
    function _c3(n) {
      this._internalRoot = n;
    }
    _c3.prototype.unstable_scheduleHydration = function(n) {
      if (n) {
        var o = cf();
        n = { blockedOn: null, target: n, priority: o };
        for (var i = 0; i < yo.length && o !== 0 && o < yo[i].priority; i++) ;
        yo.splice(i, 0, n), i === 0 && jb(n);
      }
    };
    var Ub = t.version;
    if (Ub !== "19.2.4") throw Error(a(527, Ub, "19.2.4"));
    Z.findDOMNode = function(n) {
      var o = n._reactInternals;
      if (o === void 0) throw typeof n.render == "function" ? Error(a(188)) : (n = Object.keys(n).join(","), Error(a(268, n)));
      return n = m(o), n = n !== null ? v(n) : null, n = n === null ? null : n.stateNode, n;
    };
    var zT = { bundleType: 0, version: "19.2.4", rendererPackageName: "react-dom", currentDispatcherRef: N, reconcilerVersion: "19.2.4" };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
      var Ec = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (!Ec.isDisabled && Ec.supportsFiber) try {
        Po = Ec.inject(zT), $t = Ec;
      } catch {
      }
    }
    return Ns.createRoot = function(n, o) {
      if (!s(n)) throw Error(a(299));
      var i = false, c = "", d = Fv, h = qv, w = Yv;
      return o != null && (o.unstable_strictMode === true && (i = true), o.identifierPrefix !== void 0 && (c = o.identifierPrefix), o.onUncaughtError !== void 0 && (d = o.onUncaughtError), o.onCaughtError !== void 0 && (h = o.onCaughtError), o.onRecoverableError !== void 0 && (w = o.onRecoverableError)), o = Cb(n, 1, false, null, null, i, c, null, d, h, w, Lb), n[wa] = o.current, Wd(n), new yh(o);
    }, Ns.hydrateRoot = function(n, o, i) {
      if (!s(n)) throw Error(a(299));
      var c = false, d = "", h = Fv, w = qv, A = Yv, z = null;
      return i != null && (i.unstable_strictMode === true && (c = true), i.identifierPrefix !== void 0 && (d = i.identifierPrefix), i.onUncaughtError !== void 0 && (h = i.onUncaughtError), i.onCaughtError !== void 0 && (w = i.onCaughtError), i.onRecoverableError !== void 0 && (A = i.onRecoverableError), i.formState !== void 0 && (z = i.formState)), o = Cb(n, 1, true, o, i != null ? i : null, c, d, z, h, w, A, Lb), o.context = Tb(null), i = o.current, c = mn(), c = ba(c), d = no(c), d.callback = null, ro(i, d, c), i = c, o.current.lanes = i, at(o, i), tr(o), n[wa] = o.current, Wd(n), new _c3(o);
    }, Ns.version = "19.2.4", Ns;
  }
  var Q0;
  function uj() {
    if (Q0) return Mh.exports;
    Q0 = 1;
    function e() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e);
      } catch (t) {
        console.error(t);
      }
    }
    return e(), Mh.exports = cj(), Mh.exports;
  }
  var fj = uj(), sl = class {
    constructor() {
      this.listeners = /* @__PURE__ */ new Set(), this.subscribe = this.subscribe.bind(this);
    }
    subscribe(e) {
      return this.listeners.add(e), this.onSubscribe(), () => {
        this.listeners.delete(e), this.onUnsubscribe();
      };
    }
    hasListeners() {
      return this.listeners.size > 0;
    }
    onSubscribe() {
    }
    onUnsubscribe() {
    }
  }, dj = { setTimeout: (e, t) => setTimeout(e, t), clearTimeout: (e) => clearTimeout(e), setInterval: (e, t) => setInterval(e, t), clearInterval: (e) => clearInterval(e) }, hj = (_c = class {
    constructor() {
      __privateAdd(this, _e2, dj);
      __privateAdd(this, _t, false);
    }
    setTimeoutProvider(e) {
      __privateSet(this, _e2, e);
    }
    setTimeout(e, t) {
      return __privateGet(this, _e2).setTimeout(e, t);
    }
    clearTimeout(e) {
      __privateGet(this, _e2).clearTimeout(e);
    }
    setInterval(e, t) {
      return __privateGet(this, _e2).setInterval(e, t);
    }
    clearInterval(e) {
      __privateGet(this, _e2).clearInterval(e);
    }
  }, _e2 = new WeakMap(), _t = new WeakMap(), _c), aa = new hj();
  function pj(e) {
    setTimeout(e, 0);
  }
  var fa = typeof window > "u" || "Deno" in globalThis;
  function nn() {
  }
  function mj(e, t) {
    return typeof e == "function" ? e(t) : e;
  }
  function cp(e) {
    return typeof e == "number" && e >= 0 && e !== 1 / 0;
  }
  function Ox(e, t) {
    return Math.max(e + (t || 0) - Date.now(), 0);
  }
  function Ao(e, t) {
    return typeof e == "function" ? e(t) : e;
  }
  function Nn(e, t) {
    return typeof e == "function" ? e(t) : e;
  }
  function G0(e, t) {
    const { type: r = "all", exact: a, fetchStatus: s, predicate: l, queryKey: u, stale: f } = e;
    if (u) {
      if (a) {
        if (t.queryHash !== cm(u, t.options)) return false;
      } else if (!qs(t.queryKey, u)) return false;
    }
    if (r !== "all") {
      const p = t.isActive();
      if (r === "active" && !p || r === "inactive" && p) return false;
    }
    return !(typeof f == "boolean" && t.isStale() !== f || s && s !== t.state.fetchStatus || l && !l(t));
  }
  function K0(e, t) {
    const { exact: r, status: a, predicate: s, mutationKey: l } = e;
    if (l) {
      if (!t.options.mutationKey) return false;
      if (r) {
        if (Fs(t.options.mutationKey) !== Fs(l)) return false;
      } else if (!qs(t.options.mutationKey, l)) return false;
    }
    return !(a && t.state.status !== a || s && !s(t));
  }
  function cm(e, t) {
    return ((t == null ? void 0 : t.queryKeyHashFn) || Fs)(e);
  }
  function Fs(e) {
    return JSON.stringify(e, (t, r) => fp(r) ? Object.keys(r).sort().reduce((a, s) => (a[s] = r[s], a), {}) : r);
  }
  function qs(e, t) {
    return e === t ? true : typeof e != typeof t ? false : e && t && typeof e == "object" && typeof t == "object" ? Object.keys(t).every((r) => qs(e[r], t[r])) : false;
  }
  var gj = Object.prototype.hasOwnProperty;
  function Rx(e, t, r = 0) {
    if (e === t) return e;
    if (r > 500) return t;
    const a = J0(e) && J0(t);
    if (!a && !(fp(e) && fp(t))) return t;
    const l = (a ? e : Object.keys(e)).length, u = a ? t : Object.keys(t), f = u.length, p = a ? new Array(f) : {};
    let m = 0;
    for (let v = 0; v < f; v++) {
      const g = a ? v : u[v], S = e[g], _ = t[g];
      if (S === _) {
        p[g] = S, (a ? v < l : gj.call(e, g)) && m++;
        continue;
      }
      if (S === null || _ === null || typeof S != "object" || typeof _ != "object") {
        p[g] = _;
        continue;
      }
      const x = Rx(S, _, r + 1);
      p[g] = x, x === S && m++;
    }
    return l === f && m === l ? e : p;
  }
  function up(e, t) {
    if (!t || Object.keys(e).length !== Object.keys(t).length) return false;
    for (const r in e) if (e[r] !== t[r]) return false;
    return true;
  }
  function J0(e) {
    return Array.isArray(e) && e.length === Object.keys(e).length;
  }
  function fp(e) {
    if (!W0(e)) return false;
    const t = e.constructor;
    if (t === void 0) return true;
    const r = t.prototype;
    return !(!W0(r) || !r.hasOwnProperty("isPrototypeOf") || Object.getPrototypeOf(e) !== Object.prototype);
  }
  function W0(e) {
    return Object.prototype.toString.call(e) === "[object Object]";
  }
  function vj(e) {
    return new Promise((t) => {
      aa.setTimeout(t, e);
    });
  }
  function dp(e, t, r) {
    return typeof r.structuralSharing == "function" ? r.structuralSharing(e, t) : r.structuralSharing !== false ? Rx(e, t) : t;
  }
  function yj(e, t, r = 0) {
    const a = [...e, t];
    return r && a.length > r ? a.slice(1) : a;
  }
  function bj(e, t, r = 0) {
    const a = [t, ...e];
    return r && a.length > r ? a.slice(0, -1) : a;
  }
  var um = /* @__PURE__ */ Symbol();
  function Mx(e, t) {
    return !e.queryFn && (t == null ? void 0 : t.initialPromise) ? () => t.initialPromise : !e.queryFn || e.queryFn === um ? () => Promise.reject(new Error(`Missing queryFn: '${e.queryHash}'`)) : e.queryFn;
  }
  function Nx(e, t) {
    return typeof e == "function" ? e(...t) : !!e;
  }
  function wj(e, t, r) {
    let a = false, s;
    return Object.defineProperty(e, "signal", { enumerable: true, get: () => (s != null ? s : s = t(), a || (a = true, s.aborted ? r() : s.addEventListener("abort", r, { once: true })), s) }), e;
  }
  var Sj = (_d = class extends sl {
    constructor() {
      super();
      __privateAdd(this, _e3);
      __privateAdd(this, _t2);
      __privateAdd(this, _n);
      __privateSet(this, _n, (e) => {
        if (!fa && window.addEventListener) {
          const t = () => e();
          return window.addEventListener("visibilitychange", t, false), () => {
            window.removeEventListener("visibilitychange", t);
          };
        }
      });
    }
    onSubscribe() {
      __privateGet(this, _t2) || this.setEventListener(__privateGet(this, _n));
    }
    onUnsubscribe() {
      var _a4;
      this.hasListeners() || ((_a4 = __privateGet(this, _t2)) == null ? void 0 : _a4.call(this), __privateSet(this, _t2, void 0));
    }
    setEventListener(e) {
      var _a4;
      __privateSet(this, _n, e), (_a4 = __privateGet(this, _t2)) == null ? void 0 : _a4.call(this), __privateSet(this, _t2, e((t) => {
        typeof t == "boolean" ? this.setFocused(t) : this.onFocus();
      }));
    }
    setFocused(e) {
      __privateGet(this, _e3) !== e && (__privateSet(this, _e3, e), this.onFocus());
    }
    onFocus() {
      const e = this.isFocused();
      this.listeners.forEach((t) => {
        t(e);
      });
    }
    isFocused() {
      var _a4;
      return typeof __privateGet(this, _e3) == "boolean" ? __privateGet(this, _e3) : ((_a4 = globalThis.document) == null ? void 0 : _a4.visibilityState) !== "hidden";
    }
  }, _e3 = new WeakMap(), _t2 = new WeakMap(), _n = new WeakMap(), _d), fm = new Sj();
  function hp() {
    let e, t;
    const r = new Promise((s, l) => {
      e = s, t = l;
    });
    r.status = "pending", r.catch(() => {
    });
    function a(s) {
      Object.assign(r, s), delete r.resolve, delete r.reject;
    }
    return r.resolve = (s) => {
      a({ status: "fulfilled", value: s }), e(s);
    }, r.reject = (s) => {
      a({ status: "rejected", reason: s }), t(s);
    }, r;
  }
  var xj = pj;
  function _j() {
    let e = [], t = 0, r = (f) => {
      f();
    }, a = (f) => {
      f();
    }, s = xj;
    const l = (f) => {
      t ? e.push(f) : s(() => {
        r(f);
      });
    }, u = () => {
      const f = e;
      e = [], f.length && s(() => {
        a(() => {
          f.forEach((p) => {
            r(p);
          });
        });
      });
    };
    return { batch: (f) => {
      let p;
      t++;
      try {
        p = f();
      } finally {
        t--, t || u();
      }
      return p;
    }, batchCalls: (f) => (...p) => {
      l(() => {
        f(...p);
      });
    }, schedule: l, setNotifyFunction: (f) => {
      r = f;
    }, setBatchNotifyFunction: (f) => {
      a = f;
    }, setScheduler: (f) => {
      s = f;
    } };
  }
  var zt = _j(), Ej = (_e5 = class extends sl {
    constructor() {
      super();
      __privateAdd(this, _e4, true);
      __privateAdd(this, _t3);
      __privateAdd(this, _n2);
      __privateSet(this, _n2, (e) => {
        if (!fa && window.addEventListener) {
          const t = () => e(true), r = () => e(false);
          return window.addEventListener("online", t, false), window.addEventListener("offline", r, false), () => {
            window.removeEventListener("online", t), window.removeEventListener("offline", r);
          };
        }
      });
    }
    onSubscribe() {
      __privateGet(this, _t3) || this.setEventListener(__privateGet(this, _n2));
    }
    onUnsubscribe() {
      var _a4;
      this.hasListeners() || ((_a4 = __privateGet(this, _t3)) == null ? void 0 : _a4.call(this), __privateSet(this, _t3, void 0));
    }
    setEventListener(e) {
      var _a4;
      __privateSet(this, _n2, e), (_a4 = __privateGet(this, _t3)) == null ? void 0 : _a4.call(this), __privateSet(this, _t3, e(this.setOnline.bind(this)));
    }
    setOnline(e) {
      __privateGet(this, _e4) !== e && (__privateSet(this, _e4, e), this.listeners.forEach((r) => {
        r(e);
      }));
    }
    isOnline() {
      return __privateGet(this, _e4);
    }
  }, _e4 = new WeakMap(), _t3 = new WeakMap(), _n2 = new WeakMap(), _e5), ou = new Ej();
  function Aj(e) {
    return Math.min(1e3 * 2 ** e, 3e4);
  }
  function zx(e) {
    return (e != null ? e : "online") === "online" ? ou.isOnline() : true;
  }
  var pp = class extends Error {
    constructor(e) {
      super("CancelledError"), this.revert = e == null ? void 0 : e.revert, this.silent = e == null ? void 0 : e.silent;
    }
  };
  function Dx(e) {
    let t = false, r = 0, a;
    const s = hp(), l = () => s.status !== "pending", u = (E) => {
      var _a4;
      if (!l()) {
        const C = new pp(E);
        S(C), (_a4 = e.onCancel) == null ? void 0 : _a4.call(e, C);
      }
    }, f = () => {
      t = true;
    }, p = () => {
      t = false;
    }, m = () => fm.isFocused() && (e.networkMode === "always" || ou.isOnline()) && e.canRun(), v = () => zx(e.networkMode) && e.canRun(), g = (E) => {
      l() || (a == null ? void 0 : a(), s.resolve(E));
    }, S = (E) => {
      l() || (a == null ? void 0 : a(), s.reject(E));
    }, _ = () => new Promise((E) => {
      var _a4;
      a = (C) => {
        (l() || m()) && E(C);
      }, (_a4 = e.onPause) == null ? void 0 : _a4.call(e);
    }).then(() => {
      var _a4;
      a = void 0, l() || ((_a4 = e.onContinue) == null ? void 0 : _a4.call(e));
    }), x = () => {
      if (l()) return;
      let E;
      const C = r === 0 ? e.initialPromise : void 0;
      try {
        E = C != null ? C : e.fn();
      } catch (T) {
        E = Promise.reject(T);
      }
      Promise.resolve(E).then(g).catch((T) => {
        var _a4, _b2, _c3;
        if (l()) return;
        const R = (_a4 = e.retry) != null ? _a4 : fa ? 0 : 3, O = (_b2 = e.retryDelay) != null ? _b2 : Aj, D = typeof O == "function" ? O(r, T) : O, P = R === true || typeof R == "number" && r < R || typeof R == "function" && R(r, T);
        if (t || !P) {
          S(T);
          return;
        }
        r++, (_c3 = e.onFail) == null ? void 0 : _c3.call(e, r, T), vj(D).then(() => m() ? void 0 : _()).then(() => {
          t ? S(T) : x();
        });
      });
    };
    return { promise: s, status: () => s.status, cancel: u, continue: () => (a == null ? void 0 : a(), s), cancelRetry: f, continueRetry: p, canStart: v, start: () => (v() ? x() : _().then(x), s) };
  }
  var jx = (_f = class {
    constructor() {
      __privateAdd(this, _e6);
    }
    destroy() {
      this.clearGcTimeout();
    }
    scheduleGc() {
      this.clearGcTimeout(), cp(this.gcTime) && __privateSet(this, _e6, aa.setTimeout(() => {
        this.optionalRemove();
      }, this.gcTime));
    }
    updateGcTime(e) {
      this.gcTime = Math.max(this.gcTime || 0, e != null ? e : fa ? 1 / 0 : 300 * 1e3);
    }
    clearGcTimeout() {
      __privateGet(this, _e6) && (aa.clearTimeout(__privateGet(this, _e6)), __privateSet(this, _e6, void 0));
    }
  }, _e6 = new WeakMap(), _f), Cj = (_g = class extends jx {
    constructor(e) {
      var _a4;
      super();
      __privateAdd(this, _Cj_instances);
      __privateAdd(this, _e7);
      __privateAdd(this, _t4);
      __privateAdd(this, _n3);
      __privateAdd(this, _o2);
      __privateAdd(this, _r);
      __privateAdd(this, _s);
      __privateAdd(this, _i2);
      __privateSet(this, _i2, false), __privateSet(this, _s, e.defaultOptions), this.setOptions(e.options), this.observers = [], __privateSet(this, _o2, e.client), __privateSet(this, _n3, __privateGet(this, _o2).getQueryCache()), this.queryKey = e.queryKey, this.queryHash = e.queryHash, __privateSet(this, _e7, tw(this.options)), this.state = (_a4 = e.state) != null ? _a4 : __privateGet(this, _e7), this.scheduleGc();
    }
    get meta() {
      return this.options.meta;
    }
    get promise() {
      var _a4;
      return (_a4 = __privateGet(this, _r)) == null ? void 0 : _a4.promise;
    }
    setOptions(e) {
      if (this.options = { ...__privateGet(this, _s), ...e }, this.updateGcTime(this.options.gcTime), this.state && this.state.data === void 0) {
        const t = tw(this.options);
        t.data !== void 0 && (this.setState(ew(t.data, t.dataUpdatedAt)), __privateSet(this, _e7, t));
      }
    }
    optionalRemove() {
      !this.observers.length && this.state.fetchStatus === "idle" && __privateGet(this, _n3).remove(this);
    }
    setData(e, t) {
      const r = dp(this.state.data, e, this.options);
      return __privateMethod(this, _Cj_instances, a_fn).call(this, { data: r, type: "success", dataUpdatedAt: t == null ? void 0 : t.updatedAt, manual: t == null ? void 0 : t.manual }), r;
    }
    setState(e, t) {
      __privateMethod(this, _Cj_instances, a_fn).call(this, { type: "setState", state: e, setStateOptions: t });
    }
    cancel(e) {
      var _a4, _b2;
      const t = (_a4 = __privateGet(this, _r)) == null ? void 0 : _a4.promise;
      return (_b2 = __privateGet(this, _r)) == null ? void 0 : _b2.cancel(e), t ? t.then(nn).catch(nn) : Promise.resolve();
    }
    destroy() {
      super.destroy(), this.cancel({ silent: true });
    }
    reset() {
      this.destroy(), this.setState(__privateGet(this, _e7));
    }
    isActive() {
      return this.observers.some((e) => Nn(e.options.enabled, this) !== false);
    }
    isDisabled() {
      return this.getObserversCount() > 0 ? !this.isActive() : this.options.queryFn === um || this.state.dataUpdateCount + this.state.errorUpdateCount === 0;
    }
    isStatic() {
      return this.getObserversCount() > 0 ? this.observers.some((e) => Ao(e.options.staleTime, this) === "static") : false;
    }
    isStale() {
      return this.getObserversCount() > 0 ? this.observers.some((e) => e.getCurrentResult().isStale) : this.state.data === void 0 || this.state.isInvalidated;
    }
    isStaleByTime(e = 0) {
      return this.state.data === void 0 ? true : e === "static" ? false : this.state.isInvalidated ? true : !Ox(this.state.dataUpdatedAt, e);
    }
    onFocus() {
      var _a4, _b2;
      (_a4 = this.observers.find((t) => t.shouldFetchOnWindowFocus())) == null ? void 0 : _a4.refetch({ cancelRefetch: false }), (_b2 = __privateGet(this, _r)) == null ? void 0 : _b2.continue();
    }
    onOnline() {
      var _a4, _b2;
      (_a4 = this.observers.find((t) => t.shouldFetchOnReconnect())) == null ? void 0 : _a4.refetch({ cancelRefetch: false }), (_b2 = __privateGet(this, _r)) == null ? void 0 : _b2.continue();
    }
    addObserver(e) {
      this.observers.includes(e) || (this.observers.push(e), this.clearGcTimeout(), __privateGet(this, _n3).notify({ type: "observerAdded", query: this, observer: e }));
    }
    removeObserver(e) {
      this.observers.includes(e) && (this.observers = this.observers.filter((t) => t !== e), this.observers.length || (__privateGet(this, _r) && (__privateGet(this, _i2) ? __privateGet(this, _r).cancel({ revert: true }) : __privateGet(this, _r).cancelRetry()), this.scheduleGc()), __privateGet(this, _n3).notify({ type: "observerRemoved", query: this, observer: e }));
    }
    getObserversCount() {
      return this.observers.length;
    }
    invalidate() {
      this.state.isInvalidated || __privateMethod(this, _Cj_instances, a_fn).call(this, { type: "invalidate" });
    }
    async fetch(e, t) {
      var _a4, _b2, _c3, _d3, _e13, _f2, _g2, _h4, _i6, _j3, _k3, _l3;
      if (this.state.fetchStatus !== "idle" && ((_a4 = __privateGet(this, _r)) == null ? void 0 : _a4.status()) !== "rejected") {
        if (this.state.data !== void 0 && (t == null ? void 0 : t.cancelRefetch)) this.cancel({ silent: true });
        else if (__privateGet(this, _r)) return __privateGet(this, _r).continueRetry(), __privateGet(this, _r).promise;
      }
      if (e && this.setOptions(e), !this.options.queryFn) {
        const f = this.observers.find((p) => p.options.queryFn);
        f && this.setOptions(f.options);
      }
      const r = new AbortController(), a = (f) => {
        Object.defineProperty(f, "signal", { enumerable: true, get: () => (__privateSet(this, _i2, true), r.signal) });
      }, s = () => {
        const f = Mx(this.options, t), m = (() => {
          const v = { client: __privateGet(this, _o2), queryKey: this.queryKey, meta: this.meta };
          return a(v), v;
        })();
        return __privateSet(this, _i2, false), this.options.persister ? this.options.persister(f, m, this) : f(m);
      }, u = (() => {
        const f = { fetchOptions: t, options: this.options, queryKey: this.queryKey, client: __privateGet(this, _o2), state: this.state, fetchFn: s };
        return a(f), f;
      })();
      (_b2 = this.options.behavior) == null ? void 0 : _b2.onFetch(u, this), __privateSet(this, _t4, this.state), (this.state.fetchStatus === "idle" || this.state.fetchMeta !== ((_c3 = u.fetchOptions) == null ? void 0 : _c3.meta)) && __privateMethod(this, _Cj_instances, a_fn).call(this, { type: "fetch", meta: (_d3 = u.fetchOptions) == null ? void 0 : _d3.meta }), __privateSet(this, _r, Dx({ initialPromise: t == null ? void 0 : t.initialPromise, fn: u.fetchFn, onCancel: (f) => {
        f instanceof pp && f.revert && this.setState({ ...__privateGet(this, _t4), fetchStatus: "idle" }), r.abort();
      }, onFail: (f, p) => {
        __privateMethod(this, _Cj_instances, a_fn).call(this, { type: "failed", failureCount: f, error: p });
      }, onPause: () => {
        __privateMethod(this, _Cj_instances, a_fn).call(this, { type: "pause" });
      }, onContinue: () => {
        __privateMethod(this, _Cj_instances, a_fn).call(this, { type: "continue" });
      }, retry: u.options.retry, retryDelay: u.options.retryDelay, networkMode: u.options.networkMode, canRun: () => true }));
      try {
        const f = await __privateGet(this, _r).start();
        if (f === void 0) throw new Error(`${this.queryHash} data is undefined`);
        return this.setData(f), (_f2 = (_e13 = __privateGet(this, _n3).config).onSuccess) == null ? void 0 : _f2.call(_e13, f, this), (_h4 = (_g2 = __privateGet(this, _n3).config).onSettled) == null ? void 0 : _h4.call(_g2, f, this.state.error, this), f;
      } catch (f) {
        if (f instanceof pp) {
          if (f.silent) return __privateGet(this, _r).promise;
          if (f.revert) {
            if (this.state.data === void 0) throw f;
            return this.state.data;
          }
        }
        throw __privateMethod(this, _Cj_instances, a_fn).call(this, { type: "error", error: f }), (_j3 = (_i6 = __privateGet(this, _n3).config).onError) == null ? void 0 : _j3.call(_i6, f, this), (_l3 = (_k3 = __privateGet(this, _n3).config).onSettled) == null ? void 0 : _l3.call(_k3, this.state.data, f, this), f;
      } finally {
        this.scheduleGc();
      }
    }
  }, _e7 = new WeakMap(), _t4 = new WeakMap(), _n3 = new WeakMap(), _o2 = new WeakMap(), _r = new WeakMap(), _s = new WeakMap(), _i2 = new WeakMap(), _Cj_instances = new WeakSet(), a_fn = function(e) {
    const t = (r) => {
      var _a4;
      switch (e.type) {
        case "failed":
          return { ...r, fetchFailureCount: e.failureCount, fetchFailureReason: e.error };
        case "pause":
          return { ...r, fetchStatus: "paused" };
        case "continue":
          return { ...r, fetchStatus: "fetching" };
        case "fetch":
          return { ...r, ...kx(r.data, this.options), fetchMeta: (_a4 = e.meta) != null ? _a4 : null };
        case "success":
          const a = { ...r, ...ew(e.data, e.dataUpdatedAt), dataUpdateCount: r.dataUpdateCount + 1, ...!e.manual && { fetchStatus: "idle", fetchFailureCount: 0, fetchFailureReason: null } };
          return __privateSet(this, _t4, e.manual ? a : void 0), a;
        case "error":
          const s = e.error;
          return { ...r, error: s, errorUpdateCount: r.errorUpdateCount + 1, errorUpdatedAt: Date.now(), fetchFailureCount: r.fetchFailureCount + 1, fetchFailureReason: s, fetchStatus: "idle", status: "error", isInvalidated: true };
        case "invalidate":
          return { ...r, isInvalidated: true };
        case "setState":
          return { ...r, ...e.state };
      }
    };
    this.state = t(this.state), zt.batch(() => {
      this.observers.forEach((r) => {
        r.onQueryUpdate();
      }), __privateGet(this, _n3).notify({ query: this, type: "updated", action: e });
    });
  }, _g);
  function kx(e, t) {
    return { fetchFailureCount: 0, fetchFailureReason: null, fetchStatus: zx(t.networkMode) ? "fetching" : "paused", ...e === void 0 && { error: null, status: "pending" } };
  }
  function ew(e, t) {
    return { data: e, dataUpdatedAt: t != null ? t : Date.now(), error: null, isInvalidated: false, status: "success" };
  }
  function tw(e) {
    const t = typeof e.initialData == "function" ? e.initialData() : e.initialData, r = t !== void 0, a = r ? typeof e.initialDataUpdatedAt == "function" ? e.initialDataUpdatedAt() : e.initialDataUpdatedAt : 0;
    return { data: t, dataUpdateCount: 0, dataUpdatedAt: r ? a != null ? a : Date.now() : 0, error: null, errorUpdateCount: 0, errorUpdatedAt: 0, fetchFailureCount: 0, fetchFailureReason: null, fetchMeta: null, isInvalidated: false, status: r ? "success" : "pending", fetchStatus: "idle" };
  }
  var Tj = (_h3 = class extends sl {
    constructor(e, t) {
      super();
      __privateAdd(this, _Tj_instances);
      __privateAdd(this, _e8);
      __privateAdd(this, _t5);
      __privateAdd(this, _n4);
      __privateAdd(this, _o3);
      __privateAdd(this, _r2);
      __privateAdd(this, _s2);
      __privateAdd(this, _i3);
      __privateAdd(this, _a2);
      __privateAdd(this, _m2);
      __privateAdd(this, _d2);
      __privateAdd(this, _h2);
      __privateAdd(this, _c2);
      __privateAdd(this, _u2);
      __privateAdd(this, _l);
      __privateAdd(this, _p2, /* @__PURE__ */ new Set());
      this.options = t, __privateSet(this, _e8, e), __privateSet(this, _a2, null), __privateSet(this, _i3, hp()), this.bindMethods(), this.setOptions(t);
    }
    bindMethods() {
      this.refetch = this.refetch.bind(this);
    }
    onSubscribe() {
      this.listeners.size === 1 && (__privateGet(this, _t5).addObserver(this), nw(__privateGet(this, _t5), this.options) ? __privateMethod(this, _Tj_instances, f_fn).call(this) : this.updateResult(), __privateMethod(this, _Tj_instances, b_fn).call(this));
    }
    onUnsubscribe() {
      this.hasListeners() || this.destroy();
    }
    shouldFetchOnReconnect() {
      return mp(__privateGet(this, _t5), this.options, this.options.refetchOnReconnect);
    }
    shouldFetchOnWindowFocus() {
      return mp(__privateGet(this, _t5), this.options, this.options.refetchOnWindowFocus);
    }
    destroy() {
      this.listeners = /* @__PURE__ */ new Set(), __privateMethod(this, _Tj_instances, w_fn).call(this), __privateMethod(this, _Tj_instances, S_fn).call(this), __privateGet(this, _t5).removeObserver(this);
    }
    setOptions(e) {
      const t = this.options, r = __privateGet(this, _t5);
      if (this.options = __privateGet(this, _e8).defaultQueryOptions(e), this.options.enabled !== void 0 && typeof this.options.enabled != "boolean" && typeof this.options.enabled != "function" && typeof Nn(this.options.enabled, __privateGet(this, _t5)) != "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
      __privateMethod(this, _Tj_instances, x_fn).call(this), __privateGet(this, _t5).setOptions(this.options), t._defaulted && !up(this.options, t) && __privateGet(this, _e8).getQueryCache().notify({ type: "observerOptionsUpdated", query: __privateGet(this, _t5), observer: this });
      const a = this.hasListeners();
      a && rw(__privateGet(this, _t5), r, this.options, t) && __privateMethod(this, _Tj_instances, f_fn).call(this), this.updateResult(), a && (__privateGet(this, _t5) !== r || Nn(this.options.enabled, __privateGet(this, _t5)) !== Nn(t.enabled, __privateGet(this, _t5)) || Ao(this.options.staleTime, __privateGet(this, _t5)) !== Ao(t.staleTime, __privateGet(this, _t5))) && __privateMethod(this, _Tj_instances, g_fn).call(this);
      const s = __privateMethod(this, _Tj_instances, v_fn).call(this);
      a && (__privateGet(this, _t5) !== r || Nn(this.options.enabled, __privateGet(this, _t5)) !== Nn(t.enabled, __privateGet(this, _t5)) || s !== __privateGet(this, _l)) && __privateMethod(this, _Tj_instances, y_fn).call(this, s);
    }
    getOptimisticResult(e) {
      const t = __privateGet(this, _e8).getQueryCache().build(__privateGet(this, _e8), e), r = this.createResult(t, e);
      return Rj(this, r) && (__privateSet(this, _o3, r), __privateSet(this, _s2, this.options), __privateSet(this, _r2, __privateGet(this, _t5).state)), r;
    }
    getCurrentResult() {
      return __privateGet(this, _o3);
    }
    trackResult(e, t) {
      return new Proxy(e, { get: (r, a) => (this.trackProp(a), t == null ? void 0 : t(a), a === "promise" && (this.trackProp("data"), !this.options.experimental_prefetchInRender && __privateGet(this, _i3).status === "pending" && __privateGet(this, _i3).reject(new Error("experimental_prefetchInRender feature flag is not enabled"))), Reflect.get(r, a)) });
    }
    trackProp(e) {
      __privateGet(this, _p2).add(e);
    }
    getCurrentQuery() {
      return __privateGet(this, _t5);
    }
    refetch({ ...e } = {}) {
      return this.fetch({ ...e });
    }
    fetchOptimistic(e) {
      const t = __privateGet(this, _e8).defaultQueryOptions(e), r = __privateGet(this, _e8).getQueryCache().build(__privateGet(this, _e8), t);
      return r.fetch().then(() => this.createResult(r, t));
    }
    fetch(e) {
      var _a4;
      return __privateMethod(this, _Tj_instances, f_fn).call(this, { ...e, cancelRefetch: (_a4 = e.cancelRefetch) != null ? _a4 : true }).then(() => (this.updateResult(), __privateGet(this, _o3)));
    }
    createResult(e, t) {
      var _a4;
      const r = __privateGet(this, _t5), a = this.options, s = __privateGet(this, _o3), l = __privateGet(this, _r2), u = __privateGet(this, _s2), p = e !== r ? e.state : __privateGet(this, _n4), { state: m } = e;
      let v = { ...m }, g = false, S;
      if (t._optimisticResults) {
        const $ = this.hasListeners(), re = !$ && nw(e, t), G = $ && rw(e, r, t, a);
        (re || G) && (v = { ...v, ...kx(m.data, e.options) }), t._optimisticResults === "isRestoring" && (v.fetchStatus = "idle");
      }
      let { error: _, errorUpdatedAt: x, status: E } = v;
      S = v.data;
      let C = false;
      if (t.placeholderData !== void 0 && S === void 0 && E === "pending") {
        let $;
        (s == null ? void 0 : s.isPlaceholderData) && t.placeholderData === (u == null ? void 0 : u.placeholderData) ? ($ = s.data, C = true) : $ = typeof t.placeholderData == "function" ? t.placeholderData((_a4 = __privateGet(this, _h2)) == null ? void 0 : _a4.state.data, __privateGet(this, _h2)) : t.placeholderData, $ !== void 0 && (E = "success", S = dp(s == null ? void 0 : s.data, $, t), g = true);
      }
      if (t.select && S !== void 0 && !C) if (s && S === (l == null ? void 0 : l.data) && t.select === __privateGet(this, _m2)) S = __privateGet(this, _d2);
      else try {
        __privateSet(this, _m2, t.select), S = t.select(S), S = dp(s == null ? void 0 : s.data, S, t), __privateSet(this, _d2, S), __privateSet(this, _a2, null);
      } catch ($) {
        __privateSet(this, _a2, $);
      }
      __privateGet(this, _a2) && (_ = __privateGet(this, _a2), S = __privateGet(this, _d2), x = Date.now(), E = "error");
      const T = v.fetchStatus === "fetching", R = E === "pending", O = E === "error", D = R && T, P = S !== void 0, k = { status: E, fetchStatus: v.fetchStatus, isPending: R, isSuccess: E === "success", isError: O, isInitialLoading: D, isLoading: D, data: S, dataUpdatedAt: v.dataUpdatedAt, error: _, errorUpdatedAt: x, failureCount: v.fetchFailureCount, failureReason: v.fetchFailureReason, errorUpdateCount: v.errorUpdateCount, isFetched: v.dataUpdateCount > 0 || v.errorUpdateCount > 0, isFetchedAfterMount: v.dataUpdateCount > p.dataUpdateCount || v.errorUpdateCount > p.errorUpdateCount, isFetching: T, isRefetching: T && !R, isLoadingError: O && !P, isPaused: v.fetchStatus === "paused", isPlaceholderData: g, isRefetchError: O && P, isStale: dm(e, t), refetch: this.refetch, promise: __privateGet(this, _i3), isEnabled: Nn(t.enabled, e) !== false };
      if (this.options.experimental_prefetchInRender) {
        const $ = k.data !== void 0, re = k.status === "error" && !$, G = (le) => {
          re ? le.reject(k.error) : $ && le.resolve(k.data);
        }, ae = () => {
          const le = __privateSet(this, _i3, k.promise = hp());
          G(le);
        }, se = __privateGet(this, _i3);
        switch (se.status) {
          case "pending":
            e.queryHash === r.queryHash && G(se);
            break;
          case "fulfilled":
            (re || k.data !== se.value) && ae();
            break;
          case "rejected":
            (!re || k.error !== se.reason) && ae();
            break;
        }
      }
      return k;
    }
    updateResult() {
      const e = __privateGet(this, _o3), t = this.createResult(__privateGet(this, _t5), this.options);
      if (__privateSet(this, _r2, __privateGet(this, _t5).state), __privateSet(this, _s2, this.options), __privateGet(this, _r2).data !== void 0 && __privateSet(this, _h2, __privateGet(this, _t5)), up(t, e)) return;
      __privateSet(this, _o3, t);
      const r = () => {
        if (!e) return true;
        const { notifyOnChangeProps: a } = this.options, s = typeof a == "function" ? a() : a;
        if (s === "all" || !s && !__privateGet(this, _p2).size) return true;
        const l = new Set(s != null ? s : __privateGet(this, _p2));
        return this.options.throwOnError && l.add("error"), Object.keys(__privateGet(this, _o3)).some((u) => {
          const f = u;
          return __privateGet(this, _o3)[f] !== e[f] && l.has(f);
        });
      };
      __privateMethod(this, _Tj_instances, __fn).call(this, { listeners: r() });
    }
    onQueryUpdate() {
      this.updateResult(), this.hasListeners() && __privateMethod(this, _Tj_instances, b_fn).call(this);
    }
  }, _e8 = new WeakMap(), _t5 = new WeakMap(), _n4 = new WeakMap(), _o3 = new WeakMap(), _r2 = new WeakMap(), _s2 = new WeakMap(), _i3 = new WeakMap(), _a2 = new WeakMap(), _m2 = new WeakMap(), _d2 = new WeakMap(), _h2 = new WeakMap(), _c2 = new WeakMap(), _u2 = new WeakMap(), _l = new WeakMap(), _p2 = new WeakMap(), _Tj_instances = new WeakSet(), f_fn = function(e) {
    __privateMethod(this, _Tj_instances, x_fn).call(this);
    let t = __privateGet(this, _t5).fetch(this.options, e);
    return (e == null ? void 0 : e.throwOnError) || (t = t.catch(nn)), t;
  }, g_fn = function() {
    __privateMethod(this, _Tj_instances, w_fn).call(this);
    const e = Ao(this.options.staleTime, __privateGet(this, _t5));
    if (fa || __privateGet(this, _o3).isStale || !cp(e)) return;
    const r = Ox(__privateGet(this, _o3).dataUpdatedAt, e) + 1;
    __privateSet(this, _c2, aa.setTimeout(() => {
      __privateGet(this, _o3).isStale || this.updateResult();
    }, r));
  }, v_fn = function() {
    var _a4;
    return (_a4 = typeof this.options.refetchInterval == "function" ? this.options.refetchInterval(__privateGet(this, _t5)) : this.options.refetchInterval) != null ? _a4 : false;
  }, y_fn = function(e) {
    __privateMethod(this, _Tj_instances, S_fn).call(this), __privateSet(this, _l, e), !(fa || Nn(this.options.enabled, __privateGet(this, _t5)) === false || !cp(__privateGet(this, _l)) || __privateGet(this, _l) === 0) && __privateSet(this, _u2, aa.setInterval(() => {
      (this.options.refetchIntervalInBackground || fm.isFocused()) && __privateMethod(this, _Tj_instances, f_fn).call(this);
    }, __privateGet(this, _l)));
  }, b_fn = function() {
    __privateMethod(this, _Tj_instances, g_fn).call(this), __privateMethod(this, _Tj_instances, y_fn).call(this, __privateMethod(this, _Tj_instances, v_fn).call(this));
  }, w_fn = function() {
    __privateGet(this, _c2) && (aa.clearTimeout(__privateGet(this, _c2)), __privateSet(this, _c2, void 0));
  }, S_fn = function() {
    __privateGet(this, _u2) && (aa.clearInterval(__privateGet(this, _u2)), __privateSet(this, _u2, void 0));
  }, x_fn = function() {
    const e = __privateGet(this, _e8).getQueryCache().build(__privateGet(this, _e8), this.options);
    if (e === __privateGet(this, _t5)) return;
    const t = __privateGet(this, _t5);
    __privateSet(this, _t5, e), __privateSet(this, _n4, e.state), this.hasListeners() && (t == null ? void 0 : t.removeObserver(this), e.addObserver(this));
  }, __fn = function(e) {
    zt.batch(() => {
      e.listeners && this.listeners.forEach((t) => {
        t(__privateGet(this, _o3));
      }), __privateGet(this, _e8).getQueryCache().notify({ query: __privateGet(this, _t5), type: "observerResultsUpdated" });
    });
  }, _h3);
  function Oj(e, t) {
    return Nn(t.enabled, e) !== false && e.state.data === void 0 && !(e.state.status === "error" && t.retryOnMount === false);
  }
  function nw(e, t) {
    return Oj(e, t) || e.state.data !== void 0 && mp(e, t, t.refetchOnMount);
  }
  function mp(e, t, r) {
    if (Nn(t.enabled, e) !== false && Ao(t.staleTime, e) !== "static") {
      const a = typeof r == "function" ? r(e) : r;
      return a === "always" || a !== false && dm(e, t);
    }
    return false;
  }
  function rw(e, t, r, a) {
    return (e !== t || Nn(a.enabled, e) === false) && (!r.suspense || e.state.status !== "error") && dm(e, r);
  }
  function dm(e, t) {
    return Nn(t.enabled, e) !== false && e.isStaleByTime(Ao(t.staleTime, e));
  }
  function Rj(e, t) {
    return !up(e.getCurrentResult(), t);
  }
  function ow(e) {
    return { onFetch: (t, r) => {
      var _a4, _b2, _c3, _d3, _e13;
      const a = t.options, s = (_c3 = (_b2 = (_a4 = t.fetchOptions) == null ? void 0 : _a4.meta) == null ? void 0 : _b2.fetchMore) == null ? void 0 : _c3.direction, l = ((_d3 = t.state.data) == null ? void 0 : _d3.pages) || [], u = ((_e13 = t.state.data) == null ? void 0 : _e13.pageParams) || [];
      let f = { pages: [], pageParams: [] }, p = 0;
      const m = async () => {
        var _a5;
        let v = false;
        const g = (x) => {
          wj(x, () => t.signal, () => v = true);
        }, S = Mx(t.options, t.fetchOptions), _ = async (x, E, C) => {
          if (v) return Promise.reject();
          if (E == null && x.pages.length) return Promise.resolve(x);
          const R = (() => {
            const L = { client: t.client, queryKey: t.queryKey, pageParam: E, direction: C ? "backward" : "forward", meta: t.options.meta };
            return g(L), L;
          })(), O = await S(R), { maxPages: D } = t.options, P = C ? bj : yj;
          return { pages: P(x.pages, O, D), pageParams: P(x.pageParams, E, D) };
        };
        if (s && l.length) {
          const x = s === "backward", E = x ? Mj : aw, C = { pages: l, pageParams: u }, T = E(a, C);
          f = await _(C, T, x);
        } else {
          const x = e != null ? e : l.length;
          do {
            const E = p === 0 ? (_a5 = u[0]) != null ? _a5 : a.initialPageParam : aw(a, f);
            if (p > 0 && E == null) break;
            f = await _(f, E), p++;
          } while (p < x);
        }
        return f;
      };
      t.options.persister ? t.fetchFn = () => {
        var _a5, _b3;
        return (_b3 = (_a5 = t.options).persister) == null ? void 0 : _b3.call(_a5, m, { client: t.client, queryKey: t.queryKey, meta: t.options.meta, signal: t.signal }, r);
      } : t.fetchFn = m;
    } };
  }
  function aw(e, { pages: t, pageParams: r }) {
    const a = t.length - 1;
    return t.length > 0 ? e.getNextPageParam(t[a], t, r[a], r) : void 0;
  }
  function Mj(e, { pages: t, pageParams: r }) {
    var _a4;
    return t.length > 0 ? (_a4 = e.getPreviousPageParam) == null ? void 0 : _a4.call(e, t[0], t, r[0], r) : void 0;
  }
  var Nj = (_i4 = class extends jx {
    constructor(e) {
      super();
      __privateAdd(this, _Nj_instances);
      __privateAdd(this, _e9);
      __privateAdd(this, _t6);
      __privateAdd(this, _n5);
      __privateAdd(this, _o4);
      __privateSet(this, _e9, e.client), this.mutationId = e.mutationId, __privateSet(this, _n5, e.mutationCache), __privateSet(this, _t6, []), this.state = e.state || zj(), this.setOptions(e.options), this.scheduleGc();
    }
    setOptions(e) {
      this.options = e, this.updateGcTime(this.options.gcTime);
    }
    get meta() {
      return this.options.meta;
    }
    addObserver(e) {
      __privateGet(this, _t6).includes(e) || (__privateGet(this, _t6).push(e), this.clearGcTimeout(), __privateGet(this, _n5).notify({ type: "observerAdded", mutation: this, observer: e }));
    }
    removeObserver(e) {
      __privateSet(this, _t6, __privateGet(this, _t6).filter((t) => t !== e)), this.scheduleGc(), __privateGet(this, _n5).notify({ type: "observerRemoved", mutation: this, observer: e });
    }
    optionalRemove() {
      __privateGet(this, _t6).length || (this.state.status === "pending" ? this.scheduleGc() : __privateGet(this, _n5).remove(this));
    }
    continue() {
      var _a4, _b2;
      return (_b2 = (_a4 = __privateGet(this, _o4)) == null ? void 0 : _a4.continue()) != null ? _b2 : this.execute(this.state.variables);
    }
    async execute(e) {
      var _a4, _b2, _c3, _d3, _e13, _f2, _g2, _h4, _i6, _j3, _k3, _l3, _m3, _n8, _o6, _p3, _q, _r4, _s4;
      const t = () => {
        __privateMethod(this, _Nj_instances, r_fn).call(this, { type: "continue" });
      }, r = { client: __privateGet(this, _e9), meta: this.options.meta, mutationKey: this.options.mutationKey };
      __privateSet(this, _o4, Dx({ fn: () => this.options.mutationFn ? this.options.mutationFn(e, r) : Promise.reject(new Error("No mutationFn found")), onFail: (l, u) => {
        __privateMethod(this, _Nj_instances, r_fn).call(this, { type: "failed", failureCount: l, error: u });
      }, onPause: () => {
        __privateMethod(this, _Nj_instances, r_fn).call(this, { type: "pause" });
      }, onContinue: t, retry: (_a4 = this.options.retry) != null ? _a4 : 0, retryDelay: this.options.retryDelay, networkMode: this.options.networkMode, canRun: () => __privateGet(this, _n5).canRun(this) }));
      const a = this.state.status === "pending", s = !__privateGet(this, _o4).canStart();
      try {
        if (a) t();
        else {
          __privateMethod(this, _Nj_instances, r_fn).call(this, { type: "pending", variables: e, isPaused: s }), __privateGet(this, _n5).config.onMutate && await __privateGet(this, _n5).config.onMutate(e, this, r);
          const u = await ((_c3 = (_b2 = this.options).onMutate) == null ? void 0 : _c3.call(_b2, e, r));
          u !== this.state.context && __privateMethod(this, _Nj_instances, r_fn).call(this, { type: "pending", context: u, variables: e, isPaused: s });
        }
        const l = await __privateGet(this, _o4).start();
        return await ((_e13 = (_d3 = __privateGet(this, _n5).config).onSuccess) == null ? void 0 : _e13.call(_d3, l, e, this.state.context, this, r)), await ((_g2 = (_f2 = this.options).onSuccess) == null ? void 0 : _g2.call(_f2, l, e, this.state.context, r)), await ((_i6 = (_h4 = __privateGet(this, _n5).config).onSettled) == null ? void 0 : _i6.call(_h4, l, null, this.state.variables, this.state.context, this, r)), await ((_k3 = (_j3 = this.options).onSettled) == null ? void 0 : _k3.call(_j3, l, null, e, this.state.context, r)), __privateMethod(this, _Nj_instances, r_fn).call(this, { type: "success", data: l }), l;
      } catch (l) {
        try {
          await ((_m3 = (_l3 = __privateGet(this, _n5).config).onError) == null ? void 0 : _m3.call(_l3, l, e, this.state.context, this, r));
        } catch (u) {
          Promise.reject(u);
        }
        try {
          await ((_o6 = (_n8 = this.options).onError) == null ? void 0 : _o6.call(_n8, l, e, this.state.context, r));
        } catch (u) {
          Promise.reject(u);
        }
        try {
          await ((_q = (_p3 = __privateGet(this, _n5).config).onSettled) == null ? void 0 : _q.call(_p3, void 0, l, this.state.variables, this.state.context, this, r));
        } catch (u) {
          Promise.reject(u);
        }
        try {
          await ((_s4 = (_r4 = this.options).onSettled) == null ? void 0 : _s4.call(_r4, void 0, l, e, this.state.context, r));
        } catch (u) {
          Promise.reject(u);
        }
        throw __privateMethod(this, _Nj_instances, r_fn).call(this, { type: "error", error: l }), l;
      } finally {
        __privateGet(this, _n5).runNext(this);
      }
    }
  }, _e9 = new WeakMap(), _t6 = new WeakMap(), _n5 = new WeakMap(), _o4 = new WeakMap(), _Nj_instances = new WeakSet(), r_fn = function(e) {
    const t = (r) => {
      switch (e.type) {
        case "failed":
          return { ...r, failureCount: e.failureCount, failureReason: e.error };
        case "pause":
          return { ...r, isPaused: true };
        case "continue":
          return { ...r, isPaused: false };
        case "pending":
          return { ...r, context: e.context, data: void 0, failureCount: 0, failureReason: null, error: null, isPaused: e.isPaused, status: "pending", variables: e.variables, submittedAt: Date.now() };
        case "success":
          return { ...r, data: e.data, failureCount: 0, failureReason: null, error: null, status: "success", isPaused: false };
        case "error":
          return { ...r, data: void 0, error: e.error, failureCount: r.failureCount + 1, failureReason: e.error, isPaused: false, status: "error" };
      }
    };
    this.state = t(this.state), zt.batch(() => {
      __privateGet(this, _t6).forEach((r) => {
        r.onMutationUpdate(e);
      }), __privateGet(this, _n5).notify({ mutation: this, type: "updated", action: e });
    });
  }, _i4);
  function zj() {
    return { context: void 0, data: void 0, error: null, failureCount: 0, failureReason: null, isPaused: false, status: "idle", variables: void 0, submittedAt: 0 };
  }
  var Dj = (_j2 = class extends sl {
    constructor(e = {}) {
      super();
      __privateAdd(this, _e10);
      __privateAdd(this, _t7);
      __privateAdd(this, _n6);
      this.config = e, __privateSet(this, _e10, /* @__PURE__ */ new Set()), __privateSet(this, _t7, /* @__PURE__ */ new Map()), __privateSet(this, _n6, 0);
    }
    build(e, t, r) {
      const a = new Nj({ client: e, mutationCache: this, mutationId: ++__privateWrapper(this, _n6)._, options: e.defaultMutationOptions(t), state: r });
      return this.add(a), a;
    }
    add(e) {
      __privateGet(this, _e10).add(e);
      const t = Nc(e);
      if (typeof t == "string") {
        const r = __privateGet(this, _t7).get(t);
        r ? r.push(e) : __privateGet(this, _t7).set(t, [e]);
      }
      this.notify({ type: "added", mutation: e });
    }
    remove(e) {
      if (__privateGet(this, _e10).delete(e)) {
        const t = Nc(e);
        if (typeof t == "string") {
          const r = __privateGet(this, _t7).get(t);
          if (r) if (r.length > 1) {
            const a = r.indexOf(e);
            a !== -1 && r.splice(a, 1);
          } else r[0] === e && __privateGet(this, _t7).delete(t);
        }
      }
      this.notify({ type: "removed", mutation: e });
    }
    canRun(e) {
      var _a4;
      const t = Nc(e);
      if (typeof t == "string") {
        const a = (_a4 = __privateGet(this, _t7).get(t)) == null ? void 0 : _a4.find((s) => s.state.status === "pending");
        return !a || a === e;
      } else return true;
    }
    runNext(e) {
      var _a4, _b2, _c3;
      const t = Nc(e);
      return typeof t == "string" ? (_c3 = (_b2 = (_a4 = __privateGet(this, _t7).get(t)) == null ? void 0 : _a4.find((a) => a !== e && a.state.isPaused)) == null ? void 0 : _b2.continue()) != null ? _c3 : Promise.resolve() : Promise.resolve();
    }
    clear() {
      zt.batch(() => {
        __privateGet(this, _e10).forEach((e) => {
          this.notify({ type: "removed", mutation: e });
        }), __privateGet(this, _e10).clear(), __privateGet(this, _t7).clear();
      });
    }
    getAll() {
      return Array.from(__privateGet(this, _e10));
    }
    find(e) {
      const t = { exact: true, ...e };
      return this.getAll().find((r) => K0(t, r));
    }
    findAll(e = {}) {
      return this.getAll().filter((t) => K0(e, t));
    }
    notify(e) {
      zt.batch(() => {
        this.listeners.forEach((t) => {
          t(e);
        });
      });
    }
    resumePausedMutations() {
      const e = this.getAll().filter((t) => t.state.isPaused);
      return zt.batch(() => Promise.all(e.map((t) => t.continue().catch(nn))));
    }
  }, _e10 = new WeakMap(), _t7 = new WeakMap(), _n6 = new WeakMap(), _j2);
  function Nc(e) {
    var _a4;
    return (_a4 = e.options.scope) == null ? void 0 : _a4.id;
  }
  var jj = (_k2 = class extends sl {
    constructor(e = {}) {
      super();
      __privateAdd(this, _e11);
      this.config = e, __privateSet(this, _e11, /* @__PURE__ */ new Map());
    }
    build(e, t, r) {
      var _a4;
      const a = t.queryKey, s = (_a4 = t.queryHash) != null ? _a4 : cm(a, t);
      let l = this.get(s);
      return l || (l = new Cj({ client: e, queryKey: a, queryHash: s, options: e.defaultQueryOptions(t), state: r, defaultOptions: e.getQueryDefaults(a) }), this.add(l)), l;
    }
    add(e) {
      __privateGet(this, _e11).has(e.queryHash) || (__privateGet(this, _e11).set(e.queryHash, e), this.notify({ type: "added", query: e }));
    }
    remove(e) {
      const t = __privateGet(this, _e11).get(e.queryHash);
      t && (e.destroy(), t === e && __privateGet(this, _e11).delete(e.queryHash), this.notify({ type: "removed", query: e }));
    }
    clear() {
      zt.batch(() => {
        this.getAll().forEach((e) => {
          this.remove(e);
        });
      });
    }
    get(e) {
      return __privateGet(this, _e11).get(e);
    }
    getAll() {
      return [...__privateGet(this, _e11).values()];
    }
    find(e) {
      const t = { exact: true, ...e };
      return this.getAll().find((r) => G0(t, r));
    }
    findAll(e = {}) {
      const t = this.getAll();
      return Object.keys(e).length > 0 ? t.filter((r) => G0(e, r)) : t;
    }
    notify(e) {
      zt.batch(() => {
        this.listeners.forEach((t) => {
          t(e);
        });
      });
    }
    onFocus() {
      zt.batch(() => {
        this.getAll().forEach((e) => {
          e.onFocus();
        });
      });
    }
    onOnline() {
      zt.batch(() => {
        this.getAll().forEach((e) => {
          e.onOnline();
        });
      });
    }
  }, _e11 = new WeakMap(), _k2), kj = (_l2 = class {
    constructor(e = {}) {
      __privateAdd(this, _e12);
      __privateAdd(this, _t8);
      __privateAdd(this, _n7);
      __privateAdd(this, _o5);
      __privateAdd(this, _r3);
      __privateAdd(this, _s3);
      __privateAdd(this, _i5);
      __privateAdd(this, _a3);
      __privateSet(this, _e12, e.queryCache || new jj()), __privateSet(this, _t8, e.mutationCache || new Dj()), __privateSet(this, _n7, e.defaultOptions || {}), __privateSet(this, _o5, /* @__PURE__ */ new Map()), __privateSet(this, _r3, /* @__PURE__ */ new Map()), __privateSet(this, _s3, 0);
    }
    mount() {
      __privateWrapper(this, _s3)._++, __privateGet(this, _s3) === 1 && (__privateSet(this, _i5, fm.subscribe(async (e) => {
        e && (await this.resumePausedMutations(), __privateGet(this, _e12).onFocus());
      })), __privateSet(this, _a3, ou.subscribe(async (e) => {
        e && (await this.resumePausedMutations(), __privateGet(this, _e12).onOnline());
      })));
    }
    unmount() {
      var _a4, _b2;
      __privateWrapper(this, _s3)._--, __privateGet(this, _s3) === 0 && ((_a4 = __privateGet(this, _i5)) == null ? void 0 : _a4.call(this), __privateSet(this, _i5, void 0), (_b2 = __privateGet(this, _a3)) == null ? void 0 : _b2.call(this), __privateSet(this, _a3, void 0));
    }
    isFetching(e) {
      return __privateGet(this, _e12).findAll({ ...e, fetchStatus: "fetching" }).length;
    }
    isMutating(e) {
      return __privateGet(this, _t8).findAll({ ...e, status: "pending" }).length;
    }
    getQueryData(e) {
      var _a4;
      const t = this.defaultQueryOptions({ queryKey: e });
      return (_a4 = __privateGet(this, _e12).get(t.queryHash)) == null ? void 0 : _a4.state.data;
    }
    ensureQueryData(e) {
      const t = this.defaultQueryOptions(e), r = __privateGet(this, _e12).build(this, t), a = r.state.data;
      return a === void 0 ? this.fetchQuery(e) : (e.revalidateIfStale && r.isStaleByTime(Ao(t.staleTime, r)) && this.prefetchQuery(t), Promise.resolve(a));
    }
    getQueriesData(e) {
      return __privateGet(this, _e12).findAll(e).map(({ queryKey: t, state: r }) => {
        const a = r.data;
        return [t, a];
      });
    }
    setQueryData(e, t, r) {
      var _a4;
      const a = this.defaultQueryOptions({ queryKey: e }), l = (_a4 = __privateGet(this, _e12).get(a.queryHash)) == null ? void 0 : _a4.state.data, u = mj(t, l);
      if (u !== void 0) return __privateGet(this, _e12).build(this, a).setData(u, { ...r, manual: true });
    }
    setQueriesData(e, t, r) {
      return zt.batch(() => __privateGet(this, _e12).findAll(e).map(({ queryKey: a }) => [a, this.setQueryData(a, t, r)]));
    }
    getQueryState(e) {
      var _a4;
      const t = this.defaultQueryOptions({ queryKey: e });
      return (_a4 = __privateGet(this, _e12).get(t.queryHash)) == null ? void 0 : _a4.state;
    }
    removeQueries(e) {
      const t = __privateGet(this, _e12);
      zt.batch(() => {
        t.findAll(e).forEach((r) => {
          t.remove(r);
        });
      });
    }
    resetQueries(e, t) {
      const r = __privateGet(this, _e12);
      return zt.batch(() => (r.findAll(e).forEach((a) => {
        a.reset();
      }), this.refetchQueries({ type: "active", ...e }, t)));
    }
    cancelQueries(e, t = {}) {
      const r = { revert: true, ...t }, a = zt.batch(() => __privateGet(this, _e12).findAll(e).map((s) => s.cancel(r)));
      return Promise.all(a).then(nn).catch(nn);
    }
    invalidateQueries(e, t = {}) {
      return zt.batch(() => {
        var _a4, _b2;
        return __privateGet(this, _e12).findAll(e).forEach((r) => {
          r.invalidate();
        }), (e == null ? void 0 : e.refetchType) === "none" ? Promise.resolve() : this.refetchQueries({ ...e, type: (_b2 = (_a4 = e == null ? void 0 : e.refetchType) != null ? _a4 : e == null ? void 0 : e.type) != null ? _b2 : "active" }, t);
      });
    }
    refetchQueries(e, t = {}) {
      var _a4;
      const r = { ...t, cancelRefetch: (_a4 = t.cancelRefetch) != null ? _a4 : true }, a = zt.batch(() => __privateGet(this, _e12).findAll(e).filter((s) => !s.isDisabled() && !s.isStatic()).map((s) => {
        let l = s.fetch(void 0, r);
        return r.throwOnError || (l = l.catch(nn)), s.state.fetchStatus === "paused" ? Promise.resolve() : l;
      }));
      return Promise.all(a).then(nn);
    }
    fetchQuery(e) {
      const t = this.defaultQueryOptions(e);
      t.retry === void 0 && (t.retry = false);
      const r = __privateGet(this, _e12).build(this, t);
      return r.isStaleByTime(Ao(t.staleTime, r)) ? r.fetch(t) : Promise.resolve(r.state.data);
    }
    prefetchQuery(e) {
      return this.fetchQuery(e).then(nn).catch(nn);
    }
    fetchInfiniteQuery(e) {
      return e.behavior = ow(e.pages), this.fetchQuery(e);
    }
    prefetchInfiniteQuery(e) {
      return this.fetchInfiniteQuery(e).then(nn).catch(nn);
    }
    ensureInfiniteQueryData(e) {
      return e.behavior = ow(e.pages), this.ensureQueryData(e);
    }
    resumePausedMutations() {
      return ou.isOnline() ? __privateGet(this, _t8).resumePausedMutations() : Promise.resolve();
    }
    getQueryCache() {
      return __privateGet(this, _e12);
    }
    getMutationCache() {
      return __privateGet(this, _t8);
    }
    getDefaultOptions() {
      return __privateGet(this, _n7);
    }
    setDefaultOptions(e) {
      __privateSet(this, _n7, e);
    }
    setQueryDefaults(e, t) {
      __privateGet(this, _o5).set(Fs(e), { queryKey: e, defaultOptions: t });
    }
    getQueryDefaults(e) {
      const t = [...__privateGet(this, _o5).values()], r = {};
      return t.forEach((a) => {
        qs(e, a.queryKey) && Object.assign(r, a.defaultOptions);
      }), r;
    }
    setMutationDefaults(e, t) {
      __privateGet(this, _r3).set(Fs(e), { mutationKey: e, defaultOptions: t });
    }
    getMutationDefaults(e) {
      const t = [...__privateGet(this, _r3).values()], r = {};
      return t.forEach((a) => {
        qs(e, a.mutationKey) && Object.assign(r, a.defaultOptions);
      }), r;
    }
    defaultQueryOptions(e) {
      if (e._defaulted) return e;
      const t = { ...__privateGet(this, _n7).queries, ...this.getQueryDefaults(e.queryKey), ...e, _defaulted: true };
      return t.queryHash || (t.queryHash = cm(t.queryKey, t)), t.refetchOnReconnect === void 0 && (t.refetchOnReconnect = t.networkMode !== "always"), t.throwOnError === void 0 && (t.throwOnError = !!t.suspense), !t.networkMode && t.persister && (t.networkMode = "offlineFirst"), t.queryFn === um && (t.enabled = false), t;
    }
    defaultMutationOptions(e) {
      return (e == null ? void 0 : e._defaulted) ? e : { ...__privateGet(this, _n7).mutations, ...(e == null ? void 0 : e.mutationKey) && this.getMutationDefaults(e.mutationKey), ...e, _defaulted: true };
    }
    clear() {
      __privateGet(this, _e12).clear(), __privateGet(this, _t8).clear();
    }
  }, _e12 = new WeakMap(), _t8 = new WeakMap(), _n7 = new WeakMap(), _o5 = new WeakMap(), _r3 = new WeakMap(), _s3 = new WeakMap(), _i5 = new WeakMap(), _a3 = new WeakMap(), _l2), Px = y.createContext(void 0), Pj = (e) => {
    const t = y.useContext(Px);
    if (!t) throw new Error("No QueryClient set, use QueryClientProvider to set one");
    return t;
  }, Lj = ({ client: e, children: t }) => (y.useEffect(() => (e.mount(), () => {
    e.unmount();
  }), [e]), b.jsx(Px.Provider, { value: e, children: t })), Lx = y.createContext(false), Uj = () => y.useContext(Lx);
  Lx.Provider;
  function Bj() {
    let e = false;
    return { clearReset: () => {
      e = false;
    }, reset: () => {
      e = true;
    }, isReset: () => e };
  }
  var Ij = y.createContext(Bj()), Hj = () => y.useContext(Ij), $j = (e, t, r) => {
    const a = (r == null ? void 0 : r.state.error) && typeof e.throwOnError == "function" ? Nx(e.throwOnError, [r.state.error, r]) : e.throwOnError;
    (e.suspense || e.experimental_prefetchInRender || a) && (t.isReset() || (e.retryOnMount = false));
  }, Vj = (e) => {
    y.useEffect(() => {
      e.clearReset();
    }, [e]);
  }, Zj = ({ result: e, errorResetBoundary: t, throwOnError: r, query: a, suspense: s }) => e.isError && !t.isReset() && !e.isFetching && a && (s && e.data === void 0 || Nx(r, [e.error, a])), Fj = (e) => {
    if (e.suspense) {
      const r = (s) => s === "static" ? s : Math.max(s != null ? s : 1e3, 1e3), a = e.staleTime;
      e.staleTime = typeof a == "function" ? (...s) => r(a(...s)) : r(a), typeof e.gcTime == "number" && (e.gcTime = Math.max(e.gcTime, 1e3));
    }
  }, qj = (e, t) => e.isLoading && e.isFetching && !t, Yj = (e, t) => (e == null ? void 0 : e.suspense) && t.isPending, iw = (e, t, r) => t.fetchOptimistic(e).catch(() => {
    r.clearReset();
  });
  function Xj(e, t, r) {
    var _a4, _b2, _c3, _d3, _e13;
    const a = Uj(), s = Hj(), l = Pj(), u = l.defaultQueryOptions(e);
    (_b2 = (_a4 = l.getDefaultOptions().queries) == null ? void 0 : _a4._experimental_beforeQuery) == null ? void 0 : _b2.call(_a4, u);
    const f = l.getQueryCache().get(u.queryHash);
    u._optimisticResults = a ? "isRestoring" : "optimistic", Fj(u), $j(u, s, f), Vj(s);
    const p = !l.getQueryCache().get(u.queryHash), [m] = y.useState(() => new t(l, u)), v = m.getOptimisticResult(u), g = !a && e.subscribed !== false;
    if (y.useSyncExternalStore(y.useCallback((S) => {
      const _ = g ? m.subscribe(zt.batchCalls(S)) : nn;
      return m.updateResult(), _;
    }, [m, g]), () => m.getCurrentResult(), () => m.getCurrentResult()), y.useEffect(() => {
      m.setOptions(u);
    }, [u, m]), Yj(u, v)) throw iw(u, m, s);
    if (Zj({ result: v, errorResetBoundary: s, throwOnError: u.throwOnError, query: f, suspense: u.suspense })) throw v.error;
    return (_d3 = (_c3 = l.getDefaultOptions().queries) == null ? void 0 : _c3._experimental_afterQuery) == null ? void 0 : _d3.call(_c3, u, v), u.experimental_prefetchInRender && !fa && qj(v, a) && ((_e13 = p ? iw(u, m, s) : f == null ? void 0 : f.promise) == null ? void 0 : _e13.catch(nn).finally(() => {
      m.updateResult();
    })), u.notifyOnChangeProps ? v : m.trackResult(v);
  }
  function Ux(e, t) {
    return Xj(e, Tj);
  }
  const Bx = y.createContext(null);
  function Qj({ children: e, defaultTheme: t = "system", storageKey: r = "shadcn-ui-theme" }) {
    const [a, s] = y.useState(() => {
      var _a4;
      return (_a4 = localStorage.getItem(r)) != null ? _a4 : t;
    });
    return y.useEffect(() => {
      const l = window.document.documentElement;
      if (l.classList.remove("light", "dark"), a === "system") {
        const u = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
        l.classList.add(u);
        return;
      }
      l.classList.add(a);
    }, [a]), b.jsx(Bx, { value: { theme: a, setTheme: (l) => {
      localStorage.setItem(r, l), s(l);
    } }, children: e });
  }
  function Gj() {
    const e = y.use(Bx);
    if (e === null) throw new Error("useTheme must be used within a ThemeProvider");
    return e;
  }
  function Ee(e, t, { checkForDefaultPrevented: r = true } = {}) {
    return function(s) {
      if (e == null ? void 0 : e(s), r === false || !s.defaultPrevented) return t == null ? void 0 : t(s);
    };
  }
  function sw(e, t) {
    if (typeof e == "function") return e(t);
    e != null && (e.current = t);
  }
  function Ci(...e) {
    return (t) => {
      let r = false;
      const a = e.map((s) => {
        const l = sw(s, t);
        return !r && typeof l == "function" && (r = true), l;
      });
      if (r) return () => {
        for (let s = 0; s < a.length; s++) {
          const l = a[s];
          typeof l == "function" ? l() : sw(e[s], null);
        }
      };
    };
  }
  function Ne(...e) {
    return y.useCallback(Ci(...e), e);
  }
  function Kj(e, t) {
    const r = y.createContext(t), a = (l) => {
      const { children: u, ...f } = l, p = y.useMemo(() => f, Object.values(f));
      return b.jsx(r.Provider, { value: p, children: u });
    };
    a.displayName = e + "Provider";
    function s(l) {
      const u = y.useContext(r);
      if (u) return u;
      if (t !== void 0) return t;
      throw new Error(`\`${l}\` must be used within \`${e}\``);
    }
    return [a, s];
  }
  function Fn(e, t = []) {
    let r = [];
    function a(l, u) {
      const f = y.createContext(u), p = r.length;
      r = [...r, u];
      const m = (g) => {
        var _a4;
        const { scope: S, children: _, ...x } = g, E = ((_a4 = S == null ? void 0 : S[e]) == null ? void 0 : _a4[p]) || f, C = y.useMemo(() => x, Object.values(x));
        return b.jsx(E.Provider, { value: C, children: _ });
      };
      m.displayName = l + "Provider";
      function v(g, S) {
        var _a4;
        const _ = ((_a4 = S == null ? void 0 : S[e]) == null ? void 0 : _a4[p]) || f, x = y.useContext(_);
        if (x) return x;
        if (u !== void 0) return u;
        throw new Error(`\`${g}\` must be used within \`${l}\``);
      }
      return [m, v];
    }
    const s = () => {
      const l = r.map((u) => y.createContext(u));
      return function(f) {
        const p = (f == null ? void 0 : f[e]) || l;
        return y.useMemo(() => ({ [`__scope${e}`]: { ...f, [e]: p } }), [f, p]);
      };
    };
    return s.scopeName = e, [a, Jj(s, ...t)];
  }
  function Jj(...e) {
    const t = e[0];
    if (e.length === 1) return t;
    const r = () => {
      const a = e.map((s) => ({ useScope: s(), scopeName: s.scopeName }));
      return function(l) {
        const u = a.reduce((f, { useScope: p, scopeName: m }) => {
          const g = p(l)[`__scope${m}`];
          return { ...f, ...g };
        }, {});
        return y.useMemo(() => ({ [`__scope${t.scopeName}`]: u }), [u]);
      };
    };
    return r.scopeName = t.scopeName, r;
  }
  var Et = (globalThis == null ? void 0 : globalThis.document) ? y.useLayoutEffect : () => {
  }, Wj = nm[" useId ".trim().toString()] || (() => {
  }), e3 = 0;
  function Br(e) {
    const [t, r] = y.useState(Wj());
    return Et(() => {
      r((a) => a != null ? a : String(e3++));
    }, [e]), e || (t ? `radix-${t}` : "");
  }
  var t3 = nm[" useInsertionEffect ".trim().toString()] || Et;
  function Hr({ prop: e, defaultProp: t, onChange: r = () => {
  }, caller: a }) {
    const [s, l, u] = n3({ defaultProp: t, onChange: r }), f = e !== void 0, p = f ? e : s;
    {
      const v = y.useRef(e !== void 0);
      y.useEffect(() => {
        const g = v.current;
        g !== f && console.warn(`${a} is changing from ${g ? "controlled" : "uncontrolled"} to ${f ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`), v.current = f;
      }, [f, a]);
    }
    const m = y.useCallback((v) => {
      var _a4;
      if (f) {
        const g = r3(v) ? v(e) : v;
        g !== e && ((_a4 = u.current) == null ? void 0 : _a4.call(u, g));
      } else l(v);
    }, [f, e, l, u]);
    return [p, m];
  }
  function n3({ defaultProp: e, onChange: t }) {
    const [r, a] = y.useState(e), s = y.useRef(r), l = y.useRef(t);
    return t3(() => {
      l.current = t;
    }, [t]), y.useEffect(() => {
      var _a4;
      s.current !== r && ((_a4 = l.current) == null ? void 0 : _a4.call(l, r), s.current = r);
    }, [r, s]), [r, a, l];
  }
  function r3(e) {
    return typeof e == "function";
  }
  function o3(e) {
    const t = a3(e), r = y.forwardRef((a, s) => {
      const { children: l, ...u } = a, f = y.Children.toArray(l), p = f.find(s3);
      if (p) {
        const m = p.props.children, v = f.map((g) => g === p ? y.Children.count(m) > 1 ? y.Children.only(null) : y.isValidElement(m) ? m.props.children : null : g);
        return b.jsx(t, { ...u, ref: s, children: y.isValidElement(m) ? y.cloneElement(m, void 0, v) : null });
      }
      return b.jsx(t, { ...u, ref: s, children: l });
    });
    return r.displayName = `${e}.Slot`, r;
  }
  function a3(e) {
    const t = y.forwardRef((r, a) => {
      const { children: s, ...l } = r;
      if (y.isValidElement(s)) {
        const u = c3(s), f = l3(l, s.props);
        return s.type !== y.Fragment && (f.ref = a ? Ci(a, u) : u), y.cloneElement(s, f);
      }
      return y.Children.count(s) > 1 ? y.Children.only(null) : null;
    });
    return t.displayName = `${e}.SlotClone`, t;
  }
  var i3 = /* @__PURE__ */ Symbol("radix.slottable");
  function s3(e) {
    return y.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === i3;
  }
  function l3(e, t) {
    const r = { ...t };
    for (const a in t) {
      const s = e[a], l = t[a];
      /^on[A-Z]/.test(a) ? s && l ? r[a] = (...f) => {
        const p = l(...f);
        return s(...f), p;
      } : s && (r[a] = s) : a === "style" ? r[a] = { ...s, ...l } : a === "className" && (r[a] = [s, l].filter(Boolean).join(" "));
    }
    return { ...e, ...r };
  }
  function c3(e) {
    var _a4, _b2;
    let t = (_a4 = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : _a4.get, r = t && "isReactWarning" in t && t.isReactWarning;
    return r ? e.ref : (t = (_b2 = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : _b2.get, r = t && "isReactWarning" in t && t.isReactWarning, r ? e.props.ref : e.props.ref || e.ref);
  }
  var u3 = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "select", "span", "svg", "ul"], Te = u3.reduce((e, t) => {
    const r = o3(`Primitive.${t}`), a = y.forwardRef((s, l) => {
      const { asChild: u, ...f } = s, p = u ? r : t;
      return typeof window < "u" && (window[/* @__PURE__ */ Symbol.for("radix-ui")] = true), b.jsx(p, { ...f, ref: l });
    });
    return a.displayName = `Primitive.${t}`, { ...e, [t]: a };
  }, {});
  function f3(e, t) {
    e && Ai.flushSync(() => e.dispatchEvent(t));
  }
  function rn(e) {
    const t = y.useRef(e);
    return y.useEffect(() => {
      t.current = e;
    }), y.useMemo(() => (...r) => {
      var _a4;
      return (_a4 = t.current) == null ? void 0 : _a4.call(t, ...r);
    }, []);
  }
  function d3(e, t = globalThis == null ? void 0 : globalThis.document) {
    const r = rn(e);
    y.useEffect(() => {
      const a = (s) => {
        s.key === "Escape" && r(s);
      };
      return t.addEventListener("keydown", a, { capture: true }), () => t.removeEventListener("keydown", a, { capture: true });
    }, [r, t]);
  }
  var h3 = "DismissableLayer", gp = "dismissableLayer.update", p3 = "dismissableLayer.pointerDownOutside", m3 = "dismissableLayer.focusOutside", lw, Ix = y.createContext({ layers: /* @__PURE__ */ new Set(), layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(), branches: /* @__PURE__ */ new Set() }), Lu = y.forwardRef((e, t) => {
    var _a4;
    const { disableOutsidePointerEvents: r = false, onEscapeKeyDown: a, onPointerDownOutside: s, onFocusOutside: l, onInteractOutside: u, onDismiss: f, ...p } = e, m = y.useContext(Ix), [v, g] = y.useState(null), S = (_a4 = v == null ? void 0 : v.ownerDocument) != null ? _a4 : globalThis == null ? void 0 : globalThis.document, [, _] = y.useState({}), x = Ne(t, (k) => g(k)), E = Array.from(m.layers), [C] = [...m.layersWithOutsidePointerEventsDisabled].slice(-1), T = E.indexOf(C), R = v ? E.indexOf(v) : -1, O = m.layersWithOutsidePointerEventsDisabled.size > 0, D = R >= T, P = y3((k) => {
      const $ = k.target, re = [...m.branches].some((G) => G.contains($));
      !D || re || (s == null ? void 0 : s(k), u == null ? void 0 : u(k), k.defaultPrevented || (f == null ? void 0 : f()));
    }, S), L = b3((k) => {
      const $ = k.target;
      [...m.branches].some((G) => G.contains($)) || (l == null ? void 0 : l(k), u == null ? void 0 : u(k), k.defaultPrevented || (f == null ? void 0 : f()));
    }, S);
    return d3((k) => {
      R === m.layers.size - 1 && (a == null ? void 0 : a(k), !k.defaultPrevented && f && (k.preventDefault(), f()));
    }, S), y.useEffect(() => {
      if (v) return r && (m.layersWithOutsidePointerEventsDisabled.size === 0 && (lw = S.body.style.pointerEvents, S.body.style.pointerEvents = "none"), m.layersWithOutsidePointerEventsDisabled.add(v)), m.layers.add(v), cw(), () => {
        r && m.layersWithOutsidePointerEventsDisabled.size === 1 && (S.body.style.pointerEvents = lw);
      };
    }, [v, S, r, m]), y.useEffect(() => () => {
      v && (m.layers.delete(v), m.layersWithOutsidePointerEventsDisabled.delete(v), cw());
    }, [v, m]), y.useEffect(() => {
      const k = () => _({});
      return document.addEventListener(gp, k), () => document.removeEventListener(gp, k);
    }, []), b.jsx(Te.div, { ...p, ref: x, style: { pointerEvents: O ? D ? "auto" : "none" : void 0, ...e.style }, onFocusCapture: Ee(e.onFocusCapture, L.onFocusCapture), onBlurCapture: Ee(e.onBlurCapture, L.onBlurCapture), onPointerDownCapture: Ee(e.onPointerDownCapture, P.onPointerDownCapture) });
  });
  Lu.displayName = h3;
  var g3 = "DismissableLayerBranch", v3 = y.forwardRef((e, t) => {
    const r = y.useContext(Ix), a = y.useRef(null), s = Ne(t, a);
    return y.useEffect(() => {
      const l = a.current;
      if (l) return r.branches.add(l), () => {
        r.branches.delete(l);
      };
    }, [r.branches]), b.jsx(Te.div, { ...e, ref: s });
  });
  v3.displayName = g3;
  function y3(e, t = globalThis == null ? void 0 : globalThis.document) {
    const r = rn(e), a = y.useRef(false), s = y.useRef(() => {
    });
    return y.useEffect(() => {
      const l = (f) => {
        if (f.target && !a.current) {
          let p = function() {
            Hx(p3, r, m, { discrete: true });
          };
          const m = { originalEvent: f };
          f.pointerType === "touch" ? (t.removeEventListener("click", s.current), s.current = p, t.addEventListener("click", s.current, { once: true })) : p();
        } else t.removeEventListener("click", s.current);
        a.current = false;
      }, u = window.setTimeout(() => {
        t.addEventListener("pointerdown", l);
      }, 0);
      return () => {
        window.clearTimeout(u), t.removeEventListener("pointerdown", l), t.removeEventListener("click", s.current);
      };
    }, [t, r]), { onPointerDownCapture: () => a.current = true };
  }
  function b3(e, t = globalThis == null ? void 0 : globalThis.document) {
    const r = rn(e), a = y.useRef(false);
    return y.useEffect(() => {
      const s = (l) => {
        l.target && !a.current && Hx(m3, r, { originalEvent: l }, { discrete: false });
      };
      return t.addEventListener("focusin", s), () => t.removeEventListener("focusin", s);
    }, [t, r]), { onFocusCapture: () => a.current = true, onBlurCapture: () => a.current = false };
  }
  function cw() {
    const e = new CustomEvent(gp);
    document.dispatchEvent(e);
  }
  function Hx(e, t, r, { discrete: a }) {
    const s = r.originalEvent.target, l = new CustomEvent(e, { bubbles: false, cancelable: true, detail: r });
    t && s.addEventListener(e, t, { once: true }), a ? f3(s, l) : s.dispatchEvent(l);
  }
  var Dh = "focusScope.autoFocusOnMount", jh = "focusScope.autoFocusOnUnmount", uw = { bubbles: false, cancelable: true }, w3 = "FocusScope", hm = y.forwardRef((e, t) => {
    const { loop: r = false, trapped: a = false, onMountAutoFocus: s, onUnmountAutoFocus: l, ...u } = e, [f, p] = y.useState(null), m = rn(s), v = rn(l), g = y.useRef(null), S = Ne(t, (E) => p(E)), _ = y.useRef({ paused: false, pause() {
      this.paused = true;
    }, resume() {
      this.paused = false;
    } }).current;
    y.useEffect(() => {
      if (a) {
        let E = function(O) {
          if (_.paused || !f) return;
          const D = O.target;
          f.contains(D) ? g.current = D : xo(g.current, { select: true });
        }, C = function(O) {
          if (_.paused || !f) return;
          const D = O.relatedTarget;
          D !== null && (f.contains(D) || xo(g.current, { select: true }));
        }, T = function(O) {
          if (document.activeElement === document.body) for (const P of O) P.removedNodes.length > 0 && xo(f);
        };
        document.addEventListener("focusin", E), document.addEventListener("focusout", C);
        const R = new MutationObserver(T);
        return f && R.observe(f, { childList: true, subtree: true }), () => {
          document.removeEventListener("focusin", E), document.removeEventListener("focusout", C), R.disconnect();
        };
      }
    }, [a, f, _.paused]), y.useEffect(() => {
      if (f) {
        dw.add(_);
        const E = document.activeElement;
        if (!f.contains(E)) {
          const T = new CustomEvent(Dh, uw);
          f.addEventListener(Dh, m), f.dispatchEvent(T), T.defaultPrevented || (S3(C3($x(f)), { select: true }), document.activeElement === E && xo(f));
        }
        return () => {
          f.removeEventListener(Dh, m), setTimeout(() => {
            const T = new CustomEvent(jh, uw);
            f.addEventListener(jh, v), f.dispatchEvent(T), T.defaultPrevented || xo(E != null ? E : document.body, { select: true }), f.removeEventListener(jh, v), dw.remove(_);
          }, 0);
        };
      }
    }, [f, m, v, _]);
    const x = y.useCallback((E) => {
      if (!r && !a || _.paused) return;
      const C = E.key === "Tab" && !E.altKey && !E.ctrlKey && !E.metaKey, T = document.activeElement;
      if (C && T) {
        const R = E.currentTarget, [O, D] = x3(R);
        O && D ? !E.shiftKey && T === D ? (E.preventDefault(), r && xo(O, { select: true })) : E.shiftKey && T === O && (E.preventDefault(), r && xo(D, { select: true })) : T === R && E.preventDefault();
      }
    }, [r, a, _.paused]);
    return b.jsx(Te.div, { tabIndex: -1, ...u, ref: S, onKeyDown: x });
  });
  hm.displayName = w3;
  function S3(e, { select: t = false } = {}) {
    const r = document.activeElement;
    for (const a of e) if (xo(a, { select: t }), document.activeElement !== r) return;
  }
  function x3(e) {
    const t = $x(e), r = fw(t, e), a = fw(t.reverse(), e);
    return [r, a];
  }
  function $x(e) {
    const t = [], r = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: (a) => {
      const s = a.tagName === "INPUT" && a.type === "hidden";
      return a.disabled || a.hidden || s ? NodeFilter.FILTER_SKIP : a.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    } });
    for (; r.nextNode(); ) t.push(r.currentNode);
    return t;
  }
  function fw(e, t) {
    for (const r of e) if (!_3(r, { upTo: t })) return r;
  }
  function _3(e, { upTo: t }) {
    if (getComputedStyle(e).visibility === "hidden") return true;
    for (; e; ) {
      if (t !== void 0 && e === t) return false;
      if (getComputedStyle(e).display === "none") return true;
      e = e.parentElement;
    }
    return false;
  }
  function E3(e) {
    return e instanceof HTMLInputElement && "select" in e;
  }
  function xo(e, { select: t = false } = {}) {
    if (e && e.focus) {
      const r = document.activeElement;
      e.focus({ preventScroll: true }), e !== r && E3(e) && t && e.select();
    }
  }
  var dw = A3();
  function A3() {
    let e = [];
    return { add(t) {
      const r = e[0];
      t !== r && (r == null ? void 0 : r.pause()), e = hw(e, t), e.unshift(t);
    }, remove(t) {
      var _a4;
      e = hw(e, t), (_a4 = e[0]) == null ? void 0 : _a4.resume();
    } };
  }
  function hw(e, t) {
    const r = [...e], a = r.indexOf(t);
    return a !== -1 && r.splice(a, 1), r;
  }
  function C3(e) {
    return e.filter((t) => t.tagName !== "A");
  }
  var T3 = "Portal", Uu = y.forwardRef((e, t) => {
    var _a4;
    const { container: r, ...a } = e, [s, l] = y.useState(false);
    Et(() => l(true), []);
    const u = r || s && ((_a4 = globalThis == null ? void 0 : globalThis.document) == null ? void 0 : _a4.body);
    return u ? gx.createPortal(b.jsx(Te.div, { ...a, ref: t }), u) : null;
  });
  Uu.displayName = T3;
  function O3(e, t) {
    return y.useReducer((r, a) => {
      var _a4;
      return (_a4 = t[r][a]) != null ? _a4 : r;
    }, e);
  }
  var qn = (e) => {
    const { present: t, children: r } = e, a = R3(t), s = typeof r == "function" ? r({ present: a.isPresent }) : y.Children.only(r), l = Ne(a.ref, M3(s));
    return typeof r == "function" || a.isPresent ? y.cloneElement(s, { ref: l }) : null;
  };
  qn.displayName = "Presence";
  function R3(e) {
    const [t, r] = y.useState(), a = y.useRef(null), s = y.useRef(e), l = y.useRef("none"), u = e ? "mounted" : "unmounted", [f, p] = O3(u, { mounted: { UNMOUNT: "unmounted", ANIMATION_OUT: "unmountSuspended" }, unmountSuspended: { MOUNT: "mounted", ANIMATION_END: "unmounted" }, unmounted: { MOUNT: "mounted" } });
    return y.useEffect(() => {
      const m = zc(a.current);
      l.current = f === "mounted" ? m : "none";
    }, [f]), Et(() => {
      const m = a.current, v = s.current;
      if (v !== e) {
        const S = l.current, _ = zc(m);
        e ? p("MOUNT") : _ === "none" || (m == null ? void 0 : m.display) === "none" ? p("UNMOUNT") : p(v && S !== _ ? "ANIMATION_OUT" : "UNMOUNT"), s.current = e;
      }
    }, [e, p]), Et(() => {
      var _a4;
      if (t) {
        let m;
        const v = (_a4 = t.ownerDocument.defaultView) != null ? _a4 : window, g = (_) => {
          const E = zc(a.current).includes(CSS.escape(_.animationName));
          if (_.target === t && E && (p("ANIMATION_END"), !s.current)) {
            const C = t.style.animationFillMode;
            t.style.animationFillMode = "forwards", m = v.setTimeout(() => {
              t.style.animationFillMode === "forwards" && (t.style.animationFillMode = C);
            });
          }
        }, S = (_) => {
          _.target === t && (l.current = zc(a.current));
        };
        return t.addEventListener("animationstart", S), t.addEventListener("animationcancel", g), t.addEventListener("animationend", g), () => {
          v.clearTimeout(m), t.removeEventListener("animationstart", S), t.removeEventListener("animationcancel", g), t.removeEventListener("animationend", g);
        };
      } else p("ANIMATION_END");
    }, [t, p]), { isPresent: ["mounted", "unmountSuspended"].includes(f), ref: y.useCallback((m) => {
      a.current = m ? getComputedStyle(m) : null, r(m);
    }, []) };
  }
  function zc(e) {
    return (e == null ? void 0 : e.animationName) || "none";
  }
  function M3(e) {
    var _a4, _b2;
    let t = (_a4 = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : _a4.get, r = t && "isReactWarning" in t && t.isReactWarning;
    return r ? e.ref : (t = (_b2 = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : _b2.get, r = t && "isReactWarning" in t && t.isReactWarning, r ? e.props.ref : e.props.ref || e.ref);
  }
  var kh = 0;
  function Vx() {
    y.useEffect(() => {
      var _a4, _b2;
      const e = document.querySelectorAll("[data-radix-focus-guard]");
      return document.body.insertAdjacentElement("afterbegin", (_a4 = e[0]) != null ? _a4 : pw()), document.body.insertAdjacentElement("beforeend", (_b2 = e[1]) != null ? _b2 : pw()), kh++, () => {
        kh === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach((t) => t.remove()), kh--;
      };
    }, []);
  }
  function pw() {
    const e = document.createElement("span");
    return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
  }
  var ir = function() {
    return ir = Object.assign || function(t) {
      for (var r, a = 1, s = arguments.length; a < s; a++) {
        r = arguments[a];
        for (var l in r) Object.prototype.hasOwnProperty.call(r, l) && (t[l] = r[l]);
      }
      return t;
    }, ir.apply(this, arguments);
  };
  function Zx(e, t) {
    var r = {};
    for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && t.indexOf(a) < 0 && (r[a] = e[a]);
    if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var s = 0, a = Object.getOwnPropertySymbols(e); s < a.length; s++) t.indexOf(a[s]) < 0 && Object.prototype.propertyIsEnumerable.call(e, a[s]) && (r[a[s]] = e[a[s]]);
    return r;
  }
  function N3(e, t, r) {
    if (r || arguments.length === 2) for (var a = 0, s = t.length, l; a < s; a++) (l || !(a in t)) && (l || (l = Array.prototype.slice.call(t, 0, a)), l[a] = t[a]);
    return e.concat(l || Array.prototype.slice.call(t));
  }
  var Yc = "right-scroll-bar-position", Xc = "width-before-scroll-bar", z3 = "with-scroll-bars-hidden", D3 = "--removed-body-scroll-bar-size";
  function Ph(e, t) {
    return typeof e == "function" ? e(t) : e && (e.current = t), e;
  }
  function j3(e, t) {
    var r = y.useState(function() {
      return { value: e, callback: t, facade: { get current() {
        return r.value;
      }, set current(a) {
        var s = r.value;
        s !== a && (r.value = a, r.callback(a, s));
      } } };
    })[0];
    return r.callback = t, r.facade;
  }
  var k3 = typeof window < "u" ? y.useLayoutEffect : y.useEffect, mw = /* @__PURE__ */ new WeakMap();
  function P3(e, t) {
    var r = j3(null, function(a) {
      return e.forEach(function(s) {
        return Ph(s, a);
      });
    });
    return k3(function() {
      var a = mw.get(r);
      if (a) {
        var s = new Set(a), l = new Set(e), u = r.current;
        s.forEach(function(f) {
          l.has(f) || Ph(f, null);
        }), l.forEach(function(f) {
          s.has(f) || Ph(f, u);
        });
      }
      mw.set(r, e);
    }, [e]), r;
  }
  function L3(e) {
    return e;
  }
  function U3(e, t) {
    t === void 0 && (t = L3);
    var r = [], a = false, s = { read: function() {
      if (a) throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return r.length ? r[r.length - 1] : e;
    }, useMedium: function(l) {
      var u = t(l, a);
      return r.push(u), function() {
        r = r.filter(function(f) {
          return f !== u;
        });
      };
    }, assignSyncMedium: function(l) {
      for (a = true; r.length; ) {
        var u = r;
        r = [], u.forEach(l);
      }
      r = { push: function(f) {
        return l(f);
      }, filter: function() {
        return r;
      } };
    }, assignMedium: function(l) {
      a = true;
      var u = [];
      if (r.length) {
        var f = r;
        r = [], f.forEach(l), u = r;
      }
      var p = function() {
        var v = u;
        u = [], v.forEach(l);
      }, m = function() {
        return Promise.resolve().then(p);
      };
      m(), r = { push: function(v) {
        u.push(v), m();
      }, filter: function(v) {
        return u = u.filter(v), r;
      } };
    } };
    return s;
  }
  function B3(e) {
    e === void 0 && (e = {});
    var t = U3(null);
    return t.options = ir({ async: true, ssr: false }, e), t;
  }
  var Fx = function(e) {
    var t = e.sideCar, r = Zx(e, ["sideCar"]);
    if (!t) throw new Error("Sidecar: please provide `sideCar` property to import the right car");
    var a = t.read();
    if (!a) throw new Error("Sidecar medium not found");
    return y.createElement(a, ir({}, r));
  };
  Fx.isSideCarExport = true;
  function I3(e, t) {
    return e.useMedium(t), Fx;
  }
  var qx = B3(), Lh = function() {
  }, Bu = y.forwardRef(function(e, t) {
    var r = y.useRef(null), a = y.useState({ onScrollCapture: Lh, onWheelCapture: Lh, onTouchMoveCapture: Lh }), s = a[0], l = a[1], u = e.forwardProps, f = e.children, p = e.className, m = e.removeScrollBar, v = e.enabled, g = e.shards, S = e.sideCar, _ = e.noRelative, x = e.noIsolation, E = e.inert, C = e.allowPinchZoom, T = e.as, R = T === void 0 ? "div" : T, O = e.gapMode, D = Zx(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]), P = S, L = P3([r, t]), k = ir(ir({}, D), s);
    return y.createElement(y.Fragment, null, v && y.createElement(P, { sideCar: qx, removeScrollBar: m, shards: g, noRelative: _, noIsolation: x, inert: E, setCallbacks: l, allowPinchZoom: !!C, lockRef: r, gapMode: O }), u ? y.cloneElement(y.Children.only(f), ir(ir({}, k), { ref: L })) : y.createElement(R, ir({}, k, { className: p, ref: L }), f));
  });
  Bu.defaultProps = { enabled: true, removeScrollBar: true, inert: false };
  Bu.classNames = { fullWidth: Xc, zeroRight: Yc };
  var H3 = function() {
    if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
  };
  function $3() {
    if (!document) return null;
    var e = document.createElement("style");
    e.type = "text/css";
    var t = H3();
    return t && e.setAttribute("nonce", t), e;
  }
  function V3(e, t) {
    e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
  }
  function Z3(e) {
    var t = document.head || document.getElementsByTagName("head")[0];
    t.appendChild(e);
  }
  var F3 = function() {
    var e = 0, t = null;
    return { add: function(r) {
      e == 0 && (t = $3()) && (V3(t, r), Z3(t)), e++;
    }, remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    } };
  }, q3 = function() {
    var e = F3();
    return function(t, r) {
      y.useEffect(function() {
        return e.add(t), function() {
          e.remove();
        };
      }, [t && r]);
    };
  }, Yx = function() {
    var e = q3(), t = function(r) {
      var a = r.styles, s = r.dynamic;
      return e(a, s), null;
    };
    return t;
  }, Y3 = { left: 0, top: 0, right: 0, gap: 0 }, Uh = function(e) {
    return parseInt(e || "", 10) || 0;
  }, X3 = function(e) {
    var t = window.getComputedStyle(document.body), r = t[e === "padding" ? "paddingLeft" : "marginLeft"], a = t[e === "padding" ? "paddingTop" : "marginTop"], s = t[e === "padding" ? "paddingRight" : "marginRight"];
    return [Uh(r), Uh(a), Uh(s)];
  }, Q3 = function(e) {
    if (e === void 0 && (e = "margin"), typeof window > "u") return Y3;
    var t = X3(e), r = document.documentElement.clientWidth, a = window.innerWidth;
    return { left: t[0], top: t[1], right: t[2], gap: Math.max(0, a - r + t[2] - t[0]) };
  }, G3 = Yx(), mi = "data-scroll-locked", K3 = function(e, t, r, a) {
    var s = e.left, l = e.top, u = e.right, f = e.gap;
    return r === void 0 && (r = "margin"), `
  .`.concat(z3, ` {
   overflow: hidden `).concat(a, `;
   padding-right: `).concat(f, "px ").concat(a, `;
  }
  body[`).concat(mi, `] {
    overflow: hidden `).concat(a, `;
    overscroll-behavior: contain;
    `).concat([t && "position: relative ".concat(a, ";"), r === "margin" && `
    padding-left: `.concat(s, `px;
    padding-top: `).concat(l, `px;
    padding-right: `).concat(u, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(f, "px ").concat(a, `;
    `), r === "padding" && "padding-right: ".concat(f, "px ").concat(a, ";")].filter(Boolean).join(""), `
  }
  
  .`).concat(Yc, ` {
    right: `).concat(f, "px ").concat(a, `;
  }
  
  .`).concat(Xc, ` {
    margin-right: `).concat(f, "px ").concat(a, `;
  }
  
  .`).concat(Yc, " .").concat(Yc, ` {
    right: 0 `).concat(a, `;
  }
  
  .`).concat(Xc, " .").concat(Xc, ` {
    margin-right: 0 `).concat(a, `;
  }
  
  body[`).concat(mi, `] {
    `).concat(D3, ": ").concat(f, `px;
  }
`);
  }, gw = function() {
    var e = parseInt(document.body.getAttribute(mi) || "0", 10);
    return isFinite(e) ? e : 0;
  }, J3 = function() {
    y.useEffect(function() {
      return document.body.setAttribute(mi, (gw() + 1).toString()), function() {
        var e = gw() - 1;
        e <= 0 ? document.body.removeAttribute(mi) : document.body.setAttribute(mi, e.toString());
      };
    }, []);
  }, W3 = function(e) {
    var t = e.noRelative, r = e.noImportant, a = e.gapMode, s = a === void 0 ? "margin" : a;
    J3();
    var l = y.useMemo(function() {
      return Q3(s);
    }, [s]);
    return y.createElement(G3, { styles: K3(l, !t, s, r ? "" : "!important") });
  }, vp = false;
  if (typeof window < "u") try {
    var Dc = Object.defineProperty({}, "passive", { get: function() {
      return vp = true, true;
    } });
    window.addEventListener("test", Dc, Dc), window.removeEventListener("test", Dc, Dc);
  } catch {
    vp = false;
  }
  var ai = vp ? { passive: false } : false, ek = function(e) {
    return e.tagName === "TEXTAREA";
  }, Xx = function(e, t) {
    if (!(e instanceof Element)) return false;
    var r = window.getComputedStyle(e);
    return r[t] !== "hidden" && !(r.overflowY === r.overflowX && !ek(e) && r[t] === "visible");
  }, tk = function(e) {
    return Xx(e, "overflowY");
  }, nk = function(e) {
    return Xx(e, "overflowX");
  }, vw = function(e, t) {
    var r = t.ownerDocument, a = t;
    do {
      typeof ShadowRoot < "u" && a instanceof ShadowRoot && (a = a.host);
      var s = Qx(e, a);
      if (s) {
        var l = Gx(e, a), u = l[1], f = l[2];
        if (u > f) return true;
      }
      a = a.parentNode;
    } while (a && a !== r.body);
    return false;
  }, rk = function(e) {
    var t = e.scrollTop, r = e.scrollHeight, a = e.clientHeight;
    return [t, r, a];
  }, ok = function(e) {
    var t = e.scrollLeft, r = e.scrollWidth, a = e.clientWidth;
    return [t, r, a];
  }, Qx = function(e, t) {
    return e === "v" ? tk(t) : nk(t);
  }, Gx = function(e, t) {
    return e === "v" ? rk(t) : ok(t);
  }, ak = function(e, t) {
    return e === "h" && t === "rtl" ? -1 : 1;
  }, ik = function(e, t, r, a, s) {
    var l = ak(e, window.getComputedStyle(t).direction), u = l * a, f = r.target, p = t.contains(f), m = false, v = u > 0, g = 0, S = 0;
    do {
      if (!f) break;
      var _ = Gx(e, f), x = _[0], E = _[1], C = _[2], T = E - C - l * x;
      (x || T) && Qx(e, f) && (g += T, S += x);
      var R = f.parentNode;
      f = R && R.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? R.host : R;
    } while (!p && f !== document.body || p && (t.contains(f) || t === f));
    return (v && Math.abs(g) < 1 || !v && Math.abs(S) < 1) && (m = true), m;
  }, jc = function(e) {
    return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
  }, yw = function(e) {
    return [e.deltaX, e.deltaY];
  }, bw = function(e) {
    return e && "current" in e ? e.current : e;
  }, sk = function(e, t) {
    return e[0] === t[0] && e[1] === t[1];
  }, lk = function(e) {
    return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
  }, ck = 0, ii = [];
  function uk(e) {
    var t = y.useRef([]), r = y.useRef([0, 0]), a = y.useRef(), s = y.useState(ck++)[0], l = y.useState(Yx)[0], u = y.useRef(e);
    y.useEffect(function() {
      u.current = e;
    }, [e]), y.useEffect(function() {
      if (e.inert) {
        document.body.classList.add("block-interactivity-".concat(s));
        var E = N3([e.lockRef.current], (e.shards || []).map(bw), true).filter(Boolean);
        return E.forEach(function(C) {
          return C.classList.add("allow-interactivity-".concat(s));
        }), function() {
          document.body.classList.remove("block-interactivity-".concat(s)), E.forEach(function(C) {
            return C.classList.remove("allow-interactivity-".concat(s));
          });
        };
      }
    }, [e.inert, e.lockRef.current, e.shards]);
    var f = y.useCallback(function(E, C) {
      if ("touches" in E && E.touches.length === 2 || E.type === "wheel" && E.ctrlKey) return !u.current.allowPinchZoom;
      var T = jc(E), R = r.current, O = "deltaX" in E ? E.deltaX : R[0] - T[0], D = "deltaY" in E ? E.deltaY : R[1] - T[1], P, L = E.target, k = Math.abs(O) > Math.abs(D) ? "h" : "v";
      if ("touches" in E && k === "h" && L.type === "range") return false;
      var $ = vw(k, L);
      if (!$) return true;
      if ($ ? P = k : (P = k === "v" ? "h" : "v", $ = vw(k, L)), !$) return false;
      if (!a.current && "changedTouches" in E && (O || D) && (a.current = P), !P) return true;
      var re = a.current || P;
      return ik(re, C, E, re === "h" ? O : D);
    }, []), p = y.useCallback(function(E) {
      var C = E;
      if (!(!ii.length || ii[ii.length - 1] !== l)) {
        var T = "deltaY" in C ? yw(C) : jc(C), R = t.current.filter(function(P) {
          return P.name === C.type && (P.target === C.target || C.target === P.shadowParent) && sk(P.delta, T);
        })[0];
        if (R && R.should) {
          C.cancelable && C.preventDefault();
          return;
        }
        if (!R) {
          var O = (u.current.shards || []).map(bw).filter(Boolean).filter(function(P) {
            return P.contains(C.target);
          }), D = O.length > 0 ? f(C, O[0]) : !u.current.noIsolation;
          D && C.cancelable && C.preventDefault();
        }
      }
    }, []), m = y.useCallback(function(E, C, T, R) {
      var O = { name: E, delta: C, target: T, should: R, shadowParent: fk(T) };
      t.current.push(O), setTimeout(function() {
        t.current = t.current.filter(function(D) {
          return D !== O;
        });
      }, 1);
    }, []), v = y.useCallback(function(E) {
      r.current = jc(E), a.current = void 0;
    }, []), g = y.useCallback(function(E) {
      m(E.type, yw(E), E.target, f(E, e.lockRef.current));
    }, []), S = y.useCallback(function(E) {
      m(E.type, jc(E), E.target, f(E, e.lockRef.current));
    }, []);
    y.useEffect(function() {
      return ii.push(l), e.setCallbacks({ onScrollCapture: g, onWheelCapture: g, onTouchMoveCapture: S }), document.addEventListener("wheel", p, ai), document.addEventListener("touchmove", p, ai), document.addEventListener("touchstart", v, ai), function() {
        ii = ii.filter(function(E) {
          return E !== l;
        }), document.removeEventListener("wheel", p, ai), document.removeEventListener("touchmove", p, ai), document.removeEventListener("touchstart", v, ai);
      };
    }, []);
    var _ = e.removeScrollBar, x = e.inert;
    return y.createElement(y.Fragment, null, x ? y.createElement(l, { styles: lk(s) }) : null, _ ? y.createElement(W3, { noRelative: e.noRelative, gapMode: e.gapMode }) : null);
  }
  function fk(e) {
    for (var t = null; e !== null; ) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
    return t;
  }
  const dk = I3(qx, uk);
  var pm = y.forwardRef(function(e, t) {
    return y.createElement(Bu, ir({}, e, { ref: t, sideCar: dk }));
  });
  pm.classNames = Bu.classNames;
  var hk = function(e) {
    if (typeof document > "u") return null;
    var t = Array.isArray(e) ? e[0] : e;
    return t.ownerDocument.body;
  }, si = /* @__PURE__ */ new WeakMap(), kc = /* @__PURE__ */ new WeakMap(), Pc = {}, Bh = 0, Kx = function(e) {
    return e && (e.host || Kx(e.parentNode));
  }, pk = function(e, t) {
    return t.map(function(r) {
      if (e.contains(r)) return r;
      var a = Kx(r);
      return a && e.contains(a) ? a : (console.error("aria-hidden", r, "in not contained inside", e, ". Doing nothing"), null);
    }).filter(function(r) {
      return !!r;
    });
  }, mk = function(e, t, r, a) {
    var s = pk(t, Array.isArray(e) ? e : [e]);
    Pc[r] || (Pc[r] = /* @__PURE__ */ new WeakMap());
    var l = Pc[r], u = [], f = /* @__PURE__ */ new Set(), p = new Set(s), m = function(g) {
      !g || f.has(g) || (f.add(g), m(g.parentNode));
    };
    s.forEach(m);
    var v = function(g) {
      !g || p.has(g) || Array.prototype.forEach.call(g.children, function(S) {
        if (f.has(S)) v(S);
        else try {
          var _ = S.getAttribute(a), x = _ !== null && _ !== "false", E = (si.get(S) || 0) + 1, C = (l.get(S) || 0) + 1;
          si.set(S, E), l.set(S, C), u.push(S), E === 1 && x && kc.set(S, true), C === 1 && S.setAttribute(r, "true"), x || S.setAttribute(a, "true");
        } catch (T) {
          console.error("aria-hidden: cannot operate on ", S, T);
        }
      });
    };
    return v(t), f.clear(), Bh++, function() {
      u.forEach(function(g) {
        var S = si.get(g) - 1, _ = l.get(g) - 1;
        si.set(g, S), l.set(g, _), S || (kc.has(g) || g.removeAttribute(a), kc.delete(g)), _ || g.removeAttribute(r);
      }), Bh--, Bh || (si = /* @__PURE__ */ new WeakMap(), si = /* @__PURE__ */ new WeakMap(), kc = /* @__PURE__ */ new WeakMap(), Pc = {});
    };
  }, Jx = function(e, t, r) {
    r === void 0 && (r = "data-aria-hidden");
    var a = Array.from(Array.isArray(e) ? e : [e]), s = hk(e);
    return s ? (a.push.apply(a, Array.from(s.querySelectorAll("[aria-live], script"))), mk(a, s, r, "aria-hidden")) : function() {
      return null;
    };
  };
  function gk(e) {
    const t = vk(e), r = y.forwardRef((a, s) => {
      const { children: l, ...u } = a, f = y.Children.toArray(l), p = f.find(bk);
      if (p) {
        const m = p.props.children, v = f.map((g) => g === p ? y.Children.count(m) > 1 ? y.Children.only(null) : y.isValidElement(m) ? m.props.children : null : g);
        return b.jsx(t, { ...u, ref: s, children: y.isValidElement(m) ? y.cloneElement(m, void 0, v) : null });
      }
      return b.jsx(t, { ...u, ref: s, children: l });
    });
    return r.displayName = `${e}.Slot`, r;
  }
  function vk(e) {
    const t = y.forwardRef((r, a) => {
      const { children: s, ...l } = r;
      if (y.isValidElement(s)) {
        const u = Sk(s), f = wk(l, s.props);
        return s.type !== y.Fragment && (f.ref = a ? Ci(a, u) : u), y.cloneElement(s, f);
      }
      return y.Children.count(s) > 1 ? y.Children.only(null) : null;
    });
    return t.displayName = `${e}.SlotClone`, t;
  }
  var yk = /* @__PURE__ */ Symbol("radix.slottable");
  function bk(e) {
    return y.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === yk;
  }
  function wk(e, t) {
    const r = { ...t };
    for (const a in t) {
      const s = e[a], l = t[a];
      /^on[A-Z]/.test(a) ? s && l ? r[a] = (...f) => {
        const p = l(...f);
        return s(...f), p;
      } : s && (r[a] = s) : a === "style" ? r[a] = { ...s, ...l } : a === "className" && (r[a] = [s, l].filter(Boolean).join(" "));
    }
    return { ...e, ...r };
  }
  function Sk(e) {
    var _a4, _b2;
    let t = (_a4 = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : _a4.get, r = t && "isReactWarning" in t && t.isReactWarning;
    return r ? e.ref : (t = (_b2 = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : _b2.get, r = t && "isReactWarning" in t && t.isReactWarning, r ? e.props.ref : e.props.ref || e.ref);
  }
  var Iu = "Dialog", [Wx, e1] = Fn(Iu), [xk, Yn] = Wx(Iu), t1 = (e) => {
    const { __scopeDialog: t, children: r, open: a, defaultOpen: s, onOpenChange: l, modal: u = true } = e, f = y.useRef(null), p = y.useRef(null), [m, v] = Hr({ prop: a, defaultProp: s != null ? s : false, onChange: l, caller: Iu });
    return b.jsx(xk, { scope: t, triggerRef: f, contentRef: p, contentId: Br(), titleId: Br(), descriptionId: Br(), open: m, onOpenChange: v, onOpenToggle: y.useCallback(() => v((g) => !g), [v]), modal: u, children: r });
  };
  t1.displayName = Iu;
  var n1 = "DialogTrigger", r1 = y.forwardRef((e, t) => {
    const { __scopeDialog: r, ...a } = e, s = Yn(n1, r), l = Ne(t, s.triggerRef);
    return b.jsx(Te.button, { type: "button", "aria-haspopup": "dialog", "aria-expanded": s.open, "aria-controls": s.contentId, "data-state": vm(s.open), ...a, ref: l, onClick: Ee(e.onClick, s.onOpenToggle) });
  });
  r1.displayName = n1;
  var mm = "DialogPortal", [_k, o1] = Wx(mm, { forceMount: void 0 }), a1 = (e) => {
    const { __scopeDialog: t, forceMount: r, children: a, container: s } = e, l = Yn(mm, t);
    return b.jsx(_k, { scope: t, forceMount: r, children: y.Children.map(a, (u) => b.jsx(qn, { present: r || l.open, children: b.jsx(Uu, { asChild: true, container: s, children: u }) })) });
  };
  a1.displayName = mm;
  var au = "DialogOverlay", i1 = y.forwardRef((e, t) => {
    const r = o1(au, e.__scopeDialog), { forceMount: a = r.forceMount, ...s } = e, l = Yn(au, e.__scopeDialog);
    return l.modal ? b.jsx(qn, { present: a || l.open, children: b.jsx(Ak, { ...s, ref: t }) }) : null;
  });
  i1.displayName = au;
  var Ek = gk("DialogOverlay.RemoveScroll"), Ak = y.forwardRef((e, t) => {
    const { __scopeDialog: r, ...a } = e, s = Yn(au, r);
    return b.jsx(pm, { as: Ek, allowPinchZoom: true, shards: [s.contentRef], children: b.jsx(Te.div, { "data-state": vm(s.open), ...a, ref: t, style: { pointerEvents: "auto", ...a.style } }) });
  }), da = "DialogContent", s1 = y.forwardRef((e, t) => {
    const r = o1(da, e.__scopeDialog), { forceMount: a = r.forceMount, ...s } = e, l = Yn(da, e.__scopeDialog);
    return b.jsx(qn, { present: a || l.open, children: l.modal ? b.jsx(Ck, { ...s, ref: t }) : b.jsx(Tk, { ...s, ref: t }) });
  });
  s1.displayName = da;
  var Ck = y.forwardRef((e, t) => {
    const r = Yn(da, e.__scopeDialog), a = y.useRef(null), s = Ne(t, r.contentRef, a);
    return y.useEffect(() => {
      const l = a.current;
      if (l) return Jx(l);
    }, []), b.jsx(l1, { ...e, ref: s, trapFocus: r.open, disableOutsidePointerEvents: true, onCloseAutoFocus: Ee(e.onCloseAutoFocus, (l) => {
      var _a4;
      l.preventDefault(), (_a4 = r.triggerRef.current) == null ? void 0 : _a4.focus();
    }), onPointerDownOutside: Ee(e.onPointerDownOutside, (l) => {
      const u = l.detail.originalEvent, f = u.button === 0 && u.ctrlKey === true;
      (u.button === 2 || f) && l.preventDefault();
    }), onFocusOutside: Ee(e.onFocusOutside, (l) => l.preventDefault()) });
  }), Tk = y.forwardRef((e, t) => {
    const r = Yn(da, e.__scopeDialog), a = y.useRef(false), s = y.useRef(false);
    return b.jsx(l1, { ...e, ref: t, trapFocus: false, disableOutsidePointerEvents: false, onCloseAutoFocus: (l) => {
      var _a4, _b2;
      (_a4 = e.onCloseAutoFocus) == null ? void 0 : _a4.call(e, l), l.defaultPrevented || (a.current || ((_b2 = r.triggerRef.current) == null ? void 0 : _b2.focus()), l.preventDefault()), a.current = false, s.current = false;
    }, onInteractOutside: (l) => {
      var _a4, _b2;
      (_a4 = e.onInteractOutside) == null ? void 0 : _a4.call(e, l), l.defaultPrevented || (a.current = true, l.detail.originalEvent.type === "pointerdown" && (s.current = true));
      const u = l.target;
      ((_b2 = r.triggerRef.current) == null ? void 0 : _b2.contains(u)) && l.preventDefault(), l.detail.originalEvent.type === "focusin" && s.current && l.preventDefault();
    } });
  }), l1 = y.forwardRef((e, t) => {
    const { __scopeDialog: r, trapFocus: a, onOpenAutoFocus: s, onCloseAutoFocus: l, ...u } = e, f = Yn(da, r), p = y.useRef(null), m = Ne(t, p);
    return Vx(), b.jsxs(b.Fragment, { children: [b.jsx(hm, { asChild: true, loop: true, trapped: a, onMountAutoFocus: s, onUnmountAutoFocus: l, children: b.jsx(Lu, { role: "dialog", id: f.contentId, "aria-describedby": f.descriptionId, "aria-labelledby": f.titleId, "data-state": vm(f.open), ...u, ref: m, onDismiss: () => f.onOpenChange(false) }) }), b.jsxs(b.Fragment, { children: [b.jsx(Rk, { titleId: f.titleId }), b.jsx(Nk, { contentRef: p, descriptionId: f.descriptionId })] })] });
  }), gm = "DialogTitle", c1 = y.forwardRef((e, t) => {
    const { __scopeDialog: r, ...a } = e, s = Yn(gm, r);
    return b.jsx(Te.h2, { id: s.titleId, ...a, ref: t });
  });
  c1.displayName = gm;
  var u1 = "DialogDescription", f1 = y.forwardRef((e, t) => {
    const { __scopeDialog: r, ...a } = e, s = Yn(u1, r);
    return b.jsx(Te.p, { id: s.descriptionId, ...a, ref: t });
  });
  f1.displayName = u1;
  var d1 = "DialogClose", h1 = y.forwardRef((e, t) => {
    const { __scopeDialog: r, ...a } = e, s = Yn(d1, r);
    return b.jsx(Te.button, { type: "button", ...a, ref: t, onClick: Ee(e.onClick, () => s.onOpenChange(false)) });
  });
  h1.displayName = d1;
  function vm(e) {
    return e ? "open" : "closed";
  }
  var p1 = "DialogTitleWarning", [Ok, m1] = Kj(p1, { contentName: da, titleName: gm, docsSlug: "dialog" }), Rk = ({ titleId: e }) => {
    const t = m1(p1), r = `\`${t.contentName}\` requires a \`${t.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${t.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${t.docsSlug}`;
    return y.useEffect(() => {
      e && (document.getElementById(e) || console.error(r));
    }, [r, e]), null;
  }, Mk = "DialogDescriptionWarning", Nk = ({ contentRef: e, descriptionId: t }) => {
    const a = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${m1(Mk).contentName}}.`;
    return y.useEffect(() => {
      var _a4;
      const s = (_a4 = e.current) == null ? void 0 : _a4.getAttribute("aria-describedby");
      t && s && (document.getElementById(t) || console.warn(a));
    }, [a, e, t]), null;
  }, g1 = t1, v1 = r1, y1 = a1, b1 = i1, w1 = s1, zk = c1, Dk = f1, S1 = h1;
  const x1 = (...e) => e.filter((t, r, a) => !!t && t.trim() !== "" && a.indexOf(t) === r).join(" ").trim();
  const jk = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
  const kk = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (t, r, a) => a ? a.toUpperCase() : r.toLowerCase());
  const ww = (e) => {
    const t = kk(e);
    return t.charAt(0).toUpperCase() + t.slice(1);
  };
  var Pk = { xmlns: "http://www.w3.org/2000/svg", width: 24, height: 24, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" };
  const Lk = (e) => {
    for (const t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return true;
    return false;
  };
  const Uk = y.forwardRef(({ color: e = "currentColor", size: t = 24, strokeWidth: r = 2, absoluteStrokeWidth: a, className: s = "", children: l, iconNode: u, ...f }, p) => y.createElement("svg", { ref: p, ...Pk, width: t, height: t, stroke: e, strokeWidth: a ? Number(r) * 24 / Number(t) : r, className: x1("lucide", s), ...!l && !Lk(f) && { "aria-hidden": "true" }, ...f }, [...u.map(([m, v]) => y.createElement(m, v)), ...Array.isArray(l) ? l : [l]]));
  const At = (e, t) => {
    const r = y.forwardRef(({ className: a, ...s }, l) => y.createElement(Uk, { ref: l, iconNode: t, className: x1(`lucide-${jk(ww(e))}`, `lucide-${e}`, a), ...s }));
    return r.displayName = ww(e), r;
  };
  const Bk = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]], ym = At("chevron-down", Bk);
  const Ik = [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]], Hk = At("chevron-up", Ik);
  const $k = [["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]], Vk = At("circle", $k);
  const Zk = [["path", { d: "m16 18 6-6-6-6", key: "eg8j8" }], ["path", { d: "m8 6-6 6 6 6", key: "ppft3o" }]], Fk = At("code", Zk);
  const qk = [["path", { d: "M12 15V3", key: "m9g1x1" }], ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }], ["path", { d: "m7 10 5 5 5-5", key: "brsn70" }]], Yk = At("download", qk);
  const Xk = [["path", { d: "m15 15 6 6", key: "1s409w" }], ["path", { d: "m15 9 6-6", key: "ko1vev" }], ["path", { d: "M21 16v5h-5", key: "1ck2sf" }], ["path", { d: "M21 8V3h-5", key: "1qoq8a" }], ["path", { d: "M3 16v5h5", key: "1t08am" }], ["path", { d: "m3 21 6-6", key: "wwnumi" }], ["path", { d: "M3 8V3h5", key: "1ln10m" }], ["path", { d: "M9 9 3 3", key: "v551iv" }]], Qk = At("expand", Xk);
  const Gk = [["path", { d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2", key: "usdka0" }]], Kk = At("folder-open", Gk);
  const Jk = [["path", { d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z", key: "1kt360" }]], Wk = At("folder", Jk);
  const e5 = [["path", { d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5", key: "mvr1a0" }]], t5 = At("heart", e5);
  const n5 = [["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }], ["path", { d: "M12 16v-4", key: "1dtifu" }], ["path", { d: "M12 8h.01", key: "e9boi3" }]], Ys = At("info", n5);
  const r5 = [["path", { d: "M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z", key: "e79jfc" }], ["circle", { cx: "13.5", cy: "6.5", r: ".5", fill: "currentColor", key: "1okk4w" }], ["circle", { cx: "17.5", cy: "10.5", r: ".5", fill: "currentColor", key: "f64h9f" }], ["circle", { cx: "6.5", cy: "12.5", r: ".5", fill: "currentColor", key: "qy21gx" }], ["circle", { cx: "8.5", cy: "7.5", r: ".5", fill: "currentColor", key: "fotxhn" }]], o5 = At("palette", r5);
  const a5 = [["path", { d: "m21 21-4.34-4.34", key: "14j7rj" }], ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }]], i5 = At("search", a5);
  const s5 = [["path", { d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915", key: "1i5ecw" }], ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]], l5 = At("settings", s5);
  const c5 = [["path", { d: "m10 20-1.25-2.5L6 18", key: "18frcb" }], ["path", { d: "M10 4 8.75 6.5 6 6", key: "7mghy3" }], ["path", { d: "m14 20 1.25-2.5L18 18", key: "1chtki" }], ["path", { d: "m14 4 1.25 2.5L18 6", key: "1b4wsy" }], ["path", { d: "m17 21-3-6h-4", key: "15hhxa" }], ["path", { d: "m17 3-3 6 1.5 3", key: "11697g" }], ["path", { d: "M2 12h6.5L10 9", key: "kv9z4n" }], ["path", { d: "m20 10-1.5 2 1.5 2", key: "1swlpi" }], ["path", { d: "M22 12h-6.5L14 15", key: "1mxi28" }], ["path", { d: "m4 10 1.5 2L4 14", key: "k9enpj" }], ["path", { d: "m7 21 3-6-1.5-3", key: "j8hb9u" }], ["path", { d: "m7 3 3 6h4", key: "1otusx" }]], u5 = At("snowflake", c5);
  const f5 = [["path", { d: "M14.5 2v17.5c0 1.4-1.1 2.5-2.5 2.5c-1.4 0-2.5-1.1-2.5-2.5V2", key: "125lnx" }], ["path", { d: "M8.5 2h7", key: "csnxdl" }], ["path", { d: "M14.5 16h-5", key: "1ox875" }]], d5 = At("test-tube", f5);
  const h5 = [["path", { d: "M10 11v6", key: "nco0om" }], ["path", { d: "M14 11v6", key: "outv1u" }], ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }], ["path", { d: "M3 6h18", key: "d0wm0j" }], ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]], p5 = At("trash-2", h5);
  const m5 = [["path", { d: "M12 4v16", key: "1654pz" }], ["path", { d: "M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2", key: "e0r10z" }], ["path", { d: "M9 20h6", key: "s66wpe" }]], g5 = At("type", m5);
  const v5 = [["path", { d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z", key: "uqj9uw" }], ["path", { d: "M16 9a5 5 0 0 1 0 6", key: "1q6k2b" }], ["path", { d: "M19.364 18.364a9 9 0 0 0 0-12.728", key: "ijwkga" }]], y5 = At("volume-2", v5);
  function _1(e) {
    var t, r, a = "";
    if (typeof e == "string" || typeof e == "number") a += e;
    else if (typeof e == "object") if (Array.isArray(e)) {
      var s = e.length;
      for (t = 0; t < s; t++) e[t] && (r = _1(e[t])) && (a && (a += " "), a += r);
    } else for (r in e) e[r] && (a && (a += " "), a += r);
    return a;
  }
  function E1() {
    for (var e, t, r = 0, a = "", s = arguments.length; r < s; r++) (e = arguments[r]) && (t = _1(e)) && (a && (a += " "), a += t);
    return a;
  }
  const b5 = (e, t) => {
    const r = new Array(e.length + t.length);
    for (let a = 0; a < e.length; a++) r[a] = e[a];
    for (let a = 0; a < t.length; a++) r[e.length + a] = t[a];
    return r;
  }, w5 = (e, t) => ({ classGroupId: e, validator: t }), A1 = (e = /* @__PURE__ */ new Map(), t = null, r) => ({ nextPart: e, validators: t, classGroupId: r }), iu = "-", Sw = [], S5 = "arbitrary..", x5 = (e) => {
    const t = E5(e), { conflictingClassGroups: r, conflictingClassGroupModifiers: a } = e;
    return { getClassGroupId: (u) => {
      if (u.startsWith("[") && u.endsWith("]")) return _5(u);
      const f = u.split(iu), p = f[0] === "" && f.length > 1 ? 1 : 0;
      return C1(f, p, t);
    }, getConflictingClassGroupIds: (u, f) => {
      if (f) {
        const p = a[u], m = r[u];
        return p ? m ? b5(m, p) : p : m || Sw;
      }
      return r[u] || Sw;
    } };
  }, C1 = (e, t, r) => {
    if (e.length - t === 0) return r.classGroupId;
    const s = e[t], l = r.nextPart.get(s);
    if (l) {
      const m = C1(e, t + 1, l);
      if (m) return m;
    }
    const u = r.validators;
    if (u === null) return;
    const f = t === 0 ? e.join(iu) : e.slice(t).join(iu), p = u.length;
    for (let m = 0; m < p; m++) {
      const v = u[m];
      if (v.validator(f)) return v.classGroupId;
    }
  }, _5 = (e) => e.slice(1, -1).indexOf(":") === -1 ? void 0 : (() => {
    const t = e.slice(1, -1), r = t.indexOf(":"), a = t.slice(0, r);
    return a ? S5 + a : void 0;
  })(), E5 = (e) => {
    const { theme: t, classGroups: r } = e;
    return A5(r, t);
  }, A5 = (e, t) => {
    const r = A1();
    for (const a in e) {
      const s = e[a];
      bm(s, r, a, t);
    }
    return r;
  }, bm = (e, t, r, a) => {
    const s = e.length;
    for (let l = 0; l < s; l++) {
      const u = e[l];
      C5(u, t, r, a);
    }
  }, C5 = (e, t, r, a) => {
    if (typeof e == "string") {
      T5(e, t, r);
      return;
    }
    if (typeof e == "function") {
      O5(e, t, r, a);
      return;
    }
    R5(e, t, r, a);
  }, T5 = (e, t, r) => {
    const a = e === "" ? t : T1(t, e);
    a.classGroupId = r;
  }, O5 = (e, t, r, a) => {
    if (M5(e)) {
      bm(e(a), t, r, a);
      return;
    }
    t.validators === null && (t.validators = []), t.validators.push(w5(r, e));
  }, R5 = (e, t, r, a) => {
    const s = Object.entries(e), l = s.length;
    for (let u = 0; u < l; u++) {
      const [f, p] = s[u];
      bm(p, T1(t, f), r, a);
    }
  }, T1 = (e, t) => {
    let r = e;
    const a = t.split(iu), s = a.length;
    for (let l = 0; l < s; l++) {
      const u = a[l];
      let f = r.nextPart.get(u);
      f || (f = A1(), r.nextPart.set(u, f)), r = f;
    }
    return r;
  }, M5 = (e) => "isThemeGetter" in e && e.isThemeGetter === true, N5 = (e) => {
    if (e < 1) return { get: () => {
    }, set: () => {
    } };
    let t = 0, r = /* @__PURE__ */ Object.create(null), a = /* @__PURE__ */ Object.create(null);
    const s = (l, u) => {
      r[l] = u, t++, t > e && (t = 0, a = r, r = /* @__PURE__ */ Object.create(null));
    };
    return { get(l) {
      let u = r[l];
      if (u !== void 0) return u;
      if ((u = a[l]) !== void 0) return s(l, u), u;
    }, set(l, u) {
      l in r ? r[l] = u : s(l, u);
    } };
  }, yp = "!", xw = ":", z5 = [], _w = (e, t, r, a, s) => ({ modifiers: e, hasImportantModifier: t, baseClassName: r, maybePostfixModifierPosition: a, isExternal: s }), D5 = (e) => {
    const { prefix: t, experimentalParseClassName: r } = e;
    let a = (s) => {
      const l = [];
      let u = 0, f = 0, p = 0, m;
      const v = s.length;
      for (let E = 0; E < v; E++) {
        const C = s[E];
        if (u === 0 && f === 0) {
          if (C === xw) {
            l.push(s.slice(p, E)), p = E + 1;
            continue;
          }
          if (C === "/") {
            m = E;
            continue;
          }
        }
        C === "[" ? u++ : C === "]" ? u-- : C === "(" ? f++ : C === ")" && f--;
      }
      const g = l.length === 0 ? s : s.slice(p);
      let S = g, _ = false;
      g.endsWith(yp) ? (S = g.slice(0, -1), _ = true) : g.startsWith(yp) && (S = g.slice(1), _ = true);
      const x = m && m > p ? m - p : void 0;
      return _w(l, _, S, x);
    };
    if (t) {
      const s = t + xw, l = a;
      a = (u) => u.startsWith(s) ? l(u.slice(s.length)) : _w(z5, false, u, void 0, true);
    }
    if (r) {
      const s = a;
      a = (l) => r({ className: l, parseClassName: s });
    }
    return a;
  }, j5 = (e) => {
    const t = /* @__PURE__ */ new Map();
    return e.orderSensitiveModifiers.forEach((r, a) => {
      t.set(r, 1e6 + a);
    }), (r) => {
      const a = [];
      let s = [];
      for (let l = 0; l < r.length; l++) {
        const u = r[l], f = u[0] === "[", p = t.has(u);
        f || p ? (s.length > 0 && (s.sort(), a.push(...s), s = []), a.push(u)) : s.push(u);
      }
      return s.length > 0 && (s.sort(), a.push(...s)), a;
    };
  }, k5 = (e) => ({ cache: N5(e.cacheSize), parseClassName: D5(e), sortModifiers: j5(e), ...x5(e) }), P5 = /\s+/, L5 = (e, t) => {
    const { parseClassName: r, getClassGroupId: a, getConflictingClassGroupIds: s, sortModifiers: l } = t, u = [], f = e.trim().split(P5);
    let p = "";
    for (let m = f.length - 1; m >= 0; m -= 1) {
      const v = f[m], { isExternal: g, modifiers: S, hasImportantModifier: _, baseClassName: x, maybePostfixModifierPosition: E } = r(v);
      if (g) {
        p = v + (p.length > 0 ? " " + p : p);
        continue;
      }
      let C = !!E, T = a(C ? x.substring(0, E) : x);
      if (!T) {
        if (!C) {
          p = v + (p.length > 0 ? " " + p : p);
          continue;
        }
        if (T = a(x), !T) {
          p = v + (p.length > 0 ? " " + p : p);
          continue;
        }
        C = false;
      }
      const R = S.length === 0 ? "" : S.length === 1 ? S[0] : l(S).join(":"), O = _ ? R + yp : R, D = O + T;
      if (u.indexOf(D) > -1) continue;
      u.push(D);
      const P = s(T, C);
      for (let L = 0; L < P.length; ++L) {
        const k = P[L];
        u.push(O + k);
      }
      p = v + (p.length > 0 ? " " + p : p);
    }
    return p;
  }, U5 = (...e) => {
    let t = 0, r, a, s = "";
    for (; t < e.length; ) (r = e[t++]) && (a = O1(r)) && (s && (s += " "), s += a);
    return s;
  }, O1 = (e) => {
    if (typeof e == "string") return e;
    let t, r = "";
    for (let a = 0; a < e.length; a++) e[a] && (t = O1(e[a])) && (r && (r += " "), r += t);
    return r;
  }, B5 = (e, ...t) => {
    let r, a, s, l;
    const u = (p) => {
      const m = t.reduce((v, g) => g(v), e());
      return r = k5(m), a = r.cache.get, s = r.cache.set, l = f, f(p);
    }, f = (p) => {
      const m = a(p);
      if (m) return m;
      const v = L5(p, r);
      return s(p, v), v;
    };
    return l = u, (...p) => l(U5(...p));
  }, I5 = [], wt = (e) => {
    const t = (r) => r[e] || I5;
    return t.isThemeGetter = true, t;
  }, R1 = /^\[(?:(\w[\w-]*):)?(.+)\]$/i, M1 = /^\((?:(\w[\w-]*):)?(.+)\)$/i, H5 = /^\d+\/\d+$/, $5 = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/, V5 = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/, Z5 = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/, F5 = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/, q5 = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/, li = (e) => H5.test(e), ze = (e) => !!e && !Number.isNaN(Number(e)), So = (e) => !!e && Number.isInteger(Number(e)), Ih = (e) => e.endsWith("%") && ze(e.slice(0, -1)), Ur = (e) => $5.test(e), Y5 = () => true, X5 = (e) => V5.test(e) && !Z5.test(e), N1 = () => false, Q5 = (e) => F5.test(e), G5 = (e) => q5.test(e), K5 = (e) => !he(e) && !pe(e), J5 = (e) => Ti(e, j1, N1), he = (e) => R1.test(e), ra = (e) => Ti(e, k1, X5), Hh = (e) => Ti(e, rP, ze), Ew = (e) => Ti(e, z1, N1), W5 = (e) => Ti(e, D1, G5), Lc = (e) => Ti(e, P1, Q5), pe = (e) => M1.test(e), zs = (e) => Oi(e, k1), eP = (e) => Oi(e, oP), Aw = (e) => Oi(e, z1), tP = (e) => Oi(e, j1), nP = (e) => Oi(e, D1), Uc = (e) => Oi(e, P1, true), Ti = (e, t, r) => {
    const a = R1.exec(e);
    return a ? a[1] ? t(a[1]) : r(a[2]) : false;
  }, Oi = (e, t, r = false) => {
    const a = M1.exec(e);
    return a ? a[1] ? t(a[1]) : r : false;
  }, z1 = (e) => e === "position" || e === "percentage", D1 = (e) => e === "image" || e === "url", j1 = (e) => e === "length" || e === "size" || e === "bg-size", k1 = (e) => e === "length", rP = (e) => e === "number", oP = (e) => e === "family-name", P1 = (e) => e === "shadow", aP = () => {
    const e = wt("color"), t = wt("font"), r = wt("text"), a = wt("font-weight"), s = wt("tracking"), l = wt("leading"), u = wt("breakpoint"), f = wt("container"), p = wt("spacing"), m = wt("radius"), v = wt("shadow"), g = wt("inset-shadow"), S = wt("text-shadow"), _ = wt("drop-shadow"), x = wt("blur"), E = wt("perspective"), C = wt("aspect"), T = wt("ease"), R = wt("animate"), O = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"], D = () => ["center", "top", "bottom", "left", "right", "top-left", "left-top", "top-right", "right-top", "bottom-right", "right-bottom", "bottom-left", "left-bottom"], P = () => [...D(), pe, he], L = () => ["auto", "hidden", "clip", "visible", "scroll"], k = () => ["auto", "contain", "none"], $ = () => [pe, he, p], re = () => [li, "full", "auto", ...$()], G = () => [So, "none", "subgrid", pe, he], ae = () => ["auto", { span: ["full", So, pe, he] }, So, pe, he], se = () => [So, "auto", pe, he], le = () => ["auto", "min", "max", "fr", pe, he], ue = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"], oe = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"], N = () => ["auto", ...$()], Z = () => [li, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...$()], B = () => [e, pe, he], ce = () => [...D(), Aw, Ew, { position: [pe, he] }], me = () => ["no-repeat", { repeat: ["", "x", "y", "space", "round"] }], M = () => ["auto", "cover", "contain", tP, J5, { size: [pe, he] }], F = () => [Ih, zs, ra], X = () => ["", "none", "full", m, pe, he], J = () => ["", ze, zs, ra], ie = () => ["solid", "dashed", "dotted", "double"], ge = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"], ne = () => [ze, Ih, Aw, Ew], fe = () => ["", "none", x, pe, he], xe = () => ["none", ze, pe, he], Re = () => ["none", ze, pe, he], De = () => [ze, pe, he], Le = () => [li, "full", ...$()];
    return { cacheSize: 500, theme: { animate: ["spin", "ping", "pulse", "bounce"], aspect: ["video"], blur: [Ur], breakpoint: [Ur], color: [Y5], container: [Ur], "drop-shadow": [Ur], ease: ["in", "out", "in-out"], font: [K5], "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"], "inset-shadow": [Ur], leading: ["none", "tight", "snug", "normal", "relaxed", "loose"], perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"], radius: [Ur], shadow: [Ur], spacing: ["px", ze], text: [Ur], "text-shadow": [Ur], tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"] }, classGroups: { aspect: [{ aspect: ["auto", "square", li, he, pe, C] }], container: ["container"], columns: [{ columns: [ze, he, pe, f] }], "break-after": [{ "break-after": O() }], "break-before": [{ "break-before": O() }], "break-inside": [{ "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"] }], "box-decoration": [{ "box-decoration": ["slice", "clone"] }], box: [{ box: ["border", "content"] }], display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"], sr: ["sr-only", "not-sr-only"], float: [{ float: ["right", "left", "none", "start", "end"] }], clear: [{ clear: ["left", "right", "both", "none", "start", "end"] }], isolation: ["isolate", "isolation-auto"], "object-fit": [{ object: ["contain", "cover", "fill", "none", "scale-down"] }], "object-position": [{ object: P() }], overflow: [{ overflow: L() }], "overflow-x": [{ "overflow-x": L() }], "overflow-y": [{ "overflow-y": L() }], overscroll: [{ overscroll: k() }], "overscroll-x": [{ "overscroll-x": k() }], "overscroll-y": [{ "overscroll-y": k() }], position: ["static", "fixed", "absolute", "relative", "sticky"], inset: [{ inset: re() }], "inset-x": [{ "inset-x": re() }], "inset-y": [{ "inset-y": re() }], start: [{ start: re() }], end: [{ end: re() }], top: [{ top: re() }], right: [{ right: re() }], bottom: [{ bottom: re() }], left: [{ left: re() }], visibility: ["visible", "invisible", "collapse"], z: [{ z: [So, "auto", pe, he] }], basis: [{ basis: [li, "full", "auto", f, ...$()] }], "flex-direction": [{ flex: ["row", "row-reverse", "col", "col-reverse"] }], "flex-wrap": [{ flex: ["nowrap", "wrap", "wrap-reverse"] }], flex: [{ flex: [ze, li, "auto", "initial", "none", he] }], grow: [{ grow: ["", ze, pe, he] }], shrink: [{ shrink: ["", ze, pe, he] }], order: [{ order: [So, "first", "last", "none", pe, he] }], "grid-cols": [{ "grid-cols": G() }], "col-start-end": [{ col: ae() }], "col-start": [{ "col-start": se() }], "col-end": [{ "col-end": se() }], "grid-rows": [{ "grid-rows": G() }], "row-start-end": [{ row: ae() }], "row-start": [{ "row-start": se() }], "row-end": [{ "row-end": se() }], "grid-flow": [{ "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"] }], "auto-cols": [{ "auto-cols": le() }], "auto-rows": [{ "auto-rows": le() }], gap: [{ gap: $() }], "gap-x": [{ "gap-x": $() }], "gap-y": [{ "gap-y": $() }], "justify-content": [{ justify: [...ue(), "normal"] }], "justify-items": [{ "justify-items": [...oe(), "normal"] }], "justify-self": [{ "justify-self": ["auto", ...oe()] }], "align-content": [{ content: ["normal", ...ue()] }], "align-items": [{ items: [...oe(), { baseline: ["", "last"] }] }], "align-self": [{ self: ["auto", ...oe(), { baseline: ["", "last"] }] }], "place-content": [{ "place-content": ue() }], "place-items": [{ "place-items": [...oe(), "baseline"] }], "place-self": [{ "place-self": ["auto", ...oe()] }], p: [{ p: $() }], px: [{ px: $() }], py: [{ py: $() }], ps: [{ ps: $() }], pe: [{ pe: $() }], pt: [{ pt: $() }], pr: [{ pr: $() }], pb: [{ pb: $() }], pl: [{ pl: $() }], m: [{ m: N() }], mx: [{ mx: N() }], my: [{ my: N() }], ms: [{ ms: N() }], me: [{ me: N() }], mt: [{ mt: N() }], mr: [{ mr: N() }], mb: [{ mb: N() }], ml: [{ ml: N() }], "space-x": [{ "space-x": $() }], "space-x-reverse": ["space-x-reverse"], "space-y": [{ "space-y": $() }], "space-y-reverse": ["space-y-reverse"], size: [{ size: Z() }], w: [{ w: [f, "screen", ...Z()] }], "min-w": [{ "min-w": [f, "screen", "none", ...Z()] }], "max-w": [{ "max-w": [f, "screen", "none", "prose", { screen: [u] }, ...Z()] }], h: [{ h: ["screen", "lh", ...Z()] }], "min-h": [{ "min-h": ["screen", "lh", "none", ...Z()] }], "max-h": [{ "max-h": ["screen", "lh", ...Z()] }], "font-size": [{ text: ["base", r, zs, ra] }], "font-smoothing": ["antialiased", "subpixel-antialiased"], "font-style": ["italic", "not-italic"], "font-weight": [{ font: [a, pe, Hh] }], "font-stretch": [{ "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", Ih, he] }], "font-family": [{ font: [eP, he, t] }], "fvn-normal": ["normal-nums"], "fvn-ordinal": ["ordinal"], "fvn-slashed-zero": ["slashed-zero"], "fvn-figure": ["lining-nums", "oldstyle-nums"], "fvn-spacing": ["proportional-nums", "tabular-nums"], "fvn-fraction": ["diagonal-fractions", "stacked-fractions"], tracking: [{ tracking: [s, pe, he] }], "line-clamp": [{ "line-clamp": [ze, "none", pe, Hh] }], leading: [{ leading: [l, ...$()] }], "list-image": [{ "list-image": ["none", pe, he] }], "list-style-position": [{ list: ["inside", "outside"] }], "list-style-type": [{ list: ["disc", "decimal", "none", pe, he] }], "text-alignment": [{ text: ["left", "center", "right", "justify", "start", "end"] }], "placeholder-color": [{ placeholder: B() }], "text-color": [{ text: B() }], "text-decoration": ["underline", "overline", "line-through", "no-underline"], "text-decoration-style": [{ decoration: [...ie(), "wavy"] }], "text-decoration-thickness": [{ decoration: [ze, "from-font", "auto", pe, ra] }], "text-decoration-color": [{ decoration: B() }], "underline-offset": [{ "underline-offset": [ze, "auto", pe, he] }], "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"], "text-overflow": ["truncate", "text-ellipsis", "text-clip"], "text-wrap": [{ text: ["wrap", "nowrap", "balance", "pretty"] }], indent: [{ indent: $() }], "vertical-align": [{ align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", pe, he] }], whitespace: [{ whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"] }], break: [{ break: ["normal", "words", "all", "keep"] }], wrap: [{ wrap: ["break-word", "anywhere", "normal"] }], hyphens: [{ hyphens: ["none", "manual", "auto"] }], content: [{ content: ["none", pe, he] }], "bg-attachment": [{ bg: ["fixed", "local", "scroll"] }], "bg-clip": [{ "bg-clip": ["border", "padding", "content", "text"] }], "bg-origin": [{ "bg-origin": ["border", "padding", "content"] }], "bg-position": [{ bg: ce() }], "bg-repeat": [{ bg: me() }], "bg-size": [{ bg: M() }], "bg-image": [{ bg: ["none", { linear: [{ to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"] }, So, pe, he], radial: ["", pe, he], conic: [So, pe, he] }, nP, W5] }], "bg-color": [{ bg: B() }], "gradient-from-pos": [{ from: F() }], "gradient-via-pos": [{ via: F() }], "gradient-to-pos": [{ to: F() }], "gradient-from": [{ from: B() }], "gradient-via": [{ via: B() }], "gradient-to": [{ to: B() }], rounded: [{ rounded: X() }], "rounded-s": [{ "rounded-s": X() }], "rounded-e": [{ "rounded-e": X() }], "rounded-t": [{ "rounded-t": X() }], "rounded-r": [{ "rounded-r": X() }], "rounded-b": [{ "rounded-b": X() }], "rounded-l": [{ "rounded-l": X() }], "rounded-ss": [{ "rounded-ss": X() }], "rounded-se": [{ "rounded-se": X() }], "rounded-ee": [{ "rounded-ee": X() }], "rounded-es": [{ "rounded-es": X() }], "rounded-tl": [{ "rounded-tl": X() }], "rounded-tr": [{ "rounded-tr": X() }], "rounded-br": [{ "rounded-br": X() }], "rounded-bl": [{ "rounded-bl": X() }], "border-w": [{ border: J() }], "border-w-x": [{ "border-x": J() }], "border-w-y": [{ "border-y": J() }], "border-w-s": [{ "border-s": J() }], "border-w-e": [{ "border-e": J() }], "border-w-t": [{ "border-t": J() }], "border-w-r": [{ "border-r": J() }], "border-w-b": [{ "border-b": J() }], "border-w-l": [{ "border-l": J() }], "divide-x": [{ "divide-x": J() }], "divide-x-reverse": ["divide-x-reverse"], "divide-y": [{ "divide-y": J() }], "divide-y-reverse": ["divide-y-reverse"], "border-style": [{ border: [...ie(), "hidden", "none"] }], "divide-style": [{ divide: [...ie(), "hidden", "none"] }], "border-color": [{ border: B() }], "border-color-x": [{ "border-x": B() }], "border-color-y": [{ "border-y": B() }], "border-color-s": [{ "border-s": B() }], "border-color-e": [{ "border-e": B() }], "border-color-t": [{ "border-t": B() }], "border-color-r": [{ "border-r": B() }], "border-color-b": [{ "border-b": B() }], "border-color-l": [{ "border-l": B() }], "divide-color": [{ divide: B() }], "outline-style": [{ outline: [...ie(), "none", "hidden"] }], "outline-offset": [{ "outline-offset": [ze, pe, he] }], "outline-w": [{ outline: ["", ze, zs, ra] }], "outline-color": [{ outline: B() }], shadow: [{ shadow: ["", "none", v, Uc, Lc] }], "shadow-color": [{ shadow: B() }], "inset-shadow": [{ "inset-shadow": ["none", g, Uc, Lc] }], "inset-shadow-color": [{ "inset-shadow": B() }], "ring-w": [{ ring: J() }], "ring-w-inset": ["ring-inset"], "ring-color": [{ ring: B() }], "ring-offset-w": [{ "ring-offset": [ze, ra] }], "ring-offset-color": [{ "ring-offset": B() }], "inset-ring-w": [{ "inset-ring": J() }], "inset-ring-color": [{ "inset-ring": B() }], "text-shadow": [{ "text-shadow": ["none", S, Uc, Lc] }], "text-shadow-color": [{ "text-shadow": B() }], opacity: [{ opacity: [ze, pe, he] }], "mix-blend": [{ "mix-blend": [...ge(), "plus-darker", "plus-lighter"] }], "bg-blend": [{ "bg-blend": ge() }], "mask-clip": [{ "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"] }, "mask-no-clip"], "mask-composite": [{ mask: ["add", "subtract", "intersect", "exclude"] }], "mask-image-linear-pos": [{ "mask-linear": [ze] }], "mask-image-linear-from-pos": [{ "mask-linear-from": ne() }], "mask-image-linear-to-pos": [{ "mask-linear-to": ne() }], "mask-image-linear-from-color": [{ "mask-linear-from": B() }], "mask-image-linear-to-color": [{ "mask-linear-to": B() }], "mask-image-t-from-pos": [{ "mask-t-from": ne() }], "mask-image-t-to-pos": [{ "mask-t-to": ne() }], "mask-image-t-from-color": [{ "mask-t-from": B() }], "mask-image-t-to-color": [{ "mask-t-to": B() }], "mask-image-r-from-pos": [{ "mask-r-from": ne() }], "mask-image-r-to-pos": [{ "mask-r-to": ne() }], "mask-image-r-from-color": [{ "mask-r-from": B() }], "mask-image-r-to-color": [{ "mask-r-to": B() }], "mask-image-b-from-pos": [{ "mask-b-from": ne() }], "mask-image-b-to-pos": [{ "mask-b-to": ne() }], "mask-image-b-from-color": [{ "mask-b-from": B() }], "mask-image-b-to-color": [{ "mask-b-to": B() }], "mask-image-l-from-pos": [{ "mask-l-from": ne() }], "mask-image-l-to-pos": [{ "mask-l-to": ne() }], "mask-image-l-from-color": [{ "mask-l-from": B() }], "mask-image-l-to-color": [{ "mask-l-to": B() }], "mask-image-x-from-pos": [{ "mask-x-from": ne() }], "mask-image-x-to-pos": [{ "mask-x-to": ne() }], "mask-image-x-from-color": [{ "mask-x-from": B() }], "mask-image-x-to-color": [{ "mask-x-to": B() }], "mask-image-y-from-pos": [{ "mask-y-from": ne() }], "mask-image-y-to-pos": [{ "mask-y-to": ne() }], "mask-image-y-from-color": [{ "mask-y-from": B() }], "mask-image-y-to-color": [{ "mask-y-to": B() }], "mask-image-radial": [{ "mask-radial": [pe, he] }], "mask-image-radial-from-pos": [{ "mask-radial-from": ne() }], "mask-image-radial-to-pos": [{ "mask-radial-to": ne() }], "mask-image-radial-from-color": [{ "mask-radial-from": B() }], "mask-image-radial-to-color": [{ "mask-radial-to": B() }], "mask-image-radial-shape": [{ "mask-radial": ["circle", "ellipse"] }], "mask-image-radial-size": [{ "mask-radial": [{ closest: ["side", "corner"], farthest: ["side", "corner"] }] }], "mask-image-radial-pos": [{ "mask-radial-at": D() }], "mask-image-conic-pos": [{ "mask-conic": [ze] }], "mask-image-conic-from-pos": [{ "mask-conic-from": ne() }], "mask-image-conic-to-pos": [{ "mask-conic-to": ne() }], "mask-image-conic-from-color": [{ "mask-conic-from": B() }], "mask-image-conic-to-color": [{ "mask-conic-to": B() }], "mask-mode": [{ mask: ["alpha", "luminance", "match"] }], "mask-origin": [{ "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"] }], "mask-position": [{ mask: ce() }], "mask-repeat": [{ mask: me() }], "mask-size": [{ mask: M() }], "mask-type": [{ "mask-type": ["alpha", "luminance"] }], "mask-image": [{ mask: ["none", pe, he] }], filter: [{ filter: ["", "none", pe, he] }], blur: [{ blur: fe() }], brightness: [{ brightness: [ze, pe, he] }], contrast: [{ contrast: [ze, pe, he] }], "drop-shadow": [{ "drop-shadow": ["", "none", _, Uc, Lc] }], "drop-shadow-color": [{ "drop-shadow": B() }], grayscale: [{ grayscale: ["", ze, pe, he] }], "hue-rotate": [{ "hue-rotate": [ze, pe, he] }], invert: [{ invert: ["", ze, pe, he] }], saturate: [{ saturate: [ze, pe, he] }], sepia: [{ sepia: ["", ze, pe, he] }], "backdrop-filter": [{ "backdrop-filter": ["", "none", pe, he] }], "backdrop-blur": [{ "backdrop-blur": fe() }], "backdrop-brightness": [{ "backdrop-brightness": [ze, pe, he] }], "backdrop-contrast": [{ "backdrop-contrast": [ze, pe, he] }], "backdrop-grayscale": [{ "backdrop-grayscale": ["", ze, pe, he] }], "backdrop-hue-rotate": [{ "backdrop-hue-rotate": [ze, pe, he] }], "backdrop-invert": [{ "backdrop-invert": ["", ze, pe, he] }], "backdrop-opacity": [{ "backdrop-opacity": [ze, pe, he] }], "backdrop-saturate": [{ "backdrop-saturate": [ze, pe, he] }], "backdrop-sepia": [{ "backdrop-sepia": ["", ze, pe, he] }], "border-collapse": [{ border: ["collapse", "separate"] }], "border-spacing": [{ "border-spacing": $() }], "border-spacing-x": [{ "border-spacing-x": $() }], "border-spacing-y": [{ "border-spacing-y": $() }], "table-layout": [{ table: ["auto", "fixed"] }], caption: [{ caption: ["top", "bottom"] }], transition: [{ transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", pe, he] }], "transition-behavior": [{ transition: ["normal", "discrete"] }], duration: [{ duration: [ze, "initial", pe, he] }], ease: [{ ease: ["linear", "initial", T, pe, he] }], delay: [{ delay: [ze, pe, he] }], animate: [{ animate: ["none", R, pe, he] }], backface: [{ backface: ["hidden", "visible"] }], perspective: [{ perspective: [E, pe, he] }], "perspective-origin": [{ "perspective-origin": P() }], rotate: [{ rotate: xe() }], "rotate-x": [{ "rotate-x": xe() }], "rotate-y": [{ "rotate-y": xe() }], "rotate-z": [{ "rotate-z": xe() }], scale: [{ scale: Re() }], "scale-x": [{ "scale-x": Re() }], "scale-y": [{ "scale-y": Re() }], "scale-z": [{ "scale-z": Re() }], "scale-3d": ["scale-3d"], skew: [{ skew: De() }], "skew-x": [{ "skew-x": De() }], "skew-y": [{ "skew-y": De() }], transform: [{ transform: [pe, he, "", "none", "gpu", "cpu"] }], "transform-origin": [{ origin: P() }], "transform-style": [{ transform: ["3d", "flat"] }], translate: [{ translate: Le() }], "translate-x": [{ "translate-x": Le() }], "translate-y": [{ "translate-y": Le() }], "translate-z": [{ "translate-z": Le() }], "translate-none": ["translate-none"], accent: [{ accent: B() }], appearance: [{ appearance: ["none", "auto"] }], "caret-color": [{ caret: B() }], "color-scheme": [{ scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"] }], cursor: [{ cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", pe, he] }], "field-sizing": [{ "field-sizing": ["fixed", "content"] }], "pointer-events": [{ "pointer-events": ["auto", "none"] }], resize: [{ resize: ["none", "", "y", "x"] }], "scroll-behavior": [{ scroll: ["auto", "smooth"] }], "scroll-m": [{ "scroll-m": $() }], "scroll-mx": [{ "scroll-mx": $() }], "scroll-my": [{ "scroll-my": $() }], "scroll-ms": [{ "scroll-ms": $() }], "scroll-me": [{ "scroll-me": $() }], "scroll-mt": [{ "scroll-mt": $() }], "scroll-mr": [{ "scroll-mr": $() }], "scroll-mb": [{ "scroll-mb": $() }], "scroll-ml": [{ "scroll-ml": $() }], "scroll-p": [{ "scroll-p": $() }], "scroll-px": [{ "scroll-px": $() }], "scroll-py": [{ "scroll-py": $() }], "scroll-ps": [{ "scroll-ps": $() }], "scroll-pe": [{ "scroll-pe": $() }], "scroll-pt": [{ "scroll-pt": $() }], "scroll-pr": [{ "scroll-pr": $() }], "scroll-pb": [{ "scroll-pb": $() }], "scroll-pl": [{ "scroll-pl": $() }], "snap-align": [{ snap: ["start", "end", "center", "align-none"] }], "snap-stop": [{ snap: ["normal", "always"] }], "snap-type": [{ snap: ["none", "x", "y", "both"] }], "snap-strictness": [{ snap: ["mandatory", "proximity"] }], touch: [{ touch: ["auto", "none", "manipulation"] }], "touch-x": [{ "touch-pan": ["x", "left", "right"] }], "touch-y": [{ "touch-pan": ["y", "up", "down"] }], "touch-pz": ["touch-pinch-zoom"], select: [{ select: ["none", "text", "all", "auto"] }], "will-change": [{ "will-change": ["auto", "scroll", "contents", "transform", pe, he] }], fill: [{ fill: ["none", ...B()] }], "stroke-w": [{ stroke: [ze, zs, ra, Hh] }], stroke: [{ stroke: ["none", ...B()] }], "forced-color-adjust": [{ "forced-color-adjust": ["auto", "none"] }] }, conflictingClassGroups: { overflow: ["overflow-x", "overflow-y"], overscroll: ["overscroll-x", "overscroll-y"], inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"], "inset-x": ["right", "left"], "inset-y": ["top", "bottom"], flex: ["basis", "grow", "shrink"], gap: ["gap-x", "gap-y"], p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"], px: ["pr", "pl"], py: ["pt", "pb"], m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"], mx: ["mr", "ml"], my: ["mt", "mb"], size: ["w", "h"], "font-size": ["leading"], "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"], "fvn-ordinal": ["fvn-normal"], "fvn-slashed-zero": ["fvn-normal"], "fvn-figure": ["fvn-normal"], "fvn-spacing": ["fvn-normal"], "fvn-fraction": ["fvn-normal"], "line-clamp": ["display", "overflow"], rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"], "rounded-s": ["rounded-ss", "rounded-es"], "rounded-e": ["rounded-se", "rounded-ee"], "rounded-t": ["rounded-tl", "rounded-tr"], "rounded-r": ["rounded-tr", "rounded-br"], "rounded-b": ["rounded-br", "rounded-bl"], "rounded-l": ["rounded-tl", "rounded-bl"], "border-spacing": ["border-spacing-x", "border-spacing-y"], "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"], "border-w-x": ["border-w-r", "border-w-l"], "border-w-y": ["border-w-t", "border-w-b"], "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"], "border-color-x": ["border-color-r", "border-color-l"], "border-color-y": ["border-color-t", "border-color-b"], translate: ["translate-x", "translate-y", "translate-none"], "translate-none": ["translate", "translate-x", "translate-y", "translate-z"], "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"], "scroll-mx": ["scroll-mr", "scroll-ml"], "scroll-my": ["scroll-mt", "scroll-mb"], "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"], "scroll-px": ["scroll-pr", "scroll-pl"], "scroll-py": ["scroll-pt", "scroll-pb"], touch: ["touch-x", "touch-y", "touch-pz"], "touch-x": ["touch"], "touch-y": ["touch"], "touch-pz": ["touch"] }, conflictingClassGroupModifiers: { "font-size": ["leading"] }, orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"] };
  }, iP = B5(aP);
  function Pe(...e) {
    return iP(E1(e));
  }
  function sP({ ...e }) {
    return b.jsx(g1, { "data-slot": "sheet", ...e });
  }
  function lP({ ...e }) {
    return b.jsx(v1, { "data-slot": "sheet-trigger", ...e });
  }
  function cP({ ...e }) {
    return b.jsx(y1, { "data-slot": "sheet-portal", ...e });
  }
  function uP({ className: e, ...t }) {
    return b.jsx(b1, { "data-slot": "sheet-overlay", className: Pe("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-[99990] bg-black/50", e), style: { top: "var(--ym-spacer-size-xxxl)" }, ...t });
  }
  function fP({ className: e, children: t, side: r = "right", ...a }) {
    return b.jsxs(cP, { children: [b.jsx(uP, {}), b.jsx(w1, { "data-slot": "sheet-content", className: Pe("bg-background data-[state=open]:animate-in data-[state=closed]:animate-out fixed z-[99991] flex flex-col shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500", r === "right" && "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-full border-l lg:w-3/4 lg:max-w-sm", r === "left" && "data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-full lg:w-3/4 lg:max-w-sm", r === "top" && "data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b", r === "bottom" && "data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t", e), ...a, children: t })] });
  }
  var dP = y.createContext(void 0);
  function Hu(e) {
    const t = y.useContext(dP);
    return e || t || "ltr";
  }
  function Xs(e, [t, r]) {
    return Math.min(r, Math.max(t, e));
  }
  function hP(e, t) {
    return y.useReducer((r, a) => {
      var _a4;
      return (_a4 = t[r][a]) != null ? _a4 : r;
    }, e);
  }
  var wm = "ScrollArea", [L1, OI] = Fn(wm), [pP, Dn] = L1(wm), U1 = y.forwardRef((e, t) => {
    const { __scopeScrollArea: r, type: a = "hover", dir: s, scrollHideDelay: l = 600, ...u } = e, [f, p] = y.useState(null), [m, v] = y.useState(null), [g, S] = y.useState(null), [_, x] = y.useState(null), [E, C] = y.useState(null), [T, R] = y.useState(0), [O, D] = y.useState(0), [P, L] = y.useState(false), [k, $] = y.useState(false), re = Ne(t, (ae) => p(ae)), G = Hu(s);
    return b.jsx(pP, { scope: r, type: a, dir: G, scrollHideDelay: l, scrollArea: f, viewport: m, onViewportChange: v, content: g, onContentChange: S, scrollbarX: _, onScrollbarXChange: x, scrollbarXEnabled: P, onScrollbarXEnabledChange: L, scrollbarY: E, onScrollbarYChange: C, scrollbarYEnabled: k, onScrollbarYEnabledChange: $, onCornerWidthChange: R, onCornerHeightChange: D, children: b.jsx(Te.div, { dir: G, ...u, ref: re, style: { position: "relative", "--radix-scroll-area-corner-width": T + "px", "--radix-scroll-area-corner-height": O + "px", ...e.style } }) });
  });
  U1.displayName = wm;
  var B1 = "ScrollAreaViewport", I1 = y.forwardRef((e, t) => {
    const { __scopeScrollArea: r, children: a, nonce: s, ...l } = e, u = Dn(B1, r), f = y.useRef(null), p = Ne(t, f, u.onViewportChange);
    return b.jsxs(b.Fragment, { children: [b.jsx("style", { dangerouslySetInnerHTML: { __html: "[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}" }, nonce: s }), b.jsx(Te.div, { "data-radix-scroll-area-viewport": "", ...l, ref: p, style: { overflowX: u.scrollbarXEnabled ? "scroll" : "hidden", overflowY: u.scrollbarYEnabled ? "scroll" : "hidden", ...e.style }, children: b.jsx("div", { ref: u.onContentChange, style: { minWidth: "100%", display: "table" }, children: a }) })] });
  });
  I1.displayName = B1;
  var pr = "ScrollAreaScrollbar", H1 = y.forwardRef((e, t) => {
    const { forceMount: r, ...a } = e, s = Dn(pr, e.__scopeScrollArea), { onScrollbarXEnabledChange: l, onScrollbarYEnabledChange: u } = s, f = e.orientation === "horizontal";
    return y.useEffect(() => (f ? l(true) : u(true), () => {
      f ? l(false) : u(false);
    }), [f, l, u]), s.type === "hover" ? b.jsx(mP, { ...a, ref: t, forceMount: r }) : s.type === "scroll" ? b.jsx(gP, { ...a, ref: t, forceMount: r }) : s.type === "auto" ? b.jsx($1, { ...a, ref: t, forceMount: r }) : s.type === "always" ? b.jsx(Sm, { ...a, ref: t }) : null;
  });
  H1.displayName = pr;
  var mP = y.forwardRef((e, t) => {
    const { forceMount: r, ...a } = e, s = Dn(pr, e.__scopeScrollArea), [l, u] = y.useState(false);
    return y.useEffect(() => {
      const f = s.scrollArea;
      let p = 0;
      if (f) {
        const m = () => {
          window.clearTimeout(p), u(true);
        }, v = () => {
          p = window.setTimeout(() => u(false), s.scrollHideDelay);
        };
        return f.addEventListener("pointerenter", m), f.addEventListener("pointerleave", v), () => {
          window.clearTimeout(p), f.removeEventListener("pointerenter", m), f.removeEventListener("pointerleave", v);
        };
      }
    }, [s.scrollArea, s.scrollHideDelay]), b.jsx(qn, { present: r || l, children: b.jsx($1, { "data-state": l ? "visible" : "hidden", ...a, ref: t }) });
  }), gP = y.forwardRef((e, t) => {
    const { forceMount: r, ...a } = e, s = Dn(pr, e.__scopeScrollArea), l = e.orientation === "horizontal", u = Vu(() => p("SCROLL_END"), 100), [f, p] = hP("hidden", { hidden: { SCROLL: "scrolling" }, scrolling: { SCROLL_END: "idle", POINTER_ENTER: "interacting" }, interacting: { SCROLL: "interacting", POINTER_LEAVE: "idle" }, idle: { HIDE: "hidden", SCROLL: "scrolling", POINTER_ENTER: "interacting" } });
    return y.useEffect(() => {
      if (f === "idle") {
        const m = window.setTimeout(() => p("HIDE"), s.scrollHideDelay);
        return () => window.clearTimeout(m);
      }
    }, [f, s.scrollHideDelay, p]), y.useEffect(() => {
      const m = s.viewport, v = l ? "scrollLeft" : "scrollTop";
      if (m) {
        let g = m[v];
        const S = () => {
          const _ = m[v];
          g !== _ && (p("SCROLL"), u()), g = _;
        };
        return m.addEventListener("scroll", S), () => m.removeEventListener("scroll", S);
      }
    }, [s.viewport, l, p, u]), b.jsx(qn, { present: r || f !== "hidden", children: b.jsx(Sm, { "data-state": f === "hidden" ? "hidden" : "visible", ...a, ref: t, onPointerEnter: Ee(e.onPointerEnter, () => p("POINTER_ENTER")), onPointerLeave: Ee(e.onPointerLeave, () => p("POINTER_LEAVE")) }) });
  }), $1 = y.forwardRef((e, t) => {
    const r = Dn(pr, e.__scopeScrollArea), { forceMount: a, ...s } = e, [l, u] = y.useState(false), f = e.orientation === "horizontal", p = Vu(() => {
      if (r.viewport) {
        const m = r.viewport.offsetWidth < r.viewport.scrollWidth, v = r.viewport.offsetHeight < r.viewport.scrollHeight;
        u(f ? m : v);
      }
    }, 10);
    return wi(r.viewport, p), wi(r.content, p), b.jsx(qn, { present: a || l, children: b.jsx(Sm, { "data-state": l ? "visible" : "hidden", ...s, ref: t }) });
  }), Sm = y.forwardRef((e, t) => {
    const { orientation: r = "vertical", ...a } = e, s = Dn(pr, e.__scopeScrollArea), l = y.useRef(null), u = y.useRef(0), [f, p] = y.useState({ content: 0, viewport: 0, scrollbar: { size: 0, paddingStart: 0, paddingEnd: 0 } }), m = Y1(f.viewport, f.content), v = { ...a, sizes: f, onSizesChange: p, hasThumb: m > 0 && m < 1, onThumbChange: (S) => l.current = S, onThumbPointerUp: () => u.current = 0, onThumbPointerDown: (S) => u.current = S };
    function g(S, _) {
      return xP(S, u.current, f, _);
    }
    return r === "horizontal" ? b.jsx(vP, { ...v, ref: t, onThumbPositionChange: () => {
      if (s.viewport && l.current) {
        const S = s.viewport.scrollLeft, _ = Cw(S, f, s.dir);
        l.current.style.transform = `translate3d(${_}px, 0, 0)`;
      }
    }, onWheelScroll: (S) => {
      s.viewport && (s.viewport.scrollLeft = S);
    }, onDragScroll: (S) => {
      s.viewport && (s.viewport.scrollLeft = g(S, s.dir));
    } }) : r === "vertical" ? b.jsx(yP, { ...v, ref: t, onThumbPositionChange: () => {
      if (s.viewport && l.current) {
        const S = s.viewport.scrollTop, _ = Cw(S, f);
        l.current.style.transform = `translate3d(0, ${_}px, 0)`;
      }
    }, onWheelScroll: (S) => {
      s.viewport && (s.viewport.scrollTop = S);
    }, onDragScroll: (S) => {
      s.viewport && (s.viewport.scrollTop = g(S));
    } }) : null;
  }), vP = y.forwardRef((e, t) => {
    const { sizes: r, onSizesChange: a, ...s } = e, l = Dn(pr, e.__scopeScrollArea), [u, f] = y.useState(), p = y.useRef(null), m = Ne(t, p, l.onScrollbarXChange);
    return y.useEffect(() => {
      p.current && f(getComputedStyle(p.current));
    }, [p]), b.jsx(Z1, { "data-orientation": "horizontal", ...s, ref: m, sizes: r, style: { bottom: 0, left: l.dir === "rtl" ? "var(--radix-scroll-area-corner-width)" : 0, right: l.dir === "ltr" ? "var(--radix-scroll-area-corner-width)" : 0, "--radix-scroll-area-thumb-width": $u(r) + "px", ...e.style }, onThumbPointerDown: (v) => e.onThumbPointerDown(v.x), onDragScroll: (v) => e.onDragScroll(v.x), onWheelScroll: (v, g) => {
      if (l.viewport) {
        const S = l.viewport.scrollLeft + v.deltaX;
        e.onWheelScroll(S), Q1(S, g) && v.preventDefault();
      }
    }, onResize: () => {
      p.current && l.viewport && u && a({ content: l.viewport.scrollWidth, viewport: l.viewport.offsetWidth, scrollbar: { size: p.current.clientWidth, paddingStart: lu(u.paddingLeft), paddingEnd: lu(u.paddingRight) } });
    } });
  }), yP = y.forwardRef((e, t) => {
    const { sizes: r, onSizesChange: a, ...s } = e, l = Dn(pr, e.__scopeScrollArea), [u, f] = y.useState(), p = y.useRef(null), m = Ne(t, p, l.onScrollbarYChange);
    return y.useEffect(() => {
      p.current && f(getComputedStyle(p.current));
    }, [p]), b.jsx(Z1, { "data-orientation": "vertical", ...s, ref: m, sizes: r, style: { top: 0, right: l.dir === "ltr" ? 0 : void 0, left: l.dir === "rtl" ? 0 : void 0, bottom: "var(--radix-scroll-area-corner-height)", "--radix-scroll-area-thumb-height": $u(r) + "px", ...e.style }, onThumbPointerDown: (v) => e.onThumbPointerDown(v.y), onDragScroll: (v) => e.onDragScroll(v.y), onWheelScroll: (v, g) => {
      if (l.viewport) {
        const S = l.viewport.scrollTop + v.deltaY;
        e.onWheelScroll(S), Q1(S, g) && v.preventDefault();
      }
    }, onResize: () => {
      p.current && l.viewport && u && a({ content: l.viewport.scrollHeight, viewport: l.viewport.offsetHeight, scrollbar: { size: p.current.clientHeight, paddingStart: lu(u.paddingTop), paddingEnd: lu(u.paddingBottom) } });
    } });
  }), [bP, V1] = L1(pr), Z1 = y.forwardRef((e, t) => {
    const { __scopeScrollArea: r, sizes: a, hasThumb: s, onThumbChange: l, onThumbPointerUp: u, onThumbPointerDown: f, onThumbPositionChange: p, onDragScroll: m, onWheelScroll: v, onResize: g, ...S } = e, _ = Dn(pr, r), [x, E] = y.useState(null), C = Ne(t, (re) => E(re)), T = y.useRef(null), R = y.useRef(""), O = _.viewport, D = a.content - a.viewport, P = rn(v), L = rn(p), k = Vu(g, 10);
    function $(re) {
      if (T.current) {
        const G = re.clientX - T.current.left, ae = re.clientY - T.current.top;
        m({ x: G, y: ae });
      }
    }
    return y.useEffect(() => {
      const re = (G) => {
        const ae = G.target;
        (x == null ? void 0 : x.contains(ae)) && P(G, D);
      };
      return document.addEventListener("wheel", re, { passive: false }), () => document.removeEventListener("wheel", re, { passive: false });
    }, [O, x, D, P]), y.useEffect(L, [a, L]), wi(x, k), wi(_.content, k), b.jsx(bP, { scope: r, scrollbar: x, hasThumb: s, onThumbChange: rn(l), onThumbPointerUp: rn(u), onThumbPositionChange: L, onThumbPointerDown: rn(f), children: b.jsx(Te.div, { ...S, ref: C, style: { position: "absolute", ...S.style }, onPointerDown: Ee(e.onPointerDown, (re) => {
      re.button === 0 && (re.target.setPointerCapture(re.pointerId), T.current = x.getBoundingClientRect(), R.current = document.body.style.webkitUserSelect, document.body.style.webkitUserSelect = "none", _.viewport && (_.viewport.style.scrollBehavior = "auto"), $(re));
    }), onPointerMove: Ee(e.onPointerMove, $), onPointerUp: Ee(e.onPointerUp, (re) => {
      const G = re.target;
      G.hasPointerCapture(re.pointerId) && G.releasePointerCapture(re.pointerId), document.body.style.webkitUserSelect = R.current, _.viewport && (_.viewport.style.scrollBehavior = ""), T.current = null;
    }) }) });
  }), su = "ScrollAreaThumb", F1 = y.forwardRef((e, t) => {
    const { forceMount: r, ...a } = e, s = V1(su, e.__scopeScrollArea);
    return b.jsx(qn, { present: r || s.hasThumb, children: b.jsx(wP, { ref: t, ...a }) });
  }), wP = y.forwardRef((e, t) => {
    const { __scopeScrollArea: r, style: a, ...s } = e, l = Dn(su, r), u = V1(su, r), { onThumbPositionChange: f } = u, p = Ne(t, (g) => u.onThumbChange(g)), m = y.useRef(void 0), v = Vu(() => {
      m.current && (m.current(), m.current = void 0);
    }, 100);
    return y.useEffect(() => {
      const g = l.viewport;
      if (g) {
        const S = () => {
          if (v(), !m.current) {
            const _ = _P(g, f);
            m.current = _, f();
          }
        };
        return f(), g.addEventListener("scroll", S), () => g.removeEventListener("scroll", S);
      }
    }, [l.viewport, v, f]), b.jsx(Te.div, { "data-state": u.hasThumb ? "visible" : "hidden", ...s, ref: p, style: { width: "var(--radix-scroll-area-thumb-width)", height: "var(--radix-scroll-area-thumb-height)", ...a }, onPointerDownCapture: Ee(e.onPointerDownCapture, (g) => {
      const _ = g.target.getBoundingClientRect(), x = g.clientX - _.left, E = g.clientY - _.top;
      u.onThumbPointerDown({ x, y: E });
    }), onPointerUp: Ee(e.onPointerUp, u.onThumbPointerUp) });
  });
  F1.displayName = su;
  var xm = "ScrollAreaCorner", q1 = y.forwardRef((e, t) => {
    const r = Dn(xm, e.__scopeScrollArea), a = !!(r.scrollbarX && r.scrollbarY);
    return r.type !== "scroll" && a ? b.jsx(SP, { ...e, ref: t }) : null;
  });
  q1.displayName = xm;
  var SP = y.forwardRef((e, t) => {
    const { __scopeScrollArea: r, ...a } = e, s = Dn(xm, r), [l, u] = y.useState(0), [f, p] = y.useState(0), m = !!(l && f);
    return wi(s.scrollbarX, () => {
      var _a4;
      const v = ((_a4 = s.scrollbarX) == null ? void 0 : _a4.offsetHeight) || 0;
      s.onCornerHeightChange(v), p(v);
    }), wi(s.scrollbarY, () => {
      var _a4;
      const v = ((_a4 = s.scrollbarY) == null ? void 0 : _a4.offsetWidth) || 0;
      s.onCornerWidthChange(v), u(v);
    }), m ? b.jsx(Te.div, { ...a, ref: t, style: { width: l, height: f, position: "absolute", right: s.dir === "ltr" ? 0 : void 0, left: s.dir === "rtl" ? 0 : void 0, bottom: 0, ...e.style } }) : null;
  });
  function lu(e) {
    return e ? parseInt(e, 10) : 0;
  }
  function Y1(e, t) {
    const r = e / t;
    return isNaN(r) ? 0 : r;
  }
  function $u(e) {
    const t = Y1(e.viewport, e.content), r = e.scrollbar.paddingStart + e.scrollbar.paddingEnd, a = (e.scrollbar.size - r) * t;
    return Math.max(a, 18);
  }
  function xP(e, t, r, a = "ltr") {
    const s = $u(r), l = s / 2, u = t || l, f = s - u, p = r.scrollbar.paddingStart + u, m = r.scrollbar.size - r.scrollbar.paddingEnd - f, v = r.content - r.viewport, g = a === "ltr" ? [0, v] : [v * -1, 0];
    return X1([p, m], g)(e);
  }
  function Cw(e, t, r = "ltr") {
    const a = $u(t), s = t.scrollbar.paddingStart + t.scrollbar.paddingEnd, l = t.scrollbar.size - s, u = t.content - t.viewport, f = l - a, p = r === "ltr" ? [0, u] : [u * -1, 0], m = Xs(e, p);
    return X1([0, u], [0, f])(m);
  }
  function X1(e, t) {
    return (r) => {
      if (e[0] === e[1] || t[0] === t[1]) return t[0];
      const a = (t[1] - t[0]) / (e[1] - e[0]);
      return t[0] + a * (r - e[0]);
    };
  }
  function Q1(e, t) {
    return e > 0 && e < t;
  }
  var _P = (e, t = () => {
  }) => {
    let r = { left: e.scrollLeft, top: e.scrollTop }, a = 0;
    return (function s() {
      const l = { left: e.scrollLeft, top: e.scrollTop }, u = r.left !== l.left, f = r.top !== l.top;
      (u || f) && t(), r = l, a = window.requestAnimationFrame(s);
    })(), () => window.cancelAnimationFrame(a);
  };
  function Vu(e, t) {
    const r = rn(e), a = y.useRef(0);
    return y.useEffect(() => () => window.clearTimeout(a.current), []), y.useCallback(() => {
      window.clearTimeout(a.current), a.current = window.setTimeout(r, t);
    }, [r, t]);
  }
  function wi(e, t) {
    const r = rn(t);
    Et(() => {
      let a = 0;
      if (e) {
        const s = new ResizeObserver(() => {
          cancelAnimationFrame(a), a = window.requestAnimationFrame(r);
        });
        return s.observe(e), () => {
          window.cancelAnimationFrame(a), s.unobserve(e);
        };
      }
    }, [e, r]);
  }
  var EP = U1, AP = I1, CP = q1;
  function G1({ className: e, children: t, viewportClassName: r, ...a }) {
    return b.jsxs(EP, { "data-slot": "scroll-area", className: Pe("relative", e), ...a, children: [b.jsx(AP, { "data-slot": "scroll-area-viewport", className: Pe("focus-visible:ring-ring/50 size-full rounded-[inherit] transition-[color,box-shadow] outline-none focus-visible:ring-[3px] focus-visible:outline-1", r), children: t }), b.jsx(TP, {}), b.jsx(CP, {})] });
  }
  function TP({ className: e, orientation: t = "vertical", ...r }) {
    return b.jsx(H1, { "data-slot": "scroll-area-scrollbar", orientation: t, className: Pe("flex touch-none p-px transition-colors select-none", t === "vertical" && "h-full w-2.5 border-l border-l-transparent", t === "horizontal" && "h-2.5 flex-col border-t border-t-transparent", e), ...r, children: b.jsx(F1, { "data-slot": "scroll-area-thumb", className: "bg-border relative flex-1 rounded-full" }) });
  }
  var OP = (e, t, r, a, s, l, u, f) => {
    let p = document.documentElement, m = ["light", "dark"];
    function v(_) {
      (Array.isArray(e) ? e : [e]).forEach((x) => {
        let E = x === "class", C = E && l ? s.map((T) => l[T] || T) : s;
        E ? (p.classList.remove(...C), p.classList.add(l && l[_] ? l[_] : _)) : p.setAttribute(x, _);
      }), g(_);
    }
    function g(_) {
      f && m.includes(_) && (p.style.colorScheme = _);
    }
    function S() {
      return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    }
    if (a) v(a);
    else try {
      let _ = localStorage.getItem(t) || r, x = u && _ === "system" ? S() : _;
      v(x);
    } catch {
    }
  }, RP = y.createContext(void 0), MP = { setTheme: (e) => {
  }, themes: [] }, NP = () => {
    var e;
    return (e = y.useContext(RP)) != null ? e : MP;
  };
  y.memo(({ forcedTheme: e, storageKey: t, attribute: r, enableSystem: a, enableColorScheme: s, defaultTheme: l, value: u, themes: f, nonce: p, scriptProps: m }) => {
    let v = JSON.stringify([r, t, l, e, f, u, a, s]).slice(1, -1);
    return y.createElement("script", { ...m, suppressHydrationWarning: true, nonce: typeof window > "u" ? p : "", dangerouslySetInnerHTML: { __html: `(${OP.toString()})(${v})` } });
  });
  const zP = ({ ...e }) => {
    const { theme: t = "system" } = NP();
    return b.jsx(jD, { theme: t, className: "toaster group ", style: { "--normal-bg": "var(--popover)", "--normal-text": "var(--popover-foreground)", "--normal-border": "var(--border)" }, ...e });
  };
  function Tw(e) {
    const t = DP(e), r = y.forwardRef((a, s) => {
      const { children: l, ...u } = a, f = y.Children.toArray(l), p = f.find(kP);
      if (p) {
        const m = p.props.children, v = f.map((g) => g === p ? y.Children.count(m) > 1 ? y.Children.only(null) : y.isValidElement(m) ? m.props.children : null : g);
        return b.jsx(t, { ...u, ref: s, children: y.isValidElement(m) ? y.cloneElement(m, void 0, v) : null });
      }
      return b.jsx(t, { ...u, ref: s, children: l });
    });
    return r.displayName = `${e}.Slot`, r;
  }
  function DP(e) {
    const t = y.forwardRef((r, a) => {
      const { children: s, ...l } = r;
      if (y.isValidElement(s)) {
        const u = LP(s), f = PP(l, s.props);
        return s.type !== y.Fragment && (f.ref = a ? Ci(a, u) : u), y.cloneElement(s, f);
      }
      return y.Children.count(s) > 1 ? y.Children.only(null) : null;
    });
    return t.displayName = `${e}.SlotClone`, t;
  }
  var jP = /* @__PURE__ */ Symbol("radix.slottable");
  function kP(e) {
    return y.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === jP;
  }
  function PP(e, t) {
    const r = { ...t };
    for (const a in t) {
      const s = e[a], l = t[a];
      /^on[A-Z]/.test(a) ? s && l ? r[a] = (...f) => {
        const p = l(...f);
        return s(...f), p;
      } : s && (r[a] = s) : a === "style" ? r[a] = { ...s, ...l } : a === "className" && (r[a] = [s, l].filter(Boolean).join(" "));
    }
    return { ...e, ...r };
  }
  function LP(e) {
    var _a4, _b2;
    let t = (_a4 = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : _a4.get, r = t && "isReactWarning" in t && t.isReactWarning;
    return r ? e.ref : (t = (_b2 = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : _b2.get, r = t && "isReactWarning" in t && t.isReactWarning, r ? e.props.ref : e.props.ref || e.ref);
  }
  function _m(e) {
    const t = e + "CollectionProvider", [r, a] = Fn(t), [s, l] = r(t, { collectionRef: { current: null }, itemMap: /* @__PURE__ */ new Map() }), u = (E) => {
      const { scope: C, children: T } = E, R = W.useRef(null), O = W.useRef(/* @__PURE__ */ new Map()).current;
      return b.jsx(s, { scope: C, itemMap: O, collectionRef: R, children: T });
    };
    u.displayName = t;
    const f = e + "CollectionSlot", p = Tw(f), m = W.forwardRef((E, C) => {
      const { scope: T, children: R } = E, O = l(f, T), D = Ne(C, O.collectionRef);
      return b.jsx(p, { ref: D, children: R });
    });
    m.displayName = f;
    const v = e + "CollectionItemSlot", g = "data-radix-collection-item", S = Tw(v), _ = W.forwardRef((E, C) => {
      const { scope: T, children: R, ...O } = E, D = W.useRef(null), P = Ne(C, D), L = l(v, T);
      return W.useEffect(() => (L.itemMap.set(D, { ref: D, ...O }), () => void L.itemMap.delete(D))), b.jsx(S, { [g]: "", ref: P, children: R });
    });
    _.displayName = v;
    function x(E) {
      const C = l(e + "CollectionConsumer", E);
      return W.useCallback(() => {
        const R = C.collectionRef.current;
        if (!R) return [];
        const O = Array.from(R.querySelectorAll(`[${g}]`));
        return Array.from(C.itemMap.values()).sort((L, k) => O.indexOf(L.ref.current) - O.indexOf(k.ref.current));
      }, [C.collectionRef, C.itemMap]);
    }
    return [{ Provider: u, Slot: m, ItemSlot: _ }, x, a];
  }
  var Zu = "Collapsible", [UP, K1] = Fn(Zu), [BP, Em] = UP(Zu), J1 = y.forwardRef((e, t) => {
    const { __scopeCollapsible: r, open: a, defaultOpen: s, disabled: l, onOpenChange: u, ...f } = e, [p, m] = Hr({ prop: a, defaultProp: s != null ? s : false, onChange: u, caller: Zu });
    return b.jsx(BP, { scope: r, disabled: l, contentId: Br(), open: p, onOpenToggle: y.useCallback(() => m((v) => !v), [m]), children: b.jsx(Te.div, { "data-state": Cm(p), "data-disabled": l ? "" : void 0, ...f, ref: t }) });
  });
  J1.displayName = Zu;
  var W1 = "CollapsibleTrigger", e_ = y.forwardRef((e, t) => {
    const { __scopeCollapsible: r, ...a } = e, s = Em(W1, r);
    return b.jsx(Te.button, { type: "button", "aria-controls": s.contentId, "aria-expanded": s.open || false, "data-state": Cm(s.open), "data-disabled": s.disabled ? "" : void 0, disabled: s.disabled, ...a, ref: t, onClick: Ee(e.onClick, s.onOpenToggle) });
  });
  e_.displayName = W1;
  var Am = "CollapsibleContent", t_ = y.forwardRef((e, t) => {
    const { forceMount: r, ...a } = e, s = Em(Am, e.__scopeCollapsible);
    return b.jsx(qn, { present: r || s.open, children: ({ present: l }) => b.jsx(IP, { ...a, ref: t, present: l }) });
  });
  t_.displayName = Am;
  var IP = y.forwardRef((e, t) => {
    const { __scopeCollapsible: r, present: a, children: s, ...l } = e, u = Em(Am, r), [f, p] = y.useState(a), m = y.useRef(null), v = Ne(t, m), g = y.useRef(0), S = g.current, _ = y.useRef(0), x = _.current, E = u.open || f, C = y.useRef(E), T = y.useRef(void 0);
    return y.useEffect(() => {
      const R = requestAnimationFrame(() => C.current = false);
      return () => cancelAnimationFrame(R);
    }, []), Et(() => {
      const R = m.current;
      if (R) {
        T.current = T.current || { transitionDuration: R.style.transitionDuration, animationName: R.style.animationName }, R.style.transitionDuration = "0s", R.style.animationName = "none";
        const O = R.getBoundingClientRect();
        g.current = O.height, _.current = O.width, C.current || (R.style.transitionDuration = T.current.transitionDuration, R.style.animationName = T.current.animationName), p(a);
      }
    }, [u.open, a]), b.jsx(Te.div, { "data-state": Cm(u.open), "data-disabled": u.disabled ? "" : void 0, id: u.contentId, hidden: !E, ...l, ref: v, style: { "--radix-collapsible-content-height": S ? `${S}px` : void 0, "--radix-collapsible-content-width": x ? `${x}px` : void 0, ...e.style }, children: E && s });
  });
  function Cm(e) {
    return e ? "open" : "closed";
  }
  var HP = J1, $P = e_, VP = t_, Xn = "Accordion", ZP = ["Home", "End", "ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight"], [Tm, FP, qP] = _m(Xn), [Fu, RI] = Fn(Xn, [qP, K1]), Om = K1(), n_ = W.forwardRef((e, t) => {
    const { type: r, ...a } = e, s = a, l = a;
    return b.jsx(Tm.Provider, { scope: e.__scopeAccordion, children: r === "multiple" ? b.jsx(GP, { ...l, ref: t }) : b.jsx(QP, { ...s, ref: t }) });
  });
  n_.displayName = Xn;
  var [r_, YP] = Fu(Xn), [o_, XP] = Fu(Xn, { collapsible: false }), QP = W.forwardRef((e, t) => {
    const { value: r, defaultValue: a, onValueChange: s = () => {
    }, collapsible: l = false, ...u } = e, [f, p] = Hr({ prop: r, defaultProp: a != null ? a : "", onChange: s, caller: Xn });
    return b.jsx(r_, { scope: e.__scopeAccordion, value: W.useMemo(() => f ? [f] : [], [f]), onItemOpen: p, onItemClose: W.useCallback(() => l && p(""), [l, p]), children: b.jsx(o_, { scope: e.__scopeAccordion, collapsible: l, children: b.jsx(a_, { ...u, ref: t }) }) });
  }), GP = W.forwardRef((e, t) => {
    const { value: r, defaultValue: a, onValueChange: s = () => {
    }, ...l } = e, [u, f] = Hr({ prop: r, defaultProp: a != null ? a : [], onChange: s, caller: Xn }), p = W.useCallback((v) => f((g = []) => [...g, v]), [f]), m = W.useCallback((v) => f((g = []) => g.filter((S) => S !== v)), [f]);
    return b.jsx(r_, { scope: e.__scopeAccordion, value: u, onItemOpen: p, onItemClose: m, children: b.jsx(o_, { scope: e.__scopeAccordion, collapsible: true, children: b.jsx(a_, { ...l, ref: t }) }) });
  }), [KP, qu] = Fu(Xn), a_ = W.forwardRef((e, t) => {
    const { __scopeAccordion: r, disabled: a, dir: s, orientation: l = "vertical", ...u } = e, f = W.useRef(null), p = Ne(f, t), m = FP(r), g = Hu(s) === "ltr", S = Ee(e.onKeyDown, (_) => {
      var _a4;
      if (!ZP.includes(_.key)) return;
      const x = _.target, E = m().filter(($) => {
        var _a5;
        return !((_a5 = $.ref.current) == null ? void 0 : _a5.disabled);
      }), C = E.findIndex(($) => $.ref.current === x), T = E.length;
      if (C === -1) return;
      _.preventDefault();
      let R = C;
      const O = 0, D = T - 1, P = () => {
        R = C + 1, R > D && (R = O);
      }, L = () => {
        R = C - 1, R < O && (R = D);
      };
      switch (_.key) {
        case "Home":
          R = O;
          break;
        case "End":
          R = D;
          break;
        case "ArrowRight":
          l === "horizontal" && (g ? P() : L());
          break;
        case "ArrowDown":
          l === "vertical" && P();
          break;
        case "ArrowLeft":
          l === "horizontal" && (g ? L() : P());
          break;
        case "ArrowUp":
          l === "vertical" && L();
          break;
      }
      const k = R % T;
      (_a4 = E[k].ref.current) == null ? void 0 : _a4.focus();
    });
    return b.jsx(KP, { scope: r, disabled: a, direction: s, orientation: l, children: b.jsx(Tm.Slot, { scope: r, children: b.jsx(Te.div, { ...u, "data-orientation": l, ref: p, onKeyDown: a ? void 0 : S }) }) });
  }), cu = "AccordionItem", [JP, Rm] = Fu(cu), i_ = W.forwardRef((e, t) => {
    const { __scopeAccordion: r, value: a, ...s } = e, l = qu(cu, r), u = YP(cu, r), f = Om(r), p = Br(), m = a && u.value.includes(a) || false, v = l.disabled || e.disabled;
    return b.jsx(JP, { scope: r, open: m, disabled: v, triggerId: p, children: b.jsx(HP, { "data-orientation": l.orientation, "data-state": d_(m), ...f, ...s, ref: t, disabled: v, open: m, onOpenChange: (g) => {
      g ? u.onItemOpen(a) : u.onItemClose(a);
    } }) });
  });
  i_.displayName = cu;
  var s_ = "AccordionHeader", l_ = W.forwardRef((e, t) => {
    const { __scopeAccordion: r, ...a } = e, s = qu(Xn, r), l = Rm(s_, r);
    return b.jsx(Te.h3, { "data-orientation": s.orientation, "data-state": d_(l.open), "data-disabled": l.disabled ? "" : void 0, ...a, ref: t });
  });
  l_.displayName = s_;
  var bp = "AccordionTrigger", c_ = W.forwardRef((e, t) => {
    const { __scopeAccordion: r, ...a } = e, s = qu(Xn, r), l = Rm(bp, r), u = XP(bp, r), f = Om(r);
    return b.jsx(Tm.ItemSlot, { scope: r, children: b.jsx($P, { "aria-disabled": l.open && !u.collapsible || void 0, "data-orientation": s.orientation, id: l.triggerId, ...f, ...a, ref: t }) });
  });
  c_.displayName = bp;
  var u_ = "AccordionContent", f_ = W.forwardRef((e, t) => {
    const { __scopeAccordion: r, ...a } = e, s = qu(Xn, r), l = Rm(u_, r), u = Om(r);
    return b.jsx(VP, { role: "region", "aria-labelledby": l.triggerId, "data-orientation": s.orientation, ...u, ...a, ref: t, style: { "--radix-accordion-content-height": "var(--radix-collapsible-content-height)", "--radix-accordion-content-width": "var(--radix-collapsible-content-width)", ...e.style } });
  });
  f_.displayName = u_;
  function d_(e) {
    return e ? "open" : "closed";
  }
  var WP = n_, e6 = i_, t6 = l_, n6 = c_, r6 = f_;
  function o6({ ...e }) {
    return b.jsx(WP, { "data-slot": "accordion", ...e });
  }
  function a6({ className: e, ...t }) {
    return b.jsx(e6, { "data-slot": "accordion-item", className: Pe("border-b last:border-b-0", e), ...t });
  }
  function i6({ className: e, children: t, ...r }) {
    return b.jsx(t6, { className: "flex", children: b.jsxs(n6, { "data-slot": "accordion-trigger", className: Pe("focus-visible:border-ring focus-visible:ring-ring/50 flex flex-1 cursor-pointer items-start justify-between gap-4 rounded-md py-4 text-left text-sm font-medium transition-all outline-none focus-visible:ring-[3px] disabled:pointer-events-none disabled:opacity-50 [&[data-state=open]>svg]:rotate-180", e), ...r, children: [t, b.jsx(ym, { className: "text-muted-foreground pointer-events-none size-4 shrink-0 translate-y-0.5 transition-transform duration-200" })] }) });
  }
  function s6({ className: e, children: t, ...r }) {
    return b.jsx(r6, { "data-slot": "accordion-content", className: "data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down overflow-hidden text-sm", ...r, children: b.jsx("div", { className: Pe("pt-0 pb-4", e), children: t }) });
  }
  function mr(e) {
    const [t, r] = y.useState(Math.random().toString());
    return b.jsx(o6, { type: "single", collapsible: true, className: Pe("m-3 flex flex-col gap-4 rounded-md px-3 bg-card", e.className), defaultValue: e.opened ? t : void 0, children: b.jsxs(a6, { value: t, children: [b.jsx(i6, { className: Pe("hover:text-foreground/80 text-foreground text-md w-full font-semibold cursor-pointer", e.titleClassName), children: b.jsxs("div", { className: "flex items-center gap-3 px-2", children: [e.icon && b.jsx("span", { className: "shrink-0", children: e.icon }), b.jsx("span", { children: e.title })] }) }), b.jsx(s6, { className: Pe("flex flex-col gap-4", e.contentClassName), children: e.children })] }) });
  }
  const l6 = ["top", "right", "bottom", "left"], Oo = Math.min, yn = Math.max, uu = Math.round, Bc = Math.floor, fr = (e) => ({ x: e, y: e }), c6 = { left: "right", right: "left", bottom: "top", top: "bottom" }, u6 = { start: "end", end: "start" };
  function wp(e, t, r) {
    return yn(e, Oo(t, r));
  }
  function $r(e, t) {
    return typeof e == "function" ? e(t) : e;
  }
  function Vr(e) {
    return e.split("-")[0];
  }
  function Ri(e) {
    return e.split("-")[1];
  }
  function Mm(e) {
    return e === "x" ? "y" : "x";
  }
  function Nm(e) {
    return e === "y" ? "height" : "width";
  }
  const f6 = /* @__PURE__ */ new Set(["top", "bottom"]);
  function ur(e) {
    return f6.has(Vr(e)) ? "y" : "x";
  }
  function zm(e) {
    return Mm(ur(e));
  }
  function d6(e, t, r) {
    r === void 0 && (r = false);
    const a = Ri(e), s = zm(e), l = Nm(s);
    let u = s === "x" ? a === (r ? "end" : "start") ? "right" : "left" : a === "start" ? "bottom" : "top";
    return t.reference[l] > t.floating[l] && (u = fu(u)), [u, fu(u)];
  }
  function h6(e) {
    const t = fu(e);
    return [Sp(e), t, Sp(t)];
  }
  function Sp(e) {
    return e.replace(/start|end/g, (t) => u6[t]);
  }
  const Ow = ["left", "right"], Rw = ["right", "left"], p6 = ["top", "bottom"], m6 = ["bottom", "top"];
  function g6(e, t, r) {
    switch (e) {
      case "top":
      case "bottom":
        return r ? t ? Rw : Ow : t ? Ow : Rw;
      case "left":
      case "right":
        return t ? p6 : m6;
      default:
        return [];
    }
  }
  function v6(e, t, r, a) {
    const s = Ri(e);
    let l = g6(Vr(e), r === "start", a);
    return s && (l = l.map((u) => u + "-" + s), t && (l = l.concat(l.map(Sp)))), l;
  }
  function fu(e) {
    return e.replace(/left|right|bottom|top/g, (t) => c6[t]);
  }
  function y6(e) {
    return { top: 0, right: 0, bottom: 0, left: 0, ...e };
  }
  function h_(e) {
    return typeof e != "number" ? y6(e) : { top: e, right: e, bottom: e, left: e };
  }
  function du(e) {
    const { x: t, y: r, width: a, height: s } = e;
    return { width: a, height: s, top: r, left: t, right: t + a, bottom: r + s, x: t, y: r };
  }
  function Mw(e, t, r) {
    let { reference: a, floating: s } = e;
    const l = ur(t), u = zm(t), f = Nm(u), p = Vr(t), m = l === "y", v = a.x + a.width / 2 - s.width / 2, g = a.y + a.height / 2 - s.height / 2, S = a[f] / 2 - s[f] / 2;
    let _;
    switch (p) {
      case "top":
        _ = { x: v, y: a.y - s.height };
        break;
      case "bottom":
        _ = { x: v, y: a.y + a.height };
        break;
      case "right":
        _ = { x: a.x + a.width, y: g };
        break;
      case "left":
        _ = { x: a.x - s.width, y: g };
        break;
      default:
        _ = { x: a.x, y: a.y };
    }
    switch (Ri(t)) {
      case "start":
        _[u] -= S * (r && m ? -1 : 1);
        break;
      case "end":
        _[u] += S * (r && m ? -1 : 1);
        break;
    }
    return _;
  }
  const b6 = async (e, t, r) => {
    const { placement: a = "bottom", strategy: s = "absolute", middleware: l = [], platform: u } = r, f = l.filter(Boolean), p = await (u.isRTL == null ? void 0 : u.isRTL(t));
    let m = await u.getElementRects({ reference: e, floating: t, strategy: s }), { x: v, y: g } = Mw(m, a, p), S = a, _ = {}, x = 0;
    for (let E = 0; E < f.length; E++) {
      const { name: C, fn: T } = f[E], { x: R, y: O, data: D, reset: P } = await T({ x: v, y: g, initialPlacement: a, placement: S, strategy: s, middlewareData: _, rects: m, platform: u, elements: { reference: e, floating: t } });
      v = R != null ? R : v, g = O != null ? O : g, _ = { ..._, [C]: { ..._[C], ...D } }, P && x <= 50 && (x++, typeof P == "object" && (P.placement && (S = P.placement), P.rects && (m = P.rects === true ? await u.getElementRects({ reference: e, floating: t, strategy: s }) : P.rects), { x: v, y: g } = Mw(m, S, p)), E = -1);
    }
    return { x: v, y: g, placement: S, strategy: s, middlewareData: _ };
  };
  async function Qs(e, t) {
    var r;
    t === void 0 && (t = {});
    const { x: a, y: s, platform: l, rects: u, elements: f, strategy: p } = e, { boundary: m = "clippingAncestors", rootBoundary: v = "viewport", elementContext: g = "floating", altBoundary: S = false, padding: _ = 0 } = $r(t, e), x = h_(_), C = f[S ? g === "floating" ? "reference" : "floating" : g], T = du(await l.getClippingRect({ element: (r = await (l.isElement == null ? void 0 : l.isElement(C))) == null || r ? C : C.contextElement || await (l.getDocumentElement == null ? void 0 : l.getDocumentElement(f.floating)), boundary: m, rootBoundary: v, strategy: p })), R = g === "floating" ? { x: a, y: s, width: u.floating.width, height: u.floating.height } : u.reference, O = await (l.getOffsetParent == null ? void 0 : l.getOffsetParent(f.floating)), D = await (l.isElement == null ? void 0 : l.isElement(O)) ? await (l.getScale == null ? void 0 : l.getScale(O)) || { x: 1, y: 1 } : { x: 1, y: 1 }, P = du(l.convertOffsetParentRelativeRectToViewportRelativeRect ? await l.convertOffsetParentRelativeRectToViewportRelativeRect({ elements: f, rect: R, offsetParent: O, strategy: p }) : R);
    return { top: (T.top - P.top + x.top) / D.y, bottom: (P.bottom - T.bottom + x.bottom) / D.y, left: (T.left - P.left + x.left) / D.x, right: (P.right - T.right + x.right) / D.x };
  }
  const w6 = (e) => ({ name: "arrow", options: e, async fn(t) {
    const { x: r, y: a, placement: s, rects: l, platform: u, elements: f, middlewareData: p } = t, { element: m, padding: v = 0 } = $r(e, t) || {};
    if (m == null) return {};
    const g = h_(v), S = { x: r, y: a }, _ = zm(s), x = Nm(_), E = await u.getDimensions(m), C = _ === "y", T = C ? "top" : "left", R = C ? "bottom" : "right", O = C ? "clientHeight" : "clientWidth", D = l.reference[x] + l.reference[_] - S[_] - l.floating[x], P = S[_] - l.reference[_], L = await (u.getOffsetParent == null ? void 0 : u.getOffsetParent(m));
    let k = L ? L[O] : 0;
    (!k || !await (u.isElement == null ? void 0 : u.isElement(L))) && (k = f.floating[O] || l.floating[x]);
    const $ = D / 2 - P / 2, re = k / 2 - E[x] / 2 - 1, G = Oo(g[T], re), ae = Oo(g[R], re), se = G, le = k - E[x] - ae, ue = k / 2 - E[x] / 2 + $, oe = wp(se, ue, le), N = !p.arrow && Ri(s) != null && ue !== oe && l.reference[x] / 2 - (ue < se ? G : ae) - E[x] / 2 < 0, Z = N ? ue < se ? ue - se : ue - le : 0;
    return { [_]: S[_] + Z, data: { [_]: oe, centerOffset: ue - oe - Z, ...N && { alignmentOffset: Z } }, reset: N };
  } }), S6 = function(e) {
    return e === void 0 && (e = {}), { name: "flip", options: e, async fn(t) {
      var r, a;
      const { placement: s, middlewareData: l, rects: u, initialPlacement: f, platform: p, elements: m } = t, { mainAxis: v = true, crossAxis: g = true, fallbackPlacements: S, fallbackStrategy: _ = "bestFit", fallbackAxisSideDirection: x = "none", flipAlignment: E = true, ...C } = $r(e, t);
      if ((r = l.arrow) != null && r.alignmentOffset) return {};
      const T = Vr(s), R = ur(f), O = Vr(f) === f, D = await (p.isRTL == null ? void 0 : p.isRTL(m.floating)), P = S || (O || !E ? [fu(f)] : h6(f)), L = x !== "none";
      !S && L && P.push(...v6(f, E, x, D));
      const k = [f, ...P], $ = await Qs(t, C), re = [];
      let G = ((a = l.flip) == null ? void 0 : a.overflows) || [];
      if (v && re.push($[T]), g) {
        const ue = d6(s, u, D);
        re.push($[ue[0]], $[ue[1]]);
      }
      if (G = [...G, { placement: s, overflows: re }], !re.every((ue) => ue <= 0)) {
        var ae, se;
        const ue = (((ae = l.flip) == null ? void 0 : ae.index) || 0) + 1, oe = k[ue];
        if (oe && (!(g === "alignment" ? R !== ur(oe) : false) || G.every((B) => ur(B.placement) === R ? B.overflows[0] > 0 : true))) return { data: { index: ue, overflows: G }, reset: { placement: oe } };
        let N = (se = G.filter((Z) => Z.overflows[0] <= 0).sort((Z, B) => Z.overflows[1] - B.overflows[1])[0]) == null ? void 0 : se.placement;
        if (!N) switch (_) {
          case "bestFit": {
            var le;
            const Z = (le = G.filter((B) => {
              if (L) {
                const ce = ur(B.placement);
                return ce === R || ce === "y";
              }
              return true;
            }).map((B) => [B.placement, B.overflows.filter((ce) => ce > 0).reduce((ce, me) => ce + me, 0)]).sort((B, ce) => B[1] - ce[1])[0]) == null ? void 0 : le[0];
            Z && (N = Z);
            break;
          }
          case "initialPlacement":
            N = f;
            break;
        }
        if (s !== N) return { reset: { placement: N } };
      }
      return {};
    } };
  };
  function Nw(e, t) {
    return { top: e.top - t.height, right: e.right - t.width, bottom: e.bottom - t.height, left: e.left - t.width };
  }
  function zw(e) {
    return l6.some((t) => e[t] >= 0);
  }
  const x6 = function(e) {
    return e === void 0 && (e = {}), { name: "hide", options: e, async fn(t) {
      const { rects: r } = t, { strategy: a = "referenceHidden", ...s } = $r(e, t);
      switch (a) {
        case "referenceHidden": {
          const l = await Qs(t, { ...s, elementContext: "reference" }), u = Nw(l, r.reference);
          return { data: { referenceHiddenOffsets: u, referenceHidden: zw(u) } };
        }
        case "escaped": {
          const l = await Qs(t, { ...s, altBoundary: true }), u = Nw(l, r.floating);
          return { data: { escapedOffsets: u, escaped: zw(u) } };
        }
        default:
          return {};
      }
    } };
  }, p_ = /* @__PURE__ */ new Set(["left", "top"]);
  async function _6(e, t) {
    const { placement: r, platform: a, elements: s } = e, l = await (a.isRTL == null ? void 0 : a.isRTL(s.floating)), u = Vr(r), f = Ri(r), p = ur(r) === "y", m = p_.has(u) ? -1 : 1, v = l && p ? -1 : 1, g = $r(t, e);
    let { mainAxis: S, crossAxis: _, alignmentAxis: x } = typeof g == "number" ? { mainAxis: g, crossAxis: 0, alignmentAxis: null } : { mainAxis: g.mainAxis || 0, crossAxis: g.crossAxis || 0, alignmentAxis: g.alignmentAxis };
    return f && typeof x == "number" && (_ = f === "end" ? x * -1 : x), p ? { x: _ * v, y: S * m } : { x: S * m, y: _ * v };
  }
  const E6 = function(e) {
    return e === void 0 && (e = 0), { name: "offset", options: e, async fn(t) {
      var r, a;
      const { x: s, y: l, placement: u, middlewareData: f } = t, p = await _6(t, e);
      return u === ((r = f.offset) == null ? void 0 : r.placement) && (a = f.arrow) != null && a.alignmentOffset ? {} : { x: s + p.x, y: l + p.y, data: { ...p, placement: u } };
    } };
  }, A6 = function(e) {
    return e === void 0 && (e = {}), { name: "shift", options: e, async fn(t) {
      const { x: r, y: a, placement: s } = t, { mainAxis: l = true, crossAxis: u = false, limiter: f = { fn: (C) => {
        let { x: T, y: R } = C;
        return { x: T, y: R };
      } }, ...p } = $r(e, t), m = { x: r, y: a }, v = await Qs(t, p), g = ur(Vr(s)), S = Mm(g);
      let _ = m[S], x = m[g];
      if (l) {
        const C = S === "y" ? "top" : "left", T = S === "y" ? "bottom" : "right", R = _ + v[C], O = _ - v[T];
        _ = wp(R, _, O);
      }
      if (u) {
        const C = g === "y" ? "top" : "left", T = g === "y" ? "bottom" : "right", R = x + v[C], O = x - v[T];
        x = wp(R, x, O);
      }
      const E = f.fn({ ...t, [S]: _, [g]: x });
      return { ...E, data: { x: E.x - r, y: E.y - a, enabled: { [S]: l, [g]: u } } };
    } };
  }, C6 = function(e) {
    return e === void 0 && (e = {}), { options: e, fn(t) {
      const { x: r, y: a, placement: s, rects: l, middlewareData: u } = t, { offset: f = 0, mainAxis: p = true, crossAxis: m = true } = $r(e, t), v = { x: r, y: a }, g = ur(s), S = Mm(g);
      let _ = v[S], x = v[g];
      const E = $r(f, t), C = typeof E == "number" ? { mainAxis: E, crossAxis: 0 } : { mainAxis: 0, crossAxis: 0, ...E };
      if (p) {
        const O = S === "y" ? "height" : "width", D = l.reference[S] - l.floating[O] + C.mainAxis, P = l.reference[S] + l.reference[O] - C.mainAxis;
        _ < D ? _ = D : _ > P && (_ = P);
      }
      if (m) {
        var T, R;
        const O = S === "y" ? "width" : "height", D = p_.has(Vr(s)), P = l.reference[g] - l.floating[O] + (D && ((T = u.offset) == null ? void 0 : T[g]) || 0) + (D ? 0 : C.crossAxis), L = l.reference[g] + l.reference[O] + (D ? 0 : ((R = u.offset) == null ? void 0 : R[g]) || 0) - (D ? C.crossAxis : 0);
        x < P ? x = P : x > L && (x = L);
      }
      return { [S]: _, [g]: x };
    } };
  }, T6 = function(e) {
    return e === void 0 && (e = {}), { name: "size", options: e, async fn(t) {
      var r, a;
      const { placement: s, rects: l, platform: u, elements: f } = t, { apply: p = () => {
      }, ...m } = $r(e, t), v = await Qs(t, m), g = Vr(s), S = Ri(s), _ = ur(s) === "y", { width: x, height: E } = l.floating;
      let C, T;
      g === "top" || g === "bottom" ? (C = g, T = S === (await (u.isRTL == null ? void 0 : u.isRTL(f.floating)) ? "start" : "end") ? "left" : "right") : (T = g, C = S === "end" ? "top" : "bottom");
      const R = E - v.top - v.bottom, O = x - v.left - v.right, D = Oo(E - v[C], R), P = Oo(x - v[T], O), L = !t.middlewareData.shift;
      let k = D, $ = P;
      if ((r = t.middlewareData.shift) != null && r.enabled.x && ($ = O), (a = t.middlewareData.shift) != null && a.enabled.y && (k = R), L && !S) {
        const G = yn(v.left, 0), ae = yn(v.right, 0), se = yn(v.top, 0), le = yn(v.bottom, 0);
        _ ? $ = x - 2 * (G !== 0 || ae !== 0 ? G + ae : yn(v.left, v.right)) : k = E - 2 * (se !== 0 || le !== 0 ? se + le : yn(v.top, v.bottom));
      }
      await p({ ...t, availableWidth: $, availableHeight: k });
      const re = await u.getDimensions(f.floating);
      return x !== re.width || E !== re.height ? { reset: { rects: true } } : {};
    } };
  };
  function Yu() {
    return typeof window < "u";
  }
  function Mi(e) {
    return m_(e) ? (e.nodeName || "").toLowerCase() : "#document";
  }
  function bn(e) {
    var t;
    return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
  }
  function gr(e) {
    var t;
    return (t = (m_(e) ? e.ownerDocument : e.document) || window.document) == null ? void 0 : t.documentElement;
  }
  function m_(e) {
    return Yu() ? e instanceof Node || e instanceof bn(e).Node : false;
  }
  function $n(e) {
    return Yu() ? e instanceof Element || e instanceof bn(e).Element : false;
  }
  function dr(e) {
    return Yu() ? e instanceof HTMLElement || e instanceof bn(e).HTMLElement : false;
  }
  function Dw(e) {
    return !Yu() || typeof ShadowRoot > "u" ? false : e instanceof ShadowRoot || e instanceof bn(e).ShadowRoot;
  }
  const O6 = /* @__PURE__ */ new Set(["inline", "contents"]);
  function ll(e) {
    const { overflow: t, overflowX: r, overflowY: a, display: s } = Vn(e);
    return /auto|scroll|overlay|hidden|clip/.test(t + a + r) && !O6.has(s);
  }
  const R6 = /* @__PURE__ */ new Set(["table", "td", "th"]);
  function M6(e) {
    return R6.has(Mi(e));
  }
  const N6 = [":popover-open", ":modal"];
  function Xu(e) {
    return N6.some((t) => {
      try {
        return e.matches(t);
      } catch {
        return false;
      }
    });
  }
  const z6 = ["transform", "translate", "scale", "rotate", "perspective"], D6 = ["transform", "translate", "scale", "rotate", "perspective", "filter"], j6 = ["paint", "layout", "strict", "content"];
  function Dm(e) {
    const t = jm(), r = $n(e) ? Vn(e) : e;
    return z6.some((a) => r[a] ? r[a] !== "none" : false) || (r.containerType ? r.containerType !== "normal" : false) || !t && (r.backdropFilter ? r.backdropFilter !== "none" : false) || !t && (r.filter ? r.filter !== "none" : false) || D6.some((a) => (r.willChange || "").includes(a)) || j6.some((a) => (r.contain || "").includes(a));
  }
  function k6(e) {
    let t = Ro(e);
    for (; dr(t) && !Si(t); ) {
      if (Dm(t)) return t;
      if (Xu(t)) return null;
      t = Ro(t);
    }
    return null;
  }
  function jm() {
    return typeof CSS > "u" || !CSS.supports ? false : CSS.supports("-webkit-backdrop-filter", "none");
  }
  const P6 = /* @__PURE__ */ new Set(["html", "body", "#document"]);
  function Si(e) {
    return P6.has(Mi(e));
  }
  function Vn(e) {
    return bn(e).getComputedStyle(e);
  }
  function Qu(e) {
    return $n(e) ? { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop } : { scrollLeft: e.scrollX, scrollTop: e.scrollY };
  }
  function Ro(e) {
    if (Mi(e) === "html") return e;
    const t = e.assignedSlot || e.parentNode || Dw(e) && e.host || gr(e);
    return Dw(t) ? t.host : t;
  }
  function g_(e) {
    const t = Ro(e);
    return Si(t) ? e.ownerDocument ? e.ownerDocument.body : e.body : dr(t) && ll(t) ? t : g_(t);
  }
  function Gs(e, t, r) {
    var a;
    t === void 0 && (t = []), r === void 0 && (r = true);
    const s = g_(e), l = s === ((a = e.ownerDocument) == null ? void 0 : a.body), u = bn(s);
    if (l) {
      const f = xp(u);
      return t.concat(u, u.visualViewport || [], ll(s) ? s : [], f && r ? Gs(f) : []);
    }
    return t.concat(s, Gs(s, [], r));
  }
  function xp(e) {
    return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
  }
  function v_(e) {
    const t = Vn(e);
    let r = parseFloat(t.width) || 0, a = parseFloat(t.height) || 0;
    const s = dr(e), l = s ? e.offsetWidth : r, u = s ? e.offsetHeight : a, f = uu(r) !== l || uu(a) !== u;
    return f && (r = l, a = u), { width: r, height: a, $: f };
  }
  function km(e) {
    return $n(e) ? e : e.contextElement;
  }
  function gi(e) {
    const t = km(e);
    if (!dr(t)) return fr(1);
    const r = t.getBoundingClientRect(), { width: a, height: s, $: l } = v_(t);
    let u = (l ? uu(r.width) : r.width) / a, f = (l ? uu(r.height) : r.height) / s;
    return (!u || !Number.isFinite(u)) && (u = 1), (!f || !Number.isFinite(f)) && (f = 1), { x: u, y: f };
  }
  const L6 = fr(0);
  function y_(e) {
    const t = bn(e);
    return !jm() || !t.visualViewport ? L6 : { x: t.visualViewport.offsetLeft, y: t.visualViewport.offsetTop };
  }
  function U6(e, t, r) {
    return t === void 0 && (t = false), !r || t && r !== bn(e) ? false : t;
  }
  function ha(e, t, r, a) {
    t === void 0 && (t = false), r === void 0 && (r = false);
    const s = e.getBoundingClientRect(), l = km(e);
    let u = fr(1);
    t && (a ? $n(a) && (u = gi(a)) : u = gi(e));
    const f = U6(l, r, a) ? y_(l) : fr(0);
    let p = (s.left + f.x) / u.x, m = (s.top + f.y) / u.y, v = s.width / u.x, g = s.height / u.y;
    if (l) {
      const S = bn(l), _ = a && $n(a) ? bn(a) : a;
      let x = S, E = xp(x);
      for (; E && a && _ !== x; ) {
        const C = gi(E), T = E.getBoundingClientRect(), R = Vn(E), O = T.left + (E.clientLeft + parseFloat(R.paddingLeft)) * C.x, D = T.top + (E.clientTop + parseFloat(R.paddingTop)) * C.y;
        p *= C.x, m *= C.y, v *= C.x, g *= C.y, p += O, m += D, x = bn(E), E = xp(x);
      }
    }
    return du({ width: v, height: g, x: p, y: m });
  }
  function Gu(e, t) {
    const r = Qu(e).scrollLeft;
    return t ? t.left + r : ha(gr(e)).left + r;
  }
  function b_(e, t) {
    const r = e.getBoundingClientRect(), a = r.left + t.scrollLeft - Gu(e, r), s = r.top + t.scrollTop;
    return { x: a, y: s };
  }
  function B6(e) {
    let { elements: t, rect: r, offsetParent: a, strategy: s } = e;
    const l = s === "fixed", u = gr(a), f = t ? Xu(t.floating) : false;
    if (a === u || f && l) return r;
    let p = { scrollLeft: 0, scrollTop: 0 }, m = fr(1);
    const v = fr(0), g = dr(a);
    if ((g || !g && !l) && ((Mi(a) !== "body" || ll(u)) && (p = Qu(a)), dr(a))) {
      const _ = ha(a);
      m = gi(a), v.x = _.x + a.clientLeft, v.y = _.y + a.clientTop;
    }
    const S = u && !g && !l ? b_(u, p) : fr(0);
    return { width: r.width * m.x, height: r.height * m.y, x: r.x * m.x - p.scrollLeft * m.x + v.x + S.x, y: r.y * m.y - p.scrollTop * m.y + v.y + S.y };
  }
  function I6(e) {
    return Array.from(e.getClientRects());
  }
  function H6(e) {
    const t = gr(e), r = Qu(e), a = e.ownerDocument.body, s = yn(t.scrollWidth, t.clientWidth, a.scrollWidth, a.clientWidth), l = yn(t.scrollHeight, t.clientHeight, a.scrollHeight, a.clientHeight);
    let u = -r.scrollLeft + Gu(e);
    const f = -r.scrollTop;
    return Vn(a).direction === "rtl" && (u += yn(t.clientWidth, a.clientWidth) - s), { width: s, height: l, x: u, y: f };
  }
  const jw = 25;
  function $6(e, t) {
    const r = bn(e), a = gr(e), s = r.visualViewport;
    let l = a.clientWidth, u = a.clientHeight, f = 0, p = 0;
    if (s) {
      l = s.width, u = s.height;
      const v = jm();
      (!v || v && t === "fixed") && (f = s.offsetLeft, p = s.offsetTop);
    }
    const m = Gu(a);
    if (m <= 0) {
      const v = a.ownerDocument, g = v.body, S = getComputedStyle(g), _ = v.compatMode === "CSS1Compat" && parseFloat(S.marginLeft) + parseFloat(S.marginRight) || 0, x = Math.abs(a.clientWidth - g.clientWidth - _);
      x <= jw && (l -= x);
    } else m <= jw && (l += m);
    return { width: l, height: u, x: f, y: p };
  }
  const V6 = /* @__PURE__ */ new Set(["absolute", "fixed"]);
  function Z6(e, t) {
    const r = ha(e, true, t === "fixed"), a = r.top + e.clientTop, s = r.left + e.clientLeft, l = dr(e) ? gi(e) : fr(1), u = e.clientWidth * l.x, f = e.clientHeight * l.y, p = s * l.x, m = a * l.y;
    return { width: u, height: f, x: p, y: m };
  }
  function kw(e, t, r) {
    let a;
    if (t === "viewport") a = $6(e, r);
    else if (t === "document") a = H6(gr(e));
    else if ($n(t)) a = Z6(t, r);
    else {
      const s = y_(e);
      a = { x: t.x - s.x, y: t.y - s.y, width: t.width, height: t.height };
    }
    return du(a);
  }
  function w_(e, t) {
    const r = Ro(e);
    return r === t || !$n(r) || Si(r) ? false : Vn(r).position === "fixed" || w_(r, t);
  }
  function F6(e, t) {
    const r = t.get(e);
    if (r) return r;
    let a = Gs(e, [], false).filter((f) => $n(f) && Mi(f) !== "body"), s = null;
    const l = Vn(e).position === "fixed";
    let u = l ? Ro(e) : e;
    for (; $n(u) && !Si(u); ) {
      const f = Vn(u), p = Dm(u);
      !p && f.position === "fixed" && (s = null), (l ? !p && !s : !p && f.position === "static" && !!s && V6.has(s.position) || ll(u) && !p && w_(e, u)) ? a = a.filter((v) => v !== u) : s = f, u = Ro(u);
    }
    return t.set(e, a), a;
  }
  function q6(e) {
    let { element: t, boundary: r, rootBoundary: a, strategy: s } = e;
    const u = [...r === "clippingAncestors" ? Xu(t) ? [] : F6(t, this._c) : [].concat(r), a], f = u[0], p = u.reduce((m, v) => {
      const g = kw(t, v, s);
      return m.top = yn(g.top, m.top), m.right = Oo(g.right, m.right), m.bottom = Oo(g.bottom, m.bottom), m.left = yn(g.left, m.left), m;
    }, kw(t, f, s));
    return { width: p.right - p.left, height: p.bottom - p.top, x: p.left, y: p.top };
  }
  function Y6(e) {
    const { width: t, height: r } = v_(e);
    return { width: t, height: r };
  }
  function X6(e, t, r) {
    const a = dr(t), s = gr(t), l = r === "fixed", u = ha(e, true, l, t);
    let f = { scrollLeft: 0, scrollTop: 0 };
    const p = fr(0);
    function m() {
      p.x = Gu(s);
    }
    if (a || !a && !l) if ((Mi(t) !== "body" || ll(s)) && (f = Qu(t)), a) {
      const _ = ha(t, true, l, t);
      p.x = _.x + t.clientLeft, p.y = _.y + t.clientTop;
    } else s && m();
    l && !a && s && m();
    const v = s && !a && !l ? b_(s, f) : fr(0), g = u.left + f.scrollLeft - p.x - v.x, S = u.top + f.scrollTop - p.y - v.y;
    return { x: g, y: S, width: u.width, height: u.height };
  }
  function $h(e) {
    return Vn(e).position === "static";
  }
  function Pw(e, t) {
    if (!dr(e) || Vn(e).position === "fixed") return null;
    if (t) return t(e);
    let r = e.offsetParent;
    return gr(e) === r && (r = r.ownerDocument.body), r;
  }
  function S_(e, t) {
    const r = bn(e);
    if (Xu(e)) return r;
    if (!dr(e)) {
      let s = Ro(e);
      for (; s && !Si(s); ) {
        if ($n(s) && !$h(s)) return s;
        s = Ro(s);
      }
      return r;
    }
    let a = Pw(e, t);
    for (; a && M6(a) && $h(a); ) a = Pw(a, t);
    return a && Si(a) && $h(a) && !Dm(a) ? r : a || k6(e) || r;
  }
  const Q6 = async function(e) {
    const t = this.getOffsetParent || S_, r = this.getDimensions, a = await r(e.floating);
    return { reference: X6(e.reference, await t(e.floating), e.strategy), floating: { x: 0, y: 0, width: a.width, height: a.height } };
  };
  function G6(e) {
    return Vn(e).direction === "rtl";
  }
  const K6 = { convertOffsetParentRelativeRectToViewportRelativeRect: B6, getDocumentElement: gr, getClippingRect: q6, getOffsetParent: S_, getElementRects: Q6, getClientRects: I6, getDimensions: Y6, getScale: gi, isElement: $n, isRTL: G6 };
  function x_(e, t) {
    return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
  }
  function J6(e, t) {
    let r = null, a;
    const s = gr(e);
    function l() {
      var f;
      clearTimeout(a), (f = r) == null || f.disconnect(), r = null;
    }
    function u(f, p) {
      f === void 0 && (f = false), p === void 0 && (p = 1), l();
      const m = e.getBoundingClientRect(), { left: v, top: g, width: S, height: _ } = m;
      if (f || t(), !S || !_) return;
      const x = Bc(g), E = Bc(s.clientWidth - (v + S)), C = Bc(s.clientHeight - (g + _)), T = Bc(v), O = { rootMargin: -x + "px " + -E + "px " + -C + "px " + -T + "px", threshold: yn(0, Oo(1, p)) || 1 };
      let D = true;
      function P(L) {
        const k = L[0].intersectionRatio;
        if (k !== p) {
          if (!D) return u();
          k ? u(false, k) : a = setTimeout(() => {
            u(false, 1e-7);
          }, 1e3);
        }
        k === 1 && !x_(m, e.getBoundingClientRect()) && u(), D = false;
      }
      try {
        r = new IntersectionObserver(P, { ...O, root: s.ownerDocument });
      } catch {
        r = new IntersectionObserver(P, O);
      }
      r.observe(e);
    }
    return u(true), l;
  }
  function W6(e, t, r, a) {
    a === void 0 && (a = {});
    const { ancestorScroll: s = true, ancestorResize: l = true, elementResize: u = typeof ResizeObserver == "function", layoutShift: f = typeof IntersectionObserver == "function", animationFrame: p = false } = a, m = km(e), v = s || l ? [...m ? Gs(m) : [], ...Gs(t)] : [];
    v.forEach((T) => {
      s && T.addEventListener("scroll", r, { passive: true }), l && T.addEventListener("resize", r);
    });
    const g = m && f ? J6(m, r) : null;
    let S = -1, _ = null;
    u && (_ = new ResizeObserver((T) => {
      let [R] = T;
      R && R.target === m && _ && (_.unobserve(t), cancelAnimationFrame(S), S = requestAnimationFrame(() => {
        var O;
        (O = _) == null || O.observe(t);
      })), r();
    }), m && !p && _.observe(m), _.observe(t));
    let x, E = p ? ha(e) : null;
    p && C();
    function C() {
      const T = ha(e);
      E && !x_(E, T) && r(), E = T, x = requestAnimationFrame(C);
    }
    return r(), () => {
      var T;
      v.forEach((R) => {
        s && R.removeEventListener("scroll", r), l && R.removeEventListener("resize", r);
      }), g == null ? void 0 : g(), (T = _) == null || T.disconnect(), _ = null, p && cancelAnimationFrame(x);
    };
  }
  const e8 = E6, t8 = A6, n8 = S6, r8 = T6, o8 = x6, Lw = w6, a8 = C6, i8 = (e, t, r) => {
    const a = /* @__PURE__ */ new Map(), s = { platform: K6, ...r }, l = { ...s.platform, _c: a };
    return b6(e, t, { ...s, platform: l });
  };
  var s8 = typeof document < "u", l8 = function() {
  }, Qc = s8 ? y.useLayoutEffect : l8;
  function hu(e, t) {
    if (e === t) return true;
    if (typeof e != typeof t) return false;
    if (typeof e == "function" && e.toString() === t.toString()) return true;
    let r, a, s;
    if (e && t && typeof e == "object") {
      if (Array.isArray(e)) {
        if (r = e.length, r !== t.length) return false;
        for (a = r; a-- !== 0; ) if (!hu(e[a], t[a])) return false;
        return true;
      }
      if (s = Object.keys(e), r = s.length, r !== Object.keys(t).length) return false;
      for (a = r; a-- !== 0; ) if (!{}.hasOwnProperty.call(t, s[a])) return false;
      for (a = r; a-- !== 0; ) {
        const l = s[a];
        if (!(l === "_owner" && e.$$typeof) && !hu(e[l], t[l])) return false;
      }
      return true;
    }
    return e !== e && t !== t;
  }
  function __(e) {
    return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
  }
  function Uw(e, t) {
    const r = __(e);
    return Math.round(t * r) / r;
  }
  function Vh(e) {
    const t = y.useRef(e);
    return Qc(() => {
      t.current = e;
    }), t;
  }
  function c8(e) {
    e === void 0 && (e = {});
    const { placement: t = "bottom", strategy: r = "absolute", middleware: a = [], platform: s, elements: { reference: l, floating: u } = {}, transform: f = true, whileElementsMounted: p, open: m } = e, [v, g] = y.useState({ x: 0, y: 0, strategy: r, placement: t, middlewareData: {}, isPositioned: false }), [S, _] = y.useState(a);
    hu(S, a) || _(a);
    const [x, E] = y.useState(null), [C, T] = y.useState(null), R = y.useCallback((B) => {
      B !== L.current && (L.current = B, E(B));
    }, []), O = y.useCallback((B) => {
      B !== k.current && (k.current = B, T(B));
    }, []), D = l || x, P = u || C, L = y.useRef(null), k = y.useRef(null), $ = y.useRef(v), re = p != null, G = Vh(p), ae = Vh(s), se = Vh(m), le = y.useCallback(() => {
      if (!L.current || !k.current) return;
      const B = { placement: t, strategy: r, middleware: S };
      ae.current && (B.platform = ae.current), i8(L.current, k.current, B).then((ce) => {
        const me = { ...ce, isPositioned: se.current !== false };
        ue.current && !hu($.current, me) && ($.current = me, Ai.flushSync(() => {
          g(me);
        }));
      });
    }, [S, t, r, ae, se]);
    Qc(() => {
      m === false && $.current.isPositioned && ($.current.isPositioned = false, g((B) => ({ ...B, isPositioned: false })));
    }, [m]);
    const ue = y.useRef(false);
    Qc(() => (ue.current = true, () => {
      ue.current = false;
    }), []), Qc(() => {
      if (D && (L.current = D), P && (k.current = P), D && P) {
        if (G.current) return G.current(D, P, le);
        le();
      }
    }, [D, P, le, G, re]);
    const oe = y.useMemo(() => ({ reference: L, floating: k, setReference: R, setFloating: O }), [R, O]), N = y.useMemo(() => ({ reference: D, floating: P }), [D, P]), Z = y.useMemo(() => {
      const B = { position: r, left: 0, top: 0 };
      if (!N.floating) return B;
      const ce = Uw(N.floating, v.x), me = Uw(N.floating, v.y);
      return f ? { ...B, transform: "translate(" + ce + "px, " + me + "px)", ...__(N.floating) >= 1.5 && { willChange: "transform" } } : { position: r, left: ce, top: me };
    }, [r, f, N.floating, v.x, v.y]);
    return y.useMemo(() => ({ ...v, update: le, refs: oe, elements: N, floatingStyles: Z }), [v, le, oe, N, Z]);
  }
  const u8 = (e) => {
    function t(r) {
      return {}.hasOwnProperty.call(r, "current");
    }
    return { name: "arrow", options: e, fn(r) {
      const { element: a, padding: s } = typeof e == "function" ? e(r) : e;
      return a && t(a) ? a.current != null ? Lw({ element: a.current, padding: s }).fn(r) : {} : a ? Lw({ element: a, padding: s }).fn(r) : {};
    } };
  }, f8 = (e, t) => ({ ...e8(e), options: [e, t] }), d8 = (e, t) => ({ ...t8(e), options: [e, t] }), h8 = (e, t) => ({ ...a8(e), options: [e, t] }), p8 = (e, t) => ({ ...n8(e), options: [e, t] }), m8 = (e, t) => ({ ...r8(e), options: [e, t] }), g8 = (e, t) => ({ ...o8(e), options: [e, t] }), v8 = (e, t) => ({ ...u8(e), options: [e, t] });
  var y8 = "Arrow", E_ = y.forwardRef((e, t) => {
    const { children: r, width: a = 10, height: s = 5, ...l } = e;
    return b.jsx(Te.svg, { ...l, ref: t, width: a, height: s, viewBox: "0 0 30 10", preserveAspectRatio: "none", children: e.asChild ? r : b.jsx("polygon", { points: "0,0 30,0 15,10" }) });
  });
  E_.displayName = y8;
  var b8 = E_;
  function Pm(e) {
    const [t, r] = y.useState(void 0);
    return Et(() => {
      if (e) {
        r({ width: e.offsetWidth, height: e.offsetHeight });
        const a = new ResizeObserver((s) => {
          if (!Array.isArray(s) || !s.length) return;
          const l = s[0];
          let u, f;
          if ("borderBoxSize" in l) {
            const p = l.borderBoxSize, m = Array.isArray(p) ? p[0] : p;
            u = m.inlineSize, f = m.blockSize;
          } else u = e.offsetWidth, f = e.offsetHeight;
          r({ width: u, height: f });
        });
        return a.observe(e, { box: "border-box" }), () => a.unobserve(e);
      } else r(void 0);
    }, [e]), t;
  }
  var Lm = "Popper", [A_, Ku] = Fn(Lm), [w8, C_] = A_(Lm), T_ = (e) => {
    const { __scopePopper: t, children: r } = e, [a, s] = y.useState(null);
    return b.jsx(w8, { scope: t, anchor: a, onAnchorChange: s, children: r });
  };
  T_.displayName = Lm;
  var O_ = "PopperAnchor", R_ = y.forwardRef((e, t) => {
    const { __scopePopper: r, virtualRef: a, ...s } = e, l = C_(O_, r), u = y.useRef(null), f = Ne(t, u), p = y.useRef(null);
    return y.useEffect(() => {
      const m = p.current;
      p.current = (a == null ? void 0 : a.current) || u.current, m !== p.current && l.onAnchorChange(p.current);
    }), a ? null : b.jsx(Te.div, { ...s, ref: f });
  });
  R_.displayName = O_;
  var Um = "PopperContent", [S8, x8] = A_(Um), M_ = y.forwardRef((e, t) => {
    var _a4, _b2, _c3, _d3, _e13, _f2, _g2, _h4;
    const { __scopePopper: r, side: a = "bottom", sideOffset: s = 0, align: l = "center", alignOffset: u = 0, arrowPadding: f = 0, avoidCollisions: p = true, collisionBoundary: m = [], collisionPadding: v = 0, sticky: g = "partial", hideWhenDetached: S = false, updatePositionStrategy: _ = "optimized", onPlaced: x, ...E } = e, C = C_(Um, r), [T, R] = y.useState(null), O = Ne(t, (ne) => R(ne)), [D, P] = y.useState(null), L = Pm(D), k = (_a4 = L == null ? void 0 : L.width) != null ? _a4 : 0, $ = (_b2 = L == null ? void 0 : L.height) != null ? _b2 : 0, re = a + (l !== "center" ? "-" + l : ""), G = typeof v == "number" ? v : { top: 0, right: 0, bottom: 0, left: 0, ...v }, ae = Array.isArray(m) ? m : [m], se = ae.length > 0, le = { padding: G, boundary: ae.filter(E8), altBoundary: se }, { refs: ue, floatingStyles: oe, placement: N, isPositioned: Z, middlewareData: B } = c8({ strategy: "fixed", placement: re, whileElementsMounted: (...ne) => W6(...ne, { animationFrame: _ === "always" }), elements: { reference: C.anchor }, middleware: [f8({ mainAxis: s + $, alignmentAxis: u }), p && d8({ mainAxis: true, crossAxis: false, limiter: g === "partial" ? h8() : void 0, ...le }), p && p8({ ...le }), m8({ ...le, apply: ({ elements: ne, rects: fe, availableWidth: xe, availableHeight: Re }) => {
      const { width: De, height: Le } = fe.reference, Ct = ne.floating.style;
      Ct.setProperty("--radix-popper-available-width", `${xe}px`), Ct.setProperty("--radix-popper-available-height", `${Re}px`), Ct.setProperty("--radix-popper-anchor-width", `${De}px`), Ct.setProperty("--radix-popper-anchor-height", `${Le}px`);
    } }), D && v8({ element: D, padding: f }), A8({ arrowWidth: k, arrowHeight: $ }), S && g8({ strategy: "referenceHidden", ...le })] }), [ce, me] = D_(N), M = rn(x);
    Et(() => {
      Z && (M == null ? void 0 : M());
    }, [Z, M]);
    const F = (_c3 = B.arrow) == null ? void 0 : _c3.x, X = (_d3 = B.arrow) == null ? void 0 : _d3.y, J = ((_e13 = B.arrow) == null ? void 0 : _e13.centerOffset) !== 0, [ie, ge] = y.useState();
    return Et(() => {
      T && ge(window.getComputedStyle(T).zIndex);
    }, [T]), b.jsx("div", { ref: ue.setFloating, "data-radix-popper-content-wrapper": "", style: { ...oe, transform: Z ? oe.transform : "translate(0, -200%)", minWidth: "max-content", zIndex: ie, "--radix-popper-transform-origin": [(_f2 = B.transformOrigin) == null ? void 0 : _f2.x, (_g2 = B.transformOrigin) == null ? void 0 : _g2.y].join(" "), ...((_h4 = B.hide) == null ? void 0 : _h4.referenceHidden) && { visibility: "hidden", pointerEvents: "none" } }, dir: e.dir, children: b.jsx(S8, { scope: r, placedSide: ce, onArrowChange: P, arrowX: F, arrowY: X, shouldHideArrow: J, children: b.jsx(Te.div, { "data-side": ce, "data-align": me, ...E, ref: O, style: { ...E.style, animation: Z ? void 0 : "none" } }) }) });
  });
  M_.displayName = Um;
  var N_ = "PopperArrow", _8 = { top: "bottom", right: "left", bottom: "top", left: "right" }, z_ = y.forwardRef(function(t, r) {
    const { __scopePopper: a, ...s } = t, l = x8(N_, a), u = _8[l.placedSide];
    return b.jsx("span", { ref: l.onArrowChange, style: { position: "absolute", left: l.arrowX, top: l.arrowY, [u]: 0, transformOrigin: { top: "", right: "0 0", bottom: "center 0", left: "100% 0" }[l.placedSide], transform: { top: "translateY(100%)", right: "translateY(50%) rotate(90deg) translateX(-50%)", bottom: "rotate(180deg)", left: "translateY(50%) rotate(-90deg) translateX(50%)" }[l.placedSide], visibility: l.shouldHideArrow ? "hidden" : void 0 }, children: b.jsx(b8, { ...s, ref: r, style: { ...s.style, display: "block" } }) });
  });
  z_.displayName = N_;
  function E8(e) {
    return e !== null;
  }
  var A8 = (e) => ({ name: "transformOrigin", options: e, fn(t) {
    var _a4, _b2, _c3, _d3, _e13;
    const { placement: r, rects: a, middlewareData: s } = t, u = ((_a4 = s.arrow) == null ? void 0 : _a4.centerOffset) !== 0, f = u ? 0 : e.arrowWidth, p = u ? 0 : e.arrowHeight, [m, v] = D_(r), g = { start: "0%", center: "50%", end: "100%" }[v], S = ((_c3 = (_b2 = s.arrow) == null ? void 0 : _b2.x) != null ? _c3 : 0) + f / 2, _ = ((_e13 = (_d3 = s.arrow) == null ? void 0 : _d3.y) != null ? _e13 : 0) + p / 2;
    let x = "", E = "";
    return m === "bottom" ? (x = u ? g : `${S}px`, E = `${-p}px`) : m === "top" ? (x = u ? g : `${S}px`, E = `${a.floating.height + p}px`) : m === "right" ? (x = `${-p}px`, E = u ? g : `${_}px`) : m === "left" && (x = `${a.floating.width + p}px`, E = u ? g : `${_}px`), { data: { x, y: E } };
  } });
  function D_(e) {
    const [t, r = "center"] = e.split("-");
    return [t, r];
  }
  var j_ = T_, k_ = R_, P_ = M_, L_ = z_;
  function C8(e) {
    const t = T8(e), r = y.forwardRef((a, s) => {
      const { children: l, ...u } = a, f = y.Children.toArray(l), p = f.find(R8);
      if (p) {
        const m = p.props.children, v = f.map((g) => g === p ? y.Children.count(m) > 1 ? y.Children.only(null) : y.isValidElement(m) ? m.props.children : null : g);
        return b.jsx(t, { ...u, ref: s, children: y.isValidElement(m) ? y.cloneElement(m, void 0, v) : null });
      }
      return b.jsx(t, { ...u, ref: s, children: l });
    });
    return r.displayName = `${e}.Slot`, r;
  }
  function T8(e) {
    const t = y.forwardRef((r, a) => {
      const { children: s, ...l } = r;
      if (y.isValidElement(s)) {
        const u = N8(s), f = M8(l, s.props);
        return s.type !== y.Fragment && (f.ref = a ? Ci(a, u) : u), y.cloneElement(s, f);
      }
      return y.Children.count(s) > 1 ? y.Children.only(null) : null;
    });
    return t.displayName = `${e}.SlotClone`, t;
  }
  var O8 = /* @__PURE__ */ Symbol("radix.slottable");
  function R8(e) {
    return y.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === O8;
  }
  function M8(e, t) {
    const r = { ...t };
    for (const a in t) {
      const s = e[a], l = t[a];
      /^on[A-Z]/.test(a) ? s && l ? r[a] = (...f) => {
        const p = l(...f);
        return s(...f), p;
      } : s && (r[a] = s) : a === "style" ? r[a] = { ...s, ...l } : a === "className" && (r[a] = [s, l].filter(Boolean).join(" "));
    }
    return { ...e, ...r };
  }
  function N8(e) {
    var _a4, _b2;
    let t = (_a4 = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : _a4.get, r = t && "isReactWarning" in t && t.isReactWarning;
    return r ? e.ref : (t = (_b2 = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : _b2.get, r = t && "isReactWarning" in t && t.isReactWarning, r ? e.props.ref : e.props.ref || e.ref);
  }
  function Bm(e) {
    const t = y.useRef({ value: e, previous: e });
    return y.useMemo(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e]);
  }
  var U_ = Object.freeze({ position: "absolute", border: 0, width: 1, height: 1, padding: 0, margin: -1, overflow: "hidden", clip: "rect(0, 0, 0, 0)", whiteSpace: "nowrap", wordWrap: "normal" }), z8 = "VisuallyHidden", B_ = y.forwardRef((e, t) => b.jsx(Te.span, { ...e, ref: t, style: { ...U_, ...e.style } }));
  B_.displayName = z8;
  var D8 = B_, j8 = [" ", "Enter", "ArrowUp", "ArrowDown"], k8 = [" ", "Enter"], pa = "Select", [Ju, Wu, P8] = _m(pa), [Ni, MI] = Fn(pa, [P8, Ku]), ef = Ku(), [L8, zo] = Ni(pa), [U8, B8] = Ni(pa), I_ = (e) => {
    const { __scopeSelect: t, children: r, open: a, defaultOpen: s, onOpenChange: l, value: u, defaultValue: f, onValueChange: p, dir: m, name: v, autoComplete: g, disabled: S, required: _, form: x } = e, E = ef(t), [C, T] = y.useState(null), [R, O] = y.useState(null), [D, P] = y.useState(false), L = Hu(m), [k, $] = Hr({ prop: a, defaultProp: s != null ? s : false, onChange: l, caller: pa }), [re, G] = Hr({ prop: u, defaultProp: f, onChange: p, caller: pa }), ae = y.useRef(null), se = C ? x || !!C.closest("form") : true, [le, ue] = y.useState(/* @__PURE__ */ new Set()), oe = Array.from(le).map((N) => N.props.value).join(";");
    return b.jsx(j_, { ...E, children: b.jsxs(L8, { required: _, scope: t, trigger: C, onTriggerChange: T, valueNode: R, onValueNodeChange: O, valueNodeHasChildren: D, onValueNodeHasChildrenChange: P, contentId: Br(), value: re, onValueChange: G, open: k, onOpenChange: $, dir: L, triggerPointerDownPosRef: ae, disabled: S, children: [b.jsx(Ju.Provider, { scope: t, children: b.jsx(U8, { scope: e.__scopeSelect, onNativeOptionAdd: y.useCallback((N) => {
      ue((Z) => new Set(Z).add(N));
    }, []), onNativeOptionRemove: y.useCallback((N) => {
      ue((Z) => {
        const B = new Set(Z);
        return B.delete(N), B;
      });
    }, []), children: r }) }), se ? b.jsxs(sE, { "aria-hidden": true, required: _, tabIndex: -1, name: v, autoComplete: g, value: re, onChange: (N) => G(N.target.value), disabled: S, form: x, children: [re === void 0 ? b.jsx("option", { value: "" }) : null, Array.from(le)] }, oe) : null] }) });
  };
  I_.displayName = pa;
  var H_ = "SelectTrigger", $_ = y.forwardRef((e, t) => {
    const { __scopeSelect: r, disabled: a = false, ...s } = e, l = ef(r), u = zo(H_, r), f = u.disabled || a, p = Ne(t, u.onTriggerChange), m = Wu(r), v = y.useRef("touch"), [g, S, _] = cE((E) => {
      const C = m().filter((O) => !O.disabled), T = C.find((O) => O.value === u.value), R = uE(C, E, T);
      R !== void 0 && u.onValueChange(R.value);
    }), x = (E) => {
      f || (u.onOpenChange(true), _()), E && (u.triggerPointerDownPosRef.current = { x: Math.round(E.pageX), y: Math.round(E.pageY) });
    };
    return b.jsx(k_, { asChild: true, ...l, children: b.jsx(Te.button, { type: "button", role: "combobox", "aria-controls": u.contentId, "aria-expanded": u.open, "aria-required": u.required, "aria-autocomplete": "none", dir: u.dir, "data-state": u.open ? "open" : "closed", disabled: f, "data-disabled": f ? "" : void 0, "data-placeholder": lE(u.value) ? "" : void 0, ...s, ref: p, onClick: Ee(s.onClick, (E) => {
      E.currentTarget.focus(), v.current !== "mouse" && x(E);
    }), onPointerDown: Ee(s.onPointerDown, (E) => {
      v.current = E.pointerType;
      const C = E.target;
      C.hasPointerCapture(E.pointerId) && C.releasePointerCapture(E.pointerId), E.button === 0 && E.ctrlKey === false && E.pointerType === "mouse" && (x(E), E.preventDefault());
    }), onKeyDown: Ee(s.onKeyDown, (E) => {
      const C = g.current !== "";
      !(E.ctrlKey || E.altKey || E.metaKey) && E.key.length === 1 && S(E.key), !(C && E.key === " ") && j8.includes(E.key) && (x(), E.preventDefault());
    }) }) });
  });
  $_.displayName = H_;
  var V_ = "SelectValue", Z_ = y.forwardRef((e, t) => {
    const { __scopeSelect: r, className: a, style: s, children: l, placeholder: u = "", ...f } = e, p = zo(V_, r), { onValueNodeHasChildrenChange: m } = p, v = l !== void 0, g = Ne(t, p.onValueNodeChange);
    return Et(() => {
      m(v);
    }, [m, v]), b.jsx(Te.span, { ...f, ref: g, style: { pointerEvents: "none" }, children: lE(p.value) ? b.jsx(b.Fragment, { children: u }) : l });
  });
  Z_.displayName = V_;
  var I8 = "SelectIcon", F_ = y.forwardRef((e, t) => {
    const { __scopeSelect: r, children: a, ...s } = e;
    return b.jsx(Te.span, { "aria-hidden": true, ...s, ref: t, children: a || "▼" });
  });
  F_.displayName = I8;
  var H8 = "SelectPortal", q_ = (e) => b.jsx(Uu, { asChild: true, ...e });
  q_.displayName = H8;
  var ma = "SelectContent", Y_ = y.forwardRef((e, t) => {
    const r = zo(ma, e.__scopeSelect), [a, s] = y.useState();
    if (Et(() => {
      s(new DocumentFragment());
    }, []), !r.open) {
      const l = a;
      return l ? Ai.createPortal(b.jsx(X_, { scope: e.__scopeSelect, children: b.jsx(Ju.Slot, { scope: e.__scopeSelect, children: b.jsx("div", { children: e.children }) }) }), l) : null;
    }
    return b.jsx(Q_, { ...e, ref: t });
  });
  Y_.displayName = ma;
  var Hn = 10, [X_, Do] = Ni(ma), $8 = "SelectContentImpl", V8 = C8("SelectContent.RemoveScroll"), Q_ = y.forwardRef((e, t) => {
    const { __scopeSelect: r, position: a = "item-aligned", onCloseAutoFocus: s, onEscapeKeyDown: l, onPointerDownOutside: u, side: f, sideOffset: p, align: m, alignOffset: v, arrowPadding: g, collisionBoundary: S, collisionPadding: _, sticky: x, hideWhenDetached: E, avoidCollisions: C, ...T } = e, R = zo(ma, r), [O, D] = y.useState(null), [P, L] = y.useState(null), k = Ne(t, (ne) => D(ne)), [$, re] = y.useState(null), [G, ae] = y.useState(null), se = Wu(r), [le, ue] = y.useState(false), oe = y.useRef(false);
    y.useEffect(() => {
      if (O) return Jx(O);
    }, [O]), Vx();
    const N = y.useCallback((ne) => {
      const [fe, ...xe] = se().map((Le) => Le.ref.current), [Re] = xe.slice(-1), De = document.activeElement;
      for (const Le of ne) if (Le === De || (Le == null ? void 0 : Le.scrollIntoView({ block: "nearest" }), Le === fe && P && (P.scrollTop = 0), Le === Re && P && (P.scrollTop = P.scrollHeight), Le == null ? void 0 : Le.focus(), document.activeElement !== De)) return;
    }, [se, P]), Z = y.useCallback(() => N([$, O]), [N, $, O]);
    y.useEffect(() => {
      le && Z();
    }, [le, Z]);
    const { onOpenChange: B, triggerPointerDownPosRef: ce } = R;
    y.useEffect(() => {
      if (O) {
        let ne = { x: 0, y: 0 };
        const fe = (Re) => {
          var _a4, _b2, _c3, _d3;
          ne = { x: Math.abs(Math.round(Re.pageX) - ((_b2 = (_a4 = ce.current) == null ? void 0 : _a4.x) != null ? _b2 : 0)), y: Math.abs(Math.round(Re.pageY) - ((_d3 = (_c3 = ce.current) == null ? void 0 : _c3.y) != null ? _d3 : 0)) };
        }, xe = (Re) => {
          ne.x <= 10 && ne.y <= 10 ? Re.preventDefault() : O.contains(Re.target) || B(false), document.removeEventListener("pointermove", fe), ce.current = null;
        };
        return ce.current !== null && (document.addEventListener("pointermove", fe), document.addEventListener("pointerup", xe, { capture: true, once: true })), () => {
          document.removeEventListener("pointermove", fe), document.removeEventListener("pointerup", xe, { capture: true });
        };
      }
    }, [O, B, ce]), y.useEffect(() => {
      const ne = () => B(false);
      return window.addEventListener("blur", ne), window.addEventListener("resize", ne), () => {
        window.removeEventListener("blur", ne), window.removeEventListener("resize", ne);
      };
    }, [B]);
    const [me, M] = cE((ne) => {
      const fe = se().filter((De) => !De.disabled), xe = fe.find((De) => De.ref.current === document.activeElement), Re = uE(fe, ne, xe);
      Re && setTimeout(() => Re.ref.current.focus());
    }), F = y.useCallback((ne, fe, xe) => {
      const Re = !oe.current && !xe;
      (R.value !== void 0 && R.value === fe || Re) && (re(ne), Re && (oe.current = true));
    }, [R.value]), X = y.useCallback(() => O == null ? void 0 : O.focus(), [O]), J = y.useCallback((ne, fe, xe) => {
      const Re = !oe.current && !xe;
      (R.value !== void 0 && R.value === fe || Re) && ae(ne);
    }, [R.value]), ie = a === "popper" ? _p : G_, ge = ie === _p ? { side: f, sideOffset: p, align: m, alignOffset: v, arrowPadding: g, collisionBoundary: S, collisionPadding: _, sticky: x, hideWhenDetached: E, avoidCollisions: C } : {};
    return b.jsx(X_, { scope: r, content: O, viewport: P, onViewportChange: L, itemRefCallback: F, selectedItem: $, onItemLeave: X, itemTextRefCallback: J, focusSelectedItem: Z, selectedItemText: G, position: a, isPositioned: le, searchRef: me, children: b.jsx(pm, { as: V8, allowPinchZoom: true, children: b.jsx(hm, { asChild: true, trapped: R.open, onMountAutoFocus: (ne) => {
      ne.preventDefault();
    }, onUnmountAutoFocus: Ee(s, (ne) => {
      var _a4;
      (_a4 = R.trigger) == null ? void 0 : _a4.focus({ preventScroll: true }), ne.preventDefault();
    }), children: b.jsx(Lu, { asChild: true, disableOutsidePointerEvents: true, onEscapeKeyDown: l, onPointerDownOutside: u, onFocusOutside: (ne) => ne.preventDefault(), onDismiss: () => R.onOpenChange(false), children: b.jsx(ie, { role: "listbox", id: R.contentId, "data-state": R.open ? "open" : "closed", dir: R.dir, onContextMenu: (ne) => ne.preventDefault(), ...T, ...ge, onPlaced: () => ue(true), ref: k, style: { display: "flex", flexDirection: "column", outline: "none", ...T.style }, onKeyDown: Ee(T.onKeyDown, (ne) => {
      const fe = ne.ctrlKey || ne.altKey || ne.metaKey;
      if (ne.key === "Tab" && ne.preventDefault(), !fe && ne.key.length === 1 && M(ne.key), ["ArrowUp", "ArrowDown", "Home", "End"].includes(ne.key)) {
        let Re = se().filter((De) => !De.disabled).map((De) => De.ref.current);
        if (["ArrowUp", "End"].includes(ne.key) && (Re = Re.slice().reverse()), ["ArrowUp", "ArrowDown"].includes(ne.key)) {
          const De = ne.target, Le = Re.indexOf(De);
          Re = Re.slice(Le + 1);
        }
        setTimeout(() => N(Re)), ne.preventDefault();
      }
    }) }) }) }) }) });
  });
  Q_.displayName = $8;
  var Z8 = "SelectItemAlignedPosition", G_ = y.forwardRef((e, t) => {
    const { __scopeSelect: r, onPlaced: a, ...s } = e, l = zo(ma, r), u = Do(ma, r), [f, p] = y.useState(null), [m, v] = y.useState(null), g = Ne(t, (k) => v(k)), S = Wu(r), _ = y.useRef(false), x = y.useRef(true), { viewport: E, selectedItem: C, selectedItemText: T, focusSelectedItem: R } = u, O = y.useCallback(() => {
      if (l.trigger && l.valueNode && f && m && E && C && T) {
        const k = l.trigger.getBoundingClientRect(), $ = m.getBoundingClientRect(), re = l.valueNode.getBoundingClientRect(), G = T.getBoundingClientRect();
        if (l.dir !== "rtl") {
          const De = G.left - $.left, Le = re.left - De, Ct = k.left - Le, yt = k.width + Ct, vr = Math.max(yt, $.width), Qn = window.innerWidth - Hn, jn = Xs(Le, [Hn, Math.max(Hn, Qn - vr)]);
          f.style.minWidth = yt + "px", f.style.left = jn + "px";
        } else {
          const De = $.right - G.right, Le = window.innerWidth - re.right - De, Ct = window.innerWidth - k.right - Le, yt = k.width + Ct, vr = Math.max(yt, $.width), Qn = window.innerWidth - Hn, jn = Xs(Le, [Hn, Math.max(Hn, Qn - vr)]);
          f.style.minWidth = yt + "px", f.style.right = jn + "px";
        }
        const ae = S(), se = window.innerHeight - Hn * 2, le = E.scrollHeight, ue = window.getComputedStyle(m), oe = parseInt(ue.borderTopWidth, 10), N = parseInt(ue.paddingTop, 10), Z = parseInt(ue.borderBottomWidth, 10), B = parseInt(ue.paddingBottom, 10), ce = oe + N + le + B + Z, me = Math.min(C.offsetHeight * 5, ce), M = window.getComputedStyle(E), F = parseInt(M.paddingTop, 10), X = parseInt(M.paddingBottom, 10), J = k.top + k.height / 2 - Hn, ie = se - J, ge = C.offsetHeight / 2, ne = C.offsetTop + ge, fe = oe + N + ne, xe = ce - fe;
        if (fe <= J) {
          const De = ae.length > 0 && C === ae[ae.length - 1].ref.current;
          f.style.bottom = "0px";
          const Le = m.clientHeight - E.offsetTop - E.offsetHeight, Ct = Math.max(ie, ge + (De ? X : 0) + Le + Z), yt = fe + Ct;
          f.style.height = yt + "px";
        } else {
          const De = ae.length > 0 && C === ae[0].ref.current;
          f.style.top = "0px";
          const Ct = Math.max(J, oe + E.offsetTop + (De ? F : 0) + ge) + xe;
          f.style.height = Ct + "px", E.scrollTop = fe - J + E.offsetTop;
        }
        f.style.margin = `${Hn}px 0`, f.style.minHeight = me + "px", f.style.maxHeight = se + "px", a == null ? void 0 : a(), requestAnimationFrame(() => _.current = true);
      }
    }, [S, l.trigger, l.valueNode, f, m, E, C, T, l.dir, a]);
    Et(() => O(), [O]);
    const [D, P] = y.useState();
    Et(() => {
      m && P(window.getComputedStyle(m).zIndex);
    }, [m]);
    const L = y.useCallback((k) => {
      k && x.current === true && (O(), R == null ? void 0 : R(), x.current = false);
    }, [O, R]);
    return b.jsx(q8, { scope: r, contentWrapper: f, shouldExpandOnScrollRef: _, onScrollButtonChange: L, children: b.jsx("div", { ref: p, style: { display: "flex", flexDirection: "column", position: "fixed", zIndex: D }, children: b.jsx(Te.div, { ...s, ref: g, style: { boxSizing: "border-box", maxHeight: "100%", ...s.style } }) }) });
  });
  G_.displayName = Z8;
  var F8 = "SelectPopperPosition", _p = y.forwardRef((e, t) => {
    const { __scopeSelect: r, align: a = "start", collisionPadding: s = Hn, ...l } = e, u = ef(r);
    return b.jsx(P_, { ...u, ...l, ref: t, align: a, collisionPadding: s, style: { boxSizing: "border-box", ...l.style, "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)", "--radix-select-content-available-width": "var(--radix-popper-available-width)", "--radix-select-content-available-height": "var(--radix-popper-available-height)", "--radix-select-trigger-width": "var(--radix-popper-anchor-width)", "--radix-select-trigger-height": "var(--radix-popper-anchor-height)" } });
  });
  _p.displayName = F8;
  var [q8, Im] = Ni(ma, {}), Ep = "SelectViewport", K_ = y.forwardRef((e, t) => {
    const { __scopeSelect: r, nonce: a, ...s } = e, l = Do(Ep, r), u = Im(Ep, r), f = Ne(t, l.onViewportChange), p = y.useRef(0);
    return b.jsxs(b.Fragment, { children: [b.jsx("style", { dangerouslySetInnerHTML: { __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}" }, nonce: a }), b.jsx(Ju.Slot, { scope: r, children: b.jsx(Te.div, { "data-radix-select-viewport": "", role: "presentation", ...s, ref: f, style: { position: "relative", flex: 1, overflow: "hidden auto", ...s.style }, onScroll: Ee(s.onScroll, (m) => {
      const v = m.currentTarget, { contentWrapper: g, shouldExpandOnScrollRef: S } = u;
      if ((S == null ? void 0 : S.current) && g) {
        const _ = Math.abs(p.current - v.scrollTop);
        if (_ > 0) {
          const x = window.innerHeight - Hn * 2, E = parseFloat(g.style.minHeight), C = parseFloat(g.style.height), T = Math.max(E, C);
          if (T < x) {
            const R = T + _, O = Math.min(x, R), D = R - O;
            g.style.height = O + "px", g.style.bottom === "0px" && (v.scrollTop = D > 0 ? D : 0, g.style.justifyContent = "flex-end");
          }
        }
      }
      p.current = v.scrollTop;
    }) }) })] });
  });
  K_.displayName = Ep;
  var J_ = "SelectGroup", [Y8, X8] = Ni(J_), Q8 = y.forwardRef((e, t) => {
    const { __scopeSelect: r, ...a } = e, s = Br();
    return b.jsx(Y8, { scope: r, id: s, children: b.jsx(Te.div, { role: "group", "aria-labelledby": s, ...a, ref: t }) });
  });
  Q8.displayName = J_;
  var W_ = "SelectLabel", G8 = y.forwardRef((e, t) => {
    const { __scopeSelect: r, ...a } = e, s = X8(W_, r);
    return b.jsx(Te.div, { id: s.id, ...a, ref: t });
  });
  G8.displayName = W_;
  var pu = "SelectItem", [K8, eE] = Ni(pu), tE = y.forwardRef((e, t) => {
    const { __scopeSelect: r, value: a, disabled: s = false, textValue: l, ...u } = e, f = zo(pu, r), p = Do(pu, r), m = f.value === a, [v, g] = y.useState(l != null ? l : ""), [S, _] = y.useState(false), x = Ne(t, (R) => {
      var _a4;
      return (_a4 = p.itemRefCallback) == null ? void 0 : _a4.call(p, R, a, s);
    }), E = Br(), C = y.useRef("touch"), T = () => {
      s || (f.onValueChange(a), f.onOpenChange(false));
    };
    if (a === "") throw new Error("A <Select.Item /> must have a value prop that is not an empty string. This is because the Select value can be set to an empty string to clear the selection and show the placeholder.");
    return b.jsx(K8, { scope: r, value: a, disabled: s, textId: E, isSelected: m, onItemTextChange: y.useCallback((R) => {
      g((O) => {
        var _a4;
        return O || ((_a4 = R == null ? void 0 : R.textContent) != null ? _a4 : "").trim();
      });
    }, []), children: b.jsx(Ju.ItemSlot, { scope: r, value: a, disabled: s, textValue: v, children: b.jsx(Te.div, { role: "option", "aria-labelledby": E, "data-highlighted": S ? "" : void 0, "aria-selected": m && S, "data-state": m ? "checked" : "unchecked", "aria-disabled": s || void 0, "data-disabled": s ? "" : void 0, tabIndex: s ? void 0 : -1, ...u, ref: x, onFocus: Ee(u.onFocus, () => _(true)), onBlur: Ee(u.onBlur, () => _(false)), onClick: Ee(u.onClick, () => {
      C.current !== "mouse" && T();
    }), onPointerUp: Ee(u.onPointerUp, () => {
      C.current === "mouse" && T();
    }), onPointerDown: Ee(u.onPointerDown, (R) => {
      C.current = R.pointerType;
    }), onPointerMove: Ee(u.onPointerMove, (R) => {
      var _a4;
      C.current = R.pointerType, s ? (_a4 = p.onItemLeave) == null ? void 0 : _a4.call(p) : C.current === "mouse" && R.currentTarget.focus({ preventScroll: true });
    }), onPointerLeave: Ee(u.onPointerLeave, (R) => {
      var _a4;
      R.currentTarget === document.activeElement && ((_a4 = p.onItemLeave) == null ? void 0 : _a4.call(p));
    }), onKeyDown: Ee(u.onKeyDown, (R) => {
      var _a4;
      ((_a4 = p.searchRef) == null ? void 0 : _a4.current) !== "" && R.key === " " || (k8.includes(R.key) && T(), R.key === " " && R.preventDefault());
    }) }) }) });
  });
  tE.displayName = pu;
  var Ls = "SelectItemText", nE = y.forwardRef((e, t) => {
    const { __scopeSelect: r, className: a, style: s, ...l } = e, u = zo(Ls, r), f = Do(Ls, r), p = eE(Ls, r), m = B8(Ls, r), [v, g] = y.useState(null), S = Ne(t, (T) => g(T), p.onItemTextChange, (T) => {
      var _a4;
      return (_a4 = f.itemTextRefCallback) == null ? void 0 : _a4.call(f, T, p.value, p.disabled);
    }), _ = v == null ? void 0 : v.textContent, x = y.useMemo(() => b.jsx("option", { value: p.value, disabled: p.disabled, children: _ }, p.value), [p.disabled, p.value, _]), { onNativeOptionAdd: E, onNativeOptionRemove: C } = m;
    return Et(() => (E(x), () => C(x)), [E, C, x]), b.jsxs(b.Fragment, { children: [b.jsx(Te.span, { id: p.textId, ...l, ref: S }), p.isSelected && u.valueNode && !u.valueNodeHasChildren ? Ai.createPortal(l.children, u.valueNode) : null] });
  });
  nE.displayName = Ls;
  var rE = "SelectItemIndicator", J8 = y.forwardRef((e, t) => {
    const { __scopeSelect: r, ...a } = e;
    return eE(rE, r).isSelected ? b.jsx(Te.span, { "aria-hidden": true, ...a, ref: t }) : null;
  });
  J8.displayName = rE;
  var Ap = "SelectScrollUpButton", oE = y.forwardRef((e, t) => {
    const r = Do(Ap, e.__scopeSelect), a = Im(Ap, e.__scopeSelect), [s, l] = y.useState(false), u = Ne(t, a.onScrollButtonChange);
    return Et(() => {
      if (r.viewport && r.isPositioned) {
        let f = function() {
          const m = p.scrollTop > 0;
          l(m);
        };
        const p = r.viewport;
        return f(), p.addEventListener("scroll", f), () => p.removeEventListener("scroll", f);
      }
    }, [r.viewport, r.isPositioned]), s ? b.jsx(iE, { ...e, ref: u, onAutoScroll: () => {
      const { viewport: f, selectedItem: p } = r;
      f && p && (f.scrollTop = f.scrollTop - p.offsetHeight);
    } }) : null;
  });
  oE.displayName = Ap;
  var Cp = "SelectScrollDownButton", aE = y.forwardRef((e, t) => {
    const r = Do(Cp, e.__scopeSelect), a = Im(Cp, e.__scopeSelect), [s, l] = y.useState(false), u = Ne(t, a.onScrollButtonChange);
    return Et(() => {
      if (r.viewport && r.isPositioned) {
        let f = function() {
          const m = p.scrollHeight - p.clientHeight, v = Math.ceil(p.scrollTop) < m;
          l(v);
        };
        const p = r.viewport;
        return f(), p.addEventListener("scroll", f), () => p.removeEventListener("scroll", f);
      }
    }, [r.viewport, r.isPositioned]), s ? b.jsx(iE, { ...e, ref: u, onAutoScroll: () => {
      const { viewport: f, selectedItem: p } = r;
      f && p && (f.scrollTop = f.scrollTop + p.offsetHeight);
    } }) : null;
  });
  aE.displayName = Cp;
  var iE = y.forwardRef((e, t) => {
    const { __scopeSelect: r, onAutoScroll: a, ...s } = e, l = Do("SelectScrollButton", r), u = y.useRef(null), f = Wu(r), p = y.useCallback(() => {
      u.current !== null && (window.clearInterval(u.current), u.current = null);
    }, []);
    return y.useEffect(() => () => p(), [p]), Et(() => {
      var _a4, _b2;
      (_b2 = (_a4 = f().find((v) => v.ref.current === document.activeElement)) == null ? void 0 : _a4.ref.current) == null ? void 0 : _b2.scrollIntoView({ block: "nearest" });
    }, [f]), b.jsx(Te.div, { "aria-hidden": true, ...s, ref: t, style: { flexShrink: 0, ...s.style }, onPointerDown: Ee(s.onPointerDown, () => {
      u.current === null && (u.current = window.setInterval(a, 50));
    }), onPointerMove: Ee(s.onPointerMove, () => {
      var _a4;
      (_a4 = l.onItemLeave) == null ? void 0 : _a4.call(l), u.current === null && (u.current = window.setInterval(a, 50));
    }), onPointerLeave: Ee(s.onPointerLeave, () => {
      p();
    }) });
  }), W8 = "SelectSeparator", eL = y.forwardRef((e, t) => {
    const { __scopeSelect: r, ...a } = e;
    return b.jsx(Te.div, { "aria-hidden": true, ...a, ref: t });
  });
  eL.displayName = W8;
  var Tp = "SelectArrow", tL = y.forwardRef((e, t) => {
    const { __scopeSelect: r, ...a } = e, s = ef(r), l = zo(Tp, r), u = Do(Tp, r);
    return l.open && u.position === "popper" ? b.jsx(L_, { ...s, ...a, ref: t }) : null;
  });
  tL.displayName = Tp;
  var nL = "SelectBubbleInput", sE = y.forwardRef(({ __scopeSelect: e, value: t, ...r }, a) => {
    const s = y.useRef(null), l = Ne(a, s), u = Bm(t);
    return y.useEffect(() => {
      const f = s.current;
      if (!f) return;
      const p = window.HTMLSelectElement.prototype, v = Object.getOwnPropertyDescriptor(p, "value").set;
      if (u !== t && v) {
        const g = new Event("change", { bubbles: true });
        v.call(f, t), f.dispatchEvent(g);
      }
    }, [u, t]), b.jsx(Te.select, { ...r, style: { ...U_, ...r.style }, ref: l, defaultValue: t });
  });
  sE.displayName = nL;
  function lE(e) {
    return e === "" || e === void 0;
  }
  function cE(e) {
    const t = rn(e), r = y.useRef(""), a = y.useRef(0), s = y.useCallback((u) => {
      const f = r.current + u;
      t(f), (function p(m) {
        r.current = m, window.clearTimeout(a.current), m !== "" && (a.current = window.setTimeout(() => p(""), 1e3));
      })(f);
    }, [t]), l = y.useCallback(() => {
      r.current = "", window.clearTimeout(a.current);
    }, []);
    return y.useEffect(() => () => window.clearTimeout(a.current), []), [r, s, l];
  }
  function uE(e, t, r) {
    const s = t.length > 1 && Array.from(t).every((m) => m === t[0]) ? t[0] : t, l = r ? e.indexOf(r) : -1;
    let u = rL(e, Math.max(l, 0));
    s.length === 1 && (u = u.filter((m) => m !== r));
    const p = u.find((m) => m.textValue.toLowerCase().startsWith(s.toLowerCase()));
    return p !== r ? p : void 0;
  }
  function rL(e, t) {
    return e.map((r, a) => e[(t + a) % e.length]);
  }
  var oL = I_, aL = $_, iL = Z_, sL = F_, lL = q_, cL = Y_, uL = K_, fL = tE, dL = nE, hL = oE, pL = aE;
  function Op({ ...e }) {
    return b.jsx(oL, { "data-slot": "select", ...e });
  }
  function Rp({ ...e }) {
    return b.jsx(iL, { "data-slot": "select-value", ...e });
  }
  function Mp({ className: e, size: t = "default", children: r, ...a }) {
    return b.jsxs(aL, { "data-slot": "select-trigger", "data-size": t, className: Pe("data-[placeholder]:text-muted-foreground [&_svg:not([class*='text-'])]:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive flex w-fit items-center justify-between gap-2 rounded-md px-3 py-2 text-sm whitespace-nowraptransition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 data-[size=default]:h-9 data-[size=sm]:h-8 *:data-[slot=select-value]:line-clamp-1 *:data-[slot=select-value]:flex *:data-[slot=select-value]:items-center *:data-[slot=select-value]:gap-2 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 select-none border bg-card hover:bg-background/50 dark:hover:bg-input/30", e), ...a, children: [r, b.jsx(sL, { asChild: true, children: b.jsx(ym, { className: "size-4 opacity-50" }) })] });
  }
  function Np({ className: e, children: t, position: r = "popper", ...a }) {
    return b.jsx(lL, { children: b.jsxs(cL, { "data-slot": "select-content", className: Pe("bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 relative z-99992 max-h-(--radix-select-content-available-height) min-w-[8rem] origin-(--radix-select-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border shadow-md", r === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", e), position: r, ...a, children: [b.jsx(mL, {}), b.jsx(uL, { className: Pe("p-1", r === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)] scroll-my-1"), children: t }), b.jsx(gL, {})] }) });
  }
  function ci({ className: e, children: t, ...r }) {
    return b.jsx(fL, { "data-slot": "select-item", className: Pe("[&_svg:not([class*='text-'])]:text-muted-foreground relative flex w-full cursor-pointer items-center gap-2 rounded-sm py-1.5 pr-8 pl-2 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 *:[span]:last:flex *:[span]:last:items-center *:[span]:last:gap-2 focus:bg-background/70 dark:focus:bg-input/30 hover:bg-background/50 dark:hover:bg-input/30 ", e), ...r, children: b.jsx(dL, { children: t }) });
  }
  function mL({ className: e, ...t }) {
    return b.jsx(hL, { "data-slot": "select-scroll-up-button", className: Pe("flex cursor-default items-center justify-center py-1", e), ...t, children: b.jsx(Hk, { className: "size-4" }) });
  }
  function gL({ className: e, ...t }) {
    return b.jsx(pL, { "data-slot": "select-scroll-down-button", className: Pe("flex cursor-default items-center justify-center py-1", e), ...t, children: b.jsx(ym, { className: "size-4" }) });
  }
  var vL = /* @__PURE__ */ Symbol.for("react.lazy"), mu = nm[" use ".trim().toString()];
  function yL(e) {
    return typeof e == "object" && e !== null && "then" in e;
  }
  function fE(e) {
    return e != null && typeof e == "object" && "$$typeof" in e && e.$$typeof === vL && "_payload" in e && yL(e._payload);
  }
  function Hm(e) {
    const t = wL(e), r = y.forwardRef((a, s) => {
      let { children: l, ...u } = a;
      fE(l) && typeof mu == "function" && (l = mu(l._payload));
      const f = y.Children.toArray(l), p = f.find(xL);
      if (p) {
        const m = p.props.children, v = f.map((g) => g === p ? y.Children.count(m) > 1 ? y.Children.only(null) : y.isValidElement(m) ? m.props.children : null : g);
        return b.jsx(t, { ...u, ref: s, children: y.isValidElement(m) ? y.cloneElement(m, void 0, v) : null });
      }
      return b.jsx(t, { ...u, ref: s, children: l });
    });
    return r.displayName = `${e}.Slot`, r;
  }
  var bL = Hm("Slot");
  function wL(e) {
    const t = y.forwardRef((r, a) => {
      let { children: s, ...l } = r;
      if (fE(s) && typeof mu == "function" && (s = mu(s._payload)), y.isValidElement(s)) {
        const u = EL(s), f = _L(l, s.props);
        return s.type !== y.Fragment && (f.ref = a ? Ci(a, u) : u), y.cloneElement(s, f);
      }
      return y.Children.count(s) > 1 ? y.Children.only(null) : null;
    });
    return t.displayName = `${e}.SlotClone`, t;
  }
  var SL = /* @__PURE__ */ Symbol("radix.slottable");
  function xL(e) {
    return y.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === SL;
  }
  function _L(e, t) {
    const r = { ...t };
    for (const a in t) {
      const s = e[a], l = t[a];
      /^on[A-Z]/.test(a) ? s && l ? r[a] = (...f) => {
        const p = l(...f);
        return s(...f), p;
      } : s && (r[a] = s) : a === "style" ? r[a] = { ...s, ...l } : a === "className" && (r[a] = [s, l].filter(Boolean).join(" "));
    }
    return { ...e, ...r };
  }
  function EL(e) {
    var _a4, _b2;
    let t = (_a4 = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : _a4.get, r = t && "isReactWarning" in t && t.isReactWarning;
    return r ? e.ref : (t = (_b2 = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : _b2.get, r = t && "isReactWarning" in t && t.isReactWarning, r ? e.props.ref : e.props.ref || e.ref);
  }
  var AL = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "select", "span", "svg", "ul"], CL = AL.reduce((e, t) => {
    const r = Hm(`Primitive.${t}`), a = y.forwardRef((s, l) => {
      const { asChild: u, ...f } = s, p = u ? r : t;
      return typeof window < "u" && (window[/* @__PURE__ */ Symbol.for("radix-ui")] = true), b.jsx(p, { ...f, ref: l });
    });
    return a.displayName = `Primitive.${t}`, { ...e, [t]: a };
  }, {}), TL = "Label", dE = y.forwardRef((e, t) => b.jsx(CL.label, { ...e, ref: t, onMouseDown: (r) => {
    var _a4;
    r.target.closest("button, input, select, textarea") || ((_a4 = e.onMouseDown) == null ? void 0 : _a4.call(e, r), !r.defaultPrevented && r.detail > 1 && r.preventDefault());
  } }));
  dE.displayName = TL;
  var OL = dE;
  function sr({ className: e, ...t }) {
    return b.jsx(OL, { "data-slot": "label", className: Pe("text-foreground flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", e), ...t });
  }
  var tf = "Switch", [RL, NI] = Fn(tf), [ML, NL] = RL(tf), hE = y.forwardRef((e, t) => {
    const { __scopeSwitch: r, name: a, checked: s, defaultChecked: l, required: u, disabled: f, value: p = "on", onCheckedChange: m, form: v, ...g } = e, [S, _] = y.useState(null), x = Ne(t, (O) => _(O)), E = y.useRef(false), C = S ? v || !!S.closest("form") : true, [T, R] = Hr({ prop: s, defaultProp: l != null ? l : false, onChange: m, caller: tf });
    return b.jsxs(ML, { scope: r, checked: T, disabled: f, children: [b.jsx(Te.button, { type: "button", role: "switch", "aria-checked": T, "aria-required": u, "data-state": vE(T), "data-disabled": f ? "" : void 0, disabled: f, value: p, ...g, ref: x, onClick: Ee(e.onClick, (O) => {
      R((D) => !D), C && (E.current = O.isPropagationStopped(), E.current || O.stopPropagation());
    }) }), C && b.jsx(gE, { control: S, bubbles: !E.current, name: a, value: p, checked: T, required: u, disabled: f, form: v, style: { transform: "translateX(-100%)" } })] });
  });
  hE.displayName = tf;
  var pE = "SwitchThumb", mE = y.forwardRef((e, t) => {
    const { __scopeSwitch: r, ...a } = e, s = NL(pE, r);
    return b.jsx(Te.span, { "data-state": vE(s.checked), "data-disabled": s.disabled ? "" : void 0, ...a, ref: t });
  });
  mE.displayName = pE;
  var zL = "SwitchBubbleInput", gE = y.forwardRef(({ __scopeSwitch: e, control: t, checked: r, bubbles: a = true, ...s }, l) => {
    const u = y.useRef(null), f = Ne(u, l), p = Bm(r), m = Pm(t);
    return y.useEffect(() => {
      const v = u.current;
      if (!v) return;
      const g = window.HTMLInputElement.prototype, _ = Object.getOwnPropertyDescriptor(g, "checked").set;
      if (p !== r && _) {
        const x = new Event("click", { bubbles: a });
        _.call(v, r), v.dispatchEvent(x);
      }
    }, [p, r, a]), b.jsx("input", { type: "checkbox", "aria-hidden": true, defaultChecked: r, ...s, tabIndex: -1, ref: f, style: { ...s.style, ...m, position: "absolute", pointerEvents: "none", opacity: 0, margin: 0 } });
  });
  gE.displayName = zL;
  function vE(e) {
    return e ? "checked" : "unchecked";
  }
  var DL = hE, jL = mE;
  function lr({ className: e, ...t }) {
    return b.jsx(DL, { "data-slot": "switch", className: Pe("peer data-[state=checked]:bg-primary data-[state=unchecked]:bg-input focus-visible:border-ring focus-visible:ring-ring/50 dark:data-[state=unchecked]:bg-input/80 inline-flex h-[1.15rem] w-8 shrink-0 items-center rounded-full border border-transparent shadow-xs transition-all outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 cursor-pointer", e), ...t, children: b.jsx(jL, { "data-slot": "switch-thumb", className: Pe("bg-background dark:data-[state=unchecked]:bg-foreground dark:data-[state=checked]:bg-primary-foreground pointer-events-none block size-4 rounded-full ring-0 transition-transform data-[state=checked]:translate-x-[calc(100%-2px)] data-[state=unchecked]:translate-x-0") }) });
  }
  function Eo(e) {
    return e.condition ? e.children : e.fallback;
  }
  const zp = [{ name: "DotumChe Pixel", family: "DotumChe Pixel", extraStylesheet: '*:not(.UserID-Avatar-Image):not(img[class*="ArtistCard_image__"]) { border-radius: 0 !important; }' }, { name: "Dwarven Stonecraft", family: "Dwarven Stonecraft" }, { name: "Izax SHA", family: "Izax SHA" }, { name: "Sjz", family: "Sjz" }, { name: "JetBrains Mono", family: "JetBrains Mono" }], Ds = zp.map((e) => e.name);
  function kL() {
    const [e, t] = y.useState(false), [r, a] = y.useState(Ds[0]);
    return y.useEffect(() => {
      (async () => {
        let s = await window.xlamModz.getStorageValue("font-changer/savedFont");
        s = Ds.find((u) => u === s) || Ds[0];
        const l = await window.xlamModz.getStorageValue("font-changer/enabled") || false;
        t(l || false), a(s || Ds[0]);
      })();
    }, []), b.jsx(mr, { title: "Шрифты XLam", icon: b.jsx(g5, { className: "h-4 w-4" }), children: b.jsxs("div", { className: "flex flex-col gap-5 pt-2 px-3", children: [b.jsxs("div", { className: "flex items-center gap-3", children: [b.jsx(lr, { id: "font-changer-toggle", checked: e, onCheckedChange: (s) => {
      t(s), window.xlamModz.setStorageValue("font-changer/enabled", s);
    } }), b.jsx(sr, { htmlFor: "font-changer-toggle", className: "cursor-pointer", children: "Заменить шрифты в приложении" })] }), b.jsx(Eo, { condition: e, children: b.jsxs("div", { className: "flex gap-4 items-center justify-center", children: [b.jsx("span", { className: "text-sm text-foreground", children: "Шрифт:" }), b.jsxs(Op, { value: r, onValueChange: (s) => {
      a(s), window.xlamModz.setStorageValue("font-changer/savedFont", s);
    }, disabled: !e, children: [b.jsx(Mp, { className: "w-full text-foreground", children: b.jsx(Rp, { placeholder: "Выбрать шрифт" }) }), b.jsx(Np, { children: Ds.map((s) => b.jsx(ci, { value: s, children: s })) })] })] }) })] }) });
  }
  const Bw = (e) => typeof e == "boolean" ? `${e}` : e === 0 ? "0" : e, Iw = E1, yE = (e, t) => (r) => {
    var a;
    if ((t == null ? void 0 : t.variants) == null) return Iw(e, r == null ? void 0 : r.class, r == null ? void 0 : r.className);
    const { variants: s, defaultVariants: l } = t, u = Object.keys(s).map((m) => {
      const v = r == null ? void 0 : r[m], g = l == null ? void 0 : l[m];
      if (v === null) return null;
      const S = Bw(v) || Bw(g);
      return s[m][S];
    }), f = r && Object.entries(r).reduce((m, v) => {
      let [g, S] = v;
      return S === void 0 || (m[g] = S), m;
    }, {}), p = t == null || (a = t.compoundVariants) === null || a === void 0 ? void 0 : a.reduce((m, v) => {
      let { class: g, className: S, ..._ } = v;
      return Object.entries(_).every((x) => {
        let [E, C] = x;
        return Array.isArray(C) ? C.includes({ ...l, ...f }[E]) : { ...l, ...f }[E] === C;
      }) ? [...m, g, S] : m;
    }, []);
    return Iw(e, u, p, r == null ? void 0 : r.class, r == null ? void 0 : r.className);
  }, PL = yE("relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current", { variants: { variant: { default: "bg-transparent text-card-foreground", destructive: "text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90" } }, defaultVariants: { variant: "default" } });
  function Ks({ className: e, variant: t, ...r }) {
    return b.jsx("div", { "data-slot": "alert", role: "alert", className: Pe(PL({ variant: t }), e), ...r });
  }
  function bE({ className: e, ...t }) {
    return b.jsx("div", { "data-slot": "alert-description", className: Pe("text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed", e), ...t });
  }
  function LL() {
    const [e, t] = y.useState(false), [r, a] = y.useState(false);
    return y.useEffect(() => {
      (async () => (t(await window.xlamModz.getStorageValue("devtools/enabled") || false), a(await window.xlamModz.getStorageValue("devtools/systemToolbar") || false)))();
    }, []), b.jsx(mr, { title: "Для разработчиков", icon: b.jsx(Fk, { className: "h-4 w-4" }), children: b.jsxs("div", { className: "flex flex-col gap-5 pt-2 px-3", children: [b.jsxs("div", { className: "flex items-center gap-3", children: [b.jsx(lr, { id: "devtools-toggle", checked: e, onCheckedChange: (s) => {
      t(s), window.xlamModz.setStorageValue("devtools/enabled", s);
    } }), b.jsx(sr, { htmlFor: "devtools-toggle", className: "cursor-pointer", children: "Включить режим разработчика" })] }), b.jsxs("div", { className: "flex items-center gap-3", children: [b.jsx(lr, { id: "systemToolbar-toggle", checked: r, onCheckedChange: (s) => {
      a(s), window.xlamModz.setStorageValue("devtools/systemToolbar", s);
    } }), b.jsx(sr, { htmlFor: "systemToolbar-toggle", className: "cursor-pointer", children: "Включить системную рамку окна" })] }), b.jsxs(Ks, { variant: "default", className: "cursor-default", children: [b.jsx(Ys, {}), b.jsx(bE, { children: "Потребуется перезапуск" })] })] }) });
  }
  function UL(e) {
    const t = Object.keys(e).find((r) => r.startsWith("__reactFiber$"));
    return t ? e[t] : null;
  }
  function BL(e) {
    let t = e;
    for (; t == null ? void 0 : t.return; ) t = t.return;
    return t || null;
  }
  function Dp(e, t, r = 0) {
    if (!e) return null;
    const a = t(e, r);
    if (a != null) return a;
    const s = Dp(e.child, t, r + 1);
    if (s != null) return s;
    const l = Dp(e.sibling, t, r);
    return l != null ? l : null;
  }
  function IL(e, t) {
    if (!e) throw "Element is not defined.";
    const r = UL(e);
    if (r) {
      const a = BL(r);
      return Dp(a, (l, u) => l.memoizedProps && l.memoizedProps.hasOwnProperty(t) ? l.memoizedProps : null);
    } else throw "Fiber node not found for the given element.";
  }
  const HL = 'section[data-test-id="PLAYERBAR_DESKTOP"]';
  let Hw = false;
  function $L() {
    const e = document.querySelector(HL);
    if (!e) return Se("Player element not found in DOM");
    const t = IL(e, "entityMeta");
    if (!t) return Se("Fiber not found");
    const r = t.entityMeta;
    if (!r) return Se("entityMeta not found");
    if (r.title === "Промокод Upgrade") return Hw || (console.warn("[getTrackMeta] Обнаружена реклама в плеере"), V4("upgrade_promocode", { extra: { track: r } })), Hw = true, Se("upgrade_promocode");
    const s = Eh({ id: wo(), title: wo(), durationMs: Os(), albumId: Os(), type: wo(), genre: wo(), isAvailable: S0(), artists: op(Eh({ id: wo(), name: wo() })), albums: op(Eh({ id: Os(), title: wo(), year: Os().optional(), isAvailable: S0(), genre: wo().optional(), trackCount: Os() })).optional() }).safeParse(r);
    return s.error ? Se(`Validation error: ${s.error.message} for ${JSON.stringify(r, null, 2)}`) : it(JSON.parse(JSON.stringify({ ...r })));
  }
  const VL = yE("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive cursor-pointer select-none", { variants: { variant: { default: "bg-primary text-primary-foreground shadow-xs hover:bg-primary/90", destructive: "bg-destructive text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60", outline: "border bg-card shadow-xs border-input hover:bg-background dark:hover:bg-input/30", secondary: "border bg-card shadow-xs border-input hover:bg-background dark:hover:bg-input/30", ghost: " bg-card shadow-xs hover:bg-background dark:hover:bg-input/30 ", link: "text-primary underline-offset-4 hover:underline" }, size: { default: "h-9 px-4 py-2 has-[>svg]:px-3", sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5", lg: "h-10 rounded-md px-6 has-[>svg]:px-4", icon: "size-9" } }, defaultVariants: { variant: "default", size: "default" } });
  function Dt({ className: e, variant: t, size: r, asChild: a = false, ...s }) {
    const l = a ? bL : "button";
    return b.jsx(l, { "data-slot": "button", className: Pe(VL({ variant: t, size: r, className: e })), ...s });
  }
  function ZL(e, t = []) {
    let r = [];
    function a(l, u) {
      const f = y.createContext(u);
      f.displayName = l + "Context";
      const p = r.length;
      r = [...r, u];
      const m = (g) => {
        var _a4;
        const { scope: S, children: _, ...x } = g, E = ((_a4 = S == null ? void 0 : S[e]) == null ? void 0 : _a4[p]) || f, C = y.useMemo(() => x, Object.values(x));
        return b.jsx(E.Provider, { value: C, children: _ });
      };
      m.displayName = l + "Provider";
      function v(g, S) {
        var _a4;
        const _ = ((_a4 = S == null ? void 0 : S[e]) == null ? void 0 : _a4[p]) || f, x = y.useContext(_);
        if (x) return x;
        if (u !== void 0) return u;
        throw new Error(`\`${g}\` must be used within \`${l}\``);
      }
      return [m, v];
    }
    const s = () => {
      const l = r.map((u) => y.createContext(u));
      return function(f) {
        const p = (f == null ? void 0 : f[e]) || l;
        return y.useMemo(() => ({ [`__scope${e}`]: { ...f, [e]: p } }), [f, p]);
      };
    };
    return s.scopeName = e, [a, FL(s, ...t)];
  }
  function FL(...e) {
    const t = e[0];
    if (e.length === 1) return t;
    const r = () => {
      const a = e.map((s) => ({ useScope: s(), scopeName: s.scopeName }));
      return function(l) {
        const u = a.reduce((f, { useScope: p, scopeName: m }) => {
          const g = p(l)[`__scope${m}`];
          return { ...f, ...g };
        }, {});
        return y.useMemo(() => ({ [`__scope${t.scopeName}`]: u }), [u]);
      };
    };
    return r.scopeName = t.scopeName, r;
  }
  var qL = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "select", "span", "svg", "ul"], wE = qL.reduce((e, t) => {
    const r = Hm(`Primitive.${t}`), a = y.forwardRef((s, l) => {
      const { asChild: u, ...f } = s, p = u ? r : t;
      return typeof window < "u" && (window[/* @__PURE__ */ Symbol.for("radix-ui")] = true), b.jsx(p, { ...f, ref: l });
    });
    return a.displayName = `Primitive.${t}`, { ...e, [t]: a };
  }, {}), $m = "Progress", Vm = 100, [YL, zI] = ZL($m), [XL, QL] = YL($m), SE = y.forwardRef((e, t) => {
    const { __scopeProgress: r, value: a = null, max: s, getValueLabel: l = GL, ...u } = e;
    (s || s === 0) && !$w(s) && console.error(KL(`${s}`, "Progress"));
    const f = $w(s) ? s : Vm;
    a !== null && !Vw(a, f) && console.error(JL(`${a}`, "Progress"));
    const p = Vw(a, f) ? a : null, m = gu(p) ? l(p, f) : void 0;
    return b.jsx(XL, { scope: r, value: p, max: f, children: b.jsx(wE.div, { "aria-valuemax": f, "aria-valuemin": 0, "aria-valuenow": gu(p) ? p : void 0, "aria-valuetext": m, role: "progressbar", "data-state": EE(p, f), "data-value": p != null ? p : void 0, "data-max": f, ...u, ref: t }) });
  });
  SE.displayName = $m;
  var xE = "ProgressIndicator", _E = y.forwardRef((e, t) => {
    var _a4;
    const { __scopeProgress: r, ...a } = e, s = QL(xE, r);
    return b.jsx(wE.div, { "data-state": EE(s.value, s.max), "data-value": (_a4 = s.value) != null ? _a4 : void 0, "data-max": s.max, ...a, ref: t });
  });
  _E.displayName = xE;
  function GL(e, t) {
    return `${Math.round(e / t * 100)}%`;
  }
  function EE(e, t) {
    return e == null ? "indeterminate" : e === t ? "complete" : "loading";
  }
  function gu(e) {
    return typeof e == "number";
  }
  function $w(e) {
    return gu(e) && !isNaN(e) && e > 0;
  }
  function Vw(e, t) {
    return gu(e) && !isNaN(e) && e <= t && e >= 0;
  }
  function KL(e, t) {
    return `Invalid prop \`max\` of value \`${e}\` supplied to \`${t}\`. Only numbers greater than 0 are valid max values. Defaulting to \`${Vm}\`.`;
  }
  function JL(e, t) {
    return `Invalid prop \`value\` of value \`${e}\` supplied to \`${t}\`. The \`value\` prop must be:
  - a positive number
  - less than the value passed to \`max\` (or ${Vm} if no \`max\` prop is set)
  - \`null\` or \`undefined\` if the progress is indeterminate.

Defaulting to \`null\`.`;
  }
  var WL = SE, e9 = _E;
  function AE({ className: e, value: t, ...r }) {
    return b.jsx(WL, { "data-slot": "progress", className: Pe("bg-primary/20 relative h-2 w-full overflow-hidden rounded-full", e), ...r, children: b.jsx(e9, { "data-slot": "progress-indicator", className: "bg-primary h-full w-full flex-1 transition-all", style: { transform: `translateX(-${100 - (t || 0)}%)` } }) });
  }
  function Zm({ className: e, type: t, ...r }) {
    return b.jsx("input", { type: t, "data-slot": "input", className: Pe("file:text-foreground text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground border-input flex h-9 w-full min-w-0 rounded-md border  px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]", "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive border shadow-xs border-input bg-transparent hover:bg-background/30 dark:hover:bg-input/10 transition-colors duration-100 ease-in-out", e), ...r });
  }
  var t9 = /* @__PURE__ */ Symbol("radix.slottable");
  function n9(e) {
    const t = ({ children: r }) => b.jsx(b.Fragment, { children: r });
    return t.displayName = `${e}.Slottable`, t.__radixId = t9, t;
  }
  var [nf, DI] = Fn("Tooltip", [Ku]), rf = Ku(), CE = "TooltipProvider", r9 = 700, jp = "tooltip.open", [o9, Fm] = nf(CE), TE = (e) => {
    const { __scopeTooltip: t, delayDuration: r = r9, skipDelayDuration: a = 300, disableHoverableContent: s = false, children: l } = e, u = y.useRef(true), f = y.useRef(false), p = y.useRef(0);
    return y.useEffect(() => {
      const m = p.current;
      return () => window.clearTimeout(m);
    }, []), b.jsx(o9, { scope: t, isOpenDelayedRef: u, delayDuration: r, onOpen: y.useCallback(() => {
      window.clearTimeout(p.current), u.current = false;
    }, []), onClose: y.useCallback(() => {
      window.clearTimeout(p.current), p.current = window.setTimeout(() => u.current = true, a);
    }, [a]), isPointerInTransitRef: f, onPointerInTransitChange: y.useCallback((m) => {
      f.current = m;
    }, []), disableHoverableContent: s, children: l });
  };
  TE.displayName = CE;
  var Js = "Tooltip", [a9, cl] = nf(Js), OE = (e) => {
    const { __scopeTooltip: t, children: r, open: a, defaultOpen: s, onOpenChange: l, disableHoverableContent: u, delayDuration: f } = e, p = Fm(Js, e.__scopeTooltip), m = rf(t), [v, g] = y.useState(null), S = Br(), _ = y.useRef(0), x = u != null ? u : p.disableHoverableContent, E = f != null ? f : p.delayDuration, C = y.useRef(false), [T, R] = Hr({ prop: a, defaultProp: s != null ? s : false, onChange: (k) => {
      k ? (p.onOpen(), document.dispatchEvent(new CustomEvent(jp))) : p.onClose(), l == null ? void 0 : l(k);
    }, caller: Js }), O = y.useMemo(() => T ? C.current ? "delayed-open" : "instant-open" : "closed", [T]), D = y.useCallback(() => {
      window.clearTimeout(_.current), _.current = 0, C.current = false, R(true);
    }, [R]), P = y.useCallback(() => {
      window.clearTimeout(_.current), _.current = 0, R(false);
    }, [R]), L = y.useCallback(() => {
      window.clearTimeout(_.current), _.current = window.setTimeout(() => {
        C.current = true, R(true), _.current = 0;
      }, E);
    }, [E, R]);
    return y.useEffect(() => () => {
      _.current && (window.clearTimeout(_.current), _.current = 0);
    }, []), b.jsx(j_, { ...m, children: b.jsx(a9, { scope: t, contentId: S, open: T, stateAttribute: O, trigger: v, onTriggerChange: g, onTriggerEnter: y.useCallback(() => {
      p.isOpenDelayedRef.current ? L() : D();
    }, [p.isOpenDelayedRef, L, D]), onTriggerLeave: y.useCallback(() => {
      x ? P() : (window.clearTimeout(_.current), _.current = 0);
    }, [P, x]), onOpen: D, onClose: P, disableHoverableContent: x, children: r }) });
  };
  OE.displayName = Js;
  var kp = "TooltipTrigger", RE = y.forwardRef((e, t) => {
    const { __scopeTooltip: r, ...a } = e, s = cl(kp, r), l = Fm(kp, r), u = rf(r), f = y.useRef(null), p = Ne(t, f, s.onTriggerChange), m = y.useRef(false), v = y.useRef(false), g = y.useCallback(() => m.current = false, []);
    return y.useEffect(() => () => document.removeEventListener("pointerup", g), [g]), b.jsx(k_, { asChild: true, ...u, children: b.jsx(Te.button, { "aria-describedby": s.open ? s.contentId : void 0, "data-state": s.stateAttribute, ...a, ref: p, onPointerMove: Ee(e.onPointerMove, (S) => {
      S.pointerType !== "touch" && !v.current && !l.isPointerInTransitRef.current && (s.onTriggerEnter(), v.current = true);
    }), onPointerLeave: Ee(e.onPointerLeave, () => {
      s.onTriggerLeave(), v.current = false;
    }), onPointerDown: Ee(e.onPointerDown, () => {
      s.open && s.onClose(), m.current = true, document.addEventListener("pointerup", g, { once: true });
    }), onFocus: Ee(e.onFocus, () => {
      m.current || s.onOpen();
    }), onBlur: Ee(e.onBlur, s.onClose), onClick: Ee(e.onClick, s.onClose) }) });
  });
  RE.displayName = kp;
  var qm = "TooltipPortal", [i9, s9] = nf(qm, { forceMount: void 0 }), ME = (e) => {
    const { __scopeTooltip: t, forceMount: r, children: a, container: s } = e, l = cl(qm, t);
    return b.jsx(i9, { scope: t, forceMount: r, children: b.jsx(qn, { present: r || l.open, children: b.jsx(Uu, { asChild: true, container: s, children: a }) }) });
  };
  ME.displayName = qm;
  var xi = "TooltipContent", NE = y.forwardRef((e, t) => {
    const r = s9(xi, e.__scopeTooltip), { forceMount: a = r.forceMount, side: s = "top", ...l } = e, u = cl(xi, e.__scopeTooltip);
    return b.jsx(qn, { present: a || u.open, children: u.disableHoverableContent ? b.jsx(zE, { side: s, ...l, ref: t }) : b.jsx(l9, { side: s, ...l, ref: t }) });
  }), l9 = y.forwardRef((e, t) => {
    const r = cl(xi, e.__scopeTooltip), a = Fm(xi, e.__scopeTooltip), s = y.useRef(null), l = Ne(t, s), [u, f] = y.useState(null), { trigger: p, onClose: m } = r, v = s.current, { onPointerInTransitChange: g } = a, S = y.useCallback(() => {
      f(null), g(false);
    }, [g]), _ = y.useCallback((x, E) => {
      const C = x.currentTarget, T = { x: x.clientX, y: x.clientY }, R = d9(T, C.getBoundingClientRect()), O = h9(T, R), D = p9(E.getBoundingClientRect()), P = g9([...O, ...D]);
      f(P), g(true);
    }, [g]);
    return y.useEffect(() => () => S(), [S]), y.useEffect(() => {
      if (p && v) {
        const x = (C) => _(C, v), E = (C) => _(C, p);
        return p.addEventListener("pointerleave", x), v.addEventListener("pointerleave", E), () => {
          p.removeEventListener("pointerleave", x), v.removeEventListener("pointerleave", E);
        };
      }
    }, [p, v, _, S]), y.useEffect(() => {
      if (u) {
        const x = (E) => {
          const C = E.target, T = { x: E.clientX, y: E.clientY }, R = (p == null ? void 0 : p.contains(C)) || (v == null ? void 0 : v.contains(C)), O = !m9(T, u);
          R ? S() : O && (S(), m());
        };
        return document.addEventListener("pointermove", x), () => document.removeEventListener("pointermove", x);
      }
    }, [p, v, u, m, S]), b.jsx(zE, { ...e, ref: l });
  }), [c9, u9] = nf(Js, { isInside: false }), f9 = n9("TooltipContent"), zE = y.forwardRef((e, t) => {
    const { __scopeTooltip: r, children: a, "aria-label": s, onEscapeKeyDown: l, onPointerDownOutside: u, ...f } = e, p = cl(xi, r), m = rf(r), { onClose: v } = p;
    return y.useEffect(() => (document.addEventListener(jp, v), () => document.removeEventListener(jp, v)), [v]), y.useEffect(() => {
      if (p.trigger) {
        const g = (S) => {
          var _a4;
          ((_a4 = S.target) == null ? void 0 : _a4.contains(p.trigger)) && v();
        };
        return window.addEventListener("scroll", g, { capture: true }), () => window.removeEventListener("scroll", g, { capture: true });
      }
    }, [p.trigger, v]), b.jsx(Lu, { asChild: true, disableOutsidePointerEvents: false, onEscapeKeyDown: l, onPointerDownOutside: u, onFocusOutside: (g) => g.preventDefault(), onDismiss: v, children: b.jsxs(P_, { "data-state": p.stateAttribute, ...m, ...f, ref: t, style: { ...f.style, "--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)", "--radix-tooltip-content-available-width": "var(--radix-popper-available-width)", "--radix-tooltip-content-available-height": "var(--radix-popper-available-height)", "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)", "--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)" }, children: [b.jsx(f9, { children: a }), b.jsx(c9, { scope: r, isInside: true, children: b.jsx(D8, { id: p.contentId, role: "tooltip", children: s || a }) })] }) });
  });
  NE.displayName = xi;
  var DE = "TooltipArrow", jE = y.forwardRef((e, t) => {
    const { __scopeTooltip: r, ...a } = e, s = rf(r);
    return u9(DE, r).isInside ? null : b.jsx(L_, { ...s, ...a, ref: t });
  });
  jE.displayName = DE;
  function d9(e, t) {
    const r = Math.abs(t.top - e.y), a = Math.abs(t.bottom - e.y), s = Math.abs(t.right - e.x), l = Math.abs(t.left - e.x);
    switch (Math.min(r, a, s, l)) {
      case l:
        return "left";
      case s:
        return "right";
      case r:
        return "top";
      case a:
        return "bottom";
      default:
        throw new Error("unreachable");
    }
  }
  function h9(e, t, r = 5) {
    const a = [];
    switch (t) {
      case "top":
        a.push({ x: e.x - r, y: e.y + r }, { x: e.x + r, y: e.y + r });
        break;
      case "bottom":
        a.push({ x: e.x - r, y: e.y - r }, { x: e.x + r, y: e.y - r });
        break;
      case "left":
        a.push({ x: e.x + r, y: e.y - r }, { x: e.x + r, y: e.y + r });
        break;
      case "right":
        a.push({ x: e.x - r, y: e.y - r }, { x: e.x - r, y: e.y + r });
        break;
    }
    return a;
  }
  function p9(e) {
    const { top: t, right: r, bottom: a, left: s } = e;
    return [{ x: s, y: t }, { x: r, y: t }, { x: r, y: a }, { x: s, y: a }];
  }
  function m9(e, t) {
    const { x: r, y: a } = e;
    let s = false;
    for (let l = 0, u = t.length - 1; l < t.length; u = l++) {
      const f = t[l], p = t[u], m = f.x, v = f.y, g = p.x, S = p.y;
      v > a != S > a && r < (g - m) * (a - v) / (S - v) + m && (s = !s);
    }
    return s;
  }
  function g9(e) {
    const t = e.slice();
    return t.sort((r, a) => r.x < a.x ? -1 : r.x > a.x ? 1 : r.y < a.y ? -1 : r.y > a.y ? 1 : 0), v9(t);
  }
  function v9(e) {
    if (e.length <= 1) return e.slice();
    const t = [];
    for (let a = 0; a < e.length; a++) {
      const s = e[a];
      for (; t.length >= 2; ) {
        const l = t[t.length - 1], u = t[t.length - 2];
        if ((l.x - u.x) * (s.y - u.y) >= (l.y - u.y) * (s.x - u.x)) t.pop();
        else break;
      }
      t.push(s);
    }
    t.pop();
    const r = [];
    for (let a = e.length - 1; a >= 0; a--) {
      const s = e[a];
      for (; r.length >= 2; ) {
        const l = r[r.length - 1], u = r[r.length - 2];
        if ((l.x - u.x) * (s.y - u.y) >= (l.y - u.y) * (s.x - u.x)) r.pop();
        else break;
      }
      r.push(s);
    }
    return r.pop(), t.length === 1 && r.length === 1 && t[0].x === r[0].x && t[0].y === r[0].y ? t : t.concat(r);
  }
  var y9 = TE, b9 = OE, w9 = RE, S9 = ME, x9 = NE, _9 = jE;
  function E9({ delayDuration: e = 0, ...t }) {
    return b.jsx(y9, { "data-slot": "tooltip-provider", delayDuration: e, ...t });
  }
  function vu({ ...e }) {
    return b.jsx(E9, { children: b.jsx(b9, { "data-slot": "tooltip", ...e }) });
  }
  function yu({ ...e }) {
    return b.jsx(w9, { "data-slot": "tooltip-trigger", ...e });
  }
  function bu({ className: e, sideOffset: t = 0, children: r, ...a }) {
    return b.jsx(S9, { children: b.jsxs(x9, { "data-slot": "tooltip-content", sideOffset: t, className: Pe("bg-background text-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 border-border z-[99999] w-fit origin-(--radix-tooltip-content-transform-origin) rounded-md border px-3 py-1.5 text-xs text-balance", e), ...a, children: [r, b.jsx(_9, { className: "text-background bg-background fill-background z-[99999] size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px]" })] }) });
  }
  const A9 = { [hi.LOSSLESS]: "Максимальное", [hi.NQ]: "Среднее", [hi.LQ]: "Низкое" };
  function C9() {
    const [e, t] = y.useState(0), [r, a] = y.useState(hi.LOSSLESS), [s, l] = y.useState(false), [u, f] = y.useState(0), [p, m] = y.useState(""), [v, g] = y.useState(null), S = y.useRef(false);
    y.useEffect(() => {
      (async () => {
        try {
          const k = await window.xlamModz.getStorageValue("downloadFolderPath");
          k && g(k);
        } catch (k) {
          console.warn("Failed to load download folder path:", k);
        }
      })();
    }, []);
    const _ = async (L) => {
      try {
        await window.xlamModz.setStorageValue("downloadFolderPath", L), g(L);
      } catch (k) {
        console.error("Failed to save download folder path:", k), Ve.error("Не удалось сохранить путь к папке");
      }
    }, x = async () => {
      try {
        const L = await window.xlamModz.selectDownloadFolder();
        L.success && L.path && (await _(L.path), Ve.success("Папка для загрузки выбрана", { description: L.path }));
      } catch (L) {
        console.error("Failed to select folder:", L), Ve.error("Не удалось выбрать папку");
      }
    }, E = async () => {
      if (!v) {
        Ve.warning("Папка не выбрана");
        return;
      }
      try {
        const L = await window.xlamModz.openFolder(v);
        L.success || Ve.error("Не удалось открыть папку", { description: L.error || "Неизвестная ошибка" });
      } catch (L) {
        console.error("Failed to open folder:", L), Ve.error("Не удалось открыть папку");
      }
    }, C = window.location.href.includes("/artist") ? 1 : window.location.href.includes("/playlists") ? 2 : window.location.href.includes("/album") ? 3 : 0;
    y.useEffect(() => {
      t(C);
    }, [C]);
    const T = new URLSearchParams(window.location.search), R = C === 1 ? T.get("artistId") : C === 3 ? T.get("albumId") : C === 2 ? T.get("playlistUuid") : null, O = Ux({ queryKey: ["player-test-track-meta"], queryFn: async () => {
      const L = $L();
      if (L.isErr()) throw L.error;
      return L.value;
    }, enabled: true, retry: false, staleTime: 500, refetchInterval: 500 });
    async function D(L, k) {
      const $ = [];
      for (var G = 0; G < L.length; G += 50) {
        if (m(`Получение информации о треках ${(G / L.length * 100).toFixed(2)}%`), f(G / L.length * 100), S.current) return;
        const se = L.slice(G, G + 50);
        var ae = await hx(se, true);
        if (console.log("[Downloader] get tracks info", se, ae), ae.isErr()) return console.error("[Downloader] get tracks info", ae.error), Ve.error(`Произошла ошибка при получении информации о треках (${G * 50} / ${L.length})`, { description: ae.error });
        $.push(...ae.value), await new Promise((le) => setTimeout(le, 300));
      }
      console.log("[Downloader] tracks info", $);
      for (var G = 0; G < $.length; G++) {
        if (m(`Скачивание треков ${G + 1} / ${$.length}`), f(G / $.length * 100), S.current) return;
        const le = `${$[G].artists.map((N) => N.name).join(", ")} - ${$[G].title}`;
        if ($[G].available === false) {
          console.log("[Downloader] Track is not available", $[G]), Ve.warning("Трек недоступен", { description: le });
          continue;
        }
        const ue = await fx($[G].id, k);
        if (ue.isErr()) {
          console.log("[Downloader] DownloadUrl not available", $[G]), Ve.error("Не удалось получить ссылку для загрузки трека", { description: le });
          continue;
        }
        oj("tracks_downloaded", 1), console.log("[Downloader] got track download url", $[G], ue.value);
        const oe = await window.xlamModz.downloadTrack(ue.value, $[G], v || "");
        if (oe.error) {
          console.error("[Downloader] error while downloading track", oe.error), Ve.error("Не удалось скачать трек", { description: oe.error });
          continue;
        }
        console.log("[Downloader] downloadResult", oe), await new Promise((N) => setTimeout(N, 300));
      }
    }
    async function P() {
      if (s) {
        S.current = true, l(false), m(""), f(0);
        return;
      }
      switch (S.current = false, l(true), e) {
        case 0:
          await D([O.data.id], r);
          break;
        case 3:
          if (R) {
            const L = await Kz(R);
            if (L.isErr()) {
              Ve.error("Произошла ошибка", { description: L.error });
              return;
            }
            await D(L.value, r);
          }
          break;
        case 1:
          if (R) {
            const L = await Jz(R);
            if (L.isErr()) {
              Ve.error("Произошла ошибка", { description: L.error });
              return;
            }
            await D(L.value, r);
          }
          break;
        case 2:
          if (R) {
            const L = await dx(R);
            if (L.isErr()) {
              Ve.error("Произошла ошибка", { description: L.error });
              return;
            }
            await D(L.value, r);
          }
          break;
        default:
          Ve.error("Неизвестный тип загрузки");
          break;
      }
      l(false);
    }
    return b.jsx(mr, { title: "Скачать треки", icon: b.jsx(Yk, { className: "h-4 w-4" }), opened: true, children: b.jsxs("div", { className: "flex flex-col gap-5 pt-2 px-3", children: [b.jsx(Eo, { condition: s, children: b.jsxs("div", { className: "flex flex-col gap-3", children: [b.jsx("span", { className: "text-sm text-foreground text-center", children: p }), b.jsx(AE, { value: u })] }) }), b.jsxs("div", { className: "flex gap-4 items-center justify-center", children: [b.jsx("span", { className: "text-sm text-foreground", children: "Скачать" }), b.jsxs(Op, { value: e.toString(), onValueChange: (L) => t(parseInt(L, 10)), children: [b.jsx(Mp, { className: "text-foreground w-full", children: b.jsx(Rp, { className: "text-foreground" }) }), b.jsxs(Np, { children: [b.jsx(ci, { value: "0", children: "Текущий трек" }), b.jsx(Eo, { condition: C === 3, children: b.jsx(ci, { value: "3", children: "Весь альбом" }) }), b.jsx(Eo, { condition: C === 2, children: b.jsx(ci, { value: "2", children: "Весь плейлист" }) }), b.jsx(Eo, { condition: C === 1, children: b.jsx(ci, { value: "1", children: "Все треки артиста" }) })] })] })] }), b.jsxs("div", { className: "flex gap-4 items-center justify-center", children: [b.jsx("span", { className: "text-sm text-foreground", children: "Качество" }), b.jsxs(Op, { value: r, onValueChange: (L) => a(L), children: [b.jsx(Mp, { className: "text-foreground w-full", children: b.jsx(Rp, { className: "text-foreground" }) }), b.jsx(Np, { children: Object.values(hi).map((L) => b.jsx(ci, { value: L, children: A9[L] }, L)) })] })] }), b.jsxs("div", { className: "flex gap-3", children: [b.jsx(Zm, { type: "text", value: v || "Папка не выбрана", readOnly: true, className: "flex-1 text-sm cursor-default w-full", placeholder: "Выберите папку для загрузки" }), b.jsxs(vu, { children: [b.jsx(yu, { children: b.jsx(Dt, { variant: "outline", size: "sm", className: "p-2 h-9 w-9", onClick: x, disabled: s, children: b.jsx(Wk, { className: "h-4 w-4" }) }) }), b.jsx(bu, { children: b.jsx("p", { children: "Выбрать папку" }) })] }), b.jsxs(vu, { children: [b.jsx(yu, { children: b.jsx(Dt, { variant: "outline", size: "sm", className: "p-2 h-9 w-9", onClick: E, disabled: !v, children: b.jsx(Kk, { className: "h-4 w-4" }) }) }), b.jsx(bu, { children: b.jsx("p", { children: "Открыть папку" }) })] })] }), b.jsx(Dt, { variant: "default", className: "w-auto", disabled: (!O.isSuccess || !O.data.id) && C === 0, onClick: P, children: s ? "Стоп" : "Скачать" }), b.jsxs(Ks, { variant: "default", className: "cursor-default", children: [b.jsx(Ys, {}), b.jsx("div", { className: "text-sm text-muted-foreground", children: "Для загрузки всех треков артиста, плейлиста или альбома - откройте соответствующую страницу" })] })] }) });
  }
  function T9() {
    const [e, t] = y.useState(true);
    return y.useEffect(() => {
      (async () => t(await window.xlamModz.getStorageValue("autoBestQuality/enabled") !== false))();
    }, []), b.jsx(mr, { title: "Авто-выбор качества", icon: b.jsx(y5, { className: "h-4 w-4" }), children: b.jsx("div", { className: "flex flex-col gap-5 pt-2 px-3", children: b.jsxs("div", { className: "flex items-center gap-3", children: [b.jsx(lr, { id: "auto-quality-toggle", checked: e, onCheckedChange: (r) => {
      t(r), window.xlamModz.setStorageValue("autoBestQuality/enabled", r);
    } }), b.jsx(sr, { htmlFor: "auto-quality-toggle", className: "cursor-pointer", children: "Высокое качество музыки по умолчанию" })] }) }) });
  }
  function O9() {
    try {
      const e = localStorage.getItem("oauth");
      if (!e) return null;
      const t = JSON.parse(e);
      return (t == null ? void 0 : t.value) ? "OAuth " + t.value : null;
    } catch (e) {
      return console.error("[xlam-modz] failed to parse oauth from localStorage:", e), null;
    }
  }
  function R9() {
    async function e() {
      try {
        const t = O9(), r = await rt.get("https://api.music.yandex.net/account/experiments/details", { method: "GET", headers: { "x-yandex-music-client": "YandexMusicDesktopAppWindows/" + window.VERSION, "x-yandex-music-without-invocation-info": "1", Authorization: t } });
        if (r.status !== 200) {
          console.error("Failed to save experiments", r.status), Ve.error("Не удалось получить данные аккаунта");
          return;
        }
        const a = { accessToken: t, experiments: r.data };
        await navigator.clipboard.writeText(JSON.stringify(a)), Ve.success("Данные авторизации скопированы");
      } catch (t) {
        console.error("[xlam-modz] copy auth data failed:", t), Ve.error("Не удалось скопировать данные авторизации");
      }
    }
    return b.jsx(mr, { title: "Настройки", icon: b.jsx(l5, { className: "h-4 w-4" }), children: b.jsx("div", { className: "flex flex-col gap-5 pt-2 px-3", children: b.jsx("div", { className: "flex items-center gap-3", children: b.jsxs(vu, { children: [b.jsx(yu, { className: "w-full", children: b.jsx(Dt, { onClick: e, className: "w-full", children: "Скопировать данные авторизации" }) }), b.jsxs(bu, { side: "right", children: [b.jsx("p", { children: "Копирует OAuth-токен и эксперименты аккаунта в буфер обмена." }), b.jsx("p", { children: "Никому не передавайте эти данные." })] })] }) }) }) });
  }
  function M9() {
    const [e, t] = y.useState(false), [r, a] = y.useState(0), [s, l] = y.useState(""), [u, f] = y.useState(""), p = y.useRef(false), m = async () => {
      var _a4;
      if (e) {
        p.current = true;
        return;
      }
      p.current = false, t(true), a(0), l("Получение информации о плейлисте");
      const g = ((_a4 = u.match(/playlists\/([a-z0-9-\.]+)/)) == null ? void 0 : _a4[1]) || "";
      if (!g) {
        Ve.error("Произошла ошибка", { description: "Не удалось получить информацию о плейлисте" }), t(false);
        return;
      }
      const S = await dx(g);
      if (S.isErr()) {
        Ve.error("Произошла ошибка", { description: S.error }), t(false);
        return;
      }
      const _ = S.value.reverse(), x = await eD();
      if (x.isErr()) {
        Ve.error("Произошла ошибка", { description: x.error }), t(false);
        return;
      }
      const E = x.value.uid;
      console.log("[AutoLiker] userId", E);
      for (var C = 0; C < _.length; C++) {
        if (p.current) {
          t(false);
          return;
        }
        l(`Добавление треков ${C + 1} / ${_.length}`), a(C / _.length * 100);
        const T = await Wz(E, _[C]);
        if (T.isErr()) {
          Ve.error("Произошла ошибка", { description: T.error });
          continue;
        }
        await new Promise((R) => setTimeout(R, 300));
      }
      t(false);
    }, v = async () => {
      var _a4;
      const g = await tD();
      if (g.isErr()) return Ve.error("Произошла ошибка", { description: g.error });
      if (!((_a4 = g.value.favorites) == null ? void 0 : _a4.playlistUuid)) return Ve.error("Произошла ошибка", { description: "Не удалось получить информацию о плейлисте" });
      const S = await nD("userMusicVisibility", "PUBLIC");
      if (S.isErr()) return Ve.error("Произошла ошибка", { description: S.error });
      await navigator.clipboard.writeText(`https://music.yandex.ru/playlists/${g.value.favorites.playlistUuid}`), Ve.success("Ссылка скопирована", { description: "Ссылка на плейлист скопирована в буфер обмена" });
    };
    return b.jsx(mr, { title: "Перенести треки из плейлиста", icon: b.jsx(t5, { className: "h-4 w-4" }), opened: false, children: b.jsxs("div", { className: "flex flex-col gap-5 pt-2 px-3", children: [b.jsxs(Ks, { variant: "default", className: "cursor-default", children: [b.jsx(Ys, {}), b.jsx("div", { className: "text-sm text-muted-foreground", children: "Мод поставит лайки под каждым треком в плейлисте, это нужно для переноса музыки с другого аккаунта" })] }), b.jsx(Eo, { condition: e, children: b.jsxs("div", { className: "flex flex-col gap-3", children: [b.jsx("span", { className: "text-sm text-foreground text-center", children: s }), b.jsx(AE, { value: r })] }) }), b.jsx("div", { className: "flex gap-4 items-center justify-center", children: b.jsx(Zm, { type: "text", defaultValue: u, onChange: (g) => f(g.target.value), disabled: e, className: "flex-1 text-sm cursor-default w-full", placeholder: "Ссылка на плейлист" }) }), b.jsx(Dt, { variant: "default", className: "w-full", onClick: m, disabled: u.length === 0, children: e ? "Стоп" : "Перенести треки" }), b.jsx("div", { className: "w-full my-2 border-b border-border" }), b.jsx(Dt, { variant: "default", className: "w-full", onClick: v, children: "Ссылка на Мою коллекцию" })] }) });
  }
  function N9(e, t, r) {
    return t in e ? Object.defineProperty(e, t, { value: r, enumerable: true, configurable: true, writable: true }) : e[t] = r, e;
  }
  function Zw(e, t) {
    var r = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var a = Object.getOwnPropertySymbols(e);
      t && (a = a.filter(function(s) {
        return Object.getOwnPropertyDescriptor(e, s).enumerable;
      })), r.push.apply(r, a);
    }
    return r;
  }
  function Fw(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t] != null ? arguments[t] : {};
      t % 2 ? Zw(Object(r), true).forEach(function(a) {
        N9(e, a, r[a]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Zw(Object(r)).forEach(function(a) {
        Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(r, a));
      });
    }
    return e;
  }
  function z9(e, t) {
    if (e == null) return {};
    var r = {}, a = Object.keys(e), s, l;
    for (l = 0; l < a.length; l++) s = a[l], !(t.indexOf(s) >= 0) && (r[s] = e[s]);
    return r;
  }
  function D9(e, t) {
    if (e == null) return {};
    var r = z9(e, t), a, s;
    if (Object.getOwnPropertySymbols) {
      var l = Object.getOwnPropertySymbols(e);
      for (s = 0; s < l.length; s++) a = l[s], !(t.indexOf(a) >= 0) && Object.prototype.propertyIsEnumerable.call(e, a) && (r[a] = e[a]);
    }
    return r;
  }
  function j9(e, t) {
    return k9(e) || P9(e, t) || L9(e, t) || U9();
  }
  function k9(e) {
    if (Array.isArray(e)) return e;
  }
  function P9(e, t) {
    if (!(typeof Symbol > "u" || !(Symbol.iterator in Object(e)))) {
      var r = [], a = true, s = false, l = void 0;
      try {
        for (var u = e[Symbol.iterator](), f; !(a = (f = u.next()).done) && (r.push(f.value), !(t && r.length === t)); a = true) ;
      } catch (p) {
        s = true, l = p;
      } finally {
        try {
          !a && u.return != null && u.return();
        } finally {
          if (s) throw l;
        }
      }
      return r;
    }
  }
  function L9(e, t) {
    if (e) {
      if (typeof e == "string") return qw(e, t);
      var r = Object.prototype.toString.call(e).slice(8, -1);
      if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
      if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return qw(e, t);
    }
  }
  function qw(e, t) {
    (t == null || t > e.length) && (t = e.length);
    for (var r = 0, a = new Array(t); r < t; r++) a[r] = e[r];
    return a;
  }
  function U9() {
    throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  function B9(e, t, r) {
    return t in e ? Object.defineProperty(e, t, { value: r, enumerable: true, configurable: true, writable: true }) : e[t] = r, e;
  }
  function Yw(e, t) {
    var r = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var a = Object.getOwnPropertySymbols(e);
      t && (a = a.filter(function(s) {
        return Object.getOwnPropertyDescriptor(e, s).enumerable;
      })), r.push.apply(r, a);
    }
    return r;
  }
  function Xw(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t] != null ? arguments[t] : {};
      t % 2 ? Yw(Object(r), true).forEach(function(a) {
        B9(e, a, r[a]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Yw(Object(r)).forEach(function(a) {
        Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(r, a));
      });
    }
    return e;
  }
  function I9() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
    return function(a) {
      return t.reduceRight(function(s, l) {
        return l(s);
      }, a);
    };
  }
  function Us(e) {
    return function t() {
      for (var r = this, a = arguments.length, s = new Array(a), l = 0; l < a; l++) s[l] = arguments[l];
      return s.length >= e.length ? e.apply(this, s) : function() {
        for (var u = arguments.length, f = new Array(u), p = 0; p < u; p++) f[p] = arguments[p];
        return t.apply(r, [].concat(s, f));
      };
    };
  }
  function wu(e) {
    return {}.toString.call(e).includes("Object");
  }
  function H9(e) {
    return !Object.keys(e).length;
  }
  function Ws(e) {
    return typeof e == "function";
  }
  function $9(e, t) {
    return Object.prototype.hasOwnProperty.call(e, t);
  }
  function V9(e, t) {
    return wu(t) || Co("changeType"), Object.keys(t).some(function(r) {
      return !$9(e, r);
    }) && Co("changeField"), t;
  }
  function Z9(e) {
    Ws(e) || Co("selectorType");
  }
  function F9(e) {
    Ws(e) || wu(e) || Co("handlerType"), wu(e) && Object.values(e).some(function(t) {
      return !Ws(t);
    }) && Co("handlersType");
  }
  function q9(e) {
    e || Co("initialIsRequired"), wu(e) || Co("initialType"), H9(e) && Co("initialContent");
  }
  function Y9(e, t) {
    throw new Error(e[t] || e.default);
  }
  var X9 = { initialIsRequired: "initial state is required", initialType: "initial state should be an object", initialContent: "initial state shouldn't be an empty object", handlerType: "handler should be an object or a function", handlersType: "all handlers should be a functions", selectorType: "selector should be a function", changeType: "provided value of changes should be an object", changeField: 'it seams you want to change a field in the state which is not specified in the "initial" state', default: "an unknown error accured in `state-local` package" }, Co = Us(Y9)(X9), Ic = { changes: V9, selector: Z9, handler: F9, initial: q9 };
  function Q9(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    Ic.initial(e), Ic.handler(t);
    var r = { current: e }, a = Us(J9)(r, t), s = Us(K9)(r), l = Us(Ic.changes)(e), u = Us(G9)(r);
    function f() {
      var m = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : function(v) {
        return v;
      };
      return Ic.selector(m), m(r.current);
    }
    function p(m) {
      I9(a, s, l, u)(m);
    }
    return [f, p];
  }
  function G9(e, t) {
    return Ws(t) ? t(e.current) : t;
  }
  function K9(e, t) {
    return e.current = Xw(Xw({}, e.current), t), t;
  }
  function J9(e, t, r) {
    return Ws(t) ? t(e.current) : Object.keys(r).forEach(function(a) {
      var s;
      return (s = t[a]) === null || s === void 0 ? void 0 : s.call(t, e.current[a]);
    }), r;
  }
  var W9 = { create: Q9 }, eU = { paths: { vs: "https://cdn.jsdelivr.net/npm/monaco-editor@0.52.2/min/vs" } };
  function tU(e) {
    return function t() {
      for (var r = this, a = arguments.length, s = new Array(a), l = 0; l < a; l++) s[l] = arguments[l];
      return s.length >= e.length ? e.apply(this, s) : function() {
        for (var u = arguments.length, f = new Array(u), p = 0; p < u; p++) f[p] = arguments[p];
        return t.apply(r, [].concat(s, f));
      };
    };
  }
  function nU(e) {
    return {}.toString.call(e).includes("Object");
  }
  function rU(e) {
    return e || Qw("configIsRequired"), nU(e) || Qw("configType"), e.urls ? (oU(), { paths: { vs: e.urls.monacoBase } }) : e;
  }
  function oU() {
    console.warn(kE.deprecation);
  }
  function aU(e, t) {
    throw new Error(e[t] || e.default);
  }
  var kE = { configIsRequired: "the configuration object is required", configType: "the configuration object should be an object", default: "an unknown error accured in `@monaco-editor/loader` package", deprecation: `Deprecation warning!
    You are using deprecated way of configuration.

    Instead of using
      monaco.config({ urls: { monacoBase: '...' } })
    use
      monaco.config({ paths: { vs: '...' } })

    For more please check the link https://github.com/suren-atoyan/monaco-loader#config
  ` }, Qw = tU(aU)(kE), iU = { config: rU }, sU = function() {
    for (var t = arguments.length, r = new Array(t), a = 0; a < t; a++) r[a] = arguments[a];
    return function(s) {
      return r.reduceRight(function(l, u) {
        return u(l);
      }, s);
    };
  };
  function PE(e, t) {
    return Object.keys(t).forEach(function(r) {
      t[r] instanceof Object && e[r] && Object.assign(t[r], PE(e[r], t[r]));
    }), Fw(Fw({}, e), t);
  }
  var lU = { type: "cancelation", msg: "operation is manually canceled" };
  function Zh(e) {
    var t = false, r = new Promise(function(a, s) {
      e.then(function(l) {
        return t ? s(lU) : a(l);
      }), e.catch(s);
    });
    return r.cancel = function() {
      return t = true;
    }, r;
  }
  var cU = W9.create({ config: eU, isInitialized: false, resolve: null, reject: null, monaco: null }), LE = j9(cU, 2), ul = LE[0], of = LE[1];
  function uU(e) {
    var t = iU.config(e), r = t.monaco, a = D9(t, ["monaco"]);
    of(function(s) {
      return { config: PE(s.config, a), monaco: r };
    });
  }
  function fU() {
    var e = ul(function(t) {
      var r = t.monaco, a = t.isInitialized, s = t.resolve;
      return { monaco: r, isInitialized: a, resolve: s };
    });
    if (!e.isInitialized) {
      if (of({ isInitialized: true }), e.monaco) return e.resolve(e.monaco), Zh(Fh);
      if (window.monaco && window.monaco.editor) return UE(window.monaco), e.resolve(window.monaco), Zh(Fh);
      sU(dU, pU)(mU);
    }
    return Zh(Fh);
  }
  function dU(e) {
    return document.body.appendChild(e);
  }
  function hU(e) {
    var t = document.createElement("script");
    return e && (t.src = e), t;
  }
  function pU(e) {
    var t = ul(function(a) {
      var s = a.config, l = a.reject;
      return { config: s, reject: l };
    }), r = hU("".concat(t.config.paths.vs, "/loader.js"));
    return r.onload = function() {
      return e();
    }, r.onerror = t.reject, r;
  }
  function mU() {
    var e = ul(function(r) {
      var a = r.config, s = r.resolve, l = r.reject;
      return { config: a, resolve: s, reject: l };
    }), t = window.require;
    t.config(e.config), t(["vs/editor/editor.main"], function(r) {
      UE(r), e.resolve(r);
    }, function(r) {
      e.reject(r);
    });
  }
  function UE(e) {
    ul().monaco || of({ monaco: e });
  }
  function gU() {
    return ul(function(e) {
      var t = e.monaco;
      return t;
    });
  }
  var Fh = new Promise(function(e, t) {
    return of({ resolve: e, reject: t });
  }), BE = { config: uU, init: fU, __getMonacoInstance: gU }, vU = { wrapper: { display: "flex", position: "relative", textAlign: "initial" }, fullWidth: { width: "100%" }, hide: { display: "none" } }, qh = vU, yU = { container: { display: "flex", height: "100%", width: "100%", justifyContent: "center", alignItems: "center" } }, bU = yU;
  function wU({ children: e }) {
    return W.createElement("div", { style: bU.container }, e);
  }
  var SU = wU, xU = SU;
  function _U({ width: e, height: t, isEditorReady: r, loading: a, _ref: s, className: l, wrapperProps: u }) {
    return W.createElement("section", { style: { ...qh.wrapper, width: e, height: t }, ...u }, !r && W.createElement(xU, null, a), W.createElement("div", { ref: s, style: { ...qh.fullWidth, ...!r && qh.hide }, className: l }));
  }
  var EU = _U, IE = y.memo(EU);
  function AU(e) {
    y.useEffect(e, []);
  }
  var HE = AU;
  function CU(e, t, r = true) {
    let a = y.useRef(true);
    y.useEffect(a.current || !r ? () => {
      a.current = false;
    } : e, t);
  }
  var vn = CU;
  function $s() {
  }
  function fi(e, t, r, a) {
    return TU(e, a) || OU(e, t, r, a);
  }
  function TU(e, t) {
    return e.editor.getModel($E(e, t));
  }
  function OU(e, t, r, a) {
    return e.editor.createModel(t, r, a ? $E(e, a) : void 0);
  }
  function $E(e, t) {
    return e.Uri.parse(t);
  }
  function RU({ original: e, modified: t, language: r, originalLanguage: a, modifiedLanguage: s, originalModelPath: l, modifiedModelPath: u, keepCurrentOriginalModel: f = false, keepCurrentModifiedModel: p = false, theme: m = "light", loading: v = "Loading...", options: g = {}, height: S = "100%", width: _ = "100%", className: x, wrapperProps: E = {}, beforeMount: C = $s, onMount: T = $s }) {
    let [R, O] = y.useState(false), [D, P] = y.useState(true), L = y.useRef(null), k = y.useRef(null), $ = y.useRef(null), re = y.useRef(T), G = y.useRef(C), ae = y.useRef(false);
    HE(() => {
      let oe = BE.init();
      return oe.then((N) => (k.current = N) && P(false)).catch((N) => (N == null ? void 0 : N.type) !== "cancelation" && console.error("Monaco initialization: error:", N)), () => L.current ? ue() : oe.cancel();
    }), vn(() => {
      if (L.current && k.current) {
        let oe = L.current.getOriginalEditor(), N = fi(k.current, e || "", a || r || "text", l || "");
        N !== oe.getModel() && oe.setModel(N);
      }
    }, [l], R), vn(() => {
      if (L.current && k.current) {
        let oe = L.current.getModifiedEditor(), N = fi(k.current, t || "", s || r || "text", u || "");
        N !== oe.getModel() && oe.setModel(N);
      }
    }, [u], R), vn(() => {
      let oe = L.current.getModifiedEditor();
      oe.getOption(k.current.editor.EditorOption.readOnly) ? oe.setValue(t || "") : t !== oe.getValue() && (oe.executeEdits("", [{ range: oe.getModel().getFullModelRange(), text: t || "", forceMoveMarkers: true }]), oe.pushUndoStop());
    }, [t], R), vn(() => {
      var _a4, _b2;
      (_b2 = (_a4 = L.current) == null ? void 0 : _a4.getModel()) == null ? void 0 : _b2.original.setValue(e || "");
    }, [e], R), vn(() => {
      let { original: oe, modified: N } = L.current.getModel();
      k.current.editor.setModelLanguage(oe, a || r || "text"), k.current.editor.setModelLanguage(N, s || r || "text");
    }, [r, a, s], R), vn(() => {
      var _a4;
      (_a4 = k.current) == null ? void 0 : _a4.editor.setTheme(m);
    }, [m], R), vn(() => {
      var _a4;
      (_a4 = L.current) == null ? void 0 : _a4.updateOptions(g);
    }, [g], R);
    let se = y.useCallback(() => {
      var _a4;
      if (!k.current) return;
      G.current(k.current);
      let oe = fi(k.current, e || "", a || r || "text", l || ""), N = fi(k.current, t || "", s || r || "text", u || "");
      (_a4 = L.current) == null ? void 0 : _a4.setModel({ original: oe, modified: N });
    }, [r, t, s, e, a, l, u]), le = y.useCallback(() => {
      var _a4;
      !ae.current && $.current && (L.current = k.current.editor.createDiffEditor($.current, { automaticLayout: true, ...g }), se(), (_a4 = k.current) == null ? void 0 : _a4.editor.setTheme(m), O(true), ae.current = true);
    }, [g, m, se]);
    y.useEffect(() => {
      R && re.current(L.current, k.current);
    }, [R]), y.useEffect(() => {
      !D && !R && le();
    }, [D, R, le]);
    function ue() {
      var _a4, _b2, _c3, _d3;
      let oe = (_a4 = L.current) == null ? void 0 : _a4.getModel();
      f || ((_b2 = oe == null ? void 0 : oe.original) == null ? void 0 : _b2.dispose()), p || ((_c3 = oe == null ? void 0 : oe.modified) == null ? void 0 : _c3.dispose()), (_d3 = L.current) == null ? void 0 : _d3.dispose();
    }
    return W.createElement(IE, { width: _, height: S, isEditorReady: R, loading: v, _ref: $, className: x, wrapperProps: E });
  }
  var MU = RU;
  y.memo(MU);
  function NU(e) {
    let t = y.useRef();
    return y.useEffect(() => {
      t.current = e;
    }, [e]), t.current;
  }
  var zU = NU, Hc = /* @__PURE__ */ new Map();
  function DU({ defaultValue: e, defaultLanguage: t, defaultPath: r, value: a, language: s, path: l, theme: u = "light", line: f, loading: p = "Loading...", options: m = {}, overrideServices: v = {}, saveViewState: g = true, keepCurrentModel: S = false, width: _ = "100%", height: x = "100%", className: E, wrapperProps: C = {}, beforeMount: T = $s, onMount: R = $s, onChange: O, onValidate: D = $s }) {
    let [P, L] = y.useState(false), [k, $] = y.useState(true), re = y.useRef(null), G = y.useRef(null), ae = y.useRef(null), se = y.useRef(R), le = y.useRef(T), ue = y.useRef(), oe = y.useRef(a), N = zU(l), Z = y.useRef(false), B = y.useRef(false);
    HE(() => {
      let M = BE.init();
      return M.then((F) => (re.current = F) && $(false)).catch((F) => (F == null ? void 0 : F.type) !== "cancelation" && console.error("Monaco initialization: error:", F)), () => G.current ? me() : M.cancel();
    }), vn(() => {
      var _a4, _b2, _c3, _d3;
      let M = fi(re.current, e || a || "", t || s || "", l || r || "");
      M !== ((_a4 = G.current) == null ? void 0 : _a4.getModel()) && (g && Hc.set(N, (_b2 = G.current) == null ? void 0 : _b2.saveViewState()), (_c3 = G.current) == null ? void 0 : _c3.setModel(M), g && ((_d3 = G.current) == null ? void 0 : _d3.restoreViewState(Hc.get(l))));
    }, [l], P), vn(() => {
      var _a4;
      (_a4 = G.current) == null ? void 0 : _a4.updateOptions(m);
    }, [m], P), vn(() => {
      !G.current || a === void 0 || (G.current.getOption(re.current.editor.EditorOption.readOnly) ? G.current.setValue(a) : a !== G.current.getValue() && (B.current = true, G.current.executeEdits("", [{ range: G.current.getModel().getFullModelRange(), text: a, forceMoveMarkers: true }]), G.current.pushUndoStop(), B.current = false));
    }, [a], P), vn(() => {
      var _a4, _b2;
      let M = (_a4 = G.current) == null ? void 0 : _a4.getModel();
      M && s && ((_b2 = re.current) == null ? void 0 : _b2.editor.setModelLanguage(M, s));
    }, [s], P), vn(() => {
      var _a4;
      f !== void 0 && ((_a4 = G.current) == null ? void 0 : _a4.revealLine(f));
    }, [f], P), vn(() => {
      var _a4;
      (_a4 = re.current) == null ? void 0 : _a4.editor.setTheme(u);
    }, [u], P);
    let ce = y.useCallback(() => {
      var _a4;
      if (!(!ae.current || !re.current) && !Z.current) {
        le.current(re.current);
        let M = l || r, F = fi(re.current, a || e || "", t || s || "", M || "");
        G.current = (_a4 = re.current) == null ? void 0 : _a4.editor.create(ae.current, { model: F, automaticLayout: true, ...m }, v), g && G.current.restoreViewState(Hc.get(M)), re.current.editor.setTheme(u), f !== void 0 && G.current.revealLine(f), L(true), Z.current = true;
      }
    }, [e, t, r, a, s, l, m, v, g, u, f]);
    y.useEffect(() => {
      P && se.current(G.current, re.current);
    }, [P]), y.useEffect(() => {
      !k && !P && ce();
    }, [k, P, ce]), oe.current = a, y.useEffect(() => {
      var _a4, _b2;
      P && O && ((_a4 = ue.current) == null ? void 0 : _a4.dispose(), ue.current = (_b2 = G.current) == null ? void 0 : _b2.onDidChangeModelContent((M) => {
        B.current || O(G.current.getValue(), M);
      }));
    }, [P, O]), y.useEffect(() => {
      if (P) {
        let M = re.current.editor.onDidChangeMarkers((F) => {
          var _a4;
          let X = (_a4 = G.current.getModel()) == null ? void 0 : _a4.uri;
          if (X && F.find((J) => J.path === X.path)) {
            let J = re.current.editor.getModelMarkers({ resource: X });
            D == null ? void 0 : D(J);
          }
        });
        return () => {
          M == null ? void 0 : M.dispose();
        };
      }
      return () => {
      };
    }, [P, D]);
    function me() {
      var _a4, _b2;
      (_a4 = ue.current) == null ? void 0 : _a4.dispose(), S ? g && Hc.set(l, G.current.saveViewState()) : (_b2 = G.current.getModel()) == null ? void 0 : _b2.dispose(), G.current.dispose();
    }
    return W.createElement(IE, { width: _, height: x, isEditorReady: P, loading: p, _ref: ae, className: E, wrapperProps: C });
  }
  var jU = DU, kU = y.memo(jU);
  function PU(e) {
    const { theme: t } = Gj();
    return b.jsx(kU, { height: e.height || "400px", theme: t === "dark" ? "vs-dark" : "vs", defaultLanguage: "json", defaultValue: "{}", options: { wordWrap: "on", stickyScroll: { enabled: false }, minimap: { enabled: false }, scrollbar: { useShadows: false } }, className: "border-border overflow-hidden rounded-sm", ...e });
  }
  function LU() {
    const [e, t] = y.useState(""), [r, a] = y.useState(""), [s, l] = y.useState([]), [u, f] = y.useState([]), [p, m] = y.useState(""), [v, g] = y.useState(false), [S, _] = y.useState(false), x = Ux({ queryKey: ["accountExperiments"], queryFn: async () => {
      const O = await rD();
      if (O.isErr()) throw new Error(O.error);
      return O.value;
    }, enabled: true, retry: true }), E = y.useMemo(() => s.filter((O) => e.trim().length === 0 || O.id.toLowerCase().includes(e.replaceAll(" ", "").replaceAll("	", "").toLowerCase())), [s, e]), C = y.useMemo(() => s.find((O) => O.id === r), [s, r]), T = async () => {
      if (!(!r || !p)) {
        _(true);
        try {
          const O = JSON.parse(p), D = [...u], P = D.findIndex((L) => L.id === r);
          P >= 0 ? D[P] = { id: r, value: O } : D.push({ id: r, value: O }), await window.xlamModz.setStorageValue("settings/accountExperimentsOverride", D), f(D), g(false), Ve.success(`Эксперимент "${r}" сохранен`);
        } catch {
          Ve.error("Ошибка: Некорректный JSON формат");
        } finally {
          _(false);
        }
      }
    }, R = async () => {
      if (!r) {
        Ve.error("Выберите эксперимент");
        return;
      }
      _(true);
      try {
        const O = { group: "on", value: { title: "on", enabled: true } }, D = [...u], P = D.findIndex((L) => L.id === r);
        P >= 0 ? D[P] = { id: r, value: O } : D.push({ id: r, value: O }), await window.xlamModz.setStorageValue("settings/accountExperimentsOverride", D), f(D), g(false), Ve.success(`Эксперимент "${r}" включен`);
      } catch {
        Ve.error("Ошибка при включении эксперимента");
      } finally {
        _(false);
      }
    };
    return y.useEffect(() => {
      if (x.data) {
        const O = Object.entries(x.data).map((D) => ({ id: D[0], value: D[1] }));
        l(O), !r && O.length > 0 && a(O[0].id);
      }
    }, [x.data, r]), y.useEffect(() => {
      if (C) {
        const O = u.find((P) => P.id === r), D = O ? O.value : C.value;
        m(JSON.stringify(D, null, 2)), g(false);
      } else m(""), g(false);
    }, [C, r, u]), y.useEffect(() => {
      if (C) {
        const O = u.find((L) => L.id === r), D = O ? O.value : C.value, P = p.trim();
        P && P !== JSON.stringify(D, null, 2) ? g(true) : g(false);
      }
    }, [p, C, r, u]), y.useEffect(() => {
      (async () => f(await window.xlamModz.getStorageValue("settings/accountExperimentsOverride") || []))();
    }, []), b.jsx(mr, { title: "Экспериментальные функции", icon: b.jsx(d5, { className: "h-4 w-4" }), opened: false, children: b.jsxs("div", { className: "flex flex-col gap-5 pt-2", children: [b.jsxs(Ks, { variant: "default", className: "cursor-default", children: [b.jsx(Ys, {}), b.jsx("div", { className: "text-sm text-muted-foreground", children: "Некоторые экспериментальные функции Яндекс Музыки могут сломать интерфейс приложения, используйте только если вы знаете, что делаете" })] }), b.jsxs("div", { className: "flex flex-col gap-4", children: [b.jsxs("div", { className: "flex flex-col gap-2", children: [b.jsxs("div", { className: "flex gap-2", children: [b.jsxs("div", { className: "relative flex-1", children: [b.jsx(i5, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" }), b.jsx(Zm, { placeholder: "Поиск экспериментов...", value: e, onChange: (O) => t(O.target.value), className: "pl-10" })] }), u.find((O) => O.id === r) && b.jsx(Dt, { variant: "destructive", size: "icon", onClick: async () => {
      const O = u.filter((D) => D.id !== r);
      await window.xlamModz.setStorageValue("settings/accountExperimentsOverride", O), f(O), Ve.success(`Переопределение "${r}" удалено`);
    }, children: b.jsx(p5, { className: "h-4 w-4" }) }), b.jsx(Dt, { variant: "default", onClick: R, disabled: !r || S, className: "px-4", children: S ? "..." : "ON" })] }), b.jsx(G1, { className: "h-[200px] w-full border rounded-md overflow-hidden", children: b.jsx("div", { className: "p-2 w-full overflow-hidden", children: E.length > 0 ? b.jsx("div", { className: "flex flex-col gap-1", children: E.map((O) => {
      const D = u.some((L) => L.id === O.id), P = r === O.id;
      return b.jsx(Dt, { variant: "ghost", className: "w-full max-w-full justify-start h-auto py-2 px-3 overflow-hidden whitespace-normal break-all", style: P ? { outline: "1px solid var(--border)" } : {}, onClick: () => a(O.id), children: b.jsxs("div", { className: "flex items-center gap-2 w-full max-w-full min-w-0 overflow-hidden", children: [D && b.jsx(Vk, { className: "h-[6px]! w-[6px]! fill-border text-border flex-shrink-0" }), b.jsx("span", { className: "text-left text-sm min-w-0 flex-1 break-all overflow-hidden", children: O.id })] }) }, O.id);
    }) }) : b.jsx("div", { className: "text-center text-muted-foreground py-4", children: "Эксперименты не найдены" }) }) })] }), r && C && b.jsxs("div", { className: "flex flex-col gap-3", children: [b.jsx(PU, { id: "experiment-editor", value: p, onChange: (O) => m(O || ""), language: "json", className: "h-[200px]" }), b.jsxs("div", { className: "flex gap-2", children: [b.jsx(Dt, { variant: "default", onClick: T, disabled: !v || S || !p.trim(), className: "flex-1", children: S ? "Сохранение..." : "Сохранить" }), v && b.jsx(Dt, { variant: "outline", onClick: () => {
      const O = u.find((P) => P.id === r), D = O ? O.value : C.value;
      m(JSON.stringify(D, null, 2)), g(false);
    }, children: "Отмена" })] }), v && b.jsxs(Ks, { variant: "default", children: [b.jsx(Ys, { className: "h-4 w-4" }), b.jsx(bE, { children: 'У вас есть несохраненные изменения. Нажмите "Сохранить" чтобы применить их.' })] })] })] })] }) });
  }
  var VE = ["PageUp", "PageDown"], ZE = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"], FE = { "from-left": ["Home", "PageDown", "ArrowDown", "ArrowLeft"], "from-right": ["Home", "PageDown", "ArrowDown", "ArrowRight"], "from-bottom": ["Home", "PageDown", "ArrowDown", "ArrowLeft"], "from-top": ["Home", "PageDown", "ArrowUp", "ArrowLeft"] }, zi = "Slider", [Pp, UU, BU] = _m(zi), [qE, jI] = Fn(zi, [BU]), [IU, af] = qE(zi), YE = y.forwardRef((e, t) => {
    const { name: r, min: a = 0, max: s = 100, step: l = 1, orientation: u = "horizontal", disabled: f = false, minStepsBetweenThumbs: p = 0, defaultValue: m = [a], value: v, onValueChange: g = () => {
    }, onValueCommit: S = () => {
    }, inverted: _ = false, form: x, ...E } = e, C = y.useRef(/* @__PURE__ */ new Set()), T = y.useRef(0), O = u === "horizontal" ? HU : $U, [D = [], P] = Hr({ prop: v, defaultProp: m, onChange: (ae) => {
      var _a4;
      (_a4 = [...C.current][T.current]) == null ? void 0 : _a4.focus(), g(ae);
    } }), L = y.useRef(D);
    function k(ae) {
      const se = YU(D, ae);
      G(ae, se);
    }
    function $(ae) {
      G(ae, T.current);
    }
    function re() {
      const ae = L.current[T.current];
      D[T.current] !== ae && S(D);
    }
    function G(ae, se, { commit: le } = { commit: false }) {
      const ue = KU(l), oe = JU(Math.round((ae - a) / l) * l + a, ue), N = Xs(oe, [a, s]);
      P((Z = []) => {
        const B = FU(Z, N, se);
        if (GU(B, p * l)) {
          T.current = B.indexOf(N);
          const ce = String(B) !== String(Z);
          return ce && le && S(B), ce ? B : Z;
        } else return Z;
      });
    }
    return b.jsx(IU, { scope: e.__scopeSlider, name: r, disabled: f, min: a, max: s, valueIndexToChangeRef: T, thumbs: C.current, values: D, orientation: u, form: x, children: b.jsx(Pp.Provider, { scope: e.__scopeSlider, children: b.jsx(Pp.Slot, { scope: e.__scopeSlider, children: b.jsx(O, { "aria-disabled": f, "data-disabled": f ? "" : void 0, ...E, ref: t, onPointerDown: Ee(E.onPointerDown, () => {
      f || (L.current = D);
    }), min: a, max: s, inverted: _, onSlideStart: f ? void 0 : k, onSlideMove: f ? void 0 : $, onSlideEnd: f ? void 0 : re, onHomeKeyDown: () => !f && G(a, 0, { commit: true }), onEndKeyDown: () => !f && G(s, D.length - 1, { commit: true }), onStepKeyDown: ({ event: ae, direction: se }) => {
      if (!f) {
        const oe = VE.includes(ae.key) || ae.shiftKey && ZE.includes(ae.key) ? 10 : 1, N = T.current, Z = D[N], B = l * oe * se;
        G(Z + B, N, { commit: true });
      }
    } }) }) }) });
  });
  YE.displayName = zi;
  var [XE, QE] = qE(zi, { startEdge: "left", endEdge: "right", size: "width", direction: 1 }), HU = y.forwardRef((e, t) => {
    const { min: r, max: a, dir: s, inverted: l, onSlideStart: u, onSlideMove: f, onSlideEnd: p, onStepKeyDown: m, ...v } = e, [g, S] = y.useState(null), _ = Ne(t, (O) => S(O)), x = y.useRef(void 0), E = Hu(s), C = E === "ltr", T = C && !l || !C && l;
    function R(O) {
      const D = x.current || g.getBoundingClientRect(), P = [0, D.width], k = Ym(P, T ? [r, a] : [a, r]);
      return x.current = D, k(O - D.left);
    }
    return b.jsx(XE, { scope: e.__scopeSlider, startEdge: T ? "left" : "right", endEdge: T ? "right" : "left", direction: T ? 1 : -1, size: "width", children: b.jsx(GE, { dir: E, "data-orientation": "horizontal", ...v, ref: _, style: { ...v.style, "--radix-slider-thumb-transform": "translateX(-50%)" }, onSlideStart: (O) => {
      const D = R(O.clientX);
      u == null ? void 0 : u(D);
    }, onSlideMove: (O) => {
      const D = R(O.clientX);
      f == null ? void 0 : f(D);
    }, onSlideEnd: () => {
      x.current = void 0, p == null ? void 0 : p();
    }, onStepKeyDown: (O) => {
      const P = FE[T ? "from-left" : "from-right"].includes(O.key);
      m == null ? void 0 : m({ event: O, direction: P ? -1 : 1 });
    } }) });
  }), $U = y.forwardRef((e, t) => {
    const { min: r, max: a, inverted: s, onSlideStart: l, onSlideMove: u, onSlideEnd: f, onStepKeyDown: p, ...m } = e, v = y.useRef(null), g = Ne(t, v), S = y.useRef(void 0), _ = !s;
    function x(E) {
      const C = S.current || v.current.getBoundingClientRect(), T = [0, C.height], O = Ym(T, _ ? [a, r] : [r, a]);
      return S.current = C, O(E - C.top);
    }
    return b.jsx(XE, { scope: e.__scopeSlider, startEdge: _ ? "bottom" : "top", endEdge: _ ? "top" : "bottom", size: "height", direction: _ ? 1 : -1, children: b.jsx(GE, { "data-orientation": "vertical", ...m, ref: g, style: { ...m.style, "--radix-slider-thumb-transform": "translateY(50%)" }, onSlideStart: (E) => {
      const C = x(E.clientY);
      l == null ? void 0 : l(C);
    }, onSlideMove: (E) => {
      const C = x(E.clientY);
      u == null ? void 0 : u(C);
    }, onSlideEnd: () => {
      S.current = void 0, f == null ? void 0 : f();
    }, onStepKeyDown: (E) => {
      const T = FE[_ ? "from-bottom" : "from-top"].includes(E.key);
      p == null ? void 0 : p({ event: E, direction: T ? -1 : 1 });
    } }) });
  }), GE = y.forwardRef((e, t) => {
    const { __scopeSlider: r, onSlideStart: a, onSlideMove: s, onSlideEnd: l, onHomeKeyDown: u, onEndKeyDown: f, onStepKeyDown: p, ...m } = e, v = af(zi, r);
    return b.jsx(Te.span, { ...m, ref: t, onKeyDown: Ee(e.onKeyDown, (g) => {
      g.key === "Home" ? (u(g), g.preventDefault()) : g.key === "End" ? (f(g), g.preventDefault()) : VE.concat(ZE).includes(g.key) && (p(g), g.preventDefault());
    }), onPointerDown: Ee(e.onPointerDown, (g) => {
      const S = g.target;
      S.setPointerCapture(g.pointerId), g.preventDefault(), v.thumbs.has(S) ? S.focus() : a(g);
    }), onPointerMove: Ee(e.onPointerMove, (g) => {
      g.target.hasPointerCapture(g.pointerId) && s(g);
    }), onPointerUp: Ee(e.onPointerUp, (g) => {
      const S = g.target;
      S.hasPointerCapture(g.pointerId) && (S.releasePointerCapture(g.pointerId), l(g));
    }) });
  }), KE = "SliderTrack", JE = y.forwardRef((e, t) => {
    const { __scopeSlider: r, ...a } = e, s = af(KE, r);
    return b.jsx(Te.span, { "data-disabled": s.disabled ? "" : void 0, "data-orientation": s.orientation, ...a, ref: t });
  });
  JE.displayName = KE;
  var Lp = "SliderRange", WE = y.forwardRef((e, t) => {
    const { __scopeSlider: r, ...a } = e, s = af(Lp, r), l = QE(Lp, r), u = y.useRef(null), f = Ne(t, u), p = s.values.length, m = s.values.map((S) => nA(S, s.min, s.max)), v = p > 1 ? Math.min(...m) : 0, g = 100 - Math.max(...m);
    return b.jsx(Te.span, { "data-orientation": s.orientation, "data-disabled": s.disabled ? "" : void 0, ...a, ref: f, style: { ...e.style, [l.startEdge]: v + "%", [l.endEdge]: g + "%" } });
  });
  WE.displayName = Lp;
  var Up = "SliderThumb", eA = y.forwardRef((e, t) => {
    const r = UU(e.__scopeSlider), [a, s] = y.useState(null), l = Ne(t, (f) => s(f)), u = y.useMemo(() => a ? r().findIndex((f) => f.ref.current === a) : -1, [r, a]);
    return b.jsx(VU, { ...e, ref: l, index: u });
  }), VU = y.forwardRef((e, t) => {
    const { __scopeSlider: r, index: a, name: s, ...l } = e, u = af(Up, r), f = QE(Up, r), [p, m] = y.useState(null), v = Ne(t, (R) => m(R)), g = p ? u.form || !!p.closest("form") : true, S = Pm(p), _ = u.values[a], x = _ === void 0 ? 0 : nA(_, u.min, u.max), E = qU(a, u.values.length), C = S == null ? void 0 : S[f.size], T = C ? XU(C, x, f.direction) : 0;
    return y.useEffect(() => {
      if (p) return u.thumbs.add(p), () => {
        u.thumbs.delete(p);
      };
    }, [p, u.thumbs]), b.jsxs("span", { style: { transform: "var(--radix-slider-thumb-transform)", position: "absolute", [f.startEdge]: `calc(${x}% + ${T}px)` }, children: [b.jsx(Pp.ItemSlot, { scope: e.__scopeSlider, children: b.jsx(Te.span, { role: "slider", "aria-label": e["aria-label"] || E, "aria-valuemin": u.min, "aria-valuenow": _, "aria-valuemax": u.max, "aria-orientation": u.orientation, "data-orientation": u.orientation, "data-disabled": u.disabled ? "" : void 0, tabIndex: u.disabled ? void 0 : 0, ...l, ref: v, style: _ === void 0 ? { display: "none" } : e.style, onFocus: Ee(e.onFocus, () => {
      u.valueIndexToChangeRef.current = a;
    }) }) }), g && b.jsx(tA, { name: s != null ? s : u.name ? u.name + (u.values.length > 1 ? "[]" : "") : void 0, form: u.form, value: _ }, a)] });
  });
  eA.displayName = Up;
  var ZU = "RadioBubbleInput", tA = y.forwardRef(({ __scopeSlider: e, value: t, ...r }, a) => {
    const s = y.useRef(null), l = Ne(s, a), u = Bm(t);
    return y.useEffect(() => {
      const f = s.current;
      if (!f) return;
      const p = window.HTMLInputElement.prototype, v = Object.getOwnPropertyDescriptor(p, "value").set;
      if (u !== t && v) {
        const g = new Event("input", { bubbles: true });
        v.call(f, t), f.dispatchEvent(g);
      }
    }, [u, t]), b.jsx(Te.input, { style: { display: "none" }, ...r, ref: l, defaultValue: t });
  });
  tA.displayName = ZU;
  function FU(e = [], t, r) {
    const a = [...e];
    return a[r] = t, a.sort((s, l) => s - l);
  }
  function nA(e, t, r) {
    const l = 100 / (r - t) * (e - t);
    return Xs(l, [0, 100]);
  }
  function qU(e, t) {
    return t > 2 ? `Value ${e + 1} of ${t}` : t === 2 ? ["Minimum", "Maximum"][e] : void 0;
  }
  function YU(e, t) {
    if (e.length === 1) return 0;
    const r = e.map((s) => Math.abs(s - t)), a = Math.min(...r);
    return r.indexOf(a);
  }
  function XU(e, t, r) {
    const a = e / 2, l = Ym([0, 50], [0, a]);
    return (a - l(t) * r) * r;
  }
  function QU(e) {
    return e.slice(0, -1).map((t, r) => e[r + 1] - t);
  }
  function GU(e, t) {
    if (t > 0) {
      const r = QU(e);
      return Math.min(...r) >= t;
    }
    return true;
  }
  function Ym(e, t) {
    return (r) => {
      if (e[0] === e[1] || t[0] === t[1]) return t[0];
      const a = (t[1] - t[0]) / (e[1] - e[0]);
      return t[0] + a * (r - e[0]);
    };
  }
  function KU(e) {
    return (String(e).split(".")[1] || "").length;
  }
  function JU(e, t) {
    const r = Math.pow(10, t);
    return Math.round(e * r) / r;
  }
  var WU = YE, eB = JE, tB = WE, nB = eA;
  function rB({ className: e, defaultValue: t, value: r, min: a = 0, max: s = 100, ...l }) {
    const u = y.useMemo(() => Array.isArray(r) ? r : Array.isArray(t) ? t : [a, s], [r, t, a, s]);
    return b.jsxs(WU, { "data-slot": "slider", defaultValue: t, value: r, min: a, max: s, className: Pe("relative flex w-full touch-none items-center select-none data-[disabled]:opacity-50 data-[orientation=vertical]:h-full data-[orientation=vertical]:min-h-44 data-[orientation=vertical]:w-auto data-[orientation=vertical]:flex-col", e), ...l, children: [b.jsx(eB, { "data-slot": "slider-track", className: Pe("bg-muted relative grow overflow-hidden rounded-full data-[orientation=horizontal]:h-1.5 data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-1.5"), children: b.jsx(tB, { "data-slot": "slider-range", className: Pe("bg-primary absolute data-[orientation=horizontal]:h-full data-[orientation=vertical]:w-full") }) }), Array.from({ length: u.length }, (f, p) => b.jsx(nB, { "data-slot": "slider-thumb", className: "border-primary bg-background ring-ring/50 block size-4 shrink-0 rounded-full border shadow-sm transition-[color,box-shadow] hover:ring-4 focus-visible:ring-4 focus-visible:outline-hidden disabled:pointer-events-none disabled:opacity-50" }, p))] });
  }
  function oB() {
    const [e, t] = y.useState(1);
    return y.useEffect(() => {
      (async () => {
        const r = await window.xlamModz.getStorageValue("scale-changer/savedScale");
        r || window.xlamModz.setStorageValue("scale-changer/savedScale", 1), t(r || 1);
      })();
    }, []), b.jsx(mr, { title: "Размер интерфейса", icon: b.jsx(Qk, { className: "h-4 w-4" }), children: b.jsxs("div", { className: "flex flex-col gap-4 pt-2 px-3 items-center justify-center", children: [b.jsxs("div", { className: "flex gap-3 items-center w-full", children: [b.jsxs("span", { className: "text-sm text-muted-foreground", children: ["Размер интерфейса: ", e.toFixed(2), "x"] }), b.jsx(Dt, { className: "text-sm", variant: "ghost", onClick: () => {
      t(1), window.xlamModz.setStorageValue("scale-changer/savedScale", 1);
    }, children: "Сбросить" })] }), b.jsx(rB, { defaultValue: [e], value: [e], min: 0.3, max: 2, step: 0.05, onValueChange: (r) => {
      t(r[0]), window.xlamModz.setStorageValue("scale-changer/savedScale", r[0]);
    } })] }) });
  }
  var aB = /* @__PURE__ */ Symbol("radix.slottable");
  function iB(e) {
    const t = ({ children: r }) => b.jsx(b.Fragment, { children: r });
    return t.displayName = `${e}.Slottable`, t.__radixId = aB, t;
  }
  var rA = "AlertDialog", [sB, kI] = Fn(rA, [e1]), Fr = e1(), oA = (e) => {
    const { __scopeAlertDialog: t, ...r } = e, a = Fr(t);
    return b.jsx(g1, { ...a, ...r, modal: true });
  };
  oA.displayName = rA;
  var lB = "AlertDialogTrigger", cB = y.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...a } = e, s = Fr(r);
    return b.jsx(v1, { ...s, ...a, ref: t });
  });
  cB.displayName = lB;
  var uB = "AlertDialogPortal", aA = (e) => {
    const { __scopeAlertDialog: t, ...r } = e, a = Fr(t);
    return b.jsx(y1, { ...a, ...r });
  };
  aA.displayName = uB;
  var fB = "AlertDialogOverlay", iA = y.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...a } = e, s = Fr(r);
    return b.jsx(b1, { ...s, ...a, ref: t });
  });
  iA.displayName = fB;
  var vi = "AlertDialogContent", [dB, hB] = sB(vi), pB = iB("AlertDialogContent"), sA = y.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, children: a, ...s } = e, l = Fr(r), u = y.useRef(null), f = Ne(t, u), p = y.useRef(null);
    return b.jsx(Ok, { contentName: vi, titleName: lA, docsSlug: "alert-dialog", children: b.jsx(dB, { scope: r, cancelRef: p, children: b.jsxs(w1, { role: "alertdialog", ...l, ...s, ref: f, onOpenAutoFocus: Ee(s.onOpenAutoFocus, (m) => {
      var _a4;
      m.preventDefault(), (_a4 = p.current) == null ? void 0 : _a4.focus({ preventScroll: true });
    }), onPointerDownOutside: (m) => m.preventDefault(), onInteractOutside: (m) => m.preventDefault(), children: [b.jsx(pB, { children: a }), b.jsx(gB, { contentRef: u })] }) }) });
  });
  sA.displayName = vi;
  var lA = "AlertDialogTitle", cA = y.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...a } = e, s = Fr(r);
    return b.jsx(zk, { ...s, ...a, ref: t });
  });
  cA.displayName = lA;
  var uA = "AlertDialogDescription", fA = y.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...a } = e, s = Fr(r);
    return b.jsx(Dk, { ...s, ...a, ref: t });
  });
  fA.displayName = uA;
  var mB = "AlertDialogAction", dA = y.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...a } = e, s = Fr(r);
    return b.jsx(S1, { ...s, ...a, ref: t });
  });
  dA.displayName = mB;
  var hA = "AlertDialogCancel", pA = y.forwardRef((e, t) => {
    const { __scopeAlertDialog: r, ...a } = e, { cancelRef: s } = hB(hA, r), l = Fr(r), u = Ne(t, s);
    return b.jsx(S1, { ...l, ...a, ref: u });
  });
  pA.displayName = hA;
  var gB = ({ contentRef: e }) => {
    const t = `\`${vi}\` requires a description for the component to be accessible for screen reader users.

You can add a description to the \`${vi}\` by passing a \`${uA}\` component as a child, which also benefits sighted users by adding visible context to the dialog.

Alternatively, you can use your own component as a description by assigning it an \`id\` and passing the same value to the \`aria-describedby\` prop in \`${vi}\`. If the description is confusing or duplicative for sighted users, you can use the \`@radix-ui/react-visually-hidden\` primitive as a wrapper around your description component.

For more information, see https://radix-ui.com/primitives/docs/components/alert-dialog`;
    return y.useEffect(() => {
      var _a4;
      document.getElementById((_a4 = e.current) == null ? void 0 : _a4.getAttribute("aria-describedby")) || console.warn(t);
    }, [t, e]), null;
  }, vB = oA, yB = aA, bB = iA, wB = sA, SB = dA, xB = pA, _B = cA, EB = fA;
  function AB({ ...e }) {
    return b.jsx(vB, { "data-slot": "alert-dialog", ...e });
  }
  function CB({ ...e }) {
    return b.jsx(yB, { "data-slot": "alert-dialog-portal", ...e });
  }
  function TB({ className: e, ...t }) {
    return b.jsx(bB, { "data-slot": "alert-dialog-overlay", className: Pe("data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs fixed inset-0 z-[99994]", e), ...t });
  }
  function OB({ className: e, size: t = "default", ...r }) {
    return b.jsxs(CB, { children: [b.jsx(TB, {}), b.jsx(wB, { "data-slot": "alert-dialog-content", "data-size": t, className: Pe("data-open:animate-in data-closed:animate-out data-closed:fade-out-0 data-open:fade-in-0 data-closed:zoom-out-95 data-open:zoom-in-95 bg-background ring-foreground/10 gap-4 rounded-xl p-4 ring-1 duration-100 data-[size=default]:max-w-xs data-[size=sm]:max-w-xs data-[size=default]:sm:max-w-sm group/alert-dialog-content fixed top-1/2 left-1/2 z-[99995] grid w-full -translate-x-1/2 -translate-y-1/2 outline-none", e), ...r })] });
  }
  function RB({ className: e, ...t }) {
    return b.jsx("div", { "data-slot": "alert-dialog-header", className: Pe("grid grid-rows-[auto_1fr] place-items-center gap-1.5 text-center has-data-[slot=alert-dialog-media]:grid-rows-[auto_auto_1fr] has-data-[slot=alert-dialog-media]:gap-x-4 sm:group-data-[size=default]/alert-dialog-content:place-items-start sm:group-data-[size=default]/alert-dialog-content:text-left sm:group-data-[size=default]/alert-dialog-content:has-data-[slot=alert-dialog-media]:grid-rows-[auto_1fr]", e), ...t });
  }
  function MB({ className: e, ...t }) {
    return b.jsx("div", { "data-slot": "alert-dialog-footer", className: Pe("bg-muted/50 -mx-4 -mb-4 rounded-b-xl border-t p-4 flex flex-col-reverse gap-2 group-data-[size=sm]/alert-dialog-content:grid group-data-[size=sm]/alert-dialog-content:grid-cols-2 sm:flex-row sm:justify-end", e), ...t });
  }
  function NB({ className: e, ...t }) {
    return b.jsx(_B, { "data-slot": "alert-dialog-title", className: Pe("text-base font-medium sm:group-data-[size=default]/alert-dialog-content:group-has-data-[slot=alert-dialog-media]/alert-dialog-content:col-start-2", e), ...t });
  }
  function zB({ className: e, ...t }) {
    return b.jsx(EB, { "data-slot": "alert-dialog-description", className: Pe("text-foreground *:[a]:hover:text-foreground text-sm text-balance md:text-pretty *:[a]:underline *:[a]:underline-offset-3", e), ...t });
  }
  function DB({ className: e, variant: t = "default", size: r = "default", ...a }) {
    return b.jsx(Dt, { variant: t, size: r, asChild: true, children: b.jsx(SB, { "data-slot": "alert-dialog-action", className: Pe(e), ...a }) });
  }
  function jB({ className: e, variant: t = "outline", size: r = "default", ...a }) {
    return b.jsx(Dt, { variant: t, size: r, asChild: true, children: b.jsx(xB, { "data-slot": "alert-dialog-cancel", className: Pe(e), ...a }) });
  }
  const Yh = ["#fed42b", "#4A9EFF", "#34c72c", "#e74343", "#b74bd9", "#f161c4"], kB = [{ label: "Концерты", value: "concerts" }, { label: "Подкасты", value: "non-music" }, { label: "Детям", value: "kids" }];
  function PB() {
    const [e, t] = y.useState(false), [r, a] = y.useState(Yh[0]), [s, l] = y.useState(false), [u, f] = y.useState(false), [p, m] = y.useState(false), [v, g] = y.useState([]), [S, _] = y.useState(false);
    return y.useEffect(() => {
      (async () => {
        const x = await window.xlamModz.getStorageValue("custom-themes/enabled"), E = await window.xlamModz.getStorageValue("custom-themes/accent"), C = await window.xlamModz.getStorageValue("custom-themes/playerColorsReplace") !== false, T = await window.xlamModz.getStorageValue("custom-themes/disableVibeAnimation"), R = await window.xlamModz.getStorageValue("custom-themes/disableExplicitMark") !== false, O = await window.xlamModz.getStorageValue("custom-themes/hideMenuItems");
        t(x || false), a(E || Yh[0]), l(C), f(T), m(R), g(O || []);
      })();
    }, []), b.jsx(mr, { title: "Интерфейс и тема", icon: b.jsx(o5, { className: "h-4 w-4" }), children: b.jsx("div", { className: "flex flex-col gap-4 pt-2 px-3", children: b.jsxs("div", { className: "flex flex-col gap-4", children: [b.jsxs("div", { className: "flex items-center gap-3", children: [b.jsx(lr, { id: "custom-colors-toggle", checked: e, onCheckedChange: (x) => {
      x ? (t(x), window.xlamModz.setStorageValue("custom-themes/enabled", x)) : _(true);
    } }), b.jsx(sr, { htmlFor: "custom-colors-toggle", className: "cursor-pointer", children: "Собственная тема" }), b.jsx(AB, { open: S, onOpenChange: _, children: b.jsxs(OB, { children: [b.jsxs(RB, { children: [b.jsx(NB, { children: "Требуется перезагрузка" }), b.jsx(zB, { children: "Для отключения собственной темы требуется перезагрузка приложения" })] }), b.jsxs(MB, { children: [b.jsx(jB, { children: "Отмена" }), b.jsx(DB, { className: "text-foreground", onClick: () => {
      t(false), window.xlamModz.setStorageValue("custom-themes/enabled", false), setTimeout(() => {
        location.reload();
      }, 500);
    }, children: "Ок" })] })] }) })] }), b.jsxs(Eo, { condition: e, children: [b.jsx("div", { className: "grid grid-cols-6 gap-2", children: Yh.map((x) => b.jsx("button", { className: `w-8 h-8 rounded-lg border-2 transition-all hover:scale-110 cursor-pointer ${r === x ? "border-foreground shadow-md" : "border-transparent hover:border-muted-foreground/50"}`, style: { backgroundColor: x }, onClick: () => {
      a(x), window.xlamModz.setStorageValue("custom-themes/accent", x);
    }, title: x }, x)) }), b.jsxs("div", { className: "flex items-center gap-3", children: [b.jsx(lr, { id: "player-colors-toggle", checked: s, onCheckedChange: (x) => {
      l(x), window.xlamModz.setStorageValue("custom-themes/playerColorsReplace", x);
    } }), b.jsx(sr, { htmlFor: "player-colors-toggle", className: "cursor-pointer", children: "Заменить цвета в плеере" })] }), b.jsxs("div", { className: "flex items-center gap-3 mt-4", children: [b.jsx(lr, { id: "disable-vibe-animation-toggle", checked: u, onCheckedChange: (x) => {
      f(x), window.xlamModz.setStorageValue("custom-themes/disableVibeAnimation", x);
    } }), b.jsx(sr, { htmlFor: "disable-vibe-animation-toggle", className: "cursor-pointer", children: 'Отключить анимацию "Моей Волны"' })] }), b.jsxs("div", { className: "flex items-center gap-3 mb-4", children: [b.jsx(lr, { id: "disable-explicit-mark-toggle", checked: p, onCheckedChange: (x) => {
      m(x), window.xlamModz.setStorageValue("custom-themes/disableExplicitMark", x);
    } }), b.jsx(sr, { htmlFor: "disable-explicit-mark-toggle", className: "cursor-pointer", children: "Убрать уведомление 18+" })] }), kB.map((x) => b.jsxs("div", { className: "flex items-center gap-3", children: [b.jsx(lr, { id: `hide-menu-item-${x.value}-toggle`, checked: v.includes(x.value), onCheckedChange: (E) => {
      g((C) => {
        const T = C.filter((O) => O !== x.value), R = E ? [...T, x.value] : T;
        return window.xlamModz.setStorageValue("custom-themes/hideMenuItems", R), R;
      });
    } }), b.jsxs(sr, { htmlFor: `hide-menu-item-${x.value}-toggle`, className: "cursor-pointer", children: ['Скрыть раздел "', x.label, '"'] })] }, x.value))] })] }) }) });
  }
  var Xh, Gw;
  function LB() {
    if (Gw) return Xh;
    Gw = 1;
    var e = typeof Element < "u", t = typeof Map == "function", r = typeof Set == "function", a = typeof ArrayBuffer == "function" && !!ArrayBuffer.isView;
    function s(l, u) {
      if (l === u) return true;
      if (l && u && typeof l == "object" && typeof u == "object") {
        if (l.constructor !== u.constructor) return false;
        var f, p, m;
        if (Array.isArray(l)) {
          if (f = l.length, f != u.length) return false;
          for (p = f; p-- !== 0; ) if (!s(l[p], u[p])) return false;
          return true;
        }
        var v;
        if (t && l instanceof Map && u instanceof Map) {
          if (l.size !== u.size) return false;
          for (v = l.entries(); !(p = v.next()).done; ) if (!u.has(p.value[0])) return false;
          for (v = l.entries(); !(p = v.next()).done; ) if (!s(p.value[1], u.get(p.value[0]))) return false;
          return true;
        }
        if (r && l instanceof Set && u instanceof Set) {
          if (l.size !== u.size) return false;
          for (v = l.entries(); !(p = v.next()).done; ) if (!u.has(p.value[0])) return false;
          return true;
        }
        if (a && ArrayBuffer.isView(l) && ArrayBuffer.isView(u)) {
          if (f = l.length, f != u.length) return false;
          for (p = f; p-- !== 0; ) if (l[p] !== u[p]) return false;
          return true;
        }
        if (l.constructor === RegExp) return l.source === u.source && l.flags === u.flags;
        if (l.valueOf !== Object.prototype.valueOf && typeof l.valueOf == "function" && typeof u.valueOf == "function") return l.valueOf() === u.valueOf();
        if (l.toString !== Object.prototype.toString && typeof l.toString == "function" && typeof u.toString == "function") return l.toString() === u.toString();
        if (m = Object.keys(l), f = m.length, f !== Object.keys(u).length) return false;
        for (p = f; p-- !== 0; ) if (!Object.prototype.hasOwnProperty.call(u, m[p])) return false;
        if (e && l instanceof Element) return false;
        for (p = f; p-- !== 0; ) if (!((m[p] === "_owner" || m[p] === "__v" || m[p] === "__o") && l.$$typeof) && !s(l[m[p]], u[m[p]])) return false;
        return true;
      }
      return l !== l && u !== u;
    }
    return Xh = function(u, f) {
      try {
        return s(u, f);
      } catch (p) {
        if ((p.message || "").match(/stack|recursion/i)) return console.warn("react-fast-compare cannot handle circular refs"), false;
        throw p;
      }
    }, Xh;
  }
  var UB = LB();
  const Gc = em(UB);
  function et(e, t) {
    return !Number.isInteger(e) || !Number.isInteger(t) ? Math.random() * (t - e) + e : Math.floor(Math.random() * (t - e + 1) + e);
  }
  function js(e, t, r) {
    return (1 - r) * e + r * t;
  }
  function BB(e) {
    const t = Math.floor(Math.random() * e.length);
    return e[t];
  }
  function Kw(e) {
    return e ? { height: e.offsetHeight, width: e.offsetWidth } : { height: 0, width: 0 };
  }
  const Jw = Math.PI * 2, or = { color: "#dee4fd", radius: [0.5, 3], speed: [1, 3], wind: [-0.5, 2], changeFrequency: 200, rotationSpeed: [-1, 1], opacity: [1, 1], enable3DRotation: false };
  class sa {
    static createSnowflakes(t, r, a) {
      if (!t) return [];
      const s = [];
      for (let l = 0; l < r; l++) s.push(new sa(t, a));
      return s;
    }
    constructor(t, r = {}) {
      this.updateConfig(r);
      const { radius: a, wind: s, speed: l, rotationSpeed: u, opacity: f, enable3DRotation: p } = this.config;
      this.params = { x: et(0, t.offsetWidth), y: et(-t.offsetHeight, 0), rotation: et(0, 360), radius: et(...a), speed: et(...l), wind: et(...s), rotationSpeed: et(...u), nextSpeed: et(...l), nextWind: et(...s), nextRotationSpeed: et(...u), opacity: et(...f), hasNextOpacity: false, rotationX: p ? et(0, 360) : 0, rotationY: p ? et(0, 360) : 0, rotationSpeedX: p ? et(-2, 2) : 0, rotationSpeedY: p ? et(-2, 2) : 0, nextRotationSpeedX: p ? et(-2, 2) : 0, nextRotationSpeedY: p ? et(-2, 2) : 0 }, this.framesSinceLastUpdate = 0;
    }
    selectImage() {
      this.config.images && this.config.images.length > 0 ? this.image = BB(this.config.images) : this.image = void 0;
    }
    updateConfig(t) {
      const r = this.config;
      this.config = { ...or, ...t }, this.config.changeFrequency = et(this.config.changeFrequency, this.config.changeFrequency * 1.5), this.params && !Gc(this.config.radius, r == null ? void 0 : r.radius) && (this.params.radius = et(...this.config.radius)), Gc(this.config.images, r == null ? void 0 : r.images) || this.selectImage(), (r == null ? void 0 : r.opacity) && !Gc(this.config.opacity, r == null ? void 0 : r.opacity) && (this.params.hasNextOpacity = true);
    }
    updateTargetParams() {
      this.params.nextSpeed = et(...this.config.speed), this.params.nextWind = et(...this.config.wind), this.image && (this.params.nextRotationSpeed = et(...this.config.rotationSpeed)), this.config.enable3DRotation && (this.params.nextRotationSpeedX = et(-2, 2), this.params.nextRotationSpeedY = et(-2, 2));
    }
    update(t, r, a = 1) {
      const { x: s, y: l, rotation: u, rotationSpeed: f, nextRotationSpeed: p, wind: m, speed: v, nextWind: g, nextSpeed: S, radius: _ } = this.params;
      this.params.x = (s + m * a) % (t + _ * 2), this.params.x > t + _ && (this.params.x = -_), this.params.y = (l + v * a) % (r + _ * 2), this.params.y > r + _ && (this.params.hasNextOpacity && (this.params.opacity = et(...this.config.opacity), this.params.hasNextOpacity = false), this.params.y = -_), (this.image || this.config.enable3DRotation) && (this.params.rotation = (u + f) % 360), this.config.enable3DRotation && (this.params.rotationX = (this.params.rotationX + this.params.rotationSpeedX * a) % 360, this.params.rotationY = (this.params.rotationY + this.params.rotationSpeedY * a) % 360), this.params.speed = js(v, S, 0.01), this.params.wind = js(m, g, 0.01), this.params.rotationSpeed = js(f, p, 0.01), this.config.enable3DRotation && (this.params.rotationSpeedX = js(this.params.rotationSpeedX, this.params.nextRotationSpeedX, 0.01), this.params.rotationSpeedY = js(this.params.rotationSpeedY, this.params.nextRotationSpeedY, 0.01)), this.framesSinceLastUpdate++ > this.config.changeFrequency && (this.updateTargetParams(), this.framesSinceLastUpdate = 0);
    }
    getImageOffscreenCanvas(t, r) {
      var a, s;
      if (t instanceof HTMLImageElement && t.loading) return t;
      let l = sa.offscreenCanvases.get(t);
      if (l || (l = {}, sa.offscreenCanvases.set(t, l)), !(r in l)) {
        const u = document.createElement("canvas");
        u.width = r, u.height = r, (a = u.getContext("2d")) === null || a === void 0 || a.drawImage(t, 0, 0, r, r), l[r] = u;
      }
      return (s = l[r]) !== null && s !== void 0 ? s : t;
    }
    apply3DTransform(t, r, a) {
      if (this.config.enable3DRotation) {
        const { rotationX: s, rotationY: l } = this.params, u = this.params.rotation || 0, f = s * Math.PI / 180, p = l * Math.PI / 180, m = u * Math.PI / 180, v = Math.cos(f), g = Math.sin(f), S = Math.cos(p), _ = Math.sin(p), x = Math.cos(m), E = Math.sin(m), C = x * S, T = x * _ * g - E * v, R = x * _ * v + E * g, O = E * S;
        t.setTransform(C, T, R, O, r, a);
      } else {
        const l = (this.params.rotation || 0) * Math.PI / 180, u = Math.cos(l), f = Math.sin(l);
        t.setTransform(u, f, -f, u, r, a);
      }
    }
    drawCircle(t) {
      t.moveTo(this.params.x, this.params.y), t.arc(this.params.x, this.params.y, this.params.radius, 0, Jw);
    }
    drawCircle3D(t, r) {
      const { x: a, y: s, radius: l } = this.params;
      t.save(), this.config.enable3DRotation ? this.apply3DTransform(t, a, s) : t.translate(a, s), t.beginPath(), t.arc(0, 0, l, 0, Jw), t.fillStyle = r, t.fill(), t.restore();
    }
    drawImage(t) {
      const { x: r, y: a, radius: s } = this.params;
      t.save(), this.params.opacity !== 1 && (t.globalAlpha = this.params.opacity), this.apply3DTransform(t, r, a);
      const l = this.getImageOffscreenCanvas(this.image, s);
      t.drawImage(l, -(s / 2), -(s / 2), s, s), t.restore();
    }
  }
  sa.offscreenCanvases = /* @__PURE__ */ new WeakMap();
  const IB = { pointerEvents: "none", backgroundColor: "transparent", position: "absolute", top: 0, left: 0, width: "100%", height: "100%" }, HB = 1e3 / 60;
  var Ww = function(e, t, r, a) {
    if (r === "a" && !a) throw new TypeError("Private accessor was defined without a getter");
    if (typeof t == "function" ? e !== t || !a : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return r === "m" ? a : r === "a" ? a.call(e) : a ? a.value : t.get(e);
  }, $c = function(e, t, r, a, s) {
    if (a === "m") throw new TypeError("Private method is not writable");
    if (a === "a" && !s) throw new TypeError("Private accessor was defined without a setter");
    if (typeof t == "function" ? e !== t || !s : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return a === "a" ? s.call(e, r) : s ? s.value = r : t.set(e, r), r;
  }, Bs, Is;
  class $B {
    get ctx() {
      return Ww(this, Bs, "f");
    }
    get canvas() {
      return Ww(this, Is, "f");
    }
    set canvas(t) {
      $c(this, Is, t, "f"), $c(this, Bs, t.getContext("2d"), "f");
    }
    constructor(t, r) {
      this.lastUpdate = Date.now(), this.snowflakes = [], Bs.set(this, void 0), Is.set(this, void 0), $c(this, Is, t, "f"), $c(this, Bs, t.getContext("2d"), "f"), this.config = { snowflakeCount: 150, ...or, ...r }, this.snowflakes = [], this.snowflakes = sa.createSnowflakes(t, r.snowflakeCount || 150, r), this.play();
    }
    updateConfig(t) {
      this.config = { ...this.config, ...t };
      const r = this.config.snowflakeCount - this.snowflakes.length;
      r > 0 && (this.snowflakes = [...this.snowflakes, ...sa.createSnowflakes(this.canvas, r, t)]), r < 0 && (this.snowflakes = this.snowflakes.slice(0, this.config.snowflakeCount));
      for (const a of this.snowflakes) a.updateConfig(this.config);
    }
    render(t = 1) {
      const { ctx: r, canvas: a, snowflakes: s } = this;
      if (!r || !a) return;
      const { offsetWidth: l, offsetHeight: u } = a;
      for (const f of s) f.update(l, u, t);
      if (r.setTransform(1, 0, 0, 1, 0, 0), r.clearRect(0, 0, l, u), this.config.images && this.config.images.length > 0) {
        for (const f of s) f.drawImage(r);
        return;
      }
      if (this.config.enable3DRotation) for (const f of s) f.drawCircle3D(r, this.config.color);
      else {
        r.beginPath();
        for (const f of s) f.drawCircle(r);
        r.fillStyle = this.config.color, r.fill();
      }
    }
    loop() {
      const t = Date.now(), r = Date.now() - this.lastUpdate;
      this.lastUpdate = t;
      const a = r / HB;
      this.render(a), this.animationFrame = requestAnimationFrame(() => this.loop());
    }
    play() {
      this.loop();
    }
    pause() {
      this.animationFrame && (cancelAnimationFrame(this.animationFrame), this.animationFrame = void 0);
    }
  }
  Bs = /* @__PURE__ */ new WeakMap(), Is = /* @__PURE__ */ new WeakMap();
  const VB = (e) => {
    const [t, r] = y.useState(Kw(e.current)), a = y.useCallback(() => {
      e.current && r(Kw(e.current));
    }, [e]);
    return y.useEffect(() => {
      const { ResizeObserver: s } = window;
      if (e.current) if (a(), typeof s == "function") {
        const l = new s(a);
        return l.observe(e.current), () => l.disconnect();
      } else return window.addEventListener("resize", a), () => window.removeEventListener("resize", a);
    }, [e, a]), t;
  }, ZB = (e) => y.useMemo(() => ({ ...IB, ...e || {} }), [e]);
  function FB(e, t) {
    const r = y.useRef(t);
    return Gc(t, r.current) || (r.current = t), y.useEffect(e, r.current);
  }
  function qB(e) {
    const [t, r] = y.useState(e);
    return FB(() => r(e), [e]), t;
  }
  const YB = ({ color: e = or.color, changeFrequency: t = or.changeFrequency, radius: r = or.radius, speed: a = or.speed, wind: s = or.wind, rotationSpeed: l = or.rotationSpeed, opacity: u = or.opacity, snowflakeCount: f = 150, images: p, enable3DRotation: m = or.enable3DRotation, style: v } = {}) => {
    const g = ZB(v), S = y.useRef(null), _ = VB(S), x = qB({ color: e, changeFrequency: t, radius: r, speed: a, wind: s, rotationSpeed: l, images: p, snowflakeCount: f, opacity: u, enable3DRotation: m }), E = y.useRef(x), C = y.useRef();
    return y.useEffect(() => (!C.current && S.current && (C.current = new $B(S.current, E.current)), () => {
      var T;
      (T = C.current) === null || T === void 0 || T.pause(), C.current = void 0;
    }), []), y.useEffect(() => {
      C.current && C.current.updateConfig(x);
    }, [x]), W.createElement("canvas", { ref: S, height: _.height, width: _.width, style: g, "data-testid": "SnowfallCanvas" });
  }, Bp = () => {
    const e = /* @__PURE__ */ new Date(), t = e.getFullYear(), r = new Date(t, 11, 10), a = new Date(t + 1, 0, 15);
    return e >= r && e <= a;
  };
  function XB() {
    const [e, t] = y.useState(false), [r, a] = y.useState(true);
    return y.useEffect(() => {
      (async () => {
        const l = await window.xlamModz.getStorageValue("snowfall/enabled") !== false;
        a(l || false);
      })(), window.xlamModz.onStorageChanged((l, u) => {
        l.includes("snowfall/enabled") && a(u !== false);
      }), t(Bp());
      const s = setInterval(() => {
        t(Bp());
      }, 1e3 * 60 * 60);
      return () => clearInterval(s);
    }, []), b.jsxs(Eo, { condition: r && e, children: [b.jsx(YB, { style: { position: "fixed", width: "100vw", height: "100vh", zIndex: 99999 }, snowflakeCount: 25, speed: [0.5, 3], wind: [-0.5, 2], radius: [1, 3], color: "white" }), b.jsx("style", { children: `
        .ym-dark-theme canvas[data-testid="SnowfallCanvas"]
        {
            opacity: 0.2;
        }
        ` })] });
  }
  function QB() {
    if (!Bp()) return null;
    const [e, t] = y.useState(false);
    return y.useEffect(() => {
      (async () => {
        const r = await window.xlamModz.getStorageValue("snowfall/enabled") !== false;
        t(r || false);
      })();
    }, []), b.jsx(mr, { title: "Падающий снежок", icon: b.jsx(u5, { className: "h-4 w-4" }), children: b.jsx("div", { className: "flex flex-col gap-5 pt-2 px-3", children: b.jsxs("div", { className: "flex items-center gap-3", children: [b.jsx(lr, { id: "snowfall-toggle", checked: e, onCheckedChange: (r) => {
      t(r), window.xlamModz.setStorageValue("snowfall/enabled", r);
    } }), b.jsx(sr, { htmlFor: "snowfall-toggle", className: "cursor-pointer", children: "Включить анимацию падающего снежка" })] }) }) });
  }
  const eS = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABiBSURBVHhe7d1rVFTnvQbwfszHfMyHo5imOYknjSDe4wUVTXu6zjmLtqenJmpIm5rE5KTRpiYmOTakSWojKjGCyEVHxTsqguBwHxAUELkIKIJRvAQVweA1mCZd+6z/O+6ReRkuM/PeTJ5nrWeZNlnCB37PbPbsvedHP0IQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBBliokNWTYwOiZ0eHbLyxeiQVTF8f8ca57MveXWNVxf46qNrWV8ZoAtZE3z2dU8T7/cxd9/wapJX3+zTFE8X9+7jdjewvjVAl7A6fPYd6hN2N3v13T5N8/R9n93GusxXR7r7wcgd/fZD1l0++5FX0919yt1PfHYv6/IB+ilrhnefdjfW08w+XeXVA16N82qOV9fca9zT2S+uDXVOp/I/48i9PB+yImz+sNiY+cNW1r0wfKVFjR6+yooOud8XQ1Z7+jvWOE9/Tx3xGetLXl1j/aFXF7B+7unL1EfXsr7i1Xjr1V5dyJrg7o8TrNd+vM7T1z1NZP1f6mPrWd/wapL1x15987Fk682f3O+in6R4upg11d3HU60/sW5gfcurG60/U//V3SWsDk/fZt3E+g71CbubraW9+i7rFk/feyLNeu9Jd9/3dCvr/7FuY13m1e3WX6gj3f1g5I5e3WnF9OqHrLvc/bdd1l9Zd7N+5NV062PqU+5+wrrH07+x7mVdTv2p3X3W33v1U9YMT1f8dL+14ml3Yz3NZF3JmsW6yqsHrNXUUe7Gjcru1Rzrs15dw3qQ9fNQu05rracHm+NHOeN+0KMQHbJ8xLzhKxPnDYttm38PPfAD//cfv9OKZ81lTQjL7U4Iy3XEh+aF8Ua+l4kOiXt43vDYuHnDYnvmD4+1gB/4f8D4ezWP/twRPy77Ed7M9yZzh61YOm/Yim43fOAHfuC38a+714Sw3J7E0fnLHRGuh3g/D2zoVX/u8FjnffjAD/zAz+OnJobl2637XhwNsN/1h8XWAT/wA/+Q8VvrR+db68PyL68Lz5/Im3pgQmf353od8gM/8AP/kPCzFtAI9CSNzpvD2zI+9MoP/MAP/IHjT7pXGoGU0IIH5y1DdqZ/2Ipm4Ad+4A8OPzXZ/Wd30pjcJ3lrRgYn/IAf+MXhTx5d6G54YZsj1PUw782o0Ft9wA/8wC8cv5USXmSljC7K4M0Zk+iQFY/cv8AH+IEf+IXiv9dkU68apCv8gB/4gV8e/lRTjwKiQ1Y+ict7gR/45eJ3t9hKGV3wc96g1swfHusAfuAHfvn4qRvCi128Qa2ZNyz2MvADP/ArwU9/9hjzjsDckNjpwA/8wK8G/4YxLtbUcNeLvEUtmTc8djnwAz/wq8O/kRpevIO3qCXzh8U2Az/wA79C/OyfS7qNuG0Y+IEf+NXi3zimhNUR6hrBe1Sa6JC4EcAP/MCvAT+rS+9NQuzpvcAP/MCvAX+J5Rjr0nurcPS/rIwCfuAHfg34qeGuRbxJpYkOWbUI+IEf+NXj3zSm1HKMKY3hTSrNvQ/qAH7gB37F+DeNNWQAgB/4gV89fuMGAPiBH/jV4d809pC12ZQBAH7gB37F+E0ZAOAHfuDXgN+EAbj3Kb3AD/zArxq/GQPAPpIb+IEf+BXj38IGoMyMAQB+4Ad+tfi3jC0zYwCAH/iBXz1+cwYA+IEf+JXjp6aZMgDAD/zArxg/dZwBAwD8wA/8OvCX6x+Al7wGAPiBH/jV4TdqAIAf+IFfJf6t5gwA8AM/8KvGb8gArIkBfuAHfvX43QNw2JwBAH7gB351+LeOO2xtM2UAgB/4gV85fjMGAPiBH/i14Nc/AAvYAAA/8AO/BvxmDQDwAz/wq8O/3aQBAH7gB361+LePO2LGAAA/8AO/evzmDADwAz/wK8dP3aF9AB5dywYA+IEf+FXjp1boHwDgB37g14B/fIX+AXjFawCAH/iBXxl+swYA+IEf+FXi32nOAAA/8AO/avzGDADwAz/wq8dv3AAAP/ADvzr8O8dXWrtMGQDgB37gV4zflAEAfuAHfg34TRiAhWwAgB/4gV85fjMGIME9AMAP/MCvFP9uNgBVBgwA8AM/8CvHv3t8lRkDAPy+8a+LclptVR3+9WiHdY716pBaHNeoHf++hZXWxequQXqN9Us/W/SXRuDvBz8bgAkGDQDw933lJ9Qy8+3d76zPIrK14adePXWD/7aE5E7XXWvD1CLg7wf/7glVVropAwD8ffFTE3+Zy/9cC8/RLae14c9adIz/doSluNerP/D7wn/UjAEAft/47d/3Kzaf4n+2hYaOAtZE5CjHv3bcQet2513+2xGS9uprwD8ofgMG4HXPAAC/L/zU2Kn7rVudPfzPuNC44pqU4qcTfSUrTvDfhpB8980/rd2/PQL8g+I3ZgCAvz/89tn+3OW1/M+50Nzu7LFix+xXhl/mq//xreeAfwj495gxAIlsAIC/f/x2Lzd38z/rQlP4aYMS/NSKxFb+ywsJnfhLGl8A/EPA7x6Aav0DAPyD46f3+TdHu/ifd6Gho4CVYzKl40+eWWB9e/ef/JcXkvx3jgP/EPHvmVBtyAAA/6D47Yt8mgu/5H/mhYaOAmTip9amneW/rJCcP9wJ/H7gp+7VPgCPuQcA+AfHT1f4rZ6Wyc7ay8r19jtS8SfPLLS+k/DqTyf+dkQdBn7/8JsxAMA/NPz25b2lCXLOntvZ98dKKfjp8t4WZzv/5YSkdmMb8PuLf+Ix/QPwhtcAAP9g+KnLR++V+rZgR/N1Kfi3/aaM/1JCcqfrGyt5fCHw+4vfrAEA/qHgt2/q2f3GYd6B0GS8WSUUP93Q80XRFf7LCEnu4nrgDwD/PnMGAPj9wW/f1Uc388gKHQWIxL9znpzBOlvcAfwB4ncPQI3uAUiKAX7/8dMtvSm/LuA9CM3O35cLwU+VccMPnfjb+osy4A8Q/76JNWYNAPAPHb99P3/VFjkX1FBOF10Wgv+ApBt+qtefAf4g8FMzTBkA4PcfPz3Mg27lpQt4ZGXLb0qCwi/r1f9m+9dWyoRC4A8GvykDAPyB4bcf5FHw93reh7DQUUAw+POXHef/SiHJeb0G+IPFb8IAvEkDAPwB46euCM+wrjRf540ICx0FBII/fpzTuiPhhp+24g7gF4HftAEAfv/x20/y2flKOe9EWE45v/QbPz3Dr3TFSf6vCjp04m/LrBLgF4B//8RaK2OSIQMA/IHjt5/k01Ik5yo7unFn/Yx8v/DHj8uV8upf+Xkr8AvCv3+SIQMA/MHjpwd5rHvWKe0+gZq0s0PGT0/urUtr4/+KoNPddttKmVAE/ILwuwegTvcApHgGAPgDx28/yacitYV3IyR0FJA0M39I+FNmFkm54SdrwTHgF4h//6Q6K9OUAQD+4PHTffx0P7+stwXpNt7B8LNX/63iX/1P514BfvH4zRgA4BeD327WkqO8HyGhowB6mMdA+NOiSoW/+tOJv7RZpcAvHr/+AVjMBgD4ReG3H+bRfvwa70hISlac7Bc/fVrPmWLxN/wciW0Bfjn4DRoA4BeGn+r472LekZDQmf2145w+8e/4H/FvRXadumml3jvxB/xi8WcZMwDALxS//TCPul3ifxen0Pv7PH5Zr/4ZLxwFfkn4sybVGzAAj6fEAL94/HQvf8IMp3X35j94U0Hnq7O3+uBPjRR/xNGS2Q78EvEbNADALxq//TCP4k8beVdCsn9htden9B5ZI/btx29ufstO/AG/PPxZz9RbB/QPwAY2AMAvHj81buwB9nAP0aHD/d4f0X2j/Wv+PwkqdOIP+CXjZwNwXP8AAL8c/PbDPPa8WsH7Cjr0Vl/SlEKGP/O1av5fBxU68Qf8CvA/c1z/ALzlNQDALxq//TAPuq1XdAqXNbABOJkp9rMK9s6pBH4V+M0aAOCXhZ+a8rNC4Z/GQ78G0ACIPNF4Mv0i8CvCn23OAAC/TPz2vfxVqad5b0GFfg3IEnj4T4/33jrrEPArwm/MAAC/fPzUNWNzhH8i792b3/L/V8Ap+6QZ+BXiN2cAgF86fvthHjlv1/DujEhHw3XgV4w/+5kGK8eUAQB++fjt+/kvHZf7MeOBZO+cKuBXjZ862YABAH51+OlW3q2/OcT705rGbReAXwt+AwZgCRsA4FeF3+7x3ed5h1pCJ/42RZQAvxb8RgyAwzMAwK8GP93PL+tjuv1NyQcngF8T/oPsz0YzBgD41eG37+WX8dRef3Lp2FfArxH/wcmNZgwA8KvHT6Xn9n919jbvUknoKT/7nqsCfo34DRoA4FeN376fP3uRnrcF6cQf8OvFT3WaMgDArx6/zMd4DZSvu76xNk50Ab9+/GYMAPDrw09Ni1L7tmC94xzwG4G/Sf8AvEMDAPza8NP9/HRXn8rQwz62zS4Dfu34TRiAJ+wBAH4d+DdEFkv5CK/B0pp1Cfg14881ZwCAXwd+upW31XmJt6ksOQtqgV8j/twpRgzA5hjg14Nf9JN8/M21U7esTZNKgV8TfvcAnDBnAIBfHf514/OEP8cvkFSvPQP8mvDnTjlh5ZkyAMCvDj+1XsLn9wUSuiBo939WAL8O/KYMAPCrxZ8+X/xDQoPJeVcn8OvAb8IAvMsGAPhV4adD/85TN3iD2lP0VhPwq8Zv2gAAv1z8VNEf4CEqdHXglkmHgF8h/nyTBgD45ePfFnVI6C3A9Px+kWlwXAB+hfjzp5w0YwCAXz7++FCn9WW12I8MP7BA7I1EdEIw6/ka4FeE35ABSIsBfvn4C5eJ/YzA7rbb7DFeN9t7+H8VVC4fuw78ivBTCyY3mzEAwC8P/8ZIl9DHd1PqHG3shp6WLPFXEpbHtAC/CvxTmq2CqQYMAPDLwx8fmivlct/0X1WwASj9QPxTheiE4M4ZR4BfPn79A/C+ZwCAXwb+rNeO8b6CTkfDDc/DPBwTXex3d9Fp2XMZ+OXjN2UAgF8G/sTx+dadLvF3+pX/7ZTX/fytWeI/eJSS/Xwt8EvEX2jSAAC/WPzUpvQLvKmgYz/Np/fDPDKeOyrlKOCrltvALxF/4dRTZgwA8IvHv2d+Je9JSCpWtvp8kk/Ttov8fyok1avPAr8k/AYNAPCLxL9+fL7VKfgiHUp32x32Oz+Pn27n3f7sYSlHAfT0oL0/Pwr8EvBTi/QPwDY2AMAvBn9CWK51dP0XvCMhKfhTg0/89v38so4CzuV1Ar8U/NQW/QMA/OLwb48qk/JK3HXq1oD4qTuePSLla1MKX20CfvH49Q/AMq8BAP5g8FNFX+5rx/3q3z9++37+qlVyjj5utH1t7ZxcAfxi8Zs0AMAfLP6Sj0/wboTknOvqkPDTrbx0Rx+9UyAj9fHngF8g/mJzBgD4g8XvkHC5rx16m28o+O0elXQUQL9eZP5XDfALwm/MAAB/cPiprblyLsY55+r0Cz/dz5/2TJm0o4CLJdeAXxD+4qmthgwA8AeF/+DiOt6JkNAr7p5fVfqF376fv/S9Zv6vE5ayJS3ALwA/1aV9AEa6BwD4A8O/fnyBlMt9KU3bLgSE376f/1qLnE8e7un6h5U+pQr4g8ZvyAAAf2D4E8LypFzuS6FX/+2zywPGTy3+s5yTkpSTm9qBP1j80wwYgA9G7ug1AMDvD/69ki73pbBX/yDw2/fzyzoKoIHKndcA/MHgZwNw2pQBAH5/8CeNL2BP5ZEROoEn6hN78l6R98GjXY23gD8I/CXTTpsyAMDvD/51YXlWtaTLfSmVq04LwW/3gquL/xLCUvXXM8AfIH5jBgD4/cO/Papc2iW39qu/KPx0P3/2XDnvUlDohGDWv9cCfwD4jRsA4B8cP/VKw3XegbC43j0hFL99P/+FEnlHAV/s7QD+APCXTPvCKjVlAIB/aPhLPxb/DD4711puScFPt/LmzK2TdtRCKXrpJPD7i9+UAQD+oeHfFFki7XJfSuFbjVLw223eLv7hpHa6W+4Av7/4TRiAD9kAAP9g+Klnizv4n3thudpwQyp+up+fHuwh8yigPu488PuD34wB2OUeAOAfEH/u4nr+511o9j9XLRW/fS+/zKMAGpfsX9QD/xDxH2IDcMaAAQD+AfFvnFps3ZF0cw3F/nhu2fip+yQfBVzIvwb8Q8R/aNoZMwYA+PvHnxiWb51Il/OoLTv7nzumBL/9MI+a1W38tyA05YtagX8I+NkARBgxAMDfH/7MP1TzP99C07ynXSl+6q7Jlez9e1m5ea7HypxWC/yD4D8UccYqM2UAgL8v/uTxhdIu96XQoTg9x08lfvthHrWrz/HfjtA0p14C/sHxmzEAwN8XP7V6/Rn+51po6Cm+OvDTvfy7p1RJPQpgNwv9shH4B8R/Vv8AfOQ1AMBv40//bYXUk2X0vP2dvV79VeK3H+Zx5P1W/tsSmisVN4B/QPxGDQDw2/ipMi/3pdDTe3Xit0sX8MhM5dtngL8f/OXmDADw98Z/6BN5l/tS6IYfenqvbvz0MI/yJS38tyc0d+lmoYh64PeB35ABSI8B/vv414/OtzJeqLKyFhyzDvRpjafZC2o9zeF6kPpyHdd6VufL9da+Xx81Ar99L7/r1ZP32uzuwmarpFdLPT3Feoj6WgvXVtayXi2nvt5qOf+jEfh94HcPQJsBAwD8HvzuFlhJvZrMWuhueCH7aG67vj6oU8STfFThx8M89OEvj2izDmsfgKfcAwD8wA/8yvGbMQDAD/zArwH/dAMG4BM2AMAP/MCvHL9pAwD8wA/86vAfMWkAgB/4gV8t/iPTz5kxAMAP/MCvHr9BAwD8wA/8qvFTK/QPwF42AMAP/MCvGD8bgPP6BwD4gR/4NeCffl7/ACynAQB+4Ad+9fjNGgDgB37gV4m/kv6cYcQAAD/wA79q/JUzDBkA4Ad+4FeP37gBAH7gB351+CtnXLCqTBkA4Ad+4FeN35ABAH7gB34d+A0YgE/ZAAA/8AO/evzUi7oHIMMzAMAP/MCvDv/RGRfNGQDgB37gV4vfmAEAfuAHfvX4zRkA4Ad+4FeOn1qtfQCedg8A8AM/8KvG/6UZAwD8wA/8GvDPNGAAYj0DAPzAD/xK8ZszAMAP/MCvGv8xNgDtugcgkw0A8AM/8KvFf2xmuxkDAPzAD/zq8Rs0AMAP/MCvGj+1xpQBAH7gB37F+E0ZAOAHfuDXgH/mJf0DsMprAIAf+IFfGX6zBgD4gR/4VeKvNWcAgB/4gV81fvcAXNY9AAdigB/4gV89/tqZlw0ZAOAHfuBXjp9aZ8oAAD/wA79i/NRIAwYA+IEf+LXg1z8AcV4DAPzAD/wK8Zs0AMAP/MCvEn995BVTBgD4gR/4VeM3ZAByYoAf+IFfPX73AHSYMwDAD/zArw5/fWSHddyUAQB+4Ad+5fjNGADgB37g14Jf/wCsYQMA/MAP/BrwmzMAwA/8wK8Wf4MJA/DZqOylwA/8wK8ef0PkVRMG4OAc4Ad+4FePn1o/q2Mpb1Jp1oY6pwM/8AO/evwNs65ax2d3vMibVJq4UOcI4Ad+4FePv5Ea2TmdN6k0jhDXQ8AP/MCvAf+sTqvh2c4neZPKs3aUsxv4gR/41eKn1kV0P8x7VJ6EUQcdwA/8wK8Wf9Osqy7eopasHXVwDvADP/CrxN9pNeh+B8AOnQeID3P2AD/wA78a/NTmn10ewVvUloQwpxP4gR/41eBvirzazBvUmoTQ3CjgB37gV4Cf/e+ri3iD2rMuLM8J/MAP/HLxN0V2NbdFtD3E+9Oe+NC8MOAHfuCXiH9Wl3ViZmcUb8+YrAvLdwA/8AO/JPyRXXW8OaMSF+p6eF1YfhvwAz/wi8XfNKurp2l2Rxhvzrgkjcl9MjEsrwf4gR/4xeA/QX3W4EN/PkmhuVHAD/zALwZ/06xOMy768SdJYQVLgR/4gT84/CdmXXPwth6YJI3Om5MUVtAD/MAP/AHgn92p94k/IpIcnj8xKbygG/iBH/iHhp9O+DXOvjqHt/TAJjHUNSI5vMgF/MAP/APjp7f6Hoiz/YEkdUxhVGp4UR3wAz/w98Hf1jS7S+8jvlQldXThnNTRRc3AD/zA39lG1/YbeXmv7DhCXSM2hLsWbQwvdgE/8P9Q8DdGdtY1RnbGfG8P9QOJI9T1sGOMa/q9LnWMKY3p3c19WuZpGnWcrx6O2TZAd7BW+OyuPq1yd0JVTLrPVrPu9dka1gy+k+zWxWQO0AOsx302hzq5dxs9dfbbEzF5A7RgcnNMwVTfLWJt8VmXV097tbRPz7gbcSamrN+2xRweoBWs5+93xv1WefWiV6v7tN3TGp+9zFpHjfTVjhh6Rn9/bWTtnE5tiuh4hP/ZRxAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAE4fL/68EW5r1b+GgAAAAASUVORK5CYII=";
  var mA = { color: void 0, size: void 0, className: void 0, style: void 0, attr: void 0 }, tS = W.createContext && W.createContext(mA), GB = ["attr", "size", "title"];
  function KB(e, t) {
    if (e == null) return {};
    var r = JB(e, t), a, s;
    if (Object.getOwnPropertySymbols) {
      var l = Object.getOwnPropertySymbols(e);
      for (s = 0; s < l.length; s++) a = l[s], !(t.indexOf(a) >= 0) && Object.prototype.propertyIsEnumerable.call(e, a) && (r[a] = e[a]);
    }
    return r;
  }
  function JB(e, t) {
    if (e == null) return {};
    var r = {};
    for (var a in e) if (Object.prototype.hasOwnProperty.call(e, a)) {
      if (t.indexOf(a) >= 0) continue;
      r[a] = e[a];
    }
    return r;
  }
  function Su() {
    return Su = Object.assign ? Object.assign.bind() : function(e) {
      for (var t = 1; t < arguments.length; t++) {
        var r = arguments[t];
        for (var a in r) Object.prototype.hasOwnProperty.call(r, a) && (e[a] = r[a]);
      }
      return e;
    }, Su.apply(this, arguments);
  }
  function nS(e, t) {
    var r = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var a = Object.getOwnPropertySymbols(e);
      t && (a = a.filter(function(s) {
        return Object.getOwnPropertyDescriptor(e, s).enumerable;
      })), r.push.apply(r, a);
    }
    return r;
  }
  function xu(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t] != null ? arguments[t] : {};
      t % 2 ? nS(Object(r), true).forEach(function(a) {
        WB(e, a, r[a]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : nS(Object(r)).forEach(function(a) {
        Object.defineProperty(e, a, Object.getOwnPropertyDescriptor(r, a));
      });
    }
    return e;
  }
  function WB(e, t, r) {
    return t = eI(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: true, configurable: true, writable: true }) : e[t] = r, e;
  }
  function eI(e) {
    var t = tI(e, "string");
    return typeof t == "symbol" ? t : t + "";
  }
  function tI(e, t) {
    if (typeof e != "object" || !e) return e;
    var r = e[Symbol.toPrimitive];
    if (r !== void 0) {
      var a = r.call(e, t);
      if (typeof a != "object") return a;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (t === "string" ? String : Number)(e);
  }
  function gA(e) {
    return e && e.map((t, r) => W.createElement(t.tag, xu({ key: r }, t.attr), gA(t.child)));
  }
  function nI(e) {
    return (t) => W.createElement(rI, Su({ attr: xu({}, e.attr) }, t), gA(e.child));
  }
  function rI(e) {
    var t = (r) => {
      var { attr: a, size: s, title: l } = e, u = KB(e, GB), f = s || r.size || "1em", p;
      return r.className && (p = r.className), e.className && (p = (p ? p + " " : "") + e.className), W.createElement("svg", Su({ stroke: "currentColor", fill: "currentColor", strokeWidth: "0" }, r.attr, a, u, { className: p, style: xu(xu({ color: e.color || r.color }, r.style), e.style), height: f, width: f, xmlns: "http://www.w3.org/2000/svg" }), l && W.createElement("title", null, l), e.children);
    };
    return tS !== void 0 ? W.createElement(tS.Consumer, null, (r) => t(r)) : t(mA);
  }
  function rS(e) {
    return nI({ attr: { viewBox: "0 0 448 512" }, child: [{ tag: "path", attr: { d: "M446.7 98.6l-67.6 318.8c-5.1 22.5-18.4 28.1-37.3 17.5l-103-75.9-49.7 47.8c-5.5 5.5-10.1 10.1-20.7 10.1l7.4-104.9 190.9-172.5c8.3-7.4-1.8-11.5-12.9-4.1L117.8 284 16.2 252.2c-22.1-6.9-22.5-22.1 4.6-32.7L418.2 66.4c18.4-6.9 34.5 4.1 28.5 32.2z" }, child: [] }] })(e);
  }
  const Qh = "https://t.me/xlammodz", oI = false;
  function oS() {
    const e = new URL(Qh);
    if (e.protocol !== "https:" || e.hostname !== "t.me") {
      console.error("[xlam-modz] blocked non-telegram redirect:", Qh);
      return;
    }
    window.open(Qh, "_blank", "noreferrer");
  }
  function aI() {
    const [e, t] = y.useState(null), [r, a] = y.useState(oI), [s, l] = y.useState(false);
    y.useEffect(() => {
      (async () => l(await window.xlamModz.getStorageValue("devtools/enabled") || false))(), window.xlamModz.onStorageChanged((f, p) => {
        f.includes("devtools/enabled") && l(p);
      });
    }, []), y.useEffect(() => {
      const f = 'div[class*="NavbarDesktopUserWidget_userProfileContainer"]', p = "mod-sheet-container", m = () => {
        var _a4;
        const g = document.querySelector(f);
        let S = document.getElementById(p);
        g ? (S || (S = document.createElement("div"), S.id = p, S.style.display = "flex", S.style.justifyContent = "center", (_a4 = g.parentNode) == null ? void 0 : _a4.insertBefore(S, g)), t(S)) : (S && S.remove(), t(null));
      };
      m();
      const v = new MutationObserver(m);
      return v.observe(document.body, { childList: true, subtree: true }), () => {
        v.disconnect();
        const g = document.getElementById(p);
        g && g.remove();
      };
    }, []);
    const u = b.jsxs(b.Fragment, { children: [b.jsxs(lP, { className: "flex w-full items-center justify-center gap-2.5 rounded-full border-2 border-[var(--ym-outline-color-primary-disabled)] p-[5px] text-[var(--ym-controls-color-primary-text-enabled_variant)] transition-colors duration-100 ease-in-out hover:bg-[var(--ym-surface-color-primary-enabled-list)] px-6", children: [b.jsx("div", { className: "h-[25px] w-[25px] bg-contain bg-no-repeat", style: { backgroundImage: `url(${eS})` } }), b.jsx("span", { className: "trigger-text hidden lg:inline", children: "XLam ModZ" }), b.jsx(zP, { position: "bottom-right" })] }), b.jsx(XB, {})] });
    return b.jsx(Qj, { children: b.jsxs(sP, { open: r, onOpenChange: a, children: [e && Ai.createPortal(u, e), b.jsxs(fP, { side: "left", className: "w-full", onOpenAutoFocus: (f) => f.preventDefault(), children: [b.jsx("div", { id: "header", className: "flex items-center justify-between px-4", style: { height: "var(--ym-spacer-size-xxxl)", backgroundColor: "var(--ym-background-color-primary-enabled-basic)" } }), b.jsxs("div", { className: "bg-secondary/20 m-3 mb-0 flex justify-between rounded-md border px-4 py-2 shadow-sm", children: [b.jsxs("div", { className: "flex items-center gap-2", children: [b.jsx("div", { className: "h-6 w-6 bg-contain bg-no-repeat", style: { backgroundImage: `url(${eS})` } }), b.jsx("span", { className: "text-foreground text-base font-semibold", children: "XLam ModZ" }), b.jsxs("span", { className: "text-muted-foreground text-xs font-semibold", children: ["v", "2.2.0-xl.1"] })] }), b.jsx("div", { className: "flex items-center gap-2", children: b.jsxs(vu, { children: [b.jsx(yu, { children: b.jsx(Dt, { variant: "outline", size: "icon", onClick: () => oS(), children: b.jsx(rS, { className: "text-sky-500 h-[1.3rem]! w-[1.3rem]!", fill: "currentColor" }) }) }), b.jsx(bu, { side: "bottom", children: b.jsx("p", { children: "Telegram-канал @xlammodz" }) })] }) })] }), b.jsxs(G1, { className: "flex h-full flex-col p-1 pt-0 overflow-hidden overflow-x-auto overflow-y-auto rounded-md", viewportClassName: "gap-2", children: [b.jsx(C9, {}), b.jsx(QB, {}), b.jsx(M9, {}), b.jsx(PB, {}), b.jsx(kL, {}), b.jsx(oB, {}), b.jsx(T9, {}), b.jsx(R9, {}), b.jsx(LL, {}), s && b.jsx(b.Fragment, { children: b.jsx(LU, {}) }), b.jsx("div", { className: "flex flex-col gap-4 justify-center items-center m-6", children: b.jsxs("div", { className: "py-3 px-2 w-full flex flex-row justify-center items-center gap-4 border-sky-500 border-1 rounded-xl hover:scale-105 transition-all cursor-pointer opacity-90 dark:opacity-100", onClick: () => oS(), children: [b.jsx(rS, { className: "text-white h-[2.5rem]! w-[2.5rem]!", fill: "currentColor" }), b.jsxs("div", { className: "flex flex-col gap-1 justify-center items-start", children: [b.jsx("span", { className: "text-white text-lg font-semibold", children: "XLam ModZ" }), b.jsx("span", { className: "text-slate-200 text-sm mt-[-3px]", children: "Новости мода в Telegram — @xlammodz" })] })] }) })] }), b.jsxs("div", { className: "m-4 flex flex-row", children: [b.jsx(Dt, { variant: "default", className: "flex-1 opacity-0", onClick: () => a(false), children: "Сохранить" }), b.jsx(Dt, { variant: "outline", className: "text-foreground flex-1", onClick: () => a(false), children: "Назад" })] })] })] }) });
  }
  const iI = new kj();
  document.addEventListener("DOMContentLoaded", () => {
    const e = document.createElement("div");
    e.id = "xlam-modz-sidebar", document.body.appendChild(e), fj.createRoot(e, {}).render(b.jsx(y.StrictMode, { children: b.jsx(Lj, { client: iI, children: b.jsx(aI, {}) }) }));
  });
  const aS = "xlam-modz-font-changer-style";
  async function vA() {
    var _a4;
    const e = await window.xlamModz.getStorageValue("font-changer/savedFont"), t = await window.xlamModz.getStorageValue("font-changer/enabled"), r = zp.find((s) => s.name === e) || zp[0];
    if (console.log("[font-changer]", { savedFont: r, fontChangerEnabled: t }), (_a4 = document.getElementById(aS)) == null ? void 0 : _a4.remove(), !t) return;
    if (!r) {
      console.error("[font-changer]", "No font found");
      return;
    }
    const a = document.createElement("style");
    a.id = aS, a.innerHTML = `* {
  font-family: "${r.family}" !important;
}
${(r == null ? void 0 : r.extraStylesheet) || ""}
`, document.head.appendChild(a);
  }
  window.xlamModz.onStorageChanged((e, t) => {
    e.includes("font-changer") && vA();
  });
  vA();
  const iS = "xlam-modz-scale-changer-style";
  async function yA() {
    var _a4;
    const e = await window.xlamModz.getStorageValue("scale-changer/savedScale") || 1;
    console.log("[scale-changer]", { savedScale: e }), (_a4 = document.getElementById(iS)) == null ? void 0 : _a4.remove();
    const t = document.createElement("style");
    t.id = iS, t.innerHTML = `div[class*="DefaultLayout_root_"] {
  zoom: ${e} !important;
}
`, document.head.appendChild(t);
  }
  window.xlamModz.onStorageChanged((e, t) => {
    e.includes("scale-changer") && yA();
  });
  yA();
  const sI = ":root{--xlamModzPalette-50: color-mix(in srgb, var(--xlamModzAccent) 6%, black 93%);--xlamModzPalette-100: color-mix(in srgb, var(--xlamModzAccent) 9%, black 95%);--xlamModzPalette-200: color-mix(in srgb, var(--xlamModzAccent) 30%, black 70%);--xlamModzPalette-300: color-mix(in srgb, var(--xlamModzAccent) 40%, black 60%);--xlamModzPalette-400: color-mix(in srgb, var(--xlamModzAccent) 50%, black 50%);--xlamModzPalette-500: color-mix(in srgb, var(--xlamModzAccent) 60%, black 40%);--xlamModzPalette-600: color-mix(in srgb, var(--xlamModzAccent) 70%, black 30%);--xlamModzPalette-700: color-mix(in srgb, var(--xlamModzAccent) 80%, black 20%);--xlamModzPalette-800: color-mix(in srgb, var(--xlamModzAccent) 90%, black 10%);--xlamModzPalette-900: color-mix(in srgb, var(--xlamModzAccent) 95%, black 5%);--xlamModzPalette-light-50: color-mix(in srgb, var(--xlamModzAccent) 6%, white 94%);--xlamModzPalette-light-100: color-mix(in srgb, var(--xlamModzAccent) 9%, white 91%);--xlamModzPalette-light-200: color-mix(in srgb, var(--xlamModzAccent) 30%, white 70%);--xlamModzPalette-light-300: color-mix(in srgb, var(--xlamModzAccent) 40%, white 60%);--xlamModzPalette-light-400: color-mix(in srgb, var(--xlamModzAccent) 50%, white 50%);--xlamModzPalette-light-500: color-mix(in srgb, var(--xlamModzAccent) 60%, white 40%);--xlamModzPalette-light-600: color-mix(in srgb, var(--xlamModzAccent) 70%, white 30%);--xlamModzPalette-light-700: color-mix(in srgb, var(--xlamModzAccent) 80%, white 20%);--xlamModzPalette-light-800: color-mix(in srgb, var(--xlamModzAccent) 90%, white 10%);--xlamModzPalette-light-900: color-mix(in srgb, var(--xlamModzAccent) 95%, white 5%)}div[class*=VibeAnimation_root__]:after{background:transparent!important}.ym-dark-theme{--ym-background-color-primary-enabled-basic: var(--xlamModzPalette-50) !important;--ym-background-color-primary-enabled-popover: var(--xlamModzPalette-100) !important;--ym-controls-color-secondary-outline-disabled: var(--xlamModzPalette-50) !important;--ym-controls-color-secondary-outline-selected: var(--xlamModzPalette-100) !important;--ym-controls-color-secondary-outline-hovered: var(--xlamModzPalette-100) !important;--ym-controls-color-primary-outline-disabled: var(--xlamModzPalette-800) !important;--ym-controls-color-primary-outline-enabled: var(--xlamModzPalette-200) !important;--ym-controls-color-primary-outline-hovered: var(--xlamModzPalette-200) !important;--ym-controls-color-primary-outline-selected_stroke: var(--xlamModzPalette-800) !important;--ym-controls-color-primary-default-disabled: var(--xlamModzPalette-600) !important;--ym-controls-color-primary-default-enabled: var(--xlamModzPalette-900) !important;--ym-controls-color-primary-default-hovered: var(--xlamModzPalette-800) !important;--ym-controls-color-primary-default-pressed: var(--xlamModzPalette-500) !important;--ym-background-color-primary-enabled-content: var(--xlamModzPalette-100) !important;--ym-logo-color-primary-variant: var(--xlamModzPalette-900) !important;--ym-logo-color-primary-player: var(--xlamModzPalette-900) !important}.ym-light-theme{--ym-controls-color-primary-outline-disabled: var(--xlamModzPalette-light-100) !important;--ym-controls-color-primary-outline-enabled: var(--xlamModzPalette-light-200) !important;--ym-controls-color-primary-outline-hovered: var(--xlamModzPalette-light-300) !important;--ym-controls-color-primary-outline-selected_stroke: var(--xlamModzPalette-light-800) !important;--ym-controls-color-primary-default-disabled: var(--xlamModzPalette-light-400) !important;--ym-controls-color-primary-default-enabled: var(--xlamModzPalette-light-900) !important;--ym-controls-color-primary-default-hovered: var(--xlamModzPalette-light-800) !important;--ym-controls-color-primary-default-pressed: var(--xlamModzPalette-light-600) !important;--ym-logo-color-primary-variant: var(--xlamModzPalette-light-900) !important;--ym-logo-color-primary-player: var(--xlamModzPalette-light-100) !important}", sS = "xlam-modz-custom-themes-style";
  let lS = setInterval(() => {
  }, 1e3 * 60 * 60), bA = false, Ip = "#4A9EFF";
  async function wA() {
    var _a4;
    const e = await window.xlamModz.getStorageValue("custom-themes/enabled") === true, t = await window.xlamModz.getStorageValue("custom-themes/accent"), r = await window.xlamModz.getStorageValue("custom-themes/playerColorsReplace") !== false, a = await window.xlamModz.getStorageValue("custom-themes/disableVibeAnimation"), s = await window.xlamModz.getStorageValue("custom-themes/disableExplicitMark"), l = await window.xlamModz.getStorageValue("custom-themes/hideMenuItems") || [];
    if (console.log("[custom-themes]", { enabled: e, accent: t, playerColorsReplaceEnabled: r, disableVibeAnimation: a, disableExplicitMark: s, hiddenMenuItems: l }), bA = e, Ip = t, (_a4 = document.getElementById(sS)) == null ? void 0 : _a4.remove(), e && t) {
      const u = document.createElement("style");
      if (u.id = sS, u.innerHTML = sI, u.innerHTML += `
      :root {
        --xlamModzAccent: ${t};
      }`, r && (u.innerHTML += `
        .ym-dark-theme 
        section[data-test-id="PLAYERBAR_DESKTOP"]
        {
          --player-average-color-background: var(--xlamModzPalette-200) !important;
        }
        .ym-dark-theme 
        div[data-test-id="FULLSCREEN_PLAYER_MODAL"]
        {
          --player-average-color-background: var(--xlamModzPalette-200) !important;
        }
        .ym-light-theme
        section[data-test-id="PLAYERBAR_DESKTOP"],
        div[data-test-id="FULLSCREEN_PLAYER_MODAL"]
        {
          --player-average-color-background: var(--xlamModzPalette-700) !important;
        }
        .ym-dark-theme div[class*="_averageColorBackground__"] {
          background: linear-gradient(var(--xlamModzPalette-200, var(--ym-background-color-secondary-enabled-blur)) 0, transparent 100%); 
        }
        .ym-light-theme div[class*="_averageColorBackground__"] {
          background: linear-gradient(var(--xlamModzPalette-light-300, var(--ym-background-color-secondary-enabled-blur)) 0, transparent 100%); 
        }
      `), clearInterval(lS), a ? (u.innerHTML += `
        div[data-test-id="VIBE_BLOCK"] {
            height: 32vh !important;
            min-height: unset !important;
        }
        div[data-test-id="VIBE_ANIMATION"] {
          display: none!important;
        }
          `, lS = setInterval(() => {
        _u("vibe-animation-worker-disable", void 0);
      }, 2e3)) : _u("vibe-animation-worker-enable", void 0), s && (u.innerHTML += `
        span[class*="Meta_explicitMarkContainer__"], svg[class*="ExplicitMarkIcon_"], svg[class*="explicitMark__"] {
          display: none!important;
        }
      `), l && l.length > 0) for (const f of l) u.innerHTML += `
          aside[data-test-id="NAVBAR"] li:has(a[href="/${f}"]) {
            display: none!important;
          }
        `;
      document.head.appendChild(u), SA();
    }
  }
  function SA() {
    function e(a, s = 0) {
      a = a.replace(/^#/, ""), a.length === 3 && (a = a.split("").map((S) => S + S).join(""));
      const l = parseInt(a.substring(0, 2), 16) / 255, u = parseInt(a.substring(2, 4), 16) / 255, f = parseInt(a.substring(4, 6), 16) / 255, p = Math.max(l, u, f), m = Math.min(l, u, f), v = p - m;
      let g = 0;
      if (v !== 0) {
        switch (p) {
          case l:
            g = (u - f) / v % 6;
            break;
          case u:
            g = (f - l) / v + 2;
            break;
          case f:
            g = (l - u) / v + 4;
            break;
        }
        g *= 60, g < 0 && (g += 360);
      }
      return g = (g + s) % 360, g < 0 && (g += 360), g;
    }
    function t(a) {
      const s = document.createElement("div");
      s.style.display = "none", s.style.color = `var(${a})`, document.body.appendChild(s);
      const l = getComputedStyle(s).color;
      document.body.removeChild(s);
      let u;
      return l.startsWith("color(srgb") ? (u = l.match(/color\(srgb ([\d.]+) ([\d.]+) ([\d.]+)\)/), u ? { r: parseFloat(u[1]), g: parseFloat(u[2]), b: parseFloat(u[3]) } : null) : l.startsWith("rgb") ? (u = l.match(/rgb\((\d+), (\d+), (\d+)\)/), u ? { r: parseInt(u[1], 10) / 255, g: parseInt(u[2], 10) / 255, b: parseInt(u[3], 10) / 255 } : null) : null;
    }
    const r = t("--ym-background-color-primary-enabled-content");
    console.log("[custom-themes] updateVibeBackgroundColor", r), r && (_u("vibe-animation-worker-apply-settings", { isXlamModz: true, backgroundColor: [r.r, r.g, r.b] }), bA && _u("vibe-animation-worker-apply-settings", { isXlamModz: true, collectionHue: e(Ip, 50), hue: e(Ip, 50), useDefaultHue: false }));
  }
  window.xlamModz.onStorageChanged((e, t) => {
    e.includes("custom-themes") && wA();
  });
  wA();
  (function() {
    window.__workers = [];
    const e = window.Worker;
    window.Worker = function(...r) {
      const a = new e(...r), s = a.postMessage;
      return window.__workers.push(a), a.postMessage = function(l, u) {
        var _a4, _b2, _c3;
        return (((_a4 = l == null ? void 0 : l.payload) == null ? void 0 : _a4.backgroundColor) || ((_b2 = l == null ? void 0 : l.payload) == null ? void 0 : _b2.collectionHue)) && (((_c3 = l == null ? void 0 : l.payload) == null ? void 0 : _c3.isXlamModz) || setTimeout(() => {
          SA();
        }, 500)), s.call(a, l, u);
      }, a;
    };
    const t = atob;
    window.atob = function(r) {
      const a = t(r);
      if (a.includes("updateBackgroundColor(t){this.background=new c(t,t,t)}")) {
        const s = a.replace("updateBackgroundColor(t){this.background=new c(t,t,t)}", `
        updateBackgroundColor(t)
        {
            if(Array.isArray(t))
              this.background=new c(t[0],t[1],t[2]);
            else
              this.background=new c(t,t,t);
         }
        `);
        return console.log("[custom-themes] Modified vibe animation worker code"), s;
      }
      return a;
    };
  })();
  function _u(e, t) {
    for (const r of window.__workers.filter((a) => !a.objectURL)) r.postMessage({ source: "vibe", type: e, payload: t });
  }
  const lI = "div[class*=TitleBar_root__],div[class*=NavbarDesktop_logoWrapper__],div[class*=NavbarDesktop_subTitle__]{display:none!important}*{--ym-spacer-size-xxxl: 1rem !important}div[class*=applicationPreserveTitleBar__]{padding-block-start:1rem!important}";
  (async () => {
    const e = await window.xlamModz.getStorageValue("devtools/systemToolbar");
    if (console.log("[devtools] systemToolbarEnabled", e), e) {
      const t = document.createElement("style");
      t.id = "xlam-modz-devtools-style", t.innerHTML = lI, document.head.appendChild(t);
    }
  })();
  async function xA() {
    const e = await window.xlamModz.getStorageValue("autoBestQuality/enabled") !== false;
    if (console.log("[auto-best-quality] enabled", e), !!e && window.localStorage.ymPlayerQuality) {
      const t = JSON.parse(window.localStorage.ymPlayerQuality);
      if (!t) return;
      const r = t.value !== "high_quality";
      t.value = "high_quality", t.expires = "2077-01-01T11:29:20.427Z", window.localStorage.setItem("ymPlayerQuality", JSON.stringify(t)), console.log("[auto-best-quality] setting best quality", t), r && window.location.reload();
    }
  }
  window.xlamModz.onStorageChanged((e, t) => {
    e.includes("autoBestQuality") && xA();
  });
  xA();
  let Kc = [];
  (async () => {
    const e = await window.xlamModz.getStorageValue("settings/accountExperimentsOverride") || [];
    console.log("[experimentsOverride] ", e), e && e.length > 0 && (Kc = [...e]);
  })();
  Zr("/account/experiments/details", async function(e) {
    if (console.log("[experimentsOverride] Original experiments:", e.data), !Kc || Kc.length === 0) return console.log("[experimentsOverride] No overrides configured, returning original data"), e.data;
    const t = { ...e.data };
    return Kc.forEach((r) => {
      r.id && t[r.id] ? (console.log(`[experimentsOverride] Overriding experiment ${r.id}:`, r.value), t[r.id] = r.value) : r.id && (console.log(`[experimentsOverride] Adding new experiment ${r.id}:`, r.value), t[r.id] = r.value);
    }), console.log("[experimentsOverride] Modified experiments:", t), t;
  });
  kT();
})();
